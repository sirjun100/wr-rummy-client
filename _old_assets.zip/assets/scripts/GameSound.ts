// @ts-nocheck
// Recovered from index.js:169
import { _decorator, Component, assert, AudioSource, director, Node } from "cc";
import SoundManager from "./SoundManager";
const { ccclass, property } = _decorator;
@ccclass("GameSound")
export class GameSound extends Component {
    @property(Node)
    public lob_bg: Node = null;
    @property(Node)
    public room_bg: Node = null;
    @property(Node)
    public sound: Node = null;
    public _hallAudioSource: any = null;
    public _roomAudioSource: any = null;
    public _soundAudioSource: any = null;
    onLoad() {
        const o = this.lob_bg.getComponent(AudioSource);
        assert(o);
        this._hallAudioSource = o;
        const e = this.room_bg.getComponent(AudioSource);
        assert(e);
        this._roomAudioSource = e;
        const t = this.sound.getComponent(AudioSource);
        assert(t);
        this._soundAudioSource = t;
        this.node.name = "GameSound";
        director.addPersistRootNode(this.node);
        SoundManager.shared().initAudioSource(this._hallAudioSource, this._roomAudioSource, this._soundAudioSource);
    }
    onEnable() {
        SoundManager.shared().playMusic(true);
    }
    start() {
        "undefined" != typeof cocosAnalytics && cocosAnalytics.enableDebug(true);
    }
}
