// @ts-nocheck
// Recovered from index.js:139
import { _decorator, tween } from "cc";
import { ToolUtils } from "./ToolUtils";
import FruitSlotGameCmd from "./FruitSlotGameCmd";
import User from "./User";
import GameConfig from "./GameConfig";
import { TLog } from "./TLog";
import Server from "./Server";
import URLConfig from "./URLConfig";
import NetHostManager from "./NetHostManager";
import NetConfig from "./NetConfig";
import PushCenter from "./PushCenter";
import gameNetworkDelay from "./gameNetworkDelay";
import TweenTool from "./TweenTool";
import Utils from "./Utils";
import PushEvent from "./PushEvent";
import i18nMgr from "./i18nMgr";
const { ccclass } = _decorator;
@ccclass("FruitSlotGameManager")
export class FruitSlotGameManager {
    static _instance = null;
    public _TAG: string = "FruitSlotGameManager";
    public checkLoadingRefresh: boolean = false;
    public sceneNode: any = null;
    public popNode: any = null;
    public _tidKey: string = "";
    public _vid: number = 0;
    public _coin: number = 0;
    public _multiple: any[] = [];
    public _winscore: number = 0;
    public _hasRedPoint: number = 0;
    public _isBet: boolean = true;
    public _gameState: number = 1;
    public _betIndex: number = 0;
    public _raisBetlist: any[] = [];
    public _isAuto: number = 0;
    public _result: any[] = [1, 2, 3, 8, 8, 8, 4, 5, 6, 7, 4, 5, 9, 8, 8];
    public _cur_freegame_win_socre: number = 0;
    public _isfast: number = 0;
    public _autoNum: number = 0;
    public _win_data: any[] = [];
    public _winshow_anim: number = 0;
    public _free_game_num: number = 0;
    public _freegamecount: number = 0;
    public _is_xyc_complete: boolean = false;
    public _game_win_socre: number = 0;
    public _game_state_type: number = 0;
    public _free_game_total_win: number = 0;
    public _jackpot_type: number = 0;
    public _near_win_cols: any[] = [];
    public _jackpot_win: number = 0;
    public isAnimPlaying: boolean = false;
    public data: any = {};
    constructor() {
        this.init();
    }
    static shared(): FruitSlotGameManager {
        return null == this._instance && (this._instance = new FruitSlotGameManager), this._instance;
    }
    init() {
    }
    sendLoginRequest() {
        let e = { cmd: FruitSlotGameCmd.GM_LOGIN_REQUEST, ch_id: 0, uid: User.shared().data.uid, version: GameConfig.Server_Api_Ver, skey: User.shared().getSkey(), vid: ToolUtils.curRoomId, tid_key: this._tidKey };
        Server.shared().send(e);
    }
    sendGameInfoRequest() {
        let t = { cmd: FruitSlotGameCmd.GM_GET_TABLE_INFO, uid: User.shared().data.uid, version: GameConfig.Server_Api_Ver, skey: User.shared().getSkey(), vid: ToolUtils.curRoomId, tid_key: this._tidKey };
        Server.shared().send(t);
        FruitSlotGameManager.shared().checkLoadingRefresh = true;
        TweenTool.delayAct(this.sceneNode, (() => {
            FruitSlotGameManager.shared().checkLoadingRefresh && (FruitSlotGameManager.shared().checkLoadingRefresh = false, ToolUtils.backgroundWebSocketReconnection = false, Server.shared().disconnectWebSocket(), TweenTool.delayAct(this.sceneNode, (() => {
                FruitSlotGameManager.shared().loginGameServer();
            }), 0.2, true));
        }), 5, true);
    }
    sendLoginOutRequest() {
        let e = { cmd: FruitSlotGameCmd.GM_LOGINOUT_REQUEST, uid: User.shared().data.uid, version: GameConfig.Server_Api_Ver, skey: User.shared().getSkey(), vid: ToolUtils.curRoomId, tid_key: this._tidKey };
        Server.shared().send(e);
    }
    sendBetRequest() {
        let e = { cmd: FruitSlotGameCmd.GM_BET_REQUEST, uid: User.shared().data.uid, version: GameConfig.Server_Api_Ver, skey: User.shared().getSkey(), vid: ToolUtils.curRoomId, bet: this._raisBetlist[this._betIndex], tid_key: this._tidKey };
        Server.shared().send(e);
    }
    judgeCoin(e, t) {
        if (e < t) {
            let e = { vid: ToolUtils.curVId, min_entry: t };
            return User.shared().fastBuy(e), true;
        }
        return false;
    }
    sendAutoBetRequest(e) {
        let t = 1;
        1 == this._isAuto && (t = 0);
        let s = { cmd: FruitSlotGameCmd.GM_AUTO_BET_REQUEST, uid: User.shared().data.uid, version: GameConfig.Server_Api_Ver, skey: User.shared().getSkey(), vid: ToolUtils.curRoomId, tid_key: this._tidKey, type: t, count: e };
        Server.shared().send(s);
    }
    sendBetChangeRequest(e) {
        let t = { cmd: FruitSlotGameCmd.GM_NOTIFY_BET_CHANGE, uid: User.shared().data.uid, version: GameConfig.Server_Api_Ver, skey: User.shared().getSkey(), vid: ToolUtils.curRoomId, tid_key: this._tidKey, cur_bet: this._raisBetlist[e] };
        Server.shared().send(t);
    }
    sendGameRecordRequest() {
        let e = { cmd: FruitSlotGameCmd.GM_HISTORY_RECORD_REQUSET, uid: User.shared().data.uid, version: GameConfig.Server_Api_Ver, skey: User.shared().getSkey(), vid: ToolUtils.curRoomId, tid_key: this._tidKey };
        Server.shared().send(e);
    }
    sendSpeedRequest(e) {
        let t = { cmd: FruitSlotGameCmd.GM_SPEED_REQUEST, uid: User.shared().data.uid, version: GameConfig.Server_Api_Ver, skey: User.shared().getSkey(), vid: ToolUtils.curRoomId, type: e, tid_key: this._tidKey };
        Server.shared().send(t);
    }
    loginGameServer() {
        this.checkLoadingRefresh = false;
        Server.shared().setOpenCb((() => {
            User.shared().send_login_gate_request();
        }));
        Server.shared().setReconCb((() => {
            User.shared().send_request_game_tableinfo();
        }));
        let e = URLConfig.orginHttp_tcp, t = NetHostManager.shared().chooseBestTcpIpConn(ToolUtils.curRoomId), s = NetHostManager.shared().chooseBestTcpPortConn(ToolUtils.curRoomId);
        "-1" != t && -1 != s && (e = 443 == s ? "wss://" + t + ":443" : "ws://" + t + ":" + s);
        Server.shared().createSocket(e);
        User.shared().isGameDisconnectServer = false;
    }
    login(e = false) {
        User.shared().curTid_key === this._tidKey && this.loginGameServer();
    }
    create_new_table() {
        if (User.shared().isGameDisconnectServer) {
            return Server.shared().disconnectWebSocket(), void this.login(true);
        }
        this.send_create_table_request();
    }
    send_create_table_request() {
        let e = { cmd: NetConfig.GM_CREATE_TABLE_REQUEST, uid: User.shared().data.uid, version: GameConfig.Server_Api_Ver, skey: User.shared().getSkey(), vid: this._vid, auto_sort: User.shared().auto_sort, ch_id: GameConfig.CHANNEL_ID };
        e.tid_key = this._tidKey;
        Server.shared().send(e);
    }
    handler_server_login_gate_return(e) {
        try {
            if (0 == e.res) {
                this.send_login_request();
                PushCenter.shared().pushEvent(GameConfig.NetWorkDelayShow);
            }
            else if (2 == e.res) {
                gameNetworkDelay.shared().setActiveDisconnect(true);
                User.shared().isGameDisconnectServer = true;
                Server.shared().disconnectWebSocket();
                let t = "You are not in any table!", s = "NOTICE";
                ToolUtils.isSafeString(e.title).length > 0 && (s = e.title);
                ToolUtils.isSafeString(e.msg).length > 0 && (t = e.msg);
                TweenTool.delayAct(this.sceneNode, (() => {
                    window.InGameScene && Utils.shared().showCommomDialog(t, s, (e => {
                        PushCenter.shared().pushEvent(PushEvent.ExitGameToHall);
                    }), false, ToolUtils.getIsNormalDirection());
                }), 2, true);
            }
            else {
                Utils.shared().showCommomDialog(i18nMgr.shared().getValueByKey("rummy_main.gameTipstext11"), i18nMgr.shared().getValueByKey("gameRummy_notice_Pop.notice"), (e => {
                    PushCenter.shared().pushEvent(PushEvent.ExitGameToHall);
                }), false, ToolUtils.getIsNormalDirection(), null, null, null, null, null, null);
            }
        }
        catch (e) {
            TLog.printError("trycatch handler_server_login_gate_return ,error:", e);
        }
    }
    send_login_request() {
        let e = { cmd: NetConfig.GM_LOGIN_REQUEST, uid: User.shared().data.uid, skey: User.shared().getSkey(), version: GameConfig.Server_Api_Ver, ch_id: GameConfig.CHANNEL_ID, tid_key: this._tidKey };
        e.vid = ToolUtils.curVId;
        Server.shared().send(e);
    }
    static parseJackPotNum(e) {
        if (e < 1000) {
            return `${Math.floor(e)}`;
        }
        if (e < 100000) {
            const t = e % 1000;
            return `${Math.floor(e / 1000) % 100},${t.toString().padStart(3, "0")}`;
        }
        if (e < 10000000) {
            const t = e % 1000, s = Math.floor(e / 1000) % 100;
            return `${Math.floor(e / 100000) % 100},${s.toString().padStart(2, "0")},${t.toString().padStart(3, "0")}`;
        }
        if (e < 1000000000) {
            const t = e % 1000, s = Math.floor(e / 1000) % 100, i = Math.floor(e / 100000) % 100;
            return `${Math.floor(e / 10000000) % 100},${i.toString().padStart(2, "0")},${s.toString().padStart(2, "0")},${t.toString().padStart(3, "0")}`;
        }
        {
            const t = e % 1000, s = Math.floor(e / 1000) % 100, i = Math.floor(e / 100000) % 100, r = Math.floor(e / 10000000) % 100;
            return `${Math.floor(e / 1000000000) % 100},${r.toString().padStart(2, "0")},${i.toString().padStart(2, "0")},${s.toString().padStart(2, "0")},${t.toString().padStart(3, "0")}`;
        }
    }
    static playTextAnim(t, s, r, a) {
        if (TweenTool.stopNodeAction(t), t.string = FruitSlotGameManager.parseJackPotNum(r), Math.abs(a - r) > 0) {
            const n = 0.03, d = (a - r) / Math.floor(s / n);
            let o = r, h = tween(t).delay(n), _ = tween(t).call((() => {
                o += d;
                let s = FruitSlotGameManager.parseJackPotNum(o);
                t.string = "₹" + s;
            }));
            tween(t).sequence(h, _).repeatForever().start();
        }
    }
    static arrayUnique(e) {
        const t = {}, s = [];
        for (let i = 0; i < e.length; i++) {
            const r = e[i];
            t[r] || (s.push(r), t[r] = true);
        }
        return s.sort(((e, t) => e < t ? -1 : e > t ? 1 : 0)), s;
    }
}
