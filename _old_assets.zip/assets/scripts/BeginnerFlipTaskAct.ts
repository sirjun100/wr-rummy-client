// @ts-nocheck
// Recovered from index.js:31
import { _decorator, Button, Label, Node, ProgressBar, size, Sprite, SpriteFrame, sys } from "cc";
import BaseLayer from "./BaseLayer";
import PushCenter from "./PushCenter";
import PushEvent from "./PushEvent";
import Utils from "./Utils";
import TweenTool from "./TweenTool";
import User from "./User";
import i18nMgr from "./i18nMgr";
import { CheckModule, CommonGameType, HallGameType } from "./CommDefine";
import HowToPlayDefined from "./HowToPlayDefined";
import { ToolUtils } from "./ToolUtils";
import SoundManager from "./SoundManager";
import PhpReportDefined from "./PhpReportDefined";
const { ccclass, property } = _decorator;
@ccclass("BeginnerFlipTaskAct")
export class BeginnerFlipTaskAct extends BaseLayer {
    public TAG: string = "BeginnerFlipTaskAct";
    @property(Node)
    public root: Node = null;
    @property(Node)
    public itemRoot: Node = null;
    @property(Node)
    public expireTime: Node = null;
    @property(Node)
    public playNowBtn: Node = null;
    @property(Node)
    public target_room_info: Node = null;
    @property([SpriteFrame])
    public bgImgs: SpriteFrame[] = [];
    @property([SpriteFrame])
    public taskIcons_cb: SpriteFrame[] = [];
    public has_reportUI: boolean = false;
    public _lastClick: number = 0;
    public _linkId: number = 0;
    public _reportScene: any = -1;
    public _initDelay: number = 0;
    public _pop_souce: number = 0;
    public taskAwardIconMap: Map = new Map;
    public _jumpHtype: any = HallGameType.LOBBY_GAME_TYPE_RUMMY;
    public _jumpShowStr: string = "Rummy-Points/Classic-6P";
    public _has_close: boolean = false;
    public isNext: boolean = false;
    public targetRoom: any = null;
    public ruleInit: boolean = false;
    onLoad() {
        PushCenter.shared().addListener(PushEvent.RefreshFlopCashTask, (e => {
            ToolUtils.isObjValid(this.node) && this.refreshView();
        }), this);
        PushCenter.shared().addListener(PushEvent.commentDownloaderImg, (e => {
            if (sys.isObjectValid(this.node) && this.taskAwardIconMap.size > 0) {
                for (const [t, i] of this.taskAwardIconMap) {
                    i == e && Utils.shared().updateNetImage(t, e, size(158, 158));
                }
            }
        }), this);
    }
    start() {
        super.start();
        this._linkId = this._linkId > 0 ? this._linkId : sys.now();
        this._reportScene = this._reportScene >= 0 ? this._reportScene : ToolUtils.getIsInRoom() ? 2 : 1;
        this.startShowAnim(this.root);
        ToolUtils.showFullScreen(this.node.getChildByName("mask"));
        this.initView();
        TweenTool.delayAct(this.node, (() => {
            null !== User.shared().flopCashTaskData && this.refreshView();
            User.shared().requestFlopCashTaskInfo();
        }), this._initDelay, true);
        SoundManager.shared().playFx("act_popshow");
    }
    initView() {
        for (let e = 0; e < 5; e++) {
            let t = this.itemRoot.getChildByName("moban" + e);
            sys.isObjectValid(t) && (t.getChildByName("bg").getComponent(Sprite).spriteFrame = this.bgImgs[0], t.getChildByName("icon").active = false, t.getChildByName("reward_node").active = false, t.getChildByName("total").active = false, t.getChildByName("effect").active = false, t.getChildByName("mask").active = false);
            this.root.getChildByName("cmp_tip").active = false;
            this.root.getChildByName("ProgressBar").active = true;
            this.root.getChildByName("percent").active = true;
        }
        this.taskAwardIconMap.clear();
    }
    refreshView() {
        let e = User.shared().flopCashTaskData;
        if (!sys.isObjectValid(e)) {
            return;
        }
        sys.isObjectValid(e.time_left) && (TweenTool.stopNodeAction(this.expireTime), this.updateTime(), TweenTool.myschedule(this.expireTime, 1, (() => {
            ToolUtils.isObjValid(this.node) && this.updateTime();
        })));
        let t = 1;
        if (sys.isObjectValid(e.today_task_status) && (t = e.today_task_status, 1 == t ? (i18nMgr.shared().changeLocalizedLabelKey(this.playNowBtn.getChildByName("txt"), "choose_game.play_now"), this.playNowBtn.getComponent(Button).clickEvents[0].customEventData = "play") : (i18nMgr.shared().changeLocalizedLabelKey(this.playNowBtn.getChildByName("txt"), "email.okey"), this.playNowBtn.getComponent(Button).clickEvents[0].customEventData = "close")), sys.isObjectValid(e.max_reward) && (this.root.getChildByName("tip").getComponent(Label).string = ToolUtils.format(i18nMgr.shared().getValueByKey("flop_cash.up_tip"), e.max_reward)), 1 == t) {
            this.initView();
            sys.isObjectValid(e.current_play_num) && sys.isObjectValid(e.target_play_num) && 0 != e.target_play_num && (this.root.getChildByName("ProgressBar").getComponent(ProgressBar).progress = e.current_play_num / e.target_play_num, this.root.getChildByName("ProgressBar").active = true, this.root.getChildByName("percent").getComponent(Label).string = ToolUtils.format(i18nMgr.shared().getValueByKey("flop_cash.percent"), e.current_play_num, e.target_play_num), this.root.getChildByName("percent").active = true);
        }
        else {
            this.root.getChildByName("ProgressBar").active = false;
            this.root.getChildByName("percent").active = false;
            sys.isObjectValid(e.is_last_day) && (this.root.getChildByName("cmp_tip").active = true, 1 == e.is_last_day ? i18nMgr.shared().changeLocalizedLabelKey(this.root.getChildByName("cmp_tip"), "flop_cash.cmp_tip2") : i18nMgr.shared().changeLocalizedLabelKey(this.root.getChildByName("cmp_tip"), "flop_cash.cmp_tip"));
            let t = 0;
            sys.isObjectValid(e.reward) && Array.isArray(e.reward) && e.reward.length > 0 && (t = e.reward.length);
            t > 5 && (t = 5);
            for (let i = 0; i < t; i++) {
                let t = this.itemRoot.getChildByName("moban" + i);
                this.initItemView(t, e.reward[i]);
            }
        }
        this.refreshPlayRoom();
        this.refreshBtnStatus();
    }
    updateTime() {
        let e = User.shared().flopCashTaskData;
        sys.isObjectValid(e.time_left) && Number(e.time_left) > 0 ? (User.shared().flopCashTaskData.time_left = User.shared().flopCashTaskData.time_left - 1, this.expireTime.getComponent(Label).string = ToolUtils.format(i18nMgr.shared().getValueByKey("lottery.time_left"), Utils.shared().parseCountDown(User.shared().flopCashTaskData.time_left))) : (TweenTool.stopNodeAction(this.expireTime), this.onBackView());
    }
    refreshPlayRoom() {
        let e = null, t = User.shared().flopCashTaskData.jump;
        if (sys.isObjectValid(t)) {
            let i = sys.isObjectValid(t.game) ? t.game : HowToPlayDefined.RUMMY_POINTS, a = sys.isObjectValid(t.data) && sys.isObjectValid(t.data.player) ? t.data.player : 6, s = sys.isObjectValid(t.data) && sys.isObjectValid(t.data.mode) ? t.data.mode : 1, o = sys.isObjectValid(t.data) && sys.isObjectValid(t.data.pool_game) ? t.data.pool_game : 0, r = sys.isObjectValid(t.data) && sys.isObjectValid(t.data.deals) ? t.data.deals : 0, n = {}, h = "", d = ["Points", "Pool", "Deals"], c = "", m = ["Classic", "Easy", "Multiple", "Bump", "Double"], p = "";
            switch ((this._jumpHtype = Number(t.htype), Number(t.htype))) {
                case HallGameType.LOBBY_GAME_TYPE_RUMMY:
                    h = "Rummy", c = d[i], 0 == i ? p = m[s - 1] : 1 == i ? p = o : 2 == i && (p = r), e = User.shared().processFindBestRoom(0, i, { tplayer: a, finalMode: s, pools: o, deals: r });
                    break;
                case HallGameType.LOBBY_GAME_TYPE_PRIVATE_RUMMY:
                    this._jumpHtype = HallGameType.LOBBY_GAME_TYPE_RUMMY, h = "Rummy", c = d[i], 0 == i ? p = m[s - 1] : 1 == i ? p = o : 2 == i && (p = r), e = User.shared().processFindBestRoom(2, i, { tplayer: a, finalMode: s, pools: o, deals: r });
                    break;
                case HallGameType.LOBBY_GAME_TYPE_MATCH:
                    this._jumpHtype = HallGameType.LOBBY_GAME_TYPE_RUMMY, h = "Match", c = d[i], 0 == i ? p = m[s - 1] : 1 == i ? p = o : 2 == i && (p = r), e = User.shared().processFindBestRoom(1, i, { tplayer: a, finalMode: s, pools: o, deals: r });
                    break;
                case HallGameType.LOBBY_GAME_TYPE_SHUIGUOJI: h = "Slots", n = User.shared().getGameRoomTable(HallGameType.LOBBY_GAME_TYPE_SHUIGUOJI), sys.isObjectValid(n) && sys.isObjectValid(n.info) && (e = { bestRoom: n.info });
            }
            sys.isObjectValid(e) && sys.isObjectValid(e.bestRoom) && (c.length > 0 ? this._jumpShowStr = ToolUtils.format("${0}-${1}/${2}-${3}P/${4}", h, c, p, a, e.bestRoom.boot) : Number(t.htype) == HallGameType.LOBBY_GAME_TYPE_SHUIGUOJI ? this._jumpShowStr = ToolUtils.format("${0}", h) : this._jumpShowStr = ToolUtils.format("${0}-${1}", h, e.bestRoom.boot));
        }
        else {
            e = User.shared().processFindBestRoom(0, HowToPlayDefined.RUMMY_POINTS, { tplayer: 6, finalMode: 1 });
            sys.isObjectValid(e) && sys.isObjectValid(e.bestRoom) && (this._jumpShowStr = ToolUtils.format("Rummy-Points/Classic-6P/${0}", e.bestRoom.boot));
        }
        this.targetRoom = null;
        sys.isObjectValid(e) && sys.isObjectValid(e.bestRoom) && (this.targetRoom = e.bestRoom, this.refreshRoomInfoTips());
    }
    refreshRoomInfoTips() {
        this.targetRoom && this.target_room_info && (this.target_room_info.getComponent(Label).string = this._jumpShowStr || "");
    }
    initItemView(e, t) {
        if (sys.isObjectValid(e) && sys.isObjectValid(t)) {
            e.active = true;
            e.getChildByName("bg").getComponent(Sprite).spriteFrame = this.bgImgs[1];
            sys.isObjectValid(t.is_get) && (0 == t.is_get ? (e.getChildByName("mask").active = true, e.getChildByName("effect").active = false) : (e.getChildByName("mask").active = false, e.getChildByName("effect").active = true));
            e.getChildByName("reward_node").active = true;
            let i = -1, a = 0;
            sys.isObjectValid(t.cash) && t.cash > 0 ? (e.getChildByName("reward_node").getChildByName("cash_diban").active = true, e.getChildByName("reward_node").getChildByName("cash_diban").getChildByName("wz").getComponent(Label).string = String(t.cash), a = t.cash, i = 0) : e.getChildByName("reward_node").getChildByName("cash_diban").active = false;
            sys.isObjectValid(t.bonus) && t.bonus > 0 ? (e.getChildByName("reward_node").getChildByName("bonus_diban").active = true, e.getChildByName("reward_node").getChildByName("bonus_diban").getChildByName("wz").getComponent(Label).string = String(t.bonus), a += t.bonus, i = 0 == i ? 2 : 1) : e.getChildByName("reward_node").getChildByName("bonus_diban").active = false;
            sys.isObjectValid(t.icon_id) && (e.getChildByName("icon").active = true, 0 == i && t.icon_id >= 1 && t.icon_id <= 9 ? e.getChildByName("icon").getComponent(Sprite).spriteFrame = this.taskIcons_cb[0] : 1 == i && t.icon_id >= 1 && t.icon_id <= 6 ? e.getChildByName("icon").getComponent(Sprite).spriteFrame = this.taskIcons_cb[1] : 2 == i && t.icon_id >= 1 && t.icon_id <= 6 && (e.getChildByName("icon").getComponent(Sprite).spriteFrame = this.taskIcons_cb[2]));
            e.getChildByName("total").getComponent(Label).string = ToolUtils.format(i18nMgr.shared().getValueByKey("flip_act.total_get"), Number(a.toFixed(2)));
            e.getChildByName("total").active = true;
        }
    }
    initParaData(e) {
        sys.isObjectValid(e) && sys.isObjectValid(e.isNext) && (this.isNext = e.isNext);
        sys.isObjectValid(e) && sys.isObjectValid(e.reportScene) && (this._reportScene = e.reportScene);
        sys.isObjectValid(e) && sys.isObjectValid(e.link_id) && e.link_id > 0 && (this._linkId = e.link_id);
        sys.isObjectValid(e) && sys.isObjectValid(e.pop_souce) && (this._pop_souce = e.pop_souce);
    }
    onClickBtnEvent(e, t) {
        if (ToolUtils.isObjValid(this.node)) {
            if (sys.now() - this._lastClick < 500) {
                return;
            }
            if (this._lastClick = sys.now(), "close" === t) {
                if (this._has_close) {
                    return;
                }
                this._has_close = true;
                this.onBackView();
            }
            else {
                "record" === t ? Utils.shared().showFlopCashRecords() : "play" === t && this.dealPlayGameLogic();
            }
        }
    }
    refreshBtnStatus() {
        let e = User.shared().flopCashTaskData;
        if (sys.isObjectValid(e.today_task_status)) {
            if (1 == e.today_task_status) {
                if (i18nMgr.shared().changeLocalizedLabelKey(this.playNowBtn.getChildByName("txt"), "choose_game.play_now"), this.playNowBtn.getComponent(Button).clickEvents[0].customEventData = "play", !sys.isObjectValid(this.targetRoom)) {
                    return;
                }
                User.shared().data.money < this.targetRoom.entry && i18nMgr.shared().changeLocalizedLabelKey(this.playNowBtn.getChildByName("txt"), "choose_game.add_cash");
            }
        }
    }
    dealPlayGameLogic() {
        if (sys.isObjectValid(this.targetRoom)) {
            if (ToolUtils.isObjValid(this.node) && this.node.destroy(), User.shared().data.money < this.targetRoom.entry) {
                if (!User.shared().checkCanRecharge()) {
                    return void (ToolUtils.isObjValid(this.node) && this.node.destroy());
                }
                Utils.shared().showQuickRecharge(this.targetRoom.vid, null, true, "", 0, this.targetRoom.entry, true, 0, 0);
                User.shared().updatePayScene(PhpReportDefined.pay_scene.hall_less_money, Number(this.targetRoom.vid));
            }
            else {
                if (!User.shared().checkCanPlayCashGame(CheckModule.CASH_PLAY)) {
                    return;
                }
                ToolUtils.curRoomId = Number(this.targetRoom.vid);
                let e = { vid: Number(this.targetRoom.vid), isNewTable: 1 };
                if (this._jumpHtype == HallGameType.LOBBY_GAME_TYPE_RUMMY) {
                    return void Utils.shared().showCommEnterRoom(e);
                }
                this._jumpHtype == HallGameType.LOBBY_GAME_TYPE_SHUIGUOJI && (e.game_type = CommonGameType.FruitMachine);
                Utils.shared().showCommEnterGame(e);
            }
        }
    }
    onBackView() {
        let e = { alert_node: this.node, rootNode: this.root, isNext: this.isNext, pop_type: PushEvent.JUMP_TO_Act_FlopCash, pop_souce: this._pop_souce };
        Utils.shared().closeActivityView(e);
    }
    onDestroy() {
        super.onDestroy();
        ToolUtils.judgeIfInHall() && PushCenter.shared().pushEvent(PushEvent.HallGet);
        TweenTool.stopNodeAction(this.expireTime);
        TweenTool.stopNodeAction(this.node);
        this.unscheduleAllCallbacks();
        PushCenter.shared().removeListenersByTag(this);
    }
}
