// @ts-nocheck
// Recovered from index.js:535
import { _decorator, instantiate, Label, Node, Sprite, SpriteFrame, sys } from "cc";
import BaseLayer from "./BaseLayer";
import PushCenter from "./PushCenter";
import SoundManager from "./SoundManager";
import { ToolUtils } from "./ToolUtils";
import { SixPointManager } from "./SixPointManager";
const { ccclass, property } = _decorator;
@ccclass("SixPointRecode")
export class SixPointRecode extends BaseLayer {
    public TAG: string = "SixPointRecode";
    @property(Node)
    public root: Node = null;
    @property([SpriteFrame])
    public dot_imgs: SpriteFrame[] = [];
    @property(Node)
    public moban: Node = null;
    @property(Node)
    public scrollView: Node = null;
    public _lastClick: number = 0;
    public _has_close: boolean = false;
    public gameCallback: any = null;
    onLoad() {
    }
    start() {
        super.start();
        this.startShowAnim(this.root);
        ToolUtils.showFullScreen(this.node.getChildByName("bg"));
        this.initView();
    }
    initParaData(e) {
        sys.isObjectValid(e) && sys.isObjectValid(e.cb) && (this.gameCallback = e.cb);
    }
    initView() {
    }
    refreshUI(e) {
        this.scrollView.removeAllChildren();
        for (let e = 0; e < SixPointManager.shared().history_recordVec.length; e++) {
            SixPointManager.shared().history_recordVec[e].length;
        }
        for (let e = 0; e < SixPointManager.shared().history_recordVec.length; e++) {
            let t = instantiate(this.moban);
            t.active = true;
            this.scrollView.addChild(t);
            let i = SixPointManager.shared().history_recordVec[e].length, o = 0;
            i > 14 && (o = i - 14);
            let r = 0;
            for (let n = o; n < i; n++) {
                let i = SixPointManager.shared().history_recordVec[e][n], o = "dot" + r, s = t.getChildByName(o);
                ToolUtils.isObjValid(s) && (i >= 0 && i <= 1 ? (s.getChildByName("num").getComponent(Label).string = "X", s.getComponent(Sprite).spriteFrame = this.dot_imgs[0]) : (s.getChildByName("num").getComponent(Label).string = "" + i, s.getComponent(Sprite).spriteFrame = this.dot_imgs[1]));
                r += 1;
            }
        }
    }
    touchBtnEvent(e, t) {
        SoundManager.shared().playFx("click");
        sys.now() - this._lastClick < 500 || (this._lastClick = sys.now(), this.onBackView());
    }
    onBackView() {
        ToolUtils.isObjValid(this.node) && (this.gameCallback && this.gameCallback(1), this.node.destroy());
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().removeListenersByTag(this);
    }
}
