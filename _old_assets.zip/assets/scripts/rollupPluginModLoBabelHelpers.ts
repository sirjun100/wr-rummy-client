// @ts-nocheck
// Recovered from bundle.js:4
export let applyDecoratedDescriptor;
export let initializerDefineProperty;
(applyDecoratedDescriptor = function (e, i, r, n, l) {
    var t = {};
    Object.keys(n).forEach((function (e) {
        t[e] = n[e];
    }));
    t.enumerable = !!t.enumerable;
    t.configurable = !!t.configurable;
    ("value" in t || t.initializer) && (t.writable = true);
    t = r.slice().reverse().reduce((function (r, n) {
        return n(e, i, r) || r;
    }), t);
    l && undefined !== t.initializer && (t.value = t.initializer ? t.initializer.call(l) : undefined, t.initializer = undefined);
    undefined === t.initializer && (Object.defineProperty(e, i, t), t = null);
    return t;
}, initializerDefineProperty = function (e, i, r, n) {
    if (!r) {
        return;
    }
    Object.defineProperty(e, i, { enumerable: r.enumerable, configurable: r.configurable, writable: r.writable, value: r.initializer ? r.initializer.call(n) : undefined });
});
