// @ts-nocheck
// Recovered from index.js:509
import { _decorator, director, instantiate, Label, Node, Prefab, Sprite, SpriteFrame, sys, v3 } from "cc";
import SoundManager from "./SoundManager";
import Utils from "./Utils";
import User from "./User";
import i18nMgr from "./i18nMgr";
import PushCenter from "./PushCenter";
import PushEvent from "./PushEvent";
import TweenTool from "./TweenTool";
import HttpManager from "./HttpManager";
import ReportConfig from "./ReportConfig";
import GameConfig from "./GameConfig";
import BaseLayer from "./BaseLayer";
import BundleNameDefined from "./BundleNameDefined";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("SettingPopWindow")
export default class SettingPopWindow extends BaseLayer {
    @property(Node)
    public rootNode: Node = null;
    @property(Node)
    public imgNode: Node = null;
    @property(Node)
    public labelNode: Node = null;
    @property(Label)
    public version: Label = null;
    @property(Sprite)
    public background_switch: Sprite = null;
    @property(Sprite)
    public sound_switch: Sprite = null;
    @property(Sprite)
    public vibration_switch: Sprite = null;
    @property([SpriteFrame])
    public switchs: SpriteFrame[] = [];
    @property(Node)
    public logOutNode: Node = null;
    @property(Label)
    public label_pass: Label = null;
    @property(Label)
    public label_lang: Label = null;
    @property(Prefab)
    public setlanguage: Prefab = null;
    public islabel: boolean = true;
    public callback: any = null;
    onLoad() {
        director.getScene().name == BundleNameDefined.rummy_scence && (this.bIsInGame = true);
        let e = sys.localStorage.getItem("auto_sort");
        null != e && null != e && (User.shared().auto_sort = Number(e));
        this.refreshSwitchUI();
        this.label_pass && (User.shared().data.tel_no && "" !== User.shared().data.tel_no ? i18nMgr.shared().changeLabelLanguage(this.label_pass, "settings.setpass1") : i18nMgr.shared().changeLabelLanguage(this.label_pass, "settings.setpass"), PushCenter.shared().addListener(PushEvent.passsetting, (e => {
            i18nMgr.shared().changeLabelLanguage(this.label_pass, "settings.setpass1");
        }), this));
        PushCenter.shared().addListener(PushEvent.changeLanguage, (e => {
            this.reflanguage(i18nMgr.shared().language);
        }), this);
        this.reflanguage(i18nMgr.shared().language);
    }
    onEnable() {
    }
    setCallBack(e) {
        this.callback = e;
    }
    reflanguage(e) {
        switch (Number(e)) {
            case 0:
                i18nMgr.shared().changeLabelLanguage(this.label_lang, "settings.setlang");
                break;
            case 1:
                i18nMgr.shared().changeLabelLanguage(this.label_lang, "settings.setlang1");
                break;
            case 2:
                i18nMgr.shared().changeLabelLanguage(this.label_lang, "settings.setlang2");
                break;
            case 3: i18nMgr.shared().changeLabelLanguage(this.label_lang, "settings.setlang3");
        }
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().removeListenersByTag(this);
    }
    clickCallback(e, t) {
        if (SoundManager.shared().playFx("click"), "password" == t) {
            if (1 === User.shared().temp_pingbi.me) {
                return void Utils.shared().showToast("Coming soon", 2);
            }
            PushCenter.shared().pushEvent(PushEvent.ShowCreatePassWordView, { lastNode: this.node });
        }
        else if ("language" == t) {
            if (1 === User.shared().temp_pingbi.loginLanguage) {
                return void Utils.shared().showToast("Coming soon", 2);
            }
            let e = director.getScene().getChildByName("Canvas"), t = instantiate(this.setlanguage);
            e.addChild(t);
        }
    }
    listenChangeMobileCall(e, t, a) {
        if (0 != t.length) {
            if (200 != a) {
                alert("The login timed out, please try again");
            }
            else {
                let e = ToolUtils.parseJson(t);
                501 == e.ret ? PushCenter.shared().pushEvent(PushEvent.ShowSafetyVerify, { lastNode: this.node, jump_info: { type: PushEvent.JUMP_TO_MOBILE, exe: { lastNode: this.node, nType: 1 } } }) : 502 == e.ret ? PushCenter.shared().pushEvent(PushEvent.ShowChangeBindMobile, { lastNode: this.node, nType: 1 }) : (e.ret, e.desc && e.desc.length > 0 && Utils.shared().showToast(e.desc, 3));
            }
        }
    }
    fitScreen() {
        this.node.getChildByName("log_out") && (ToolUtils.adaptSafeArea(this.rootNode), this.setUiEdgeDistance(this.node.getChildByName("log_out"), 68, 3, false));
    }
    startShowAnim() {
        this.rootNode.setScale(v3(0.2, 0.2, 0.2));
        TweenTool.scaleTo(this.rootNode, 0.2, v3(1, 1, 1), "backOut", true, (() => {
            this.rootNode.setScale(v3(1, 1, 1));
        }));
    }
    start() {
        super.start();
        this.fitScreen();
        this.updateInfo();
    }
    onclickByClose(e, t) {
        SoundManager.shared().playFx("click");
        ToolUtils.isObjValid(this.node) && this.node.destroy();
    }
    onToggleCheck(e, t) {
    }
    refreshSwitchUI() {
        let e = SoundManager.shared().bg_enabled;
        this.background_switch.spriteFrame = e ? this.switchs[0] : this.switchs[1];
        let t = SoundManager.shared().fx_enabled;
        this.sound_switch.spriteFrame = t ? this.switchs[0] : this.switchs[1];
        let a = sys.localStorage.getItem("vb_enabled"), s = true;
        sys.isObjectValid(a) && (s = "true" === a);
        this.vibration_switch.spriteFrame = s ? this.switchs[0] : this.switchs[1];
    }
    onClickByBtn(e, t) {
        if (SoundManager.shared().playFx("click"), "background" == t) {
            let e = SoundManager.shared().bg_enabled;
            e = !e;
            SoundManager.shared().setEnabled(e);
            ToolUtils.saveData("bg_enabled", String(e));
            this.refreshSwitchUI();
        }
        else if ("sound" == t) {
            let e = SoundManager.shared().fx_enabled;
            e = !e;
            SoundManager.shared().setFxEnabled(e);
            ToolUtils.saveData("fx_enabled", String(e));
            this.refreshSwitchUI();
        }
        else if ("vibration" == t) {
            let e = sys.localStorage.getItem("vb_enabled"), t = true;
            sys.isObjectValid(e) && (t = "true" === e);
            t = !t;
            ToolUtils.saveData("vb_enabled", String(t));
            this.refreshSwitchUI();
        }
        else if ("card" == t) {
            let e = sys.localStorage.getItem("card_reading_def");
            sys.isObjectValid(e) || (e = User.shared().help_setting.card_reading_def);
            let t = 1 == Number(e) ? 0 : 1;
            ToolUtils.saveData("card_reading_def", String(t));
            this.refreshSwitchUI();
        }
        else {
            "logout" == t ? (HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.ME, event: ReportConfig.hall_evt.click_logout }), User.shared().showLogin()) : "autosort" == t && (User.shared().auto_sort = 1 == User.shared().auto_sort ? 0 : 1, ToolUtils.saveData("auto_sort", String(User.shared().auto_sort)), this.refreshAutosortSwitch(), PushCenter.shared().pushEvent(PushEvent.Setting_Auto_sort));
        }
    }
    refreshAutosortSwitch() {
    }
    updateInfo() {
        this.refreshSwitchUI();
        this.version && (1 == GameConfig.SERVER_DEBUG ? this.version.string = GameConfig.NEW_APP_VERSION + "_" + GameConfig.Server_Api_Ver + "_" + GameConfig.CHANNEL_ID : this.version.string = GameConfig.NEW_APP_VERSION);
    }
    setLandscapeShow() {
        ToolUtils.getOrientation() || this.node.setRotationFromEuler(v3(0, 0, -90));
        let e = this.node.getChildByName("bg1");
        ToolUtils.showFullScreen(e);
    }
    setTidKey(e) {
        this.tid_key = e;
    }
}
