// @ts-nocheck
// Recovered from index.js:615
import { _decorator, Button, color, director, instantiate, Label, LabelOutline, LabelShadow, Node, ProgressBar, RichText, ScrollView, size, Size, sp, Sprite, SpriteAtlas, sys, UITransform, v3, Vec3, Widget } from "cc";
import BaseLayer from "./BaseLayer";
import Utils from "./Utils";
import { TLog } from "./TLog";
import SoundManager from "./SoundManager";
import i18nMgr from "./i18nMgr";
import { LobbyAds } from "./LobbyAds";
import HttpManager from "./HttpManager";
import { HttpRequest } from "./HttpRequestName";
import User from "./User";
import BundleNameDefined from "./BundleNameDefined";
import PushEvent from "./PushEvent";
import PushCenter from "./PushCenter";
import ReportConfig from "./ReportConfig";
import { CUSTOM_REWARD_ENUM } from "./CommDefine";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("SuperVip")
export class SuperVip extends BaseLayer {
    @property(Node)
    public upgradeBtnNode: Node = null;
    @property(Node)
    public curPointsNode: Node = null;
    @property(ProgressBar)
    public progressBar: ProgressBar = null;
    @property(SpriteAtlas)
    public benefitsSpreteAtlas: SpriteAtlas = null;
    @property(Node)
    public bannerNode: Node = null;
    @property(Node)
    public adDefaultNode: Node = null;
    @property(sp.Skeleton)
    public levelAnim: any = null;
    @property(Node)
    public bubbleNode: Node = null;
    public BannersPrefab: any = null;
    @property(Node)
    public topGift: Node = null;
    @property(Node)
    public rootNode: Node = null;
    @property(ScrollView)
    public scrollview: ScrollView = null;
    @property(Node)
    public contentNode: Node = null;
    @property(Node)
    public tab1Node: Node = null;
    @property(Node)
    public tab3Node: Node = null;
    @property(Node)
    public pot1: Node = null;
    @property(Node)
    public tips1: Node = null;
    @property(Node)
    public pot2: Node = null;
    @property(Node)
    public tips2: Node = null;
    @property(Node)
    public pot3: Node = null;
    @property(Node)
    public tips3: Node = null;
    @property(Node)
    public newbubbleNode: Node = null;
    @property(Node)
    public rewardItem: Node = null;
    public _vip_level: number = 0;
    public _vip_offsetX: number = 120;
    public _cur_Index: any = -1;
    public _vipItems: any[] = [];
    public _test_types: any[] = [];
    public _upgrade_state: number = 1;
    public _last_upgrade_state: number = 0;
    public _moveAct: any = null;
    public _startScrX: any = -360;
    public _scrContentPos: any = null;
    public _last_state: any = -1;
    public _benefitsList: any[] = [];
    public _showPopTips: boolean = false;
    public _curwelfare: any = null;
    public _helpData: any = null;
    public _hasClick: boolean = false;
    public _linkId: number = 0;
    public _reportScene: number = 1;
    public _bCanSend: boolean = false;
    public _resetActive: boolean = false;
    public _maxHeight: number = 0;
    public giftItems: any[] = [];
    onLoad() {
        this._maxHeight = this.scrollview.content.getComponent(UITransform).contentSize.height;
        User.shared().superVipHelpData || HttpManager.shared().doGetSuperVipHelp(((e, t, i) => {
            if (Utils.shared().hideLoading(), 200 == i) {
                try {
                    let e = ToolUtils.parseJson(t);
                    0 == e.ret && (User.shared().superVipHelpData = e.data, ToolUtils.isObjValid(this.node) && this.updateContent());
                }
                catch (e) {
                    TLog.printError("listenGetSuperVipHelp err:", e);
                }
            }
        }));
    }
    start() {
        super.start();
        this._linkId = this._linkId > 0 ? this._linkId : sys.now();
        this._reportScene = this._reportScene >= 0 ? this._reportScene : ToolUtils.getIsInRoom() ? 2 : 1;
        User.shared().superVipHelpData ? this.updateContent() : Utils.shared().showLoading(10, true, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
        }));
        this.fitScreen();
        this.dealMultipleLanguages();
        this._scrContentPos = new Vec3;
        this.addGiftItems();
        this.refreshUi();
        User.shared().requestSuperVipHomePageData((() => {
            ToolUtils.isObjValid(this.node) && (this.refreshUi(), this._bCanSend || (this._bCanSend = true, HttpManager.shared().doCommReportRechargeEvent(ReportConfig.Cmd_SuperVip, this._reportScene, 7, this._linkId, "", 0)));
        }));
        PushCenter.shared().addListener(PushEvent.RefreshSuperVipHome, (e => {
            ToolUtils.isObjValid(this.node) && User.shared().requestSuperVipHomePageData((() => {
                ToolUtils.isObjValid(this.node) && (this.refreshUi(), this._bCanSend || (this._bCanSend = true, HttpManager.shared().doCommReportRechargeEvent(ReportConfig.Cmd_SuperVip, this._reportScene, 7, this._linkId, "", 0)));
            }));
        }), this);
        PushCenter.shared().addListener(PushEvent.ShowSuperLevelUpAlert, (e => {
            if (ToolUtils.isObjValid(this.node) && User.shared().superVipUpMsg && sys.isObjectValid(User.shared().superVipUpMsg)) {
                let e = false, t = [];
                if (t.type = CUSTOM_REWARD_ENUM.VIP_LEVEL, t.num = User.shared().superVipUpMsg.new_show_level || 0, User.shared().superVipUpMsg.list) {
                    let i = User.shared().superVipUpMsg.list.length;
                    for (let s = 0; s < i; s++) {
                        if (User.shared().superVipUpMsg.list[s].type == t.type) {
                            e = true;
                            break;
                        }
                    }
                }
                e || User.shared().superVipUpMsg.list.unshift(t);
                Utils.shared().showRewardTips(User.shared().superVipUpMsg, null, 1, "reward_tips.okey", "", (() => {
                    User.shared().superVipUpMsg = null;
                    User.shared().requestSuperVipConfirmUpgradePop();
                }));
            }
        }), this);
        PushCenter.shared().addListener(PushEvent.OnJumpToChooseGame, (e => {
            ToolUtils.isObjValid(this.node) && this.onBackView();
        }), this);
    }
    addGiftItems() {
        let e = this.topGift.getChildByName("Layout");
        e.children && Array.isArray(e.children) && e.children.length > 0 && e.removeAllChildren();
        let t = this.topGift.getChildByName("gift_item");
        t.active = false;
        for (let i = 0; i < 3; i++) {
            let s = instantiate(t);
            s.active = true;
            e.addChild(s);
            this.giftItems[i] = s;
        }
    }
    dealMultipleLanguages() {
        if (2 != i18nMgr.shared().language && 3 != i18nMgr.shared().language || (this.curPointsNode.getComponent(Label).fontSize = 20, this.upgradeBtnNode.getChildByName("Label").getComponent(Label).fontSize = 18), 2 == i18nMgr.shared().language) {
            for (let e = 1; e <= 11; e++) {
                let t = this.tab1Node.getChildByName("title" + e);
                t.getComponent(Label).fontSize = 20;
                t.getComponent(Label).lineHeight = 24;
            }
            for (let e = 1; e <= 4; e++) {
                let t = this.tab3Node.getChildByName("title" + e);
                t.getComponent(Label).fontSize = 16;
                t.getComponent(Label).lineHeight = 20;
            }
        }
    }
    praseReward(e, t) {
        if (ToolUtils.isSafeString(t).length > 0) {
            e.getComponent(Label).string = this.getCellValue(t);
        }
        else if (e.getComponent(Label).string = "", sys.isObjectValid(t.cash) || sys.isObjectValid(t.bonus)) {
            let i = instantiate(this.rewardItem);
            sys.isObjectValid(t.cash) && Number(t.cash) > 0 && (i.getChildByName("Layout").getChildByName("cash").getChildByName("Label").getComponent(Label).string = t.cash, i.getChildByName("Layout").getChildByName("cash").active = true);
            sys.isObjectValid(t.bonus) && Number(t.bonus) > 0 && (i.getChildByName("Layout").getChildByName("bonus").getChildByName("Label").getComponent(Label).string = t.bonus, i.getChildByName("Layout").getChildByName("bonus").active = true);
            sys.isObjectValid(t.bonus_boost_rate) && String(t.bonus_boost_rate).length > 0 && (i.getChildByName("Layout").getChildByName("bonus_add").getChildByName("Label").getComponent(Label).string = t.bonus_boost_rate, i.getChildByName("Layout").getChildByName("bonus_add").active = true);
            i.active = true;
            i.position = v3(e.position.x - 4, e.position.y);
            i.parent = e.parent;
        }
    }
    updateContent() {
        if (!User.shared().superVipHelpData) {
            return;
        }
        if (sys.isObjectValid(User.shared().superVipHelpData.table_1_list_v2) && User.shared().superVipHelpData.table_1_list_v2.length >= 7) {
            for (let e = 1; e <= 7; e++) {
                this.praseReward(this.tab1Node.getChildByName("mon_coupon" + e), User.shared().superVipHelpData.table_1_list_v2[e - 1][6]);
                this.praseReward(this.tab1Node.getChildByName("withdraw_fee" + e), User.shared().superVipHelpData.table_1_list_v2[e - 1][7]);
                this.praseReward(this.tab1Node.getChildByName("upgrade_gift" + e), User.shared().superVipHelpData.table_1_list_v2[e - 1][3]);
                this.praseReward(this.tab1Node.getChildByName("game_birth" + e), User.shared().superVipHelpData.table_1_list_v2[e - 1][4]);
                this.praseReward(this.tab1Node.getChildByName("monthly_gift" + e), User.shared().superVipHelpData.table_1_list_v2[e - 1][2]);
                this.praseReward(this.tab1Node.getChildByName("weekly_gift" + e), User.shared().superVipHelpData.table_1_list_v2[e - 1][1]);
                this.praseReward(this.tab1Node.getChildByName("special_cs" + e), User.shared().superVipHelpData.table_1_list_v2[e - 1][8]);
                this.praseReward(this.tab1Node.getChildByName("custom_acc" + e), User.shared().superVipHelpData.table_1_list_v2[e - 1][9]);
            }
        }
        if (sys.isObjectValid(User.shared().superVipHelpData.table_3_list) && User.shared().superVipHelpData.table_3_list.length >= 7) {
            for (let e = 1; e <= 7; e++) {
                this.tab3Node.getChildByName("points_upgrade_" + e).getComponent(Label).string = this.getCellValue(User.shared().superVipHelpData.table_3_list[e - 1].upgrade);
                1 == e ? this.tab3Node.getChildByName("validity_1").getComponent(Label).string = this.getCellValue(User.shared().superVipHelpData.table_3_list[0].validity) : 2 == e ? this.tab3Node.getChildByName("validity_2").getComponent(Label).string = this.getCellValue(User.shared().superVipHelpData.table_3_list[4].validity) : 3 == e ? this.tab3Node.getChildByName("validity_3").getComponent(Label).string = this.getCellValue(User.shared().superVipHelpData.table_3_list[5].validity) : 4 == e && (this.tab3Node.getChildByName("validity_4").getComponent(Label).string = this.getCellValue(User.shared().superVipHelpData.table_3_list[6].validity));
                this.tab3Node.getChildByName("points_level_" + e).getComponent(Label).string = this.getCellValue(User.shared().superVipHelpData.table_3_list[e - 1].maintain);
            }
        }
        let e = this._maxHeight;
        sys.isObjectValid(User.shared().superVipHelpData.bottom_tips_1) && User.shared().superVipHelpData.bottom_tips_1.length > 0 ? (this.tips1.getComponent(Label).string = User.shared().superVipHelpData.bottom_tips_1, this.tips1.getComponent(Label).updateRenderData(true), this.tips1.setPosition(v3(this.tips2.position.x, -e)), this.pot1.setPosition(v3(this.pot2.position.x, -e - 15)), e += this.tips1.getComponent(UITransform).contentSize.height, this.pot1.active = true, this.tips1.active = true) : (this.pot1.active = false, this.tips1.active = false);
        sys.isObjectValid(User.shared().superVipHelpData.bottom_tips_2) && User.shared().superVipHelpData.bottom_tips_2.length > 0 ? (this.tips2.getComponent(Label).string = User.shared().superVipHelpData.bottom_tips_2, this.tips2.getComponent(Label).updateRenderData(true), this.tips2.setPosition(v3(this.tips2.position.x, -e)), this.pot2.setPosition(v3(this.pot2.position.x, -e - 15)), e += this.tips2.getComponent(UITransform).contentSize.height + 10, this.pot2.active = true, this.tips2.active = true) : (this.pot2.active = false, this.tips2.active = false);
        sys.isObjectValid(User.shared().superVipHelpData.bottom_tips_3) && User.shared().superVipHelpData.bottom_tips_3.length > 0 ? (this.tips3.getComponent(Label).string = User.shared().superVipHelpData.bottom_tips_3, this.tips3.getComponent(Label).updateRenderData(true), this.tips3.setPosition(v3(this.tips3.position.x, -e)), this.pot3.setPosition(v3(this.pot3.position.x, -e - 15)), e += this.tips3.getComponent(UITransform).contentSize.height + 20, this.pot3.active = true, this.tips3.active = true) : (this.pot3.active = false, this.tips3.active = false, e += 10);
        e += 30;
        this.scrollview.content.getComponent(UITransform).setContentSize(size(720, e));
    }
    getCellValue(e) {
        let t;
        return t = sys.isObjectValid(e) ? "N" == e ? "/" : "Y" == e ? "√" : e : "/", t;
    }
    requestSuperVipReceiveReward(e, t) {
        HttpManager.shared().doGetCommonRequest({ type: e, level: t }, HttpRequest.SuperVipReceive, ((e, t, i) => {
            if (200 != i) {
                ;
            }
            else {
                let e = ToolUtils.parseJson(t);
                if (0 == e.ret && sys.isObjectValid(e.data) && sys.isObjectValid(e.data.reward_list)) {
                    let t = { list: [] };
                    sys.isObjectValid(e.data.msg) && (t.msg = e.data.msg + "");
                    for (let i = 0, s = e.data.reward_list.length; i < s; i++) {
                        let s = e.data.reward_list[i], a = [];
                        sys.isObjectValid(s.amt) && (a.num = s.amt);
                        sys.isObjectValid(s.amount) && (a.num = s.amount);
                        a.type = s.type;
                        a.php_data = s;
                        a.name = Utils.shared().getIconNameByType(s.type, s.desc);
                        t.list[i] = a;
                        t.isSuperVip = true;
                    }
                    director.getScene().name == BundleNameDefined.hall_scene && Utils.shared().showRewardTips(t, (t => {
                        sys.isObjectValid(e.data.page) && (User.shared().superVipPageData = e.data.page, ToolUtils.isObjValid(this.node) && this.refreshUi());
                    }), 1, "reward_tips.okey");
                }
            }
        }));
    }
    refreshUi() {
        if (!sys.isObjectValid(User.shared().superVipPageData)) {
            return;
        }
        this.node.getChildByName("root").getChildByName("degree").active = true;
        let e = User.shared().superVipPageData;
        if (this._last_state = -1, sys.isObjectValid(e.current_show_level) && this._vip_level != Number(e.current_show_level) && (this._vip_level = Number(e.current_show_level), this._cur_Index = -1), sys.isObjectValid(e.list) && Array.isArray(e.list) && e.list.length > 0) {
            this._benefitsList = e.list;
            for (let e = 0; e < this._benefitsList.length; e++) {
                if (sys.isObjectValid(this._benefitsList[e].show_level)) {
                    if (-1 == this._cur_Index) {
                        if (Number(this._benefitsList[e].show_level) == this._vip_level) {
                            this._upgrade_state = this._benefitsList[e].upgrade_btn;
                            break;
                        }
                    }
                    else if (e == this._cur_Index) {
                        this._upgrade_state = this._benefitsList[e].upgrade_btn;
                        break;
                    }
                }
            }
        }
        ToolUtils.isSafeString(e.pop_tips).length > 0 && -1 == this._cur_Index ? this.contentNode.getChildByName("title3_layout").getChildByName("help_btn").active = true : this.contentNode.getChildByName("title3_layout").getChildByName("help_btn").active = false;
        this.initVipInfo();
        this.refreshBenefits();
        this.updateTopBenefits();
    }
    initParaData(e) {
        sys.isObjectValid(e) && sys.isObjectValid(e.reportScene) && (this._reportScene = e.reportScene);
        sys.isObjectValid(e) && sys.isObjectValid(e.link_id) && e.link_id > 0 && (this._linkId = e.link_id);
    }
    addBannerNode(e) {
        ToolUtils.loadCommonPrefab(this.BannersPrefab, BundleNameDefined.bundle_hall, "prefab/LobbyAd", (t => {
            try {
                if (this.BannersPrefab = t, director.getScene().name != BundleNameDefined.hall_scene) {
                    return;
                }
                this.bannerNode.active = true;
                this.adDefaultNode.active = false;
                let i = this.bannerNode.getChildByName("LobbyAd");
                if (ToolUtils.isObjValid(i)) {
                    i.getComponent(LobbyAds).updateBanners(1, e);
                }
                else {
                    i = instantiate(this.BannersPrefab);
                    this.bannerNode.addChild(i);
                    i.getComponent(LobbyAds).updateBanners(1, e);
                }
            }
            catch (e) {
                TLog.printError("SuperVip addBannerNode error= " + e);
            }
        }));
    }
    initVipInfo() {
        this._last_upgrade_state = this._upgrade_state;
        -1 == this._cur_Index && (this._cur_Index = this._vip_level - 1);
        this.refreshUpdateBtn();
        this.levelAnim.node.active = true;
        this.refreshVipLevel();
        let e = -this._vip_offsetX * this._cur_Index;
        this._scrContentPos.x = this._startScrX + e;
    }
    refreshVipLevel() {
        if (this._cur_Index >= 0 && this._cur_Index <= 6) {
            let e = "level" + (this._cur_Index + 1);
            this.levelAnim.setSkin(e);
            this.levelAnim.clearTracks();
            this.levelAnim.setAnimation(0, "animation", true);
        }
    }
    refreshUpdateBtn() {
        let e = "", t = true, i = this.upgradeBtnNode.getChildByName("Label");
        1 == this._upgrade_state ? e = "superVip.upgrade" : 3 == this._upgrade_state ? e = "superVip.keepup" : 2 == this._upgrade_state && (e = "superVip.achieved", t = false);
        this._last_state = this._upgrade_state;
        this.upgradeBtnNode.getComponent(Button).interactable = t;
        i18nMgr.shared().changeLocalizedLabelKey(i, e);
    }
    updateTopBenefits() {
        if (this._benefitsList.length <= this._cur_Index) {
            return;
        }
        let e = this._benefitsList[this._cur_Index].welfare, t = e.length;
        for (let i = 0; i < t; i++) {
            let t = e[i].type;
            if (-1 == [1, 2, 3].indexOf(t)) {
                return;
            }
            let s = null;
            if (3 == this.giftItems.length && (3 == t ? s = this.giftItems[0] : 2 == t ? s = this.giftItems[1] : 1 == t && (s = this.giftItems[2])), s) {
                let a = Number(e[i].icon_status), r = e[i].btn_status, n = ToolUtils.isSafeString(e[i].btn_msg), l = Number(e[i].can_receive_num), o = e[i].reward_desc + "", h = ToolUtils.isSafeString(e[i].btn_tips) + "", p = s.getChildByName("benefit_ic"), u = s.getChildByName("name"), g = s.getChildByName("num"), _ = s.getChildByName("Button"), b = _.getChildByName("bg_0"), m = _.getChildByName("bg_1"), V = _.getChildByName("Label_0"), w = _.getChildByName("Label_1"), B = _.getChildByName("date"), S = s.getChildByName("bubble"), L = S.getChildByName("Label"), D = s.getChildByName("reward"), O = D.getChildByName("root"), j = s.getChildByName("withdraw_fee");
                if (sys.isObjectValid(e[i].bonus) || sys.isObjectValid(e[i].bmoney)) {
                    D.active = true;
                    let t = O.getChildByName("Layout"), s = t.getChildByName("gold"), a = O.getChildByName("Layout2"), r = a.getChildByName("bonus"), n = O.getChildByName("Layout3"), l = n.getChildByName("num");
                    O.active = true;
                    g.active = false;
                    t.active = false;
                    a.active = false;
                    n.active = false;
                    sys.isObjectValid(e[i].bonus) && (a.active = true, r.getComponent(Label).string = e[i].bonus + "");
                    sys.isObjectValid(e[i].bmoney) && (t.active = true, s.getComponent(Label).string = e[i].bmoney + "");
                    sys.isObjectValid(e[i].bonus_boost_rate) && (n.active = true, l.getComponent(Label).string = e[i].bonus_boost_rate + "");
                }
                else {
                    D.active = false;
                    g.active = true;
                }
                let H = "superVip_reward" + t + "0";
                _.getComponent(Button).clickEvents[0].customEventData = i + "";
                let R = true;
                1 == r && "" == h && (R = false);
                _.getComponent(Button).interactable = R;
                let k = "_0";
                H = "superVip_reward" + t + k;
                let x = p.getChildByName("Label"), P = e[i].coupon_rate + "";
                if (6 == t ? (x.active = true, x.getComponent(Label).string = P, 1 != a ? (x.getComponent(Label).color = color(215, 28, 28, 255), x.getComponent(LabelShadow).color = color(255, 247, 181, 255)) : (x.getComponent(Label).color = color(84, 71, 62, 255), x.getComponent(LabelShadow).color = color(151, 128, 112, 255))) : x.active = false, j.active = false, 7 == t) {
                    let s = e[i].withdraw_fee_rate;
                    0 == s ? H = "superVip_reward" + t + "_0" + k : (H = "superVip_reward" + t + "_50" + k, j.active = true, j.getComponent(Label).string = s + "%", 1 == a ? (j.getComponent(Label).color = color(172, 149, 134, 255), j.getComponent(LabelOutline).color = color(59, 48, 41, 255)) : (j.getComponent(Label).color = color(255, 255, 255, 255), j.getComponent(LabelOutline).color = color(166, 51, 0, 255)));
                }
                p.getComponent(Sprite).spriteFrame = this.benefitsSpreteAtlas.getSpriteFrame(H);
                let z = e[i].welfare_name + "";
                S.active = l > 1;
                L.getComponent(Label).string = "x" + l;
                u.getComponent(Label).string = z;
                i18nMgr.shared().changeLabelFont(u.getComponent(Label));
                g.getComponent(Label).string = o;
                i18nMgr.shared().changeLabelFont(g.getComponent(Label));
                i18nMgr.shared().changeLabelFont(V.getComponent(Label), true);
                i18nMgr.shared().changeLabelFont(w.getComponent(Label), true);
                i18nMgr.shared().changeLabelFont(B.getComponent(Label));
                let A = e[i].is_date_btn;
                0 == A ? (b.active = V.active = !(1 == r), m.active = w.active = 1 == r) : b.active = V.active = m.active = w.active = false;
                B.active = 1 == A;
                B.getComponent(Label).string = n;
                V.getComponent(Label).string = n;
                w.getComponent(Label).string = n;
            }
        }
    }
    refreshBenefits() {
        if (this._benefitsList.length <= this._cur_Index) {
            return;
        }
        let e = this._benefitsList[this._cur_Index];
        ToolUtils.isSafeString(e.expire_date);
        this.curPointsNode.active = true;
        i18nMgr.shared().changeLabelFont(this.curPointsNode.getComponent(Label));
        this.curPointsNode.getComponent(Label).string = ToolUtils.isSafeString(e.progress_text);
        this.progressBar.progress = Number(e.progress);
        this._curwelfare = e.welfare;
    }
    fitScreen() {
        let e = sys.getSafeAreaRect().y;
        !sys.isNative || sys.os !== sys.OS.ANDROID && sys.os !== sys.OS.OHOS ? e > 0 && (this.node.getChildByName("root").getComponent(Widget).top = e - 40) : e > 0 && (this.node.getChildByName("root").getComponent(Widget).top = e);
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().removeListenersByTag(this);
        this.unscheduleAllCallbacks();
    }
    refreshVipTab() {
        for (let e = 0; e < 7; e++) {
            let t = this._vipItems[e], i = false;
            e == this._cur_Index && (i = true);
            let s = t.getChildByName("Label");
            t.getChildByName("Sprite").active = i;
            s.active = !i;
        }
        this._upgrade_state = this._benefitsList[this._cur_Index].upgrade_btn;
        this.refreshUpdateBtn();
        this.refreshVipLevel();
        this.refreshBenefits();
    }
    rewardButtonClick(e, t) {
        SoundManager.shared().playFx("click");
        let i = 0, s = Number(t);
        if (this._curwelfare && this._curwelfare.length > s) {
            let e = this._curwelfare[s].type, t = ToolUtils.isSafeString(this._curwelfare[s].btn_tips) + "";
            if (t.length > 0) {
                return void Utils.shared().showToast(t, 2);
            }
            if (6 == e) {
                Utils.shared().showStoreView(null, this.node);
            }
            else if (7 == e) {
                Utils.shared().showDepositTransferView(this.node);
                i = 15;
            }
            else if (8 == e) {
                sys.isObjectValid(ToolUtils.vip_data) && sys.isObjectValid(ToolUtils.vip_data.whurl) && (Utils.shared().jumpToWhatsAppByUrl(ToolUtils.vip_data.whurl), i = 16);
            }
            else {
                if (this._hasClick) {
                    return;
                }
                this._hasClick = true;
                let t = this._benefitsList[this._cur_Index].level;
                switch ((this.requestSuperVipReceiveReward(e, t), e)) {
                    case 1:
                        i = 11;
                        break;
                    case 2:
                        i = 12;
                        break;
                    case 4:
                        i = 13;
                        break;
                    case 5: i = 14;
                }
                this.scheduleOnce((() => {
                    this._hasClick = false;
                }));
            }
            i > 0 && this._bCanSend && HttpManager.shared().doCommReportRechargeEvent(ReportConfig.Cmd_SuperVip, this._reportScene, i, this._linkId, "", 0);
        }
    }
    judgeRemainReward() {
        let e = false;
        if (this._benefitsList.length <= this._cur_Index) {
            return e;
        }
        let t = this._benefitsList[this._cur_Index];
        if (!(sys.isObjectValid(t.welfare) && Array.isArray(t.welfare) && t.welfare.length > 0)) {
            return e;
        }
        let i = t.welfare, s = i.length;
        for (let t = 0; t < s; t++) {
            if (i[t].can_receive_num > 0) {
                return e = true, e;
            }
        }
        return e;
    }
    onButtonClick(e, t) {
        if (SoundManager.shared().playFx("click"), "close" === t) {
            this.onBackView();
        }
        else if ("help" === t) {
            if (1 == User.shared().temp_pingbi.feedback) {
                return void Utils.shared().showToast("Coming soon", 2);
            }
            Utils.shared().doJumpLogic(PushEvent.JUMP_TO_FEEDBACK);
        }
        else if ("help_bubble" === t) {
            if (this.newbubbleNode.active) {
                return void (this.newbubbleNode.active = false);
            }
            if (!sys.isObjectValid(User.shared().superVipPageData)) {
                return;
            }
            let e = User.shared().superVipPageData, t = ToolUtils.isSafeString(e.pop_tips), i = this.newbubbleNode.getChildByName("richlab");
            i18nMgr.shared().changeLabelFont(i.getComponent(RichText));
            i.getComponent(RichText).string = t;
            let s = i.getComponent(UITransform).height;
            s > 60 && this.newbubbleNode.getComponent(UITransform).setContentSize(new Size(320, 74 + s - 54.24));
            this.scheduleOnce((() => {
                ToolUtils.isObjValid(this.newbubbleNode) && (this.newbubbleNode.active = false);
            }), 6);
            this.newbubbleNode.active = true;
        }
        else if ("upgrade" === t) {
            let e = sys.now();
            if (this._bCanSend) {
                let t = 0;
                1 == this._upgrade_state ? t = 9 : 3 == this._upgrade_state && (t = 10);
                t > 0 && HttpManager.shared().doCommReportRechargeEvent(ReportConfig.Cmd_SuperVip, this._reportScene, t, this._linkId, "", 0, e);
            }
            Utils.shared().showStoreView({ rep_act_id: PushEvent.JUMP_TO_SuperVip, link_id: this._linkId, client_time: e }, this.node);
        }
    }
    onBackView() {
        if (ToolUtils.isObjValid(this.node)) {
            let e = director.getScene().getChildByName("Canvas").getChildByName("supervip_help");
            ToolUtils.isObjValid(e) && e.active ? e.active = false : (this.node.destroy(), User.shared().getHallInfo());
        }
    }
    onDisable() {
        this._resetActive = true;
    }
    onEnable() {
        this._resetActive && this._bCanSend && HttpManager.shared().doCommReportRechargeEvent(ReportConfig.Cmd_SuperVip, this._reportScene, 7, this._linkId, "", 0);
    }
}
