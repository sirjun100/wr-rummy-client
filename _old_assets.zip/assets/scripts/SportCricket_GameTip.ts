// @ts-nocheck
// Recovered from index.js:565
import { _decorator, Node, sys } from "cc";
import BaseLayer from "./BaseLayer";
import SoundManager from "./SoundManager";
import Utils from "./Utils";
import PushCenter from "./PushCenter";
import TweenTool from "./TweenTool";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("SportCricket_GameTip")
export class SportCricket_GameTip extends BaseLayer {
    public TAG: string = "SportCricket_GameTip";
    @property(Node)
    public rootNode: Node = null;
    public isNext: boolean = false;
    public _data: any = null;
    initParaData(t) {
        sys.isObjectValid(t) && (this._data = t, sys.isObjectValid(t.isNext) && (this.isNext = t.isNext));
    }
    onLoad() {
    }
    start() {
        super.start();
        ToolUtils.showFullScreen(this.node.getChildByName("mask"));
        this.startShowAnim(this.rootNode);
    }
    onButtonClick(t, e) {
        SoundManager.shared().playFx("click");
        "close" == e ? this.onBackView() : "add_chip" == e && (Utils.shared().showStoreView(null, null), this.onBackView());
    }
    onDestroy() {
        super.onDestroy();
        TweenTool.stopNodeAction(this.node);
        PushCenter.shared().removeListenersByTag(this);
        Utils.shared().hideLoading();
    }
    onBackView() {
        ToolUtils.isObjValid(this.node) && this.node.destroy();
    }
}
