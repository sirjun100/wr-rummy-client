// @ts-nocheck
// Recovered from index.js:45
import { _decorator, Component, instantiate, Node, RichText, size, UITransform, v3, Vec3 } from "cc";
import TweenTool from "./TweenTool";
import GameConfig from "./GameConfig";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("BroadCast")
export class BroadCast extends Component {
    @property(Node)
    public bgNode: Node = null;
    @property(Node)
    public msgNode: Node = null;
    public _laba_width: number = 720;
    public _view_height: number = 1280;
    public directHide: boolean = false;
    public bgShow: boolean = false;
    public moveDistance: number = 0;
    public autoHide: boolean = false;
    public isMoving: boolean = false;
    public curMsgLabel: any = null;
    public safe_hei: number = 0;
    public moveRepeatAct: any = null;
    public labaAct: any = null;
    public _labadi_hei: number = 40;
    start() {
        this.bgNode.active = false;
        this._laba_width = GameConfig.REAL_SCREEN_WIDTH;
        ToolUtils.getOrientation() ? (this._laba_width = GameConfig.REAL_SCREEN_HEIGHT, this.bgNode.getComponent(UITransform).setContentSize(size(this._laba_width, this._labadi_hei)), this._view_height = GameConfig.REAL_SCREEN_WIDTH) : (this.safe_hei = ToolUtils.getSafeDistance(), ToolUtils.isPadPlatform() && (this.safe_hei = 0), this._view_height = GameConfig.REAL_SCREEN_HEIGHT, this.bgNode.getComponent(UITransform).setContentSize(size(this._laba_width, this._labadi_hei)));
        this.msgNode.active = false;
        this.bgNode.setPosition(v3(0, this._view_height / 2 + this._labadi_hei / 2 + this.safe_hei));
        this.startLabaAction();
    }
    onDestroy() {
        this.unscheduleAllCallbacks();
    }
    startLabaAction() {
        this.labaAct && (TweenTool.stopAction(this.labaAct), this.labaAct = null);
        this.labaAct = TweenTool.myschedule(this.node, 0.5, this.listenLabaMsg.bind(this));
    }
    setAutoHide(t) {
        this.autoHide = t;
    }
    setDirectHide(t) {
        this.directHide = t;
    }
    listenLabaMsg() {
        ToolUtils.hasShowLabaCount >= ToolUtils.LabaCount ? this.bgShow && this.autoHide && (this.bgShow = false, this.directHide ? this.bgNode.active = false : TweenTool.moveTo(this.bgNode, 0.5, v3(0, this._view_height / 2 + this._labadi_hei / 2 + this.safe_hei), null, true)) : this.createNewMsg();
    }
    createNewMsg() {
        if (this.isMoving) {
            return;
        }
        let t = ToolUtils.LabaTable[ToolUtils.hasShowLabaCount];
        if (t) {
            this.labaAct && (TweenTool.stopAction(this.labaAct), this.labaAct = null);
            let i = instantiate(this.msgNode);
            this.bgNode.addChild(i);
            i.active = true;
            i.setPosition(v3(this._laba_width / 2, this._labadi_hei / 2 + 5));
            i.getComponent(RichText).string = t;
            this.curMsgLabel = i;
            this.moveDistance = 0;
            this.isMoving = true;
            this.bgShow ? (this.bgNode.active = true, this.startMoveAction()) : this.showMarqueeBG();
        }
    }
    showMarqueeBG() {
        let t = v3(0, this._view_height / 2 - this._labadi_hei / 2 - this.safe_hei);
        this.bgNode.active = true;
        this.bgShow = true;
        this.autoHide && this.directHide ? this.startMoveAction() : TweenTool.moveTo(this.bgNode, 0.5, t, null, true, (() => {
            this.bgNode.setPosition(t);
            this.startMoveAction();
        }));
    }
    startMoveAction() {
        this.stopMoveAction();
        this.moveRepeatAct = TweenTool.myschedule(this.node, 0.02, this.updateMove.bind(this));
    }
    stopMoveAction() {
        this.moveRepeatAct && (TweenTool.stopAction(this.moveRepeatAct), this.moveRepeatAct = null);
    }
    updateMove() {
        if (ToolUtils.isObjValid(this.curMsgLabel)) {
            this.bgShow = true;
            let t = new Vec3;
            this.curMsgLabel.getPosition(t);
            this.curMsgLabel.setPosition(v3(t.x - 3, t.y));
            this.moveDistance = this.moveDistance + 3;
            let i = this.curMsgLabel.getComponent(UITransform).width;
            this.moveDistance >= i + this._laba_width && (this.curMsgLabel.active = false, this.curMsgLabel.destroy(), this.curMsgLabel = null, TweenTool.stopNodeAction(this.bgNode), this.isMoving = false, ToolUtils.hasShowLabaCount = ToolUtils.hasShowLabaCount + 1, this.stopMoveAction(), this.startLabaAction());
        }
    }
}
