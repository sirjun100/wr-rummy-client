// @ts-nocheck
// Recovered from index.js:395
import { _decorator, Button, EditBox, instantiate, Label, Node, ProgressBar, Slider, sys, UITransform, v3 } from "cc";
import BaseLayer from "./BaseLayer";
import PushCenter from "./PushCenter";
import SoundManager from "./SoundManager";
import { ToolUtils } from "./ToolUtils";
import { RocketGameManager } from "./RocketGameManager";
const { ccclass, property } = _decorator;
@ccclass("RocketGameAutoPlay")
export class RocketGameAutoPlay extends BaseLayer {
    public TAG: string = "RocketGameAutoPlay";
    @property(Node)
    public root: Node = null;
    @property(Node)
    public autoOutNode: Node = null;
    @property(Node)
    public checkoutEditNode: Node = null;
    @property(Node)
    public curCheckOutNode: Node = null;
    public _lastClick: number = 0;
    public _has_close: boolean = false;
    public isNext: boolean = false;
    public isFix: boolean = false;
    public callBack: any = null;
    public roundIndex: number = 0;
    public curRound: number = 0;
    public paraRound: number = 0;
    public checkout_num: number = 0;
    public checkout_min: number = 0;
    public checkout_max: number = 10;
    public nIdx: number = 0;
    onLoad() {
    }
    start() {
        super.start();
        this.startShowAnim(this.root);
        ToolUtils.showFullScreen(this.node.getChildByName("bg"));
        this.initView();
    }
    initParaData(t) {
        sys.isObjectValid(t) && sys.isObjectValid(t.isFix) && (this.isFix = t.isFix);
        sys.isObjectValid(t) && sys.isObjectValid(t.auto_checkout_num) && (this.checkout_num = t.auto_checkout_num);
        sys.isObjectValid(t) && sys.isObjectValid(t.round) && (this.paraRound = t.round);
        sys.isObjectValid(t) && sys.isObjectValid(t.cb) && (this.callBack = t.cb);
    }
    initView() {
        let t = RocketGameManager.shared().auto_play_cnt;
        if (!sys.isObjectValid(t)) {
            return;
        }
        let e = t.rounds[0];
        if (sys.isObjectValid(t.target_round) && (e = t.target_round), this.paraRound > 0 && (e = this.paraRound), this.isFix && this.checkout_num > 0 ? sys.isObjectValid(t.auto_out) && t.auto_out.length > 0 && (this.checkout_min = t.auto_out[0], this.checkout_max = t.auto_out[t.auto_out.length - 1]) : (sys.isObjectValid(t.auto_out) && t.auto_out.length > 0 && (this.checkout_min = t.auto_out[0], this.checkout_num = this.checkout_min, this.nIdx = 0, this.checkout_max = t.auto_out[t.auto_out.length - 1]), sys.isObjectValid(t.check_outnum) && !this.isFix && (this.checkout_num = t.check_outnum)), sys.isObjectValid(t.rounds) && Array.isArray(t.rounds) && 5 == t.rounds.length) {
            for (let i = 0; i < t.rounds.length; i++) {
                let o = this.root.getChildByName("round_btn" + i);
                o.getChildByName("wz0").getComponent(Label).string = String(t.rounds[i]);
                o.getChildByName("wz1").getComponent(Label).string = String(t.rounds[i]);
                ToolUtils.isObjValid(o) && (e == t.rounds[i] ? (this.roundIndex = i, this.curRound = e, this.updateRoundItemStatus(o, true)) : this.updateRoundItemStatus(o, false));
            }
        }
        this.updateCurCheckOutNum(this.checkout_num.toFixed(2));
        this.setCheckOutPoint();
        this.reSetSliderView(this.checkout_num);
        this.isFix && (this.root.getChildByName("sure").getChildByName("wz").getComponent(Label).string = "SAVE AUTOPLAY");
    }
    updateCurCheckOutNum(t) {
        this.curCheckOutNode.getComponent(Label).string = String(t) + "X";
        this.checkoutEditNode.getComponent(EditBox).string = String(t);
    }
    onCheckOutTextChanged(t, e, i) {
        this.updateCheckOutClearStatus();
    }
    onCheckOutTextEnd(t, e, i) {
        this.updateCheckOutClearStatus(true);
    }
    updateCheckOutClearStatus(t) {
        let e = ToolUtils.isSafeString(this.checkoutEditNode.getComponent(EditBox).string), i = 0;
        e.length > 0 && (i = Number(e), i >= this.checkout_min && i <= this.checkout_max || (i < this.checkout_min ? i = this.checkout_min : i > this.checkout_max && (i = this.checkout_max)));
        sys.isObjectValid(t) && (0 == e.length && (i = this.checkout_num), this.checkoutEditNode.getComponent(EditBox).string = String(i), this.checkout_num = i, this.updateCurCheckOutNum(i.toFixed(2)), this.curCheckOutNode.active = true, this.checkoutEditNode.active = false, this.autoOutNode.getChildByName("del_btn").active = false, this.autoOutNode.getChildByName("edit_btn").active = true, this.reSetSliderView(this.checkout_num));
    }
    setCheckOutPoint() {
        let t = this.autoOutNode.getChildByName("slider_view"), e = t.getChildByName("Slider"), i = t.getChildByName("betroot"), o = t.getChildByName("bet_moban");
        o.active = false;
        i.destroyAllChildren();
        let u = RocketGameManager.shared().auto_play_cnt;
        if (!sys.isObjectValid(u.auto_out)) {
            return;
        }
        let n = e.getComponent(UITransform).contentSize.width, h = 0;
        u.auto_out.length > 1 && (h = n / (u.auto_out.length - 1));
        for (let t = 0, e = u.auto_out.length; t < u.auto_out.length; t++) {
            let s = instantiate(o);
            s.active = true;
            let c = u.auto_out[t];
            s.getComponent(Label).string = c;
            0 == t ? s.setPosition(v3(-n / 2, 0)) : t == e - 1 ? s.setPosition(v3(n / 2, 0)) : (s.setPosition(v3(-n / 2 + h * t, 0)), s.getComponent(Label).string = "");
            i.addChild(s);
        }
    }
    updateChangePointBtnState() {
        let t = this.autoOutNode.getChildByName("slider_view");
        t.getChildByName("btn_add").getComponent(Button);
        t.getChildByName("btn_reduce").getComponent(Button);
        RocketGameManager.shared().auto_play_cnt;
    }
    reSetSliderView(t) {
        let e = (t - this.checkout_min) / (this.checkout_max - this.checkout_min), i = (RocketGameManager.shared().auto_play_cnt, this.autoOutNode.getChildByName("slider_view"));
        i.getChildByName("Slider").getComponent(Slider).progress = e;
        i.getChildByName("Slider").getChildByName("ProgressBar").getComponent(ProgressBar).progress = e;
        this.updateCurCheckOutNum(t.toFixed(2));
    }
    onSliderCallback(t, e) {
        t.target;
        let i = this.autoOutNode.getChildByName("slider_view").getChildByName("Slider"), o = i.getChildByName("ProgressBar"), u = i.getComponent(Slider).progress, n = RocketGameManager.shared().auto_play_cnt;
        n.auto_out && n.auto_out.length > 1 && Math.floor((n.auto_out.length - 1) * u + 0.5);
        o.getComponent(ProgressBar).progress = u;
        let s = (this.checkout_max - this.checkout_min) * u + this.checkout_min;
        this.checkout_num = s;
        this.updateCurCheckOutNum(s.toFixed(2));
    }
    updateSliderProgress(t, e = true) {
        let i = this.autoOutNode.getChildByName("slider_view").getChildByName("Slider"), o = i.getChildByName("ProgressBar"), u = RocketGameManager.shared().auto_play_cnt;
        if (u.auto_out && u.auto_out.length > 1) {
            this.nIdx = t - 1;
            let e = (t - 1) / (u.auto_out.length - 1);
            i.getComponent(Slider).progress = e;
            o.getComponent(ProgressBar).progress = e;
            this.updateEntryInfo(t);
        }
        else {
            this.nIdx = 0;
            i.getComponent(Slider).progress = 0;
            o.getComponent(ProgressBar).progress = 0;
            this.updateEntryInfo(1);
        }
    }
    updateEntryInfo(t) {
        let e = RocketGameManager.shared().auto_play_cnt;
        e.auto_out && e.auto_out.length > 0 && (this.updateChangePointBtnState(), this.checkout_num = e.auto_out[t - 1], this.updateCurCheckOutNum(this.checkout_num));
    }
    updateRoundItemStatus(t, e) {
        if (ToolUtils.isObjValid(t)) {
            t.getChildByName("ico").active = e;
            t.getChildByName("wz0").active = !e;
            t.getChildByName("wz1").active = e;
            let i = t.name;
            ToolUtils.isObjValid(t.getChildByName("line")) && (t.getChildByName("line").active = !e, 1 == this.roundIndex ? "round_btn0" == i && (t.getChildByName("line").active = false) : 2 == this.roundIndex ? "round_btn1" == i && (t.getChildByName("line").active = false) : 3 == this.roundIndex ? "round_btn2" == i && (t.getChildByName("line").active = false) : 4 == this.roundIndex && "round_btn3" == i && (t.getChildByName("line").active = false));
        }
    }
    onClickItemEvent(t, e) {
        if (ToolUtils.isObjValid(this.node)) {
            if (sys.now() - this._lastClick < 500) {
                return;
            }
            this._lastClick = sys.now();
            let t = Number(e);
            if (this.roundIndex == t) {
                return;
            }
            this.roundIndex = t;
            let i = RocketGameManager.shared().auto_play_cnt;
            this.curRound = i.rounds[t];
            for (let e = 0; e < 5; e++) {
                let i = this.root.getChildByName("round_btn" + e);
                ToolUtils.isObjValid(i) && (e == t ? this.updateRoundItemStatus(i, true) : this.updateRoundItemStatus(i, false));
            }
        }
    }
    onDealButtonEvent(t, e) {
        if (SoundManager.shared().playFx("click"), ToolUtils.isObjValid(this.node)) {
            if (sys.now() - this._lastClick < 500) {
                return;
            }
            if (this._lastClick = sys.now(), "close" == e) {
                this.onBackView();
            }
            else if ("ok" == e) {
                this.dealAssureLogic();
            }
            else if ("clear_checkout" == e) {
                this.checkoutEditNode.getComponent(EditBox).string = "";
            }
            else if ("edit_checkout" == e) {
                this.curCheckOutNode.active = false;
                this.checkoutEditNode.active = true;
                this.autoOutNode.getChildByName("del_btn").active = true;
                this.autoOutNode.getChildByName("edit_btn").active = false;
            }
            else if ("add" == e) {
                let t = RocketGameManager.shared().auto_play_cnt;
                this.checkout_num + 0.1 <= t.auto_out[1] && (this.checkout_num = this.checkout_num + 0.1, this.reSetSliderView(this.checkout_num));
            }
            else if ("reduce" == e) {
                let t = RocketGameManager.shared().auto_play_cnt;
                this.checkout_num - 0.1 >= t.auto_out[0] && (this.checkout_num = this.checkout_num - 0.1, this.reSetSliderView(this.checkout_num));
            }
        }
    }
    dealAssureLogic() {
        let t = { check_num: this.checkout_num, round: this.curRound };
        this.callBack && this.callBack(t);
        this.onBackView();
    }
    onBackView() {
        ToolUtils.isObjValid(this.node) && this.node.destroy();
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().removeListenersByTag(this);
    }
}
