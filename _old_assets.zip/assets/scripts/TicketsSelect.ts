// @ts-nocheck
// Recovered from index.js:623
import { _decorator, Button, color, instantiate, Label, Node, ScrollView, size, Sprite, SpriteFrame, sys, UITransform, v3, view } from "cc";
import Utils from "./Utils";
import SoundManager from "./SoundManager";
import HttpManager from "./HttpManager";
import PushEvent from "./PushEvent";
import i18nMgr from "./i18nMgr";
import BaseLayer from "./BaseLayer";
import TweenTool from "./TweenTool";
import { ScrollviewUtils } from "./ScrollviewUtils";
import User from "./User";
import PushCenter from "./PushCenter";
import ReportConfig from "./ReportConfig";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("TicketsSelect")
export class TicketsSelect extends BaseLayer {
    @property(ScrollView)
    public scollview: ScrollView = null;
    @property([SpriteFrame])
    public ticket_images: SpriteFrame[] = [];
    @property(Node)
    public itemNode: Node = null;
    @property(Node)
    public bgNode: Node = null;
    @property(Label)
    public titleLabel: Label = null;
    @property(Label)
    public timeLabel: Label = null;
    @property(Label)
    public feeLabel: Label = null;
    @property(Label)
    public old_feeLabel: Label = null;
    public _scrollUtil: any = null;
    public listData: any[] = [];
    public availableData: any[] = [];
    public usedData: any[] = [];
    public expiredData: any[] = [];
    public showType: number = 1;
    public _selectColor: any = color(71, 113, 231, 255);
    public _unSelectColor: any = color(49, 49, 49, 255);
    public _itemNodes: any[] = [];
    public _startY: number = 0;
    public _closeAct: any = null;
    public _startAct: any = null;
    public _callback: any = null;
    public race_info: any = null;
    public time_action: any = null;
    public leftTime: number = 0;
    public select_index: number = 0;
    public click_time: number = 0;
    public cur_race_id: number = 0;
    public cur_tk_no: any = null;
    public ui_type: number = 0;
    public match_tid_key: any = null;
    public match_vid: any = null;
    public link_id: number = 0;
    onLoad() {
        this.fitScreen();
        this._scrollUtil = this.node.addComponent(ScrollviewUtils);
        this._scrollUtil.initScrollviewUtils(this.scollview);
    }
    start() {
        super.start();
        this.itemNode.active = false;
        this.link_id = sys.now();
        let t = ToolUtils.judgeIfInRummy() ? 2 : 1, e = ToolUtils.judgeIfInRummy() ? 430 : 431;
        HttpManager.shared().doCommReportRechargeEvent(ReportConfig.Cmd_MatchTicket, t, 5, this.link_id, null, e);
        this.showSelectView();
        this.refreshListUi();
    }
    initParaData(t = null, e = 0, i = null) {
        this._callback = i;
        sys.isObjectValid(t) && (sys.isObjectValid(t.raceinfo) && (this.race_info = t.raceinfo), sys.isObjectValid(t.tickets) && Array.isArray(t.tickets) && (this.listData = t.tickets), sys.isObjectValid(t.raceid) && (this.cur_race_id = t.raceid), sys.isObjectValid(t.match_tid_key) && (this.match_tid_key = t.match_tid_key), sys.isObjectValid(t.match_vid) && (this.match_vid = t.match_vid), this.ui_type = e);
    }
    ticketItem_click(t, e) {
        if (SoundManager.shared().playFx("click"), this.select_index != Number(e)) {
            for (let t = 0, i = this._itemNodes.length; t < i; t++) {
                let i = this._itemNodes[t];
                if (ToolUtils.isObjValid(i)) {
                    let s = i.getChildByName("select"), n = i.getChildByName("unselect"), l = i.getChildByName("desc").getComponent(Label);
                    t == Number(e) ? l.color = color(0, 140, 22, 255) : l.color = color(153, 153, 153, 255);
                    s.active = t == Number(e);
                    n.active = t != Number(e);
                }
            }
            this.select_index = Number(e);
            this.refreshEntryFee();
        }
    }
    initCurMobanCallBack(t, e, i) {
        if (null == e) {
            return;
        }
        t.active = true;
        t.getComponent(Button).clickEvents[0].customEventData = String(i);
        let s = e.discount, n = t.getChildByName("ticket").getComponent(Sprite), l = t.getChildByName("discount_root");
        l.getChildByName("discount").getComponent(Label).string = String(s);
        let a = t.getChildByName("desc").getComponent(Label);
        a.string = ToolUtils.format(i18nMgr.shared().getValueByKey("ticket.reduce_tip"), s);
        let r = t.getChildByName("select"), h = t.getChildByName("unselect");
        0 == i ? (this.select_index = i, a.color = color(0, 140, 22, 255)) : a.color = color(153, 153, 153, 255);
        r.active = 0 == i;
        h.active = 0 != i;
        100 == Number(s) ? (n.spriteFrame = this.ticket_images[1], l.setPosition(v3(0, 0))) : (n.spriteFrame = this.ticket_images[0], 0 == this.ui_type ? l.setPosition(v3(-7, -2)) : 1 == this.ui_type && l.setPosition(v3(-4, 0)));
    }
    updatTime() {
        if (this.leftTime = this.leftTime - 1, this.leftTime <= 0 && (this.time_action && (TweenTool.stopAction(this.time_action), this.time_action = null), 3 == Number(this.race_info.mode))) {
            return i18nMgr.shared().changeLabelFont(this.timeLabel), void (this.timeLabel.string = i18nMgr.shared().getValueByKey("freeMatchPush.enter"));
        }
        let t = Utils.shared().getCountDownString(this.leftTime);
        this.timeLabel.string = t;
    }
    refreshListUi() {
        if (sys.isObjectValid(this.race_info) && (sys.isObjectValid(this.race_info.match_name) && (this.titleLabel.string = "" + this.race_info.match_name), sys.isObjectValid(this.race_info.mode))) {
            if (0 == this.race_info.mode) {
                sys.isObjectValid(this.race_info.joined) && sys.isObjectValid(this.race_info.max_join) && (this.timeLabel.string = this.race_info.joined + "/" + this.race_info.max_join);
            }
            else if (1 == this.race_info.mode || 3 == this.race_info.mode) {
                if (this.leftTime = ToolUtils.isSafeNumber(this.race_info.sy_ts), this.time_action && TweenTool.stopAction(this.time_action), 3 == ToolUtils.isSafeNumber(this.race_info.mode) && this.leftTime <= 0) {
                    i18nMgr.shared().changeLabelFont(this.timeLabel);
                    this.timeLabel.string = i18nMgr.shared().getValueByKey("freeMatchPush.enter");
                }
                else {
                    let t = Utils.shared().getCountDownString(this.leftTime);
                    this.timeLabel.string = t;
                    this.time_action = TweenTool.myschedule(this.node, 1, this.updatTime.bind(this));
                }
            }
            sys.isObjectValid(this.race_info.entry) && (this.old_feeLabel.string = "₹" + ToolUtils.parse_double(String(this.race_info.entry), -2));
        }
        Array.isArray(this.scollview.content.children) && this.scollview.content.children.length > 0 && this.scollview.content.removeAllChildren();
        let t, e = 0, i = 0, s = this.listData.length, n = this.itemNode.getComponent(UITransform).height, l = n;
        for (let i = 0; i < s; i++) {
            e = -i * l;
            ToolUtils.isObjValid(this._itemNodes[i]) ? (t = this._itemNodes[i], t.active = true, t.setPosition(v3(0, e)), this.scollview.content.addChild(t)) : (t = instantiate(this.itemNode), t.active = true, t.setPosition(v3(0, e)), this.scollview.content.addChild(t), this._itemNodes[i] = t);
            this.initCurMobanCallBack(t, this.listData[i], i);
        }
        let a = this.scollview.getComponent(UITransform).contentSize;
        i = l * (s - 1) + n;
        this.scollview.content.getComponent(UITransform).setContentSize(size(a.width, i));
        this._scrollUtil.setScollDetails2(1, a.height, s, true);
        this.refreshEntryFee();
    }
    refreshEntryFee() {
        if (Array.isArray(this.listData) && this.listData.length > this.select_index && sys.isObjectValid(this.race_info) && sys.isObjectValid(this.race_info.entry)) {
            this.old_feeLabel.string = "₹" + ToolUtils.parse_double(String(this.race_info.entry), -2);
            let t = (1 - this.listData[this.select_index].discount / 100) * this.race_info.entry;
            t <= 0 ? (i18nMgr.shared().changeLabelFont(this.feeLabel, true), this.feeLabel.string = i18nMgr.shared().getValueByKey("tournament.free")) : this.feeLabel.string = "₹" + t.toFixed(2);
        }
    }
    button_click(t, e) {
        if (SoundManager.shared().playFx("click"), "close" == e) {
            this.onBackView();
        }
        else if ("cancel" == e) {
            this.onBackView();
        }
        else if ("join" == e) {
            if (sys.now() - this.click_time <= 1000) {
                return;
            }
            if (this.click_time = sys.now(), Array.isArray(this.listData) && this.listData.length > this.select_index) {
                this.cur_tk_no = this.listData[this.select_index].tk_no;
                let t = { tk_no: this.cur_tk_no }, e = ToolUtils.judgeIfInRummy() ? 2 : 1, i = ToolUtils.judgeIfInRummy() ? 430 : 431;
                HttpManager.shared().doCommReportRechargeEvent(ReportConfig.Cmd_MatchTicket, e, 6, this.link_id, t, i);
                User.shared().send_race_rejoin_request(this.cur_race_id, null, this.cur_tk_no, this.match_tid_key, this.match_vid);
            }
            PushCenter.shared().pushEvent(PushEvent.CloseMatchTicketUsingView);
            this.onBackView();
        }
    }
    fitScreen() {
    }
    onBackView() {
        ToolUtils.isObjValid(this.node) && this.hideSelectView();
    }
    showSelectView() {
        if (0 == this.ui_type) {
            let t = -view.getVisibleSize().height / 2, e = this.bgNode.getComponent(UITransform).height;
            this._startY = t - e - 20;
            this.bgNode.setPosition(v3(0, this._startY));
            this._startAct = TweenTool.moveTo(this.bgNode, 0.2, v3(0, t), "sineIn", true);
        }
        else {
            this.node.getChildByName("mask").getComponent(UITransform).setContentSize(view.getVisibleSize());
            this.startShowAnim(this.bgNode);
        }
    }
    hideSelectView() {
        this._startAct && TweenTool.stopAction(this._startAct);
        this._closeAct || (this._callback && this._callback(), this._closeAct = TweenTool.moveTo(this.bgNode, 0.2, v3(0, this._startY), "sineIn", true, (() => {
            ToolUtils.isObjValid(this.node) && this.node.destroy();
        })));
    }
    onDestroy() {
        super.onDestroy();
        this.time_action && TweenTool.stopAction(this.time_action);
        this.time_action = null;
    }
}
