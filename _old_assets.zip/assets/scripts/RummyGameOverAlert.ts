// @ts-nocheck
// Recovered from index.js:445
import { _decorator, Button, color, director, game, HorizontalTextAlignment, instantiate, Label, LabelShadow, Node, Overflow, Prefab, ProgressBar, RichText, size, sp, Sprite, SpriteAtlas, SpriteFrame, sys, tween, UIOpacity, UITransform, v3, Vec3, Widget } from "cc";
import BaseLayer from "./BaseLayer";
import i18nMgr from "./i18nMgr";
import PushCenter from "./PushCenter";
import { TLog } from "./TLog";
import { ToolUtils } from "./ToolUtils";
import { TransferPlatform } from "./TransferPlatform";
import TweenTool from "./TweenTool";
import Utils from "./Utils";
import CommDefine from "./CommDefine";
import GameConfig from "./GameConfig";
import PhpReportDefined from "./PhpReportDefined";
import PushEvent from "./PushEvent";
import RummyCmd from "./RummyCmd";
import User from "./User";
import HttpManager from "./HttpManager";
import SoundManager from "./SoundManager";
import RummyDataManager, { RUMMY_GAME_TYPE, RUMMY_MATCH_MODE } from "./RummyDataManager";
const { ccclass, property } = _decorator;
@ccclass("RummyGameOverAlert")
export default class RummyGameOverAlert extends BaseLayer {
    @property(Node)
    public rootNode: Node = null;
    @property(Node)
    public treasurehuntNode: Node = null;
    @property(SpriteAtlas)
    public myAtlas: SpriteAtlas = null;
    @property(Prefab)
    public cardPrefab: Prefab = null;
    @property(Node)
    public mobanView: Node = null;
    @property(SpriteAtlas)
    public rummyAtlas: SpriteAtlas = null;
    @property([SpriteFrame])
    public bottom_card_img: SpriteFrame[] = [];
    @property(Node)
    public tipsMask: Node = null;
    @property(Node)
    public bonusTipsMask: Node = null;
    @property(Node)
    public bottomBtns: Node = null;
    @property([SpriteFrame])
    public laizi_imgs: SpriteFrame[] = [];
    @property(SpriteAtlas)
    public clubKuangAtlas: SpriteAtlas = null;
    @property([SpriteFrame])
    public btn_imgs: SpriteFrame[] = [];
    @property([SpriteFrame])
    public win_flags: SpriteFrame[] = [];
    @property(SpriteAtlas)
    public rewardPlist: SpriteAtlas = null;
    public _callback: any = null;
    public cardScale: any = v3(0.32, 0.32, 0.32);
    public fromtype: number = 0;
    public laizicard: number = 0;
    public msg: any = null;
    public will_disuse: number = 0;
    public startTime: number = 0;
    public can_rejoin: number = 0;
    public ispoolRummyend: boolean = false;
    public all_end: number = 0;
    public bIsEnd: boolean = false;
    public cround: number = 0;
    public dealsMyTiebreak: boolean = false;
    public poolRejoin: boolean = false;
    public poolRejoinMoney: number = 0;
    public poolRejoinScore: number = 0;
    public is_auto_split: number = 0;
    public auto_split_money: number = 0;
    public _lastClick: number = 0;
    public hide_start: number = 0;
    public itemViewDate: any[] = [];
    public time_action: any = null;
    public isShowOkBtn: boolean = false;
    public isShowStartBtn: boolean = false;
    public isShowShareBtn: boolean = false;
    public isShowExitBtn: boolean = false;
    public isShowPoolRejoinBtn: boolean = false;
    public isShowPoolCencelBtn: boolean = false;
    public isShowSwitchBtn: boolean = false;
    public _bClickBtn: boolean = false;
    public isShowPoolYesBtn: boolean = false;
    public isShowPoolNoBtn: boolean = false;
    public _isWatching: number = 0;
    public pre_end: number = 0;
    public settle_type: number = 0;
    public win_prize: number = 0;
    public _showNewPlayerGuide: number = 0;
    public _showIndex: number = 0;
    public _leftTime: any = -1;
    public _isReissue: boolean = false;
    public _upType: any = -1;
    public hasHideCashTip: boolean = false;
    public hasClickCloseTreasure_Play: boolean = false;
    public hasClickCloseTreasure_Banner: boolean = false;
    public hasShowBonusTips: boolean = false;
    public _hideBonusTipsAct: any = null;
    public _showBonusTipsStr: string = "";
    public _curBonusTipsWidth: number = 0;
    public _hasUpBtn: boolean = false;
    public flopCashStopTime: boolean = false;
    public _rankAct: any = null;
    public rankAnimHasPlay: boolean = false;
    public hasShowRank: boolean = false;
    public _bReportSwitch: boolean = false;
    public _bHasReportShow: boolean = false;
    public _hasReportShare: boolean = false;
    onLoad() {
        this.bIsInGame = true;
        this._bReportSwitch = ToolUtils.checkIsModuleReport(PhpReportDefined.module.game_over_high);
    }
    onEnable() {
        ToolUtils.isObjValid(this.rootNode) && ToolUtils.isObjValid(this.rootNode.getChildByName("playerView")) && this.rootNode.getChildByName("playerView").on("scrolling", this.onScrollView_Scrolling, this);
        ToolUtils.isObjValid(this.tipsMask) && (this.tipsMask.getChildByName("mask").on(Node.EventType.TOUCH_START, this.onTouchEvent, this), this.tipsMask.getChildByName("mask").on(Node.EventType.TOUCH_MOVE, this.onTouchEvent, this), this.tipsMask.getChildByName("mask").on(Node.EventType.TOUCH_END, this.onTouchEvent, this), this.tipsMask.getChildByName("mask").on(Node.EventType.TOUCH_CANCEL, this.onTouchEvent, this));
    }
    onDisable() {
        ToolUtils.isObjValid(this.rootNode) && ToolUtils.isObjValid(this.rootNode.getChildByName("playerView")) && this.rootNode.getChildByName("playerView").off("scrolling", this.onScrollView_Scrolling, this);
        ToolUtils.isObjValid(this.tipsMask) && (this.tipsMask.getChildByName("mask").off(Node.EventType.TOUCH_START, this.onTouchEvent, this), this.tipsMask.getChildByName("mask").off(Node.EventType.TOUCH_MOVE, this.onTouchEvent, this), this.tipsMask.getChildByName("mask").off(Node.EventType.TOUCH_END, this.onTouchEvent, this), this.tipsMask.getChildByName("mask").off(Node.EventType.TOUCH_CANCEL, this.onTouchEvent, this));
    }
    start() {
        super.start();
        ToolUtils.showFullScreen(this.node.getChildByName("bg"));
        PushCenter.shared().addListener(PushEvent.HideGameOverBg, (e => {
            ToolUtils.isObjValid(this.node) && (this.node.getChildByName("bg").active = false);
        }), this);
        PushCenter.shared().addListener(PushEvent.ShowGameOverBg, (e => {
            ToolUtils.isObjValid(this.node) && (this.node.getChildByName("bg").active = true);
        }), this);
        PushCenter.shared().addListener(PushEvent.NoticeFinishFlopStart, (e => {
            ToolUtils.isObjValid(this.node) && this.tid_key == e && this.dealStartClickLogic();
        }), this);
        PushCenter.shared().addListener(PushEvent.Update_Gullak_State, (e => {
            if (ToolUtils.isObjValid(this.node)) {
                let e = RummyDataManager.shared().rummyInfos.get(this.tid_key);
                sys.isObjectValid(e) && e.gameRummyType != RUMMY_GAME_TYPE.MATCH && (e.gameRummyType == RUMMY_GAME_TYPE.POOL || e.gameRummyType == RUMMY_GAME_TYPE.DEALS || e.gameRummyType == RUMMY_GAME_TYPE.PRI_POOL || e.gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL || 0 == e.crashModel && this.updateGullakBtnStatus(User.shared().act_68_open, User.shared().act_68_full_status, true));
            }
        }), this);
        PushCenter.shared().addListener(PushEvent.Notice_VipUpdateShow, (e => {
            ToolUtils.isObjValid(this.node) && (this.flopCashStopTime = true, this.stopUpdateTime());
        }), this);
        3 == i18nMgr.shared().language && (this.rootNode.getChildByName("start_btn").getChildByName("wz").getComponent(Label).horizontalAlign = HorizontalTextAlignment.LEFT, this.rootNode.getChildByName("start_btn").getChildByName("wz").getComponent(Label).overflow = Overflow.NONE);
        let e = RummyDataManager.shared().rummyInfos.get(this.tid_key);
        if (sys.isObjectValid(e)) {
            let t = e.novicesGameOverLaba;
            sys.isObjectValid(t) && this.updateNovicesBanner(t);
            let i = e.flopCashTaskLaba;
            sys.isObjectValid(i) && this.updateFlopCashBanner(i);
            e.gameRummyType != RUMMY_GAME_TYPE.MATCH && (e.gameRummyType == RUMMY_GAME_TYPE.POOL || e.gameRummyType == RUMMY_GAME_TYPE.DEALS || e.gameRummyType == RUMMY_GAME_TYPE.PRI_POOL || e.gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL || 0 == e.crashModel && this.updateGullakBtnStatus(User.shared().act_68_open, User.shared().act_68_full_status, false));
        }
    }
    updateGullakBtnStatus(e, t, i) {
        let s = this.bottomBtns.getChildByName("gullak_btn");
        if (ToolUtils.isObjValid(s) && (s.active = 1 == e, 1 == e)) {
            let e = s.getChildByName("anim").getComponent(sp.Skeleton);
            e.clearTracks();
            e.setToSetupPose();
            i ? (e.setAnimation(0, "2", false), e.setCompleteListener((() => {
                e.setCompleteListener(null);
                e.clearTracks();
                e.setToSetupPose();
                0 == t ? e.setAnimation(0, "0", true) : e.setAnimation(0, "1", true);
            }))) : 0 == t ? e.setAnimation(0, "0", true) : e.setAnimation(0, "1", true);
        }
    }
    onDestroy() {
        this.removePopNode();
        TweenTool.stopNodeAction(this.node);
        this.time_action && (TweenTool.stopAction(this.time_action), this.time_action = null);
        RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType == RUMMY_GAME_TYPE.PRIVATE && PushCenter.shared().pushEvent(PushEvent.ShowWinShareBtn, false);
        ToolUtils.isObjValid(this.rootNode) && this.rootNode.getChildByName("playerView").off("scrolling", this.onScrollView_Scrolling, this);
        PushCenter.shared().removeListenersByTag(this);
        this.unscheduleAllCallbacks();
    }
    startShowAnim() {
        try {
            TweenTool.stopNodeAction(this.rootNode);
            this.rootNode.active = true;
            this.rootNode.setPosition(v3(0, 400, 0));
            this.rootNode.getComponent(UIOpacity) || this.rootNode.addComponent(UIOpacity);
            this.rootNode.getComponent(UIOpacity).opacity = 255;
            let e = TweenTool.moveToByFade(this.rootNode, 0.26, v3(0, -10, 0), 0.7, 1, false, (() => {
                this.rootNode.setPosition(v3(0, -10, 0));
                RummyDataManager.shared().rummyInfos.get(this.tid_key).manule_rejoin_select && this.bIsEnd && this._callback && this._callback("manula_auto_rejoin");
            })), t = TweenTool.moveTo(this.rootNode, 0.1, v3(0, 0, 0), "quadInOut");
            TweenTool.sequence(this.rootNode, true, null, e, t).start();
            1 == User.shared().isInPerformanceRoom && (this.node.getChildByName("bg").active = false);
        }
        catch (e) {
            TLog.printError("trycatch RummyGameOverAlert startShowAnim ", e);
        }
    }
    startHideAnim() {
        try {
            TweenTool.stopNodeAction(this.rootNode);
            this.rootNode.active = false;
            this.rankAnimHasPlay = false;
            RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType == RUMMY_GAME_TYPE.PRIVATE && PushCenter.shared().pushEvent(PushEvent.ShowWinShareBtn, false);
        }
        catch (e) {
            TLog.printError("trycatch RummyGameOverAlert startHideAnim ", e);
        }
    }
    onClickClose(e, t = "") {
        SoundManager.shared().playFx("click");
        sys.now() - this._lastClick < 500 || (this._lastClick = sys.now(), "close" == t && 1 == this.fromtype ? this.onBackView() : "ok" == t && (this.startHideAnim(), this.isShowEndView(false), 0 == this.fromtype ? this._callback && this._callback("private_gameOver_self_closed") : RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType == RUMMY_GAME_TYPE.PRIVATE && undefined !== this.msg.start_cd && this._callback && this._callback("private_close")));
    }
    onTouchEvent(e) {
        e.preventSwallow = true;
        e.getType() == Node.EventType.TOUCH_START && ToolUtils.isObjValid(this.node) && this.onCloseItemHelpTips(null);
    }
    onScrollView_Scrolling(e) {
        if (ToolUtils.isObjValid(this.tipsMask) && this.tipsMask.active) {
            let e = 0.5 * GameConfig.REAL_SCREEN_WIDTH;
            if (this.itemViewDate[this._showIndex].item && this.itemViewDate[this._showIndex].item.isValid) {
                let t = this.itemViewDate[this._showIndex].item, i = t.children.length + 1;
                t.getChildByName("help_btn").setSiblingIndex(i);
                let s = t.getChildByName("help_btn").getWorldPosition();
                1 == i18nMgr.shared().language ? (this.tipsMask.getComponent(UITransform).contentSize = size(770, 60), this.tipsMask.setPosition(v3(-30, s.y - e - 45))) : (this.tipsMask.getComponent(UITransform).contentSize = size(810, 60), this.tipsMask.setPosition(v3(-50, s.y - e - 45)));
                s.y - e - 45 > 264.438 && (this.bonusTipsMask.active = false);
            }
        }
        if (ToolUtils.isObjValid(this.bonusTipsMask) && this.bonusTipsMask.active) {
            let e = 0.5 * GameConfig.REAL_SCREEN_WIDTH;
            if (this.itemViewDate[this._showIndex].item && this.itemViewDate[this._showIndex].item.isValid) {
                let t = this.itemViewDate[this._showIndex].item, i = t.children.length + 1;
                t.getChildByName("bonus_btn").setSiblingIndex(i);
                let s = t.getChildByName("bonus_btn").getWorldPosition(), o = new Vec3;
                this.rootNode.inverseTransformPoint(o, s);
                this.bonusTipsMask.setPosition(v3(o.x + 34, o.y + 63));
                s.y - e + 63 > 264.438 && (this.bonusTipsMask.active = false);
            }
        }
    }
    updateInfo(e, t, i = null, s = false) {
        try {
            sys.isObjectValid(t.isReissue) && (this._isReissue = t.isReissue);
            let o = RummyDataManager.shared().rummyInfos.get(this.tid_key);
            if (t.cmd == RummyCmd.SM_GAME_END_BC_INFORM && (o.gameRummyType != RUMMY_GAME_TYPE.POINTS && o.gameRummyType != RUMMY_GAME_TYPE.PRIVATE && o.gameRummyType != RUMMY_GAME_TYPE.MULTIPLE && o.gameRummyType != RUMMY_GAME_TYPE.MATCH || PushCenter.shared().pushEvent(PushEvent.GameOverShowFreeMatchPush), sys.isObjectValid(t.show_share) && 1 == t.show_share && (this.isShowShareBtn = true, this._bHasReportShow || (this._bHasReportShow = true, HttpManager.shared().doReportClick({ module: PhpReportDefined.module.share, scene: PhpReportDefined.scece.share_gameover, event: PhpReportDefined.share_event.show })))), this.rootNode.getChildByName("ok_btn").getComponent(Button).clickEvents[0].customEventData = "ok", this.fromtype = e, this.bIsEnd = s, this.msg = null, this.win_prize = ToolUtils.isSafeNumber(t.win_prize), this.all_end = null != t.all_end ? t.all_end : 0, null != t.hide_start && (this.hide_start = t.hide_start), this.settle_type = ToolUtils.isSafeNumber(t.settle_type), t.players) {
                for (let e = 0, i = t.players.length; e < i; e++) {
                    const i = t.players[e];
                    if (i.uid == User.shared().data.uid) {
                        this.can_rejoin = ToolUtils.isSafeNumber(i.can_rejoin);
                        this.will_disuse = ToolUtils.isSafeNumber(i.will_disuse);
                        this.bIsEnd && sys.isObjectValid(i.show_new_player_guide) && (this._showNewPlayerGuide = i.show_new_player_guide);
                        break;
                    }
                }
            }
            if (o.gameRummyType == RUMMY_GAME_TYPE.POOL || o.gameRummyType == RUMMY_GAME_TYPE.PRI_POOL) {
                1 == t.all_end ? o.game_end_state = 5 : o.game_end_state = t.WaitState;
                let e = o.clientSeatId;
                if (t.pool_game_info && null != t.pool_game_info && t.pool_game_info.rejoin_seatids && t.pool_game_info.rejoin_seatids.length > 0) {
                    for (let i = 0, s = t.pool_game_info.rejoin_seatids.length; i < s; i++) {
                        if (e == t.pool_game_info.rejoin_seatids[i]) {
                            this.poolRejoin = true;
                            this.poolRejoinMoney = t.pool_game_info.rejoin_money;
                            this.poolRejoinScore = t.pool_game_info.rejoin_score;
                            break;
                        }
                    }
                }
                if (sys.isObjectValid(t.is_auto_split) && (this.is_auto_split = t.is_auto_split, sys.isObjectValid(t.is_auto_split) && (this.auto_split_money = t.split_prize)), null != t.cd) {
                    let e = t.cd;
                    null != t.isReissue && 1 == t.isReissue && 1 == this.poolRejoin && (e = t.cd, 0 == e && (this.startTime = e));
                    e > 0 && this.setPoolRummyCountDown(e);
                }
                this.rootNode.getChildByName("exit_btn").active = false;
                this.rootNode.getChildByName("title_node").getChildByName("label_sum").getComponent(Label).string = i18nMgr.shared().getValueByKey("rummy_gameover.total");
            }
            else if (o.gameRummyType == RUMMY_GAME_TYPE.DEALS || o.gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL) {
                this.rootNode.getChildByName("no_btn").getComponent(Button).clickEvents[0].customEventData = "no";
                2 === this.settle_type && o.gameRummyType == RUMMY_GAME_TYPE.DEALS && (this.rootNode.getChildByName("no_btn").getComponent(Button).clickEvents[0].customEventData = "pool_game_all_end", this.all_end = 1);
                o.gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL && 2 === this.settle_type && (this.rootNode.getChildByName("ok_btn").getComponent(Button).clickEvents[0].customEventData = "no");
                this.pre_end = ToolUtils.isSafeNumber(t.pre_end);
                this.rootNode.getChildByName("title_node").getChildByName("label_sum").getComponent(Label).string = i18nMgr.shared().getValueByKey("rummy_gameover.total");
                this.rootNode.getChildByName("title_node").getChildByName("label_score").getComponent(Label).string = i18nMgr.shared().getValueByKey("rummy_gameover.score");
                let e = o.clientSeatId;
                if (t.deals_tiebreak_seatids && null != t.deals_tiebreak_seatids && t.deals_tiebreak_seatids.length > 0) {
                    for (let i = 0, s = t.deals_tiebreak_seatids.length; i < s; i++) {
                        e == t.deals_tiebreak_seatids[i] && (this.dealsMyTiebreak = true);
                    }
                }
                if (null != t.cd && (o.dealsRummyCurrentRount = t.cround + 1, this.cround = t.cround, 1 == t.all_end ? o.game_end_state = 5 : (o.game_end_state = t.WaitState, o.dealsRummyCurrentRount = 1), null != t.cd)) {
                    let e = t.cd;
                    1 === this.settle_type && o.gameRummyType == RUMMY_GAME_TYPE.DEALS && (e = 0);
                    e > 0 && this.setPoolRummyCountDown(e);
                }
            }
            else if ((o.gameRummyType == RUMMY_GAME_TYPE.POINTS || o.gameRummyType == RUMMY_GAME_TYPE.MULTIPLE || this.checkIsPointsMatch()) && null != t.cd) {
                let e = t.cd;
                e > 0 && this.setPoolRummyCountDown(e);
            }
            if (this.sortPlayers(t), this._callback = i, 1 === e ? this.showGameRecodeCountDownTips(t) : 1 == User.shared().isInPerformanceRoom ? this.showPerformanceRoomTips(t) : o.gameRummyType == RUMMY_GAME_TYPE.PRIVATE && PushCenter.shared().addListener(PushEvent.GameOverDowntimeTip, (e => {
                e.tid_key == this.tid_key && this.showPrivateTips(e.typeNum, e.TextStr);
            }), this), this.checkShowWinShareBtn(), sys.isObjectValid(this.msg.force_up_venue_tips_end) && 1 == ToolUtils.isSafeNumber(this.msg.force_up_venue_tips_end.show)) {
                o.force_up_venue_tips_end = this.msg.force_up_venue_tips_end;
                this.rootNode.getChildByName("start_btn").getComponent(Button).clickEvents[0].customEventData = "continue";
            }
            this._hasUpBtn = false;
            sys.isObjectValid(t.up_venue) ? (1 == o.crashModel ? this.show_up_btn(t.up_venue, 1) : this.show_up_btn(t.up_venue, 0), this._hasUpBtn && 0 == o.crashModel && this._bReportSwitch && !this._bHasReportShow && (HttpManager.shared().doReportClick({ module: PhpReportDefined.module.game_over_high, scene: PhpReportDefined.scece.cash_room_gameover, event: PhpReportDefined.game_over_high_event.show, vid: o.vid }), this._bHasReportShow = true)) : 1 == o.crashModel && sys.isObjectValid(t.tf_venue) && this.show_up_btn(t.tf_venue, 2);
            t.cmd != RummyCmd.SM_LAST_CARD_RETURN && this.updateTreasureHuntBanner(null);
            sys.isObjectValid(t.show_quick) && 1 == t.show_quick && TweenTool.delayAct(this.node, (() => {
                ToolUtils.isObjValid(this.node) && (this._callback && this._callback("show_quick"), this.stopUpdateTime());
            }), 0.5, true);
        }
        catch (e) {
            TLog.printError("trycatch RummyGameOverAlert updateInfo set:", e);
        }
    }
    refreshRoomActAnim() {
    }
    updateTreasureHuntBanner(e) {
        if (this.hasClickCloseTreasure_Banner) {
            return;
        }
        if (0 == RummyDataManager.shared().rummyInfos.get(this.tid_key).crashModel) {
            return;
        }
        let t = null;
        if (t = sys.isObjectValid(e) ? e.data : RummyDataManager.shared().rummyInfos.get(this.tid_key).act97_data, !sys.isObjectValid(t)) {
            return;
        }
        let i = this.rootNode.getChildByName("up_btn"), s = false, o = false;
        if (sys.isObjectValid(t.end_task) && (0 == Number(t.end_task) ? s = true : i.active && 1 == this._upType ? s = false : sys.isObjectValid(t.up_venue) ? (s = true, o = true) : s = false), s) {
            try {
                this.treasurehuntNode.active = true;
                let e = this.treasurehuntNode.getChildByName("play_node"), i = this.treasurehuntNode.getChildByName("banner_node");
                e.active = false;
                i.active = true;
                let s = i.getChildByName("anim");
                s.active = true;
                let a = i.getChildByName("progress").getChildByName("Bar").getChildByName("Node").getChildByName("anim");
                a.active = false;
                for (let e = 0; e < 4; e++) {
                    i.getChildByName("reward_node").getChildByName("item" + e).active = false;
                }
                if (o) {
                    if (sys.isObjectValid(t.up_venue.c_rewards) && Array.isArray(t.up_venue.c_rewards) && t.up_venue.c_rewards.length > 0) {
                        for (let e = 0; e < t.up_venue.c_rewards.length; e++) {
                            let s = t.up_venue.c_rewards[e].type, o = "item0";
                            0 == s ? o = "item0" : 1 == s ? o = "item1" : 7 == s ? o = "item2" : 9999 == s && (o = "item3");
                            i.getChildByName("reward_node").getChildByName(o).active = true;
                            9999 != s && (i.getChildByName("reward_node").getChildByName(o).getChildByName("num").getComponent(Label).string = 7 == s ? ToolUtils.parse_ChipNum2(t.up_venue.c_rewards[e].amt) : t.up_venue.c_rewards[e].amt);
                        }
                    }
                    s.active = true;
                    s.getComponent(sp.Skeleton).clearTracks();
                    s.getComponent(sp.Skeleton).setToSetupPose();
                    s.getComponent(sp.Skeleton).setAnimation(0, "standby", true);
                    i.getChildByName("progress").getComponent(ProgressBar).progress = t.up_venue.cju / t.up_venue.tju;
                    i.getChildByName("progress_wz").getComponent(Label).string = String(t.up_venue.cju) + "/" + String(t.up_venue.tju);
                    a.active = true;
                    a.getComponent(sp.Skeleton).clearTracks();
                    a.getComponent(sp.Skeleton).setToSetupPose();
                    a.getComponent(sp.Skeleton).setAnimation(0, "progress", true);
                    this.hasClickCloseTreasure_Play || (e.active = true, e.getChildByName("play_treasure_upbtn").getChildByName("root").getChildByName("num").getComponent(Label).string = t.up_venue.point);
                    a.parent.getComponent(Widget).updateAlignment();
                }
                else {
                    if (sys.isObjectValid(t.c_rewards) && Array.isArray(t.c_rewards) && t.c_rewards.length > 0) {
                        for (let e = 0; e < t.c_rewards.length; e++) {
                            let s = t.c_rewards[e].type, o = "item0";
                            0 == s ? o = "item0" : 1 == s ? o = "item1" : 7 == s ? o = "item2" : 9999 == s && (o = "item3");
                            i.getChildByName("reward_node").getChildByName(o).active = true;
                            9999 != s && (i.getChildByName("reward_node").getChildByName(o).getChildByName("num").getComponent(Label).string = 7 == s ? ToolUtils.parse_ChipNum2(t.c_rewards[e].amt) : t.c_rewards[e].amt);
                        }
                    }
                    sys.isObjectValid(t.show_box) && 1 == Number(t.show_box) ? (s.active = true, s.getComponent(sp.Skeleton).clearTracks(), s.getComponent(sp.Skeleton).setToSetupPose(), s.getComponent(sp.Skeleton).setAnimation(0, "glow", true), i.getChildByName("progress_wz").getComponent(Label).string = "100%", i.getChildByName("progress").getComponent(ProgressBar).progress = 1) : (s.active = true, s.getComponent(sp.Skeleton).clearTracks(), s.getComponent(sp.Skeleton).setToSetupPose(), s.getComponent(sp.Skeleton).setAnimation(0, "standby", true), i.getChildByName("progress").getComponent(ProgressBar).progress = t.cju / t.tju, i.getChildByName("progress_wz").getComponent(Label).string = String(t.cju) + "/" + String(t.tju), a.active = true, a.getComponent(sp.Skeleton).clearTracks(), a.getComponent(sp.Skeleton).clearTracks(), a.getComponent(sp.Skeleton).setAnimation(0, "progress", true), a.parent.getComponent(Widget).updateAlignment());
                }
            }
            catch (e) {
                TLog.printError("updateTreasureHuntBanner err:", e);
            }
        }
        else {
            this.treasurehuntNode.active = false;
        }
    }
    showPerformanceRoomTips(e) {
        let t = 0;
        if (null != e.cd && (t = e.cd, t > 0 && 1 == e.all_end)) {
            let e = RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType;
            if (e == RUMMY_GAME_TYPE.POOL || e == RUMMY_GAME_TYPE.PRI_POOL || e == RUMMY_GAME_TYPE.DEALS || e == RUMMY_GAME_TYPE.PRI_DEAL) {
                this.time_action && (TweenTool.stopAction(this.time_action), this.time_action = null);
                this.rootNode.getChildByName("pool_time").setPosition(v3(362, -211));
                this.startTime = t;
                let e = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_gameover.over_tips4"), this.startTime);
                this.rootNode.getChildByName("pool_time").active = true;
                this.rootNode.getChildByName("ready_tips").active = false;
                let i = 28;
                0 != this._upType && 2 != this._upType || 0 != i18nMgr.shared().language && 1 != i18nMgr.shared().language && (i = 20);
                this.rootNode.getChildByName("pool_time").getComponent(RichText).fontSize = i;
                this.rootNode.getChildByName("pool_time").getComponent(RichText).string = e;
                this.updateReadyTipPos();
                let s = this;
                this.time_action = TweenTool.myschedule(RummyDataManager.shared().sceneNode, 1, (() => {
                    s.updatePerformanceTime();
                }));
            }
        }
    }
    updatePerformanceTime() {
        if (ToolUtils.isObjValid(this.rootNode)) {
            if (this.startTime = this.startTime - 1, this.startTime < 1) {
                this.stopPoolRummyCountDown();
                PushCenter.shared().pushEvent(PushEvent.RestoreRoomPerformance);
            }
            else {
                let e = "", t = 28;
                0 != this._upType && 2 != this._upType || 0 != i18nMgr.shared().language && 1 != i18nMgr.shared().language && (t = 20);
                e = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_gameover.over_tips4"), this.startTime);
                this.rootNode.getChildByName("pool_time").getComponent(RichText).fontSize = t;
                this.rootNode.getChildByName("pool_time").getComponent(RichText).string = e;
                this.rootNode.getChildByName("ready_tips").active = false;
            }
        }
    }
    showCommingSplitTips(e) {
        this.time_action && (TweenTool.stopAction(this.time_action), this.time_action = null);
        this.rootNode.getChildByName("pool_time").setPosition(v3(362, -211));
        this.startTime = e;
        let t = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_gameover.over_tips15"), this.startTime);
        this.rootNode.getChildByName("pool_time").active = true;
        this.rootNode.getChildByName("ready_tips").active = false;
        this.rootNode.getChildByName("pool_time").getComponent(RichText).string = t;
        this.rootNode.getChildByName("pool_time").getComponent(RichText).fontSize = 28;
        this.updateReadyTipPos();
        let i = this;
        this.time_action = TweenTool.myschedule(RummyDataManager.shared().sceneNode, 1, (() => {
            i.updateCommingSplitTime();
        }));
    }
    updateCommingSplitTime() {
        if (ToolUtils.isObjValid(this.rootNode)) {
            if (this.startTime = this.startTime - 1, this.startTime < 1) {
                this.stopPoolRummyCountDown();
                ToolUtils.isObjValid(this.node) && this.node.destroy();
                this._callback && (this._callback("pool_game_all_end"), this._callback("gameOverAlertDestroy"), this._callback("cleanGameEndPointer"));
            }
            else if (RummyDataManager.shared().rummyInfos.has(this.tid_key)) {
                let e = "", t = 28;
                0 != this._upType && 2 != this._upType || 0 != i18nMgr.shared().language && 1 != i18nMgr.shared().language && (t = 20);
                e = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_gameover.over_tips15"), this.startTime);
                this.rootNode.getChildByName("pool_time").getComponent(RichText).string = e;
                this.rootNode.getChildByName("pool_time").getComponent(RichText).fontSize = t;
                this.rootNode.getChildByName("ready_tips").active = false;
            }
        }
    }
    showNotifyRejoinTips(e) {
        if (RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType == RUMMY_GAME_TYPE.POOL || RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType == RUMMY_GAME_TYPE.PRI_POOL) {
            this.time_action && (TweenTool.stopAction(this.time_action), this.time_action = null);
            this.rootNode.getChildByName("pool_time").setPosition(v3(362, -211));
            this.startTime = e;
            let t = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_gameover.over_tips5"), this.startTime), i = 28;
            0 != this._upType && 2 != this._upType || 0 != i18nMgr.shared().language && 1 != i18nMgr.shared().language && (i = 20);
            this.rootNode.getChildByName("pool_time").active = true;
            this.rootNode.getChildByName("ready_tips").active = false;
            this.rootNode.getChildByName("pool_time").getComponent(RichText).string = t;
            this.rootNode.getChildByName("pool_time").getComponent(RichText).fontSize = i;
            this.updateReadyTipPos();
            let s = this;
            this.time_action = TweenTool.myschedule(RummyDataManager.shared().sceneNode, 1, (() => {
                s.updateRejoinTime();
            }));
        }
    }
    updateRejoinTime() {
        if (ToolUtils.isObjValid(this.rootNode)) {
            if (this.startTime = this.startTime - 1, this.startTime < 1) {
                this.stopPoolRummyCountDown();
                ToolUtils.isObjValid(this.node) && this.node.destroy();
                this._callback && this._callback("cleanGameEndPointer");
            }
            else if (RummyDataManager.shared().rummyInfos.has(this.tid_key)) {
                let e = "", t = 28;
                0 != this._upType && 2 != this._upType || 0 != i18nMgr.shared().language && 1 != i18nMgr.shared().language && (t = 20);
                e = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_gameover.over_tips5"), this.startTime);
                this.rootNode.getChildByName("pool_time").getComponent(RichText).string = e;
                this.rootNode.getChildByName("pool_time").getComponent(RichText).fontSize = t;
                this.rootNode.getChildByName("ready_tips").active = false;
            }
        }
    }
    showGameRecodeCountDownTips(e) {
        let t = RummyDataManager.shared().rummyInfos.get(this.tid_key);
        if (t.gameRummyType == RUMMY_GAME_TYPE.POOL || t.gameRummyType == RUMMY_GAME_TYPE.PRI_POOL || t.gameRummyType == RUMMY_GAME_TYPE.DEALS || t.gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL) {
            if (this.time_action && (TweenTool.stopAction(this.time_action), this.time_action = null), ToolUtils.isSafeNumber(e.start_cd) > 0) {
                this.rootNode.getChildByName("ok_btn").getComponent(Button).clickEvents[0].customEventData = "recode_ok";
                this.rootNode.getChildByName("ok_btn").active = true;
                this.rootNode.getChildByName("start_btn").active = false;
                this.rootNode.getChildByName("split_prize_btn").active = false;
                this.rootNode.getChildByName("pool_time").setPosition(v3(362, -211));
                this.rootNode.getChildByName("btn_close").active = false;
                this.startTime = e.start_cd;
                let i = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_gameover.over_tips5"), this.startTime);
                if (t.gameRummyType == RUMMY_GAME_TYPE.DEALS || t.gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL) {
                    this.cround = ToolUtils.isSafeNumber(this.msg.cround);
                    let e = this.cround;
                    i = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_gameover.over_tips7"), e, this.startTime);
                }
                this.rootNode.getChildByName("pool_time").active = true;
                this.rootNode.getChildByName("ready_tips").active = false;
                let s = 28;
                0 != this._upType && 2 != this._upType || 0 != i18nMgr.shared().language && 1 != i18nMgr.shared().language && (s = 20);
                this.rootNode.getChildByName("pool_time").getComponent(RichText).string = i;
                this.rootNode.getChildByName("pool_time").getComponent(RichText).fontSize = s;
                this.updateReadyTipPos();
                let o = this;
                this.time_action = TweenTool.myschedule(RummyDataManager.shared().sceneNode, 1, (() => {
                    o.updateRecodeTime();
                }));
            }
        }
        else if (t.gameRummyType == RUMMY_GAME_TYPE.PRIVATE && undefined !== e.start_cd) {
            this.time_action && (TweenTool.stopAction(this.time_action), this.time_action = null);
            this.rootNode.getChildByName("btn_close").active = true;
            this.isShowStartBtn = false;
            this.isShowExitBtn = false;
            this.isShowOkBtn = false;
            let e = this.rootNode.getChildByName("start_btn"), t = this.rootNode.getChildByName("exit_btn");
            e.active = this.isShowStartBtn;
            t.active = this.isShowExitBtn;
            let i = this.rootNode.getChildByName("ready_tips"), s = this.rootNode.getChildByName("pool_time");
            i.active = false;
            s.active = false;
            this.rootNode.getChildByName("close_btn").active = true;
            this.updateReadyTipPos();
            PushCenter.shared().addListener(PushEvent.GameOverDowntimeTip, (e => {
                if (e.tid_key == this.tid_key) {
                    this.showPrivateTips(e.typeNum, e.TextStr);
                    let t = e.typeNum;
                    4 != t && 5 != t && 6 != t && 7 != t && 15 != t && 16 != t && 17 != t && 18 != t || (i.getComponent(Label).string = e.TextStr, i.active = true);
                }
            }), this);
        }
    }
    updateRecodeTime() {
        if (ToolUtils.isObjValid(this.rootNode)) {
            if (this.startTime = this.startTime - 1, this.startTime < 1) {
                this.stopPoolRummyCountDown();
                ToolUtils.isObjValid(this.node) && this.node.destroy();
                this._callback && this._callback("cleanGameEndPointer");
            }
            else if (RummyDataManager.shared().rummyInfos.has(this.tid_key)) {
                let e = "";
                e = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_gameover.over_tips5"), this.startTime);
                let t = this.cround;
                RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType != RUMMY_GAME_TYPE.DEALS && RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType != RUMMY_GAME_TYPE.PRI_DEAL || (e = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_gameover.over_tips7"), t, this.startTime));
                let i = 28;
                0 != this._upType && 2 != this._upType || 0 != i18nMgr.shared().language && 1 != i18nMgr.shared().language && (i = 20);
                this.rootNode.getChildByName("pool_time").getComponent(RichText).string = e;
                this.rootNode.getChildByName("pool_time").getComponent(RichText).fontSize = i;
                this.rootNode.getChildByName("ready_tips").active = false;
            }
        }
    }
    onClickBtnEvent(e, t) {
        if (SoundManager.shared().playFx("click"), sys.now() - this._lastClick < 500) {
            return;
        }
        this._lastClick = sys.now();
        this._bClickBtn = true;
        let i = RummyDataManager.shared().rummyInfos.get(this.tid_key);
        if ("recode_ok" === t) {
            return ToolUtils.isObjValid(this.node) && this.node.destroy(), void (this._callback && this._callback("cleanGameEndPointer"));
        }
        if ("treasure_hunt" !== t) {
            if ("close_treasurehunt_play" === t) {
                return this.bottomBtns.getChildByName("treasurehunt_node").active = false, void (this.hasClickCloseTreasure_Play = true);
            }
            if ("close_treasurehunt" === t) {
                return this.bottomBtns.getChildByName("treasurehunt_node").active = false, void (this.hasClickCloseTreasure_Banner = true);
            }
            if ("novices_arrow" === t) {
                return this.hideNovicesBanner(), void Utils.shared().showNovicesTaskView(false, { vid: i.vid });
            }
            if ("gameover_switch" === t && (this.rootNode.getChildByName("switch_btn").getComponent(Button).interactable = false, TweenTool.delayAct(this.node, (() => {
                ToolUtils.isObjValid(this.node) && (this.rootNode.getChildByName("switch_btn").getComponent(Button).interactable = true);
            }), 1, true)), i.gameRummyType != RUMMY_GAME_TYPE.POINTS && i.gameRummyType != RUMMY_GAME_TYPE.MULTIPLE || "start" !== t || 1 != this._showNewPlayerGuide) {
                if ("share" !== t) {
                    if ("up" == t) {
                        if (2 == this._upType) {
                            return void (this._callback && this._callback("practice_to_cash"));
                        }
                        this._hasUpBtn && 0 == this._upType && 0 == i.crashModel && this._bReportSwitch && HttpManager.shared().doReportClick({ module: PhpReportDefined.module.game_over_high, scene: PhpReportDefined.scece.cash_room_gameover, event: PhpReportDefined.game_over_high_event.click_play_with_cash, vid: i.vid });
                    }
                    if ("treasurehunt_upbtn" != t) {
                        if ("up_tocash_close" == t) {
                            return this.hasHideCashTip = true, RummyDataManager.shared().hasCloseUpToCashTips = true, void (this.rootNode.getChildByName("up_tocash").active = false);
                        }
                        this._callback && this._callback(t);
                        "start" === t && (this._hasUpBtn && 0 == this._upType && 0 == i.crashModel && this._bReportSwitch && HttpManager.shared().doReportClick({ module: PhpReportDefined.module.game_over_high, scene: PhpReportDefined.scece.cash_room_gameover, event: PhpReportDefined.game_over_high_event.click_start, vid: i.vid }), this.dealStartClickLogic());
                        "end_ready" == t && (this._callback && this._callback("private_gameOver_self_closed"), this.isShowEndView(false));
                    }
                    else {
                        this._callback && this._callback("treasurehunt_upbtn");
                    }
                }
                else if (User.shared().shareMainInfo) {
                    let e = ToolUtils.isSafeString(User.shared().shareMainInfo.cash_share_text), t = ToolUtils.isSafeString(User.shared().shareMainInfo.share_url);
                    sys.now();
                    if (0 === TransferPlatform.shared().checkPackageInstalled("com.whatsapp")) {
                        Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text48"), 2);
                        let i = e + " " + t;
                        return TransferPlatform.shared().shareWebPage(ToolUtils.isSafeString(i)), void HttpManager.shared().doReportClick({ module: PhpReportDefined.module.share, scene: PhpReportDefined.scece.share_gameover, event: PhpReportDefined.share_event.click_share });
                    }
                    let i = e + " " + t;
                    ToolUtils.isSafeString(i).length > 0 && (User.shared().shareImageAndTextToThirdApp(1, "", i), HttpManager.shared().doReportClick({ module: PhpReportDefined.module.share, scene: PhpReportDefined.scece.share_gameover, event: PhpReportDefined.share_event.click_share }));
                }
            }
            else {
                this._callback && this._callback("points_end_tip_guide");
            }
        }
        else {
            this._callback && this._callback("gameover_treasure_hunt");
        }
    }
    dealStartClickLogic(e = true) {
        let t = RummyDataManager.shared().rummyInfos.get(this.tid_key).entry_fee;
        if (0 == RummyDataManager.shared().rummyInfos.get(this.tid_key).crashModel) {
            if (User.shared().data.money < t) {
                return;
            }
        }
        else if (1 == RummyDataManager.shared().rummyInfos.get(this.tid_key).crashModel && User.shared().data.money_exe < t) {
            return;
        }
        RummyDataManager.shared().rummyInfos.get(this.tid_key).stayInTable || !e && this._isReissue || (ToolUtils.isObjValid(this.node) && this.node.destroy(), this._callback && this._callback("cleanGameEndPointer"));
    }
    sortPlayers(e) {
        try {
            let t = 0;
            if (null != e.record_status && (t = e.record_status), 1 == this.fromtype && 1 == t) {
                let t = [], i = -1, s = e.players.length;
                if (e.players) {
                    for (let t = 0; t < s; t++) {
                        if (e.players[t].uid == User.shared().data.uid) {
                            i = t;
                            break;
                        }
                    }
                    if (i < 0) {
                        return;
                    }
                    t.push(e.players[i]);
                    for (let o = i + 1; o < s; o++) {
                        t.push(e.players[o]);
                    }
                    for (let s = 0; s < i; s++) {
                        t.push(e.players[s]);
                    }
                    e.players = [];
                    e.players = t;
                }
                this.msg = null;
                this.msg = e;
            }
            else {
                let t = [], i = [], s = -1, o = -1, a = RummyDataManager.shared().rummyInfos.get(this.tid_key).clientSeatId, h = e.players.length;
                if (e.players) {
                    if (sys.isObjectValid(e.is_tie) && 1 == e.is_tie) {
                        for (let i = 0; i < h; i++) {
                            let s = e.players[i];
                            if (s.uid == User.shared().data.uid && 1 != s.iswin) {
                                t.push(s);
                                break;
                            }
                        }
                    }
                    for (let r = 0; r < h; r++) {
                        let h = e.players[r];
                        h.uid == User.shared().data.uid ? (a = h.seatid, o = r, 1 == h.iswin ? (s = h.seatid, t.push(h)) : s >= 0 && t.push(h)) : 1 == h.iswin ? (s = h.seatid, t.push(h), o >= 0 && t.push(e.players[o])) : i.push(h);
                    }
                    if (i.length > 0) {
                        let e = this;
                        i.sort((function (t, i) {
                            return e.getPosBySeatid(t.seatid, a) - e.getPosBySeatid(i.seatid, a);
                        }));
                        let s = [];
                        for (let e = 0, o = i.length; e < o; e++) {
                            1 !== i[e].status && 5 !== i[e].status ? t.push(i[e]) : s.push(i[e]);
                        }
                        if (s.length > 0) {
                            for (let e = 0, i = s.length; e < i; e++) {
                                t.push(s[e]);
                            }
                        }
                    }
                    e.players = [];
                    e.players = t;
                }
                this.msg = null;
                this.msg = e;
            }
            this.refreshView();
        }
        catch (e) {
            TLog.printError("trycatch RummyGameOverAlert sortPlayers", e);
        }
    }
    getPosBySeatid(e, t) {
        let i = e - t;
        return i >= 0 ? i : i + RummyDataManager.shared().rummyInfos.get(this.tid_key).pnum;
    }
    executePreFrame(e, t) {
        return new Promise(((i, s) => {
            let o = e, a = () => {
                let e = (new Date).getTime();
                for (let s = o.next();; s = o.next()) {
                    if (null == s || s.done) {
                        return void i();
                    }
                    if ((new Date).getTime() - e > t) {
                        return void this.scheduleOnce((() => {
                            a();
                        }), game.frameTime / 1000 * 2);
                    }
                }
            };
            a();
        }));
    }
    refreshView() {
        try {
            let e = this.msg, t = RummyDataManager.shared().rummyInfos.get(this.tid_key), i = false;
            if (this.hasShowRank = false, 1 == t.is_multiple || 1 == this.msg.is_multiple) {
                let e = t.finish_multiple;
                sys.isObjectValid(this.msg.finish_multiple) && (e = this.msg.finish_multiple);
                let s = t.round_per_game;
                sys.isObjectValid(this.msg.finish_turn) && (s = this.msg.finish_turn);
                i18nMgr.shared().changeLabelLanguage(this.rootNode.getChildByName("multi_into").getChildByName("wz").getComponent(RichText), "rummy_main.multi_gameOverTip", false, s, e);
                i = true;
            }
            i && (this.rootNode.getChildByName("multi_into").active = true, this.rootNode.getChildByName("title_node").setPosition(v3(0, -53)), this.rootNode.getChildByName("playerView").setPosition(v3(0, 178.541)), this.rootNode.getChildByName("playerView").getComponent(UITransform).setContentSize(size(1190, 340)), this.rootNode.getChildByName("playerView").getChildByName("view").getComponent(UITransform).setContentSize(size(1190, 340)));
            this._isWatching = ToolUtils.isSafeNumber(e.isWatching);
            this.tipsMask.active = false;
            let s = 0, o = e.players.length;
            for (let t = 0; t < o; t++) {
                1 == e.players[t].isfold && (s += 1);
            }
            this.rootNode.getChildByName("laizibiaoshi").getComponent(Sprite).spriteFrame = this.laizi_imgs[0];
            let a = e.lz_card, h = e.flop_lz_card, r = 0, n = false;
            if (null != e.record_status && (r = e.record_status), 1 == this.fromtype && 0 != r && (n = true), 1 == t.is_bump && n) {
                ToolUtils.isObjValid(this.rootNode.getChildByName("JokerCard")) && this.rootNode.getChildByName("JokerCard").removeAllChildren();
            }
            else {
                let e = this.rootNode.getChildByName("JokerCard").getChildByName("laiCardNode");
                if (sys.isObjectValid(e)) {
                    let t = e.getComponent("RummyCard");
                    t.init(h, false, 1);
                    t.openCard();
                }
                else {
                    let e = instantiate(this.cardPrefab);
                    e.name = "laiCardNode";
                    let t = e.getComponent("RummyCard");
                    t.init(h, false, 1);
                    t.openCard();
                    e.setPosition(v3(0, 44));
                    this.rootNode.getChildByName("JokerCard").addChild(e);
                }
            }
            let g = 20, y = 54, p = 8, B = y + p - g, b = -200, k = -54, R = 516, P = -84, O = 12;
            this.laizicard = a;
            this.itemViewDate = [];
            let I = 303, E = "", j = null, A = [v3(0, 0), v3(0, -107), v3(0, -214), v3(0, -321), v3(0, -428), v3(0, -535)];
            if (e.players) {
                let i = "", a = "", h = this.rootNode.getChildByName("playerView").getChildByName("view").getChildByName("content");
                h.getComponent(UITransform).contentSize = size(1190, 2 == o ? 212 : 212 + 107 * (o - 2));
                let r = e.showcard || 0;
                for (let n = 0; n < o; n++) {
                    const f = e.players[n];
                    let D = f.uid, z = f.avatar, x = f.name, K = f.avatar_url, H = f.iswin, G = f.gamesocre, W = f.winscore, $ = f.isfold, q = (f.club_level, false);
                    null != f.ready ? q = 1 == f.ready : null != f.zhunbei && (q = 1 == f.zhunbei);
                    let J = 0;
                    null != f.record_status && (J = f.record_status);
                    let Q = 0;
                    sys.isObjectValid(f.avatar_frame_id) && (Q = f.avatar_frame_id);
                    let X = h.getChildByName(ToolUtils.format("${0}", n));
                    if (null == X && (X = instantiate(this.mobanView), X.name = ToolUtils.format("${0}", n), h.addChild(X)), X.setPosition(A[n]), X.active = true, this.itemViewDate[n] = {}, this.itemViewDate[n].item = X, this.itemViewDate[n].players = f, t.gameRummyType != RUMMY_GAME_TYPE.POOL && t.gameRummyType != RUMMY_GAME_TYPE.PRI_POOL && t.gameRummyType != RUMMY_GAME_TYPE.DEALS && t.gameRummyType != RUMMY_GAME_TYPE.PRI_DEAL || (W = f.score, G = f.winscore), null == W && (W = ""), null == G && (G = ""), Utils.shared().updateHeadImg(X.getChildByName("head_mask").getChildByName("head"), z, K, size(70, 70)), sys.isObjectValid(User.shared().data.club) && 1 == User.shared().data.club.show_room_avatar_frame) {
                        let e = Q;
                        X.getChildByName("club_kuang").active = e > 0;
                        e > 0 && e <= 9 && Utils.shared().setImage(X.getChildByName("club_kuang"), ToolUtils.format("club_headkuang${0}", e), this.clubKuangAtlas);
                    }
                    x = ToolUtils.GetShortName2(x, 8, true);
                    Utils.shared().setStr(X.getChildByName("name"), x);
                    null != f.lose_half && 1 == f.lose_half ? (X.getChildByName("help_btn").active = true, X.getChildByName("final_score").active = true, sys.isObjectValid(f.final_score) && Utils.shared().setStr(X.getChildByName("final_score"), f.final_score), ToolUtils.parse_double("" + G, -2).length > 3 && (X.getChildByName("final_score").setPosition(v3(291, -54)), I = 291)) : (X.getChildByName("help_btn").active = false, X.getChildByName("final_score").active = false);
                    let Z = "tip" + n;
                    X.getChildByName("help_btn").getComponent(Button).clickEvents[0].customEventData = Z;
                    E = "" + G;
                    1 == f.isfinish && (0 == this.fromtype || 1 == this.fromtype && 0 == J) ? t.gameRummyType == RUMMY_GAME_TYPE.DEALS || t.gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL ? 1 === ToolUtils.isSafeNumber(e.all_finish) || this.bIsEnd || 1 != H ? Utils.shared().setStr(X.getChildByName("score"), "" + G) : Utils.shared().setStr(X.getChildByName("score"), "") : (t.gameRummyType == RUMMY_GAME_TYPE.MULTIPLE && 1 == t.is_multiple && sys.isObjectValid(f.src_score) ? E = null != f.lose_half && 1 == f.lose_half || 1 == H || 2 != f.status && 3 != f.status || !sys.isObjectValid(f.src_score) ? "" + ToolUtils.parse_double("" + G, -2) : f.src_score + "/" + ToolUtils.parse_double("" + G, -2) : 1 != t.is_double && 1 != this.msg.is_double || (E = "" + G), Utils.shared().setStr(X.getChildByName("score"), E)) : Utils.shared().setStr(X.getChildByName("score"), "");
                    X.getChildByName("win_bg").active = false;
                    let ee = false;
                    if (D === User.shared().data.uid) {
                        if (X.getChildByName("me_img").active = true, 0 == t.crashModel && 0 == H && sys.isObjectValid(f.tf_bonus) && f.tf_bonus > 0 && t.gameRummyType != RUMMY_GAME_TYPE.POOL && t.gameRummyType != RUMMY_GAME_TYPE.PRI_POOL && t.gameRummyType != RUMMY_GAME_TYPE.DEALS && t.gameRummyType != RUMMY_GAME_TYPE.PRI_DEAL) {
                            let e = "bonus_tips_" + n;
                            if (X.getChildByName("bonus_btn").getComponent(Button).clickEvents[0].customEventData = e, this._showBonusTipsStr = e, sys.isObjectValid(f.bonus_incr_rate) && f.bonus_incr_rate > 0) {
                                ee = true;
                                let e = 100 * Number(ToolUtils.parse_double(f.bonus_incr_rate));
                                X.getChildByName("bonus_btn").getChildByName("Label").getComponent(Label).string = `+${e}%`;
                            }
                        }
                        1 == H && sys.isObjectValid(f.rank_info) && (j = f.rank_info, this.hasShowRank = true);
                    }
                    else {
                        X.getChildByName("me_img").active = false;
                    }
                    X.getChildByName("bonus_btn").active = ee;
                    1 == H ? (X.getChildByName("bg").active = false, X.getChildByName("win_bg").active = true) : (X.getChildByName("bg").active = true, X.getChildByName("win_bg").active = false);
                    let te = X.getChildByName("win_money");
                    if (i = 1 == t.crashModel ? "" + ToolUtils.parse_ChipNum2(W) : t.gameRummyType === RUMMY_GAME_TYPE.POINTS || t.gameRummyType === RUMMY_GAME_TYPE.MULTIPLE || t.gameRummyType === RUMMY_GAME_TYPE.PRIVATE ? ToolUtils.parse_double("" + W) : "" + W, t.gameRummyType == RUMMY_GAME_TYPE.PRIVATE || t.gameRummyType == RUMMY_GAME_TYPE.PRI_POOL || t.gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL) {
                        let e = X.getChildByName("head_mask").getChildByName("head").getChildByName("ready");
                        e && (e.active = q);
                    }
                    let ie = X.getChildByName("head_mask").getChildByName("head").getChildByName("state");
                    ie && (ie.active = false);
                    let se = X.getChildByName("status"), oe = X.getChildByName("cash_layout"), ae = X.getChildByName("bonus_layout");
                    if (se.getChildByName("flag").active = false, 1 == f.isfinish && (0 == this.fromtype || 1 == this.fromtype && 0 == J)) {
                        if (se.active = true, 1 == H) {
                            te.setPosition(v3(513, -54));
                            oe.active = false;
                            ae.active = false;
                            se.getChildByName("flag").active = true;
                            se.getChildByName("flag").getComponent(Label).string = "WINNER";
                            se.getChildByName("flag").setPosition(v3(0, -5));
                            X.getChildByName("link_win").active = false;
                            X.getChildByName("winfire_anim").active = false;
                            te.getChildByName("line").active = false;
                            se.getComponent(Sprite).spriteFrame = this.bottom_card_img[11];
                            se.getComponent(Sprite).color = color(255, 255, 255);
                            let s = true;
                            if (t.gameRummyType != RUMMY_GAME_TYPE.DEALS && t.gameRummyType != RUMMY_GAME_TYPE.PRI_DEAL || this.bIsEnd || (s = 1 === ToolUtils.isSafeNumber(e.all_finish)), s) {
                                if (String("" + i).length > 0) {
                                    let e = false;
                                    t.gameRummyType != RUMMY_GAME_TYPE.POINTS && t.gameRummyType != RUMMY_GAME_TYPE.PRIVATE && t.gameRummyType != RUMMY_GAME_TYPE.MULTIPLE || this.msg.cmd === RummyCmd.SM_FINISH_STATUS_INFO && 0 == Number(i) && (i = "");
                                    a = i;
                                    e || Utils.shared().setStr(te, a);
                                }
                                else {
                                    t.gameRummyType == RUMMY_GAME_TYPE.POOL || t.gameRummyType == RUMMY_GAME_TYPE.PRI_POOL ? Utils.shared().setStr(te, "0") : Utils.shared().setStr(te, "");
                                }
                                te.getComponent(Label).color = color(0, 140, 22);
                                t.gameRummyType != RUMMY_GAME_TYPE.POINTS && t.gameRummyType != RUMMY_GAME_TYPE.MULTIPLE || sys.isObjectValid(f.win_count) && f.win_count >= 2 && (se.getComponent(Sprite).spriteFrame = this.win_flags[1], X.getChildByName("link_win").active ? (se.getChildByName("flag").getComponent(Label).string = "WINS", se.getChildByName("flag").setPosition(v3(0, -30))) : (X.getChildByName("link_win").active = true, X.getChildByName("link_win").getComponent(Label).string = String(f.win_count), se.getChildByName("flag").getComponent(Label).string = "WINS", se.getChildByName("flag").setPosition(v3(0, -30)), tween(X.getChildByName("head_mask")).to(0.13, { scale: new Vec3(1.3, 1.3, 1.3) }).to(0.13, { scale: new Vec3(1, 1, 1) }).call((() => {
                                    X.getChildByName("winfire_anim").active = true;
                                    let e = X.getChildByName("winfire_anim").getComponent(sp.Skeleton);
                                    e.clearTracks();
                                    e.setToSetupPose();
                                    e.setAnimation(0, "animation", true);
                                    this.playEffectByName("rummy_linkwin_headfire");
                                })).start()));
                            }
                            else {
                                Utils.shared().setStr(te, "");
                            }
                        }
                        else {
                            if (sys.isObjectValid(f.tf_bonus) && f.tf_bonus > 0) {
                                te.setPosition(v3(513, -29));
                                te.getChildByName("line").active = true;
                                te.getComponent(Label).updateRenderData(true);
                                oe.active = true;
                                ae.active = true;
                                let e = Number(ToolUtils.parse_double(String(f.tf_bonus)));
                                ae.getChildByName("num").getComponent(Label).string = ToolUtils.parse_double(String(f.tf_bonus));
                                let t = Math.abs(f.winscore + e);
                                oe.getChildByName("num").getComponent(Label).string = ToolUtils.parse_double(String(t));
                            }
                            else {
                                te.setPosition(v3(513, -54));
                                oe.active = false;
                                ae.active = false;
                                te.getChildByName("line").active = false;
                            }
                            Utils.shared().setStr(te, i);
                            te.getComponent(Label).color = color(71, 71, 71);
                            1 == f.status ? (se.getComponent(Sprite).spriteFrame = this.bottom_card_img[7], se.getComponent(Sprite).color = color(102, 102, 102)) : 3 == f.status ? (se.getComponent(Sprite).spriteFrame = this.bottom_card_img[10], se.getComponent(Sprite).color = color(102, 102, 102)) : 5 == f.status ? (se.getComponent(Sprite).spriteFrame = this.bottom_card_img[9], se.getComponent(Sprite).color = color(102, 102, 102)) : (se.getComponent(Sprite).spriteFrame = this.bottom_card_img[8], se.getComponent(Sprite).color = color(102, 102, 102));
                        }
                    }
                    else {
                        Utils.shared().setStr(te, "");
                        1 == this.fromtype ? se.active = false : (se.getComponent(Sprite).spriteFrame = this.bottom_card_img[8], se.getComponent(Sprite).color = color(102, 102, 102), se.active = true);
                    }
                    sys.isObjectValid(e.is_tie) && 1 == e.is_tie && (se.active = true, 0 == i18nMgr.shared().language ? (se.getComponent(Sprite).spriteFrame = this.bottom_card_img[12], se.getComponent(Sprite).color = color(102, 102, 102)) : 1 == i18nMgr.shared().language ? (se.getComponent(Sprite).spriteFrame = this.bottom_card_img[13], se.getComponent(Sprite).color = color(255, 255, 255)) : 2 == i18nMgr.shared().language ? (se.getComponent(Sprite).spriteFrame = this.bottom_card_img[14], se.getComponent(Sprite).color = color(255, 255, 255)) : 3 == i18nMgr.shared().language && (se.getComponent(Sprite).spriteFrame = this.bottom_card_img[15], se.getComponent(Sprite).color = color(255, 255, 255)));
                    let he = ToolUtils.shouldHideSettlementHand(f, r, s >= o - 1);
                    let re = X.getChildByName("cardNodes");
                    if (re.destroyAllChildren(), 1 == f.isfinish && (0 == this.fromtype || 1 == this.fromtype && 0 == J)) {
                        if (X.getChildByName("waiting").active = false, g = 27, he) {
                            let e, t;
                            for (let i = 0; i < 13; i++) {
                                e = instantiate(this.cardPrefab);
                                e.name = ToolUtils.format("card_${0}", i);
                                re.addChild(e);
                                t = e.getComponent("RummyCard");
                                t.init(1, true, 1);
                                e.setPosition(v3(b + g * i, k));
                            }
                        }
                        else if (sys.isObjectValid(f.cardinfos) && f.cardinfos.length > 0) {
                            let e, t, i, s, o, a, h, r, n, l, d, _, N, C, w, S = 0, V = 0, I = f.cardinfos.length;
                            for (let t = 0; t < I; t++) {
                                e = f.cardinfos[t];
                                null != e.cards && (V += e.cards.length);
                            }
                            0 == V && (V = 13);
                            for (let t = 0; t < I; t++) {
                                if (e = f.cardinfos[t], null != e.cards) {
                                    a = I;
                                    h = (a - 1) * p;
                                    r = a * y;
                                    n = V - a;
                                    g = (R - h - r) / (1 * n);
                                    B = y + p - g;
                                    for (let i = 0, s = e.cards.length; i < s; i++) {
                                        d = e.cards[i];
                                        _ = instantiate(this.cardPrefab);
                                        _.name = ToolUtils.format("card_${0}_${1}", t, i);
                                        re.addChild(_);
                                        N = _.getComponent("RummyCard");
                                        N.init(d, false, 1);
                                        N.openCard();
                                        N.showJsLaiziFlag(this.isShowLaiziColor(d));
                                        l = b + g * S + B * t;
                                        _.setPosition(v3(l, k));
                                        S += 1;
                                    }
                                }
                            }
                            S = 0;
                            for (let d = 0; d < I; d++) {
                                if (e = f.cardinfos[d], null != e.cards) {
                                    t = e.color;
                                    i = 0;
                                    s = e.cards.length;
                                    o = Math.floor(s / 2);
                                    a = I;
                                    h = (a - 1) * p;
                                    r = a * y;
                                    n = V - a;
                                    g = (R - h - r) / (1 * n);
                                    B = y + p - g;
                                    for (let t = 0, s = e.cards.length; t < s; t++) {
                                        l = b + g * S + B * d;
                                        S += 1;
                                        t == o && (i = l);
                                    }
                                    C = instantiate(X.getChildByName("zhegai"));
                                    C.name = ToolUtils.format("zhegai_${0}", d);
                                    re.addChild(C);
                                    0 == t || 1 == t ? C.getComponent(Sprite).spriteFrame = this.bottom_card_img[0] : 2 == t ? C.getComponent(Sprite).spriteFrame = this.bottom_card_img[2] : 3 == t && (C.getComponent(Sprite).spriteFrame = this.bottom_card_img[1]);
                                    0 == Math.floor(s % 2) && (i -= g / 2);
                                    w = (s - 1) * g + y;
                                    C.getComponent(UITransform).setContentSize(size(w, O));
                                    C.setSiblingIndex(100 + d);
                                    C.setPosition(v3(i, P));
                                    C.active = true;
                                }
                            }
                        }
                    }
                    else {
                        1 == this.fromtype && 1 == J ? i18nMgr.shared().changeLabelLanguage(X.getChildByName("waiting").getComponent(Label), "rummy_gameover.playing") : i18nMgr.shared().changeLabelLanguage(X.getChildByName("waiting").getComponent(Label), "rummy_gameover.waiting");
                        X.getChildByName("waiting").active = true;
                    }
                    if ((1 == t.is_double || 1 == this.msg.is_double) && sys.isObjectValid(f.double_type)) {
                        let e = X.getChildByName("double_state");
                        e && (e.active = f.double_type > 0, e.getChildByName("Label").getComponent(Label).string = "+" + f.double_type);
                    }
                }
            }
            let D = this.rootNode.getChildByName("ready_tips"), z = 0;
            null != e.record_status && (z = e.record_status);
            let x = this.rootNode.getChildByName("pool_time");
            if (D) {
                if (i18nMgr.shared().changeLabelFontSize(D.getComponent(Label), 28), t.gameRummyType == RUMMY_GAME_TYPE.PRIVATE) {
                    if (this.bIsEnd) {
                        D.active = true;
                        this.showPrivateTipsText(t.gameTipsTextType);
                    }
                    else {
                        D.active = true;
                        i18nMgr.shared().changeLabelLanguage(D.getComponent(Label), "rummy_gameover.over_tips1");
                        let e = 1 == i18nMgr.shared().language ? 26 : 28;
                        i18nMgr.shared().changeLabelFontSize(D.getComponent(Label), e);
                        2 == i18nMgr.shared().language && (e = 22, i18nMgr.shared().changeLabelFontSize(D.getComponent(Label), e));
                    }
                }
                else if (1 == this.fromtype) {
                    1 == z ? (i18nMgr.shared().changeLabelLanguage(D.getComponent(Label), "rummy_gameover.over_tips10"), D.active = true) : 2 == z ? (i18nMgr.shared().changeLabelLanguage(D.getComponent(Label), "rummy_gameover.over_tips9"), D.active = !x.active, D.active) : D.active = false;
                }
                else if (this.bIsEnd) {
                    D.active = false;
                }
                else {
                    D.getComponent(Label).string = "Please wait for all the players to declare.";
                    i18nMgr.shared().changeLabelLanguage(D.getComponent(Label), "rummy_gameover.over_tips1");
                    let t = 1 == i18nMgr.shared().language ? 26 : 28;
                    i18nMgr.shared().changeLabelFontSize(D.getComponent(Label), t);
                    0 === ToolUtils.isSafeNumber(e.all_end) ? (D.active = !x.active, D.active) : D.active = false;
                    2 == i18nMgr.shared().language && (t = 22, i18nMgr.shared().changeLabelFontSize(D.getComponent(Label), t));
                }
            }
            if (1 != this.fromtype && (t.gameRummyType == RUMMY_GAME_TYPE.PRIVATE || t.gameRummyType == RUMMY_GAME_TYPE.PRI_POOL && 1 == this.all_end || t.gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL && 1 == this.all_end)) {
                let e = t.clientSeatId;
                if (1 != t.playerModels[e].ready) {
                    2 !== this.settle_type && this.show_ready_btn();
                    this.rootNode.getChildByName("close_btn").active = false;
                }
                else {
                    this.hide_ready_btn();
                    this.rootNode.getChildByName("close_btn").active = true;
                }
            }
            this.updateReadyTipPos();
            1 == this.fromtype && (0 == z && (D.active = false), this.rootNode.getChildByName("pool_time").active = false);
        }
        catch (e) {
            TLog.printError("trycatch RummyGameOverAlert refreshView ", e);
        }
    }
    isShowLaiziColor(e) {
        if (78 == this.laizicard || 79 == this.laizicard) {
            if (78 == e || 79 == e || 1 == e || 17 == e || 33 == e || 49 == e) {
                return true;
            }
        }
        else {
            if (78 == e || 79 == e) {
                return true;
            }
            if (this.laizicard % 16 == e % 16) {
                return true;
            }
        }
        return false;
    }
    hide_ready_btn() {
        this.rootNode.getChildByName("ready_btn").active = false;
        this.updateReadyTipPos();
    }
    show_ready_btn() {
        if (!this.isShowStartBtn) {
            if (1 != this.fromtype) {
                this.rootNode.getChildByName("ready_btn").active = true;
            }
            this.updateReadyTipPos();
        }
    }
    checkEndFlag() {
        return this.bIsEnd;
    }
    playEffectByName(e, t) {
        this.tid_key === User.shared().curTid_key && SoundManager.shared().playFx(e, null, t);
    }
    show_up_btn(e, t) {
        let i = CommDefine.shadowcolor.orange, s = CommDefine.shadowcolor.green, o = CommDefine.shadowcolor.blue, a = this.rootNode.getChildByName("up_btn"), h = this.rootNode.getChildByName("start_btn");
        if (a) {
            if (a.active = true, this._upType = t, sys.isObjectValid(e.base_money) && (a.getChildByName("root").getChildByName("num").getComponent(Label).string = 1 == t ? String(e.base_money) : "₹" + String(e.base_money)), 0 == t) {
                this.rootNode.getChildByName("start_btn").setPosition(v3(270, -218));
                let e = this.rootNode.getChildByName("ready_tips");
                e.setPosition(v3(145, -211));
                e.getComponent(Label).overflow = Overflow.SHRINK;
                e.getComponent(UITransform).contentSize = size(400, 50.4);
                ToolUtils.isObjValid(this.rootNode.getChildByName("up_tocash")) && (this.rootNode.getChildByName("up_tocash").active = false);
                ToolUtils.isObjValid(this.rootNode.getChildByName("up_tip")) && (this.rootNode.getChildByName("up_tip").active = true);
                1 == i18nMgr.shared().language && (a.getChildByName("root").getChildByName("wz").active = false, a.getChildByName("root").getChildByName("wz1").active = true);
                a.getComponent(Sprite).spriteFrame = this.btn_imgs[0];
                h.getComponent(Sprite).spriteFrame = this.btn_imgs[2];
                Utils.updateLabelMaterial(h.getChildByName("wz"), CommDefine.gradient.btn_blue);
                h.getChildByName("wz").getComponent(LabelShadow).color = o;
                Utils.updateLabelMaterial(a.getChildByName("root").getChildByName("wz"), CommDefine.gradient.btn_green);
                Utils.updateLabelMaterial(a.getChildByName("root").getChildByName("num"), CommDefine.gradient.btn_green);
                Utils.updateLabelMaterial(a.getChildByName("root").getChildByName("wz1"), CommDefine.gradient.btn_green);
                a.getChildByName("root").getChildByName("wz").getComponent(LabelShadow).color = s;
                a.getChildByName("root").getChildByName("num").getComponent(LabelShadow).color = s;
                a.getChildByName("root").getChildByName("wz1").getComponent(LabelShadow).color = s;
                this._hasUpBtn = true;
            }
            else if (1 == i18nMgr.shared().language && (a.getChildByName("root").getChildByName("wz").active = false, a.getChildByName("root").getChildByName("wz1").active = true), ToolUtils.isObjValid(this.rootNode.getChildByName("up_tip")) && (this.rootNode.getChildByName("up_tip").active = false), ToolUtils.isObjValid(this.rootNode.getChildByName("up_tip_practice")) && (this.rootNode.getChildByName("up_tip_practice").active = 1 == t), 2 == t) {
                if (ToolUtils.isObjValid(this.rootNode.getChildByName("up_tocash"))) {
                    if (this.hasHideCashTip) {
                        this.rootNode.getChildByName("up_tocash").active = false;
                    }
                    else if (RummyDataManager.shared().hasCloseUpToCashTips) {
                        this.rootNode.getChildByName("up_tocash").active = false;
                    }
                    else if (RummyDataManager.shared().enterPracticeCount + 1 <= RummyDataManager.shared().rummyInfos.get(this.tid_key).tf_entry_tips_times) {
                        let e = sys.localStorage.getItem("tf_show_tips_count_" + User.shared().data.uid);
                        null == e || Number.isNaN(Number(e)) ? e = 1 : (e = Number(e), e += 1);
                        e <= RummyDataManager.shared().rummyInfos.get(this.tid_key).tf_max_tips_times ? (RummyDataManager.shared().enterPracticeCount += 1, ToolUtils.saveData("tf_show_tips_count_" + User.shared().data.uid, "" + e), this.rootNode.getChildByName("up_tocash").active = true) : this.rootNode.getChildByName("up_tocash").active = false;
                    }
                    else {
                        this.rootNode.getChildByName("up_tocash").active = false;
                    }
                }
                let e = this.rootNode.getChildByName("ready_tips");
                e.setPosition(v3(-70, -211));
                e.getComponent(Label).overflow = Overflow.SHRINK;
                e.getComponent(UITransform).contentSize = size(400, 50.4);
                this.rootNode.getChildByName("pool_time").setPosition(v3(-70, -211));
                this.rootNode.getChildByName("start_btn").setPosition(v3(270, -218));
                i18nMgr.shared().changeLocalizedLabelKey(this.rootNode.getChildByName("start_btn").getChildByName("wz"), "deposit.continue");
                this.rootNode.getChildByName("start_btn").getChildByName("wz").getComponent(Label).string = i18nMgr.shared().getValueByKey("deposit.continue");
                this.rootNode.getChildByName("exit_btn").setPosition(v3(50, -218));
                a.getComponent(Sprite).spriteFrame = this.btn_imgs[1];
                Utils.updateLabelMaterial(a.getChildByName("root").getChildByName("wz"), CommDefine.gradient.btn_orange);
                Utils.updateLabelMaterial(a.getChildByName("root").getChildByName("num"), CommDefine.gradient.btn_orange);
                Utils.updateLabelMaterial(a.getChildByName("root").getChildByName("wz1"), CommDefine.gradient.btn_orange);
                a.getChildByName("root").getChildByName("wz").getComponent(LabelShadow).color = i;
                a.getChildByName("root").getChildByName("num").getComponent(LabelShadow).color = i;
                a.getChildByName("root").getChildByName("wz1").getComponent(LabelShadow).color = i;
            }
            else {
                1 == t && (ToolUtils.isObjValid(this.rootNode.getChildByName("up_tocash")) && (this.rootNode.getChildByName("up_tocash").active = false), this.rootNode.getChildByName("start_btn").active = false, this.rootNode.getChildByName("exit_btn").setPosition(v3(270, -218)), a.getComponent(Sprite).spriteFrame = this.btn_imgs[0], Utils.updateLabelMaterial(a.getChildByName("root").getChildByName("wz"), CommDefine.gradient.btn_green), Utils.updateLabelMaterial(a.getChildByName("root").getChildByName("num"), CommDefine.gradient.btn_green), Utils.updateLabelMaterial(a.getChildByName("root").getChildByName("wz1"), CommDefine.gradient.btn_green), a.getChildByName("root").getChildByName("wz").getComponent(LabelShadow).color = s, a.getChildByName("root").getChildByName("num").getComponent(LabelShadow).color = s, a.getChildByName("root").getChildByName("wz1").getComponent(LabelShadow).color = s);
            }
        }
    }
    show_btn() {
        this.rootNode.getChildByName("ready_btn").active = false;
        let e = this.rootNode.getChildByName("start_btn"), t = this.rootNode.getChildByName("exit_btn"), i = this.rootNode.getChildByName("exit_btn2"), s = this.rootNode.getChildByName("share_btn"), a = this.rootNode.getChildByName("ok_btn"), h = this.rootNode.getChildByName("switch_btn"), r = this.rootNode.getChildByName("rejoin_btn"), n = this.rootNode.getChildByName("cencel_btn"), g = this.rootNode.getChildByName("yes_btn"), y = this.rootNode.getChildByName("no_btn"), _ = this.rootNode.getChildByName("ready_tips"), p = this.rootNode.getChildByName("pool_out_tips"), u = this.rootNode.getChildByName("pool_time"), c = this.rootNode.getChildByName("guide_tips");
        if (h.active = false, this.isShowOkBtn = false, this.isShowStartBtn = false, this.isShowExitBtn = false, this.isShowPoolCencelBtn = false, this.isShowPoolRejoinBtn = false, this.isShowPoolYesBtn = false, this.isShowPoolNoBtn = false, 1 == this.fromtype ? (this.isShowOkBtn = true, this.isShowStartBtn = false, this.isShowExitBtn = false) : (this.isShowStartBtn = true, this.isShowExitBtn = true, this.isShowOkBtn = false), 1 == User.shared().isInPerformanceRoom && this.msg.cmd == RummyCmd.SM_GAME_END_BC_INFORM) {
            return e.active = false, t.active = false, a.active = false, r.active = false, n.active = false, g.active = false, y.active = false, _.active = false, c.active = false, this.rootNode.getChildByName("btn_close").active = false, void this.updateReadyTipPos();
        }
        this.rootNode.getChildByName("btn_close").active = !this.bIsEnd;
        let N = RummyDataManager.shared().rummyInfos.get(this.tid_key);
        if (N.gameRummyType == RUMMY_GAME_TYPE.POOL || N.gameRummyType == RUMMY_GAME_TYPE.PRI_POOL) {
            this.isShowExitBtn = false;
            let t = 0, i = 0;
            this.can_rejoin = 0;
            for (let e = 0, s = this.msg.players.length; e < s; e++) {
                this.msg.players[e].uid == User.shared().data.uid && (t = this.msg.players[e].can_rejoin, i = this.msg.players[e].will_disuse, this.can_rejoin = t, this.will_disuse = i, 1 == i && (this.ispoolRummyend = true));
            }
            let s = this.msg.show_split_prize;
            if (u.setPosition(v3(362, -211)), 1 === this._isWatching && (s = 0, i = 0), 1 == t) {
                N.manule_rejoin_select && this.bIsEnd && this._callback && this._callback("manula_auto_rejoin");
            }
            else if (1 == i) {
                N.gameRummyType !== RUMMY_GAME_TYPE.PRI_POOL && this.stopPoolRummyCountDown();
                N.gameRummyType == RUMMY_GAME_TYPE.POOL ? (i18nMgr.shared().changeLabelFont(p.getComponent(Label)), p.getComponent(Label).string = i18nMgr.shared().getValueByKey("rummy_main.out_tip"), this.isShowPoolYesBtn = true, this.isShowPoolNoBtn = true, this.poolRejoin = false, _.active = false, p.active = true) : (this.isShowExitBtn = true, u.setPosition(v3(145, -211)));
            }
            else if (1 == s) {
                this.rootNode.getChildByName("split_prize_btn").active = true;
                this.rootNode.getChildByName("split_prize_btn").getChildByName("wz").getComponent(Label).fontSize = 0 == i18nMgr.shared().language ? 28 : 26;
                u.setPosition(v3(145, -211));
                User.shared().curTid_key != this.tid_key && (this.playEffectByName("rummySelfTurn"), TransferPlatform.shared().openVibrate());
            }
            if (1 == this.all_end ? (1 == N.crashModel ? 2 != this._upType && (e.getChildByName("wz").getComponent(Label).string = i18nMgr.shared().getValueByKey("rummy_gameover.start")) : e.getChildByName("wz").getComponent(Label).string = i18nMgr.shared().getValueByKey("rummy_gameover.start"), this.isShowStartBtn = false, this.isShowOkBtn = true) : (1 == N.crashModel ? 2 != this._upType && (e.getChildByName("wz").getComponent(Label).string = i18nMgr.shared().getValueByKey("rummy_gameover.start")) : e.getChildByName("wz").getComponent(Label).string = i18nMgr.shared().getValueByKey("rummy_gameover.okay"), this.isShowStartBtn = false, this.isShowOkBtn = !!this.bIsEnd), this.poolRejoin) {
                this.isShowPoolCencelBtn = true;
                this.isShowPoolRejoinBtn = true;
                this.isShowOkBtn = false;
                this.isShowStartBtn = false;
                this.isShowExitBtn = false;
                r.active = this.isShowPoolRejoinBtn;
                let e = r.getChildByName("Layout").getChildByName("wz"), t = r.getChildByName("Layout").getChildByName("Layout").getChildByName("wz_money"), i = r.getChildByName("Layout").getChildByName("Layout").getChildByName("icon");
                3 == i18nMgr.shared().language && (e.getComponent(Label).fontSize = 18);
                1 == N.crashModel ? (t.getComponent(Label).string = ToolUtils.parse_ChipNum2(this.poolRejoinMoney), i.active = true) : (t.getComponent(Label).string = "₹" + this.poolRejoinMoney, i.active = false);
                u.setPosition(v3(145, -211));
            }
        }
        else if (N.gameRummyType == RUMMY_GAME_TYPE.DEALS || N.gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL) {
            this.pre_end = ToolUtils.isSafeNumber(this.msg.pre_end);
            1 == this.all_end ? (this.isShowOkBtn = true, this.isShowStartBtn = false, this.isShowExitBtn = false, u.setPosition(v3(362, -211))) : (this.isShowOkBtn = !!this.bIsEnd, this.isShowStartBtn = false, this.isShowExitBtn = false, u.setPosition(v3(362, -211)));
            1 === this.settle_type ? N.gameRummyType == RUMMY_GAME_TYPE.DEALS ? (this.isShowPoolYesBtn = true, this.isShowPoolNoBtn = true, this.poolRejoin = false, _.active = false, u.active = false, p.active = true, this.isShowOkBtn = false, this.isShowStartBtn = false, this.isShowExitBtn = false, i18nMgr.shared().changeLabelFont(p.getComponent(Label)), p.getComponent(Label).string = i18nMgr.shared().getValueByKey("rummy_main.out_tip")) : N.gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL && (this.isShowOkBtn = true, this.isShowStartBtn = false, this.isShowExitBtn = false, this.isShowPoolYesBtn = false, this.isShowPoolNoBtn = false, this.poolRejoin = false) : 2 === this.settle_type ? (N.gameRummyType == RUMMY_GAME_TYPE.DEALS ? (this.isShowPoolYesBtn = true, this.isShowPoolNoBtn = true, this.isShowOkBtn = false, this.isShowExitBtn = false) : N.gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL && (this.isShowPoolYesBtn = false, this.isShowPoolNoBtn = false, this.isShowOkBtn = true, this.isShowExitBtn = true), this.poolRejoin = false, _.active = false, p.active = true, this.isShowStartBtn = false, u.active = false) : 3 === this.settle_type && (this.isShowOkBtn = true, this.isShowStartBtn = false, this.isShowExitBtn = false, this.isShowPoolYesBtn = false, this.isShowPoolNoBtn = false, this.poolRejoin = false);
            1 === this.pre_end && u.setPosition(v3(372, -211));
        }
        else if (N.gameRummyType == RUMMY_GAME_TYPE.PRIVATE) {
            this.rootNode.getChildByName("btn_close").active = false;
            let t = N.clientSeatId;
            1 == N.playerModels[t].ready && (this.rootNode.getChildByName("btn_close").active = true, this.isShowOkBtn = false, this.isShowStartBtn = false, this.isShowExitBtn = false);
            this.msg.cmd !== RummyCmd.SM_GAME_END_BC_INFORM && this.msg.cmd !== RummyCmd.SM_FINISH_STATUS_INFO || i18nMgr.shared().changeLocalizedLabelKey(e.getChildByName("wz"), "rummy_gameover.ready");
        }
        else {
            N.gameRummyType == RUMMY_GAME_TYPE.MATCH ? (this.rootNode.getChildByName("btn_close").active = false, this.isShowOkBtn = true, this.isShowStartBtn = false, this.isShowExitBtn = false, 1 != this.fromtype && this.checkIsPointsMatch() && sys.isObjectValid(this.msg.match_over) && (this.isShowStartBtn = 0 == this.msg.match_over, this.isShowOkBtn = 1 == this.msg.match_over)) : N.gameRummyType != RUMMY_GAME_TYPE.POINTS && N.gameRummyType !== RUMMY_GAME_TYPE.MULTIPLE || !this.bIsEnd || 1 == this._showNewPlayerGuide && (HttpManager.shared().doReportPlayerGuideAct(PhpReportDefined.roomPlayerGuideEvent.loseGameSHow), c.getComponent(RichText).string = i18nMgr.shared().getValueByKey("rummy_gameover.guide_tips"), c.getComponent(RichText).node.on(Node.EventType.TOUCH_END, this.guideRichTextClick, this), c.active = true, _.active = false, p.active = false, u.active = false);
        }
        this.msg.cmd === RummyCmd.SM_FINISH_STATUS_INFO && (N.gameRummyType != RUMMY_GAME_TYPE.POOL && N.gameRummyType != RUMMY_GAME_TYPE.PRI_POOL && N.gameRummyType != RUMMY_GAME_TYPE.DEALS && N.gameRummyType != RUMMY_GAME_TYPE.PRI_DEAL || (this.rootNode.getChildByName("btn_close").active = 0 !== ToolUtils.isSafeNumber(this.msg.show_close_btn)));
        e.active = this.isShowStartBtn;
        0 != N.crashModel || N.gameRummyType != RUMMY_GAME_TYPE.POINTS && N.gameRummyType != RUMMY_GAME_TYPE.MULTIPLE ? (t.active = this.isShowExitBtn, i.active = false) : (i.active = this.isShowExitBtn, t.active = false);
        a.active = this.isShowOkBtn;
        r.active = this.isShowPoolRejoinBtn;
        n.active = this.isShowPoolCencelBtn;
        g.active = this.isShowPoolYesBtn;
        y.active = this.isShowPoolNoBtn;
        0 !== this.hide_start && (this.isShowStartBtn = false, e.active = this.isShowStartBtn);
        1 == this.poolRejoin && 0 == this.startTime && this.showYesOrNobtn();
        this.isShowShareBtn && (s.active = true);
        this.updateReadyTipPos();
        this.checkShowWinShareBtn();
    }
    checkOverBtnsToDestroryEndAlert() {
        let e = this.rootNode.getChildByName("ready_btn"), t = this.rootNode.getChildByName("start_btn"), i = this.rootNode.getChildByName("exit_btn"), s = this.rootNode.getChildByName("ok_btn"), o = this.rootNode.getChildByName("close_btn"), a = this.rootNode.getChildByName("switch_btn"), h = this.rootNode.getChildByName("split_prize_btn"), r = this.rootNode.getChildByName("cencel_btn"), n = this.rootNode.getChildByName("rejoin_btn"), m = this.rootNode.getChildByName("yes_btn"), l = this.rootNode.getChildByName("no_btn"), d = this.rootNode.getChildByName("btn_close"), g = 0;
        g += e.active ? 1 : 0;
        g += t.active ? 1 : 0;
        g += i.active ? 1 : 0;
        g += s.active || o.active ? 1 : 0;
        g += a.active ? 1 : 0;
        g += h.active ? 1 : 0;
        g += r.active ? 1 : 0;
        g += n.active ? 1 : 0;
        g += m.active ? 1 : 0;
        g += l.active ? 1 : 0;
        let y = false;
        return 1 == g && (y = true), d.active && (y = true), y;
    }
    guideRichTextClick(e) {
        SoundManager.shared().playFx("click");
        this._callback && this._callback("points_end_guide");
    }
    show_switch_btn(e) {
        let t = RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType;
        if (t == RUMMY_GAME_TYPE.POINTS || t === RUMMY_GAME_TYPE.MULTIPLE) {
            this.rootNode.getChildByName("switch_btn").active = e;
            this.isShowSwitchBtn = e;
            this.updateReadyTipPos();
        }
    }
    reshow_btn(e = false) {
        this.rootNode.getChildByName("ready_btn").active = false;
        let t = this.rootNode.getChildByName("start_btn"), i = this.rootNode.getChildByName("share_btn"), s = this.rootNode.getChildByName("exit_btn"), o = this.rootNode.getChildByName("exit_btn2"), a = this.rootNode.getChildByName("ok_btn");
        t.active = this.isShowStartBtn;
        let h = RummyDataManager.shared().rummyInfos.get(this.tid_key), r = h.gameRummyType;
        0 != h.crashModel || r != RUMMY_GAME_TYPE.POINTS && r !== RUMMY_GAME_TYPE.MULTIPLE ? (s.active = this.isShowExitBtn, o.active = false) : (o.active = this.isShowExitBtn, s.active = false);
        a.active = this.isShowOkBtn;
        let n = this.rootNode.getChildByName("rejoin_btn"), m = this.rootNode.getChildByName("cencel_btn");
        n.active = this.isShowPoolRejoinBtn;
        m.active = this.isShowPoolCencelBtn;
        this.rootNode.getChildByName("switch_btn").active = this.isShowSwitchBtn;
        let l = this.rootNode.getChildByName("yes_btn"), g = this.rootNode.getChildByName("no_btn");
        l.active = this.isShowPoolYesBtn;
        g.active = this.isShowPoolNoBtn;
        let y = this.rootNode.getChildByName("ready_tips"), _ = this.rootNode.getChildByName("pool_out_tips");
        this.isShowPoolNoBtn && (y.active = false, RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType == RUMMY_GAME_TYPE.POOL && (i18nMgr.shared().changeLabelFont(_.getComponent(Label)), _.getComponent(Label).string = i18nMgr.shared().getValueByKey("rummy_main.out_tip")), _.active = true);
        this.isShowShareBtn && (i.active = true);
        this.updateReadyTipPos();
        this.checkShowWinShareBtn(e);
    }
    isAlreadyShow() {
        return this.node.active && this.rootNode.active;
    }
    checkShowWinShareBtn(e = false) {
        let t = 0;
        if (null != this.msg.record_status && (t = this.msg.record_status), this.bIsEnd && 0 == t && RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType == RUMMY_GAME_TYPE.PRIVATE && (this.msg.cmd === RummyCmd.SM_GAME_END_BC_INFORM || this.msg.cmd === RummyCmd.SM_LAST_CARD_RETURN) && sys.isObjectValid(this.msg.players)) {
            for (let t = 0, i = this.msg.players.length; t < i; t++) {
                if (this.msg.players[t].uid == User.shared().data.uid) {
                    1 == Number(this.msg.players[t].iswin) ? PushCenter.shared().pushEvent(PushEvent.ShowWinShareBtn, true) : e && PushCenter.shared().pushEvent(PushEvent.ShowWinShareBtn, false);
                    break;
                }
            }
        }
    }
    setLandscapeShow() {
        ToolUtils.getOrientation() || this.node.setRotationFromEuler(v3(0, 0, -90));
    }
    isShowEndView(e) {
        let t = this.node.active;
        this.node.active = e;
        e && !t && this.startShowAnim();
        e || (this.rankAnimHasPlay = false);
        e ? this.pushGamePopNode() : this.removePopNode();
    }
    onEnterLineUp() {
        this._bClickBtn && (ToolUtils.isObjValid(this.node) && this.node.destroy(), this._callback && this._callback("cleanGameEndPointer"));
    }
    showCountDown(e) {
        let t = RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType;
        if (t == RUMMY_GAME_TYPE.POINTS || t == RUMMY_GAME_TYPE.MULTIPLE || t == RUMMY_GAME_TYPE.MATCH) {
            let t = this.rootNode.getChildByName("ready_tips");
            e && t && e.length > 0 ? (t.getComponent(Label).string = e, t.active = true) : t.active = false;
        }
    }
    showPrivateTips(e, t) {
        if (1 != this.fromtype && RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType == RUMMY_GAME_TYPE.PRIVATE) {
            let i = this.rootNode.getChildByName("ready_tips");
            4 != e && 4 != e && 5 != e && 6 != e && 7 != e && 15 != e && 16 != e && 17 != e && 18 != e || (i.getComponent(Label).string = t, i.active = true);
        }
    }
    showPrivateTipsText(e) {
        if (1 == this.fromtype) {
            return;
        }
        let t = "", i = RummyDataManager.shared().rummyInfos.get(this.tid_key).gameTipsTextDownTime;
        if (RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType == RUMMY_GAME_TYPE.PRIVATE) {
            0 == e ? t = "" : 1 == e ? t = i18nMgr.shared().getValueByKey("rummy_main.gameTipstext13") : 2 == e ? i > 0 && (t = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_main.gameTipsText"), i)) : 3 == e ? t = i18nMgr.shared().getValueByKey("rummy_main.gameTipsText10") : 4 == e ? i > 0 && (t = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_main.gameTipsText1"), i)) : 5 == e ? t = i18nMgr.shared().getValueByKey("rummy_main.gameTipsText7") : 6 == e ? t = i18nMgr.shared().getValueByKey("rummy_main.gameTipsText8") : 7 == e || 8 == e || 9 == e ? i > 0 && (t = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_main.gameTipsText"), i)) : 10 == e || (11 == e || 12 == e ? i > 0 && (t = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_main.gameTipsText"), i)) : 13 == e ? t = i18nMgr.shared().getValueByKey("rummy_main.gameTipsText9") : 14 == e ? t = i18nMgr.shared().getValueByKey("rummy_main.gameTipstext13") : 15 == e ? t = i18nMgr.shared().getValueByKey("rummy_main.gameTipstext15") : 16 == e ? t = i18nMgr.shared().getValueByKey("rummy_main.gameTipstext16") : 17 == e ? i > 0 && (t = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_main.gameTipstext17"), i)) : 18 == e && (t = i18nMgr.shared().getValueByKey("rummy_main.gameTipstext18")));
            let s = this.rootNode.getChildByName("ready_tips");
            0 != e && 4 != e && 5 != e && 6 != e && 7 != e && 15 != e && 16 != e && 17 != e && 18 != e || (s.getComponent(Label).string = t, s.active = true);
        }
    }
    showReadyView(e, t) {
        if (RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType == RUMMY_GAME_TYPE.PRIVATE) {
            for (let i = 0, s = this.itemViewDate.length; i < s; i++) {
                if (this.itemViewDate[i].item && this.itemViewDate[i].item.isValid) {
                    let s = this.itemViewDate[i].item, o = this.itemViewDate[i].players;
                    if (o.seatid == e) {
                        if (null != o.ready ? o.ready = t ? 1 : 0 : null != o.zhunbei && (o.zhunbei = t ? 1 : 0), t) {
                            let e = s.getChildByName("head_mask").getChildByName("head").getChildByName("ready");
                            e && (e.active = t);
                        }
                        break;
                    }
                }
            }
        }
    }
    updateReadyTipPos() {
        let e = this.rootNode.getChildByName("ready_btn"), t = this.rootNode.getChildByName("start_btn"), i = this.rootNode.getChildByName("share_btn"), s = this.rootNode.getChildByName("exit_btn"), o = this.rootNode.getChildByName("ok_btn"), a = this.rootNode.getChildByName("close_btn"), h = this.rootNode.getChildByName("switch_btn"), r = this.rootNode.getChildByName("split_prize_btn"), n = this.rootNode.getChildByName("cencel_btn"), l = this.rootNode.getChildByName("rejoin_btn"), g = this.rootNode.getChildByName("yes_btn"), _ = this.rootNode.getChildByName("no_btn"), p = this.rootNode.getChildByName("up_btn"), N = 0;
        if (N += e.active ? 1 : 0, 1 == this._upType ? N += t.active || p.active ? 1 : 0 : (N += t.active ? 1 : 0, N += p.active ? 1 : 0), N += s.active ? 1 : 0, N += o.active || a.active ? 1 : 0, N += h.active ? 1 : 0, N += r.active ? 1 : 0, N += i.active ? 1 : 0, RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType != RUMMY_GAME_TYPE.POOL && RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType != RUMMY_GAME_TYPE.PRI_POOL || (N += n.active ? 1 : 0, N += l.active ? 1 : 0, N += g.active ? 1 : 0, N += _.active ? 1 : 0), 1 == N) {
            if (this.rootNode.getChildByName("ready_tips").setPosition(v3(362, -211)), this.rootNode.getChildByName("pool_time").setPosition(v3(362, -211)), s.active && (s.position = t.position), !p.active) {
                let e = this.rootNode.getChildByName("ready_tips");
                e.getComponent(Label).overflow = Overflow.NONE;
                e.getComponent(UITransform).contentSize = size(0, 50.4);
            }
        }
        else if (0 == N) {
            if (this.rootNode.getChildByName("ready_tips").setPosition(v3(580, -211)), this.rootNode.getChildByName("pool_time").setPosition(v3(580, -211)), !p.active) {
                let e = this.rootNode.getChildByName("ready_tips");
                e.getComponent(Label).overflow = Overflow.NONE;
                e.getComponent(UITransform).contentSize = size(0, 50.4);
            }
        }
        else if (p.active) {
            if (1 == this._upType) {
                let e = this.rootNode.getChildByName("ready_tips");
                e.getComponent(Label).overflow = Overflow.NONE;
                e.getComponent(UITransform).contentSize = size(0, 50.4);
                e.setPosition(v3(145, -211));
                this.rootNode.getChildByName("pool_time").setPosition(v3(-70, -211));
            }
        }
        else {
            this.rootNode.getChildByName("ready_tips").setPosition(v3(145, -211));
            this.rootNode.getChildByName("pool_time").setPosition(v3(145, -211));
            this.isShowShareBtn && (t.position = r.position);
            s.active && (s.position = r.position);
            let e = this.rootNode.getChildByName("ready_tips");
            e.getComponent(Label).overflow = Overflow.NONE;
            e.getComponent(UITransform).contentSize = size(0, 50.4);
        }
    }
    setPoolRummyCountDown(e, t) {
        if (this.flopCashStopTime) {
            return;
        }
        e = ToolUtils.isSafeNumber(e);
        if (1 == User.shared().isInPerformanceRoom) {
            return;
        }
        if (!RummyDataManager.shared().rummyInfos.get(this.tid_key)) {
            return;
        }
        let i = RummyDataManager.shared().rummyInfos.get(this.tid_key);
        if (1 == this.all_end && t) {
            return void (i.game_end_state = 5);
        }
        if (i.gameRummyType !== RUMMY_GAME_TYPE.PRI_POOL && 1 == this.will_disuse) {
            return;
        }
        this.time_action && (TweenTool.stopAction(this.time_action), this.time_action = null);
        this.startTime = e;
        let s = 28;
        i.end_game_countdown = this.startTime;
        let o = "", a = true, h = false, r = this.rootNode.getChildByName("pool_out_tips");
        if (this.poolRejoin ? (o = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_gameover.over_tips3"), this.poolRejoinScore, this.startTime), s = 22) : 5 == i.game_end_state ? o = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_gameover.over_tips4"), this.startTime) : (o = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_gameover.over_tips5"), this.startTime), i.gameRummyType != RUMMY_GAME_TYPE.POOL && i.gameRummyType != RUMMY_GAME_TYPE.PRI_POOL || 1 == i.game_end_state && (o = "<color=#000000>" + ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_main.gameTipsText6"), this.startTime) + "</color>", s = 0 != i18nMgr.shared().language && 1 != i18nMgr.shared().language ? 22 : 28), i.gameRummyType == RUMMY_GAME_TYPE.PRI_POOL && 1 === this.will_disuse && (o = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_gameover.over_tips12"), this.startTime))), i.gameRummyType == RUMMY_GAME_TYPE.DEALS || i.gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL) {
            if (this.dealsMyTiebreak) {
                o = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_gameover.over_tips6"), this.startTime);
            }
            else if (5 == i.game_end_state) {
                o = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_gameover.over_tips4"), this.startTime);
            }
            else {
                let e = this.cround + 1;
                o = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_gameover.over_tips7"), e, this.startTime);
            }
            1 === this.pre_end && (o = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_gameover.over_tips11"), this.startTime));
            2 === this.settle_type ? (a = false, h = true, i18nMgr.shared().changeLabelFont(r.getComponent(Label)), i.gameRummyType == RUMMY_GAME_TYPE.DEALS ? r.getComponent(Label).string = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_gameover.over_tips13"), this.win_prize, this.startTime) : i.gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL && (r.getComponent(Label).string = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_gameover.over_tips14"), this.win_prize, this.startTime))) : 1 === this.settle_type ? i.gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL && (a = true, h = false, o = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_gameover.over_tips12"), this.startTime)) : 3 === this.settle_type && (a = true, h = false, o = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_gameover.over_tips5"), this.startTime));
        }
        (i.gameRummyType == RUMMY_GAME_TYPE.POINTS || i.gameRummyType == RUMMY_GAME_TYPE.MULTIPLE || this.checkIsPointsMatch()) && (this.startTime > 0 ? (this.rootNode.getChildByName("pool_time").setPosition(v3(145, -211)), o = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_gameover.over_tips8"), this.startTime)) : o = "");
        1 == this.is_auto_split ? o = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_gameover.auto_split_tip"), ToolUtils.parse_double("" + this.auto_split_money, 0), this.startTime) : 2 == this.is_auto_split && (o = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_gameover.over_tips16"), this.startTime));
        0 != this._upType && 2 != this._upType || 0 != i18nMgr.shared().language && 1 != i18nMgr.shared().language && s > 22 && (s = 20);
        this.rootNode.getChildByName("pool_time").active = a;
        this.rootNode.getChildByName("ready_tips").active = false;
        this.rootNode.getChildByName("pool_time").getComponent(RichText).string = o;
        this.rootNode.getChildByName("pool_time").getComponent(RichText).fontSize = s;
        r.active = h;
        this.updateReadyTipPos();
        let n = this;
        this.time_action = TweenTool.myschedule(RummyDataManager.shared().sceneNode, 1, (() => {
            n.updateTime();
        }));
    }
    stopPoolRummyCountDown() {
        this.time_action && (TweenTool.stopAction(this.time_action), this.time_action = null);
        RummyDataManager.shared().rummyInfos.has(this.tid_key) && (RummyDataManager.shared().rummyInfos.get(this.tid_key).end_game_countdown = 0);
        this.rootNode.getChildByName("pool_time").active = false;
    }
    stopUpdateTime() {
        let e = RummyDataManager.shared().rummyInfos.get(this.tid_key);
        !sys.isObjectValid(e) || e.gameRummyType != RUMMY_GAME_TYPE.POINTS && e.gameRummyType != RUMMY_GAME_TYPE.MULTIPLE || (this.startTime = 0, this.stopPoolRummyCountDown(), this.rootNode.getChildByName("pool_time").active = false, this._callback && this._callback("points_time_out"));
    }
    updateTime() {
        if (!ToolUtils.isObjValid(this.rootNode)) {
            return;
        }
        if (this.flopCashStopTime) {
            return;
        }
        Number.isFinite(this.startTime) || (this.startTime = 1);
        this.startTime = this.startTime - 1;
        let e = RummyDataManager.shared().rummyInfos.get(this.tid_key);
        sys.isObjectValid(e) && (e.end_game_countdown = this.startTime);
        let t = this.rootNode.getChildByName("pool_out_tips");
        if (this.startTime <= 0) {
            if (!sys.isObjectValid(e) || e.gameRummyType != RUMMY_GAME_TYPE.POINTS && e.gameRummyType != RUMMY_GAME_TYPE.MULTIPLE) {
                if (2 === this.settle_type && (t.active = false), this.stopPoolRummyCountDown(), sys.isObjectValid(e) && e.gameRummyType == RUMMY_GAME_TYPE.POOL && this.poolRejoin) {
                    this.isShowPoolYesBtn = true;
                    this.isShowPoolNoBtn = true;
                    this.poolRejoin = false;
                    this.isShowStartBtn = false;
                    this.isShowExitBtn = false;
                    this.isShowOkBtn = false;
                    this.isShowPoolRejoinBtn = false;
                    this.isShowPoolCencelBtn = false;
                    this.isShowSwitchBtn = false;
                    this.reshow_btn();
                }
                else {
                    if (sys.isObjectValid(e) && e.gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL && 2 === this.settle_type) {
                        return this._callback("no"), ToolUtils.isObjValid(this.node) && this.node.destroy(), void (this._callback && this._callback("cleanGameEndPointer"));
                    }
                    1 == this.all_end && this._callback("pool_game_all_end");
                    this._isReissue || (ToolUtils.isObjValid(this.node) && this.node.destroy(), this._callback && (this._callback("gameOverAlertDestroy"), this._callback("cleanGameEndPointer")));
                }
            }
            else if (this.rootNode.getChildByName("pool_time").active = false, this.stopPoolRummyCountDown(), !sys.isObjectValid(this.msg.force_up_venue_tips_end) || 1 != ToolUtils.isSafeNumber(this.msg.force_up_venue_tips_end.show)) {
                this._callback && this._callback("points_time_out");
                let e = director.getScene().getChildByName("Canvas");
                sys.isObjectValid(e.getChildByName("game_fast_buy")) || this.dealStartClickLogic(false);
            }
        }
        else if (sys.isObjectValid(e)) {
            let i = "", s = 28;
            if (this.poolRejoin ? (i = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_gameover.over_tips3"), this.poolRejoinScore, this.startTime), s = 22) : 5 == e.game_end_state ? i = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_gameover.over_tips4"), this.startTime) : (i = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_gameover.over_tips5"), this.startTime), e.gameRummyType != RUMMY_GAME_TYPE.POOL && e.gameRummyType != RUMMY_GAME_TYPE.PRI_POOL || 1 == e.game_end_state && (i = "<color=#000000>" + ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_main.gameTipsText6"), this.startTime) + "</color>", s = 0 != i18nMgr.shared().language && 1 != i18nMgr.shared().language ? 22 : 28), e.gameRummyType == RUMMY_GAME_TYPE.PRI_POOL && 1 === this.will_disuse && (i = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_gameover.over_tips12"), this.startTime))), e.gameRummyType == RUMMY_GAME_TYPE.DEALS || e.gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL) {
                if (this.dealsMyTiebreak) {
                    i = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_gameover.over_tips6"), this.startTime);
                }
                else if (5 == e.game_end_state) {
                    i = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_gameover.over_tips4"), this.startTime);
                }
                else {
                    let e = this.cround + 1;
                    i = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_gameover.over_tips7"), e, this.startTime);
                }
                1 === this.pre_end && (i = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_gameover.over_tips11"), this.startTime));
                2 === this.settle_type ? e.gameRummyType == RUMMY_GAME_TYPE.DEALS ? t.getComponent(Label).string = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_gameover.over_tips13"), this.win_prize, this.startTime) : e.gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL && (t.getComponent(Label).string = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_gameover.over_tips14"), this.win_prize, this.startTime)) : 1 === this.settle_type ? e.gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL && (i = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_gameover.over_tips12"), this.startTime)) : 3 === this.settle_type && (i = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_gameover.over_tips5"), this.startTime));
            }
            (e.gameRummyType == RUMMY_GAME_TYPE.POINTS || e.gameRummyType == RUMMY_GAME_TYPE.MULTIPLE || this.checkIsPointsMatch()) && (i = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_gameover.over_tips8"), this.startTime));
            1 == this.is_auto_split ? i = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_gameover.auto_split_tip"), ToolUtils.parse_double("" + this.auto_split_money, 0), this.startTime) : 2 == this.is_auto_split && (i = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_gameover.over_tips16"), this.startTime));
            0 != this._upType && 2 != this._upType || 0 != i18nMgr.shared().language && 1 != i18nMgr.shared().language && s > 22 && (s = 20);
            this.rootNode.getChildByName("pool_time").getComponent(RichText).string = i;
            this.rootNode.getChildByName("pool_time").getComponent(RichText).fontSize = s;
            this.rootNode.getChildByName("ready_tips").active = false;
        }
    }
    showYesOrNobtn() {
        this.stopPoolRummyCountDown();
        RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType != RUMMY_GAME_TYPE.POOL && RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType != RUMMY_GAME_TYPE.PRI_POOL || this.poolRejoin && (this.isShowPoolYesBtn = true, this.isShowPoolNoBtn = true, this.poolRejoin = false, this.isShowStartBtn = false, this.isShowExitBtn = false, this.isShowOkBtn = false, this.isShowPoolRejoinBtn = false, this.isShowPoolCencelBtn = false, this.isShowSwitchBtn = false, this.reshow_btn());
    }
    updateBtnShow() {
        let e = RummyDataManager.shared().rummyInfos.get(this.tid_key);
        if (0 == e.game_end_state) {
            this.rootNode.getChildByName("start_btn").active = true;
            this.rootNode.getChildByName("split_prize_btn").active = false;
            this.rootNode.getChildByName("pool_time").setPosition(v3(362, -211));
        }
        else if (1 == e.game_end_state) {
            this.rootNode.getChildByName("start_btn").active = false;
            this.rootNode.getChildByName("ok_btn").active = true;
            this.rootNode.getChildByName("split_prize_btn").active = false;
            this.rootNode.getChildByName("pool_time").setPosition(v3(362, -211));
        }
        else if (2 == e.game_end_state) {
            if (this.rootNode.getChildByName("start_btn").active = false, this.rootNode.getChildByName("ok_btn").active = true, 1 !== this._isWatching) {
                this.rootNode.getChildByName("split_prize_btn").active = true;
                this.rootNode.getChildByName("split_prize_btn").getChildByName("wz").getComponent(Label).fontSize = 0 == i18nMgr.shared().language ? 28 : 26;
                User.shared().curTid_key != this.tid_key && (this.playEffectByName("rummySelfTurn"), TransferPlatform.shared().openVibrate());
            }
            this.rootNode.getChildByName("pool_time").setPosition(v3(145, -211));
        }
        else {
            3 == e.game_end_state ? (this.rootNode.getChildByName("start_btn").active = true, this.rootNode.getChildByName("split_prize_btn").active = false, this.rootNode.getChildByName("exit_btn").active = true, this.stopPoolRummyCountDown()) : 4 == e.game_end_state && (this.rootNode.getChildByName("ok_btn").active = true, this.rootNode.getChildByName("start_btn").active = false, this.rootNode.getChildByName("split_prize_btn").active = false, this.rootNode.getChildByName("pool_time").setPosition(v3(362, -211)));
        }
        e.gameRummyType == RUMMY_GAME_TYPE.POOL && this.poolRejoin && (this.isShowPoolCencelBtn = true, this.isShowPoolRejoinBtn = true, this.rootNode.getChildByName("cencel_btn").active = true, this.rootNode.getChildByName("rejoin_btn").active = true, this.rootNode.getChildByName("pool_time").setPosition(v3(357, -211)), this.rootNode.getChildByName("start_btn").active = false, this.rootNode.getChildByName("ok_btn").active = false, this.rootNode.getChildByName("exit_btn").active = false);
        this.isShowOkBtn = this.rootNode.getChildByName("ok_btn").active;
        this.isShowStartBtn = this.rootNode.getChildByName("start_btn").active;
        this.isShowExitBtn = this.rootNode.getChildByName("exit_btn").active;
        0 !== this.hide_start && (this.isShowStartBtn = false, this.rootNode.getChildByName("start_btn").active = false);
        this.updateReadyTipPos();
    }
    setPoolRummyIsEnd(e) {
        this.ispoolRummyend = e;
    }
    getPoolRummyIsEnd() {
        return this.ispoolRummyend;
    }
    updateDealsView() {
        this.rootNode.getChildByName("start_btn").active = true;
        this.rootNode.getChildByName("exit_btn").active = true;
        this.rootNode.getChildByName("ok_btn").active = false;
        0 !== this.hide_start && (this.isShowStartBtn = false, this.rootNode.getChildByName("start_btn").active = false);
        this.stopPoolRummyCountDown();
    }
    itemHelpBtnOnclick(e, t) {
        if (SoundManager.shared().playFx("click"), -1 != t.indexOf("bonus_tips")) {
            if (this.bonusTipsMask.active) {
                return void this.onCloseItemHelpTips(null);
            }
            let e = parseInt(t.substring("bonus_tips_".length));
            for (let t = 0, i = this.itemViewDate.length; t < i; t++) {
                if (t == e) {
                    if (this._showIndex = t, this.itemViewDate[t].item && this.itemViewDate[t].item.isValid) {
                        this.bonusTipsMask.active = true;
                        let e = this.itemViewDate[t].item, i = e.children.length + 1;
                        e.getChildByName("bonus_btn").setSiblingIndex(i);
                        let s = e.getChildByName("bonus_btn").getWorldPosition();
                        if (sys.isObjectValid(this.itemViewDate[t].players.bonus_incr_rate)) {
                            let e = 100 * Number(ToolUtils.parse_double(this.itemViewDate[t].players.bonus_incr_rate));
                            this.bonusTipsMask.getChildByName("Label").getComponent(Label).string = ToolUtils.format("BONUS transtion extra ${0}%", e);
                        }
                        let o = new Vec3;
                        this.rootNode.inverseTransformPoint(o, s);
                        this.bonusTipsMask.setPosition(v3(o.x + 34, o.y + 63));
                    }
                    break;
                }
            }
        }
        else if (-1 != t.indexOf("tip")) {
            let e = parseInt(t.substring("tip".length)), i = 0.5 * GameConfig.REAL_SCREEN_WIDTH;
            for (let t = 0, s = this.itemViewDate.length; t < s; t++) {
                if (t == e) {
                    if (this._showIndex = t, this.itemViewDate[t].item && this.itemViewDate[t].item.isValid) {
                        let e = this.itemViewDate[t].item, s = e.children.length + 1;
                        e.getChildByName("help_btn").setSiblingIndex(s);
                        let o = e.getChildByName("help_btn").getWorldPosition();
                        i18nMgr.shared().changeLabelLanguage(this.tipsMask.getChildByName("Label").getComponent(Label), "rummy_gameover.Label_text");
                        1 == i18nMgr.shared().language ? (this.tipsMask.getComponent(UITransform).contentSize = size(780, 60), this.tipsMask.setPosition(v3(-30, o.y - i - 45))) : (this.tipsMask.getComponent(UITransform).contentSize = size(730, 60), this.tipsMask.setPosition(v3(-50, o.y - i - 45)));
                        this.tipsMask.active = true;
                    }
                    break;
                }
            }
        }
    }
    checkFlopCashView(e) {
        if (sys.isObjectValid(e) && sys.isObjectValid(e.tid_key) && this.tid_key == e.tid_key && 2 == e.current_task_status) {
            let e = RummyDataManager.shared().rummyInfos.get(this.tid_key);
            !sys.isObjectValid(e) || e.gameRummyType != RUMMY_GAME_TYPE.POINTS && e.gameRummyType != RUMMY_GAME_TYPE.MULTIPLE || (this.flopCashStopTime = true);
            this.stopUpdateTime();
        }
    }
    updateFlopCashBanner(e) {
        let t = this.bottomBtns.getChildByName("flopcashTask_node");
        if (ToolUtils.isObjValid(t)) {
            try {
                if (t.active = true, sys.isObjectValid(e) && sys.isObjectValid(e.current_play_num) && sys.isObjectValid(e.target_play_num) && Number(e.target_play_num) > 0) {
                    t.getChildByName("progress_num").getComponent(Label).string = String(e.current_play_num) + "/" + String(e.target_play_num);
                    t.getChildByName("ProgressBar").getComponent(ProgressBar).progress = Number(e.current_play_num) / Number(e.target_play_num);
                    let i = ToolUtils.format(i18nMgr.shared().getValueByKey("flop_cash.task"), e.target_play_num);
                    t.getChildByName("name").getComponent(Label).string = i;
                }
                sys.isObjectValid(e) && sys.isObjectValid(e.today_task_status) && 2 == e.today_task_status && (t.active = false);
                this.checkFlopCashView(e);
            }
            catch (e) {
                TLog.printError("updateFlopCashBanner err:", e);
            }
        }
    }
    hideFlopCashBanner() {
        let e = this.bottomBtns.getChildByName("flopcashTask_node");
        ToolUtils.isObjValid(e) && (e.active = false);
    }
    updateNovicesBanner(e) {
        let t = this.bottomBtns.getChildByName("novicesTask_node");
        if (ToolUtils.isObjValid(t)) {
            try {
                if (t.active && e.game_id == RummyDataManager.shared().rummyInfos.get(this.tid_key).gameSerialId && 0 == e.task_status) {
                    return;
                }
                t.active = true;
                let i = t.getChildByName("rewardItem");
                i.active = false;
                t.getChildByName("ProgressBar");
                ToolUtils.isSafeNumber(e.type);
                let s = ToolUtils.isSafeString(e.sub_title);
                if (s.length > 0 && (t.getChildByName("name").getComponent(Label).string = s), sys.isObjectValid(e.num) && sys.isObjectValid(e.total)) {
                    e.num > e.total ? t.getChildByName("progress_num").getComponent(Label).string = ToolUtils.format("${0}/${1}", e.total, e.total) : t.getChildByName("progress_num").getComponent(Label).string = ToolUtils.format("${0}/${1}", ToolUtils.parse_double(e.num, -1), e.total);
                    let i = Number(e.num) / Number(e.total);
                    t.getChildByName("ProgressBar").getComponent(ProgressBar).progress = i;
                }
                if (sys.isObjectValid(e.reward) && e.reward.length > 0) {
                    let s = t.getChildByName("rewardList").getChildByName("view").getChildByName("content");
                    s.removeAllChildren();
                    for (let t = 0, o = e.reward.length; t < o; t++) {
                        let o = instantiate(i);
                        this.updateRewardSprite(o.getChildByName("ico"), Number(e.reward[t].type));
                        o.getChildByName("num").getComponent(Label).string = e.reward[t].amt;
                        o.active = true;
                        s.addChild(o);
                    }
                }
            }
            catch (e) {
                TLog.printError("updateNovicesBanner err:", e);
            }
        }
    }
    hideNovicesBanner() {
        let e = this.bottomBtns.getChildByName("novicesTask_node");
        ToolUtils.isObjValid(e) && (e.active = false);
    }
    updateRewardSprite(e, t) {
        ToolUtils.isSafeString(CommDefine.rewardPistName[t]).length > 0 && Utils.shared().setImage(e, CommDefine.rewardPistName[t], this.rewardPlist);
    }
    onCloseItemHelpTips(e, t = "") {
        ToolUtils.isObjValid(this.tipsMask) && this.tipsMask.active && (this.tipsMask.active = false);
        ToolUtils.isObjValid(this.bonusTipsMask) && this.bonusTipsMask.active && (this.bonusTipsMask.active = false);
        this._hideBonusTipsAct && (TweenTool.stopAction(this._hideBonusTipsAct), this._hideBonusTipsAct = null);
    }
    onBackView() {
        let e = false;
        1 == this.fromtype && (e = true, RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType === RUMMY_GAME_TYPE.PRIVATE && undefined !== this.msg.start_cd && (e = false));
        e && (this.startHideAnim(), this.isShowEndView(false));
    }
    pushGamePopNode() {
        const room = RummyDataManager.shared().rummyInfos.get(this.tid_key);
        if (!room) return;
        const stack = room.popNode || (room.popNode = []);
        if (!stack.includes(this.node)) stack.push(this.node);
    }
    removePopNode() {
        const room = RummyDataManager.shared().rummyInfos.get(this.tid_key);
        if (!room || !room.popNode) return;
        // Identity matters: history and settlement can use the same prefab.
        room.popNode = room.popNode.filter(node => node !== this.node);
    }
    checkIsPointsMatch() {
        let e = false, t = RummyDataManager.shared().rummyInfos.get(this.tid_key);
        return sys.isObjectValid(t) && t.gameRummyType == RUMMY_GAME_TYPE.MATCH && t.gameMatchMode == RUMMY_MATCH_MODE.PointsMatch && (e = true), e;
    }
}
