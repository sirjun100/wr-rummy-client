// @ts-nocheck
// Recovered from index.js:481
import { _decorator, Label, Node } from "cc";
import Utils from "./Utils";
import User from "./User";
import GameConfig from "./GameConfig";
import SoundManager from "./SoundManager";
import PushCenter from "./PushCenter";
import HowToPlayDefined from "./HowToPlayDefined";
import i18nMgr from "./i18nMgr";
import BaseLayer from "./BaseLayer";
import HttpManager from "./HttpManager";
import RummyDataManager, { RUMMY_GAME_TYPE } from "./RummyDataManager";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("RummyPracticeGuide")
export class RummyPracticeGuide extends BaseLayer {
    @property(Node)
    public go_btn: Node = null;
    public callfun: any = null;
    public pnum: number = 0;
    public vid: number = 0;
    public roomInfo: any = null;
    onLoad() {
        this.bIsInGame = true;
    }
    start() {
        super.start();
        let e = this.node.getChildByName("mask");
        ToolUtils.showFullScreen(e);
        this.refreshUI();
        PushCenter.shared().addListener(GameConfig.Update_Money, (e => {
            ToolUtils.isObjValid(this.node) && (this.refreshUI(), this.onButtonClick(null, "go_ahead", false));
        }), this);
        ToolUtils.startShowAnim(this.node.getChildByName("rootNode"));
        HttpManager.shared().doGetCommonRequest({ type: 4 }, "BeginnerGuide.exerciseGameReport", null);
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().removeListenersByTag(this);
    }
    refreshUI() {
        this.vid = this.getRoomVid();
        let e = 0 == this.vid ? i18nMgr.shared().getValueByKey("choose_game.add_cash") : i18nMgr.shared().getValueByKey("gameRummy_Deals_Pop.go_ahead");
        this.go_btn.getChildByName("wz").getComponent(Label).string = e;
        i18nMgr.shared().changeLabelFont(this.go_btn.getChildByName("wz").getComponent(Label), true);
    }
    setParaData(e, t) {
        this.callfun = e;
        this.pnum = t;
    }
    getRoomVid() {
        let e = 0, t = [], s = RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType;
        t = s == RUMMY_GAME_TYPE.POINTS || s == RUMMY_GAME_TYPE.MULTIPLE ? User.shared().roomTable.pointsrummy.crashlist : s == RUMMY_GAME_TYPE.POOL ? User.shared().roomTable.poolrummy.crashlist : User.shared().roomTable.dealsrummy.crashlist;
        let i = [];
        if (null != t && t.length > 0) {
            for (let e = 0, n = t.length; e < n; e++) {
                s == RUMMY_GAME_TYPE.POINTS || s == RUMMY_GAME_TYPE.MULTIPLE ? t[e].player == this.pnum && 1 == t[e].mode && i.push(t[e]) : t[e].player == this.pnum && i.push(t[e]);
            }
        }
        if (null != i && i.length > 0) {
            for (let t = 0, s = i.length; t < s; t++) {
                User.shared().data.money >= i[t].entry && (e = i[t].vid);
            }
        }
        return 0 == e && (this.roomInfo = i[0]), e;
    }
    onButtonClick(e, t, s = true) {
        if (s && SoundManager.shared().playFx("click"), "go_ahead" == t) {
            if (User.shared().isCanPlayCashGame()) {
                if (0 != this.vid) {
                    HttpManager.shared().doGetCommonRequest({ type: 6 }, "BeginnerGuide.exerciseGameReport", null);
                    RummyDataManager.shared().rummyInfos.get(this.tid_key).switchCash = true;
                    Utils.shared().showLoadTable(this.vid, HowToPlayDefined.gameId_RummyGame, null, null, null, null, null, 1);
                    RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType != RUMMY_GAME_TYPE.POINTS && User.shared().send_client_consume_table_record_laba(this.tid_key);
                    this.callfun && this.callfun("practice_exit");
                    ToolUtils.isObjValid(this.node) && this.node.destroy();
                }
                else {
                    let e = 0;
                    undefined !== this.roomInfo.entry && (e = this.roomInfo.entry);
                    Utils.shared().showQuickRecharge(this.roomInfo.vid, null, true, this.tid_key, 0, e);
                    HttpManager.shared().doGetCommonRequest({ type: 7 }, "BeginnerGuide.exerciseGameReport", null);
                }
            }
            else {
                RummyDataManager.shared().rummyInfos.get(this.tid_key).isInGameing = 0;
                this.callfun && this.callfun("practice_exit");
                HttpManager.shared().doGetCommonRequest({ type: 6 }, "BeginnerGuide.exerciseGameReport", null);
                ToolUtils.isObjValid(this.node) && this.node.destroy();
            }
        }
        else {
            "cancel" == t && (this.callfun && this.callfun("guide_cancel"), HttpManager.shared().doGetCommonRequest({ type: 5 }, "BeginnerGuide.exerciseGameReport", null), ToolUtils.isObjValid(this.node) && this.node.destroy());
        }
    }
    setTidKey(e) {
        this.tid_key = e;
    }
}
