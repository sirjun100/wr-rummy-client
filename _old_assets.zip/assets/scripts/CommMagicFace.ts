// @ts-nocheck
// Recovered from index.js:73
import { _decorator, Button, director, Label, Node, size, Sprite, SpriteAtlas, sys, v3, Vec3 } from "cc";
import SoundManager from "./SoundManager";
import Utils from "./Utils";
import GameConfig from "./GameConfig";
import PushCenter from "./PushCenter";
import BaseLayer from "./BaseLayer";
import User from "./User";
import { ToolUtils } from "./ToolUtils";
import PhpReportDefined from "./PhpReportDefined";
const { ccclass, property } = _decorator;
@ccclass("CommMagicFace")
export default class CommMagicFace extends BaseLayer {
    public TAG: string = "CommMagicFace";
    @property(Node)
    public bgNode: Node = null;
    @property(Node)
    public rootNode: Node = null;
    @property(Sprite)
    public headSp: Sprite = null;
    @property(Label)
    public nameLable: Label = null;
    @property(Label)
    public cashLabel: Label = null;
    @property(Node)
    public addCashIco: Node = null;
    @property(Node)
    public cashBgNode: Node = null;
    @property(Node)
    public gift_scroll: Node = null;
    @property(SpriteAtlas)
    public cmomonIconAtlas: SpriteAtlas = null;
    @property(SpriteAtlas)
    public faceImgAtlas: SpriteAtlas = null;
    public cb_face: any = null;
    public cb_notify_user_info_status: any = null;
    public target_seatid: number = 0;
    public seat_id: number = 0;
    public _chatFaceCount: number = 6;
    public faceImgNames: any[] = ["dtz_magic_flower", "dtz_magic_kiss", "dtz_magic_tea", "dtz_magic_shoes", "dtz_magic_bomb", "dtz_magic_egg"];
    public faceIdArr: any[] = [1, 2, 6, 3, 4, 5];
    public magicexpressioncost: number = 0;
    public emotion_fee_cfg: any = null;
    public magic_ts: number = 0;
    public players: any = null;
    public bIsInPrivateRoom: boolean = false;
    public bIsPracticeRoom: boolean = false;
    public bIsMatchRoom: boolean = false;
    public bIsSend: boolean = false;
    public cur_uid: any = null;
    public _vid: any = -1;
    public _entryFee: any = -1;
    public _tidKey: any = User.shared().curTid_key;
    onLoad() {
        this.bIsSend = false;
        this.fitScreen();
        this.bIsInGame = true;
        PushCenter.shared().addListener(GameConfig.Close_Magic_View, (t => {
            ToolUtils.isObjValid(this.node) && Number(t) >= 0 && t === this.target_seatid && ToolUtils.isObjValid(this.node) && this.node.destroy();
        }), this);
        PushCenter.shared().addListener(GameConfig.Update_Money, (t => {
            ToolUtils.isObjValid(this.node) && this.updateSelfCoin();
        }), this);
    }
    onDestroy() {
        this.seat_id >= 0 && this.cb_notify_user_info_status(this.seat_id, 0);
        super.onDestroy();
        PushCenter.shared().removeListenersByTag(this);
        this.unscheduleAllCallbacks();
    }
    fitScreen() {
        ToolUtils.showFullScreen(this.node.getChildByName("bg"));
    }
    start() {
        super.start();
        this.initCostView();
        this.startShowAnim(this.rootNode);
        let t = new Vec3;
        this.bgNode.getPosition(t);
        this.seat_id >= 0 && this.cb_notify_user_info_status(this.seat_id, 1);
    }
    initCostView() {
        for (let t = 0; t < 6; t++) {
            let e = this.gift_scroll.getChildByName("faceItem" + t);
            if (sys.isObjectValid(e) && sys.isObjectValid(this.emotion_fee_cfg)) {
                let i = this.faceIdArr[t];
                if (sys.isObjectValid(this.emotion_fee_cfg[String(i)])) {
                    let t = Number(this.emotion_fee_cfg[String(i)]);
                    e.getChildByName("goldAmtNode").getComponent(Label).string = "₹" + t;
                }
            }
        }
    }
    setIsInPrivateRoom(t) {
        this.bIsInPrivateRoom = t;
    }
    setIsPracticeRoom(t) {
        this.cur_uid;
        User.shared().data.uid;
        this.bIsPracticeRoom = t;
    }
    setIsMatchRoom(t) {
    }
    updateSelfCoin() {
        if (this.cur_uid == User.shared().data.uid) {
            let t = User.shared().data.money;
            this.cashLabel.getComponent(Label).string = ToolUtils.parse_double(t + "") || "";
        }
    }
    updatePlayerInfo(t) {
        let e = t.pmodel, i = t.money, s = e.avatar, a = e.avatar_url;
        this.cur_uid = e.uid;
        let o = e.name, r = this.cur_uid == User.shared().data.uid;
        this.addCashIco.active = r;
        this.cashBgNode.getComponent(Button).interactable = r;
        i <= 0 && (i = 0);
        this.nameLable.string = ToolUtils.GetShortName2(o, 12, true);
        ToolUtils.isSafeNumber(e.avatar_frame_id);
        if (s && s.length > 0 && Utils.shared().updateHeadImg(this.headSp.node, s, a, size(120, 120)), r) {
            let t = User.shared().data.money;
            this.cashLabel.getComponent(Label).string = ToolUtils.parse_double(t + "") || "";
        }
        else {
            this.cashLabel.getComponent(Label).string = ToolUtils.parse_double(i + "");
        }
    }
    setFaceCallback(t) {
        this.cb_face = t;
    }
    setNotifyUserInfoStatus(t, e) {
        this.cb_notify_user_info_status = t;
        this.seat_id = e;
    }
    setTargetClientId(t) {
        this.target_seatid = t;
    }
    setRoomInfo(t) {
        sys.isObjectValid(t) && (sys.isObjectValid(t.entryFee) && (this._entryFee = Number(t.entryFee)), sys.isObjectValid(t.vid) && (this._vid = t.vid), sys.isObjectValid(t.tid_key) && (this._tidKey = t.tid_key), sys.isObjectValid(t.bPrivate) && this.setIsInPrivateRoom(t.bPrivate), sys.isObjectValid(t.bPractice) && this.setIsPracticeRoom(t.bPractice), sys.isObjectValid(t.cost) && (this.magicexpressioncost = t.cost), sys.isObjectValid(t.emotion_fee_cfg) && (this.emotion_fee_cfg = t.emotion_fee_cfg), sys.isObjectValid(t.magic_ts) && (this.magic_ts = t.magic_ts));
    }
    onClickByFace(t, e) {
        if (this.bIsSend) {
            return;
        }
        this.bIsSend = true;
        SoundManager.shared().playFx("click");
        let i = 0;
        sys.isObjectValid(this.emotion_fee_cfg[String(e)]) && (i = Number(this.emotion_fee_cfg[String(e)]));
        this.cb_face(e, this.target_seatid, i);
        this.bIsInPrivateRoom ? this.scheduleOnce((() => {
            this.bIsSend = false;
        }), 0.7) : ToolUtils.isObjValid(this.node) && this.node.destroy();
    }
    onClickClose(t, e) {
        SoundManager.shared().playFx("click");
        ToolUtils.isObjValid(this.node) && this.node.destroy();
    }
    onClickAdd(t, e) {
        if (SoundManager.shared().playFx("click"), this.cur_uid == User.shared().data.uid) {
            this._vid;
            director.getScene().getChildByName("Canvas");
            this._tidKey;
            this._entryFee;
            Utils.shared().showQuickRecharge(this._vid, this.node, true, this.tid_key, 0, this._entryFee);
            User.shared().updatePayScene(PhpReportDefined.pay_scene.game_desktop, this._vid);
        }
    }
    setLandscapeShow() {
        ToolUtils.getOrientation() || this.node.setRotationFromEuler(v3(0, 0, -90));
    }
}
