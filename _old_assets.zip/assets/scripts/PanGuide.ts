// @ts-nocheck
// Recovered from index.js:331
import { _decorator, Button, color, EditBox, Label, LabelShadow, Node, Sprite, SpriteFrame, sys, v3 } from "cc";
import SoundManager from "./SoundManager";
import Utils from "./Utils";
import BaseLayer from "./BaseLayer";
import User from "./User";
import HttpManager from "./HttpManager";
import i18nMgr from "./i18nMgr";
import PushCenter from "./PushCenter";
import PushEvent from "./PushEvent";
import { TransferPlatform } from "./TransferPlatform";
import TweenTool from "./TweenTool";
import GameConfig from "./GameConfig";
import CommDefine from "./CommDefine";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("PanGuide")
export class PanGuide extends BaseLayer {
    @property(Node)
    public rootNode: Node = null;
    @property(Node)
    public verifyNode: Node = null;
    @property(Node)
    public waitNode: Node = null;
    @property(Node)
    public secTipsLabel: Node = null;
    @property(Node)
    public cardNumberNode: Node = null;
    @property(Node)
    public errTipNode: Node = null;
    @property(Node)
    public verify_btn: Node = null;
    @property([SpriteFrame])
    public verifyBtnDiImags: SpriteFrame[] = [];
    public cardNumberStr: string = "";
    public isNext: boolean = false;
    public from_source: number = 0;
    public _closed: boolean = false;
    public is_refine: number = 0;
    public _mIdTime: number = 0;
    public _identitytimeAction: any = null;
    public _countDownAction: any = null;
    public _keyboardHei: number = 740;
    public _lastClick: number = 0;
    initParaData(e) {
        sys.isObjectValid(e) && (sys.isObjectValid(e.isNext) && (this.isNext = e.isNext), sys.isObjectValid(e.from_source) && (this.from_source = e.from_source), sys.isObjectValid(e.is_refine) && (this.is_refine = e.is_refine));
    }
    onLoad() {
        let e = this.node.getChildByName("mask");
        ToolUtils.showFullScreen(e);
        this.updateCheckStatus();
    }
    start() {
        super.start();
        TransferPlatform.shared().setSoftInputMode(1);
        this.startShowAnim(this.rootNode);
        this.updateVerifyView(true);
        this.updateCardNumberStatus();
        PushCenter.shared().addListener(PushEvent.Update_PanResult, (() => {
            ToolUtils.isObjValid(this.node) && (this.stopCountDownActin(), 1 == User.shared().pan_check ? this.updateCheckStatus(false) : this.updateCheckStatus(true), this.updateVerifyView(), this.restoreScrollviewTop(), this.updateRewardList(), 2 == User.shared().pan_check || 3 == User.shared().pan_check ? (3 == User.shared().pan_check && (this.updateCardNumberView("", true, false), this.updateCardNumberStatus()), Utils.shared().hideLoading(), 2 == User.shared().pan_check ? this.onBackView() : this.showVerifyBtnStatus(1)) : 1 != User.shared().pan_check && this.showVerifyBtnStatus(1));
        }), this);
        PushCenter.shared().addListener(PushEvent.changeWebViewHeight, (e => {
            ToolUtils.isObjValid(this.node) && (this._keyboardHei = ToolUtils.isSafeNumber(Number(e)), this.showScrollivewUp(this.cardNumberNode.getChildByName("EditBox")));
        }), this);
        PushCenter.shared().addListener(PushEvent.Close_PanView, (e => {
            ToolUtils.isObjValid(this.node) && this.onBackView();
        }), this);
        PushCenter.shared().addListener(PushEvent.RefreshPanReason, (e => {
            ToolUtils.isObjValid(this.node) && this.updateErrTips(e);
        }), this);
        this.updateRewardList();
    }
    updateRewardList() {
        let e = User.shared().data.kyc_list;
        if (sys.isObjectValid(e) && Array.isArray(e) && e.length > 0) {
            for (let t = 0; t < e.length; t++) {
                if (3 == ToolUtils.isSafeNumber(e[t].type)) {
                    let i = 0, a = 0;
                    if (sys.isObjectValid(e[t].cash) && (i = Number(e[t].cash)), sys.isObjectValid(e[t].bonus) && (a = Number(e[t].bonus)), i > 0 && a > 0) {
                        let e = ToolUtils.format(i18nMgr.shared().getValueByKey("kyc.pan_top_tip"), "₹" + String(i + a) + "*");
                        this.rootNode.getChildByName("top_tip").getComponent(Label).string = e;
                    }
                    else if (i > 0) {
                        let e = ToolUtils.format(i18nMgr.shared().getValueByKey("kyc.pan_top_tip"), "CASH ₹" + String(i));
                        this.rootNode.getChildByName("top_tip").getComponent(Label).string = e;
                    }
                    else if (a > 0) {
                        let e = ToolUtils.format(i18nMgr.shared().getValueByKey("kyc.pan_top_tip"), "BONUS ₹" + String(a));
                        this.rootNode.getChildByName("top_tip").getComponent(Label).string = e;
                    }
                    else {
                        this.rootNode.getChildByName("top_tip").getComponent(Label).string = i18nMgr.shared().getValueByKey("kyc.kyc_top_tip1") || "";
                    }
                    break;
                }
            }
        }
    }
    onDestroy() {
        super.onDestroy();
        TransferPlatform.shared().setSoftInputMode(0);
        TweenTool.stopNodeAction(this.rootNode);
        TweenTool.stopNodeAction(this.node);
        Utils.shared().hideLoading();
        PushCenter.shared().removeListenersByTag(this);
    }
    updateCheckStatus(e = true) {
        e && (0 == User.shared().pan_check || 3 == User.shared().pan_check ? (this.verifyNode.active = true, this.waitNode.active = false) : 1 == User.shared().pan_check && (this.waitNode.active = true, this.verifyNode.active = false));
    }
    updateErrTips(e) {
        if (sys.isObjectValid(e) && e.length > 0) {
            return this.errTipNode.active = true, this.errTipNode.getChildByName("tx").getComponent(Label).string = e, this.errTipNode.getChildByName("tx").getComponent(Label).updateRenderData(true), this.cardNumberNode.setPosition(v3(0, -86.4)), void this.verifyNode.getChildByName("enter_number").setPosition(v3(-286.767, -94.037));
        }
        User.shared().pancard_data && ToolUtils.isSafeString(User.shared().pancard_data.fast_reason).length > 0 ? (this.errTipNode.active = true, this.errTipNode.getChildByName("tx").getComponent(Label).string = ToolUtils.isSafeString(User.shared().pancard_data.fast_reason), this.errTipNode.getChildByName("tx").getComponent(Label).updateRenderData(true), this.cardNumberNode.setPosition(v3(0, -86.4)), this.verifyNode.getChildByName("enter_number").setPosition(v3(-286.767, -94.037))) : (this.errTipNode.active = false, this.errTipNode.getChildByName("tx").getComponent(Label).string = "", this.cardNumberNode.setPosition(v3(0, -106.4)), this.verifyNode.getChildByName("enter_number").setPosition(v3(-286.767, -114.037)));
    }
    updateCardNumberView(e = "", t, i = true) {
        i && (this.cardNumberStr = e, this.cardNumberNode.getChildByName("del_btn").active = false);
        this.cardNumberNode.getChildByName("EditBox").getComponent(EditBox).string = this.cardNumberStr;
        this.cardNumberNode.getChildByName("content").getComponent(Label).string = this.cardNumberStr;
        this.cardNumberNode.getChildByName("EditBox").active = t;
        this.cardNumberNode.getChildByName("content").active = !t;
        this.cardNumberNode.getChildByName("EditBox").getComponent(EditBox).inputMode = EditBox.InputMode.SINGLE_LINE;
        this.cardNumberNode.getChildByName("EditBox").getComponent(EditBox).maxLength = 10;
        i18nMgr.shared().changeLabelLanguage(this.cardNumberNode.getChildByName("EditBox").getComponent(EditBox).placeholderLabel, "Enter aadhaar No.");
    }
    updateCardNumberStatus() {
        if (this.cardNumberNode) {
            let e = this.cardNumberNode.getChildByName("EditBox");
            this.cardNumberStr = ToolUtils.isSafeString(e.getComponent(EditBox).string).toUpperCase();
            e.getComponent(EditBox).string = this.cardNumberStr;
            this.cardNumberStr.length > 0 && (0 == User.shared().pan_check || 3 == User.shared().pan_check) ? this.cardNumberNode.getChildByName("del_btn").active = true : this.cardNumberNode.getChildByName("del_btn").active = false;
            10 == this.cardNumberStr.length ? this.showVerifyBtnStatus(1) : this.showVerifyBtnStatus(0);
        }
    }
    onEditDidBegan(e, t) {
    }
    onEditBoxChanged(e, t, i) {
        "card_number" == i && this.updateCardNumberStatus();
    }
    onEditBoxEnded(e, t) {
        "card_number" == t && this.updateCardNumberStatus();
    }
    showScrollivewUp(e) {
        if (ToolUtils.getIsInRoom()) {
            return;
        }
        let t = v3(0, 0);
        this.node.inverseTransformPoint(t, e.getWorldPosition());
        let i = GameConfig.REAL_SCREEN_HEIGHT;
        ToolUtils.getIsInRoom() && (i = GameConfig.REAL_SCREEN_WIDTH);
        let a = i / 2 + t.y - 34 - 80;
        a < this._keyboardHei ? this.rootNode.setPosition(v3(0, this._keyboardHei - a)) : this.rootNode.setPosition(v3(0, 0));
    }
    restoreScrollviewTop() {
        this.rootNode.setPosition(v3(0, 0));
    }
    updateVerifyView(e = false) {
        this._closed || (3 == User.shared().pan_check && sys.isObjectValid(User.shared().pancard_data) && (this.updateErrTips(), ToolUtils.isSafeString(User.shared().pancard_data.card).length > 0 && (this.updateCardNumberView(User.shared().pancard_data.card, true), this.updateCardNumberStatus())), 0 == User.shared().pan_check || 3 == User.shared().pan_check ? (this.verify_btn.getComponent(Button).interactable = true, 0 == User.shared().pan_check ? i18nMgr.shared().changeLabelLanguage(this.verify_btn.getChildByName("wz").getComponent(Label), "kyc.verify", true) : (Utils.shared().hideLoading(), i18nMgr.shared().changeLabelLanguage(this.verify_btn.getChildByName("wz").getComponent(Label), "kyc.resubmit", true))) : this.verify_btn.getComponent(Button).interactable = false);
    }
    onButtonClick(e, t) {
        if (SoundManager.shared().playFx("click"), "back" == t || "close" == t) {
            this.onCloseLogic();
        }
        else if ("verify" == t) {
            if (sys.now() - this._lastClick < 500) {
                return;
            }
            this._lastClick = sys.now();
            let e = ToolUtils.isSafeString(this.cardNumberStr);
            if (10 !== e.length) {
                return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text78"), 2);
            }
            this.showVerifyBtnStatus(2);
            this.verify_btn.getChildByName("wz").getComponent(Label).string = i18nMgr.shared().getValueByKey("kyc.verity_pending");
            this.stopCountDownActin();
            this._countDownAction = TweenTool.delayAct(this.node, (() => {
                Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text37"), 3);
                this.revertBtnStatus(1);
            }), 30, true);
            this.cardNumberNode.getChildByName("del_btn").active = false;
            HttpManager.shared().doPanFastSave(e, this.listenSubmitCall.bind(this));
        }
        else if ("check" == t) {
            this.onCloseLogic();
        }
        else if ("feedback" == t) {
            Utils.shared().doJumpLogic(PushEvent.JUMP_TO_FEEDBACK);
        }
        else if ("cardnumber_del" == t) {
            let e = this.cardNumberNode.getChildByName("EditBox");
            e.getComponent(EditBox).string = "";
            e.getComponent(EditBox).blur();
            this.updateCardNumberStatus();
        }
        else if ("more_verify" == t) {
            ToolUtils.getIsInRoom() && (User.shared().BackHallOpenModule = 3, User.shared().isShowPopList = false, PushCenter.shared().pushEvent(GameConfig.BackToHall));
            this.onCloseLogic();
        }
        else if ("check_more" == t) {
            ToolUtils.getIsInRoom() ? (User.shared().BackHallOpenModule = 3, User.shared().isShowPopList = false, PushCenter.shared().pushEvent(GameConfig.BackToHall)) : Utils.shared().showKycView2();
        }
        else if ("kefu" == t) {
            if (1 == User.shared().temp_pingbi.feedback) {
                return void Utils.shared().showToast("Coming soon", 2);
            }
            let e = { sourceType: CommDefine.TawkUser_Feedback_Source.Withdraw, groupType: CommDefine.TawkUser_Feedback_Source.Withdraw_Group.Pan };
            Utils.shared().doJumpLogic(PushEvent.JUMP_TO_FEEDBACK, e);
        }
    }
    revertBtnStatus(e) {
        this.showVerifyBtnStatus(e);
        this.updateVerifyView();
    }
    listenSubmitCall(e, t, i) {
        if (200 !== i) {
            ToolUtils.isObjValid(this.node) && (Utils.shared().hideLoading(), Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text37"), 2), this.stopCountDownActin(), this.revertBtnStatus(1));
        }
        else {
            try {
                let e = ToolUtils.parseJson(t);
                if (0 === e.ret) {
                    if (sys.isObjectValid(e.data.pan_check) && (User.shared().pan_check = e.data.pan_check), sys.isObjectValid(e.data.name) && (User.shared().pancard_data.name = e.data.name), sys.isObjectValid(e.data.photo_frontend) && (User.shared().pancard_data.photo_frontend = e.data.photo_frontend), sys.isObjectValid(e.data.card) && (User.shared().pancard_data.card = e.data.card), PushCenter.shared().pushEvent(PushEvent.Update_Pan, User.shared().pan_check), 1 == User.shared().pan_check) {
                        if (sys.isObjectValid(e.data.msg) && e.data.msg.length > 0) {
                            Utils.shared().showToast(e.data.msg, 3);
                        }
                        else {
                            let e = i18nMgr.shared().getValueByKey("kyc.kyc_submit_tip");
                            Utils.shared().showToast(e, 3);
                        }
                        this.cardNumberNode.getChildByName("del_btn").active = false;
                        this.updateCardNumberView("", false, false);
                        this.showVerifyBtnStatus(2);
                    }
                    1 == User.shared().pan_check && (this.verify_btn.getComponent(Button).interactable = false, i18nMgr.shared().changeLabelLanguage(this.verify_btn.getChildByName("wz").getComponent(Label), "kyc.verity_pending", true));
                    sys.isObjectValid(e.data.loading_seconds) && Number(e.data.loading_seconds) > 0 ? ToolUtils.isObjValid(this.node) && (1 == User.shared().pan_check && (this.verify_btn.getComponent(Button).interactable = false, i18nMgr.shared().changeLabelLanguage(this.verify_btn.getChildByName("wz").getComponent(Label), "kyc.verity_pending", true)), this.stopCountDownActin(), this._countDownAction = TweenTool.delayAct(this.node, (() => {
                        Utils.shared().hideLoading();
                        PushCenter.shared().pushEvent(PushEvent.Update_PanResult);
                    }), Number(e.data.loading_seconds), true)) : (2 != User.shared().pan_check && 1 != User.shared().pan_check || (User.shared().pancard_data.reason = "", User.shared().pancard_data.fast_reason = "", ToolUtils.isObjValid(this.node) && (this.stopCountDownActin(), 2 == User.shared().pan_check && (sys.isObjectValid(e.data.reward_list) && e.data.reward_list.length > 0 ? Utils.shared().showKycVerifySucTip(e.data.reward_list, i18nMgr.shared().getValueByKey("kyc.KYC_Verify_Suc")) : Utils.shared().showToast(i18nMgr.shared().getValueByKey("kyc.submit_success"), 2), ToolUtils.isObjValid(this.node) && this.onBackView()))), PushCenter.shared().pushEvent(PushEvent.Update_PanResult));
                }
                else if (4027 === e.ret) {
                    User.shared().data.pan_submit_left_hour = e.data.submit_left_seconds;
                    let t = { is_pan: 1 };
                    Utils.shared().doJumpLogic(PushEvent.Custom_TO_KycLimitTip, t);
                    TweenTool.delayAct(this.node, (() => {
                        this.onBackView();
                    }), 1, true);
                }
                else {
                    ToolUtils.isObjValid(this.node) && (this.stopCountDownActin(), this.revertBtnStatus(1), e.desc && e.desc.length > 0 && Utils.shared().showToast(e.desc, 2));
                }
            }
            catch (e) {
                ToolUtils.isObjValid(this.node) && (this.stopCountDownActin(), this.revertBtnStatus(1));
            }
        }
    }
    showVerifyBtnStatus(e) {
        let t = this.verify_btn.getChildByName("anim_waiting");
        1 == e ? (this.verify_btn.getComponent(Button).interactable = true, this.verify_btn.getChildByName("di").getComponent(Sprite).spriteFrame = this.verifyBtnDiImags[1], this.verify_btn.getChildByName("di").active = true, t.active = false, this.verify_btn.getChildByName("wz").getComponent(Label).color = color(255, 255, 255), this.verify_btn.getChildByName("wz").getComponent(LabelShadow).color = CommDefine.shadowcolor.green, this.verify_btn.getChildByName("wz").getComponent(LabelShadow).enabled = true, Utils.updateLabelMaterial(this.verify_btn.getChildByName("wz"), CommDefine.gradient.btn_green)) : 0 == e ? (this.verify_btn.getComponent(Button).interactable = false, this.verify_btn.getChildByName("di").getComponent(Sprite).spriteFrame = this.verifyBtnDiImags[0], this.verify_btn.getChildByName("di").active = true, t.active = false, this.verify_btn.getChildByName("wz").getComponent(Label).color = color(255, 255, 255), this.verify_btn.getChildByName("wz").getComponent(LabelShadow).enabled = true, this.verify_btn.getChildByName("wz").getComponent(LabelShadow).color = CommDefine.shadowcolor.gray, Utils.updateLabelMaterial(this.verify_btn.getChildByName("wz"), CommDefine.gradient.btn_gray)) : 2 == e && (this.verify_btn.getComponent(Button).interactable = false, t.active = true, this.verify_btn.getChildByName("wz").getComponent(LabelShadow).enabled = true, this.verify_btn.getChildByName("wz").getComponent(LabelShadow).color = CommDefine.shadowcolor.gray, this.verify_btn.getChildByName("di").active = true, this.verify_btn.getChildByName("di").getComponent(Sprite).spriteFrame = this.verifyBtnDiImags[0], Utils.updateLabelMaterial(this.verify_btn.getChildByName("wz"), CommDefine.gradient.btn_gray));
    }
    stopCountDownActin() {
        this._countDownAction && (TweenTool.stopAction(this._countDownAction), this._countDownAction = null);
    }
    stopIdentityActin() {
        this._identitytimeAction && (TweenTool.stopAction(this._identitytimeAction), this._identitytimeAction = null);
    }
    onCloseLogic() {
        PushCenter.shared().pushEvent(PushEvent.onKycGuideRemove);
        this.stopIdentityActin();
        this.stopCountDownActin();
        this.isNext && PushCenter.shared().pushEvent(PushEvent.Update_NextPopActivity);
        this.onRemoveWindow();
    }
    onRemoveWindow() {
        this._closed || ToolUtils.isObjValid(this.node) && (this._closed = true, this.node.destroy());
    }
    onBackView() {
        this.onCloseLogic();
    }
}
