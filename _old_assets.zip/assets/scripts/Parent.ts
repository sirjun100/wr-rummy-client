// @ts-nocheck
// Recovered from index.js:335
import { _decorator, Component, sys, v3, view } from "cc";
import PushCenter from "./PushCenter";
import TweenTool from "./TweenTool";
import GameConfig from "./GameConfig";
import Server from "./Server";
const { ccclass } = _decorator;
export let AdapDirection;
(AdapDirection = undefined);
(!function (t) {
    t[t.Left = 0] = "Left";
    t[t.Right = 1] = "Right";
    t[t.Up = 2] = "Up";
    t[t.Down = 3] = "Down";
}(AdapDirection || (AdapDirection = AdapDirection = {})));
@ccclass("Parent")
export default class Parent extends Component {
    onLoad() {
    }
    start() {
    }
    startShowAnim(t) {
        t.setScale(v3(0.2, 0.2, 0.2));
        TweenTool.scaleTo(t, 0.2, v3(1, 1, 1), "backOut", true, (() => {
            t.setScale(v3(1, 1, 1));
        }));
    }
    baseExe() {
        this.login();
        this.regEvent();
    }
    login() {
    }
    regEvent() {
    }
    onDestroy() {
        Server.shared().clearEventByTarget(this);
        PushCenter.shared().removeListenersByTag(this);
        this.unscheduleAllCallbacks();
    }
    onOpen() {
    }
    onClose() {
    }
    onError() {
    }
    resetUiPos(t, e, s = false, E, a, r) {
        let _ = t.position, R = (GameConfig.REAL_SCREEN_WIDTH - GameConfig.CONFIG_SCREEN_WIDTH) / 2, l = (GameConfig.REAL_SCREEN_HEIGHT - GameConfig.CONFIG_SCREEN_HEIGHT) / 2;
        s && (R = (GameConfig.REAL_SCREEN_HEIGHT - GameConfig.CONFIG_SCREEN_HEIGHT) / 2, l = 0);
        let C = sys.getSafeAreaRect().y;
        C <= 0 && sys.getSafeAreaRect().x > 0 && (C = sys.getSafeAreaRect().x);
        E || (E = 1);
        let H = R * E;
        s ? e == AdapDirection.Left ? (a && (H -= C), view.getVisibleSize().width > GameConfig.CONFIG_SCREEN_HEIGHT && t.setPosition(v3(_.x - H, _.y, _.z))) : e == AdapDirection.Right ? (r && (H -= C), view.getVisibleSize().width > GameConfig.CONFIG_SCREEN_HEIGHT && t.setPosition(v3(_.x + H, _.y, _.z))) : e == AdapDirection.Up ? (H = (GameConfig.REAL_SCREEN_WIDTH - GameConfig.CONFIG_SCREEN_WIDTH) / 2, H *= E, t.setPosition(v3(_.x, _.y + H, _.z))) : e == AdapDirection.Down && (H = (GameConfig.REAL_SCREEN_WIDTH - GameConfig.CONFIG_SCREEN_WIDTH) / 2, H *= E, t.setPosition(v3(_.x, _.y - H, _.z))) : (H = l * E, e == AdapDirection.Up ? (a && (H -= C), t.setPosition(v3(_.x, _.y + H, _.z))) : e == AdapDirection.Down && t.setPosition(v3(_.x, _.y - H, _.z)));
    }
    setUiEdgeDistance(t, e, s, o = false) {
        let n = GameConfig.REAL_SCREEN_WIDTH / 2, E = GameConfig.REAL_SCREEN_HEIGHT / 2;
        o && (n = GameConfig.REAL_SCREEN_HEIGHT / 2, E = GameConfig.REAL_SCREEN_WIDTH / 2);
        let a = t.position;
        s == AdapDirection.Left ? t.setPosition(v3(e - n, a.y, a.z)) : s == AdapDirection.Right ? t.setPosition(v3(n - e, a.y, a.z)) : s == AdapDirection.Up ? t.setPosition(v3(a.x, E - e, a.z)) : s == AdapDirection.Down && t.setPosition(v3(a.x, e - E, a.z));
    }
}
