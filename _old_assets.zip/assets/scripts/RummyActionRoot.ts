// @ts-nocheck
// Recovered from index.js:415
import { _decorator, Button, color, game, instantiate, Label, Node, NodePool, Overflow, ProgressBar, ScrollView, size, Size, sp, Sprite, SpriteAtlas, SpriteFrame, sys, tween, UIOpacity, UITransform, v3, Vec3 } from "cc";
import Utils from "./Utils";
import RummyDataManager, { RUMMY_GAME_TYPE, RUMMY_MATCH_MODE, RUMMY_MATCH_TYPE } from "./RummyDataManager";
import { TLog } from "./TLog";
import Parent, { AdapDirection } from "./Parent";
import PushCenter from "./PushCenter";
import GameConfig from "./GameConfig";
import User from "./User";
import TweenTool from "./TweenTool";
import RummyCardConstant from "./RummyCardConstant";
import PushEvent from "./PushEvent";
import CommDefine from "./CommDefine";
import SoundManager from "./SoundManager";
import i18nMgr from "./i18nMgr";
import TableViewUtils from "./TableViewUtils";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("RummyActionRoot")
export default class RummyActionRoot extends Parent {
    @property([SpriteFrame])
    public taskSprite: SpriteFrame[] = [];
    @property([SpriteFrame])
    public rewardIconImags: SpriteFrame[] = [];
    @property(Node)
    public flyGoldNode: Node = null;
    @property(Node)
    public flyGoldAnimNode: Node = null;
    @property(ScrollView)
    public matchRankScrollview: ScrollView = null;
    @property([SpriteFrame])
    public matchRewardTabImages: SpriteFrame[] = [];
    @property([SpriteFrame])
    public ticket_images: SpriteFrame[] = [];
    @property(SpriteAtlas)
    public rewardAtlas: SpriteAtlas = null;
    @property(Node)
    public rankItemNode: Node = null;
    @property(SpriteFrame)
    public rankFrame: SpriteFrame = [];
    public tid_key: string = "";
    public operate_xs: any[] = [356, 532];
    public _matchRankPos: Vec3 = new Vec3;
    public _bReadyShow: boolean = false;
    public _bStartShow: boolean = false;
    public _bTouchAuto: boolean = false;
    public _bLongTouch: boolean = false;
    public clickDelayAct: any = null;
    public rank_progress: number = 0;
    public fly_gold_index: number = 1;
    public fly_bonus_index: number = 1;
    public flyGolds: any[] = [];
    public fly_start_postion: Vec3 = new Vec3;
    public flyGoldPool: any = null;
    public flyGoldNum: number = 10;
    public flyGoldEndPositions: any[] = [];
    public race_reward_tabIndex: number = 0;
    public canGetTreaHuntAward: boolean = false;
    public treaHuntAwardData: any = null;
    public rewardNames: any[] = ["reward_watch.png"];
    public isShowPlayBtn: boolean = false;
    public rewardItems: any[] = [];
    public rankTableView: any = null;
    public doubleChooseTime: number = 0;
    public doubleTimeAction: any = null;
    public reward_infos: any = null;
    onLoad() {
        this.adapptationScreen();
        let e = this.node.getChildByName("topNode").getChildByName("shop_btn");
        ToolUtils.isObjValid(e) && (e.active = false);
        this.flyGoldPool = new NodePool("RummyFLyGold");
        this.dealMultipleLanguages();
        let t = [this.rankItemNode];
        this.rankTableView = this.node.addComponent(TableViewUtils);
        this.rankTableView.init([], this.matchRankScrollview.node, t, this.initRankItem.bind(this), 1, 42, this.scrollRefreshCallBack.bind(this));
    }
    dealMultipleLanguages() {
        2 == i18nMgr.shared().language && (this.node.getChildByName("operate_bg").getChildByName("drop_btn").getChildByName("label").getComponent(Label).fontSize = 44, this.node.getChildByName("operate_bg").getChildByName("drop_btn").getChildByName("label").getComponent(Label).overflow = Overflow.NONE, this.node.getChildByName("copy_btn").getChildByName("Text").getComponent(Label).fontSize = 40, this.node.getChildByName("copy_btn").getChildByName("Text").getComponent(Label).lineHeight = 48);
    }
    onEnable() {
        let e = this.node.getChildByName("operate_bg").getChildByName("auto_group_btn");
        e.on(Node.EventType.TOUCH_START, this.onTouchBegan, this);
        e.on(Node.EventType.TOUCH_MOVE, this.onTouchMoved, this);
        e.on(Node.EventType.TOUCH_END, this.onTouchEnded, this);
    }
    onDisable() {
        let e = this.node.getChildByName("operate_bg").getChildByName("auto_group_btn");
        e.off(Node.EventType.TOUCH_START, this.onTouchBegan, this);
        e.off(Node.EventType.TOUCH_MOVE, this.onTouchMoved, this);
        e.off(Node.EventType.TOUCH_END, this.onTouchEnded, this);
    }
    start() {
        this.node.getChildByName("race_reward_di").getPosition(this._matchRankPos);
    }
    onDestroy() {
        super.onDestroy();
        this.flyGoldPool.clear();
        RummyDataManager.shared().stopTweenAction(this.doubleTimeAction);
        this.doubleTimeAction = null;
        this.unscheduleAllCallbacks();
        PushCenter.shared().removeListenersByTag(this);
    }
    resetAll() {
        this.changeTaskAnimVisible(false);
        this.initShopBtn();
        this.changMatchLevelBtnVisibile();
        this.changeFinishBtnStatus(false);
        this.changeGroupBtnStatus(false);
        this.changeDiscardBtnStatus(false);
        this.changeSortBtnStatus(false);
        this.changeSwitchBtnStatus(false);
        this.changeOperateBgState(false);
        this.changeDirectionBtnStatus(true);
        this.changeDropBtnStatus(false);
        this.setMatch_reward_btnVisible(false);
        this.changeRaceRewardDiVisible(false);
        this.changeBestJokerStatus(false);
        this.changePlayBtnStatus(false);
    }
    onGameStartReset() {
        this.changeOperateBgState(false);
        this.changeGroupBtnStatus(false);
        this.changeFinishBtnStatus(false);
        this.changeDropBtnStatus(false);
        this.changeSwitchBtnStatus(false);
        this.changeAutoGroupBtnStatus(false);
        this.hidePrivateBtn();
        this.hideStartBtn();
        this.hideReadyBtn();
        this.changeDirectionBtnStatus(false);
        this.changeBestJokerStatus(false);
    }
    onPickUpReset(e, t) {
        this.changeGroupBtnStatus(false);
        this.changeDiscardBtnStatus(false);
        this.changeAutoGroupBtnStatus(true);
        this.changeFinishBtnStatus(false);
        this.changeDropBtnStatus(false);
        this.updateDropNum(e);
        this.changeSortBtnStatus(t);
    }
    onDecaredReset() {
        this.changeDropBtnStatus(false);
        this.changeGroupBtnStatus(false);
        this.changeFinishBtnStatus(false);
        this.changeSwitchBtnStatus(false);
        this.changeDiscardBtnStatus(false);
        this.changeAutoGroupBtnStatus(false);
    }
    onTouchBegan(e) {
        this._bTouchAuto = true;
        this._bLongTouch = false;
    }
    onTouchMoved(e) {
        let t = v3(0, 0), i = e.getUILocation(), a = this.node.getChildByName("operate_bg").getChildByName("auto_group_btn");
        a.inverseTransformPoint(t, v3(i.x, i.y, 0));
        a.getComponent(UITransform).contentSize;
    }
    onTouchEnded(e) {
        if (this._bTouchAuto && !this._bLongTouch) {
            this._bTouchAuto = false;
            this.clickDelayAct && TweenTool.stopAction(this.clickDelayAct);
            this.clickDelayAct = null;
            let e = { tid_key: this.tid_key, eventData: "auto_group_long" };
            PushCenter.shared().pushEvent(PushEvent.updateAutoGroup, e);
        }
    }
    changeBuddyRankBtnVisibile() {
        let e = this.node.getChildByName("topNode").getChildByName("topRightBtns").getChildByName("buddy_rank_btn");
        e && (User.shared().roomTable && 1 === User.shared().roomTable.pri_rk_open ? e.active = true : e.active = false);
    }
    updateGullakBtnStatus(e, t, i) {
        let a = this.node.getChildByName("topNode").getChildByName("topRightBtns").getChildByName("gullak_btn");
        if (ToolUtils.isObjValid(a) && (a.active = 1 == e, 1 == e)) {
            let e = a.getChildByName("anim").getComponent(sp.Skeleton);
            e.clearTracks();
            e.setToSetupPose();
            i ? (e.setAnimation(0, "2", false), e.setCompleteListener((() => {
                e.setCompleteListener(null);
                e.clearTracks();
                e.setToSetupPose();
                0 == t ? e.setAnimation(0, "0", true) : e.setAnimation(0, "1", true);
            }))) : 0 == t ? e.setAnimation(0, "0", true) : e.setAnimation(0, "1", true);
        }
    }
    changMatchLevelBtnVisibile() {
        let e = this.node.getChildByName("topNode").getChildByName("level_btn");
        e && (RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType == RUMMY_GAME_TYPE.MATCH && RummyDataManager.shared().rummyInfos.get(this.tid_key).gameMatchType == RUMMY_MATCH_TYPE.BASEMONEYUP ? e.active = true : e.active = false);
    }
    changeMatchRankBtnVisibile(e) {
        let t = this.node.getChildByName("match_tips_btn");
        ToolUtils.isObjValid(t) && (t.active = e);
    }
    setMatchRankBtnVisible(e) {
        let t = this.node.getChildByName("match_rank_btn");
        ToolUtils.isObjValid(t) && (t.active = e);
    }
    resetView() {
        let e = this.node.getChildByName("topNode").getChildByName("history_btn");
        ToolUtils.isObjValid(e) && (e.active = false);
        let t = this.node.getChildByName("topNode").getChildByName("pool_total_history_btn");
        ToolUtils.isObjValid(t) && (t.active = false);
    }
    showHeadBtn(e, t) {
        let i = this.node.getChildByName("head_click" + e);
        ToolUtils.isObjValid(i) && (i.setPosition(t), i.getComponent(Button).enabled = true);
    }
    refreshHeadClickPosition() {
        if (4 == RummyDataManager.shared().rummyInfos.get(this.tid_key).pnum) {
            for (let e = 1; e < 4; e++) {
                let t = this.node.getChildByName("head_click" + e);
                t && t.setPosition(RummyCardConstant.fourPlayerPosVec[e]);
            }
        }
    }
    changeOperateBgState(e) {
        if (e) {
            ;
        }
        else {
            let e = this.node.getChildByName("operate_bg").getChildByName("finish_btn");
            e && (e.active = false);
            let t = this.node.getChildByName("operate_bg").getChildByName("group_btn1");
            t && (t.active = false);
            let i = this.node.getChildByName("operate_bg").getChildByName("discard_btn");
            i && (i.active = false);
            this.changeDropBtnStatus(false);
            this.changeGroupBtnStatus(false);
            this.changeFinishBtnStatus(false);
            this.changeDiscardBtnStatus(false);
            this.changeSortBtnStatus(false);
            this.changeAutoGroupBtnStatus(false);
        }
    }
    changeDropBtnStatus(e) {
        let t = RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType;
        if ((t == RUMMY_GAME_TYPE.DEALS || t == RUMMY_GAME_TYPE.PRI_DEAL) && 0 == RummyDataManager.shared().rummyInfos.get(this.tid_key).dealsrummyIsCanFold) {
            return void (this.node.getChildByName("operate_bg").getChildByName("drop_btn").active = false);
        }
        let i = this.node.getChildByName("operate_bg").getChildByName("drop_btn");
        i && (i.getComponent(Button).enabled = e, i.active = e);
    }
    changeFinishBtnStatus(e) {
        let t = this.node.getChildByName("operate_bg").getChildByName("finish_btn");
        t && (t.active = e);
    }
    changeCenterFinishBtnStatus(e) {
        let t = this.node.getChildByName("finish_btn");
        t && (t.active = e);
    }
    changeGroupBtnStatus(e) {
        let t = this.node.getChildByName("operate_bg").getChildByName("group_btn1");
        t && (t.getComponent(Button).enabled = true, t.active = e);
    }
    changeDiscardBtnStatus(e) {
        let t = this.node.getChildByName("operate_bg").getChildByName("discard_btn");
        t && (t.active = e);
    }
    changeSortBtnStatus(e) {
        let t = this.node.getChildByName("operate_bg").getChildByName("sort_btn");
        if (t) {
            let i = this.node.getChildByName("operate_bg").getChildByName("group_btn1");
            if (e) {
                let t = this.node.getChildByName("operate_bg").getChildByName("discard_btn");
                (i && i.active || t && t.active) && (e = false);
            }
            t.active = e;
        }
    }
    changeAutoGroupBtnStatus(e) {
        let t = this.node.getChildByName("operate_bg").getChildByName("auto_group_btn");
        if (t) {
            if (null != e) {
                if (e) {
                    let t = this.node.getChildByName("operate_bg").getChildByName("sort_btn"), i = this.node.getChildByName("operate_bg").getChildByName("group_btn1"), a = this.node.getChildByName("operate_bg").getChildByName("discard_btn");
                    (t && t.active || i && i.active || a && a.active) && (e = false);
                    1 != RummyDataManager.shared().rummyInfos.get(this.tid_key).isAbleAutoGroup && (e = false);
                }
                t.active = e;
            }
            const model = RummyDataManager.shared().rummyInfos.get(this.tid_key);
            const status = model.autoGroupDesiredStatus == null ? model.autoGroupStatus : model.autoGroupDesiredStatus;
            1 == status ? (t.getChildByName("auto_sort").active = true, t.getChildByName("auto_sort").getChildByName("autogou").active = true, t.getChildByName("hold_sort").active = false) : (t.getChildByName("auto_sort").active = true, t.getChildByName("auto_sort").getChildByName("autogou").active = false, t.getChildByName("hold_sort").active = false);
        }
    }
    changeAutoGroupTipsStatus(e, t) {
        let i = this.node.getChildByName("operate_bg").getChildByName("auto_group_btn");
        if (i) {
            let a = i.getChildByName("tips");
            if (null != t && (a.getChildByName("layout").getChildByName("check_bg").getChildByName("check").active = t), TweenTool.stopNodeAction(a), a.active = e, a.getComponent(UIOpacity).opacity = 255, e) {
                let e = TweenTool.delayAct(a, null, 5, false), t = new Vec3;
                a.getPosition(t);
                let i = TweenTool.moveToByFade(a, 0.5, t, 1, 0, false);
                TweenTool.sequence(a, true, (() => {
                    this.isAutoGroupTipsCheck() && ToolUtils.saveData("autoSortCount", String(0));
                }), e, i);
            }
            else {
                this.isAutoGroupTipsCheck() && ToolUtils.saveData("autoSortCount", String(0));
            }
        }
    }
    isAutoGroupTipsCheck() {
        let e = this.node.getChildByName("operate_bg").getChildByName("auto_group_btn");
        if (e) {
            return e.getChildByName("tips").getChildByName("layout").getChildByName("check_bg").getChildByName("check").active;
        }
    }
    isSwitchBtnVisbile() {
        return this.node.getChildByName("switch_btn2").active;
    }
    changeSwitchBtnStatus(e) {
        let t = this.node.getChildByName("switch_btn"), i = this.node.getChildByName("switch_btn2");
        if (t) {
            t.setSiblingIndex(20);
            let a = RummyDataManager.shared().rummyInfos.get(this.tid_key);
            0 != a.crashModel || a.gameRummyType != RUMMY_GAME_TYPE.POINTS && a.gameRummyType != RUMMY_GAME_TYPE.MULTIPLE ? (t.active = e, i.active = false, this.changePlayBtnStatus(false)) : (i.active = e, t.active = false, this.isShowPlayBtn ? i.setPosition(v3(-165, -166)) : i.setPosition(v3(0, -166)), e || this.changePlayBtnStatus(false));
            e && this.changeSortBtnStatus(false);
        }
    }
    changePlayBtnStatus(e) {
        let t = this.node.getChildByName("play_btn");
        if (t) {
            t.active = e;
            let i = this.node.getChildByName("switch_btn2");
            i && (e ? i.setPosition(v3(-165, -166)) : i.setPosition(v3(0, -166)));
            this.isShowPlayBtn = e;
        }
    }
    getIsPlayBtnVisible() {
        return this.isShowPlayBtn;
    }
    refreshPlayBtnNum(e) {
        let t = this.node.getChildByName("play_btn");
        if (t) {
            let i = "Play (Value:${0})";
            t.getChildByName("Label").getComponent(Label).string = ToolUtils.format(i, ToolUtils.parse_double(String(e), -1));
        }
    }
    changeQiPaiTableStatus(e) {
        let t = this.node.getChildByName("biaoge");
        t && (t.active = e);
    }
    changeRecodeBtnStatus(e) {
        e = !!e;
        this.node.getChildByName("topNode").getChildByName("match_reward_btn").active && (e = false);
        let t = this.node.getChildByName("topNode").getChildByName("history_btn");
        if (t) {
            t.active = e;
            t.getComponent(Button).enabled = e;
        }
        let i = RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType;
        if (i === RUMMY_GAME_TYPE.DEALS || i === RUMMY_GAME_TYPE.POOL || i === RUMMY_GAME_TYPE.PRI_POOL || i === RUMMY_GAME_TYPE.PRI_DEAL) {
            let t = this.node.getChildByName("topNode").getChildByName("pool_total_history_btn");
            if (t) {
                t.active = e;
                t.getComponent(Button).enabled = e;
            }
        }
    }
    changeOpenCardStatus(e, t) {
        let i = this.node.getChildByName("open_btn");
        if (i) {
            i.active = e;
            i.getComponent(Button).enabled = e;
            t && (t.node.getChildByName("rootNode").getChildByName("card_node").getChildByName("open_btn_img_show").active = e);
        }
    }
    changeSwitchJokerStatus(e, t) {
        if (1 != RummyDataManager.shared().rummyInfos.get(this.tid_key).is_bump) {
            return;
        }
        let i = this.node.getChildByName("bump_switch_btn");
        if (i) {
            i.active = e;
            i.getComponent(Button).enabled = e;
            t && (t.node.getChildByName("rootNode").getChildByName("card_node").getChildByName("bump_switch_btn_img").active = e);
        }
    }
    changeBestJokerStatus(e, t) {
        if (1 != RummyDataManager.shared().rummyInfos.get(this.tid_key).is_bump) {
            return;
        }
        let i = this.node.getChildByName("bump_best_btn");
        if (i) {
            i.active = e;
            i.getComponent(Button).enabled = e;
            t && (t.node.getChildByName("rootNode").getChildByName("card_node").getChildByName("bump_best_bubble").active = e);
        }
    }
    updateDropNum(e) {
        let t = this.node.getChildByName("operate_bg").getChildByName("drop_btn");
        if (t) {
            let i = t.getChildByName("goldNum");
            if (i) {
                let t = e + "";
                1 == RummyDataManager.shared().rummyInfos.get(this.tid_key).crashModel && (t = ToolUtils.parse_ChipNum2(t));
                Utils.shared().setStr(i, t);
            }
        }
    }
    setMopaiBtnInteractable(e) {
        const info = RummyDataManager.shared().rummyInfos.get(this.tid_key);
        if (info.in_choose_double === 1) e = false;
        this.node.getChildByName("mopai_btn").getComponent(Button).interactable = e;
        let t = 0 == info.gameRummyMode && e;
        this.node.getChildByName("qipai_btn").getComponent(Button).interactable = t;
    }
    changeDirectionBtnStatus(e) {
    }
    hideReadyBtn() {
        this.node.getChildByName("ready_btn").active = false;
        this._bReadyShow = false;
    }
    showReadyBtn() {
        let e = RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType;
        e == RUMMY_GAME_TYPE.PRIVATE || e == RUMMY_GAME_TYPE.PRI_POOL || e == RUMMY_GAME_TYPE.PRI_DEAL ? (this.node.getChildByName("ready_btn").active = true, this._bReadyShow = true) : this._bReadyShow = false;
    }
    hideStartBtn() {
        this.node.getChildByName("start_btn").active = false;
        this._bStartShow = false;
    }
    showStartBtn() {
        let e = RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType;
        e == RUMMY_GAME_TYPE.PRIVATE || e == RUMMY_GAME_TYPE.PRI_POOL || e == RUMMY_GAME_TYPE.PRI_DEAL ? (this.node.getChildByName("start_btn").active = true, this._bStartShow = true) : this._bStartShow = false;
    }
    showInviteBtn() {
        let e = RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType;
        e != RUMMY_GAME_TYPE.PRIVATE && e != RUMMY_GAME_TYPE.PRI_POOL && e != RUMMY_GAME_TYPE.PRI_DEAL || (this.node.getChildByName("invite_btn").active = true);
    }
    showCopyBtn() {
        let e = RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType;
        e != RUMMY_GAME_TYPE.PRIVATE && e != RUMMY_GAME_TYPE.PRI_POOL && e != RUMMY_GAME_TYPE.PRI_DEAL || (this.node.getChildByName("copy_btn").active = true);
    }
    hidePrivateBtn() {
        this.node.getChildByName("start_btn").active = false;
        this._bStartShow = false;
        this.node.getChildByName("invite_btn").active = false;
        this.node.getChildByName("copy_btn").active = false;
    }
    reshow_btn() {
        this.node.getChildByName("ready_btn").active = this._bReadyShow;
        this.node.getChildByName("start_btn").active = this._bStartShow;
    }
    showPrizeBtn() {
        this.node.getChildByName("prizeBtn").active = true;
    }
    initActionView() {
        this.changeOpenCardStatus(false);
        this.changeSwitchJokerStatus(false);
        this.node.getChildByName("topNode").getChildByName("history_btn").active = false;
        this.node.getChildByName("topNode").getChildByName("pool_total_history_btn").active = false;
        this.tid_key == CommDefine.NewerGuideRoomTidkey && (this.hidePrivateBtn(), this.node.getChildByName("topNode").getChildByName("refresh_btn").active = false);
    }
    initShopBtn() {
    }
    ishudongshow(e) {
        let t = this.node.getChildByName("chat_btn").getComponent(Sprite).color;
        e ? (this.node.getChildByName("chat_btn").getComponent(Button).interactable = true, this.node.getChildByName("chat_btn").getComponent(Sprite).color = color(t.r, t.g, t.b, 255)) : (this.node.getChildByName("chat_btn").getComponent(Button).interactable = false, this.node.getChildByName("chat_btn").getComponent(Sprite).color = color(t.r, t.g, t.b, 77));
    }
    isShowDealsPrizeBtn(e) {
        this.node.getChildByName("topNode").getChildByName("dealsPrizebtn").active = e;
    }
    changeTaskRedDotVisible(e) {
        let t = this.node.getChildByName("topNode").getChildByName("topRightBtns").getChildByName("task_btn");
        if (t) {
            let i = t.getChildByName("hdts");
            i && (i.active = e);
        }
    }
    changeTaskBtnVisible(e, t) {
        let i = this.node.getChildByName("topNode").getChildByName("topRightBtns").getChildByName("task_btn");
        if (i) {
            i.active = e;
            i.getChildByName("di").active = 0 == t;
            1 == t ? 1 == User.shared().showNewDailyTask || 1 == User.shared().showBackTask ? (i.getChildByName("ic").getComponent(Sprite).spriteFrame = this.taskSprite[2], i.getChildByName("di").active = true) : i.getChildByName("ic").getComponent(Sprite).spriteFrame = this.taskSprite[1] : i.getChildByName("ic").getComponent(Sprite).spriteFrame = this.taskSprite[t];
            let a = 0 == t ? "task" : "daily_task";
            i.getComponent(Button).clickEvents[0].customEventData = a;
        }
    }
    changeTaskTipsVisible(e) {
        let t = this.node.getChildByName("topNode").getChildByName("topRightBtns").getChildByName("task_btn").getChildByName("tips");
        t && (t.active = e, 2 != i18nMgr.shared().language && 3 != i18nMgr.shared().language || (t.getComponent(UITransform).contentSize = new Size(446, 100), t.setPosition(v3(-151, -70))));
    }
    getTaskTipsVisible() {
        let e = this.node.getChildByName("topNode").getChildByName("topRightBtns").getChildByName("task_btn").getChildByName("tips");
        return !!e && e.active;
    }
    changeTaskAnimVisible(e) {
        let t = this.node.getChildByName("topNode").getChildByName("topRightBtns").getChildByName("task_btn");
        if (t) {
            let i = t.getChildByName("ic"), a = t.getChildByName("ic_anim"), n = t.getChildByName("hdts");
            if (e) {
                i.active = false;
                a.active = true;
                let e = a.getComponent(sp.Skeleton);
                e.setToSetupPose();
                e.setAnimation(0, "fj_dgdh", false);
                e.setCompleteListener((() => {
                    sys.isObjectValid(this.node) && (i.active = true, a.active = false);
                }));
                TweenTool.delayAct(RummyDataManager.shared().sceneNode, (() => {
                    sys.isObjectValid(this.node) && (i.active = true);
                }), 1, true);
                TweenTool.delayAct(RummyDataManager.shared().sceneNode, (() => {
                    sys.isObjectValid(this.node) && (n.active || (n.active = true, TweenTool.moveToByFade(n, 0.03, n.getPosition(), 0, 255, true)));
                }), 1.3, true);
            }
            else {
                i.active = true;
                a.active = false;
            }
        }
    }
    menuBtnIsViseble(e) {
        this.node.getChildByName("topNode").getChildByName("menu_btn").active = e;
    }
    showHistoryWinLoseMoney(e, t) {
        let i = this.node.getChildByName("topNode").getChildByName("win_money");
        if (t && sys.isObjectValid(i)) {
            if (i.active = true, Number(e) > 0) {
                i.getComponent(Label).string = "+₹" + ToolUtils.parse_double(e);
                i.getComponent(Label).color = color(0, 173, 41, 255);
            }
            else {
                let t = Math.abs(e) + "", a = "" + ToolUtils.parse_double(t);
                i.getComponent(Label).string = "-₹" + a;
                i.getComponent(Label).color = color(255, 38, 38, 255);
            }
            i.getComponent(Label).updateRenderData(true);
            let t = i.getComponent(UITransform).width, a = (GameConfig.REAL_SCREEN_HEIGHT - GameConfig.CONFIG_SCREEN_HEIGHT) / 2 - sys.getSafeAreaRect().x, n = -522 - a - t / 2, o = 294, s = -489 - a, l = 319;
            i.getComponent(Label).fontSize = 0;
            i.getComponent(UIOpacity).opacity = 0;
            i.setPosition(new Vec3(n, o));
            let h = 0.2, r = h + 1, m = 0.2, c = { target_position: new Vec3(s, l), fadeStart: 0, fadeEnd: 255, duration: h, font_change: true, font_start: 0, font_end: 24, easing: "sineOutIn" };
            try {
                TweenTool.fadeInOut(i, c);
                TweenTool.delayAct(RummyDataManager.shared().sceneNode, (() => {
                    if (sys.isObjectValid(i)) {
                        let e = { target_position: new Vec3(s, l), fadeStart: 255, fadeEnd: 0, duration: m, easing: "sineOutIn" };
                        TweenTool.fadeInOut(i, e);
                    }
                }), r, true);
            }
            catch (e) {
                TLog.printError(" showHistoryWinLoseMoney0 err:", e);
            }
        }
    }
    setEasyHelpBtnVisible(e) {
        let t = this.node.getChildByName("topNode").getChildByName("easy_help_btn");
        t && (t.active = e);
    }
    setMultipleHelpBtnVisible(e) {
        let t = this.node.getChildByName("topNode").getChildByName("multiple_help_btn");
        t && (t.active = false);
    }
    setMultipleTipsBtnShow(e) {
        let t = this.node.getChildByName("multiple_tip_btn");
        ToolUtils.isObjValid(t) && (t.active = e);
    }
    preInitFlyGoldPool() {
        try {
            if (this.flyGoldPool) {
                let e = 0;
                for (let t = this.flyGoldPool.size(); t < this.flyGoldNum; t++) {
                    TweenTool.delayAct(RummyDataManager.shared().sceneNode, (() => {
                        if (this.flyGoldPool.size() < this.flyGoldNum) {
                            let e = instantiate(this.flyGoldNode);
                            e.active = false;
                            this.flyGoldPool.put(e);
                        }
                    }), game.frameTime / 1000 * 5 * e, true);
                    e += 1;
                }
            }
        }
        catch (e) {
        }
    }
    getFlyGoldNode() {
        let e = null;
        return e = this.flyGoldPool.size() > 0 ? this.flyGoldPool.get() : instantiate(this.flyGoldNode), e.active = true, e;
    }
    putFlyGoldNode(e) {
        TweenTool.stopNodeAction(e);
        e.active = false;
        this.flyGoldPool && this.flyGoldPool.put(e);
    }
    updateFlopCashBannerStatus() {
        let e = this.node.getChildByName("flopcash_btn");
        if (sys.isObjectValid(e)) {
            let t = e.getChildByName("banner").active;
            e.getChildByName("banner").active = !t;
        }
    }
    updateFlopCashStatus(e, t) {
        let i = this.node.getChildByName("flopcash_btn");
        if (sys.isObjectValid(i)) {
            if (i.active = e, e) {
                if (sys.isObjectValid(t) && sys.isObjectValid(t.max_reward) ? (i.getChildByName("reward").getComponent(Label).string = "₹" + String(t.max_reward) + "+", i.getChildByName("reward").active = true) : i.getChildByName("reward").active = false, sys.isObjectValid(t) && sys.isObjectValid(t.current_play_num) && sys.isObjectValid(t.target_play_num) && Number(t.target_play_num) > 0) {
                    i.getChildByName("progress").active = true;
                    i.getChildByName("progress").getComponent(ProgressBar).progress = Number(t.current_play_num) / Number(t.target_play_num);
                    i.getChildByName("wz").active = true;
                    i.getChildByName("wz").getComponent(Label).string = String(t.current_play_num) + "/" + String(t.target_play_num);
                    i.getChildByName("banner").getChildByName("task_progress").getComponent(ProgressBar).progress = t.current_play_num / t.target_play_num;
                    i.getChildByName("banner").getChildByName("task_progress_wz").getComponent(Label).string = String(t.current_play_num) + "/" + String(t.target_play_num);
                    let e = ToolUtils.format(i18nMgr.shared().getValueByKey("flop_cash.task"), t.target_play_num);
                    i.getChildByName("banner").getChildByName("task").getComponent(Label).string = e;
                }
                else {
                    i.getChildByName("progress").active = false;
                    i.getChildByName("wz").active = false;
                }
            }
            sys.isObjectValid(t) && sys.isObjectValid(t.today_task_status) && 2 == t.today_task_status && (i.active = false);
        }
    }
    updateTreasureHuntBox(e, t) {
        this.node.getChildByName("treahunt_btn").getChildByName("box").active = false;
    }
    playTreaHuntBoxAnim(e, t) {
        let i = "cbc_room0";
        1 == e.length ? 7 == e[0].type && (i = "chip_room0") : i = "cbc_room0";
        let a = this.node.getChildByName("treahunt_reward_anim");
        a.active = true;
        a.getComponent(sp.Skeleton).clearTracks();
        a.getComponent(sp.Skeleton).setAnimation(0, i, false);
        let n = false;
        a.getComponent(sp.Skeleton).setCompleteListener((() => {
            n || (a.active = false, n = true, t && t());
        }));
    }
    updateTreasureHuntBtn(e, t, i) {
        if (0 == e) {
            this.setTreaHuntBtnVisible(true);
            let e = this.node.getChildByName("treahunt_btn");
            if (sys.isObjectValid(t)) {
                t.cju >= t.tju ? (e.getChildByName("progress").active = false, e.getChildByName("wz").active = false) : (e.getChildByName("progress").active = true, e.getChildByName("wz").active = true, e.getChildByName("progress").getComponent(ProgressBar).progress = t.cju / t.tju, e.getChildByName("wz").getComponent(Label).string = String(t.cju) + "/" + String(t.tju));
                this.node.getChildByName("treahunt_reward_anim").active = false;
                let i = e.getChildByName("icon_anim");
                i.active = true;
                i.getComponent(sp.Skeleton).clearTracks();
                i.getComponent(sp.Skeleton).setToSetupPose();
                let a = RummyDataManager.shared().rummyInfos.get(this.tid_key);
                0 == a.crashModel ? i.getComponent(sp.Skeleton).setAnimation(0, "standby", false) : i.getComponent(sp.Skeleton).setAnimation(0, "standbychip", false);
                e.getChildByName("panim").active = false;
                1 == a.crashModel ? 1 == a.show_box_act97 ? (e.getChildByName("progress").active = true, e.getChildByName("wz").active = true, e.getChildByName("progress").getComponent(ProgressBar).progress = 1, e.getChildByName("wz").getComponent(Label).string = "100%", this.canGetTreaHuntAward = false, i.getComponent(sp.Skeleton).clearTracks(), i.getComponent(sp.Skeleton).setToSetupPose(), i.getComponent(sp.Skeleton).setAnimation(0, "loopchip2", true)) : sys.isObjectValid(a.act97_data.end_task) && 1 == Number(a.act97_data.end_task) && (e.getChildByName("progress").active = false, e.getChildByName("wz").active = false) : t.cju >= t.tju && (e.getChildByName("tip").active = true, e.active = false);
            }
            this.canGetTreaHuntAward = false;
        }
        else if (1 == e) {
            let e = this.node.getChildByName("treahunt_btn");
            e.getChildByName("progress").active = true;
            e.getChildByName("wz").active = true;
            e.getChildByName("progress").getComponent(ProgressBar).progress = t.cju / t.tju;
            e.getChildByName("wz").getComponent(Label).string = String(t.cju) + "/" + String(t.tju);
            t.cju == t.tju ? (this.canGetTreaHuntAward = true, this.treaHuntAwardData = t) : t.cju > t.tju && (e.getChildByName("progress").active = false, e.getChildByName("wz").active = false, this.node.getChildByName("treahunt_reward_anim").active = false);
            let i = e.getChildByName("icon_anim");
            i.active = true;
            i.getComponent(sp.Skeleton).clearTracks();
            i.getComponent(sp.Skeleton).setToSetupPose();
            let a = RummyDataManager.shared().rummyInfos.get(this.tid_key);
            if (0 == a.crashModel ? i.getComponent(sp.Skeleton).setAnimation(0, "standby", false) : i.getComponent(sp.Skeleton).setAnimation(0, "standbychip", false), 1 == a.crashModel) {
                if (1 == a.show_box_act97) {
                    let t = e.getChildByName("icon_anim");
                    t.active = true;
                    t.getComponent(sp.Skeleton).clearTracks();
                    t.getComponent(sp.Skeleton).setToSetupPose();
                    e.getChildByName("progress").active = true;
                    e.getChildByName("wz").active = true;
                    e.getChildByName("progress").getComponent(ProgressBar).progress = 1;
                    e.getChildByName("wz").getComponent(Label).string = "100%";
                    this.canGetTreaHuntAward = false;
                    this.treaHuntAwardData = null;
                    t.getComponent(sp.Skeleton).setAnimation(0, "loopchip2", true);
                }
                else {
                    sys.isObjectValid(a.act97_data.end_task) && 1 == Number(a.act97_data.end_task) && (e.getChildByName("progress").active = false, e.getChildByName("wz").active = false);
                }
            }
        }
        else if (2 == e) {
            if (!this.canGetTreaHuntAward) {
                return;
            }
            let e = this.node.getChildByName("treahunt_btn");
            if (!e.getChildByName("wz").active) {
                return;
            }
            this.canGetTreaHuntAward = false;
            let t = new Vec3;
            if (e.getPosition(t), this.fly_start_postion = new Vec3(t.x, t.y), sys.isObjectValid(this.treaHuntAwardData)) {
                if (sys.isObjectValid(this.treaHuntAwardData.is_box_task) && Number(1 == this.treaHuntAwardData.is_box_task)) {
                    return void this.updateTreasureHuntBtn(3, this.treaHuntAwardData);
                }
                if (sys.isObjectValid(this.treaHuntAwardData.reward) && this.treaHuntAwardData.reward.length > 0) {
                    let t = e.getChildByName("icon_anim");
                    t.active = true;
                    t.getComponent(sp.Skeleton).clearTracks();
                    t.getComponent(sp.Skeleton).setToSetupPose();
                    0 == RummyDataManager.shared().rummyInfos.get(this.tid_key).crashModel ? t.getComponent(sp.Skeleton).setAnimation(0, "loop", false) : t.getComponent(sp.Skeleton).setAnimation(0, "loopchip", false);
                    let i = e.getChildByName("panim");
                    i.active = true;
                    i.getComponent(sp.Skeleton).clearTracks();
                    let a = false, n = "play_cash";
                    if (1 == this.treaHuntAwardData.reward.length) {
                        n = 0 == this.treaHuntAwardData.reward[0].type ? "play_cash" : 7 == this.treaHuntAwardData.reward[0].type ? "play_chip" : "play_bonus";
                    }
                    else {
                        let e = RummyDataManager.shared().rummyInfos.get(this.tid_key);
                        n = 0 == e.crashModel ? "play_cash_bonus" : "play_cash_bonus_chip";
                    }
                    i.getComponent(sp.Skeleton).setCompleteListener((() => {
                        if (!a) {
                            let e = this.node.getChildByName("treahunt_reward_anim");
                            e.active = true;
                            e.getComponent(sp.Skeleton).clearTracks();
                            e.getComponent(sp.Skeleton).setAnimation(0, n, false);
                            i.active = false;
                            let t = false;
                            e.getComponent(sp.Skeleton).setCompleteListener((() => {
                                t || (this.updateTreasureHuntBtn(3, this.treaHuntAwardData), this.treaHuntAwardData = null, t = true);
                            }));
                        }
                        a = true;
                    }));
                    i.getComponent(sp.Skeleton).setAnimation(0, "Play", false);
                }
            }
            else {
                this.canGetTreaHuntAward = false;
            }
        }
        else if (3 == e) {
            i && (t = this.treaHuntAwardData);
            let e = this.node.getChildByName("treahunt_btn");
            if (!sys.isObjectValid(t)) {
                return void (this.node.getChildByName("treahunt_reward_anim").active = false);
            }
            if (this.canGetTreaHuntAward = false, sys.isObjectValid(t)) {
                if (e.active = true, sys.isObjectValid(t.n_cju) && sys.isObjectValid(t.n_tju)) {
                    e.getChildByName("progress").active = true;
                    e.getChildByName("wz").active = true;
                    e.getChildByName("progress").getComponent(ProgressBar).progress = t.n_cju / t.n_tju;
                    e.getChildByName("wz").getComponent(Label).string = String(t.n_cju) + "/" + String(t.n_tju);
                    e.getChildByName("panim").active = false;
                    this.node.getChildByName("treahunt_reward_anim").active = false;
                    let i = e.getChildByName("icon_anim");
                    i.active = true;
                    i.getComponent(sp.Skeleton).clearTracks();
                    i.getComponent(sp.Skeleton).setToSetupPose();
                    0 == RummyDataManager.shared().rummyInfos.get(this.tid_key).crashModel ? i.getComponent(sp.Skeleton).setAnimation(0, "standby", false) : i.getComponent(sp.Skeleton).setAnimation(0, "standbychip", false);
                    t.n_cju >= t.n_tju && (e.active = false);
                }
                else {
                    e.getChildByName("progress").active = false;
                    e.getChildByName("wz").active = false;
                    this.node.getChildByName("treahunt_reward_anim").active = false;
                    e.getChildByName("tip").active = true;
                    e.active = false;
                }
            }
            else {
                e.active = true;
                e.getChildByName("progress").active = false;
                e.getChildByName("wz").active = false;
                let t = e.getChildByName("icon_anim");
                t.active = true;
                t.getComponent(sp.Skeleton).clearTracks();
                t.getComponent(sp.Skeleton).setToSetupPose();
                0 == RummyDataManager.shared().rummyInfos.get(this.tid_key).crashModel ? t.getComponent(sp.Skeleton).setAnimation(0, "standby", true) : t.getComponent(sp.Skeleton).setAnimation(0, "standbychip", true);
                e.getChildByName("panim").active = false;
                this.node.getChildByName("treahunt_reward_anim").active = false;
                e.getChildByName("tip").active = true;
                e.active = false;
            }
            this.treaHuntAwardData = null;
        }
        else if (4 == e) {
            this.canGetTreaHuntAward = false;
            this.node.getChildByName("treahunt_btn").active = false;
            this.node.getChildByName("treahunt_reward_anim").active = false;
            this.updateTreasureHuntBox(0, 0);
        }
    }
    setTreaHuntBtnVisible(e) {
        let t = this.node.getChildByName("treahunt_btn");
        t && (t.active = e);
    }
    updateNovicesTaskBtn(e) {
        let t = this.node.getChildByName("novicesTask_btn");
        if (ToolUtils.isObjValid(t)) {
            let i = User.shared().roomNovicesData;
            if (!e || sys.isObjectValid(i.data) && sys.isObjectValid(i.data.progress) || (e = false), t.active = e, e) {
                let e = i.data.progress;
                if (t.getChildByName("redpot").active = 1 == e.red_dot, 2 == e.task_status) {
                    t.getChildByName("progress").active = false;
                    t.getChildByName("wz").getComponent(Label).string = "STARTER\nMISSION";
                }
                else {
                    t.getChildByName("progress").active = true;
                    t.getChildByName("progress").getComponent(ProgressBar).progress = e.num / e.total;
                    let i = "";
                    1 == e.sub_type ? i = "GAMES" : 2 == e.sub_type ? i = "WINS" : 3 == e.sub_type && (i = "RECHARGE");
                    e.num > e.total ? t.getChildByName("wz").getComponent(Label).string = i + "\n" + e.total + "/" + e.total : t.getChildByName("wz").getComponent(Label).string = i + "\n" + ToolUtils.parse_double(e.num, -1) + "/" + e.total;
                }
            }
        }
    }
    setLeaderBoardsBtnVisible(e, t = "") {
        let i = this.node.getChildByName("leader_boards_btn");
        i && (i.active = e, e && t.length > 0 && (i.getChildByName("wz").getComponent(Label).string = t));
    }
    showLeaderBoardsProgress(e) {
    }
    refreshRankProgress(e, t) {
        let i = e.getChildByName("reward_icon"), a = e.getChildByName("ProgressBar").getComponent(ProgressBar), n = this.rank_progress, o = e.getChildByName("anim"), s = Number(t.progress_rate), l = t.end_icon, h = t.is_completed;
        l >= 1 && l <= 3 && (i.getComponent(Sprite).spriteFrame = this.rewardIconImags[l - 1]);
        this.rank_progress = s;
        let r = e.getChildByName("points").getComponent(Label);
        sys.isObjectValid(t.incr_points) && t.incr_points > 0 ? (r.node.active = true, r.string = "+" + t.incr_points, r.updateRenderData(true)) : r.node.active = false;
        o.active = false;
        TweenTool.stopNodeAction(a.node);
        let m = new Vec3;
        a.node.getPosition(m);
        this.flyGoldAnimNode.active = false;
        tween(a.node).delay(0.2).to(1, { position: m }, { onUpdate: (e, t) => {
                a.progress = n + (s - n) * t;
            }, onComplete: t => {
                a.progress = s;
                1 == Number(h) ? (this.rank_progress = 0, o.active = true, o.getComponent(sp.Skeleton).clearTracks(), o.getComponent(sp.Skeleton).setAnimation(0, "animation", false), SoundManager.shared().playFx("rummy_fly_gold"), this.showGoldFlyAnim(l, e)) : this.flyGoldAnimNode.active = false;
            }, onStart: e => {
                a.progress = n;
            } }).start();
    }
    removeFlyGolds() {
        let e;
        for (let t = 0, i = this.flyGolds.length; t < i; t++) {
            e = this.flyGolds[t];
            e && e.isValid && this.putFlyGoldNode(e);
        }
        this.flyGoldAnimNode.removeAllChildren();
        this.flyGolds = [];
    }
    showGoldFlyAnim(e, t, i) {
        this.removeFlyGolds();
        this.flyGoldAnimNode.active = true;
        TweenTool.stopNodeAction(this.flyGoldAnimNode);
        this.flyGoldEndPositions = [];
        let a, n, o, s = this.fly_start_postion.x - 33, l = this.fly_start_postion.x + 33, h = this.fly_start_postion.y - 33, r = this.fly_start_postion.y + 33;
        for (let e = 0; e < this.flyGoldNum; e++) {
            let e = this.getFlyGoldNode();
            this.flyGoldAnimNode.addChild(e);
            e.active = true;
            a = Math.floor(Math.random() * (l - s + 1)) + s;
            n = Math.floor(Math.random() * (r - h + 1)) + h;
            o = Math.floor(61 * Math.random()) + -30;
            this.flyGoldEndPositions.push(new Vec3(a, n));
            e.setPosition(this.fly_start_postion);
            e.setRotationFromEuler(v3(0, 0, o));
            this.flyGolds.push(e);
        }
        let g = this.node.getChildByName("head_click0"), m = new Vec3;
        g.getPosition(m);
        this.fly_bonus_index = 1;
        this.fly_gold_index = 1;
        for (let t = 0; t < this.flyGoldNum; t++) {
            let i = t < 5;
            this.updateFlyImage(this.flyGolds[t], e, i);
        }
        let y = 0;
        for (let e = 0, t = this.flyGolds.length; e < t; e++) {
            tween(this.flyGolds[e]).to(0.3, { position: this.flyGoldEndPositions[e] }, { easing: "quadOut" }).delay(y).to(0.6, { position: m }, { easing: "quadIn" }).call((() => {
                TweenTool.stopNodeAction(this.flyGolds[e]);
            })).start();
            y += 0.1;
        }
        y = y + 0.6 + 0.3;
        tween(this.flyGoldAnimNode).delay(y).call((() => {
            TweenTool.stopNodeAction(this.flyGoldAnimNode);
            this.flyGoldAnimNode.active = false;
            i && i();
        })).start();
    }
    updateFlyImage(e, t, i) {
        let a, n = e.getChildByName("anim");
        n.active = true;
        1 == t ? a = "cash" : 2 == t ? a = "bonus" : 3 == t && (a = i ? "cash" : "bonus");
        n.getComponent(sp.Skeleton).clearTracks();
        n.getComponent(sp.Skeleton).setToSetupPose();
        n.getComponent(sp.Skeleton).setAnimation(0, a, true);
    }
    checkBtnPos() {
        // 布局健康自检：刷新按钮 x > 900 视为场景没正确渲染，GameRummy 据此
        // backToHall()。900 是按原生固定 1280 设计分辨率定的阈值，原生上有效、要保留。
        // 但 web 的 Canvas 适配随浏览器窗口浮动（可视宽 1296~2218），右对齐按钮 x
        // 正常也会 > 900，导致进桌即被误判踢回、无限重连。所以只在 web 关掉这个自检，
        // 原生（打 APK）走原逻辑、不受影响。
        if (!sys.isNative) {
            return true;
        }
        let e = this.node.getChildByName("topNode").getChildByName("refresh_btn");
        return !(ToolUtils.isObjValid(e) && e.position.x > 900);
    }
    setMatch_reward_btnVisible(e) {
        let t = this.node.getChildByName("topNode").getChildByName("match_reward_btn");
        t && (t.active = e);
    }
    changeRaceRewardDiVisible(e) {
        let t = this.node.getChildByName("race_reward_di");
        if (t) {
            if (e) {
                let e = { startPos: v3(this._matchRankPos.x - 800, this._matchRankPos.y, this._matchRankPos.z), endPos: this._matchRankPos };
                t.active = true;
                ToolUtils.showPushAnim(t, 2, (() => {
                    ToolUtils.isObjValid(this.node) && t.setPosition(this._matchRankPos);
                }), e);
                this.changeRaceRewardTab(this.race_reward_tabIndex);
            }
            else if (t.active) {
                let e = { startPos: this._matchRankPos, endPos: v3(this._matchRankPos.x - 800, this._matchRankPos.y, this._matchRankPos.z) };
                ToolUtils.showPushAnim(t, 2, (() => {
                    ToolUtils.isObjValid(this.node) && (t.active = false);
                }), e);
            }
        }
    }
    getRaceRewardVisible() {
        return this.node.getChildByName("race_reward_di").active;
    }
    refreshRaceRewardList(e) {
        try {
            this.reward_infos = e;
            let t = this.node.getChildByName("race_reward_di").getChildByName("bg").getChildByName("reward_root"), i = t.getChildByName("title_item"), a = t.getChildByName("title_item2"), n = t.getChildByName("item"), o = t.getChildByName("item2"), l = t.getChildByName("tips_root"), h = l.getChildByName("tips_title"), d = l.getChildByName("tips1"), r = l.getChildByName("tips2"), m = l.getChildByName("tips3"), c = null, y = RummyDataManager.shared().rummyInfos.get(this.tid_key);
            n.active = false;
            o.active = false;
            y && y.gameMatchMode == RUMMY_MATCH_MODE.PointsMatch ? (c = n, i.active = true, a.active = false) : (c = o, i.active = false, a.active = true, i18nMgr.shared().changeLocalizedLabelKey(h, "match_info.pts_reward_zm_title"), i18nMgr.shared().changeLocalizedLabelKey(d, "match_info.pts_reward_zm_tip1"), i18nMgr.shared().changeLocalizedLabelKey(r, "match_info.pts_reward_zm_tip2"), i18nMgr.shared().changeLocalizedLabelKey(m, "match_info.pts_reward_zm_tip3"));
            c.active = false;
            let u = t.getChildByName("ScrollView").getComponent(ScrollView), p = 0;
            e && e.length > 0 && (p = e);
            let C = false;
            if (Array(u.content.children) && u.content.children.length > 0 && u.content.children.length != p && (u.content.removeAllChildren(), C = true), l.active = false, e && e.length > 0) {
                let t;
                for (let i = 0, a = e.length; i < a; i++) {
                    ToolUtils.isObjValid(this.rewardItems[i]) ? (t = this.rewardItems[i], C && u.content.addChild(t)) : (t = instantiate(c), u.content.addChild(t), this.rewardItems[i] = t);
                    let a = e[i];
                    t.active = true;
                    let n = t.getChildByName("Id"), o = t.getChildByName("pts").getComponent(Label);
                    y && y.gameMatchMode == RUMMY_MATCH_MODE.PointsMatch ? (n.getComponent(Label).string = String(i + 1), o.node.active = true, o.string = ToolUtils.parse_double(String(a.points), -1) + "") : (sys.isObjectValid(a.desc) && (n.getComponent(Label).string = a.desc + ""), o.node.active = false);
                    let s = t.getChildByName("prize_root");
                    if (s && sys.isObjectValid(a.infos2) && Array(a.infos2) && a.infos2.length > 0) {
                        s.active = true;
                        let e = s.getChildByName("layout0"), t = s.getChildByName("layout1"), i = s.getChildByName("layout2"), n = s.getChildByName("layout3"), o = e.getChildByName("gold").getComponent(Label), l = t.getChildByName("bonus").getComponent(Label), h = i.getChildByName("discount").getComponent(Label), d = i.getChildByName("ic").getComponent(Sprite);
                        e.active = false;
                        t.active = false;
                        i.active = false;
                        n.active = false;
                        for (let s = 0; s < a.infos2.length; s++) {
                            const r = a.infos2[s];
                            if (sys.isObjectValid(r)) {
                                if (sys.isObjectValid(r.type) && 2 == r.type) {
                                    e.active = true;
                                    sys.isObjectValid(r.value) && (o.string = "" + ToolUtils.parse_double(String(r.value), -1));
                                }
                                else if (sys.isObjectValid(r.type) && 6 == r.type) {
                                    t.active = true;
                                    sys.isObjectValid(r.value) && (l.string = "" + ToolUtils.parse_double(String(r.value), -1));
                                }
                                else if (sys.isObjectValid(r.type) && 11 == r.type) {
                                    if (i.active = true, sys.isObjectValid(r.discount)) {
                                        let e = Number(r.discount);
                                        d.spriteFrame = 100 == e ? this.ticket_images[1] : this.ticket_images[0];
                                        0 != i18nMgr.shared().language && i18nMgr.shared().changeLabelFont(h);
                                        let t = ToolUtils.format(i18nMgr.shared().getValueByKey("ticket.off"), r.discount);
                                        sys.isObjectValid(r.value) && Number(r.value) >= 2 && (t = t + "*" + r.value);
                                        h.string = t;
                                    }
                                }
                                else if (sys.isObjectValid(r.type) && 13 == r.type) {
                                    n.active = true;
                                    let e = n.getChildByName("ic"), t = n.getChildByName("desc"), i = ToolUtils.isSafeString(r.item_url), a = ToolUtils.getImageUrlPictureName(i);
                                    ToolUtils.isSafeString(a).length > 0 && (a != this.rewardNames[0] ? (Utils.shared().setImage(e, "reward_unload", this.rewardAtlas), Utils.shared().updateNetImage(e, i, size(36, 36), (() => {
                                    }))) : Utils.shared().setImage(e, "reward_watch", this.rewardAtlas));
                                    sys.isObjectValid(r.item_name) && (i18nMgr.shared().changeLabelFont(t.getComponent(Label)), t.getComponent(Label).string = "" + r.item_name);
                                }
                            }
                        }
                    }
                }
            }
            let B = instantiate(l);
            B.active = true;
            u.content.addChild(B);
        }
        catch (e) {
            TLog.printError("trycatch error refreshRaceRewardList:", e);
        }
    }
    initRankItem(e, t, i) {
        e.active = true;
        e.getChildByName("bg").active = t.uid == User.shared().data.uid;
        let a = e.getChildByName("rank").getComponent(Label), n = e.getChildByName("rank_icon").getComponent(Sprite);
        sys.isObjectValid(t.rank) && t.rank >= 1 && t.rank <= 3 ? (n.node.active = true, a.node.active = false, n.spriteFrame = this.rankFrame[t.rank - 1]) : (n.node.active = false, a.node.active = true, a.string = String(t.rank));
        let o = e.getChildByName("name").getComponent(Label);
        sys.isObjectValid(t.name) && (o.string = ToolUtils.GetShortName2(t.name, 9, true));
        let s = e.getChildByName("pts").getComponent(Label);
        t.state && 1 == t.state ? (i18nMgr.shared().changeLabelFont(s), s.string = 0 == i ? i18nMgr.shared().getValueByKey("match_rank.win") : i18nMgr.shared().getValueByKey("match_rank.out")) : sys.isObjectValid(t.score) && (s.string = ToolUtils.parse_double(String(t.score), -2) + "");
        let l = e.getChildByName("head").getChildByName("img");
        Utils.shared().updateHeadImg(l, t.avatar, t.avatar_url, size(40, 40));
        let h = t.rank || -1, d = e.getChildByName("prize").getComponent(Label);
        if (d.string = "-", this.reward_infos && h > 0 && this.reward_infos.length > 0) {
            for (let e = 0, t = this.reward_infos.length; e < t; e++) {
                let t = this.reward_infos[e], i = String(t.desc).split("-"), a = false;
                if (sys.isObjectValid(i[1]) ? h >= Number(i[0]) && h <= Number(i[1]) && (a = true) : Number(i[0]) == h && (a = true), a) {
                    if (sys.isObjectValid(t.infos2) && Array(t.infos2) && t.infos2.length > 0) {
                        for (let e = 0; e < t.infos2.length; e++) {
                            const i = t.infos2[e];
                            if (sys.isObjectValid(i) && sys.isObjectValid(i.type) && 2 == i.type) {
                                sys.isObjectValid(i.value) && (d.string = "₹" + ToolUtils.parse_double(String(i.value), -1));
                                break;
                            }
                        }
                    }
                    break;
                }
            }
        }
    }
    refreshRaceRankList(e) {
        try {
            let t = this.node.getChildByName("race_reward_di").getChildByName("bg").getChildByName("rank_root");
            t.getChildByName("item").active = false;
            let i = t.getChildByName("ScrollView").getComponent(ScrollView);
            i.node.active = true;
            let a = [], n = RummyDataManager.shared().rummyInfos.get(this.tid_key);
            a = n && n.gameMatchMode == RUMMY_MATCH_MODE.PointsMatch ? e.rank_info : e;
            let o = Array.isArray(a) ? a.length : 0, l = null, h = 0;
            if (i.scrollToTop(), o > 0) {
                this.rankTableView.reloadData(a);
                for (let e = 0, t = a.length; e < t; e++) {
                    let t = a[e];
                    if (n.gameMatchMode != RUMMY_MATCH_MODE.PointsMatch && sys.isObjectValid(t.uid) && t.uid == User.shared().data.uid) {
                        l = t;
                        h = e;
                        break;
                    }
                }
            }
            let d = t.getChildByName("my_item");
            d.active = true;
            let r = d.getChildByName("rank").getComponent(Label), m = d.getChildByName("rank_icon").getComponent(Sprite), c = d.getChildByName("name").getComponent(Label), y = d.getChildByName("pts").getComponent(Label), u = d.getChildByName("prize").getComponent(Label), p = d.getChildByName("head").getChildByName("img");
            Utils.shared().updateHeadImg(p, User.shared().data.avatar, User.shared().data.avatar_url, size(40, 40));
            let C = -1;
            if (l ? (C = l.rank, sys.isObjectValid(l.rank) && l.rank >= 1 && l.rank <= 3 ? (m.node.active = true, r.node.active = false, m.spriteFrame = this.rankFrame[l.rank - 1]) : 0 == l.rank ? (m.node.active = false, r.node.active = true, r.string = "--") : (m.node.active = false, r.node.active = true, r.string = String(l.rank)), sys.isObjectValid(l.name) && (c.string = ToolUtils.GetShortName2(l.name, 9, true)), l.state && 1 == l.state ? (i18nMgr.shared().changeLabelFont(y), y.string = 0 == h ? i18nMgr.shared().getValueByKey("match_rank.win") : i18nMgr.shared().getValueByKey("match_rank.out")) : sys.isObjectValid(l.score) && (y.string = ToolUtils.parse_double(String(l.score), -2) + "")) : (sys.isObjectValid(e.rank) && (C = e.rank, 0 == e.rank ? r.string = "--" : r.string = String(e.rank)), sys.isObjectValid(e.name) && (c.string = ToolUtils.GetShortName2(e.name, 9, true)), sys.isObjectValid(e.score) && (y.string = ToolUtils.parse_double(String(e.score), -2) + "")), u.string = "-", this.reward_infos && C > 0 && this.reward_infos.length > 0) {
                for (let e = 0, t = this.reward_infos.length; e < t; e++) {
                    let t = this.reward_infos[e], i = String(t.desc).split("-"), a = false;
                    if (sys.isObjectValid(i[1]) ? C >= Number(i[0]) && C <= Number(i[1]) && (a = true) : Number(i[0]) == C && (a = true), a) {
                        if (sys.isObjectValid(t.infos2) && Array(t.infos2) && t.infos2.length > 0) {
                            for (let e = 0; e < t.infos2.length; e++) {
                                const i = t.infos2[e];
                                if (sys.isObjectValid(i) && sys.isObjectValid(i.type) && 2 == i.type) {
                                    sys.isObjectValid(i.value) && (u.string = "₹" + ToolUtils.parse_double(String(i.value), -1));
                                    break;
                                }
                            }
                        }
                        break;
                    }
                }
            }
        }
        catch (e) {
            TLog.printError("trycatch error refreshRaceRankList:", e);
        }
    }
    scrollRefreshCallBack() {
    }
    changeRaceRewardTab(e) {
        this.race_reward_tabIndex = 0;
        let t = this.node.getChildByName("race_reward_di").getChildByName("bg"), i = t.getChildByName("reward_root"), a = t.getChildByName("rank_root"), n = t.getChildByName("tab0"), o = t.getChildByName("tab1");
        n.active = false;
        o.active = false;
        a.active = true;
        i.active = false;
    }
    showDoubleGameChooseTip(e, t = null) {
        let i = this.node.getChildByName("double_choose");
        if (i) {
            if (this.doubleTimeAction && (TweenTool.stopAction(this.doubleTimeAction), this.doubleTimeAction = null), e) {
                let e = i.getChildByName("time");
                if (sys.isObjectValid(t) && (sys.isObjectValid(t.cd) && (e.getComponent(Label).string = t.cd + "", this.showDoubleClockAnim(t.cd), t.cd > 0 && (this.doubleChooseTime = t.cd, this.doubleTimeAction = TweenTool.myschedule(RummyDataManager.shared().sceneNode, 1, this.updateDoubleTime.bind(this)))), Array.isArray(t.cfg) && t.cfg.length >= 3)) {
                    i.getChildByName("btn1").getChildByName("Label").getComponent(Label).string = "DOUBLE +" + t.cfg[1];
                    i.getChildByName("btn2").getChildByName("Label").getComponent(Label).string = "DOUBLE +" + t.cfg[2];
                }
                SoundManager.shared().playFx("rummySelfTurn");
            }
            i.active = e;
        }
    }
    updateDoubleTime() {
        let e = this.node.getChildByName("double_choose");
        if (e) {
            if (this.doubleChooseTime = this.doubleChooseTime - 1, this.doubleChooseTime < 0) {
                return void (this.doubleTimeAction && (TweenTool.stopAction(this.doubleTimeAction), this.doubleTimeAction = null, e.active = false));
            }
            SoundManager.shared().playFx("doubleCountDown");
            e.getChildByName("time").getComponent(Label).string = this.doubleChooseTime + "";
            3 == this.doubleChooseTime && this.showDoubleClockAnim(this.doubleChooseTime);
        }
    }
    showDoubleClockAnim(e) {
        let t = this.node.getChildByName("double_choose");
        if (t) {
            let i = t.getChildByName("clock_anim");
            i.active = true;
            let a = i.getComponent(sp.Skeleton);
            a.clearTracks();
            a.setToSetupPose();
            let n = e <= 3 ? "1" : "0";
            a.setAnimation(0, n, true);
        }
    }
    adapptationScreen() {
        let e = this.node.getChildByName("chat_btn"), t = this.node.getChildByName("rule_btn"), i = this.node.getChildByName("topNode").getChildByName("menu_btn"), a = this.node.getChildByName("topNode").getChildByName("match_reward_btn"), n = this.node.getChildByName("topNode").getChildByName("multiple_help_btn"), o = this.node.getChildByName("topNode").getChildByName("shop_btn"), s = this.node.getChildByName("topNode").getChildByName("refresh_btn"), l = this.node.getChildByName("topNode").getChildByName("history_btn"), h = this.node.getChildByName("topNode").getChildByName("topRightBtns"), d = this.node.getChildByName("topNode").getChildByName("pool_total_history_btn"), r = this.node.getChildByName("topNode").getChildByName("easy_help_btn"), g = this.node.getChildByName("leader_boards_btn"), m = this.node.getChildByName("multiple_tip_btn"), c = this.node.getChildByName("race_reward_di"), y = this.node.getChildByName("novicesTask_btn"), u = this.node.getChildByName("tingpai"), p = this.node.getChildByName("treahunt_btn"), C = this.node.getChildByName("flopcash_btn");
        if (ToolUtils.isPadPlatform()) {
            let i = this.node.getChildByName("topNode"), a = this.node.getChildByName("security_btn"), n = this.node.getChildByName("prizeBtn"), o = this.node.getChildByName("operate_bg"), s = this.node.getChildByName("switch_btn"), l = this.node.getChildByName("copy_btn"), h = this.node.getChildByName("invite_btn"), d = this.node.getChildByName("head_click0");
            return this.resetUiPos(i, AdapDirection.Up, true, 1, false), this.resetUiPos(t, AdapDirection.Up, true, 1, false), this.resetUiPos(a, AdapDirection.Up, true, 1, false), this.resetUiPos(n, AdapDirection.Up, true, 1, false), this.resetUiPos(e, AdapDirection.Down, true, 1, false), this.resetUiPos(o, AdapDirection.Down, true, 1, false), this.resetUiPos(s, AdapDirection.Down, true, 1, false), this.resetUiPos(l, AdapDirection.Down, true, 1, false), this.resetUiPos(h, AdapDirection.Down, true, 1, false), this.resetUiPos(d, AdapDirection.Down, true, 1, false), void this.resetUiPos(m, AdapDirection.Down, true, 1, false);
        }
        this.resetUiPos(t, AdapDirection.Left, true, 1, true);
        this.resetUiPos(i, AdapDirection.Left, true, 1, true);
        this.resetUiPos(a, AdapDirection.Left, true, 1, true);
        this.resetUiPos(n, AdapDirection.Left, true, 1, true);
        this.resetUiPos(l, AdapDirection.Left, true, 1, true);
        this.resetUiPos(s, AdapDirection.Right, true, 1, true, true);
        this.resetUiPos(h, AdapDirection.Right, true, 1, true, true);
        this.resetUiPos(e, AdapDirection.Right, true, 1, true, true);
        this.resetUiPos(d, AdapDirection.Left, true, 1, true);
        ToolUtils.isObjValid(o) && this.resetUiPos(o, AdapDirection.Right, true, 1, true, true);
        this.resetUiPos(c, AdapDirection.Left, true, 1, true);
        this.resetUiPos(r, AdapDirection.Left, true, 1, true);
        ToolUtils.isIosPlatform() ? (this.resetUiPos(g, AdapDirection.Left, true, 0.5, true, true), this.resetUiPos(C, AdapDirection.Left, true, 0.5, true, true), this.resetUiPos(y, AdapDirection.Left, true, 0.5, true, true), this.resetUiPos(p, AdapDirection.Left, true, 0.5, true)) : (this.resetUiPos(g, AdapDirection.Left, true, 1, true, true), this.resetUiPos(C, AdapDirection.Left, true, 1, true, true), this.resetUiPos(y, AdapDirection.Left, true, 1, true, true), this.resetUiPos(p, AdapDirection.Left, true, 1, true));
        this.resetUiPos(u, AdapDirection.Right, true, 1, true, true);
    }
}
