// @ts-nocheck
// Recovered from index.js:87
import { _decorator, Button, color, instantiate, Label, Node, Sprite, SpriteFrame, sys, UITransform, v3 } from "cc";
import PushCenter from "./PushCenter";
import SoundManager from "./SoundManager";
import BaseLayer from "./BaseLayer";
import TweenTool from "./TweenTool";
import { ToolUtils } from "./ToolUtils";
import Utils from "./Utils";
const { ccclass, property } = _decorator;
@ccclass("CouponPopList")
export class CouponPopList extends BaseLayer {
    @property(Node)
    public rootNode: Node = null;
    @property(Node)
    public couponMoban: Node = null;
    @property(Node)
    public couponMoban2: Node = null;
    @property(Node)
    public couponRoot: Node = null;
    @property([SpriteFrame])
    public buttonImages: SpriteFrame[] = [];
    @property([SpriteFrame])
    public id_kuangs: SpriteFrame[] = [];
    @property([SpriteFrame])
    public bg_imgs: SpriteFrame[] = [];
    public click_time: number = 0;
    public _callback: any = null;
    public _goodData: any = null;
    public _couponNodes: any[] = [];
    public _more_couponNodes: any[] = [];
    public _curSelectIndex: any = -1;
    public avatarIconMap: Map = new Map;
    setGameMode(e) {
    }
    initParaData(e, t = null) {
        sys.isObjectValid(t) && (this._callback = t);
        sys.isObjectValid(e) && (this._goodData = e);
    }
    start() {
        super.start();
        ToolUtils.showFullScreen(this.node.getChildByName("bg"));
        this.fitScreen();
        this.refreshUI(true);
        this.startShowAnim();
    }
    fitScreen() {
    }
    startShowAnim() {
        let e = this.node.getChildByName("bg").getComponent(UITransform).contentSize, t = v3(0, -e.height / 2);
        this.rootNode.setPosition(v3(0, -1670, 0));
        TweenTool.moveTo(this.rootNode, 0.15, t, "fade", true, (() => {
            this.rootNode.setPosition(t);
        }));
    }
    refreshUI(e = false) {
        if (!sys.isObjectValid(this._goodData.coupon_list)) {
            return this.rootNode.getChildByName("display_node").active = false, void (this.rootNode.getChildByName("nodata").active = true);
        }
        this.rootNode.getChildByName("nodata").active = false;
        let t = 0;
        if (sys.isObjectValid(this._goodData.coupon_list.check_info) ? (this.couponRoot.getChildByName("cur_coupon").active = true, sys.isObjectValid(this._goodData.coupon_list.check_info.select) ? 1 == this._goodData.coupon_list.check_info.select && (this._curSelectIndex = 0) : (this._goodData.coupon_list.check_info.select = 1, this._curSelectIndex = 0), this.updateCouponInfo(this.couponRoot.getChildByName("cur_coupon"), this._goodData.coupon_list.check_info, t, 0), this._couponNodes.push(this.couponRoot.getChildByName("cur_coupon")), this.couponRoot.getChildByName("cur_coupon").getChildByName("date_open").getComponent(Button).clickEvents[0].customEventData = "date_open_0", this.couponRoot.getChildByName("cur_coupon").info = this._goodData.coupon_list.check_info, t += 1) : this.couponRoot.getChildByName("cur_coupon").active = false, sys.isObjectValid(this._goodData.coupon_list.recommended) && Array.isArray(this._goodData.coupon_list.recommended)) {
            this.couponRoot.getChildByName("rec_coupon").active = true;
            for (let e = 0; e < this._goodData.coupon_list.recommended.length; e++) {
                if (!sys.isObjectValid(this._goodData.coupon_list.recommended[e])) {
                    continue;
                }
                sys.isObjectValid(this._goodData.coupon_list.recommended[e].select) || (this._goodData.coupon_list.recommended[e].select = 0);
                let o = this._goodData.coupon_list.recommended[e], i = instantiate(this.couponMoban);
                i.active = true;
                this.couponRoot.getChildByName("rec_coupon").addChild(i);
                i.info = o;
                this.updateCouponInfo(i, o, t, 0);
                this._couponNodes.push(i);
                i.getChildByName("date_open").getComponent(Button).clickEvents[0].customEventData = "date_open_" + t;
                t += 1;
            }
        }
        else {
            this.couponRoot.getChildByName("rec_coupon").active = false;
        }
        let o = 0;
        if (sys.isObjectValid(this._goodData.coupon_list.more) && Array.isArray(this._goodData.coupon_list.more)) {
            this.couponRoot.getChildByName("more_coupon").active = true;
            for (let e = 0; e < this._goodData.coupon_list.more.length; e++) {
                this._goodData.coupon_list.more[e].select = 0;
                let t = this._goodData.coupon_list.more[e], i = instantiate(this.couponMoban2);
                i.active = true;
                this.couponRoot.getChildByName("more_coupon").addChild(i);
                i.info = t;
                this.updateCouponInfo(i, t, o, 1);
                this._more_couponNodes.push(i);
                i.getChildByName("date_open").getComponent(Button).clickEvents[0].customEventData = "date_more_open_" + o;
                o += 1;
            }
        }
        else {
            this.couponRoot.getChildByName("more_coupon").active = false;
        }
    }
    updateOperateBtn(e, t) {
        1 == t ? (e.getChildByName("img").getComponent(Sprite).color = color(85, 85, 85), e.getChildByName("img").getComponent(Sprite).spriteFrame = this.buttonImages[0], e.getChildByName("wz").getComponent(Label).string = "REMOVE", e.getChildByName("wz").getComponent(Label).color = color(85, 85, 85)) : (e.getChildByName("img").getComponent(Sprite).color = color(255, 255, 255), e.getChildByName("wz").getComponent(Label).string = "APPLY", e.getChildByName("img").getComponent(Sprite).spriteFrame = this.buttonImages[1], e.getChildByName("wz").getComponent(Label).color = color(255, 255, 255));
    }
    updateCouponInfo(e, t, o, i) {
        sys.isObjectValid(i) && (e.getChildByName("image").getComponent(Sprite).spriteFrame = this.bg_imgs[i], 1 == i ? (e.getChildByName("type_wz").getComponent(Label).color = color(225, 114, 15), e.getChildByName("operate_btn").getComponent(Button).clickEvents[0].customEventData = "no_use_" + t.price, this.updateOperateBtn(e.getChildByName("operate_btn"), 0)) : (e.getChildByName("type_wz").getComponent(Label).color = color(5, 129, 10), e.getChildByName("operate_btn").getComponent(Button).clickEvents[0].customEventData = "c_select_" + o));
        sys.isObjectValid(t.rate_text) && (e.getChildByName("type_wz").getComponent(Label).string = t.rate_text);
        sys.isObjectValid(t.content) && (e.getChildByName("title_wz").getComponent(Label).string = t.content);
        sys.isObjectValid(t.coupon_code) && t.coupon_code.length > 0 ? (e.getChildByName("kuang_img").active = true, e.getChildByName("kuang").active = true, e.getChildByName("kuang").getChildByName("title_wz").getComponent(Label).string = t.coupon_code) : (e.getChildByName("kuang_img").active = false, e.getChildByName("kuang").active = false);
        sys.isObjectValid(t.select) && 1 == t.select ? (e.getChildByName("kuang").getChildByName("gou").active = true, e.getChildByName("kuang_img").getComponent(Sprite).spriteFrame = this.id_kuangs[1], e.getChildByName("kuang").getChildByName("title_wz").getComponent(Label).color = color(5, 129, 10), this.updateOperateBtn(e.getChildByName("operate_btn"), 1), this._curSelectIndex = o) : (e.getChildByName("kuang").getChildByName("gou").active = false, e.getChildByName("kuang_img").getComponent(Sprite).spriteFrame = this.id_kuangs[0], e.getChildByName("kuang").getChildByName("title_wz").getComponent(Label).color = color(0, 0, 0), this.updateOperateBtn(e.getChildByName("operate_btn"), 0));
        sys.isObjectValid(t.expire_text) && (e.getChildByName("date_ez").getComponent(Label).string = t.expire_text);
    }
    couponClick(e, t) {
        if (SoundManager.shared().playFx("click"), !(sys.now() - this.click_time <= 1000)) {
            if (this.click_time = sys.now(), -1 != t.indexOf("no_use_")) {
                let e = `This coupon needs to add ₹${parseInt(t.split("use_")[1])} more`;
                Utils.shared().showToast(e, 2, 0, ToolUtils.getIsNormalDirection());
            }
            else if (-1 != t.indexOf("date_open_")) {
                let e = parseInt(t.split("ate_open_")[1]), o = this._couponNodes[e], i = o.getChildByName("date_ez").active;
                i = !i;
                o.getChildByName("date_ez").active = i;
                o.getChildByName("date_open").getChildByName("wz").getComponent(Label).string = i ? "- CLOSE" : "+ MORE";
            }
            else if (-1 != t.indexOf("date_more_open_")) {
                let e = parseInt(t.split("_more_open_")[1]), o = this._more_couponNodes[e], i = o.getChildByName("date_ez").active;
                i = !i;
                o.getChildByName("date_ez").active = i;
                o.getChildByName("date_open").getChildByName("wz").getComponent(Label).string = i ? "- CLOSE" : "+ MORE";
            }
            else if (-1 != t.indexOf("c_select_")) {
                let e = parseInt(t.split("select_")[1]);
                if (this._curSelectIndex == e) {
                    let t = this._couponNodes[e], o = t.info;
                    1 == o.select ? (this.updateOperateBtn(t.getChildByName("operate_btn"), 0), o.select = 0, this._curSelectIndex = -1) : (this.updateOperateBtn(t.getChildByName("operate_btn"), 1), o.select = 1, this._curSelectIndex = e);
                    sys.isObjectValid(o.select) && 1 == o.select ? (t.getChildByName("kuang").getChildByName("gou").active = true, t.getChildByName("kuang_img").getComponent(Sprite).spriteFrame = this.id_kuangs[1], t.getChildByName("kuang").getChildByName("title_wz").getComponent(Label).color = color(5, 129, 10)) : (t.getChildByName("kuang").getChildByName("gou").active = false, t.getChildByName("kuang_img").getComponent(Sprite).spriteFrame = this.id_kuangs[0], t.getChildByName("kuang").getChildByName("title_wz").getComponent(Label).color = color(0, 0, 0));
                    this._couponNodes[e].info = o;
                }
                else {
                    if (-1 != this._curSelectIndex) {
                        let e = this._couponNodes[this._curSelectIndex], t = e.info;
                        t.select = 0;
                        this.updateOperateBtn(e.getChildByName("operate_btn"), 0);
                        this._couponNodes[this._curSelectIndex].info = t;
                        e.getChildByName("kuang").getChildByName("gou").active = false;
                        e.getChildByName("kuang_img").getComponent(Sprite).spriteFrame = this.id_kuangs[0];
                        e.getChildByName("kuang").getChildByName("title_wz").getComponent(Label).color = color(0, 0, 0);
                    }
                    let t = this._couponNodes[e], o = t.info;
                    this.updateOperateBtn(t.getChildByName("operate_btn"), 1);
                    o.select = 1;
                    this._curSelectIndex = e;
                    t.getChildByName("kuang").getChildByName("gou").active = true;
                    t.getChildByName("kuang_img").getComponent(Sprite).spriteFrame = this.id_kuangs[1];
                    t.getChildByName("kuang").getChildByName("title_wz").getComponent(Label).color = color(5, 129, 10);
                }
            }
        }
    }
    dealCallBackInfo() {
        if (-1 == this._curSelectIndex) {
            this._goodData.check_coupon_id = 0;
        }
        else if (this._curSelectIndex >= 0) {
            let e = this._couponNodes[this._curSelectIndex].info;
            if (this._goodData.check_coupon_id = e.coupon_id, this._goodData.check_coupon_code = e.coupon_code, this._goodData.add_bonus = e.add_bonus, this._goodData.add_cash = e.add_cash, this._goodData.total_get = e.total_get, this._goodData.check_act_id = e.act_id, sys.isObjectValid(this._goodData.coupon_list.check_info)) {
                if (0 == this._curSelectIndex) {
                    this._goodData.coupon_list.check_info.select = 1;
                }
                else {
                    this._goodData.coupon_list.check_info.select = 0;
                    let e = this._goodData.coupon_list.check_info;
                    for (let e = 0; e < this._goodData.coupon_list.recommended.length; e++) {
                        this._goodData.coupon_list.recommended[e].select = 0;
                    }
                    this._goodData.coupon_list.recommended[this._curSelectIndex - 1].select = 1;
                    this._goodData.coupon_list.check_info = this._goodData.coupon_list.recommended[this._curSelectIndex - 1];
                    this._goodData.coupon_list.recommended[this._curSelectIndex - 1] = e;
                }
            }
            else {
                for (let e = 0; e < this._goodData.coupon_list.recommended.length; e++) {
                    sys.isObjectValid(this._goodData.coupon_list.recommended[e]) && (this._goodData.coupon_list.recommended[e].select = 0);
                }
                this._goodData.coupon_list.recommended[this._curSelectIndex].select = 1;
                this._goodData.coupon_list.check_info.select = this._goodData.coupon_list.recommended[this._curSelectIndex];
                this._goodData.coupon_list.recommended[this._curSelectIndex] = null;
            }
        }
        sys.isObjectValid(this._callback) && this._callback(this._goodData);
    }
    onDestroy() {
        PushCenter.shared().removeListenersByTag(this);
        this.unscheduleAllCallbacks();
    }
    onCloseClick(e, t) {
        SoundManager.shared().playFx("click");
        this.dealCallBackInfo();
        this.onBackView();
    }
    onBackView() {
        ToolUtils.isObjValid(this.node) && this.node.destroy();
    }
    update(e) {
    }
}
