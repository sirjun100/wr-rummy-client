// @ts-nocheck
// Recovered from index.js:373
import { _decorator, Button, color, EditBox, HorizontalTextAlignment, instantiate, Label, LabelShadow, Node, ProgressBar, Slider, sys, UITransform, v3, Vec3, view } from "cc";
import SoundManager from "./SoundManager";
import HttpManager from "./HttpManager";
import Utils from "./Utils";
import TweenTool from "./TweenTool";
import PushEvent from "./PushEvent";
import i18nMgr from "./i18nMgr";
import User from "./User";
import BaseLayer from "./BaseLayer";
import BundleNameDefined from "./BundleNameDefined";
import CommDefine from "./CommDefine";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("RechargeLimits")
export class RechargeLimits extends BaseLayer {
    @property(Label)
    public monthly_money: Label = null;
    @property(Label)
    public daily_money: Label = null;
    @property(Button)
    public edit_btn: Button = null;
    @property(Button)
    public add_btn: Button = null;
    @property(Button)
    public reduce_btn: Button = null;
    @property(Button)
    public submit_btn: Button = null;
    @property(Node)
    public reset_time: Node = null;
    @property(EditBox)
    public editBox: EditBox = null;
    @property(Slider)
    public slider: Slider = null;
    @property(Node)
    public limitMoban: Node = null;
    @property(Node)
    public limitRoot: Node = null;
    @property(Node)
    public rootNode: Node = null;
    @property(Node)
    public bgNode: Node = null;
    @property(Node)
    public daily_limit_tips: Node = null;
    @property(Node)
    public weekly_limit: Node = null;
    @property(Label)
    public weekly_money: Label = null;
    public nIndex: any = null;
    public nTime: number = 0;
    public timeAction: any = null;
    public callback: any = null;
    public vLimitList: any[] = [];
    setCallBack(t) {
        this.callback = t;
    }
    start() {
        super.start();
        this.nIndex = 0;
        this.limitMoban.active = false;
        this.editBox.node.active = false;
        this.reset_time.active = false;
        this.submit_btn.interactable = false;
        this.updateSubmitWzColor();
        let t = view.getVisibleSize(), i = this.rootNode.getComponent(UITransform), e = this.bgNode.getComponent(UITransform), s = this.node.getComponent(UITransform);
        ToolUtils.getOrientation() ? (this.node.setRotationFromEuler(new Vec3(0, 0, 90)), i.setContentSize(t.height, t.width), e.setContentSize(t.height, t.width), s.setContentSize(t.height, t.width), this.rootNode.setPosition(v3(0, -sys.getSafeAreaRect().x, 0))) : (i.setContentSize(t.width, t.height), e.setContentSize(t.width, t.height), s.setContentSize(t.width, t.height), this.rootNode.setPosition(v3(0, -sys.getSafeAreaRect().y, 0)));
        this.fitScreen();
        this.weekly_limit.active = 1 == User.shared().data.kyc_otp_pop;
        this.daily_limit_tips.active = 1 == User.shared().data.kyc_otp_pop;
        sys.isObjectValid(User.shared().rechargeLimitData) ? this.updateInfo() : Utils.shared().showLoading(10, true, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
        }));
        HttpManager.shared().doGetPayDefLimit(this.listenGetPayDefLimitCallback.bind(this));
        SoundManager.shared().preLoadBundleSounds(BundleNameDefined.bundle_sound, "select");
    }
    listenGetPayDefLimitCallback(t, i, e) {
        Utils.shared().hideLoading();
        try {
            if (200 != e) {
                alert("The login timed out, please try again");
            }
            else {
                let t = ToolUtils.parseJson(i);
                0 == t.ret && (User.shared().rechargeLimitData = t.data, ToolUtils.isObjValid(this.node) && this.updateInfo());
            }
        }
        catch (t) {
        }
    }
    listenPayDefSetLimitCallback(t, i, e) {
        Utils.shared().hideLoading();
        try {
            if (200 != e) {
                alert("The login timed out, please try again");
            }
            else {
                let t = ToolUtils.parseJson(i);
                0 == t.ret && (this.reset_time.active = true, this.submit_btn.interactable = false, this.updateSubmitWzColor(), this.nTime = t.data.cd, User.shared().rechargeLimitData.cd = t.data.cd, this.startCountDwonTime(), Utils.shared().showToast(i18nMgr.shared().getValueByKey("add_cash_limits.submit_success"), 3, 0, ToolUtils.getIsNormalDirection()));
                t.desc && t.desc.length > 0 && Utils.shared().showToast(t.desc, 3, 0, ToolUtils.getIsNormalDirection());
            }
        }
        catch (t) {
        }
    }
    updateSubmitWzColor() {
        let t = this.submit_btn.node.getChildByName("wz");
        this.submit_btn.interactable ? (Utils.updateLabelMaterial(t, CommDefine.gradient.btn_green), t.getComponent(LabelShadow).color = color(5, 123, 58, 255)) : (Utils.updateLabelMaterial(t, CommDefine.gradient.btn_gray), t.getComponent(LabelShadow).color = color(103, 103, 103, 255));
    }
    updateInfo() {
        let t = User.shared().rechargeLimitData;
        if (t.cd > 0 ? (this.reset_time.active = true, this.submit_btn.interactable = false, this.nTime = t.cd, this.startCountDwonTime()) : (this.reset_time.active = false, this.submit_btn.interactable = true), this.updateSubmitWzColor(), this.vLimitList = t.list, this.limitMoban.active = false, this.nIndex = this.getCurIndexMoney(t.mlimit), this.updateSliderProgress(this.nIndex + 1, false), this.updateSlidBtnStatus(), this.monthly_money.string = "" + t.mlimit, this.daily_money.string = "₹" + t.dlimit, this.limitRoot.destroyAllChildren(), this.vLimitList && this.vLimitList.length > 0) {
            let t = this.slider.getComponent(UITransform).contentSize.width;
            for (let i = 0, e = this.vLimitList.length; i < e; i++) {
                let s = instantiate(this.limitMoban);
                if (s.active = true, s.getComponent(Label).string = this.vLimitList[i] + "", 0 == i) {
                    s.setPosition(v3(-t / 2, 0));
                }
                else if (i == e - 1) {
                    s.setPosition(v3(t / 2, 0));
                }
                else {
                    let r = t / (e - 1);
                    s.setPosition(v3(-t / 2 + r * i, 0));
                    s.getComponent(Label).string = "";
                }
                this.limitRoot.addChild(s);
            }
        }
        this.daily_limit_tips.active = false;
        this.weekly_limit.active = true;
        this.weekly_money.string = "₹" + t.wlimit;
    }
    updateLimitMoney(t) {
        this.nTime <= 0 && this.vLimitList && null != this.vLimitList[t - 1] && (this.monthly_money.string = "" + String(this.vLimitList[t - 1]), this.daily_money.string = "₹" + String(Math.floor(0.33 * this.vLimitList[t - 1])), this.weekly_money.string = "₹" + String(Math.floor(0.66 * this.vLimitList[t - 1])));
    }
    updateSlidBtnStatus() {
        this.vLimitList && this.vLimitList.length > 0 ? (this.add_btn.interactable = this.nIndex < this.vLimitList.length - 1, this.reduce_btn.interactable = this.nIndex > 0) : (this.add_btn.interactable = false, this.reduce_btn.interactable = false);
    }
    startCountDwonTime() {
        let t = TweenTool.delayAct(this.reset_time, this.refreshTime.bind(this), 1, false);
        this.timeAction = TweenTool.sequence(this.reset_time, true, null, t, null);
        this.timeAction.repeatForever();
        this.timeAction.start();
        this.reset_time.getChildByName("time").getComponent(Label).string = ToolUtils.timeStr2(this.nTime, true);
    }
    getCurIndexMoney(t) {
        if (this.vLimitList && this.vLimitList.length > 0) {
            for (let i = 0, e = this.vLimitList.length; i < e; i++) {
                if (this.vLimitList[i] >= t) {
                    return i;
                }
            }
            return this.vLimitList.length - 1;
        }
        return 0;
    }
    refreshTime() {
        if (this.nTime <= 0) {
            return this.reset_time.active = false, this.submit_btn.interactable = true, this.updateSubmitWzColor(), void TweenTool.stopAction(this.timeAction);
        }
        this.nTime >= 0 && (this.nTime = this.nTime - 1, this.reset_time.getChildByName("time").getComponent(Label).string = ToolUtils.timeStr2(this.nTime, true));
    }
    onButtonClick(t, i) {
        if (SoundManager.shared().playFx("click"), "close" === i) {
            this.onBackView();
        }
        else if ("kefu" == i) {
            if (1 == User.shared().temp_pingbi.feedback) {
                return void Utils.shared().showToast("Coming soon", 2);
            }
            Utils.shared().doJumpLogic(PushEvent.JUMP_TO_FEEDBACK);
        }
        else if ("edit" == i) {
            if (this.nTime <= 0) {
                this.monthly_money.node.active = false;
                this.editBox.node.active = true;
                this.edit_btn.interactable = false;
                this.editBox.string = ToolUtils.getPureNumberString(this.monthly_money.string);
                this.editBox.setFocus();
            }
            else {
                let t = ToolUtils.timeStr2(this.nTime, true);
                Utils.shared().showToast(ToolUtils.format(i18nMgr.shared().getValueByKey("add_cash_limits.submit_tips"), t), 3, 0, ToolUtils.getIsNormalDirection());
            }
        }
        else if ("reduce" == i) {
            if (this.nTime <= 0) {
                this.vLimitList && this.vLimitList.length > 1 && this.nIndex > 0 && (this.nIndex = this.nIndex - 1, this.updateSliderProgress(this.nIndex + 1));
            }
            else {
                let t = ToolUtils.timeStr2(this.nTime, true);
                Utils.shared().showToast(ToolUtils.format(i18nMgr.shared().getValueByKey("add_cash_limits.submit_tips"), t), 3, 0, ToolUtils.getIsNormalDirection());
            }
        }
        else if ("add" == i) {
            if (this.nTime <= 0) {
                this.vLimitList && this.vLimitList.length > 1 && this.nIndex < this.vLimitList.length - 1 && (this.nIndex = this.nIndex + 1, this.updateSliderProgress(this.nIndex + 1));
            }
            else {
                let t = ToolUtils.timeStr2(this.nTime, true);
                Utils.shared().showToast(ToolUtils.format(i18nMgr.shared().getValueByKey("add_cash_limits.submit_tips"), t), 3, 0, ToolUtils.getIsNormalDirection());
            }
        }
        else if ("submit" == i && this.nTime <= 0) {
            let t = Number(ToolUtils.getPureNumberString(this.monthly_money.string)), i = Number(ToolUtils.getPureNumberString(this.daily_money.string)), e = Number(ToolUtils.getPureNumberString(this.weekly_money.string));
            this.vLimitList && this.vLimitList.length > 1 && (t <= this.vLimitList[this.vLimitList.length - 1] ? (Utils.shared().showLoading(10, true, (() => {
                Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
            })), HttpManager.shared().doPayDefSetLimit(t, i, e, this.listenPayDefSetLimitCallback.bind(this))) : Utils.shared().showToast(i18nMgr.shared().getValueByKey("add_cash_limits.submit_failed"), 3, 0, ToolUtils.getIsNormalDirection()));
        }
    }
    onEditDidEnded(t, i) {
        this.editBox.node.active = false;
        this.monthly_money.node.active = true;
        this.edit_btn.interactable = true;
        let e = ToolUtils.getPureNumberString2(this.editBox.string), s = Math.floor(Number(e));
        this.nIndex = this.getCurIndexMoney(s);
        this.updateSliderProgress(this.nIndex + 1);
        this.updateSlidBtnStatus();
        this.monthly_money.string = "" + s;
        this.daily_money.string = "₹" + Math.floor(0.33 * s);
        this.weekly_money.string = "₹" + Math.floor(0.66 * s);
    }
    onSliderCallback(t, i) {
        let e = 0, s = this.slider.node.getChildByName("ProgressBar"), n = this.slider.progress;
        s.getComponent(ProgressBar).progress = n;
        this.vLimitList && this.vLimitList.length > 1 && (e = Math.floor((this.vLimitList.length - 1) * n + 0.5));
        this.nTime <= 0 ? this.updateSliderProgress(e + 1) : this.updateSliderProgress(this.nIndex + 1);
    }
    updateSliderProgress(t, i = true) {
        let e = this.slider.node.getChildByName("ProgressBar");
        if (this.vLimitList && this.vLimitList.length > 1) {
            i && this.nIndex != t - 1 && SoundManager.shared().playFx("select_time");
            this.nIndex = t - 1;
            let s = (t - 1) / (this.vLimitList.length - 1);
            this.slider.getComponent(Slider).progress = s;
            e.getComponent(ProgressBar).progress = s;
            this.updateLimitMoney(t);
        }
        else {
            this.nIndex = 0;
            this.slider.getComponent(Slider).progress = 0;
            e.getComponent(ProgressBar).progress = 0;
            this.updateLimitMoney(1);
        }
        this.updateSlidBtnStatus();
    }
    fitScreen() {
        ToolUtils.adaptSafeArea(this.node.getChildByName("root"), 1);
        this.setUiEdgeDistance(this.submit_btn.node, 68, 3, false);
        this.setUiEdgeDistance(this.reset_time, 139, 3, false);
        2 == i18nMgr.shared().language ? this.rootNode.getChildByName("info_top").getChildByName("label_nodes").getChildByName("monthly_limit_tips").getComponent(Label).fontSize = 22 : 3 == i18nMgr.shared().language && (this.rootNode.getChildByName("info_top").getChildByName("label_nodes").getChildByName("daily_limit_tips").getComponent(Label).horizontalAlign = HorizontalTextAlignment.RIGHT);
    }
    onBackView() {
        ToolUtils.isObjValid(this.node) && (this.callback && this.callback(), this.node.destroy());
    }
    onDestroy() {
        super.onDestroy();
        this.unscheduleAllCallbacks();
    }
}
