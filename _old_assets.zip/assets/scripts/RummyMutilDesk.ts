// @ts-nocheck
// Recovered from index.js:469
import { _decorator, Component, color, Label, LabelOutline, Node, size, sp, Sprite, SpriteAtlas, SpriteFrame, sys, UIOpacity, UITransform, Vec3 } from "cc";
import PushCenter from "./PushCenter";
import { TLog } from "./TLog";
import TweenTool from "./TweenTool";
import Utils from "./Utils";
import GameConfig from "./GameConfig";
import PushEvent from "./PushEvent";
import User from "./User";
import SoundManager from "./SoundManager";
import RummyDataManager from "./RummyDataManager";
import i18nMgr from "./i18nMgr";
import CommDefine from "./CommDefine";
import { HttpRequest } from "./HttpRequestName";
import HttpManager from "./HttpManager";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("RummyMutilDesk")
export class RummyMutilDesk extends Component {
    public TAG: string = "RummyMutilDesk";
    @property([SpriteFrame])
    public desk_di_imgs: SpriteFrame[] = [];
    @property([Node])
    public desk_nodes: Node[] = [];
    @property([SpriteAtlas])
    public table_css: SpriteAtlas[] = [];
    @property([Node])
    public add_nodes: Node[] = [];
    @property([Node])
    public add_lock_nodes: Node[] = [];
    @property([Node])
    public small_desks: Node[] = [];
    @property(Node)
    public treahunt_reward_anim: Node = null;
    @property([SpriteFrame])
    public player_state_imgs: SpriteFrame[] = [];
    @property([SpriteFrame])
    public four_player_tables: SpriteFrame[] = [];
    public dzCallback: any = null;
    public playerPostions: any[] = [];
    public playersInfo: Map = new Map;
    public timePlays: Map = new Map;
    public deskCds: Map = new Map;
    public seatInfo: Map = new Map;
    public desk_tid_keys: any[] = [];
    public desk_msg: Map = new Map;
    public time_node: any = null;
    public stepDt: number = 0.1;
    public flickerAction: Map = new Map;
    public deskSelfOpseat: Map = new Map;
    public matchTipsInfo: Map = new Map;
    public play_info: any = null;
    buttonClick(e, t) {
        let s = Number(t);
        s > 0 && (s -= 1, this.chooseDesk(s));
        this.dzCallback && this.dzCallback(t);
    }
    boxBtnClick(e, t) {
        let s = Number(t) - 1;
        this.onDealTreasureHuntBoxReward(s);
    }
    onDealTreasureHuntBoxReward(e) {
        let t = this.desk_tid_keys[e], s = RummyDataManager.shared().rummyInfos.get(t).vid, i = RummyDataManager.shared().rummyInfos.get(t).pnum;
        HttpManager.shared().doGetCommonRequest({ vid: s, player: i }, HttpRequest.GetTreaHuntRank_REWARD_CHIP, ((e, i, a) => {
            if (200 != a) {
                ;
            }
            else {
                let e = ToolUtils.parseJson(i);
                if (0 == e.ret && ToolUtils.isObjValid(this.node)) {
                    if (sys.isObjectValid(e.data.reward_list) && Array.isArray(e.data.reward_list) && e.data.reward_list.length > 0) {
                        User.shared().showChargeReward(e.data.reward_list, (e => {
                        }), e.data.msg);
                        let i = 0, a = 0;
                        sys.isObjectValid(e.data.show_box) && (i = Number(e.data.show_box));
                        sys.isObjectValid(e.data.show_box) && (a = Number(e.data.box_type));
                        RummyDataManager.shared().rummyInfos.get(t).show_box_act97 = i;
                        RummyDataManager.shared().rummyInfos.get(t).box_type_act97 = a;
                        RummyDataManager.shared().rummyInfos.get(t).act97_data = e.data;
                        let d = { vid: s, show_box: i, box_type: a, data: e.data, pnum: RummyDataManager.shared().rummyInfos.get(t).pnum, gameBaseMoney: RummyDataManager.shared().rummyInfos.get(t).gameBaseMoney };
                        PushCenter.shared().pushEvent(PushEvent.UpdateTreaBoxStateInGame, d);
                    }
                    else if (sys.isObjectValid(e.data.show_box)) {
                        RummyDataManager.shared().rummyInfos.get(t).show_box_act97 = Number(e.data.show_box);
                        RummyDataManager.shared().rummyInfos.get(t).box_type_act97 = Number(e.data.box_type);
                        RummyDataManager.shared().rummyInfos.get(t).act97_data = e.data;
                        let i = { vid: s, show_box: Number(e.data.show_box), box_type: Number(e.data.box_type), data: e.data, pnum: RummyDataManager.shared().rummyInfos.get(t).pnum, gameBaseMoney: RummyDataManager.shared().rummyInfos.get(t).gameBaseMoney };
                        PushCenter.shared().pushEvent(PushEvent.UpdateTreaBoxStateInGame, i);
                    }
                }
            }
        }));
    }
    addButtonClick(e, t) {
        if (SoundManager.shared().playFx("click"), Number(t) > 1) {
            let e = Utils.shared().judgeMutliTableUnlock();
            if (e && !e.openBol) {
                return void Utils.shared().showMutliTableUnlockToast(e.num);
            }
        }
        this.dzCallback && this.dzCallback(0);
    }
    start() {
        this.initDeskbg();
        this.initDeskPlay();
        this.initPushCenter();
    }
    checkIsMatchRoom(e = "") {
        let t = e.length > 0 ? e : User.shared().curTid_key, s = ToolUtils.deskInfos.get(t), i = false;
        s && 4 == s.mode && 3 != s.match_mode && (i = true);
        let a = RummyDataManager.shared().rummyInfos.get(t);
        return sys.isObjectValid(a) && 4 == a.gameRummyType && 3 != a.gameMatchMode && (i = true), i;
    }
    initDeskbg() {
        for (let e = 0, t = this.small_desks.length; e < t; e++) {
            let t = this.desk_nodes[e].getChildByName("di"), s = this.desk_nodes[e].getChildByName("desk_ic"), i = this.desk_nodes[e].getChildByName("type"), a = this.desk_nodes[e].getChildByName("type2");
            i.getComponent(Label).color = color(255, 255, 255, 255);
            a.getComponent(LabelOutline).color = color(0, 0, 0, 110);
            let d = this.checkIsMatchRoom(this.desk_tid_keys[e]) ? 5 : 0;
            Utils.shared().setImage(t, "rummy_dz_cur_desk_di", this.table_css[d]);
            Utils.shared().setImage(this.add_nodes[e], "rummy_dz_addgame", this.table_css[d]);
            Utils.shared().setImage(s, "rummy_dz_desk", this.table_css[d]);
            sys.isObjectValid(this.desk_tid_keys[e]) && this.desk_tid_keys[e] == CommDefine.NewerGuideRoomTidkey && (this.desk_nodes[e].getChildByName("fen_di").getChildByName("fen").getComponent(Label).string = "");
            sys.isObjectValid(this.desk_tid_keys[e]) && ToolUtils.deskInfos.get(this.desk_tid_keys[e]) && 1 == ToolUtils.deskInfos.get(this.desk_tid_keys[e]).special_mode && (s.getComponent(Sprite).spriteFrame = this.four_player_tables[0]);
            sys.isObjectValid(this.desk_tid_keys[e]) && RummyDataManager.shared().rummyInfos.has(this.desk_tid_keys[e]) && this.pushToUpdateOpenCardDesk(e, s);
        }
    }
    pushToUpdateOpenCardDesk(e, t, s = false) {
        if (sys.isObjectValid(this.desk_tid_keys[e]) && ToolUtils.isObjValid(t)) {
            let i = {};
            i.tid_key = this.desk_tid_keys[e];
            i.spriteFrame = t.getComponent(Sprite).spriteFrame;
            RummyDataManager.shared().openCardInfos.set(this.desk_tid_keys[e], i);
            s && PushCenter.shared().pushEvent(PushEvent.UpdateOpenCardDeskImage, i);
        }
    }
    refreshDeskIc(e, t) {
        let s = this.desk_nodes[e].getChildByName("desk_ic");
        if (1 == t) {
            s.getComponent(Sprite).spriteFrame = this.four_player_tables[User.shared().styles[0] - 1];
        }
        else {
            let t = this.checkIsMatchRoom(this.desk_tid_keys[e]) ? 5 : 0;
            Utils.shared().setImage(s, "rummy_dz_desk", this.table_css[t]);
        }
        this.pushToUpdateOpenCardDesk(e, s);
    }
    initPushCenter() {
        PushCenter.shared().addListener(PushEvent.UpdateRaceCSS, (() => {
            for (let e = 0, t = this.small_desks.length; e < t; e++) {
                let t = this.desk_nodes[e].getChildByName("desk_ic"), s = this.desk_nodes[e].getChildByName("type"), i = this.desk_nodes[e].getChildByName("type2");
                s.getComponent(Label).color = color(0, 69, 34, 255);
                i.getComponent(LabelOutline).color = color(0, 69, 34, 255);
                this.chooseDesk(User.shared().curDeskIndex);
                this.changePlayerCss(this.desk_nodes[e], e);
                let a = this.checkIsMatchRoom(this.desk_tid_keys[e]) ? 5 : 0;
                sys.isObjectValid(this.desk_tid_keys[e]) && ToolUtils.deskInfos.get(this.desk_tid_keys[e]) && 1 == ToolUtils.deskInfos.get(this.desk_tid_keys[e]).special_mode ? t.getComponent(Sprite).spriteFrame = this.four_player_tables[0] : Utils.shared().setImage(t, "rummy_dz_desk", this.table_css[a]);
                Utils.shared().setImage(this.add_nodes[e], "rummy_dz_addgame", this.table_css[a]);
                this.pushToUpdateOpenCardDesk(e, t, true);
            }
        }), this);
        PushCenter.shared().addListener(GameConfig.Update_Mutil_Desk_Info, (e => {
            this.updateDeskinfo(e);
        }), this);
        PushCenter.shared().addListener(PushEvent.UpdateTreaBoxStateInGame, (e => {
            this.updateTreaBoxStatus(e);
        }), this);
    }
    onDestroy() {
        PushCenter.shared().removeListenersByTag(this);
        this.unscheduleAllCallbacks();
        TweenTool.stopNodeAction(this.time_node);
    }
    chooseDesk(e) {
        let t;
        User.shared().curDeskIndex = e;
        let s = this.checkIsMatchRoom() ? 5 : 0;
        for (let i = 0, a = this.desk_nodes.length; i < a; i++) {
            if (t = this.desk_nodes[i].getChildByName("di").getComponent(Sprite), i == e) {
                t.spriteFrame = this.table_css[s].getSpriteFrame(this.desk_di_imgs[1].name);
                this.small_desks[i].setSiblingIndex(3);
            }
            else {
                if (t.spriteFrame = this.table_css[s].getSpriteFrame(this.desk_di_imgs[0].name), this.desk_tid_keys.length > i) {
                    let e = this.desk_tid_keys[i];
                    if (this.timePlays.get(e)) {
                        (this.timePlays.get(e) || 0 == RummyDataManager.shared().rummyInfos.get(e).auto_drop_type) && (t.spriteFrame = this.table_css[s].getSpriteFrame(this.desk_di_imgs[2].name));
                    }
                }
                this.small_desks[i].setSiblingIndex(0);
            }
        }
        this.refreshTeaBoxStatus();
    }
    updateTreaBoxStatus(e) {
        let t = new Map, s = this.desk_tid_keys[User.shared().curDeskIndex], i = RummyDataManager.shared().rummyInfos.get(s);
        sys.isObjectValid(i) && i.pnum == e.pnum && i.gameBaseMoney == e.gameBaseMoney && (RummyDataManager.shared().rummyInfos.get(s).show_box_act97 = e.show_box, RummyDataManager.shared().rummyInfos.get(s).box_type_act97 = e.box_type, 1 == e.show_box && t.set(e.pnum + "_" + e.gameBaseMoney, 1));
        for (let s = 0; s < this.desk_tid_keys.length; s++) {
            let i = this.desk_tid_keys[s], a = RummyDataManager.shared().rummyInfos.get(i);
            sys.isObjectValid(a) && a.pnum == e.pnum && a.gameBaseMoney == e.gameBaseMoney && -1 != User.shared().act_97_recommend_list.indexOf(String(a.vid)) && (this.desk_nodes[s].getChildByName("box").active = 1 == e.show_box, RummyDataManager.shared().rummyInfos.get(i).show_box_act97 = e.show_box, RummyDataManager.shared().rummyInfos.get(i).box_type_act97 = e.box_type, RummyDataManager.shared().rummyInfos.get(i).act97_data = e.data, 1 == e.show_box && (this.desk_nodes[s].getChildByName("box").getChildByName("box0").getComponent(sp.Skeleton).clearTracks(), this.desk_nodes[s].getChildByName("box").getChildByName("box0").getComponent(sp.Skeleton).setToSetupPose(), this.desk_nodes[s].getChildByName("box").getChildByName("box0").getComponent(sp.Skeleton).setAnimation(0, "loopchip2", true)), 1 == e.show_box && (t.has(e.pnum + "_" + e.gameBaseMoney) && 1 == t.get(e.pnum + "_" + e.gameBaseMoney) ? this.desk_nodes[s].getChildByName("box").active = false : t.set(e.pnum + "_" + e.gameBaseMoney, 1)), User.shared().curDeskIndex == s && (this.desk_nodes[s].getChildByName("box").active = false));
        }
    }
    refreshTeaBoxStatus() {
        let e = new Map, t = this.desk_tid_keys[User.shared().curDeskIndex], s = RummyDataManager.shared().rummyInfos.get(t);
        sys.isObjectValid(s) && -1 != User.shared().act_97_recommend_list.indexOf(String(s.vid)) && 1 == s.show_box_act97 && e.set(s.pnum + "_" + s.gameBaseMoney, 1);
        for (let t = 0; t < this.desk_tid_keys.length; t++) {
            let s = this.desk_tid_keys[t], i = RummyDataManager.shared().rummyInfos.get(s);
            sys.isObjectValid(i) && -1 != User.shared().act_97_recommend_list.indexOf(String(i.vid)) && sys.isObjectValid(i) && sys.isObjectValid(i.show_box_act97) && (this.desk_nodes[t].getChildByName("box").active = 1 == i.show_box_act97, 1 == i.show_box_act97 && (this.desk_nodes[t].getChildByName("box").getChildByName("box0").getComponent(sp.Skeleton).clearTracks(), this.desk_nodes[t].getChildByName("box").getChildByName("box0").getComponent(sp.Skeleton).setToSetupPose(), this.desk_nodes[t].getChildByName("box").getChildByName("box0").getComponent(sp.Skeleton).setAnimation(0, "loopchip2", true)), 1 == i.show_box_act97 && (e.has(i.pnum + "_" + i.gameBaseMoney) && 1 == e.get(i.pnum + "_" + i.gameBaseMoney) ? this.desk_nodes[t].getChildByName("box").active = false : e.set(i.pnum + "_" + i.gameBaseMoney, 1)), User.shared().curDeskIndex == t && (this.desk_nodes[t].getChildByName("box").active = false));
        }
    }
    setCallBack(e) {
        this.dzCallback = e;
    }
    initDeskPlay() {
        for (let e = 0, t = this.desk_nodes.length; e < t; e++) {
            this.desk_tid_keys.length > e ? this.timePlays.set(this.desk_tid_keys[e], false) : this.timePlays.set("", false);
            let t = { cur_cd: 0, timestate: 0, delay_cd: 0 };
            if (this.deskCds.set("", t), 0 == e) {
                let t = "";
                for (let s = 0; s < 6; s++) {
                    t = "player" + s;
                    this.playerPostions[s] = this.desk_nodes[e].getChildByName(t).getPosition();
                }
            }
        }
        this.time_node = new Node;
        this.node.addChild(this.time_node);
        TweenTool.myschedule(this.time_node, this.stepDt, this.updateDeskTime.bind(this));
    }
    changePlayerVisible(e, t, s) {
        let i = "player" + e;
        const a = t.getChildByName(i);
        ToolUtils.isObjValid(a) && (a.active = s);
    }
    changePlayerState(e, t, s, i) {
        let a = "player" + e;
        const d = t.getChildByName(a);
        if (ToolUtils.isObjValid(d)) {
            let e = this.checkIsMatchRoom(this.desk_tid_keys[i]) ? 5 : 0;
            Utils.shared().setImage(d, String(this.player_state_imgs[s].name), this.table_css[e]);
        }
    }
    changePlayerCss(e, t) {
        let s = this.checkIsMatchRoom(this.desk_tid_keys[t]) ? 5 : 0;
        for (let t = 0; t < 6; t++) {
            let i = "player" + t;
            const a = e.getChildByName(i);
            ToolUtils.isObjValid(a) && (a.getComponent(Sprite).spriteFrame.name == this.player_state_imgs[0].name ? Utils.shared().setImage(a, String(this.player_state_imgs[0].name), this.table_css[s]) : a.getComponent(Sprite).spriteFrame.name == this.player_state_imgs[1].name ? Utils.shared().setImage(a, String(this.player_state_imgs[1].name), this.table_css[s]) : a.getComponent(Sprite).spriteFrame.name == this.player_state_imgs[2].name && Utils.shared().setImage(a, String(this.player_state_imgs[2].name), this.table_css[s]));
        }
    }
    getPosBySeatid(e, t) {
        if (!this.seatInfo.has(t)) {
            return;
        }
        let s = e - this.seatInfo.get(t).seatid;
        return s >= 0 ? s : s + this.seatInfo.get(t).pnum;
    }
    refreshSmallDesk(e, t, s, i, a) {
        try {
            this.play_info = e;
            let i = { seatid: e.seatid, pnum: e.pnum };
            this.seatInfo.set(ToolUtils.isSafeString(e.tid_key), i);
            for (let e = 1; e < 6; e++) {
                this.changePlayerState(e, t, 0, s);
            }
            if (this.changePlayerState(0, t, 1, s), 2 == e.pnum) {
                for (let e = 0; e <= 5; e++) {
                    e <= 1 ? this.changePlayerVisible(e, t, true) : this.changePlayerVisible(e, t, false);
                }
                let e = "player1";
                t.getChildByName(e).setPosition(this.playerPostions[3]);
            }
            else if (4 == e.pnum) {
                for (let e = 0; e <= 5; e++) {
                    e <= 3 ? this.changePlayerVisible(e, t, true) : this.changePlayerVisible(e, t, false);
                }
                t.getChildByName("player2").setPosition(this.playerPostions[3]);
                t.getChildByName("player3").setPosition(this.playerPostions[5]);
            }
            else {
                for (let e = 0; e <= 5; e++) {
                    this.changePlayerVisible(e, t, true);
                }
                let e = "player1";
                t.getChildByName(e).setPosition(this.playerPostions[1]);
            }
            if (e.players) {
                for (const i in e.players) {
                    let a = e.players[i], d = this.getPosBySeatid(a.seatid, e.tid_key);
                    "number" == typeof a.small_status && this.changePlayerState(d, t, a.small_status, s);
                    this.changePlayerVisible(d, t, true);
                }
            }
            let d = t.getChildByName("type2").getComponent(Label), n = t.getChildByName("type").getComponent(Label);
            n.string = e.gametype + "";
            let o = t.getChildByName("fen_di"), h = o.getChildByName("fen").getComponent(Label), r = t.getChildByName("di").getComponent(Sprite), _ = new Vec3, m = o.getChildByName("icon");
            if (e.tid_key == CommDefine.NewerGuideRoomTidkey) {
                h.string = "";
                m.active = false;
            }
            else if (1 == e.game_type) {
                h.string = ToolUtils.parse_ChipNum2(e.point_value) + "";
                let t = h.node.getComponent(UITransform);
                h.node.setPosition(10, _.y, _.z);
                h.node.getPosition(_);
                TweenTool.delayAct(this.time_node, (() => {
                    if (ToolUtils.isObjValid(m)) {
                        m.active = true;
                        let e = _.x - 0.5 * t.width / 2 - 13;
                        m.setPosition(e, m.getPosition().y, 0);
                    }
                }), 0.1, true);
            }
            else {
                h.node.setPosition(0, _.y, _.z);
                0 == e.point_value ? h.string = "free" : h.string = "₹" + ToolUtils.parse_double("" + e.point_value);
                m.active = false;
            }
            let y = t.getChildByName("time_di"), p = y.getChildByName("Label").getComponent(Label), u = e.cur_cd, f = e.delay_cd, b = e.timestate, I = { cur_cd: u, timestate: b, delay_cd: f };
            true === a && this.deskCds.has(e.tid_key) && (I = this.deskCds.get(e.tid_key));
            this.deskCds.set(ToolUtils.isSafeString(e.tid_key), I);
            let B = false, S = 0;
            0 == b ? (u >= 1 ? S = I.cur_cd : (I.cur_cd = 0, S = I.delay_cd), I.cur_cd + I.delay_cd > 0 && (B = true)) : 1 == b && f > 0 && (B = true, S = f);
            p.string = "" + S;
            User.shared().curTid_key === ToolUtils.isSafeString(e.tid_key) && (B = false);
            User.shared().curDeskIndex === s && (B = false);
            y.active = B;
            this.deskSelfOpseat.set(ToolUtils.isSafeString(e.tid_key), e.opseatid === e.seatid);
            let N = this.checkIsMatchRoom() ? 5 : 0;
            this.refreshDeskIc(s, ToolUtils.deskInfos.get(e.tid_key).special_mode);
            e.opseatid === e.seatid ? (this.timePlays.set(ToolUtils.isSafeString(e.tid_key), true), User.shared().curDeskIndex == s ? r.spriteFrame = this.table_css[N].getSpriteFrame(this.desk_di_imgs[1].name) : 0 == RummyDataManager.shared().rummyInfos.get(e.tid_key).auto_drop_type && (r.spriteFrame = this.table_css[N].getSpriteFrame(this.desk_di_imgs[2].name))) : (y.active = false, I.cur_cd = -1, I.delay_cd = -1, this.deskCds.set(ToolUtils.isSafeString(e.tid_key), I), this.timePlays.set(ToolUtils.isSafeString(e.tid_key), false), User.shared().curDeskIndex == s ? r.spriteFrame = this.table_css[N].getSpriteFrame(this.desk_di_imgs[1].name) : r.spriteFrame = this.table_css[N].getSpriteFrame(this.desk_di_imgs[0].name));
            let w = false, P = e.table_status;
            if (ToolUtils.isSafeString(e.money_desc).length > 0 && (P = e.money_desc + ToolUtils.parse_double(e.money_value, -1)), ToolUtils.isSafeString(P).length > 0 && (d.string = ToolUtils.isSafeString(P)), 1 === e.player_state) {
                w = true;
            }
            else if (2 === e.player_state) {
                w = true;
            }
            else if (3 === e.player_state) {
                w = true;
            }
            else if (4 === e.player_state) {
                w = true;
            }
            else if (5 === e.player_state && ToolUtils.isSafeString(P).length > 0) {
                w = true;
                for (let e = 0; e <= 5; e++) {
                    this.changePlayerVisible(e, t, false);
                }
            }
            n.node.active = !w;
            d.node.active = w;
            w ? (y.active = false, I.cur_cd = 0, I.delay_cd = 0, o.active = false, this.deskCds.set(ToolUtils.isSafeString(e.tid_key), I)) : o.active = true;
            this.desk_msg.set(ToolUtils.isSafeString(e.tid_key), e);
        }
        catch (e) {
            TLog.printError("refreshSmallDesk,error", e);
        }
    }
    refreshLocalDesk(e, t, s) {
        if (this.desk_msg.has(s)) {
            let i = this.desk_msg.get(s);
            this.refreshSmallDesk(i, e, t, s);
        }
    }
    updateDeskTime() {
        for (let e = 0, t = this.desk_nodes.length; e < t; e++) {
            let t = this.desk_nodes[e].getChildByName("di"), s = this.desk_nodes[e].getChildByName("time_di"), i = s.getChildByName("Label").getComponent(Label), a = false, d = false;
            if (this.desk_tid_keys.length > e) {
                let s = this.desk_tid_keys[e], n = false;
                if (this.deskCds.get(s)) {
                    let o = this.deskCds.get(s), h = 0, r = 0;
                    if (0 == o.timestate ? (o.cur_cd = o.cur_cd - this.stepDt, o.cur_cd >= 0 ? (h = Math.floor(o.cur_cd), h <= 0 && (h = Math.floor(o.delay_cd)), h >= 0 && (r = h, a = true, Math.floor(10 * o.cur_cd) % 10 == 0 && (n = true))) : (o.delay_cd = o.delay_cd - this.stepDt, o.delay_cd >= 0 && (h = Math.floor(o.delay_cd), r = h, a = true, Math.floor(10 * o.delay_cd) % 10 == 0 && (n = true)))) : 1 == o.timestate && (o.delay_cd = o.delay_cd - this.stepDt, o.delay_cd >= 0 && (a = true, h = Math.floor(o.delay_cd), r = h, Math.floor(10 * o.delay_cd) % 10 == 0 && (n = true))), n && (i.string = "" + h), this.deskCds.set(s, o), User.shared().curTid_key != s && r > 0 && r <= 10 && a && this.deskSelfOpseat.has(s) && this.deskSelfOpseat.get(s) && (d = true, (User.shared().curDeskIndex === e || RummyDataManager.shared().rummyInfos.get(s).auto_drop_type > 0) && (d = false), n && d && !this.flickerAction.has(s))) {
                        let e = TweenTool.flickerOpacity(t, t.getPosition(), 1, 0.5, 0.8);
                        this.flickerAction.set(s, e);
                    }
                }
                if (d || this.stopFlickerAction(s, e), User.shared().curTid_key === s && (a = false), User.shared().curDeskIndex === e && (a = false, this.stopFlickerAction(s, e)), this.matchTipsInfo.has(s)) {
                    let t = this.matchTipsInfo.get(s);
                    t.duration > 0 ? (t.duration = t.duration - this.stepDt, this.matchTipsInfo.set(s, t), this.updateMatchTipsState(true, e, t.raceName)) : (this.updateMatchTipsState(false, e), this.matchTipsInfo.delete(s));
                }
            }
            s.active = a;
        }
    }
    stopFlickerAction(e, t) {
        this.flickerAction.has(e) && (this.flickerAction.get(e).stop(), this.flickerAction.delete(e));
        const s = this.desk_nodes[t];
        ToolUtils.isObjValid(s) && (s.getChildByName("di").getComponent(UIOpacity).opacity = 255);
    }
    setMatchTipsInfo(e, t, s) {
        let i = { duration: t, raceName: s };
        this.matchTipsInfo.set(e, i);
    }
    updateMatchTipsState(e, t, s) {
        const i = this.desk_nodes[t];
        if (i) {
            let t = i.getChildByName("match_tips");
            if (e != t.active && (t.active = e, null != s && "" != s)) {
                let e = t.getChildByName("tips");
                i18nMgr.shared().changeLabelLanguage(e.getComponent(Label), "rummy_main.match_has_started", false, s);
                this.scheduleOnce((() => {
                    if (ToolUtils.isObjValid(e)) {
                        let s = e.getComponent(UITransform).contentSize;
                        t.getComponent(UITransform).contentSize = size(s.width + 10, 38);
                    }
                }), 0);
            }
        }
    }
    refreshTidKeys(e) {
        this.desk_tid_keys = e;
        for (let e = 0, t = this.desk_nodes.length; e < t; e++) {
            const t = this.desk_nodes[e];
            this.desk_tid_keys.length > e && (1 === GameConfig.SERVER_DEBUG ? (t.getChildByName("tid_key").active = false, t.getChildByName("tid_key").getComponent(Label).string = this.desk_tid_keys[e] + "") : t.getChildByName("tid_key").active = false, t.getChildByName("tid_key").active = false);
        }
    }
    updateDeskinfo(e) {
        if (this.deskCds.get(e.tid_key)) {
            let t = this.deskCds.get(e.tid_key);
            t.cur_cd = -1;
            t.delay_cd = -1;
            this.desk_msg.delete(e.tid_key);
            this.timePlays.set(ToolUtils.isSafeString(e.tid_key), false);
            this.reSetSamllDesk(e.tid_key);
        }
    }
    reSetSamllDesk(e) {
        let t = -1;
        for (let s = 0, i = this.desk_tid_keys.length; s < i; s++) {
            this.desk_tid_keys[s] === e && (t = s);
        }
        if (-1 !== t) {
            let s = this.checkIsMatchRoom() ? 5 : 0;
            let i = this.desk_nodes[t].getChildByName("di").getComponent(Sprite);
            if (e == User.shared().curTid_key) {
                i.spriteFrame = this.table_css[s].getSpriteFrame(this.desk_di_imgs[1].name);
            }
            else if (i.spriteFrame = this.table_css[s].getSpriteFrame(this.desk_di_imgs[0].name), this.desk_tid_keys.length > t) {
                let e = this.desk_tid_keys[t];
                this.timePlays.get(e) && this.timePlays.set(e, false);
            }
        }
    }
    changeSmallDeskUIVisibile(e, t) {
        this.desk_nodes.length > e && (t && (this.small_desks[e].active = t, this.desk_tid_keys[e] && ToolUtils.deskInfos.get(this.desk_tid_keys[e]) && this.refreshDeskIc(e, ToolUtils.deskInfos.get(this.desk_tid_keys[e]).special_mode)), this.desk_nodes[e].active = t, this.add_nodes[e].active = !t, 1 == User.shared().isInPerformanceRoom && (this.desk_nodes[e].active = false, this.add_nodes[e].active = false, this.small_desks[e].active = false));
    }
    changeAddVisibile(e, t) {
        this.desk_nodes.length > e && (this.desk_nodes[e].active = !t, 1 == User.shared().isInPerformanceRoom && (t = false), this.small_desks[e].active = t, this.add_nodes[e].active = t);
    }
    changeAddLockVisible(e, t) {
        if (e < 0 || e >= this.desk_nodes.length) {
            return;
        }
        let s = t;
        if (1 === User.shared().isInPerformanceRoom || 0 == e) {
            s = false;
        }
        else {
            let e = Utils.shared().judgeMutliTableUnlock();
            s && e && (s = !e.openBol);
        }
        this.add_lock_nodes[e].active = s;
    }
    resetSmallTable(e) {
        const t = this.desk_nodes[e];
        t.getChildByName("type").getComponent(Label).string = "";
        t.getChildByName("fen_di").getChildByName("fen").getComponent(Label).string = "";
        t.getChildByName("match_tips").active = false;
    }
}
