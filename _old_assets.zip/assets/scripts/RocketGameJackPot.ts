// @ts-nocheck
// Recovered from index.js:399
import { _decorator, Label, Node, sys, UITransform } from "cc";
import BaseLayer from "./BaseLayer";
import PushCenter from "./PushCenter";
import SoundManager from "./SoundManager";
import { ToolUtils } from "./ToolUtils";
import TableViewUtils from "./TableViewUtils";
import HttpManager from "./HttpManager";
import { HttpRequest } from "./HttpRequestName";
const { ccclass, property } = _decorator;
@ccclass("RocketGameJackPot")
export class RocketGameJackPot extends BaseLayer {
    public TAG: string = "RocketGameJackPot";
    @property(Node)
    public root: Node = null;
    @property(Node)
    public moban: Node = null;
    @property(Node)
    public scrollView: Node = null;
    public _lastClick: number = 0;
    public _has_close: boolean = false;
    public gameCallback: any = null;
    public last_times: number = 0;
    public totalPage: number = 1;
    public canGetMore: boolean = true;
    public recordTabView: any = null;
    public scollToTop: boolean = false;
    public jackPotData: any[] = [];
    onLoad() {
    }
    start() {
        super.start();
        this.startShowAnim(this.root);
        ToolUtils.showFullScreen(this.node.getChildByName("bg"));
        this.initView();
    }
    initParaData(t) {
        sys.isObjectValid(t) && sys.isObjectValid(t.cb) && (this.gameCallback = t.cb);
    }
    initView() {
        let t = [this.moban];
        this.recordTabView = this.node.addComponent(TableViewUtils);
        let e = this.moban.getComponent(UITransform).height;
        this.recordTabView.init([], this.scrollView, t, this.initCurMobanCallBack.bind(this), 10, e, this.scrollRefreshCallBack.bind(this));
        this.scollToTop = true;
        this.requestRecord();
    }
    initCurMobanCallBack(t, e) {
        null != e && (t.active = true, sys.isObjectValid(e.date_text) && (t.getChildByName("date").getComponent(Label).string = e.date_text), sys.isObjectValid(e.reward) && (t.getChildByName("reward").getComponent(Label).string = e.reward), sys.isObjectValid(e.multiples) && (t.getChildByName("multiples").getComponent(Label).string = e.multiples), sys.isObjectValid(e.win_players) && (t.getChildByName("winner").getComponent(Label).string = e.win_players), sys.isObjectValid(e.bigwin_name) && (t.getChildByName("name").getComponent(Label).string = ToolUtils.GetShortName2(e.bigwin_name, 20, false)), sys.isObjectValid(e.bigwin_detail) && (t.getChildByName("win_node").getChildByName("num").getComponent(Label).string = e.bigwin_detail));
    }
    requestRecord() {
        this.recordTabView.stopAutoScroll();
        HttpManager.shared().doGetCommonRequest({ last_times: this.last_times }, HttpRequest.GetGameCrashJackPot, ((t, e, i) => {
            if (200 == i) {
                let t = ToolUtils.parseJson(e);
                if (0 == t.ret) {
                    if (this.last_times = t.data.last_times, sys.isObjectValid(t.data.list) && Array.isArray(t.data.list) && t.data.list.length > 0) {
                        for (let e = 0; e < t.data.list.length; e++) {
                            this.jackPotData.push(t.data.list[e]);
                        }
                    }
                    this.root.getChildByName("nodata").active = 0 == this.jackPotData.length;
                    this.recordTabView.reloadData(this.jackPotData, this.scollToTop);
                }
            }
        }));
    }
    scrollRefreshCallBack() {
        0 != this.last_times && (this.requestRecord(), this.scollToTop = false);
    }
    touchBtnEvent(t, e) {
        SoundManager.shared().playFx("click");
        sys.now() - this._lastClick < 500 || (this._lastClick = sys.now(), this.onBackView());
    }
    onBackView() {
        ToolUtils.isObjValid(this.node) && (this.gameCallback && this.gameCallback[-1], this.node.destroy());
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().removeListenersByTag(this);
    }
}
