// @ts-nocheck
// Recovered from index.js:47
import { _decorator, Button, director, Label, LabelShadow, Node, Sprite, SpriteFrame, v3, Vec3 } from "cc";
import SoundManager from "./SoundManager";
import Utils from "./Utils";
import PushCenter from "./PushCenter";
import { TransferPlatform } from "./TransferPlatform";
import i18nMgr from "./i18nMgr";
import BaseLayer from "./BaseLayer";
import PushEvent from "./PushEvent";
import BundleNameDefined from "./BundleNameDefined";
import CommDefine from "./CommDefine";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("BuddyRoomJoin")
export default class BuddyRoomJoin extends BaseLayer {
    @property(Node)
    public rootNode: Node = null;
    @property(Node)
    public btn_jon: Node = null;
    @property([Node])
    public numTextTab: Node[] = [];
    @property([Vec3])
    public vecRootPos: Vec3[] = [];
    @property([SpriteFrame])
    public btnBgArr: SpriteFrame[] = [];
    public numTab: any[] = [];
    start() {
        super.start();
        director.getScene().name == BundleNameDefined.rummy_scence ? (ToolUtils.getOrientation() || this.node.setRotationFromEuler(v3(0, 0, -90)), this.rootNode.getChildByName("bg").setPosition(v3(0, 0, 0))) : this.rootNode.getChildByName("bg").setPosition(v3(0, 0, 0));
        ToolUtils.showFullScreen(this.node.getChildByName("bg1"));
        this.startShowAnim(this.rootNode);
        PushCenter.shared().addListener(PushEvent.Close_BuddyRoomJoin, (t => {
            ToolUtils.isObjValid(this.node) && this.node.destroy();
        }), this);
        this.updateBtnJoinUI();
    }
    onJoinRequest() {
        let t = this.getRoomNum();
        6 == this.numTab.length && t.length > 0 && Number(t) > 0 ? Utils.shared().joinPrivateRoomByRoomId(t) : Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text35"), 3);
    }
    onclickByClose(t, e) {
        SoundManager.shared().playFx("click");
        ToolUtils.isObjValid(this.node) && (Utils.shared().hideToast(), this.node.destroy());
    }
    onPasteEvent(t, e) {
        SoundManager.shared().playFx("click");
        let n = TransferPlatform.shared().getPasteBoard();
        if (null == n || 0 == n.length) {
            return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text35"), 3);
        }
        let o = Number(n);
        if (isNaN(o)) {
            return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text35"), 3);
        }
        let i = [];
        do {
            if (i.push(o % 10), o = Math.floor(o / 10), 6 == i.length) {
                break;
            }
        } while (0 != o);
        if (this.numTab = [], 6 == i.length) {
            for (let t = 0, e = i.length; t < e; t++) {
                this.numTab[5 - t] = i[t];
            }
        }
        6 == i.length ? this.updateRoomNum() : Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text35"), 3);
    }
    onJoinEvent(t, e) {
        SoundManager.shared().playFx("click");
        let n = this.getRoomNum();
        6 == this.numTab.length && n.length > 0 && Number(n) > 0 ? this.onJoinRequest() : Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text35"), 3);
    }
    onDeleteEvent(t, e) {
        SoundManager.shared().playFx("click");
        this.numTab.length > 0 && (this.numTab.splice(this.numTab.length - 1, 1), this.updateRoomNum());
    }
    onNumberEvent(t, e) {
        SoundManager.shared().playFx("click");
        let n = Number("" + e);
        this.numTab.length < 6 && (this.numTab.push(n), this.updateRoomNum());
    }
    updateRoomNum() {
        for (let t = 0, e = this.numTextTab.length; t < e; t++) {
            null != this.numTab[t] && null != this.numTab[t] ? (this.numTextTab[t].getComponent(Label).string = String(this.numTab[t]), this.numTextTab[t].active = true) : this.numTextTab[t].active = false;
        }
        this.updateBtnJoinUI();
    }
    updateBtnJoinUI() {
        let t = false, e = this.btn_jon.getChildByName("Label");
        this.numTab && (t = this.numTab.length >= 6);
        this.btn_jon.getComponent(Button).interactable = t;
        this.btn_jon.getComponent(Sprite).spriteFrame = t ? this.btnBgArr[0] : this.btnBgArr[1];
        e && (e.getComponent(LabelShadow).color = t ? CommDefine.shadowcolor.green : CommDefine.shadowcolor.gray, Utils.updateLabelMaterial(e, t ? CommDefine.gradient.btn_green : CommDefine.gradient.btn_gray));
    }
    getRoomNum() {
        if (6 == this.numTab.length) {
            let t = "";
            for (let e = 0; e < 6; e++) {
                t += this.numTab[e];
            }
            return t;
        }
        return "";
    }
}
