// @ts-nocheck
// Recovered from index.js:93
import { _decorator, Button, director, instantiate, Label, LabelShadow, Node, Sprite, SpriteFrame, sys, v3, Vec3 } from "cc";
import PushCenter from "./PushCenter";
import Utils from "./Utils";
import PushEvent from "./PushEvent";
import User from "./User";
import SoundManager from "./SoundManager";
import BaseLayer from "./BaseLayer";
import { TransferPlatform } from "./TransferPlatform";
import BundleNameDefined from "./BundleNameDefined";
import CommDefine from "./CommDefine";
import HttpManager from "./HttpManager";
import TweenTool from "./TweenTool";
import i18nMgr from "./i18nMgr";
import { TLog } from "./TLog";
import { HttpRequest } from "./HttpRequestName";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("DailyFireSale")
export class DailyFireSale extends BaseLayer {
    @property(Node)
    public rootNode: Node = null;
    @property(Node)
    public maskNode: Node = null;
    @property(Label)
    public leftTimeLabel: Label = null;
    @property(Node)
    public itemNode: Node = null;
    @property(Node)
    public modalNode: Node = null;
    @property([SpriteFrame])
    public rewardSprites: SpriteFrame[] = [];
    @property(Node)
    public okNode: Node = null;
    @property([SpriteFrame])
    public btnSprites: SpriteFrame[] = [];
    public rechargeNode: any[] = [];
    public isNext: boolean = false;
    public isBackKey: boolean = true;
    public lastPayTime: number = 0;
    public goods_id: any = null;
    public isEnterStore: boolean = false;
    public isquick: boolean = false;
    public _nVid: number = 0;
    public _bStartCountDown: boolean = false;
    public _nCountcd: any = -1;
    public rechragePos: any[] = [];
    public _linkId: number = 0;
    public _reportScene: any = -1;
    public _bCanSend: boolean = false;
    public _pop_souce: number = 0;
    public _has_close: boolean = false;
    public _curContent: any = null;
    public _flag: number = 0;
    public _mPara: any[] = [];
    public _DailyFireSaleData: any = null;
    public _nType: number = 0;
    public _finishAnim: boolean = false;
    public TAG: string = "DailyFireSale";
    public checkKyc: number = 0;
    public _btn_status: number = 0;
    public _click_time: number = 0;
    public isRefresh: boolean = false;
    initParaData(e, t = 0) {
        this._nType = t;
        this._mPara = e;
        sys.isObjectValid(e) && (this.isNext = e.isNext, sys.isObjectValid(e.vid) ? this._nVid = e.vid : this._nVid = ToolUtils.curRoomId, sys.isObjectValid(e.isquick) && (this.isquick = e.isquick), sys.isObjectValid(e.flag) && (this._flag = e.flag), sys.isObjectValid(e.flag) && (this.checkKyc = e.checkKyc), sys.isObjectValid(e.pop_souce) && (this._pop_souce = e.pop_souce), sys.isObjectValid(e.reportScene) && (this._reportScene = e.reportScene), sys.isObjectValid(e.link_id) && e.link_id > 0 && (this._linkId = e.link_id), sys.isObjectValid(e.ext) && (this._DailyFireSaleData = e.ext), sys.isObjectValid(e.isRefresh) && (this.isRefresh = e.isRefresh));
    }
    start() {
        super.start();
        this._linkId = this._linkId > 0 ? this._linkId : sys.now();
        this._reportScene = this._reportScene >= 0 ? this._reportScene : ToolUtils.getIsInRoom() ? 2 : 1;
        let e, t = this.rootNode.getChildByName("content");
        this._curContent = t.getChildByName("item_root");
        for (let t = 0; t < 4; t++) {
            e = instantiate(this.itemNode);
            this._curContent.addChild(e);
            e.active = true;
            let i = new Vec3(0, 242 - 160 * t);
            e.setPosition(i);
            this.rechargeNode[t] = e;
            this.rechragePos[t] = i;
        }
        if (ToolUtils.showFullScreen(this.maskNode), sys.isObjectValid(this._DailyFireSaleData) && this.refreshView(), PushCenter.shared().addListener(PushEvent.CloseDailyFireSale, (e => {
            ToolUtils.isObjValid(this.node) && (this.isNext && PushCenter.shared().pushEvent(PushEvent.Update_NextPopActivity), this.node.destroy());
        }), this), PushCenter.shared().addListener(PushEvent.RefreshDailyFireSale, (e => {
            ToolUtils.isObjValid(this.node) && (this._DailyFireSaleData = e, this.refreshView());
        }), this), PushCenter.shared().pushEvent(PushEvent.HideGameOverBg), this.isRefresh ? User.shared().requestDailySalePage((e => {
            ToolUtils.isObjValid(this.node) && (this._DailyFireSaleData = e, this.refreshView(), TweenTool.commonSchedule(this.node, 1, this.scheduleCallBack.bind(this)));
        })) : TweenTool.commonSchedule(this.node, 1, this.scheduleCallBack.bind(this)), director.getScene().name == BundleNameDefined.hall_scene) {
            for (let e = 0, t = this.rechargeNode.length; e < t; e++) {
                this.rechargeNode[e].active = false;
            }
        }
        this.startShowAnim(this.rootNode, (() => {
            if (director.getScene().name == BundleNameDefined.hall_scene) {
                let e = this._DailyFireSaleData;
                e && this.startItemMoveAnim(e);
            }
        }));
    }
    startItemMoveAnim(e) {
        if (!this._finishAnim) {
            for (let t = 0, i = this.rechargeNode.length; t < i; t++) {
                TweenTool.stopNodeAction(this.rechargeNode[t]);
                this.rechargeNode[t].setPosition(v3(this.rechragePos[t].x + 660, this.rechragePos[t].y));
                this.rechargeNode[t].active = true;
                let i = TweenTool.delayAct(this.rechargeNode[t], (() => {
                    sys.isObjectValid(e.good_list) && sys.isObjectValid(e.good_list[t]) && (this.rechargeNode[t].active = true);
                }), 0.04 * t, false), a = TweenTool.moveToByFade(this.rechargeNode[t], 0.15, v3(this.rechragePos[t].x - 20, this.rechragePos[t].y), 0, 1, false), s = TweenTool.moveTo(this.rechargeNode[t], 0.1, v3(this.rechragePos[t].x + 15, this.rechragePos[t].y), null, false), r = TweenTool.moveTo(this.rechargeNode[t], 0.06, v3(this.rechragePos[t].x, this.rechragePos[t].y), null, false);
                TweenTool.sequence(this.rechargeNode[t], true, (() => {
                }), i, a, s, r);
            }
        }
        this._finishAnim = true;
    }
    dealMultipleLanguages() {
        if (3 == i18nMgr.shared().language) {
            for (let e = 0, t = this.rechargeNode.length; e < t; e++) {
                this.rechargeNode[e].getChildByName("btn_addcash").getChildByName("wz").getComponent(Label).fontSize = 20;
            }
        }
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().pushEvent(PushEvent.ShowGameOverBg);
        PushCenter.shared().removeListenersByTag(this);
        TweenTool.stopNodeAction(this.node);
        this.unscheduleAllCallbacks();
    }
    onEnable() {
        TransferPlatform.shared().setNormalFrameRate();
    }
    refreshView() {
        this.updateCashContent();
    }
    updateCashContent() {
        let e = this._DailyFireSaleData;
        if (sys.isObjectValid(e)) {
            this.startItemMoveAnim(e);
            this.startLeftTime(Number(e.time_left));
            for (let t = 0, i = this.rechargeNode.length; t < i; t++) {
                if (this.rechargeNode[t].getChildByName("layout").removeAllChildren(), sys.isObjectValid(e.good_list) && sys.isObjectValid(e.good_list[t])) {
                    this._finishAnim && (this.rechargeNode[t].active = true);
                    let i = e.good_list[t];
                    if (sys.isObjectValid(i) && sys.isObjectValid(i.reward) && Array.isArray(i.reward)) {
                        let e = i.reward;
                        for (let i = 0; i < e.length; i++) {
                            let a = e[i].type, s = e[i].num;
                            if (0 == a || 1 == a) {
                                let e = instantiate(this.modalNode);
                                e.getChildByName("icon").getComponent(Sprite).spriteFrame = this.rewardSprites[a];
                                e.getChildByName("num").getComponent(Label).string = "" + s;
                                e.active = true;
                                this.rechargeNode[t].getChildByName("layout").addChild(e);
                            }
                        }
                    }
                    let a = i.name, s = i.status;
                    this.rechargeNode[t].getChildByName("name").getComponent(Label).string = a + "";
                    let l = this.rechargeNode[t].getChildByName("claim_btn"), o = this.rechargeNode[t].getChildByName("add_cash_btn"), d = this.rechargeNode[t].getChildByName("claimed"), c = this.rechargeNode[t].getChildByName("purchased");
                    0 == t ? (l.active = 0 == s, d.active = 1 == s, o.active = false, c.active = false) : (l.active = false, d.active = false, o.active = 0 == s, c.active = 1 == s);
                    l.getComponent(Button).clickEvents[0].customEventData = String(t);
                    o.getComponent(Button).clickEvents[0].customEventData = String(t);
                    sys.isObjectValid(i.price) && (o.getChildByName("Label").getComponent(Label).string = "₹" + i.price);
                }
                else {
                    this.rechargeNode[t].active = false;
                }
            }
            let t = e.status;
            this._btn_status = t;
            let i = e.price, a = this.okNode.getChildByName("Label").getComponent(Label);
            a.string = 0 == t || 1 == t ? `₹${i} BUY ALL` : "PURCHASED";
            0 == t ? (this.okNode.getChildByName("Label").getComponent(LabelShadow).color = CommDefine.shadowcolor.green, Utils.updateLabelMaterial(this.okNode.getChildByName("Label"), CommDefine.gradient.btn_green), this.okNode.getComponent(Sprite).spriteFrame = this.btnSprites[0]) : (this.okNode.getChildByName("Label").getComponent(LabelShadow).color = CommDefine.shadowcolor.gray, Utils.updateLabelMaterial(this.okNode.getChildByName("Label"), CommDefine.gradient.btn_gray), this.okNode.getComponent(Sprite).spriteFrame = this.btnSprites[1]);
            let s = this.okNode.getChildByName("flag");
            sys.isObjectValid(e.percent) && String(e.percent).length > 0 ? (s.active = true, s.getChildByName("num").getComponent(Label).string = String(e.percent)) : s.active = false;
        }
    }
    startLeftTime(e) {
        let t = i18nMgr.shared().getValueByKey("first_recharge_text.left_time");
        if (Number.isNaN(e) || e <= 0) {
            return User.shared().getHallInfo(), void (this.leftTimeLabel.string = "Only once in a lifetime");
        }
        this._bStartCountDown = true;
        this._nCountcd = e;
        t = ToolUtils.format("${0} ${1}", t, Utils.shared().parseCountDown(this._nCountcd));
        this.leftTimeLabel.string = t;
        i18nMgr.shared().changeLabelFont(this.leftTimeLabel, false);
    }
    scheduleCallBack() {
        let e = this._DailyFireSaleData;
        if (sys.isObjectValid(e) && this._bStartCountDown) {
            if (this._nCountcd -= 1, e.time_left = this._nCountcd, this._nCountcd < 0) {
                return e.time_left = -1, User.shared().getHallInfo(), void this.onBackView();
            }
            this.leftTimeLabel.string = ToolUtils.format("${0} ${1}", i18nMgr.shared().getValueByKey("first_recharge_text.left_time"), Utils.shared().parseCountDown(this._nCountcd));
        }
    }
    onClaimBtnClick(e, t) {
        SoundManager.shared().playFx("click");
        let i = sys.now();
        i - this._click_time < 1000 || (this._click_time = i, Utils.shared().showLoading(10, true, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
        })), User.shared().dailyFireSaleData = null, HttpManager.shared().doGetCommonRequest(null, HttpRequest.DailyFireSaleReward, ((e, t, i) => {
            if (Utils.shared().hideLoading(), 200 != i) {
                ;
            }
            else {
                try {
                    let e = ToolUtils.parseJson(t);
                    if (0 == e.ret) {
                        if (sys.isObjectValid(e.data.reward_list)) {
                            let t = null;
                            sys.isObjectValid(e.data.tips) && (t = e.data.tips + "");
                            User.shared().showChargeReward(e.data.reward_list, (t => {
                                sys.isObjectValid(e.data.ext) && ToolUtils.isObjValid(this.node) && sys.isObjectValid(e.data.ext) && (this._DailyFireSaleData = e.data.ext, User.shared().dailyFireSaleData = this._DailyFireSaleData, sys.isObjectValid(this._DailyFireSaleData) && this.refreshView());
                            }), t);
                        }
                    }
                    else {
                        1 == e.ret && sys.isObjectValid(e.desc) && ToolUtils.isSafeString(e.desc).length > 0 && Utils.shared().showToast(e.desc, 2);
                    }
                }
                catch (e) {
                    TLog.printError("requestGameRatingPage err:", e.toString());
                }
            }
        })));
    }
    onAddCashBtnClick(e, t) {
        if (SoundManager.shared().playFx("click"), sys.isObjectValid(this._DailyFireSaleData) && sys.isObjectValid(this._DailyFireSaleData.good_list) && sys.isObjectValid(this._DailyFireSaleData.good_list[Number(t)]) && ToolUtils.isObjValid(this.node)) {
            if (!User.shared().checkCanRecharge()) {
                return void this.node.destroy();
            }
            let e = sys.now();
            if (e - this._click_time < 1000) {
                return;
            }
            User.shared().dailyFireSaleData = null;
            this._click_time = e;
            let i = { price: this._DailyFireSaleData.good_list[Number(t)].price, act_id: PushEvent.JUMP_TO_DailyFireSale, link_id: this._linkId };
            User.shared().startPay(i);
        }
    }
    onButtonClick(e, t) {
        if (SoundManager.shared().playFx("click"), "close" == t) {
            if (this._flag > 0) {
                return Utils.shared().showQuickRecharge(this._mPara.vid, this._mPara.parent_node, true, this._mPara.tid_key, 0, this._mPara.score, true, this._flag, this.checkKyc), void this.onBackView();
            }
            1 == this.checkKyc && Utils.shared().checkAddCashKyc();
            this.onBackView();
        }
        else {
            if (1 == this._btn_status) {
                return void Utils.shared().showToast("You've bought one pack; no combo allowed", 3);
            }
            if (2 == this._btn_status) {
                return void Utils.shared().showToast("You've bought all packs", 3);
            }
            let e = sys.now();
            if (e - this._click_time < 1000) {
                return;
            }
            if (this._click_time = e, sys.isObjectValid(this._DailyFireSaleData) && sys.isObjectValid(this._DailyFireSaleData.price) && ToolUtils.isObjValid(this.node)) {
                if (!User.shared().checkCanRecharge()) {
                    return void this.node.destroy();
                }
                User.shared().dailyFireSaleData = null;
                let e = { price: this._DailyFireSaleData.price, act_id: PushEvent.JUMP_TO_DailyFireSale, buy_all: 1, link_id: this._linkId };
                User.shared().startPay(e);
            }
        }
    }
    onBackView() {
        if (ToolUtils.isObjValid(this.node)) {
            if (this._has_close) {
                return;
            }
            this._has_close = true;
            let e = { alert_node: this.node, rootNode: this.rootNode, isNext: this.isNext, pop_type: PushEvent.JUMP_TO_DailyFireSale, pop_souce: this._pop_souce };
            Utils.shared().closeActivityView(e);
            User.shared().getHallInfo();
        }
    }
}
