// @ts-nocheck
// Recovered from index.js:315
import { _decorator, assetManager, director, error, ImageAsset, instantiate, isValid, Node, Prefab, sp, Sprite, SpriteFrame, tween } from "cc";
import PushCenter from "./PushCenter";
import { TLog } from "./TLog";
import { ToolUtils } from "./ToolUtils";
import Server from "./Server";
import SoundManager from "./SoundManager";
import Parent from "./Parent";
const { ccclass } = _decorator;
@ccclass("MyComponent")
export class MyComponent extends Parent {
    public defaultBundleName: string = "resources";
    public resCache: Set = new Set;
    public mtweenArr: any[] = [];
    setTranslateFont(e, t) {
    }
    translateLabel(e, t, r) {
    }
    addEffect(e) {
        SoundManager.shared().playFx(e);
    }
    createCocosAnimByJson() {
        return new Node;
    }
    addMusic(e) {
    }
    addEvent(e, t, r = this) {
        PushCenter.shared().addListener(e, t, r);
    }
    emitEvent(e, t = null) {
        PushCenter.shared().pushEvent(e, t);
    }
    log(e, t, r, n, l, s, o, a, i) {
    }
    logError(e, t, r, n, l, s, o, a, i) {
        TLog.printError(e, t, r, n, l, s, o, a, i);
    }
    addTweenAnim(e) {
        this.mtweenArr.includes(e) || this.mtweenArr.push(e);
    }
    deleteTweenAnim(e) {
        if (e) {
            let t = this.mtweenArr.indexOf(e);
            t >= 0 && (this.mtweenArr[t] && (this.mtweenArr[t].stop(), this.mtweenArr[t].removeSelf()), this.mtweenArr.splice(t, 1));
        }
        else {
            this.mtweenArr.forEach((e => {
                e && (e.stop(), e.removeSelf());
            }));
            this.mtweenArr = [];
        }
    }
    setListView(e, t, r, o = null, a = 0) {
        let i = [];
        if (Array.isArray(e)) {
            i = e;
        }
        else if ("object" == typeof e) {
            Object.keys(e).forEach((t => {
                i.push(e[t]);
            }));
        }
        else if ("number" == typeof e) {
            for (let t = 0; t < e; t++) {
                i.push(t);
            }
        }
        if (!isValid(t)) {
            return;
        }
        if (!o) {
            if (0 == t.children.length) {
                return;
            }
            o = t.children[0];
        }
        let d = i.length, c = t.children.length;
        if (d < c) {
            for (let e = 0; e < c - d; e++) {
                t.children[t.children.length - 1 - e].active = false;
            }
        }
        if (!d) {
            return;
        }
        let u = 0;
        for (let e = 0; e < i.length; e++) {
            const d = e;
            let c = t.children[d], h = i[e];
            c ? r && (c.active = true, r(h, c, d)) : 0 == a ? (c = instantiate(o), t.addChild(c), c.active = true, r && r(h, c, d)) : (tween(t).delay(u * a).call((() => {
                isValid(o) && (c = instantiate(o), t.addChild(c), c.active = true, r && r(h, c, d));
            })).start(), u += 1);
        }
    }
    async setSprite(e, t, l = "") {
        let s;
        if (s = "string" == typeof t && "" != t ? await this.loadResFromBundle(l, t.toString(), ImageAsset) : t, !s) {
            return;
        }
        if (e instanceof Node && (e = e.getComponent(Sprite)), !isValid(e)) {
            return;
        }
        let d = SpriteFrame.createWithImage(s);
        e.spriteFrame = d;
    }
    async loadPrefabToPop(e, t, r) {
        this.log("openpop...", t);
        let s = this;
        return new Promise((async (o, a) => {
            const i = await s.loadPrefab(e, t);
            if (!isValid(i)) {
                return;
            }
            let c = null;
            if (r) {
                if (!isValid(r)) {
                    return;
                }
                c = instantiate(i);
            }
            else {
                c = instantiate(i);
                r = director.getScene().getChildByName("Canvas").getChildByName("pop");
            }
            o(c);
            r.addChild(c);
        }));
    }
    async loadPrefab(e, t) {
        let r = this;
        return new Promise((async (l, s) => {
            let o = await r.loadResFromBundle(e, t, Prefab);
            o ? (this.log(`createPrefab succeed...${isValid(r.node) ? r.node.name : ""}`), l(o)) : this.logError(`createPrefab error...${isValid(r.node) ? r.node.name : ""}:`, error);
        }));
    }
    async setSpSkeleton(e, t, l, s) {
        if (e instanceof Node && (e.getComponent(sp.Skeleton) || e.addComponent(sp.Skeleton), e = e.getComponent(sp.Skeleton)), e.premultipliedAlpha = false, "string" == typeof t && (t = await this.loadSpSkeleton(l, t)), !t || !isValid(e)) {
            return;
        }
        e.skeletonData = t;
        let o = s && s.trackIndex ? s.trackIndex : 0, a = !(!s || !s.skin) && s.skin, i = !(!s || !s.anim) && s.anim, d = !(!s || !s.loop) && s.loop;
        a && e.setSkin(a);
        i && e.setAnimation(o, i, d);
    }
    async loadSpSkeleton(e, t) {
        let r = await this.loadResFromBundle(e, t, sp.SkeletonData);
        if (r) {
            return r;
        }
    }
    loadRemoteBundle(e, t, r) {
        ToolUtils.loadRemoteBundle(e, t, r);
    }
    preLoadBundlePrefab(e, t, r) {
        ToolUtils.loadRemoteBundle(e, t, r);
    }
    loadBundleScene(e, t, r) {
        ToolUtils.loadBundleScene(e, t, r);
    }
    preLoadGameBundle(e, t, r = true) {
        ToolUtils.preLoadGameBundle(e, t, r);
    }
    async loadResFromBundle(e, t, r, n) {
        e = e || this.defaultBundleName;
        let l = this;
        return new Promise(((s, o) => {
            assetManager.loadBundle(e, null, ((o, a) => {
                o ? (s(null), l.logError("load bundle res error 1111==", e, t, r, o)) : a.load(t, r, n, ((n, o) => {
                    n ? (s(null), l.logError("load bundle res error 2222==", e, t, r, n)) : (l.cacheAsset(o), s(o));
                }));
            }));
        }));
    }
    async preloadResFromBundle(e, t, r) {
        e = e || this.defaultBundleName;
        let n = this;
        return new Promise(((l, s) => {
            assetManager.loadBundle(e, null, ((s, o) => {
                s ? (l(false), n.logError("load bundle res error 1111==", e, t)) : o.preload(t, r, ((r, s) => {
                    r ? (n.logError("load bundle res error 2222==", e, t), l(false)) : (l(true), n.log(`load bundle res:${e}/${t}succeed`));
                }));
            }));
        }));
    }
    async preloadDir(e, t, r) {
        e = e || this.defaultBundleName;
        let n = this;
        return new Promise(((l, s) => {
            assetManager.loadBundle(e, null, ((s, o) => {
                s ? (l(false), n.logError("load bundle res error 1111==", e, t)) : o.preloadDir(t, r, ((r, s) => {
                    r ? (n.logError("load bundle res error 2222==", e, t), l(false)) : (l(true), n.log(`load bundle res:${e}/${t}succeed`));
                }));
            }));
        }));
    }
    cacheAsset(e) {
        this && this.resCache && !this.resCache.has(e) && (e.addRef(), this.resCache.add(e));
    }
    releaseAssets() {
        this.resCache.forEach((e => {
            this.log("releaseAssets", e);
            e.decRef();
        }));
        this.resCache.clear();
    }
    onDestroy() {
        this.deleteTweenAnim();
        this.releaseAssets();
        PushCenter.shared().removeListenersByTag(this);
        Server.shared().clearEventByTarget(this);
        this.unscheduleAllCallbacks();
    }
}
