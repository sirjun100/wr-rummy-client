// @ts-nocheck
// Recovered from index.js:467
import { _decorator, Label, Node, UITransform, v3 } from "cc";
import SoundManager from "./SoundManager";
import BaseLayer from "./BaseLayer";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("RummyMatchWait")
export class RummyMatchWait extends BaseLayer {
    @property(Node)
    public rootNode: Node = null;
    @property(Label)
    public titlelabel: Label = null;
    @property([Label])
    public awardLabel: Label[] = [];
    @property(Label)
    public joinedLabel: Label = null;
    @property(Label)
    public totalJoinLabel: Label = null;
    public raceName: string = "";
    public awardInfo: any = null;
    public curJoined: number = 0;
    public totalJoined: number = 0;
    public callfunc: any = null;
    onLoad() {
        this.bIsInGame = true;
    }
    start() {
        super.start();
        this.initView();
    }
    onDestroy() {
        super.onDestroy();
    }
    setMatchWaitInfo(t, e, i, a, n, o) {
        this.tid_key = t;
        this.raceName = e;
        this.awardInfo = i;
        this.curJoined = a;
        this.totalJoined = n;
        this.callfunc = o;
    }
    initView() {
        this.titlelabel.string = this.raceName;
        this.titlelabel.updateRenderData(true);
        let t = this.titlelabel.node.getComponent(UITransform).contentSize;
        if (this.rootNode.getChildByName("left_ears").setPosition(v3(-t.width / 2 - 20, 310)), this.rootNode.getChildByName("right_ears").setPosition(v3(t.width / 2 + 20, 310)), this.awardInfo && this.awardInfo.length > 0) {
            for (let t = 0; t < 4; t++) {
                if (this.awardInfo[t] && this.awardInfo[t].type && this.awardInfo[t].type.length > 0) {
                    for (let e = 0, i = this.awardInfo[t].type.length; e < i; e++) {
                        if (null != this.awardInfo[t].type[e] && 0 == this.awardInfo[t].type[e]) {
                            if (3 == t) {
                                let i = this.awardInfo[t].rank;
                                this.awardInfo[t].desc && this.awardInfo[t].desc + "" && (i = this.awardInfo[t].desc);
                                this.awardLabel[t].string = ToolUtils.format("${0}:₹${1}", i, ToolUtils.parse_double(this.awardInfo[t].value[e]));
                            }
                            else {
                                this.awardLabel[t].string = ToolUtils.format("₹${0}", ToolUtils.parse_double(this.awardInfo[t].value[e]));
                            }
                        }
                    }
                }
                else {
                    this.awardLabel[t].node.active = false;
                }
            }
            this.awardInfo.length <= 4 && (this.rootNode.getChildByName("more_btn").active = false, this.awardInfo.length < 4 && (this.rootNode.getChildByName("more_bg").active = false));
        }
        this.joinedLabel.string = ToolUtils.format("${0}", this.curJoined);
        this.totalJoinLabel.string = ToolUtils.format("/${0}", this.totalJoined);
    }
    updateJoinedNum(t) {
        this.joinedLabel.string = ToolUtils.format("${0}", t);
    }
    onButtonClick(t, e) {
        SoundManager.shared().playFx("click");
        this.callfunc && this.callfunc(e);
    }
    onBackView() {
        this.callfunc && this.callfunc("cancel");
    }
}
