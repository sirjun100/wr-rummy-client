// @ts-nocheck
// Recovered from index.js:273
import { _decorator, Label, Node, Sprite, SpriteFrame, sys, tween, Tween, v3 } from "cc";
import { ToolUtils } from "./ToolUtils";
import Utils from "./Utils";
import PushEvent from "./PushEvent";
import User from "./User";
import Server from "./Server";
import SoundManager from "./SoundManager";
import { MyComponent } from "./MyComponent";
import { LuckyBallGameCmd } from "./LuckyBallGameCmd";
import PhpReportDefined from "./PhpReportDefined";
const { ccclass, property } = _decorator;
@ccclass("LucktBallAntePop")
export class LucktBallAntePop extends MyComponent {
    @property(SpriteFrame)
    public qiuIconArr: SpriteFrame = [];
    @property(Node)
    public targeticonNode: Node = null;
    @property(Node)
    public anteCountLayout: Node = null;
    @property(Node)
    public anteRateLayout: Node = null;
    @property(Label)
    public currRateLabel: Label = null;
    @property(Label)
    public anteBtnLabel: Label = null;
    @property(SpriteFrame)
    public jianIconArr: SpriteFrame = [];
    @property(SpriteFrame)
    public jiaIconArr: SpriteFrame = [];
    @property(Node)
    public jiaOrJianBtnNode: Node = [];
    public currSelectCount: number = 0;
    public currSelectRate: number = 1;
    public currSelectType: any = null;
    public isClose: boolean = false;
    public mcallback: any = null;
    public mbet_multiple_config: any[] = [];
    public isPlayCloseAnim: boolean = false;
    start() {
        this.addEvent(PushEvent.LuckBallCountDownEvent, (() => {
            this.isClose || (this.isClose = true, this.onCloseBtn());
        }), this);
    }
    setData(e, t, i, n) {
        let r = sys.getSafeAreaRect().y;
        this.mcallback = n;
        this.node.getChildByName("bg").getChildByName("bg").setPosition(v3(0, -675));
        let a = tween(this.node.getChildByName("bg").getChildByName("bg")).to(0.2, { position: v3(0, r) }).call((() => {
            this.deleteTweenAnim(a);
        })).start();
        this.addTweenAnim(a);
        this.currSelectType = { type: t, index: i, mode: e.mode, tid_key: e.tid_key };
        this.setListView(e.bet_config, this.anteCountLayout, ((e, t, i) => {
            t.name = e.toString();
            t.getChildByName("com").getChildByName("label").getComponent(Label).string = e.toString();
            t.getChildByName("select").getChildByName("label").getComponent(Label).string = e.toString();
        }));
        this.setListView(e.bet_multiple_config, this.anteRateLayout, ((e, t, i) => {
            t.name = e.toString();
            t.getChildByName("com").getChildByName("label").getComponent(Label).string = e.toString();
            t.getChildByName("select").getChildByName("label").getComponent(Label).string = e.toString();
        }));
        this.targeticonNode.children.forEach((e => e.active = false));
        let o = "";
        0 == t ? (0 == i ? (this.targeticonNode.getChildByName("green").active = true, o = "GREEN") : 1 == i ? (this.targeticonNode.getChildByName("red").active = true, o = "RED") : 2 == i && (this.targeticonNode.getChildByName("violet").active = true, o = "VIOLET"), this.targeticonNode.getChildByName("label").active = true, this.targeticonNode.getChildByName("label").getComponent(Label).string = o) : 1 == t ? (0 == i ? (this.targeticonNode.getChildByName("small").active = true, o = "SMALL") : 1 == i && (this.targeticonNode.getChildByName("big").active = true, o = "BIG"), this.targeticonNode.getChildByName("label").active = true, this.targeticonNode.getChildByName("label").getComponent(Label).string = o) : 2 == t && (this.targeticonNode.getChildByName("qiu").active = true, this.targeticonNode.getChildByName("qiu").getComponent(Sprite).spriteFrame = this.qiuIconArr[i]);
        this.mbet_multiple_config = e.bet_multiple_config;
        this.onClickCountBtn(null, e.bet_config[0]);
        this.onClickRateBtn(null, 1);
    }
    requestAnte() {
        if (SoundManager.shared().playFx("click"), User.shared().data.money < this.currSelectCount * this.currSelectRate) {
            return Utils.shared().showQuickRecharge(ToolUtils.curRoomId, null, true, "", 0, this.currSelectCount * this.currSelectRate, true, 0, 1), void User.shared().updatePayScene(PhpReportDefined.pay_scene.game_selectroom_less_money, ToolUtils.curVId);
        }
        let e = { cmd: LuckyBallGameCmd.GM_BET_REQUEST, bet: this.currSelectCount, multiple: this.currSelectRate, mode: this.currSelectType.mode, type: this.currSelectType.type, index: this.currSelectType.index, tid_key: this.currSelectType.tid_key };
        Server.shared().send(e);
    }
    onClickCountBtn(e, t) {
        if (e) {
            SoundManager.shared().playFx("click");
            let t = e.target;
            if (Number(t.name) == this.currSelectCount) {
                return;
            }
            this.currSelectCount = Number(t.name);
        }
        else {
            this.currSelectCount = t;
        }
        this.anteCountLayout.children.forEach((e => {
            e.getChildByName("select").active = Number(e.name) == this.currSelectCount;
            e.getChildByName("com").active = Number(e.name) != this.currSelectCount;
        }));
        this.updateMoneyShow();
    }
    onClickRateBtn(e, t) {
        if (e) {
            SoundManager.shared().playFx("click");
            let t = e.target;
            if (Number(t.name) == this.currSelectRate) {
                return;
            }
            this.currSelectRate = Number(t.name);
        }
        else {
            this.currSelectRate = t;
        }
        this.anteRateLayout.children.forEach((e => {
            e.getChildByName("select").active = Number(e.name) == this.currSelectRate;
            e.getChildByName("com").active = Number(e.name) != this.currSelectRate;
        }));
        1 == this.currSelectRate ? this.jiaOrJianBtnNode[0].getComponent(Sprite).spriteFrame = this.jianIconArr[0] : this.jiaOrJianBtnNode[0].getComponent(Sprite).spriteFrame = this.jianIconArr[1];
        this.currSelectRate >= this.mbet_multiple_config[this.mbet_multiple_config.length - 1] ? (this.currSelectRate = this.mbet_multiple_config[this.mbet_multiple_config.length - 1], this.jiaOrJianBtnNode[1].getComponent(Sprite).spriteFrame = this.jiaIconArr[0]) : this.jiaOrJianBtnNode[1].getComponent(Sprite).spriteFrame = this.jiaIconArr[1];
        this.updateMoneyShow();
        this.updateCurrRateLabel();
    }
    onClickJiaJianBtn(e, t) {
        SoundManager.shared().playFx("click");
        "jia" == t ? this.currSelectRate += 1 : this.currSelectRate > 1 && (this.currSelectRate -= 1);
        1 == this.currSelectRate ? this.jiaOrJianBtnNode[0].getComponent(Sprite).spriteFrame = this.jianIconArr[0] : this.jiaOrJianBtnNode[0].getComponent(Sprite).spriteFrame = this.jianIconArr[1];
        this.currSelectRate >= this.mbet_multiple_config[this.mbet_multiple_config.length - 1] ? (this.currSelectRate = this.mbet_multiple_config[this.mbet_multiple_config.length - 1], this.jiaOrJianBtnNode[1].getComponent(Sprite).spriteFrame = this.jiaIconArr[0]) : this.jiaOrJianBtnNode[1].getComponent(Sprite).spriteFrame = this.jiaIconArr[1];
        this.anteRateLayout.children.forEach((e => {
            e.getChildByName("select").active = Number(e.name) == this.currSelectRate;
            e.getChildByName("com").active = Number(e.name) != this.currSelectRate;
        }));
        this.updateCurrRateLabel();
        this.updateMoneyShow();
    }
    updateCurrRateLabel() {
        this.currRateLabel.string = this.currSelectRate.toString();
    }
    updateMoneyShow() {
        this.anteBtnLabel.string = "Bet ₹" + this.currSelectCount * this.currSelectRate;
    }
    onCloseBtn() {
        if (this.isPlayCloseAnim) {
            return;
        }
        this.isPlayCloseAnim = true;
        Tween.stopAllByTarget(this.node.getChildByName("bg").getChildByName("bg"));
        let e = tween(this.node.getChildByName("bg").getChildByName("bg")).to(0.3, { position: v3(0, -675) }).call((() => {
            this.deleteTweenAnim(e);
            this.mcallback && this.mcallback();
            this.node.destroy();
        })).start();
        this.addTweenAnim(e);
    }
}
