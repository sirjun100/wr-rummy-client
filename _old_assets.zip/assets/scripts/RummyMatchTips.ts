// @ts-nocheck
// Recovered from index.js:465
import { _decorator, Component, sp } from "cc";
import TweenTool from "./TweenTool";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("RummyMatchTips")
export class RummyMatchTips extends Component {
    @property([sp.SkeletonData])
    public animArray: sp.SkeletonData[] = [];
    @property(sp.Skeleton)
    public anim_node: any = null;
    public status: number = 0;
    public vecAnimName: any[] = ["starts", "bsc_lj", "stadium_start"];
    start() {
    }
    showGameStatusAnim(t, e) {
        if (ToolUtils.isObjValid(t) && e >= 0 && e < 3) {
            this.anim_node.skeletonData = this.animArray[e];
            this.anim_node.setAnimation(0, this.vecAnimName[e], false);
            let i = this, n = 0 == e ? 1.4 : 2;
            TweenTool.delayAct(t, (() => {
                ToolUtils.isObjValid(i.node) && i.node.destroy();
            }), n, true);
        }
    }
}
