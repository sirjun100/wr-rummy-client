import RobotAvatar from "./RobotAvatar";
// @ts-nocheck
// Recovered from index.js:247
import { _decorator, Button, color, director, instantiate, Label, Node, ProgressBar, ScrollView, size, Slider, Sprite, SpriteAtlas, SpriteFrame, sys, UIOpacity, UITransform, v3, Vec3, Widget } from "cc";
import PushCenter from "./PushCenter";
import { TLog } from "./TLog";
import TweenTool from "./TweenTool";
import Utils from "./Utils";
import GameConfig from "./GameConfig";
import HowToPlayDefined from "./HowToPlayDefined";
import PhpReportDefined from "./PhpReportDefined";
import ReportConfig from "./ReportConfig";
import User from "./User";
import HttpManager from "./HttpManager";
import SoundManager from "./SoundManager";
import BaseLayer from "./BaseLayer";
import i18nMgr from "./i18nMgr";
import { TransferPlatform } from "./TransferPlatform";
import { CheckModule, CUSTOM_REWARD_ENUM, PointsType } from "./CommDefine";
import { ToolUtils } from "./ToolUtils";
import BundleNameDefined from "./BundleNameDefined";
import { HttpRequest } from "./HttpRequestName";
import PushEvent from "./PushEvent";
import { MatchRoom } from "./MatchRoom";
const { ccclass, property } = _decorator;
@ccclass("LobbyRummySelection")
export default class LobbyRummySelection extends BaseLayer {
    public TAG: string = "LobbyRummySelection";
    @property(Node)
    public gameTypeNode: Node = null;
    @property([Node])
    public gameTypeTabs: Node[] = [];
    @property(Node)
    public chipsGameTypeNode: Node = null;
    @property([Node])
    public chipsGameTypeTabs: Node[] = [];
    @property(Node)
    public rummyTypeNode: Node = null;
    @property(Node)
    public modeHelpBtn: Node = null;
    @property([Node])
    public rummyTypeTabs: Node[] = [];
    @property(Node)
    public roomInfoNode: Node = null;
    @property([SpriteFrame])
    public rankStarFrame: SpriteFrame[] = [];
    @property(Node)
    public tournamentNode: Node = null;
    @property(Node)
    public rankInnerNode: Node = null;
    @property(Node)
    public risk_tipNode: Node = null;
    @property(Label)
    public selectPlayerLabel2: Label = null;
    @property(Node)
    public flagNew1Node: Node = null;
    @property(Node)
    public flagNew2Node: Node = null;
    @property(Node)
    public sliderStarNode: Node = null;
    @property(Node)
    public playnowStarNode: Node = null;
    @property(Node)
    public addCashStarNode: Node = null;
    @property(ScrollView)
    public tabScrollView: ScrollView = null;
    @property(Node)
    public chip_infoNode: Node = null;
    @property(Node)
    public free_chip_btnNode: Node = null;
    @property(Node)
    public chip_help: Node = null;
    @property(Node)
    public hand_guide: Node = null;
    @property([SpriteFrame])
    public flagDiImages: SpriteFrame[] = [];
    @property([SpriteFrame])
    public switchSelectImages: SpriteFrame[] = [];
    @property(SpriteAtlas)
    public spAtlas617: SpriteAtlas = null;
    @property(SpriteFrame)
    public selectSpFrame617: SpriteFrame = [];
    @property(SpriteFrame)
    public selectplayersSp617: SpriteFrame = [];
    @property(SpriteFrame)
    public progressSpFrame617: SpriteFrame = [];
    @property(SpriteFrame)
    public jiaAndjianSp617: SpriteFrame = [];
    public _close_cb: any = null;
    public _help_cb: any = null;
    public _cb: any = null;
    public gameType: any = -1;
    public rummyType: any = -1;
    public vCurRoomList: any[] = [];
    public selectPlayers: number = 2;
    public selectMode: number = 1;
    public selectPool: number = 101;
    public selectDeals: number = 2;
    public selectBotMode: number = 0;
    public nIdx: number = 0;
    public _min_entry: number = 0;
    public bestIndex: number = 0;
    public lastIndex: number = 0;
    public gameTypeAnim: any[] = ["1_jbc", "2_bsc", "3_hyc", "4_lxc"];
    public tempTime: number = 0;
    public cur_money: number = 0;
    public startBtnAction: any = null;
    public isPlaySwitchAction: boolean = false;
    public hasMatch: boolean = true;
    public left_second: number = 0;
    public free_chip_action: any = null;
    public request_click_time: number = 0;
    public _lastClick: number = 0;
    public chip_num: number = 0;
    public gameType_noSelectColor: any = color(102, 102, 102, 255);
    public rummyType_selectColor: any = color(147, 11, 11, 255);
    public btn_noSelectColor: any = color(51, 51, 51, 255);
    onLoad() {
        this.fitLuckyTheme();
        this.chipsGameTypeNode.active = 1 == GameConfig.CHIPS_MODLE;
        this.gameTypeNode.active = 0 == GameConfig.CHIPS_MODLE;
    }
    fitLuckyTheme() {
        if (0 == GameConfig.NATIVE_GAME_APP_TYPE) {
            return;
        }
        this.gameType_noSelectColor = color(178, 191, 255, 255);
        this.rummyType_selectColor = color(221, 3, 3, 255);
        this.btn_noSelectColor = color(80, 89, 130, 255);
        let e = this.node.getChildByName("root").getChildByName("rummy_switch");
        e.getChildByName("bg").getComponent(Sprite).color = color(250, 250, 250, 255);
        e.getChildByName("btn_point").getChildByName("line").getComponent(Sprite).color = color(221, 3, 3, 255);
        e.getChildByName("btn_pool").getChildByName("line").getComponent(Sprite).color = color(221, 3, 3, 255);
        e.getChildByName("btn_deals").getChildByName("line").getComponent(Sprite).color = color(221, 3, 3, 255);
        let t = this.roomInfoNode.getChildByName("entry_info");
        t.getChildByName("entry").getChildByName("fee").getComponent(Label).color = color(222, 3, 3, 255);
        t.getChildByName("points").getChildByName("value").getComponent(Label).color = color(222, 3, 3, 255);
        t.getChildByName("feeNode").getChildByName("fee").getComponent(Label).color = color(222, 3, 3, 255);
    }
    fitChipMode() {
        if (1 != GameConfig.CHIPS_MODLE || 2000617 != GameConfig.CHANNEL_ID || 0 != GameConfig.GAME_HALL_THEME) {
            return;
        }
        let e = this.chipsGameTypeNode.getChildByName("ScrollView").getComponent(ScrollView).content;
        ["btn_cash", "btn_practice", "btn_match", "btn_buddy"].forEach((t => {
            e.getChildByName(t).getComponent(Button).normalSprite = this.selectSpFrame617[0];
            e.getChildByName(t).getComponent(Button).pressedSprite = this.selectSpFrame617[0];
            e.getChildByName(t).getComponent(Button).hoverSprite = this.selectSpFrame617[0];
            e.getChildByName(t).getComponent(Button).disabledSprite = this.selectSpFrame617[1];
        }));
        e.getChildByName("btn_practice").getChildByName("title").getChildByName("wz").getComponent(Label).string = "GAMES";
        const t = this.node.getChildByName("root");
        t.getChildByName("rummy_switch").getChildByName("bg").getComponent(Sprite).color = color("#fafafa");
        t.getChildByName("tournament").getChildByName("list_switch").getChildByName("bg").getComponent(Sprite).color = color("#fafafa");
        const i = t.getChildByName("room_info");
        i.getChildByName("player_select").getChildByName("select").getComponent(Sprite).spriteAtlas = this.spAtlas617;
        i.getChildByName("deals_select").getChildByName("select").getComponent(Sprite).spriteFrame = this.selectplayersSp617[0];
        i.getChildByName("pool_select").getChildByName("select").getComponent(Sprite).spriteFrame = this.selectplayersSp617[0];
        i.getChildByName("mode_select").getChildByName("layout").getChildByName("btn_switch1").getChildByName("select").getComponent(Sprite).spriteFrame = this.selectplayersSp617[0];
        i.getChildByName("mode_select").getChildByName("layout").getChildByName("btn_switch5").getChildByName("select").getComponent(Sprite).spriteFrame = this.selectplayersSp617[0];
        i.getChildByName("mode_select").getChildByName("layout").getChildByName("btn_switch3").getChildByName("select").getComponent(Sprite).spriteFrame = this.selectplayersSp617[0];
        i.getChildByName("mode_select").getChildByName("layout").getChildByName("btn_switch4").getChildByName("select").getComponent(Sprite).spriteFrame = this.selectplayersSp617[0];
        const s = i.getChildByName("slider_view");
        s.getChildByName("Slider").getComponent(Sprite).spriteFrame = this.progressSpFrame617[0];
        s.getChildByName("Slider").getChildByName("ProgressBar").getChildByName("Bar").getComponent(Sprite).spriteFrame = this.progressSpFrame617[1];
        s.getChildByName("Slider").getChildByName("Handle").getComponent(Sprite).spriteAtlas = this.spAtlas617;
        s.getChildByName("Slider").getChildByName("Handle").getComponent(Sprite).spriteFrame = this.progressSpFrame617[2];
        s.getChildByName("btn_reduce").getComponent(Button).normalSprite = this.jiaAndjianSp617[1];
        s.getChildByName("btn_reduce").getComponent(Button).pressedSprite = this.jiaAndjianSp617[1];
        s.getChildByName("btn_reduce").getComponent(Button).hoverSprite = this.jiaAndjianSp617[1];
        s.getChildByName("btn_reduce").getComponent(Button).disabledSprite = this.jiaAndjianSp617[0];
        s.getChildByName("btn_add").getComponent(Button).normalSprite = this.jiaAndjianSp617[3];
        s.getChildByName("btn_add").getComponent(Button).pressedSprite = this.jiaAndjianSp617[3];
        s.getChildByName("btn_add").getComponent(Button).hoverSprite = this.jiaAndjianSp617[3];
        s.getChildByName("btn_add").getComponent(Button).disabledSprite = this.jiaAndjianSp617[2];
    }
    onEnable() {
        User.shared().getHallInfo();
        let e = this.roomInfoNode.getChildByName("btn_start");
        e.on(Node.EventType.TOUCH_START, this.onTouchStart, this);
        e.on(Node.EventType.TOUCH_END, this.onTouchEnd, this);
        e.on(Node.EventType.TOUCH_CANCEL, this.onTouchEnd, this);
        this.checkBtnWzFontSize();
    }
    onDisable() {
        let e = this.roomInfoNode.getChildByName("btn_start");
        e.off(Node.EventType.TOUCH_START, this.onTouchStart, this);
        e.off(Node.EventType.TOUCH_END, this.onTouchEnd, this);
        e.off(Node.EventType.TOUCH_CANCEL, this.onTouchEnd, this);
    }
    reFreshGameTabs() {
        0 == User.shared().temp_pingbi.matchshow ? (this.hasMatch = true, this.gameTypeTabs[1].active = true, this.chipsGameTypeTabs[1].active = true) : (this.hasMatch = false, this.gameTypeTabs[1].active = false, this.chipsGameTypeTabs[1].active = false);
    }
    showFreeChipsTime() {
        sys.isObjectValid(User.shared().exe_data) && sys.isObjectValid(User.shared().exe_data.left_second) ? this.left_second = User.shared().exe_data.left_second : this.left_second = 0;
        this.free_chip_action && (TweenTool.stopAction(this.free_chip_action), this.free_chip_action = null);
    }
    start() {
        super.start();
        SoundManager.shared().preLoadBundleSounds(BundleNameDefined.bundle_sound, "select");
        this.cur_money = User.shared().data.money;
        this.chip_num = User.shared().data.money_exe;
        this.showFreeChipsTime();
        this.showFreeChipAnim();
        this.reFreshGameTabs();
        this.initView();
        this.fitScreen();
        PushCenter.shared().addListener(GameConfig.Update_Money, (e => {
            if (ToolUtils.isObjValid(this.node) && this.cur_money != User.shared().data.money) {
                this.cur_money = User.shared().data.money;
                this.updateStartBtnState();
                let e = sys.localStorage.getItem(User.shared().data.uid + "recommendRoom" + this.gameType + this.rummyType), t = null;
                if (e) {
                    let i = ToolUtils.parseJson(e), s = this.selectPlayers;
                    if (this.rummyType == HowToPlayDefined.RUMMY_POINTS && this.selectMode == PointsType.Easy && 2 != s && (s = 4), 1 != this.gameType && i.data.player == s) {
                        let e = ToolUtils.getRecommendRoom(i);
                        (this.rummyType == HowToPlayDefined.RUMMY_POINTS || this.rummyType == HowToPlayDefined.RUMMY_MULTIPLE || this.rummyType == HowToPlayDefined.RUMMY_BUMP || this.rummyType == HowToPlayDefined.RUMMY_POOL && i.data.pool_game == this.selectPool || this.rummyType == HowToPlayDefined.RUMMY_DEALS && i.data.deals == this.selectDeals) && (t = e.enterMoney);
                    }
                    User.shared().isLoginHall && sys.isObjectValid(User.shared().data.daily_login_cnt) && 1 == User.shared().data.daily_login_cnt && (t = null);
                }
                this.getSelectRoomList(this.selectPlayers, this.selectPool, this.selectDeals, t);
                this.checkHandGuide(11);
            }
        }), this);
        PushCenter.shared().addListener(PushEvent.EasyGameShowNewFlag, (e => {
            ToolUtils.isObjValid(this.node) && this.showPointsNewflag();
        }), this);
        PushCenter.shared().addListener(PushEvent.ShowSuperLevelUpAlert, (e => {
            if (ToolUtils.isObjValid(this.node) && User.shared().superVipUpMsg && sys.isObjectValid(User.shared().superVipUpMsg)) {
                let e = false, t = [];
                if (t.type = CUSTOM_REWARD_ENUM.VIP_LEVEL, t.num = User.shared().superVipUpMsg.new_show_level || 0, User.shared().superVipUpMsg.list) {
                    let i = User.shared().superVipUpMsg.list.length;
                    for (let s = 0; s < i; s++) {
                        if (User.shared().superVipUpMsg.list[s].type == t.type) {
                            e = true;
                            break;
                        }
                    }
                }
                e || User.shared().superVipUpMsg.list.unshift(t);
                Utils.shared().showRewardTips(User.shared().superVipUpMsg, null, 1, "reward_tips.okey", "", (() => {
                    User.shared().superVipUpMsg = null;
                    User.shared().requestSuperVipConfirmUpgradePop();
                }));
            }
        }), this);
        PushCenter.shared().addListener(PushEvent.RefreshHallChooseGameRankStar, (e => {
            ToolUtils.isObjValid(this.node) && this.refreshRankStar();
        }), this);
        PushCenter.shared().addListener(PushEvent.UpdatePractiseGold, (e => {
            if (ToolUtils.isObjValid(this.node) && this.chip_num != User.shared().data.money_exe) {
                this.updateChip();
                this.updateStartBtnState();
                let e = sys.localStorage.getItem(User.shared().data.uid + "recommendRoom" + this.gameType + this.rummyType), t = null;
                if (e) {
                    let i = ToolUtils.parseJson(e), s = this.selectPlayers;
                    if (this.rummyType == HowToPlayDefined.RUMMY_POINTS && this.selectMode == PointsType.Easy && 2 != s && (s = 4), 1 != this.gameType && i.data.player == s) {
                        let e = ToolUtils.getRecommendRoom(i);
                        (this.rummyType == HowToPlayDefined.RUMMY_POINTS || this.rummyType == HowToPlayDefined.RUMMY_MULTIPLE || this.rummyType == HowToPlayDefined.RUMMY_BUMP || this.rummyType == HowToPlayDefined.RUMMY_POOL && i.data.pool_game == this.selectPool || this.rummyType == HowToPlayDefined.RUMMY_DEALS && i.data.deals == this.selectDeals) && (t = e.enterMoney);
                    }
                    User.shared().isLoginHall && sys.isObjectValid(User.shared().data.daily_login_cnt) && 1 == User.shared().data.daily_login_cnt && (t = null);
                }
                this.getSelectRoomList(this.selectPlayers, this.selectPool, this.selectDeals, t);
            }
        }), this);
        PushCenter.shared().addListener(PushEvent.CheckHandGuide, (e => {
            ToolUtils.isObjValid(this.node) && this.checkHandGuide(0);
        }), this);
        PushCenter.shared().addListener(PushEvent.FastStartGame, (e => {
            if (ToolUtils.isObjValid(this.node)) {
                let e = this.roomInfoNode.getChildByName("btn_start");
                this.roomInfoNode.getChildByName("btn_addcash");
                e.active ? this.onStartGameClick(null, "start") : this.onStartGameClick(null, "addcash");
            }
        }), this);
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().removeListenersByTag(this);
        this.free_chip_action && TweenTool.stopAction(this.free_chip_action);
        this.free_chip_action = null;
    }
    updateChip() {
        this.chip_num = User.shared().data.money_exe;
        let e = this.chip_infoNode.getChildByName("chip");
        e && (e.getComponent(Label).string = "" + ToolUtils.parse_ChipNum2(User.shared().data.money_exe));
    }
    initView(e = false) {
        if (1 == GameConfig.CHIPS_MODLE && 0 == this.gameType && (this.gameType = 3), !e && (this.gameType >= 0 || this.rummyType >= 0)) {
            this.setInitGameType(this.gameType, this.rummyType);
        }
        else {
            let e = null, t = null;
            if (1 == GameConfig.CHIPS_MODLE) {
                let e = sys.localStorage.getItem(User.shared().data.uid + "recommendRoomNew");
                sys.isObjectValid(e) ? (t = ToolUtils.getRecommendRoom(ToolUtils.parseJson(e)), t && 3 == t.gameType && sys.isObjectValid(t.playersIndex) ? this.setInitGameType(3, t.rummyType, t.playersIndex, t.poolIndex, t.dealsIndex, false, t.enterMoney, t.modeIndex) : this.setInitGameType(3, 0, 1, 0, 1, false)) : this.setInitGameType(3, 0, 1, 0, 1, false);
            }
            else {
                User.shared().isLoginHall && (e = User.shared().sysRecommend);
                sys.isObjectValid(e) && User.shared().checkRecommendRoom();
                let i = ToolUtils.getRecommendRoom(e);
                if (User.shared().chip_local_has && (sys.isObjectValid(User.shared().data.exe_restart) && (i = ToolUtils.getRecommendRoom(User.shared().data.exe_restart)), User.shared().chip_local_has = false), sys.isObjectValid(i.playersIndex) ? t = i : (i = sys.localStorage.getItem(User.shared().data.uid + "recommendRoomNew"), sys.isObjectValid(i) && (t = ToolUtils.getRecommendRoom(ToolUtils.parseJson(i)))), t && (0 != t.gameType || 0 != t.rummyType)) {
                    let e = User.shared().checkGetSysRecommedRoom();
                    sys.isObjectValid(e) && (t = ToolUtils.getRecommendRoom(e), sys.localStorage.removeItem(User.shared().data.uid + "recommendRoom"), sys.localStorage.removeItem(User.shared().data.uid + "recommendRoomNew"), sys.localStorage.removeItem(User.shared().data.uid + "addRecommendRoomNew"), sys.localStorage.removeItem(User.shared().data.uid + "recommendRoom00"));
                }
                if (!t || 1 == t.gameType && 1 == User.shared().temp_pingbi.matchshow || 0 == t.gameType && t.rummyType == HowToPlayDefined.RUMMY_MULTIPLE && 1 != User.shared().multiple_rummy_open && 1 != User.shared().multiple_2_open || 3 == t.gameType && t.rummyType == HowToPlayDefined.RUMMY_MULTIPLE && 1 != User.shared().chip_multiple_rummy_open && 1 != User.shared().chip_multiple_2_open) {
                    if (sys.isObjectValid(User.shared().sysRecommend)) {
                        let e = ToolUtils.getRecommendRoom(User.shared().sysRecommend);
                        sys.isObjectValid(e.playersIndex) && (0 != e.gameType || e.rummyType != HowToPlayDefined.RUMMY_MULTIPLE || 1 == User.shared().multiple_rummy_open || 1 == User.shared().multiple_2_open || 3 == e.gameType && e.rummyType == HowToPlayDefined.RUMMY_MULTIPLE && 1 != User.shared().chip_multiple_rummy_open && 1 != User.shared().chip_multiple_2_open) ? this.setInitGameType(e.gameType, e.rummyType, e.playersIndex, e.poolIndex, e.dealsIndex, false, e.enterMoney, e.modeIndex) : this.setInitGameType(0, 0, 1, 0, 1, false);
                    }
                    else {
                        this.setInitGameType(0, 0, 1, 0, 1, false);
                    }
                }
                else {
                    this.setInitGameType(t.gameType, t.rummyType, t.playersIndex, t.poolIndex, t.dealsIndex, false, t.enterMoney, t.modeIndex);
                }
            }
        }
        this.updateSelectPlayer2();
        this.showPointsNewflag();
        this.refreshRankStar();
        this.updateChip();
        User.shared().choose_game_type = this.gameType;
    }
    showPointsNewflag() {
    }
    updateSelectPlayer2() {
        let e = "6";
        0 != this.gameType && 3 != this.gameType || User.shared().easy_mode_show && this.rummyType == HowToPlayDefined.RUMMY_POINTS && this.selectMode == PointsType.Easy && (e = "4");
        this.selectPlayerLabel2.string = e;
        let t = this.roomInfoNode.getChildByName("player_select"), i = this.roomInfoNode.getChildByName("mode_select"), s = false;
        if (0 != this.gameType && 3 != this.gameType || ((1 == User.shared().multiple_rummy_open || 1 == User.shared().multiple_2_open) && i.active && this.selectMode != PointsType.Classic || (1 == User.shared().bump_rummy_open || 1 == User.shared().double_6_open || 1 == User.shared().chip_double_6_open) && i.active && this.selectMode != PointsType.Classic) && (s = true), s) {
            if (i.active && this.selectMode == PointsType.Double) {
                if (0 == this.gameType && 1 == User.shared().double_6_open || 3 == this.gameType && 1 == User.shared().chip_double_6_open) {
                    t.getChildByName("switch_bg").active = false;
                    t.getChildByName("btn_switch1").active = false;
                    t.getChildByName("btn_switch2").active = false;
                    t.getChildByName("Label1").active = false;
                    t.getChildByName("Label2").active = true;
                    let e = t.getChildByName("Label2").position;
                    t.getChildByName("Label2").setPosition(v3(0, e.y, e.z));
                    e = t.getChildByName("select").position;
                    t.getChildByName("select").setPosition(v3(0, e.y, e.z));
                    t.getChildByName("Label2").getComponent(Label).color = color(255, 253, 253);
                    1 != GameConfig.CHIPS_MODLE || 2000617 != GameConfig.CHANNEL_ID || 0 != GameConfig.GAME_HALL_THEME ? t.getChildByName("select").getComponent(Sprite).spriteFrame = this.switchSelectImages[1] : t.getChildByName("select").getComponent(Sprite).spriteFrame = this.selectplayersSp617[1];
                }
            }
            else if (i.active && this.selectMode == PointsType.Wild) {
                if (0 == this.gameType && 1 == User.shared().bump_2_open && 1 == User.shared().bump_6_open || 3 == this.gameType && 1 == User.shared().chip_bump_2_open && 1 == User.shared().chip_bump_6_open) {
                    t.getChildByName("switch_bg").active = true;
                    t.getChildByName("switch_bg").getComponent(UITransform).setContentSize(size(224, 102));
                    t.getChildByName("btn_switch1").active = true;
                    t.getChildByName("btn_switch2").active = true;
                    t.getChildByName("Label1").active = true;
                    t.getChildByName("Label2").active = true;
                    let e = t.getChildByName("Label1").position;
                    t.getChildByName("Label1").setPosition(v3(-55, e.y, e.z));
                    t.getChildByName("Label2").setPosition(v3(55, e.y, e.z));
                    e = t.getChildByName("select").position;
                    2 == this.selectPlayers ? t.getChildByName("select").setPosition(v3(-55, e.y, e.z)) : t.getChildByName("select").setPosition(v3(55, e.y, e.z));
                    1 != GameConfig.CHIPS_MODLE || 2000617 != GameConfig.CHANNEL_ID || 0 != GameConfig.GAME_HALL_THEME ? t.getChildByName("select").getComponent(Sprite).spriteFrame = this.switchSelectImages[0] : t.getChildByName("select").getComponent(Sprite).spriteFrame = this.selectplayersSp617[0];
                }
                else if (0 == this.gameType && 1 == User.shared().bump_2_open || 3 == this.gameType && 1 == User.shared().chip_bump_2_open) {
                    t.getChildByName("switch_bg").active = false;
                    t.getChildByName("btn_switch1").active = false;
                    t.getChildByName("btn_switch2").active = false;
                    t.getChildByName("Label2").active = false;
                    t.getChildByName("Label1").active = true;
                    let e = t.getChildByName("Label1").position;
                    t.getChildByName("Label1").setPosition(v3(0, e.y, e.z));
                    e = t.getChildByName("select").position;
                    t.getChildByName("select").setPosition(v3(0, e.y, e.z));
                    t.getChildByName("Label1").getComponent(Label).color = color(255, 253, 253);
                    1 != GameConfig.CHIPS_MODLE || 2000617 != GameConfig.CHANNEL_ID || 0 != GameConfig.GAME_HALL_THEME ? t.getChildByName("select").getComponent(Sprite).spriteFrame = this.switchSelectImages[1] : t.getChildByName("select").getComponent(Sprite).spriteFrame = this.selectplayersSp617[1];
                }
                else if (0 == this.gameType && 1 == User.shared().bump_6_open || 3 == this.gameType && 1 == User.shared().chip_bump_6_open) {
                    t.getChildByName("switch_bg").active = false;
                    t.getChildByName("btn_switch1").active = false;
                    t.getChildByName("btn_switch2").active = false;
                    t.getChildByName("Label1").active = false;
                    t.getChildByName("Label2").active = true;
                    let e = t.getChildByName("Label2").position;
                    t.getChildByName("Label2").setPosition(v3(0, e.y, e.z));
                    e = t.getChildByName("select").position;
                    t.getChildByName("select").setPosition(v3(0, e.y, e.z));
                    t.getChildByName("Label2").getComponent(Label).color = color(255, 253, 253);
                    1 != GameConfig.CHIPS_MODLE || 2000617 != GameConfig.CHANNEL_ID || 0 != GameConfig.GAME_HALL_THEME ? t.getChildByName("select").getComponent(Sprite).spriteFrame = this.switchSelectImages[1] : t.getChildByName("select").getComponent(Sprite).spriteFrame = this.selectplayersSp617[1];
                }
            }
            else if (i.active && this.selectMode == PointsType.Multiple) {
                if (0 == this.gameType && 1 == User.shared().multiple_rummy_open && 1 == User.shared().multiple_2_open || 3 == this.gameType && 1 == User.shared().chip_multiple_rummy_open && 1 == User.shared().chip_multiple_2_open) {
                    t.getChildByName("switch_bg").active = true;
                    t.getChildByName("switch_bg").getComponent(UITransform).setContentSize(size(224, 102));
                    t.getChildByName("btn_switch1").active = true;
                    t.getChildByName("btn_switch2").active = true;
                    t.getChildByName("Label1").active = true;
                    t.getChildByName("Label2").active = true;
                    let e = t.getChildByName("Label1").position;
                    t.getChildByName("Label1").setPosition(v3(-55, e.y, e.z));
                    t.getChildByName("Label2").setPosition(v3(55, e.y, e.z));
                    e = t.getChildByName("select").position;
                    2 == this.selectPlayers ? t.getChildByName("select").setPosition(v3(-55, e.y, e.z)) : t.getChildByName("select").setPosition(v3(55, e.y, e.z));
                    1 != GameConfig.CHIPS_MODLE || 2000617 != GameConfig.CHANNEL_ID || 0 != GameConfig.GAME_HALL_THEME ? t.getChildByName("select").getComponent(Sprite).spriteFrame = this.switchSelectImages[0] : t.getChildByName("select").getComponent(Sprite).spriteFrame = this.selectplayersSp617[0];
                }
                else if (0 == this.gameType && 1 == User.shared().multiple_rummy_open && 0 == User.shared().multiple_2_open || 3 == this.gameType && 1 == User.shared().chip_multiple_rummy_open && 0 == User.shared().chip_multiple_2_open) {
                    t.getChildByName("switch_bg").active = false;
                    t.getChildByName("btn_switch1").active = false;
                    t.getChildByName("btn_switch2").active = false;
                    t.getChildByName("Label1").active = false;
                    t.getChildByName("Label2").active = true;
                    let e = t.getChildByName("Label2").position;
                    t.getChildByName("Label2").setPosition(v3(0, e.y, e.z));
                    e = t.getChildByName("select").position;
                    t.getChildByName("select").setPosition(v3(0, e.y, e.z));
                    t.getChildByName("Label2").getComponent(Label).color = color(255, 253, 253);
                    1 != GameConfig.CHIPS_MODLE || 2000617 != GameConfig.CHANNEL_ID || 0 != GameConfig.GAME_HALL_THEME ? t.getChildByName("select").getComponent(Sprite).spriteFrame = this.switchSelectImages[1] : t.getChildByName("select").getComponent(Sprite).spriteFrame = this.selectplayersSp617[1];
                }
                else if (0 == this.gameType && 0 == User.shared().multiple_rummy_open && 1 == User.shared().multiple_2_open || 3 == this.gameType && 0 == User.shared().chip_multiple_rummy_open && 1 == User.shared().chip_multiple_2_open) {
                    t.getChildByName("switch_bg").active = false;
                    t.getChildByName("btn_switch1").active = false;
                    t.getChildByName("btn_switch2").active = false;
                    t.getChildByName("Label1").active = true;
                    t.getChildByName("Label2").active = false;
                    let e = t.getChildByName("Label1").position;
                    t.getChildByName("Label1").setPosition(v3(0, e.y, e.z));
                    e = t.getChildByName("select").position;
                    t.getChildByName("select").setPosition(v3(0, e.y, e.z));
                    t.getChildByName("Label1").getComponent(Label).color = color(255, 253, 253);
                    1 != GameConfig.CHIPS_MODLE || 2000617 != GameConfig.CHANNEL_ID || 0 != GameConfig.GAME_HALL_THEME ? t.getChildByName("select").getComponent(Sprite).spriteFrame = this.switchSelectImages[1] : t.getChildByName("select").getComponent(Sprite).spriteFrame = this.selectplayersSp617[1];
                }
            }
            else {
                t.getChildByName("switch_bg").active = true;
                t.getChildByName("switch_bg").getComponent(UITransform).setContentSize(size(224, 102));
                t.getChildByName("btn_switch1").active = true;
                t.getChildByName("btn_switch2").active = true;
                t.getChildByName("Label1").active = true;
                t.getChildByName("Label2").active = true;
                let e = t.getChildByName("Label1").position;
                t.getChildByName("Label1").setPosition(v3(-55, e.y, e.z));
                t.getChildByName("Label2").setPosition(v3(55, e.y, e.z));
                e = t.getChildByName("select").position;
                2 == this.selectPlayers ? t.getChildByName("select").setPosition(v3(-55, e.y, e.z)) : t.getChildByName("select").setPosition(v3(55, e.y, e.z));
                1 != GameConfig.CHIPS_MODLE || 2000617 != GameConfig.CHANNEL_ID || 0 != GameConfig.GAME_HALL_THEME ? t.getChildByName("select").getComponent(Sprite).spriteFrame = this.switchSelectImages[0] : t.getChildByName("select").getComponent(Sprite).spriteFrame = this.selectplayersSp617[0];
            }
        }
        else {
            t.getChildByName("switch_bg").active = true;
            t.getChildByName("switch_bg").getComponent(UITransform).setContentSize(size(224, 102));
            t.getChildByName("btn_switch1").active = true;
            t.getChildByName("btn_switch2").active = true;
            t.getChildByName("Label1").active = true;
            t.getChildByName("Label2").active = true;
            let e = t.getChildByName("Label1").position;
            t.getChildByName("Label1").setPosition(v3(-55, e.y, e.z));
            t.getChildByName("Label2").setPosition(v3(55, e.y, e.z));
            e = t.getChildByName("select").position;
            2 == this.selectPlayers ? t.getChildByName("select").setPosition(v3(-55, e.y, e.z)) : t.getChildByName("select").setPosition(v3(55, e.y, e.z));
            1 != GameConfig.CHIPS_MODLE || 2000617 != GameConfig.CHANNEL_ID || 0 != GameConfig.GAME_HALL_THEME ? t.getChildByName("select").getComponent(Sprite).spriteFrame = this.switchSelectImages[0] : t.getChildByName("select").getComponent(Sprite).spriteFrame = this.selectplayersSp617[0];
        }
    }
    updateGameType(e, t) {
        this.gameTypeTabs[1].active = this.hasMatch;
        this.chipsGameTypeTabs[1].active = this.hasMatch;
        this.hasMatch || 1 != e || (e = 0);
        this.gameType = e;
        this.roomInfoNode.active = 1 != e;
        this.tournamentNode.active = 1 == e;
        User.shared().choose_game_type = this.gameType;
        this.hasMatch && (0 == this.gameType ? this.tabScrollView.scrollToLeft(0) : 3 == this.gameType && this.tabScrollView.scrollToRight(0), PushCenter.shared().pushEvent(PushEvent.InMatchChooseGameCloseAct, this.gameType));
        PushCenter.shared().pushEvent(PushEvent.RefreshActCollStatus, this.gameType);
        1 == e ? this.rummyTypeNode.active = false : (this.rummyTypeNode.active = true, User.shared().doSendMatchOnlineStatus(0), Utils.shared().hideLoading());
        let i = [this.gameTypeTabs[0], this.gameTypeTabs[1], this.gameTypeTabs[2], this.gameTypeTabs[3]];
        1 == GameConfig.CHIPS_MODLE && (i = [this.chipsGameTypeTabs[0], this.chipsGameTypeTabs[1], this.chipsGameTypeTabs[2], this.chipsGameTypeTabs[3]]);
        let s = color(255, 255, 255, 255), a = this.gameType_noSelectColor;
        1 != GameConfig.CHIPS_MODLE || 2000617 != GameConfig.CHANNEL_ID || 0 != GameConfig.GAME_HALL_THEME || (s = color("#ffd8a6"), a = color("#45a584"));
        for (let o = 0, h = i.length; o < h; o++) {
            let h = i[o], n = h.getChildByName("title"), r = n.getChildByName("wz"), m = n.getChildByName("icon");
            if (o == e) {
                if (h.getComponent(Button).interactable = false, m.getComponent(Sprite).color = s, r.getComponent(Label).color = s, i18nMgr.shared().changeLabelFont(r.getComponent(Label), true), t) {
                    TweenTool.stopNodeAction(n);
                    let e = TweenTool.scaleTo(n, 0.06, v3(0.9, 0.9, 1)), t = TweenTool.scaleTo(n, 0.2, v3(1, 1, 1));
                    TweenTool.sequence(n, true, null, e, t);
                }
            }
            else {
                h.getComponent(Button).interactable = true;
                m.getComponent(Sprite).color = a;
                r.getComponent(Label).color = a;
                i18nMgr.shared().changeLabelFont(r.getComponent(Label), false);
            }
        }
        this.updateSelectPlayer2();
        this.showPointsNewflag();
        this.chip_infoNode.active = 3 == e;
        this.checkFreeChipBtnVisible();
    }
    updateFreeChipTime() {
        this.left_second -= 1;
        let e = this.free_chip_btnNode.getChildByName("time_di"), t = e.getChildByName("Label").getComponent(Label);
        if (this.left_second >= 0) {
            e.active = true;
            let i = Utils.shared().getCountDownString(this.left_second);
            t.string = "" + i;
        }
        else {
            e.active = false;
            1 == User.shared().chip_hall_give && sys.isObjectValid(User.shared().exe_data) && -1 == this.left_second && this.requestFreeChipsConfig();
        }
    }
    checkFreeChipBtnVisible() {
    }
    showFreeChipAnim() {
        1 == User.shared().chip_hall_give && sys.isObjectValid(User.shared().exe_data);
    }
    updateRummyType(e) {
        let t = this.rummyTypeTabs, i = this.rummyType_selectColor, s = color(102, 102, 102, 255);
        for (let a = 0, o = t.length; a < o; a++) {
            let o = t[a], h = o.getChildByName("wz"), n = o.getChildByName("line");
            if (a == e || 3 == a && e == HowToPlayDefined.RUMMY_MULTIPLE) {
                if (o.getComponent(Button).interactable = false, h.getComponent(Label).color = i, i18nMgr.shared().changeLabelFont(h.getComponent(Label), true), n.active = true, this.rummyType != e) {
                    n.scale = v3(0, 1, 1);
                    let e = TweenTool.scaleTo(n, 0.16, v3(1.1, 1, 1), null, false), t = TweenTool.scaleTo(n, 0.16, v3(1, 1, 1), null, false);
                    TweenTool.sequence(n, true, null, e, t);
                }
                else {
                    n.scale = v3(1, 1, 1);
                }
            }
            else {
                o.getComponent(Button).interactable = true;
                h.getComponent(Label).color = s;
                i18nMgr.shared().changeLabelFont(h.getComponent(Label), false);
                n.scale = v3(1, 1, 1);
                a == this.rummyType ? TweenTool.scaleTo(n, 0.1, v3(0.2, 1, 1), null, true, (() => {
                    n.scale = v3(1, 1, 1);
                    n.active = false;
                })) : n.active = false;
            }
        }
        this.rummyType = e;
        this.updateRoomInfo();
        this.updateSelectPlayer2();
    }
    layoutPracticeSelectors(player, mode, pool, deals, bot, y) {
        const extra = [mode, pool, deals].find(node => node.active);
        const selectors = extra ? [player, extra, bot] : [player, bot];
        const scale = extra ? 0.9 : 1;
        const positions = extra ? [-230, 0, 230] : [-130, 130];
        selectors.forEach((node, index) => {
            node.setScale(v3(scale, scale, 1));
            node.setPosition(v3(positions[index], y));
        });
    }
    updateRoomInfo() {
        this.roomInfoNode.getComponent(UIOpacity).opacity = 255;
        this.roomInfoNode.getComponent(Widget).updateAlignment();
        let e = this.roomInfoNode.getComponent(UITransform).height, t = this.roomInfoNode.getChildByName("player_select"), i = this.roomInfoNode.getChildByName("mode_select"), s = this.roomInfoNode.getChildByName("pool_select"), a = this.roomInfoNode.getChildByName("deals_select"), o = this.roomInfoNode.getChildByName("entry_info"), l = this.roomInfoNode.getChildByName("slider_view"), h = this.roomInfoNode.getChildByName("btn_start"), n = this.roomInfoNode.getChildByName("btn_addcash"), r = this.roomInfoNode.getChildByName("btn_create"), m = this.roomInfoNode.getChildByName("btn_join");
        if (0 == this.gameType && this.rummyType == HowToPlayDefined.RUMMY_POINTS) {
            i.active = true;
            let e = i.getChildByName("layout");
            e.getChildByName("btn_switch5").active = 1 == User.shared().double_6_open;
            e.getChildByName("btn_switch5").active || e.getChildByName("btn_switch4").active || e.getChildByName("btn_switch3").active || (i.active = false);
        }
        else if (3 == this.gameType && this.rummyType == HowToPlayDefined.RUMMY_POINTS) {
            i.active = true;
            let e = i.getChildByName("layout");
            e.getChildByName("btn_switch5").active = 1 == User.shared().chip_double_6_open;
            e.getChildByName("btn_switch5").active || e.getChildByName("btn_switch3").active || e.getChildByName("btn_switch3").active || (i.active = false);
        }
        else {
            i.active = false;
        }
        t.getChildByName("help").active = false;
        a.active = this.rummyType == HowToPlayDefined.RUMMY_DEALS;
        o.active = true;
        l.active = true;
        h.active = 2 != this.gameType;
        this.stopStartBtnAnim();
        2 != this.gameType && this.playStartBtnAnim();
        n.active = false;
        r.active = 2 == this.gameType;
        m.active = 2 == this.gameType;
        let d = -(161 + 161 * (e - 790) / 790 / 1.5);
        this.rummyType == HowToPlayDefined.RUMMY_POINTS ? (i.active ? (t.setPosition(v3(-130, d)), i.setPosition(v3(130, d))) : t.setPosition(v3(0, d)), a.active = false, s.active = false) : this.rummyType == HowToPlayDefined.RUMMY_POOL ? (s.active = true, a.active = false, t.setPosition(v3(-130, d)), s.setPosition(v3(130, d))) : this.rummyType == HowToPlayDefined.RUMMY_DEALS && (a.active = true, s.active = false, t.setPosition(v3(-130, d)), a.setPosition(v3(130, d)));
        this.chip_infoNode.active = 3 == this.gameType;
        this.chip_infoNode.setPosition(v3(-320, -50));
        o.setPosition(v3(0, -(315 + 315 * (e - 790) / 790 / 2)));
        let bot = this.roomInfoNode.getChildByName("bot_select");
        [t, i, s, a].forEach(node => node.setScale(v3(1, 1, 1)));
        if (bot) {
            bot.active = 3 == this.gameType;
            ToolUtils.isObjValid(bot.getChildByName("help")) && (bot.getChildByName("help").active = false);
            if (bot.active) {
                this.layoutPracticeSelectors(t, i, s, a, bot, d);
                this.updateBtnSwitchState(bot, this.selectBotMode, 5, this.selectBotMode);
            }
        }
        l.setPosition(v3(0, -(390 + 390 * (e - 790) / 790 / 2)));
        let c = h.getPosition().x, p = -(533 + 533 * (e - 790) / 790 / 2);
        if (h.setPosition(v3(c, p)), n.setPosition(v3(c, p)), r.setPosition(v3(c, p)), m.setPosition(v3(0, -(674 + 674 * (e - 790) / 790 / 2))), this.isPlaySwitchAction) {
            let e = 0.08, d = 0.08;
            this.chip_infoNode.active && this.playRoomInfoAnim(this.chip_infoNode, 0);
            this.chip_help.active && this.playRoomInfoAnim(this.chip_help, 0);
            t.active && this.playRoomInfoAnim(t, 0);
            i.active && this.playRoomInfoAnim(i, 0);
            s.active && this.playRoomInfoAnim(s, 0);
            a.active && this.playRoomInfoAnim(a, 0);
            o.active && (this.playRoomInfoAnim(o, d), d += e);
            l.active && (this.playRoomInfoAnim(l, d), d += e);
            h.active && (this.playRoomInfoAnim(h, d), this.playStartBtnAnim());
            n.active && this.playRoomInfoAnim(n, d);
            r.active && this.playRoomInfoAnim(r, d);
            m.active && this.playRoomInfoAnim(m, d);
        }
        this.isPlaySwitchAction = true;
    }
    playRoomInfoAnim(e, t) {
        let i = new Vec3;
        TweenTool.stopNodeAction(e);
        e.getPosition(i);
        e.getComponent(UIOpacity).opacity = 0;
        e.setPosition(v3(i.x, i.y - 20));
        let s = TweenTool.moveToByFade(e, 0.16, i, 0, 1, false), a = TweenTool.delayAct(e, null, t, false);
        TweenTool.sequence(e, true, null, a, s);
    }
    updateBtnSwitchState(e, t, i, s) {
        let a = this.btn_noSelectColor, o = color(255, 253, 253);
        if (1 != GameConfig.CHIPS_MODLE || 2000617 != GameConfig.CHANNEL_ID || 0 != GameConfig.GAME_HALL_THEME || (a = color("#647d77"), o = color("#ffd8a6")), 3 != i) {
            0 == t ? (e.getChildByName("select").setPosition(-55, -34.5), e.getChildByName("select").setScale(v3(-1, 1, 1)), e.getChildByName("Label1").getComponent(Label).color = o, e.getChildByName("btn_switch1").getComponent(Button).interactable = false, e.getChildByName("Label2").getComponent(Label).color = a, e.getChildByName("btn_switch2").getComponent(Button).interactable = true) : (e.getChildByName("select").setPosition(55, -34.5), e.getChildByName("select").setScale(v3(1, 1, 1)), e.getChildByName("Label1").getComponent(Label).color = a, e.getChildByName("btn_switch1").getComponent(Button).interactable = true, e.getChildByName("Label2").getComponent(Label).color = o, e.getChildByName("btn_switch2").getComponent(Button).interactable = false);
        }
        else {
            let i = e.getChildByName("layout"), s = [], h = User.shared().getCurModeVec(0), n = -1;
            for (let e, a = 0, o = h.length; a < o; a++) {
                e = h[a];
                ToolUtils.isObjValid(i.getChildByName("btn_switch" + e)) && i.getChildByName("btn_switch" + e).active && (s.push(i.getChildByName("btn_switch" + e)), e == t && (n = s.length - 1));
            }
            if (n >= 0) {
                ToolUtils.isObjValid(s[n].getChildByName("line")) && (s[n].getChildByName("line").active = false);
                s[n].getChildByName("select").active = true;
                s[n].getChildByName("Label").getComponent(Label).color = o;
                s[n].getComponent(Button).interactable = false;
                i18nMgr.shared().changeLabelFont(s[n].getChildByName("Label").getComponent(Label), true);
                for (let e = 0, t = s.length; e < t; e++) {
                    e != n && (s[e].getChildByName("select").active = false, s[e].getChildByName("Label").getComponent(Label).color = a, s[e].getComponent(Button).interactable = true, i18nMgr.shared().changeLabelFont(s[e].getChildByName("Label").getComponent(Label), false));
                }
            }
        }
        if (0 == i) {
            this.selectPlayers = s;
        }
        else if (1 == i) {
            this.selectPool = s;
        }
        else if (2 == i) {
            this.selectDeals = s;
        }
        else if (5 == i) {
            this.selectBotMode = s;
        }
        else if (3 == i) {
            if (this.selectMode = s, s == PointsType.Multiple) {
                this.modeHelpBtn.active = true;
                let e = sys.localStorage.getItem(User.shared().data.uid + "clickMultiple");
                if (!sys.isObjectValid(e) || Number(e) < 3) {
                    let t = isNaN(Number(e)) ? 1 : Number(e) + 1;
                    ToolUtils.saveData(User.shared().data.uid + "clickMultiple", "" + t);
                }
            }
            else if (s == PointsType.Wild) {
                this.modeHelpBtn.active = true;
                let e = sys.localStorage.getItem(User.shared().data.uid + "clickBump");
                if (!sys.isObjectValid(e) || Number(e) < 3) {
                    let t = isNaN(Number(e)) ? 1 : Number(e) + 1;
                    ToolUtils.saveData(User.shared().data.uid + "clickBump", "" + t);
                }
            }
            else if (s == PointsType.Double) {
                this.modeHelpBtn.active = true;
                let e = sys.localStorage.getItem(User.shared().data.uid + "clickDouble");
                if (!sys.isObjectValid(e) || Number(e) < 3) {
                    let t = isNaN(Number(e)) ? 1 : Number(e) + 1;
                    ToolUtils.saveData(User.shared().data.uid + "clickDouble", "" + t);
                }
            }
            else {
                this.modeHelpBtn.active = false;
            }
        }
    }
    updateDealsState() {
        2 == this.selectPlayers ? (this.roomInfoNode.getChildByName("deals_select").getChildByName("Label1").getComponent(Label).string = "2", this.roomInfoNode.getChildByName("deals_select").getChildByName("Label2").getComponent(Label).string = "3") : (this.roomInfoNode.getChildByName("deals_select").getChildByName("Label1").getComponent(Label).string = "3", this.roomInfoNode.getChildByName("deals_select").getChildByName("Label2").getComponent(Label).string = "6");
    }
    updateSliderProgress(e, t = true) {
        let i = this.roomInfoNode.getChildByName("slider_view").getChildByName("Slider"), s = i.getChildByName("ProgressBar");
        if (this.vCurRoomList && this.vCurRoomList.length > 1) {
            t && this.nIdx != e - 1 && this.playSoundAndVibration(1);
            this.nIdx = e - 1;
            let a = (e - 1) / (this.vCurRoomList.length - 1);
            i.getComponent(Slider).progress = a;
            s.getComponent(ProgressBar).progress = a;
            this.updateEntryInfo(e);
        }
        else {
            this.nIdx = 0;
            i.getComponent(Slider).progress = 0;
            s.getComponent(ProgressBar).progress = 0;
            this.updateEntryInfo(1);
        }
    }
    updateEntryInfo(e) {
        let t = this.roomInfoNode.getChildByName("entry_info");
        if (this.vCurRoomList && this.vCurRoomList[e - 1]) {
            t.active = true;
            let i = t.getChildByName("arrow"), s = t.getChildByName("points"), a = s.getChildByName("value"), o = t.getChildByName("entry"), h = o.getChildByName("fee"), n = t.getChildByName("feeNode"), r = n.getChildByName("fee"), m = "", d = "";
            this.rummyType == HowToPlayDefined.RUMMY_POINTS || this.rummyType == HowToPlayDefined.RUMMY_MULTIPLE ? (s.active = true, o.active = true, i.active = true, n.active = false, m = this.vCurRoomList[e - 1].boot, d = this.vCurRoomList[e - 1].entry) : (n.active = true, i.active = false, s.active = false, o.active = false, m = this.vCurRoomList[e - 1].boot, d = this.vCurRoomList[e - 1].entry);
            let c = 3 == this.gameType ? "" : "₹";
            3 == this.gameType && (m = ToolUtils.parse_ChipNum2(m), d = ToolUtils.parse_ChipNum2(d));
            a.getComponent(Label).string = c + m;
            h.getComponent(Label).string = c + d;
            r.getComponent(Label).string = c + d;
        }
        else {
            t.active = false;
        }
        this.updateChangePointBtnState();
        this.updateStartBtnState();
    }
    setBetPoint() {
        let e = this.roomInfoNode.getChildByName("slider_view"), t = e.getChildByName("Slider"), i = e.getChildByName("betroot"), s = e.getChildByName("bet_moban");
        if (s.active = false, i.destroyAllChildren(), this.vCurRoomList && this.vCurRoomList.length > 0) {
            let e = t.getComponent(UITransform).contentSize.width, a = 0;
            this.vCurRoomList.length > 1 && (a = e / (this.vCurRoomList.length - 1));
            t.getChildByName("best").active = this.bestIndex > 0;
            t.getChildByName("last").active = false;
            let o = -1, h = 0;
            0 == this.lastIndex ? 0 != this.bestIndex && (o = this.bestIndex, h = 1) : 0 != this.bestIndex ? this.lastIndex >= this.bestIndex ? (o = this.lastIndex, h = 0) : (o = this.bestIndex, h = 1) : (o = this.lastIndex, h = 1);
            -1 != o ? 0 == h ? (t.getChildByName("best").active = false, t.getChildByName("last").active = true, t.getChildByName("last").setPosition(v3(-e / 2 + a * (o - 1), t.getChildByName("last").position.y))) : (t.getChildByName("best").active = o > 1 && o != this.vCurRoomList.length, t.getChildByName("last").active = false, t.getChildByName("best").setPosition(v3(-e / 2 + a * (o - 1), t.getChildByName("best").position.y))) : (t.getChildByName("best").active = false, t.getChildByName("last").active = false);
            for (let t = 0, o = this.vCurRoomList.length; t < o; t++) {
                let h = instantiate(s);
                h.active = true;
                let n = this.vCurRoomList[t].boot;
                3 == this.gameType && (n = ToolUtils.parse_ChipNum2(n));
                h.getComponent(Label).string = n;
                0 == t ? h.setPosition(v3(-e / 2, 0)) : t == o - 1 ? h.setPosition(v3(e / 2, 0)) : (h.setPosition(v3(-e / 2 + a * t, 0)), sys.isObjectValid(this.vCurRoomList[t].sbet) && 1 == this.vCurRoomList[t].sbet || (h.getComponent(Label).string = ""));
                i.addChild(h);
            }
        }
        t.getChildByName("best").active = false;
        t.getChildByName("last").active = false;
    }
    updateChangePointBtnState() {
        let e = this.roomInfoNode.getChildByName("slider_view"), t = e.getChildByName("btn_add").getComponent(Button), i = e.getChildByName("btn_reduce").getComponent(Button);
        this.vCurRoomList && this.vCurRoomList.length > 1 ? (t.interactable = this.nIdx + 1 < this.vCurRoomList.length, i.interactable = this.nIdx > 0) : (t.interactable = false, i.interactable = false);
    }
    updateStartBtnState() {
        let e = null;
        Array.isArray(this.vCurRoomList) && this.vCurRoomList.length > this.nIdx && (e = this.vCurRoomList[this.nIdx]);
        try {
            if (null != e && null != e) {
                let t = ToolUtils.isSafeNumber(e.entry);
                if (this._min_entry = t, ToolUtils.isObjValid(this.roomInfoNode)) {
                    if (0 == this.gameType) {
                        let e = this.roomInfoNode.getChildByName("btn_start");
                        ToolUtils.isObjValid(e) && (!e.active && User.shared().data.money >= t && (this.stopStartBtnAnim(), this.playStartBtnAnim()), e.active = User.shared().data.money >= t);
                    }
                    else if (3 == this.gameType) {
                        let e = this.roomInfoNode.getChildByName("btn_start");
                        ToolUtils.isObjValid(e) && (!e.active && this.checkChipGameCanPlay(t) && (this.stopStartBtnAnim(), this.playStartBtnAnim()), e.active = this.checkChipGameCanPlay(t));
                    }
                    else if (2 == this.gameType) {
                        let e = this.roomInfoNode.getChildByName("btn_create");
                        ToolUtils.isObjValid(e) && (e.active = User.shared().data.money >= t);
                    }
                    let e = this.roomInfoNode.getChildByName("btn_addcash"), i = e.getChildByName("layout").getChildByName("wz");
                    ToolUtils.isObjValid(e) && (3 == this.gameType ? (e.active = !this.checkChipGameCanPlay(t), i18nMgr.shared().changeLocalizedLabelKey(i, "choose_game.play_now")) : (e.active = User.shared().data.money < t, e.active && i18nMgr.shared().changeLocalizedLabelKey(i, "choose_game.add_cash"), 2 == this.gameType && i18nMgr.shared().changeLocalizedLabelKey(i, "choose_game.create")));
                    this.checkBtnWzFontSize();
                }
            }
        }
        catch (e) {
            TLog.printError("trycatch updateStartBtnState,error:", e);
        }
        this.refreshRankStar();
    }
    checkChipGameCanPlay(e) {
        return 3 == this.gameType && User.shared().data.money_exe >= e;
    }
    checkBtnWzFontSize() {
    }
    fitScreen() {
        sys.os === sys.OS.IOS && ToolUtils.isObjValid(this.node.getChildByName("root")) && ToolUtils.getSafeDistance() > 40 && (this.node.getChildByName("root").getComponent(Widget).top = 284);
        let e = 21, t = sys.getSafeAreaRect().y;
        ToolUtils.isPadPlatform() && (t = 0, e = 0);
        this.risk_tipNode.getComponent(Widget).bottom = 110 + e - t;
    }
    onYesClick(e, t) {
        SoundManager.shared().playFx("click");
        TransferPlatform.shared().logEvent_firebase(ReportConfig.firebase_evt.click_yes11);
        let i = { lastNode: Utils.shared().hall_rootNode };
        Utils.shared().doJumpLogic(PushEvent.JUMP_TO_Yes11, i);
    }
    onRankClick(e, t) {
        SoundManager.shared().playFx("click");
        Utils.shared().showGameRankView();
    }
    onGameTypeClick(e, t) {
        SoundManager.shared().playFx("click");
        let i = Number(t);
        if (1 === User.shared().temp_pingbi.matchgame && 1 == i) {
            return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text41"), 2);
        }
        if (1 === User.shared().temp_pingbi.buddygame && 2 == i) {
            return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text41"), 2);
        }
        if (User.shared().openGameTab && User.shared().openGameTab[i + 1]) {
            if (1 != i) {
                let e = false, t = sys.localStorage.getItem(User.shared().data.uid + "recommendRoom" + i + 0);
                if (t) {
                    let s = ToolUtils.getRecommendRoom(ToolUtils.parseJson(t));
                    e = this.setInitGameType(i, s.rummyType, s.playersIndex, s.poolIndex, s.dealsIndex, true, s.enterMoney, s.modeIndex);
                }
                else {
                    let t = null;
                    if (!sys.isObjectValid(t) && sys.isObjectValid(User.shared().data.recommend)) {
                        let e = ToolUtils.getRecommendRoom(User.shared().data.recommend);
                        sys.isObjectValid(e.playersIndex) && e.gameType == i && (t = e);
                    }
                    if (!sys.isObjectValid(t) && sys.isObjectValid(User.shared().roomTable.recommend)) {
                        let e = ToolUtils.getRecommendRoom(User.shared().roomTable.recommend);
                        sys.isObjectValid(e.playersIndex) && e.gameType == i && (t = e);
                    }
                    e = sys.isObjectValid(t) ? this.setInitGameType(i, t.rummyType, t.playersIndex, t.poolIndex, t.dealsIndex, true, t.enterMoney, t.modeIndex) : this.setInitGameType(i, 0, 1, 0, 0, true);
                }
                e || (Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text34"), 2), User.shared().cleanLocalRoomTable(true), User.shared().checkGameRoomList(false, true));
            }
            else {
                this.updateGameType(i, true);
                this.tournamentNode && this.tournamentNode.getComponent(MatchRoom).playRoomInfoAnim();
            }
        }
        else {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text34"), 2);
            User.shared().cleanLocalRoomTable(true);
            User.shared().checkGameRoomList(false, true);
        }
        let s = "";
        0 == i ? s = ReportConfig.hall_evt.clickCashGame : 1 == i && (s = ReportConfig.hall_evt.clickMatchGame);
        s.length > 0 && HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Hall, event: s });
        this.refreshRankStar();
        this.checkHandGuide(8);
    }
    onRummyTypeClick(e, t) {
        SoundManager.shared().playFx("click");
        let i = "", s = "", a = "", o = Number(t);
        if (0 === this.gameType && (User.shared().getHallInfo(), 0 == o ? (i = ReportConfig.cash_evt.click_points_tab, s = ReportConfig.scece.CashPoint, a = ReportConfig.func.Rummy_Game_Point) : 1 == o ? (i = ReportConfig.cash_evt.click_pool_tab, s = ReportConfig.scece.CashPool, a = ReportConfig.func.Rummy_Game_Pool) : 2 == o ? (i = ReportConfig.cash_evt.click_deals_tab, s = ReportConfig.scece.CashDeals, a = ReportConfig.func.Rummy_Game_Deals) : 3 == o && (o = HowToPlayDefined.RUMMY_MULTIPLE, i = ReportConfig.cash_evt.click_multiple_tab, s = ReportConfig.scece.CashMultiple, a = ReportConfig.func.Rummy_Game_Multiple), s.length > 0 && HttpManager.shared().doSdkApiReport({ scene: s, func: a, event: i })), 0 == this.gameType) {
            if (1 == o) {
                if (Utils.shared().judgeCashPoolAllRoomLock()) {
                    let e = Utils.shared().getCashPoolAllRoomLockTipsNum();
                    if (e > 0) {
                        return void Utils.shared().showRoomUnlockDialog(this.gameType, e);
                    }
                }
            }
            else if (2 == o) {
                if (Utils.shared().judgeCashDealsAllRoomLock()) {
                    let e = Utils.shared().getCashDealsAllRoomLockTipsNum();
                    if (e > 0) {
                        return void Utils.shared().showRoomUnlockDialog(this.gameType, e);
                    }
                }
            }
        }
        let l = Utils.shared().getCurRoomList(this.gameType, o);
        l && l.length > 0 ? this.isPlaySwitchAction ? (this.roomInfoNode.getComponent(UIOpacity).opacity = 255, this.refreshRummyType(o), this.checkHandGuide(10, o)) : this.refreshRummyType(o) : Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text34"), 2);
        this.refreshRankStar();
        this.checkHandGuide(9);
    }
    refreshRummyType(e) {
        let t = sys.localStorage.getItem(User.shared().data.uid + "recommendRoom" + this.gameType + e);
        if (t) {
            let i = ToolUtils.getRecommendRoom(ToolUtils.parseJson(t));
            this.setInitGameType(this.gameType, e, i.playersIndex, i.poolIndex, i.dealsIndex, false, i.enterMoney, i.modeIndex);
        }
        else {
            let t = null;
            if (!sys.isObjectValid(t) && sys.isObjectValid(User.shared().data.recommend)) {
                let i = ToolUtils.getRecommendRoom(User.shared().data.recommend);
                sys.isObjectValid(i.playersIndex) && i.gameType == this.gameType && i.rummyType == e && (t = i);
            }
            if (!sys.isObjectValid(t) && sys.isObjectValid(User.shared().roomTable.recommend)) {
                let i = ToolUtils.getRecommendRoom(User.shared().roomTable.recommend);
                sys.isObjectValid(i.playersIndex) && i.gameType == this.gameType && i.rummyType == e && (t = i);
            }
            sys.isObjectValid(t) ? this.setInitGameType(this.gameType, e, t.playersIndex, t.poolIndex, t.dealsIndex, false, t.enterMoney, t.modeIndex) : this.setInitGameType(this.gameType, e, 1, 0, 1);
        }
        e == HowToPlayDefined.RUMMY_MULTIPLE && this.onShowMultipleTip();
    }
    onPlayerSelectClick(e, t) {
        SoundManager.shared().playFx("click");
        let i = Number(t), s = 2 == i ? 0 : 1, a = sys.localStorage.getItem(User.shared().data.uid + "recommendRoom" + this.gameType + this.rummyType), o = this.vCurRoomList[this.nIdx], l = -1;
        sys.isObjectValid(o.mode) && (l = o.mode);
        let h = null;
        if (a) {
            let e = ToolUtils.parseJson(a);
            if (e && e.data) {
                if (sys.isObjectValid(e.data.mode)) {
                    let t = i;
                    2 == e.data.mode && 2 != t && (t = 4);
                    sys.isObjectValid(e.data.mode) && -1 != l ? e.data.player == t && e.data.mode == l && (h = e.data.entry) : e.data.player == t && (h = e.data.entry);
                }
                else {
                    sys.isObjectValid(e.data.mode) && -1 != l ? e.data.player == i && e.data.mode == l && (h = e.data.entry) : e.data.player == i && (h = e.data.entry);
                }
            }
        }
        let n = null;
        if (this.rummyType == HowToPlayDefined.RUMMY_DEALS) {
            if (2 == i) {
                if (n = this.getSelectRoomList(i, this.selectPool, 2, h), n && n.length > 0) {
                    return this.selectDeals = 2, this.updateBtnSwitchState(this.roomInfoNode.getChildByName("player_select"), s, 0, i), this.updateBtnSwitchState(this.roomInfoNode.getChildByName("deals_select"), 0, 2, 2), void this.updateDealsState();
                }
                if (n = this.getSelectRoomList(i, this.selectPool, 3, h), !(n && n.length > 0)) {
                    return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text34"), 2);
                }
                this.selectDeals = 3;
                this.updateBtnSwitchState(this.roomInfoNode.getChildByName("player_select"), s, 0, i);
                this.updateBtnSwitchState(this.roomInfoNode.getChildByName("deals_select"), 1, 2, 3);
                this.updateDealsState();
            }
            else {
                if (n = this.getSelectRoomList(i, this.selectPool, 3, h), n && n.length > 0) {
                    return this.selectDeals = 3, this.updateBtnSwitchState(this.roomInfoNode.getChildByName("player_select"), s, 0, i), this.updateBtnSwitchState(this.roomInfoNode.getChildByName("deals_select"), 0, 2, 3), void this.updateDealsState();
                }
                if (n = this.getSelectRoomList(i, this.selectPool, 6, h), !(n && n.length > 0)) {
                    return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text34"), 2);
                }
                this.selectDeals = 6;
                this.updateBtnSwitchState(this.roomInfoNode.getChildByName("player_select"), s, 0, i);
                this.updateBtnSwitchState(this.roomInfoNode.getChildByName("deals_select"), 1, 2, 6);
                this.updateDealsState();
            }
        }
        else {
            if (!Utils.shared().judgeCashPointExistUnlockRoom(i, l) && 0 == this.gameType && this.rummyType == HowToPlayDefined.RUMMY_POINTS) {
                let e = Utils.shared().getCashUnlockRoomNum(this.rummyType, i, l);
                return void Utils.shared().showRoomUnlockDialog(this.gameType, e);
            }
            if (n = this.getSelectRoomList(i, this.selectPool, this.selectDeals, h), !(n && n.length > 0)) {
                return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text34"), 2);
            }
            this.updateBtnSwitchState(this.roomInfoNode.getChildByName("player_select"), s, 0, i);
        }
        this.checkHandGuide(3);
    }
    onModeSelectClick(e, t) {
        SoundManager.shared().playFx("click");
        let i = Number(t), s = this.vCurRoomList[this.nIdx];
        if (s && i > 0 && 0 === this.gameType) {
            let e = {};
            if (this.rummyType == HowToPlayDefined.RUMMY_POINTS && (e = Utils.shared().judgeCashPointRoomUnlock(this.selectPlayers, i, s.entry)), e && !e.openBol) {
                return void Utils.shared().showRoomUnlockDialog(this.gameType, e.num);
            }
        }
        if (i == PointsType.Wild) {
            (0 == this.gameType && 6 == this.selectPlayers && 1 != User.shared().bump_6_open || 2 == this.selectPlayers && 1 != User.shared().bump_2_open || 3 == this.gameType && 6 == this.selectPlayers && 1 != User.shared().chip_bump_6_open || 2 == this.selectPlayers && 1 != User.shared().chip_bump_2_open) && (0 == this.gameType && 1 == User.shared().bump_6_open || 3 == this.gameType && 1 == User.shared().chip_bump_6_open ? this.updateBtnSwitchState(this.roomInfoNode.getChildByName("player_select"), 1, 0, 6) : this.updateBtnSwitchState(this.roomInfoNode.getChildByName("player_select"), 0, 0, 2));
        }
        else if (i == PointsType.Double) {
            0 != this.gameType && 3 != this.gameType || this.updateBtnSwitchState(this.roomInfoNode.getChildByName("player_select"), 1, 0, 6);
        }
        else if (i == PointsType.Multiple) {
            if (0 === this.gameType && (1 == User.shared().multiple_rummy_open || 1 == User.shared().multiple_2_open) || 3 === this.gameType && (1 == User.shared().chip_multiple_rummy_open || 1 == User.shared().chip_multiple_2_open)) {
                if (s && i > 0 && 0 === this.gameType) {
                    let e = {};
                    if (this.rummyType == HowToPlayDefined.RUMMY_POINTS && (e = Utils.shared().judgeCashPointRoomUnlock(this.selectPlayers, i, s.entry)), e && !e.openBol) {
                        return void Utils.shared().showRoomUnlockDialog(this.gameType, e.num);
                    }
                }
                (0 === this.gameType && 6 == this.selectPlayers && 1 != User.shared().multiple_rummy_open || 2 == this.selectPlayers && 1 != User.shared().multiple_2_open || 3 === this.gameType && 6 == this.selectPlayers && 1 != User.shared().chip_multiple_rummy_open || 2 == this.selectPlayers && 1 != User.shared().chip_multiple_2_open) && (0 === this.gameType && 1 == User.shared().multiple_rummy_open || 3 === this.gameType && 1 == User.shared().chip_multiple_rummy_open ? this.updateBtnSwitchState(this.roomInfoNode.getChildByName("player_select"), 1, 0, 6) : this.updateBtnSwitchState(this.roomInfoNode.getChildByName("player_select"), 0, 0, 2));
            }
            else if (0 === this.gameType && 1 == User.shared().multiple_rummy_open || 3 === this.gameType && 1 == User.shared().chip_multiple_rummy_open) {
                if (s && i > 0 && 0 === this.gameType) {
                    let e = {};
                    if (this.rummyType == HowToPlayDefined.RUMMY_POINTS && (e = Utils.shared().judgeCashPointRoomUnlock(6, i, s.entry)), e && !e.openBol) {
                        return void Utils.shared().showRoomUnlockDialog(this.gameType, e.num);
                    }
                }
                6 != this.selectPlayers && (0 === this.gameType && 0 == User.shared().multiple_2_open || 3 === this.gameType && 0 == User.shared().chip_multiple_2_open) && this.updateBtnSwitchState(this.roomInfoNode.getChildByName("player_select"), 1, 0, 6);
            }
            else if (0 === this.gameType && 1 == User.shared().multiple_2_open || 3 === this.gameType && 1 == User.shared().chip_multiple_2_open) {
                if (s && i > 0 && 0 === this.gameType) {
                    let e = {};
                    if (this.rummyType == HowToPlayDefined.RUMMY_POINTS && (e = Utils.shared().judgeCashPointRoomUnlock(2, i, s.entry)), e && !e.openBol) {
                        return void Utils.shared().showRoomUnlockDialog(this.gameType, e.num);
                    }
                }
                2 != this.selectPlayers && this.updateBtnSwitchState(this.roomInfoNode.getChildByName("player_select"), 1, 0, 2);
            }
        }
        let a = this.getEnterMoney(i), o = this.getSelectRoomList(this.selectPlayers, this.selectPool, this.selectDeals, a, i);
        o && o.length > 0 ? (this.updateBtnSwitchState(this.roomInfoNode.getChildByName("mode_select"), i, 3, i), this.updateSelectPlayer2(), i == PointsType.Multiple ? this.onShowMultipleTip() : i == PointsType.Wild ? this.onShowBumpTip() : i == PointsType.Double ? this.onShowDoubleTip() : i == PointsType.Easy && this.onShowEasyTip(), this.checkHandGuide(7)) : Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text34"), 2);
    }
    getEnterMoneyApi(e, t = false, i = 0, s = 0, a = 0) {
        let o = sys.localStorage.getItem(User.shared().data.uid + "recommendRoom" + i + s), l = null;
        if (o) {
            let i = ToolUtils.parseJson(o);
            if (i && i.data) {
                if (sys.isObjectValid(i.data.mode)) {
                    let s = a;
                    t && 2 == i.data.mode && 2 != s && (s = 4);
                    i.data.player == s && i.data.mode == e && (l = i.data.entry);
                }
                else {
                    i.data.player == a && (l = i.data.entry);
                }
                if (sys.isObjectValid(i.data.mode)) {
                    let t = a;
                    i.data.player == t && i.data.mode == e && (l = i.data.entry);
                }
                else {
                    i.data.player == a && (l = i.data.entry);
                }
            }
        }
        return l;
    }
    getEnterMoney(e, t = false) {
        let i = sys.localStorage.getItem(User.shared().data.uid + "recommendRoom" + this.gameType + this.rummyType), s = null;
        if (i) {
            let a = ToolUtils.parseJson(i);
            if (a && a.data) {
                if (sys.isObjectValid(a.data.mode)) {
                    let i = this.selectPlayers;
                    t && 2 == a.data.mode && 2 != i && (i = 4);
                    a.data.player == i && a.data.mode == e && (s = a.data.entry);
                }
                else {
                    a.data.player == this.selectPlayers && (s = a.data.entry);
                }
                if (sys.isObjectValid(a.data.mode)) {
                    let t = this.selectPlayers;
                    a.data.player == t && a.data.mode == e && (s = a.data.entry);
                }
                else {
                    a.data.player == this.selectPlayers && (s = a.data.entry);
                }
            }
        }
        return s;
    }
    onShowEasyTip() {
        let e = sys.localStorage.getItem(User.shared().data.uid + "Easy_Game_Tips_Times"), t = 0, i = false;
        sys.isObjectValid(e) ? Number(e) > 0 && Number(e) < ToolUtils.isSafeNumber(User.shared().points_easy_cfg.tips_times) && (i = true, t = Number(e) + 1) : (i = true, t = 1);
        i && (ToolUtils.saveData(User.shared().data.uid + "Easy_Game_Tips_Times", String(t)), this.showEasyGameAlert());
    }
    onShowMultipleTip() {
        let e = sys.localStorage.getItem(User.shared().data.uid + "Multiple_Game_Tips_Times"), t = 0, i = false;
        sys.isObjectValid(e) ? Number(e) > 0 && Number(e) < ToolUtils.isSafeNumber(User.shared().points_multiple_cfg.tips_times) && (i = true, t = Number(e) + 1) : (i = true, t = 1);
        i && (ToolUtils.saveData(User.shared().data.uid + "Multiple_Game_Tips_Times", String(t)), this.showMultipleGameAlert());
    }
    onShowBumpTip() {
        let e = sys.localStorage.getItem(User.shared().data.uid + "Bump_Game_Tips_Times"), t = 0, i = false;
        sys.isObjectValid(e) || (e = "0");
        Number(e) < ToolUtils.isSafeNumber(User.shared().points_bump_cfg.tips_times) && (i = true, t = Number(e) + 1);
        i && (ToolUtils.saveData(User.shared().data.uid + "Bump_Game_Tips_Times", String(t)), this.showBumpGameAlert());
    }
    onShowDoubleTip() {
        let e = sys.localStorage.getItem(User.shared().data.uid + "Double_Game_Tips_Times"), t = 0, i = false;
        sys.isObjectValid(e) || (e = "0");
        Number(e) < ToolUtils.isSafeNumber(User.shared().points_double_cfg.tips_times) && (i = true, t = Number(e) + 1);
        i && (ToolUtils.saveData(User.shared().data.uid + "Double_Game_Tips_Times", String(t)), this.showDoubleGameAlert());
    }
    onShowChipTip() {
        let e = sys.localStorage.getItem(User.shared().data.uid + "Chip_Game_Tips_Times"), t = 0, i = false;
        sys.isObjectValid(e) ? Number(e) > 0 && Number(e) < ToolUtils.isSafeNumber(User.shared().exe_cfg.introduce_times) && (i = true, t = Number(e) + 1) : (i = true, t = 1);
        i && (ToolUtils.saveData(User.shared().data.uid + "Chip_Game_Tips_Times", String(t)), this.showChipGameAlert());
    }
    onCheckShowGameAlert() {
        if (this.selectMode !== PointsType.Multiple && this.selectMode != PointsType.Wild && this.selectMode != PointsType.Double && this.selectMode != PointsType.Easy) {
            return;
        }
        let e = this.getSelectRoomList(this.selectPlayers, this.selectPool, this.selectDeals);
        e && e.length > 0 && (this.selectMode == PointsType.Multiple ? this.showMultipleGameAlert() : this.selectMode == PointsType.Wild ? this.showBumpGameAlert() : this.selectMode == PointsType.Double ? this.showDoubleGameAlert() : this.selectMode == PointsType.Easy && this.showEasyGameAlert());
    }
    onModeHelpClick(e, t) {
        SoundManager.shared().playFx("click");
        "chips" == t ? this.showChipGameAlert() : this.selectMode == PointsType.Multiple ? this.showMultipleGameAlert() : this.selectMode == PointsType.Easy ? this.showEasyGameAlert() : this.selectMode == PointsType.Wild ? this.showBumpGameAlert() : this.selectMode == PointsType.Double && this.showDoubleGameAlert();
    }
    showMultipleGameAlert() {
        let e = this.roomInfoNode.getChildByName("entry_info").getChildByName("points").getChildByName("value").getComponent(Label).string, t = { info: "Points - Multiples - " + this.selectPlayers + "Players - " + e, min_entry: this._min_entry, game_type: this.gameType };
        Utils.shared().showMultipleGameTypeAlert(t, (e => {
            this.onStartGameClick(null, e);
        }));
    }
    showBumpGameAlert() {
        let e = this.roomInfoNode.getChildByName("entry_info").getChildByName("points").getChildByName("value").getComponent(Label).string, t = { info: "Points - Wild - " + this.selectPlayers + "Players - " + e, min_entry: this._min_entry, game_type: this.gameType };
        Utils.shared().showBumpGameTypeAlert(t, (e => {
            this.onStartGameClick(null, e);
        }));
    }
    showEasyGameAlert() {
        let e = { info: "Points - Easy- " + (6 == this.selectPlayers ? 4 : this.selectPlayers) + "Players - " + this.roomInfoNode.getChildByName("entry_info").getChildByName("points").getChildByName("value").getComponent(Label).string, min_entry: this._min_entry };
        Utils.shared().showEasyGameTypeAlert(e, (e => {
            this.onStartGameClick(null, e);
        }));
    }
    showChipGameAlert() {
        let e = { info: "Chip - " + (6 == this.selectPlayers ? 4 : this.selectPlayers) + "Players - " + this.roomInfoNode.getChildByName("entry_info").getChildByName("points").getChildByName("value").getComponent(Label).string, min_entry: this._min_entry, parent_node: director.getScene().getChildByName("Canvas") };
        Utils.shared().showChipGameTypeView(e, (e => {
            this.onStartGameClick(null, e);
        }));
    }
    showDoubleGameAlert() {
        let e = this.roomInfoNode.getChildByName("entry_info").getChildByName("points").getChildByName("value").getComponent(Label).string, t = { info: "Points - Double - " + this.selectPlayers + "Players - " + e, min_entry: this._min_entry, game_type: this.gameType };
        Utils.shared().showDoubleRummyTypeAlert(t, (e => {
            this.onStartGameClick(null, e);
        }));
    }
    onPoolSelectClick(e, t) {
        SoundManager.shared().playFx("click");
        let i = 101 == Number(t) ? 0 : 1, s = sys.localStorage.getItem(User.shared().data.uid + "recommendRoom" + this.gameType + this.rummyType), a = null;
        if (s) {
            let e = ToolUtils.parseJson(s);
            e && e.data && e.data.player == this.selectPlayers && e.data.pool_game == Number(t) && (a = e.data.entry);
        }
        let o = this.getSelectRoomList(this.selectPlayers, Number(t), this.selectDeals, a);
        o && o.length > 0 ? this.updateBtnSwitchState(this.roomInfoNode.getChildByName("pool_select"), i, 1, Number(t)) : Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text34"), 2);
    }
    onDealsSelectClick(e, t) {
        SoundManager.shared().playFx("click");
        let i = 2 == Number(t) ? 0 : 1, s = Number(t);
        6 == this.selectPlayers && (s = 2 == Number(t) ? 3 : 6);
        let a = sys.localStorage.getItem(User.shared().data.uid + "recommendRoom" + this.gameType + this.rummyType), o = null;
        if (a) {
            let e = ToolUtils.parseJson(a);
            e && e.data && e.data.player == this.selectPlayers && e.data.deals == s && (o = e.data.entry);
        }
        let l = this.getSelectRoomList(this.selectPlayers, this.selectPool, s, o);
        l && l.length > 0 ? this.updateBtnSwitchState(this.roomInfoNode.getChildByName("deals_select"), i, 2, s) : Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text34"), 2);
    }
    onSliderCallback(e, t) {
        e.target;
        let i = 0, s = this.roomInfoNode.getChildByName("slider_view").getChildByName("Slider"), a = s.getChildByName("ProgressBar"), o = s.getComponent(Slider).progress;
        this.vCurRoomList && this.vCurRoomList.length > 1 && (i = Math.floor((this.vCurRoomList.length - 1) * o + 0.5));
        a.getComponent(ProgressBar).progress = o;
        this.updateSliderProgress(i + 1);
        this.checkHandGuide(6);
    }
    playSoundAndVibration(e) {
        SoundManager.shared().playFx("select_time");
    }
    onChangePointClick(e, t) {
        SoundManager.shared().playFx("click");
        this._lastClick = sys.now();
        this.vCurRoomList && this.vCurRoomList.length > 0 && ("add" == t ? this.nIdx + 1 < this.vCurRoomList.length && (this.nIdx = this.nIdx + 1, this.updateSliderProgress(this.nIdx + 1)) : this.nIdx > 0 && (this.nIdx = this.nIdx - 1, this.updateSliderProgress(this.nIdx + 1)), this.updateChangePointBtnState());
        this.checkHandGuide(5);
    }
    onStartGameClick(e, t) {
        SoundManager.shared().playFx("click");
        this._lastClick = sys.now();
        let i = this.vCurRoomList[this.nIdx];
        if (i && 0 === this.gameType) {
            let e = {};
            if (this.rummyType == HowToPlayDefined.RUMMY_POINTS) {
                e = Utils.shared().judgeCashPointRoomUnlock(this.selectPlayers, i.mode, i.entry);
            }
            else if (this.rummyType == HowToPlayDefined.RUMMY_POOL) {
                e = Utils.shared().judgeCashPoolRoomUnlock(this.selectPlayers, i.pool_game, i.entry);
            }
            else if (this.rummyType == HowToPlayDefined.RUMMY_DEALS) {
                let t = this.selectDeals;
                6 == this.selectPlayers && (t = 2 == Number(t) ? 3 : 6);
                e = Utils.shared().judgeCashDealsRoomUnlock(this.selectPlayers, t, i.entry);
            }
            if (e && !e.openBol) {
                return void Utils.shared().showRoomUnlockDialog(this.gameType, e.num);
            }
        }
        if ("addcash" != t && i && i.vid) {
            let e = i.vid;
            User.shared().min_money = i.entry;
            ToolUtils.curRoomId = e;
            0 !== this.gameType && 2 !== this.gameType || (this.rummyType == HowToPlayDefined.RUMMY_POINTS ? (HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.CashPoint, func: ReportConfig.func.Rummy_Game_Point, event: ReportConfig.cash_evt.click_points_start, type: HowToPlayDefined.RUMMY_POINTS, cnt: this.selectPlayers, amt: i.boot }), User.shared().uploadLocationInfo()) : this.rummyType == HowToPlayDefined.RUMMY_POOL ? (HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.CashPool, func: ReportConfig.func.Rummy_Game_Pool, event: ReportConfig.cash_evt.click_pool_start, type: HowToPlayDefined.RUMMY_POOL, cnt: this.selectPlayers, amt: i.boot, round: this.selectPool }), User.shared().uploadLocationInfo()) : this.rummyType == HowToPlayDefined.RUMMY_DEALS ? (HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.CashDeals, func: ReportConfig.func.Rummy_Game_Deals, event: ReportConfig.cash_evt.click_deals_start, type: HowToPlayDefined.RUMMY_DEALS, cnt: this.selectPlayers, amt: i.boot, round: this.selectDeals }), User.shared().uploadLocationInfo()) : this.rummyType == HowToPlayDefined.RUMMY_MULTIPLE && (HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.CashMultiple, func: ReportConfig.func.Rummy_Game_Multiple, event: ReportConfig.cash_evt.click_multiple_start, type: HowToPlayDefined.RUMMY_MULTIPLE, cnt: this.selectPlayers, amt: i.boot }), User.shared().uploadLocationInfo()));
        }
        if ("start" == t) {
            if (3 == this.gameType) {
                if (!User.shared().checkCanPlayCashGame(CheckModule.CHIPS_PLAY)) {
                    return;
                }
            }
            else if (!User.shared().checkCanPlayCashGame(CheckModule.CASH_PLAY)) {
                return;
            }
            TransferPlatform.shared().logEvent_firebase(ReportConfig.firebase_evt.click_choosegame_start);
        }
        let s = "Click_GameIcon_Rm_", a = s + (parseInt("" + this.nIdx) + 1), o = GameConfig[a];
        if (null != GameConfig[a] && null != GameConfig[a] || (o = parseInt("" + PhpReportDefined[s + "1"]) + parseInt("" + this.nIdx)), HttpManager.shared().doReportUserAct(o), Utils.shared().uploadGtagEvent(PhpReportDefined.GA_StartGameEvent), Utils.shared().uploadFBEvent(PhpReportDefined.FB_StartGameEvent), "addcash" == t) {
            TransferPlatform.shared().logEvent_firebase(ReportConfig.firebase_evt.click_choosegame_addgold);
            this.roomInfoNode.getChildByName("btn_addcash").getComponent(Button).interactable = false;
            TweenTool.delayAct(this.roomInfoNode, (() => {
                ToolUtils.isObjValid(this.roomInfoNode) && (this.roomInfoNode.getChildByName("btn_addcash").getComponent(Button).interactable = true);
            }), 1, true);
            let e = null, t = 0;
            if (this._min_entry = 0, Array.isArray(this.vCurRoomList) && this.vCurRoomList.length > this.nIdx && (e = this.vCurRoomList[this.nIdx], t = ToolUtils.isSafeNumber(e.vid), undefined !== e.entry && (this._min_entry = e.entry)), 0 == this.gameType || 2 == this.gameType) {
                Utils.shared().showQuickRecharge(t, null, true, "", 0, this._min_entry, true, 0, 1);
                User.shared().updatePayScene(PhpReportDefined.pay_scene.hall_less_money, t);
            }
            else if (3 == this.gameType) {
                director.getScene().getChildByName("Canvas");
                this._min_entry;
                Utils.shared().showToast("Not enough chips for this table. Please choose a lower point value or another practice table.", 3, 0, ToolUtils.getIsNormalDirection());
            }
            0 === this.gameType && (this.rummyType == HowToPlayDefined.RUMMY_POINTS ? HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.CashPoint, func: ReportConfig.func.Rummy_Game_Point, event: ReportConfig.cash_evt.click_points_add_ca }) : this.rummyType == HowToPlayDefined.RUMMY_POOL ? HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.CashPool, func: ReportConfig.func.Rummy_Game_Pool, event: ReportConfig.cash_evt.click_pool_add_ca }) : this.rummyType == HowToPlayDefined.RUMMY_DEALS ? HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.CashDeals, func: ReportConfig.func.Rummy_Game_Deals, event: ReportConfig.cash_evt.click_deals_add_ca }) : this.rummyType == HowToPlayDefined.RUMMY_MULTIPLE && HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.CashMultiple, func: ReportConfig.func.Rummy_Game_Multiple, event: ReportConfig.cash_evt.click_multiple_add_ca }));
        }
        else {
            let e = 0, t = 0;
            if (Array.isArray(this.vCurRoomList) && this.vCurRoomList.length > this.nIdx) {
                let i = this.vCurRoomList[this.nIdx];
                t = i.boot;
                undefined !== i.entry && (e = i.entry);
                undefined !== i.max_money && i.max_money > e && (e = i.max_money);
            }
            if (3 == this.gameType && User.shared().data.money_exe >= e) {
                let e = this.getRecommendPracticeRoom();
                if (e) {
                    let t = e.boot, i = ToolUtils.format(i18nMgr.shared().getValueByKey("choose_game.chip_up_tips"), t), s = { bLandscape: ToolUtils.getIsNormalDirection(), bWithCancel: false, strContent: i, sureKey: "choose_game.play_now" };
                    return void Utils.shared().showCommonAlert(s, (t => {
                        1 === t && this.enterGame(e);
                    }), true);
                }
            }
            else if (0 == this.gameType && sys.isObjectValid(this.vCurRoomList) && 0 != this.bestIndex) {
                let e = this.vCurRoomList[this.bestIndex - 1];
                if (null != e.boot && e.boot > t) {
                    return void User.shared().requestCheckCashGameUpPop({ vid: e.vid }, (t => {
                        sys.isObjectValid(t) && 1 == t ? User.shared().showCashGameUpAlert(e.boot, (t => {
                            ToolUtils.isObjValid(this.node) && (1 == t ? this.enterGame(e) : Array.isArray(this.vCurRoomList) && this.vCurRoomList.length > this.nIdx && this.enterGame(this.vCurRoomList[this.nIdx]));
                        }), PhpReportDefined.scece.cash_hall_choose) : ToolUtils.isObjValid(this.node) && Array.isArray(this.vCurRoomList) && this.vCurRoomList.length > this.nIdx && this.enterGame(this.vCurRoomList[this.nIdx]);
                    }));
                }
            }
            Array.isArray(this.vCurRoomList) && this.vCurRoomList.length > this.nIdx && this.enterGame(this.vCurRoomList[this.nIdx]);
        }
    }
    enterGame(e) {
        if (this.roomInfoNode.getChildByName("btn_start").getComponent(Button).interactable = false, TweenTool.delayAct(this.roomInfoNode, (() => {
            ToolUtils.isObjValid(this.roomInfoNode) && (this.roomInfoNode.getChildByName("btn_start").getComponent(Button).interactable = true);
        }), 1, true), e && e.vid) {
            let t = e.vid;
            User.shared().min_money = e.entry;
            ToolUtils.curRoomId = t;
            let i = {};
            i.lobby = this.gameType;
            i.game = this.rummyType;
            i.data = e;
            ToolUtils.saveData(User.shared().data.uid + "recommendRoom" + this.gameType + this.rummyType, ToolUtils.toJsonString(i));
            ToolUtils.saveData(User.shared().data.uid + "recommendRoomNew", ToolUtils.toJsonString(i));
            this.enterRummy(t, this.rummyType);
        }
    }
    onBuddyGameClick(e, t) {
        if (SoundManager.shared().playFx("click"), sys.now() - this._lastClick < 500) {
            return;
        }
        if (this._lastClick = sys.now(), !User.shared().checkCanPlayCashGame(CheckModule.CASH_PLAY)) {
            return;
        }
        if (1 != Utils.shared().showFastKyc()) {
            if ("join" == t) {
                Utils.shared().showBuddyJoinView();
            }
            else if ("create" == t) {
                let e = this.vCurRoomList[this.nIdx], t = e.boot, i = {};
                i.lobby = this.gameType;
                i.game = this.rummyType;
                i.data = { boot: t, max_money: e.max_money, entry: e.entry, min_money: e.min_money, player: this.selectPlayers, pool_game: this.selectPool, deals: this.selectDeals };
                ToolUtils.saveData(User.shared().data.uid + "recommendRoom" + this.gameType + this.rummyType, ToolUtils.toJsonString(i));
                ToolUtils.saveData(User.shared().data.uid + "recommendRoomNew", ToolUtils.toJsonString(i));
                sys.localStorage.removeItem(User.shared().data.uid + "addRecommendRoomNew");
                null != e && null != e && (this.rummyType == HowToPlayDefined.RUMMY_POINTS ? PushCenter.shared().pushEvent(GameConfig.Enter_Private_Room, { vid: e.vid, roomType: 1, privateRoomData: { roomid: 0, base_money: t, seat_max: this.selectPlayers } }) : this.rummyType == HowToPlayDefined.RUMMY_POOL ? PushCenter.shared().pushEvent(GameConfig.Enter_Private_Room, { vid: e.vid, roomType: 1, privateRoomData: { roomid: 0, base_money: t, seat_max: this.selectPlayers, disuse_score: this.selectPool } }) : PushCenter.shared().pushEvent(GameConfig.Enter_Private_Room, { vid: e.vid, roomType: 1, privateRoomData: { roomid: 0, base_money: t, seat_max: this.selectPlayers, rounds: this.selectDeals } }));
            }
        }
        else {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("kyc.kyc_privateroom"), 2);
        }
    }
    getSelectRoomList(e = this.selectPlayers, t = this.selectPool, i = this.selectDeals, s, a = this.selectMode) {
        let o = Utils.shared().getCurSelectRoomList(this.gameType, this.rummyType, e, t, i, a);
        if (o && o.length > 0) {
            this.vCurRoomList = o;
            let e = this.getRecommendRoomIndex(o, s);
            this.updateSliderProgress(e, false);
            this.setBetPoint();
        }
        return o;
    }
    getRecommendRoomIndex(e, t, i = -1) {
        let s = 0, a = 0;
        -1 == i && (this.bestIndex = 0, this.lastIndex = 0);
        let o = User.shared().data.money;
        if (3 == this.gameType && (o = User.shared().data.money_exe), 0 == i ? o = User.shared().data.money : 1 == i && (o = User.shared().data.money_exe), null != e && sys.isObjectValid(e.length) && e.length > 0) {
            let l;
            for (let h = e.length - 1; h >= 0; h--) {
                sys.isObjectValid(t) && (l = e[h].entry, l == t && (-1 == i ? 0 == this.lastIndex && (this.lastIndex = h + 1) : 0 == a && (a = h + 1)));
                e[h].min_money <= o && o < e[h].max_money && (-1 == i ? 0 == this.bestIndex && (this.bestIndex = h + 1) : 0 == s && (s = h + 1));
            }
            if (sys.isObjectValid(t)) {
                for (let h = e.length - 1; h >= 0; h--) {
                    if (l = e[h].entry, l == t && t <= o) {
                        let e = h + 1;
                        return 0 == this.lastIndex ? e = this.bestIndex : 0 != this.bestIndex && (e = this.lastIndex >= this.bestIndex ? this.lastIndex : this.bestIndex), -1 == i ? e : [e, s, a];
                    }
                }
            }
            for (let t = e.length - 1; t >= 0; t--) {
                if (e[t].min_money <= o && o < e[t].max_money) {
                    let e = t + 1;
                    return 0 == this.lastIndex ? e = this.bestIndex : 0 != this.bestIndex && (e = this.lastIndex >= this.bestIndex ? this.lastIndex : this.bestIndex), -1 == i ? e : [e, s, a];
                }
            }
        }
        return -1 == i ? 1 : [1, s, a];
    }
    getRecommendPracticeRoom() {
        let e = -1;
        if (null != this.vCurRoomList && sys.isObjectValid(this.vCurRoomList.length) && this.vCurRoomList.length > 0) {
            let t = User.shared().data.money_exe;
            for (let i = this.vCurRoomList.length - 1; i >= 0; i--) {
                this.vCurRoomList[i].min_money <= t && t < this.vCurRoomList[i].max_money && (e = i);
            }
        }
        return -1 != e ? this.vCurRoomList[e] : null;
    }
    setInitGameType(e = 0, t = 0, i = 0, s = 0, a = 0, o = false, l, h = 0) {
        t = 3 == t ? 8 : t;
        let n = [2, 6], r = [101, 201], m = [2, 3, 6], d = [PointsType.Classic];
        if (d = User.shared().getCurModeVec(e), 1 == e) {
            if (!User.shared().openGameTab || !User.shared().openGameTab[2]) {
                return e += 1, void this.setInitGameType(e, 0, 0, 0, 0, o, l);
            }
            this.updateGameType(e, o);
        }
        else {
            let c = Utils.shared().getCurRoomList(e, t);
            if (null == c || 0 == c.length) {
                let n = e, r = t;
                if (0 != e || 1 != User.shared().multiple_rummy_open && 1 != User.shared().multiple_2_open) {
                    if (t == HowToPlayDefined.RUMMY_DEALS) {
                        if (o) {
                            return false;
                        }
                        if (0 == e) {
                            n = e + 1;
                        }
                        else if (2 == e) {
                            return false;
                        }
                    }
                    else {
                        if (t == HowToPlayDefined.RUMMY_MULTIPLE) {
                            return false;
                        }
                        r = t + 1;
                    }
                }
                else if (t == HowToPlayDefined.RUMMY_MULTIPLE) {
                    if (o) {
                        return false;
                    }
                    if (0 == e) {
                        n = e + 1;
                    }
                    else if (2 == e) {
                        return false;
                    }
                }
                else {
                    r = t == HowToPlayDefined.RUMMY_DEALS ? HowToPlayDefined.RUMMY_MULTIPLE : t + 1;
                }
                return void this.setInitGameType(n, r, i, s, a, o, l, h);
            }
            {
                this.updateGameType(e, o);
                this.updateRummyType(t);
                let c = this.getSelectRoomList(n[i], r[s], m[a], l, d[h]);
                if (null == c || 0 == c.length) {
                    if (t == HowToPlayDefined.RUMMY_POINTS) {
                        if (1 == i && h >= d.length) {
                            return false;
                        }
                        h == d.length ? (i += 1, h = 0) : h += 1;
                    }
                    else if (t == HowToPlayDefined.RUMMY_POOL) {
                        if (1 == i && 1 == s) {
                            return false;
                        }
                        1 == s ? (i += 1, s = 0) : s += 1;
                    }
                    else {
                        if (t == HowToPlayDefined.RUMMY_MULTIPLE) {
                            return false;
                        }
                        if (1 == i && 2 == a) {
                            return false;
                        }
                        2 == a ? (i += 1, a = 0) : a += 1;
                    }
                    return this.setInitGameType(e, t, i, s, a, o, l, h), true;
                }
                {
                    let e = this.roomInfoNode.getChildByName("player_select"), t = this.roomInfoNode.getChildByName("mode_select"), o = this.roomInfoNode.getChildByName("pool_select"), l = this.roomInfoNode.getChildByName("deals_select");
                    this.rummyType == HowToPlayDefined.RUMMY_MULTIPLE ? this.updateBtnSwitchState(e, 1, 4, n[1]) : this.updateBtnSwitchState(e, i, 0, n[i]);
                    this.updateBtnSwitchState(t, d[h], 3, d[h]);
                    this.updateBtnSwitchState(o, s, 1, r[s]);
                    1 == i ? this.updateBtnSwitchState(l, a - 1, 2, m[a]) : this.updateBtnSwitchState(l, a, 2, m[a]);
                    this.updateDealsState();
                    this.updateSelectPlayer2();
                }
            }
        }
        return true;
    }
    enterRummy(e, t = 1, i, s, a = 0, o) {
        0 == this.gameType && (User.shared().first_click_play_time = Math.floor(sys.now() / 1000));
        ToolUtils.curRoomId = e;
        RobotAvatar.setRoomMode(e, 3 == this.gameType ? this.selectBotMode : 0);
        Utils.shared().showCommEnterRoom({ vid: e, game_type: t, tid: i, privateRoomData: s, is_back: a, raceid: o, isNewTable: 1, robot_view: 3 == this.gameType ? this.selectBotMode : 0 });
    }
    onBotModeClick(e, t) {
        SoundManager.shared().playFx("click");
        let i = Number(t);
        this.updateBtnSwitchState(this.roomInfoNode.getChildByName("bot_select"), i, 5, i);
    }
    onBackView() {
        // This is the lobby's root selection page, so Back must not close it.
    }
    onTouchStart(e) {
        this.stopStartBtnAnim();
    }
    onTouchEnd(e) {
        this.playStartBtnAnim();
    }
    playStartBtnAnim() {
        let e = this.roomInfoNode.getChildByName("btn_start");
        if (e) {
            e.scale = v3(1, 1, 1);
            let t = TweenTool.scaleTo(e, 0.1, v3(0.9, 0.9, 1), "sineInOut", false), i = TweenTool.scaleTo(e, 7 / 40, v3(1.05, 1.05, 1), "sineInOut", false), s = TweenTool.scaleTo(e, 7 / 40, v3(0.96, 0.96, 1), "sineInOut", false), a = TweenTool.scaleTo(e, 5 / 40, v3(1.02, 1.02, 1), "sineInOut", false), o = TweenTool.scaleTo(e, 5 / 40, v3(1, 1, 1), "sineInOut", false), l = TweenTool.delayAct(e, null, 80 / 30, false);
            this.startBtnAction = TweenTool.sequence(e, false, null, l, t, i, s, a, o);
            this.startBtnAction.repeatForever();
            this.startBtnAction.start();
        }
    }
    stopStartBtnAnim() {
        let e = this.roomInfoNode.getChildByName("btn_start");
        e && (e.scale = v3(1, 1, 1));
        this.startBtnAction && TweenTool.stopAction(this.startBtnAction);
    }
    refreshRankStar() {
        let e = false, t = 1;
        if (0 == this.gameType) {
            if (2 == User.shared().act_116_not_recommend_show) {
                if (this.vCurRoomList && this.vCurRoomList[this.nIdx]) {
                    let i = this.vCurRoomList[this.nIdx];
                    if (sys.isObjectValid(i) && i.vid) {
                        let s = i.vid;
                        sys.isObjectValid(User.shared().act_116_not_recommend_list) && Array.isArray(User.shared().act_116_not_recommend_list) && -1 === User.shared().act_116_not_recommend_list.indexOf(String(s)) && (e = true, t = 5);
                    }
                }
            }
            else {
                1 == User.shared().act_116_not_recommend_show ? (e = true, t = 5) : 0 == User.shared().act_116_not_recommend_show && (e = false, t = 1);
            }
        }
        1 == GameConfig.CHIPS_MODLE && 2000617 == GameConfig.CHANNEL_ID && 0 == GameConfig.GAME_HALL_THEME || (this.sliderStarNode.getParent().getComponent(Sprite).spriteFrame = e ? this.rankStarFrame[t] : this.rankStarFrame[0]);
    }
    chooseRoomByOutSide(e) {
        if (!sys.isObjectValid(e)) {
            return;
        }
        sys.isObjectValid(e.lobby) && (0 == e.lobby ? this.gameType = 0 : 1 == e.lobby ? this.gameType = 3 : 2 == e.lobby && (this.gameType = 2));
        sys.isObjectValid(e.game) && (this.rummyType = e.game);
        let t = 1;
        if (sys.isObjectValid(e.player) && 2 == e.player && (t = 0), this.setInitGameType(this.gameType, this.rummyType, t, 0, 0, false), 3 != this.gameType && sys.isObjectValid(this.vCurRoomList)) {
            let t = this.getRecommendRoomIndex(this.vCurRoomList), i = -1, s = 1;
            if (e.entry_range && Array.isArray(e.entry_range) && e.entry_range.length >= 2) {
                i = e.entry_range[0];
                let t = e.entry_range[1];
                if (null != this.vCurRoomList && sys.isObjectValid(this.vCurRoomList.length) && this.vCurRoomList.length > 0) {
                    for (let e = 0; e < this.vCurRoomList.length; e++) {
                        if (this.vCurRoomList[e].entry >= i && this.vCurRoomList[e].entry <= t) {
                            s = e + 1;
                            break;
                        }
                    }
                }
            }
            if (this.vCurRoomList.length >= this.bestIndex && 0 != this.bestIndex) {
                let i = this.vCurRoomList[t - 1];
                if (sys.isObjectValid(i) && sys.isObjectValid(i.entry)) {
                    let a = ToolUtils.isSafeNumber(i.entry);
                    e.entry_range && Array.isArray(e.entry_range) && 2 == e.entry_range.length && (a >= e.entry_range[0] && a <= e.entry_range[1] || (t = s));
                }
            }
            this.updateSliderProgress(t, false);
            this.setBetPoint();
        }
    }
    onFastKycClick(e, t) {
        SoundManager.shared().playFx("click");
        sys.now() - this._lastClick < 1000 || (this._lastClick = sys.now(), Utils.shared().showFastKyc());
    }
    onFreeChipsClick(e, t) {
        if (SoundManager.shared().playFx("click"), sys.isObjectValid(User.shared().exe_data) && sys.isObjectValid(User.shared().exe_data.can_receive) && 1 == Number(User.shared().exe_data.can_receive)) {
            if (sys.now() - this.request_click_time < 1000) {
                return;
            }
            this.request_click_time = sys.now();
            this.requestFreeChipsReward();
        }
    }
    requestFreeChipsReward() {
        HttpManager.shared().doGetCommonRequest(null, HttpRequest.ExerciseReceiveDailyReward, ((e, t, i) => {
            if (200 != i) {
                ;
            }
            else {
                try {
                    let e = ToolUtils.parseJson(t);
                    0 == e.ret ? (User.shared().exe_data = e.data, ToolUtils.isObjValid(this.node) && (this.showFreeChipsTime(), this.showFreeChipAnim(), this.checkFreeChipBtnVisible(), this.showChipsRewardTips())) : null != e.desc && null != e.desc && Utils.shared().showToast(e.desc, 2, 0, ToolUtils.getIsNormalDirection());
                }
                catch (e) {
                    TLog.printError("requestGameDisplayPage err:", e.toString());
                }
            }
        }));
    }
    requestFreeChipsConfig() {
        HttpManager.shared().doGetCommonRequest(null, HttpRequest.ExerciseGetHallPage, ((e, t, i) => {
            if (200 != i) {
                ;
            }
            else {
                try {
                    let e = ToolUtils.parseJson(t);
                    0 == e.ret ? (User.shared().exe_data = e.data, ToolUtils.isObjValid(this.node) && (this.showFreeChipsTime(), this.showFreeChipAnim(), this.checkFreeChipBtnVisible())) : null != e.desc && null != e.desc && Utils.shared().showToast(e.desc, 2, 0, ToolUtils.getIsNormalDirection());
                }
                catch (e) {
                    TLog.printError("requestGameDisplayPage err:", e.toString());
                }
            }
        }));
    }
    showChipsRewardTips() {
        if (sys.isObjectValid(User.shared().exe_data) && sys.isObjectValid(User.shared().exe_data.get_reward)) {
            let e = { list: [] }, t = [];
            t.num = ToolUtils.isSafeNumber(User.shared().exe_data.get_reward);
            t.type = 7;
            t.name = Utils.shared().getIconNameByType(7, "");
            e.list[0] = t;
            e.msg = i18nMgr.shared().getValueByKey("choose_game.chips_reward_tips");
            Utils.shared().showRewardTips(e, null, 1, "reward_tips.okey");
        }
    }
    setHandGuideAnim(e) {
        let t = this.roomInfoNode.getChildByName("btn_start"), i = this.roomInfoNode.getChildByName("btn_addcash"), s = t.getChildByName("anim_hand"), a = i.getChildByName("anim_hand");
        if (this.hand_guide.active = false, !e || !e.type) {
            return s && (s.active = false), void (a && (a.active = false));
        }
        (Number(e.type) || 0) > 0 && (s && (t.active ? s.active = true : s.active = false), a && (i.active ? a.active = true : a.active = false));
    }
    checkHandGuide(e, t) {
        let i = User.shared().data.uid + "handGuideShow", s = 0, a = t >= 0 ? t : this.rummyType, o = localStorage.getItem(i) || null;
        if (null != o && 0 == Number(o)) {
            return s = 0, void this.setHandGuideAnim({ type: s });
        }
        if (director.getScene().name === BundleNameDefined.hall_scene && 1 === User.shared().data.beginner_guide.practice_status && 1 === User.shared().points_classic_gesture) {
            if (0 === this.gameType && a === HowToPlayDefined.RUMMY_POINTS && 6 === this.selectPlayers && this.selectMode === PointsType.Classic && Array.isArray(this.vCurRoomList) && this.vCurRoomList.length) {
                var l;
                let e = User.shared().points_classic_base_money, t = (null == (l = this.vCurRoomList.find((t => t.point === e))) ? undefined : l.entry) || 0, a = this.vCurRoomList[this.nIdx] || null, o = User.shared().processFindBestRoom(0, HowToPlayDefined.RUMMY_POINTS, { tplayer: 6, finalMode: 1 });
                o && o.findIndex >= 0 && o.bestRoom && o.bestRoom.entry > t ? (s = 0, localStorage.setItem(i, "0")) : t && a && a.entry <= t && (s = 5);
            }
            this.setHandGuideAnim({ type: s });
        }
        else {
            this.setHandGuideAnim({ type: s });
        }
    }
}
