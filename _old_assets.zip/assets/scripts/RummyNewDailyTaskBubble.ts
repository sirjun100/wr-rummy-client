// @ts-nocheck
// Recovered from index.js:471
import { _decorator, Button, color, game, instantiate, Label, Node, RichText, ScrollView, Sprite, SpriteFrame, sys, UITransform, v3, Vec3 } from "cc";
import ReportConfig from "./ReportConfig";
import SoundManager from "./SoundManager";
import { TLog } from "./TLog";
import User from "./User";
import PushEvent from "./PushEvent";
import HttpManager from "./HttpManager";
import Utils from "./Utils";
import i18nMgr from "./i18nMgr";
import TweenTool from "./TweenTool";
import Parent, { AdapDirection } from "./Parent";
import TableViewUtils from "./TableViewUtils";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("RummyNewDailyTaskBubble")
export class RummyNewDailyTaskBubble extends Parent {
    @property(Node)
    public task_item: Node = null;
    @property(Node)
    public bubble0: Node = null;
    @property(Node)
    public bubble1: Node = null;
    @property([SpriteFrame])
    public smallBtnSprites: SpriteFrame[] = [];
    @property([SpriteFrame])
    public taskFlagSprites: SpriteFrame[] = [];
    @property(ScrollView)
    public taskScrollview: ScrollView = null;
    public sceneStr: any = ReportConfig.scece.Hall;
    public tid_key: string = "";
    public curTabIndex: number = 0;
    public taskData: any = null;
    public vid: number = 0;
    public funcId: any = ReportConfig.func.New_reward;
    public taskTabView: any = null;
    public bReShowList: boolean = false;
    public isRequest: boolean = false;
    public _bubble_type: number = 0;
    public _cur_bubble: any = null;
    public _initDelay: number = 0;
    public _listData: any = null;
    public _itemArr: any[] = [];
    onLoad() {
        ToolUtils.showFullScreen(this.node);
        ToolUtils.isPadPlatform() ? (this.resetUiPos(this.bubble0, AdapDirection.Up, true, 1, true, true), this.resetUiPos(this.bubble1, AdapDirection.Up, true, 1, true, true)) : (this.resetUiPos(this.bubble0, AdapDirection.Right, true, 1, true, true), this.resetUiPos(this.bubble1, AdapDirection.Right, true, 1, true, true));
    }
    start() {
        if (ToolUtils.showFullScreen(this.node.getChildByName("mask")), 0 == this._bubble_type) {
            if (this.bubble0.active = true, this.bubble1.active = false, this._cur_bubble = this.bubble0, this._cur_bubble.destroyAllChildren(), this.taskData) {
                let t = instantiate(this.task_item);
                t.getChildByName("img_nodes") && t.getChildByName("img_nodes").getChildByName("device_line") && (t.getChildByName("img_nodes").getChildByName("device_line").active = false);
                t.active = true;
                this._cur_bubble.addChild(t);
                t.setPosition(v3(-245, -14));
                this._listData = [this.taskData];
                this.initCurMobanCallBack(t, this.taskData, 0);
            }
        }
        else {
            this.bubble0.active = false;
            this.bubble1.active = true;
            this._cur_bubble = this.bubble1;
            let t = this.task_item.getComponent(UITransform).height;
            this.task_item.setPosition(new Vec3(0, this.task_item.position.y, this.task_item.position.z));
            this.taskTabView = this.node.addComponent(TableViewUtils);
            this.taskTabView.init([], this.taskScrollview.node, [this.task_item], this.initCurMobanCallBack.bind(this), 1, t, this.scrollRefreshCallBack.bind(this), true);
            this.refreshDailyTaskList();
        }
        User.shared().getRoomRoomInfo(this.vid, PushEvent.JUMP_TO_DAILYTASK);
        this._initDelay += 0.05;
        TweenTool.delayAct(this.node, (() => {
            TweenTool.commonSchedule(this.node, 1, this.scheduleCallBack.bind(this));
        }), this._initDelay, true);
        this.node.getChildByName("mask").active = true;
    }
    scheduleCallBack() {
        try {
            if (Array.isArray(this._listData) && this._listData.length > 0) {
                for (let t = 0, e = this._listData.length; t < e; t++) {
                    if (sys.isObjectValid(this._listData[t].leftTime) && this._listData[t].leftTime > 0 && (this._listData[t].leftTime -= 1, ToolUtils.isObjValid(this._itemArr[t]) && this._itemArr[t].active && this.taskTabView.getCellIndex(this._itemArr[t]) == t && this.initCurMobanCallBack(this._itemArr[t], this._listData[t], t), 0 == this._listData[t].leftTime)) {
                        if (0 != this._bubble_type) {
                            return void this.refreshDailyTaskList(true);
                        }
                        ToolUtils.isObjValid(this.node) && this.node.destroy();
                    }
                }
                1 == this._bubble_type && this.taskTabView && this.taskTabView.updateData(this._listData);
            }
        }
        catch (t) {
            TLog.printError("updateTaskLeftTime err:", t);
        }
    }
    initTask(t) {
        this.vid = t.vid;
        this._bubble_type = t.bubble_type;
        this.tid_key = t.tid_key;
        this.taskData = t.taskData;
    }
    startShowAnim(t, e) {
        t.setScale(v3(0, 0, 0));
        let i = TweenTool.delayAct(t, null, 0.1, false), s = TweenTool.scaleTo(t, 0.2, v3(1, 1, 1), "backOut", false, (() => {
            t.setScale(v3(1, 1, 1));
            e && e();
        }));
        TweenTool.sequence(t, true, null, i, s);
    }
    refreshDailyTaskList(t = false) {
        this.task_item && (this.task_item.active = false, t || sys.isObjectValid(User.shared().newDailyListData) && (this.bReShowList = true, this.updateTaskListContent(User.shared().newDailyListData.list)), HttpManager.shared().doGetNewDailyTaskList(((t, e, i) => {
            if (200 != i) {
                ;
            }
            else {
                let t = ToolUtils.parseJson(e);
                0 == t.ret && (User.shared().newDailyListData = t.data, ToolUtils.isObjValid(this.node) && sys.isObjectValid(t) && sys.isObjectValid(t.data) && this.updateTaskListContent(User.shared().newDailyListData.list));
            }
        }), this.vid));
    }
    updateTaskListContent(t) {
        let e = true;
        sys.isObjectValid(t) && Array.isArray(t) || (t = [], this.bReShowList = true, e = false);
        this._listData = t;
        this.taskTabView.reloadData(t, this.bReShowList);
        e && (this.bReShowList = false);
    }
    initCurMobanCallBack(t, e, i) {
        if (!ToolUtils.isObjValid(t) || !sys.isObjectValid(e)) {
            return;
        }
        t.active = true;
        let s = t.getChildByName("img_nodes"), a = t.getChildByName("label_nodes"), l = t.getChildByName("left_time"), n = l.getChildByName("layout").getChildByName("time_txt"), o = a.getChildByName("name"), r = a.getChildByName("test"), c = a.getChildByName("desc"), _ = t.getChildByName("task_btn"), C = _.getChildByName("btn_wz"), f = "", k = "", B = e.reward;
        if (e.leftTime > 0) {
            l.active = true;
            let t = Utils.shared().parseCountDown(e.leftTime);
            n.getComponent(Label).string = t;
        }
        else {
            l.active = false;
        }
        sys.isObjectValid(e.nametxt) ? (f = "<color=#FFFFFF>" + e.nametxt + "</color>", k = e.nametxt) : sys.isObjectValid(e.name) && (f = "<color=#FFFFFF>" + e.name + "</color>", k = e.name);
        sys.isObjectValid(e.progress) && ToolUtils.isSafeString(e.progress).length > 0 && (f += "<color=#539C49 > " + e.progress + " < /color>", k += " " + e.progress);
        o.getComponent(RichText).string = f;
        let w, D, v, S, V, R = "" + e.desc;
        c.getComponent(Label).string = R;
        r.active = true;
        r.getComponent(Label).string = k;
        r.getComponent(Label).updateRenderData(true);
        0 == R.length ? (c.setPosition(v3(-229, -5)), r.getComponent(UITransform).height > 40 ? o.setPosition(v3(-229, 43)) : o.setPosition(v3(-229, 30))) : r.getComponent(UITransform).height > 40 ? (o.setPosition(v3(-229, 53)), c.setPosition(v3(-229, -5))) : (o.setPosition(v3(-229, 43)), c.setPosition(v3(-229, 3)));
        r.active = false;
        1 == e.status ? (_.getChildByName("btn_di").getComponent(Sprite).spriteFrame = this.smallBtnSprites[1], C.getComponent(Label).string = i18nMgr.shared().getValueByKey("daily_tasks.collect"), C.getComponent(Label).color = color(255, 255, 255), _.getComponent(Button).interactable = true, _.getChildByName("btn_di").active = true) : 1 == e.end ? (_.getChildByName("btn_di").getComponent(Sprite).spriteFrame = this.smallBtnSprites[2], C.getComponent(Label).string = i18nMgr.shared().getValueByKey("daily_tasks.end"), C.getComponent(Label).color = color(153, 153, 153), _.getComponent(Button).interactable = false, _.getChildByName("btn_di").active = false) : 0 == e.valid ? (_.getChildByName("btn_di").getComponent(Sprite).spriteFrame = this.smallBtnSprites[2], C.getComponent(Label).string = i18nMgr.shared().getValueByKey("daily_tasks.upcoming"), C.getComponent(Label).color = color(153, 153, 153), _.getComponent(Button).interactable = false, _.getChildByName("btn_di").active = false) : 0 == e.status ? (_.getChildByName("btn_di").active = false, _.getChildByName("btn_di").getComponent(Sprite).spriteFrame = this.smallBtnSprites[2], C.getComponent(Label).string = i18nMgr.shared().getValueByKey("rummy_main.incomplete"), C.getComponent(Label).color = color(153, 153, 153), _.getComponent(Button).interactable = false, _.getChildByName("btn_di").active = false) : 2 == e.status && (_.getChildByName("btn_di").active = false, _.getChildByName("btn_di").getComponent(Sprite).spriteFrame = this.smallBtnSprites[2], C.getComponent(Label).string = i18nMgr.shared().getValueByKey("daily_tasks.collected"), C.getComponent(Label).color = color(153, 153, 153), _.getComponent(Button).interactable = false);
        let F = false;
        for (let t = 0; t < 3; t++) {
            w = "img" + t;
            D = s.getChildByName(w);
            w = "num" + t;
            v = a.getChildByName(w);
            F = false;
            B && "object" == typeof B && B[t] && (S = B[t].type, F = true, V = B[t].amt, 0 == this._bubble_type && (V = B[t].num), v.getComponent(Label).string = "x" + ToolUtils.parse_double("" + V, -1), D.getChildByName("ico").getComponent(Sprite).spriteFrame = this.taskFlagSprites[S], 2 == S ? D.getChildByName("ico").setScale(v3(0.22, 0.22, 0.22)) : D.getChildByName("ico").setScale(v3(0.7, 0.7, 0.7)));
            D.active = F;
            v.active = F;
        }
        this._itemArr[i] = t;
    }
    scrollRefreshCallBack() {
    }
    mobanCallBack(t, e) {
        SoundManager.shared().playFx("click");
        let i = Number(e), s = User.shared().newDailyListData.list[i], a = s.task_id, l = (s.ename, ToolUtils.isSafeNumber(s.status));
        if (0 == l) {
            if (1 === ToolUtils.isInGameScene) {
                return;
            }
        }
        else if (1 == l) {
            if (this.isRequest) {
                return;
            }
            this.isRequest = true;
            Utils.shared().showLoading(10, false);
            this.requestDailyTaskReward(a);
            TweenTool.delayAct(this.node, (() => {
                ToolUtils.isObjValid(this.node) && this.isRequest && (this.isRequest = false);
            }), 5, true);
        }
    }
    requestDailyTaskReward(t) {
        HttpManager.shared().doGetNewDailyTaskReward(t, ((t, e, i) => {
            Utils.shared().hideLoading();
            sys.isObjectValid(this.node) && (this.isRequest = false);
            try {
                if (200 != i) {
                    alert("The login timed out, please try again");
                }
                else {
                    let t = ToolUtils.parseJson(e);
                    0 == t.ret ? (sys.isObjectValid(t.data.money) && User.shared().updateMoney(t.data.money), sys.isObjectValid(t.data.bonus) && User.shared().updateBonus(t.data.bonus), sys.isObjectValid(t.data.myActive) && (User.shared().newDailydata.myActive = Number(t.data.myActive)), User.shared().newDailyListData = t.data.page, sys.isObjectValid(this.node) && (this.updateTaskListContent(User.shared().newDailyListData.list), User.shared().getRoomRoomInfo(this.vid, PushEvent.JUMP_TO_DAILYTASK), t.data.reward && t.data.reward.length > 0 && TweenTool.delayAct(this.node, (() => {
                        this.Poprewards(t.data.reward);
                    }), game.frameTime / 1000 * 2, true))) : ToolUtils.isSafeString(t.desc).length > 0 && Utils.shared().showToast(ToolUtils.isSafeString(t.desc), 3, 0, ToolUtils.getIsNormalDirection());
                }
            }
            catch (t) {
                TLog.printError("listenTaskRewardCallback:", t);
            }
        }));
    }
    Poprewards(t) {
        let e = t;
        e && e.length && e.length;
        e && e.length > 0 && User.shared().showChargeReward(e);
    }
    onButtonClick(t, e) {
        SoundManager.shared().playFx("click");
        "close" === e && ToolUtils.isObjValid(this.node) && this.node.destroy();
    }
}
