// @ts-nocheck
// Recovered from index.js:49
import { _decorator, Button, color, director, Label, Node, size, Sprite, SpriteFrame, UITransform, v3, Vec3 } from "cc";
import SoundManager from "./SoundManager";
import Utils from "./Utils";
import User from "./User";
import PushCenter from "./PushCenter";
import TableViewUtils from "./TableViewUtils";
import HttpManager from "./HttpManager";
import i18nMgr from "./i18nMgr";
import BaseLayer from "./BaseLayer";
import BundleNameDefined from "./BundleNameDefined";
import TweenTool from "./TweenTool";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("BuddyRoomRank")
export default class BuddyRoomRank extends BaseLayer {
    @property(Node)
    public bg: Node = null;
    @property(Node)
    public curWeekSelect: Node = null;
    @property(Node)
    public lastWeekSelect: Node = null;
    @property(Node)
    public rankList: Node = null;
    @property(Node)
    public itemMoban: Node = null;
    @property(Node)
    public myRankNode: Node = null;
    @property(Node)
    public nodata: Node = null;
    @property([SpriteFrame])
    public rankTop3Frames: SpriteFrame[] = [];
    public _curSelect: number = 1;
    public rankListTabView: any = null;
    public my_week_cash_pos: Vec3 = new Vec3;
    public my_week_games_pos: Vec3 = new Vec3;
    public cur_page: number = 1;
    public tab_bRequest: any[] = [true, true];
    public listData: any[] = [];
    public bReShowList: boolean = false;
    onLoad() {
        this.fitScreen();
        let t = [this.itemMoban];
        this.rankListTabView = this.node.addComponent(TableViewUtils);
        let e = this.itemMoban.getComponent(UITransform).height;
        this.rankListTabView.init([], this.rankList, t, this.initRoomItem.bind(this), 0, e, this.scrollRefreshCallBack.bind(this));
        this.myRankNode.getChildByName("cash_label").getPosition(this.my_week_cash_pos);
        this.myRankNode.getChildByName("games_label").getPosition(this.my_week_games_pos);
        this.tab_bRequest = [true, true];
        this._curSelect = 1;
        this.updateSelectBtnState();
        director.getScene().name === BundleNameDefined.rummy_scence && (this.node.getChildByName("bg_block").getComponent(Button).interactable = true);
    }
    start() {
        super.start();
        this.myRankNode.getChildByName("name_label").getComponent(Label).string = ToolUtils.GetShortName2(User.shared().data.name, 10, true);
        this.startShowAnim(this.bg, (() => {
            this.bReShowList = true;
            this.doRequestRankInfo();
        }));
        let t = new Vec3;
        this.bg.getPosition(t);
        TweenTool.moveSpriteByFade(this.bg, 0.2, t, 0, 1, true);
        this.dealMultipleLanguages();
    }
    dealMultipleLanguages() {
        2 == i18nMgr.shared().language && (this.lastWeekSelect.getChildByName("Label").getComponent(Label).fontSize = 24, this.bg.getChildByName("list_title").getChildByName("tx_cash_point").getComponent(Label).fontSize = 16, this.bg.getChildByName("list_title").getChildByName("tx_game_point").getComponent(Label).fontSize = 16, this.bg.getChildByName("list_title").getChildByName("tx_total_point").getComponent(Label).fontSize = 16, this.bg.getChildByName("list_title").getChildByName("tx_cash_point").getComponent(Label).lineHeight = 20, this.bg.getChildByName("list_title").getChildByName("tx_total_point").getComponent(Label).lineHeight = 20);
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().removeListenersByTag(this);
        this.unscheduleAllCallbacks();
    }
    fitScreen() {
        if (ToolUtils.showFullScreen(this.node.getChildByName("bg_block")), director.getScene().name === BundleNameDefined.rummy_scence) {
            let t = this.bg.getComponent(UITransform).contentSize, e = t.height - 604;
            this.bg.getComponent(UITransform).contentSize = size(t.width, 604);
            let i = new Vec3;
            this.bg.getPosition(i);
            this.bg.setPosition(v3(i.x, i.y + 40, i.z));
            this.bg.getChildByName("top").getPosition(i);
            this.bg.getChildByName("top").setPosition(v3(i.x, i.y - e / 2, i.z));
            this.bg.getChildByName("list_title").getPosition(i);
            this.bg.getChildByName("list_title").setPosition(v3(i.x, i.y - e / 2, i.z));
            let a = this.rankList.getComponent(UITransform).contentSize;
            this.rankList.getComponent(UITransform).contentSize = size(a.width, a.height - e);
            this.myRankNode.getPosition(i);
            this.myRankNode.setPosition(i.x, i.y + e / 2);
        }
    }
    updateSubItemPos(t, e, i, a) {
    }
    cleanMyRankInfo() {
        let t = this.myRankNode.getChildByName("cash_label"), e = t.getChildByName("cash_point_label");
        t.setPosition(this.my_week_cash_pos);
        t.getComponent(Label).string = "--";
        e.getComponent(Label).string = "";
        this.updateSubItemPos(t, "--", e, "--");
        let i = this.myRankNode.getChildByName("games_label"), a = i.getChildByName("games_point_label");
        i.setPosition(this.my_week_games_pos);
        i.getComponent(Label).string = "--";
        a.getComponent(Label).string = "(--)";
        this.updateSubItemPos(i, "--", a, "--");
        this.myRankNode.getChildByName("rank_label").getComponent(Label).string = "--";
        this.myRankNode.getChildByName("total_label").getComponent(Label).string = "--";
    }
    updateMyRankInfo(t) {
        let e = ToolUtils.parse_double(t.cnt, 0), i = ToolUtils.parse_double(t.cntpoint, 0), a = ToolUtils.parse_double(t.reward), n = this.myRankNode.getChildByName("cash_label"), s = n.getChildByName("cash_point_label");
        n.setPosition(this.my_week_cash_pos);
        let l = ToolUtils.parse_double(t.bmoney);
        n.getComponent(Label).string = String(l);
        let o = ToolUtils.format("(${0})", a);
        s.getComponent(Label).string = o;
        this.updateSubItemPos(n, String(l), s, String(a));
        let h = this.myRankNode.getChildByName("games_label"), r = h.getChildByName("games_point_label");
        h.setPosition(this.my_week_games_pos);
        h.getComponent(Label).string = String(e);
        o = ToolUtils.format("(${0})", i);
        r.getComponent(Label).string = o;
        this.updateSubItemPos(h, String(e), r, String(i));
        this.myRankNode.getChildByName("rank_label").getComponent(Label).string = String(t.rank);
        this.myRankNode.getChildByName("total_label").getComponent(Label).string = ToolUtils.parse_double(t.score);
        this.myRankNode.getChildByName("name_label").getComponent(Label).string = ToolUtils.GetShortName2(String(t.name), 10, true);
    }
    updateSelectBtnState() {
        let t = this.curWeekSelect, e = this.lastWeekSelect;
        1 == this._curSelect && (t = this.lastWeekSelect, e = this.curWeekSelect);
        t.getChildByName("wz").getComponent(Label).color = color(84, 89, 155);
        t.getChildByName("di").active = true;
        let i = t.getChildByName("line");
        i.active && (TweenTool.stopNodeAction(i), TweenTool.scaleTo(i, 0.1, v3(0.2, 1, 1), null, true, (() => {
            i.scale = v3(1, 1, 1);
            i.active = false;
        })));
        e.getChildByName("wz").getComponent(Label).color = color(183, 0, 0);
        e.getChildByName("di").active = false;
        let a = e.getChildByName("line");
        a.active = true;
        TweenTool.stopNodeAction(a);
        a.scale = v3(0, 1, 1);
        let n = TweenTool.scaleTo(a, 0.16, v3(1.1, 1, 1), null, false), s = TweenTool.scaleTo(a, 0.16, v3(1, 1, 1), null, false);
        TweenTool.sequence(a, true, null, n, s);
    }
    updateRankList(t) {
        let e = true;
        null != t && null != t || (t = [], this.bReShowList = true, e = false);
        this.listData = [];
        for (let e = 0, i = t.length; e < i; e++) {
            this.listData.push(t[e]);
            t[e].uid == User.shared().data.uid && this.updateMyRankInfo(t[e]);
        }
        this.nodata.active = 0 == this.listData.length;
        this.rankListTabView.reloadData(this.listData, this.bReShowList);
        e && (this.bReShowList = false);
    }
    listenWeekRankCallBack(t, e, i) {
        if (Utils.shared().hideLoading(), ToolUtils.isObjValid(this.node)) {
            if (200 != i) {
                Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text29"), 2);
            }
            else {
                let t = ToolUtils.parseJson(e);
                t && (0 === t.ret && t.data && t.data.list ? (User.shared().data.lastMatchRankInfo[0] = t.data.list, 1 == this._curSelect && this.updateRankList(t.data.list)) : 1 == this._curSelect && this.updateRankList([]));
            }
        }
    }
    listenMonthRankCallBack(t, e, i) {
        if (Utils.shared().hideLoading(), ToolUtils.isObjValid(this.node)) {
            if (200 != i) {
                Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text29"), 2);
            }
            else {
                let t = ToolUtils.parseJson(e);
                t && (0 === t.ret && t.data && t.data.list ? (User.shared().data.lastMatchRankInfo[1] = t.data.list, 2 == this._curSelect && this.updateRankList(t.data.list)) : 2 == this._curSelect && this.updateRankList([]));
            }
        }
    }
    doRequestRankInfo() {
        null != User.shared().data.lastMatchRankInfo && null != User.shared().data.lastMatchRankInfo || (User.shared().data.lastMatchRankInfo = []);
        null == User.shared().data.lastMatchRankInfo[this._curSelect - 1] || null == User.shared().data.lastMatchRankInfo[this._curSelect - 1] || this.tab_bRequest[this._curSelect - 1] ? (this.tab_bRequest[this._curSelect - 1] = false, null != User.shared().data.lastMatchRankInfo[this._curSelect - 1] && null != User.shared().data.lastMatchRankInfo[this._curSelect - 1] || Utils.shared().showLoading(10), null == User.shared().data.lastMatchRankInfo[this._curSelect - 1] || null == User.shared().data.lastMatchRankInfo[this._curSelect - 1] ? (this.listData = [], this.rankListTabView.reloadData(this.listData, true)) : this.updateRankList(User.shared().data.lastMatchRankInfo[this._curSelect - 1]), 1 == this._curSelect ? HttpManager.shared().doGetRummyMonthMatchRank(0, this.listenWeekRankCallBack.bind(this)) : HttpManager.shared().doGetRummyMonthMatchRank(1, this.listenMonthRankCallBack.bind(this))) : this.updateRankList(User.shared().data.lastMatchRankInfo[this._curSelect - 1]);
    }
    initRoomItem(t, e) {
        t.active = true;
        let i = t.getChildByName("rank_label"), a = t.getChildByName("rank_sp"), n = Number(e.rank);
        n <= 3 ? (a.getComponent(Sprite).spriteFrame = this.rankTop3Frames[n - 1], a.active = true, i.active = false) : (a.active = false, i.getComponent(Label).string = String(n), i.active = true);
        let s = String(e.name), l = String(e.score), o = ToolUtils.parse_double(e.cnt, 0), h = ToolUtils.parse_double(e.cntpoint, 0), r = ToolUtils.parse_double(e.reward);
        t.getChildByName("name_label").getComponent(Label).string = ToolUtils.GetShortName2(ToolUtils.isSafeString(s), 10, true);
        let d = t.getChildByName("cash_label"), g = d.getChildByName("cash_point_label"), u = ToolUtils.parse_double(e.bmoney);
        d.getComponent(Label).string = String(u);
        let m = ToolUtils.format("(${0})", r);
        g.getComponent(Label).string = "";
        this.updateSubItemPos(d, String(u), g, String(r));
        let b = t.getChildByName("games_label"), y = b.getChildByName("games_point_label");
        b.getComponent(Label).string = String(o);
        m = ToolUtils.format("(${0})", h);
        y.getComponent(Label).string = m;
        this.updateSubItemPos(b, String(o), y, String(h));
        t.getChildByName("total_label").getComponent(Label).string = ToolUtils.parse_double(l);
    }
    scrollRefreshCallBack() {
    }
    onclickByClose(t, e) {
        SoundManager.shared().playFx("click");
        ToolUtils.isObjValid(this.node) && this.node.destroy();
    }
    onclickByMaskBg(t, e) {
        ToolUtils.isObjValid(this.node) && this.node.destroy();
    }
    onClickSelectBtn(t, e) {
        "curweek" == e ? 1 != this._curSelect && (SoundManager.shared().playFx("click"), this._curSelect = 1, this.updateSelectBtnState(), this.rankListTabView.clearAllItem(), this.bReShowList = true, this.cleanMyRankInfo(), this.cur_page = 1, this.doRequestRankInfo()) : "lastweek" == e && 2 != this._curSelect && (SoundManager.shared().playFx("click"), this._curSelect = 2, this.updateSelectBtnState(), this.rankListTabView.clearAllItem(), this.bReShowList = true, this.cleanMyRankInfo(), this.cur_page = 1, this.doRequestRankInfo());
    }
}
