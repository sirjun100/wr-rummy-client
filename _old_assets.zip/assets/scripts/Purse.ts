// @ts-nocheck
// Recovered from index.js:355
import { _decorator, Component, Button, color, director, EditBox, instantiate, Label, Node, Prefab, size, Sprite, SpriteFrame, sys, UITransform, v3, view } from "cc";
import PushCenter from "./PushCenter";
import { TLog } from "./TLog";
import Utils from "./Utils";
import GameConfig from "./GameConfig";
import User from "./User";
import SoundManager from "./SoundManager";
import HttpManager from "./HttpManager";
import { walletPayDetails } from "./walletPayDetails";
import TweenTool from "./TweenTool";
import { TransferPlatform } from "./TransferPlatform";
import PushEvent from "./PushEvent";
import i18nMgr from "./i18nMgr";
import ReportConfig from "./ReportConfig";
import { ToolUtils } from "./ToolUtils";
import PhpReportDefined from "./PhpReportDefined";
const { ccclass, property } = _decorator;
@ccclass("Purse")
export class Purse extends Component {
    @property(Label)
    public totalBalanceLabel: Label = null;
    @property(Label)
    public deposited_text: Label = null;
    @property(Label)
    public winnings_text: Label = null;
    @property(Label)
    public bonus_text: Label = null;
    @property(Node)
    public topInfoNode: Node = null;
    @property(Node)
    public cntNode: Node = null;
    @property(Node)
    public sexNode: Node = null;
    @property(Node)
    public birthNode: Node = null;
    @property([SpriteFrame])
    public clubStarFrame: SpriteFrame[] = [];
    @property([SpriteFrame])
    public sexKuangFrame: SpriteFrame[] = [];
    @property([SpriteFrame])
    public btnFrame: SpriteFrame[] = [];
    @property(EditBox)
    public otpField: EditBox = null;
    @property([Label])
    public otp_Label: Label[] = [];
    @property(Prefab)
    public walletPayPre: Prefab = null;
    @property(Prefab)
    public cashHelp: Prefab = null;
    public lastid: number = 0;
    public isRequest: boolean = false;
    public _closed: boolean = false;
    public sdate: string = "";
    public edate: string = "";
    public _unBindType: any = -1;
    public bindType: any = -1;
    public selectSex: any = -1;
    public _keyboardHei: number = 780;
    onLoad() {
        this.deposited_text.string = "";
        this.winnings_text.string = "";
        this.totalBalanceLabel.string = "";
        this.fitScreen();
    }
    start() {
        this.addNotify();
        this.isRequest = false;
        this.refreshUI();
    }
    refreshUI() {
        this.refreshInfoView();
        sys.isObjectValid(User.shared().club_data) || User.shared().doMemberShipData();
        this.refreshTel_no();
        this.refreshEmailState();
        this.refreshMemberShipInfo();
        this.refreshGenderInfo();
        this.refreshBirthInfo();
        this.refreshTgRobotState();
    }
    refreshTgRobotState() {
        sys.isObjectValid(User.shared().data.tg_name) && User.shared().data.tg_name.length > 0 ? (i18nMgr.shared().changeLabelFont(this.cntNode.getChildByName("birth_desc").getComponent(Label), true), this.cntNode.getChildByName("tg_desc").getComponent(Label).string = User.shared().data.tg_name, this.cntNode.getChildByName("tg_desc").getComponent(Label).color = color(51, 51, 51), this.cntNode.getChildByName("tg_verified").active = true, this.cntNode.getChildByName("tg_desc").getComponent(Label).fontSize = 56, this.cntNode.getChildByName("tg_desc").getComponent(Label).isBold = true, this.cntNode.getChildByName("btn_tg").getChildByName("wz").getComponent(Label).string = "OPEN") : (this.cntNode.getChildByName("tg_desc").getComponent(Label).string = "Not added", i18nMgr.shared().changeLabelFont(this.cntNode.getChildByName("tg_desc").getComponent(Label), false), this.cntNode.getChildByName("tg_verified").active = false, this.cntNode.getChildByName("tg_desc").getComponent(Label).fontSize = 48, this.cntNode.getChildByName("btn_tg").getChildByName("wz").getComponent(Label).string = "ADD", this.cntNode.getChildByName("tg_desc").getComponent(Label).isBold = false);
    }
    refreshBirthInfo() {
        const birthday = User.shared().data.birthday;
        const hasBirthday = sys.isObjectValid(birthday) && birthday.length > 0;
        const label = this.cntNode.getChildByName("birth_desc").getComponent(Label);
        label.string = hasBirthday ? birthday : "Not added";
        label.color = color(51, 51, 51);
        i18nMgr.shared().changeLabelFont(label, hasBirthday);
        const button = this.cntNode.getChildByName("btn_birth");
        button.active = true;
        button.getChildByName("wz").getComponent(Label).string = hasBirthday ? "EDIT" : "ADD";
        this.cntNode.getChildByName("ico_birth_gou").active = false;
    }
    refreshGenderInfo() {
        1 == User.shared().data.sex ? this.cntNode.getChildByName("sex_desc").getComponent(Label).string = "Male" : 2 == User.shared().data.sex ? this.cntNode.getChildByName("sex_desc").getComponent(Label).string = "Female" : this.cntNode.getChildByName("sex_desc").getComponent(Label).string = "Other";
    }
    refreshEmailState() {
        User.shared().data.email && "" != User.shared().data.email ? (this.cntNode.getChildByName("email").active = true, this.cntNode.getChildByName("email").getComponent(Label).string = User.shared().data.email, this.cntNode.getChildByName("email_notadd").active = false, this.cntNode.getChildByName("email_verified").active = true, this.cntNode.getChildByName("btn_email").getChildByName("wz").getComponent(Label).string = "CHANGE", this.cntNode.getChildByName("btn_email").active = true) : (this.cntNode.getChildByName("email_notadd").active = true, this.cntNode.getChildByName("email").active = false, this.cntNode.getChildByName("email_verified").active = false, this.cntNode.getChildByName("btn_email").getChildByName("wz").getComponent(Label).string = "ADD", this.cntNode.getChildByName("btn_email").active = true);
    }
    refreshMemberShipInfo() {
        let e = User.shared().data.player_club, t = User.shared().getGradeByMemberShipLevel(Number(e.club_level));
        this.topInfoNode.getChildByName("btn_clubInfo").getChildByName("icon").getComponent(Sprite).spriteFrame = this.clubStarFrame[t];
        this.cntNode.getChildByName("club_bg").getChildByName("ico").getComponent(Sprite).spriteFrame = this.clubStarFrame[t];
        sys.isObjectValid(e.club_score) && sys.isObjectValid(e.next_club_score) && (this.cntNode.getChildByName("club_bg").getChildByName("desc").getComponent(Label).string = `Next level:${Math.floor(e.club_score)}/${e.next_club_score}`);
    }
    refreshTel_no() {
        User.shared().data.tel_no && "" !== User.shared().data.tel_no ? (this.cntNode.getChildByName("mobile").active = true, this.cntNode.getChildByName("btn_tel").getChildByName("wz").getComponent(Label).string = "CHANGE", this.cntNode.getChildByName("mobile_notadd").getComponent(Label).string = User.shared().data.tel_no, this.cntNode.getChildByName("mobile_notadd").getComponent(Label).isBold = true, this.cntNode.getChildByName("mobile_notadd").getComponent(Label).color = color(51, 51, 51, 255), this.cntNode.getChildByName("mobile_verified").active = true) : (this.cntNode.getChildByName("mobile_notadd").getComponent(Label).string = "Not added", this.cntNode.getChildByName("mobile_notadd").getComponent(Label).color = color(153, 153, 153, 255), this.cntNode.getChildByName("btn_tel").getChildByName("wz").getComponent(Label).string = "ADD", this.cntNode.getChildByName("mobile_notadd").getComponent(Label).isBold = false, this.cntNode.getChildByName("mobile_verified").active = false);
    }
    refreshInfoView() {
        this.topInfoNode.getChildByName("name").getComponent(Label).string = User.shared().data.name + "";
        User.shared().data.avatar && User.shared().data.avatar.length > 0 && Utils.shared().updateHeadImg(this.topInfoNode.getChildByName("head_mask").getChildByName("head_img"), User.shared().data.avatar, User.shared().data.avatar_url, size(120, 120));
        this.topInfoNode.getChildByName("id").getComponent(Label).string = "ID: " + User.shared().data.uid;
    }
    onEnable() {
        TransferPlatform.shared().setNormalFrameRate();
        this.totalBalanceLabel.string = "₹" + ToolUtils.parse_double(User.shared().data.money, 2, true);
        this.totalBalanceLabel.updateRenderData(true);
        this.deposited_text.string = "₹" + ToolUtils.parse_double(User.shared().data.deposit, 2, true);
        this.deposited_text.updateRenderData(true);
        this.winnings_text.string = "₹" + ToolUtils.parse_double(User.shared().data.withdraw, 2, true);
        this.winnings_text.updateRenderData(true);
        this.bonus_text.string = ToolUtils.parse_double(User.shared().data.bonus, 2, true);
        this.bonus_text.updateRenderData(true);
    }
    addNotify() {
        PushCenter.shared().addListener(GameConfig.Update_Money, (e => {
            ToolUtils.isObjValid(this.node) && (this.totalBalanceLabel.string = "₹" + ToolUtils.parse_double(User.shared().data.money, 2, true));
        }), this);
        PushCenter.shared().addListener(GameConfig.Update_Deposit, (e => {
            ToolUtils.isObjValid(this.node) && (this.deposited_text.string = "₹" + ToolUtils.parse_double(User.shared().data.deposit, 2, true));
        }), this);
        PushCenter.shared().addListener(GameConfig.Update_Bonus, (e => {
            ToolUtils.isObjValid(this.node) && (this.bonus_text.string = ToolUtils.parse_double(String(e), 2, true));
        }), this);
        PushCenter.shared().addListener(GameConfig.Update_withdraw, (e => {
            ToolUtils.isObjValid(this.node) && (this.winnings_text.string = "₹" + ToolUtils.parse_double(User.shared().data.withdraw, 2, true));
        }), this);
        PushCenter.shared().addListener(PushEvent.showWalletHistoryView, (e => {
            ToolUtils.isObjValid(this.node) && Utils.shared().showWalletDetailstView(e, this.node);
        }), this);
        PushCenter.shared().addListener(PushEvent.showWalletPayDetailsView, (e => {
            ToolUtils.isObjValid(this.node) && this.showWalletPayDetails(e);
        }), this);
        PushCenter.shared().addListener(GameConfig.Update_Name, (e => {
            ToolUtils.isObjValid(this.node) && this.refreshInfoView();
        }), this);
        PushCenter.shared().addListener(GameConfig.Change_Head, (e => {
            ToolUtils.isObjValid(this.node) && this.refreshInfoView();
        }), this);
        PushCenter.shared().addListener(GameConfig.MobileBlind_State, (e => {
            ToolUtils.isObjValid(this.node) && this.refreshTel_no();
        }), this);
        PushCenter.shared().addListener(GameConfig.EmailBlind_State, (e => {
            ToolUtils.isObjValid(this.node) && this.refreshEmailState();
        }), this);
        PushCenter.shared().addListener(PushEvent.changeWebViewHeight, (e => {
            ToolUtils.isObjValid(this.node);
        }), this);
        PushCenter.shared().addListener(PushEvent.Telegram_Robot_Update, (e => {
            ToolUtils.isObjValid(this.node) && this.refreshTgRobotState();
        }), this);
        PushCenter.shared().addListener(GameConfig.onEnterForeground, (e => {
            ToolUtils.isObjValid(this.node) && this.dealRefreshTg();
        }), this);
        PushCenter.shared().addListener(PushEvent.OTP_Verify_Succ, (e => {
            ToolUtils.isObjValid(this.node) && (0 == this.bindType ? PushCenter.shared().pushEvent(PushEvent.ShowChangeBindMobile, { nType: 1 }) : PushCenter.shared().pushEvent(PushEvent.ShowChangeBindMobile, { nType: 4 }));
        }), this);
    }
    onDestroy() {
        PushCenter.shared().removeListenersByTag(this);
        this.unscheduleAllCallbacks();
    }
    checkWithrawPopKyc() {
        return false;
    }
    checkOtpInputLogic(e) {
        let t = e.length;
        for (let i = 0; i < this.otp_Label.length; i++) {
            i < t ? this.updateBirthStatus(i, e.charAt(i)) : this.updateBirthStatus(i, "");
        }
    }
    onOtpTextBegan(e, t, i) {
        this.showScrollivewUp(this.otpField.node);
    }
    onOtpTextChanged(e, t, i) {
        "input_otp_all" != i || this.checkOtpInputLogic(e);
    }
    updateBirBtnStatus(e) {
        this.birthNode.getChildByName("root").getChildByName("save_btn").getComponent(Sprite).spriteFrame = this.btnFrame[e];
        this.birthNode.getChildByName("root").getChildByName("save_btn").getComponent(Button).interactable = 1 == e;
    }
    checkAndSendOtpReq() {
        let e = this.otpField.string;
        if (e.length < 8) {
            return void (this.birthNode.getChildByName("root").getChildByName("tip").active = true);
        }
        let t = e.substring(0, 2);
        if (Number(t) < 1 || Number(t) > 31) {
            return void (this.birthNode.getChildByName("root").getChildByName("tip").active = true);
        }
        let i = e.substring(2, 4);
        if (Number(i) < 1 || Number(i) > 12) {
            return void (this.birthNode.getChildByName("root").getChildByName("tip").active = true);
        }
        let a = e.substring(4, 8), s = new Date;
        Number(a) < 1900 || Number(a) > Number(s.getFullYear()) ? this.birthNode.getChildByName("root").getChildByName("tip").active = true : (this.birthNode.getChildByName("root").getChildByName("tip").active = false, this.updateBirBtnStatus(1));
    }
    onOtpTextEnded(e, t) {
        this.checkAndSendOtpReq();
        this.restoreScrollviewTop();
    }
    button_click(e, t) {
        if (SoundManager.shared().playFx("click"), "add_cash" === t) {
            Utils.shared().showStoreView();
            User.shared().updatePayScene(PhpReportDefined.pay_scene.hall_shop);
        }
        else if ("withdraw" === t) {
            Utils.shared().doJumpLogic(PushEvent.JUMP_TO_WITHDRAWAL);
        }
        else if ("edit_user" == t) {
            Utils.shared().doJumpLogic(PushEvent.JUMP_TO_USERINFO);
        }
        else if ("more_record" === t) {
            if (this.isRequest) {
                return;
            }
            HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Wallet, event: ReportConfig.hall_evt.click_cash_detail });
            Utils.shared().showWalletDetailstView(User.shared().walletData_history, this.node);
        }
        else if ("help" == t) {
            Utils.shared().showWalletHelpView();
        }
        else if ("kefu" == t) {
            Utils.shared().showContactUsView();
        }
        else if ("close" == t) {
            if (this._closed) {
                return;
            }
            this.onBackView();
        }
        else if ("head" == t) {
            let e = director.getScene().getChildByName("Canvas");
            Utils.shared().showHallGameDisPlay({ parent_node: e });
        }
        else if ("bonus" == t) {
            if (this.isRequest) {
                return;
            }
            HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Wallet, event: ReportConfig.hall_evt.click_bonus_detail });
        }
        else if ("tel" == t) {
            if (User.shared().data.tel_no && "" !== User.shared().data.tel_no) {
                if (10 != User.shared().data.tel_no.length) {
                    return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("bind_mobile.invalid_mobile_number"), 2);
                }
                this.bindType = 0;
                User.shared().data.email && "" != User.shared().data.email && -1 != User.shared().data.email.search("@") ? PushCenter.shared().pushEvent(PushEvent.ShowChangeBindMobile, { nType: 6 }) : PushCenter.shared().pushEvent(PushEvent.ShowChangeBindMobile, { nType: 5 });
            }
            else {
                PushCenter.shared().pushEvent(PushEvent.ShowChangeBindMobile, { nType: 0 });
            }
        }
        else if ("email" == t) {
            if (User.shared().data.email && "" != User.shared().data.email) {
                if (-1 == User.shared().data.email.search("@")) {
                    return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("bind_mobile.invalid_email"), 2);
                }
                this.bindType = 1;
                User.shared().data.tel_no && "" !== User.shared().data.tel_no && 10 == User.shared().data.tel_no.length ? PushCenter.shared().pushEvent(PushEvent.ShowChangeBindMobile, { nType: 5 }) : PushCenter.shared().pushEvent(PushEvent.ShowChangeBindMobile, { nType: 6 });
            }
            else {
                PushCenter.shared().pushEvent(PushEvent.ShowChangeBindMobile, { nType: 2 });
            }
        }
        else {
            "club" == t ? Utils.shared().doJumpLogic(PushEvent.JUMP_TO_CLUB) : "sex" == t ? (this.sexNode.active = true, this.selectSex = User.shared().data.sex, this.updateSexTabView(), ToolUtils.showFullScreen(this.node.getChildByName("mask")), this.node.getChildByName("mask").active = true, this.startShowAnim(this.sexNode.getChildByName("root"), -515)) : "close_sex" == t ? (this.node.getChildByName("mask").active = false, this.sexNode.active = false) : "birthday" == t ? (this.resetBirthView(), ToolUtils.showFullScreen(this.node.getChildByName("mask")), this.node.getChildByName("mask").active = true, this.startShowAnim(this.birthNode.getChildByName("root"), -515), this.birthNode.active = true) : "close_birth" == t ? (this.node.getChildByName("mask").active = false, this.birthNode.active = false) : "sex0" == t ? (this.selectSex = 1, this.updateSexTabView()) : "sex1" == t ? (this.selectSex = 2, this.updateSexTabView()) : "sex2" == t ? (this.selectSex = 3, this.updateSexTabView()) : "save_sex" == t ? (User.shared().data.sex = this.selectSex, this.node.getChildByName("mask").active = false, this.sexNode.active = false, this.refreshGenderInfo(), this.reportSexChange(this.selectSex)) : "save_birth" == t ? this.dealSaveBirthLogic() : "copy_uid" == t ? (TransferPlatform.shared().copyContent(User.shared().data.uid), Utils.shared().showToast("Copy successful", 2)) : "tg" == t && sys.isObjectValid(User.shared().data.tg_auth_url) && User.shared().data.tg_auth_url.length > 0 && (1 === TransferPlatform.shared().checkPackageInstalled("org.telegram.messenger") ? TransferPlatform.shared().openApplicationChat("org.telegram.messenger", User.shared().data.tg_auth_url) : 1 === TransferPlatform.shared().checkPackageInstalled("org.telegram.messenger.web") ? TransferPlatform.shared().openApplicationChat("org.telegram.messenger.web", User.shared().data.tg_auth_url) : Utils.shared().showToast("Please install the Telegram app first.", 2));
        }
    }
    dealRefreshTg() {
        HttpManager.shared().doGetCommonRequest({}, "Player.UserInfo.getTg", ((e, t, i) => {
            if (Utils.shared().hideLoading(), 200 != i) {
                Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.request_fail"), 2);
                ToolUtils.isObjValid(this.node);
            }
            else {
                try {
                    let e = ToolUtils.parseJson(t);
                    0 == e.ret && sys.isObjectValid(e.data.tg_name) && (sys.isObjectValid(e.data.tg_name) && (User.shared().data.tg_name = e.data.tg_name), sys.isObjectValid(e.data.tg_auth_url) && e.data.tg_auth_url.length > 0 && (User.shared().data.tg_auth_url = e.data.tg_auth_url), this.refreshTgRobotState());
                }
                catch (e) {
                    TLog.printError("dealRefreshTg err:", e.toString());
                }
            }
        }));
    }
    dealSaveBirthLogic() {
        Utils.shared().showLoading(10, false, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3);
        }));
        let e = this.otpField.string, t = e.substring(0, 2) + "/" + e.substring(2, 4) + "/" + e.substring(4, 8);
        HttpManager.shared().doGetCommonRequest({ birthday: t }, "Player.UserInfo.setBirthday", ((e, t, i) => {
            if (Utils.shared().hideLoading(), 200 != i) {
                Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.request_fail"), 2);
                ToolUtils.isObjValid(this.node);
            }
            else {
                try {
                    let e = ToolUtils.parseJson(t);
                    0 == e.ret && sys.isObjectValid(e.data.birthday) && (User.shared().data.birthday = e.data.birthday, this.refreshBirthInfo(), this.node.getChildByName("mask").active = false, this.birthNode.active = false);
                    if (e.ret != 0) {
                        Utils.shared().showToast(e.desc || "Unable to save date of birth. Please try again.", 3);
                    }
                }
                catch (e) {
                    TLog.printError("reportSexChange err:", e.toString());
                }
            }
        }));
    }
    resetBirthView() {
        let e = ["d", "d", "m", "m", "y", "y", "y", "y"];
        for (let t = 0; t <= 7; t++) {
            this.otp_Label[t].getComponent(Label).string = e[t];
            this.otp_Label[t].getComponent(Label).color = color(153, 153, 153);
        }
        const birthday = User.shared().data.birthday;
        this.otpField.string = typeof birthday === "string" ? birthday.replace(/\//g, "") : "";
        this.checkOtpInputLogic(this.otpField.string);
        this.birthNode.getChildByName("root").getChildByName("tip").active = false;
        this.updateBirBtnStatus(this.otpField.string.length === 8 ? 1 : 0);
    }
    updateBirthStatus(e, t) {
        let i = ["d", "d", "m", "m", "y", "y", "y", "y"];
        if (e >= 0 && e <= 7) {
            this.birthNode.getChildByName("root").getChildByName("otp_input_bg" + e);
            0 == t.length || t == i[e] ? (this.otp_Label[e].getComponent(Label).string = i[e], this.otp_Label[e].getComponent(Label).color = color(153, 153, 153)) : (this.otp_Label[e].getComponent(Label).string = t, this.otp_Label[e].getComponent(Label).color = color(51, 51, 51));
        }
    }
    startShowAnim(e, t) {
        this.node.getChildByName("bg").getComponent(UITransform).contentSize;
        let i = v3(0, 0);
        e.setPosition(v3(0, t, 0));
        TweenTool.moveTo(e, 0.15, i, "fade", true, (() => {
            e.setPosition(i);
        }));
    }
    reportSexChange(e) {
        HttpManager.shared().doGetCommonRequest({ sex: e }, "Player.UserInfo.setSex", ((e, t, i) => {
            if (Utils.shared().hideLoading(), 200 != i) {
                Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.request_fail"), 2);
                ToolUtils.isObjValid(this.node);
            }
            else {
                try {
                    ToolUtils.parseJson(t).ret;
                }
                catch (e) {
                    TLog.printError("reportSexChange err:", e.toString());
                }
            }
        }));
    }
    updateSexTabView() {
        this.sexNode.getChildByName("root").getChildByName("male_btn").getChildByName("kuang").getComponent(Sprite).spriteFrame = 1 == this.selectSex ? this.sexKuangFrame[1] : this.sexKuangFrame[0];
        this.sexNode.getChildByName("root").getChildByName("female_btn").getChildByName("kuang").getComponent(Sprite).spriteFrame = 2 == this.selectSex ? this.sexKuangFrame[1] : this.sexKuangFrame[0];
        this.sexNode.getChildByName("root").getChildByName("other_btn").getChildByName("kuang").getComponent(Sprite).spriteFrame = 3 == this.selectSex ? this.sexKuangFrame[1] : this.sexKuangFrame[0];
        i18nMgr.shared().changeLabelFont(this.sexNode.getChildByName("root").getChildByName("male_btn").getChildByName("desc").getComponent(Label), 1 == this.selectSex);
        i18nMgr.shared().changeLabelFont(this.sexNode.getChildByName("root").getChildByName("female_btn").getChildByName("desc").getComponent(Label), 2 == this.selectSex);
        i18nMgr.shared().changeLabelFont(this.sexNode.getChildByName("root").getChildByName("other_btn").getChildByName("desc").getComponent(Label), 3 == this.selectSex);
    }
    onBackView(e = true) {
        e && (Utils.shared().hideLoading(), this._closed = true, ToolUtils.showPushAnim(this.node, 1, (() => {
            ToolUtils.isObjValid(this.node) && this.node.destroy();
        })));
    }
    listenWalletHistoryCallback(e, t, i) {
        if (ToolUtils.isObjValid(this.node) && (this.isRequest = false), 0 != t.length) {
            if (200 != i) {
                Utils.shared().hideLoading();
                alert("The login timed out, please try again");
            }
            else {
                let e = ToolUtils.parseJson(t);
                0 == e.ret && ToolUtils.isObjValid(this.node) && (User.shared().walletData_history = e, Utils.shared().showWalletDetailstView(e, this.node));
            }
        }
        else {
            Utils.shared().hideLoading();
        }
    }
    listenBounsCallback(e, t, i) {
        if (ToolUtils.isObjValid(this.node) && (this.isRequest = false), 0 != t.length) {
            if (200 != i) {
                Utils.shared().hideLoading();
                alert("The login timed out, please try again");
            }
            else {
                let e = ToolUtils.parseJson(t);
                0 == e.ret && (User.shared().walletData_bonus = e, Utils.shared().showWalletDetailstView(e, this.node, 1));
            }
        }
        else {
            Utils.shared().hideLoading();
        }
    }
    requestWallet() {
        let e = new Date, t = 0, i = 0, a = 0;
        t = e.getFullYear();
        i = e.getMonth() + 1;
        a = e.getDate();
        let s = t.toString() + String("0" + i).slice(-2) + String("0" + a).slice(-2);
        this.edate = s;
        let d = e.getTime();
        d -= 518400000;
        e.setTime(d);
        t = e.getFullYear();
        i = e.getMonth() + 1;
        a = e.getDate();
        let h = t.toString() + String("0" + i).slice(-2) + String("0" + a).slice(-2);
        this.sdate = h;
    }
    mobanCallBack(e, t) {
        if (this.isRequest) {
            return;
        }
        SoundManager.shared().playFx("click");
        let i = User.shared().walletDetailsData.get(String(t.id));
        if (sys.isObjectValid(i) && i.language == i18nMgr.shared().language) {
            let e = User.shared().walletDetailsData.get(String(t.id));
            this.showWalletPayDetails(e);
        }
        else {
            this.isRequest = true;
            Utils.shared().showLoading(10, false, (() => {
                Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3);
            }));
            HttpManager.shared().doReportWalletGetOne(t.id, this.listenWalletPayCallback.bind(this));
            TweenTool.delayAct(this.node, (() => {
                ToolUtils.isObjValid(this.node) && this.isRequest && (this.isRequest = false);
            }), 15, true);
        }
    }
    listenWalletPayCallback(e, t, i) {
        if (Utils.shared().hideLoading(), ToolUtils.isObjValid(this.node) && (this.isRequest = false), 0 != t.length) {
            if (200 != i) {
                alert("The login timed out, please try again");
            }
            else {
                let e = ToolUtils.parseJson(t);
                0 == e.ret && (e.language = i18nMgr.shared().language, User.shared().walletDetailsData.set(String(e.data.id), e), ToolUtils.isObjValid(this.node) && this.showWalletPayDetails(e));
            }
        }
    }
    showWalletPayDetails(e) {
        let t = director.getScene().getChildByName("Canvas"), i = t.getChildByName("walletPayDetails");
        if (!ToolUtils.isObjValid(i)) {
            let i = instantiate(this.walletPayPre);
            i.name = "walletPayDetails";
            t.addChild(i);
            i.getComponent(walletPayDetails).init(e, (() => {
                ToolUtils.isObjValid(this.node) && (this.node.active = true);
            }));
        }
    }
    fitScreen() {
        let e = ToolUtils.getSafeDistance();
        ToolUtils.adaptSafeArea(this.node.getChildByName("bgView"));
        view.getVisibleSize();
        ToolUtils.isPadPlatform() && (e = 0);
    }
    showScrollivewUp(e) {
        if (ToolUtils.getIsInRoom()) {
            return;
        }
        if (sys.isBrowser) {
            return;
        }
        let t = v3(0, 0);
        this.birthNode.getChildByName("root").inverseTransformPoint(t, e.getWorldPosition());
        ToolUtils.getIsInRoom();
        let i = t.y + 34 - 80;
        i < this._keyboardHei ? this.birthNode.getChildByName("root").setPosition(v3(0, this._keyboardHei - i)) : this.birthNode.getChildByName("root").setPosition(v3(0, 0));
    }
    restoreScrollviewTop() {
        this.birthNode.getChildByName("root").setPosition(v3(0, 0));
    }
}
