// @ts-nocheck
// Recovered from index.js:215
import { _decorator, Button, instantiate, Label, LabelShadow, Node, size, sp, Sprite, SpriteFrame, sys, UITransform, v3, Widget } from "cc";
import BaseLayer from "./BaseLayer";
import SoundManager from "./SoundManager";
import PushCenter from "./PushCenter";
import GameConfig from "./GameConfig";
import { TLog } from "./TLog";
import Utils from "./Utils";
import User from "./User";
import HttpManager from "./HttpManager";
import PushEvent from "./PushEvent";
import i18nMgr from "./i18nMgr";
import CommDefine from "./CommDefine";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("KycMainNew")
export class KycMainNew extends BaseLayer {
    @property(Node)
    public rootNode: Node = null;
    @property(Node)
    public verifyNode: Node = null;
    @property(sp.Skeleton)
    public kyc_logo_anim: any = null;
    @property(Node)
    public updateNode: Node = null;
    @property(Node)
    public reward_moban: Node = null;
    @property(Node)
    public tipsNode: Node = null;
    @property([SpriteFrame])
    public reward_sprites: SpriteFrame[] = [];
    @property([SpriteFrame])
    public btnSprites: SpriteFrame[] = [];
    public bShowPushAnim: boolean = false;
    public _closed: boolean = false;
    public _btnPos: any[] = [v3(255, -2), v3(255, -18)];
    public _updateSize: any = size(720, 100);
    init(e) {
        this.bShowPushAnim = e;
    }
    onLoad() {
        if (ToolUtils.isSafeString(User.shared().kyc_bottom_tip).length > 0) {
            this.tipsNode.getComponent(Label).string = User.shared().kyc_bottom_tip;
        }
        else {
            let e = i18nMgr.shared().getValueByKey("kyc.kyc_18tips");
            this.tipsNode.getComponent(Label).string = e;
        }
    }
    start() {
        super.start();
        this.initView();
        this.bShowPushAnim && ToolUtils.showPushAnim(this.node);
        PushCenter.shared().addListener(GameConfig.MobileBlind_State, (e => {
            ToolUtils.isObjValid(this.node) && HttpManager.shared().doGetKycVerifyList2(this.listenGetKycVerifyListCallback.bind(this));
        }), this);
        PushCenter.shared().addListener(PushEvent.Update_Pan, (() => {
            ToolUtils.isObjValid(this.node) && this.updatePanView();
        }), this);
        PushCenter.shared().addListener(GameConfig.Update_Kyc, (() => {
            2 != User.shared().data.card_check && 1 != User.shared().data.card_check || User.shared().doGetKycAccount();
            ToolUtils.isObjValid(this.node) && this.initVerifyView();
        }), this);
        PushCenter.shared().addListener(PushEvent.RefreshKycList, (() => {
            ToolUtils.isObjValid(this.node) && this.initVerifyView();
        }), this);
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().removeListenersByTag(this);
        this.unscheduleAllCallbacks();
    }
    onCloseButtonClick(e, t) {
        if (SoundManager.shared().playFx("click"), "back_btn" == t) {
            if (this._closed) {
                return;
            }
            this.onBackView();
        }
    }
    initView() {
        this.fitScreen();
        this.verifyNode.active = true;
        this.rootNode.getChildByName("panel_center").getChildByName("tips").active = true;
        this.verifyNode.getChildByName("list").getChildByName("moblie_verify").active = false;
        this.verifyNode.getChildByName("list").getChildByName("pan_verify").active = false;
        this.verifyNode.getChildByName("list").getChildByName("identity_verify").active = false;
        i18nMgr.shared().changeLabelLanguage(this.rootNode.getChildByName("top_node").getChildByName("title").getComponent(Label), "kyc.kyc_verification", true);
        User.shared().data.kyc_list && User.shared().data.kyc_list.length > 0 && this.initVerifyView();
        HttpManager.shared().doGetKycVerifyList2(this.listenGetKycVerifyListCallback.bind(this));
        HttpManager.shared().doGetKycAccount2(this.listenGetKycAccountCallback.bind(this));
        this.dealMultipleLanguages();
    }
    dealMultipleLanguages() {
        2 == i18nMgr.shared().language && (this.rootNode.getChildByName("panel_center").getChildByName("tips").getComponent(Widget).bottom = 50);
    }
    listenGetKycVerifyListCallback(e, t, a) {
        try {
            if (200 != a) {
                alert("The login timed out, please try again");
            }
            else {
                let e = ToolUtils.parseJson(t);
                0 == e.ret && (User.shared().data.kyc_check = e.data.kyc_check, User.shared().data.kyc_imgPath = e.data.kyc_img_url, User.shared().data.card_check = e.data.card_check, User.shared().data.card_check_type = e.data.card_check_type, User.shared().data.kyc_update_status = e.data.kyc_update_status, User.shared().data.kyc_list = e.data.list, User.shared().data.show_resubmit = e.data.show_resubmit, User.shared().data.resubmit_tips = e.data.resubmit_tips, User.shared().data.resubmit_status = e.data.resubmit_status, ToolUtils.isObjValid(this.node) && this.initVerifyView());
            }
        }
        catch (e) {
            TLog.printError("listenGetKycVerifyListCallback:", e);
        }
    }
    listenGetKycAccountCallback(e, t, a) {
        try {
            if (200 != a) {
                alert("The login timed out, please try again");
            }
            else {
                let e = ToolUtils.parseJson(t);
                0 == e.ret && (User.shared().newKycData = e.data);
            }
        }
        catch (e) {
            TLog.printError("listenGetKycAccountCallback:", e);
        }
    }
    initVerifyView() {
        if (sys.isObjectValid(User.shared().data.show_resubmit) && 1 == User.shared().data.show_resubmit ? (this.updateNode.active = true, sys.isObjectValid(User.shared().data.resubmit_tips) && (this.updateNode.getChildByName("tx").getComponent(Label).string = User.shared().data.resubmit_tips, this.updateNode.getChildByName("tx").getComponent(Label).updateRenderData(true), this.updateNode.getChildByName("tx").getComponent(UITransform).contentSize.height > 70 && (this.updateNode.getComponent(UITransform).setContentSize(size(this._updateSize.width, this._updateSize.height + 30)), this.verifyNode.getChildByName("list").setPosition(v3(0, -30))), sys.isObjectValid(User.shared().data.resubmit_status) ? (0 == User.shared().data.resubmit_status || 3 == User.shared().data.resubmit_status ? (this.updateNode.getChildByName("btn").getComponent(Sprite).spriteFrame = this.btnSprites[2], i18nMgr.shared().changeLocalizedLabelKey(this.updateNode.getChildByName("btn").getChildByName("wz"), "kyc.update"), this.updateNode.getChildByName("btn").getComponent(Button).interactable = true, this.updateNode.getChildByName("btn").getChildByName("wz").getComponent(LabelShadow).color = CommDefine.shadowcolor.red, Utils.updateLabelMaterial(this.updateNode.getChildByName("btn").getChildByName("wz"), CommDefine.gradient.btn_red)) : (this.updateNode.getChildByName("btn").getComponent(Sprite).spriteFrame = this.btnSprites[3], i18nMgr.shared().changeLocalizedLabelKey(this.updateNode.getChildByName("btn").getChildByName("wz"), "kyc.verity_pending"), this.updateNode.getChildByName("btn").getComponent(Button).interactable = false, this.updateNode.getChildByName("btn").getChildByName("wz").getComponent(LabelShadow).color = CommDefine.shadowcolor.gray, Utils.updateLabelMaterial(this.updateNode.getChildByName("btn").getChildByName("wz"), CommDefine.gradient.btn_gray)), this.updateNode.getChildByName("btn").active = true) : this.updateNode.getChildByName("btn").active = false), User.shared().doGetKycResubmitInfo()) : (this.updateNode.active = false, this.verifyNode.getChildByName("list").setPosition(v3(0, 0))), User.shared().data.kyc_list && User.shared().data.kyc_list.length > 0) {
            let e = -70;
            for (let t = 0; t < User.shared().data.kyc_list.length; t++) {
                let a = User.shared().data.kyc_list[t];
                if (1 == ToolUtils.isSafeNumber(a.type)) {
                    let t = this.verifyNode.getChildByName("list").getChildByName("moblie_verify");
                    t.active = true;
                    t.setPosition(v3(0, e));
                    this.updateMobileView(a);
                    e -= 120;
                }
                if (2 == ToolUtils.isSafeNumber(a.type)) {
                    let t = this.verifyNode.getChildByName("list").getChildByName("identity_verify");
                    t.active = true;
                    t.setPosition(v3(0, e));
                    this.updateCardCheckView(a);
                    e -= 120;
                }
                if (3 == ToolUtils.isSafeNumber(a.type)) {
                    let t = this.verifyNode.getChildByName("list").getChildByName("pan_verify");
                    t.active = true;
                    t.setPosition(v3(0, e));
                    this.updatePanView(a);
                    e -= 120;
                }
            }
        }
    }
    showReward(e, t, a) {
        if (ToolUtils.isSafeNumber(t.bonus) > 0 && ToolUtils.isSafeNumber(t.cash) > 0) {
            let a = instantiate(this.reward_moban);
            a.getChildByName("ico").getComponent(Sprite).spriteFrame = this.reward_sprites[0];
            a.getChildByName("num").getComponent(Label).string = "x" + t.cash;
            a.active = true;
            e.addChild(a);
            a = instantiate(this.reward_moban);
            a.getChildByName("ico").getComponent(Sprite).spriteFrame = this.reward_sprites[1];
            a.getChildByName("num").getComponent(Label).string = "x" + t.bonus;
            a.active = true;
            e.addChild(a);
            e.active = true;
        }
        else if (ToolUtils.isSafeNumber(t.bonus) > 0) {
            let a = instantiate(this.reward_moban);
            a.getChildByName("ico").getComponent(Sprite).spriteFrame = this.reward_sprites[1];
            a.getChildByName("num").getComponent(Label).string = "x" + t.bonus;
            a.active = true;
            e.addChild(a);
            e.active = true;
        }
        else if (ToolUtils.isSafeNumber(t.cash) > 0) {
            let a = instantiate(this.reward_moban);
            a.getChildByName("ico").getComponent(Sprite).spriteFrame = this.reward_sprites[0];
            a.getChildByName("num").getComponent(Label).string = "x" + t.cash;
            a.active = true;
            e.addChild(a);
            e.active = true;
        }
        else {
            e.active = false;
        }
        e.active ? a.setPosition(this._btnPos[1]) : a.setPosition(this._btnPos[0]);
    }
    updateMobileView(e = null) {
        let t = this.verifyNode.getChildByName("list").getChildByName("moblie_verify"), a = t.getChildByName("tel"), i = t.getChildByName("tips"), s = t.getChildByName("btn"), r = t.getChildByName("reward"), n = User.shared().data.tel_no;
        n && n.length > 0 ? (a.active = true, a.getComponent(Label).string = "+91 " + n, i.active = false, r.removeAllChildren(), r.active = false, s.getComponent(Sprite).spriteFrame = this.btnSprites[1], i18nMgr.shared().changeLabelLanguage(s.getChildByName("wz").getComponent(Label), "kyc.update", true), s.getChildByName("wz").getComponent(LabelShadow).color = CommDefine.shadowcolor.blue, Utils.updateLabelMaterial(s.getChildByName("wz"), CommDefine.gradient.btn_blue)) : (a.active = false, i.active = true, s.getComponent(Sprite).spriteFrame = this.btnSprites[0], i18nMgr.shared().changeLabelLanguage(s.getChildByName("wz").getComponent(Label), "kyc.verify", true), s.getChildByName("wz").getComponent(LabelShadow).color = CommDefine.shadowcolor.green, Utils.updateLabelMaterial(s.getChildByName("wz"), CommDefine.gradient.btn_green));
        sys.isObjectValid(e) ? (r.removeAllChildren(), this.showReward(r, e, s)) : s.setPosition(this._btnPos[0]);
    }
    updatePanView(e = null) {
        let t = this.verifyNode.getChildByName("list").getChildByName("pan_verify"), a = t.getChildByName("btn"), i = a.getChildByName("wz").getComponent(Label), s = t.getChildByName("reward");
        0 == User.shared().pan_check ? (a.getComponent(Sprite).spriteFrame = this.btnSprites[0], i18nMgr.shared().changeLabelLanguage(i, "kyc.verify", true), a.getChildByName("wz").getComponent(LabelShadow).color = CommDefine.shadowcolor.green, Utils.updateLabelMaterial(a.getChildByName("wz"), CommDefine.gradient.btn_green)) : 1 == User.shared().pan_check ? (a.getComponent(Sprite).spriteFrame = this.btnSprites[3], i18nMgr.shared().changeLabelLanguage(i, "kyc.verity_pending", true), a.getChildByName("wz").getComponent(LabelShadow).color = CommDefine.shadowcolor.gray, Utils.updateLabelMaterial(a.getChildByName("wz"), CommDefine.gradient.btn_gray)) : 2 == User.shared().pan_check ? (a.getComponent(Sprite).spriteFrame = this.btnSprites[1], i18nMgr.shared().changeLabelLanguage(i, "kyc.details", true), a.getChildByName("wz").getComponent(LabelShadow).color = CommDefine.shadowcolor.blue, Utils.updateLabelMaterial(a.getChildByName("wz"), CommDefine.gradient.btn_blue), s.removeAllChildren(), s.active = false, a.setPosition(this._btnPos[0])) : 3 == User.shared().pan_check && (a.getComponent(Sprite).spriteFrame = this.btnSprites[2], i18nMgr.shared().changeLabelLanguage(i, "kyc.resubmit", true), a.getChildByName("wz").getComponent(LabelShadow).color = CommDefine.shadowcolor.red, Utils.updateLabelMaterial(a.getChildByName("wz"), CommDefine.gradient.btn_red));
        a.getComponent(Button).interactable = 1 != User.shared().pan_check;
        2 !== Number(User.shared().pan_check) && sys.isObjectValid(e) ? (s.removeAllChildren(), this.showReward(s, e, a)) : s.active || a.setPosition(this._btnPos[0]);
    }
    updateCardCheckView(e) {
        let t = this.verifyNode.getChildByName("list").getChildByName("identity_verify"), a = t.getChildByName("btn"), i = a.getChildByName("wz").getComponent(Label), s = t.getChildByName("reward");
        0 == User.shared().data.card_check ? (a.getComponent(Sprite).spriteFrame = this.btnSprites[0], i18nMgr.shared().changeLabelLanguage(i, "kyc.verify", true), a.getChildByName("wz").getComponent(LabelShadow).color = CommDefine.shadowcolor.green, Utils.updateLabelMaterial(a.getChildByName("wz"), CommDefine.gradient.btn_green)) : 1 == User.shared().data.card_check ? (a.getComponent(Button).interactable = false, a.getComponent(Sprite).spriteFrame = this.btnSprites[3], i18nMgr.shared().changeLabelLanguage(i, "kyc.verity_pending", true), a.getChildByName("wz").getComponent(LabelShadow).color = CommDefine.shadowcolor.gray, Utils.updateLabelMaterial(a.getChildByName("wz"), CommDefine.gradient.btn_gray)) : 2 == User.shared().data.card_check ? (i18nMgr.shared().changeLabelLanguage(i, "kyc.details", true), 1 == User.shared().data.card_check_type ? (a.getComponent(Button).interactable = false, a.getComponent(Sprite).spriteFrame = this.btnSprites[3], a.getChildByName("wz").getComponent(LabelShadow).color = CommDefine.shadowcolor.gray, Utils.updateLabelMaterial(a.getChildByName("wz"), CommDefine.gradient.btn_gray)) : (a.getComponent(Button).interactable = true, a.getComponent(Sprite).spriteFrame = this.btnSprites[1], a.getChildByName("wz").getComponent(LabelShadow).color = CommDefine.shadowcolor.blue, Utils.updateLabelMaterial(a.getChildByName("wz"), CommDefine.gradient.btn_blue)), s.removeAllChildren(), s.active = false, a.setPosition(this._btnPos[0])) : 3 == User.shared().data.card_check && (i18nMgr.shared().changeLabelLanguage(i, "kyc.resubmit", true), 1 == User.shared().data.card_check_type ? (a.getComponent(Button).interactable = false, a.getComponent(Sprite).spriteFrame = this.btnSprites[3], a.getChildByName("wz").getComponent(LabelShadow).color = CommDefine.shadowcolor.gray, Utils.updateLabelMaterial(a.getChildByName("wz"), CommDefine.gradient.btn_gray)) : (a.getComponent(Sprite).spriteFrame = this.btnSprites[2], a.getComponent(Button).interactable = true, a.getChildByName("wz").getComponent(LabelShadow).color = CommDefine.shadowcolor.red, Utils.updateLabelMaterial(a.getChildByName("wz"), CommDefine.gradient.btn_red)));
        2 !== Number(User.shared().data.card_check) && sys.isObjectValid(e) ? (s.removeAllChildren(), this.showReward(s, e, a)) : a.setPosition(this._btnPos[0]);
    }
    onVerifyButtonClick(e, t) {
        if (SoundManager.shared().playFx("click"), "verifyMobile" == t) {
            User.shared().data.tel_no && User.shared().data.tel_no.length > 0 ? HttpManager.shared().doChangePhoneRequist(this.listenChangeMobileCall.bind(this)) : PushCenter.shared().pushEvent(PushEvent.ShowChangeBindMobile, { lastNode: this.node, nType: 0, bShowPushAnim: true });
        }
        else if ("verifyCard" == t) {
            if (2 == User.shared().data.card_check) {
                return void User.shared().data.card_check_type;
            }
            User.shared().data.card_check;
            sys.isObjectValid(User.shared().newKycData.form_list) && User.shared().newKycData.form_list.length > 0 ? this.dealVerifyType() : (Utils.shared().showLoading(10, true, (() => {
                Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3);
            })), HttpManager.shared().doGetKycAccount2(((e, t, a) => {
                if (Utils.shared().hideLoading(), 200 == a) {
                    try {
                        let e = ToolUtils.parseJson(t);
                        0 == e.ret && (User.shared().newKycData = e.data, ToolUtils.isObjValid(this.node) && this.dealVerifyType());
                    }
                    catch (e) {
                        TLog.printError("listenGetKycAccountCallback:", e);
                    }
                }
            })));
        }
    }
    dealVerifyType() {
        if (sys.isObjectValid(User.shared().newKycData.form_list) && User.shared().newKycData.form_list.length > 0) {
            if (User.shared().newKycData.form_list.length > 1) {
                Utils.shared().showVerifySelestView(true, this.node);
            }
            else {
                Number(User.shared().newKycData.form_list[0].type);
            }
        }
        else {
            Utils.shared().showToast("Coming soon", 2);
            TLog.printError("dealVerifyType error no form_list");
        }
    }
    listenChangeMobileCall(e, t, a) {
        if (0 != t.length) {
            if (200 != a) {
                alert("The login timed out, please try again");
            }
            else {
                let e = ToolUtils.parseJson(t);
                501 == e.ret ? PushCenter.shared().pushEvent(PushEvent.ShowSafetyVerify, { lastNode: this.node, jump_info: { type: PushEvent.JUMP_TO_MOBILE, exe: { lastNode: this.node, nType: 1, bShowPushAnim: true } } }) : 502 == e.ret ? PushCenter.shared().pushEvent(PushEvent.ShowChangeBindMobile, { lastNode: this.node, nType: 1, bShowPushAnim: true }) : (e.ret, e.desc && e.desc.length > 0 && Utils.shared().showToast(e.desc, 3));
            }
        }
    }
    onButtonClick(e, t) {
        if ("male" != t && "female" != t && SoundManager.shared().playFx("click"), "kefu" == t) {
            if (1 == User.shared().temp_pingbi.feedback) {
                return void Utils.shared().showToast("Coming soon", 2);
            }
            Utils.shared().doJumpLogic(PushEvent.JUMP_TO_FEEDBACK);
        }
    }
    onBackView(e = true) {
        ToolUtils.isObjValid(this.node) && e && (this.bShowPushAnim ? (this._closed = true, ToolUtils.showPushAnim(this.node, 1, (() => {
            ToolUtils.isObjValid(this.node) && this.node.destroy();
        }))) : ToolUtils.isObjValid(this.node) && this.node.destroy());
    }
    fitScreen() {
        ToolUtils.adaptSafeArea(this.rootNode);
        let e = sys.getSafeAreaRect().y;
        this.rootNode.getChildByName("panel_center").getChildByName("tips").getComponent(Widget).bottom = 20 - e;
        2 == i18nMgr.shared().language && (this.rootNode.getChildByName("panel_center").getChildByName("tips").getComponent(Widget).bottom = 30 - e);
    }
}
