// @ts-nocheck
// Recovered from index.js:659
import { _decorator, assetManager, Canvas, Color, director, error, game, Game, input, Input, instantiate, isValid, KeyCode, Label, Material, native, Node, Prefab, RenderTexture, resources, size, sp, Sprite, SpriteFrame, sys, tween, UITransform, v3, view } from "cc";
import BundleNameDefined from "./BundleNameDefined";
import GameConfig from "./GameConfig";
import NetConfig from "./NetConfig";
import PushEvent from "./PushEvent";
import { BroadCast } from "./BroadCast";
import WebViewNode from "./WebViewNode";
import HttpManager from "./HttpManager";
import SoundManager from "./SoundManager";
import MD5 from "./MD5";
import PushCenter from "./PushCenter";
import { TLog } from "./TLog";
import TweenTool from "./TweenTool";
import i18nMgr from "./i18nMgr";
import CommDefine, { CheckModule, CUSTOM_REWARD_ENUM, HallGameType } from "./CommDefine";
import { HttpRequest } from "./HttpRequestName";
import ReportConfig from "./ReportConfig";
import HowToPlayDefined from "./HowToPlayDefined";
import { TransferPlatform } from "./TransferPlatform";
import { EarthQuakes } from "./EarthQuakes";
import UtilsLogicTool from "./UtilsLogicTool";
import User from "./User";
import AppInfo from "./AppInfo";
import { ToolUtils } from "./ToolUtils";
import { FlygoldAnim } from "./FlygoldAnim";
import PhpReportDefined from "./PhpReportDefined";
const { ccclass } = _decorator;
@ccclass("Utils")
export default class Utils {
    static _instance = null;
    public TAG: string = "Utils";
    public str: string = "";
    public toastPrefab: any = null;
    public loadingPrefab: any = null;
    public pLoadingNode: any = null;
    public loadingFlag: number = 1;
    public webViewNode: any = null;
    public webViewPrefab: any = null;
    public storePrefab: any = null;
    public personalInfoVerifyPrefab: any = null;
    public personalInfoVerifyNode: any = null;
    public depositTransferPrefab: any = null;
    public withdrawHelpPrefab: any = null;
    public walletPrefab: any = null;
    public walletDetailstPrefab: any = null;
    public walletRecordPrefab: any = null;
    public withdrawEditPrefab: any = null;
    public withdrawConfirmPrefab: any = null;
    public withdrawMainConfirmPrefab: any = null;
    public withdrawManagePrefab: any = null;
    public withdrawDeletePrefab: any = null;
    public withdrawAddPrefab: any = null;
    public bonusDetailstPrefab: any = null;
    public keyBoadViewPrefab: any = null;
    public storeReceiptDialogPrefab: any = null;
    public withdrawalStutusPrefab: any = null;
    public kycPrefab: any = null;
    public kycAgeVerifyPrefab: any = null;
    public kycPhotoPrefab: any = null;
    public hallPasswordPrefab: any = null;
    public invitePrefab: any = null;
    public inviteEarningsPrefab: any = null;
    public inviteEarnDetailsPrefab: any = null;
    public inviteRewardTaskPrefab: any = null;
    public inviteHelpPrefab: any = null;
    public withdrawalPrefab: any = null;
    public exchangeWalletPrefab: any = null;
    public bindMyReferrerPrefab: any = null;
    public clubViewPrefab: any = null;
    public menuViewPrefab: any = null;
    public hallsettingPrefab: any = null;
    public hallLogoutPrefab: any = null;
    public rechargeLimitsPrefab: any = null;
    public couponActPrefab: any = null;
    public firstRechargePrefab: any = null;
    public twentyFourRechargePrefab: any = null;
    public rebateRechargePrefab: any = null;
    public payOneForThreePrefab: any = null;
    public dailyFireSalePrefab: any = null;
    public consecutiveGiftPrefab: any = null;
    public customSelGiftPrefab: any = null;
    public treasuredrawPrefab: any = null;
    public treasuredrawShopPre: any = null;
    public happyflopPrefab: any = null;
    public lotteryPrefab: any = null;
    public lotteryGamePrefab: any = null;
    public weekmonthPrefab: any = null;
    public panCardPrefab: any = null;
    public hallUserInfoPrefab: any = null;
    public redeemCodePrefab: any = null;
    public buddyJoinPrefab: any = null;
    public ageVerifyPrefab: any = null;
    public rankPrefab: any = null;
    public dialogPrefab: any = null;
    public contactUsPrefab: any = null;
    public matchAlertPrefab: any = null;
    public matchPrizesRankPrefab: any = null;
    public matchRankPrefab: any = null;
    public rePassWordPrefab: any = null;
    public loginVerificationPrefab: any = null;
    public selectAreaPrefab: any = null;
    public selectDatePrefab: any = null;
    public rewardTipsPrefab: any = null;
    public dailyLoginActPrefab: any = null;
    public tawkFeedbackPrefab: any = null;
    public activityPrefab: any = null;
    public mailViewPrefab: any = null;
    public ruleHelpViewPrefab: any = null;
    public locationGuidePrefab: any = null;
    public panGuidePrefab: any = null;
    public mobileGuidePrefab: any = null;
    public paymentGuidePrefab: any = null;
    public happyHoliPrefab: any = null;
    public broadCastPrefab: any = null;
    public gullakPrefab: any = null;
    public gullakPrefab_inGame: any = null;
    public easyGameTypePrefab: any = null;
    public multipleGameTypePrefab: any = null;
    public bumpGameTypePrefab: any = null;
    public adPrefab: any = null;
    public adRewardPrefab: any = null;
    public AdvancedGiftPrefab: any = null;
    public leaderboardsPopPrefab: any = null;
    public superVipPrefab: any = null;
    public leaderBoardsPrefab: any = null;
    public leaderBoardsHallMainPrefab: any = null;
    public leaderBoardsTipPrefab: any = null;
    public actRankListPrefab: any = null;
    public storeRetainPrefab: any = null;
    public bonusForestPrefab: any = null;
    public bonusForestGuidePrefab: any = null;
    public treasurePrefab: any = null;
    public treasureRechargePrefab: any = null;
    public kefuAskPrefab: any = null;
    public helpAlertPrefab: any = null;
    public freeMatchPushPrefab: any = null;
    public hallGameDisplayPrefab: any = null;
    public roomGameDisplayPrefab: any = null;
    public treasureHuntPrefabInHall: any = null;
    public treasureHuntPrefabInRoom: any = null;
    public meTicketListPrefab: any = null;
    public ticketSelectPrefab: any = null;
    public roomTicketSelectPrefab: any = null;
    public ticketUsingPrefab: any = null;
    public chipGameTypePrefab: any = null;
    public chip_quick_rechargePrefab: any = null;
    public doubleRummyTypePrefab: any = null;
    public game_rechargePrefab: any = null;
    public hall_rechargePrefab: any = null;
    public marketInvitePrefab: any = null;
    public game_assistancePrefab: any = null;
    public sort_modePrefab: any = null;
    public event_promotionPrefab: any = null;
    public rechargeRewardsPrefab: any = null;
    public gameRatingPrefab: any = null;
    public restartGiftPrefab: any = null;
    public clubUpgradePrefab: any = null;
    public crazyCashbackPrefab: any = null;
    public flopCashActHallPrefab: any = null;
    public flopCashActGamePrefab: any = null;
    public flopCashActRecordsPrefab: any = null;
    public bagPrefab: any = null;
    public faqMainPrefab: any = null;
    public faqDetailPrefab: any = null;
    public cricket_mainPrefab: any = null;
    public cricket_chooseGamePrefab: any = null;
    public cricket_gameDetailsPrefab: any = null;
    public cricket_createTeamPrefab: any = null;
    public cricket_selectCaptainPrefab: any = null;
    public cricket_teamListPrefab: any = null;
    public cricket_joinListPrefab: any = null;
    public cricket_switchListPrefab: any = null;
    public cricket_assureJoinPrefab: any = null;
    public cricket_end: any = null;
    public cricket_endReward: any = null;
    public cricket_endPlayerDetail: any = null;
    public cricket_backUpPrefab: any = null;
    public cricket_notLineUpPrefab: any = null;
    public cricket_teamPreviewPrefab: any = null;
    public cricket_plusJiangChiPrefab: any = null;
    public cricket_fastCreateTeamPrefab: any = null;
    public cricket_playerMainPrefab: any = null;
    public cricket_fullTeamStatPrefab: any = null;
    public cricket_teamStatCmpPrefab: any = null;
    public cricket_teamRecentMatchPrefab: any = null;
    public cricket_venueMatchPrefab: any = null;
    public cricket_teamPkMsgPrefab: any = null;
    public cricket_gameSortPrefab: any = null;
    public cricket_playerTeamComparePrefab: any = null;
    public ruleGameHelpViewPrefab: any = null;
    public matchInfoPrefab: any = null;
    public _last_load_time: number = 0;
    public safeAreaRect: any = null;
    public HEAD_CATCH_FOLDER: string = "heads";
    public NET_IMAGE_CATCH_FOLDER: string = "netImage";
    public NORMAL_HEAD_IMAGE: string = "head_17.png";
    public NET_FILE_CATCH_FOLDER: string = "netFile";
    public backgroundSatyTime: number = 0;
    public hall_rootNode: any = null;
    public coupon_mobanPrefab: any = null;
    public _utilLogicTool: any = null;
    public actNodePos: any = null;
    public bundlePrefabs: Map = new Map;
    public prefabMaps: Map = new Map;
    constructor() {
        this.bundlePrefabs.clear();
        this.prefabMaps.clear();
        game.on(Game.EVENT_HIDE, (() => {
            this.backgroundSatyTime = sys.now();
            PushCenter.shared().pushEvent(GameConfig.onEnterBackground);
            User.shared().requestEnterBackGround();
            User.shared().popLabaSocket();
            User.shared().popGmSocket();
            TransferPlatform.shared().logEvent_firebase(ReportConfig.firebase_evt.onEnterBackground);
            ToolUtils.enterBackGround = true;
        }), this);
        game.on(Game.EVENT_SHOW, (() => {
            ToolUtils.enterBackGround = false;
            TransferPlatform.shared().logEvent_firebase(ReportConfig.firebase_evt.onEnterForeground);
            let a = sys.now(), t = a / 1000 - this.backgroundSatyTime / 1000;
            User.shared().onNativeEnterForceGround(t);
            ToolUtils.location_forbid && (ToolUtils.location_forbid = false, setTimeout((() => {
                1 === AppInfo.shared().checkLocationPermission() && AppInfo.shared().getLocationInfo();
            }), 200));
            Utils.shared().checkCurScreenOrientation();
            (User.shared().gp_raing_hasSkip || User.shared().has_go_charge) && setTimeout((() => {
                if (User.shared().gp_raing_hasSkip) {
                    User.shared().gp_raing_hasSkip = false;
                    let t = Math.ceil((a - User.shared().gp_raing_skip_time) / 1000);
                    t >= User.shared().gp_raing_finish_seconds && (Utils.shared().showToast(i18nMgr.shared().getValueByKey("suggestion.rating_success_tips"), 2), User.shared().requestGameRatingFinishRating({ finish_seconds: t }));
                }
                User.shared().has_go_charge && (User.shared().charge_sucess || PushCenter.shared().pushEvent(PushEvent.StoreShowAskHelpView), User.shared().has_go_charge = false);
            }), 1000);
        }), this);
        game.on(Game.EVENT_LOW_MEMORY, (() => {
            ToolUtils.enterBackGround || (TransferPlatform.shared().logEvent_firebase(ReportConfig.firebase_evt.event_low_memory), director.getScene().name == BundleNameDefined.switch_scence || window.InSwitchScene || (sys.os !== sys.OS.IOS && sys.os !== sys.OS.OSX && (director.getScene().name == BundleNameDefined.rummy_scence ? Utils.shared().releaseHallBundleAssets(true, true) : ToolUtils.judgeIfInHall() && Utils.shared().releaseGameBundleAssets()), PushCenter.shared().pushEvent(PushEvent.Low_Memory_Notice), sys.garbageCollect()));
        }), this);
        input.on(Input.EventType.KEY_DOWN, (e => {
            e.keyCode == KeyCode.MOBILE_BACK && sys.isNative && PushCenter.shared().pushEvent(GameConfig.BackKey_Clicked);
        }), this);
        PushCenter.shared().addListener(GameConfig.Show_Shop, (a => {
            let t = ToolUtils.parseJson(a);
            Utils.shared().showQuickRecharge(t.vid, null, true, null, t.match_vid, t.min_entry);
        }), this);
        PushCenter.shared().addListener(GameConfig.Show_FullScreen_Shop, (a => {
            Utils.shared().showStoreView();
        }), this);
        PushCenter.shared().addListener(PushEvent.PopNextRewardTip, (e => {
            setTimeout((() => {
                User.shared().popNextRewardTips();
            }), game.frameTime);
        }), this);
        PushCenter.shared().addListener(PushEvent.pushPopNode, e => this.pushPopupNode(e), this);
        PushCenter.shared().addListener(PushEvent.removePopNode, e => this.removePopupNode(e), this);
        PushCenter.shared().addListener(PushEvent.ShowCommDlg, (a => {
            if (!sys.isObjectValid(a)) {
                return;
            }
            let t = ToolUtils.isSafeString(a.strContent), r = ToolUtils.isSafeString(a.strTitle), l = a.okfc, s = a.bWithCancel, o = a.bLandscape;
            Utils.shared().showCommomDialog(t, r, l, s, o);
        }), this);
        PushCenter.shared().addListener(PushEvent.HideCommDlg, (a => {
            Utils.shared().hideCommomDialog();
        }), this);
        PushCenter.shared().addListener(PushEvent.ShowCommToast, (a => {
            if (!sys.isObjectValid(a)) {
                return;
            }
            let t = ToolUtils.isSafeString(a.str), r = ToolUtils.isSafeNumber(a.nTime);
            Utils.shared().showToast(t, r);
        }), this);
        PushCenter.shared().addListener(PushEvent.ShowCommLoading, (a => {
            if (!sys.isObjectValid(a)) {
                return;
            }
            let t = ToolUtils.isSafeNumber(a.nTime), r = a.cb;
            Utils.shared().showLoading(t, a.bUnEnableTouch, r, a.nomal_direction);
        }), this);
        PushCenter.shared().addListener(PushEvent.HideCommLoading, (a => {
            Utils.shared().hideLoading();
        }), this);
        PushCenter.shared().addListener(PushEvent.NativeFBLogin, (a => {
            Utils.shared().doFaceBookLogic(a);
        }), this);
        null == this._utilLogicTool && (this._utilLogicTool = new UtilsLogicTool, this._utilLogicTool.init(this));
    }
    addBundlePrefab(e, a, t) {
        sys.isObjectValid(e) && e.length > 0 && sys.isObjectValid(a) && a.length > 0 && sys.isObjectValid(t) && (this.bundlePrefabs.has(e) ? (-1 === this.bundlePrefabs.get(e).indexOf(a) && this.bundlePrefabs.get(e).push(a), this.prefabMaps.set(a, t)) : (this.bundlePrefabs.set(e, [a]), this.prefabMaps.set(a, t)));
    }
    clearBundlePrefab(e, a) {
        if (sys.isObjectValid(e) && e.length > 0) {
            if (sys.isObjectValid(a) && a.length > 0) {
                if (this.bundlePrefabs.has(e) && -1 !== this.bundlePrefabs.get(e).indexOf(a) && this.prefabMaps.has(a) && sys.isObjectValid(this.prefabMaps.get(a))) {
                    let t = this.bundlePrefabs.get(e).indexOf(a);
                    -1 !== t && (this.bundlePrefabs.get(e).splice(t, 1), this.prefabMaps.set(a, null));
                }
            }
            else {
                this.bundlePrefabs.has(e) && this.bundlePrefabs.delete(e);
            }
        }
    }
    getBundlePrefab(e, a, t) {
        sys.isObjectValid(e) && e.length > 0 && (this.bundlePrefabs.has(e) && -1 !== this.bundlePrefabs.get(e).indexOf(a) && this.prefabMaps.has(a) && sys.isObjectValid(this.prefabMaps.get(a)) ? t && t(this.prefabMaps.get(a)) : ToolUtils.loadCommonPrefab(null, e, a, (i => {
            this.addBundlePrefab(e, a, i);
            t && t(i);
        })));
    }
    checkScreenPortrait() {
        let e = view.getVisibleSize();
        e.width > e.height && AppInfo.shared().orientationToPortrait();
        AppInfo.shared().refreshDesignResolution();
    }
    checkScreenLandscape() {
        let e = view.getVisibleSize();
        e.height > e.width && AppInfo.shared().orientationToLandscape();
        AppInfo.shared().refreshDesignResolution();
    }
    checkCurScreenOrientation() {
        ToolUtils.getIsInRoom() ? (this.checkScreenLandscape(), 1 !== ToolUtils.in_isGuideRoom && PushCenter.shared().pushEvent(PushEvent.onBackGameCheckStatus)) : director.getScene().name == BundleNameDefined.switch_scence && 1 == ToolUtils.switchSceneTye ? this.checkScreenLandscape() : this.checkScreenPortrait();
    }
    static shared() : Utils {
        return null == this._instance && (this._instance = new Utils), this._instance;
    }
    mackCallBackStatus() {
        this._utilLogicTool.mackCallBackStatus();
    }
    cancelGoBack() {
        this._utilLogicTool.cancelGoBack();
    }
    replaceHistory() {
        this._utilLogicTool.replaceHistory();
    }
    pushHistory() {
        this._utilLogicTool.pushHistory();
    }
    setStr(e, a) {
        if (null != e) {
            let t = e.getComponent(Label);
            null != a && (t.string = a);
        }
    }
    setImage(e, a, t) {
        this._utilLogicTool.setImage(e, a, t);
    }
    showToast(e, a, t = 0, r = true) {
        sys.isObjectValid(this.toastPrefab) && this.toastPrefab.isValid ? this.createToast(e, a, t, r) : resources.load("prefabs/toast", Prefab, ((i, l) => {
            null == i && (this.toastPrefab = l, this.createToast(e, a, t, r));
        }));
    }
    createToast(e, a, t, i) {
        let r = director.getScene().getChildByName("Canvas");
        if (ToolUtils.isObjValid(r)) {
            try {
                let l = r.getChildByName("ToastNode");
                ToolUtils.isObjValid(l) || (l = instantiate(this.toastPrefab), r.addChild(l));
                l.getComponent("ToastNode").setTip(e, a, t, i);
                l.name = "ToastNode";
                l.setSiblingIndex(9999999);
            }
            catch (e) {
                TLog.printError("createToast error= " + e);
            }
        }
    }
    hideToast() {
        if (director.getScene()) {
            let e = director.getScene().getChildByName("Canvas");
            if (e) {
                let a = e.getChildByName("ToastNode");
                ToolUtils.isObjValid(a) && a.destroy();
            }
        }
    }
    showLoading(e, a = true, t = null, r = true, l, s) {
        this.loadingFlag = 1;
        sys.isObjectValid(this.loadingPrefab) && this.loadingPrefab.isValid ? this.createLoading(e, a, t, r, l, s) : resources.load("prefabs/loading", Prefab, ((i, o) => {
            null == i ? (this.loadingPrefab = o, this.loadingPrefab.addRef(), 1 == this.loadingFlag && this.createLoading(e, a, t, r, l, s)) : TLog.printError("loadLoadingPrefabs error= " + i);
        }));
    }
    hideLoading() {
        this.loadingFlag = 0;
        this.setLoadingPersist(false);
        this.removeLoading();
    }
    setLoadingPersist(e) {
        if (ToolUtils.isObjValid(this.pLoadingNode)) {
            if (e) {
                let e = director.getScene();
                if (ToolUtils.isObjValid(e)) {
                    let a = e.getChildByName("Global");
                    if (ToolUtils.isObjValid(a)) {
                        let e = a.getChildByName("Canvas");
                        ToolUtils.isObjValid(e) && this.pLoadingNode.parent != e && (this.pLoadingNode.removeFromParent(), e.addChild(this.pLoadingNode), this.pLoadingNode.active = true);
                    }
                }
            }
            else {
                let e = director.getScene().getChildByName("Canvas");
                ToolUtils.isObjValid(e) && this.pLoadingNode.parent != e && (this.pLoadingNode.removeFromParent(), e.addChild(this.pLoadingNode), this.pLoadingNode.active = true);
            }
        }
    }
    createLoading(e, a, t = null, i = true, r, l) {
        if (null != r && null != r && 1 === r || this.removeLoading(), !ToolUtils.isObjValid(this.pLoadingNode)) {
            let e = director.getScene().getChildByName("Canvas");
            this.pLoadingNode = instantiate(this.loadingPrefab);
            ToolUtils.isObjValid(e) && e.addChild(this.pLoadingNode);
        }
        let o = this.pLoadingNode.getComponent("loading"), n = this;
        o.showLoading(e, a, (() => {
            t && t();
            n.removeLoading();
        }), i, r, l);
    }
    removeLoading() {
        ToolUtils.isObjValid(this.pLoadingNode) && (this.pLoadingNode.removeFromParent(), this.pLoadingNode.destroy());
        this.pLoadingNode = null;
    }
    preLoadWebview(e) {
        this._utilLogicTool.preLoadWebview(e);
    }
    preLoadBundleAsset(e = false, a = false) {
        sys.isObjectValid(ToolUtils.report_time_param.preloadBundleRes) || (ToolUtils.report_time_param.preloadBundleRes = sys.now());
        sys.isObjectValid(ToolUtils._globalNode) && TweenTool.stopNodeAction(ToolUtils._globalNode);
        this._utilLogicTool.preLoadBundleAsset(e, a);
    }
    preLoadActBundlePrefab(e, a = null) {
        switch (Number(e)) {
            case PushEvent.JUMP_TO_Gullak:
                ToolUtils.preLoadBundlePrefab(BundleNameDefined.bundle_gullak, "prefab/piggy_bank", null);
                break;
            case PushEvent.JUMP_TO_WEEK_MONTH:
                ToolUtils.preLoadBundlePrefab(BundleNameDefined.bundle_weekmonth, "prefab/weeklymonthcard_new", null);
                break;
            case PushEvent.JUMP_TO_Adventrue:
                ToolUtils.preLoadBundlePrefab(BundleNameDefined.Bundle_advancePack, "prefab/AdvancedGift", null);
                break;
            case PushEvent.JUMP_TO_NOVICESTASK:
            case PushEvent.JUMP_TO_NEW_NOVICESTASK:
                ToolUtils.preLoadBundlePrefab(BundleNameDefined.bundle_novicesTask, "prefab/newplayer_task", null);
                break;
            case PushEvent.JUMP_TO_SCLB:
                ToolUtils.preLoadBundlePrefab(BundleNameDefined.bundle_firstRecharge, "prefab/first_buy", null), ToolUtils.preLoadBundlePrefab(BundleNameDefined.bundle_firstRecharge, "prefab/first_buy_old", null);
                break;
            case PushEvent.JUMP_TO_TwentyFourRecharge:
                ToolUtils.preLoadBundlePrefab(BundleNameDefined.bundle_firstRecharge, "prefab/wholeday_gift", null);
                break;
            case PushEvent.JUMP_TO_BuyOneGetThree:
                ToolUtils.preLoadBundlePrefab(BundleNameDefined.bundle_payoneforthree, "prefab/payoneforthree", null);
                break;
            case PushEvent.JUMP_TO_Act_FlopCash:
                ToolUtils.preLoadBundlePrefab(BundleNameDefined.Bundle_FlopCashAct, "prefab/beginner_flip_task", null);
                break;
            case PushEvent.JUMP_TO_REDEEM_CODE:
                ToolUtils.preLoadBundlePrefab(BundleNameDefined.bundle_hallTopUI, "prefab/redemption_code", null);
                break;
            case PushEvent.JUMP_TO_HAPPYHOLI:
                ToolUtils.preLoadBundlePrefab(BundleNameDefined.Bundle_happyHoli, "prefab/happyHoli", null);
                break;
            case PushEvent.JUMP_TO_LeaderBoards:
                ToolUtils.preLoadBundlePrefab(BundleNameDefined.Bundle_leaderBoards, "prefab/rankings", null);
                break;
            case PushEvent.JUMP_TO_TOURNESFORMAT:
            case PushEvent.JUMP_TO_Act_BestHighScore:
            case PushEvent.JUMP_TO_Act_Wild:
            case PushEvent.JUMP_TO_Act_Multiple:
            case PushEvent.JUMP_TO_Act_MemberShipRpExchange:
            case PushEvent.JUMP_TO_Act_RechangeCoupon:
            case PushEvent.JUMP_TO_FreeMatch:
                e == PushEvent.JUMP_TO_Act_RechangeCoupon && sys.isObjectValid(a) && ToolUtils.isSafeString(a.title_url).length > 0 && this.updateNetImage(null, a.title_url);
                break;
            case PushEvent.JUMP_TO_InviteCheck:
                ToolUtils.preLoadBundlePrefab(BundleNameDefined.bundle_invite, "prefab/share_pop_act", null);
                break;
            case PushEvent.JUMP_TO_DAILYLOGIN: ToolUtils.preLoadBundlePrefab(BundleNameDefined.Bundle_dailyLogin, "prefab/dailycheckin", null);
        }
    }
    releaseHallBundleAssets(e = false, a = false) {
        try {
            if (!a && this._utilLogicTool._preloadHallStatus) {
                return void TLog.printError("---------- releaseHallBundleAssets preloading stop");
            }
            this._utilLogicTool.releaseHallBundleAssets(e, a);
        }
        catch (e) {
            TLog.printError("----------- releaseHallBundleAssets err:", e);
        }
    }
    releaseHallUnusedAssets(e = false) {
        sys.isObjectValid(ToolUtils._globalNode) && TweenTool.stopNodeAction(ToolUtils._globalNode);
        PushCenter.shared().pushEvent(PushEvent.Low_Memory_Notice);
    }
    releaseGameBundleAssets() {
        this._utilLogicTool.releaseGameBundleAssets();
    }
    releaseGameUnusedAssets() {
        PushCenter.shared().pushEvent(PushEvent.Low_Memory_Notice);
    }
    releasePublicUnusedAssets(e = true) {
        this._utilLogicTool.releasePublicUnusedAssets(e);
    }
    showWalletView(a) {
        ToolUtils.loadCommonPrefab(this.walletPrefab, BundleNameDefined.bundle_wallet, "prefab/purse", (t => {
            if (Utils.shared().hideLoading(), this.walletPrefab = t, ToolUtils.isObjValid(a) && null == a.getChildByName("purse")) {
                let e = instantiate(this.walletPrefab);
                e.name = "purse";
                a.addChild(e);
            }
        }));
    }
    showLeaderBoardMainView(a) {
        ToolUtils.loadCommonPrefab(this.leaderBoardsHallMainPrefab, BundleNameDefined.Bundle_leaderBoards, "prefab/rankings", (t => {
            if (Utils.shared().hideLoading(), this.leaderBoardsHallMainPrefab = t, ToolUtils.isObjValid(a) && null == a.getChildByName("rankings")) {
                let e = instantiate(this.leaderBoardsHallMainPrefab);
                e.name = "rankings";
                a.addChild(e);
            }
        }));
    }
    showWalletView2() {
        ToolUtils.loadCommonPrefab(this.walletPrefab, BundleNameDefined.bundle_wallet, "prefab/purse", (a => {
            Utils.shared().hideLoading();
            this.walletPrefab = a;
            let t = director.getScene().getChildByName("Canvas"), i = t.getChildByName("purse");
            if (ToolUtils.isObjValid(i)) {
                i.active = true;
            }
            else {
                let e = instantiate(this.walletPrefab);
                e.name = "purse";
                t.addChild(e);
            }
        }));
    }
    pushPopupNode(node) {
        if (!ToolUtils.isObjValid(node)) return;
        const nodes = User.shared().popNode || (User.shared().popNode = []);
        if (!nodes.includes(node)) nodes.push(node);
    }
    removePopupNode(node) {
        // onDestroy runs after strict validity becomes false. Removal must still
        // accept that identity, otherwise Android Back targets a dead popup.
        const nodes = User.shared().popNode;
        if (!nodes) return;
        for (let i = nodes.length - 1; i >= 0; i--) {
            if (nodes[i] === node || !ToolUtils.isObjValid(nodes[i])) nodes.splice(i, 1);
        }
    }
    showWalletDetailstView(e, a = null, t = 0) {
        ToolUtils.loadCommonPrefab(this.walletDetailstPrefab, BundleNameDefined.bundle_wallet, "prefab/PurseHistory", (i => {
            if (this.walletDetailstPrefab = i, ToolUtils.judgeIfInHall()) {
                try {
                    let i = director.getScene().getChildByName("Canvas"), r = i.getChildByName("PurseHistory");
                    if (!ToolUtils.isObjValid(r)) {
                        ToolUtils.isObjValid(a) && (a.active = false);
                        let r = instantiate(this.walletDetailstPrefab);
                        r.name = "PurseHistory";
                        i.addChild(r);
                        let l = r.getComponent("PurseHistory");
                        l.setHistoryType(t);
                        l.Uishow(e, (() => {
                            ToolUtils.isObjValid(a) && (a.active = true);
                        }));
                    }
                }
                catch (e) {
                    TLog.printError("createWalletDetailstView err:", e);
                }
            }
        }));
    }
    showWalletHelpView(e = 0) {
        ToolUtils.judgeIfInHall() && ToolUtils.loadCommonPrefab(this.withdrawHelpPrefab, BundleNameDefined.bundle_wallet, "prefab/walletHelp", (a => {
            if (this.withdrawHelpPrefab = a, ToolUtils.judgeIfInHall()) {
                try {
                    let a = instantiate(this.withdrawHelpPrefab), t = director.getScene().getChildByName("Canvas");
                    a.getComponent("walletHelp").setParam(e);
                    t.addChild(a);
                }
                catch (e) {
                    TLog.printError("createWalletHelpView err:", e);
                }
            }
        }));
    }
    showActivityView(e) {
        ToolUtils.judgeIfInHall();
    }
    showEmailView(e) {
        ToolUtils.judgeIfInHall() && ToolUtils.loadCommonPrefab(this.mailViewPrefab, BundleNameDefined.bundle_hallTopUI, "prefab/email_main", (a => {
            try {
                if (this.mailViewPrefab = a, ToolUtils.isObjValid(e) && null == e.getChildByName("EmailMain")) {
                    try {
                        let a = instantiate(this.mailViewPrefab);
                        a.name = "EmailMain";
                        e.addChild(a);
                    }
                    catch (e) {
                        TLog.printError("createEmailView err:", e);
                    }
                }
            }
            catch (e) {
                TLog.printError("createMailView error:", e);
            }
        }));
    }
    showGameRankView() {
    }
    showStoreView(a = null, t = null) {
        if (1 === User.shared().temp_pingbi.store) {
            return void Utils.shared().showToast("Coming soon", 2);
        }
        if (0 === User.shared().charge_open) {
            return;
        }
        let r = ToolUtils.judgeIfInHall();
        ToolUtils.loadCommonPrefab(this.storePrefab, BundleNameDefined.bundle_wallet, "prefab/ShopMain", (e => {
            if (this.storePrefab = e, r) {
                if (!ToolUtils.judgeIfInHall()) {
                    return;
                }
            }
            else if (!ToolUtils.getIsInRoom()) {
                return;
            }
            try {
                let e = director.getScene().getChildByName("Canvas"), r = e.getChildByName("ShopMain");
                if (ToolUtils.isObjValid(r)) {
                    r.active = true;
                }
                else {
                    r = instantiate(this.storePrefab);
                    let l = r.getComponent("ShopMain");
                    l && sys.isObjectValid(l) && l.isValid ? (ToolUtils.isObjValid(t) && (t.active = false), PushCenter.shared().pushEvent(PushEvent.DeleteDailyTask), r.name = "ShopMain", e.addChild(r), a && l.setParaData(a), l.setCallBack((() => {
                        ToolUtils.isObjValid(t) && (t.active = true);
                    }))) : this.storePrefab = null;
                }
                this.checkRewardShowTop(e);
            }
            catch (e) {
                TLog.printError("createStoreView err:", e.toString());
                this.storePrefab = null;
            }
        }));
    }
    checkAddCashKyc() {
    }
    showOtpKyc(e = null) {
    }
    showFastKyc(e) {
        return 0;
    }
    checkPanLimitTipShow() {
        let e = false, a = 0;
        return sys.isObjectValid(User.shared().data.pan_submit_left_hour) && (a = Number(User.shared().data.pan_submit_left_hour)), a > 0 && a > sys.now() / 1000 && (e = true), e;
    }
    checkKycLimitTipShow() {
        let e = false, a = 0;
        return sys.isObjectValid(User.shared().data.submit_left_hour) && (a = Number(User.shared().data.submit_left_hour)), a > 0 && a > sys.now() / 1000 && (e = true), e;
    }
    showStoreReceiptDialogView(e) {
    }
    showRePassword() {
    }
    showQuickRechargeByYes11(a) {
        if (0 === User.shared().charge_open) {
            return;
        }
        if (sys.isObjectValid(a) && sys.isObjectValid(a.bShowNetTip) && 1 == a.bShowNetTip) {
            if (0 == sys.getNetworkType()) {
                return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text91"), 3, 0, ToolUtils.getIsNormalDirection());
            }
            Utils.shared().showLoading(11, true, (() => {
                0 == sys.getNetworkType() ? Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text91"), 3, 0, ToolUtils.getIsNormalDirection()) : Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
            }));
        }
        let t = { fee: a.fee, inRoom: 0, flag: 0, auto_quick: 0 }, r = HttpRequest.Yes11_MoneyLess;
        sys.isObjectValid(a) && sys.isObjectValid(a.is_chip) && (r = HttpRequest.Yes11_ChipLess);
        HttpManager.shared().doGetCommonRequest(t, r, ((r, l, s) => {
            if (Utils.shared().hideLoading(), 200 != s) {
                Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.request_fail"), 2);
            }
            else {
                try {
                    let r = ToolUtils.parseJson(l);
                    if (0 == r.ret) {
                        if (sys.isObjectValid(r.data)) {
                            let l;
                            sys.isObjectValid(r.data.ext) && (l = r.data.ext);
                            let s = { isShowTip: a.isShowTip, ext: l, isquick: true, inRoom: t.inRoom, type: PushEvent.JUMP_TO_Yes11, auto_quick: t.auto_quick };
                            sys.isObjectValid(l) && sys.isObjectValid(l.flag) && (s.flag = l.flag);
                            s.checkKyc = 0;
                            sys.isObjectValid(r.data.type) && (s.type = r.data.type, Utils.shared().doJumpLogic(r.data.type, s));
                        }
                    }
                    else {
                        sys.isObjectValid(r.desc) && r.desc.length > 0 && Utils.shared().showToast(r.desc, 2);
                    }
                }
                catch (e) {
                    TLog.printError("showQuickRechargeByYes11 err:", e.toString());
                }
            }
        }));
    }
    checkPopRestartGift(e) {
        let a = 0;
        if (sys.isObjectValid(e) && sys.isObjectValid(e.pop_up_124) && 1 == e.pop_up_124) {
            a = 1;
            let t = { parent_node: e.parent_node, ext: e.pop_up_data, tid_key: e.tid_key, score: e.score, inRoom: e.inRoom, type: PushEvent.JUMP_TO_RestartGift };
            this.doJumpLogic(PushEvent.JUMP_TO_RestartGift, t);
        }
        return a;
    }
    showQuickRecharge(a, t, r = true, l = "", s = 0, o = 0, n = false, d, h, c, u = 0) {
        if (0 === User.shared().charge_open) {
            return;
        }
        if (n) {
            if (0 == sys.getNetworkType()) {
                return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text91"), 3, 0, ToolUtils.getIsNormalDirection());
            }
            Utils.shared().showLoading(11, true, (() => {
                0 == sys.getNetworkType() ? Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text91"), 3, 0, ToolUtils.getIsNormalDirection()) : Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
            }));
        }
        let p = { score: o, new_vid: a, inRoom: 0, flag: 0 };
        ToolUtils.judgeIfInHall() ? (p.inRoom = 0, p.flag = 0) : (p.inRoom = 1, sys.isObjectValid(d) && d > 0 && (p.flag = d));
        sys.isObjectValid(c) && 1 == c ? p.auto_quick = 1 : p.auto_quick = 0;
        sys.isObjectValid(u) && 1 == u ? p.is_pop = 1 : p.is_pop = 0;
        HttpManager.shared().doGetQuickRechargeMoneyLess(p, ((s, d, c) => {
            n && Utils.shared().hideLoading();
            try {
                if (200 != c) {
                    alert("The login timed out, please try again");
                    n && (0 == sys.getNetworkType() ? Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text91"), 3, 0, ToolUtils.getIsNormalDirection()) : Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection()));
                }
                else {
                    let s = ToolUtils.parseJson(d);
                    if (0 == s.ret && sys.isObjectValid(s.data)) {
                        let n;
                        sys.isObjectValid(s.data.ext) && (n = s.data.ext);
                        let d = { tid_key: l, parent_node: t, vid: a, isShowTip: r, ext: n, isquick: true, score: o, type: s.data.type, inRoom: p.inRoom, auto_quick: p.auto_quick };
                        if (sys.isObjectValid(n) && sys.isObjectValid(n.flag) && (d.flag = n.flag), sys.isObjectValid(s.data.pop_up_124) && 1 == s.data.pop_up_124 && sys.isObjectValid(s.data.page_124) && (d.pop_up_124 = s.data.pop_up_124, d.page_124 = s.data.page_124), d.checkKyc = 0, sys.isObjectValid(h) && 1 == Number(h) && (d.checkKyc = 1), sys.isObjectValid(s.data.type)) {
                            if (sys.isObjectValid(p.inRoom)) {
                                if (1 == p.inRoom && !ToolUtils.getIsInRoom()) {
                                    return;
                                }
                                if (0 == p.inRoom && !ToolUtils.judgeIfInHall()) {
                                    return;
                                }
                            }
                            Utils.shared().doJumpLogic(s.data.type, d);
                        }
                    }
                }
            }
            catch (e) {
                TLog.printError("doGetQuickRechargePackageCallback:", e);
            }
        }));
    }
    showBonusRecharge(a, t, r = true, l = "", s = 0, o = 0, n = false, d) {
        if (0 === User.shared().charge_open) {
            return;
        }
        if (n) {
            if (0 == sys.getNetworkType()) {
                return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text91"), 3, 0, ToolUtils.getIsNormalDirection());
            }
            Utils.shared().showLoading(11, true, (() => {
                0 == sys.getNetworkType() ? Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text91"), 3, 0, ToolUtils.getIsNormalDirection()) : Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
            }));
        }
        let h = { new_vid: a, inRoom: 1, flag: 0 };
        HttpManager.shared().doGetBonusRecharge(h, ((s, d, h) => {
            n && Utils.shared().hideLoading();
            try {
                if (200 != h) {
                    alert("The login timed out, please try again");
                    n && (0 == sys.getNetworkType() ? Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text91"), 3, 0, ToolUtils.getIsNormalDirection()) : Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection()));
                }
                else {
                    let s = ToolUtils.parseJson(d);
                    if (0 == s.ret && sys.isObjectValid(s.data)) {
                        let n = s.data, d = { tid_key: l, parent_node: t, vid: a, isShowTip: r, ext: n, isquick: true, score: o, type: 101 };
                        sys.isObjectValid(n) && sys.isObjectValid(n.flag) && (d.flag = n.flag);
                        Utils.shared().doJumpLogic(101, d);
                        PushCenter.shared().pushEvent(PushEvent.UpdateBonusGiftStatus, 1);
                    }
                }
            }
            catch (e) {
                TLog.printError("showQuickRechargePackageCallback:", e);
            }
        }));
    }
    hideOtherQuickPayAlertByType(e, a) {
        if (ToolUtils.getOrientation()) {
            let t = a;
            if (!ToolUtils.isObjValid(t)) {
                t = director.getScene().getChildByName("Canvas");
            }
            if (ToolUtils.isObjValid(t)) {
                let a = t.getChildByName("CashGameUpAlert");
                ToolUtils.isObjValid(a) && a.destroy();
                let i = t.getChildByName("FirstRecharge");
                ToolUtils.isObjValid(i) && e != PushEvent.JUMP_TO_SCLB && i.destroy();
                let r = t.getChildByName("Lottery");
                ToolUtils.isObjValid(r) && e != PushEvent.JUMP_TO_LOTTERYACT && r.destroy();
                let l = t.getChildByName("HappyFlop");
                ToolUtils.isObjValid(l) && e != PushEvent.JUMP_TO_HAPPYFLOP && l.destroy();
            }
        }
    }
    showQuick_recharge_Package(e) {
        if (undefined === e.parent_node || null === e.parent_node) {
            let a = director.getScene();
            e.parent_node = a.getChildByName("Canvas");
        }
        ToolUtils.judgeIfInHall() ? this.showHallQuickChargeAlert(e) : ToolUtils.getIsInRoom() && ToolUtils.loadCommonPrefab(this.game_rechargePrefab, BundleNameDefined.Bundle_QuickCharge, "prefab/game_fast_buy", (a => {
            this.game_rechargePrefab = a;
            try {
                if (!ToolUtils.getIsInRoom()) {
                    return;
                }
                let a;
                sys.isObjectValid(e) && (a = e.parent_node);
                ToolUtils.isObjValid(a) || (a = director.getScene().getChildByName("Canvas"));
                let t = a.getChildByName("game_fast_buy");
                if (ToolUtils.isObjValid(t)) {
                    let a = t.getComponent("GameFastBuy");
                    t.active = true;
                    sys.isObjectValid(a) && a.initView(e);
                }
                else {
                    t = instantiate(this.game_rechargePrefab);
                    t.parent = a;
                    t.getComponent("GameFastBuy").initView(e);
                    this.hideOtherQuickPayAlertByType(0);
                }
            }
            catch (e) {
                TLog.printError("showQuick_recharge_Package error:" + e);
            }
        }));
    }
    showDepositTransferView(a = null) {
        1 !== User.shared().temp_pingbi.withdraw ? 0 !== User.shared().charge_open && ToolUtils.loadCommonPrefab(this.depositTransferPrefab, BundleNameDefined.bundle_wallet, "prefab/WithdrawalMain", (e => {
            if (this.depositTransferPrefab = e, ToolUtils.judgeIfInHall()) {
                try {
                    let e = director.getScene().getChildByName("Canvas"), t = e.getChildByName("WithdrawalMain");
                    if (!ToolUtils.isObjValid(t)) {
                        t = instantiate(this.depositTransferPrefab);
                        let r = t.getComponent("WithdrawalMain");
                        r && sys.isObjectValid(r) && r.isValid ? (ToolUtils.isObjValid(a) && (a.active = false), t.name = "WithdrawalMain", e.addChild(t), r.initData((() => {
                            ToolUtils.isObjValid(a) && (a.active = true);
                        }))) : this.depositTransferPrefab = null;
                    }
                }
                catch (e) {
                    TLog.printError("createConversionView error= " + e);
                    this.depositTransferPrefab = null;
                }
            }
        })) : Utils.shared().showToast("Coming soon", 2);
    }
    showWalletRecordView(e, a = null, t) {
        let i = ToolUtils.judgeIfInHall();
        ToolUtils.loadCommonPrefab(this.walletRecordPrefab, BundleNameDefined.bundle_wallet, "prefab/WalletRecode", (r => {
            if (this.walletRecordPrefab = r, i) {
                if (!ToolUtils.judgeIfInHall()) {
                    return;
                }
            }
            else if (!ToolUtils.judgeIfInRummy()) {
                return;
            }
            try {
                let i = director.getScene().getChildByName("Canvas"), r = i.getChildByName("WalletRecode");
                if (!ToolUtils.isObjValid(r)) {
                    let r = instantiate(this.walletRecordPrefab);
                    i.addChild(r);
                    ToolUtils.isObjValid(a) && (a.active = false);
                    let l = r.getComponent("WalletRecode");
                    null != e && (l.setParaData(e), t && "WithdrawalMain" !== t && l.setRecode_tabl(t));
                    l.setCallBack((() => {
                        ToolUtils.isObjValid(a) && (a.active = true, t && "WithdrawalMain" == t && PushCenter.shared().pushEvent(PushEvent.Update_PanInfo));
                    }));
                }
            }
            catch (e) {
                TLog.printError("createWalletRecordView error= " + e);
            }
        }));
    }
    showKeyboardView(e) {
        ToolUtils.loadCommonPrefab(this.keyBoadViewPrefab, BundleNameDefined.bundle_wallet, "prefab/LetterKeyboard", (a => {
            this.keyBoadViewPrefab = a;
            try {
                let a = instantiate(this.keyBoadViewPrefab);
                if (director.getScene().getChildByName("Canvas").addChild(a), null != e) {
                    a.getComponent("LetterKeyBoard").setParaData(e);
                }
            }
            catch (e) {
                TLog.printError("createKeyboardView error= " + e);
            }
        }));
    }
    hidePersonalInfoVerifyView() {
        ToolUtils.isObjValid(this.personalInfoVerifyNode) && this.personalInfoVerifyNode.destroy();
        this.personalInfoVerifyNode = null;
    }
    showPersonalInfoVerifyView(e) {
        this.hidePersonalInfoVerifyView();
        ToolUtils.loadCommonPrefab(this.personalInfoVerifyPrefab, BundleNameDefined.bundle_wallet, "prefab/PersonalInfoVerify", (a => {
            this.personalInfoVerifyPrefab = a;
            try {
                this.personalInfoVerifyNode = instantiate(this.personalInfoVerifyPrefab);
                director.getScene().getChildByName("Canvas").addChild(this.personalInfoVerifyNode);
                this.personalInfoVerifyNode.getComponent("PersonalInfoVerify").updateUI(e);
            }
            catch (e) {
                TLog.printError("createPersonnalInfoVerify error:", e);
            }
        }));
    }
    showKycPhotoView(e, a) {
        ToolUtils.loadCommonPrefab(this.kycPhotoPrefab, BundleNameDefined.Bundle_kyc, "prefab/Kyc_photo", (t => {
            if (this.kycPhotoPrefab = t, ToolUtils.judgeIfInHall()) {
                try {
                    let t = e.getChildByName("Kyc_photo");
                    if (ToolUtils.isObjValid(t)) {
                        t.active || (t.active = true);
                    }
                    else {
                        t = instantiate(this.kycPhotoPrefab);
                        e.addChild(t);
                        t.getComponent("KycPhoto").setCallBack(a);
                    }
                }
                catch (e) {
                    TLog.printError("createKycPhotoView error:", e);
                }
            }
        }));
    }
    showAgeVerification(e = null, a = null) {
        if (null == a) {
            let e = director.getScene();
            a = e.getChildByName("Canvas");
        }
        ToolUtils.loadCommonPrefab(this.ageVerifyPrefab, BundleNameDefined.bundle_public, "prefab/age_verification", (t => {
            this.ageVerifyPrefab = t;
            try {
                if (null == a.getChildByName("AgeVerification")) {
                    let t = instantiate(this.ageVerifyPrefab);
                    t.name = "AgeVerification";
                    a.addChild(t);
                    t.getComponent("AgeVerification").setCallBack(e);
                }
            }
            catch (e) {
                TLog.printError("createAgeVerification error= " + e);
            }
        }));
    }
    showSelectAreaView(e, a, t, i) {
        ToolUtils.loadCommonPrefab(this.selectAreaPrefab, BundleNameDefined.bundle_public, "prefab/select_area", (r => {
            if (this.selectAreaPrefab = r, ToolUtils.judgeIfInHall()) {
                try {
                    let r = e.getChildByName("select_area");
                    if (ToolUtils.isObjValid(r)) {
                        r.active || (r.active = true);
                    }
                    else {
                        r = instantiate(this.selectAreaPrefab);
                        e.addChild(r);
                        r.getComponent("SelectArea").setCallBack(a, t, i);
                    }
                }
                catch (e) {
                    TLog.printError("createSelectAreaView error:", e);
                }
            }
        }));
    }
    showSelectDateView(e, a, t, i, r) {
        ToolUtils.loadCommonPrefab(this.selectDatePrefab, BundleNameDefined.bundle_public, "prefab/seltct_date", (l => {
            try {
                this.selectDatePrefab = l;
                let s = e.getChildByName("seltct_date");
                if (ToolUtils.isObjValid(s)) {
                    s.active || (s.active = true);
                }
                else {
                    s = instantiate(this.selectDatePrefab);
                    e.addChild(s);
                    s.getComponent("SelectDate").setCallBack(a, t, i, r);
                }
            }
            catch (e) {
                TLog.printError("createSelectAreaView error:", e);
            }
        }));
    }
    showInviteView(e) {
        ToolUtils.loadCommonPrefab(this.invitePrefab, BundleNameDefined.bundle_invite, "prefab/share_main_page", (a => {
            if (this.invitePrefab = a, ToolUtils.judgeIfInHall()) {
                try {
                    if (null == e.getChildByName("Invite")) {
                        let a = instantiate(this.invitePrefab);
                        a.name = "Invite";
                        e.addChild(a);
                    }
                }
                catch (e) {
                    TLog.printError("createInviteView error:", e);
                }
            }
        }));
    }
    showEarnDetailsView(e, a) {
    }
    showInviteEarningsView(e) {
    }
    showInviteHelpView(e) {
        ToolUtils.loadCommonPrefab(this.inviteHelpPrefab, BundleNameDefined.bundle_invite, "prefab/inviteHelp", (a => {
            try {
                this.inviteHelpPrefab = a;
                let t = director.getScene().getChildByName("Canvas");
                if (null == t.getChildByName("inviteHelp")) {
                    let a = instantiate(this.inviteHelpPrefab);
                    a.name = "inviteHelp";
                    t.addChild(a);
                    a.getComponent("InviteHelp").setParaData(e);
                }
            }
            catch (e) {
                TLog.printError("createInviteHelpView error:", e);
            }
        }));
    }
    showBindingMyReferrer(e) {
    }
    showMenuView(a) {
        ToolUtils.loadCommonPrefab(this.menuViewPrefab, BundleNameDefined.bundle_menu, "prefab/carte_node_v2", (t => {
            Utils.shared().hideLoading();
            try {
                if (this.menuViewPrefab = t, null == a.getChildByName("carte_node_v2")) {
                    let e = instantiate(this.menuViewPrefab);
                    e.name = "carte_node_v2";
                    a.addChild(e);
                }
            }
            catch (e) {
                TLog.printError("createMenuView error:", e);
            }
        }));
    }
    showHallSettingView() {
        ToolUtils.loadCommonPrefab(this.hallsettingPrefab, BundleNameDefined.bundle_menu, "prefab/lobby_settings", (a => {
            Utils.shared().hideLoading();
            try {
                this.hallsettingPrefab = a;
                let e = director.getScene().getChildByName("Canvas");
                if (null == e.getChildByName("lobby_settings")) {
                    let a = instantiate(this.hallsettingPrefab);
                    a.name = "lobby_settings";
                    e.addChild(a);
                }
            }
            catch (e) {
                TLog.printError("createMenuView error:", e);
            }
        }));
    }
    showHallLogoutView() {
        ToolUtils.loadCommonPrefab(this.hallLogoutPrefab, BundleNameDefined.bundle_menu, "prefab/lobby_logout", (a => {
            Utils.shared().hideLoading();
            try {
                this.hallLogoutPrefab = a;
                let e = director.getScene().getChildByName("Canvas");
                if (null == e.getChildByName("lobby_logout")) {
                    let a = instantiate(this.hallLogoutPrefab);
                    a.name = "lobby_logout";
                    e.addChild(a);
                }
            }
            catch (e) {
                TLog.printError("showHallLogoutView error:", e);
            }
        }));
    }
    showHallPassWordView(e = false, a = "", t = "") {
        ToolUtils.loadCommonPrefab(this.hallPasswordPrefab, BundleNameDefined.Bundle_kyc, "prefab/hall_settings_password", (e => {
            try {
                if (this.hallPasswordPrefab = e, director.getScene().name != BundleNameDefined.hall_scene) {
                    return;
                }
                let i = director.getScene().getChildByName("Canvas"), r = i.getChildByName("hall_settings_password");
                ToolUtils.isObjValid(r) || (r = instantiate(this.hallPasswordPrefab), r.parent = i);
                r.getComponent("HallSettingsPassword").setDataInfo(a, t);
            }
            catch (e) {
                TLog.printError("Hall showCreatePassWord err:", e);
            }
        }));
    }
    showRechargeLimitsView() {
    }
    showContactUsView(e) {
        ToolUtils.loadCommonPrefab(this.contactUsPrefab, BundleNameDefined.bundle_public, "prefab/contactus_node", (a => {
            try {
                this.contactUsPrefab = a;
                let t = director.getScene().getChildByName("Canvas");
                if (null == t.getChildByName("contactus")) {
                    let a = instantiate(this.contactUsPrefab);
                    a.name = "contactus";
                    t.addChild(a);
                    a.getComponent("ContactUsAlert").setParaData(e);
                }
            }
            catch (e) {
                TLog.printError("createMenuView error:", e);
            }
        }));
    }
    showMemberShipView(e) {
        ToolUtils.loadCommonPrefab(this.clubViewPrefab, BundleNameDefined.bundle_club, "prefab/membership", (a => {
            this.clubViewPrefab = a;
            try {
                let a = null, t = false;
                e && e.node && (a = e.node);
                e && sys.isObjectValid(e.bShowPushAnim) && (t = e.bShowPushAnim);
                let r = instantiate(this.clubViewPrefab);
                director.getScene().getChildByName("Canvas").addChild(r);
                let l = r.getComponent("MemberShip");
                l.initParaData(e);
                l.init(t, (() => {
                    ToolUtils.isObjValid(a) && (a.active = false);
                }), (() => {
                    ToolUtils.isObjValid(a) && (a.active = true);
                }));
            }
            catch (e) {
                TLog.printError("createMemberShipView error:", e);
            }
        }));
    }
    showUserInfoView() {
        ToolUtils.loadCommonPrefab(this.hallUserInfoPrefab, BundleNameDefined.bundle_hallTopUI, "prefab/userinfo_prefab", (e => {
            try {
                this.hallUserInfoPrefab = e;
                let a = director.getScene().getChildByName("Canvas"), t = a.getChildByName("HallUserInfoAlert");
                ToolUtils.isObjValid(t) ? t.active = true : (t = instantiate(this.hallUserInfoPrefab), t.name = "HallUserInfoAlert", a.addChild(t));
            }
            catch (e) {
                TLog.printError("createUserInfoView error:", e);
            }
        }));
    }
    showPerformanceView() {
        try {
            ToolUtils.loadCommonPrefab(null, BundleNameDefined.bundle_hallTopUI, "prefab/performance", (e => {
                if (director.getScene().name != BundleNameDefined.hall_scene) {
                    return;
                }
                let a = director.getScene().getChildByName("Canvas"), t = a.getChildByName("performance");
                ToolUtils.isObjValid(t) || (t = instantiate(e), a.addChild(t));
            }));
        }
        catch (e) {
            TLog.printError("Utils showPerformanceView err:", e);
        }
    }
    showAnnouncementView(e, a = false) {
        try {
            ToolUtils.loadCommonPrefab(null, BundleNameDefined.bundle_hallTopUI, "prefab/announcement", (t => {
                if (director.getScene().name != BundleNameDefined.hall_scene) {
                    return;
                }
                let i = instantiate(t);
                i.name = "announcement";
                director.getScene().getChildByName("Canvas").addChild(i);
                i.getComponent("Announcement").initAnnoucement(e, a);
            }));
        }
        catch (e) {
            TLog.printError("Utils showPerformanceView err:", e);
        }
    }
    showUpdateGuideView(e, a = false) {
        try {
            ToolUtils.loadCommonPrefab(null, BundleNameDefined.bundle_hallTopUI, "prefab/update_guide", (t => {
                if (director.getScene().name != BundleNameDefined.hall_scene) {
                    return;
                }
                let i = instantiate(t);
                i.name = "update_guide";
                director.getScene().getChildByName("Canvas").addChild(i);
                i.getComponent("UpdateGuide").initAnnoucement(e, a);
            }));
        }
        catch (e) {
            TLog.printError("Utils showUpdateGuideView err:", e);
        }
    }
    showRecodeDetailsView(e) {
        try {
            ToolUtils.loadCommonPrefab(null, BundleNameDefined.bundle_rummy, "prefab/recode_details", (a => {
                if (director.getScene().name != BundleNameDefined.hall_scene) {
                    return;
                }
                let t = director.getScene().getChildByName("Canvas"), i = t.getChildByName("recode_details");
                if (!ToolUtils.isObjValid(i)) {
                    i = instantiate(a);
                    t.addChild(i);
                    i.getComponent("RecodeDetails").initUI(e, null);
                }
            }));
        }
        catch (e) {
            TLog.printError("Utils showRecodeDetailsView err:", e);
        }
    }
    showMailView(e = null) {
        ToolUtils.loadCommonPrefab(this.mailViewPrefab, BundleNameDefined.bundle_hallTopUI, "prefab/email_main", (a => {
            try {
                this.mailViewPrefab = a;
                ToolUtils.isObjValid(e) && (e.active = false);
                let t = instantiate(this.mailViewPrefab);
                director.getScene().getChildByName("Canvas").addChild(t);
                t.getComponent("EmailMain").initData((() => {
                    ToolUtils.isObjValid(e) && (e.active = true);
                }));
            }
            catch (e) {
                TLog.printError("createMailView error:", e);
            }
        }));
    }
    showSingleGameRuleHelpView(e = null) {
        ToolUtils.loadCommonPrefab(this.ruleGameHelpViewPrefab, BundleNameDefined.bundle_rule, "prefab/game_regular_node", (a => {
            this.ruleGameHelpViewPrefab = a;
            try {
                let a = director.getScene().getChildByName("Canvas");
                e && ToolUtils.isObjValid(e.parent) && (a = e.parent);
                let t = instantiate(this.ruleGameHelpViewPrefab), r = t.getComponent("GameRegular");
                a.addChild(t);
                e && (sys.isObjectValid(e.game_type) && r.setGameType(e.game_type), e.isLandscape && r.setLandscapeShow(), e.target_sp && r.showByData(e.target_sp, "", 0), e.target_wz && r.showByData(null, e.target_wz, 1));
            }
            catch (e) {
                TLog.printError("createRuleHelpView error:", e);
            }
        }));
    }
    showRuleHelpView(e = null) {
        ToolUtils.loadCommonPrefab(this.ruleHelpViewPrefab, BundleNameDefined.bundle_rule, "prefab/regular_node", (a => {
            this.ruleHelpViewPrefab = a;
            try {
                let a = director.getScene().getChildByName("Canvas");
                e && ToolUtils.isObjValid(e.parent) && (a = e.parent);
                let t = User.shared().ruleFlag.length > 0 ? User.shared().ruleFlag : "point";
                e && ToolUtils.isSafeString(e.ruleFlag).length > 0 && (t = e.ruleFlag);
                let r = false, l = false, o = false;
                e && sys.isObjectValid(e.isEasy) && (l = e.isEasy);
                e && sys.isObjectValid(e.isMultiple) && (r = e.isMultiple);
                e && sys.isObjectValid(e.isBump) && (o = e.isBump);
                let n = instantiate(this.ruleHelpViewPrefab), d = n.getComponent("regular_node");
                a.addChild(n);
                d.updateInfo(t, r, l, o);
                e && e.isLandscape && d.setLandscapeShow();
                e && e.tid_key && d.setTidKey(e.tid_key);
            }
            catch (e) {
                TLog.printError("createRuleHelpView error:", e);
            }
        }));
    }
    loadSoundManager() {
        resources.load("prefabs/gameSound", Prefab, ((e, a) => {
            if (null == e) {
                try {
                    let e = director.getScene();
                    if (null == e.getChildByName("GameSound")) {
                        let t = instantiate(a);
                        e.addChild(t);
                    }
                    SoundManager.shared().bg_enabled && setTimeout((() => {
                        SoundManager.shared().setEnabled(SoundManager.shared().bg_enabled);
                    }), 200);
                }
                catch (e) {
                    TLog.printError("loadSoundManager error:", e);
                }
            }
            else {
                TLog.printError("loadSoundManager error= " + e);
            }
        }));
    }
    showLoadTable(e, a, t, i, r = 0, l, o, n, d) {
        if (director.getScene().name == BundleNameDefined.rummy_scence) {
            let a = { cmd: NetConfig.GM_CREATE_TABLE_REQUEST, uid: User.shared().data.uid, version: GameConfig.Server_Api_Ver, skey: User.shared().getSkey(), vid: e, auto_sort: User.shared().auto_sort, isNewTable: null != n && null != n ? n : 0, from_beginner_tutorial: null != d && null != d ? d : 0, ch_id: GameConfig.CHANNEL_ID };
            null != o && (a.raceid = o);
            null != l && (a.tid_key = l);
            null != i && null != i && (a.room_type = 1, a.roomid = null != i.roomid && null != i.roomid ? i.roomid : 0, a.base_money = null != i.base_money && null != i.base_money ? i.base_money : 0, a.seat_max = null != i.seat_max && null != i.seat_max ? i.seat_max : 0, null !== i.disuse_score && (a.disuse_score = i.disuse_score), null !== i.rounds && (a.rounds = i.rounds), a.clubid = Number(AppInfo.shared().getChannelId()), a.enterScene = 1);
            User.shared().doSendCommGameServerMsg(a);
        }
        else {
            if (1 == ToolUtils.isSafeNumber(n)) {
                let e = Date.parse((new Date).toString());
                if (e - this._last_load_time < 2000) {
                    return;
                }
                this._last_load_time = e;
            }
            let h = director.getScene().getChildByName("Canvas");
            ToolUtils.isObjValid(h.getChildByName("loadTableCpp")) && h.getChildByName("loadTableCpp").destroy();
            let c = new Node;
            c.addComponent("LoadTableCpp");
            h.addChild(c);
            c.name = "loadTableCpp";
            c.getComponent("LoadTableCpp").showLoadTable(e, a, t, i, r, l, o, n, d);
        }
    }
    showCommEnterGame(e) {
        if (sys.isObjectValid(e) && sys.isObjectValid(e.game_type) && (PushCenter.shared().pushEvent(PushEvent.ResetHallGameBg, e.game_type), !ToolUtils.checkIsRummy(e.game_type))) {
            if (ToolUtils.getIsInRoom()) {
                let a = { cmd: NetConfig.GM_CREATE_TABLE_REQUEST, uid: User.shared().data.uid, version: GameConfig.Server_Api_Ver, skey: User.shared().getSkey(), vid: e.vid, auto_sort: User.shared().auto_sort, isNewTable: null != e.isNewTable && null != e.isNewTable ? e.isNewTable : 0, ch_id: GameConfig.CHANNEL_ID };
                User.shared().doSendCommGameServerMsg(a);
            }
            else {
                let a = Date.parse((new Date).toString());
                if (a - this._last_load_time < 2000) {
                    return;
                }
                if (!ToolUtils.checkIsGameDownLoad(ToolUtils.getHallGameType(e.game_type))) {
                    return void TLog.printError(this.TAG, e.game_type, "Has not complate download resource");
                }
                this._last_load_time = a;
                let t = director.getScene().getChildByName("Canvas");
                ToolUtils.isObjValid(t.getChildByName("LoadTableGame")) && t.getChildByName("LoadTableGame").destroy();
                let i = new Node;
                i.addComponent("LoadTableGame");
                t.addChild(i);
                i.name = "LoadTableGame";
                i.getComponent("LoadTableGame").showCommLoadTable(e);
            }
        }
    }
    static playNumAnim(a, t, i, r, l = 0) {
        if (!a) {
            return;
        }
        if (TweenTool.stopNodeAction(a), a.string = 0 == l ? String(Math.floor(i)) : Utils.parseJackPotNum(i), Math.abs(r - i) <= 0) {
            return;
        }
        let s = i, o = Math.floor(t / 0.03), n = (r - i) / o, d = tween(a).delay(0.03), h = tween(a).call((() => {
            if (s += n, 0 == l) {
                let e = String(Math.floor(s));
                a.string = e;
            }
            else {
                let t = Utils.parseJackPotNum(s);
                a.string = t;
            }
            (n > 0 && s >= r || n < 0 && s <= r) && (TweenTool.stopNodeAction(a), a.string = 0 == l ? String(Math.floor(r)) : Utils.parseJackPotNum(r));
        }));
        tween(a).sequence(d, h).repeatForever().start();
    }
    static parseJackPotNum(e) {
        if ((e = Math.floor(e)) < 1000) {
            return `${e}`;
        }
        if (e < 100000) {
            const a = e % 1000;
            return `${Math.floor(e / 1000) % 100},${a.toString().padStart(3, "0")}`;
        }
        if (e < 10000000) {
            const a = e % 1000, t = Math.floor(e / 1000) % 100;
            return `${Math.floor(e / 100000) % 100},${t.toString().padStart(2, "0")},${a.toString().padStart(3, "0")}`;
        }
        if (e < 1000000000) {
            const a = e % 1000, t = Math.floor(e / 1000) % 100, i = Math.floor(e / 100000) % 100;
            return `${Math.floor(e / 10000000) % 100},${i.toString().padStart(2, "0")},${t.toString().padStart(2, "0")},${a.toString().padStart(3, "0")}`;
        }
        {
            const a = e % 1000, t = Math.floor(e / 1000) % 100, i = Math.floor(e / 100000) % 100, r = Math.floor(e / 10000000) % 100;
            return `${Math.floor(e / 1000000000) % 100},${r.toString().padStart(2, "0")},${i.toString().padStart(2, "0")},${t.toString().padStart(2, "0")},${a.toString().padStart(3, "0")}`;
        }
    }
    showCommEnterRoom(e) {
        sys.isObjectValid(e.game_type) && PushCenter.shared().pushEvent(PushEvent.ResetHallGameBg, e.game_type);
        let a = e.vid, t = e.isNewTable, r = e.fromBeginnerTutorial, l = e.raceid, o = e.privateRoomData, n = e.tid_key;
        if (director.getScene().name == BundleNameDefined.rummy_scence) {
            let s = { cmd: NetConfig.GM_CREATE_TABLE_REQUEST, uid: User.shared().data.uid, version: GameConfig.Server_Api_Ver, skey: User.shared().getSkey(), vid: a, auto_sort: User.shared().auto_sort, isNewTable: null != t && null != t ? t : 0, from_beginner_tutorial: null != r && null != r ? r : 0, ch_id: GameConfig.CHANNEL_ID };
            s.robot_view = null != e.robot_view ? e.robot_view : 0;
            null != l && null != l && (s.raceid = l);
            null != n && null != n && (s.tid_key = n);
            null != o && null != o && (s.room_type = 1, s.roomid = null != o.roomid && null != o.roomid ? o.roomid : 0, s.base_money = null != o.base_money && null != o.base_money ? o.base_money : 0, s.seat_max = null != o.seat_max && null != o.seat_max ? o.seat_max : 0, null !== o.disuse_score && (s.disuse_score = o.disuse_score), null !== o.rounds && (s.rounds = o.rounds), s.clubid = Number(AppInfo.shared().getChannelId()), s.enterScene = 1);
            sys.isObjectValid(e.round) && (s.round = e.round);
            User.shared().doSendCommGameServerMsg(s);
        }
        else {
            let a = Date.parse((new Date).toString());
            if (a - this._last_load_time < 2000) {
                return;
            }
            this._last_load_time = a;
            let t = director.getScene().getChildByName("Canvas");
            ToolUtils.isObjValid(t.getChildByName("loadTableCpp")) && t.getChildByName("loadTableCpp").destroy();
            let i = new Node;
            i.addComponent("LoadTableCpp");
            t.addChild(i);
            i.name = "loadTableCpp";
            i.getComponent("LoadTableCpp").showCommLoadTable(e);
        }
    }
    showCommonAlert(e, a = null, t = false) {
        sys.isObjectValid(this.dialogPrefab) && this.dialogPrefab.isValid ? TweenTool.delayAct(ToolUtils.getPersistGlobalNode(), (() => {
            this.createCommonAlert(e, a, t);
        }), 0.01, true) : ToolUtils.loadCommonPrefab(this.dialogPrefab, BundleNameDefined.bundle_public, "prefab/commondialog_node", (i => {
            this.dialogPrefab = i;
            this.createCommonAlert(e, a, t);
        }));
    }
    createCommonAlert(e, a = null, t = false) {
        let r = e.parent_node, l = null;
        sys.isObjectValid(e) && ToolUtils.isObjValid(e.last_node) && (l = e.last_node || null);
        let o = false, n = 0, d = false, h = false, c = "", u = "", p = "", m = "", g = false, b = "", _ = true, w = -1;
        if (sys.isObjectValid(e.bLandscape) && (o = e.bLandscape), sys.isObjectValid(e.bHideTopRightClose) && (h = e.bHideTopRightClose), sys.isObjectValid(e.bWithCancel) && (d = e.bWithCancel), sys.isObjectValid(e.closeType) && (n = Number(e.closeType)), sys.isObjectValid(e.strContent) && (c = e.strContent), sys.isObjectValid(e.strTitle) && (u = e.strTitle), sys.isObjectValid(e.sureKey) && (p = e.sureKey), sys.isObjectValid(e.cancelKey) && (m = e.cancelKey), sys.isObjectValid(e.kefu) && (g = e.kefu), sys.isObjectValid(e.tid_key) && (b = e.tid_key), sys.isObjectValid(e.lastNodeVisible) && (_ = e.lastNodeVisible), sys.isObjectValid(e.sceneType) && (w = e.sceneType), !sys.isObjectValid(r)) {
            r = director.getScene().getChildByName("Canvas");
        }
        let C = true, y = "commondialog_node", P = 0;
        if (sys.isObjectValid(e.dialogType) && (P = e.dialogType), ToolUtils.isObjValid(r)) {
            undefined !== e.name && null !== e.name && (y = e.name);
            let a = r.getChildByName(y);
            ToolUtils.isObjValid(a) && (a.destroy(), C = false);
        }
        try {
            let e = instantiate(this.dialogPrefab), s = e.getComponent("CommonDlgAlert");
            C && s.showNodeAnim(o);
            s.setDialogType(P);
            b && s.setTidKey(b);
            d ? s.updateDlgInfo2(c, u, a, h, n) : s.updateDlgInfo1(c, u, a, h, n);
            p.length > 0 ? s.setSureButtonLableKey(p) : s.setSureButtonLableKey("reward_tips.okey");
            m.length > 0 ? s.setCancleButtonLableKey(m) : s.setCancleButtonLableKey("reward_tips.cancel");
            g && s.setKefuBtnVisible(g);
            w >= 0 && s.setSceneType(w);
            t && s.setTouchClose(t);
            ToolUtils.isObjValid(r) && (ToolUtils.isObjValid(l) && l && (sys.isObjectValid(_) ? l.active = _ : l.active = true), e.name = y, r.addChild(e));
        }
        catch (e) {
            ToolUtils.isObjValid(l) && l && (l.active = true);
            TLog.printError("createDialog error= " + e);
        }
    }
    showCommomDialog(e, a = "", t = null, r = false, l = false, s, o, n = false, d, h, c, u) {
        sys.isObjectValid(this.dialogPrefab) && this.dialogPrefab.isValid ? TweenTool.delayAct(ToolUtils.getPersistGlobalNode(), (() => {
            this.createDialog(e, a, t, r, l, s, o, n, d, h, c, u);
        }), 0.01, true) : ToolUtils.loadCommonPrefab(this.dialogPrefab, BundleNameDefined.bundle_public, "prefab/commondialog_node", (i => {
            this.dialogPrefab = i;
            this.createDialog(e, a, t, r, l, s, o, n, d, h, c, u);
        }));
    }
    setCommomDialogBtnText(e, a, t) {
        if (null == t) {
            t = director.getScene().getChildByName("Canvas");
        }
        let i = t.getChildByName("commondialog_node");
        if (ToolUtils.isObjValid(i)) {
            let t = i.getComponent("CommonDlgAlert");
            e ? t.setSureButtonWz(e) : t.setSureButtonWz(i18nMgr.shared().getValueByKey("reward_tips.okey"));
            a ? t.setCancleButtonWz(a) : t.setCancleButtonWz(i18nMgr.shared().getValueByKey("reward_tips.cancel"));
        }
    }
    hideCommomDialog(e) {
        if (ToolUtils.isObjValid(e)) {
            if (ToolUtils.isObjValid(e)) {
                let a = e.getChildByName("commondialog_node");
                ToolUtils.isObjValid(a) && a.destroy();
                let t = e.getChildByName("GameRummy_switch_notice");
                ToolUtils.isObjValid(t) && t.destroy();
                let i = e.getChildByName("comm_magic_face");
                ToolUtils.isObjValid(i) && i.destroy();
            }
            PushCenter.shared().pushEvent(PushEvent.CloseCommonAlert);
        }
        else {
            let e = director.getScene().getChildByName("Canvas").getChildByName("commondialog_node");
            ToolUtils.isObjValid(e) && e.destroy();
        }
    }
    createDialog(e, a = "", t = null, i = false, r = false, l, o, n = false, d, h, c, u) {
        if (!ToolUtils.isObjValid(d)) {
            d = director.getScene().getChildByName("Canvas");
        }
        let p = true;
        if (ToolUtils.isObjValid(d)) {
            let e = d.getChildByName("commondialog_node");
            ToolUtils.isObjValid(e) && (e.destroy(), p = false);
        }
        try {
            let s = instantiate(this.dialogPrefab), m = s.getComponent("CommonDlgAlert");
            p && m.showNodeAnim(r);
            m.setDialogType(h);
            i ? m.updateDlgInfo2(e, a, t, n) : m.updateDlgInfo1(e, a, t, n);
            l ? m.setSureButtonWz(l) : m.setSureButtonWz(i18nMgr.shared().getValueByKey("reward_tips.okey"));
            o ? m.setCancleButtonWz(o) : m.setCancleButtonWz(i18nMgr.shared().getValueByKey("reward_tips.cancel"));
            ToolUtils.isObjValid(d) && d.addChild(s);
            c && m.setTidKey(c);
            null == u || u || m.setCanback(u);
        }
        catch (e) {
            TLog.printError("createDialog error= " + e);
        }
    }
    showMiddelCommomDialog(e, a = "", t = null, i = false, r = false, l, s, o, n = 0, d = 0) {
        ToolUtils.loadCommonPrefab(null, BundleNameDefined.bundle_public, "prefab/commondialog_node", (h => {
            this.createMiddleCommDialog(h, e, a, t, i, r, l, s, o, n, d);
        }));
    }
    createMiddleCommDialog(e, a, t = "", i = null, r = false, l = false, o, n, d, h = 0, c = 0) {
        try {
            let u = instantiate(e), p = u.getComponent("CommonDlgAlert");
            if (p.showNodeAnim(l), p.updateMiddleAlertInfo(a, t, r, i, h, c), o && p.setSureButtonWz(o), n && p.setCancleButtonWz(n), !ToolUtils.isObjValid(d)) {
                d = director.getScene().getChildByName("Canvas");
            }
            if (ToolUtils.isObjValid(d)) {
                let e = d.getChildByName("commondialog_node");
                ToolUtils.isObjValid(e) && e.destroy();
            }
            ToolUtils.isObjValid(d) && d.addChild(u);
        }
        catch (e) {
            TLog.printError("showMiddelCommomDialog error= " + e);
        }
    }
    showVerifyPhoneDlg() {
    }
    openUrl(e, a = null) {
        sys.isObjectValid(this.webViewPrefab) && this.webViewPrefab.isValid ? this.createWebView(e, a) : resources.load("prefabs/webView", Prefab, ((t, i) => {
            null == t ? (this.webViewPrefab = i, this.createWebView(e, a)) : (e.h5GameId && this.hideLoading(), TLog.printMsg("loadwebview error= " + t));
        }));
    }
    createWebView(e, a = null) {
        try {
            this.webViewNode = instantiate(this.webViewPrefab);
            let t = director.getScene().getChildByName("Canvas");
            ToolUtils.isObjValid(a) && (a.active = false);
            let i = this.webViewNode.getComponent(WebViewNode);
            // A native Android WebView is rendered above Cocos. Put it offscreen
            // before attaching the prefab so its about:blank frame can never be
            // presented while the H5 document is starting.
            e.h5GameId && i.prepareH5Launch();
            t.addChild(this.webViewNode);
            this.webViewNode.setSiblingIndex(10000);
            ToolUtils.isObjValid(e.h5LaunchCover) && (e.h5LaunchCover.active = false);
            e.h5ReadyCallback = () => this.hideLoading();
            i.setWebData(e, (() => {
                ToolUtils.isObjValid(a) && (a.active = true);
            }));
            if (!e.h5GameId) {
                i.setCallback(this.onPaySuccessCallback.bind(this), this.onPayCancelCallback.bind(this));
            }
        }
        catch (error) {
            e.h5GameId && this.hideLoading();
            TLog.printError("createWebView error= " + error);
        }
    }
    onPaySuccessCallback(e) {
    }
    onPayCancelCallback() {
        this.webViewNode = null;
    }
    downLoadApk(e, a) {
        this._utilLogicTool.downLoadApk(e, a);
    }
    resetDownLoadHeadFlag() {
        this._utilLogicTool.resetDownLoadHeadFlag();
    }
    clearImagUrlPushEvent(e) {
        this._utilLogicTool.clearImagUrlPushEvent(e);
    }
    checkDownNetFileExsits(e, a) {
        if ("MOBILE_BROWSER" == sys.platform || "DESKTOP_BROWSER" == sys.platform) {
            return { ret: 0, path: e };
        }
        try {
            let t = native.fileUtils.getWritablePath() + this.NET_FILE_CATCH_FOLDER;
            native.fileUtils.isDirectoryExist(t) || native.fileUtils.createDirectory(t);
            let i = t + "/" + MD5.Instance.hex_md5(e) + "." + a;
            return native.fileUtils.isFileExist(i) ? { ret: 1, path: i } : { ret: 0, path: e };
        }
        catch (a) {
            return TLog.printError("checkDownNetFileExsits,error:", a), { ret: 0, path: e };
        }
    }
    downNetFile(e, a, t) {
        this._utilLogicTool.downNetFile(e, a, t);
    }
    downNetImage(e) {
        this._utilLogicTool.downNetImage(e);
    }
    updateNetImage(e, a, t, i, r) {
        this._utilLogicTool.updateNetImage(e, a, t, i, r);
    }
    preDownLoadHeadImg(e, a = "") {
        this._utilLogicTool.preDownLoadHeadImg(e, a);
    }
    updateHeadImg(e, a, t = "", i = size(114, 114), r = this.NORMAL_HEAD_IMAGE, l = false) {
        this._utilLogicTool.updateHeadImg(e, a, t, i, r, l);
    }
    checkIsSysHeadImg(e) {
        let a = false;
        for (let t = 1; t <= 17; t++) {
            if (e == "head_" + t + ".png") {
                a = true;
                break;
            }
        }
        let t = [101, 102];
        for (let i = 0; i <= t.length; i++) {
            if (e == "head_" + t[i] + ".png") {
                a = true;
                break;
            }
        }
        return a;
    }
    checkGenderByHeadImg(e) {
        let a = 0;
        for (let t = 1; t <= 17; t++) {
            if (e == "head_" + t + ".png" && t <= 8) {
                a = 1;
                break;
            }
        }
        return a;
    }
    uploadGtagEvent(e) {
        0 != GameConfig.WITH_GA_UPDATE_DEBUG && window.dispatchEvent && window.dispatchEvent(new Event("" + e));
    }
    uploadFBEvent(e) {
        0 != GameConfig.WITH_FB_UPDATE_DEBUG && window.dispatchEvent && window.dispatchEvent(new Event("" + e));
    }
    getFixPosX(e) {
        return view.getVisibleSizeInPixel().width / GameConfig.CONFIG_SCREEN_WIDTH * e;
    }
    getFixPosY(e) {
        return view.getVisibleSizeInPixel().height / GameConfig.CONFIG_SCREEN_HEIGHT * e;
    }
    getscaleX() {
        let e = view.getScaleX();
        return e = Math.abs(e), e;
    }
    getscaleY() {
        let e = view.getScaleY();
        return e = Math.abs(e), e;
    }
    getHeightStretch() {
        let e = view.getVisibleSizeInPixel();
        return GameConfig.CONFIG_SCREEN_WIDTH / e.width * e.height;
    }
    static phoneFormat(e) {
        return sys.isObjectValid(e) && e.length >= 10 && (e = ToolUtils.format("${0}*****${1}", e.slice(0, 3), e.slice(-2))), e;
    }
    static emailFormat(e) {
        if (sys.isObjectValid(e) && e.includes("@")) {
            let a = e.split("@");
            if (sys.isObjectValid(a) && a.length > 1) {
                e = ToolUtils.format("${0}******", a[0].slice(0, 3));
                for (let t = 1, i = a.length; t < i; t++) {
                    e = ToolUtils.format("${0}@${1}", e, a[t]);
                }
            }
        }
        return e;
    }
    doReportActEvt(e, a, t, i = 0, r = "", l = 0) {
        this._utilLogicTool.doReportActEvt(e, a, t, i, r, l);
    }
    doJumpLogic(a, t = null, r) {
        let l = false, o = false, h = ToolUtils.getIsInRoom() ? 2 : 1;
        // Keep report metadata in its own object. Cocos 3.7.2 can otherwise
        // drop the outer scalar declarations when switch cases declare local
        // variables with the same minified names, leaving free `n`/`d`
        // references in the published bundle.
        const jumpReport = { eventId: -1, linkId: -1 };
        switch ((sys.isObjectValid(r) && (sys.isObjectValid(r.isNext) && (l = r.isNext), sys.isObjectValid(r.bWithTip) && (o = r.bWithTip), sys.isObjectValid(r.reportScene) && (h = r.reportScene), sys.isObjectValid(r.reportEvtId) && (jumpReport.eventId = r.reportEvtId), sys.isObjectValid(r.link_id) && (jumpReport.linkId = r.link_id)), a = Number(a), jumpReport.eventId >= 0 && (jumpReport.linkId > 0 ? this.doReportActEvt(a, h, jumpReport.eventId, jumpReport.linkId) : this.doReportActEvt(a, h, jumpReport.eventId)), a != PushEvent.JUMP_TO_CASH_ROOM && a != PushEvent.JUMP_TO_PRACTICE_ROOM && a != PushEvent.JUMP_TO_PRIVATE_ROOM && (null == t && (t = {}), t.reportScene = h, t.link_id = jumpReport.linkId > 0 ? jumpReport.linkId : sys.now()), a)) {
            case PushEvent.JUMP_TO_ROOM:
                if (User.shared().checkCanPlayCashGame(CheckModule.CASH_PLAY)) {
                    try {
                        Utils.shared().showLoadTable(Number(t.vid), t.gtype, null, null, null, null, null, 1);
                    }
                    catch (e) {
                    }
                }
                break;
            case PushEvent.JUMP_TO_CASH_ROOM:
                if (null != t && null != t) {
                    let e = Number(t.player);
                    if (2 == e || 6 == e) {
                        let a = 2 == e ? 0 : 1, i = Number(t.pool_game), r = Number(t.deals);
                        if (1 != Number(t.play) || 101 != i && 201 != i) {
                            if (2 != Number(t.play) || 3 != r && 6 != r) {
                                Number(t.mode) > 1 ? PushCenter.shared().pushEvent(GameConfig.Jump_Hall_Choose_game, ["rummy", t.play, a, t.mode, t.show_game_introduce]) : PushCenter.shared().pushEvent(GameConfig.Jump_Hall_Choose_game, ["rummy", t.play, a, Number.NaN, t.show_game_introduce]);
                            }
                            else {
                                let e = 3 == r ? 1 : 0;
                                e = 6 == r ? 2 : e;
                                PushCenter.shared().pushEvent(GameConfig.Jump_Hall_Choose_game, ["rummy", 2, a, e, t.show_game_introduce]);
                            }
                        }
                        else {
                            let e = 101 == i ? 0 : 1;
                            PushCenter.shared().pushEvent(GameConfig.Jump_Hall_Choose_game, ["rummy", 1, a, e, t.show_game_introduce]);
                        }
                    }
                    else {
                        PushCenter.shared().pushEvent(GameConfig.Jump_Hall_Choose_game, ["rummy", t.play, Number.NaN, Number.NaN, t.show_game_introduce]);
                    }
                }
                else {
                    PushCenter.shared().pushEvent(GameConfig.Jump_Hall_Choose_game, ["rummy", Number.NaN, Number.NaN, Number.NaN, Number.NaN]);
                }
                break;
            case PushEvent.JUMP_TO_MATCH_ROOM:
                sys.isObjectValid(t) && sys.isObjectValid(t.race_id) ? User.shared().sendJoinMatch({ raceid: t.race_id, is_detail: 1 }) : PushCenter.shared().pushEvent(GameConfig.Jump_Hall_Choose_game, ["match"]);
                break;
            case PushEvent.JUMP_TO_PRIVATE_ROOM:
                t ? undefined !== t.play && null !== t.play || (t.play = 0) : t = { play: 0 }, PushCenter.shared().pushEvent(GameConfig.Jump_Hall_Choose_game, ["buddy", t.play]);
                break;
            case PushEvent.JUMP_TO_PRACTICE_ROOM:
                t ? undefined !== t.play && null !== t.play || (t.play = 0) : t = { play: 0 };
                let n = Number(t.player);
                if (2 == n || 6 == n) {
                    let e = 2 == n ? 0 : 1, a = Number(t.pool_game), i = Number(t.deals);
                    if (1 != Number(t.play) || 101 != a && 201 != a) {
                        if (2 != Number(t.play) || 3 != i && 6 != i) {
                            Number(t.mode) > 1 ? PushCenter.shared().pushEvent(GameConfig.Jump_Hall_Choose_game, ["prictice", t.play, e, t.mode, t.show_game_introduce]) : PushCenter.shared().pushEvent(GameConfig.Jump_Hall_Choose_game, ["prictice", t.play, e, Number.NaN, t.show_game_introduce]);
                        }
                        else {
                            let a = 3 == i ? 1 : 0;
                            a = 6 == i ? 2 : a;
                            PushCenter.shared().pushEvent(GameConfig.Jump_Hall_Choose_game, ["prictice", 2, e, a, t.show_game_introduce]);
                        }
                    }
                    else {
                        let i = 101 == a ? 0 : 1;
                        PushCenter.shared().pushEvent(GameConfig.Jump_Hall_Choose_game, ["prictice", 1, e, i, t.show_game_introduce]);
                    }
                }
                else {
                    PushCenter.shared().pushEvent(GameConfig.Jump_Hall_Choose_game, ["prictice", t.play, Number.NaN, Number.NaN, t.show_game_introduce]);
                }
                break;
            case PushEvent.JUMP_TO_INVITE:
                PushCenter.shared().pushEvent(GameConfig.Jump_Hall_Tab_View, "3");
                break;
            case PushEvent.JUMP_TO_STORE:
                Utils.shared().showStoreView(t);
                break;
            case PushEvent.JUMP_TO_WALLET_RECORD:
                Utils.shared().showWalletRecordView(1);
                break;
            case PushEvent.JUMP_TO_URL:
                t && t.url && sys.openURL(ToolUtils.isSafeString(t.url));
                break;
            case PushEvent.JUMP_TO_CLUB:
                if (1 == User.shared().temp_pingbi.club) {
                    return void (o && Utils.shared().showToast("Coming soon", 2));
                }
                Utils.shared().showMemberShipView(t);
                break;
            case PushEvent.JUMP_TO_EMAIL:
                if (1 === User.shared().temp_pingbi.email) {
                    return void (o && Utils.shared().showToast("Coming soon", 2));
                }
                let d = null;
                t && t.node && (d = t.node), Utils.shared().showMailView(d);
                break;
            case PushEvent.JUMP_TO_MOBILE:
                PushCenter.shared().pushEvent(PushEvent.ShowChangeBindMobile, t);
                break;
            case PushEvent.JUMP_TO_HOW_TO_PLAY:
                Utils.shared().showRuleHelpView();
                break;
            case PushEvent.JUMP_TO_CONTACT_US:
                let h = { url: ToolUtils.contact_url, title: i18nMgr.shared().getValueByKey("contact_us.contact_us") };
                Utils.shared().openUrl(h);
                break;
            case PushEvent.Custom_TO_GSTRULE:
                {
                    let a = i18nMgr.shared().getValueByKey("menu.gst"), t = { url: ToolUtils.gst_url, title: a.toUpperCase() };
                    Utils.shared().openUrl(t);
                }
                break;
            case PushEvent.JUMP_TO_ABOUT_US:
                if (ToolUtils.isSafeString(ToolUtils.about_url).length > 0) {
                    let a = { url: ToolUtils.about_url, title: i18nMgr.shared().getValueByKey("menu.title_aboutus") };
                    a && a.url && Utils.shared().openUrl(a);
                }
                break;
            case PushEvent.JUMP_TO_SHARE_APP:
                ToolUtils.isSafeString(User.shared().data.share_app).length > 0 && AppInfo.shared().shareWebPage(ToolUtils.isSafeString(User.shared().data.recommended));
                break;
            case PushEvent.JUMP_TO_RECOMMENDED:
                ToolUtils.isSafeString(User.shared().data.recommended).length > 0 && sys.openURL(ToolUtils.isSafeString(User.shared().data.recommended));
                break;
            case PushEvent.JUMP_TO_SETTING:
                PushCenter.shared().pushEvent(GameConfig.Jump_Hall_Setting);
                break;
            case PushEvent.JUMP_TO_WITHDRAWAL:
                Utils.shared().showDepositTransferView();
                break;
            case PushEvent.JUMP_TO_USERINFO:
                if (1 === User.shared().temp_pingbi.userinfo) {
                    return void (o && Utils.shared().showToast("Coming soon", 2));
                }
                Utils.shared().showUserInfoView();
                break;
            case PushEvent.JUMP_TO_FEEDBACK:
            case PushEvent.JUMP_TO_FEEDBACK_LOGIN:
                this.showContactUsView();
                break;
            case PushEvent.JUMP_TO_NOVICESTASK:
            case PushEvent.JUMP_TO_NEW_NOVICESTASK:
                if (1 === User.shared().temp_pingbi.xstask) {
                    return void (o && Utils.shared().showToast("Coming soon", 2));
                }
                PushCenter.shared().pushEvent(PushEvent.ShowNovicesTaskView, { exe: t, isNext: l });
                break;
            case PushEvent.JUMP_TO_BINDFB:
                AppInfo.shared().startFacebookLogin("Utils", this, "doFaceBookLogic", "");
                break;
            case PushEvent.JUMP_TO_GONGGAO:
                let c = { exe: t, isNext: l };
                PushCenter.shared().pushEvent(PushEvent.JUMP_TO_ANNOUNCEMENT, c);
                break;
            case PushEvent.JUMP_TO_UPDATE_GUIDE:
                {
                    let a = { exe: t, isNext: l };
                    Utils.shared().showUpdateGuideView(a);
                }
                break;
            case PushEvent.JUMP_TO_BACKCARDTASK:
                Utils.shared().showBackCardTask({ exe: t, isNext: l });
                break;
            case PushEvent.JUMP_TO_SCLB:
                if (1 === User.shared().temp_pingbi.sclb) {
                    return void (o && Utils.shared().showToast("Coming soon", 2));
                }
                sys.isObjectValid(t.ext) && !sys.isObjectValid(User.shared().firstrechargeData) && (User.shared().firstrechargeData = t.ext), t.isNext = l, PushCenter.shared().pushEvent(PushEvent.ShowFirstRecharge, t);
                break;
            case PushEvent.JUMP_TO_COUPON_ACT:
                t.isNext = l, !!sys.isObjectValid(r) && r.needReqPage ? HttpManager.shared().doGetCommonRequest(null, "Activity.Act_140.page", ((e, a, i) => {
                    if (200 == i) {
                        let e = ToolUtils.parseJson(a);
                        0 == e.ret && (t.ext = e.data, PushCenter.shared().pushEvent(PushEvent.ShowCouponAct, t));
                    }
                })) : PushCenter.shared().pushEvent(PushEvent.ShowCouponAct, t);
                break;
            case PushEvent.JUMP_TO_TwentyFourRecharge:
                sys.isObjectValid(t.ext) && (User.shared().twentyfourrechargeData = t.ext), t.isNext = l, PushCenter.shared().pushEvent(PushEvent.ShowTwentyFourRecharge, t);
                break;
            case PushEvent.JUMP_TO_RebateRecharge:
                sys.isObjectValid(t.ext) && !sys.isObjectValid(User.shared().rebaterechargeData) && (User.shared().rebaterechargeData = t.ext), t.isNext = l, PushCenter.shared().pushEvent(PushEvent.ShowRebateRecharge, t);
                break;
            case PushEvent.JUMP_TO_BuyOneGetThree:
                sys.isObjectValid(t.ext) && !sys.isObjectValid(User.shared().payOneForThreeData) && (User.shared().payOneForThreeData = t.ext), t.isNext = l, PushCenter.shared().pushEvent(PushEvent.ShowBuyOneGetThree, t);
                break;
            case PushEvent.JUMP_TO_ConsecutiveGift:
                sys.isObjectValid(t.ext) && !sys.isObjectValid(User.shared().consecutiveGiftData) && (User.shared().consecutiveGiftData = t.ext), t.isNext = l, PushCenter.shared().pushEvent(PushEvent.ShowConsecutiveGift, t);
                break;
            case PushEvent.JUMP_TO_LOGIN:
                User.shared().showLogin();
                break;
            case PushEvent.JUMP_TO_CREATE_PSW:
                PushCenter.shared().pushEvent(PushEvent.ShowCreatePassWordView, { isNext: l });
                break;
            case PushEvent.JUMP_TO_PrivacyPolicy:
                let u = i18nMgr.shared().getValueByKey("login.pp"), p = { url: ToolUtils.pp_url, title: u.toUpperCase() };
                Utils.shared().openUrl(p);
                break;
            case PushEvent.JUMP_TO_Refund:
                {
                    let a = i18nMgr.shared().getValueByKey("menu.refund"), t = { url: ToolUtils.refund_url, title: a.toUpperCase() };
                    Utils.shared().openUrl(t);
                }
                break;
            case PushEvent.JUMP_TO_LOGIN_RESPONSIBLY:
                let f = i18nMgr.shared().getValueByKey("utlis.responsible"), m = { url: ToolUtils.responsible_url, title: f.toUpperCase() };
                Utils.shared().openUrl(m);
                break;
            case PushEvent.JUMP_TO_TDSPolicy:
                let g = i18nMgr.shared().getValueByKey("utlis.TDS"), b = { url: ToolUtils.tds_policy_url, title: g.toUpperCase() };
                Utils.shared().openUrl(b);
                break;
            case PushEvent.JUMP_TO_RESPONSIBLY:
                if (ToolUtils.isSafeString(User.shared().data.help_responsible_url).length > 0) {
                    let a = i18nMgr.shared().getValueByKey("utlis.responsible"), t = { url: User.shared().data.help_responsible_url, title: a.toUpperCase() };
                    Utils.shared().openUrl(t);
                }
                break;
            case PushEvent.JUMP_TO_TREASURE_HUNT:
                t.isNext = l, t.treasureType = 0, Utils.shared().showTreasureHunt(t);
                break;
            case PushEvent.JUMP_TO_CHIP_TREASURE_HUNT:
                t.isNext = l, t.treasureType = 1, Utils.shared().showTreasureHunt(t);
                break;
            case PushEvent.JUMP_TO_Act_FlopCash:
                t.isNext = l, Utils.shared().showFlopCashAct(t);
                break;
            case PushEvent.JUMP_TO_LOTTERYACT:
                t.isNext = l, PushCenter.shared().pushEvent(PushEvent.ShowLotteryAct, t);
                break;
            case PushEvent.JUMP_TO_HAPPYFLOP:
                t.isNext = l, Utils.shared().showHappyFlopView(t);
                break;
            case PushEvent.JUMP_TO_WEEK_MONTH:
                t.isNext = l, Utils.shared().showWeekMonthView(t);
                break;
            case PushEvent.JUMP_TO_Gullak:
                t.isNext = l, Utils.shared().showGullakView(t);
                break;
            case PushEvent.JUMP_TO_REDEEM_CODE:
                t.isNext = l, Utils.shared().showRedeemCodeView(t);
                break;
            case PushEvent.JUMP_TO_QUICKCHARGE:
                this.showQuick_recharge_Package(t);
                break;
            case PushEvent.JUMP_TO_QUICKCHARGE_YES11:
            case PushEvent.JUMP_TO_QUICKCHIPCHARGE_YES11:
                sys.isObjectValid(t) && !sys.isObjectValid(t.parent_node) && (t.parent_node = director.getScene().getChildByName("Canvas")), this.showHallQuickChargeAlert(t);
                break;
            case PushEvent.JUMP_TO_HAPPYHOLI:
                t.isNext = l, Utils.shared().showHappyHoliView(t);
                break;
            case PushEvent.JUMP_TO_Adventrue:
                t.isNext = l, this.showAdvancedGift(t);
                break;
            case PushEvent.JUMP_TO_Receipt:
                t.isNext = l, t.enterReceipt = true, this.showStoreView(t);
                break;
            case PushEvent.JUMP_TO_LeaderBoards:
                t.isNext = l, this.showLeaderBoardsPop(t);
                break;
            case PushEvent.JUMP_TO_Treasure:
                t.isNext = l, this.showTreasureView(t);
                break;
            case PushEvent.JUMP_TO_SuperVip:
                t.isNext = l, this.showSuperVip(t);
                break;
            case PushEvent.JUMP_TO_InviteCheck:
                t.isNext = l, this.showInviteRewardTaskPop(t);
                break;
            case PushEvent.JUMP_TO_QuickChargeChip:
                this.showChipChargeAlert(t);
                break;
            case PushEvent.JUMP_TO_BonusChipGift:
                t.isNext = l, this.showBonusGift(t);
                break;
            case PushEvent.JUMP_TO_CHIPBANKRUPT:
                this.showChipBankruptAlert(t);
                break;
            case PushEvent.JUMP_TO_DAILYLOGIN:
                t.isNext = l, this.showDailyCheckinActivity(t);
                break;
            case PushEvent.JUMP_TO_TOURNESFORMAT:
            case PushEvent.JUMP_TO_Act_BestHighScore:
            case PushEvent.JUMP_TO_Act_Wild:
            case PushEvent.JUMP_TO_Act_Multiple:
            case PushEvent.JUMP_TO_Act_MemberShipRpExchange:
            case PushEvent.JUMP_TO_Act_RechangeCoupon:
            case PushEvent.JUMP_TO_FreeMatch:
                t.isNext = l, t.act_id = a, this.showEventPromotionView(t);
                break;
            case PushEvent.JUMP_TO_LeaderBoardsNewReward:
            case PushEvent.JUMP_TO_LeaderBoardsReward:
                t.isNext = l, t.act_id = a, this.showLeaderboardReward(t);
                break;
            case PushEvent.JUMP_TO_GameRatingAlert:
                t.isNext = l, this.showGameRatingAlert(t);
                break;
            case PushEvent.JUMP_TO_RestartGift:
                t.isNext = l, ToolUtils.getIsInRoom() ? PushCenter.shared().pushEvent(PushEvent.ShowRestartGift, t) : ToolUtils.judgeIfInHall() && (t.parent_node = director.getScene().getChildByName("Canvas"), this.showRestartGiftAlert(t));
                break;
            case PushEvent.JUMP_TO_DailyFireSale:
                sys.isObjectValid(t.ext) && !sys.isObjectValid(User.shared().dailyFireSaleData) && (User.shared().dailyFireSaleData = t.ext), t.isNext = l, PushCenter.shared().pushEvent(PushEvent.ShowDailyFireSale, t);
                break;
            case PushEvent.JUMP_TO_EMAIL_BIND:
                PushCenter.shared().pushEvent(PushEvent.ShowChangeBindMobile, { lastNode: null, nType: 2, bShowPushAnim: true });
                break;
            case PushEvent.JUMP_TO_Yes11:
                t.isNext = l, this.showSportCricket_main(t);
                break;
            default: this.doCustomJump(a, t, l);
        }
    }
    getTawkFeedbackUrl(e) {
        let a = "";
        return 1 == e ? a = User.shared().tawk_url_1 : 2 == e ? a = User.shared().tawk_url_2 : 3 == e ? a = User.shared().tawk_url_3 : 4 == e ? a = User.shared().tawk_url_4 : 5 == e ? a = User.shared().tawk_url_5 : 6 == e ? a = User.shared().tawk_url_6 : 7 == e ? a = User.shared().tawk_url_7 : 8 == e ? a = User.shared().tawk_url_8 : 9 == e ? a = User.shared().tawk_url_9 : 10 == e ? a = User.shared().tawk_url_10 : 11 == e ? a = User.shared().tawk_url_11 : 12 == e && (a = ToolUtils.tawk_url_12), sys.isObjectValid(a) && a.length > 0 ? a : "";
    }
    doCustomJump(a, t = null, r = false) {
        switch (a) {
            case PushEvent.Custom_Delete_Ios_Account:
                if (ToolUtils.isSafeString(User.shared().data.ios_delete_acc_url).length > 0) {
                    let a = i18nMgr.shared().getValueByKey("menu.delete_account"), t = { url: User.shared().data.ios_delete_acc_url, title: a.toUpperCase() };
                    Utils.shared().openUrl(t);
                }
                break;
            case PushEvent.Custom_TO_TC:
                if (ToolUtils.isSafeString(ToolUtils.tos_url).length > 0) {
                    let a = i18nMgr.shared().getValueByKey("login.ts"), t = { url: ToolUtils.tos_url, title: a.toUpperCase() };
                    Utils.shared().openUrl(t);
                }
                break;
            case PushEvent.Custom_TO_LevelUpSuperVip:
                if (sys.isObjectValid(t) && sys.isObjectValid(User.shared().superVipUpMsg)) {
                    let a = false, t = [];
                    if (t.type = CUSTOM_REWARD_ENUM.VIP_LEVEL, t.num = User.shared().superVipUpMsg.new_show_level || 0, User.shared().superVipUpMsg.list) {
                        let e = User.shared().superVipUpMsg.list.length;
                        for (let i = 0; i < e; i++) {
                            if (User.shared().superVipUpMsg.list[i].type == t.type) {
                                a = true;
                                break;
                            }
                        }
                    }
                    a || User.shared().superVipUpMsg.list.unshift(t);
                    Utils.shared().showRewardTips(User.shared().superVipUpMsg, (() => {
                        PushCenter.shared().pushEvent(PushEvent.Update_NextPopActivity);
                    }), 1, "reward_tips.okey", "", (() => {
                        User.shared().superVipUpMsg = null;
                        User.shared().requestSuperVipConfirmUpgradePop();
                    }));
                }
                break;
            case PushEvent.Custom_TO_MemberShipUpgrade:
                if (sys.isObjectValid(User.shared().clubUpgradeMsg)) {
                    let e = User.shared().clubUpgradeMsg;
                    this.showMemberShipUpgradeView(e);
                }
                break;
            case PushEvent.Custom_TO_MOBILE_BIND_GUIDE:
                this.showMobileBindGuide(t);
                break;
            case PushEvent.Custom_TO_TAWK_FEEDBACK:
                this.showTawkFeedback(t);
                break;
            case PushEvent.Custom_TO_TREASURE_RECHARGE:
                this.showTreasureRecharge(t);
                break;
            case PushEvent.Custom_TO_RESPONSIBLY:
                if (ToolUtils.isSafeString(User.shared().faqMainData.responsible_url).length > 0) {
                    let a = i18nMgr.shared().getValueByKey("utlis.responsible"), t = { url: User.shared().faqMainData.responsible_url, title: a.toUpperCase() };
                    Utils.shared().openUrl(t);
                }
                break;
            default: r && PushCenter.shared().pushEvent(PushEvent.Update_NextPopActivity);
        }
    }
    doFaceBookLogic(a) {
        400 != a && 401 != a && (User.shared().access_token = a, Utils.shared().showLoading(10, true, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3);
        })), HttpManager.shared().doBlindFBAccount(a, this.listenBlindFbCallback.bind(this)));
    }
    listenBlindFbCallback(a, t, i) {
        if (Utils.shared().hideLoading(), 200 != i) {
            ;
        }
        else {
            try {
                let a = ToolUtils.parseJson(t);
                0 == a.ret ? (User.shared().loginType = "1", ToolUtils.saveData("logintype", "1"), ToolUtils.isSafeString(a.data.name).length > 0 && (User.shared().data.name = a.data.name), a.data.avatar_url && (User.shared().data.avatar_url = a.data.avatar_url), a.data.avatar && (User.shared().data.avatar = a.data.avatar), User.shared().data.hasBlindFb = 1, PushCenter.shared().pushEvent(GameConfig.Update_Name), PushCenter.shared().pushEvent(PushEvent.updateBannerList)) : a.desc && a.desc.length > 0 && Utils.shared().showToast(a.desc, 3);
            }
            catch (e) {
            }
        }
    }
    changeHallActVisibile(e) {
    }
    hideHallNode() {
        this._utilLogicTool.hideHallNode();
    }
    hideRummyNode(e = null) {
        this._utilLogicTool.hideRummyNode(e);
    }
    StartNodeShowAnim(e) {
        ToolUtils.isObjValid(e) && (e.setScale(v3(0.2, 0.2, 0.2)), TweenTool.scaleTo(e, 0.2, v3(1, 1, 1), "backOut", true, (() => {
            e.setScale(v3(1, 1, 1));
        })));
    }
    judgeIfHasNode(e) {
        let a = director.getScene().getChildByName("Canvas"), t = false;
        if (a) {
            let i = a.getChildByName(e);
            ToolUtils.isObjValid(i) && (t = true);
        }
        return t;
    }
    parseDianzanNumber(e) {
        let a = Number(e);
        if (a < 1000) {
            return a.toString();
        }
        if (a <= 10000) {
            return (a / 1000).toFixed(1) + "K";
        }
        return "10K+";
    }
    getSafeAreaRect() {
        return null == this.safeAreaRect && (this.safeAreaRect = sys.getSafeAreaRect()), this.safeAreaRect;
    }
    getIconNameByType(e, a = "") {
        return 0 == e ? i18nMgr.shared().getValueByKey("match_info.cash") : 1 == e ? i18nMgr.shared().getValueByKey("userinfo.bonus") : 2 == e ? 1 == User.shared().showNewDailyTask || 1 == User.shared().showBackTask ? i18nMgr.shared().getValueByKey("store.ticket") : i18nMgr.shared().getValueByKey("store.active") : 3 == e || 4 == e || 5 == e || 6 == e ? i18nMgr.shared().getValueByKey("reward_tips.coupons") : 7 == e ? i18nMgr.shared().getValueByKey("reward_tips.practice_chips") : 8 == e ? i18nMgr.shared().getValueByKey("store_receipt.receipt") : 10 == e ? i18nMgr.shared().getValueByKey("tournament.ticket") : ToolUtils.isSafeString("").length > 0 ? "" : a;
    }
    showKycVerifySucTip(a, t = "") {
        let i = {};
        i.msg = t;
        i.list = [];
        for (let t = 0, r = a.length; t < r; t++) {
            const r = a[t];
            let l = [];
            l.num = r.amount;
            l.type = r.type;
            l.php_data = r;
            l.name = Utils.shared().getIconNameByType(r.type, r.desc || "");
            i.list[t] = l;
        }
        Utils.shared().showRewardTips(i, (e => {
        }), 3, "reward_tips.okey");
    }
    isRewardTipsShow() {
        let e = director.getScene().getChildByName("Canvas");
        if (ToolUtils.isObjValid(e)) {
            let a = e.getChildByName("reward_tips");
            if (ToolUtils.isObjValid(a)) {
                return true;
            }
        }
        return false;
    }
    showRewardTips(e, a, t, l, o, n) {
        let d = director.getScene().getChildByName("Canvas"), h = 0;
        if (ToolUtils.isObjValid(d)) {
            let e = d.getChildByName("reward_tips");
            ToolUtils.isObjValid(e) && (e.active = false, e.destroy(), e = null, h = game.frameTime);
        }
        setTimeout((() => {
            let r = "reward_tips";
            4 == t ? r = "reward_tips_10Cash" : 7 == t && (r = "reward_tips_chip_bankrupt");
            sys.isObjectValid(this.rewardTipsPrefab) && this.rewardTipsPrefab.isValid ? this.createRewardTips(d, r, e, a, t, l, o, n) : ToolUtils.loadCommonPrefab(null, BundleNameDefined.bundle_public, "prefab/reward_tips", (i => {
                this.rewardTipsPrefab = i;
                this.createRewardTips(d, r, e, a, t, l, o, n);
            }));
        }), h);
    }
    createRewardTips(e, a, t, i, r, l, s, o) {
        if (ToolUtils.isObjValid(e)) {
            let n = e.getChildByName("adView");
            if (ToolUtils.isObjValid(n)) {
                return;
            }
            let d = e.getChildByName(a);
            if (!ToolUtils.isObjValid(d)) {
                try {
                    let n = instantiate(this.rewardTipsPrefab);
                    n.name = a;
                    e.addChild(n);
                    4 == r && n.setSiblingIndex(9999999);
                    7 == r && (t.msg2 = i18nMgr.shared().getValueByKey("reward_tips.free_chip"));
                    n.getComponent("RewardTips").initData(t, i, r, l, s, o);
                }
                catch (e) {
                    TLog.printError("createRewardTips error= " + e);
                }
            }
        }
    }
    getDeviceRecodeTime(e = 0) {
        let a = new Date;
        return e > 0 && a.setTime(e), { year: a.getFullYear() + "", month: a.getMonth() + 1, day: a.getDate() };
    }
    showBroadCastView(e) {
        if (null == e) {
            let a = director.getScene();
            e = a.getChildByName("Canvas");
        }
        sys.isObjectValid(this.broadCastPrefab) && this.broadCastPrefab.isValid ? this.createBroadCastView(e) : resources.load("prefabs/broadcast", Prefab, ((a, t) => {
            null == a ? (this.broadCastPrefab = t, this.createBroadCastView(e)) : TLog.printError("showBroadCastView error= " + a);
        }));
    }
    createBroadCastView(e) {
        if (ToolUtils.isObjValid(e) && null == e.getChildByName("broadcast")) {
            try {
                let a = instantiate(this.broadCastPrefab);
                a.name = "broadcast";
                e.addChild(a);
                let t = a.getComponent(BroadCast);
                t.setAutoHide(true);
                t.setDirectHide(false);
            }
            catch (e) {
                TLog.printError("create BroadCastView error= " + e);
            }
        }
    }
    showWithdrawConfirmView(e, a = null) {
        ToolUtils.loadCommonPrefab(this.withdrawConfirmPrefab, BundleNameDefined.bundle_wallet, "prefab/withdraw_confirm", (t => {
            this.withdrawConfirmPrefab = t;
            try {
                let t = director.getScene().getChildByName("Canvas");
                if (null == t.getChildByName("WithdrawConfirm")) {
                    let i = instantiate(this.withdrawConfirmPrefab);
                    i.name = "WithdrawConfirm";
                    t.addChild(i);
                    i.getComponent("WithdrawConfirm").initData(e, a);
                }
            }
            catch (e) {
                TLog.printError("createWithdrawView error= " + e);
            }
        }));
    }
    showWithdrawMainConfirmView(e, a) {
        ToolUtils.loadCommonPrefab(this.withdrawMainConfirmPrefab, BundleNameDefined.bundle_wallet, "prefab/withdraw_main_confirm", (t => {
            try {
                this.withdrawMainConfirmPrefab = t;
                let i = director.getScene().getChildByName("Canvas");
                if (null == i.getChildByName("WithdrawConfirm")) {
                    let t = instantiate(this.withdrawMainConfirmPrefab);
                    t.name = "WithdrawMainConfirm";
                    i.addChild(t);
                    t.getComponent("WithdrawMainConfirm").initData(e, a);
                }
            }
            catch (e) {
                TLog.printError("createWithdrawView error= " + e);
            }
        }));
    }
    showWithdrawEditView(e = null, a, t = null) {
        ToolUtils.loadCommonPrefab(this.withdrawEditPrefab, BundleNameDefined.bundle_wallet, "prefab/Withdrawal_Edit", (i => {
            try {
                this.withdrawEditPrefab = i;
                let r = director.getScene().getChildByName("Canvas");
                if (null == r.getChildByName("WithdrawEdit")) {
                    ToolUtils.isObjValid(e) && (e.active = false);
                    let i = instantiate(this.withdrawEditPrefab);
                    i.name = "Withdrawal_Edit";
                    r.addChild(i);
                    i.getComponent("Withdrawal_Edit").initData(a, t);
                }
            }
            catch (e) {
                TLog.printError("createWithdrawEidtView error= " + e);
            }
        }));
    }
    showWithdrawManageView(e = null) {
        ToolUtils.loadCommonPrefab(this.withdrawManagePrefab, BundleNameDefined.bundle_wallet, "prefab/withdraw_manage", (a => {
            this.withdrawManagePrefab = a;
            try {
                let a = director.getScene().getChildByName("Canvas");
                if (null == a.getChildByName("ManageAccounts")) {
                    ToolUtils.isObjValid(e) && (e.active = false);
                    let t = instantiate(this.withdrawManagePrefab);
                    t.name = "ManageAccounts";
                    a.addChild(t);
                    t.getComponent("ManageAccounts").initData((() => {
                        ToolUtils.isObjValid(e) && (e.active = true);
                    }));
                }
            }
            catch (e) {
                TLog.printError("createWithdrawManageView error= " + e);
            }
        }));
    }
    showWithdrawDeleteView(e, a = null) {
        ToolUtils.loadCommonPrefab(this.withdrawDeletePrefab, BundleNameDefined.bundle_wallet, "prefab/withdraw_delete", (t => {
            try {
                this.withdrawDeletePrefab = t;
                let i = director.getScene().getChildByName("Canvas");
                if (null == i.getChildByName("WithdrawDelete")) {
                    let t = instantiate(this.withdrawDeletePrefab);
                    t.name = "WithdrawDelete";
                    i.addChild(t);
                    t.getComponent("WithdrawDelete").initData(e, a);
                }
            }
            catch (e) {
                TLog.printError("createWithdrawDeleteView error= " + e);
            }
        }));
    }
    showWithdrawAddView(e = null, a = null, t = null) {
    }
    checkRewardShowTop(e) {
        this.moveNodeToTop(e, "reward_tips");
        this.moveNodeToTop(e, "commondialog_reward_tips");
        this.moveNodeToTop(e, "superVip_levelup");
        this.moveNodeToTop(e, "ToastNode");
        this.moveNodeToTop(e, "reward_tips_chip_bankrupt");
    }
    showCouponActView(e, a) {
        if (director.getScene().name == BundleNameDefined.switch_scence) {
            return;
        }
        let t = "prefab/coupon_package";
        ToolUtils.getIsInRoom() && (t = "prefab/coupon_package_game");
        ToolUtils.loadCommonPrefab(null, BundleNameDefined.bundle_firstRecharge, t, (i => {
            try {
                if ("prefab/coupon_package" == t && !ToolUtils.judgeIfInHall()) {
                    return;
                }
                if ("prefab/coupon_package_game" == t && !ToolUtils.getIsInRoom()) {
                    return;
                }
                this.couponActPrefab = i;
                ToolUtils.isObjValid(e) || (e = director.getScene().getChildByName("Canvas"));
                let r = e.getChildByName("coupon_package");
                if (!ToolUtils.isObjValid(r)) {
                    r = instantiate(this.couponActPrefab);
                    r.name = "coupon_package";
                    r.getComponent("CouponPackageAct").initParaData(a);
                    r.parent = e;
                    this.checkRewardShowTop(e);
                }
            }
            catch (e) {
                TLog.printError("showCouponActView error:" + e);
            }
        }));
    }
    showFirstRechargeView(e, a, t = 0) {
        if (director.getScene().name == BundleNameDefined.switch_scence) {
            return;
        }
        let i = "prefab/first_buy_old";
        ToolUtils.getIsInRoom() && (i = "prefab/first_buy_game");
        2 == User.shared().first_recharge_type && (i = "prefab/first_buy");
        ToolUtils.loadCommonPrefab(null, BundleNameDefined.bundle_firstRecharge, i, (r => {
            try {
                if (1 == User.shared().data.first_recharge) {
                    if ("prefab/first_buy_old" == i && !ToolUtils.judgeIfInHall()) {
                        return;
                    }
                    if ("prefab/first_buy_game" == i && !ToolUtils.getIsInRoom()) {
                        return;
                    }
                }
                if (this.firstRechargePrefab = r, ToolUtils.judgeIfInScene(BundleNameDefined.switch_scence)) {
                    return;
                }
                ToolUtils.isObjValid(e) || (e = director.getScene().getChildByName("Canvas"));
                let l = e.getChildByName("FirstRecharge");
                if (!ToolUtils.isObjValid(l)) {
                    l = instantiate(this.firstRechargePrefab);
                    l.name = "FirstRecharge";
                    l.getComponent("FirstBuy").initParaData(a, t);
                    l.parent = e;
                    this.checkRewardShowTop(e);
                }
            }
            catch (e) {
                TLog.printError("showFirstRechargeView error:" + e);
            }
        }));
    }
    showTwentyFourRechargeView(e, a, t = 0) {
        if (director.getScene().name == BundleNameDefined.switch_scence) {
            return;
        }
        let i = ToolUtils.judgeIfInHall();
        ToolUtils.loadCommonPrefab(this.twentyFourRechargePrefab, BundleNameDefined.bundle_firstRecharge, "prefab/wholeday_gift", (r => {
            if (this.twentyFourRechargePrefab = r, i) {
                if (!ToolUtils.judgeIfInHall()) {
                    return;
                }
            }
            else if (!ToolUtils.judgeIfInRummy()) {
                return;
            }
            try {
                if (director.getScene().name == BundleNameDefined.switch_scence) {
                    return;
                }
                let i = (e = director.getScene().getChildByName("Canvas")).getChildByName("TwentyFourRecharge");
                if (!ToolUtils.isObjValid(i)) {
                    i = instantiate(this.twentyFourRechargePrefab);
                    i.name = "TwentyFourRecharge";
                    i.getComponent("WholeDayGift").initParaData(a, t);
                    i.parent = e;
                    this.checkRewardShowTop(e);
                }
            }
            catch (e) {
                TLog.printError("showTwentyFourRechargeView error:" + e);
            }
        }));
    }
    showConsecutiveGiftView(e, a, t = 0) {
        if (director.getScene().name == BundleNameDefined.switch_scence) {
            return;
        }
        let i = "prefab/endlessbenefitsgift";
        ToolUtils.getIsInRoom() && (i = "prefab/endlessbenefitsgift_game");
        ToolUtils.loadCommonPrefab(null, BundleNameDefined.bundle_firstRecharge, i, (r => {
            try {
                if ("prefab/endlessbenefitsgift" == i && !ToolUtils.judgeIfInHall()) {
                    return;
                }
                if ("prefab/cendlessbenefitsgift_game" == i && !ToolUtils.getIsInRoom()) {
                    return;
                }
                this.consecutiveGiftPrefab = r;
                let l = (e = director.getScene().getChildByName("Canvas")).getChildByName("ConsecutiveGift");
                if (!ToolUtils.isObjValid(l)) {
                    l = instantiate(this.consecutiveGiftPrefab);
                    l.name = "ConsecutiveGift";
                    l.getComponent("EndlessBenefitsGift").initParaData(a, t);
                    l.parent = e;
                    this.checkRewardShowTop(e);
                }
            }
            catch (e) {
                TLog.printError("showConsecutiveGiftView error:" + e);
            }
        }));
    }
    showRebateRechargeView(e, a, t = 0) {
        if (director.getScene().name != BundleNameDefined.hall_scene) {
            return;
        }
        let i = ToolUtils.judgeIfInHall();
        ToolUtils.loadCommonPrefab(this.rebateRechargePrefab, BundleNameDefined.bundle_firstRecharge, "prefab/rebate_recharge", (r => {
            try {
                if (this.rebateRechargePrefab = r, i) {
                    if (!ToolUtils.judgeIfInHall()) {
                        return;
                    }
                }
                else if (!ToolUtils.judgeIfInRummy()) {
                    return;
                }
                let l = (e = director.getScene().getChildByName("Canvas")).getChildByName("RebateRecharge");
                if (!ToolUtils.isObjValid(l)) {
                    l = instantiate(r);
                    l.name = "RebateRecharge";
                    l.getComponent("RebateRecharge").initParaData(a, t);
                    l.parent = e;
                    this.checkRewardShowTop(e);
                }
            }
            catch (e) {
                TLog.printError("showRebateRechargeView error:" + e);
            }
        }));
    }
    showBuyOneGetThreeView(e, a) {
        if (director.getScene().name == BundleNameDefined.switch_scence) {
            return;
        }
        let t = "prefab/payoneforthree";
        ToolUtils.getIsInRoom() && (t = "prefab/payoneforthree_game");
        ToolUtils.loadCommonPrefab(this.payOneForThreePrefab, BundleNameDefined.bundle_payoneforthree, t, (i => {
            try {
                if ("prefab/payoneforthree" == t && !ToolUtils.judgeIfInHall()) {
                    return;
                }
                if ("prefab/payoneforthree_room" == t && !ToolUtils.getIsInRoom()) {
                    return;
                }
                if (this.payOneForThreePrefab = i, director.getScene().name == BundleNameDefined.switch_scence) {
                    return;
                }
                let r = (e = director.getScene().getChildByName("Canvas")).getChildByName("BuyOneGetThree");
                if (!ToolUtils.isObjValid(r)) {
                    r = instantiate(i);
                    r.name = "BuyOneGetThree";
                    r.getComponent("PayOneForThreeRecharge").initParaData(a);
                    r.parent = e;
                    this.checkRewardShowTop(e);
                }
            }
            catch (e) {
                TLog.printError("showBuyOneGetThreeView error:" + e);
            }
        }));
    }
    showLotteryView(e, a) {
    }
    showReliefPackageView(e = null) {
        director.getScene().name;
        BundleNameDefined.hall_scene;
    }
    showBuddyJoinView() {
        ToolUtils.loadCommonPrefab(this.buddyJoinPrefab, BundleNameDefined.bundle_public, "prefab/buddy_room_join", (e => {
            this.buddyJoinPrefab = e;
            try {
                let e = director.getScene().getChildByName("Canvas"), a = e.getChildByName("buddy_room_join");
                ToolUtils.isObjValid(a) || (a = instantiate(this.buddyJoinPrefab), a.parent = e);
            }
            catch (e) {
                TLog.printError("createBuddyJoinView error= " + e);
            }
        }));
    }
    showMatchAlertView(e, a) {
        let t = director.getScene().getChildByName("Canvas"), r = "", l = "", o = null, n = "", d = false, h = "", c = false, u = 0;
        sys.isObjectValid(a) && (ToolUtils.isObjValid(a.parentNode) && (t = a.parentNode), sys.isObjectValid(a.strContent) && (r = a.strContent), sys.isObjectValid(a.strBtn) && (l = a.strBtn), sys.isObjectValid(a.callfun) && (o = a.callfun), sys.isObjectValid(a.strFunc) && (n = a.strFunc), sys.isObjectValid(a.bRejoin) && (d = a.bRejoin), sys.isObjectValid(a.strTime) && (h = a.strTime), sys.isObjectValid(a.isLateJoin) && (c = a.isLateJoin), d ? u = 1 : c && (u = 2));
        ToolUtils.loadCommonPrefab(this.matchAlertPrefab, BundleNameDefined.bundle_public, "prefab/match_alert", (a => {
            this.matchAlertPrefab = a;
            try {
                let a = t.getChildByName("match_alert");
                if (!ToolUtils.isObjValid(a)) {
                    a = instantiate(this.matchAlertPrefab);
                    a.parent = t;
                    a.getComponent("MatchAlert").updateDlgInfo(e, r, l, o, n, h, u);
                }
            }
            catch (e) {
                TLog.printError("createMatchAlertView error= " + e);
            }
        }));
    }
    showBuyOneGetThree(a) {
        if (0 !== User.shared().charge_open) {
            if (window.InSwitchScene) {
                TLog.printError("-------- showBuyOneGetThree switchScene stop preload res.");
            }
            else {
                if (sys.isObjectValid(a) || (a = {}), !sys.isObjectValid(a.vid) || !sys.isObjectValid(a.ext)) {
                    return sys.isObjectValid(User.shared().payOneForThreeData) ? (a.ext = User.shared().payOneForThreeData, void Utils.shared().showBuyOneGetThreeView(a.parent_node, a)) : void HttpManager.shared().doGetCommonRequest(null, HttpRequest.BuyOneGetThreePage, ((t, i, r) => {
                        if (200 != r) {
                            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.request_fail"), 2);
                        }
                        else {
                            let t = ToolUtils.parseJson(i);
                            0 == t.ret ? (User.shared().payOneForThreeData = t.data, ToolUtils.isObjValid(a.parent_node) && (a.ext = User.shared().payOneForThreeData, a.needReqPage = false, Utils.shared().showBuyOneGetThreeView(a.parent_node, a))) : ToolUtils.isSafeString(t.desc).length > 0 && (Utils.shared().showToast(ToolUtils.isSafeString(t.desc), 2), PushCenter.shared().pushEvent(PushEvent.PurchasedFirstRecharge), PushCenter.shared().pushEvent(PushEvent.CloseBuyOneGetThree));
                        }
                    }));
                }
                Utils.shared().showBuyOneGetThreeView(a.parent_node, a);
            }
        }
    }
    showConsecutiveGift(a) {
        if (0 !== User.shared().charge_open) {
            if (window.InSwitchScene) {
                TLog.printError("-------- showConsecutiveGift switchScene stop preload res.");
            }
            else {
                if (sys.isObjectValid(a) || (a = {}), !sys.isObjectValid(a.vid) || !sys.isObjectValid(a.ext)) {
                    return sys.isObjectValid(User.shared().consecutiveGiftData) ? (a.ext = User.shared().consecutiveGiftData, void Utils.shared().showConsecutiveGiftView(a.parent_node, a)) : void HttpManager.shared().doGetCommonRequest(null, HttpRequest.ConsecutiveGiftPage, ((t, i, r) => {
                        if (200 != r) {
                            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.request_fail"), 2);
                        }
                        else {
                            let t = ToolUtils.parseJson(i);
                            0 == t.ret ? (User.shared().consecutiveGiftData = t.data, ToolUtils.isObjValid(a.parent_node) && (a.ext = User.shared().consecutiveGiftData, Utils.shared().showConsecutiveGiftView(a.parent_node, a))) : ToolUtils.isSafeString(t.desc).length > 0 && (Utils.shared().showToast(ToolUtils.isSafeString(t.desc), 2), PushCenter.shared().pushEvent(PushEvent.PurchasedFirstRecharge), PushCenter.shared().pushEvent(PushEvent.CloseConsecutiveGift));
                        }
                    }));
                }
                Utils.shared().showConsecutiveGiftView(a.parent_node, a);
            }
        }
    }
    showRestartGift(a) {
        0 !== User.shared().charge_open && (window.InSwitchScene ? TLog.printError("-------- showRestartGift switchScene stop preload res.") : (sys.isObjectValid(a) || (a = {}), Utils.shared().showRestartGiftAlert(a)));
    }
    showFirstRecharge_game2(a) {
        if (0 !== User.shared().charge_open) {
            if (window.InSwitchScene) {
                TLog.printError("-------- showFirstRecharge_game2 switchScene stop preload res.");
            }
            else {
                if (!sys.isObjectValid(a.vid) || !sys.isObjectValid(a.ext)) {
                    return sys.isObjectValid(User.shared().firstrechargeData) ? (a.ext = User.shared().firstrechargeData, void Utils.shared().showFirstRechargeView(null, a)) : void HttpManager.shared().doGetCommonRequest(null, HttpRequest.FirstRechargePage, ((t, i, r) => {
                        if (200 != r) {
                            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.request_fail"), 2);
                        }
                        else {
                            let t = ToolUtils.parseJson(i);
                            0 == t.ret ? (User.shared().firstrechargeData = t.data, ToolUtils.isObjValid(a.parent_node) && (a.ext = User.shared().firstrechargeData, Utils.shared().showFirstRechargeView(null, a))) : ToolUtils.isSafeString(t.desc).length > 0 && (Utils.shared().showToast(ToolUtils.isSafeString(t.desc), 2), User.shared().canFirstPay = 0, PushCenter.shared().pushEvent(PushEvent.PurchasedFirstRecharge), PushCenter.shared().pushEvent(PushEvent.CloseFirstRecharge));
                        }
                    }));
                }
                Utils.shared().showFirstRechargeView(null, a);
            }
        }
    }
    showTwentyHourRecharge(a) {
        0 !== User.shared().charge_open && (window.InSwitchScene ? TLog.printError("-------- showTwentyHourRecharge switchScene stop preload res.") : sys.isObjectValid(User.shared().twentyfourrechargeData) ? Utils.shared().showTwentyFourRechargeView(a.parent_node, a) : HttpManager.shared().doGetCommonRequest(null, HttpRequest.TwentyFourRechargePage, ((t, i, r) => {
            if (200 != r) {
                Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.request_fail"), 2);
            }
            else {
                let t = ToolUtils.parseJson(i);
                0 == t.ret ? (User.shared().twentyfourrechargeData = t.data, ToolUtils.isObjValid(a.parent_node) && Utils.shared().showTwentyFourRechargeView(a.parent_node, a)) : ToolUtils.isSafeString(t.desc).length > 0 && (Utils.shared().showToast(ToolUtils.isSafeString(t.desc), 2), User.shared().canTwentyFour = 0, PushCenter.shared().pushEvent(PushEvent.PurchasedFirstRecharge), PushCenter.shared().pushEvent(PushEvent.CloseTwentyHourRecharge));
            }
        })));
    }
    showMatchRankView(e, a, t, r) {
        ToolUtils.loadCommonPrefab(this.matchRankPrefab, BundleNameDefined.bundle_public, "prefab/match_rank", (l => {
            this.matchRankPrefab = l;
            try {
                if (!ToolUtils.isObjValid(e)) {
                    return;
                }
                let l = e.getChildByName("match_rank");
                ToolUtils.isObjValid(l) || (l = instantiate(this.matchRankPrefab), l.parent = e, l.setSiblingIndex(20));
                let s = l.getComponent("MatchRank");
                s.refreshUI(a, r);
                sys.isObjectValid(t) && (s.setTidKey(t), s.setLandscapeShow());
            }
            catch (e) {
                TLog.printError("createMatchRankView error= " + e);
            }
        }));
    }
    showMatchPrizesRankView(e, a, t) {
        ToolUtils.loadCommonPrefab(this.matchPrizesRankPrefab, BundleNameDefined.bundle_public, "prefab/match_prizes_rank", (r => {
            this.matchPrizesRankPrefab = r;
            try {
                let r = e.getChildByName("match_prizes_rank");
                ToolUtils.isObjValid(r) || (r = instantiate(this.matchPrizesRankPrefab), r.parent = e, r.setSiblingIndex(20));
                let l = r.getComponent("MatchPrizesRank");
                l.refreshUI(a);
                sys.isObjectValid(t) && (l.setTidKey(t), l.setLandscapeShow());
            }
            catch (e) {
                TLog.printError("createMatchPrizesRankView error= " + e);
            }
        }));
    }
    openLocation(e = "1") {
        0 === AppInfo.shared().checkOpenLocationService() ? AppInfo.shared().jumpToLocationService() : 0 === AppInfo.shared().checkOpenLocationPermission() ? (AppInfo.shared().getLocationInfo(e), ToolUtils.location_forbid = false, TweenTool.delayAct(ToolUtils.getPersistGlobalNode(), (() => {
            ToolUtils.location_forbid && AppInfo.shared().jumpToPermissionSetting();
        }), 1, true)) : AppInfo.shared().getLocationInfo(e);
    }
    showLocationTipsAlert(e = 0, a = null, t = 0, r = true) {
        let l = false;
        if (0 === User.shared().is_check_location) {
            return l;
        }
        if (e === CheckModule.LOGIN) {
            if ("1" === ToolUtils.isSafeString(sys.localStorage.getItem(CommDefine.FirstLogin))) {
                return User.shared().requestGetLocationStatus(), AppInfo.shared().getLocationInfo("0"), false;
            }
            l = true;
        }
        else if (null !== User.shared().check_list) {
            let a = "moudule_" + e;
            if (undefined !== User.shared().check_list[a]) {
                let t = CommDefine.LocationGuideTime + a;
                if (3 === User.shared().check_list[a].location_status) {
                    if (l = false, 0 == AppInfo.shared().checkOpenLocationService()) {
                        if (1 === User.shared().check_list[a].location_pop_limit) {
                            l = true;
                            ToolUtils.saveData(t, "" + sys.now());
                        }
                        else if (2 === User.shared().check_list[a].location_pop_limit) {
                            let e = ToolUtils.isSafeString(sys.localStorage.getItem(t));
                            "" !== e && ToolUtils.isToday(Number(e)) ? l = false : (l = true, ToolUtils.saveData(t, "" + sys.now()));
                        }
                        else if (3 === User.shared().check_list[a].location_pop_limit) {
                            "" === ToolUtils.isSafeString(sys.localStorage.getItem(t)) && (l = true, ToolUtils.saveData(t, "" + sys.now()));
                        }
                    }
                }
                else if (1 === User.shared().check_list[a].location_status) {
                    if (1 === User.shared().check_list[a].location_pop_limit) {
                        1 == AppInfo.shared().checkOpenLocationService() ? l = false : (l = true, ToolUtils.saveData(t, "" + sys.now()));
                    }
                    else if (2 === User.shared().check_list[a].location_pop_limit) {
                        let e = ToolUtils.isSafeString(sys.localStorage.getItem(t));
                        "" !== e && ToolUtils.isToday(Number(e)) ? l = false : (l = true, ToolUtils.saveData(t, "" + sys.now()));
                    }
                    else if (3 === User.shared().check_list[a].location_pop_limit) {
                        "" === ToolUtils.isSafeString(sys.localStorage.getItem(t)) && (l = true, ToolUtils.saveData(t, "" + sys.now()));
                    }
                    AppInfo.shared().checkIfOpenLocation() && (l = false);
                    e == CheckModule.HALL && ToolUtils.hasGetLocation && (l = false);
                }
                else {
                    if (0 === (e == CheckModule.CHIPS_PLAY ? User.shared().data.chip_location_status : User.shared().data.location_status)) {
                        if (1 === User.shared().check_list[a].location_pop_limit) {
                            l = true;
                            ToolUtils.saveData(t, "" + sys.now());
                        }
                        else if (2 === User.shared().check_list[a].location_pop_limit) {
                            let e = ToolUtils.isSafeString(sys.localStorage.getItem(t));
                            "" !== e && ToolUtils.isToday(Number(e)) ? l = false : (l = true, ToolUtils.saveData(t, "" + sys.now()));
                        }
                        else if (3 === User.shared().check_list[a].location_pop_limit) {
                            "" === ToolUtils.isSafeString(sys.localStorage.getItem(t)) && (l = true, ToolUtils.saveData(t, "" + sys.now()));
                        }
                        else if (4 === User.shared().check_list[a].location_pop_limit) {
                            return l = false, false;
                        }
                    }
                }
            }
            ToolUtils.isForbidFuc() && e == CheckModule.HALL && (l = true);
        }
        return e == CheckModule.HALL && ToolUtils.hasGetLocation && (l = false), l && (0 == AppInfo.shared().checkOpenLocationService() && e != CheckModule.LOGIN ? 0 == AppInfo.shared().showLocationSwitchGuide() && this.showLocationGuideAlert(a, e, t, r) : this.showLocationGuideAlert(a, e, t, r)), l;
    }
    showLocationGuideAlert(a = null, t, i, r = true) {
        if (ToolUtils.isForbidFuc()) {
            User.shared().requestGetLocationStatus();
            Utils.shared().openLocation(String(t));
        }
        else {
            let i = ReportConfig.func.Login, l = director.getScene().getChildByName("Canvas"), o = l;
            if (ToolUtils.judgeIfInHall() && ((l.getChildByName("reward_tips_10Cash") || l.getChildByName("node_guide") && l.getChildByName("node_guide").active) && l.getChildByName("tips_node") && (o = l.getChildByName("tips_node")), i = ReportConfig.func.Hall), HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: i, event: ReportConfig.login_evt.location_guide_pop }), t != CheckModule.LOGIN) {
                r && (CheckModule.RECHARGE, Utils.shared().showCustomLocationGuide(o, 1, t));
            }
            else {
                let t = { bLandscape: ToolUtils.getIsNormalDirection(), bWithCancel: false, strContent: i18nMgr.shared().getValueByKey("utlis.location_guide_tip"), strTitle: i18nMgr.shared().getValueByKey("cash_help.tips"), sureKey: "utlis.allow", dialogType: 1 };
                t.parent_node = o;
                Utils.shared().showCommonAlert(t, (t => {
                    User.shared().requestGetLocationStatus();
                    1 === t ? (HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: i, event: ReportConfig.login_evt.location_guide_allow }), Utils.shared().openLocation()) : HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: i, event: ReportConfig.login_evt.location_guide_close });
                    a && a();
                }));
            }
        }
    }
    checkCanShowLocationAlert(e = 0) {
        let a = false;
        if (0 === User.shared().is_check_location) {
            return a;
        }
        if (0 !== e && null !== User.shared().check_list) {
            let t = "moudule_" + e;
            if (undefined !== User.shared().check_list[t]) {
                let r = CommDefine.LocationGuideTime + t;
                if (3 === User.shared().check_list[t].location_status) {
                    return false;
                }
                if (0 === (e == CheckModule.CHIPS_PLAY ? User.shared().data.chip_location_status : User.shared().data.location_status)) {
                    if (1 === User.shared().check_list[t].location_pop_limit) {
                        a = true;
                    }
                    else if (2 === User.shared().check_list[t].location_pop_limit) {
                        let e = ToolUtils.isSafeString(sys.localStorage.getItem(r));
                        a = "" === e || !ToolUtils.isToday(Number(e));
                    }
                    else if (3 === User.shared().check_list[t].location_pop_limit) {
                        "" === ToolUtils.isSafeString(sys.localStorage.getItem(r)) && (a = true);
                    }
                    else if (4 === User.shared().check_list[t].location_pop_limit) {
                        return a = false, false;
                    }
                }
            }
        }
        return a;
    }
    getOffsetDistance() {
        return ToolUtils.getRealViewSize().height - GameConfig.CONFIG_SCREEN_HEIGHT;
    }
    showRedeemCodeView(e) {
        ToolUtils.loadCommonPrefab(this.redeemCodePrefab, BundleNameDefined.bundle_hallTopUI, "prefab/redemption_code", (a => {
            this.redeemCodePrefab = a;
            try {
                if (ToolUtils.judgeIfInHall()) {
                    let t = director.getScene().getChildByName("Canvas"), i = t.getChildByName("redemption_code");
                    if (!ToolUtils.isObjValid(i)) {
                        i = instantiate(a);
                        i.parent = t;
                        this.checkRewardShowTop(t);
                        i.name = "redemption_code";
                        i.getComponent("RedemptionCode").initParaData(e);
                    }
                }
            }
            catch (e) {
                TLog.printError("createRedeemCodeView error= " + e);
            }
        }));
    }
    showHappyHoliView(e) {
        ToolUtils.loadCommonPrefab(this.happyHoliPrefab, BundleNameDefined.Bundle_happyHoli, "prefab/happyHoli", (a => {
            this.happyHoliPrefab = a;
            try {
                if (ToolUtils.judgeIfInHall()) {
                    let t = director.getScene().getChildByName("Canvas"), i = t.getChildByName("happyHoli");
                    if (!ToolUtils.isObjValid(i)) {
                        i = instantiate(a);
                        i.name = "happyHoli";
                        t.addChild(i);
                        this.checkRewardShowTop(t);
                        i.getComponent("HappyHoli").initParaData(e);
                    }
                }
            }
            catch (e) {
                TLog.printError("createHappyHoliView error= " + e);
            }
        }));
    }
    reSetWebViewSiblingIndex() {
        let e = director.getScene().getChildByName("Canvas").getChildByName("webView");
        ToolUtils.isObjValid(e) && e.setSiblingIndex(100000);
    }
    showLoginSafeVerification(e, a = null, t = null) {
        if (null == t) {
            let e = director.getScene();
            t = e.getChildByName("Canvas");
        }
        ToolUtils.loadCommonPrefab(this.loginVerificationPrefab, BundleNameDefined.bundle_public, "prefab/safe_verify", (i => {
            this.loginVerificationPrefab = i;
            try {
                if (null == t.getChildByName("SafetyVerification")) {
                    let i = instantiate(this.loginVerificationPrefab);
                    i.name = "SafetyVerification";
                    t.addChild(i);
                    i.getComponent("SafetyVerification").refreshUI(e, a);
                }
            }
            catch (e) {
                TLog.printError("createLoginVerification error= " + e);
            }
        }));
    }
    showTawkFeedback(e) {
        ToolUtils.loadCommonPrefab(this.tawkFeedbackPrefab, BundleNameDefined.bundle_public, "prefab/feedback_node", (a => {
            try {
                this.tawkFeedbackPrefab = a;
                let t = director.getScene().getChildByName("Canvas");
                if (!ToolUtils.isObjValid(t)) {
                    return;
                }
                let i = t.getChildByName("feedback_node");
                if (ToolUtils.isObjValid(i)) {
                    i.active = true;
                }
                else {
                    i = instantiate(a);
                    i.parent = t;
                    this.checkRewardShowTop(t);
                    i.getComponent("FeedbackAlert").setParaData(e);
                }
            }
            catch (e) {
                TLog.printError("showTawkFeedback error= " + e);
            }
        }));
    }
    showMobileBindGuide(e) {
        ToolUtils.loadCommonPrefab(this.mobileGuidePrefab, BundleNameDefined.Bundle_kyc, "prefab/mobile_blind2", (a => {
            try {
                this.mobileGuidePrefab = a;
                let t = director.getScene().getChildByName("Canvas");
                if (!ToolUtils.isObjValid(t)) {
                    return;
                }
                let i = t.getChildByName("mobile_blind2");
                if (ToolUtils.isObjValid(i)) {
                    i.active = true;
                }
                else {
                    i = instantiate(a);
                    i.parent = t;
                    this.checkRewardShowTop(t);
                    i.getComponent("BindMobileGuide").init(e);
                }
            }
            catch (e) {
                TLog.printError("showMobileBindGuide error= " + e);
            }
        }));
    }
    showPaymentGuide(e = null, a, t) {
        ToolUtils.loadCommonPrefab(this.paymentGuidePrefab, BundleNameDefined.bundle_wallet, "prefab/payment_select", (i => {
            try {
                if (this.paymentGuidePrefab = i, ToolUtils.isObjValid(e) || (e = director.getScene().getChildByName("Canvas")), !ToolUtils.isObjValid(e)) {
                    return;
                }
                let r = e.getChildByName("payment_select");
                if (ToolUtils.isObjValid(r)) {
                    r.active = true;
                    r.getComponent("PaymentSelect").setParaData(t, a);
                }
                else {
                    r = instantiate(i);
                    r.parent = e;
                    this.checkRewardShowTop(e);
                    r.getComponent("PaymentSelect").setParaData(t, a);
                }
            }
            catch (e) {
                TLog.printError("showPaymentGuide error= " + e);
            }
        }));
    }
    showDailyCheckinActivity(e) {
        let a = ToolUtils.judgeIfInHall();
        if (a) {
            let t = "prefab/dailycheckin";
            ToolUtils.loadCommonPrefab(this.dailyLoginActPrefab, BundleNameDefined.Bundle_dailyLogin, t, (t => {
                try {
                    if (this.dailyLoginActPrefab = t, a = ToolUtils.judgeIfInHall(), !a) {
                        return;
                    }
                    let i = director.getScene().getChildByName("Canvas");
                    if (!ToolUtils.isObjValid(i)) {
                        return;
                    }
                    let r = i.getChildByName("dailycheckin");
                    if (ToolUtils.isObjValid(r)) {
                        r.active = true;
                    }
                    else {
                        r = instantiate(t);
                        r.parent = i;
                        this.checkRewardShowTop(i);
                        r.getComponent("DailyCheckinAct").initParaData(e);
                    }
                }
                catch (e) {
                    TLog.printError("showDailyCheckinActivity error= " + e);
                }
            }));
        }
    }
    showBackCardTask(e) {
        ToolUtils.loadCommonPrefab(null, BundleNameDefined.bundle_dailyTask, "prefab/welcomeback_work", (a => {
            let t = director.getScene().getChildByName("Canvas");
            if (ToolUtils.isObjValid(t)) {
                let i = t.getChildByName("WelcomeBackWork");
                if (!ToolUtils.isObjValid(i)) {
                    if (director.getScene().name != BundleNameDefined.hall_scene) {
                        return;
                    }
                    let i = instantiate(a);
                    i.parent = t;
                    i.name = "WelcomeBackWork";
                    this.checkRewardShowTop(t);
                    i.getComponent("WelcomeBackWork").initParaData(e, (() => {
                    }));
                }
            }
        }));
    }
    showDailyTask(e, a, t) {
    }
    showDailyGuide(e, a = false, t = null) {
    }
    showNovicesTaskView(e = false, a) {
        if (director.getScene().name != BundleNameDefined.switch_scence) {
            try {
                ToolUtils.loadCommonPrefab(null, BundleNameDefined.bundle_novicesTask, "prefab/newplayer_task", (t => {
                    let i = director.getScene().getChildByName("Canvas");
                    if (ToolUtils.isObjValid(i)) {
                        let r = i.getChildByName("newplayer_task");
                        if (!ToolUtils.isObjValid(r)) {
                            try {
                                let r = instantiate(t);
                                if (r.name = "newplayer_task", ToolUtils.isObjValid(i)) {
                                    i.addChild(r);
                                    this.checkRewardShowTop(i);
                                    r.getComponent("NewPlayerTask").initTask(e, a);
                                }
                            }
                            catch (e) {
                                TLog.printError("createNovicesTask error= " + e);
                            }
                        }
                    }
                }));
            }
            catch (e) {
                TLog.printError("showNovicesTaskView err:", e);
            }
        }
    }
    showSafetyVerify(a, t) {
        try {
            ToolUtils.loadCommonPrefab(null, BundleNameDefined.Bundle_kyc, "prefab/safety_verify_node", (i => {
                if (director.getScene().name != BundleNameDefined.hall_scene) {
                    return;
                }
                let r = instantiate(i);
                r.name = "safetyVerifyNode";
                let l = r.getComponent("SafetyVerifyPrefabs");
                ToolUtils.isObjValid(a) && (a.active = false);
                l.setCloseCallBack((i => {
                    ToolUtils.isObjValid(a) && (a.active = true);
                    i && null != t && null != t && null != t.type && Utils.shared().doJumpLogic(t.type, t.exe);
                }));
                director.getScene().getChildByName("Canvas").addChild(r);
            }));
        }
        catch (e) {
            TLog.printError("Utils showSafetyVerify err:", e);
        }
    }
    removeHTMLTag(e) {
        e = (e = (e = e.replace(/<\/?[^>]*>/g, "")).replace(/[ | ]*\n/g, "")).replace(/\n[\s| | ]*\r/g, "\n");
        const a = { lt: "<", gt: ">", nbsp: " ", amp: "&", quot: '"' };
        return e = e.replace(/&(lt|gt|nbsp|amp|quot);/gi, (function (e, t) {
            return a[t];
        }));
    }
    captureScreenshot(e, a, t) {
        let i = director.getScene().getChildByName("Canvas").getComponent(Canvas).cameraComponent, l = new RenderTexture;
        l.reset(view.getVisibleSize());
        i.targetTexture = l;
        TweenTool.delayAct(e, (() => {
            i.targetTexture = null;
            let r = a.width;
            var s = a.height, o = e.getWorldPosition();
            let n = e.getComponent(UITransform).anchorPoint;
            o.x = o.x - r * n.x;
            o.y = o.y - s * n.y;
            let d = l.readPixels(Math.round(o.x), Math.round(o.y), r, s), h = r, c = s, u = new Uint8Array(h * c * 4), p = 4 * h;
            for (let e = 0; e < c; e++) {
                let a = (c - 1 - e) * h * 4, t = e * h * 4;
                for (let e = 0; e < p; e++) {
                    u[t + e] = d[a + e];
                }
            }
            this.savaAsImage(u, r, s, t);
        }), game.frameTime / 1000, true);
    }
    savaAsImage(e, a, t, r) {
        if (sys.isNative) {
            try {
                let l = native.fileUtils.getWritablePath() + this.NET_IMAGE_CATCH_FOLDER;
                native.fileUtils.isDirectoryExist(l) || native.fileUtils.createDirectory(l);
                let s = "screenshot" + sys.now(), o = l + "/" + MD5.Instance.hex_md5(s) + ".jpg";
                native.saveImageData ? native.saveImageData(e, a, t, o).then((() => {
                    r && r(o);
                })).catch((() => {
                    TLog.printError("save image data failed!");
                    r && r(null);
                })) : r && r(null);
            }
            catch (e) {
                TLog.printError("savaAsImage error:", e);
            }
        }
    }
    startDownLoadHotUpdate(e, a) {
        this._utilLogicTool.startDownLoadHotUpdate(e, a);
    }
    renameDirectory(e, a, t) {
        let i = e + a, r = e + t;
        if (native.fileUtils.isDirectoryExist(i) && !native.fileUtils.isDirectoryExist(r)) {
            native.fileUtils.renameFile(i, r);
        }
    }
    mergeDirectories(e, a) {
        let t = [];
        return native.fileUtils.listFilesRecursively(e, t), t.forEach((t => {
            let i = t.substring(e.length);
            const r = a + i;
            try {
                if (native.fileUtils.isDirectoryExist(t)) {
                    native.fileUtils.isDirectoryExist(r) || native.fileUtils.createDirectory(r);
                }
                else if (native.fileUtils.isFileExist(t)) {
                    native.fileUtils.isFileExist(r) && native.fileUtils.removeFile(r);
                    const e = native.fileUtils.getDataFromFile(t);
                    native.fileUtils.writeDataToFile(e, r);
                }
            }
            catch (e) {
                TLog.printError("utils mergeDirectories error:", e);
            }
        })), t.length;
    }
    openLastCloseWebView() {
        if (ToolUtils.last_web_url.length > 0 && ToolUtils.last_web_title.length > 0) {
            let a = { url: ToolUtils.last_web_url, title: ToolUtils.last_web_title };
            Utils.shared().openUrl(a);
        }
    }
    parseTimeCount(e) {
        let a = [0, 0, 0, 0];
        return ToolUtils.isSafeNumber(e) > 0 && (e >= 86400 && (a[0] = Math.floor(e / 86400), e -= 86400 * a[0]), e >= 3600 && (a[1] = Math.floor(e / 3600), e -= 3600 * a[1]), e >= 60 && (a[2] = Math.floor(e / 60), e -= 60 * a[2]), e > 0 && (a[3] = e)), a;
    }
    parseCountDown(e) {
        let a = "";
        return ToolUtils.isSafeNumber(e) > 0 && (a = e >= 86400 ? Math.floor(e / 86400) + "d " + Math.floor(e % 86400 / 3600) + "h" : e >= 3600 ? Math.floor(e / 3600) + "h " + Math.floor(e % 3600 / 60) + "m" : Math.floor(e / 60) + "m " + e % 60 + "s"), a;
    }
    parseCountDownToSec(e) {
        let a = "";
        if (ToolUtils.isSafeNumber(e) > 0) {
            let t = e;
            if (t >= 3600) {
                let e = Math.floor(t / 3600);
                a = a + e + "h";
                t -= 3600 * e;
            }
            if (t >= 60) {
                a.length > 0 && (a += " ");
                let e = Math.floor(t / 60);
                a = a + e + "m";
                t = Math.floor(t - 60 * e);
            }
            t >= 0 && (a.length > 0 && (a += " "), a = t < 10 && a.length > 0 ? a + "0" + t + "s" : a + t + "s");
        }
        return a;
    }
    getCountDownArray(e) {
        let a = ["00", "00", "00"];
        if (ToolUtils.isSafeNumber(e) > 0) {
            let t = e;
            if (t >= 3600) {
                let e = Math.floor(t / 3600);
                t -= 3600 * e;
                a[0] = e < 10 ? "0" + e : "" + e;
            }
            if (t >= 60) {
                let e = Math.floor(t / 60);
                a[1] = e < 10 ? "0" + e : "" + e;
                t = Math.floor(t - 60 * e);
            }
            t >= 0 && (a[2] = t < 10 ? "0" + t : "" + t);
        }
        return a;
    }
    getCountDownString(e) {
        let a = "";
        if (ToolUtils.isSafeNumber(e) >= 0) {
            let t = e;
            if (t >= 3600) {
                let e = Math.floor(t / 3600);
                t -= 3600 * e;
                a = e < 10 ? "0" + e + ":" : e + ":";
            }
            else {
                a = "00:";
            }
            if (t >= 60) {
                let e = Math.floor(t / 60);
                a = e < 10 ? a + "0" + e + ":" : a + "" + e + ":";
                t = Math.floor(t - 60 * e);
            }
            else {
                a += "00:";
            }
            t >= 0 && (a = t < 10 ? a + "0" + t : a + "" + t);
        }
        return a;
    }
    removeNonAlphabetic(e) {
        return e.replace(/[^A-Za-z\s]/g, "");
    }
    updateAnimMaterial(e) {
    }
    getHorizontalSize() {
        let e = view.getVisibleSize(), a = e.width >= e.height ? e.width : e.height, t = GameConfig.REAL_SCREEN_HEIGHT, i = GameConfig.REAL_SCREEN_WIDTH;
        return a > t && (t = a), size(t, i);
    }
    showTreasureHunt(e) {
        let a = "prefab/earthquakes", t = ToolUtils.judgeIfInHall(), i = this.treasureHuntPrefabInHall;
        ToolUtils.judgeIfInRummy() && (a = "prefab/earthquakes_game", i = this.treasureHuntPrefabInRoom);
        ToolUtils.loadCommonPrefab(i, BundleNameDefined.Bundle_treasurehunt, a, (a => {
            ToolUtils.judgeIfInHall() ? this.treasureHuntPrefabInHall = a : ToolUtils.judgeIfInRummy() && (this.treasureHuntPrefabInRoom = a);
            try {
                if (t) {
                    if (!ToolUtils.judgeIfInHall()) {
                        return;
                    }
                }
                else if (!ToolUtils.judgeIfInRummy()) {
                    return;
                }
                let i = e.parent_node;
                i = director.getScene().getChildByName("Canvas");
                let r = null;
                if (t) {
                    if (!ToolUtils.judgeIfInHall()) {
                        return;
                    }
                }
                else if (!ToolUtils.judgeIfInRummy()) {
                    return;
                }
                if (r = i.getChildByName("earthquakes"), !ToolUtils.isObjValid(r)) {
                    r = instantiate(a);
                    r.name = "earthquakes";
                    r.parent = i;
                    this.checkRewardShowTop(i);
                    r.getComponent(EarthQuakes).initParaData(e);
                }
            }
            catch (e) {
                TLog.printError("createTreasureHuntView error= " + e);
            }
        }));
    }
    showHappyFlopView(e) {
    }
    showWeekMonthView(e) {
        ToolUtils.loadCommonPrefab(this.weekmonthPrefab, BundleNameDefined.bundle_weekmonth, "prefab/weeklymonthcard_new", (a => {
            this.weekmonthPrefab = a;
            try {
                if (ToolUtils.judgeIfInHall()) {
                    let t = director.getScene().getChildByName("Canvas"), i = t.getChildByName("weeklymonthcard_new");
                    if (!ToolUtils.isObjValid(i)) {
                        i = instantiate(a);
                        i.parent = t;
                        this.checkRewardShowTop(t);
                        i.name = "weeklymonthcard_new";
                        i.getComponent("WeeklyMonthCardNew").initParaData(e);
                    }
                }
            }
            catch (e) {
                TLog.printError("createWeekMonthView error= " + e);
            }
        }));
    }
    moveNodeToTop(e, a) {
        let t = e.getChildByName(a);
        if (ToolUtils.isObjValid(t) && (t.setSiblingIndex(9999999), "commondialog_reward_tips" == a)) {
            let e = t.getComponent("CommonDlgAlert");
            sys.isObjectValid(e) && e.setSureButtonLableKey("reward_tips.okey");
        }
    }
    showCustomLocationGuide(e, a, t = -1) {
    }
    showGullakView(e) {
        director.getScene().name != BundleNameDefined.switch_scence && ToolUtils.loadCommonPrefab(this.gullakPrefab, BundleNameDefined.bundle_gullak, "prefab/piggy_bank", (a => {
            try {
                this.gullakPrefab = a;
                let t = e.parent_node;
                t = director.getScene().getChildByName("Canvas");
                let i = t.getChildByName("gullak");
                if (!ToolUtils.isObjValid(i)) {
                    i = instantiate(a);
                    i.name = "gullak";
                    i.parent = t;
                    this.checkRewardShowTop(t);
                    i.getComponent("PiggyBank").initParaData(e);
                }
            }
            catch (e) {
                TLog.printError("createGullakView error= " + e);
            }
        }));
    }
    joinPrivateRoomByRoomId(a) {
        if (String(a).length > 0 && Number(a) > 0) {
            let t = -1, i = Number(a);
            if (User.shared().roomTable && User.shared().roomTable.pri_rm_tids && i >= User.shared().roomTable.pri_rm_tids[0] && i <= User.shared().roomTable.pri_rm_tids[1] && (t = HowToPlayDefined.gameVid_rummyPoint), t < 0 && User.shared().roomTable && User.shared().roomTable.pri_pool_tids && i >= User.shared().roomTable.pri_pool_tids[0] && i <= User.shared().roomTable.pri_pool_tids[1] && (t = HowToPlayDefined.gameVid_rummyPool), t < 0 && User.shared().roomTable && User.shared().roomTable.pri_deals_tids && i >= User.shared().roomTable.pri_deals_tids[0] && i <= User.shared().roomTable.pri_deals_tids[1] && (t = HowToPlayDefined.gameVid_rummyDeal), t < 0) {
                return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text35"), 3);
            }
            PushCenter.shared().pushEvent(GameConfig.Enter_Private_Room, { vid: t, roomType: 1, privateRoomData: { roomid: i } });
        }
    }
    showBumpGameTypeAlert(e, a = null) {
    }
    showEasyGameTypeAlert(e, a = null) {
    }
    showMultipleGameTypeAlert(e, a = null) {
    }
    showDoubleRummyTypeAlert(e, a = null) {
        ToolUtils.loadCommonPrefab(this.doubleRummyTypePrefab, BundleNameDefined.bundle_chooseGame, "prefab/doubleRummyType", (t => {
            this.doubleRummyTypePrefab = t;
            try {
                if (director.getScene().name == BundleNameDefined.switch_scence) {
                    return;
                }
                let i = e.parent_node;
                ToolUtils.isObjValid(i) || (i = director.getScene().getChildByName("Canvas"));
                let r = i.getChildByName("doubleRummyType");
                if (!ToolUtils.isObjValid(r)) {
                    r = instantiate(t);
                    r.parent = i;
                    this.checkRewardShowTop(i);
                    r.getComponent("DoubleRummyType").initParaData(e, a);
                }
            }
            catch (e) {
                TLog.printError("showDoubleRummyTypeAlert error= " + e);
            }
        }));
    }
    loadRemoteDirSpriteFrames(e, a, t) {
        ToolUtils.loadRemoteBundle(e, a, (e => {
            e && e.loadDir(t, SpriteFrame, null, ((e, a) => {
                if (!e) {
                    try {
                        a && Array.isArray(a) && a.forEach((e => {
                            User.shared().remoteImagesMap.set(e.name, e);
                        }));
                    }
                    catch (e) {
                    }
                }
            }));
        }));
    }
    loadRemoteDownSpineData(e, a, t) {
        ToolUtils.loadRemoteBundle(e, a, (e => {
            e && e.loadDir(t, sp.SkeletonData, null, ((e, a) => {
                if (!e) {
                    try {
                        a && Array.isArray(a) && a.forEach((e => {
                            User.shared().remoteAnimMap.set(e.name, e);
                        }));
                    }
                    catch (e) {
                    }
                }
            }));
        }));
    }
    loadRemoteDownLoadAnim(e, a, t = null) {
        ToolUtils.loadRemoteBundle(BundleNameDefined.bundle_downLoadRes, e, (e => {
            e && e.load(a, sp.SkeletonData, ((e, a) => {
                sys.isObjectValid(a) && a.isValid && (User.shared().remoteAnimMap.set(a.name, a), t && t(a));
            }));
        }));
    }
    loadRemoteDownLoadImage(e, a, t, r = "", l = null) {
        ToolUtils.loadRemoteBundle(BundleNameDefined.bundle_downLoadRes, e, (e => {
            e && e.load(r + "image/" + t, ((e, r) => {
                if (sys.isObjectValid(r) && r.isValid) {
                    let e = SpriteFrame.createWithImage(r);
                    User.shared().remoteImagesMap.set(t, e);
                    ToolUtils.isObjValid(a) && (a.getComponent(Sprite).spriteFrame = e);
                    l && l(e);
                }
            }));
        }));
    }
    loadRemoteDeskImage(e, a) {
        ToolUtils.loadRemoteBundle(BundleNameDefined.bundle_desk, ToolUtils.getDeskImageUrl(), (t => {
            t && t.load("big_pic/" + a, ((t, r) => {
                if (sys.isObjectValid(r) && r.isValid) {
                    let t = SpriteFrame.createWithImage(r);
                    User.shared().remoteImagesMap.set(a, t);
                    ToolUtils.isObjValid(e) && (e.getComponent(Sprite).spriteFrame = t);
                }
            }));
        }));
    }
    showAdView(a) {
        sys.isObjectValid(a) && sys.isObjectValid(a.sdk_type) && 2 == a.sdk_type && ToolUtils.isAndroidPlatform() && 1 == TransferPlatform.shared().showGoogleRewardedAd() || ToolUtils.loadCommonPrefab(this.adPrefab, BundleNameDefined.Bundle_ad, "prefab/adView", (t => {
            try {
                if (this.adPrefab = t, Utils.shared().hideLoading(), director.getScene().name != BundleNameDefined.hall_scene) {
                    return;
                }
                let i = a.parent_node;
                ToolUtils.isObjValid(i) || (i = director.getScene().getChildByName("Canvas"));
                let r = director.getScene().getChildByName("Canvas");
                if (ToolUtils.isObjValid(r)) {
                    let e = r.getChildByName("reward_tips");
                    ToolUtils.isObjValid(e) && (e.active = false, e.destroy(), e = null);
                }
                let l = i.getChildByName("adView");
                if (!ToolUtils.isObjValid(l)) {
                    l = instantiate(t);
                    l.parent = i;
                    l.getComponent("AdView").initParaData(a);
                }
            }
            catch (e) {
                TLog.printError("createAdView error= " + e);
            }
        }));
    }
    showAdAskAlert(a) {
        Utils.shared().showLoading(10, true, (() => {
        }));
        User.shared().requestActAdVideoPage((t => {
            if (ToolUtils.judgeIfInHall()) {
                if (t.from_source = a.from_source, sys.isObjectValid(a.isNext) && (t.isNext = a.isNext), User.shared().show_ask = t.show_ask, ToolUtils.report_scene = t.from_source, 0 == t.show_ask && sys.isObjectValid(t.sdk_type) && 2 == t.sdk_type && ToolUtils.isAndroidPlatform() && 1 == TransferPlatform.shared().showGoogleRewardedAd()) {
                    return;
                }
                this.loadRemoteVideo(t.video_url);
                0 == t.show_ask ? this.showAdView(t) : ToolUtils.loadCommonPrefab(this.adRewardPrefab, BundleNameDefined.Bundle_ad, "prefab/adReward", (t => {
                    this.adRewardPrefab = t;
                    try {
                        if (Utils.shared().hideLoading(), director.getScene().name != BundleNameDefined.hall_scene) {
                            return;
                        }
                        let i = a.parent_node;
                        ToolUtils.isObjValid(i) || (i = director.getScene().getChildByName("Canvas"));
                        let r = i.getChildByName("adReward");
                        if (!ToolUtils.isObjValid(r)) {
                            r = instantiate(t);
                            r.parent = i;
                            this.checkRewardShowTop(i);
                            r.getComponent("AdReward").initParaData(a);
                        }
                    }
                    catch (e) {
                        TLog.printError("createAdRewardView error= " + e);
                    }
                }));
            }
        }));
    }
    loadRemoteVideo(e) {
        let a = User.shared().vedioMap.get(e);
        sys.isObjectValid(a) && a.isValid || assetManager.loadRemote(e, { ext: ".mp4" }, ((a, t) => {
            a ? console.error(a) : (User.shared().vedioMap.set(e, t), PushCenter.shared().pushEvent(PushEvent.DownLoadVedio, t));
        }));
    }
    showLeaderBoardsPop(e) {
        director.getScene().name == BundleNameDefined.hall_scene && ToolUtils.loadCommonPrefab(this.leaderboardsPopPrefab, BundleNameDefined.Bundle_leaderBoards, "prefab/rankings_popAct", (a => {
            try {
                if (this.leaderboardsPopPrefab = a, director.getScene().name != BundleNameDefined.hall_scene) {
                    return;
                }
                let t = e.parent_node;
                ToolUtils.isObjValid(t) || (t = director.getScene().getChildByName("Canvas"));
                let i = t.getChildByName("rankings_popAct");
                if (!ToolUtils.isObjValid(i)) {
                    i = instantiate(a);
                    i.parent = t;
                    this.checkRewardShowTop(t);
                    i.getComponent("RankingsPopAct").initParaData(e);
                }
            }
            catch (e) {
                TLog.printError("showLeaderBoardsPop error= " + e);
            }
        }));
    }
    number_beat_Anim(e, a, t, i = false, r = 1, l = false) {
        let s = a - e, o = 0;
        if (s < 0) {
            return;
        }
        o = s < 10 ? 10 : s > 9 && s < 100 ? 15 : s > 99 && s < 1000 ? 20 : s > 999 && s < 10000 ? 25 : s > 9999 && s < 100000 ? 30 : 40;
        o += 1;
        let n = Math.floor(s / o);
        i || (n = s / o, n += 0.01, n = Number(n.toFixed(2)));
        let d = e, h = t.getComponent(Label);
        h.string = i ? ToolUtils.parse_ChipNum2(d + "") : ToolUtils.parse_double(d + "");
        let u = t.scale.x, p = 0, f = r / o;
        l && TweenTool.scaleTo(t, 0.1, v3(1.5 * u, 1.5 * u, 1.5 * u), null, true);
        for (let e = 0; e < o; e++) {
            p += f;
            TweenTool.delayAct(t, (() => {
                if (e == o - 1) {
                    h.string = i ? ToolUtils.parse_ChipNum2(a + "") : ToolUtils.parse_double(a + "");
                    l && TweenTool.scaleTo(t, 0.1, v3(u, u, u), null, true);
                }
                else {
                    let a = e * n + d, t = ToolUtils.parse_double(a + "");
                    i && (t = ToolUtils.parse_ChipNum2(a + ""));
                    h.node.active = true;
                    h.string = t;
                }
            }), p, true);
        }
    }
    flyGoldAnim(e, a, t = 7, i = false, r) {
        resources.load("prefabs/FlygoldAnim", Prefab, ((l, o) => {
            if (null != l) {
                return;
            }
            if (!isValid(e) || !isValid(a)) {
                return;
            }
            let n = director.getScene().getChildByName("Canvas"), d = instantiate(o);
            n.addChild(d);
            d.getComponent(FlygoldAnim).setData(1, e, a, t, i, r);
        }));
    }
    flyGoldAnim1(e) {
        0 != e && resources.load("prefabs/FlygoldAnim", Prefab, ((a, t) => {
            if (null != a) {
                return;
            }
            let i = director.getScene().getChildByName("Canvas"), r = instantiate(t);
            i.addChild(r);
            r.getComponent(FlygoldAnim).setData(2, null, null, e);
        }));
    }
    showAdvancedGift(e) {
        if (director.getScene().name == BundleNameDefined.hall_scene) {
            let a = User.shared().adventrueData;
            sys.isObjectValid(a) || (a = {});
            a.from_source = e.from_source;
            sys.isObjectValid(e.isNext) && (a.isNext = e.isNext);
            sys.isObjectValid(e.pop_souce) && (a.pop_souce = e.pop_souce);
            ToolUtils.loadCommonPrefab(this.AdvancedGiftPrefab, BundleNameDefined.Bundle_advancePack, "prefab/advancedGift", (a => {
                try {
                    if (this.AdvancedGiftPrefab = a, director.getScene().name != BundleNameDefined.hall_scene) {
                        return;
                    }
                    let t = e.parent_node;
                    ToolUtils.isObjValid(t) || (t = director.getScene().getChildByName("Canvas"));
                    let i = t.getChildByName("advancedGift");
                    if (!ToolUtils.isObjValid(i)) {
                        i = instantiate(a);
                        i.name = "advancedGift";
                        i.parent = t;
                        this.checkRewardShowTop(t);
                        i.getComponent("AdvancedGift").initParaData(e);
                    }
                }
                catch (e) {
                    TLog.printError("createAdView error= " + e);
                }
            }));
        }
    }
    showLoginBlindPhoneView(e, a = null, t = null) {
        if (null == t) {
            let e = director.getScene();
            t = e.getChildByName("Canvas");
        }
        ToolUtils.loadCommonPrefab(null, BundleNameDefined.bundle_public, "prefab/fb_login_bind", (i => {
            try {
                let r = t.getChildByName("fb_login_bind");
                if (!ToolUtils.isObjValid(r)) {
                    let r = instantiate(i);
                    r.name = "fb_login_bind";
                    t.addChild(r);
                    r.getComponent("SafetyVerification").refreshUI(e, a);
                }
            }
            catch (e) {
                TLog.printError("createLoginvBindPhoneView error= " + e);
            }
        }));
    }
    showSuperVip(e = null) {
    }
    showInviteRewardTaskPop(e) {
        ToolUtils.judgeIfInHall() && ToolUtils.loadCommonPrefab(this.inviteRewardTaskPrefab, BundleNameDefined.bundle_invite, "prefab/share_pop_act", (a => {
            this.inviteRewardTaskPrefab = a;
            try {
                if (ToolUtils.judgeIfInHall()) {
                    let t = director.getScene().getChildByName("Canvas"), i = null;
                    i = instantiate(a);
                    i.name = "invite_rewardtask";
                    t.addChild(i);
                    this.checkRewardShowTop(t);
                    i.getComponent("SharePopAct").setParaData(null, e);
                }
            }
            catch (e) {
                TLog.printError("createInviteGetRewardView error= " + e);
            }
        }));
    }
    showDirectInviteReward(e) {
        this.createInviteGetRewardView(this.inviteRewardTaskPrefab, e);
    }
    createInviteGetRewardView(e, a) {
        try {
            if (ToolUtils.judgeIfInHall()) {
                let t = director.getScene().getChildByName("Canvas"), i = null;
                i = instantiate(e);
                i.name = "invite_rewardtask";
                t.addChild(i);
                this.checkRewardShowTop(t);
                i.getComponent("SharePopAct").setParaData(null, a);
            }
        }
        catch (e) {
            TLog.printError("createInviteGetRewardView error= " + e);
        }
    }
    showTreasureView(e) {
    }
    showTreasureRecharge(a) {
        if (1 == User.shared().lucky_box) {
            if (ToolUtils.judgeIfInHall()) {
                let e = "prefab/treasure_recharge";
                ToolUtils.loadCommonPrefab(this.treasureRechargePrefab, BundleNameDefined.Bundle_treasure, e, (e => {
                    try {
                        if (this.treasureRechargePrefab = e, director.getScene().name != BundleNameDefined.hall_scene) {
                            return;
                        }
                        let t = director.getScene().getChildByName("Canvas");
                        if (t) {
                            let i = t.getChildByName("treasure_recharge");
                            if (ToolUtils.isObjValid(i)) {
                                i.active = true;
                            }
                            else {
                                i = instantiate(e);
                                i.parent = t;
                                this.checkRewardShowTop(t);
                                i.getComponent("TreasureRecharge").initParaData(a);
                            }
                        }
                    }
                    catch (e) {
                        TLog.printError("showTreasureRechargeView error= " + e);
                    }
                }));
            }
        }
        else {
            Utils.shared().showToast("Coming soon", 2);
        }
    }
    showMarketInvite(e) {
    }
    jumpToWhatsApp() {
        0 === TransferPlatform.shared().checkPackageInstalled("com.whatsapp") ? sys.openURL(ToolUtils.feedback_data.whurl) : TransferPlatform.shared().openApplicationChat("com.whatsapp", ToolUtils.feedback_data.whurl);
    }
    jumpToWhatsAppByUrl(e) {
        0 === TransferPlatform.shared().checkPackageInstalled("com.whatsapp") ? sys.openURL(e) : TransferPlatform.shared().openApplicationChat("com.whatsapp", e);
    }
    hasShowChooseGame() {
        let e = false;
        if (ToolUtils.judgeIfInHall()) {
            let a = director.getScene().getChildByName("Canvas");
            if (ToolUtils.isObjValid(a)) {
                let t = a.children.length;
                if (t >= 2) {
                    try {
                        let i = a.children[t - 2];
                        ToolUtils.isObjValid(i) && "node_guide" == i.name && (e = true);
                    }
                    catch (e) {
                        TLog.printError("hasShowChooseGame try-error:", e);
                    }
                }
            }
        }
        return e;
    }
    closeActivityView(e) {
        sys.isObjectValid(e) && this._utilLogicTool.closeActivityView(e);
    }
    showHallLeaderBoards(e = null) {
        if (ToolUtils.judgeIfInHall()) {
            let a = "prefab/rankings";
            ToolUtils.loadCommonPrefab(this.leaderBoardsPrefab, BundleNameDefined.Bundle_leaderBoards, a, (a => {
                try {
                    if (this.leaderBoardsPrefab = a, !ToolUtils.judgeIfInHall()) {
                        return;
                    }
                    let t;
                    sys.isObjectValid(e) && (t = e.parent_node);
                    ToolUtils.isObjValid(t) || (t = director.getScene().getChildByName("Canvas"));
                    let r = t.getChildByName("rankings");
                    if (ToolUtils.isObjValid(r)) {
                        r.active = true;
                    }
                    else {
                        r = instantiate(a);
                        r.parent = t;
                        this.checkRewardShowTop(t);
                        r.getComponent("RankingsMain").initParaData(e);
                    }
                }
                catch (e) {
                    TLog.printError("showHallLeaderBoards error= " + e);
                }
            }));
        }
    }
    showStoreRetainView(e = null) {
        let a = true;
        if (director.getScene().name == BundleNameDefined.switch_scence && (a = false), a) {
            let t = "prefab/shopRetain";
            ToolUtils.loadCommonPrefab(this.storeRetainPrefab, BundleNameDefined.bundle_wallet, t, (t => {
                try {
                    if (this.storeRetainPrefab = t, director.getScene().name == BundleNameDefined.switch_scence && (a = false), !a) {
                        return;
                    }
                    let r;
                    if (sys.isObjectValid(e) && (r = e.parent_node), !ToolUtils.isObjValid(r)) {
                        return;
                    }
                    let l = r.getChildByName("shopRetain");
                    if (ToolUtils.isObjValid(l)) {
                        l.active = true;
                    }
                    else {
                        l = instantiate(t);
                        l.parent = r;
                        this.checkRewardShowTop(r);
                        l.getComponent("ShopRetain").initParaData(e);
                    }
                }
                catch (e) {
                    TLog.printError("showStoreRetainView error= " + e);
                }
            }));
        }
    }
    removeNetImageDirectory() {
        if (sys.isNative) {
            let e = native.fileUtils.getWritablePath() + this.HEAD_CATCH_FOLDER;
            if (native.fileUtils.isDirectoryExist(e)) {
                let a = 0;
                for (let t of native.fileUtils.listFiles(e)) {
                    a += native.fileUtils.getFileSize(t);
                }
                a > 31457280 && native.fileUtils.removeDirectory(e);
            }
            let a = native.fileUtils.getWritablePath() + this.NET_IMAGE_CATCH_FOLDER;
            if (native.fileUtils.isDirectoryExist(a)) {
                let e = 0;
                for (let t of native.fileUtils.listFiles(a)) {
                    e += native.fileUtils.getFileSize(t);
                }
                e > 31457280 && native.fileUtils.removeDirectory(a);
            }
        }
    }
    showStoreKefuAskView(e = null) {
        let a = ToolUtils.judgeIfInHall() || ToolUtils.judgeIfInRummy();
        if (a) {
            let t = "prefab/kefu_ask";
            ToolUtils.loadCommonPrefab(this.kefuAskPrefab, BundleNameDefined.bundle_wallet, t, (t => {
                try {
                    if (this.kefuAskPrefab = t, a = ToolUtils.judgeIfInHall() || ToolUtils.judgeIfInRummy(), !a) {
                        return;
                    }
                    let r;
                    sys.isObjectValid(e) && (r = e.parent_node);
                    ToolUtils.isObjValid(r) || (r = director.getScene().getChildByName("Canvas"));
                    let l = r.getChildByName("kefu_ask");
                    ToolUtils.isObjValid(l) ? l.active = true : (l = instantiate(t), l.parent = r);
                    this.checkRewardShowTop(r);
                    l.getComponent("KefuAskView").initParaData(e);
                }
                catch (e) {
                    TLog.printError("showStoreKefuAskView error= " + e);
                }
            }));
        }
    }
    showHelpAlert(e = null) {
        let a = ToolUtils.judgeIfInHall() || ToolUtils.judgeIfInRummy();
        if (a) {
            let t = "prefab/help_alert";
            ToolUtils.loadCommonPrefab(this.helpAlertPrefab, BundleNameDefined.bundle_public, t, (t => {
                try {
                    if (this.helpAlertPrefab = t, a = ToolUtils.judgeIfInHall() || ToolUtils.judgeIfInRummy(), !a) {
                        return;
                    }
                    let r;
                    if (sys.isObjectValid(e) && (r = e.parent_node), !ToolUtils.isObjValid(r)) {
                        return;
                    }
                    let l = r.getChildByName("help_alert");
                    ToolUtils.isObjValid(l) ? l.active = true : (l = instantiate(t), l.parent = r);
                    this.checkRewardShowTop(r);
                    l.getComponent("HelpAlert").initParaData(e);
                }
                catch (e) {
                    TLog.printError("showHelpAlert error= " + e);
                }
            }));
        }
    }
    showFreeMatchPushView(e = null) {
    }
    showHallGameDisPlay(e = null, a = null) {
        let t = ToolUtils.judgeIfInHall();
        if (t) {
            let a = "prefab/props_manage";
            ToolUtils.loadCommonPrefab(this.hallGameDisplayPrefab, BundleNameDefined.Bundle_game_display, a, (a => {
                try {
                    if (this.hallGameDisplayPrefab = a, t = ToolUtils.judgeIfInHall(), !t) {
                        return;
                    }
                    let r, l;
                    if (sys.isObjectValid(e) && (r = e.parent_node, l = e.last_node), !ToolUtils.isObjValid(r)) {
                        return;
                    }
                    let s = r.getChildByName("props_manage");
                    if (ToolUtils.isObjValid(s)) {
                        s.active = true;
                    }
                    else {
                        ToolUtils.isObjValid(l) && (l.active = false);
                        s = instantiate(a);
                        s.parent = r;
                        this.checkRewardShowTop(r);
                        s.getComponent("PropsManager").initParaData({ ui_type: 0 }, (() => {
                            ToolUtils.isObjValid(l) && (l.active = true);
                        }));
                    }
                }
                catch (e) {
                    TLog.printError("showHallGameDisPlay error= " + e);
                }
            }));
        }
    }
    showRoomGameDisPlay(e = null) {
        let a = ToolUtils.judgeIfInRummy();
        if (a) {
            let t = "prefab/props_manage_room";
            ToolUtils.loadCommonPrefab(this.roomGameDisplayPrefab, BundleNameDefined.Bundle_game_display, t, (t => {
                try {
                    if (this.roomGameDisplayPrefab = t, a = ToolUtils.judgeIfInRummy(), !a) {
                        return;
                    }
                    let r;
                    if (sys.isObjectValid(e) && (r = e.parent_node), !ToolUtils.isObjValid(r)) {
                        return;
                    }
                    let l = r.getChildByName("props_manage_room");
                    if (ToolUtils.isObjValid(l)) {
                        l.active = true;
                    }
                    else {
                        l = instantiate(t);
                        l.parent = r;
                        this.checkRewardShowTop(r);
                        l.getComponent("PropsManager").initParaData({ ui_type: 1 });
                    }
                }
                catch (e) {
                    TLog.printError("showRoomGameDisPlay2 error= " + e);
                }
            }));
        }
    }
    showMeTicketListView(e = null) {
    }
    showTicketSelectView(e = null) {
        let a = ToolUtils.judgeIfInHall();
        if (a) {
            let t = "prefab/ticket_select";
            ToolUtils.loadCommonPrefab(this.ticketSelectPrefab, BundleNameDefined.Bundle_ticket, t, (t => {
                try {
                    if (this.ticketSelectPrefab = t, a = ToolUtils.judgeIfInHall(), !a) {
                        return;
                    }
                    let r, l;
                    if (sys.isObjectValid(e) && (r = e.parent_node, l = e.last_node), !ToolUtils.isObjValid(r)) {
                        return;
                    }
                    let s = r.getChildByName("ticket_select");
                    if (ToolUtils.isObjValid(s)) {
                        s.active = true;
                    }
                    else {
                        s = instantiate(t);
                        s.parent = r;
                        ToolUtils.isObjValid(l) && (l.active = false);
                        this.checkRewardShowTop(r);
                        s.getComponent("TicketsSelect").initParaData(e.data, 0, (() => {
                            ToolUtils.isObjValid(l) && (l.active = true);
                        }));
                    }
                }
                catch (e) {
                    TLog.printError("showTicketSelectView error:" + e);
                }
            }));
        }
    }
    showRoomTicketSelectView(e = null) {
        let a = ToolUtils.judgeIfInRummy();
        if (a) {
            let t = "prefab/ticket_room_select";
            ToolUtils.loadCommonPrefab(this.roomTicketSelectPrefab, BundleNameDefined.Bundle_ticket, t, (t => {
                try {
                    if (this.roomTicketSelectPrefab = t, a = ToolUtils.judgeIfInRummy(), !a) {
                        return;
                    }
                    let r;
                    if (sys.isObjectValid(e) && (r = e.parent_node), !ToolUtils.isObjValid(r)) {
                        return;
                    }
                    let l = r.getChildByName("ticket_room_select");
                    if (ToolUtils.isObjValid(l)) {
                        l.active = true;
                    }
                    else {
                        l = instantiate(t);
                        l.parent = r;
                        this.checkRewardShowTop(r);
                        l.getComponent("TicketsSelect").initParaData(e.data, 1);
                    }
                }
                catch (e) {
                    TLog.printError("showTicketSelectView error:" + e);
                }
            }));
        }
    }
    showTicketUsingView(e = null) {
        let a = ToolUtils.judgeIfInHall();
        if (a) {
            let t = "prefab/ticket_using";
            ToolUtils.loadCommonPrefab(this.ticketUsingPrefab, BundleNameDefined.Bundle_ticket, t, (t => {
                try {
                    if (this.ticketUsingPrefab = t, a = ToolUtils.judgeIfInHall(), !a) {
                        return;
                    }
                    let r;
                    if (sys.isObjectValid(e) && (r = e.parent_node), !ToolUtils.isObjValid(r)) {
                        return;
                    }
                    let l = r.getChildByName("ticket_using");
                    if (ToolUtils.isObjValid(l)) {
                        l.active = true;
                    }
                    else {
                        l = instantiate(t);
                        l.parent = r;
                        this.checkRewardShowTop(r);
                        l.getComponent("TicketsUsing").initParaData(e);
                    }
                }
                catch (e) {
                    TLog.printError("showTicketUsingView error:" + e);
                }
            }));
        }
    }
    showChipGameTypeView(e = null, a = null) {
    }
    showQuickChipRecharge(a) {
        if (0 === User.shared().charge_open) {
            return;
        }
        let t, r = false, l = true, s = "", o = 0, n = 0, d = 0, h = 0, c = 0;
        if (sys.isObjectValid(a) && (sys.isObjectValid(a.parent_node) && (t = a.parent_node), sys.isObjectValid(a.bShowNetTip) && (r = a.bShowNetTip), sys.isObjectValid(a.isShowTip) && (l = a.isShowTip), sys.isObjectValid(a.tid_key) && (s = a.tid_key), sys.isObjectValid(a.match_vid) && a.match_vid, sys.isObjectValid(a.min_entry) && (o = a.min_entry), sys.isObjectValid(a.vid) && (h = a.vid), sys.isObjectValid(a.in_room) && (c = a.in_room), sys.isObjectValid(a.auto_quick) && (n = a.auto_quick), sys.isObjectValid(a.is_pop) && (d = a.is_pop)), r) {
            if (0 == sys.getNetworkType()) {
                return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text91"), 3, 0, ToolUtils.getIsNormalDirection());
            }
            Utils.shared().showLoading(11, true, (() => {
                0 == sys.getNetworkType() ? Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text91"), 3, 0, ToolUtils.getIsNormalDirection()) : Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
            }));
        }
        let u = { score: o, new_vid: h, vid: h, in_room: c, auto_quick: n, is_pop: d };
        HttpManager.shared().doGetCommonRequest(u, HttpRequest.ChipLessPage, ((d, c, u) => {
            r && Utils.shared().hideLoading();
            try {
                if (200 != u) {
                    r && (0 == sys.getNetworkType() ? Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text91"), 3, 0, ToolUtils.getIsNormalDirection()) : Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection()));
                }
                else {
                    let r = ToolUtils.parseJson(c);
                    if (0 == r.ret) {
                        if (sys.isObjectValid(r.data)) {
                            let d;
                            sys.isObjectValid(r.data.ext) && (d = r.data.ext);
                            let c = { tid_key: s, parent_node: t, vid: h, isShowTip: l, ext: d, isquick: true, score: o, auto_quick: n };
                            sys.isObjectValid(d) && sys.isObjectValid(d.flag) && (c.flag = d.flag);
                            sys.isObjectValid(a) && sys.isObjectValid(a.checkKyc) && (c.checkKyc = Number(a.checkKyc));
                            sys.isObjectValid(r.data.type) && (c.type = Number(r.data.type), Utils.shared().doJumpLogic(r.data.type, c));
                        }
                    }
                    else {
                        sys.isObjectValid(r.desc) && r.desc.length > 0 && Utils.shared().showToast(r.desc, 2);
                    }
                }
            }
            catch (e) {
                TLog.printError("doGetQuickRechargePackageCallback:", e);
            }
        }));
    }
    showChipChargeAlert(e = null) {
        if (ToolUtils.judgeIfInHall()) {
            return void this.showHallQuickChargeAlert(e);
        }
        let a = ToolUtils.judgeIfInHall() || ToolUtils.judgeIfInRummy();
        if (a) {
            let t = "prefab/game_fast_buy", r = BundleNameDefined.Bundle_QuickCharge;
            ToolUtils.loadCommonPrefab(this.game_rechargePrefab, r, t, (t => {
                try {
                    if (this.game_rechargePrefab = t, a = ToolUtils.judgeIfInHall() || ToolUtils.judgeIfInRummy(), !a) {
                        return;
                    }
                    let r;
                    if (sys.isObjectValid(e) && (r = e.parent_node), !ToolUtils.isObjValid(r)) {
                        return;
                    }
                    let l = r.getChildByName("game_fast_buy");
                    if (ToolUtils.isObjValid(l)) {
                        l.active = true;
                    }
                    else {
                        l = instantiate(t);
                        l.parent = r;
                        l.getComponent("GameFastBuy").initView(e);
                        this.hideOtherQuickPayAlertByType(0);
                    }
                }
                catch (e) {
                    TLog.printError("showChipChargeAlert error:" + e);
                }
            }));
        }
    }
    showBonusGift(e = null) {
        let a = ToolUtils.judgeIfInRummy();
        if (a) {
            let t = "prefab/game_fast_buy", r = BundleNameDefined.Bundle_QuickCharge;
            ToolUtils.loadCommonPrefab(this.game_rechargePrefab, r, t, (t => {
                try {
                    if (this.game_rechargePrefab = t, a = ToolUtils.judgeIfInRummy(), !a) {
                        return;
                    }
                    let r;
                    sys.isObjectValid(e) && (r = e.parent_node);
                    ToolUtils.isObjValid(r) || (r = director.getScene().getChildByName("Canvas"));
                    let l = r.getChildByName("game_fast_buy");
                    if (ToolUtils.isObjValid(l)) {
                        l.active = true;
                    }
                    else {
                        l = instantiate(t);
                        l.parent = r;
                        l.getComponent("GameFastBuy").initView(e);
                        this.hideOtherQuickPayAlertByType(0);
                    }
                }
                catch (e) {
                    TLog.printError("showBonusGift error:" + e);
                }
            }));
        }
    }
    showHallQuickChargeAlert(e = null) {
        let a = ToolUtils.judgeIfInHall();
        if (a) {
            let t = "prefab/hall_fast_buy", r = BundleNameDefined.Bundle_QuickCharge;
            ToolUtils.loadCommonPrefab(this.hall_rechargePrefab, r, t, (t => {
                if (this.hall_rechargePrefab = t, a = ToolUtils.judgeIfInHall(), !a) {
                    return;
                }
                let r;
                if (sys.isObjectValid(e) && (r = e.parent_node), !ToolUtils.isObjValid(r)) {
                    return;
                }
                let l = r.getChildByName("hall_fast_buy");
                if (ToolUtils.isObjValid(l)) {
                    l.active = true;
                }
                else {
                    l = instantiate(t);
                    l.parent = r;
                    l.getComponent("HallFastBuy").initView(e);
                    this.hideOtherQuickPayAlertByType(0);
                }
            }));
        }
    }
    showChipBankruptAlert(e = null) {
        if (sys.isObjectValid(e) && sys.isObjectValid(e.ext) && sys.isObjectValid(e.ext.reward_list)) {
            let a = ToolUtils.format(i18nMgr.shared().getValueByKey("chip_bankrupt.time_left"), e.ext.times);
            User.shared().showChargeReward(e.ext.reward_list, null, a, 7);
        }
    }
    showEventPromotionView(e = null) {
    }
    showLeaderboardReward(e = null) {
        let a = ToolUtils.judgeIfInHall();
        if (a) {
            let t = "prefab/rankings_end_tip";
            ToolUtils.loadCommonPrefab(this.leaderBoardsTipPrefab, BundleNameDefined.Bundle_leaderBoards, t, (t => {
                try {
                    if (this.leaderBoardsTipPrefab = t, a = ToolUtils.judgeIfInHall(), !a) {
                        return;
                    }
                    let r;
                    sys.isObjectValid(e) && (r = e.parent_node);
                    ToolUtils.isObjValid(r) || ToolUtils.isObjValid(r) || (r = director.getScene().getChildByName("Canvas"));
                    let l = r.getChildByName("rankings_end_tip");
                    if (ToolUtils.isObjValid(l)) {
                        l.active = true;
                    }
                    else {
                        l = instantiate(t);
                        l.parent = r;
                        this.checkRewardShowTop(r);
                        l.getComponent("RankingsEndTip").initParaData(e);
                    }
                    e.act_id == PushEvent.JUMP_TO_LeaderBoardsReward ? HttpManager.shared().doGetCommonRequest(null, HttpRequest.HallLeaderBoardsDelRewardPopCache, ((e, a, t) => {
                    })) : HttpManager.shared().doGetCommonRequest(null, "Activity.Act_142.delRewardPopCache", ((e, a, t) => {
                    }));
                }
                catch (e) {
                    TLog.printError("showLeaderboardReward error:" + e);
                }
            }));
        }
    }
    getEnterMoneyApi(e, a = false, t = 0, i = 0, r = 0) {
        return this._utilLogicTool.getEnterMoneyApi(e, a, t, i, r);
    }
    getRecommendRoomIndex(e, a, t) {
        return this._utilLogicTool.getRecommendRoomIndex(e, a, t);
    }
    getCurRoomList(e, a) {
        return this._utilLogicTool.getCurRoomList(e, a);
    }
    getCurSelectRoomList(e, a, t, i, r, l) {
        return this._utilLogicTool.getCurSelectRoomList(e, a, t, i, r, l);
    }
    rollingNumbers(e, a, t, i = 10, r) {
        return new Promise((l => {
            const s = performance.now(), o = setInterval((() => {
                const i = (performance.now() - s) / t;
                if (i >= 1) {
                    r && r(a);
                    clearInterval(o);
                    l();
                }
                else {
                    const t = Math.floor(e + i * (a - e));
                    r && r(t);
                }
            }), i);
        }));
    }
    static stringToColor(e) {
        return e.startsWith("#") ? this.hexToColor(e) : e.startsWith("rgb") ? this.rgbToColor(e) : Color.WHITE;
    }
    static hexToColor(e) {
        let a = parseInt(e.slice(1, 3), 16), t = parseInt(e.slice(3, 5), 16), i = parseInt(e.slice(5, 7), 16);
        return new Color(a, t, i);
    }
    static rgbToColor(e) {
        let a = e.match(/\d+/g);
        if (a && 3 === a.length) {
            let e = parseInt(a[0]), t = parseInt(a[1]), i = parseInt(a[2]);
            return new Color(e, t, i);
        }
        return Color.WHITE;
    }
    static updateLabelMaterial(e, a) {
        resources.load("shader/material/" + a, Material, ((a, t) => {
            a ? error("load material error:", a) : ToolUtils.isObjValid(e) && sys.isObjectValid(e.getComponent(Label)) && e.getComponent(Label).setMaterial(t, 0);
        }));
    }
    getGameLockData() {
        return User.shared().game_lock_data || null;
    }
    checkHasRewardTip() {
        let e = false, a = director.getScene().getChildByName("Canvas");
        if (ToolUtils.isObjValid(a)) {
            let t = a.getChildByName("reward_tips");
            ToolUtils.isObjValid(t) && (e = true);
            let i = a.getChildByName("reward_tips_10Gold");
            ToolUtils.isObjValid(i) && (e = true);
            let r = a.getChildByName("reward_tips_chip_bankrupt");
            ToolUtils.isObjValid(r) && (e = true);
        }
        return e;
    }
    checkHasPopView(e) {
        let a = false;
        if (this.checkHasRewardTip()) {
            return a = true, a;
        }
        let t = director.getScene().getChildByName("Canvas"), i = t.getChildByName("flop_gold_task_game");
        if (ToolUtils.isObjValid(i)) {
            return a = true, a;
        }
        let r = t.getChildByName("restart_gift");
        if (ToolUtils.isObjValid(r)) {
            return a = true, a;
        }
        if (ToolUtils.isObjValid(e) && (r = e.getChildByName("restart_gift"), ToolUtils.isObjValid(r))) {
            return a = true, a;
        }
        let l = t.getChildByName("ConsecutiveGift");
        if (ToolUtils.isObjValid(l)) {
            return a = true, a;
        }
        if (ToolUtils.isObjValid(e) && (l = e.getChildByName("ConsecutiveGift"), ToolUtils.isObjValid(l))) {
            return a = true, a;
        }
        let o = t.getChildByName("BuyOneGetThree");
        if (ToolUtils.isObjValid(o)) {
            return a = true, a;
        }
        if (ToolUtils.isObjValid(e) && (o = e.getChildByName("BuyOneGetThree"), ToolUtils.isObjValid(o))) {
            return a = true, a;
        }
        let n = t.getChildByName("TwentyFourRecharge");
        if (ToolUtils.isObjValid(n)) {
            return a = true, a;
        }
        if (ToolUtils.isObjValid(e) && (n = e.getChildByName("TwentyFourRecharge"), ToolUtils.isObjValid(n))) {
            return a = true, a;
        }
        let d = t.getChildByName("membership_upgrade");
        if (ToolUtils.isObjValid(d)) {
            return a = true, a;
        }
        if (ToolUtils.isObjValid(e) && (d = e.getChildByName("membership_upgrade"), ToolUtils.isObjValid(d))) {
            return a = true, a;
        }
        let h = t.getChildByName("game_fast_buy");
        return ToolUtils.isObjValid(h) || ToolUtils.isObjValid(e) && (h = e.getChildByName("game_fast_buy"), ToolUtils.isObjValid(h)) ? (a = true, a) : a;
    }
    getCashUnlockRoomNum(e, a, t) {
        let r = 0, l = 0, s = this.getGameLockData();
        if (s && sys.isObjectValid(s.cash) && s.cash) {
            switch (e) {
                case HowToPlayDefined.RUMMY_POINTS:
                    if (sys.isObjectValid(s.cash.points) && s.cash.points && Array.isArray(s.cash.points)) {
                        l = s.cash.points.length;
                        for (let e = 0; e < l; e++) {
                            let i = s.cash.points[e].mod, l = s.cash.points[e].player, o = s.cash.points[e].num || 0;
                            if (t == i && a == l) {
                                r = o;
                                break;
                            }
                        }
                    }
                    break;
                case HowToPlayDefined.RUMMY_POOL:
                    if (sys.isObjectValid(s.cash.pool) && s.cash.pool && Array.isArray(s.cash.pool)) {
                        l = s.cash.pool.length;
                        for (let e = 0; e < l; e++) {
                            let i = s.cash.pool[e].mod, l = s.cash.pool[e].player, o = s.cash.pool[e].num || 0;
                            if (t == i && a == l) {
                                r = o;
                                break;
                            }
                        }
                    }
                    break;
                case HowToPlayDefined.RUMMY_DEALS: if (sys.isObjectValid(s.cash.deals) && s.cash.deals && Array.isArray(s.cash.deals)) {
                    l = s.cash.deals.length;
                    for (let e = 0; e < l; e++) {
                        let i = s.cash.deals[e].mod, l = s.cash.deals[e].player, o = s.cash.deals[e].num || 0;
                        if (t == i && a == l) {
                            r = o;
                            break;
                        }
                    }
                }
            }
        }
        return r;
    }
    judgeCashPoolAllRoomLock() {
        let a = [2, 6], t = [101, 201], r = this.getGameLockData();
        if (!(r && sys.isObjectValid(r.cash) && r.cash && sys.isObjectValid(r.cash.pool) && Array.isArray(r.cash.pool) && 0 !== r.cash.pool.length)) {
            return false;
        }
        for (let i of a) {
            for (let a of t) {
                let t = Utils.shared().getCurSelectRoomList(0, HowToPlayDefined.RUMMY_POOL, i, a, 0, 0);
                if (!t || !Array.isArray(t) || 0 === t.length) {
                    return false;
                }
                for (let e of t) {
                    let t = this.judgeCashPoolRoomUnlock(i, a, e.entry);
                    if (t && t.openBol) {
                        return false;
                    }
                }
            }
        }
        return true;
    }
    cleanPublicAssetsReference() {
        this._utilLogicTool.cleanPublicAssetsReference();
    }
    judgeCashDealsAllRoomLock() {
        let a = { 2: [2, 3], 6: [3, 6] }, t = this.getGameLockData();
        if (!(t && sys.isObjectValid(t.cash) && t.cash && sys.isObjectValid(t.cash.deals) && Array.isArray(t.cash.deals) && 0 !== t.cash.deals.length)) {
            return false;
        }
        for (let [t, i] of Object.entries(a)) {
            let a = Number(t);
            for (let t of i) {
                let i = Utils.shared().getCurSelectRoomList(0, HowToPlayDefined.RUMMY_DEALS, a, 0, t, 0);
                if (!i || !Array.isArray(i) || 0 === i.length) {
                    return false;
                }
                for (let e of i) {
                    let i = this.judgeCashDealsRoomUnlock(a, t, e.entry);
                    if (i && i.openBol) {
                        return false;
                    }
                }
            }
        }
        return true;
    }
    getCashPoolAllRoomLockTipsNum() {
        let a = [2, 6], t = [101, 201], r = this.getGameLockData();
        if (!(r && sys.isObjectValid(r.cash) && r.cash && sys.isObjectValid(r.cash.pool) && Array.isArray(r.cash.pool) && 0 !== r.cash.pool.length)) {
            return 0;
        }
        for (let i of a) {
            for (let a of t) {
                let t = Utils.shared().getCurSelectRoomList(0, HowToPlayDefined.RUMMY_POOL, i, a, 0, 0);
                if (t && Array.isArray(t) && 0 !== t.length) {
                    for (let e of t) {
                        let t = this.judgeCashPoolRoomUnlock(i, a, e.entry);
                        if (t && !t.openBol) {
                            return t.num || 0;
                        }
                    }
                }
            }
        }
        return 0;
    }
    getCashDealsAllRoomLockTipsNum() {
        let a = { 2: [2, 3], 6: [3, 6] }, t = this.getGameLockData();
        if (!(t && sys.isObjectValid(t.cash) && t.cash && sys.isObjectValid(t.cash.deals) && Array.isArray(t.cash.deals) && 0 !== t.cash.deals.length)) {
            return 0;
        }
        for (let [t, i] of Object.entries(a)) {
            let a = Number(t);
            for (let t of i) {
                let i = Utils.shared().getCurSelectRoomList(0, HowToPlayDefined.RUMMY_DEALS, a, 0, t, 0);
                if (i && Array.isArray(i) && 0 !== i.length) {
                    for (let e of i) {
                        let i = this.judgeCashDealsRoomUnlock(a, t, e.entry);
                        if (i && !i.openBol) {
                            return i.num || 0;
                        }
                    }
                }
            }
        }
        return 0;
    }
    judgeCashPointExistUnlockRoom(a, t) {
        let r = false, l = this.getGameLockData(), s = Utils.shared().getCurSelectRoomList(0, HowToPlayDefined.RUMMY_POINTS, a, 0, 0, t);
        if (s && Array.isArray(s) && s.length) {
            let e = s.length;
            if (l && sys.isObjectValid(l.cash) && l.cash && sys.isObjectValid(l.cash.points) && l.cash.points && Array.isArray(l.cash.points) && l.cash.points.length > 0) {
                for (let i = 0; i < e; i++) {
                    let e = this.judgeCashPointRoomUnlock(a, t, s[i].entry);
                    if (e && e.openBol) {
                        r = true;
                        break;
                    }
                }
            }
            else {
                r = true;
            }
        }
        return r;
    }
    judgeCashPoolExistUnlockRoom(a, t) {
        let r = false, l = this.getGameLockData(), s = Utils.shared().getCurSelectRoomList(0, HowToPlayDefined.RUMMY_POOL, a, t, 0, 0);
        if (s && Array.isArray(s) && s.length) {
            let e = s.length;
            if (l && sys.isObjectValid(l.cash) && l.cash && sys.isObjectValid(l.cash.pool) && l.cash.pool && Array.isArray(l.cash.pool) && l.cash.pool.length > 0) {
                for (let i = 0; i < e; i++) {
                    let e = this.judgeCashPoolRoomUnlock(a, t, s[i].entry);
                    if (e && e.openBol) {
                        r = true;
                        break;
                    }
                }
            }
            else {
                r = true;
            }
        }
        return r;
    }
    judgeCashDealsExistUnlockRoom(a, t) {
        let r = false, l = this.getGameLockData(), s = Utils.shared().getCurSelectRoomList(0, HowToPlayDefined.RUMMY_DEALS, a, 0, t, 0);
        if (s && Array.isArray(s) && s.length) {
            let e = s.length;
            if (l && sys.isObjectValid(l.cash) && l.cash && sys.isObjectValid(l.cash.deals) && l.cash.deals && Array.isArray(l.cash.deals) && l.cash.deals.length > 0) {
                for (let i = 0; i < e; i++) {
                    let e = this.judgeCashDealsRoomUnlock(a, t, s[i].entry);
                    if (e && e.openBol) {
                        r = true;
                        break;
                    }
                }
            }
            else {
                r = true;
            }
        }
        return r;
    }
    judgeCashPointRoomUnlock(e, a, t) {
        let r = true, l = 0, s = this.getGameLockData();
        if (s && sys.isObjectValid(s.cash) && s.cash && sys.isObjectValid(s.cash.points) && s.cash.points && Array.isArray(s.cash.points)) {
            let i = s.cash.points.length;
            for (let o = 0; o < i; o++) {
                let i = s.cash.points[o].mod, n = s.cash.points[o].player, d = s.cash.points[o].unlock, h = s.cash.points[o].min_entry, c = s.cash.points[o].num || 0;
                if (a == i && e == n) {
                    0 == d && (h > 0 ? t >= h && (r = false, l = c || 0) : 0 == h || (r = false, l = c || 0));
                    break;
                }
            }
        }
        return { openBol: r, num: l };
    }
    judgeCashPoolRoomUnlock(e, a, t) {
        let r = true, l = 0, s = this.getGameLockData();
        if (s && sys.isObjectValid(s.cash) && s.cash && sys.isObjectValid(s.cash.pool) && s.cash.pool && Array.isArray(s.cash.pool)) {
            let i = s.cash.pool.length;
            for (let o = 0; o < i; o++) {
                let i = s.cash.pool[o].score, n = s.cash.pool[o].player, d = s.cash.pool[o].unlock, h = s.cash.pool[o].min_entry, c = s.cash.pool[o].num || 0;
                if (a == i && e == n) {
                    0 == d && (h > 0 ? t >= h && (r = false, l = c || 0) : 0 == h || (r = false, l = c || 0));
                    break;
                }
            }
        }
        return { openBol: r, num: l };
    }
    judgeCashDealsRoomUnlock(e, a, t) {
        let r = true, l = 0, s = this.getGameLockData();
        if (s && sys.isObjectValid(s.cash.deals) && s.cash.deals && Array.isArray(s.cash.deals)) {
            let i = s.cash.deals.length;
            for (let o = 0; o < i; o++) {
                let i = s.cash.deals[o].round, n = s.cash.deals[o].player, d = s.cash.deals[o].unlock, h = s.cash.deals[o].min_entry, c = s.cash.deals[o].num || 0;
                if (a == i && e == n) {
                    0 == d && (h > 0 ? t >= h && (r = false, l = c || 0) : 0 == h || (r = false, l = c || 0));
                    break;
                }
            }
        }
        return { openBol: r, num: l };
    }
    judgeMatchRoomUnlock() {
        let e = true, a = 0, t = this.getGameLockData();
        return t && sys.isObjectValid(t.match) && t.match && sys.isObjectValid(t.match.unlock) && 0 == t.match.unlock && (e = false, a = t.match.num || 0), { openBol: e, num: a };
    }
    judgeMutliTableUnlock() {
        let e = true, a = 0, t = this.getGameLockData();
        return sys.isObjectValid(t) && t && sys.isObjectValid(t.multi_table) && t.multi_table && sys.isObjectValid(t.multi_table.unlock) && 0 == t.multi_table.unlock && (e = false, a = t.multi_table.num || 0), { openBol: e, num: a };
    }
    showRoomUnlockToast(a = 0, t) {
        if (a > 1) {
            return;
        }
        let i = t || 0, r = ToolUtils.format(i18nMgr.shared().getValueByKey("choose_game.unlock_tips"), i) || "";
        Utils.shared().showToast(r, 3);
    }
    showMutliTableUnlockToast(a) {
        let t = a || 0, i = ToolUtils.format(i18nMgr.shared().getValueByKey("choose_game.unlock_tips"), t) || "";
        Utils.shared().showToast(i, 3);
    }
    showRoomUnlockDialog(a, t) {
        if (null == a || null == a || a > 1 || null == t || null == t || t <= 0) {
            return;
        }
        let i = t || 0, r = { bLandscape: ToolUtils.getIsNormalDirection(), strContent: ToolUtils.format(i18nMgr.shared().getValueByKey("choose_game.unlock_tips"), i) || "", strTitle: i18nMgr.shared().getValueByKey("email.tips"), sureKey: "email.play_now" };
        Utils.shared().showCommonAlert(r, (t => {
            if (1 == t) {
                if (3 == a) {
                    if (!User.shared().checkCanPlayCashGame(CheckModule.CHIPS_PLAY)) {
                        return;
                    }
                }
                else if (!User.shared().checkCanPlayCashGame(CheckModule.CASH_PLAY)) {
                    return;
                }
                let t = null, i = null, r = {}, l = {}, s = -1, o = true, n = 0, d = HowToPlayDefined.RUMMY_POINTS, h = User.shared().processFindBestRoom(n, d);
                if (null == d || null == d) {
                    return;
                }
                if (h && h.vRoomlist && (t = h.vRoomlist || null), h && h.findIndex >= 0 && t && Array.isArray(t) && t.length > 0) {
                    if (s = h.bestIndex, l = Utils.shared().judgeCashPointRoomUnlock(h.bestRoom.player, h.bestRoom.mode, h.bestRoom.entry), l && l.openBol) {
                        if (o = false, null == s || null == s || s < 0 || !t[s]) {
                            return;
                        }
                        User.shared().enterGame({ gameType: n, rummyType: d, roomInfo: t[s] });
                    }
                    else if (s > 0) {
                        let a = s - 1;
                        if (d == HowToPlayDefined.RUMMY_POINTS) {
                            for (; a >= 0 && !r.openBol;) {
                                i = t[a];
                                r = Utils.shared().judgeCashPointRoomUnlock(i.player, i.mode, i.entry);
                                r && !r.openBol && a--;
                            }
                        }
                        if (r && r.openBol && i) {
                            if (User.shared().data.money >= i.min_money) {
                                if (o = false, null == a || null == a || a < 0 || !t[a]) {
                                    return;
                                }
                                User.shared().enterGame({ gameType: n, rummyType: d, roomInfo: t[a] });
                            }
                        }
                    }
                }
                if (o) {
                    let a, t;
                    if (r && r.openBol && i) {
                        a = i.vid;
                        t = i.entry;
                    }
                    else {
                        let i = Utils.shared().getCurRoomList(0, d);
                        i && Array.isArray(i) && i.length && (a = i[0].vid, t = i[0].entry);
                    }
                    if (null != a && null != t) {
                        Utils.shared().showQuickRecharge(a, null, true, "", 0, t, true, 0, 1);
                        let i = PhpReportDefined.pay_scene.hall_less_money;
                        ToolUtils.getIsInRoom() && (i = PhpReportDefined.pay_scene.game_selectroom_less_money);
                        User.shared().updatePayScene(i, Number(a));
                    }
                }
            }
        }), false);
    }
    showGameRatingAlert(e = null) {
    }
    checkMemberShipUpgradeShown() {
        let e = director.getScene().getChildByName("Canvas").getChildByName("membership_upgrade");
        return !!ToolUtils.isObjValid(e);
    }
    showMemberShipUpgradeView(a) {
        if (director.getScene().name == BundleNameDefined.switch_scence) {
            return;
        }
        let t = director.getScene().getChildByName("Canvas"), r = "prefab/membership_upgrade";
        if (ToolUtils.getIsInRoom()) {
            if (r = "prefab/membership_upgrade_game", 0 == ToolUtils.isInGameScene) {
                return;
            }
            if (Utils.shared().checkGameFlopCashShown()) {
                return;
            }
        }
        else if (!sys.isObjectValid(User.shared().clubUpgradeMsg)) {
            return void PushCenter.shared().pushEvent(PushEvent.Update_NextPopActivity);
        }
        let l = BundleNameDefined.bundle_club;
        ToolUtils.loadCommonPrefab(null, l, r, (i => {
            try {
                if ("prefab/membership_upgrade" == r && !ToolUtils.judgeIfInHall()) {
                    return;
                }
                if ("prefab/membership_upgrade_game" == r && !ToolUtils.getIsInRoom()) {
                    return;
                }
                if (ToolUtils.getIsInRoom()) {
                    if (0 == ToolUtils.isInGameScene) {
                        return;
                    }
                    if (Utils.shared().checkGameFlopCashShown()) {
                        return;
                    }
                }
                ToolUtils.isObjValid(t) || (t = director.getScene().getChildByName("Canvas"));
                let l = t.getChildByName("membership_upgrade");
                if (ToolUtils.isObjValid(l)) {
                    let e = l.getComponent("MemberShipUpgrade");
                    e.initParaData(a);
                    l.name = "membership_upgrade";
                    e.initView();
                    l.active = true;
                }
                else {
                    l = instantiate(i);
                    l.parent = t;
                    l.name = "membership_upgrade";
                    l.getComponent("MemberShipUpgrade").initParaData(a);
                }
            }
            catch (e) {
                TLog.printError("showMemberShipUpgradeView error:" + e);
            }
        }));
    }
    showRestartGiftAlert(e = null) {
        if (director.getScene().name == BundleNameDefined.switch_scence) {
            return;
        }
        let a = null;
        if (sys.isObjectValid(e) && (a = e.parent_node), !ToolUtils.isObjValid(a)) {
            return;
        }
        let t = "prefab/supervalue_gift";
        ToolUtils.getIsInRoom() && (t = "prefab/supervalue_gift_game");
        a = director.getScene().getChildByName("Canvas");
        let r = BundleNameDefined.bundle_firstRecharge;
        ToolUtils.loadCommonPrefab(null, r, t, (i => {
            try {
                if ("prefab/supervalue_gift" == t && !ToolUtils.judgeIfInHall()) {
                    return;
                }
                if ("prefab/supervalue_gift_game" == t && !ToolUtils.getIsInRoom()) {
                    return;
                }
                this.restartGiftPrefab = i;
                ToolUtils.isObjValid(a) || (a = director.getScene().getChildByName("Canvas"));
                let r = a.getChildByName("restart_gift");
                if (ToolUtils.isObjValid(r)) {
                    r.active = true;
                }
                else {
                    r = instantiate(i);
                    r.parent = a;
                    r.name = "restart_gift";
                    r.getComponent("SuperValueGift").initParaData(e);
                }
            }
            catch (e) {
                TLog.printError("showRestartGiftAlert error:" + e);
            }
        }));
    }
    showFaqMain(e = null) {
        let a = ToolUtils.judgeIfInHall();
        if (a) {
            let t = "prefab/faq_node", r = BundleNameDefined.bundle_public;
            ToolUtils.loadCommonPrefab(this.faqMainPrefab, r, t, (t => {
                try {
                    if (this.faqMainPrefab = t, a = ToolUtils.judgeIfInHall(), !a) {
                        return;
                    }
                    let r;
                    sys.isObjectValid(e) && (r = e.parent_node);
                    ToolUtils.isObjValid(r) || (r = director.getScene().getChildByName("Canvas"));
                    let l = r.getChildByName("faq_node");
                    if (ToolUtils.isObjValid(l)) {
                        l.active = true;
                    }
                    else {
                        l = instantiate(t);
                        l.parent = r;
                        l.getComponent("FaqMain").init(e);
                    }
                }
                catch (e) {
                    TLog.printError("showFaqMain error:" + e);
                }
            }));
        }
    }
    showFaqDetails(e = null) {
    }
    showFlopCashAct(e = null) {
        let a = ToolUtils.judgeIfInHall();
        if (a) {
            let t = "prefab/beginner_flip_task", r = BundleNameDefined.Bundle_FlopCashAct;
            ToolUtils.loadCommonPrefab(this.flopCashActHallPrefab, r, t, (t => {
                try {
                    if (this.flopCashActHallPrefab = t, a = ToolUtils.judgeIfInHall(), !a) {
                        return;
                    }
                    let r;
                    sys.isObjectValid(e) && (r = e.parent_node);
                    ToolUtils.isObjValid(r) || (r = director.getScene().getChildByName("Canvas"));
                    let l = r.getChildByName("beginner_flip_task");
                    if (ToolUtils.isObjValid(l)) {
                        l.active = true;
                    }
                    else {
                        l = instantiate(t);
                        l.parent = r;
                        l.getComponent("BeginnerFlipTaskAct").initParaData(e);
                    }
                }
                catch (e) {
                    TLog.printError("showFlopCashAct error:" + e);
                }
            }));
        }
    }
    checkGameFlopCashShown() {
        let e = director.getScene().getChildByName("Canvas").getChildByName("beginner_flip_task_game");
        return !!ToolUtils.isObjValid(e);
    }
    showFlopCashActInGame(e = null) {
        let a = ToolUtils.getIsInRoom();
        if (a) {
            let t = "prefab/beginner_flip_task_game", r = BundleNameDefined.Bundle_FlopCashAct;
            ToolUtils.loadCommonPrefab(this.flopCashActGamePrefab, r, t, (t => {
                try {
                    if (this.flopCashActGamePrefab = t, a = ToolUtils.getIsInRoom(), !a) {
                        return;
                    }
                    let r;
                    sys.isObjectValid(e) && (r = e.parent_node);
                    ToolUtils.isObjValid(r) || (r = director.getScene().getChildByName("Canvas"));
                    let l = r.getChildByName("beginner_flip_task_game");
                    if (ToolUtils.isObjValid(l)) {
                        l.active = true;
                    }
                    else {
                        l = instantiate(t);
                        l.parent = r;
                        l.getComponent("BeginnerFlipTaskActInGame").initParaData(e);
                    }
                }
                catch (e) {
                    TLog.printError("showFlopCashAct error:" + e);
                }
            }));
        }
    }
    showFlopCashRecords(e = null) {
        let a = ToolUtils.judgeIfInHall();
        if (a) {
            let t = "prefab/beginner_flip_record", r = BundleNameDefined.Bundle_FlopCashAct;
            ToolUtils.loadCommonPrefab(this.flopCashActRecordsPrefab, r, t, (t => {
                try {
                    if (this.flopCashActRecordsPrefab = t, a = ToolUtils.judgeIfInHall(), !a) {
                        return;
                    }
                    let r;
                    sys.isObjectValid(e) && (r = e.parent_node);
                    ToolUtils.isObjValid(r) || (r = director.getScene().getChildByName("Canvas"));
                    let l = r.getChildByName("beginner_flip_record");
                    if (ToolUtils.isObjValid(l)) {
                        l.active = true;
                    }
                    else {
                        l = instantiate(t);
                        l.parent = r;
                        l.getComponent("BeginnerFlipTaskRecord").initParaData(e);
                    }
                }
                catch (e) {
                    TLog.printError("showFlopCashRecords error:" + e);
                }
            }));
        }
    }
    showBagView(e = null) {
    }
    showMatchInfoView(a, t, i = -1) {
        ToolUtils.loadCommonPrefab(this.matchInfoPrefab, BundleNameDefined.bundle_hallTopUI, "prefab/match_details", (r => {
            try {
                if (this.matchInfoPrefab = r, !ToolUtils.judgeIfInHall()) {
                    return;
                }
                let l, o = director.getScene().getChildByName("Canvas"), n = o.getChildByName("match_details");
                ToolUtils.isObjValid(n) ? l = n : (l = instantiate(r), o.addChild(l));
                l.active = true;
                let d = l.getComponent("MatchDetails"), h = { msg: a, func: t, showIdx: i };
                d.setParaData(h);
                Utils.shared().checkRewardShowTop(o);
            }
            catch (e) {
                TLog.printError("showMatchInfoView error= " + e);
            }
        }));
    }
    showDailyFireSaleView(e) {
    }
    showWithdrawalStatusView(e) {
        director.getScene().name != BundleNameDefined.switch_scence && ToolUtils.loadCommonPrefab(this.withdrawalStutusPrefab, BundleNameDefined.bundle_wallet, "prefab/withdrawal_status", (a => {
            try {
                if (this.withdrawalStutusPrefab = a, director.getScene().name == BundleNameDefined.switch_scence) {
                    return;
                }
                let t = director.getScene().getChildByName("Canvas"), i = t.getChildByName("withdrawal_status");
                if (!ToolUtils.isObjValid(i)) {
                    i = instantiate(a);
                    i.getComponent("WithdrawalStatus").initParaData(e);
                    i.parent = t;
                    this.checkRewardShowTop(t);
                }
            }
            catch (e) {
                TLog.printError("showWithdrawalStatusView error:" + e);
            }
        }));
    }
    startLoadSubGame(e, a) {
        if (0 == ToolUtils.getSubGameBundleName(e).length) {
            return false;
        }
        ToolUtils._gameLoadInfo[e] || (ToolUtils._gameLoadInfo[e] = { isLoading: false, percent: 0 });
        ToolUtils._gameLoadInfo[e].isLoading || (ToolUtils._gameLoadInfo[e].isLoading = true, ToolUtils.startLoadSubGame(e, a, (a => {
            -1 != a ? (ToolUtils._gameLoadInfo[e].percent = a, PushCenter.shared().pushEvent(PushEvent.UpdateGameDownloadProgress, { game_type: e, progress: a })) : PushCenter.shared().pushEvent(PushEvent.OnGameDownloadError, { game_type: e });
        })));
    }
    showSportCricket_main(e = null) {
        if (!ToolUtils.checkIsGameDownLoad(HallGameType.LOBBY_GAME_TYPE_YES11)) {
            const gameType = HallGameType.LOBBY_GAME_TYPE_YES11;
            if (ToolUtils._gameLoadInfo[gameType]?.isLoading) {
                this.showToast("Downloading game resources, please wait...", 2);
                return;
            }
            this.showToast("Downloading cricket resources...", 2);
            ToolUtils.startLoadSubGame(gameType, ToolUtils.getDownLoadBundleUrl(gameType), (progress) => {
                PushCenter.shared().pushEvent(progress < 0 ? PushEvent.OnGameDownloadError : PushEvent.UpdateGameDownloadProgress,
                    { game_type: gameType, progress });
                if (progress < 0) this.showToast("Download failed. Please try again.", 2);
            }).then((ready) => {
                if (ready && ToolUtils.judgeIfInHall()) this.showSportCricket_main(e);
            });
            return;
        }
        let a = ToolUtils.judgeIfInHall();
        a && ToolUtils.loadCommonPrefab(this.cricket_mainPrefab, BundleNameDefined.Bundle_Yes11, "prefab/cricket_main", (t => {
            try {
                if (this.cricket_mainPrefab = t, a = ToolUtils.judgeIfInHall(), !a) {
                    return;
                }
                let r;
                sys.isObjectValid(e) && (r = e.parent_node);
                ToolUtils.isObjValid(r) || (r = director.getScene().getChildByName("Canvas"));
                let l = r.getChildByName("cricket_main");
                if (ToolUtils.isObjValid(l)) {
                    l.active = true;
                }
                else {
                    l = instantiate(t);
                    l.name = "cricket_main";
                    l.parent = r;
                    l.getComponent("SportCricket_Main").init(e);
                }
            }
            catch (e) {
                TLog.printError("showSportCricket_main error:" + e);
            }
        }));
    }
    showSportCricket_chooseGame(e = null) {
        let a = ToolUtils.judgeIfInHall();
        a && ToolUtils.loadCommonPrefab(this.cricket_chooseGamePrefab, BundleNameDefined.Bundle_Yes11, "prefab/cricket_choosegame", (t => {
            try {
                if (this.cricket_chooseGamePrefab = t, a = ToolUtils.judgeIfInHall(), !a) {
                    return;
                }
                let r;
                sys.isObjectValid(e) && (r = e.parent_node);
                ToolUtils.isObjValid(r) || (r = director.getScene().getChildByName("Canvas"));
                let l = r.getChildByName("cricket_choosegame");
                if (ToolUtils.isObjValid(l)) {
                    l.active = true;
                }
                else {
                    l = instantiate(t);
                    l.parent = r;
                    l.getComponent("SportCricket_ChooseGame").init(e);
                }
            }
            catch (e) {
                TLog.printError("showSportCricket_chooseGame error:" + e);
            }
        }));
    }
    showSportCricket_gameDetails(e = null) {
        let a = ToolUtils.judgeIfInHall();
        a && ToolUtils.loadCommonPrefab(this.cricket_gameDetailsPrefab, BundleNameDefined.Bundle_Yes11, "prefab/cricket_gamedetails", (t => {
            try {
                if (this.cricket_gameDetailsPrefab = t, a = ToolUtils.judgeIfInHall(), !a) {
                    return;
                }
                let r;
                sys.isObjectValid(e) && (r = e.parent_node);
                ToolUtils.isObjValid(r) || (r = director.getScene().getChildByName("Canvas"));
                let l = r.getChildByName("cricket_gamedetails");
                if (ToolUtils.isObjValid(l)) {
                    l.active = true;
                }
                else {
                    l = instantiate(t);
                    l.parent = r;
                    l.getComponent("SportCricket_GameDetails").init(e);
                }
            }
            catch (e) {
                TLog.printError("showSportCricket_gameDetails error:" + e);
            }
        }));
    }
    showSportCricket_plusJiangChi(e = null) {
        let a = ToolUtils.judgeIfInHall();
        a && ToolUtils.loadCommonPrefab(this.cricket_plusJiangChiPrefab, BundleNameDefined.Bundle_Yes11, "prefab/cricket_guaranteed_plus", (t => {
            try {
                if (this.cricket_plusJiangChiPrefab = t, a = ToolUtils.judgeIfInHall(), !a) {
                    return;
                }
                let r;
                sys.isObjectValid(e) && (r = e.parent_node);
                ToolUtils.isObjValid(r) || (r = director.getScene().getChildByName("Canvas"));
                let l = r.getChildByName("cricket_guaranteed_plus");
                if (ToolUtils.isObjValid(l)) {
                    l.active = true;
                }
                else {
                    l = instantiate(t);
                    l.parent = r;
                    l.getComponent("SportCricket_PlusJiangChi").init(e);
                }
            }
            catch (e) {
                TLog.printError("showSportCricket_gameDetails error:" + e);
            }
        }));
    }
    showSportCricket_createTeam(e = null) {
        let a = ToolUtils.judgeIfInHall();
        a && ToolUtils.loadCommonPrefab(this.cricket_createTeamPrefab, BundleNameDefined.Bundle_Yes11, "prefab/cricket_createteam", (t => {
            try {
                if (this.cricket_createTeamPrefab = t, a = ToolUtils.judgeIfInHall(), !a) {
                    return;
                }
                let r;
                sys.isObjectValid(e) && (r = e.parent_node);
                ToolUtils.isObjValid(r) || (r = director.getScene().getChildByName("Canvas"));
                let l = r.getChildByName("cricket_createteam");
                if (ToolUtils.isObjValid(l)) {
                    l.active = true;
                }
                else {
                    l = instantiate(t);
                    l.parent = r;
                    l.getComponent("SportCricket_CreateTeam").init(e);
                }
            }
            catch (e) {
                TLog.printError("showSportCricket_createTeam error:" + e);
            }
        }));
    }
    showSportCricket_fastCreateTeam(e = null) {
    }
    showSportCricket_loadTeamStatViewCmp(e) {
        let a = ToolUtils.judgeIfInHall();
        if (a) {
            let t = "prefab/cricket_teamstatscmp", r = BundleNameDefined.Bundle_Yes11, l = this.cricket_teamStatCmpPrefab;
            ToolUtils.loadCommonPrefab(l, r, t, (t => {
                try {
                    if (this.cricket_teamStatCmpPrefab = t, a = ToolUtils.judgeIfInHall(), !a) {
                        return;
                    }
                    sys.isObjectValid(e) && e(this.cricket_teamStatCmpPrefab);
                }
                catch (e) {
                    TLog.printError("showSportCricket_loadTeamStatViewCmp error:" + e);
                }
            }));
        }
    }
    showSportCricket_fullTeamStatView(e = null) {
        let a = ToolUtils.judgeIfInHall();
        if (a) {
            let t = "prefab/cricket_teamstats", r = BundleNameDefined.Bundle_Yes11, l = this.cricket_fullTeamStatPrefab;
            ToolUtils.loadCommonPrefab(l, r, t, (t => {
                try {
                    if (this.cricket_fullTeamStatPrefab = t, a = ToolUtils.judgeIfInHall(), !a) {
                        return;
                    }
                    let r;
                    sys.isObjectValid(e) && (r = e.parent_node);
                    ToolUtils.isObjValid(r) || (r = director.getScene().getChildByName("Canvas"));
                    let l = r.getChildByName("cricket_teamstats");
                    if (ToolUtils.isObjValid(l)) {
                        l.active = true;
                    }
                    else {
                        l = instantiate(t);
                        l.parent = r;
                        l.getComponent("SportCricket_TeamStats").init(e);
                    }
                }
                catch (e) {
                    TLog.printError("showSportCricket_fastCreateTeam error:" + e);
                }
            }));
        }
    }
    showSportCricket_teamRecentMatchView(e = null) {
        let a = ToolUtils.judgeIfInHall();
        if (a) {
            let t = "prefab/cricket_team_recentmatch", r = BundleNameDefined.Bundle_Yes11, l = this.cricket_teamRecentMatchPrefab;
            ToolUtils.loadCommonPrefab(l, r, t, (t => {
                try {
                    if (this.cricket_teamRecentMatchPrefab = t, a = ToolUtils.judgeIfInHall(), !a) {
                        return;
                    }
                    let r;
                    sys.isObjectValid(e) && (r = e.parent_node);
                    ToolUtils.isObjValid(r) || (r = director.getScene().getChildByName("Canvas"));
                    let l = r.getChildByName("cricket_team_recentmatch");
                    if (ToolUtils.isObjValid(l)) {
                        l.active = true;
                    }
                    else {
                        l = instantiate(t);
                        l.parent = r;
                        l.getComponent("SportCricket_TeamRecentMatch").init(e);
                    }
                }
                catch (e) {
                    TLog.printError("showSportCricket_teamRecentMatchView error:" + e);
                }
            }));
        }
    }
    showSportCricket_playerTeamCompareView(e = null) {
        let a = ToolUtils.judgeIfInHall();
        if (a) {
            let t = "prefab/cricket_player_team_compare", r = BundleNameDefined.Bundle_Yes11, l = this.cricket_playerTeamComparePrefab;
            ToolUtils.loadCommonPrefab(l, r, t, (t => {
                try {
                    if (this.cricket_playerTeamComparePrefab = t, a = ToolUtils.judgeIfInHall(), !a) {
                        return;
                    }
                    let r;
                    sys.isObjectValid(e) && (r = e.parent_node);
                    ToolUtils.isObjValid(r) || (r = director.getScene().getChildByName("Canvas"));
                    let l = r.getChildByName("cricket_player_team_compare");
                    if (ToolUtils.isObjValid(l)) {
                        l.active = true;
                    }
                    else {
                        l = instantiate(t);
                        l.parent = r;
                        l.getComponent("SportCricket_PlayerTeamCompare").init(e);
                    }
                }
                catch (e) {
                    TLog.printError("showSportCricket_playerTeamCompareView error:" + e);
                }
            }));
        }
    }
    showSportCricket_venueMatchView(e = null) {
        let a = ToolUtils.judgeIfInHall();
        if (a) {
            let t = "prefab/cricket_team_venue", r = BundleNameDefined.Bundle_Yes11, l = this.cricket_venueMatchPrefab;
            ToolUtils.loadCommonPrefab(l, r, t, (t => {
                try {
                    if (this.cricket_venueMatchPrefab = t, a = ToolUtils.judgeIfInHall(), !a) {
                        return;
                    }
                    let r;
                    sys.isObjectValid(e) && (r = e.parent_node);
                    ToolUtils.isObjValid(r) || (r = director.getScene().getChildByName("Canvas"));
                    let l = r.getChildByName("cricket_team_venue");
                    if (ToolUtils.isObjValid(l)) {
                        l.active = true;
                    }
                    else {
                        l = instantiate(t);
                        l.parent = r;
                        l.getComponent("SportCricket_TeamVenue").init(e);
                    }
                }
                catch (e) {
                    TLog.printError("showSportCricket_venueMatchView error:" + e);
                }
            }));
        }
    }
    showSportCricket_gameSortView(e = null) {
        let a = ToolUtils.judgeIfInHall();
        if (a) {
            let t = "prefab/cricket_gamesort", r = BundleNameDefined.Bundle_Yes11, l = this.cricket_gameSortPrefab;
            ToolUtils.loadCommonPrefab(l, r, t, (t => {
                try {
                    if (this.cricket_gameSortPrefab = t, a = ToolUtils.judgeIfInHall(), !a) {
                        return;
                    }
                    let r;
                    sys.isObjectValid(e) && (r = e.parent_node);
                    ToolUtils.isObjValid(r) || (r = director.getScene().getChildByName("Canvas"));
                    let l = r.getChildByName("cricket_gamesort");
                    if (ToolUtils.isObjValid(l)) {
                        l.active = true;
                    }
                    else {
                        l = instantiate(t);
                        l.parent = r;
                        l.getComponent("SportCricket_GameSort").init(e);
                    }
                }
                catch (e) {
                    TLog.printError("showSportCricket_gameSortView error:" + e);
                }
            }));
        }
    }
    showSportCricket_teamPkMsgView(e = null) {
        let a = ToolUtils.judgeIfInHall();
        if (a) {
            let t = "prefab/cricket_team_pkmsg", r = BundleNameDefined.Bundle_Yes11, l = this.cricket_teamPkMsgPrefab;
            ToolUtils.loadCommonPrefab(l, r, t, (t => {
                try {
                    if (this.cricket_teamPkMsgPrefab = t, a = ToolUtils.judgeIfInHall(), !a) {
                        return;
                    }
                    let r;
                    sys.isObjectValid(e) && (r = e.parent_node);
                    ToolUtils.isObjValid(r) || (r = director.getScene().getChildByName("Canvas"));
                    let l = r.getChildByName("cricket_team_pkmsg");
                    if (ToolUtils.isObjValid(l)) {
                        l.active = true;
                    }
                    else {
                        l = instantiate(t);
                        l.parent = r;
                        l.getComponent("SportCricket_TeamPkMsg").init(e);
                    }
                }
                catch (e) {
                    TLog.printError("showSportCricket_teamPkMsgView error:" + e);
                }
            }));
        }
    }
    showSportCricket_playerMain(e = null) {
        let a = ToolUtils.judgeIfInHall();
        a && ToolUtils.loadCommonPrefab(this.cricket_playerMainPrefab, BundleNameDefined.Bundle_Yes11, "prefab/cricket_playerInfo", (t => {
            try {
                if (this.cricket_playerMainPrefab = t, a = ToolUtils.judgeIfInHall(), !a) {
                    return;
                }
                let r;
                sys.isObjectValid(e) && (r = e.parent_node);
                ToolUtils.isObjValid(r) || (r = director.getScene().getChildByName("Canvas"));
                let l = r.getChildByName("cricket_playerInfo");
                if (ToolUtils.isObjValid(l)) {
                    l.active = true;
                }
                else {
                    l = instantiate(t);
                    l.parent = r;
                    l.getComponent("SportCricket_PlayerMain").init(e);
                }
            }
            catch (e) {
                TLog.printError("showSportCricket_playerMain error:" + e);
            }
        }));
    }
    showSportCricket_selectCaptain(e = null) {
        let a = ToolUtils.judgeIfInHall();
        a && ToolUtils.loadCommonPrefab(this.cricket_selectCaptainPrefab, BundleNameDefined.Bundle_Yes11, "prefab/cricket_captainselect", (t => {
            try {
                if (this.cricket_selectCaptainPrefab = t, a = ToolUtils.judgeIfInHall(), !a) {
                    return;
                }
                let r;
                sys.isObjectValid(e) && (r = e.parent_node);
                ToolUtils.isObjValid(r) || (r = director.getScene().getChildByName("Canvas"));
                let l = r.getChildByName("cricket_captainselect");
                if (ToolUtils.isObjValid(l)) {
                    l.active = true;
                }
                else {
                    l = instantiate(t);
                    l.parent = r;
                    l.getComponent("SportCricket_SelectCaptain").init(e);
                }
            }
            catch (e) {
                TLog.printError("showSportCricket_selectCaptain error:" + e);
            }
        }));
    }
    showSportCricket_backUpPlayers(e = null) {
        let a = ToolUtils.judgeIfInHall();
        a && ToolUtils.loadCommonPrefab(this.cricket_backUpPrefab, BundleNameDefined.Bundle_Yes11, "prefab/cricket_backupedit", (t => {
            try {
                if (this.cricket_backUpPrefab = t, a = ToolUtils.judgeIfInHall(), !a) {
                    return;
                }
                let r;
                sys.isObjectValid(e) && (r = e.parent_node);
                ToolUtils.isObjValid(r) || (r = director.getScene().getChildByName("Canvas"));
                let l = r.getChildByName("cricket_backupedit");
                if (ToolUtils.isObjValid(l)) {
                    l.active = true;
                }
                else {
                    l = instantiate(t);
                    l.parent = r;
                    l.getComponent("SportCricket_EditBackUp").init(e);
                }
            }
            catch (e) {
                TLog.printError("showSportCricket_backUpPlayers error:" + e);
            }
        }));
    }
    showSportCricket_notLineUp(e = null) {
        let a = ToolUtils.judgeIfInHall();
        a && ToolUtils.loadCommonPrefab(this.cricket_notLineUpPrefab, BundleNameDefined.Bundle_Yes11, "prefab/cricket_notlineup", (t => {
            try {
                if (this.cricket_notLineUpPrefab = t, a = ToolUtils.judgeIfInHall(), !a) {
                    return;
                }
                let r;
                sys.isObjectValid(e) && (r = e.parent_node);
                ToolUtils.isObjValid(r) || (r = director.getScene().getChildByName("Canvas"));
                let l = r.getChildByName("cricket_notlineup");
                if (ToolUtils.isObjValid(l)) {
                    l.active = true;
                }
                else {
                    l = instantiate(t);
                    l.parent = r;
                    l.getComponent("SportCricket_NotLineUp").init(e);
                }
            }
            catch (e) {
                TLog.printError("showSportCricket_notLineUp error:" + e);
            }
        }));
    }
    showSportCricket_teamPreview(e = null) {
        let a = ToolUtils.judgeIfInHall();
        a && ToolUtils.loadCommonPrefab(this.cricket_teamPreviewPrefab, BundleNameDefined.Bundle_Yes11, "prefab/cricket_teampreview", (t => {
            try {
                if (this.cricket_teamPreviewPrefab = t, a = ToolUtils.judgeIfInHall(), !a) {
                    return;
                }
                let r;
                sys.isObjectValid(e) && (r = e.parent_node);
                ToolUtils.isObjValid(r) || (r = director.getScene().getChildByName("Canvas"));
                let l = r.getChildByName("cricket_teampreview");
                if (ToolUtils.isObjValid(l)) {
                    l.active = true;
                }
                else {
                    l = instantiate(t);
                    l.parent = r;
                    l.getComponent("SportCricket_TeamPreview").init(e);
                }
            }
            catch (e) {
                TLog.printError("showSportCricket_teamPreview error:" + e);
            }
        }));
    }
    showSportCricket_teamList(e = null) {
        let a = ToolUtils.judgeIfInHall();
        a && ToolUtils.loadCommonPrefab(this.cricket_teamListPrefab, BundleNameDefined.Bundle_Yes11, "prefab/cricket_teamlist", (t => {
            try {
                if (this.cricket_teamListPrefab = t, a = ToolUtils.judgeIfInHall(), !a) {
                    return;
                }
                let r;
                sys.isObjectValid(e) && (r = e.parent_node);
                ToolUtils.isObjValid(r) || (r = director.getScene().getChildByName("Canvas"));
                let l = r.getChildByName("cricket_teamlist");
                if (ToolUtils.isObjValid(l)) {
                    l.active = true;
                }
                else {
                    l = instantiate(t);
                    l.parent = r;
                    l.getComponent("SportCricket_TeamList").init(e);
                }
            }
            catch (e) {
                TLog.printError("showSportCricket_teamList error:" + e);
            }
        }));
    }
    showSportCricket_joinList(e = null) {
        let a = ToolUtils.judgeIfInHall();
        a && ToolUtils.loadCommonPrefab(this.cricket_joinListPrefab, BundleNameDefined.Bundle_Yes11, "prefab/cricket_joinlist", (t => {
            try {
                if (this.cricket_joinListPrefab = t, a = ToolUtils.judgeIfInHall(), !a) {
                    return;
                }
                let r;
                sys.isObjectValid(e) && (r = e.parent_node);
                ToolUtils.isObjValid(r) || (r = director.getScene().getChildByName("Canvas"));
                let l = r.getChildByName("cricket_joinlist");
                if (ToolUtils.isObjValid(l)) {
                    l.active = true;
                }
                else {
                    l = instantiate(t);
                    l.parent = r;
                    l.getComponent("SportCricket_JoinList").init(e);
                }
            }
            catch (e) {
                TLog.printError("showSportCricket_joinList error:" + e);
            }
        }));
    }
    showSportCricket_switchList(e = null) {
        let a = ToolUtils.judgeIfInHall();
        a && ToolUtils.loadCommonPrefab(this.cricket_switchListPrefab, BundleNameDefined.Bundle_Yes11, "prefab/cricket_switchlist", (t => {
            try {
                if (this.cricket_switchListPrefab = t, a = ToolUtils.judgeIfInHall(), !a) {
                    return;
                }
                let r;
                sys.isObjectValid(e) && (r = e.parent_node);
                ToolUtils.isObjValid(r) || (r = director.getScene().getChildByName("Canvas"));
                let l = r.getChildByName("cricket_switchlist");
                if (ToolUtils.isObjValid(l)) {
                    l.active = true;
                }
                else {
                    l = instantiate(t);
                    l.parent = r;
                    l.getComponent("SportCricket_SwitchTeamList").init(e);
                }
            }
            catch (e) {
                TLog.printError("showSportCricket_switchList error:" + e);
            }
        }));
    }
    showSportCricket_assureJoin(e = null) {
        let a = ToolUtils.judgeIfInHall();
        a && ToolUtils.loadCommonPrefab(this.cricket_assureJoinPrefab, BundleNameDefined.Bundle_Yes11, "prefab/cricket_assurejoin", (t => {
            try {
                if (this.cricket_assureJoinPrefab = t, a = ToolUtils.judgeIfInHall(), !a) {
                    return;
                }
                let r;
                sys.isObjectValid(e) && (r = e.parent_node);
                ToolUtils.isObjValid(r) || (r = director.getScene().getChildByName("Canvas"));
                let l = r.getChildByName("cricket_assurejoin");
                if (ToolUtils.isObjValid(l)) {
                    l.active = true;
                }
                else {
                    l = instantiate(t);
                    l.parent = r;
                    l.getComponent("SportCricket_AssureJoin").init(e);
                }
            }
            catch (e) {
                TLog.printError("showSportCricket_assureJoin error:" + e);
            }
        }));
    }
    showSportCricket_end(e = null) {
        let a = ToolUtils.judgeIfInHall();
        if (a) {
            let t = this.cricket_end, r = e.target || null;
            ToolUtils.loadCommonPrefab(t, BundleNameDefined.Bundle_Yes11, "prefab/cricket_end", (t => {
                try {
                    if (this.cricket_end = t, a = ToolUtils.judgeIfInHall(), !a) {
                        return;
                    }
                    let l;
                    sys.isObjectValid(e) && (l = e.parent_node);
                    ToolUtils.isObjValid(l) || (l = director.getScene().getChildByName("Canvas"));
                    let o = l.getChildByName("cricket_end");
                    if (ToolUtils.isObjValid(o)) {
                        o.active = true;
                    }
                    else {
                        o = instantiate(t);
                        o.parent = l;
                        o.getComponent("SportCricket_End").init(e, (() => {
                            ToolUtils.isObjValid(r) && (r.active = false);
                        }), (() => {
                            ToolUtils.isObjValid(r) && (r.active = true);
                        }));
                    }
                }
                catch (e) {
                    TLog.printError("showSportCricket_end error:" + e);
                }
            }));
        }
    }
    showSportCricket_leaderBoard(e = null) {
        let a = ToolUtils.judgeIfInHall();
        a && ToolUtils.loadCommonPrefab(this.cricket_endReward, BundleNameDefined.Bundle_Yes11, "prefab/cricket_endReward", (t => {
            try {
                if (this.cricket_endReward = t, a = ToolUtils.judgeIfInHall(), !a) {
                    return;
                }
                let r, l = null;
                sys.isObjectValid(e) && (r = e.parent_node, !r && sys.isObjectValid(e.target) && (l = e.target));
                ToolUtils.isObjValid(r) || (r = director.getScene().getChildByName("Canvas"));
                let o = r.getChildByName("cricket_endReward");
                if (ToolUtils.isObjValid(o)) {
                    o.active = true;
                }
                else {
                    o = instantiate(t);
                    o.parent = r;
                    o.getComponent("SportCricket_EndReward").init(e, (() => {
                        ToolUtils.isObjValid(l) && (l.active = false);
                    }), (() => {
                        ToolUtils.isObjValid(l) && (l.active = true);
                    }));
                }
            }
            catch (e) {
                TLog.printError("showSportCricket_leaderBoard error:" + e);
            }
        }));
    }
    showSportCricket_playerDetail(e = null) {
        let a = ToolUtils.judgeIfInHall();
        a && ToolUtils.loadCommonPrefab(this.cricket_endPlayerDetail, BundleNameDefined.Bundle_Yes11, "prefab/cricket_endPlayerDetail", (t => {
            try {
                if (this.cricket_endPlayerDetail = t, a = ToolUtils.judgeIfInHall(), !a) {
                    return;
                }
                let r;
                sys.isObjectValid(e) && (r = e.parent_node);
                ToolUtils.isObjValid(r) || (r = director.getScene().getChildByName("Canvas"));
                let l = r.getChildByName("cricket_endPlayerDetail");
                if (ToolUtils.isObjValid(l)) {
                    l.active = true;
                }
                else {
                    l = instantiate(t);
                    l.parent = r;
                    l.getComponent("SportCricket_EndPlayerDetail").init(e);
                }
            }
            catch (e) {
                TLog.printError("showSportCricket_playerDetail error:" + e);
            }
        }));
    }
}
