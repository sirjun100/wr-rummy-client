// @ts-nocheck
// Recovered from index.js:375
import { _decorator, Button, instantiate, Label, LabelShadow, Node, Sprite, SpriteAtlas, SpriteFrame, sys, v3 } from "cc";
import ReportConfig from "./ReportConfig";
import i18nMgr from "./i18nMgr";
import TweenTool from "./TweenTool";
import HttpManager from "./HttpManager";
import PushCenter from "./PushCenter";
import User from "./User";
import PushEvent from "./PushEvent";
import { TransferPlatform } from "./TransferPlatform";
import BaseLayer from "./BaseLayer";
import Utils from "./Utils";
import SoundManager from "./SoundManager";
import CommDefine from "./CommDefine";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("RechargeRewards")
export class RechargeRewards extends BaseLayer {
    @property(Node)
    public rootNode: Node = null;
    @property(Label)
    public subTitleLabel: Label = null;
    @property(Label)
    public tipsLabel: Label = null;
    @property([Node])
    public taskItems: Node[] = [];
    @property([SpriteFrame])
    public btnSprites: SpriteFrame[] = [];
    @property(Node)
    public rewardModel: Node = null;
    @property(Node)
    public ruleNode: Node = null;
    @property(Label)
    public ruleLabel: Label = null;
    @property(SpriteAtlas)
    public rewardPlist: SpriteAtlas = null;
    public sceneStr: any = ReportConfig.scece.Hall;
    public vid: number = 0;
    public funcId: any = ReportConfig.func.New_reward;
    public isNext: boolean = false;
    public isRequest: boolean = false;
    public isDouble: boolean = false;
    public collectIndex: number = 0;
    public ruleTips: string = "";
    public _isScrolling: boolean = false;
    public _listData: any = null;
    public _scrollUtil: any = null;
    public _initDelay: number = 0;
    public _linkId: number = 0;
    public _reportScene: number = 1;
    public _bCanSend: boolean = false;
    public _roomScale: any = v3(0.74, 0.74, 0.74);
    public _taskData: any[] = [];
    public lastClick: number = 0;
    onLoad() {
        this.node.getChildByName("root") && ToolUtils.showFullScreen(this.node.getChildByName("root"));
        this.node.getChildByName("mask") && ToolUtils.showFullScreen(this.node.getChildByName("mask"));
        this.ruleNode.getChildByName("mask") && ToolUtils.showFullScreen(this.ruleNode.getChildByName("mask"));
    }
    start() {
        super.start();
        this._linkId = this._linkId > 0 ? this._linkId : sys.now();
        this._reportScene = this._reportScene >= 0 ? this._reportScene : ToolUtils.getIsInRoom() ? 2 : 1;
        this.isRequest = false;
        this.ruleNode.active = false;
        this.initPushEvent();
        this.startShowAnim2(this.rootNode, v3(0, 0, 0), (() => {
        }));
        this._initDelay = 0;
        TweenTool.delayAct(this.node, (() => {
            this.refreshTaskList();
        }), this._initDelay, true);
        this._initDelay += 0.05;
    }
    startShowAnim2(e, t, i) {
        e.setScale(t);
        let s = ToolUtils.getIsInRoom() ? this._roomScale : v3(1, 1, 1);
        TweenTool.scaleTo(e, 0.2, s, "backOut", true, (() => {
            e.setScale(s);
            i && i();
        }));
    }
    initTask(e) {
        if (sys.isObjectValid(e)) {
            let t = sys.isObjectValid(e.vid) ? e.vid : 0;
            this.vid = t;
            this.isNext = !!sys.isObjectValid(e.isNext) && e.isNext;
            sys.isObjectValid(e.reportScene) && (this._reportScene = e.reportScene);
            sys.isObjectValid(e.link_id) && e.link_id > 0 && (this._linkId = e.link_id);
        }
    }
    onEnable() {
        TransferPlatform.shared().setNormalFrameRate();
    }
    initPushEvent() {
        PushCenter.shared().addListener(PushEvent.RefreshRechargeRewardList, (e => {
            ToolUtils.isObjValid(this.node) && (this.requestRechargeRewardsInfo(), 0 == ToolUtils.isInGameScene && User.shared().getHallInfo(this.vid));
        }), this);
    }
    refreshTaskList() {
        this.rewardModel && (this.rewardModel.active = false, this._taskData = User.shared().rechargeRewardsData, sys.isObjectValid(this._taskData) && this.updateTaskListContent(this._taskData), this.requestRechargeRewardsInfo());
    }
    updateTaskListContent(e) {
        if (this.ruleTips = sys.isObjectValid(e) && sys.isObjectValid(e.rule) ? ToolUtils.isSafeString(e.rule) : "", e && e.list.length > 0) {
            for (let t = 0, i = e.list.length; t < i && t < 5; t++) {
                let i = e.list[t], s = this.taskItems[t];
                s.active = true;
                let a = ToolUtils.isSafeNumber(i.reward_status), n = ToolUtils.isSafeNumber(i.amt), l = ToolUtils.isSafeNumber(i.current_amt), o = ToolUtils.isSafeNumber(i.difference_amt);
                if (s.getChildByName("title").getComponent(Label).string = ToolUtils.format("Stack up ₹${0} recharge", n), s.getChildByName("progress_num").getComponent(Label).string = ToolUtils.format("${0}/${1}", ToolUtils.parse_double("" + l, -1), n), sys.isObjectValid(i.reward) && i.reward.length > 0) {
                    let e = s.getChildByName("rewardList").getChildByName("view").getChildByName("content");
                    e.removeAllChildren();
                    for (let t = 0, s = i.reward.length; t < s; t++) {
                        let s = instantiate(this.rewardModel);
                        this.updateRewardSprite(s.getChildByName("ico"), Number(i.reward[t].type));
                        s.getChildByName("num").getComponent(Label).string = i.reward[t].amt;
                        s.active = true;
                        s.name = "reward" + t;
                        e.addChild(s);
                    }
                }
                let d = s.getChildByName("btn");
                1 == a ? (d.getComponent(Button).interactable = false, d.getComponent(Sprite).spriteFrame = this.btnSprites[2], d.getChildByName("wz").getComponent(Label).string = "COLLECTED", Utils.updateLabelMaterial(d.getChildByName("wz"), CommDefine.gradient.btn_gray), d.getChildByName("wz").getComponent(LabelShadow).color = CommDefine.shadowcolor.gray) : 0 == a ? (d.getComponent(Button).interactable = true, d.getComponent(Sprite).spriteFrame = this.btnSprites[0], d.getChildByName("wz").getComponent(Label).string = "COLLECT", Utils.updateLabelMaterial(d.getChildByName("wz"), CommDefine.gradient.btn_green), d.getChildByName("wz").getComponent(LabelShadow).color = CommDefine.shadowcolor.green) : (d.getComponent(Button).interactable = true, d.getComponent(Sprite).spriteFrame = this.btnSprites[1], d.getChildByName("wz").getComponent(Label).string = ToolUtils.format("ADD ₹${0}", o), Utils.updateLabelMaterial(d.getChildByName("wz"), CommDefine.gradient.btn_blue), d.getChildByName("wz").getComponent(LabelShadow).color = CommDefine.shadowcolor.blue);
                d.active = true;
            }
        }
    }
    updateRewardSprite(e, t) {
        ToolUtils.isSafeString(CommDefine.rewardPistName[t]).length > 0 && Utils.shared().setImage(e, CommDefine.rewardPistName[t], this.rewardPlist);
    }
    onCollectBtnClick(e, t) {
        if (SoundManager.shared().playFx("click"), t = Number(t), !sys.isObjectValid(this._taskData) || !sys.isObjectValid(this._taskData.list) || !sys.isObjectValid(this._taskData.list[t])) {
            return;
        }
        let i = this._taskData.list[t];
        if (0 == ToolUtils.isSafeNumber(i.reward_status)) {
            if (this.isRequest) {
                return;
            }
            this.isRequest = true;
            Utils.shared().showLoading(10, false, (() => {
                Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
            }), ToolUtils.getIsNormalDirection());
            let e = { uid: User.shared().data.uid };
            HttpManager.shared().doGetCommonRequest(e, "Activity.Act_115.getReward", ((e, t, i) => {
                if (Utils.shared().hideLoading(), ToolUtils.isObjValid(this.node) && (this.isRequest = false), 200 == i) {
                    let e = ToolUtils.parseJson(t);
                    if (0 == e.ret) {
                        if (ToolUtils.isObjValid(this.node)) {
                            let t = e.data.reward_list;
                            t && t.length > 0 && (User.shared().showChargeReward(t, (e => {
                            })), sys.isObjectValid(this.node) && this.requestRechargeRewardsInfo(), 0 == ToolUtils.isInGameScene && User.shared().getHallInfo(this.vid));
                        }
                    }
                    else {
                        ToolUtils.isSafeString(e.desc).length > 0 && Utils.shared().showToast(e.desc, 2, 0, ToolUtils.getIsNormalDirection());
                    }
                }
            }));
            TweenTool.delayAct(this.node, (() => {
                sys.isObjectValid(this.node) && (this.isRequest = false);
            }), 5, true);
        }
        else {
            if (!User.shared().checkCanRecharge()) {
                return void (ToolUtils.isObjValid(this.node) && (this.isNext && PushCenter.shared().pushEvent(PushEvent.Update_NextPopActivity), this.node.destroy()));
            }
            if (sys.now() - this.lastClick < 800) {
                return;
            }
            this.lastClick = sys.now();
            let e = { price: ToolUtils.isSafeNumber(i.difference_amt), act_id: PushEvent.JUMP_TO_RechargeReward, link_id: this._linkId, tab_id: i.tab_id };
            User.shared().startPay(e);
        }
    }
    onButtonClick(e, t) {
        SoundManager.shared().playFx("click");
        "close" === t ? ToolUtils.isObjValid(this.node) && (this.isNext && PushCenter.shared().pushEvent(PushEvent.Update_NextPopActivity), this.node.destroy()) : "help" === t ? this.ruleTips && "" != this.ruleTips && (this.ruleNode.active = true, this.startShowAnim2(this.ruleNode, v3(0.4, 0.4, 0.4), (() => {
        })), this.ruleLabel.string = this.ruleTips) : "helpClose" === t && (this.ruleNode.active = false);
    }
    requestRechargeRewardsInfo() {
        User.shared().requestRechargeRewards((() => {
            ToolUtils.isObjValid(this.node) && (this._taskData = User.shared().rechargeRewardsData, sys.isObjectValid(this._taskData) && this.updateTaskListContent(this._taskData));
        }));
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().removeListenersByTag(this);
    }
    onBackView() {
        ToolUtils.isObjValid(this.node) && (this.isNext && PushCenter.shared().pushEvent(PushEvent.Update_NextPopActivity), this.node.destroy());
    }
}
