// @ts-nocheck
// Recovered from index.js:263
import { _decorator, sp, v3 } from "cc";
import SoundManager from "./SoundManager";
import { MyComponent } from "./MyComponent";
const { ccclass, property } = _decorator;
@ccclass("LuckBallAnteSucceed")
export class LuckBallAnteSucceed extends MyComponent {
    @property(sp.Skeleton)
    public animSk: any = null;
    public countDownNum: number = 4000;
    public mcallback: any = null;
    start() {
        this.schedule((t => {
            this.countDownNum -= t;
            this.countDownNum <= 4 && this.countDownNum >= 0 && 0 == Math.floor(this.countDownNum) && this.onCloseBtn(null);
        }));
    }
    setData(t) {
        this.animSk.node.scale = v3(1, 1, 1);
        this.animSk.setSkin("payment");
        this.animSk.setAnimation(0, "hall", false);
        this.mcallback = t;
        this.countDownNum = 4;
    }
    onCloseBtn(t) {
        t && SoundManager.shared().playFx("click");
        this.mcallback && this.mcallback();
        this.node.destroy();
    }
}
