// @ts-nocheck
// Recovered from index.js:35
import { _decorator, Label, Layout, Node, sys, UITransform } from "cc";
import BaseLayer from "./BaseLayer";
import PushCenter from "./PushCenter";
import Utils from "./Utils";
import TweenTool from "./TweenTool";
import User from "./User";
import i18nMgr from "./i18nMgr";
import HttpManager from "./HttpManager";
import { HttpRequest } from "./HttpRequestName";
import TableViewUtils from "./TableViewUtils";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("BeginnerFlipTaskRecord")
export class BeginnerFlipTaskRecord extends BaseLayer {
    public TAG: string = "BeginnerFlipTaskRecord";
    @property(Node)
    public root: Node = null;
    @property(Node)
    public itemRoot: Node = null;
    @property(Node)
    public moban: Node = null;
    public _lastClick: number = 0;
    public records_md5: any = null;
    public recordTabView: any = null;
    onLoad() {
    }
    start() {
        super.start();
        this.startShowAnim(this.root);
        ToolUtils.showFullScreen(this.node.getChildByName("mask"));
        this.recordTabView = this.node.addComponent(TableViewUtils);
        this.moban.active = false;
        let e = this.moban.getComponent(UITransform).height, t = [this.moban];
        this.recordTabView.init([], this.itemRoot, t, this.initCurMobanCallBack.bind(this), 0, e);
        TweenTool.delayAct(this.node, (() => {
            null !== User.shared().flopCashTaskRecordData ? (this.refreshView(), this.requestRecords(false)) : this.requestRecords(true);
        }), 0, true);
    }
    requestRecords(e) {
        e && Utils.shared().showLoading(10, true, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
        }));
        HttpManager.shared().doGetCommonRequest({}, HttpRequest.FlopCashTaskRecords, ((e, t, i) => {
            if (ToolUtils.isObjValid(this.node) && Utils.shared().hideLoading(), 200 != i) {
                0 == sys.getNetworkType() ? Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text91"), 3, 0, ToolUtils.getIsNormalDirection()) : Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
            }
            else {
                let e = ToolUtils.parseJson(t);
                if (0 == e.ret) {
                    let t = e.data;
                    User.shared().flopCashTaskRecordData = t;
                    let i = true;
                    if (sys.isObjectValid(this.records_md5)) {
                        let e = ToolUtils.jsonToMd5(User.shared().flopCashTaskRecordData);
                        this.records_md5 == e && (i = false);
                    }
                    i && this.refreshView();
                }
            }
        }));
    }
    initCurMobanCallBack(e, t) {
        sys.isObjectValid(t) && (e.active = true, e.getChildByName("date").getComponent(Label).string = t.reward_time, e.getChildByName("game").getComponent(Label).string = String(t.play_num), sys.isObjectValid(t.cash) && t.cash > 0 ? (e.getChildByName("reward").getChildByName("item0").getChildByName("num").getComponent(Label).string = String(t.cash), e.getChildByName("reward").getChildByName("item0").active = true, e.getChildByName("reward").getChildByName("item0").getComponent(Layout).updateLayout()) : e.getChildByName("reward").getChildByName("item0").active = false, sys.isObjectValid(t.bonus) && t.bonus > 0 ? (e.getChildByName("reward").getChildByName("item1").getChildByName("num").getComponent(Label).string = String(t.bonus), e.getChildByName("reward").getChildByName("item1").active = true, e.getChildByName("reward").getChildByName("item1").getComponent(Layout).updateLayout()) : e.getChildByName("reward").getChildByName("item1").active = false, e.getChildByName("reward").getComponent(Layout).updateLayout());
    }
    refreshView() {
        this.records_md5 = ToolUtils.jsonToMd5(User.shared().flopCashTaskRecordData);
        let e = User.shared().flopCashTaskRecordData;
        sys.isObjectValid(e) && (sys.isObjectValid(e.reward_list) && e.reward_list.length > 0 ? (this.recordTabView.reloadData(e.reward_list, false), this.root.getChildByName("nodata").active = false) : (this.recordTabView.reloadData([], false), this.root.getChildByName("nodata").active = true));
    }
    initParaData(e) {
    }
    onClickBtnEvent(e, t) {
        if (ToolUtils.isObjValid(this.node)) {
            if (sys.now() - this._lastClick < 500) {
                return;
            }
            this._lastClick = sys.now();
            "close" === t && this.onBackView();
        }
    }
    onBackView() {
        ToolUtils.isObjValid(this.node) && this.node.destroy();
    }
    onDestroy() {
        super.onDestroy();
        TweenTool.stopNodeAction(this.node);
        this.unscheduleAllCallbacks();
        PushCenter.shared().removeListenersByTag(this);
    }
}
