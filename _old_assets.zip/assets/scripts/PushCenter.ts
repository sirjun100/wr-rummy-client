// @ts-nocheck
// Recovered from index.js:359
import { _decorator, EventTarget } from "cc";
import { ToolUtils } from "./ToolUtils";
const { ccclass } = _decorator;
@ccclass("PushCenter")
export default class PushCenter {
    static _instance = null;
    public eventDisptch: EventTarget = new EventTarget;
    public _eventArr: any[] = [];
    static shared() : PushCenter {
        return null == this._instance && (this._instance = new PushCenter), this._instance;
    }
    pushEvent(t, e = null) {
        ToolUtils.enterBackGround || this.eventDisptch.emit(t, e);
    }
    addListener(t, e, s) {
        let n = { name: t, cb: this.eventDisptch.on(t, e, s), tg: s };
        this._eventArr.push(n);
    }
    removeListenersByTag(t) {
        for (let e = this._eventArr.length - 1; e >= 0; e--) {
            const s = this._eventArr[e];
            s.tg === t && (this.eventDisptch.off(s.name, s.cb, s.tg), this._eventArr.splice(e, 1));
        }
    }
    removeListenerByNameAndTag(t, e) {
        this.eventDisptch.off(t);
    }
}
