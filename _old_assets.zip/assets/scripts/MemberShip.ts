// @ts-nocheck
// Recovered from index.js:307
import { _decorator, color, instantiate, Label, Layout, Node, ProgressBar, ScrollView, size, Sprite, SpriteFrame, sys, UITransform, v3, Widget } from "cc";
import i18nMgr from "./i18nMgr";
import PushCenter from "./PushCenter";
import TweenTool from "./TweenTool";
import Utils from "./Utils";
import GameConfig from "./GameConfig";
import User from "./User";
import HttpManager from "./HttpManager";
import SoundManager from "./SoundManager";
import BaseLayer from "./BaseLayer";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("MemberShip")
export class MemberShip extends BaseLayer {
    public TAG: string = "MemberShip";
    @property(Node)
    public root: Node = null;
    @property(Node)
    public degreeMoban0: Node = null;
    @property(Node)
    public degreeMoban1: Node = null;
    @property([SpriteFrame])
    public clubDegreeIcos: SpriteFrame[] = [];
    public degreeItems: any[] = [];
    @property(ScrollView)
    public scrollView: ScrollView = null;
    public time: any = sys.now();
    public isRequest: boolean = false;
    public sdate: string = "";
    public edate: string = "";
    public bShowPushAnim: boolean = false;
    public closeUICallBack: any = null;
    public showUICallback: any = null;
    public _closed: boolean = false;
    public club_data_md5: any = null;
    public hasInitClubView: boolean = false;
    initParaData(e) {
    }
    init(e, t = null, i = null) {
        this.bShowPushAnim = e;
        this.showUICallback = t;
        this.closeUICallBack = i;
    }
    onLoad() {
        sys.os !== sys.OS.IOS && this.fitScreen();
        this.fitLuckyTheme();
    }
    fitLuckyTheme() {
        0 != GameConfig.NATIVE_GAME_APP_TYPE && (this.root.getChildByName("titlenode").getChildByName("top_bg").getComponent(Sprite).color = color(12, 26, 60));
    }
    start() {
        super.start();
        this.bShowPushAnim ? ToolUtils.showPushAnim(this.node, 0, (() => {
            this.showUICallback && this.showUICallback();
        })) : this.showUICallback && this.showUICallback();
        null != User.shared().club_data ? this.updateClubTitleInfo() : (Utils.shared().showLoading(10, true, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3);
        })), HttpManager.shared().doGetMemberShipPageData(this.listenClubDataCallback.bind(this)));
        this.addNotify();
    }
    addNotify() {
    }
    onEnable() {
    }
    onDisable() {
    }
    onBackView() {
        ToolUtils.isObjValid(this.node) && (this.closeUICallBack && this.closeUICallBack(), this.bShowPushAnim ? (this._closed = true, ToolUtils.showPushAnim(this.node, 1, (() => {
            ToolUtils.isObjValid(this.node) && this.node.destroy();
        }))) : ToolUtils.isObjValid(this.node) && this.node.destroy());
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().removeListenersByTag(this);
        this.unscheduleAllCallbacks();
        Utils.shared().hideToast();
    }
    listenClubDataCallback(e, t, i) {
        if (ToolUtils.isObjValid(this.node)) {
            if (Utils.shared().hideLoading(), 200 != i) {
                alert("The login timed out, please try again");
            }
            else {
                try {
                    let e = ToolUtils.parseJson(t);
                    if (0 == e.ret && ToolUtils.isObjValid(this.node)) {
                        User.shared().club_data = e.data;
                        e.data.player_club_info.club_level != User.shared().data.player_club.club_level && (User.shared().data.player_club.club_level = Number(e.data.player_club_info.club_level), PushCenter.shared().pushEvent(GameConfig.Hall_MemberShip_info, User.shared().data.club));
                        sys.isObjectValid(e.data.player_club_info) && (User.shared().data.player_club = e.data.player_club_info);
                        let t = true;
                        if (sys.isObjectValid(this.club_data_md5)) {
                            let e = ToolUtils.jsonToMd5(User.shared().club_data);
                            this.club_data_md5 == e && (t = false);
                        }
                        this.hasInitClubView || (t = true);
                        t && this.updateClubTitleInfo();
                    }
                }
                catch {
                }
            }
        }
    }
    updateClubTitleInfo() {
        if (null == User.shared().club_data) {
            return;
        }
        this.hasInitClubView || this.createDegreeItem();
        this.club_data_md5 = ToolUtils.jsonToMd5(User.shared().club_data);
        let e = User.shared().club_data;
        if (this.degreeItems.length > 0) {
            for (let t = 0; t < this.degreeItems.length; t++) {
                let i = this.degreeItems[t];
                if (0 == t) {
                    let a = e.list[0];
                    if (sys.isObjectValid(i)) {
                        let e = { init_score: 0, full_score: a.init_score };
                        this.refreshDegreeItem(i, t, e);
                    }
                }
                else {
                    let a = e.list[t - 1];
                    sys.isObjectValid(i) && this.refreshDegreeItem(i, t, a);
                }
            }
        }
        this.initScroviewPos();
    }
    initScroviewPos() {
        let e = User.shared().data.player_club, t = User.shared().getGradeByMemberShipLevel(Number(e.club_level));
        0 == t ? this.scrollView.scrollToBottom() : 1 == t ? this.scrollView.scrollToPercentVertical(0.03, 0) : 2 == t ? this.scrollView.scrollToPercentVertical(0.16, 0) : 3 == t ? this.scrollView.scrollToPercentVertical(0.268, 0) : 4 == t ? this.scrollView.scrollToPercentVertical(0.4, 0) : 5 == t ? this.scrollView.scrollToPercentVertical(0.52, 0) : 6 == t ? this.scrollView.scrollToPercentVertical(0.64, 0) : 7 == t ? this.scrollView.scrollToPercentVertical(0.76, 0) : 8 == t ? this.scrollView.scrollToPercentVertical(0.9, 0) : this.scrollView.scrollToTop();
    }
    refreshDegreeItem(e, t, i) {
        let a = User.shared().data.player_club, l = User.shared().getGradeByMemberShipLevel(Number(a.club_level));
        e.getChildByName("safety_node").active = l == t && 0 != t;
        e.getChildByName("ProgressBar").getChildByName("Bar").getChildByName("float_bg").active = l == t;
        e.getChildByName("reset_bg").active = l == t && 0 != t;
        e.getChildByName("reset_time").active = l == t && 0 != t;
        let s = Number(i.init_score), o = Number(i.full_score);
        if (l == t) {
            let t = Number(a.club_score), r = (t - s) / (o - s);
            e.getChildByName("safety_node").getChildByName("point").getComponent(Label).string = String(i.protect_score);
            let n = (Number(i.protect_score) - s) / (o - s), h = 400;
            l > 0 && (h = 848);
            0 == l && (e.getChildByName("ProgressBar").getChildByName("Bar").getChildByName("float_bg").getComponent(Widget).top = r < 0.06 ? -60 : -30);
            e.getChildByName("safety_node").setPosition(v3(-184.939, h * n));
            l < 9 ? e.getChildByName("ProgressBar").getComponent(ProgressBar).progress = r : (e.getChildByName("safety_node").setPosition(v3(-184.939, 0.8 * h)), t <= Number(i.protect_score) ? (r = (t - s) / (Number(i.protect_score) - s), e.getChildByName("ProgressBar").getComponent(ProgressBar).progress = r) : e.getChildByName("ProgressBar").getComponent(ProgressBar).progress = 0.8 + 0.02);
            e.getChildByName("ProgressBar").getChildByName("Bar").getChildByName("float_bg").getChildByName("lp_score").getComponent(Label).string = String(Math.floor(t));
            e.getChildByName("reset_time").getComponent(Label).string = ToolUtils.format(i18nMgr.shared().getValueByKey("advancedPack.time"), Utils.shared().parseCountDown(a.left_second));
            e.getChildByName("reset_time").getComponent(Label).updateRenderData();
            let d = e.getChildByName("reset_time").getComponent(UITransform).contentSize.width, b = e.getChildByName("reset_time").scale.x;
            e.getChildByName("reset_bg").getComponent(UITransform).contentSize = size(d * b + 15, 38);
            Number(a.left_second) > 0 && Number(a.left_second) < 120 && TweenTool.myschedule(e.getChildByName("reset_time"), 1, (() => {
                ToolUtils.isObjValid(this.node) && (a.left_second > 0 ? (a.left_second = a.left_second - 1, e.getChildByName("reset_time").getComponent(Label).string = ToolUtils.format(i18nMgr.shared().getValueByKey("advancedPack.time"), Utils.shared().parseCountDownToSec(a.left_second))) : (User.shared().getHallInfo(), TweenTool.stopNodeAction(e.getChildByName("reset_time"))));
            }));
        }
        else {
            e.getChildByName("ProgressBar").getComponent(ProgressBar).progress = l > t ? 1 : 0;
        }
        if (e.getChildByName("ico").getComponent(Sprite).spriteFrame = this.clubDegreeIcos[t], ToolUtils.isObjValid(e.getChildByName("ico1")) && (t + 1 <= 9 ? e.getChildByName("ico1").getComponent(Sprite).spriteFrame = this.clubDegreeIcos[t + 1] : e.getChildByName("ico1").active = false), t > 0) {
            e.getChildByName("degree_score").getComponent(Label).string = String(s);
            e.getChildByName("big_ico").getComponent(Sprite).spriteFrame = this.clubDegreeIcos[t];
            sys.isObjectValid(i.name) && (e.getChildByName("club_name").getComponent(Label).string = i.name, e.getChildByName("big_club_name").getComponent(Label).string = i.name);
            let a = Number(i.upgrade_cash), l = Number(i.upgrade_bonus), o = e.getChildByName("gift_node");
            if (0 == a && 0 == l) {
                o.getChildByName("up_gift").active = false;
            }
            else {
                o.getChildByName("up_gift").active = true;
                let e = o.getChildByName("up_gift").getChildByName("reward");
                a > 0 ? (e.getChildByName("item_cash").getChildByName("amt").getComponent(Label).string = String(a), e.getChildByName("item_cash").active = true, e.getChildByName("item_cash").getComponent(Layout).updateLayout()) : e.getChildByName("item_cash").active = false;
                l > 0 ? (e.getChildByName("item_bonus").getChildByName("amt").getComponent(Label).string = String(l), e.getChildByName("item_bonus").active = true, e.getChildByName("item_bonus").getComponent(Layout).updateLayout()) : e.getChildByName("item_bonus").active = false;
                e.getChildByName("add").active = l > 0 && a > 0;
                e.getComponent(Layout).updateLayout();
            }
            let r = Number(i.week_cash), d = Number(i.week_bonus);
            if (0 == r && 0 == d) {
                o.getChildByName("week_gift").active = false;
            }
            else {
                o.getChildByName("week_gift").active = true;
                let e = o.getChildByName("week_gift").getChildByName("reward");
                r > 0 ? (e.getChildByName("item_cash").getChildByName("amt").getComponent(Label).string = String(r), e.getChildByName("item_cash").active = true, e.getChildByName("item_cash").getComponent(Layout).updateLayout()) : e.getChildByName("item_cash").active = false;
                d > 0 ? (e.getChildByName("item_bonus").getChildByName("amt").getComponent(Label).string = String(d), e.getChildByName("item_bonus").active = true, e.getChildByName("item_bonus").getComponent(Layout).updateLayout()) : e.getChildByName("item_bonus").active = false;
                e.getChildByName("add").active = d > 0 && r > 0;
                e.getComponent(Layout).updateLayout();
            }
            let m = Number(i.month_cash), g = Number(i.month_bonus);
            if (0 == m && 0 == g) {
                o.getChildByName("month_gift").active = false;
            }
            else {
                o.getChildByName("month_gift").active = true;
                let e = o.getChildByName("month_gift").getChildByName("reward");
                m > 0 ? (e.getChildByName("item_cash").getChildByName("amt").getComponent(Label).string = String(m), e.getChildByName("item_cash").active = true, e.getChildByName("item_cash").getComponent(Layout).updateLayout()) : e.getChildByName("item_cash").active = false;
                g > 0 ? (e.getChildByName("item_bonus").getChildByName("amt").getComponent(Label).string = String(g), e.getChildByName("item_bonus").active = true, e.getChildByName("item_bonus").getComponent(Layout).updateLayout()) : e.getChildByName("item_bonus").active = false;
                e.getChildByName("add").active = g > 0 && m > 0;
                e.getComponent(Layout).updateLayout();
            }
            i.month_coupon_ratio;
            if (String(i.month_coupon_ratio).length > 0 ? (o.getChildByName("coupon_gitt").active = true, o.getChildByName("coupon_gitt").getChildByName("reward").getChildByName("amt").getComponent(Label).string = String(i.month_coupon_ratio), o.getChildByName("coupon_gitt").getChildByName("reward").getComponent(Layout).updateLayout()) : o.getChildByName("coupon_gitt").active = false, o.getChildByName("service_gift").active = 1 == i.specialized_cs, sys.isObjectValid(i.tx_count)) {
                let e = Number(i.tx_count);
                e > 0 ? (o.getChildByName("withdraw_count").active = true, o.getChildByName("withdraw_count").getChildByName("tip").getComponent(Label).string = String(e)) : o.getChildByName("withdraw_count").active = false;
            }
            else {
                o.getChildByName("withdraw_count").active = false;
            }
            if (sys.isObjectValid(i.tx_limit)) {
                let e = Number(i.tx_limit);
                e > 0 ? (o.getChildByName("daily_withdraw").active = true, o.getChildByName("daily_withdraw").getChildByName("tip").getComponent(Label).string = String(e)) : o.getChildByName("daily_withdraw").active = false;
            }
            else {
                o.getChildByName("daily_withdraw").active = false;
            }
        }
    }
    createDegreeItem() {
        let e = User.shared().club_data;
        if (this.degreeItems = [], sys.isObjectValid(e) && sys.isObjectValid(e.list) && Array.isArray(e.list)) {
            for (let t = e.list.length - 1; t >= 0; t--) {
                let e = instantiate(this.degreeMoban1);
                ToolUtils.isObjValid(e) && (e.name = "degree_node" + (t + 1), e.active = true, this.degreeItems.push(e), this.scrollView.content.addChild(e));
            }
            let t = instantiate(this.degreeMoban0);
            ToolUtils.isObjValid(t) && (t.name = "degree_node0", t.active = true, this.degreeItems.push(t), this.scrollView.content.addChild(t));
            this.degreeItems = this.degreeItems.reverse();
        }
    }
    onButtonClick(e, t) {
        if ("back_btn" == t) {
            if (this._closed) {
                return;
            }
            this.onBackView();
        }
        else if ("help_btn" == t) {
            let e = User.shared().club_data, t = "1", i = "1.5", a = "2.5", l = "4";
            sys.isObjectValid(e.point_sp) && (t = e.point_sp);
            sys.isObjectValid(e.pool_sp) && (i = e.pool_sp);
            sys.isObjectValid(e.deals_sp) && (a = e.deals_sp);
            sys.isObjectValid(e.cricket_sp) && (l = e.cricket_sp);
            let s = `The CLUB system provides exclusive benefits to important players. While playing in the game, you will receive more rewards and higher-quality services.\nLevels: There are 9 levels in total. The more LP you have, the higher your level. Each level has its own validity period, initial points, and safety points. No level means no safety points.\n\nLP: In cash Rummy games & Cricket games, you earn Loyalty Points (LP) by spending cash. LP can be used to upgrade or maintain your CLUB level. The LP you can accumulate through different game modes is as follows:\n- Points: 1 LP for every ${t} cash spent\n- Pool: 1 LP for every ${i} cash spent\n- Deals: 1 LP for every ${a} cash spent\n- Cricket: 1 LP for every ${l} cash spent\n\nValidity Period: This is the time you can enjoy your current CLUB benefits. Each level has a different duration. Reach 100% upgrade points within the period to level up. If your points meet the safety points, your level stays the same and resets to the initial points. If not, your level drops by one and resets to the next level’s initial points.\n\nRewards and Benefits: There are 5 types of rewards:\n- Upgrade Gift: A reward granted immediately upon reaching a level. The upgrade reward can only be claimed once per level.\n- Weekly Gift: Available at midnight every Monday. Please click the 🔔 icon at the top right of the Game Lobby to claim it. (Must be claimed within 7 days)\n-  Monthly Gift: Available at midnight on the 1st of each month. Please click the 🔔 icon at the top right of the Game Lobby to claim it. (Must be claimed within 30 days)\n- Monthly Coupon: Automatically granted at midnight on the 1st of each month.\n- Specialized CS: You will have dedicated customer service to solve all your issues.\n`;
            sys.isObjectValid(e.help_cnt) && (s = e.help_cnt);
            Utils.shared().showHelpAlert({ parent_node: this.node, tips: s });
        }
        SoundManager.shared().playFx("click");
    }
    fitScreen() {
    }
}
