// @ts-nocheck
// Recovered from index.js:561
import { _decorator, Button, color, instantiate, Label, Layout, Node, ProgressBar, ScrollView, size, sp, Sprite, SpriteFrame, sys, UITransform, v3, view, Widget } from "cc";
import SoundManager from "./SoundManager";
import PushCenter from "./PushCenter";
import { TLog } from "./TLog";
import Utils from "./Utils";
import User from "./User";
import HttpManager from "./HttpManager";
import i18nMgr from "./i18nMgr";
import BaseLayer from "./BaseLayer";
import { HttpRequest } from "./HttpRequestName";
import GameConfig from "./GameConfig";
import TableViewUtils from "./TableViewUtils";
import PushEvent from "./PushEvent";
import TweenTool from "./TweenTool";
import SportCricket_Manager from "./SportCricket_Manager";
import { ToolUtils } from "./ToolUtils";
import PhpReportDefined from "./PhpReportDefined";
const { ccclass, property } = _decorator;
@ccclass("SportCricket_GameDetails")
export class SportCricket_GameDetails extends BaseLayer {
    public TAG: string = "SportCricket_GameDetails";
    @property(Node)
    public rootNode: Node = null;
    @property(Node)
    public goldNode: Node = null;
    @property(Node)
    public teamTopNode: Node = null;
    @property(Node)
    public noRootNode: Node = null;
    @property(Node)
    public topNode: Node = null;
    @property(Node)
    public rankTopNode: Node = null;
    @property(Node)
    public tabNode: Node = null;
    @property(Node)
    public bottomNode: Node = null;
    @property(Node)
    public detailsNode: Node = null;
    @property(Node)
    public detailsNode2: Node = null;
    @property([Node])
    public winTabNodes: Node[] = [];
    @property(ScrollView)
    public contentsScrollView: ScrollView = null;
    @property(ScrollView)
    public leaderboardScrollView: ScrollView = null;
    @property([SpriteFrame])
    public iconImgs: SpriteFrame[] = [];
    @property(ScrollView)
    public winScrollView: ScrollView = null;
    public leaderboardTable: any = null;
    public winTable: any = null;
    public leader_listData: any[] = [];
    public win_listData: any[] = [];
    public win_listData_pool0: any[] = [];
    public win_listData_pool1: any[] = [];
    @property(Node)
    public content_mobanView: Node = null;
    @property(Node)
    public team_mobanView: Node = null;
    @property(Node)
    public rank_mobanView: Node = null;
    @property(Node)
    public rank_mobanView2: Node = null;
    @property([SpriteFrame])
    public capBgImgs: SpriteFrame[] = [];
    @property([SpriteFrame])
    public operateImgs: SpriteFrame[] = [];
    public _closed: boolean = false;
    public bShowPushAnim: boolean = true;
    public _lastClick: number = 0;
    public _sourceData: any = null;
    public _itemArr: any[] = [];
    public leader_has_next_page: number = 0;
    public all_cur_page: number = 1;
    public _isSendMsg: boolean = false;
    public my_has_next_page: number = 0;
    public my_cur_page: number = 1;
    public curTab: number = 0;
    public tabWzColor: any[] = [color(147, 11, 11), color(102, 102, 102)];
    public taskAwardIconMap: Map = new Map;
    public _match_id: number = 0;
    public _contest_id: number = 0;
    public _contest_source: any = null;
    public _source: any = null;
    public lastClick: number = 0;
    public _lastNode: any = null;
    public _match_state: number = 1;
    public _teamlistData: any = null;
    public _winTab: number = 0;
    public isJiangChiContest: boolean = false;
    public _show_win: number = 0;
    onLoad() {
        PushCenter.shared().addListener(GameConfig.Update_Money, (e => {
            try {
                ToolUtils.isObjValid(this.node) && this.updateGold(e);
            }
            catch (e) {
                TLog.printError(this.TAG, GameConfig.Update_Money, e);
            }
        }), this);
        PushCenter.shared().addListener(PushEvent.UpdatePractiseGold, (e => {
            try {
                ToolUtils.isObjValid(this.node) && this.updateGold(e);
            }
            catch (e) {
                TLog.printError(this.TAG, PushEvent.UpdatePractiseGold, e);
            }
        }), this);
        PushCenter.shared().addListener(PushEvent.commentDownloaderImg, (e => {
            try {
                if (ToolUtils.isObjValid(this.node) && this.taskAwardIconMap.size > 0) {
                    for (const [t, i] of this.taskAwardIconMap) {
                        i == e && Utils.shared().updateNetImage(t, e, size(100, 100));
                    }
                }
            }
            catch (e) {
                TLog.printError(this.TAG, PushEvent.commentDownloaderImg, e);
            }
        }), this);
        PushCenter.shared().addListener(PushEvent.Yes11SignOk, (e => {
            try {
                if (ToolUtils.isObjValid(this.node)) {
                    if (sys.isObjectValid(e) && sys.isObjectValid(e.contest)) {
                        let t = null;
                        t = this.isJiangChiContest ? this.detailsNode2 : this.detailsNode;
                        sys.isObjectValid(e.contest.left_sign_num) && sys.isObjectValid(e.contest.sign_num) && (t.getChildByName("progress").getComponent(ProgressBar).progress = (e.contest.sign_num - e.contest.left_sign_num) / e.contest.sign_num, t.getChildByName("left_desc1").getComponent(Label).string = e.contest.left_sign_num + " Left", t.getChildByName("left_desc2").getComponent(Label).string = e.contest.sign_num + " Spots");
                        sys.isObjectValid(e.contest.session_id) && (this._contest_id = Number(e.contest.session_id));
                    }
                    this.curTab = 0;
                    this.updateTabView();
                    this.updateTabContent();
                }
            }
            catch (e) {
                TLog.printError(this.TAG, PushEvent.Yes11SignOk, e);
            }
        }), this);
        PushCenter.shared().addListener(PushEvent.RefreshYes11TeamList, (e => {
            try {
                ToolUtils.isObjValid(this.node) && this.requestNewList();
            }
            catch (e) {
                TLog.printError(this.TAG, PushEvent.RefreshYes11TeamList, e);
            }
        }), this);
        PushCenter.shared().addListener(PushEvent.RefreshYesGameSignPer, (e => {
            try {
                ToolUtils.isObjValid(this.node) && this.updateGameSessionPercent(e);
            }
            catch (e) {
                TLog.printError(this.TAG, PushEvent.RefreshYesGameSignPer, e);
            }
        }), this);
        this.fitLuckyTheme();
    }
    fitLuckyTheme() {
        0 != GameConfig.NATIVE_GAME_APP_TYPE && (this.rootNode.getChildByName("top_node").getChildByName("top_bg").getComponent(Sprite).color = color(12, 26, 60, 255), this.goldNode.getChildByName("coin").getComponent(Label).color = color(251, 220, 0, 255), this.tabNode.getChildByName("bg").getComponent(Sprite).color = color(250, 250, 250, 255), this.tabNode.getChildByName("tab0").getChildByName("line").getComponent(Sprite).color = this.tabWzColor[0], this.tabNode.getChildByName("tab1").getChildByName("line").getComponent(Sprite).color = this.tabWzColor[0], this.tabNode.getChildByName("tab2").getChildByName("line").getComponent(Sprite).color = this.tabWzColor[0]);
    }
    updateGameSessionPercent(e) {
        if (!sys.isObjectValid(e.contest)) {
            return;
        }
        let t = null;
        if (t = this.isJiangChiContest ? this.detailsNode2 : this.detailsNode, this._match_id == Number(e.match_id) && this._contest_id == e.contest.session_id) {
            this._contest_source.left_sign_num = e.contest.left_sign_num;
            this._contest_source.sign_num = e.contest.sign_num;
            let i = this._contest_source.reward_rate;
            sys.isObjectValid(e.contest.reward_rate) && (this._contest_source.reward_rate = e.contest.reward_rate);
            sys.isObjectValid(e.contest.all_reward) && (this._contest_source.all_reward = e.contest.all_reward);
            sys.isObjectValid(e.contest.first_reward) && (this._contest_source.first_reward = e.contest.first_reward);
            sys.isObjectValid(e.contest.left_sign_num) && sys.isObjectValid(e.contest.sign_num) && (t.getChildByName("progress").getComponent(ProgressBar).progress = (e.contest.sign_num - e.contest.left_sign_num) / e.contest.sign_num, t.getChildByName("left_desc1").getComponent(Label).string = e.contest.left_sign_num + " Left", t.getChildByName("left_desc2").getComponent(Label).string = e.contest.sign_num + " Spots");
            sys.isObjectValid(e.contest.once_incr_reward) && e.contest.once_incr_reward > 0 && this.isJiangChiContest && (sys.isObjectValid(this._contest_source.last_all_reward) && this._contest_source.last_all_reward > 0 ? (t.getChildByName("max_pool").getComponent(Label).string = "₹" + this._contest_source.last_all_reward, t.getChildByName("jiangchi_node").getChildByName("amt").getComponent(Label).string = "₹" + ToolUtils.parse_double(this._contest_source.last_all_reward), t.getChildByName("jiangchi_node").getComponent(Layout).updateLayout(), this._contest_source.last_all_reward != this._contest_source.all_reward ? t.getChildByName("jiangchi_node").active = true : t.getChildByName("jiangchi_node").active = false) : t.getChildByName("jiangchi_node").active = false, t.getChildByName("pool2_arrow").active = true, t.getChildByName("pool_arrow").active = true, t.getChildByName("pool_add").active = true, t.getChildByName("pool_add").getComponent(Label).string = "+" + e.contest.once_incr_reward, i != this._contest_source.reward_rate && (t.getChildByName("prize_arrow").active = true), TweenTool.stopNodeAction(t), TweenTool.delayAct(t, (() => {
                t.getChildByName("pool2_arrow").active = false;
                t.getChildByName("pool_arrow").active = false;
                t.getChildByName("pool_add").active = false;
                t.getChildByName("prize_arrow").active = false;
                sys.isObjectValid(e.contest.all_reward) && (t.getChildByName("pool").getComponent(Label).string = "₹" + String(e.contest.all_reward));
                sys.isObjectValid(e.contest.first_reward) && (t.getChildByName("pool2").getComponent(Label).string = "₹" + String(e.contest.first_reward));
                sys.isObjectValid(e.contest.reward_rate) && (t.getChildByName("prize_desc").getComponent(Label).string = e.contest.reward_rate);
                this.refreshPos(t);
            }), 2, true));
        }
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().removeListenersByTag(this);
        this.unscheduleAllCallbacks();
    }
    init(e) {
        sys.isObjectValid(e) && (sys.isObjectValid(e.match_id) && (this._match_id = e.match_id, SportCricket_Manager.shared().cricket_curMatchId = this._match_id), sys.isObjectValid(e.contest_id) && (this._contest_id = e.contest_id), sys.isObjectValid(e.contest_source) && (this._contest_source = e.contest_source, sys.isObjectValid(this._contest_source.type) && 3 == this._contest_source.type && (this.isJiangChiContest = true)), sys.isObjectValid(e.source) && (this._source = { ...e.source }), sys.isObjectValid(e.lastNode) && (this._lastNode = e.lastNode), sys.isObjectValid(e.show_win) && 1 == e.show_win && (this._show_win = e.show_win));
    }
    start() {
        super.start();
        this.initView();
        this.updateGold(User.shared().data.money);
        this.bShowPushAnim ? ToolUtils.showPushAnim(this.node, 0, (() => {
            ToolUtils.isObjValid(this._lastNode) && (this._lastNode.active = false);
            this.refreshView();
        })) : this.refreshView();
    }
    allteam_scrollRefreshCallBack() {
        1 != this.leader_has_next_page || this._isSendMsg || (this._isSendMsg = true, this.all_cur_page = this.all_cur_page + 1, this.requestLeaderBoardList(false));
    }
    rank_scrollRefreshCallBack() {
        1 != this.my_has_next_page || this._isSendMsg || (this._isSendMsg = true, this.my_cur_page = this.my_cur_page + 1, this.requestWinList(false));
    }
    requestLeaderBoardList(e = false, t = false) {
        let i = { page: this.all_cur_page, match_id: this._match_id, session_id: this._contest_id };
        e && Utils.shared().showLoading(10, true, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
        }), ToolUtils.getIsNormalDirection());
        HttpManager.shared().doGetCommonRequest(i, HttpRequest.Yes11_LeaderboardListInContest, ((e, i, a) => {
            if (Utils.shared().hideLoading(), 200 != a) {
                Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.request_fail"), 2);
                ToolUtils.isObjValid(this.node) && (this._isSendMsg = false, 2 == this.curTab && (this.all_cur_page > 1 && (this.all_cur_page = this.all_cur_page - 1), (this.all_cur_page = 1) && this.leaderboardTable.reloadData([])));
            }
            else {
                try {
                    let e = ToolUtils.parseJson(i);
                    if (0 == e.ret) {
                        if (sys.isObjectValid(e.data) && ToolUtils.isObjValid(this.node) && (this._isSendMsg = false, 2 == this.curTab)) {
                            if (t && (this.leader_listData = []), sys.isObjectValid(e.data.list) && Array.isArray(e.data.list) && e.data.list.length > 0) {
                                for (let t = 0, i = e.data.list.length; t < i; t++) {
                                    this.leader_listData.push(e.data.list[t]);
                                }
                            }
                            this.leaderboardTable.reloadData(this.leader_listData);
                            sys.isObjectValid(e.data.page) && (this.all_cur_page = e.data.page);
                            sys.isObjectValid(e.data.has_next_page) && (this.leader_has_next_page = e.data.has_next_page);
                            this.leader_listData.length > 0 ? (this.noRootNode.getChildByName("nodata").active = false, this.teamTopNode.active = true) : (this.noRootNode.getChildByName("nodata").active = true, this.teamTopNode.active = false, this.noRootNode.getChildByName("nodata").getChildByName("wz").getComponent(Label).string = "No Records", this.noRootNode.getChildByName("nodata").getChildByName("tip").getComponent(Label).string = "Lots of teams are playing, will be opened\nafter competion");
                            sys.isObjectValid(e.data.team_num) && (this.teamTopNode.getChildByName("teams").getComponent(Label).string = ToolUtils.format(i18nMgr.shared().getValueByKey("yes11.detail_teams"), e.data.team_num));
                        }
                    }
                    else {
                        ToolUtils.isObjValid(this.node) && 2 == this.curTab && (this.all_cur_page = 1) && this.leaderboardTable.reloadData([]);
                    }
                }
                catch (e) {
                    TLog.printError("requestLeaderBoardList err:", e.toString());
                }
            }
        }));
    }
    updateTabView() {
        let e = this.tabNode.getChildByName("tab0"), t = this.tabNode.getChildByName("tab1"), i = this.tabNode.getChildByName("tab2");
        e.getChildByName("di").active = false;
        t.getChildByName("di").active = false;
        i.getChildByName("di").active = false;
        e.getChildByName("line").active = 0 == this.curTab;
        t.getChildByName("line").active = 1 == this.curTab;
        i.getChildByName("line").active = 2 == this.curTab;
        this.rankTopNode.active = 1 == this.curTab;
        this.teamTopNode.active = false;
        0 == this.curTab ? (e.getChildByName("Label").getComponent(Label).color = this.tabWzColor[0], t.getChildByName("Label").getComponent(Label).color = this.tabWzColor[1], i.getChildByName("Label").getComponent(Label).color = this.tabWzColor[1], this.bottomNode.active = false) : 1 == this.curTab ? (t.getChildByName("Label").getComponent(Label).color = this.tabWzColor[0], e.getChildByName("Label").getComponent(Label).color = this.tabWzColor[1], i.getChildByName("Label").getComponent(Label).color = this.tabWzColor[1], this.bottomNode.active = true, i18nMgr.shared().changeLocalizedLabelKey(this.bottomNode.getChildByName("wz"), "yes11.rank_tip")) : (i.getChildByName("Label").getComponent(Label).color = this.tabWzColor[0], e.getChildByName("Label").getComponent(Label).color = this.tabWzColor[1], t.getChildByName("Label").getComponent(Label).color = this.tabWzColor[1], this.bottomNode.active = false, i18nMgr.shared().changeLocalizedLabelKey(this.bottomNode.getChildByName("wz"), "yes11.leader_tip"));
        i18nMgr.shared().changeLabelFont(e.getChildByName("Label").getComponent(Label), 0 == this.curTab);
        i18nMgr.shared().changeLabelFont(t.getChildByName("Label").getComponent(Label), 1 == this.curTab);
        i18nMgr.shared().changeLabelFont(i.getChildByName("Label").getComponent(Label), 2 == this.curTab);
        let a = [];
        a.push(e.getChildByName("line"));
        a.push(t.getChildByName("line"));
        a.push(i.getChildByName("line"));
        for (let e = 0; e < 2; e++) {
            if (this.curTab == e) {
                a[e].scale = v3(0, 1, 1);
                let t = TweenTool.scaleTo(a[e], 0.16, v3(1.1, 1, 1), null, false), i = TweenTool.scaleTo(a[e], 0.16, v3(1, 1, 1), null, false);
                TweenTool.sequence(a[e], true, null, t, i);
            }
            else {
                a[e].scale = v3(1, 1, 1);
            }
        }
    }
    requestWinList(e = false, t = false) {
        let i = { page: this.my_cur_page, match_id: this._match_id, session_id: this._contest_id };
        this.isJiangChiContest && (i.from = this._winTab + 1);
        e && Utils.shared().showLoading(10, true, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
        }), ToolUtils.getIsNormalDirection());
        HttpManager.shared().doGetCommonRequest(i, HttpRequest.Yes11_WinningInContest, ((e, i, a) => {
            if (Utils.shared().hideLoading(), 200 != a) {
                Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.request_fail"), 2);
                ToolUtils.isObjValid(this.node) && (this._isSendMsg = false, this.my_cur_page > 1 && (this.my_cur_page = this.my_cur_page - 1), (this.my_cur_page = 1) && (this.winScrollView.content.removeAllChildren(), this.winScrollView.scrollToTop(0)));
            }
            else {
                try {
                    let e = ToolUtils.parseJson(i);
                    if (0 == e.ret) {
                        if (sys.isObjectValid(e.data) && ToolUtils.isObjValid(this.node) && (this._isSendMsg = false, 1 == this.curTab)) {
                            if (this.teamTopNode.active = false, t && (this.isJiangChiContest ? 0 == this._winTab ? this.win_listData_pool0 = [] : this.win_listData_pool1 = [] : this.win_listData = []), sys.isObjectValid(e.data.list) && Array.isArray(e.data.list) && e.data.list.length > 0) {
                                for (let t = 0, i = e.data.list.length; t < i; t++) {
                                    this.isJiangChiContest ? 0 == this._winTab ? this.win_listData_pool0.push(e.data.list[t]) : this.win_listData_pool1.push(e.data.list[t]) : this.win_listData.push(e.data.list[t]);
                                }
                            }
                            this.winScrollView.content.removeAllChildren();
                            this.winScrollView.scrollToTop(0);
                            let i = this.win_listData;
                            this.isJiangChiContest && (i = 0 == this._winTab ? this.win_listData_pool0 : this.win_listData_pool1);
                            for (let e = 0; e < i.length; e++) {
                                let t = null, a = 1;
                                this.isJiangChiContest ? 1 == this._winTab || this._contest_source.last_all_reward == this._contest_source.all_reward ? t = instantiate(this.rank_mobanView) : 0 == e || e == i.length - 1 ? (t = instantiate(this.rank_mobanView2), a = 2) : t = instantiate(this.rank_mobanView) : t = instantiate(this.rank_mobanView);
                                t.active = true;
                                this.winScrollView.content.addChild(t);
                                this.initRankItem(t, i[e], e, a);
                            }
                            sys.isObjectValid(e.data.page) && (this.my_cur_page = e.data.page);
                            sys.isObjectValid(e.data.has_next_page) && (this.my_has_next_page = e.data.has_next_page);
                            i.length > 0 ? this.noRootNode.getChildByName("nodata").active = false : this.noRootNode.getChildByName("nodata").active = true;
                        }
                    }
                    else {
                        ToolUtils.isObjValid(this.node) && 1 == this.curTab && (this.my_cur_page = 1) && this.winTable.reloadData([]);
                    }
                }
                catch (e) {
                    TLog.printError("requestWinList err:", e.toString());
                }
            }
        }));
    }
    onPreviewTeamClick(e, t) {
        SoundManager.shared().playFx("click");
        this._lastClick = sys.now();
        let i = ToolUtils.parseJson(t);
        if (sys.isObjectValid(i.uid)) {
            if (String(i.uid) == String(User.shared().data.uid)) {
                let e = { match_id: this._match_id, team_id: i.team_id };
                SportCricket_Manager.shared().requestYes11_PreCreateTeamCheck(e, true, (e => {
                    SportCricket_Manager.shared().dealCominePreviewLogic(e, this.node);
                }));
            }
            else {
                Utils.shared().showToast("Please wait till the match starts to view other teams", 2);
            }
        }
    }
    initAllTeamItem(e, t, i) {
        e.active = true;
        e.getChildByName("bg").getComponent(Button).clickEvents[0].customEventData = ToolUtils.toJsonString(t);
        sys.isObjectValid(t.avatar) && t.avatar.length > 0 && Utils.shared().updateHeadImg(e.getChildByName("head_mask").getChildByName("head_img"), t.avatar, t.avatar_url, size(64, 64));
        sys.isObjectValid(t.name) && t.name.length > 0 && (e.getChildByName("team_name").getComponent(Label).string = ToolUtils.GetShortName2(t.name, 10, true) + " - " + t.team_name);
        sys.isObjectValid(t.rank) && t.rank.length > 0 && (e.getChildByName("rank").getComponent(Label).string = t.rank);
        sys.isObjectValid(t.uid) ? (e.getChildByName("switch_team").active = t.uid == String(User.shared().data.uid), e.getChildByName("switch_team").active ? (e.getChildByName("switch_team").getComponent(Button).clickEvents[0].customEventData = ToolUtils.toJsonString(t), e.getChildByName("rank").setPosition(v3(304.638, -34.989))) : e.getChildByName("rank").setPosition(v3(304.638, -50)), t.uid == String(User.shared().data.uid) ? e.getChildByName("bg").getComponent(Sprite).color = color(255, 247, 224) : e.getChildByName("bg").getComponent(Sprite).color = color(240, 240, 240)) : (e.getChildByName("switch_team").active = false, e.getChildByName("rank").setPosition(v3(304.638, -50)), e.getChildByName("bg").getComponent(Sprite).color = color(240, 240, 240));
    }
    onShowJiangChiClick(e, t) {
        if (SoundManager.shared().playFx("click"), sys.now() - this._lastClick < 500) {
            return;
        }
        this._lastClick = sys.now();
        let i = { match_id: this._match_id, contest_id: this._contest_id, contest_source: this._contest_source, source: this._source, lastNode: this.rootNode, fromType: 1 };
        Utils.shared().showSportCricket_plusJiangChi(i);
    }
    initRankItem(e, t, i, a = 1) {
        e.active = true;
        sys.isObjectValid(t.rank) && t.rank.length > 0 && (1 == a ? e.getChildByName("rank").getComponent(Label).string = "#" + t.rank : e.getChildByName("rank_node").getChildByName("rank").getComponent(Label).string = "#" + t.rank);
        sys.isObjectValid(t.reward) && t.reward.length > 0 && (e.getChildByName("node").getChildByName("prize").getComponent(Label).string = t.reward);
        sys.isObjectValid(t.is_chip) && 1 == t.is_chip && (e.getChildByName("node").getChildByName("ico").active = true);
        e.getChildByName("bg").getComponent(Sprite).color = i % 2 == 0 ? color(255, 255, 255) : color(240, 240, 240);
        2 == a && (0 == i ? (ToolUtils.isObjValid(e.getChildByName("first_tip")) && (e.getChildByName("first_tip").active = true), sys.isObjectValid(t.init_cash) && t.init_cash.length > 0 && (e.getChildByName("node").getChildByName("pre_prize").active = true, e.getChildByName("node").getChildByName("pre_prize").getComponent(Label).string = t.init_cash, e.getChildByName("node").getChildByName("pre_prize").getComponent(Label).updateRenderData(true), e.getChildByName("node").getChildByName("pre_prize").getChildByName("line").getComponent(Widget).updateAlignment())) : (ToolUtils.isObjValid(e.getChildByName("second_tip")) && (e.getChildByName("second_tip").active = true, e.getChildByName("second_tip").getChildByName("tip1").getComponent(Label).string = t.tips, e.getChildByName("second_tip").getComponent(Layout).updateLayout()), sys.isObjectValid(t.init_cash) && t.init_cash.length > 0 && (e.getChildByName("rank_node").getChildByName("pre_rate").active = true, e.getChildByName("rank_node").getChildByName("pre_rate").getComponent(Label).string = t.init_cash, e.getChildByName("rank_node").getChildByName("pre_rate").getComponent(Label).updateRenderData(true), e.getChildByName("rank_node").getChildByName("pre_rate").getChildByName("line").getComponent(Widget).updateAlignment()), sys.isObjectValid(t.cur_rate) && t.init_max.length > 0 && (e.getChildByName("rank_node").getChildByName("cur_rate").active = true, e.getChildByName("rank_node").getChildByName("cur_rate").getComponent(Label).string = t.init_max, e.getChildByName("rank_node").getChildByName("cur_rate").getComponent(Label).updateRenderData(true)), e.getChildByName("rank_node").getComponent(Layout).updateLayout()));
    }
    refreshView() {
        this.noRootNode.getChildByName("nodata").active = false;
        0 == this._show_win ? this.curTab = 0 : this.curTab = 1;
        this.updateTabView();
        this.updateTabContent();
    }
    updateTopContestDetails() {
        if (!sys.isObjectValid(this._source)) {
            return;
        }
        let e = this._source.teama, t = this._source.teamb;
        sys.isObjectValid(e.short_name) && e.short_name.length > 0 && (this.topNode.getChildByName("team_short_name0").getComponent(Label).string = e.short_name);
        sys.isObjectValid(t.short_name) && t.short_name.length > 0 && (this.topNode.getChildByName("team_short_name1").getComponent(Label).string = t.short_name);
        sys.isObjectValid(e.logo_url) && e.logo_url.length > 0 && (this.taskAwardIconMap.set(this.topNode.getChildByName("team_icon0"), e.logo_url), Utils.shared().updateNetImage(this.topNode.getChildByName("team_icon0"), e.logo_url, size(76, 76)));
        sys.isObjectValid(t.logo_url) && t.logo_url.length > 0 && (this.taskAwardIconMap.set(this.topNode.getChildByName("team_icon1"), t.logo_url), Utils.shared().updateNetImage(this.topNode.getChildByName("team_icon1"), t.logo_url, size(76, 76)));
        sys.isObjectValid(this._source.location) && this._source.location.length > 0 && (this.topNode.getChildByName("location").getComponent(Label).string = this._source.location);
    }
    updateContestDetails() {
        if (!sys.isObjectValid(this._contest_source)) {
            return;
        }
        let e = null;
        e = this.isJiangChiContest ? this.detailsNode2 : this.detailsNode;
        sys.isObjectValid(this._contest_source.name) && this._contest_source.name.length > 0 && (e.getChildByName("title").getComponent(Label).string = this._contest_source.name);
        sys.isObjectValid(this._contest_source.all_reward) && (sys.isObjectValid(this._contest_source.is_chip) && 1 == this._contest_source.is_chip ? (e.getChildByName("pool").getComponent(Label).string = String(this._contest_source.all_reward), e.getChildByName("pool2").getComponent(Label).string = String(this._contest_source.first_reward), e.getChildByName("chip").active = true) : (e.getChildByName("pool").getComponent(Label).string = "₹" + String(this._contest_source.all_reward), e.getChildByName("pool2").getComponent(Label).string = "₹" + String(this._contest_source.first_reward), e.getChildByName("chip").active = false));
        sys.isObjectValid(this._contest_source.left_sign_num) && sys.isObjectValid(this._contest_source.sign_num) && (e.getChildByName("progress").getComponent(ProgressBar).progress = (this._contest_source.sign_num - this._contest_source.left_sign_num) / this._contest_source.sign_num);
        sys.isObjectValid(this._contest_source.fee) && (sys.isObjectValid(this._contest_source.is_chip) && 1 == this._contest_source.is_chip ? (e.getChildByName("status_btn").getChildByName("node").getChildByName("wz").getComponent(Label).string = this._contest_source.fee, e.getChildByName("status_btn").getChildByName("node").getChildByName("ico").active = true) : (0 == Number(this._contest_source.fee) ? e.getChildByName("status_btn").getChildByName("node").getChildByName("wz").getComponent(Label).string = "FREE" : e.getChildByName("status_btn").getChildByName("node").getChildByName("wz").getComponent(Label).string = "₹" + this._contest_source.fee, e.getChildByName("status_btn").getChildByName("node").getChildByName("ico").active = false));
        e.getChildByName("status_btn").getComponent(Button).clickEvents[0].customEventData = ToolUtils.toJsonString(this._contest_source);
        this.noRootNode.getChildByName("nodata").getChildByName("btn_create").getComponent(Button).clickEvents[0].customEventData = ToolUtils.toJsonString(this._contest_source);
        sys.isObjectValid(this._contest_source.left_sign_num) && (e.getChildByName("left_desc1").getComponent(Label).string = this._contest_source.left_sign_num + " Left");
        sys.isObjectValid(this._contest_source.sign_num) && (e.getChildByName("left_desc2").getComponent(Label).string = this._contest_source.sign_num + " Spots");
        sys.isObjectValid(this._contest_source.reward_rate) && (e.getChildByName("prize_desc").getComponent(Label).string = this._contest_source.reward_rate);
        sys.isObjectValid(this._contest_source.person_sign_num) && (this._contest_source.person_sign_num > 1 ? (e.getChildByName("m_icon").getComponent(Sprite).spriteFrame = this.iconImgs[0], e.getChildByName("m_desc").getComponent(Label).string = ToolUtils.format(i18nMgr.shared().getValueByKey("yes11.upto"), this._contest_source.person_sign_num)) : (e.getChildByName("m_icon").getComponent(Sprite).spriteFrame = this.iconImgs[1], e.getChildByName("m_desc").getComponent(Label).string = this._contest_source.m_desc, e.getChildByName("m_desc").getComponent(Label).string = ToolUtils.format(i18nMgr.shared().getValueByKey("yes11.no_team"), this._contest_source.person_sign_num)));
        this.isJiangChiContest && (sys.isObjectValid(this._contest_source.last_all_reward) && this._contest_source.last_all_reward > 0 ? (e.getChildByName("max_pool").getComponent(Label).string = "₹" + this._contest_source.last_all_reward, e.getChildByName("jiangchi_node").getChildByName("amt").getComponent(Label).string = "₹" + ToolUtils.parse_double(this._contest_source.last_all_reward), e.getChildByName("jiangchi_node").getComponent(Layout).updateLayout(), this._contest_source.last_all_reward != this._contest_source.all_reward ? e.getChildByName("jiangchi_node").active = true : e.getChildByName("jiangchi_node").active = false) : e.getChildByName("jiangchi_node").active = false);
        this.refreshPos(e);
    }
    refreshPos(e) {
        e.getChildByName("pool2").getComponent(Label).updateRenderData(true);
        e.getChildByName("prize_desc").getComponent(Label).updateRenderData(true);
        let t = v3(0, 0);
        e.getChildByName("pool2").getPosition(t);
        let i = e.getChildByName("pool2").getComponent(UITransform).contentSize.width;
        this.isJiangChiContest && e.getChildByName("pool2_arrow").setPosition(v3(t.x + i + 10, t.y));
        e.getChildByName("prize_icon").setPosition(v3(t.x + i + 30, t.y));
        e.getChildByName("prize_desc").setPosition(v3(t.x + i + 30 + 20, t.y));
        let a = v3(0, 0);
        e.getChildByName("prize_desc").getPosition(a);
        i = e.getChildByName("prize_desc").getComponent(UITransform).contentSize.width;
        this.isJiangChiContest && e.getChildByName("prize_arrow").setPosition(v3(a.x + i + 10, t.y));
        e.getChildByName("m_icon").setPosition(v3(a.x + i + 30, t.y));
        e.getChildByName("m_desc").setPosition(v3(a.x + i + 30 + 20, t.y));
        e.getChildByName("pool").getComponent(Label).updateRenderData(true);
        let s = v3(0, 0);
        e.getChildByName("pool").getPosition(s);
        i = e.getChildByName("pool").getComponent(UITransform).contentSize.width;
        this.isJiangChiContest && e.getChildByName("pool_arrow").setPosition(v3(s.x + i + 10, -81.314));
    }
    requestNewList(e = false, t = false) {
        e && Utils.shared().showLoading(10, true, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
        }), ToolUtils.getIsNormalDirection());
        let i = { match_id: this._match_id, session_id: this._contest_id };
        HttpManager.shared().doGetCommonRequest(i, HttpRequest.Yes11_TeamList, ((e, t, i) => {
            if (Utils.shared().hideLoading(), 200 != i) {
                Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.request_fail"), 2);
            }
            else {
                try {
                    let e = ToolUtils.parseJson(t);
                    0 == e.ret ? sys.isObjectValid(e.data) && 0 == this.curTab && (this.teamTopNode.active = false, this._teamlistData = e.data.list, this.updateMyContentsList(), this.tabNode.getChildByName("tab0").getChildByName("Label").getComponent(Label).string = ToolUtils.format("Registered(${0})", this._teamlistData.length), this.noRootNode.getChildByName("nodata").active = 0 == e.data.list.length, 0 == e.data.list.length && (this.noRootNode.getChildByName("nodata").getChildByName("wz").getComponent(Label).string = "No Records", this.noRootNode.getChildByName("nodata").getChildByName("tip").getComponent(Label).string = "Lots of teams are playing, create team and win cash")) : sys.isObjectValid(e.desc) && e.desc.length > 0 && Utils.shared().showToast(e.desc, 2);
                }
                catch (e) {
                    TLog.printError("showSportCricket_teamList err:", e.toString());
                }
            }
        }));
    }
    updateMyContentsList() {
        let e = this.contentsScrollView.getComponent(ScrollView).content;
        if (e.removeAllChildren(), this._teamlistData && this._teamlistData.length > 0) {
            for (let t = 0, i = this._teamlistData.length; t < i; t++) {
                let i = instantiate(this.content_mobanView);
                e.addChild(i);
                this.initContentListItem(i, this._teamlistData[t], t);
            }
        }
    }
    initContentListItem(e, t, i) {
        e.active = true;
        let a = ToolUtils.toJsonString(t);
        if (e.getChildByName("bg").getComponent(Button).clickEvents[0].customEventData = a, e.getChildByName("edit_btn").getComponent(Button).clickEvents[0].customEventData = a, e.getChildByName("backup_btn").getComponent(Button).clickEvents[0].customEventData = a, e.getChildByName("copy_btn").getComponent(Button).clickEvents[0].customEventData = a, e.getChildByName("backup_btn").getChildByName("dot").active = false, sys.isObjectValid(t.fill_backup) && 1 == t.fill_backup && (1 == SportCricket_Manager.shared().cricket_backup_open ? (e.getChildByName("backup_btn").getChildByName("dot").active = true, e.getChildByName("backup_btn").active = true) : e.getChildByName("backup_btn").active = false), sys.isObjectValid(t.name) && t.name.length > 0 && (e.getChildByName("name").getComponent(Label).string = t.name), sys.isObjectValid(t.teama_short_name) && String(t.teama_short_name).length > 0 && (e.getChildByName("team_name0").getComponent(Label).string = t.teama_short_name), sys.isObjectValid(t.teamb_short_name) && String(t.teamb_short_name).length > 0 && (e.getChildByName("team_name1").getComponent(Label).string = t.teamb_short_name), sys.isObjectValid(t.teama_num) && String(t.teama_num).length > 0 && (e.getChildByName("team_num0").getComponent(Label).string = t.teama_num), sys.isObjectValid(t.teamb_num) && String(t.teamb_num).length > 0 && (e.getChildByName("team_num1").getComponent(Label).string = t.teamb_num), sys.isObjectValid(t.members) && Array.isArray(t.members) && t.members.length > 0) {
            for (let i = 0; i < t.members.length; i++) {
                let a = t.members[i];
                1 == Number(a.captain_role) ? (e.getChildByName("cap_node0").getChildByName("wz").getComponent(Label).string = a.short_name, a.out_team_id == t.teama_id ? (e.getChildByName("cap_node0").getChildByName("bg").getComponent(Sprite).spriteFrame = this.capBgImgs[0], e.getChildByName("cap_node0").getChildByName("wz").getComponent(Label).color = color(255, 255, 255), e.getChildByName("cap_node0").getChildByName("flag").getChildByName("wz").getComponent(Label).color = color(255, 255, 255), e.getChildByName("cap_node0").getChildByName("flag").getComponent(Sprite).spriteFrame = this.operateImgs[0]) : (e.getChildByName("cap_node0").getChildByName("bg").getComponent(Sprite).spriteFrame = this.capBgImgs[1], e.getChildByName("cap_node0").getChildByName("wz").getComponent(Label).color = color(51, 51, 51), e.getChildByName("cap_node0").getChildByName("flag").getChildByName("wz").getComponent(Label).color = color(51, 51, 51), e.getChildByName("cap_node0").getChildByName("flag").getComponent(Sprite).spriteFrame = this.operateImgs[1]), sys.isObjectValid(a.thumb_url) && a.thumb_url.length > 0 && (this.taskAwardIconMap.set(e.getChildByName("cap_node0").getChildByName("player_icon"), a.thumb_url), Utils.shared().updateNetImage(e.getChildByName("cap_node0").getChildByName("player_icon"), a.thumb_url, size(88, 88)))) : 2 == Number(a.captain_role) && (e.getChildByName("cap_node1").getChildByName("wz").getComponent(Label).string = a.short_name, a.out_team_id == t.teama_id ? (e.getChildByName("cap_node1").getChildByName("bg").getComponent(Sprite).spriteFrame = this.capBgImgs[0], e.getChildByName("cap_node1").getChildByName("wz").getComponent(Label).color = color(255, 255, 255), e.getChildByName("cap_node1").getChildByName("flag").getChildByName("wz").getComponent(Label).color = color(255, 255, 255), e.getChildByName("cap_node1").getChildByName("flag").getComponent(Sprite).spriteFrame = this.operateImgs[0]) : (e.getChildByName("cap_node1").getChildByName("bg").getComponent(Sprite).spriteFrame = this.capBgImgs[1], e.getChildByName("cap_node1").getChildByName("wz").getComponent(Label).color = color(51, 51, 51), e.getChildByName("cap_node1").getChildByName("flag").getChildByName("wz").getComponent(Label).color = color(51, 51, 51), e.getChildByName("cap_node1").getChildByName("flag").getComponent(Sprite).spriteFrame = this.operateImgs[1]), sys.isObjectValid(a.thumb_url) && a.thumb_url.length > 0 && (this.taskAwardIconMap.set(e.getChildByName("cap_node1").getChildByName("player_icon"), a.thumb_url), Utils.shared().updateNetImage(e.getChildByName("cap_node1").getChildByName("player_icon"), a.thumb_url, size(88, 88))));
            }
        }
    }
    onBackUpTeamClick(e, t) {
        if (SoundManager.shared().playFx("click"), sys.now() - this._lastClick < 500) {
            return;
        }
        if (this._lastClick = sys.now(), 3 == this._match_state) {
            return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("yes11.live_tip"), 2);
        }
        if (4 == this._match_state) {
            return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("yes11.cancel_tip"), 2);
        }
        let i = ToolUtils.parseJson(t), a = { match_id: this._match_id, team_id: i.team_id };
        SportCricket_Manager.shared().requestYes11_PreCreateTeamCheck(a, true, (e => {
            let t = { source: this._source, match_id: this._match_id, player_source: e, team_id: i.team_id, fromType: 3, lastNode: this.node };
            Utils.shared().showSportCricket_backUpPlayers(t);
        }));
    }
    onCopyTeamClick(e, t) {
        if (SoundManager.shared().playFx("click"), sys.now() - this._lastClick < 500) {
            return;
        }
        if (this._lastClick = sys.now(), 3 == this._match_state) {
            return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("yes11.live_tip"), 2);
        }
        if (4 == this._match_state) {
            return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("yes11.cancel_tip"), 2);
        }
        let i = ToolUtils.parseJson(t), a = { match_id: this._match_id, team_id: i.team_id };
        SportCricket_Manager.shared().requestYes11_PreCreateTeamCheck(a, true, (e => {
            let t = { source: this._source, match_id: this._match_id, player_source: e, team_id: i.team_id, fromType: 4, lastNode: this.node };
            Utils.shared().showSportCricket_createTeam(t);
        }));
    }
    onEditTeamClick(e, t) {
        if (SoundManager.shared().playFx("click"), sys.now() - this._lastClick < 500) {
            return;
        }
        if (this._lastClick = sys.now(), 3 == this._match_state) {
            return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("yes11.live_tip"), 2);
        }
        if (4 == this._match_state) {
            return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("yes11.cancel_tip"), 2);
        }
        let i = ToolUtils.parseJson(t), a = { match_id: this._match_id, team_id: i.team_id };
        SportCricket_Manager.shared().requestYes11_PreCreateTeamCheck(a, true, (e => {
            let t = { source: this._source, match_id: this._match_id, player_source: e, team_id: i.team_id, fromType: 3, lastNode: this.node };
            Utils.shared().showSportCricket_createTeam(t);
        }));
    }
    onJoinGameClick(e, t) {
        if (SoundManager.shared().playFx("click"), sys.now() - this._lastClick < 500) {
            return;
        }
        if (this._lastClick = sys.now(), 3 == this._match_state) {
            return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("yes11.live_tip"), 2);
        }
        if (4 == this._match_state) {
            return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("yes11.cancel_tip"), 2);
        }
        let i = ToolUtils.parseJson(t);
        this.checkJoinGame(i);
    }
    checkJoinGame(e) {
        let t = { session_id: e.session_id, match_id: this._match_id };
        Utils.shared().showLoading(10, true, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
        }), ToolUtils.getIsNormalDirection());
        SportCricket_Manager.shared().requestYes11_PreJoinGameCheck(t, true, (t => {
            if (sys.isObjectValid(t) && sys.isObjectValid(t.code)) {
                if (308501 == t.code) {
                    sys.isObjectValid(e.is_chip) && 1 == e.is_chip ? Utils.shared().showQuickRechargeByYes11({ fee: e.fee, is_chip: 1 }) : Utils.shared().showQuickRechargeByYes11({ fee: e.fee });
                    User.shared().updatePayScene(PhpReportDefined.pay_scene.hall_cricket);
                }
                else if (308502 == t.code) {
                    let t = 0;
                    sys.isObjectValid(e.is_chip) && (t = e.is_chip);
                    this.checkCreateTeam(1, e.session_id, t);
                }
                else if (308503 == t.code) {
                    let i = { match_id: this._match_id, contest_id: e.session_id, assureInfo: t };
                    sys.isObjectValid(e) && sys.isObjectValid(e.is_chip) && 1 == e.is_chip && (i.assureInfo.is_chip = 1);
                    Utils.shared().showSportCricket_assureJoin(i);
                }
                else if (308504 == t.code) {
                    let t = { match_id: this._match_id, contest_id: e.session_id };
                    SportCricket_Manager.shared().requestYes11_JoinList(t, true, (t => {
                        let i = { match_id: this._match_id, contest_id: e.session_id, teamlistData: t };
                        sys.isObjectValid(e) && sys.isObjectValid(e.is_chip) && 1 == e.is_chip && (i.teamlistData.is_chip = 1);
                        Utils.shared().showSportCricket_joinList(i);
                    }));
                }
            }
        }));
    }
    checkCreateTeam(e = 0, t, i = 0) {
        let a = { match_id: this._match_id };
        SportCricket_Manager.shared().requestYes11_PreCreateTeamCheck(a, true, (e => {
            let a = { source: this._source, match_id: this._match_id, player_source: e, fromType: 1 };
            sys.isObjectValid(t) && (a.contest_id = t);
            sys.isObjectValid(i) && (a.is_chip = i);
            Utils.shared().showSportCricket_createTeam(a);
        }));
    }
    updateGold(e) {
        let t = this.goldNode.getChildByName("coin");
        null != e && t && (t.getComponent(Label).string = ToolUtils.parse_double(User.shared().data.money));
    }
    onCloseButtonClick(e, t) {
        if (SoundManager.shared().playFx("click"), "back_btn" == t) {
            if (this._closed) {
                return;
            }
            this.onBackView();
        }
    }
    updateWinTabView() {
        let e = [color(51, 51, 51), color(168, 26, 26)];
        for (let t = 0; t < 2; t++) {
            this.winTabNodes[t].getChildByName("ico").active = this._winTab == t;
            t == this._winTab ? this.winTabNodes[t].getChildByName("Label").getComponent(Label).color = e[1] : this.winTabNodes[t].getChildByName("Label").getComponent(Label).color = e[0];
            i18nMgr.shared().changeLabelFont(this.winTabNodes[t].getChildByName("Label").getComponent(Label), t == this._winTab);
        }
    }
    initView() {
        this.fitScreen();
        this.isJiangChiContest ? (this.detailsNode2.active = true, this.detailsNode.active = false, this.rootNode.getChildByName("select_diban").getComponent(Widget).top = 748.96, this.rootNode.getChildByName("select_diban").getComponent(Widget).updateAlignment(), this.rootNode.getChildByName("no_root").getComponent(Widget).top = 840.068, this.rootNode.getChildByName("no_root").getComponent(Widget).updateAlignment(), this.rootNode.getChildByName("myContents_ScrollView").getComponent(Widget).top = 852, this.rootNode.getChildByName("myContents_ScrollView").getComponent(Widget).updateAlignment(), this.rootNode.getChildByName("myContents_ScrollView").getChildByName("view").getComponent(Widget).updateAlignment(), this.rootNode.getChildByName("leaderboard_ScrollView").getComponent(Widget).top = 908, this.rootNode.getChildByName("leaderboard_ScrollView").getComponent(Widget).updateAlignment(), this.rootNode.getChildByName("leaderboard_ScrollView").getChildByName("view").getComponent(Widget).updateAlignment(), this.rootNode.getChildByName("win_ScrollView").getComponent(Widget).top = 995.98, this.rootNode.getChildByName("win_ScrollView").getComponent(Widget).updateAlignment(), this.rootNode.getChildByName("win_ScrollView").getChildByName("view").getComponent(Widget).updateAlignment(), this.rootNode.getChildByName("win_top").getComponent(Widget).top = 924.197, this.rootNode.getChildByName("win_top").getComponent(Widget).updateAlignment(), this.rootNode.getChildByName("leader_top").getComponent(Widget).top = 839, this.rootNode.getChildByName("leader_top").getComponent(Widget).updateAlignment()) : (this.detailsNode2.active = false, this.detailsNode.active = true, this.rootNode.getChildByName("select_diban").getComponent(Widget).top = 659.814, this.rootNode.getChildByName("select_diban").getComponent(Widget).updateAlignment(), this.rootNode.getChildByName("no_root").getComponent(Widget).top = 750.068, this.rootNode.getChildByName("no_root").getComponent(Widget).updateAlignment(), this.rootNode.getChildByName("myContents_ScrollView").getComponent(Widget).top = 762, this.rootNode.getChildByName("myContents_ScrollView").getComponent(Widget).updateAlignment(), this.rootNode.getChildByName("myContents_ScrollView").getChildByName("view").getComponent(Widget).updateAlignment(), this.rootNode.getChildByName("leaderboard_ScrollView").getComponent(Widget).top = 818, this.rootNode.getChildByName("leaderboard_ScrollView").getComponent(Widget).updateAlignment(), this.rootNode.getChildByName("leaderboard_ScrollView").getChildByName("view").getComponent(Widget).updateAlignment(), this.rootNode.getChildByName("win_ScrollView").getComponent(Widget).top = 822.58, this.rootNode.getChildByName("win_ScrollView").getComponent(Widget).updateAlignment(), this.rootNode.getChildByName("win_ScrollView").getChildByName("view").getComponent(Widget).updateAlignment(), this.rootNode.getChildByName("win_top").getComponent(Widget).top = 750.276, this.rootNode.getChildByName("win_top").getComponent(Widget).updateAlignment(), this.rootNode.getChildByName("leader_top").getComponent(Widget).top = 749, this.rootNode.getChildByName("leader_top").getComponent(Widget).updateAlignment());
        this.updateTopContestDetails();
        this.updateContestDetails();
        let e = [this.team_mobanView];
        this.leaderboardTable = this.node.addComponent(TableViewUtils);
        let t = this.team_mobanView.getComponent(UITransform).height;
        this.leaderboardTable.init([], this.leaderboardScrollView.node, e, this.initAllTeamItem.bind(this), 10, t, this.allteam_scrollRefreshCallBack.bind(this));
        this.rank_mobanView;
        this.rank_mobanView.getComponent(UITransform).height;
        if (sys.isObjectValid(this._source)) {
            this.rootNode.getChildByName("top_node").getChildByName("title").getComponent(Label).string = this._source.teama.short_name + " vs " + this._source.teamb.short_name;
            this.topNode.getChildByName("time_state").active = false;
            let e = this.rootNode.getChildByName("top_node").getChildByName("lefttime");
            sys.isObjectValid(this._source.status) && (this._match_state = this._source.status);
            let t = this.topNode.getChildByName("daybg"), i = this.topNode.getChildByName("hourbg"), a = this.topNode.getChildByName("secbg"), s = Utils.shared().parseTimeCount(this._source.time_left);
            t.getChildByName("time").getComponent(Label).string = s[0] > 9 ? String(s[0]) : "0" + String(s[0]);
            i.getChildByName("time").getComponent(Label).string = s[1] > 9 ? String(s[1]) : "0" + String(s[1]);
            a.getChildByName("time").getComponent(Label).string = s[2] > 9 ? String(s[2]) : "0" + String(s[2]);
            0 == this._source.time_left && 1 == this._source.status ? (e.getComponent(Label).string = this._source.start_day, sys.isObjectValid(this._source.is_current_day) && 1 == Number(this._source.is_current_day) && (this._source.status = 3, e.getComponent(Label).string = "Live", this.topNode.getChildByName("time_state").active = true, this.topNode.getChildByName("time_state").getComponent(Label).string = "Live", t.active = false, i.active = false, a.active = false)) : 1 == this._source.status ? TweenTool.myschedule(e, 1, (() => {
                if (ToolUtils.isObjValid(this.node)) {
                    if (this._source.time_left > 0) {
                        this._source.time_left = this._source.time_left - 1;
                        let e = Utils.shared().parseTimeCount(this._source.time_left);
                        t.getChildByName("time").getComponent(Label).string = e[0] > 9 ? String(e[0]) : "0" + String(e[0]);
                        i.getChildByName("time").getComponent(Label).string = e[1] > 9 ? String(e[1]) : "0" + String(e[1]);
                        a.getChildByName("time").getComponent(Label).string = e[2] > 9 ? String(e[2]) : "0" + String(e[2]);
                    }
                    else {
                        this._source.status = 3;
                        e.getComponent(Label).string = "Live";
                        TweenTool.stopNodeAction(e);
                        this.topNode.getChildByName("time_state").active = true;
                        this.topNode.getChildByName("time_state").getComponent(Label).string = "Live";
                        t.active = false;
                        i.active = false;
                        a.active = false;
                    }
                }
            })) : 3 == this._source.status ? (TweenTool.stopNodeAction(e), e.getComponent(Label).string = "Live", this.topNode.getChildByName("time_state").active = true, this.topNode.getChildByName("time_state").getComponent(Label).string = "Live", t.active = false, i.active = false, a.active = false) : 4 == this._source.status && (TweenTool.stopNodeAction(e), e.getComponent(Label).string = "Cancel", this.topNode.getChildByName("time_state").active = true, this.topNode.getChildByName("time_state").getComponent(Label).string = "Cancel", t.active = false, i.active = false, a.active = false);
            PushCenter.shared().addListener(PushEvent.UpdateYes11CurMatchLeftTime, (t => {
                try {
                    ToolUtils.isObjValid(this.node) && t.match_id == this._match_id && (this._source.time_left = t.time_left, this._source.is_current_day = t.is_current_day, this._match_state = t.status, 3 == t.status ? (TweenTool.stopNodeAction(e), e.getComponent(Label).string = "Live") : 4 == t.status && (TweenTool.stopNodeAction(e), e.getComponent(Label).string = "Cancel"));
                }
                catch (e) {
                    TLog.printError(this.TAG, PushEvent.UpdateYes11CurMatchLeftTime, e);
                }
            }), this);
            PushCenter.shared().addListener(PushEvent.ChangeYes11DetailsWin, (e => {
                try {
                    if (ToolUtils.isObjValid(this.node)) {
                        if (1 == this.curTab) {
                            return;
                        }
                        this.curTab = 1;
                        this.updateTabView();
                        this.updateTabContent();
                    }
                }
                catch (e) {
                    TLog.printError(this.TAG, PushEvent.ChangeYes11DetailsWin, e);
                }
            }), this);
            PushCenter.shared().addListener(PushEvent.Update_Gullak_RewardInGame, (e => {
                ToolUtils.isObjValid(this.node) && this.updateGullakBtnStatus(User.shared().act_68_open, User.shared().act_68_full_status, true);
            }), this);
        }
        this.updateGullakBtnStatus(User.shared().act_68_open, User.shared().act_68_full_status, true);
    }
    onSwtichTeamClick(e, t) {
        if (SoundManager.shared().playFx("click"), sys.now() - this._lastClick < 500) {
            return;
        }
        if (this._lastClick = sys.now(), 3 == this._match_state) {
            return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("yes11.live_tip"), 2);
        }
        if (4 == this._match_state) {
            return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("yes11.cancel_tip"), 2);
        }
        let i = ToolUtils.parseJson(t);
        this.dealSwitchLogic(i);
    }
    dealSwitchLogic(e) {
        let t = { match_id: this._match_id, team_id: e.team_id };
        SportCricket_Manager.shared().requestYes11_PreCreateTeamCheck(t, true, (t => {
            let i = { source: this._source, match_id: this._match_id, player_source: t, team_id: e.team_id, fromType: 2 };
            1 == SportCricket_Manager.shared().checkHasLineUp(t) && (i.fromType = 3);
            Utils.shared().showSportCricket_createTeam(i);
        }));
    }
    onButtonClick(e, t) {
        if (SoundManager.shared().playFx("click"), !(sys.now() - this._lastClick < 500)) {
            if (this._lastClick = sys.now(), 3 != this._match_state) {
                if (4 != this._match_state) {
                    if ("tab0" == t) {
                        if (0 == this.curTab) {
                            return;
                        }
                        this.curTab = 0;
                        this.updateTabView();
                        this.updateTabContent();
                    }
                    else if ("tab1" == t) {
                        if (1 == this.curTab) {
                            return;
                        }
                        this.curTab = 1;
                        this.updateTabView();
                        this.updateTabContent();
                    }
                    else if ("win_tab0" == t) {
                        if (0 == this._winTab) {
                            return;
                        }
                        this._winTab = 0;
                        this.updateWinTabView();
                        this.updateTabContent();
                    }
                    else if ("win_tab1" == t) {
                        if (1 == this._winTab) {
                            return;
                        }
                        this._winTab = 1;
                        this.updateWinTabView();
                        this.updateTabContent();
                    }
                    else if ("tab2" == t) {
                        if (2 == this.curTab) {
                            return;
                        }
                        this.curTab = 2;
                        this.updateTabView();
                        this.updateTabContent();
                    }
                    else if ("add_chip" == t) {
                        Utils.shared().showStoreView(null, null);
                        User.shared().updatePayScene(PhpReportDefined.pay_scene.hall_cricket);
                    }
                    else if ("gullak" == t) {
                        let e = {};
                        Utils.shared().doJumpLogic(PushEvent.JUMP_TO_Gullak, e, { isNext: false, bWithTip: true, link_id: sys.now(), reportEvtId: 4, reportScene: 2 });
                        User.shared().updatePayScene(PhpReportDefined.pay_scene.hall_cricket);
                    }
                }
                else {
                    Utils.shared().showToast(i18nMgr.shared().getValueByKey("yes11.cancel_tip"), 2);
                }
            }
            else {
                Utils.shared().showToast(i18nMgr.shared().getValueByKey("yes11.live_tip"), 2);
            }
        }
    }
    updateGullakBtnStatus(e, t, i) {
        let a = this.rootNode.getChildByName("top_node").getChildByName("gullak_btn");
        if (ToolUtils.isObjValid(a) && (a.active = 1 == e, 1 == e)) {
            let e = a.getChildByName("anim").getComponent(sp.Skeleton);
            e.clearTracks();
            e.setToSetupPose();
            i ? (e.setAnimation(0, "2", false), e.setCompleteListener((() => {
                e.setCompleteListener(null);
                e.clearTracks();
                e.setToSetupPose();
                0 == t ? e.setAnimation(0, "0", true) : e.setAnimation(0, "1", true);
            }))) : 0 == t ? e.setAnimation(0, "0", true) : e.setAnimation(0, "1", true);
        }
    }
    updateTabContent() {
        if (this.contentsScrollView.node.active = 0 == this.curTab, this.winScrollView.node.active = 1 == this.curTab, this.leaderboardScrollView.node.active = 2 == this.curTab, this.noRootNode.getChildByName("nodata").active = false, this.taskAwardIconMap.clear(), this.teamTopNode.active = false, 0 == this.curTab) {
            let e = true;
            this.rootNode.getChildByName("score_tab").active = false;
            sys.isObjectValid(this._teamlistData) && (this.tabNode.getChildByName("tab0").getChildByName("Label").getComponent(Label).string = ToolUtils.format("Registered(${0})", this._teamlistData.length), Array.isArray(this._teamlistData) && this._teamlistData.length > 0 && this.updateMyContentsList(), e = false);
            this.requestNewList(e, true);
        }
        else if (2 == this.curTab) {
            let e = true;
            this.rootNode.getChildByName("score_tab").active = false;
            sys.isObjectValid(this.leader_listData) && (Array.isArray(this.leader_listData) && this.leader_listData.length > 0 && (this.leaderboardTable.reloadData(this.leader_listData), this.teamTopNode.active = true), e = false);
            this.all_cur_page = 1;
            this.requestLeaderBoardList(e, true);
        }
        else {
            this.isJiangChiContest && (this.updateWinTabView(), this.rootNode.getChildByName("score_tab").active = true);
            let e = this.win_listData;
            if (this.isJiangChiContest && (e = 0 == this._winTab ? this.win_listData_pool0 : this.win_listData_pool1), sys.isObjectValid(e) && Array.isArray(e) && e.length > 0) {
                this.winScrollView.content.removeAllChildren();
                this.winScrollView.scrollToTop(0);
                for (let t = 0; t < e.length; t++) {
                    let i = null, a = 1;
                    this.isJiangChiContest ? 1 == this._winTab || this._contest_source.last_all_reward == this._contest_source.all_reward ? i = instantiate(this.rank_mobanView) : 0 == t || t == e.length - 1 ? (i = instantiate(this.rank_mobanView2), a = 2) : i = instantiate(this.rank_mobanView) : i = instantiate(this.rank_mobanView);
                    i.active = true;
                    this.winScrollView.content.addChild(i);
                    this.initRankItem(i, e[t], t, a);
                }
            }
            else {
                let e = true;
                this.my_cur_page = 1;
                this.requestWinList(e, true);
            }
        }
    }
    onBackView(e = true) {
        e && (Utils.shared().hideLoading(), this.bShowPushAnim ? (this._closed = true, ToolUtils.isObjValid(this._lastNode) && (this._lastNode.active = true), ToolUtils.showPushAnim(this.node, 1, (() => {
            ToolUtils.isObjValid(this.node) && this.node.destroy();
        }))) : (ToolUtils.isObjValid(this._lastNode) && (this._lastNode.active = true), ToolUtils.isObjValid(this.node) && this.node.destroy()));
    }
    fitScreen() {
        ToolUtils.adaptSafeArea(this.rootNode);
        let e = sys.getSafeAreaRect().y, t = view.getVisibleSize();
        if (this.node.getComponent(UITransform).setContentSize(t.width, t.height), 0 != e) {
            let t = this.leaderboardScrollView.getComponent(Widget).bottom;
            this.leaderboardScrollView.getComponent(Widget).bottom = t - e;
            t = this.winScrollView.getComponent(Widget).bottom;
            this.winScrollView.getComponent(Widget).bottom = t - e;
            t = this.bottomNode.getComponent(Widget).bottom;
            this.bottomNode.getComponent(Widget).bottom = t - e;
        }
    }
}
