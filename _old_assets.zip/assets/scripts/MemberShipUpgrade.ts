// @ts-nocheck
// Recovered from index.js:309
import { _decorator, Label, Node, Sprite, SpriteFrame, sys, v3 } from "cc";
import BaseLayer from "./BaseLayer";
import SoundManager from "./SoundManager";
import PushEvent from "./PushEvent";
import User from "./User";
import { ToolUtils } from "./ToolUtils";
import PushCenter from "./PushCenter";
const { ccclass, property } = _decorator;
@ccclass("MemberShipUpgrade")
export class MemberShipUpgrade extends BaseLayer {
    @property(Node)
    public rootNode: Node = null;
    @property(Node)
    public rewardNode: Node = null;
    @property([SpriteFrame])
    public clubIcoSprite: SpriteFrame[] = [];
    public upgradeData: any = null;
    public _callback: any = null;
    public _lastClick: number = 0;
    initParaData(e, t = null) {
        this.upgradeData = e;
        this._callback = t;
    }
    onLoad() {
        ToolUtils.showFullScreen(this.node.getChildByName("mask"));
    }
    start() {
        super.start();
        User.shared().clubUpgradeMsg = null;
        this.startShowAnim(this.rootNode, (() => {
        }));
        this.initView();
        PushCenter.shared().pushEvent(PushEvent.Notice_VipUpdateShow);
    }
    initView() {
        if (sys.isObjectValid(this.upgradeData)) {
            let e = User.shared().data.player_club, t = User.shared().getGradeByMemberShipLevel(e.club_level);
            this.rootNode.getChildByName("club_ico").getComponent(Sprite).spriteFrame = this.clubIcoSprite[t];
            this.rootNode.getChildByName("club_name").getComponent(Label).string = e.club_name;
            let i = -1;
            this.rewardNode.getChildByName("add").active = true;
            sys.isObjectValid(this.upgradeData.cash) && Number(this.upgradeData.cash) > 0 ? (i += 1, this.rewardNode.getChildByName("item0").getChildByName("num").getComponent(Label).string = "₹" + String(this.upgradeData.cash), this.rewardNode.getChildByName("item0").active = true) : (this.rewardNode.getChildByName("item0").active = false, this.rewardNode.getChildByName("add").active = false);
            sys.isObjectValid(this.upgradeData.bonus) && Number(this.upgradeData.bonus) > 0 ? (i += 1, this.rewardNode.getChildByName("item1").getChildByName("num").getComponent(Label).string = "₹" + String(this.upgradeData.bonus), this.rewardNode.getChildByName("item1").active = true) : (this.rewardNode.getChildByName("item1").active = false, this.rewardNode.getChildByName("add").active = false);
            this.rewardNode.active = -1 != i;
            this.rootNode.getChildByName("diban").active = -1 != i;
            -1 == i ? ToolUtils.getIsInRoom() ? (this.rootNode.getChildByName("club_ico").setPosition(v3(0, 35.343)), this.rootNode.getChildByName("club_name").setPosition(v3(0, -68.712))) : (this.rootNode.getChildByName("club_ico").setPosition(v3(0, 5.8)), this.rootNode.getChildByName("club_name").setPosition(v3(0, -131.049))) : ToolUtils.getIsInRoom() ? (this.rootNode.getChildByName("club_ico").setPosition(v3(0, 92.387)), this.rootNode.getChildByName("club_name").setPosition(v3(0, -11.668))) : (this.rootNode.getChildByName("club_ico").setPosition(v3(0, 89.173)), this.rootNode.getChildByName("club_name").setPosition(v3(0, -47.676)));
        }
    }
    onButtonClick(e, t) {
        SoundManager.shared().playFx("click");
        sys.now() - this._lastClick < 1000 || (this._lastClick = sys.now(), "close" == t && (this._callback && this._callback(), this.onBackView()));
    }
    onBackView() {
        User.shared().clubUpgradeMsg = null;
        ToolUtils.isObjValid(this.node) && this.node.destroy();
        PushCenter.shared().pushEvent(PushEvent.Notice_VipUpdateHide);
        sys.isObjectValid(this.upgradeData.flop_tidkey) && (PushCenter.shared().pushEvent(PushEvent.NoticeFinishFlopStart, this.upgradeData.flop_tidkey), PushCenter.shared().pushEvent(PushEvent.NoticeFinishFlop, this.upgradeData.flop_tidkey));
        ToolUtils.judgeIfInHall() && PushCenter.shared().pushEvent(PushEvent.Update_NextPopActivity);
    }
}
