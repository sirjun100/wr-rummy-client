// @ts-nocheck
// Recovered from index.js:649
import { _decorator, Component, color, Color, isValid, Label, size, Sprite, sys, tween, Tween, UIOpacity, UITransform } from "cc";
const { ccclass } = _decorator;
@ccclass("TweenTool")
export default class TweenTool extends Component {
    static moveBy(t, e, o, a, r, i) {
        let l = tween(t).by(e, { position: o }, { easing: a });
        return i && l.call(i), r && l.start(), l;
    }
    static moveTo(t, e, o, a, r, i) {
        let l = tween(t).to(e, { position: o }, { easing: a });
        return i && l.call(i), r && l.start(), l;
    }
    static fadeMoveByEasing(t, e, o, r, i, l, s, c) {
        let p = tween(t).to(e, { position: o }, { easing: l }), g = tween(t).to(e, { position: o }, { onUpdate: (t, e) => {
                t.getComponent(UIOpacity).opacity = 255 * (r + (i - r) * e);
            }, onComplete: t => {
                t.getComponent(UIOpacity).opacity = 255 * i;
            }, onStart: t => {
                t.getComponent(UIOpacity).opacity = 255 * r;
            } }), m = tween(t).parallel(p, g);
        return c && m.call(c), s && m.start(), m;
    }
    static fadeInOrOut(t, e, o, r, i, l) {
        let s = tween(t).to(e, { position: t.getPosition() }, { onUpdate: (t, e) => {
                t.getComponent(UIOpacity).opacity = 255 * (o + (r - o) * e);
            }, onComplete: t => {
                t.getComponent(UIOpacity).opacity = 255 * r;
            }, onStart: t => {
                t.getComponent(UIOpacity).opacity = 255 * o;
            } });
        return l && s.call(l), i && s.start(), s;
    }
    static fadeScaleByEasing(t, e, o, r, i, l, s, c) {
        let p, g = tween(t).to(e, { scale: o }, { easing: l });
        t.getPosition(p);
        let m = tween(t).to(e, { position: p }, { onUpdate: (t, e) => {
                t.getComponent(UIOpacity).opacity = 255 * (r + (i - r) * e);
            }, onComplete: t => {
                t.getComponent(UIOpacity).opacity = 255 * i;
            }, onStart: t => {
                t.getComponent(UIOpacity).opacity = 255 * r;
            } }), C = tween(t).parallel(g, m);
        return c && C.call(c), s && C.start(), C;
    }
    static moveToByFade(t, e, o, r, i, l, s) {
        let c = tween(t).to(e, { position: o }, { onUpdate: (t, e) => {
                t.getComponent(UIOpacity).opacity = 255 * (r + (i - r) * e);
            }, onComplete: t => {
                t.getComponent(UIOpacity).opacity = 255 * i;
            }, onStart: t => {
                t.getComponent(UIOpacity).opacity = 255 * r;
            } });
        return s && c.call(s), l && c.start(), c;
    }
    static blink(t, e, o, a, l) {
        let s = t;
        sys.isObjectValid(l) && isValid(l, true) && (s = l);
        let c = tween(s).repeat(e, tween().call((() => t.active = !t.active)).delay(0.2));
        return a && c.call(a), o && c.start(), c;
    }
    static moveSpriteByFade(t, e, o, a, r, i, c) {
        let p = t.getComponent(Sprite).color, g = tween(t).to(e, { position: o }, { onUpdate: (t, e) => {
                t.getComponent(Sprite).color = color(p.r, p.g, p.b, a < r ? 255 * (a + (r - a) * e) : 255 * (a - (a - r) * e));
            }, onComplete: t => {
                t.getComponent(Sprite).color = color(p.r, p.g, p.b, 255 * r);
            }, onStart: t => {
                t.getComponent(Sprite).color = color(p.r, p.g, p.b, 255 * a);
            } });
        return c && g.call(c), i && g.start(), g;
    }
    static moveLabelByFade(t, e, o, a, r, i, l) {
        let p = t.getComponent(Label).color, g = tween(t).to(e, { position: o }, { onUpdate: (t, e) => {
                t.getComponent(Label).color = color(p.r, p.g, p.b, a < r ? 255 * (a + (r - a) * e) : 255 * (a - (a - r) * e));
            }, onComplete: t => {
                t.getComponent(Label).color = color(p.r, p.g, p.b, 255 * r);
            }, onStart: t => {
                t.getComponent(Label).color = color(p.r, p.g, p.b, 255 * a);
            } });
        return l && g.call(l), i && g.start(), g;
    }
    static gradientLableColor(t, e, o, a, r, i) {
        let l;
        t.getScale(l);
        let s = tween(t).to(e, { scale: l }, { onUpdate: (t, e) => {
                let n = o.r + (a.r - o.r) * e, r = o.g + (a.g - o.g) * e, i = o.b + (a.b - o.b) * e, l = o.a + (a.a - o.a) * e;
                t.getComponent(Label).color = new Color(n, r, i, l);
            }, onComplete: t => {
                t.getComponent(Label).color = a;
            }, onStart: t => {
                t.getComponent(Label).color = o;
            } });
        i && s.call(i);
        r && s.start();
    }
    static scaleBy(t, e, o, a, r, i) {
        let l = tween(t).by(e, { scale: o }, { easing: a });
        return i && l.call(i), r && l.start(), l;
    }
    static scaleTo(t, e, o, a, r, i) {
        let l = tween(t).to(e, { scale: o }, { easing: a });
        return i && l.call(i), r && l.start(), l;
    }
    static rotateBy(t, e, o, a, r, i) {
        let l = tween(t).by(e, { eulerAngles: o }, { easing: a });
        return i && l.call(i), r && l.start(), l;
    }
    static rotateTo(t, e, o, a, r, i) {
        let l = tween(t).to(e, { eulerAngles: o }, { easing: a });
        return i && l.call(i), r && l.start(), l;
    }
    static delayAct(t, e, o, a) {
        let r = tween(t).delay(o).call(e);
        return a && r.start(), r;
    }
    static sequence(t, e, o, ...a) {
        let r = tween(t).sequence(...a);
        return o && r.call(o), e && r.start(), r;
    }
    static parallel(t, e, o, ...a) {
        let r = tween(t).parallel(...a);
        return o && r.call(o), e && r.start(), r;
    }
    static flicker(t, e) {
        let o = e || 0.1, a = tween(t).delay(o).hide().delay(o).show().union().repeatForever();
        return a.start(), a;
    }
    static flickerOpacity(t, e, o, r, i) {
        let l = tween(t).to(i, { position: e }, { onUpdate: (t, e) => {
                t.getComponent(UIOpacity).opacity = 255 * (o + (r - o) * e);
            }, onComplete: t => {
                t.getComponent(UIOpacity).opacity = 255 * r;
            }, onStart: t => {
                t.getComponent(UIOpacity).opacity = 255 * o;
            } }), s = tween(t).to(i, { position: e }, { onUpdate: (t, e) => {
                t.getComponent(UIOpacity).opacity = 255 * (r - (r - o) * e);
            }, onComplete: t => {
                t.getComponent(UIOpacity).opacity = 255 * o;
            }, onStart: t => {
                t.getComponent(UIOpacity).opacity = 255 * r;
            } }), c = tween(t).sequence(l, s).union().repeatForever();
        return c.start(), c;
    }
    static changeUItranform(t, e, o, a, r, i, l) {
        let s = tween(t).to(r, { position: e }, { onUpdate: (t, e) => {
                let n = o.width + (a.width - o.width) * e, r = o.height + (a.height - o.height) * e;
                t.getComponent(UITransform).setContentSize(size(n, r));
            }, onComplete: t => {
                t.getComponent(UITransform).setContentSize(a);
            }, onStart: t => {
                t.getComponent(UITransform).setContentSize(o);
            } });
        return l && s.call(l), i && s.start(), s;
    }
    static repeatForever(t) {
        t.repeatForever();
    }
    static startAction(t) {
        t.start();
    }
    static stopAction(t) {
        sys.isObjectValid(t) && (t.stop(), t = null);
    }
    static show(t) {
        let e = tween(t).show();
        return e.start(), e;
    }
    static hide(t) {
        let e = tween(t).hide();
        return e.start(), e;
    }
    static stopNodeAction(t) {
        Tween.stopAllByTarget(t);
    }
    static myschedule(t, e, o) {
        let a = 1, r = tween(t).to(1, { position: t.getPosition() }, { onUpdate: (t, n) => {
                n >= e * a && (e < 1 && n > 0.9 ? 1 != a && (a += 1, o && o()) : (a += 1, o && o()));
            }, onComplete: t => {
                a = 100;
            }, onStart: t => {
                a = 1;
            } }).repeatForever();
        return r.start(), r;
    }
    static fadeInOut(t, e) {
        let o = e.target_position, r = e.fadeStart, i = e.fadeEnd, l = e.duration, s = e.font_change, p = e.font_start, g = e.font_end, m = e.easing, C = tween(t).to(l, { position: o, easing: m }, { onUpdate: (e, o) => {
                e.getComponent(UIOpacity).opacity = 255 * (r + (i - r) * o);
                s && (t.getComponent(Label).fontSize = p + (g - p) * o);
            }, onComplete: e => {
                e.getComponent(UIOpacity).opacity = 255 * i;
                s && (t.getComponent(Label).fontSize = g);
            }, onStart: e => {
                e.getComponent(UIOpacity).opacity = 255 * r;
                s && (t.getComponent(Label).fontSize = p);
            } });
        return C.start(), C;
    }
    static commonSchedule(t, e, o) {
        let a = tween(t).to(e, { position: t.getPosition() }, { onUpdate: (t, e) => {
            }, onComplete: e => {
                o && o(t);
            }, onStart: t => {
            } }).repeatForever();
        return a.start(), a;
    }
}
