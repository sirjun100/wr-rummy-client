// @ts-nocheck
// Recovered from index.js:417
import { _decorator, Component, Button, color, director, instantiate, Label, Node, ProgressBar, ScrollView, size, Sprite, SpriteAtlas, SpriteFrame, sys, UITransform, v3, Vec3 } from "cc";
import i18nMgr from "./i18nMgr";
import PushCenter from "./PushCenter";
import { TLog } from "./TLog";
import Utils from "./Utils";
import GameConfig from "./GameConfig";
import HowToPlayDefined from "./HowToPlayDefined";
import NetConfig from "./NetConfig";
import URLConfig from "./URLConfig";
import User from "./User";
import NetHostManager from "./NetHostManager";
import SoundManager from "./SoundManager";
import PushEvent from "./PushEvent";
import TweenTool from "./TweenTool";
import Server from "./Server";
import { ScrollviewUtils } from "./ScrollviewUtils";
import HttpManager from "./HttpManager";
import { ToolUtils } from "./ToolUtils";
import AppInfo from "./AppInfo";
import CommDefine from "./CommDefine";
import PhpReportDefined from "./PhpReportDefined";
const { ccclass, property } = _decorator;
@ccclass("RummyAddGameList")
export class RummyAddGameList extends Component {
    @property(Node)
    public room_moban: Node = null;
    @property(Node)
    public RummyView: Node = null;
    @property(Node)
    public nodata: Node = null;
    @property(Node)
    public loading: Node = null;
    @property(Node)
    public content: Node = null;
    @property([Node])
    public switchBtn: Node[] = [];
    @property([Label])
    public switchBtnText: Label[] = [];
    @property([SpriteFrame])
    public matchTypeFrame: SpriteFrame[] = [];
    @property([SpriteFrame])
    public btnStateFrame: SpriteFrame[] = [];
    @property([SpriteFrame])
    public ticket_flagImages: SpriteFrame[] = [];
    @property([SpriteFrame])
    public mobanBgFrames: SpriteFrame[] = [];
    @property([SpriteFrame])
    public remindFlagFrame: SpriteFrame[] = [];
    @property(SpriteAtlas)
    public rewardAtlas: SpriteAtlas = null;
    @property([SpriteFrame])
    public filitBtnFrame: SpriteFrame[] = [];
    public rewardNames: any[] = ["reward_watch.png"];
    public itemViewDate: any[] = [];
    public _scrollUtil: any = null;
    public _itemLen: number = 0;
    public loadingAction: any = null;
    public delayAction: any = null;
    public loadingDelayAction: any = null;
    public isDisconnectServer: boolean = false;
    public lastType: number = 0;
    public networkDelay: number = 0;
    public matchroom_vid: number = 430;
    public matchInfoList: any = null;
    public histroyList: any = null;
    public curGameStatus: number = 0;
    public curGameType: number = 0;
    public backgroundSatyTime: number = 0;
    public curPage: number = 1;
    public totalPage: number = 0;
    public _lastClick: number = 0;
    public gameSelect: any = { 0: { gameStatus: 0, gameType: 0 }, 1: { gameStatus: 0, gameType: 0 } };
    public CompetitionStatus: any[] = ["tournament.all", "tournament.registering1", "tournament.late_registering", "tournament.running1", "tournament.completed1", "tournament.upcoming1"];
    public EventType: any[] = ["tournament.all", "tournament.free", "tournament.cash", "tournament.club", "tournament.special"];
    public matchBtnStatus: any[] = ["tournament.upcoming", "tournament.join_now", "tournament.withdraw", "tournament.full", "tournament.enter", "tournament.eliminated2", "tournament.running", "tournament.completed", "tournament.rejoin2", "tournament.late_registing2", "tournament.late_join2", "tournament.early_seating2"];
    public RegisterButtonStatus: any = { UPCOMING: 0, JOINNOW: 1, WITHDRAW: 2, FULL: 3, ENTER: 4, ELIMINATED: 5, RUNNING: 6, COMPLETED: 7, REJOIN: 8, LATEREGISTER: 9, LATE_JOIN: 10, EARLY_SEATING: 11 };
    public remindMatchInfo: any = {};
    public _isOpenCalendar: boolean = false;
    public time_node: any = null;
    public tab_noselect_color: any = color(10, 10, 10, 255);
    public tab_select_color: any = color(183, 0, 0, 255);
    onEnable() {
        this.doConnectRequest();
        this.curPage = 1;
        this.send_get_race_list(this.curPage);
    }
    onLoad() {
        this._scrollUtil = this.node.addComponent(ScrollviewUtils);
        this._scrollUtil.initScrollviewUtils(this.RummyView.getComponent(ScrollView));
        this.itemViewDate = [];
        this._isOpenCalendar = AppInfo.shared().isCalendarSupport();
        this.fitLuckyTheme();
    }
    fitLuckyTheme() {
        0 != GameConfig.NATIVE_GAME_APP_TYPE && (this.tab_noselect_color = color(51, 51, 51, 255), this.tab_select_color = color(47, 66, 98, 255));
    }
    start() {
        this.room_moban.active = false;
        this.refreshSwitchTab(0);
        PushCenter.shared().addListener(GameConfig.Update_Match_Hall, (() => {
            this.doConnectRequest();
        }), this);
        PushCenter.shared().addListener(GameConfig.onEnterForeground, (t => {
            if (ToolUtils.isGameBackground = false, ToolUtils.isObjValid(this.node)) {
                let t = this;
                sys.now() / 1000 - this.backgroundSatyTime / 1000 > 30 || ToolUtils.backgroundWebSocketReconnection ? (ToolUtils.backgroundWebSocketReconnection = false, this.scheduleOnce((() => {
                    Server.shared().disconnectWebSocket();
                    t.doConnectRequest();
                }))) : this.scheduleOnce((() => {
                    Server.shared().pop_response();
                    this.curPage = 1;
                    t.send_get_race_list(this.curPage);
                }));
            }
        }), this);
        PushCenter.shared().addListener(GameConfig.onEnterBackground, (t => {
            ToolUtils.isGameBackground = true;
            this.backgroundSatyTime = sys.now();
        }), this);
        PushCenter.shared().addListener(PushEvent.CancelEnterMatch, (t => {
            this.node && this.node.active && this.send_get_race_list(this.curPage);
        }), this);
        PushCenter.shared().addListener(PushEvent.OnCalendarPermissionSucc, (t => {
            this.node && this.node.active && 1 == t && (this.remindMatchInfo.status == this.RegisterButtonStatus.UPCOMING || this.remindMatchInfo.btn_status == this.RegisterButtonStatus.UPCOMING ? this.setMatchRemind(0) : (this.setMatchRemind(1), Utils.shared().showToast(ToolUtils.format("You will get a reminder when the tournament about to starts at ${0}", this.remindMatchInfo.time_info), 3)), this.updateMatchRoomList());
        }), this);
        1 == ToolUtils.heart_open && (this.unschedule(this.netWorkDelayUpdate), this.schedule(this.netWorkDelayUpdate, 1));
        this.matchInfoList = User.shared().matchInfoList;
        sys.isObjectValid(this.matchInfoList) && this.updateMatchRoomList();
        this.time_node = new Node;
        this.node.addChild(this.time_node);
        TweenTool.myschedule(this.time_node, 1, this.updateMatchTime.bind(this));
        Utils.shared().loadRemoteDeskImage(null, "rummy_card_table_bg_07");
        Utils.shared().loadRemoteDeskImage(null, "rummy_game_bg_6");
    }
    updateMatchTime(t) {
        if (sys.isObjectValid(this.matchInfoList)) {
            for (let t, e = 0, i = this.matchInfoList.length; e < i; e++) {
                t = this.matchInfoList[e];
                t.will_ready_time > 0 && (t.will_ready_time -= 1);
                t.will_start_time > 0 && (t.will_start_time -= 1);
            }
            for (let t, e = 0, i = this.itemViewDate.length; e < i; e++) {
                if (sys.isObjectValid(this.itemViewDate[e].itemdata) && (t = this.itemViewDate[e].itemdata, ToolUtils.isObjValid(this.itemViewDate[e].item) && this.itemViewDate[e].item.active && (1 == t.mode || 3 == t.mode))) {
                    let i = this.itemViewDate[e].item.getChildByName("time");
                    t.btn_status == this.RegisterButtonStatus.UPCOMING ? t.will_ready_time > 0 && Number(t.will_ready_time) <= 10800 && (i.getComponent(Label).string = ToolUtils.timeStr2(t.will_ready_time, true)) : t.btn_status != this.RegisterButtonStatus.JOINNOW && t.btn_status != this.RegisterButtonStatus.WITHDRAW || t.will_start_time > 0 && Number(t.will_start_time) <= 10800 && (i.getComponent(Label).string = ToolUtils.timeStr2(t.will_start_time, true));
                }
            }
        }
    }
    setMatchRemind(t = 0) {
        let e = 0 == GameConfig.GAME_APP_THEME ? URLConfig.calendar_master_url : URLConfig.calendar_circ_url, i = 0 == GameConfig.GAME_APP_THEME ? CommDefine.AppName_rummy : CommDefine.AppName_circ;
        if (0 == t) {
            let t = ToolUtils.format(i18nMgr.shared().getValueByKey("tournament.register_title"), i, this.remindMatchInfo.race_name, this.remindMatchInfo.time_info), n = ToolUtils.format(i18nMgr.shared().getValueByKey("tournament.register_content"), i, this.remindMatchInfo.race_name, e + "?reg=" + this.remindMatchInfo.raceid), s = AppInfo.shared().setCalendarContract(this.remindMatchInfo.will_ready_time, 300, 0, t, n);
            s.length > 0 && (ToolUtils.saveData("upcoming_" + this.remindMatchInfo.raceid, s), this.saveCurRaceId(this.remindMatchInfo.raceid), Utils.shared().showToast(ToolUtils.format("You will get a reminder when the tournament registration starts at ${0}", this.remindMatchInfo.time_info), 3));
        }
        else {
            let t = ToolUtils.format(i18nMgr.shared().getValueByKey("tournament.start_title"), i, this.remindMatchInfo.race_name, this.remindMatchInfo.time_info), n = ToolUtils.format(i18nMgr.shared().getValueByKey("tournament.start_content"), i, this.remindMatchInfo.race_name, e + "?enter=" + this.remindMatchInfo.raceid), s = AppInfo.shared().setCalendarContract(this.remindMatchInfo.will_start_time, 600, 5, t, n);
            s.length > 0 && (ToolUtils.saveData("start_" + this.remindMatchInfo.raceid, s), this.saveCurRaceId(this.remindMatchInfo.raceid));
        }
    }
    cancelMatchRemind(t) {
        sys.isObjectValid(t.upcoming_remind) && t.upcoming_remind.length > 0 && AppInfo.shared().cancelCalendarContract(t.upcoming_remind);
        sys.localStorage.removeItem("upcoming_" + t.raceid);
        sys.isObjectValid(t.start_remind) && t.start_remind.length > 0 && AppInfo.shared().cancelCalendarContract(t.start_remind);
        sys.localStorage.removeItem("start_" + t.raceid);
    }
    saveCurRaceId(t) {
        if (String(t).length > 0) {
            let e = [], i = localStorage.getItem("RemainRaceData");
            sys.isObjectValid(i) && "" != i ? (e = ToolUtils.parseJson(i), e.includes(t) || e.push(t)) : e.push(t);
            ToolUtils.saveData("RemainRaceData", ToolUtils.toJsonString(e));
        }
    }
    netWorkDelayUpdate() {
        if (this.networkDelay = this.networkDelay + 1, !this.isDisconnectServer && this.networkDelay > 10) {
            let t = { cmd: NetConfig.HEARTBEAT_CMD };
            Server.shared().send(t);
            ToolUtils.lastSendHeartBeatTime = ToolUtils.getOsTime();
            this.networkDelay = 0;
        }
    }
    regEventinit() {
        Server.shared().regDispatch(NetConfig.SYSTEM_GATEWAY_CMD, this.handler_server_login_error.bind(this), this);
        Server.shared().regDispatch(NetConfig.SERVER_LOGIN_GATE_RESP, this.handler_server_login_gate_return.bind(this), this);
        Server.shared().regDispatch(NetConfig.SM_LOGIN_RETURN, this.handler_server_login_Rummy_return.bind(this), this);
        Server.shared().regDispatch(NetConfig.SM_LOGIN_ERR_UC, this.handler_server_sm_login_err.bind(this), this);
        Server.shared().regDispatch(NetConfig.SM_RACE_LIST, this.handler_server_race_list.bind(this), this);
        Server.shared().regDispatch(NetConfig.SM_JOIN_RETRUN, this.handler_server_join_return.bind(this), this);
        Server.shared().regDispatch(NetConfig.SM_JOIN_BC_RETRUN, this.handler_server_join_bc_return.bind(this), this);
        Server.shared().regDispatch(NetConfig.SM_CANCEL_JOIN_RACE_RESPOND, this.handler_server_cancel_join_return.bind(this), this);
        Server.shared().regDispatch(NetConfig.SM_NOTIFY_BTN_STATUS, this.handler_server_notify_btn_status_return.bind(this), this);
        Server.shared().regDispatch(NetConfig.SM_ADD_RACE, this.handler_server_add_race_return.bind(this), this);
        Server.shared().regDispatch(NetConfig.SM_NOTIFY_RACE_DELETE, this.handler_server_notify_race_delete_return.bind(this), this);
        Server.shared().regDispatch(NetConfig.HEARTBEAT_CMD, this.handler_server_heartbeat_return.bind(this), this);
        Server.shared().regDispatch(NetConfig.SM_TRY_JOIN_RACE_BY_TICKET, this.handler_server_try_join_race_by_ticket_return.bind(this), this);
        Server.shared().regDispatch(NetConfig.SM_NOTIFY_REFLUSH_TICKET_LOGO, this.handler_server_notify_reflush_ticket_logo.bind(this), this);
    }
    doConnectRequest() {
        let t = Server.shared().isEnable();
        if (t || (Server.shared().reset(), this.matchInfoList && this.matchInfoList.length > 0 || Utils.shared().showLoading(10, true)), Server.shared().clearEventByTarget(this), this.regEventinit(), Server.shared().setOpenCb((() => {
            User.shared().send_match_login_gate_request();
        })), Server.shared().setReconCb((() => {
            Utils.shared().hideLoading();
        })), t) {
            Server.shared().pop_response();
            User.shared().send_match_login_request();
            User.shared().doSendMatchOnlineStatus(1);
        }
        else {
            let t = URLConfig.orginHttp_tcp, e = User.shared().getSmallPointRoomVid(), i = NetHostManager.shared().chooseBestTcpIpConn(e), n = NetHostManager.shared().chooseBestTcpPortConn(e);
            "-1" != i && -1 != n && (t = 443 == n ? "wss://" + i + ":443" : "ws://" + i + ":" + n);
            Server.shared().createSocket(t);
        }
        this.isDisconnectServer = false;
    }
    send_get_race_list(t) {
        let e = { cmd: NetConfig.GM_GET_RACE_LIST, uid: User.shared().data.uid, skey: User.shared().getSkey(), version: GameConfig.Server_Api_Ver, page: t, session_id: User.shared().session_id, in_hall: 0 };
        Server.shared().send(e);
    }
    handler_server_login_error(t) {
        let e = i18nMgr.shared().getValueByKey("gameRummy_notice_Pop.notice"), i = t.msg;
        Utils.shared().hideLoading();
        1002 == t.code ? Utils.shared().showCommomDialog(i, e, (t => {
            1 == t && this.doConnectRequest();
        }), true, false) : 1001 == t.code ? Utils.shared().showCommomDialog(i, e, (t => {
            localStorage.setItem("logintype", "-1");
            User.shared().loginType = "-1";
            PushCenter.shared().pushEvent(PushEvent.BackToLogin);
        }), false) : (-1 === t.res && (i = i18nMgr.shared().getValueByKey("utlis.service_upgrade")), Utils.shared().showCommomDialog(i, e, (t => {
            ToolUtils.isObjValid(this.node);
        }), false));
    }
    handler_server_login_gate_return(t) {
        if (0 == t.res) {
            User.shared().send_match_login_request();
            this.isDisconnectServer = false;
        }
        else {
            this.hideLoading();
            let e = ToolUtils.isSafeString(t.msg);
            0 === e.length && (e = i18nMgr.shared().getValueByKey("utlis.text4"));
            Utils.shared().showCommomDialog(e, i18nMgr.shared().getValueByKey("gameRummy_notice_Pop.notice"), (t => {
                1 == t && this.doConnectRequest();
            }), true, false);
            2 != t.res && 3 != t.res || (this.isDisconnectServer = true);
        }
    }
    handler_server_login_Rummy_return(t) {
        if (0 == parseInt("" + t.ret)) {
            sys.isObjectValid(t.session_id) && (User.shared().session_id = t.session_id);
            this.curPage = 1;
            this.send_get_race_list(this.curPage);
            User.shared().send_request_hall_tableinfo();
        }
        else if (1002 == parseInt("" + t.code)) {
            let e = i18nMgr.shared().getValueByKey("gameRummy_notice_Pop.notice"), i = t.alertStr || "", n = ToolUtils.isSafeNumber(t.in_vid), s = ToolUtils.isSafeNumber(t.game_type);
            Utils.shared().showCommomDialog(i, e, (t => {
                1 == t && Utils.shared().showLoadTable(n, s);
            }), false);
        }
        else if (1001 == t.code) {
            let e = i18nMgr.shared().getValueByKey("gameRummy_notice_Pop.notice"), i = t.alertStr || "";
            Utils.shared().showCommomDialog(i, e, (t => {
                localStorage.setItem("logintype", "-1");
                User.shared().loginType = "-1";
                PushCenter.shared().pushEvent(PushEvent.BackToLogin);
            }), false);
        }
        else {
            let e = i18nMgr.shared().getValueByKey("gameRummy_notice_Pop.notice"), i = t.alertStr || "", n = t.code;
            Utils.shared().showCommomDialog(i, e, (t => {
                1 == t && 1003 == n && PushCenter.shared().pushEvent(GameConfig.EnterRoom_LackMoney);
            }), false);
        }
        0 == parseInt("" + t.ret) || this.hideLoading();
    }
    handler_server_sm_login_err(t) {
        null != t.alertStr && null != t.alertStr && t.alertStr.length > 0 && Utils.shared().showToast(t.alertStr, 2);
        this.hideLoading();
        Server.shared().reset();
        ToolUtils.isObjValid(this.node);
    }
    handler_server_race_list(t) {
        if (this.hideLoading(), 1 == GameConfig.CHIPS_MODLE) {
            return this.curPage = 1, this.totalPage = 0, User.shared().matchInfoList = this.matchInfoList = [], void this.updateMatchRoomList();
        }
        1 != t.page && this.curPage + 1 != t.page || (this.curPage = t.page, this.totalPage = t.total, 1 == t.page ? (this.matchInfoList = {}, t.race_info && t.race_info.length > 0 && (this.matchInfoList = t.race_info)) : t.race_info && t.race_info.length > 0 && (this.matchInfoList = this.matchInfoList.concat(t.race_info)), User.shared().matchInfoList = this.matchInfoList, t.page < t.total ? this.send_get_race_list(t.page + 1) : (this.updateMatchTime(0), this.updateMatchTime(0), this.updateMatchRoomList()));
    }
    updateMatchRoomList() {
        this.loading.active = false;
        this.sortMatchInfo();
        let t = this.gameSelect[this.lastType].gameStatus, e = this.gameSelect[this.lastType].gameType, i = this.getMatchListByStatusAndType(t, e);
        if (i && i.length > 0) {
            this._itemLen = i.length;
            this.nodata.active = false;
            let t = this.RummyView.getComponent(ScrollView).view, e = 0, n = this.room_moban.getComponent(UITransform).contentSize.height, s = 0;
            for (let t = 0; t < this._itemLen; t++) {
                if (this.itemViewDate[t] && ToolUtils.isObjValid(this.itemViewDate[t].item)) {
                    this.itemViewDate[t].item.setPosition(v3(0, e));
                    this.itemViewDate[t].item.active = true;
                }
                else {
                    let i = instantiate(this.room_moban);
                    i.active = true;
                    i.setPosition(v3(0, e));
                    this.itemViewDate[t] = [];
                    this.itemViewDate[t].item = i;
                    this.content.addChild(i);
                }
                this.itemViewDate[t].itemdata = i[t];
                this.initRummyAdd(this.itemViewDate[t].item, i[t]);
                e += -(n + s);
            }
            for (let t = this._itemLen, e = this.itemViewDate.length; t < e; t++) {
                ToolUtils.isObjValid(this.itemViewDate[t].item) && (this.itemViewDate[t].item.active = false);
            }
            let a = this.content.getComponent(UITransform).contentSize;
            this.content.getComponent(UITransform).setContentSize(size(a.width, n * this._itemLen));
            this._scrollUtil.setScollDetails(n, t.height, i, true);
        }
        else {
            this.content.removeAllChildren();
            this.itemViewDate = [];
            this._itemLen = 0;
            this.nodata.active = true;
        }
    }
    sortMatchInfo() {
        this.matchInfoList && this.matchInfoList.length > 0 && this.matchInfoList.sort((function (t, e) {
            let i = t.times - e.times;
            if (0 !== i) {
                return i;
            }
            let n = 0, s = 0;
            if (sys.isObjectValid(t.ticket_mode) && t.ticket_mode.length > 0) {
                for (let e = 0; e < t.ticket_mode.length; e++) {
                    if (sys.isObjectValid(t.ticket_mode[e].pay_info) && t.ticket_mode[e].pay_info.length > 0) {
                        for (let i = 0; i < t.ticket_mode[e].pay_info.length; i++) {
                            sys.isObjectValid(t.ticket_mode[e].pay_info[i].value) && (n += Number(t.ticket_mode[e].pay_info[i].value));
                        }
                    }
                }
            }
            if (sys.isObjectValid(e.ticket_mode) && e.ticket_mode.length > 0) {
                for (let t = 0; t < e.ticket_mode.length; t++) {
                    if (sys.isObjectValid(e.ticket_mode[t].pay_info) && e.ticket_mode[t].pay_info.length > 0) {
                        for (let i = 0; i < e.ticket_mode[t].pay_info.length; i++) {
                            sys.isObjectValid(e.ticket_mode[t].pay_info[i].value) && (s += Number(e.ticket_mode[t].pay_info[i].value));
                        }
                    }
                }
            }
            let a = n - s;
            return 0 !== a ? a : e.raceid - t.raceid;
        }));
        let t = [];
        if (this.matchInfoList && this.matchInfoList.length > 0) {
            for (let e = 0, i = this.matchInfoList.length; e < i; e++) {
                let i = this.matchInfoList[e].btn_status;
                sys.isObjectValid(this.matchInfoList[e].can_join_times) && sys.isObjectValid(this.matchInfoList[e].entry_times) && this.matchInfoList[e].can_join_times == this.matchInfoList[e].entry_times && sys.isObjectValid(this.matchInfoList[e].mode) && 3 == this.matchInfoList[e].mode && (i = this.RegisterButtonStatus.ELIMINATED);
                null == t[i] && (t[i] = []);
                this.matchInfoList[e].upcoming_remind = sys.localStorage.getItem("upcoming_" + this.matchInfoList[e].raceid);
                this.matchInfoList[e].start_remind = sys.localStorage.getItem("start_" + this.matchInfoList[e].raceid);
                t[i].push(this.matchInfoList[e]);
            }
            this._isOpenCalendar && sys.isObjectValid(t[this.RegisterButtonStatus.UPCOMING]) && t[this.RegisterButtonStatus.UPCOMING].sort((function (t, e) {
                let i = sys.isObjectValid(t.upcoming_remind) && t.upcoming_remind.length > 0 ? 0 : 1;
                return (sys.isObjectValid(e.upcoming_remind) && e.upcoming_remind.length > 0 ? 0 : 1) - i;
            }));
        }
        let e = [], i = [this.RegisterButtonStatus.ENTER, this.RegisterButtonStatus.REJOIN, this.RegisterButtonStatus.EARLY_SEATING, this.RegisterButtonStatus.LATE_JOIN, this.RegisterButtonStatus.JOINNOW, this.RegisterButtonStatus.UPCOMING, this.RegisterButtonStatus.WITHDRAW, this.RegisterButtonStatus.FULL, this.RegisterButtonStatus.ELIMINATED, this.RegisterButtonStatus.RUNNING, this.RegisterButtonStatus.COMPLETED];
        for (let n = 0, s = i.length; n < s; n++) {
            let s = i[n];
            if (t && t[s] && t[s].length > 0) {
                for (let i = 0, n = t[s].length; i < n; i++) {
                    e.push(t[s][i]);
                }
            }
        }
        this.matchInfoList = e;
        User.shared().matchInfoList = this.matchInfoList;
    }
    getMatchListByStatusAndType(t, e) {
        let i = [];
        if (this.matchInfoList && this.matchInfoList.length > 0) {
            let n = [], s = [];
            for (let a = 0, o = this.matchInfoList.length; a < o; a++) {
                let o = this.matchInfoList[a];
                1 == this.lastType ? 1 == o.isjoin && o.btn_status != this.RegisterButtonStatus.UPCOMING && (0 != t && 0 != e ? o.state == t && o.event_type == e && i.push(o) : 0 != t ? o.state == t && i.push(o) : 0 != e ? o.event_type == e && i.push(o) : i.push(o)) : sys.isObjectValid(o.top) && 1 == o.top ? n.push(o) : s.push(o);
            }
            for (let s = 0, a = n.length; s < a; s++) {
                let a = n[s];
                0 != t && 0 != e ? a.state == t && a.event_type == e && i.push(a) : 0 != t ? a.state == t && i.push(a) : 0 != e ? a.event_type == e && i.push(a) : i.push(a);
            }
            for (let n = 0, a = s.length; n < a; n++) {
                let a = s[n];
                0 != t && 0 != e ? a.state == t && a.event_type == e && i.push(a) : 0 != t ? a.state == t && i.push(a) : 0 != e ? a.event_type == e && i.push(a) : i.push(a);
            }
        }
        if (1 == this.lastType && this.histroyList && this.histroyList.length > 0) {
            for (let e = 0, n = this.histroyList.length; e < n; e++) {
                0 != t ? t == this.histroyList[e].status && i.push(this.histroyList[e]) : i.push(this.histroyList[e]);
            }
        }
        return i;
    }
    handler_server_join_return(t) {
        if (this.hideLoading(), 0 == t.ret) {
            let e = t.raceid, i = t.signup_cnt, n = t.btn_status, s = t.mode, a = t.discount;
            this.updateMatchInfoList(e, i, 1, n, null, null, a);
            let o = this.getMatchInfoById(e);
            if (o && this.updateMatchView(e, o), User.shared().updateMoney(t.money), null != t.prop_info && t.prop_info.length > 0) {
                for (let e = 0, i = t.prop_info.length; e < i; e++) {
                    User.shared().setPropNumById(t.prop_info[e].pid, t.prop_info[e].value);
                }
            }
            null != t.money && null != t.money && User.shared().updateMoney(t.money);
            1 == s || 3 == s ? (this.remindMatchInfo = o || {}, sys.isObjectValid(t.is_rejoin) && 1 == Number(t.is_rejoin) || sys.isObjectValid(t.is_late_join) && 1 == Number(t.is_late_join) || this._isOpenCalendar && 1 == AppInfo.shared().getIsCalendarContractAllow() && (this.setMatchRemind(1), this.updateMatchRoomList()), t.tips && t.tips.length > 0 && Utils.shared().showToast(t.tips, 3)) : ToolUtils.isObjValid(this.node.parent) && ToolUtils.isObjValid(this.node.parent.parent) && this.node.parent.parent.destroy();
            let r = { lobby: 1, game: 0, data: null };
            ToolUtils.saveData(User.shared().data.uid + "addRecommendRoomNew", ToolUtils.toJsonString(r));
        }
        else if (0 == t.code) {
            let e = ToolUtils.isSafeNumber(t.min_enter);
            Utils.shared().showQuickRecharge(431, null, true, User.shared().curTid_key, 0, e);
            User.shared().updatePayScene(PhpReportDefined.pay_scene.game_selectroom_less_money, 431);
        }
        else {
            t.msg && Utils.shared().showToast(t.msg, 2);
        }
    }
    updateMatchInfoList(t, e, i, n, s, a, o, r) {
        if (this.matchInfoList && this.matchInfoList.length > 0) {
            for (let h = 0, l = this.matchInfoList.length; h < l; h++) {
                if (this.matchInfoList[h].raceid == t) {
                    if (null != e && (this.matchInfoList[h].num = e), null != i && (this.matchInfoList[h].isjoin = i), s && (this.matchInfoList[h].reward_value = s), a && (this.matchInfoList[h].time_info = a), r && (this.matchInfoList[h].running_entry = r), null != n) {
                        this.matchInfoList[h].btn_status = n;
                        n == this.RegisterButtonStatus.UPCOMING ? this.matchInfoList[h].state = 5 : n == this.RegisterButtonStatus.JOINNOW || n == this.RegisterButtonStatus.WITHDRAW || n == this.RegisterButtonStatus.FULL ? this.matchInfoList[h].state = 1 : n == this.RegisterButtonStatus.ENTER || n == this.RegisterButtonStatus.ELIMINATED || n == this.RegisterButtonStatus.RUNNING ? this.matchInfoList[h].state = 3 : this.matchInfoList[h].state = 4;
                        0 != this.gameSelect[this.lastType].gameStatus && this.updateMatchRoomList();
                    }
                    this.matchInfoList[h].discount = o;
                    break;
                }
            }
        }
    }
    getMatchInfoById(t) {
        if (this.matchInfoList && this.matchInfoList.length > 0) {
            for (let e = 0, i = this.matchInfoList.length; e < i; e++) {
                if (this.matchInfoList[e].raceid == t) {
                    return this.matchInfoList[e];
                }
            }
        }
        return null;
    }
    updateMatchView(t, e) {
        let i = this.gameSelect[this.lastType].gameStatus, n = this.gameSelect[this.lastType].gameType, s = this.getMatchListByStatusAndType(i, n);
        if (s && s.length > 0) {
            for (let i = 0, n = s.length; i < n; i++) {
                s[i].raceid == t && this.itemViewDate[i] && ToolUtils.isObjValid(this.itemViewDate[i].item) && this.initRummyAdd(this.itemViewDate[i].item, e);
            }
        }
    }
    handler_server_join_bc_return(t) {
        let e = t.raceid, i = t.signup_cnt, n = t.reward_value, s = t.btn_status, a = t.discount;
        this.updateMatchInfoList(e, i, null, s, n, null, a);
        let o = this.getMatchInfoById(e);
        o && this.updateMatchView(e, o);
    }
    handler_server_cancel_join_return(t) {
        if (0 == t.ret) {
            let e = t.raceid, i = t.signup_cnt, n = t.btn_status;
            sys.isObjectValid(n) || (n = this.RegisterButtonStatus.JOINNOW);
            let s = t.discount;
            if (this.updateMatchInfoList(e, i, 0, n, null, null, s), 1 == this.lastType) {
                this.updateMatchRoomList();
            }
            else {
                let t = this.getMatchInfoById(e);
                t && this.updateMatchView(e, t);
            }
            if (User.shared().updateMoney(t.money), null != t.prop_info && t.prop_info.length > 0) {
                for (let e = 0, i = t.prop_info.length; e < i; e++) {
                    User.shared().setPropNumById(t.prop_info[e].pid, t.prop_info[e].value);
                }
            }
            if (null != t.money && null != t.money && User.shared().updateMoney(t.money), this._isOpenCalendar) {
                let t = {};
                t.raceid = e;
                t.upcoming_remind = sys.localStorage.getItem("upcoming_" + e);
                t.start_remind = sys.localStorage.getItem("start_" + e);
                this.cancelMatchRemind(t);
            }
        }
        else {
            t.msg && Utils.shared().showToast(t.msg, 2);
        }
    }
    handler_server_notify_btn_status_return(t) {
        let e = t.raceid, i = t.btn_status, n = t.time_info, s = t.discount, a = t.running_entry;
        this.updateMatchInfoList(e, null, null, i, null, n, s, a);
        let o = this.getMatchInfoById(e);
        o && this.updateMatchView(e, o);
    }
    handler_server_add_race_return(t) {
        if (1 == GameConfig.CHIPS_MODLE) {
            return User.shared().matchInfoList = this.matchInfoList = [], void this.updateMatchRoomList();
        }
        let e = t.race_info;
        if (this.matchInfoList && this.matchInfoList.length > 0) {
            null == this.getMatchInfoIndexById(e.raceid) && this.matchInfoList.splice(0, 0, e);
        }
        else {
            this.matchInfoList = [];
            this.matchInfoList.push(e);
        }
        User.shared().matchInfoList = this.matchInfoList;
        this.updateMatchTime(0);
        this.updateMatchTime(0);
        this.updateMatchRoomList();
    }
    handler_server_notify_race_delete_return(t) {
        let e = t.raceid, i = this.getMatchInfoIndexById(e);
        null != i && this.matchInfoList.splice(i, 1);
        this.updateMatchRoomList();
    }
    getMatchInfoIndexById(t) {
        if (this.matchInfoList && this.matchInfoList.length > 0) {
            for (let e = 0, i = this.matchInfoList.length; e < i; e++) {
                if (this.matchInfoList[e].raceid == t) {
                    return e;
                }
            }
        }
        return null;
    }
    handler_server_heartbeat_return(t) {
        this.isDisconnectServer = false;
    }
    initRummyAdd(t, e) {
        t.active = true;
        let i = t.getChildByName("title"), n = t.getChildByName("title_time"), s = t.getChildByName("time"), o = (t.getChildByName("icon"), t.getChildByName("reward")), r = t.getChildByName("progress"), h = t.getChildByName("join"), l = t.getChildByName("status_btn"), d = l.getChildByName("layout").getChildByName("flag"), u = l.getChildByName("layout").getChildByName("wz"), _ = (t.getChildByName("bg"), t.getChildByName("entry").getChildByName("wz"));
        i.getComponent(Label).string = e.race_name;
        e.btn_status == this.RegisterButtonStatus.UPCOMING ? i18nMgr.shared().changeLabelLanguage(n.getComponent(Label), "match_info.regist_at") : i18nMgr.shared().changeLabelLanguage(n.getComponent(Label), "match_info.starts_at");
        1 == e.mode || 3 == e.mode ? e.btn_status == this.RegisterButtonStatus.UPCOMING && Number(e.will_ready_time) > 0 && Number(e.will_ready_time) <= 10800 ? (s.getComponent(Label).string = ToolUtils.timeStr2(e.will_ready_time, true), i18nMgr.shared().changeLabelLanguage(n.getComponent(Label), "match_info.regist_in")) : (e.btn_status == this.RegisterButtonStatus.JOINNOW || e.btn_status == this.RegisterButtonStatus.WITHDRAW) && Number(e.will_start_time) > 0 && Number(e.will_start_time) <= 10800 ? (s.getComponent(Label).string = ToolUtils.timeStr2(e.will_start_time, true), i18nMgr.shared().changeLabelLanguage(n.getComponent(Label), "match_info.starts_in")) : s.getComponent(Label).string = e.time_info : s.getComponent(Label).string = i18nMgr.shared().getValueByKey("tournament.start_full");
        let g = "" + ToolUtils.parse_double(e.reward_value, 0);
        if (sys.isObjectValid(e.mixed) && 1 == e.mixed && (g += "*"), o.getComponent(Label).string = ToolUtils.format("Reward: Rs ₹${0}", g), 3 == e.mode ? sys.isObjectValid(e.can_join_times) && sys.isObjectValid(e.entry_times) && i18nMgr.shared().changeLabelLanguage(h.getComponent(Label), "tournament.entry_times", false, e.can_join_times, e.entry_times) : h.getComponent(Label).string = ToolUtils.format("${0} Joined", e.num), 3 == e.mode ? r.active = false : (r.active = true, r.getComponent(ProgressBar).progress = e.num / e.total_num), e.btn_status != this.RegisterButtonStatus.REJOIN && e.btn_status != this.RegisterButtonStatus.LATE_JOIN || !sys.isObjectValid(e.running_entry)) {
            let t = "", i = 0;
            if (e.ticket_mode && e.ticket_mode.length > 0) {
                for (let n = 0, s = e.ticket_mode.length; n < s; n++) {
                    if (e.ticket_mode[n].pay_info && e.ticket_mode[n].pay_info.length > 0) {
                        for (let s = 0, a = e.ticket_mode[n].pay_info.length; s < a; s++) {
                            0 == e.ticket_mode[n].pay_info[s].type ? (t = ToolUtils.format("${0}₹${1}", t, e.ticket_mode[n].pay_info[s].value), i += e.ticket_mode[n].pay_info[s].value) : 1 == e.ticket_mode[n].pay_info[s].type && (t += i18nMgr.shared().getValueByKey("tournament.ticket"));
                            s != a - 1 && (t = ToolUtils.format("${0}&&", t));
                        }
                    }
                    n != s - 1 && (t = ToolUtils.format("${0}/", t));
                }
            }
            else {
                t = i18nMgr.shared().getValueByKey("tournament.free");
            }
            _.getComponent(Label).string = t;
        }
        else {
            let t = "Free";
            Number(e.running_entry) > 0 && (t = ToolUtils.format("₹${0}", e.running_entry));
            _.getComponent(Label).string = t;
        }
        let p = this.matchBtnStatus[e.btn_status];
        this._isOpenCalendar ? d.active = e.btn_status == this.RegisterButtonStatus.UPCOMING : d.active = false;
        e.btn_status == this.RegisterButtonStatus.UPCOMING ? (l.getComponent(Button).interactable = true, l.getComponent(Button).normalSprite = this.btnStateFrame[2], this._isOpenCalendar ? sys.isObjectValid(e.upcoming_remind) && ToolUtils.isSafeString(e.upcoming_remind).length > 0 ? (p = "tournament.upcoming5", d.getComponent(Sprite).spriteFrame = this.remindFlagFrame[1], l.getComponent(Sprite).color = color(139, 198, 142), u.getComponent(Label).color = color(70, 153, 72), d.getComponent(Sprite).color = color(70, 153, 72)) : (p = "tournament.upcoming4", d.getComponent(Sprite).spriteFrame = this.remindFlagFrame[0], l.getComponent(Sprite).color = color(220, 220, 220), u.getComponent(Label).color = color(69, 69, 69), d.getComponent(Sprite).color = color(69, 69, 69)) : (l.getComponent(Sprite).color = color(220, 220, 220), u.getComponent(Label).color = color(69, 69, 69), 3 == e.mode && (p = "tournament.upcoming"))) : e.btn_status == this.RegisterButtonStatus.JOINNOW ? (l.getComponent(Button).interactable = true, l.getComponent(Button).normalSprite = this.btnStateFrame[1], l.getComponent(Sprite).color = color(255, 255, 255), u.getComponent(Label).color = color(255, 255, 255), 3 == e.mode && (p = "tournament.join_now")) : e.btn_status == this.RegisterButtonStatus.WITHDRAW ? (l.getComponent(Button).interactable = true, l.getComponent(Button).normalSprite = this.btnStateFrame[2], l.getComponent(Sprite).color = color(220, 220, 220), u.getComponent(Label).color = color(69, 69, 69), 3 == e.mode && (p = "tournament.withdraw")) : e.btn_status == this.RegisterButtonStatus.FULL ? (l.getComponent(Button).interactable = true, l.getComponent(Button).normalSprite = this.btnStateFrame[2], l.getComponent(Sprite).color = color(220, 220, 220), u.getComponent(Label).color = color(69, 69, 69), 3 == e.mode && (p = "tournament.full")) : e.btn_status == this.RegisterButtonStatus.ENTER ? 3 == e.mode ? (l.getComponent(Button).interactable = true, p = "tournament.enter", l.getComponent(Button).normalSprite = this.btnStateFrame[0], l.getComponent(Sprite).color = color(255, 255, 255), u.getComponent(Label).color = color(255, 255, 255)) : (l.getComponent(Button).interactable = false, p = "tournament.running", l.getComponent(Button).normalSprite = this.btnStateFrame[3], l.getComponent(Sprite).color = color(255, 255, 255), u.getComponent(Label).color = color(70, 153, 75)) : e.btn_status == this.RegisterButtonStatus.ELIMINATED ? 3 == e.mode ? (l.getComponent(Button).interactable = true, p = "tournament.join_now", l.getComponent(Button).normalSprite = this.btnStateFrame[1], l.getComponent(Sprite).color = color(255, 255, 255), u.getComponent(Label).color = color(255, 255, 255)) : (l.getComponent(Button).interactable = false, p = "tournament.eliminated2", l.getComponent(Button).normalSprite = this.btnStateFrame[4], l.getComponent(Sprite).color = color(240, 240, 240), u.getComponent(Label).color = color(207, 65, 65)) : e.btn_status == this.RegisterButtonStatus.RUNNING ? (l.getComponent(Button).interactable = false, p = "tournament.running", l.getComponent(Button).normalSprite = this.btnStateFrame[3], l.getComponent(Sprite).color = color(255, 255, 255), u.getComponent(Label).color = color(70, 153, 75)) : e.btn_status == this.RegisterButtonStatus.REJOIN ? (l.getComponent(Button).interactable = true, p = "tournament.rejoin2", l.getComponent(Button).normalSprite = this.btnStateFrame[1], l.getComponent(Sprite).color = color(255, 255, 255), u.getComponent(Label).color = color(255, 255, 255)) : e.btn_status == this.RegisterButtonStatus.LATE_JOIN ? (l.getComponent(Button).interactable = true, l.getComponent(Button).normalSprite = this.btnStateFrame[1], l.getComponent(Sprite).color = color(255, 255, 255), u.getComponent(Label).color = color(255, 255, 255)) : e.btn_status == this.RegisterButtonStatus.EARLY_SEATING ? (l.getComponent(Button).interactable = true, l.getComponent(Button).normalSprite = this.btnStateFrame[0], l.getComponent(Sprite).color = color(255, 255, 255), u.getComponent(Label).color = color(255, 255, 255)) : (l.getComponent(Button).interactable = false, l.getComponent(Button).normalSprite = this.btnStateFrame[2], l.getComponent(Sprite).color = color(138, 190, 142), u.getComponent(Label).color = color(70, 153, 72), p = "tournament.viewWinner2");
        u.getComponent(Label).string = ToolUtils.format("${0}", i18nMgr.shared().getValueByKey(p));
        let I = ToolUtils.isSafeNumber(e.isphp), C = { raceid: e.raceid, race_name: e.race_name, status: e.btn_status, payinfo: e.ticket_mode, isphp: I, mode: e.mode, time_info: e.time_info, upcoming_remind: e.upcoming_remind, will_ready_time: e.will_ready_time, will_start_time: e.will_start_time };
        l.getComponent(Button).clickEvents[0].customEventData = ToolUtils.toJsonString(C);
    }
    update(t) {
    }
    onSwitchGameTypeClick(t, e) {
        if (SoundManager.shared().playFx("click"), Number(e) != this.lastType) {
            if (this.refreshSwitchTab(Number(e)), this.lastType = Number(e), 1 == this.lastType) {
                let t = this.gameSelect[this.lastType].gameStatus, e = this.gameSelect[this.lastType].gameType, i = this.getMatchListByStatusAndType(t, e);
                i && i.length > 0 ? (this.nodata.active = false, this._scrollUtil && this.updateMatchRoomList()) : Utils.shared().showLoading(10, true);
                HttpManager.shared().doGetMatchHistory(this.listenMatchHistoryCallback.bind(this));
            }
            else {
                this.updateMatchRoomList();
            }
        }
    }
    listenMatchHistoryCallback(t, e, i) {
        if (Utils.shared().hideLoading(), ToolUtils.isObjValid(this.node)) {
            if (200 != i) {
                Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text29"), 2);
            }
            else {
                try {
                    let t = ToolUtils.parseJson(e);
                    0 == t.ret && ToolUtils.isObjValid(this.node) && (this.histroyList = t.data, this.updateMatchRoomList());
                }
                catch (t) {
                    TLog.printError("listenMatchHistoryCallback err:", t);
                }
            }
        }
    }
    refreshSwitchTab(t) {
        for (let e = 0, i = this.switchBtn.length; e < i; e++) {
            let i = this.switchBtn[e], n = i.getChildByName("wz"), s = i.getChildByName("di");
            e == t ? (i.getComponent(Button).interactable = false, n.getComponent(Label).color = this.tab_select_color, s.getComponent(Sprite).spriteFrame = this.filitBtnFrame[0]) : (i.getComponent(Button).interactable = true, n.getComponent(Label).color = this.tab_noselect_color, s.getComponent(Sprite).spriteFrame = this.filitBtnFrame[1]);
        }
    }
    onMobanBtnClick(t, e) {
        if (SoundManager.shared().playFx("click"), sys.now() - this._lastClick < 500) {
            return;
        }
        if (this._lastClick = sys.now(), 1 == Utils.shared().showFastKyc()) {
            return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("kyc.kyc_match"), 2);
        }
        let i = Utils.shared().judgeMatchRoomUnlock();
        if (i && !i.openBol) {
            return void (sys.isObjectValid(User.shared()) && Utils.shared().showRoomUnlockToast(1, i.num));
        }
        let n = ToolUtils.parseJson(e);
        if (n.status == this.RegisterButtonStatus.JOINNOW || n.status == this.RegisterButtonStatus.REJOIN || n.status == this.RegisterButtonStatus.LATE_JOIN) {
            let t = 0, e = 0, i = n.payinfo;
            if (i && i.length > 1) {
                for (let n = 0, s = i.length; n < s; n++) {
                    0 == i[n].pay_type ? (t = i[n].pay_info[0].value, i[n].pay_type) : 1 == i[n].pay_type && (e = i[n].pay_info[0].value, i[n].pay_type);
                }
                let s = "", a = false, o = i18nMgr.shared().getValueByKey("match_info.register"), r = "", h = User.shared().getPropNumById(100001);
                if (0 != t && 0 != e && e <= h) {
                    if (s = ToolUtils.format(i18nMgr.shared().getValueByKey("utlis.text8"), t, e), a = true, o = i18nMgr.shared().getValueByKey("utlis.cash"), r = i18nMgr.shared().getValueByKey("menu.ticket"), "" != s) {
                        let t = i18nMgr.shared().getValueByKey("gameRummy_notice_Pop.notice");
                        Utils.shared().showCommomDialog(s, t, (t => {
                            (1 == t || 3 == t) && User.shared().send_try_join_race_by_ticket(n.raceid, null);
                        }), a, false, o, r);
                        Utils.shared().setCommomDialogBtnText(o, r);
                    }
                }
                else {
                    0 != t ? (s = ToolUtils.format(i18nMgr.shared().getValueByKey("utlis.text9"), t), User.shared().send_try_join_race_by_ticket(n.raceid, null)) : (s = ToolUtils.format(i18nMgr.shared().getValueByKey("utlis.text10"), e), User.shared().send_try_join_race_by_ticket(n.raceid, null));
                }
            }
            else if (i && i.length > 0) {
                for (let n = 0, s = i[0].pay_info.length; n < s; n++) {
                    0 == i[0].pay_info[n].type ? t = i[0].pay_info[n].value : e = i[0].pay_info[n].value;
                }
                User.shared().send_try_join_race_by_ticket(n.raceid, null);
            }
            else {
                User.shared().send_try_join_race_by_ticket(n.raceid, null);
            }
        }
        else if (n.status == this.RegisterButtonStatus.WITHDRAW) {
            let t = this, e = { bLandscape: ToolUtils.getIsNormalDirection(), bWithCancel: true, strContent: i18nMgr.shared().getValueByKey("utlis.text11"), strTitle: i18nMgr.shared().getValueByKey("gameRummy_notice_Pop.notice"), sureKey: "rummy_switch.okay", cancelKey: "rummy_switch.cancel" };
            Utils.shared().showCommonAlert(e, (e => {
                1 == e && t.send_race_cancel_join_request(n.raceid);
            }), true);
        }
        else {
            n.status == this.RegisterButtonStatus.ENTER || n.status == this.RegisterButtonStatus.EARLY_SEATING ? Utils.shared().showLoadTable(430, HowToPlayDefined.gameId_RaceRummy, null, null, null, null, n.raceid, 1) : this._isOpenCalendar && n.status == this.RegisterButtonStatus.UPCOMING && (sys.isObjectValid(n.upcoming_remind) && ToolUtils.isSafeString(n.upcoming_remind).length > 0 ? Utils.shared().showMatchAlertView(9, { parentNode: director.getScene().getChildByName("Canvas"), strContent: n.race_name, strTime: n.time_info }) : (this.remindMatchInfo = n, 1 == AppInfo.shared().getIsCalendarContractAllow() ? (this.setMatchRemind(), this.updateMatchRoomList()) : Utils.shared().showMatchAlertView(8, { parentNode: director.getScene().getChildByName("Canvas"), strContent: n.race_name, strFunc: "remind_next", strTime: n.time_info, callfun: (t = "") => {
                    "remind_next" == t && ToolUtils.isObjValid(this.node) && (1 == AppInfo.shared().getIsCalendarContractAllow() ? (this.setMatchRemind(), this.updateMatchRoomList()) : AppInfo.shared().requestCalendarContractAllow());
                } })));
        }
    }
    send_get_race_detaild_request(t) {
        let e = { cmd: NetConfig.GM_GET_RACE_DETAILD_REQUEST, uid: User.shared().data.uid, skey: User.shared().getSkey(), version: GameConfig.Server_Api_Ver, raceid: t, session_id: User.shared().session_id, in_hall: 0 };
        Server.shared().send(e);
    }
    send_race_rejoin_request(t, e) {
        let i = { cmd: NetConfig.GM_RACE_REJOIN_REQUEST, uid: User.shared().data.uid, skey: User.shared().getSkey(), version: GameConfig.Server_Api_Ver, raceid: t, pay_type: e, isNewTable: 1, from: 1, session_id: User.shared().session_id, in_hall: 0 };
        Server.shared().send(i);
    }
    send_race_cancel_join_request(t) {
        let e = { cmd: NetConfig.GM_CANCEL_JOIN_RACE_REQUEST, uid: User.shared().data.uid, skey: User.shared().getSkey(), version: GameConfig.Server_Api_Ver, raceid: t, session_id: User.shared().session_id };
        Server.shared().send(e);
    }
    onDestroy() {
        PushCenter.shared().removeListenersByTag(this);
        Server.shared().clearEventByTarget(this);
        User.shared().doSendMatchOnlineStatus(0);
        TweenTool.stopNodeAction(this.time_node);
    }
    showLoading(t = 0, e = null, i = 0) {
        0 == i && (this.loading.active = true);
        null == this.loadingAction && (this.delayAction = TweenTool.delayAct(this.node, (() => {
            this.loading.active = true;
            let t = this.loading.getChildByName("img");
            TweenTool.stopNodeAction(t);
            this.loading.getChildByName("label").getComponent(Label).string = i18nMgr.shared().getValueByKey("login.loading") + "...";
            let e = TweenTool.rotateBy(t, 0.2, new Vec3(0, 0, -90), "fade", false), i = TweenTool.rotateBy(t, 0.2, new Vec3(0, 0, -90), "fade", false), n = TweenTool.rotateBy(t, 0.2, new Vec3(0, 0, -90), "fade", false), s = TweenTool.rotateBy(t, 0.2, new Vec3(0, 0, -90), "fade", false);
            this.loadingAction && (TweenTool.stopAction(this.loadingAction), this.loadingAction = null);
            this.loadingAction = TweenTool.sequence(t, false, null, e, i, n, s);
            this.loadingAction.repeatForever();
            this.loadingAction.start();
        }), i, true));
        this.loadingDelayAction && (TweenTool.stopAction(this.loadingDelayAction), this.loadingDelayAction = null);
        t > 0 && (this.loadingDelayAction = TweenTool.delayAct(this.node, (() => {
            ToolUtils.isObjValid(this.node) && (e && e(), this.hideLoading());
        }), t, true));
    }
    hideLoading() {
        this.loadingDelayAction && (TweenTool.stopAction(this.loadingDelayAction), this.loadingDelayAction = null);
        this.delayAction && (TweenTool.stopAction(this.delayAction), this.delayAction = null);
        this.loading.active = false;
        Utils.shared().hideLoading();
    }
    playRoomInfoAnim() {
        if (!this.RummyView.getComponent(ScrollView).isScrolling()) {
            let t = 0.08, e = 0;
            if (this.itemViewDate && this.itemViewDate.length > 0 && this._itemLen > 0) {
                for (let i = 0; i < this._itemLen; i++) {
                    let n = this.itemViewDate[i].item;
                    if (ToolUtils.isObjValid(n) && n.active) {
                        let i = new Vec3;
                        TweenTool.stopNodeAction(n);
                        n.getPosition(i);
                        n.setPosition(v3(i.x, i.y - 40));
                        let s = TweenTool.moveTo(n, 0.16, i, "sineIn", false), a = TweenTool.delayAct(n, null, e, false);
                        TweenTool.sequence(n, true, null, a, s);
                        e += t;
                    }
                }
            }
        }
    }
    handler_server_try_join_race_by_ticket_return(t) {
        let e = t.ret;
        if (0 == e) {
            Utils.shared().showRoomTicketSelectView({ data: t, parent_node: director.getScene().getChildByName("Canvas") });
        }
        else if (1 == e) {
            if (sys.isObjectValid(t.err_code) && 1 == t.err_code) {
                let e = ToolUtils.isSafeNumber(t.entry_fee);
                Utils.shared().showQuickRecharge(431, null, true, User.shared().curTid_key, 0, e);
                User.shared().updatePayScene(PhpReportDefined.pay_scene.game_selectroom_less_money, 431);
            }
            else {
                sys.isObjectValid(t.raceid) && this.send_race_rejoin_request(t.raceid, null);
            }
        }
    }
    handler_server_notify_reflush_ticket_logo(t) {
        let e = false, i = 0;
        for (let n = 0, s = this.matchInfoList.length; n < s; n++) {
            let s = this.matchInfoList[n];
            if (e = false, sys.isObjectValid(t.tk_discount)) {
                for (let n = 0; n < t.tk_discount.length; n++) {
                    let a = t.tk_discount[n];
                    if (sys.isObjectValid(a) && a.raceid == s.raceid) {
                        e = true;
                        i = n;
                        break;
                    }
                }
            }
            s.discount = e ? t.tk_discount[i].discount : 0;
        }
        this.updateMatchRoomList();
    }
}
