// @ts-nocheck
// Recovered from index.js:419
import { _decorator, Button, color, director, instantiate, Label, Node, ProgressBar, size, Slider, Sprite, SpriteFrame, sys, UIOpacity, UITransform, v3, Vec3, view } from "cc";
import PushCenter from "./PushCenter";
import TweenTool from "./TweenTool";
import Utils from "./Utils";
import GameConfig from "./GameConfig";
import PhpReportDefined from "./PhpReportDefined";
import User from "./User";
import HttpManager from "./HttpManager";
import SoundManager from "./SoundManager";
import BaseLayer from "./BaseLayer";
import i18nMgr from "./i18nMgr";
import { ToolUtils } from "./ToolUtils";
import CommDefine, { CheckModule, PointsType } from "./CommDefine";
import HowToPlayDefined from "./HowToPlayDefined";
import PushEvent from "./PushEvent";
import ReportConfig from "./ReportConfig";
import { RummyAddGameList } from "./RummyAddGameList";
const { ccclass, property } = _decorator;
@ccclass("RummyAddRoom")
export default class RummyAddRoom extends BaseLayer {
    public TAG: string = "RummyAddRoom";
    @property(Node)
    public root: Node = null;
    @property(Node)
    public gameTypeNode: Node = null;
    @property([Node])
    public gameTypeTabs: Node[] = [];
    @property(Node)
    public chipsGameTypeNode: Node = null;
    @property([Node])
    public chipsGameTypeTabs: Node[] = [];
    @property(Node)
    public rummyTypeNode: Node = null;
    @property(Node)
    public modeHelpBtn: Node = null;
    @property([Node])
    public rummyTypeTabs: Node[] = [];
    @property([SpriteFrame])
    public rankStarFrame: SpriteFrame[] = [];
    @property(Node)
    public roomInfoNode: Node = null;
    @property(Node)
    public tournamentNode: Node = null;
    @property(Label)
    public selectPlayerLabel2: Label = null;
    @property(Node)
    public flagNew1Node: Node = null;
    @property(Node)
    public flagNew2Node: Node = null;
    @property(Node)
    public sliderStarNode: Node = null;
    @property(Node)
    public playnowStarNode: Node = null;
    @property(Node)
    public addCashStarNode: Node = null;
    @property(Node)
    public chip_infoNode: Node = null;
    @property(Node)
    public chip_help: Node = null;
    @property([SpriteFrame])
    public tabCashImages: SpriteFrame[] = [];
    @property([SpriteFrame])
    public tabTourneysImages: SpriteFrame[] = [];
    @property([SpriteFrame])
    public tabChipsImages: SpriteFrame[] = [];
    @property([SpriteFrame])
    public tabPrivateImages: SpriteFrame[] = [];
    @property([SpriteFrame])
    public tabSelectImages: SpriteFrame[] = [];
    @property([SpriteFrame])
    public tabUnSelectImages: SpriteFrame[] = [];
    @property([SpriteFrame])
    public flagDiImages: SpriteFrame[] = [];
    @property([SpriteFrame])
    public switchSelectImages: SpriteFrame[] = [];
    public _close_cb: any = null;
    public _cb: any = null;
    public Issports: boolean = false;
    public gameType: number = 0;
    public rummyType: number = 0;
    public vCurRoomList: any[] = [];
    public selectPlayers: number = 2;
    public selectMode: number = 1;
    public selectPool: number = 101;
    public selectDeals: number = 2;
    public nIdx: number = 0;
    public cur_vid: number = 0;
    public rankNode: any = null;
    public _min_entry: number = 0;
    public bestIndex: number = 0;
    public lastIndex: number = 0;
    public isPlaySwitchAction: boolean = true;
    public hasMatch: boolean = true;
    public _changeSliderByPlayer: boolean = false;
    public _lastClick: number = 0;
    public rummytype_select_color: any = color(147, 11, 11, 255);
    public btn_noselect_color: any = color(0, 0, 0);
    onLoad() {
        let e = this.node.getChildByName("btn_mask").getComponent(UITransform), t = view.getVisibleSize();
        this.setLandscapeShow();
        ToolUtils.showFullScreen(this.node.getChildByName("btn_close"));
        ToolUtils.getOrientation() ? e.setContentSize(size(t.width, t.height)) : e.setContentSize(size(t.height, t.width));
        PushCenter.shared().addListener(GameConfig.Update_Money, (e => {
            this.updateStartBtnState();
        }), this);
        PushCenter.shared().addListener(GameConfig.Close_Rummy_addGame, (e => {
            ToolUtils.isObjValid(this.node) && this.node.destroy();
        }), this);
        PushCenter.shared().addListener(PushEvent.EasyGameShowNewFlag, (e => {
            ToolUtils.isObjValid(this.node) && this.showPointsNewflag();
        }), this);
        PushCenter.shared().addListener(PushEvent.MultipleGameShowNewFlag, (e => {
            ToolUtils.isObjValid(this.node);
        }), this);
        PushCenter.shared().addListener(PushEvent.RefreshHallChooseGameRankStar, (e => {
            ToolUtils.isObjValid(this.node) && this.refreshRankStar();
        }), this);
        PushCenter.shared().addListener(PushEvent.UpdatePractiseGold, (e => {
            if (ToolUtils.isObjValid(this.node)) {
                this.updateChip();
                this.updateStartBtnState();
                let e = sys.localStorage.getItem(User.shared().data.uid + "recommendRoom" + this.gameType + this.rummyType), t = null;
                if (e) {
                    let i = ToolUtils.parseJson(e), s = this.selectPlayers;
                    if (this.rummyType == HowToPlayDefined.RUMMY_POINTS && this.selectMode == PointsType.Easy && 2 != s && (s = 4), 1 != this.gameType && i.data.player == s) {
                        let e = ToolUtils.getRecommendRoom(i);
                        (this.rummyType == HowToPlayDefined.RUMMY_POINTS || this.rummyType == HowToPlayDefined.RUMMY_MULTIPLE || this.rummyType == HowToPlayDefined.RUMMY_BUMP || this.rummyType == HowToPlayDefined.RUMMY_POOL && i.data.pool_game == this.selectPool || this.rummyType == HowToPlayDefined.RUMMY_DEALS && i.data.deals == this.selectDeals) && (t = e.enterMoney);
                    }
                    User.shared().isLoginHall && sys.isObjectValid(User.shared().data.daily_login_cnt) && 1 == User.shared().data.daily_login_cnt && (t = null);
                }
                3 == this.gameType && (this._changeSliderByPlayer || this.getSelectRoomList(this.selectPlayers, this.selectPool, this.selectDeals, t));
            }
        }), this);
        this.updateChip();
        this.fitLuckyTheme();
        this.chipsGameTypeNode.active = 1 == GameConfig.CHIPS_MODLE;
        this.gameTypeNode.active = 0 == GameConfig.CHIPS_MODLE;
    }
    fitLuckyTheme() {
        if (0 == GameConfig.NATIVE_GAME_APP_TYPE) {
            return;
        }
        this.btn_noselect_color = color(80, 89, 130);
        this.rummytype_select_color = color(221, 3, 3, 255);
        let e = this.node.getChildByName("root").getChildByName("rummy_switch");
        e.getChildByName("bg").getComponent(Sprite).color = color(250, 250, 250, 255);
        e.getChildByName("bth_points").getChildByName("line").getComponent(Sprite).color = color(221, 3, 3, 255);
        e.getChildByName("btn_pool").getChildByName("line").getComponent(Sprite).color = color(221, 3, 3, 255);
        e.getChildByName("btn_deals").getChildByName("line").getComponent(Sprite).color = color(221, 3, 3, 255);
        let t = this.roomInfoNode.getChildByName("entry_info");
        t.getChildByName("entry").getChildByName("fee").getComponent(Label).color = color(222, 3, 3, 255);
        t.getChildByName("points").getChildByName("value").getComponent(Label).color = color(222, 3, 3, 255);
        t.getChildByName("feeNode").getChildByName("fee").getComponent(Label).color = color(222, 3, 3, 255);
    }
    start() {
        super.start();
        ToolUtils.showFullScreen(this.node.getChildByName("mask"));
        ToolUtils.showFullScreen(this.node.getChildByName("btn_mask"));
        this.startShowAnim(this.root, (() => {
        }));
        this.reFreshGameTabs();
    }
    reFreshGameTabs() {
        0 == User.shared().temp_pingbi.matchshow ? (this.hasMatch = true, this.gameTypeTabs[1].active = true, this.chipsGameTypeTabs[1].active = true) : (this.hasMatch = false, this.gameTypeTabs[1].active = false, this.chipsGameTypeTabs[1].active = false);
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().removeListenersByTag(this);
    }
    initRummyAdd(e, t) {
    }
    initGameData(e, t, i = false) {
        if (i) {
            let e = 1;
            this.isPlaySwitchAction = true;
            this._changeSliderByPlayer = false;
            this.updateGameType(e, true);
            this.tournamentNode && this.tournamentNode.getComponent(RummyAddGameList).playRoomInfoAnim();
        }
        else {
            let e = sys.localStorage.getItem(User.shared().data.uid + "addRecommendRoomNew");
            if (sys.isObjectValid(e)) {
                let t = ToolUtils.parseJson(e);
                sys.isObjectValid(t) && 3 == Number(t.lobby) && (e = null);
            }
            else {
                e = sys.localStorage.getItem(User.shared().data.uid + "recommendRoomNew");
            }
            let t = null;
            if (sys.isObjectValid(e)) {
                let i = ToolUtils.parseJson(e);
                if (sys.isObjectValid(i) && sys.isObjectValid(i.lobby)) {
                    let e = User.shared().getCurModeVec(Number(i.lobby));
                    t = ToolUtils.getRecommendRoom(i, e);
                }
            }
            1 == GameConfig.CHIPS_MODLE ? t && 3 == t.gameType && sys.isObjectValid(t.playersIndex) ? this.setInitGameType(3, t.rummyType, t.playersIndex, t.poolIndex, t.dealsIndex, false, t.enterMoney, t.modeIndex) : this.setInitGameType(3, 0, 0, 0, 0, false) : User.shared().isCanPlayCashGame() ? !t || 1 == t.gameType && 1 == User.shared().temp_pingbi.matchshow || 0 == t.gameType && t.rummyType == HowToPlayDefined.RUMMY_MULTIPLE && 1 != User.shared().multiple_rummy_open && 1 != User.shared().multiple_2_open || 3 == t.gameType && t.rummyType == HowToPlayDefined.RUMMY_MULTIPLE && 1 != User.shared().chip_multiple_rummy_open && 1 != User.shared().chip_multiple_2_open ? this.setInitGameType(0, 0, 0, 0, 0, false) : this.setInitGameType(t.gameType, t.rummyType, t.playersIndex, t.poolIndex, t.dealsIndex, false, t.enterMoney, t.modeIndex) : !t || 3 == t.gameType && t.rummyType == HowToPlayDefined.RUMMY_MULTIPLE && 1 != User.shared().chip_multiple_rummy_open && 1 != User.shared().chip_multiple_2_open ? this.setInitGameType(3, 0, 0, 0, 0, false) : this.setInitGameType(t.gameType, t.rummyType, t.playersIndex, t.poolIndex, t.dealsIndex, false, t.enterMoney, t.modeIndex);
        }
        this._cb = t;
        this.updateSelectPlayer2();
        this.showPointsNewflag();
        this.refreshRankStar();
    }
    showPointsNewflag() {
    }
    updateSelectPlayer2() {
        let e = "6";
        0 != this.gameType && 3 != this.gameType || User.shared().easy_mode_show && this.rummyType == HowToPlayDefined.RUMMY_POINTS && this.selectMode == PointsType.Easy && (e = "4");
        this.selectPlayerLabel2.string = e;
        let t = this.roomInfoNode.getChildByName("player_select"), i = this.roomInfoNode.getChildByName("mode_select"), s = false;
        if (0 != this.gameType && 3 != this.gameType || ((1 == User.shared().multiple_rummy_open || 1 == User.shared().multiple_2_open) && i.active && this.selectMode != PointsType.Classic || (1 == User.shared().bump_rummy_open || 1 == User.shared().double_6_open || 1 == User.shared().chip_double_6_open) && i.active && this.selectMode != PointsType.Classic) && (s = true), s) {
            if (i.active && this.selectMode == PointsType.Double) {
                if (0 == this.gameType && 1 == User.shared().double_6_open || 3 == this.gameType && 1 == User.shared().chip_double_6_open) {
                    t.getChildByName("switch_bg").active = false;
                    t.getChildByName("btn_switch1").active = false;
                    t.getChildByName("btn_switch2").active = false;
                    t.getChildByName("Label1").active = false;
                    t.getChildByName("Label2").active = true;
                    let e = t.getChildByName("Label2").position;
                    t.getChildByName("Label2").setPosition(v3(0, e.y, e.z));
                    e = t.getChildByName("select").position;
                    t.getChildByName("select").setPosition(v3(0, e.y, e.z));
                    t.getChildByName("Label2").getComponent(Label).color = color(255, 253, 253);
                    t.getChildByName("select").getComponent(Sprite).spriteFrame = this.switchSelectImages[1];
                }
            }
            else if (i.active && this.selectMode == PointsType.Wild) {
                if (0 == this.gameType && 1 == User.shared().bump_2_open && 1 == User.shared().bump_6_open || 3 == this.gameType && 1 == User.shared().chip_bump_2_open && 1 == User.shared().chip_bump_6_open) {
                    t.getChildByName("switch_bg").active = true;
                    t.getChildByName("switch_bg").getComponent(UITransform).setContentSize(size(224, 102));
                    t.getChildByName("btn_switch1").active = true;
                    t.getChildByName("btn_switch2").active = true;
                    t.getChildByName("Label1").active = true;
                    t.getChildByName("Label2").active = true;
                    let e = t.getChildByName("Label1").position;
                    t.getChildByName("Label1").setPosition(v3(-55, e.y, e.z));
                    t.getChildByName("Label2").setPosition(v3(55, e.y, e.z));
                    e = t.getChildByName("select").position;
                    2 == this.selectPlayers ? t.getChildByName("select").setPosition(v3(-55, e.y, e.z)) : t.getChildByName("select").setPosition(v3(55, e.y, e.z));
                    t.getChildByName("select").getComponent(Sprite).spriteFrame = this.switchSelectImages[0];
                }
                else if (0 == this.gameType && 1 == User.shared().bump_2_open || 3 == this.gameType && 1 == User.shared().chip_bump_2_open) {
                    t.getChildByName("switch_bg").active = false;
                    t.getChildByName("btn_switch1").active = false;
                    t.getChildByName("btn_switch2").active = false;
                    t.getChildByName("Label2").active = false;
                    t.getChildByName("Label1").active = true;
                    let e = t.getChildByName("Label1").position;
                    t.getChildByName("Label1").setPosition(v3(0, e.y, e.z));
                    e = t.getChildByName("select").position;
                    t.getChildByName("select").setPosition(v3(0, e.y, e.z));
                    t.getChildByName("Label1").getComponent(Label).color = color(255, 253, 253);
                    t.getChildByName("select").getComponent(Sprite).spriteFrame = this.switchSelectImages[1];
                }
                else if (0 == this.gameType && 1 == User.shared().bump_6_open || 3 == this.gameType && 1 == User.shared().chip_bump_6_open) {
                    t.getChildByName("switch_bg").active = false;
                    t.getChildByName("btn_switch1").active = false;
                    t.getChildByName("btn_switch2").active = false;
                    t.getChildByName("Label1").active = false;
                    t.getChildByName("Label2").active = true;
                    let e = t.getChildByName("Label2").position;
                    t.getChildByName("Label2").setPosition(v3(0, e.y, e.z));
                    e = t.getChildByName("select").position;
                    t.getChildByName("select").setPosition(v3(0, e.y, e.z));
                    t.getChildByName("Label2").getComponent(Label).color = color(255, 253, 253);
                    t.getChildByName("select").getComponent(Sprite).spriteFrame = this.switchSelectImages[1];
                }
            }
            else if (i.active && this.selectMode == PointsType.Multiple) {
                if (0 == this.gameType && 1 == User.shared().multiple_rummy_open && 1 == User.shared().multiple_2_open || 3 == this.gameType && 1 == User.shared().chip_multiple_rummy_open && 1 == User.shared().chip_multiple_2_open) {
                    t.getChildByName("switch_bg").active = true;
                    t.getChildByName("switch_bg").getComponent(UITransform).setContentSize(size(224, 102));
                    t.getChildByName("btn_switch1").active = true;
                    t.getChildByName("btn_switch2").active = true;
                    t.getChildByName("Label1").active = true;
                    t.getChildByName("Label2").active = true;
                    let e = t.getChildByName("Label1").position;
                    t.getChildByName("Label1").setPosition(v3(-55, e.y, e.z));
                    t.getChildByName("Label2").setPosition(v3(55, e.y, e.z));
                    e = t.getChildByName("select").position;
                    2 == this.selectPlayers ? t.getChildByName("select").setPosition(v3(-55, e.y, e.z)) : t.getChildByName("select").setPosition(v3(55, e.y, e.z));
                    t.getChildByName("select").getComponent(Sprite).spriteFrame = this.switchSelectImages[0];
                }
                else if (0 == this.gameType && 1 == User.shared().multiple_rummy_open && 0 == User.shared().multiple_2_open || 3 == this.gameType && 1 == User.shared().chip_multiple_rummy_open && 0 == User.shared().chip_multiple_2_open) {
                    t.getChildByName("switch_bg").active = false;
                    t.getChildByName("btn_switch1").active = false;
                    t.getChildByName("btn_switch2").active = false;
                    t.getChildByName("Label1").active = false;
                    t.getChildByName("Label2").active = true;
                    let e = t.getChildByName("Label2").position;
                    t.getChildByName("Label2").setPosition(v3(0, e.y, e.z));
                    e = t.getChildByName("select").position;
                    t.getChildByName("select").setPosition(v3(0, e.y, e.z));
                    t.getChildByName("Label2").getComponent(Label).color = color(255, 253, 253);
                    t.getChildByName("select").getComponent(Sprite).spriteFrame = this.switchSelectImages[1];
                }
                else if (0 == this.gameType && 0 == User.shared().multiple_rummy_open && 1 == User.shared().multiple_2_open || 3 == this.gameType && 0 == User.shared().chip_multiple_rummy_open && 1 == User.shared().chip_multiple_2_open) {
                    t.getChildByName("switch_bg").active = false;
                    t.getChildByName("btn_switch1").active = false;
                    t.getChildByName("btn_switch2").active = false;
                    t.getChildByName("Label1").active = true;
                    t.getChildByName("Label2").active = false;
                    let e = t.getChildByName("Label1").position;
                    t.getChildByName("Label1").setPosition(v3(0, e.y, e.z));
                    e = t.getChildByName("select").position;
                    t.getChildByName("select").setPosition(v3(0, e.y, e.z));
                    t.getChildByName("Label1").getComponent(Label).color = color(255, 253, 253);
                    t.getChildByName("select").getComponent(Sprite).spriteFrame = this.switchSelectImages[1];
                }
            }
            else {
                t.getChildByName("switch_bg").active = true;
                t.getChildByName("switch_bg").getComponent(UITransform).setContentSize(size(224, 102));
                t.getChildByName("btn_switch1").active = true;
                t.getChildByName("btn_switch2").active = true;
                t.getChildByName("Label1").active = true;
                t.getChildByName("Label2").active = true;
                let e = t.getChildByName("Label1").position;
                t.getChildByName("Label1").setPosition(v3(-55, e.y, e.z));
                t.getChildByName("Label2").setPosition(v3(55, e.y, e.z));
                e = t.getChildByName("select").position;
                2 == this.selectPlayers ? t.getChildByName("select").setPosition(v3(-55, e.y, e.z)) : t.getChildByName("select").setPosition(v3(55, e.y, e.z));
                t.getChildByName("select").getComponent(Sprite).spriteFrame = this.switchSelectImages[0];
            }
        }
        else {
            t.getChildByName("switch_bg").active = true;
            t.getChildByName("switch_bg").getComponent(UITransform).setContentSize(size(224, 102));
            t.getChildByName("btn_switch1").active = true;
            t.getChildByName("btn_switch2").active = true;
            t.getChildByName("Label1").active = true;
            t.getChildByName("Label2").active = true;
            let e = t.getChildByName("Label1").position;
            t.getChildByName("Label1").setPosition(v3(-55, e.y, e.z));
            t.getChildByName("Label2").setPosition(v3(55, e.y, e.z));
            e = t.getChildByName("select").position;
            2 == this.selectPlayers ? t.getChildByName("select").setPosition(v3(-55, e.y, e.z)) : t.getChildByName("select").setPosition(v3(55, e.y, e.z));
            t.getChildByName("select").getComponent(Sprite).spriteFrame = this.switchSelectImages[0];
        }
    }
    updateGameType(e, t) {
        0 == User.shared().temp_pingbi.matchshow ? this.hasMatch = true : this.hasMatch = false;
        this.gameTypeTabs[1].active = this.hasMatch;
        this.chipsGameTypeTabs[1].active = this.hasMatch;
        this.hasMatch || 1 == e && (e = 0);
        this.gameType = e;
        this.roomInfoNode.active = 1 != e;
        this.tournamentNode.active = 1 == e;
        let i = color(90, 90, 90, 255), s = color(255, 255, 255, 255), a = [this.gameTypeTabs[0], this.gameTypeTabs[1], this.gameTypeTabs[2], this.gameTypeTabs[3]];
        1 == GameConfig.CHIPS_MODLE && (a = [this.chipsGameTypeTabs[0], this.chipsGameTypeTabs[1], this.chipsGameTypeTabs[2], this.chipsGameTypeTabs[3]]);
        for (let t = 0, o = a.length; t < o; t++) {
            let o = a[t], h = o.getChildByName("wz"), n = o.getChildByName("icon");
            t == e ? (o.getComponent(Button).interactable = false, h.getComponent(Label).color = i, n.getComponent(Sprite).color = i, i18nMgr.shared().changeLabelFontBold(h.getComponent(Label), true)) : (o.getComponent(Button).interactable = true, h.getComponent(Label).color = s, n.getComponent(Sprite).color = s, i18nMgr.shared().changeLabelFontBold(h.getComponent(Label), false));
        }
        1 != e ? (this.rummyTypeNode.active = true, User.shared().doSendMatchOnlineStatus(0), Utils.shared().hideLoading()) : this.rummyTypeNode.active = false;
        this.updateSelectPlayer2();
        this.showPointsNewflag();
        this.chip_infoNode.active = 3 == e;
    }
    updateChip() {
        let e = this.chip_infoNode.getChildByName("chip");
        e && (e.getComponent(Label).string = "" + ToolUtils.parse_ChipNum2(User.shared().data.money_exe));
    }
    updateRummyType(e) {
        let t = this.rummyTypeTabs, i = this.rummytype_select_color, s = color(102, 102, 102, 255);
        for (let a = 0, o = t.length; a < o; a++) {
            let o = t[a], h = o.getChildByName("wz"), n = o.getChildByName("line");
            if (a == e || 3 == a && e == HowToPlayDefined.RUMMY_MULTIPLE) {
                if (o.getComponent(Button).interactable = false, h.getComponent(Label).color = i, i18nMgr.shared().changeLabelFont(h.getComponent(Label), true), n.active = true, n.scale = v3(0, 1, 1), this.rummyType != e) {
                    let e = TweenTool.scaleTo(n, 0.16, v3(1.1, 1, 1), null, false), t = TweenTool.scaleTo(n, 0.16, v3(1, 1, 1), null, false);
                    TweenTool.sequence(n, true, null, e, t);
                }
                else {
                    n.scale = v3(1, 1, 1);
                }
            }
            else {
                o.getComponent(Button).interactable = true;
                h.getComponent(Label).color = s;
                i18nMgr.shared().changeLabelFont(h.getComponent(Label), false);
                n.scale = v3(1, 1, 1);
                a == this.rummyType ? TweenTool.scaleTo(n, 0.1, v3(0.2, 1, 1), null, true, (() => {
                    n.scale = v3(1, 1, 1);
                    n.active = false;
                })) : n.active = false;
            }
        }
        this.rummyType = e;
        this.updateRoomInfo();
        this.updateSelectPlayer2();
    }
    updateRoomInfo() {
        this.roomInfoNode.getComponent(UIOpacity).opacity = 255;
        let e = this.roomInfoNode.getChildByName("player_select"), t = this.roomInfoNode.getChildByName("mode_select"), i = this.roomInfoNode.getChildByName("pool_select"), s = this.roomInfoNode.getChildByName("deals_select"), a = this.roomInfoNode.getChildByName("entry_info"), o = this.roomInfoNode.getChildByName("slider_view"), l = this.roomInfoNode.getChildByName("btn_start"), h = this.roomInfoNode.getChildByName("btn_addcash"), n = this.roomInfoNode.getChildByName("btn_create"), m = this.roomInfoNode.getChildByName("btn_join");
        if (i.active = this.rummyType == HowToPlayDefined.RUMMY_POOL, 0 == this.gameType && this.rummyType == HowToPlayDefined.RUMMY_POINTS) {
            t.active = true;
            let e = t.getChildByName("layout");
            e.getChildByName("btn_switch5").active = 1 == User.shared().double_6_open;
            e.getChildByName("btn_switch5").active || e.getChildByName("btn_switch4").active || e.getChildByName("btn_switch3").active || (t.active = false);
        }
        else if (3 == this.gameType && this.rummyType == HowToPlayDefined.RUMMY_POINTS) {
            t.active = true;
            let e = t.getChildByName("layout");
            e.getChildByName("btn_switch5").active = 1 == User.shared().chip_double_6_open;
            e.getChildByName("btn_switch5").active || e.getChildByName("btn_switch3").active || e.getChildByName("btn_switch3").active || (t.active = false);
        }
        else {
            t.active = false;
        }
        s.active = this.rummyType == HowToPlayDefined.RUMMY_DEALS;
        a.active = true;
        o.active = true;
        l.active = 2 != this.gameType;
        h.active = false;
        n.active = 2 == this.gameType;
        m.active = 2 == this.gameType;
        this.chip_infoNode.active = 3 == this.gameType;
        let r = 132, d = 0, y = 0;
        2 == this.gameType && this.rummyType == HowToPlayDefined.RUMMY_POINTS && (d = 30, y = 50);
        this.rummyType == HowToPlayDefined.RUMMY_POINTS ? (t.active ? (e.setPosition(v3(-138, r + d)), t.setPosition(v3(138, r + d))) : e.setPosition(v3(0, r + d)), s.active = false, i.active = false) : this.rummyType == HowToPlayDefined.RUMMY_POOL ? (i.active = true, s.active = false, e.setPosition(v3(-138, r + d)), i.setPosition(v3(138, r + d))) : this.rummyType == HowToPlayDefined.RUMMY_DEALS && (s.active = true, i.active = false, e.setPosition(v3(-138, r + d)), s.setPosition(v3(138, r + d)));
        a.setPosition(v3(0, 11 + y));
        o.setPosition(v3(0, 17 + y));
        let c = 2 != this.gameType ? -163.983 : -123.073;
        if (l.setPosition(v3(0, c)), h.setPosition(v3(0, c)), n.setPosition(v3(0, c)), m.setPosition(v3(0, -280)), this.chip_infoNode.setPosition(v3(-400, 189)), this.chip_help.setPosition(v3(386, 189)), this.isPlaySwitchAction) {
            this.isPlaySwitchAction = false;
            let r = 0.08, d = 0.08;
            this.chip_infoNode.active && this.playRoomInfoAnim(this.chip_infoNode, 0);
            this.chip_help.active && this.playRoomInfoAnim(this.chip_help, 0);
            e.active && this.playRoomInfoAnim(e, 0);
            t.active && this.playRoomInfoAnim(t, 0);
            i.active && this.playRoomInfoAnim(i, 0);
            s.active && this.playRoomInfoAnim(s, 0);
            a.active && (this.playRoomInfoAnim(a, d), d += r);
            o.active && (this.playRoomInfoAnim(o, d), d += r);
            l.active && this.playRoomInfoAnim(l, d);
            h.active && this.playRoomInfoAnim(h, d);
            n.active && this.playRoomInfoAnim(n, d);
            m.active && this.playRoomInfoAnim(m, d);
        }
    }
    playRoomInfoAnim(e, t) {
        let i = new Vec3;
        TweenTool.stopNodeAction(e);
        e.getPosition(i);
        e.getComponent(UIOpacity).opacity = 0;
        e.setPosition(v3(i.x, i.y - 20));
        let s = TweenTool.moveToByFade(e, 0.16, i, 0, 1, false), a = TweenTool.delayAct(e, null, t, false);
        TweenTool.sequence(e, true, null, a, s);
    }
    updateBtnSwitchState(e, t, i, s) {
        let a = this.btn_noselect_color, o = color(255, 253, 253);
        if (3 != i) {
            0 == t ? (e.getChildByName("select").setPosition(-55, -21), e.getChildByName("select").setScale(v3(-1, 1, 1)), e.getChildByName("Label1").getComponent(Label).color = o, e.getChildByName("btn_switch1").getComponent(Button).interactable = false, e.getChildByName("Label2").getComponent(Label).color = a, e.getChildByName("btn_switch2").getComponent(Button).interactable = true) : (e.getChildByName("select").setPosition(55, -21), e.getChildByName("select").setScale(v3(1, 1, 1)), e.getChildByName("Label1").getComponent(Label).color = a, e.getChildByName("btn_switch1").getComponent(Button).interactable = true, e.getChildByName("Label2").getComponent(Label).color = o, e.getChildByName("btn_switch2").getComponent(Button).interactable = false);
        }
        else {
            let i = e.getChildByName("layout"), s = [], h = User.shared().getCurModeVec(0), n = -1;
            for (let e, a = 0, o = h.length; a < o; a++) {
                e = h[a];
                ToolUtils.isObjValid(i.getChildByName("btn_switch" + e)) && i.getChildByName("btn_switch" + e).active && (s.push(i.getChildByName("btn_switch" + e)), e == t && (n = s.length - 1));
            }
            if (n >= 0) {
                ToolUtils.isObjValid(s[n].getChildByName("line")) && (s[n].getChildByName("line").active = false);
                s[n].getChildByName("select").active = true;
                s[n].getChildByName("Label").getComponent(Label).color = o;
                s[n].getComponent(Button).interactable = false;
                for (let e, t = 0, i = s.length; t < i; t++) {
                    e = false;
                    t != n && (t == i - 1 ? e = false : (t < n - 1 || t >= n + 1) && (e = true), ToolUtils.isObjValid(s[t].getChildByName("line")) && (s[t].getChildByName("line").active = e), s[t].getChildByName("select").active = false, s[t].getChildByName("Label").getComponent(Label).color = a, s[t].getComponent(Button).interactable = true);
                }
            }
        }
        if (0 == i) {
            this.selectPlayers = s;
        }
        else if (1 == i) {
            this.selectPool = s;
        }
        else if (2 == i) {
            this.selectDeals = s;
        }
        else if (3 == i) {
            if (this.selectMode = s, s == PointsType.Multiple) {
                this.modeHelpBtn.active = true;
                let e = sys.localStorage.getItem(User.shared().data.uid + "clickMultiple");
                if (!sys.isObjectValid(e) || Number(e) < 3) {
                    let t = isNaN(Number(e)) ? 1 : Number(e) + 1;
                    ToolUtils.saveData(User.shared().data.uid + "clickMultiple", "" + t);
                }
            }
            else if (s == PointsType.Wild) {
                this.modeHelpBtn.active = true;
                let e = sys.localStorage.getItem(User.shared().data.uid + "clickBump");
                if (!sys.isObjectValid(e) || Number(e) < 3) {
                    let t = isNaN(Number(e)) ? 1 : Number(e) + 1;
                    ToolUtils.saveData(User.shared().data.uid + "clickBump", "" + t);
                }
            }
            else if (s == PointsType.Double) {
                this.modeHelpBtn.active = true;
                let e = sys.localStorage.getItem(User.shared().data.uid + "clickDouble");
                if (!sys.isObjectValid(e) || Number(e) < 3) {
                    let t = isNaN(Number(e)) ? 1 : Number(e) + 1;
                    ToolUtils.saveData(User.shared().data.uid + "clickDouble", "" + t);
                }
            }
            else {
                this.modeHelpBtn.active = false;
            }
        }
    }
    updateDealsState() {
        2 == this.selectPlayers ? (this.roomInfoNode.getChildByName("deals_select").getChildByName("Label1").getComponent(Label).string = "2", this.roomInfoNode.getChildByName("deals_select").getChildByName("Label2").getComponent(Label).string = "3") : (this.roomInfoNode.getChildByName("deals_select").getChildByName("Label1").getComponent(Label).string = "3", this.roomInfoNode.getChildByName("deals_select").getChildByName("Label2").getComponent(Label).string = "6");
    }
    updateSliderProgress(e) {
        let t = this.roomInfoNode.getChildByName("slider_view").getChildByName("Slider"), i = t.getChildByName("ProgressBar");
        if (this.vCurRoomList && this.vCurRoomList.length > 1) {
            this.nIdx = e - 1;
            let s = (e - 1) / (this.vCurRoomList.length - 1);
            t.getComponent(Slider).progress = s;
            i.getComponent(ProgressBar).progress = s;
            this.updateEntryInfo(e);
        }
        else {
            this.nIdx = 0;
            t.getComponent(Slider).progress = 0;
            i.getComponent(ProgressBar).progress = 0;
            this.updateEntryInfo(1);
        }
    }
    updateEntryInfo(e) {
        let t = this.roomInfoNode.getChildByName("entry_info");
        if (this.vCurRoomList && this.vCurRoomList[e - 1]) {
            t.active = true;
            let i = t.getChildByName("arrow"), s = t.getChildByName("points"), a = s.getChildByName("value"), o = t.getChildByName("entry"), h = o.getChildByName("fee"), n = t.getChildByName("feeNode"), m = n.getChildByName("fee"), r = "", d = "";
            this.rummyType == HowToPlayDefined.RUMMY_POINTS || this.rummyType == HowToPlayDefined.RUMMY_MULTIPLE ? (s.active = true, o.active = true, i.active = true, n.active = false, r = this.vCurRoomList[e - 1].boot, d = this.vCurRoomList[e - 1].entry) : (n.active = true, i.active = false, s.active = false, o.active = false, r = this.vCurRoomList[e - 1].boot, d = this.vCurRoomList[e - 1].entry);
            let y = 3 == this.gameType ? "" : "₹";
            3 == this.gameType && (r = ToolUtils.parse_ChipNum2(r), d = ToolUtils.parse_ChipNum2(d));
            a.getComponent(Label).string = y + r;
            h.getComponent(Label).string = y + d;
            m.getComponent(Label).string = y + d;
        }
        else {
            t.active = false;
        }
        this.updateChangePointBtnState();
        this.updateStartBtnState();
    }
    setBetPoint() {
        let e = this.roomInfoNode.getChildByName("slider_view"), t = e.getChildByName("Slider"), i = e.getChildByName("betroot"), s = e.getChildByName("bet_moban");
        if (s.active = false, i.destroyAllChildren(), this.vCurRoomList && this.vCurRoomList.length > 0) {
            let e = t.getComponent(UITransform).contentSize.width, a = 0, o = this.vCurRoomList.length;
            o > 1 && (a = e / (o - 1));
            t.getChildByName("best").active = this.bestIndex > 0;
            t.getChildByName("last").active = false;
            let h = -1, n = 0;
            0 == this.lastIndex ? 0 != this.bestIndex && (h = this.bestIndex, n = 1) : 0 != this.bestIndex ? this.lastIndex >= this.bestIndex ? (h = this.lastIndex, n = 0) : (h = this.bestIndex, n = 1) : (h = this.lastIndex, n = 1);
            -1 != h ? 0 == n ? (t.getChildByName("best").active = false, t.getChildByName("last").active = true, t.getChildByName("last").setPosition(v3(-e / 2 + a * (h - 1), t.getChildByName("last").position.y))) : (t.getChildByName("best").active = h > 1 && h != this.vCurRoomList.length, t.getChildByName("last").active = false, t.getChildByName("best").setPosition(v3(-e / 2 + a * (h - 1), t.getChildByName("best").position.y))) : (t.getChildByName("best").active = false, t.getChildByName("last").active = false);
            for (let t, h = 0; h < o; h++) {
                let n = instantiate(s);
                n.active = true;
                t = this.vCurRoomList[h].boot;
                3 == this.gameType && (t = ToolUtils.parse_ChipNum2(t));
                n.getComponent(Label).string = t;
                0 == h ? n.setPosition(v3(-e / 2, 0)) : h == o - 1 ? n.setPosition(v3(e / 2, 0)) : (n.setPosition(v3(-e / 2 + a * h, 0)), sys.isObjectValid(this.vCurRoomList[h].sbet) && 1 == this.vCurRoomList[h].sbet || (n.getComponent(Label).string = ""));
                i.addChild(n);
            }
        }
        t.getChildByName("best").active = false;
        t.getChildByName("last").active = false;
    }
    updateChangePointBtnState() {
        let e = this.roomInfoNode.getChildByName("slider_view"), t = e.getChildByName("btn_add").getComponent(Button), i = e.getChildByName("btn_reduce").getComponent(Button);
        this.vCurRoomList && this.vCurRoomList.length > 1 ? (t.interactable = this.nIdx + 1 < this.vCurRoomList.length, i.interactable = this.nIdx > 0) : (t.interactable = false, i.interactable = false);
    }
    updateStartBtnState() {
        let e = this.vCurRoomList[this.nIdx];
        if (0 == this.gameType) {
            if (null != e && null != e) {
                let t = e.entry;
                this.roomInfoNode.getChildByName("btn_start").active = User.shared().data.money >= t;
                this.roomInfoNode.getChildByName("btn_addcash").active = User.shared().data.money < t;
                this._min_entry = t;
            }
        }
        else if (2 == this.gameType) {
            if (null != e && null != e) {
                let t = e.entry;
                this.roomInfoNode.getChildByName("btn_create").active = User.shared().data.money >= t;
                this.roomInfoNode.getChildByName("btn_addcash").active = User.shared().data.money < t;
            }
        }
        else if (3 == this.gameType && null != e && null != e) {
            let t = e.entry;
            this.roomInfoNode.getChildByName("btn_start").active = this.checkChipGameCanPlay(t);
            this.roomInfoNode.getChildByName("btn_addcash").active = !this.checkChipGameCanPlay(t);
            this._min_entry = t;
        }
        let t = this.roomInfoNode.getChildByName("btn_addcash"), i = t.getChildByName("layout").getChildByName("wz");
        if (ToolUtils.isObjValid(t) && null != e && null != e) {
            let s = e.entry;
            3 == this.gameType ? (t.active = !this.checkChipGameCanPlay(s), i18nMgr.shared().changeLocalizedLabelKey(i, "choose_game.play_now")) : (t.active = User.shared().data.money < s, 2 == this.gameType && i18nMgr.shared().changeLocalizedLabelKey(i, "choose_game.create"));
        }
        this.refreshRankStar();
        this.checkBtnWzFontSize();
    }
    checkChipGameCanPlay(e) {
        return 3 == this.gameType && User.shared().data.money_exe >= e;
    }
    checkBtnWzFontSize() {
        let e = this.roomInfoNode.getChildByName("btn_addcash"), t = e.getChildByName("layout").getChildByName("wz"), i = 80;
        ToolUtils.isObjValid(e) && (3 == this.gameType || 3 == i18nMgr.shared().language && (i = 68));
        t.getComponent(Label).fontSize = i;
    }
    onRankClick(e, t) {
        SoundManager.shared().playFx("click");
    }
    onGameTypeClick(e, t) {
        SoundManager.shared().playFx("click");
        let i = Number(t);
        if (1 !== User.shared().temp_pingbi.matchgame || 1 != i) {
            if (1 !== User.shared().temp_pingbi.buddygame || 2 != i) {
                if (1 == GameConfig.CHIPS_MODLE && 0 == i && (i = 3), User.shared().openGameTab && User.shared().openGameTab[i + 1]) {
                    let e;
                    if (e = 3 == this.gameType ? User.shared().checkRoomCanPlayCashGame(CheckModule.CHIPS_PLAY, false) : User.shared().checkRoomCanPlayCashGame(CheckModule.CASH_PLAY, false), e < 2) {
                        if (0 == e) {
                            let e = 0 == GameConfig.GAME_APP_THEME ? CommDefine.AppName_rummy : CommDefine.AppName_circ;
                            Utils.shared().showToast(ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_main.band_cash_game_tip"), e), 5);
                        }
                        return;
                    }
                    if (this.isPlaySwitchAction = true, this._changeSliderByPlayer = false, 1 != i) {
                        let e = false, t = sys.localStorage.getItem(User.shared().data.uid + "recommendRoom" + i + this.rummyType);
                        if (t) {
                            let s = ToolUtils.getRecommendRoom(ToolUtils.parseJson(t));
                            e = this.setInitGameType(i, this.rummyType, s.playersIndex, s.poolIndex, s.dealsIndex, true, s.enterMoney);
                        }
                        else {
                            e = this.setInitGameType(i, this.rummyType, 1, 0, 1, true);
                        }
                        e || (e = this.setInitGameType(i, 0, 1, 0, 0, true));
                        e || Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text34"), 2);
                    }
                    else {
                        this.updateGameType(i, true);
                        this.tournamentNode && this.tournamentNode.getComponent(RummyAddGameList).playRoomInfoAnim();
                    }
                }
                else {
                    Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text34"), 2);
                }
                this.refreshRankStar();
                this.gameType;
            }
            else {
                Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text41"), 2);
            }
        }
        else {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text41"), 2);
        }
    }
    onShowChipTip() {
        let e = sys.localStorage.getItem(User.shared().data.uid + "Chip_Game_Tips_Times"), t = 0, i = false;
        sys.isObjectValid(e) ? Number(e) > 0 && Number(e) < ToolUtils.isSafeNumber(User.shared().exe_cfg.introduce_times) && (i = true, t = Number(e) + 1) : (i = true, t = 1);
        i && (ToolUtils.saveData(User.shared().data.uid + "Chip_Game_Tips_Times", String(t)), this.showChipGameAlert());
    }
    showChipGameAlert() {
        let e = { info: "Chip - " + (6 == this.selectPlayers ? 4 : this.selectPlayers) + "Players - " + this.roomInfoNode.getChildByName("entry_info").getChildByName("points").getChildByName("value").getComponent(Label).string, min_entry: this._min_entry, parent_node: director.getScene().getChildByName("Canvas") };
        Utils.shared().showChipGameTypeView(e, (e => {
            this.onStartGameClick(null, e);
        }));
    }
    onRummyTypeClick(e, t) {
        SoundManager.shared().playFx("click");
        let i = Number(t);
        if (this._changeSliderByPlayer = false, 0 === this.gameType) {
            if (1 == i) {
                if (Utils.shared().judgeCashPoolAllRoomLock()) {
                    let e = Utils.shared().getCashPoolAllRoomLockTipsNum();
                    if (e > 0) {
                        return void Utils.shared().showRoomUnlockToast(this.gameType, e);
                    }
                }
            }
            else if (2 == i) {
                if (Utils.shared().judgeCashDealsAllRoomLock()) {
                    let e = Utils.shared().getCashDealsAllRoomLockTipsNum();
                    if (e > 0) {
                        return void Utils.shared().showRoomUnlockToast(this.gameType, e);
                    }
                }
            }
            3 == i && (i = HowToPlayDefined.RUMMY_MULTIPLE);
        }
        let s = Utils.shared().getCurRoomList(this.gameType, i);
        if (s && s.length > 0) {
            if (this.isPlaySwitchAction) {
                let e = TweenTool.moveToByFade(this.roomInfoNode, 0.1, null, 1, 0, false), t = TweenTool.delayAct(this.roomInfoNode, (() => {
                    ToolUtils.isObjValid(this.node) && this.refreshRummyType(i);
                }), 0.1, false);
                TweenTool.parallel(this.roomInfoNode, true, null, e, t);
            }
            else {
                this.refreshRummyType(i);
            }
        }
        else {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text34"), 2);
        }
        this.refreshRankStar();
    }
    refreshRummyType(e) {
        let t = sys.localStorage.getItem(User.shared().data.uid + "recommendRoom" + this.gameType + e);
        if (t) {
            let i = ToolUtils.getRecommendRoom(ToolUtils.parseJson(t));
            this.setInitGameType(this.gameType, e, i.playersIndex, i.poolIndex, i.dealsIndex, false, i.enterMoney, i.modeIndex);
        }
        else {
            this.setInitGameType(this.gameType, e, 1, 0, 1);
        }
        if (e == HowToPlayDefined.RUMMY_MULTIPLE) {
            let e = sys.localStorage.getItem(User.shared().data.uid + "Multiple_Game_Tips_Times"), t = 0, i = false;
            sys.isObjectValid(e) ? Number(e) > 0 && Number(e) < ToolUtils.isSafeNumber(User.shared().points_multiple_cfg.tips_times) && (i = true, t = Number(e) + 1) : (i = true, t = 1);
            i && (ToolUtils.saveData(User.shared().data.uid + "Multiple_Game_Tips_Times", String(t)), this.showMultipleGameAlert());
        }
    }
    onPlayerSelectClick(e, t) {
        SoundManager.shared().playFx("click");
        this._changeSliderByPlayer = false;
        let i = Number(t), s = 2 == i ? 0 : 1, a = sys.localStorage.getItem(User.shared().data.uid + "recommendRoom" + this.gameType + this.rummyType), o = this.vCurRoomList[this.nIdx], l = -1;
        sys.isObjectValid(o.mode) && (l = o.mode);
        let h = null;
        if (a) {
            let e = ToolUtils.parseJson(a);
            if (e && e.data) {
                if (sys.isObjectValid(e.data.mode)) {
                    let t = i;
                    2 == e.data.mode && 2 != t && (t = 4);
                    e.data.player == t && (h = e.data.entry);
                }
                else {
                    e.data.player == i && (h = e.data.entry);
                }
            }
        }
        let n = null;
        if (this.rummyType == HowToPlayDefined.RUMMY_DEALS) {
            if (2 == i) {
                if (n = this.getSelectRoomList(i, this.selectPool, 2, h), n && n.length > 0) {
                    return this.selectDeals = 2, this.updateBtnSwitchState(this.roomInfoNode.getChildByName("player_select"), s, 0, i), this.updateBtnSwitchState(this.roomInfoNode.getChildByName("deals_select"), 0, 2, 2), void this.updateDealsState();
                }
                if (n = this.getSelectRoomList(i, this.selectPool, 3, h), !(n && n.length > 0)) {
                    return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text34"), 2);
                }
                this.selectDeals = 3;
                this.updateBtnSwitchState(this.roomInfoNode.getChildByName("player_select"), s, 0, i);
                this.updateBtnSwitchState(this.roomInfoNode.getChildByName("deals_select"), 1, 2, 3);
                this.updateDealsState();
            }
            else {
                if (n = this.getSelectRoomList(i, this.selectPool, 3, h), n && n.length > 0) {
                    return this.selectDeals = 3, this.updateBtnSwitchState(this.roomInfoNode.getChildByName("player_select"), s, 0, i), this.updateBtnSwitchState(this.roomInfoNode.getChildByName("deals_select"), 0, 2, 3), void this.updateDealsState();
                }
                if (n = this.getSelectRoomList(Number(t), this.selectPool, 6, h), !(n && n.length > 0)) {
                    return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text34"), 2);
                }
                this.selectDeals = 6;
                this.updateBtnSwitchState(this.roomInfoNode.getChildByName("player_select"), s, 0, i);
                this.updateBtnSwitchState(this.roomInfoNode.getChildByName("deals_select"), 1, 2, 6);
                this.updateDealsState();
            }
        }
        else {
            if (!Utils.shared().judgeCashPointExistUnlockRoom(i, l) && 0 == this.gameType && this.rummyType == HowToPlayDefined.RUMMY_POINTS) {
                let e = Utils.shared().getCashUnlockRoomNum(this.rummyType, i, l);
                return void Utils.shared().showRoomUnlockToast(this.gameType, e);
            }
            if (n = this.getSelectRoomList(i, this.selectPool, this.selectDeals, h), !(n && n.length > 0)) {
                return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text34"), 2);
            }
            this.updateBtnSwitchState(this.roomInfoNode.getChildByName("player_select"), s, 0, i);
        }
    }
    onModeSelectClick(e, t) {
        SoundManager.shared().playFx("click");
        this._changeSliderByPlayer = false;
        let i = Number(t), s = this.vCurRoomList[this.nIdx];
        if (s && i > 0 && 0 === this.gameType) {
            let e = {};
            if (this.rummyType == HowToPlayDefined.RUMMY_POINTS && (e = Utils.shared().judgeCashPointRoomUnlock(this.selectPlayers, i, s.entry)), e && !e.openBol) {
                return void Utils.shared().showRoomUnlockToast(this.gameType, e.num);
            }
        }
        if (i == PointsType.Wild) {
            (0 == this.gameType && 6 == this.selectPlayers && 1 != User.shared().bump_6_open || 2 == this.selectPlayers && 1 != User.shared().bump_2_open || 3 == this.gameType && 6 == this.selectPlayers && 1 != User.shared().chip_bump_6_open || 2 == this.selectPlayers && 1 != User.shared().chip_bump_2_open) && (0 == this.gameType && 1 == User.shared().bump_6_open || 3 == this.gameType && 1 == User.shared().chip_bump_6_open ? this.updateBtnSwitchState(this.roomInfoNode.getChildByName("player_select"), 1, 0, 6) : this.updateBtnSwitchState(this.roomInfoNode.getChildByName("player_select"), 0, 0, 2));
        }
        else if (i == PointsType.Double) {
            0 != this.gameType && 3 != this.gameType || this.updateBtnSwitchState(this.roomInfoNode.getChildByName("player_select"), 1, 0, 6);
        }
        else if (i == PointsType.Multiple) {
            if (0 === this.gameType && (1 == User.shared().multiple_rummy_open || 1 == User.shared().multiple_2_open) || 3 === this.gameType && (1 == User.shared().chip_multiple_rummy_open || 1 == User.shared().chip_multiple_2_open)) {
                if (s && i > 0 && 0 === this.gameType) {
                    let e = {};
                    if (this.rummyType == HowToPlayDefined.RUMMY_POINTS && (e = Utils.shared().judgeCashPointRoomUnlock(this.selectPlayers, i, s.entry)), e && !e.openBol) {
                        return void Utils.shared().showRoomUnlockDialog(this.gameType, e.num);
                    }
                }
                (0 === this.gameType && 6 == this.selectPlayers && 1 != User.shared().multiple_rummy_open || 2 == this.selectPlayers && 1 != User.shared().multiple_2_open || 3 === this.gameType && 6 == this.selectPlayers && 1 != User.shared().chip_multiple_rummy_open || 2 == this.selectPlayers && 1 != User.shared().chip_multiple_2_open) && (0 === this.gameType && 1 == User.shared().multiple_rummy_open || 3 === this.gameType && 1 == User.shared().chip_multiple_rummy_open ? this.updateBtnSwitchState(this.roomInfoNode.getChildByName("player_select"), 1, 0, 6) : this.updateBtnSwitchState(this.roomInfoNode.getChildByName("player_select"), 0, 0, 2));
            }
            else if (0 === this.gameType && 1 == User.shared().multiple_rummy_open || 3 === this.gameType && 1 == User.shared().chip_multiple_rummy_open) {
                if (s && i > 0 && 0 === this.gameType) {
                    let e = {};
                    if (this.rummyType == HowToPlayDefined.RUMMY_POINTS && (e = Utils.shared().judgeCashPointRoomUnlock(6, i, s.entry)), e && !e.openBol) {
                        return void Utils.shared().showRoomUnlockDialog(this.gameType, e.num);
                    }
                }
                6 != this.selectPlayers && (0 === this.gameType && 0 == User.shared().multiple_2_open || 3 === this.gameType && 0 == User.shared().chip_multiple_2_open) && this.updateBtnSwitchState(this.roomInfoNode.getChildByName("player_select"), 1, 0, 6);
            }
            else if (0 === this.gameType && 1 == User.shared().multiple_2_open || 3 === this.gameType && 1 == User.shared().chip_multiple_2_open) {
                if (s && i > 0 && 0 === this.gameType) {
                    let e = {};
                    if (this.rummyType == HowToPlayDefined.RUMMY_POINTS && (e = Utils.shared().judgeCashPointRoomUnlock(2, i, s.entry)), e && !e.openBol) {
                        return void Utils.shared().showRoomUnlockDialog(this.gameType, e.num);
                    }
                }
                2 != this.selectPlayers && this.updateBtnSwitchState(this.roomInfoNode.getChildByName("player_select"), 1, 0, 2);
            }
        }
        let a = this.getEnterMoney(i), o = this.getSelectRoomList(this.selectPlayers, this.selectPool, this.selectDeals, a, i);
        o && o.length > 0 ? (this.updateBtnSwitchState(this.roomInfoNode.getChildByName("mode_select"), i, 3, i), this.updateSelectPlayer2(), i == PointsType.Multiple ? this.onShowMultipleTip() : i == PointsType.Wild ? this.onShowBumpTip() : i == PointsType.Double ? this.onShowDoubleTip() : i == PointsType.Easy && this.onShowEasyTip()) : Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text34"), 2);
    }
    getEnterMoney(e, t = false) {
        let i = sys.localStorage.getItem(User.shared().data.uid + "recommendRoom" + this.gameType + this.rummyType), s = null;
        if (i) {
            let a = ToolUtils.parseJson(i);
            if (a && a.data) {
                if (sys.isObjectValid(a.data.mode)) {
                    let i = this.selectPlayers;
                    t && 2 == a.data.mode && 2 != i && (i = 4);
                    a.data.player == i && a.data.mode == e && (s = a.data.entry);
                }
                else {
                    a.data.player == this.selectPlayers && (s = a.data.entry);
                }
                if (sys.isObjectValid(a.data.mode)) {
                    let t = this.selectPlayers;
                    a.data.player == t && a.data.mode == e && (s = a.data.entry);
                }
                else {
                    a.data.player == this.selectPlayers && (s = a.data.entry);
                }
            }
        }
        return s;
    }
    onShowEasyTip() {
        let e = sys.localStorage.getItem(User.shared().data.uid + "Easy_Game_Tips_Times"), t = 0, i = false;
        sys.isObjectValid(e) || (e = "0");
        Number(e) > 0 && Number(e) < ToolUtils.isSafeNumber(User.shared().points_easy_cfg.tips_times) && (i = true, t = Number(e) + 1);
        i && (ToolUtils.saveData(User.shared().data.uid + "Easy_Game_Tips_Times", String(t)), this.showEasyGameAlert());
    }
    onShowMultipleTip() {
        let e = sys.localStorage.getItem(User.shared().data.uid + "Multiple_Game_Tips_Times"), t = 0, i = false;
        sys.isObjectValid(e) || (e = "0");
        Number(e) > 0 && Number(e) < ToolUtils.isSafeNumber(User.shared().points_multiple_cfg.tips_times) && (i = true, t = Number(e) + 1);
        i && (ToolUtils.saveData(User.shared().data.uid + "Multiple_Game_Tips_Times", String(t)), this.showMultipleGameAlert());
    }
    onShowBumpTip() {
        let e = sys.localStorage.getItem(User.shared().data.uid + "Bump_Game_Tips_Times"), t = 0, i = false;
        sys.isObjectValid(e) || (e = "0");
        Number(e) > 0 && Number(e) < ToolUtils.isSafeNumber(User.shared().points_bump_cfg.tips_times) && (i = true, t = Number(e) + 1);
        i && (ToolUtils.saveData(User.shared().data.uid + "Bump_Game_Tips_Times", String(t)), this.showBumpGameAlert());
    }
    onShowDoubleTip() {
        let e = sys.localStorage.getItem(User.shared().data.uid + "Double_Game_Tips_Times"), t = 0, i = false;
        sys.isObjectValid(e) || (e = "0");
        Number(e) > 0 && Number(e) < ToolUtils.isSafeNumber(User.shared().points_double_cfg.tips_times) && (i = true, t = Number(e) + 1);
        i && (ToolUtils.saveData(User.shared().data.uid + "Double_Game_Tips_Times", String(t)), this.showDoubleGameAlert());
    }
    onCheckShowGameAlert() {
        if (this.selectMode !== PointsType.Multiple && this.selectMode != PointsType.Wild && this.selectMode != PointsType.Double && this.selectMode != PointsType.Easy) {
            return;
        }
        let e = this.getSelectRoomList(this.selectPlayers, this.selectPool, this.selectDeals);
        e && e.length > 0 && (this.selectMode == PointsType.Multiple ? this.onShowMultipleTip() : this.selectMode == PointsType.Wild ? this.onShowBumpTip() : this.selectMode == PointsType.Double ? this.onShowDoubleTip() : this.selectMode == PointsType.Easy && this.onShowEasyTip());
    }
    onModeHelpClick(e, t) {
        SoundManager.shared().playFx("click");
        "chips" == t ? this.showChipGameAlert() : this.selectMode == PointsType.Multiple ? this.showMultipleGameAlert() : this.selectMode == PointsType.Wild ? this.showBumpGameAlert() : this.selectMode == PointsType.Double ? this.showDoubleGameAlert() : this.selectMode == PointsType.Easy && this.showEasyGameAlert();
    }
    showMultipleGameAlert() {
        let e = this.roomInfoNode.getChildByName("entry_info").getChildByName("points").getChildByName("value").getComponent(Label).string, t = { info: "Points - Multiples - " + this.selectPlayers + "Players - " + e, min_entry: this._min_entry, game_type: this.gameType };
        Utils.shared().showMultipleGameTypeAlert(t, (e => {
            this.onStartGameClick(null, e);
        }));
    }
    showBumpGameAlert() {
        let e = this.roomInfoNode.getChildByName("entry_info").getChildByName("points").getChildByName("value").getComponent(Label).string, t = { info: "Points - Wild - " + this.selectPlayers + "Players - " + e, min_entry: this._min_entry, game_type: this.gameType };
        Utils.shared().showBumpGameTypeAlert(t, (e => {
            this.onStartGameClick(null, e);
        }));
    }
    showEasyGameAlert() {
        let e = { info: "Points - Easy - " + (6 == this.selectPlayers ? 4 : this.selectPlayers) + "Players - " + this.roomInfoNode.getChildByName("entry_info").getChildByName("points").getChildByName("value").getComponent(Label).string, min_entry: this._min_entry };
        Utils.shared().showEasyGameTypeAlert(e, (e => {
            this.onStartGameClick(null, e);
        }));
    }
    showDoubleGameAlert() {
        let e = this.roomInfoNode.getChildByName("entry_info").getChildByName("points").getChildByName("value").getComponent(Label).string, t = { info: "Points - Double - " + this.selectPlayers + "Players - " + e, min_entry: this._min_entry, game_type: this.gameType };
        Utils.shared().showDoubleRummyTypeAlert(t, (e => {
            this.onStartGameClick(null, e);
        }));
    }
    onPoolSelectClick(e, t) {
        SoundManager.shared().playFx("click");
        let i = 101 == Number(t) ? 0 : 1;
        this._changeSliderByPlayer = false;
        let s = sys.localStorage.getItem(User.shared().data.uid + "recommendRoom" + this.gameType + this.rummyType), a = null;
        if (s) {
            let e = ToolUtils.parseJson(s);
            e && e.data && e.data.player == this.selectPlayers && e.data.pool_game == Number(t) && (a = e.data.entry);
        }
        let o = this.getSelectRoomList(this.selectPlayers, Number(t), this.selectDeals, a);
        o && o.length > 0 ? this.updateBtnSwitchState(this.roomInfoNode.getChildByName("pool_select"), i, 1, Number(t)) : Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text34"), 2);
    }
    onDealsSelectClick(e, t) {
        SoundManager.shared().playFx("click");
        this._changeSliderByPlayer = false;
        let i = 2 == Number(t) ? 0 : 1, s = Number(t);
        6 == this.selectPlayers && (s = 2 == Number(t) ? 3 : 6);
        let a = sys.localStorage.getItem(User.shared().data.uid + "recommendRoom" + this.gameType + this.rummyType), o = null;
        if (a) {
            let e = ToolUtils.parseJson(a);
            e && e.data && e.data.player == this.selectPlayers && e.data.deals == s && (o = e.data.entry);
        }
        let l = this.getSelectRoomList(this.selectPlayers, this.selectPool, s, o);
        l && l.length > 0 ? this.updateBtnSwitchState(this.roomInfoNode.getChildByName("deals_select"), i, 2, s) : Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text34"), 2);
    }
    onSliderCallback(e, t) {
        e.target;
        let i = 0, s = this.roomInfoNode.getChildByName("slider_view").getChildByName("Slider"), a = s.getChildByName("ProgressBar"), o = s.getComponent(Slider).progress;
        this.vCurRoomList && this.vCurRoomList.length > 1 && (i = Math.floor((this.vCurRoomList.length - 1) * o + 0.5));
        a.getComponent(ProgressBar).progress = o;
        this.updateSliderProgress(i + 1);
    }
    onChangePointClick(e, t) {
        SoundManager.shared().playFx("click");
        this.vCurRoomList && this.vCurRoomList.length > 0 && (this._changeSliderByPlayer = true, "add" == t ? this.nIdx + 1 < this.vCurRoomList.length && (this.nIdx = this.nIdx + 1, this.updateSliderProgress(this.nIdx + 1)) : this.nIdx > 0 && (this.nIdx = this.nIdx - 1, this.updateSliderProgress(this.nIdx + 1)), this.updateChangePointBtnState());
    }
    getRecommendPracticeRoom() {
        let e = -1;
        if (null != this.vCurRoomList && sys.isObjectValid(this.vCurRoomList.length) && this.vCurRoomList.length > 0) {
            let t = User.shared().data.money_exe;
            for (let i = this.vCurRoomList.length - 1; i >= 0; i--) {
                this.vCurRoomList[i].min_money <= t && t < this.vCurRoomList[i].max_money && (e = i);
            }
        }
        return -1 != e ? this.vCurRoomList[e] : null;
    }
    onStartGameClick(e, t) {
        SoundManager.shared().playFx("click");
        let i = this.vCurRoomList[this.nIdx];
        if (i && 0 === this.gameType) {
            let e = {};
            if (this.rummyType == HowToPlayDefined.RUMMY_POINTS) {
                e = Utils.shared().judgeCashPointRoomUnlock(this.selectPlayers, i.mode, i.entry);
            }
            else if (this.rummyType == HowToPlayDefined.RUMMY_POOL) {
                e = Utils.shared().judgeCashPoolRoomUnlock(this.selectPlayers, i.pool_game, i.entry);
            }
            else if (this.rummyType == HowToPlayDefined.RUMMY_DEALS) {
                let t = this.selectDeals;
                6 == this.selectPlayers && (t = 2 == Number(t) ? 3 : 6);
                e = Utils.shared().judgeCashDealsRoomUnlock(this.selectPlayers, t, i.entry);
            }
            if (e && !e.openBol) {
                return void Utils.shared().showRoomUnlockToast(this.gameType, e.num);
            }
        }
        let s = "Click_GameIcon_Rm_", a = s + (parseInt("" + this.nIdx) + 1), o = GameConfig[a];
        if (null != GameConfig[a] && null != GameConfig[a] || (o = parseInt("" + PhpReportDefined[s + "1"]) + parseInt("" + this.nIdx)), HttpManager.shared().doReportUserAct(o), Utils.shared().uploadGtagEvent(PhpReportDefined.GA_StartGameEvent), Utils.shared().uploadFBEvent(PhpReportDefined.FB_StartGameEvent), "addcash" == t) {
            HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Rummy_Game, func: ReportConfig.func.RummyRoom, event: ReportConfig.cash_evt.click_room_add_ca });
            this.roomInfoNode.getChildByName("btn_addcash").getComponent(Button).interactable = false;
            TweenTool.delayAct(this.roomInfoNode, (() => {
                ToolUtils.isObjValid(this.roomInfoNode) && (this.roomInfoNode.getChildByName("btn_addcash").getComponent(Button).interactable = true);
            }), 1, true);
            let e = null, t = 0;
            if (this._min_entry = 0, Array.isArray(this.vCurRoomList) && this.vCurRoomList.length > this.nIdx && (e = this.vCurRoomList[this.nIdx], t = e.vid, undefined !== e.entry && (this._min_entry = e.entry)), 0 == this.gameType || 2 == this.gameType) {
                Utils.shared().showQuickRecharge(t, null, true, User.shared().curTid_key, 0, this._min_entry, true, 0, 1);
                User.shared().updatePayScene(PhpReportDefined.pay_scene.game_selectroom_less_money, t);
            }
            else if (3 == this.gameType) {
                director.getScene().getChildByName("Canvas");
                User.shared().curTid_key;
                this._min_entry;
                Utils.shared().showToast("Not enough chips for this table. Please choose a lower point value or another practice table.", 3, 0, ToolUtils.getIsNormalDirection());
            }
        }
        else {
            let e = 0, t = 0;
            if (Array.isArray(this.vCurRoomList) && this.vCurRoomList.length > this.nIdx) {
                let i = this.vCurRoomList[this.nIdx];
                t = i.boot;
                undefined !== i.entry && (e = i.entry);
                undefined !== i.max_money && i.max_money > e && (e = i.max_money);
            }
            if (3 == this.gameType && User.shared().data.money_exe >= e) {
                let e = this.getRecommendPracticeRoom();
                if (e) {
                    let t = e.boot, i = ToolUtils.format(i18nMgr.shared().getValueByKey("choose_game.chip_up_tips"), t), s = { bLandscape: ToolUtils.getIsNormalDirection(), bWithCancel: false, strContent: i, sureKey: "choose_game.play_now" };
                    return void Utils.shared().showCommonAlert(s, (t => {
                        1 === t && this.enterGame(e);
                    }), true);
                }
            }
            else if (0 == this.gameType && sys.isObjectValid(this.vCurRoomList) && 0 != this.bestIndex) {
                let e = this.vCurRoomList[this.bestIndex - 1];
                if (null != e.boot && e.boot > t) {
                    return void User.shared().requestCheckCashGameUpPop({ vid: e.vid }, (t => {
                        sys.isObjectValid(t) && 1 == t ? User.shared().showCashGameUpAlert(e.boot, (t => {
                            ToolUtils.isObjValid(this.node) && (1 == t ? this.enterGame(e) : Array.isArray(this.vCurRoomList) && this.vCurRoomList.length > this.nIdx && this.enterGame(this.vCurRoomList[this.nIdx]));
                        }), PhpReportDefined.scece.cash_room_choose) : ToolUtils.isObjValid(this.node) && Array.isArray(this.vCurRoomList) && this.vCurRoomList.length > this.nIdx && this.enterGame(this.vCurRoomList[this.nIdx]);
                    }));
                }
            }
            Array.isArray(this.vCurRoomList) && this.vCurRoomList.length > this.nIdx && this.enterGame(this.vCurRoomList[this.nIdx]);
        }
    }
    enterGame(e) {
        if (HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Rummy_Game, func: ReportConfig.func.RummyRoom, event: ReportConfig.cash_evt.click_room_start }), User.shared().first_click_play_time = -1, this.roomInfoNode.getChildByName("btn_start").getComponent(Button).interactable = false, TweenTool.delayAct(this.roomInfoNode, (() => {
            ToolUtils.isObjValid(this.roomInfoNode) && (this.roomInfoNode.getChildByName("btn_start").getComponent(Button).interactable = true);
        }), 1, true), e && e.vid) {
            let t = e.vid;
            User.shared().min_money = e.entry;
            ToolUtils.curRoomId = t;
            let i = {};
            i.lobby = this.gameType;
            i.game = this.rummyType;
            i.data = e;
            ToolUtils.saveData(User.shared().data.uid + "recommendRoom" + this.gameType + this.rummyType, ToolUtils.toJsonString(i));
            ToolUtils.saveData(User.shared().data.uid + "recommendRoomNew", ToolUtils.toJsonString(i));
            ToolUtils.saveData(User.shared().data.uid + "addRecommendRoomNew", ToolUtils.toJsonString(i));
            this._cb && this._cb(t);
        }
        ToolUtils.isObjValid(this.node) && this.node.destroy();
    }
    onBuddyGameClick(e, t) {
        if (SoundManager.shared().playFx("click"), sys.now() - this._lastClick < 500) {
            return;
        }
        if (this._lastClick = sys.now(), 1 != Utils.shared().showFastKyc()) {
            if ("join" == t) {
                Utils.shared().showBuddyJoinView();
            }
            else if ("create" == t) {
                let e = this.vCurRoomList[this.nIdx], t = e.boot, i = {};
                i.lobby = this.gameType;
                i.game = this.rummyType;
                i.data = { boot: t, max_money: e.max_money, entry: e.entry, min_money: e.min_money, player: this.selectPlayers, pool_game: this.selectPool, deals: this.selectDeals };
                ToolUtils.saveData(User.shared().data.uid + "recommendRoom" + this.gameType + this.rummyType, ToolUtils.toJsonString(i));
                ToolUtils.saveData(User.shared().data.uid + "addRecommendRoomNew", ToolUtils.toJsonString(i));
                null != e && null != e && (this._min_entry = e.entry, this.cur_vid = 0, this.rummyType == HowToPlayDefined.RUMMY_POINTS ? PushCenter.shared().pushEvent(GameConfig.Enter_Private_Room, { vid: e.vid, roomType: 1, privateRoomData: { roomid: 0, base_money: t, seat_max: this.selectPlayers } }) : this.rummyType == HowToPlayDefined.RUMMY_POOL ? PushCenter.shared().pushEvent(GameConfig.Enter_Private_Room, { vid: e.vid, roomType: 1, privateRoomData: { roomid: 0, base_money: t, seat_max: this.selectPlayers, disuse_score: this.selectPool } }) : PushCenter.shared().pushEvent(GameConfig.Enter_Private_Room, { vid: e.vid, roomType: 1, privateRoomData: { roomid: 0, base_money: t, seat_max: this.selectPlayers, rounds: this.selectDeals } }), ToolUtils.isObjValid(this.node) && this.node.destroy());
            }
        }
        else {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("kyc.kyc_privateroom"), 2);
        }
    }
    onClickClose(e, t) {
        SoundManager.shared().playFx("click");
        ToolUtils.isObjValid(this.node) && this.node.destroy();
    }
    getSelectRoomList(e = this.selectPlayers, t = this.selectPool, i = this.selectDeals, s, a = this.selectMode) {
        let o = Utils.shared().getCurSelectRoomList(this.gameType, this.rummyType, e, t, i, a);
        if (o && o.length > 0) {
            this.vCurRoomList = o;
            let e = this.getRecommendRoomIndex(o, s);
            this.updateSliderProgress(e);
            this.setBetPoint();
        }
        return o;
    }
    getRecommendRoomIndex(e, t, i = -1) {
        this.bestIndex = 0;
        this.lastIndex = 0;
        let s = User.shared().data.money;
        if (3 == this.gameType && (s = User.shared().data.money_exe), null != e && sys.isObjectValid(e.length) && e.length > 0) {
            let i;
            for (let a = e.length - 1; a >= 0; a--) {
                sys.isObjectValid(t) && (i = e[a].entry, i == t && 0 == this.lastIndex && (this.lastIndex = a + 1));
                e[a].min_money <= s && s < e[a].max_money && 0 == this.bestIndex && (this.bestIndex = a + 1);
            }
            if (sys.isObjectValid(t)) {
                for (let a = e.length - 1; a >= 0; a--) {
                    if (i = e[a].entry, i == t && t <= s) {
                        let e = a + 1;
                        return 0 == this.lastIndex ? e = this.bestIndex : 0 != this.bestIndex && (e = this.lastIndex >= this.bestIndex ? this.lastIndex : this.bestIndex), e;
                    }
                }
            }
            for (let t = e.length - 1; t >= 0; t--) {
                if (e[t].min_money <= s && s < e[t].max_money) {
                    let e = t + 1;
                    return 0 == this.lastIndex ? e = this.bestIndex : 0 != this.bestIndex && (e = this.lastIndex >= this.bestIndex ? this.lastIndex : this.bestIndex), e;
                }
            }
        }
        return 1;
    }
    setInitGameType(e = 0, t = 0, i = 0, s = 0, a = 0, o = false, l, h = 0) {
        t = 3 == t ? 8 : t;
        let n = [2, 6], m = [101, 201], r = [2, 3, 6], d = [PointsType.Classic];
        if (d = User.shared().getCurModeVec(e), 1 == e) {
            if (!User.shared().openGameTab || !User.shared().openGameTab[2]) {
                return e += 1, void this.setInitGameType(e, 0, 0, 0, 0, o, l);
            }
            this.updateGameType(e, o);
        }
        else {
            let y = Utils.shared().getCurRoomList(e, t);
            if (null == y || 0 == y.length) {
                let n = e, m = t;
                if (0 != e || 1 != User.shared().multiple_rummy_open && 1 != User.shared().multiple_2_open) {
                    if (t == HowToPlayDefined.RUMMY_DEALS) {
                        if (o) {
                            return false;
                        }
                        if (0 == e) {
                            n = e + 1;
                        }
                        else if (2 == e) {
                            return false;
                        }
                    }
                    else {
                        if (t == HowToPlayDefined.RUMMY_MULTIPLE) {
                            return false;
                        }
                        m = t + 1;
                    }
                }
                else if (t == HowToPlayDefined.RUMMY_MULTIPLE) {
                    if (o) {
                        return false;
                    }
                    if (0 == e) {
                        n = e + 1;
                    }
                    else if (2 == e) {
                        return false;
                    }
                }
                else {
                    m = t == HowToPlayDefined.RUMMY_DEALS ? HowToPlayDefined.RUMMY_MULTIPLE : t + 1;
                }
                return void this.setInitGameType(n, m, i, s, a, o, l, h);
            }
            {
                this.updateGameType(e, o);
                this.updateRummyType(t);
                let y = this.getSelectRoomList(n[i], m[s], r[a], l, d[h]);
                if (null == y || 0 == y.length) {
                    if (t == HowToPlayDefined.RUMMY_POINTS) {
                        if (1 == i && h >= d.length) {
                            return false;
                        }
                        h == d.length ? (i += 1, h = 0) : h += 1;
                    }
                    else if (t == HowToPlayDefined.RUMMY_POOL) {
                        if (1 == i && 1 == s) {
                            return false;
                        }
                        1 == s ? (i += 1, s = 0) : s += 1;
                    }
                    else {
                        if (t == HowToPlayDefined.RUMMY_MULTIPLE) {
                            return false;
                        }
                        if (1 == i && 2 == a) {
                            return false;
                        }
                        2 == a ? (i += 1, a = 0) : a += 1;
                    }
                    return this.setInitGameType(e, t, i, s, a, o, l, h), true;
                }
                {
                    let e = this.roomInfoNode.getChildByName("player_select"), t = this.roomInfoNode.getChildByName("mode_select"), o = this.roomInfoNode.getChildByName("pool_select"), l = this.roomInfoNode.getChildByName("deals_select");
                    this.rummyType == HowToPlayDefined.RUMMY_MULTIPLE ? this.updateBtnSwitchState(e, 1, 4, n[1]) : this.updateBtnSwitchState(e, i, 0, n[i]);
                    this.updateBtnSwitchState(t, d[h], 3, d[h]);
                    this.updateBtnSwitchState(o, s, 1, m[s]);
                    1 == i ? this.updateBtnSwitchState(l, a - 1, 2, r[a]) : this.updateBtnSwitchState(l, a, 2, r[a]);
                    this.updateDealsState();
                    this.updateSelectPlayer2();
                }
            }
        }
        return true;
    }
    fastBuyCallback(e) {
        if (1 == e) {
            User.shared().checkFastBuy() ? User.shared().showFastShop(false, this.cur_vid, 0, this._min_entry) : User.shared().showBlindAlert(0, 0);
        }
        else if (2 == e) {
            User.shared().checkFastBuy() ? User.shared().showFastShop(true, User.shared().gameRummyType) : User.shared().showBlindAlert(0, 0);
        }
    }
    setLandscapeShow() {
        ToolUtils.getOrientation() || this.node.setRotationFromEuler(v3(0, 0, -90));
    }
    refreshRankStar() {
        let e = false, t = 1;
        if (0 == this.gameType) {
            if (2 == User.shared().act_116_not_recommend_show) {
                if (this.vCurRoomList && this.vCurRoomList[this.nIdx]) {
                    let i = this.vCurRoomList[this.nIdx];
                    if (sys.isObjectValid(i) && i.vid) {
                        let s = i.vid;
                        sys.isObjectValid(User.shared().act_116_not_recommend_list) && Array.isArray(User.shared().act_116_not_recommend_list) && -1 === User.shared().act_116_not_recommend_list.indexOf(String(s)) && (e = true, t = 5);
                    }
                }
            }
            else {
                1 == User.shared().act_116_not_recommend_show ? (e = true, t = 5) : 0 == User.shared().act_116_not_recommend_show && (e = false, t = 1);
            }
        }
        this.sliderStarNode.getParent().getComponent(Sprite).spriteFrame = e ? this.rankStarFrame[t] : this.rankStarFrame[0];
    }
}
