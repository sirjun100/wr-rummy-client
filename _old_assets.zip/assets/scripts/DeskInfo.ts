// @ts-nocheck
// Recovered from index.js:101
import { _decorator, Component } from "cc";
const { ccclass } = _decorator;
@ccclass("DeskInfo")
export class DeskInfo extends Component {
    public tid_key: string = "";
    public vid: number = 0;
    public venuetype: number = 2;
    public status: number = 1;
    public game_type: number = 0;
    public pnum: number = 0;
    public base_money: number = 0;
    public round: number = 1;
    public currentRound: number = 1;
    public mode: number = 0;
    public special_mode: number = 0;
    public match_mode: any = -1;
    public is_double: number = 0;
    start() {
    }
}
