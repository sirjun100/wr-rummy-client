// @ts-nocheck
// Recovered from index.js:369
import { _decorator, director, instantiate, Label, Node, sys } from "cc";
import BaseLayer from "./BaseLayer";
import SoundManager from "./SoundManager";
import Utils from "./Utils";
import PushCenter from "./PushCenter";
import PushEvent from "./PushEvent";
import { TLog } from "./TLog";
import User from "./User";
import TweenTool from "./TweenTool";
import GameConfig from "./GameConfig";
import { ToolUtils } from "./ToolUtils";
import BundleNameDefined from "./BundleNameDefined";
const { ccclass, property } = _decorator;
@ccclass("RankingsPopAct")
export class RankingsPopAct extends BaseLayer {
    public TAG: string = "RankingsPopAct";
    @property(Node)
    public rootNode: Node = null;
    public isNext: boolean = false;
    public _data: any = null;
    initParaData(t) {
        sys.isObjectValid(t) && (this._data = t, sys.isObjectValid(t.isNext) && (this.isNext = t.isNext));
    }
    onLoad() {
    }
    start() {
        super.start();
        ToolUtils.showFullScreen(this.node.getChildByName("mask"));
        this.startShowAnim(this.rootNode);
        this.refreshView();
    }
    refreshView() {
        if (sys.isObjectValid(this._data) && sys.isObjectValid(this._data.time_str) && (this.rootNode.getChildByName("date").getComponent(Label).string = this._data.time_str), sys.isObjectValid(this._data) && sys.isObjectValid(this._data.total_reward)) {
            let t = this._data.total_reward;
            -1 != String(this._data.total_reward).indexOf("₹") && (t = String(this._data.total_reward).split("₹")[1]);
            this.rootNode.getChildByName("reward_node").getChildByName("total_reward").getComponent(Label).string = t;
            this.rootNode.getChildByName("tip").getComponent(Label).string = `Challenge Rummy's ranking and divide the ${t} prize!`;
        }
        if (sys.isObjectValid(this._data) && sys.isObjectValid(this._data.entry_status) && (this.rootNode.getChildByName("optin_btn").active = 0 == this._data.entry_status, this.rootNode.getChildByName("playnow_btn").active = 1 == this._data.entry_status), sys.isObjectValid(this._data) && sys.isObjectValid(this._data.mega_rank) && Array.isArray(this._data.mega_rank) && this._data.mega_rank.length >= 3) {
            for (let t = 0; t < 3; t++) {
                this.rootNode.getChildByName("reward" + t).getComponent(Label).string = "₹" + this._data.mega_rank[t].bmoney;
            }
        }
    }
    onButtonClick(t, e) {
        SoundManager.shared().playFx("click");
        "close" == e ? this.onBackView() : "details" == e ? (0 == GameConfig.GAME_HALL_THEME ? PushCenter.shared().pushEvent(GameConfig.Jump_Hall_Tab_View, "1") : PushCenter.shared().pushEvent(PushEvent.Show_Challenge), this.onBackView()) : "playnow" == e ? this.onBackView() : "optin" == e && this.dealOptInLogic();
    }
    dealOptInLogic() {
        let t = { auto_entry_status: this._data.auto_entry_status, status: this._data.entry_status, total_reward_num: this._data.total_reward_num, jump_info: this._data.jump_info };
        ToolUtils.loadCommonPrefab(null, BundleNameDefined.Bundle_leaderBoards, "prefab/rankings_optin", (e => {
            try {
                let a = instantiate(e);
                director.getScene().getChildByName("Canvas").addChild(a);
                a.getComponent("RankingsOptIn").initParaData(t, (t => {
                    this._data.entry_status = t;
                    sys.isObjectValid(this._data) && sys.isObjectValid(this._data.entry_status) && (this.rootNode.getChildByName("optin_btn").active = 0 == this._data.entry_status, this.rootNode.getChildByName("playnow_btn").active = 1 == this._data.entry_status);
                    User.shared().getHallInfo();
                }));
            }
            catch (t) {
                TLog.printError("dealOptInLogic err:", t);
            }
        }));
    }
    onDestroy() {
        super.onDestroy();
        TweenTool.stopNodeAction(this.node);
        PushCenter.shared().removeListenersByTag(this);
        Utils.shared().hideLoading();
    }
    onBackView() {
        ToolUtils.isObjValid(this.node) && (this.isNext && PushCenter.shared().pushEvent(PushEvent.Update_NextPopActivity), this.node.destroy());
    }
}
