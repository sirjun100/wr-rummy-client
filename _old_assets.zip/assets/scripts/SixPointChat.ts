// @ts-nocheck
// Recovered from index.js:525
import { _decorator, sys } from "cc";
import Parent from "./Parent";
import PushCenter from "./PushCenter";
import SoundManager from "./SoundManager";
const { ccclass } = _decorator;
@ccclass("SixPointChat")
export default class SixPointChat extends Parent {
    public _TAG: string = "SixPointChat";
    public lastClick: number = 0;
    public gameCallback: any = null;
    onLoad() {
    }
    onDestroy() {
        super.onDestroy();
        this.unscheduleAllCallbacks();
        PushCenter.shared().removeListenersByTag(this);
    }
    start() {
        this.initView();
        this.addPushNotify();
    }
    setCallBack(t) {
        this.gameCallback = t;
    }
    addPushNotify() {
    }
    initView() {
    }
    touchBtnEvent(t, s) {
        SoundManager.shared().playFx("click");
        sys.now() - this.lastClick < 200 || (this.lastClick = sys.now(), sys.isObjectValid(this.gameCallback) && this.gameCallback(s));
    }
}
