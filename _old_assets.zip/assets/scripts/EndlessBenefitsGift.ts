// @ts-nocheck
// Recovered from index.js:111
import { _decorator, director, Label, LabelShadow, Node, Sprite, SpriteFrame, sys, v3, Vec3 } from "cc";
import BaseLayer from "./BaseLayer";
import PushCenter from "./PushCenter";
import TweenTool from "./TweenTool";
import { TransferPlatform } from "./TransferPlatform";
import PushEvent from "./PushEvent";
import Utils from "./Utils";
import SoundManager from "./SoundManager";
import User from "./User";
import i18nMgr from "./i18nMgr";
import BundleNameDefined from "./BundleNameDefined";
import CommDefine from "./CommDefine";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("EndlessBenefitsGift")
export class EndlessBenefitsGift extends BaseLayer {
    public TAG: string = "EndlessBenefitsGift";
    @property(Node)
    public rootNode: Node = null;
    @property(Node)
    public mainNode: Node = null;
    @property(Node)
    public maskNode: Node = null;
    @property(Label)
    public leftTimeLabel: Label = null;
    @property(Node)
    public extra: Node = null;
    @property(Node)
    public dayScroll: Node = null;
    @property(Node)
    public dayScrollContent: Node = null;
    @property([SpriteFrame])
    public addCashBtnBg: SpriteFrame[] = [];
    public rechargeNode: any[] = [];
    public isNext: boolean = false;
    public isquick: boolean = false;
    public _nVid: number = 0;
    public _bStartCountDown: boolean = false;
    public _nCountcd: any = -1;
    public _linkId: number = 0;
    public _reportScene: any = -1;
    public _pop_souce: number = 0;
    public _has_close: boolean = false;
    public _flag: number = 0;
    public _mPara: any[] = [];
    public checkKyc: number = 0;
    public rechragePos: any[] = [];
    public _finishAnim: boolean = false;
    public _consecutivegiftData: any = null;
    initParaData(e, t = 0) {
        this._mPara = e;
        this.isNext = e.isNext;
        sys.isObjectValid(e.vid) ? this._nVid = e.vid : this._nVid = ToolUtils.curRoomId;
        sys.isObjectValid(e.isquick) && (this.isquick = e.isquick);
        sys.isObjectValid(e.flag) && (this._flag = e.flag);
        sys.isObjectValid(e.checkKyc) && (this.checkKyc = e.checkKyc);
        sys.isObjectValid(e) && sys.isObjectValid(e.pop_souce) && (this._pop_souce = e.pop_souce);
        sys.isObjectValid(e) && sys.isObjectValid(e.reportScene) && (this._reportScene = e.reportScene);
        sys.isObjectValid(e) && sys.isObjectValid(e.link_id) && e.link_id > 0 && (this._linkId = e.link_id);
        sys.isObjectValid(e.ext) && e.ext && Object.keys(e.ext).length && (this._consecutivegiftData = e.ext);
    }
    start() {
        super.start();
        this._linkId = this._linkId > 0 ? this._linkId : sys.now();
        this._reportScene = this._reportScene >= 0 ? this._reportScene : ToolUtils.getIsInRoom() ? 2 : 1;
        for (let e, t = 0; t < 7; t++) {
            if (e = this.dayScrollContent.getChildByName("dayItem" + t), ToolUtils.isObjValid(e)) {
                this.rechargeNode[t] = e;
                let i = new Vec3;
                this.rechargeNode[t].getPosition(i);
                this.rechragePos.push(i);
            }
        }
        if (ToolUtils.showFullScreen(this.maskNode), sys.isObjectValid(this._consecutivegiftData) && this._consecutivegiftData && this.refreshView(), sys.isObjectValid(this._mPara.vid) && 0 != Number(this._mPara.vid) && sys.isObjectValid(this._consecutivegiftData) || User.shared().requestConsecutiveGiftPageData((e => {
            ToolUtils.isObjValid(this.node) && sys.isObjectValid(e) && e && Object.keys(e).length && (this._consecutivegiftData = e, this.refreshView());
        })), PushCenter.shared().addListener(PushEvent.UpdateConsecutiveGift, (e => {
            ToolUtils.isObjValid(this.node) && e && (this._consecutivegiftData = e, this.refreshView());
        }), this), PushCenter.shared().addListener(PushEvent.CloseConsecutiveGift, (e => {
            ToolUtils.isObjValid(this.node) && (this.isNext && PushCenter.shared().pushEvent(PushEvent.Update_NextPopActivity), this.node.destroy());
        }), this), PushCenter.shared().pushEvent(PushEvent.HideGameOverBg), TweenTool.commonSchedule(this.node, 1, this.scheduleCallBack.bind(this)), director.getScene().name == BundleNameDefined.hall_scene) {
            for (let e = 0, t = this.rechargeNode.length; e < t; e++) {
                this.rechargeNode[e].active = false;
            }
        }
        this._finishAnim = false;
        this.startShowAnim(this.rootNode, (() => {
            if (director.getScene().name == BundleNameDefined.hall_scene && this._consecutivegiftData) {
                for (let e = 0, t = this.rechargeNode.length; e < t; e++) {
                    TweenTool.stopNodeAction(this.rechargeNode[e]);
                    this.rechargeNode[e].setPosition(v3(this.rechragePos[e].x + 660, this.rechragePos[e].y));
                    let t = TweenTool.delayAct(this.rechargeNode[e], (() => {
                        this._finishAnim = true;
                        sys.isObjectValid(this._consecutivegiftData.good_list) && this._consecutivegiftData.good_list && Array.isArray(this._consecutivegiftData.good_list) && sys.isObjectValid(this._consecutivegiftData.good_list[e]) && this._consecutivegiftData.good_list[e] && (this.rechargeNode[e].active = true);
                    }), 0.04 * e, false), i = TweenTool.moveToByFade(this.rechargeNode[e], 0.15, v3(this.rechragePos[e].x - 20, this.rechragePos[e].y), 0, 1, false), s = TweenTool.moveTo(this.rechargeNode[e], 0.1, v3(this.rechragePos[e].x + 15, this.rechragePos[e].y), null, false), a = TweenTool.moveTo(this.rechargeNode[e], 0.06, v3(this.rechragePos[e].x, this.rechragePos[e].y), null, false);
                    TweenTool.sequence(this.rechargeNode[e], true, (() => {
                    }), t, i, s, a);
                }
            }
        }));
        SoundManager.shared().playFx("act_popshow");
    }
    refreshView() {
        sys.isObjectValid(this._consecutivegiftData) && this._consecutivegiftData && (sys.isObjectValid(this._consecutivegiftData.time_left) && this.startLeftTime(Number(this._consecutivegiftData.time_left)), sys.isObjectValid(this._consecutivegiftData.extra) && this._consecutivegiftData.extra ? (this.extra.active = true, this.extra.getComponent(Label).string = ToolUtils.format(i18nMgr.shared().getValueByKey("consecutivegift.extra"), this._consecutivegiftData.extra)) : this.extra.active = false, sys.isObjectValid(this._consecutivegiftData.good_list) && this._consecutivegiftData.good_list && Array.isArray(this._consecutivegiftData.good_list) && this.updateDayScrollView(this._consecutivegiftData.good_list));
    }
    updateDayScrollView(e) {
        if (sys.isObjectValid(this.rechargeNode) && Array.isArray(this.rechargeNode), sys.isObjectValid(e) && e && Array.isArray(e)) {
            for (let t = 0, i = this.rechargeNode.length; t < i; t++) {
                if (sys.isObjectValid(e) && sys.isObjectValid(e[t])) {
                    let i = e[t];
                    this.rechargeNode[t].active = !!this._finishAnim;
                    this.initDayItemView(this.rechargeNode[t], i);
                }
                else {
                    this.rechargeNode[t].active = false;
                }
            }
        }
    }
    initDayItemView(e, t) {
        if (!e || !t) {
            return;
        }
        let i = e.getChildByName("day"), s = e.getChildByName("add_bg"), a = e.getChildByName("add_value"), r = e.getChildByName("rewlayout"), c = e.getChildByName("btn_addcash"), h = e.getChildByName("btn_purchased"), l = r.getChildByName("rewcash"), d = r.getChildByName("rewbonus"), f = c.getChildByName("price"), _ = c.getChildByName("lock");
        if (i.getComponent(Label).string = "DAY " + t.day, sys.isObjectValid(t.ratio) && t.ratio ? (s.active = a.active = true, a.getComponent(Label).string = "" + t.ratio) : s.active = a.active = false, sys.isObjectValid(t.cash) && t.cash ? (l.active = true, l.getChildByName("num").getComponent(Label).string = t.cash || "") : l.active = false, sys.isObjectValid(t.bonus) && t.bonus ? (d.active = true, d.getChildByName("num").getComponent(Label).string = t.bonus || "") : d.active = false, c.active = h.active = _.active = false, sys.isObjectValid(t.price) && t.price ? f.getComponent(Label).string = "₹" + t.price : f.getComponent(Label).string = "", sys.isObjectValid(t.state)) {
            switch (ToolUtils.isSafeNumber(t.state)) {
                case 1:
                    c.active = true, h.active = false, Utils.updateLabelMaterial(f, CommDefine.gradient.btn_green), f.getComponent(LabelShadow).color = CommDefine.shadowcolor.green, c.getComponent(Sprite).spriteFrame = this.addCashBtnBg[0];
                    break;
                case 2:
                    _.active = true, c.active = true, h.active = false, Utils.updateLabelMaterial(f, CommDefine.gradient.btn_blue), f.getComponent(LabelShadow).color = CommDefine.shadowcolor.blue, c.getComponent(Sprite).spriteFrame = this.addCashBtnBg[1];
                    break;
                case 3:
                    c.active = false, h.active = true;
                    break;
                default: c.active = h.active = false;
            }
        }
    }
    startLeftTime(e) {
        let t = i18nMgr.shared().getValueByKey("consecutivegift.left_time");
        if (Number.isNaN(e) || e <= 0) {
            return User.shared().getHallInfo(), void (this.leftTimeLabel.string = "");
        }
        this._bStartCountDown = true;
        this._nCountcd = e;
        t = ToolUtils.format("${0} ${1}", t, Utils.shared().parseCountDown(this._nCountcd));
        this.leftTimeLabel.string = t;
        i18nMgr.shared().changeLabelFont(this.leftTimeLabel, false);
    }
    scheduleCallBack() {
        if (sys.isObjectValid(this._consecutivegiftData) && this._consecutivegiftData && this._bStartCountDown) {
            if (this._nCountcd -= 1, this._consecutivegiftData.time_left = this._nCountcd, this._nCountcd < 0) {
                return this._consecutivegiftData.time_left = -1, User.shared().getHallInfo(), void this.onBackView();
            }
            this.leftTimeLabel.string = ToolUtils.format("${0} ${1}", i18nMgr.shared().getValueByKey("consecutivegift.left_time"), Utils.shared().parseCountDown(this._nCountcd));
        }
    }
    onButtonClick(e, t) {
        if (SoundManager.shared().playFx("click"), "close" == t) {
            if (1 == Utils.shared().checkPopRestartGift(this._mPara)) {
                return void this.onBackView();
            }
            1 == this.checkKyc && Utils.shared().checkAddCashKyc();
            this.onBackView();
        }
    }
    onBtnAddCashClick(e, t) {
        SoundManager.shared().playFx("click");
        let i = Number(t);
        if (i >= 0 && sys.isObjectValid(this._consecutivegiftData) && this._consecutivegiftData && sys.isObjectValid(this._consecutivegiftData.good_list) && this._consecutivegiftData.good_list && Array.isArray(this._consecutivegiftData.good_list)) {
            if (i >= this._consecutivegiftData.good_list.length) {
                return;
            }
            let e = this._consecutivegiftData.good_list[i];
            if (e && sys.isObjectValid(e.state) && e.state) {
                if (1 == e.state) {
                    if (ToolUtils.isObjValid(this.node)) {
                        if (!User.shared().checkCanRecharge()) {
                            return void this.node.destroy();
                        }
                        if (!sys.isObjectValid(this._consecutivegiftData.act_num)) {
                            return;
                        }
                        let t = { pway: this._consecutivegiftData.pways + "", act_num: this._consecutivegiftData.act_num, day: e.day, price: e.price, goodsId: e.good_id, link_id: this._linkId, act_id: PushEvent.JUMP_TO_ConsecutiveGift };
                        User.shared().startPay(t);
                    }
                }
                else {
                    2 == e.state && Utils.shared().showToast(i18nMgr.shared().getValueByKey("consecutivegift.not_recharge_tips"), 2);
                }
            }
        }
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().pushEvent(PushEvent.ShowGameOverBg);
        PushCenter.shared().removeListenersByTag(this);
        TweenTool.stopNodeAction(this.node);
        this.unscheduleAllCallbacks();
    }
    onEnable() {
        TransferPlatform.shared().setNormalFrameRate();
    }
    onBackView() {
        if (ToolUtils.isObjValid(this.node)) {
            if (this._has_close) {
                return;
            }
            this._has_close = true;
            let e = { alert_node: this.node, rootNode: this.rootNode, isNext: this.isNext, pop_type: PushEvent.JUMP_TO_ConsecutiveGift, pop_souce: this._pop_souce };
            Utils.shared().closeActivityView(e);
        }
    }
}
