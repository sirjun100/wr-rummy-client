// @ts-nocheck
import { native, sys } from "cc";

const JAVA_CLASS = "com/lucky/rummy/H5GamePackages";
const pending = new Map();

function reconcileInstalledDownloads(): void {
    // Android may finish installing while the game-thread completion event is
    // delayed or lost. The verified marker is authoritative in that case.
    for (const [gameId, task] of pending) {
        const index = installedH5Index(gameId, task.sha256);
        if (!index) continue;
        pending.delete(gameId);
        task.progress = 1;
        for (const listener of task.listeners) listener(1);
        task.resolve(index);
    }
}

export function supportsH5Packages(): boolean {
    return sys.isNative && sys.os === sys.OS.ANDROID;
}

export function installedH5Index(gameId: string, sha256: string): string {
    if (!supportsH5Packages() || !/^[a-z0-9_-]{1,32}$/.test(gameId) || !/^[a-f0-9]{64}$/.test(sha256)) return "";
    try {
        return native.reflection.callStaticMethod(JAVA_CLASS, "installedIndex", "(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;", gameId, sha256) || "";
    } catch (_) {
        return "";
    }
}

export function prepareH5LocalWebView(): boolean {
    if (!supportsH5Packages()) return false;
    try { return !!native.reflection.callStaticMethod(JAVA_CLASS, "prepareLocalWebView", "()Z"); }
    catch (_) { return false; }
}

window.__h5GamePackageEvent = (event) => {
    if (!event || typeof event.game_id !== "string") return;
    const task = pending.get(event.game_id);
    if (!task) return;
    if (event.state === "progress") {
        const value = Math.max(0, Math.min(1, Number(event.progress) / 100 || 0));
        task.progress = value;
        for (const listener of task.listeners) listener(value);
    } else if (event.state === "done") {
        task.progress = 1;
        for (const listener of task.listeners) listener(1);
        pending.delete(event.game_id);
        const index = installedH5Index(event.game_id, task.sha256);
        index ? task.resolve(index) : task.reject(new Error("H5 package verification failed"));
    } else if (event.state === "error") {
        pending.delete(event.game_id);
        task.reject(new Error("H5 package download failed"));
    }
};

export function downloadH5Package(gameId: string, url: string, sha256: string, onProgress: (value: number) => void): Promise<string> {
    const installed = installedH5Index(gameId, sha256);
    if (installed) return Promise.resolve(installed);
    if (!supportsH5Packages() || !/^https:\/\/[^/]+/i.test(url) || !/^[a-f0-9]{64}$/.test(sha256)) {
        return Promise.reject(new Error("H5 package unavailable"));
    }
    reconcileInstalledDownloads();
    const existing = pending.get(gameId);
    if (existing) {
        if (existing.sha256 !== sha256) return Promise.reject(new Error("H5 package version changed during download"));
        existing.listeners.push(onProgress);
        onProgress(existing.progress);
        return existing.promise;
    }
    let resolve, reject;
    const promise = new Promise<string>((done, fail) => { resolve = done; reject = fail; });
    pending.set(gameId, { promise, sha256, progress: 0, listeners: [onProgress], resolve, reject });
    try {
        native.reflection.callStaticMethod(JAVA_CLASS, "download", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V", gameId, url, sha256);
    } catch (error) {
        pending.delete(gameId);
        reject(error);
    }
    return promise;
}

export function localH5LaunchURL(remoteURL: string, localIndex: string): string {
    if (!/^file:\/\//.test(localIndex) || !/^https:\/\//.test(remoteURL)) throw new Error("Unsafe H5 launch URL");
    // Cocos JSB does not consistently expose the browser URL constructor.
    // Preserve the server-issued query and one-time ticket fragment verbatim.
    const match = /^https:\/\/[^/?#]+\/[^?#]*(\?[^#]*)?(#.*)?$/.exec(remoteURL);
    if (!match) throw new Error("Unsafe H5 launch URL");
    return localIndex + (match[1] || "") + (match[2] || "");
}
