// @ts-nocheck
// Recovered from index.js:213
import { _decorator, Label, Node, Sprite, SpriteFrame, sys } from "cc";
import SoundManager from "./SoundManager";
import Utils from "./Utils";
import BaseLayer from "./BaseLayer";
import User from "./User";
import PushEvent from "./PushEvent";
import i18nMgr from "./i18nMgr";
import CommDefine from "./CommDefine";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("KycLimitTip")
export class KycLimitTip extends BaseLayer {
    @property(Node)
    public rootNode_hall: Node = null;
    @property(Node)
    public rootNode_game: Node = null;
    @property([SpriteFrame])
    public bgImgs: SpriteFrame[] = [];
    public rootNode: any = null;
    public is_pan: number = 0;
    onLoad() {
        let t = this.node.getChildByName("mask");
        ToolUtils.showFullScreen(t);
    }
    init(t) {
        sys.isObjectValid(t) && sys.isObjectValid(t.is_pan) && (this.is_pan = t.is_pan);
    }
    start() {
        super.start();
        this.rootNode = this.rootNode_hall;
        ToolUtils.judgeIfInHall() ? (this.rootNode_hall.active = true, this.rootNode_game.active = false, this.rootNode = this.rootNode_hall, this.rootNode.getChildByName("bgView").getComponent(Sprite).spriteFrame = this.bgImgs[this.is_pan]) : (this.rootNode_hall.active = false, this.rootNode_game.active = true, this.rootNode = this.rootNode_game);
        this.startShowAnim(this.rootNode);
        this.updateRewardList();
        this.updateLeftDate();
    }
    updateRewardList() {
        let t = User.shared().data.kyc_list;
        if (sys.isObjectValid(t) && Array.isArray(t) && t.length > 0) {
            for (let e = 0; e < t.length; e++) {
                let i = 2;
                if (1 == this.is_pan && (i = 3), ToolUtils.isSafeNumber(t[e].type) == i) {
                    let i = 0, o = 0, s = "kyc.kyc_top_tip";
                    if (1 == this.is_pan && (s = "kyc.pan_top_tip"), sys.isObjectValid(t[e].cash) && (i = Number(t[e].cash)), sys.isObjectValid(t[e].bonus) && (o = Number(t[e].bonus)), i > 0 && o > 0) {
                        let t = ToolUtils.format(i18nMgr.shared().getValueByKey(s), "₹" + String(i + o) + "*");
                        this.rootNode.getChildByName("top_tip").getComponent(Label).string = t;
                    }
                    else if (i > 0) {
                        let t = ToolUtils.format(i18nMgr.shared().getValueByKey(s), "CASH ₹" + String(i));
                        this.rootNode.getChildByName("top_tip").getComponent(Label).string = t;
                    }
                    else if (o > 0) {
                        let t = ToolUtils.format(i18nMgr.shared().getValueByKey(s), "BONUS ₹" + String(o));
                        this.rootNode.getChildByName("top_tip").getComponent(Label).string = t;
                    }
                    break;
                }
            }
        }
        1 == this.is_pan && (this.rootNode.getChildByName("waitingNode").getChildByName("title").getComponent(Label).string = i18nMgr.shared().getValueByKey("kyc.pan_limit_title"));
    }
    updateLeftDate() {
        let t = 0;
        1 == this.is_pan ? sys.isObjectValid(User.shared().data.pan_submit_left_hour) && (t = Number(User.shared().data.pan_submit_left_hour)) : sys.isObjectValid(User.shared().data.submit_left_hour) && (t = Number(User.shared().data.submit_left_hour));
        let e = Math.ceil((t - sys.now() / 1000) / 3600), i = ToolUtils.format(i18nMgr.shared().getValueByKey("kyc.kyc_limit_tip"), e);
        this.rootNode.getChildByName("waitingNode").getChildByName("sub_tips").getComponent(Label).string = i;
    }
    onButtonClick(t, e) {
        if (SoundManager.shared().playFx("click"), "back" == e || "close" == e) {
            this.onCloseLogic();
        }
        else if ("feedback" == e) {
            Utils.shared().doJumpLogic(PushEvent.JUMP_TO_FEEDBACK);
        }
        else if ("kefu" == e) {
            if (1 == User.shared().temp_pingbi.feedback) {
                return void Utils.shared().showToast("Coming soon", 2);
            }
            let t = { sourceType: CommDefine.TawkUser_Feedback_Source.Kyc, groupType: CommDefine.TawkUser_Feedback_Source.Kyc_Group.Limit };
            Utils.shared().doJumpLogic(PushEvent.JUMP_TO_FEEDBACK, t);
        }
    }
    onCloseLogic() {
        this.onRemoveWindow();
    }
    onRemoveWindow() {
        ToolUtils.isObjValid(this.node) && this.node.destroy();
    }
    onBackView() {
        this.onCloseLogic();
    }
}
