// @ts-nocheck
// Recovered from index.js:487
import { _decorator, color, director, instantiate, Label, size, Sprite, sys, tween, UITransform, v3, Vec3 } from "cc";
import RummyDataManager, { RUMMY_GAME_TYPE, RUMMY_MATCH_MODE, RUMMY_MATCH_TYPE } from "./RummyDataManager";
import User from "./User";
import CommDefine from "./CommDefine";
import { TLog } from "./TLog";
import Utils from "./Utils";
import TweenTool from "./TweenTool";
import SoundManager from "./SoundManager";
import RummyGamePoolPop from "./RummyGamePoolPop";
import RummyGamePoolRecord from "./RummyGamePoolRecord";
import RummyGameDealsRecord from "./RummyGameDealsRecord";
import i18nMgr from "./i18nMgr";
import RummyGameManualSplit from "./RummyGameManualSplit";
import { RummyGamePoolRejoin } from "./RummyGamePoolRejoin";
import { RummyNewPlayerGuide } from "./RummyNewPlayerGuide";
import GameRummy_switch_notice from "./GameRummy_switch_notice";
import BundleNameDefined from "./BundleNameDefined";
import HttpManager from "./HttpManager";
import RummyOpenCardsAlert from "./RummyOpenCardsAlert";
import { AdapDirection } from "./Parent";
import RummyBumpSwitchAlert from "./RummyBumpSwitchAlert";
import { ToolUtils } from "./ToolUtils";
import GameConfig from "./GameConfig";
const { ccclass } = _decorator;
@ccclass("RummyShowTopUiLogic")
export default class RummyShowTopUiLogic {
    public mainRummy: any = null;
    private historyLoadToken: any = null;
    private pendingHistoryData: any = null;
    private recordLoadGeneration: number = 0;
    private recordRequestPending: boolean = false;
    public show_pureseq_tips: number = 0;
    public show_seq_tips: number = 0;
    public show_total_score_tips: number = 0;
    public match_base_money: number = 0;
    init(e) {
        this.mainRummy = e;
    }
    reset() {
        this.show_pureseq_tips = 0;
        this.show_seq_tips = 0;
        this.show_total_score_tips = 0;
    }
    loadDailyTaskBubble(e, i = 1, t = null) {
        if (1 === User.shared().daily_task && 0 === User.shared().temp_pingbi.dailytask && this.mainRummy.tid_key !== CommDefine.NewerGuideRoomTidkey) {
            let a = { sceneStr: RummyDataManager.shared().reportClickTaskBtn(this.mainRummy.tid_key, 1), vid: RummyDataManager.shared().rummyInfos.has(this.mainRummy.tid_key) ? RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key).vid : 0, bubble_type: i, taskData: t, tid_key: this.mainRummy.tid_key };
            this.showRoomDailyTaskBubble(this.mainRummy.pop_layer6, e, a);
        }
    }
    showRoomDailyTaskBubble(e, i, a = null) {
        try {
            if (sys.isObjectValid(RummyDataManager.shared().dailyTaskBubblePrefab) && RummyDataManager.shared().dailyTaskBubblePrefab.isValid) {
                ToolUtils.isObjValid(e) && i && this.showDailyTaskBubble(RummyDataManager.shared().dailyTaskBubblePrefab, e, a);
            }
            else if (window.InSwitchScene) {
                return void TLog.printError("-------- showRoomDailyTaskBubble switchScene stop preload res.");
            }
        }
        catch (e) {
            TLog.printError("Hall showDailyGuide err:", e);
        }
    }
    showDailyTaskBubble(e, i, m = null) {
        let s = sys.isObjectValid(m.bubble_type) ? m.bubble_type : 1, n = m.taskData;
        try {
            let o = i.getChildByName("RummyDailyTaskBubble");
            if (!ToolUtils.isObjValid(o)) {
                let i = instantiate(e);
                i.name = "RummyDailyTaskBubble";
                o = i;
            }
            let r = m.sceneStr, l = m.vid, h = {};
            if (h.vid = l, h.bubble_type = s, h.taskData = n, h.tid_key = m.tid_key, 1 == User.shared().showNewDailyTask || 1 == User.shared().showBackTask) {
                let e = o.getComponent("RummyNewDailyTaskBubble");
                e && sys.isObjectValid(e) ? (i.addChild(o), e.sceneStr = r, e.initTask(h)) : TLog.printError("Utils showDailyTaskBubble  no RummyNewDailyTaskBubble");
            }
        }
        catch (e) {
            TLog.printError("Utils showDailyTaskBubble error= :" + e);
        }
    }
    showFirstRecharge_game(e = false, i) {
    }
    showFirstRecharge_game2(e) {
        0 !== User.shared().charge_open && window.InSwitchScene && TLog.printError("-------- showFirstRecharge_game2 switchScene stop preload res.");
    }
    showMatchRebuy(e) {
        if (window.InSwitchScene) {
            return void TLog.printError("-------- showMatchRebuy switchScene stop preload res.");
        }
        let i = e.reload, m = e.money, s = e.cd;
        try {
            if (ToolUtils.isObjValid(this.mainRummy.pop_layer4)) {
                let e = this.mainRummy.pop_layer4.getChildByName("match_game_rebuy");
                ToolUtils.isObjValid(e) && e.destroy();
                ToolUtils.loadCommonPrefab(null, BundleNameDefined.bundle_rummyTopUI, "prefab/match_game_rebuy", (n => {
                    if (sys.isObjectValid(n) && n.isValid && sys.isObjectValid(this.mainRummy) && ToolUtils.isObjValid(this.mainRummy.pop_layer4)) {
                        e = instantiate(n);
                        e.name = "match_game_rebuy";
                        e.parent = this.mainRummy.pop_layer4;
                        let t = e.getComponent("RummyMatchRebuy");
                        t.setTidKey(this.mainRummy.tid_key);
                        t.setParaData(RummyDataManager.shared().sceneNode, m, i, s, (e => {
                            "close" == e ? this.mainRummy.handler_user_rebuy_request(0) : this.mainRummy.handler_user_rebuy_request(1);
                        }));
                    }
                }));
            }
        }
        catch (e) {
            TLog.printError("trycatch handler_server_notify_user_rebuy_return,error:", e);
        }
    }
    updateMatchRebuy(e, i) {
        let t = this.mainRummy.pop_layer4.getChildByName("match_game_rebuy");
        if (ToolUtils.isObjValid(t)) {
            t.getComponent("RummyMatchRebuy").updateMatchRebuy(e, i);
        }
    }
    showMatchTipsAnim(e) {
        if (window.InSwitchScene) {
            TLog.printError("-------- showMatchTipsAnim switchScene stop preload res.");
        }
        else {
            try {
                let i = this.mainRummy.pop_layer4.getChildByName("match_game_wait");
                ToolUtils.isObjValid(i) && i.active && (i.active = false);
                let m = this.mainRummy.pop_layer4.getChildByName("match_game_tips");
                if (ToolUtils.isObjValid(m)) {
                    m.active = true;
                    m.getComponent("RummyMatchTips").showGameStatusAnim(RummyDataManager.shared().sceneNode, e);
                    0 == e && this.mainRummy.playEffectByName("match_start");
                }
                else {
                    ToolUtils.loadCommonPrefab(null, BundleNameDefined.bundle_rummyTopUI, "prefab/match_game_tips", (s => {
                        if (sys.isObjectValid(s) && s.isValid && sys.isObjectValid(this.mainRummy) && ToolUtils.isObjValid(this.mainRummy.pop_layer4)) {
                            ToolUtils.isObjValid(i) && i.active && (i.active = false);
                            m = instantiate(s);
                            m.name = "match_game_tips";
                            m.parent = this.mainRummy.pop_layer4;
                            m.setSiblingIndex(50);
                            m.getComponent("RummyMatchTips").showGameStatusAnim(RummyDataManager.shared().sceneNode, e);
                            0 == e && this.mainRummy.playEffectByName("match_start");
                        }
                    }));
                }
            }
            catch (e) {
            }
        }
    }
    hideMatchTipsAnim() {
        let e = this.mainRummy.pop_layer4.getChildByName("match_game_tips");
        ToolUtils.isObjValid(e) && (e.active = false);
    }
    showMatchRankInfoView() {
        Utils.shared().showMatchRankView(this.mainRummy.pop_layer4, RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key).matchRankInfo, this.mainRummy.tid_key, this.mainRummy.match_reward_info);
    }
    refreshMatchRankView() {
        if (!ToolUtils.isObjValid(this.mainRummy.pop_layer4)) {
            return;
        }
        let e = this.mainRummy.pop_layer4.getChildByName("match_rank");
        if (ToolUtils.isObjValid(e)) {
            let i = e.getComponent("MatchRank");
            i.refreshRankList(RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key).matchRankInfo);
            sys.isObjectValid(this.mainRummy.tid_key) && (i.setTidKey(this.mainRummy.tid_key), i.setLandscapeShow());
        }
    }
    showTaskCompleteAnim() {
        if (2 == this.show_pureseq_tips) {
            this.show_pureseq_tips = 1;
            let e = new Vec3;
            this.mainRummy.node_taskBg.getChildByName("select_img1").getPosition(e);
            this.mainRummy.node_taskBg.getChildByName("complete_anim1").setPosition(new Vec3(e.x - 2, e.y - 2, e.z));
            this.mainRummy.node_taskBg.getChildByName("complete_anim1").active = true;
            TweenTool.delayAct(this.mainRummy.time_node, (() => {
                SoundManager.shared().playFx("da_gou");
            }), 0.3, true);
            TweenTool.delayAct(this.mainRummy.time_node, (() => {
                this.mainRummy.node_taskBg.getChildByName("select_img1").active = true;
                this.mainRummy.node_taskBg.getChildByName("complete_anim1").active = false;
            }), 0.7, true);
        }
        else {
            this.show_pureseq_tips > 0 ? (this.mainRummy.node_taskBg.getChildByName("select_img1").active = true, this.mainRummy.node_taskBg.getChildByName("complete_anim1").active = false) : (this.mainRummy.node_taskBg.getChildByName("select_img1").active = false, this.mainRummy.node_taskBg.getChildByName("complete_anim1").active = false);
        }
        if (2 == this.show_seq_tips) {
            this.show_seq_tips = 1;
            let e = new Vec3;
            this.mainRummy.node_taskBg.getChildByName("select_img2").getPosition(e);
            this.mainRummy.node_taskBg.getChildByName("complete_anim2").setPosition(new Vec3(e.x - 2, e.y - 2, e.z));
            this.mainRummy.node_taskBg.getChildByName("complete_anim2").active = true;
            TweenTool.delayAct(this.mainRummy.time_node, (() => {
                SoundManager.shared().playFx("da_gou");
            }), 0.3, true);
            TweenTool.delayAct(this.mainRummy.time_node, (() => {
                this.mainRummy.node_taskBg.getChildByName("select_img2").active = true;
                this.mainRummy.node_taskBg.getChildByName("complete_anim2").active = false;
            }), 0.7, true);
        }
        else {
            this.show_seq_tips > 0 ? (this.mainRummy.node_taskBg.getChildByName("select_img2").active = true, this.mainRummy.node_taskBg.getChildByName("complete_anim2").active = false) : (this.mainRummy.node_taskBg.getChildByName("select_img2").active = false, this.mainRummy.node_taskBg.getChildByName("complete_anim2").active = false);
        }
        if (2 == this.show_total_score_tips) {
            this.show_total_score_tips = 1;
            let e = new Vec3;
            this.mainRummy.node_taskBg.getChildByName("select_img3").getPosition(e);
            this.mainRummy.node_taskBg.getChildByName("complete_anim3").setPosition(new Vec3(e.x - 2, e.y - 2, e.z));
            this.mainRummy.node_taskBg.getChildByName("complete_anim3").active = true;
            TweenTool.delayAct(this.mainRummy.time_node, (() => {
                SoundManager.shared().playFx("da_gou");
            }), 0.3, true);
            TweenTool.delayAct(this.mainRummy.time_node, (() => {
                this.mainRummy.node_taskBg.getChildByName("select_img3").active = true;
                this.mainRummy.node_taskBg.getChildByName("complete_anim3").active = false;
            }), 0.7, true);
        }
        else {
            this.show_total_score_tips > 0 ? (this.mainRummy.node_taskBg.getChildByName("select_img3").active = true, this.mainRummy.node_taskBg.getChildByName("complete_anim3").active = false) : (this.mainRummy.node_taskBg.getChildByName("select_img3").active = false, this.mainRummy.node_taskBg.getChildByName("complete_anim3").active = false);
        }
    }
    setTaskPanelShow(e) {
        e ? (this.mainRummy.winTips.getChildByName("icon").getComponent(Sprite).spriteFrame = this.mainRummy.winTipBtnImgs[1], this.mainRummy.node_taskBg.active || (this.mainRummy.node_taskBg.active = true), this.showTaskCompleteAnim()) : (this.mainRummy.winTips.getChildByName("icon").getComponent(Sprite).spriteFrame = this.mainRummy.winTipBtnImgs[0], this.mainRummy.node_taskBg.active && (this.mainRummy.winTips.getChildByName("icon").active = true, this.mainRummy.node_taskBg.getChildByName("complete_anim1").active = false, this.mainRummy.node_taskBg.getChildByName("complete_anim2").active = false, this.mainRummy.node_taskBg.getChildByName("complete_anim3").active = false, this.mainRummy.node_taskBg.active = false));
    }
    dealWinConditionTips(e) {
        (sys.isObjectValid(e.show_pureseq_tips) || sys.isObjectValid(e.show_seq_tips) || sys.isObjectValid(e.show_total_score_tips)) && (this.show_pureseq_tips = e.show_pureseq_tips, this.show_seq_tips = e.show_seq_tips, this.show_total_score_tips = e.show_total_score_tips, this.mainRummy._bIsShowWinTip && this.mainRummy.winTips.active && (2 == e.show_pureseq_tips || 2 == e.show_seq_tips || 2 == e.show_total_score_tips ? (this.setTaskPanelShow(true), TweenTool.delayAct(this.mainRummy.time_node, (() => {
            this.setTaskPanelShow(false);
        }), 4, true)) : (this.mainRummy.node_taskBg.getChildByName("select_img1").active = e.show_pureseq_tips > 0, this.mainRummy.node_taskBg.getChildByName("select_img2").active = e.show_seq_tips > 0, this.mainRummy.node_taskBg.getChildByName("select_img3").active = e.show_total_score_tips > 0)));
    }
    refreshWinTips() {
        2 == this.show_pureseq_tips || 2 == this.show_seq_tips || 2 == this.show_total_score_tips ? (RummyDataManager.shared().stopTweenAction(this.mainRummy.hide_win_tip_action), this.mainRummy.node_taskBg.getChildByName("tips").getChildByName("time").active = false, this.setTaskPanelShow(true), TweenTool.delayAct(this.mainRummy.time_node, (() => {
            this.setTaskPanelShow(false);
        }), 4, true)) : (this.mainRummy.node_taskBg.getChildByName("select_img1").active = this.show_pureseq_tips > 0, this.mainRummy.node_taskBg.getChildByName("select_img2").active = this.show_seq_tips > 0, this.mainRummy.node_taskBg.getChildByName("select_img3").active = this.show_total_score_tips > 0);
    }
    showWinConditionTips() {
        this.mainRummy.node_taskBg.active ? this.setTaskPanelShow(false) : (this.mainRummy.node_taskBg.getChildByName("gou").active = false, this.mainRummy.node_taskBg.getChildByName("tips").getChildByName("time").active = false, this.setTaskPanelShow(true));
    }
    dealWinTipsGou() {
        if (this.mainRummy.node_taskBg.getChildByName("gou").active) {
            this.mainRummy.node_taskBg.getChildByName("gou").active = false;
            RummyDataManager.shared().stopTweenAction(this.mainRummy.hide_win_tip_action);
            this.mainRummy.node_taskBg.getChildByName("tips").getChildByName("time").active = false;
        }
        else {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("rummy_main.win_tips_hide"), 3, 0, ToolUtils.getIsNormalDirection());
            this.mainRummy.node_taskBg.getChildByName("gou").active = true;
            let e = 3;
            this.mainRummy.node_taskBg.getChildByName("tips").getChildByName("time").getComponent(Label).string = "(" + e + "s)";
            this.mainRummy.node_taskBg.getChildByName("tips").getChildByName("time").active = true;
            RummyDataManager.shared().stopTweenAction(this.mainRummy.hide_win_tip_action);
            this.mainRummy.hide_win_tip_action = TweenTool.myschedule(RummyDataManager.shared().sceneNode, 1, (() => {
                if (e -= 1, e <= 0) {
                    RummyDataManager.shared().stopTweenAction(this.mainRummy.hide_win_tip_action);
                    this.mainRummy.winTips.active = false;
                    this.mainRummy.node_taskBg.active = false;
                    this.mainRummy.node_taskBg.getChildByName("tips").getChildByName("time").active = false;
                    ToolUtils.saveData("finish_conditions_def", "0");
                    for (let e of ToolUtils.deskInfos.keys()) {
                        User.shared().send_help_all_switcher(e);
                    }
                }
                else {
                    this.mainRummy.node_taskBg.getChildByName("tips").getChildByName("time").getComponent(Label).string = "(" + e + "s)";
                }
            }));
        }
    }
    showMagicFaceAlert(e, i) {
        if (window.InSwitchScene) {
            TLog.printError("-------- showMagicFaceAlert switchScene stop preload res.");
        }
        else {
            try {
                if (this.mainRummy.magicFaceAlertPrefab && this.mainRummy.magicFaceAlertPrefab.isValid) {
                    let t = this.mainRummy.pop_layer4.getChildByName("comm_magic_face");
                    if (!ToolUtils.isObjValid(t)) {
                        t = instantiate(this.mainRummy.magicFaceAlertPrefab);
                        t.parent = this.mainRummy.pop_layer4;
                        t.name = "comm_magic_face";
                        let m = t.getComponent("CommMagicFace");
                        this.initMagicAlert(m, e, i);
                    }
                }
                else {
                    ToolUtils.loadCommonPrefab(null, BundleNameDefined.bundle_rummyTopUI, "prefab/comm_magic_face", (m => {
                        if (sys.isObjectValid(this.mainRummy) && ToolUtils.isObjValid(this.mainRummy.pop_layer4)) {
                            let t = this.mainRummy.pop_layer4.getChildByName("comm_magic_face");
                            if (!ToolUtils.isObjValid(t)) {
                                this.mainRummy.magicFaceAlertPrefab = m;
                                t = instantiate(m);
                                t.parent = this.mainRummy.pop_layer4;
                                let s = t.getComponent("CommMagicFace");
                                this.initMagicAlert(s, e, i);
                            }
                        }
                    }));
                }
            }
            catch (e) {
                TLog.printError("trycatch showMagicFaceAlert,error:", e);
            }
        }
    }
    initMagicAlert(e, i, t) {
        let a = RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key);
        e.magicexpressioncost = a.magicexpressioncost;
        a.gameRummyType == RUMMY_GAME_TYPE.PRIVATE && e.setIsInPrivateRoom(true);
        1 == a.crashModel && e.setIsPracticeRoom(true);
        e.setTargetClientId(i);
        e.setFaceCallback(this.sendMagicFace.bind(this));
        e.setNotifyUserInfoStatus(this.sendNotifyUserInfoStatus.bind(this), i);
        e.setLandscapeShow();
        e.setRoomInfo({ tid_key: User.shared().curTid_key, emotion_fee_cfg: a.emotion_fee_cfg, players: a.playerModels, heguan: 0, entryFee: a.entry_fee, vid: a.vid });
        let m = {};
        m.money = t.money;
        m.pmodel = t;
        e.updatePlayerInfo(m);
    }
    sendMagicFace(e, i, t = 0) {
        this.mainRummy.sendMagicFace(e, i, t);
    }
    sendHisCardInfoReq() {
        this.mainRummy.rummyLogicProcessing.send_request_history_cards_info();
    }
    sendNotifyUserInfoStatus(e, i) {
        this.mainRummy.rummyLogicProcessing.send_notify_user_info_status(e, i);
    }
    createRoomInfoNode() {
        if (window.InSwitchScene) {
            TLog.printError("-------- createRoomInfoNode switchScene stop preload res.");
        }
        else {
            try {
                ToolUtils.loadCommonPrefab(null, BundleNameDefined.bundle_rummyTopUI, "prefab/room_info", (e => {
                    sys.isObjectValid(e) && e.isValid && sys.isObjectValid(this.mainRummy) && ToolUtils.isObjValid(this.mainRummy.pop_layer4) && (this.mainRummy.roomInfoNode = instantiate(e), this.mainRummy.roomInfoNode.parent = this.mainRummy.pop_layer4, this.mainRummy.roomInfoTs = this.mainRummy.roomInfoNode.getComponent("RummyRoomInfo"), this.mainRummy.roomInfoTs.setLandscapeShow(), this.mainRummy.roomInfoTs.refreshUI(this.mainRummy.roomInfoMsg), this.mainRummy.roomInfoTs.setTidKey(this.mainRummy.tid_key));
                }));
            }
            catch (e) {
                TLog.printError("trycatch createRoomInfoNode,error:", e);
            }
        }
    }
    showSecurityFeaturesView() {
        if (window.InSwitchScene) {
            TLog.printError("-------- showSecurityFeaturesView switchScene stop preload res.");
        }
        else {
            try {
                ToolUtils.loadCommonPrefab(null, BundleNameDefined.bundle_rummyTopUI, "prefab/Security_features", (e => {
                    if (sys.isObjectValid(e) && e.isValid && sys.isObjectValid(this.mainRummy) && ToolUtils.isObjValid(this.mainRummy.pop_layer4)) {
                        let i = instantiate(e);
                        i.name = "Security_features";
                        i.parent = this.mainRummy.pop_layer4;
                        i.getComponent("RummySecurityFeatures").setTidKey(this.mainRummy.tid_key);
                    }
                }));
            }
            catch (e) {
                TLog.printError("trycatch showSecurityFeaturesView,error:", e);
            }
        }
    }
    showChatAlert() {
        if (window.InSwitchScene) {
            TLog.printError("-------- showChatAlert switchScene stop preload res.");
        }
        else {
            try {
                ToolUtils.loadCommonPrefab(null, BundleNameDefined.bundle_rummyTopUI, "prefab/chat_alert", (e => {
                    if (sys.isObjectValid(e) && e.isValid && sys.isObjectValid(this.mainRummy) && ToolUtils.isObjValid(this.mainRummy.pop_layer4)) {
                        let i = instantiate(e);
                        i.name = "chat_alert";
                        i.parent = this.mainRummy.pop_layer4;
                        let t = i.getComponent("ChatAlert");
                        t.setChatType(RummyDataManager.shared().chat_Type);
                        t.startShowAnim();
                        t.setFaceCallback(this.sendFace.bind(this));
                        t.setTextCallback(this.sendText.bind(this));
                        t.setLandscapeShow();
                        t.setClientId(6);
                        t.setTidKey(this.mainRummy.tid_key);
                    }
                }));
            }
            catch (e) {
                TLog.printError("show chatAlert err:", e);
            }
        }
    }
    sendFace(e) {
        this.mainRummy.sendFace(e);
    }
    sendText(e, i) {
        this.mainRummy.sendText(e, i);
    }
    showMenuAlert() {
        try {
            if (this.mainRummy.menualertPrefab && this.mainRummy.menualertPrefab.isValid) {
                let e = instantiate(this.mainRummy.menualertPrefab);
                e.parent = this.mainRummy.pop_layer4;
                let i = e.getComponent("MenuAlert");
                this.initMenu(i);
            }
            else {
                ToolUtils.loadCommonPrefab(null, BundleNameDefined.bundle_public, "prefab/menu_alert", (e => {
                    if (sys.isObjectValid(e) && e.isValid && sys.isObjectValid(this.mainRummy) && ToolUtils.isObjValid(this.mainRummy.pop_layer4)) {
                        let i = this.mainRummy.pop_layer4.getChildByName("menu_alert");
                        if (!ToolUtils.isObjValid(i)) {
                            i = instantiate(e);
                            this.mainRummy.menualertPrefab = e;
                            i.parent = this.mainRummy.pop_layer4;
                            let t = i.getComponent("MenuAlert");
                            this.initMenu(t);
                        }
                    }
                }));
            }
        }
        catch (e) {
            TLog.printError("trycatch MainRummy onDealBtnAction set:", e);
        }
    }
    initMenu(e) {
        e.startShowAnim();
        e.setCallback(this.onMenuCallback.bind(this));
        e.setTidKey(this.mainRummy.tid_key);
        e.setLandscapeShow();
        let i = RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key), a = i.clientSeatId, m = i.playerModels[a];
        i.gameRummyType == RUMMY_GAME_TYPE.PRIVATE || i.gameRummyType == RUMMY_GAME_TYPE.PRI_POOL || i.gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL ? (e.setBtnEnable("switch", false), e.setBtnEnable("exit", true)) : (1 != i.isInGameing || 4 != m.status && !i.is_table_change_status || i.gameRummyType != RUMMY_GAME_TYPE.POINTS && 4 != m.status && (e.setBtnEnable("switch", false), e.setBtnEnable("exit", false)), i.gameRummyType != RUMMY_GAME_TYPE.POINTS && i.gameRummyType != RUMMY_GAME_TYPE.MULTIPLE || !i.is_table_change_status || (e.setBtnEnable("switch", false), e.setBtnEnable("exit", false)), i.gameRummyType == RUMMY_GAME_TYPE.MATCH && e.setBtnEnable("switch", false), 1 !== i.is_waiting && 1 != i.game_server_state || e.setBtnEnable("switch", false));
        i.isCanExit || i.gameRummyType != RUMMY_GAME_TYPE.POINTS && i.gameRummyType != RUMMY_GAME_TYPE.MULTIPLE && e.setBtnEnable("exit", false);
        i.gameRummyType != RUMMY_GAME_TYPE.POOL && i.gameRummyType != RUMMY_GAME_TYPE.DEALS && i.gameRummyType != RUMMY_GAME_TYPE.PRI_POOL && i.gameRummyType != RUMMY_GAME_TYPE.PRI_DEAL || !i.is_declare_status || (e.setBtnEnable("exit", false), e.setBtnEnable("switch", false));
        i.gameRummyType == RUMMY_GAME_TYPE.POINTS && 0 == i.is_table_change_status && sys.isObjectValid(this.mainRummy.cardsTs.cardValueVec) && this.mainRummy.cardsTs.cardValueVec.length > 0 && e.setBtnEnable("switch", 13 == this.mainRummy.cardsTs.cardValueVec.length);
    }
    onMenuCallback(e) {
        this.mainRummy.onMenuCallback(e);
    }
    showPracticeGuide() {
    }
    showCashGuide() {
        if (window.InSwitchScene) {
            TLog.printError("-------- showCashGuide switchScene stop preload res.");
        }
        else {
            if (User.shared().data.beginner_guide.cash_reward <= 0) {
                return HttpManager.shared().doGetCommonRequest({ type: 1 }, "BeginnerGuide.exerciseGameReport", null), void HttpManager.shared().doGetCommonRequest({ type: 3 }, "BeginnerGuide.exerciseGameReport", null);
            }
            try {
                ToolUtils.loadCommonPrefab(null, BundleNameDefined.bundle_rummyTopUI, "prefab/cash_guide", (e => {
                    if (sys.isObjectValid(e) && e.isValid && sys.isObjectValid(this.mainRummy) && ToolUtils.isObjValid(this.mainRummy.pop_layer5)) {
                        let i = instantiate(e);
                        i.name = "cash_guide";
                        i.parent = this.mainRummy.pop_layer5;
                        let t = i.getComponent("RummyCashGuide");
                        t.setParaData(this.onDealBtnAction.bind(this));
                        t.setTidKey(this.mainRummy.tid_key);
                    }
                }));
            }
            catch (e) {
                TLog.printError("trycatch showCashGuide,error:", e);
            }
        }
    }
    onDealBtnAction(e) {
        "onSwitchCash" == e ? RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key).switchCash = true : "onNotInGame" == e ? RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key).isInGameing = 0 : this.mainRummy.onDealBtnAction(e);
    }
    show_pool_rummy_pop(e, i, m, s) {
        if (window.InSwitchScene) {
            TLog.printError("-------- show_pool_rummy_pop switchScene stop preload res.");
        }
        else {
            try {
                ToolUtils.isObjValid(this.mainRummy.rummyGamePoolPoP) && (m || this.mainRummy.rummyGamePoolPoP.destroy());
                ToolUtils.loadCommonPrefab(null, BundleNameDefined.bundle_rummy, "prefab/GameRummy_pool_pop", (m => {
                    sys.isObjectValid(m) && m.isValid && sys.isObjectValid(this.mainRummy) && ToolUtils.isObjValid(this.mainRummy.pop_layer4) && (this.mainRummy.rummyGamePoolPoP = instantiate(m), this.mainRummy.rummyGamePoolPoP.parent = this.mainRummy.pop_layer4, this.mainRummy.rummyGamePoolPoP.getComponent(RummyGamePoolPop).initView(e, i, this.mainRummy, this.mainRummy.tid_key), s && this.mainRummy.rummyGamePoolPoP.setSiblingIndex(s));
                }));
            }
            catch (e) {
                TLog.printError("trycatch show_pool_rummy_pop:", e);
            }
        }
    }
    showMatchWaitView(e, i, m, s) {
        if (window.InSwitchScene) {
            TLog.printError("-------- showMatchWaitView switchScene stop preload res.");
        }
        else {
            try {
                let n = this.mainRummy.pop_layer4.getChildByName("match_game_tips");
                if (ToolUtils.isObjValid(n) && n.active) {
                    return;
                }
                let o = this.mainRummy.pop_layer4.getChildByName("match_game_wait");
                if (ToolUtils.isObjValid(o)) {
                    o.active = true;
                    let t = o.getComponent("RummyMatchWait");
                    t.setMatchWaitInfo(this.mainRummy.tid_key, e, i, m, s, this.onMatchCallback.bind(this));
                    t.initView();
                }
                else {
                    ToolUtils.loadCommonPrefab(null, BundleNameDefined.bundle_rummyTopUI, "prefab/match_game_wait", (r => {
                        if (sys.isObjectValid(r) && r.isValid && sys.isObjectValid(this.mainRummy) && ToolUtils.isObjValid(this.mainRummy.pop_layer4)) {
                            if (ToolUtils.isObjValid(n) && n.active) {
                                return;
                            }
                            o = instantiate(r);
                            o.name = "match_game_wait";
                            o.parent = this.mainRummy.pop_layer4;
                            o.active = true;
                            o.getComponent("RummyMatchWait").setMatchWaitInfo(this.mainRummy.tid_key, e, i, m, s, this.onMatchCallback.bind(this));
                        }
                    }));
                }
            }
            catch (e) {
                TLog.printError("trycatch showMatchAlertTip,error:", e);
            }
        }
    }
    onMatchCallback(e) {
        this.mainRummy.onMatchCallback(e);
    }
    showMatchPrizeRank() {
        window.InSwitchScene ? TLog.printError("-------- showMatchPrizeRank switchScene stop preload res.") : Utils.shared().showMatchPrizesRankView(this.mainRummy.pop_layer4, RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key).matchPrizesInfo, this.mainRummy.tid_key);
    }
    cancelDealPoolRecord() {
        this.recordLoadGeneration++;
        this.recordRequestPending = false;
        for (const key of ["openFlag_poolScoreboard", "openFlag_dealsScoreboard"]) {
            const node = this.mainRummy[key];
            if (ToolUtils.isObjValid(node)) node.destroy();
            this.mainRummy[key] = null;
        }
    }
    showDealPoolRecord(e, i = true) {
        if (window.InSwitchScene) {
            TLog.printError("-------- showDealPoolRecord switchScene stop preload res.");
        }
        else {
            try {
                // Only accept the reply to a current click, not an old match's late reply.
                if (i && !this.recordRequestPending) return;
                this.recordRequestPending = !i;
                const generation = ++this.recordLoadGeneration;
                const main = this.mainRummy;
                const key = main.tid_key;
                let m = RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key);
                if (m.gameRummyType == RUMMY_GAME_TYPE.POOL || m.gameRummyType == RUMMY_GAME_TYPE.PRI_POOL) {
                    if (!Array.isArray(e.record)) e = { ...e, record: [] };
                    if (null != e.record || !i) {
                        if (ToolUtils.isObjValid(this.mainRummy.openFlag_poolScoreboard)) {
                            if (sys.isObjectValid(e.record)) {
                                return void this.mainRummy.openFlag_poolScoreboard.getComponent(RummyGamePoolRecord).initView(2, e, this.mainRummy, this.mainRummy.tid_key);
                            }
                            this.mainRummy.openFlag_poolScoreboard.destroy();
                        }
                        ToolUtils.loadCommonPrefab(null, BundleNameDefined.bundle_rummy, "prefab/GameRummy_pool_scoreboard", (i => {
                            if (generation !== this.recordLoadGeneration || this.mainRummy !== main || main.tid_key !== key) return;
                            if (sys.isObjectValid(i) && i.isValid && sys.isObjectValid(this.mainRummy) && ToolUtils.isObjValid(this.mainRummy.pop_layer4)) {
                                let m = instantiate(i);
                                m.parent = this.mainRummy.pop_layer4;
                                sys.isObjectValid(e.record) && m.getComponent(RummyGamePoolRecord).initView(2, e, this.mainRummy, this.mainRummy.tid_key);
                                this.mainRummy.openFlag_poolScoreboard = m;
                            }
                        }));
                    }
                }
                else if (m.gameRummyType == RUMMY_GAME_TYPE.DEALS || m.gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL) {
                    if (ToolUtils.isObjValid(this.mainRummy.openFlag_dealsScoreboard)) {
                        if (sys.isObjectValid(e.record)) {
                            return void this.mainRummy.openFlag_dealsScoreboard.getComponent(RummyGameDealsRecord).initView(e.record, e.start_score, this.mainRummy, this.mainRummy.tid_key);
                        }
                        this.mainRummy.openFlag_dealsScoreboard.destroy();
                    }
                    if (2 == m.pnum) {
                        ToolUtils.loadCommonPrefab(null, BundleNameDefined.bundle_rummy, "prefab/GameRummy_deals_record", (i => {
                            if (generation !== this.recordLoadGeneration || this.mainRummy !== main || main.tid_key !== key) return;
                            if (sys.isObjectValid(i) && i.isValid && sys.isObjectValid(this.mainRummy) && ToolUtils.isObjValid(this.mainRummy.pop_layer4)) {
                                let m = instantiate(i);
                                m.name = "GameRummy_deals_record";
                                m.parent = this.mainRummy.pop_layer4;
                                sys.isObjectValid(e.record) && m.getComponent(RummyGameDealsRecord).initView(e.record, e.start_score, this.mainRummy, this.mainRummy.tid_key);
                                this.mainRummy.openFlag_dealsScoreboard = m;
                            }
                        }));
                    }
                    else if (null != e.record || !i) {
                        if (ToolUtils.isObjValid(this.mainRummy.openFlag_poolScoreboard)) {
                            if (sys.isObjectValid(e.record)) {
                                return void this.mainRummy.openFlag_poolScoreboard.getComponent(RummyGamePoolRecord).initView(2, e, this.mainRummy, this.mainRummy.tid_key);
                            }
                            this.mainRummy.openFlag_poolScoreboard.destroy();
                        }
                        ToolUtils.loadCommonPrefab(null, BundleNameDefined.bundle_rummy, "prefab/GameRummy_pool_scoreboard", (i => {
                            if (generation !== this.recordLoadGeneration || this.mainRummy !== main || main.tid_key !== key) return;
                            if (sys.isObjectValid(i) && i.isValid && sys.isObjectValid(this.mainRummy) && ToolUtils.isObjValid(this.mainRummy.pop_layer4)) {
                                let m = instantiate(i);
                                m.name = "GameRummy_pool_scoreboard";
                                m.parent = this.mainRummy.pop_layer4;
                                sys.isObjectValid(e.record) && m.getComponent(RummyGamePoolRecord).initView(2, e, this.mainRummy, this.mainRummy.tid_key);
                                this.mainRummy.openFlag_poolScoreboard = m;
                            }
                        }));
                    }
                }
            }
            catch (e) {
                TLog.printError("trycatch showDealPoolRecord ,error:", e);
            }
        }
    }
    loadTopBgPrefab(e) {
        if (ToolUtils.isObjValid(this.mainRummy.topBgNode)) {
            e && e();
        }
        else {
            if (window.InSwitchScene) {
                return void TLog.printError("-------- loadTopBgPrefab switchScene stop preload res.");
            }
            ToolUtils.loadCommonPrefab(null, BundleNameDefined.bundle_rummy, "prefab/rummy_top_bg", (i => {
                if (ToolUtils.isObjValid(this.mainRummy.tableRoot) && ToolUtils.isObjValid(this.mainRummy.tableRoot.getChildByName("topNode"))) {
                    if (ToolUtils.isObjValid(this.mainRummy.topBgNode)) {
                        return void (e && e());
                    }
                    this.mainRummy.topBgNode = instantiate(i);
                    this.mainRummy.tableRoot.getChildByName("topNode").addChild(this.mainRummy.topBgNode);
                    this.mainRummy.topBgNode.setPosition(v3(0, 344, 0));
                    ToolUtils.isPadPlatform() && this.mainRummy.resetUiPos(this.mainRummy.topBgNode, AdapDirection.Up, true, 1, false);
                    e && e();
                }
            }));
        }
    }
    show_table_top_info(e) {
        try {
            if (1 == GameConfig.CHIPS_MODLE) {
                let i = "Rummy";
                e.game_name = e.game_name.replace(new RegExp(i, "g"), "");
            }
            this.loadTopBgPrefab((() => {
                let i = this.mainRummy.topBgNode, a = i.getChildByName("points_tip");
                a.active = false;
                let s = i.getChildByName("pool_tip");
                s.active = false;
                let d = i.getChildByName("point_private_tip");
                d.active = false;
                let u = i.getChildByName("pool_private_tip");
                u.active = false;
                let R = i.getChildByName("match_moneyup_tip");
                R.active = false;
                let b = i.getChildByName("match_fixed_tip");
                b.active = false;
                let C = i.getChildByName("pool_tip_Practice");
                C.active = false;
                let w = i.getChildByName("match_points_tip");
                w.active = false;
                let B = RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key);
                if (this.mainRummy.checkIsPointsMatch() && (sys.isObjectValid(e.user_round) && (B.user_round = e.user_round), sys.isObjectValid(e.max_round) && (B.max_round = e.max_round)), B.gameRummyType == RUMMY_GAME_TYPE.POINTS || B.gameRummyType == RUMMY_GAME_TYPE.MULTIPLE) {
                    a.active = true;
                    a.getChildByName("roomID").getComponent(Label).string = e.game_serial_id;
                    a.getChildByName("roomType").getComponent(Label).string = e.game_name;
                    let i = true, t = i18nMgr.shared().getValueByKey("rummy_main.value") + "₹";
                    if (1 === B.crashModel) {
                        i = false;
                        let t = a.getChildByName("valueItem").getChildByName("base_point");
                        t.getComponent(Label).string = "" + ToolUtils.parse_ChipNum2(e.base_money);
                        1 == i18nMgr.shared().language && (a.getChildByName("valueItem").getChildByName("icon").position = v3(57, -1), t.position = v3(69, -1));
                    }
                    a.getChildByName("baseMoney").active = i;
                    a.getChildByName("valueItem").active = !i;
                    a.getChildByName("baseMoney").getComponent(Label).string = t + ToolUtils.parse_double(e.base_money, 0);
                }
                else if (B.gameRummyType == RUMMY_GAME_TYPE.POOL) {
                    if (1 == B.crashModel) {
                        C.active = true;
                        C.getChildByName("roomID").getComponent(Label).string = e.game_serial_id;
                        C.getChildByName("roomType").getComponent(Label).string = e.game_name;
                        C.getChildByName("baseMoney").getComponent(Label).string = ToolUtils.parse_ChipNum2(e.base_money);
                        let i = C.getChildByName("Layout"), a = i.getChildByName("prize1"), m = i.getChildByName("prize"), o = i.getChildByName("icon1");
                        i.active = true;
                        0 == e.prize ? (o.active = false, a.active = false, m.getComponent(Label).string = "") : (o.active = true, a.active = true, m.active = true, m.getComponent(Label).string = "" + ToolUtils.parse_ChipNum2("" + e.prize));
                        sys.isObjectValid(e.isShowRed) && (s.getChildByName("hongdian").active = 1 == e.isShowRed, this.mainRummy.top_bg_hongdian = e.isShowRed);
                        sys.isObjectValid(e.reward_detail) && this.mainRummy.tipTs.setPoolJackPotData(e.reward_detail, e.prize);
                        this.mainRummy.actionTs.showPrizeBtn();
                    }
                    else {
                        s.active = true;
                        s.getChildByName("roomID").getComponent(Label).string = e.game_serial_id;
                        s.getChildByName("roomType").getComponent(Label).string = e.game_name;
                        s.getChildByName("baseMoney").getComponent(Label).string = "₹" + e.base_money;
                        let i = s.getChildByName("prize");
                        0 == e.prize ? i.getComponent(Label).string = "" : i.getComponent(Label).string = i18nMgr.shared().getValueByKey("gameRummy_pool_manual.prize") + ":₹" + ToolUtils.parse_double("" + e.prize);
                        sys.isObjectValid(e.isShowRed) && (s.getChildByName("hongdian").active = 1 == e.isShowRed, this.mainRummy.top_bg_hongdian = e.isShowRed);
                        sys.isObjectValid(e.reward_detail) && this.mainRummy.tipTs.setPoolJackPotData(e.reward_detail, e.prize);
                        this.mainRummy.actionTs.showPrizeBtn();
                    }
                }
                else if (B.gameRummyType == RUMMY_GAME_TYPE.PRI_POOL) {
                    u.active = true;
                    u.getChildByName("id").getComponent(Label).string = "ID:" + (null != e.tid ? e.tid : "");
                    u.getChildByName("roomID").getComponent(Label).string = e.game_serial_id;
                    u.getChildByName("roomType").getComponent(Label).string = e.game_name;
                    u.getChildByName("baseMoney").getComponent(Label).string = "₹" + e.base_money;
                    0 == e.prize ? u.getChildByName("prize").getComponent(Label).string = "" : u.getChildByName("prize").getComponent(Label).string = i18nMgr.shared().getValueByKey("gameRummy_pool_manual.prize") + ":₹" + ToolUtils.parse_double("" + e.prize);
                    sys.isObjectValid(e.isShowRed) && (u.getChildByName("hongdian").active = 1 == e.isShowRed, this.mainRummy.top_bg_hongdian = e.isShowRed);
                    sys.isObjectValid(e.reward_detail) && this.mainRummy.tipTs.setPoolJackPotData(e.reward_detail, e.prize);
                    this.mainRummy.actionTs.showPrizeBtn();
                }
                else if (B.gameRummyType == RUMMY_GAME_TYPE.DEALS) {
                    if (1 == B.crashModel) {
                        C.active = true;
                        C.getChildByName("roomID").getComponent(Label).string = e.game_serial_id;
                        C.getChildByName("roomType").getComponent(Label).string = e.game_name;
                        C.getChildByName("baseMoney").getComponent(Label).string = ToolUtils.parse_ChipNum2(e.base_money);
                        let i = C.getChildByName("Layout"), t = i.getChildByName("prize1"), a = i.getChildByName("prize"), m = i.getChildByName("icon1");
                        i.active = true;
                        let s = C.getChildByName("underline");
                        0 == e.prize ? (a.getComponent(Label).string = "", m.active = false, t.active = false) : (m.active = true, t.active = true, a.getComponent(Label).string = "" + ToolUtils.parse_ChipNum2("" + e.prize));
                        null != e.first_prize && e.first_prize > 0 && null != e.second_prize && e.second_prize > 0 ? (this.mainRummy.tableRoot.getChildByName("delalsRummy6Player").getChildByName("practice_deals_tip").getChildByName("prize1").getComponent(Label).string = "1st " + i18nMgr.shared().getValueByKey("rummy_main.prize") + ":    " + ToolUtils.parse_double(e.first_prize, 0), this.mainRummy.tableRoot.getChildByName("delalsRummy6Player").getChildByName("practice_deals_tip").getChildByName("prize2").getComponent(Label).string = "2nd " + i18nMgr.shared().getValueByKey("rummy_main.prize") + ":    " + ToolUtils.parse_double(e.second_prize, 0), 1 == i18nMgr.shared().language && (this.mainRummy.tableRoot.getChildByName("delalsRummy6Player").getChildByName("practice_deals_tip").getChildByName("icon").position = v3(-47.313, -1), this.mainRummy.tableRoot.getChildByName("delalsRummy6Player").getChildByName("practice_deals_tip").getChildByName("icon1").position = v3(121, -1)), this.mainRummy.actionTs.isShowDealsPrizeBtn(true), a.getComponent(Label).updateRenderData(true), t.getComponent(Label).updateRenderData(true), TweenTool.delayAct(this.mainRummy.time_node, (() => {
                            s.active = true;
                            let e = i.getComponent(UITransform).width;
                            e > 0 && s.getComponent(UITransform).setContentSize(size(e, 2));
                        }), 0.2, true)) : (this.mainRummy.actionTs.isShowDealsPrizeBtn(false), s.active = false);
                    }
                    else {
                        s.active = true;
                        s.getChildByName("roomID").getComponent(Label).string = e.game_serial_id;
                        s.getChildByName("roomType").getComponent(Label).string = e.game_name;
                        s.getChildByName("baseMoney").getComponent(Label).string = "₹" + e.base_money;
                        0 == e.prize ? s.getChildByName("prize").getComponent(Label).string = "" : s.getChildByName("prize").getComponent(Label).string = i18nMgr.shared().getValueByKey("gameRummy_pool_manual.prize") + ":₹" + ToolUtils.parse_double("" + e.prize);
                        null != e.first_prize && e.first_prize > 0 && null != e.second_prize && e.second_prize > 0 ? (this.mainRummy.tableRoot.getChildByName("delalsRummy6Player").getChildByName("deals_tip").getChildByName("prize1").getComponent(Label).string = "1st " + i18nMgr.shared().getValueByKey("rummy_main.prize") + ":₹" + ToolUtils.parse_double(e.first_prize), this.mainRummy.tableRoot.getChildByName("delalsRummy6Player").getChildByName("deals_tip").getChildByName("prize2").getComponent(Label).string = "2nd " + i18nMgr.shared().getValueByKey("rummy_main.prize") + ":₹" + ToolUtils.parse_double(e.second_prize), this.mainRummy.actionTs.isShowDealsPrizeBtn(true), s.getChildByName("prize").getComponent(Label).isUnderline = true) : (this.mainRummy.actionTs.isShowDealsPrizeBtn(false), s.getChildByName("prize").getComponent(Label).isUnderline = false);
                    }
                }
                else if (B.gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL) {
                    u.active = true;
                    u.getChildByName("id").getComponent(Label).string = "ID:" + (null != e.tid ? e.tid : "");
                    u.getChildByName("roomID").getComponent(Label).string = e.game_serial_id;
                    u.getChildByName("roomType").getComponent(Label).string = e.game_name;
                    u.getChildByName("baseMoney").getComponent(Label).string = "₹" + e.base_money;
                    0 == e.prize ? u.getChildByName("prize").getComponent(Label).string = "" : u.getChildByName("prize").getComponent(Label).string = i18nMgr.shared().getValueByKey("rummy_main.prize") + ":₹" + ToolUtils.parse_double("" + e.prize);
                    null != e.first_prize && e.first_prize > 0 && null != e.second_prize && e.second_prize > 0 ? (this.mainRummy.tableRoot.getChildByName("delalsRummy6Player").getChildByName("deals_tip").getChildByName("prize1").getComponent(Label).string = "1st " + i18nMgr.shared().getValueByKey("rummy_main.prize") + ":₹" + ToolUtils.parse_double(e.first_prize), this.mainRummy.tableRoot.getChildByName("delalsRummy6Player").getChildByName("deals_tip").getChildByName("prize2").getComponent(Label).string = "2nd " + i18nMgr.shared().getValueByKey("rummy_main.prize") + ":₹" + ToolUtils.parse_double(e.second_prize), this.mainRummy.actionTs.isShowDealsPrizeBtn(true), u.getChildByName("prize").getComponent(Label).isUnderline = true) : (this.mainRummy.actionTs.isShowDealsPrizeBtn(false), u.getChildByName("prize").getComponent(Label).isUnderline = false);
                }
                else if (B.gameRummyType == RUMMY_GAME_TYPE.PRIVATE) {
                    d.active = true;
                    d.getChildByName("id").getComponent(Label).string = "ID:" + (null != e.tid ? e.tid : "");
                    d.getChildByName("roomID").getComponent(Label).string = e.game_serial_id;
                    d.getChildByName("roomType").getComponent(Label).string = e.game_name;
                    d.getChildByName("baseMoney").getComponent(Label).string = i18nMgr.shared().getValueByKey("rummy_main.value") + "₹" + ToolUtils.parse_double(e.base_money, 0);
                }
                else if (B.gameRummyType == RUMMY_GAME_TYPE.MATCH) {
                    if (B.gameMatchMode == RUMMY_MATCH_MODE.PointsMatch) {
                        w.active = true;
                        w.getChildByName("roomID").getComponent(Label).string = e.game_serial_id;
                        w.getChildByName("roomType").getComponent(Label).string = e.game_name;
                        let i = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_main.match_points_round"), e.user_round, e.max_round), t = w.getChildByName("rounds").getComponent(Label);
                        t.string = i;
                        i18nMgr.shared().changeLabelFont(t);
                        let a = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_main.match_points_score"), e.base_money), m = w.getChildByName("score").getComponent(Label);
                        m.string = a;
                        i18nMgr.shared().changeLabelFont(m);
                    }
                    else if (B.gameMatchType == RUMMY_MATCH_TYPE.BASEMONEYUP) {
                        R.active = true;
                        R.getChildByName("roomID").getComponent(Label).string = e.game_serial_id;
                        R.getChildByName("roomType").getComponent(Label).string = e.game_name;
                        let i = R.getChildByName("baseMoney");
                        if (R.getChildByName("baseMoney").getComponent(Label).color = color(153, 153, 153), 0 != this.match_base_money && e.base_money > this.match_base_money) {
                            TweenTool.stopNodeAction(i);
                            let t = color(255, 255, 0, 255), a = color(153, 153, 153, 255);
                            tween(i).to(0.13, { scale: new Vec3(0.6, 0.6, 0.6) }).call((() => {
                                i.getComponent(Label).string = "Value: " + e.base_money;
                                i.getComponent(Label).color = color(255, 255, 0);
                            })).to(0.13, { scale: new Vec3(0.5, 0.5, 0.5) }).to(0.16, { scale: new Vec3(0.7, 0.7, 0.7) }).to(0.13, { scale: new Vec3(0.5, 0.5, 0.5) }).union().delay(1).call((() => {
                                TweenTool.gradientLableColor(i, 0.15, t, a, true);
                            })).union().start();
                        }
                        else {
                            i.getComponent(Label).string = "Value: " + e.base_money;
                        }
                        this.match_base_money = e.base_money;
                        let a = "Next Value: ";
                        if (sys.isObjectValid(e.next_base_money) && (a = "Next Value: " + e.next_base_money), R.getChildByName("nextBaseMoney").getComponent(Label).string = a, null != e.next_up_time) {
                            B.racing_time = e.next_up_time;
                            let i = RummyDataManager.formatRaceTime(e.next_up_time);
                            this.setRaceTime(i);
                        }
                        ToolUtils.isObjValid(R.getChildByName("flag")) && (R.getChildByName("flag").active = B.is_rapid);
                    }
                    else if (b.active = true, b.getChildByName("roomID").getComponent(Label).string = e.game_serial_id, b.getChildByName("roomType").getComponent(Label).string = e.game_name, b.getChildByName("baseMoney").getComponent(Label).string = "Value: " + e.base_money, b.getChildByName("baseMoney").getComponent(Label).color = color(153, 153, 153), null != e.racing_time) {
                        B.racing_time = e.racing_time;
                        let i = RummyDataManager.formatRaceTime(e.racing_time);
                        this.setRaceTime(i);
                    }
                }
            }));
        }
        catch (e) {
            TLog.printError("trycatch show_table_top_info ,error:", e);
        }
    }
    hide_table_top_info_hongdian() {
        this.loadTopBgPrefab((() => {
            let e = this.mainRummy.topBgNode.getChildByName("pool_tip"), i = this.mainRummy.topBgNode.getChildByName("pool_private_tip");
            e.getChildByName("hongdian").active = false;
            i.getChildByName("hongdian").active = false;
        }));
    }
    showGuideRoomTopBg() {
        this.loadTopBgPrefab((() => {
            let e = this.mainRummy.topBgNode.getChildByName("points_tip");
            e.active = true;
            e.getChildByName("roomID").getComponent(Label).string = "";
            e.getChildByName("valueItem").active = false;
            e.getChildByName("baseMoney").getComponent(Label).string = "";
        }));
    }
    showMathMoneyUpTop(e, i) {
        this.loadTopBgPrefab((() => {
            let a = this.mainRummy.topBgNode.getChildByName("match_moneyup_tip");
            a.active = true;
            sys.isObjectValid(e) && (a.getChildByName("baseMoney").getComponent(Label).string = ToolUtils.format("Value: ${0}", e), a.getChildByName("baseMoney").getComponent(Label).color = color(153, 153, 153));
            sys.isObjectValid(i) && (a.getChildByName("nextBaseMoney").getComponent(Label).string = "Next Value: " + i);
        }));
    }
    setRaceTime(e) {
        this.loadTopBgPrefab((() => {
            let i = this.mainRummy.topBgNode.getChildByName("match_fixed_tip");
            RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key).gameMatchType == RUMMY_MATCH_TYPE.BASEMONEYUP && (i = this.mainRummy.topBgNode.getChildByName("match_moneyup_tip"));
            let t = i.getChildByName("time");
            null != t && (t.getComponent(Label).string = e, t.getComponent(Label).color = color(153, 153, 153, 255));
        }));
    }
    showGameManualSplit(e, i) {
        if (window.InSwitchScene) {
            TLog.printError("-------- switchScene stop preload res.");
        }
        else {
            try {
                ToolUtils.isObjValid(this.mainRummy.rummyGameManualSplit) && this.mainRummy.rummyGameManualSplit.destroy();
                ToolUtils.loadCommonPrefab(null, BundleNameDefined.bundle_rummy, "prefab/GameRummy_pool_manual", (m => {
                    if (sys.isObjectValid(m) && m.isValid && sys.isObjectValid(this.mainRummy) && ToolUtils.isObjValid(this.mainRummy.pop_layer4)) {
                        this.mainRummy.rummyGameManualSplit = instantiate(m);
                        this.mainRummy.rummyGameManualSplit.name = "GameRummy_pool_manual";
                        this.mainRummy.rummyGameManualSplit.parent = this.mainRummy.pop_layer4;
                        let t = this.mainRummy.rummyGameManualSplit.getComponent(RummyGameManualSplit);
                        t.initView(this.mainRummy, this.mainRummy.tid_key);
                        t.updateCountDown(e);
                        t.updateSelect(i);
                    }
                }));
            }
            catch (e) {
                TLog.printError("trycatch handler_server_geme_notify_bc,error", e);
            }
        }
    }
    showMatchGameOver(e) {
        if (window.InSwitchScene) {
            TLog.printError("-------- showMatchGameOver switchScene stop preload res.");
        }
        else {
            try {
                ToolUtils.loadCommonPrefab(null, BundleNameDefined.bundle_rummyTopUI, "prefab/match_game_over", (i => {
                    if (sys.isObjectValid(i) && i.isValid && sys.isObjectValid(this.mainRummy) && ToolUtils.isObjValid(this.mainRummy.pop_layer4)) {
                        if (this.mainRummy.tid_key != e.tid_key) {
                            return;
                        }
                        this.mainRummy.removeGameOverView();
                        let t = instantiate(i);
                        t.name = "match_game_over";
                        t.parent = this.mainRummy.pop_layer4;
                        t.setSiblingIndex(10);
                        let m = t.getComponent("RummyMatchOver");
                        this.mainRummy.matchover_action = null;
                        1 == e.is_win && this.mainRummy.playEffectByName("matchOver");
                        m.setParaData(e, RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key).gameMatchMode, this.onMatchCallback.bind(this));
                        m.setLandscapeShow();
                        m.setTidKey(this.mainRummy.tid_key);
                        let s = this.mainRummy.pop_layer4.getChildByName("game_fast_buy");
                        ToolUtils.isObjValid(s) && s.setSiblingIndex(11);
                    }
                }));
            }
            catch (e) {
                TLog.printError("trycatch handler_server_geme_notify_bc,error", e);
            }
        }
    }
    showPoolRejoin(e, i, m) {
        if (window.InSwitchScene) {
            TLog.printError("-------- showPoolRejoin switchScene stop preload res.");
        }
        else {
            try {
                ToolUtils.loadCommonPrefab(null, BundleNameDefined.bundle_rummy, "prefab/GameRummy_pool_rejoin", (s => {
                    if (sys.isObjectValid(s) && s.isValid && sys.isObjectValid(this.mainRummy) && ToolUtils.isObjValid(this.mainRummy.pop_layer4) && !ToolUtils.isObjValid(this.mainRummy.pop_layer4.getChildByName("GameRummy_pool_rejoin"))) {
                        let t = instantiate(s);
                        t.name = "GameRummy_pool_rejoin";
                        t.parent = this.mainRummy.pop_layer4;
                        t.getComponent(RummyGamePoolRejoin).setParaData(e, i, m, this.mainRummy.tid_key);
                    }
                }));
            }
            catch (e) {
                TLog.printError("trycatch handler_server_geme_notify_bc,error", e);
            }
        }
    }
    showNewPlayerGuide() {
        if (window.InSwitchScene) {
            TLog.printError("-------- showNewPlayerGuide switchScene stop preload res.");
        }
        else {
            try {
                ToolUtils.loadCommonPrefab(null, BundleNameDefined.bundle_rummy, "prefab/newPlayer_guide", (e => {
                    let i = instantiate(e);
                    this.mainRummy.node.addChild(i);
                    this.mainRummy.newPlayerGuideTs = i.getComponent(RummyNewPlayerGuide);
                    this.mainRummy.newPlayerGuideTs.setCallBack(this.onNewPlayerGuideCallBack.bind(this));
                    this.mainRummy.newPlayerGuideTs.seatPosVec = [];
                    for (let e = 0; e < 6; e++) {
                        this.mainRummy.newPlayerGuideTs.seatPosVec.push(this.mainRummy.playerTs.getPlayerHeadViewPos(e));
                    }
                    this.mainRummy.playerTs.setPaiDuiBgShow(false);
                    this.mainRummy.newPlayerGuideTs.preInintCardPool();
                }));
            }
            catch (e) {
                TLog.printError("trycatch showNewPlayerGuide,error", e);
            }
        }
    }
    onNewPlayerGuideCallBack(e, i, t) {
        this.mainRummy.onNewPlayerGuideCallBack(e, i, t);
    }
    showHelpAlert(e) {
        let i = {};
        i.parent = this.mainRummy.pop_layer4;
        i.ruleFlag = e;
        i.isLandscape = true;
        i.tid_key = this.mainRummy.tid_key;
        i.isMultiple = 1 == User.shared().multiple_rummy_open;
        i.isEasy = User.shared().easy_mode_show;
        i.isBump = 1 == User.shared().bump_rummy_open;
        Utils.shared().showRuleHelpView(i);
    }
    showTotalSettlementInfo() {
        if (window.InSwitchScene) {
            TLog.printError("-------- showTotalSettlementInfo switchScene stop preload res.");
        }
        else {
            try {
                ToolUtils.isObjValid(this.mainRummy.poolScoreboardView) && this.mainRummy.poolScoreboardView.destroy();
                ToolUtils.loadCommonPrefab(null, BundleNameDefined.bundle_rummy, "prefab/GameRummy_pool_scoreboard", (e => {
                    if (sys.isObjectValid(RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key).pool_rummy_all_end_data) && sys.isObjectValid(e) && e.isValid && sys.isObjectValid(this.mainRummy) && ToolUtils.isObjValid(this.mainRummy.pop_layer4)) {
                        let i = instantiate(e);
                        i.name = "GameRummy_pool_scoreboard";
                        i.parent = this.mainRummy.pop_layer4;
                        i.getComponent(RummyGamePoolRecord).initView(1, RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key).pool_rummy_all_end_data, this.mainRummy, this.mainRummy.tid_key);
                        this.mainRummy.poolScoreboardView = i;
                    }
                }));
            }
            catch (e) {
                TLog.printError("trycatch showTotalSettlementInfo,error", e);
            }
        }
    }
    showSwitchNotice(e, i, m) {
        if (window.InSwitchScene) {
            TLog.printError("-------- showSwitchNotice switchScene stop preload res.");
        }
        else {
            try {
                ToolUtils.loadCommonPrefab(null, BundleNameDefined.bundle_rummy, "prefab/GameRummy_switch_notice", (s => {
                    if (sys.isObjectValid(s) && s.isValid && sys.isObjectValid(this.mainRummy) && ToolUtils.isObjValid(this.mainRummy.pop_layer4)) {
                        let t = instantiate(s);
                        t.name = "switch_notice";
                        t.parent = this.mainRummy.pop_layer4;
                        t.getComponent(GameRummy_switch_notice).initView(this.mainRummy, this.mainRummy.tid_key, e, i, m);
                    }
                }));
            }
            catch (e) {
                TLog.printError("trycatch showSwitchNotice,error", e);
            }
        }
    }
    showRoomPerformance(e) {
        if (window.InSwitchScene) {
            TLog.printError("-------- showRoomPerformance switchScene stop preload res.");
        }
        else {
            try {
                ToolUtils.loadCommonPrefab(null, BundleNameDefined.bundle_rummyTopUI, "prefab/room_performance", (i => {
                    if (sys.isObjectValid(i) && i.isValid && sys.isObjectValid(this.mainRummy) && ToolUtils.isObjValid(this.mainRummy.pop_layer5)) {
                        let t = instantiate(i);
                        t.parent = this.mainRummy.pop_layer5;
                        this.mainRummy.roomPerformance = t.getComponent("RoomPerformance");
                        this.mainRummy.roomPerformance.initRummy(this.mainRummy, e);
                    }
                }));
            }
            catch (e) {
                TLog.printError("trycatch showSwitchNotice,error", e);
            }
        }
    }
    cancelHistoryLoad() {
        this.historyLoadToken = null;
        this.pendingHistoryData = null;
    }
    showHistoryView(e, i) {
        try {
            const main = this.mainRummy;
            if (!ToolUtils.isObjValid(main.node) || !ToolUtils.isObjValid(main.pop_layer3)) return;
            if (sys.isObjectValid(i)) this.pendingHistoryData = i;
            if (ToolUtils.isObjValid(main.gameHistoryView)) {
                const view = main.gameHistoryView.getComponent("RummyGameOverAlert");
                view.tid_key = main.tid_key;
                if (sys.isObjectValid(i)) view.updateInfo(1, i, this.onDealBtnAction.bind(this), true);
                if (e == 1) {
                    view.isShowEndView(true);
                    view.setLandscapeShow();
                }
                return;
            }
            if (e != 1 || this.historyLoadToken) return;
            // The click and 7035 reply can arrive before the same prefab loads.
            // Coalesce them, keeping the latest data and only one view.
            const token = {};
            const key = main.tid_key;
            this.historyLoadToken = token;
            ToolUtils.loadCommonPrefab(RummyDataManager.shared().gameOverPrefab,
                BundleNameDefined.bundle_rummy, "prefab/rummy_gameover", prefab => {
                    if (this.historyLoadToken !== token) return;
                    this.historyLoadToken = null;
                    if (!ToolUtils.isObjValid(prefab) || !ToolUtils.isObjValid(main.node) ||
                        !ToolUtils.isObjValid(main.pop_layer3) || main.tid_key !== key) return;
                    RummyDataManager.shared().gameOverPrefab = prefab;
                    const node = instantiate(prefab);
                    node.name = "rummy_history";
                    main.gameHistoryView = node;
                    const view = node.getComponent("RummyGameOverAlert");
                    view.tid_key = key;
                    view.fromtype = 1;
                    node.parent = main.pop_layer3;
                    const data = this.pendingHistoryData;
                    if (sys.isObjectValid(data)) view.updateInfo(1, data, this.onDealBtnAction.bind(this), true);
                    view.isShowEndView(true);
                    view.startShowAnim();
                    view.setLandscapeShow();
                });
        } catch (error) {
            this.cancelHistoryLoad();
            TLog.printError("showHistoryView", error);
        }
    }
    showOpenCardAlert(e = [], i) {
        if (!ToolUtils.isObjValid(this.mainRummy.openCardNode)) {
            return void ToolUtils.loadCommonPrefab(this.mainRummy.openCardPrefab, BundleNameDefined.bundle_rummy, "prefab/rummy_opencard", (t => {
                this.mainRummy.openCardPrefab = t;
                try {
                    if (ToolUtils.isObjValid(this.mainRummy.pop_layer6)) {
                        this.mainRummy.openCardNode = instantiate(this.mainRummy.openCardPrefab);
                        // Above table controls and tips, but below settlement/confirmation dialogs.
                        this.mainRummy.openCardNode.parent = this.mainRummy.pop_layer6;
                        this.mainRummy.openCardNode.active = true;
                        let t = this.mainRummy.openCardNode.getComponent(RummyOpenCardsAlert);
                        t.tid_key = this.mainRummy.tid_key;
                        t.setCloseCallBack((() => {
                            this.mainRummy.isOpenQipai = false;
                            this.mainRummy.actionTs.changeOpenCardStatus(true, this.mainRummy);
                        }));
                        t.changeJpqDiImage();
                        t.setLandscapeShow();
                        t.refreshOpenCardPlayerPostion();
                        t.startShowAnim();
                        t.showXiajiaPosition();
                        t.refreshDeskImage();
                        t.updateInfo(e, i);
                    }
                }
                catch (e) {
                }
            }));
        }
        let t = this.mainRummy.openCardNode.getComponent(RummyOpenCardsAlert);
        t.tid_key = this.mainRummy.tid_key;
        t.pushGamePopNode();
        let m = !this.mainRummy.openCardNode.active;
        this.mainRummy.openCardNode.active = true;
        t.changeJpqDiImage();
        m && (t.refreshOpenCardPlayerPostion(), t.startShowAnim(), t.showXiajiaPosition(), t.refreshDeskImage());
        t.updateInfo(e, i);
    }
    removeRoomTask(e = false) {
        let i = director.getScene().getChildByName("Canvas");
        if (ToolUtils.isObjValid(i)) {
            let t = i.getChildByName("room_task");
            ToolUtils.isObjValid(t) && t.destroy();
            let a = i.getChildByName("reward_tips");
            if (ToolUtils.isObjValid(a) && !this.checkFlopCashView() && e) {
                a.getComponent("RewardTips").delayToClose(5);
            }
        }
    }
    checkFlopCashView() {
        let e = director.getScene().getChildByName("Canvas");
        if (sys.isObjectValid(e)) {
            let i = e.getChildByName("beginner_flip_task_game");
            if (ToolUtils.isObjValid(i)) {
                return true;
            }
        }
        return false;
    }
    showGameChat() {
        if (window.InSwitchScene) {
            TLog.printError("-------- showGameChat switchScene stop preload res.");
        }
        else {
            try {
                ToolUtils.isObjValid(this.mainRummy.game_chatNode) ? (this.mainRummy.game_chatTs = this.mainRummy.game_chatNode.getComponent("RummyChatRoot"), this.mainRummy.game_chatTs.initView(this.mainRummy)) : ToolUtils.loadCommonPrefab(null, BundleNameDefined.bundle_rummyTopUI, "prefab/game_chat", (e => {
                    if (sys.isObjectValid(this.mainRummy) && ToolUtils.isObjValid(this.mainRummy.chatRoot)) {
                        let i = instantiate(e);
                        i.name = "game_chat";
                        i.parent = this.mainRummy.chatRoot;
                        this.mainRummy.game_chatNode = i;
                        this.mainRummy.game_chatTs = i.getComponent("RummyChatRoot");
                        this.mainRummy.game_chatTs.initView(this.mainRummy);
                    }
                }));
            }
            catch (e) {
                TLog.printError("trycatch showGameChat,error", e);
            }
        }
    }
    refreshTask() {
        try {
            let e = this.mainRummy.pop_layer6.getChildByName("RummyDailyTaskBubble");
            if (ToolUtils.isObjValid(e) && e.active) {
                let i = e.getComponent("RummyNewDailyTaskBubble");
                i && sys.isObjectValid(i) && i.refreshDailyTaskList(true);
            }
        }
        catch (e) {
            TLog.printError("------- refreshTask err:", e);
        }
    }
    showRoomActRank(e = null) {
        if (!ToolUtils.judgeIfInRummy()) {
            return;
        }
        let i = this.mainRummy.pop_layer6;
        if (ToolUtils.isObjValid(this.mainRummy.room_act_rankNode)) {
            return void this.mainRummy.room_act_rankNode.getComponent("GameActLeaderBoard").initParaData(e);
        }
        ToolUtils.loadCommonPrefab(RummyDataManager.shared().actRankPrefab, BundleNameDefined.Bundle_room_act_rank, "prefab/game_act_leaderboard", (t => {
            try {
                if (!ToolUtils.isObjValid(this.mainRummy.pop_layer6)) {
                    return;
                }
                if (!ToolUtils.judgeIfInRummy()) {
                    return;
                }
                RummyDataManager.shared().actRankPrefab = t;
                let m = i.getChildByName("game_act_leaderboard");
                ToolUtils.isObjValid(m) ? m.active = true : (m = instantiate(t), m.parent = i);
                m.getComponent("GameActLeaderBoard").initParaData(e);
            }
            catch (e) {
                TLog.printError("showRoomActRank error= " + e);
            }
        }));
    }
    showSelectJokerAlert(e, i = null) {
        if (!ToolUtils.judgeIfInRummy()) {
            return;
        }
        let t = RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key);
        if (!i) {
            return void this.mainRummy.rummyLogicProcessing.send_choose_joker_request(t.laizicard);
        }
        if (!ToolUtils.isObjValid(this.mainRummy.switchJokerNode)) {
            return void ToolUtils.loadCommonPrefab(this.mainRummy.switchJokerPrefab, BundleNameDefined.bundle_rummy, "prefab/rummy_bump_switch", (t => {
                this.mainRummy.switchJokerPrefab = t;
                try {
                    if (!ToolUtils.isObjValid(this.mainRummy.switchJokerNode) && ToolUtils.isObjValid(this.mainRummy.pop_layer4)) {
                        this.mainRummy.switchJokerNode = instantiate(this.mainRummy.switchJokerPrefab);
                        this.mainRummy.switchJokerNode.parent = this.mainRummy.pop_layer4;
                        this.mainRummy.switchJokerNode.active = true;
                        let t = this.mainRummy.switchJokerNode.getComponent(RummyBumpSwitchAlert);
                        t.tid_key = this.mainRummy.tid_key;
                        t.setCloseCallBack(((e, i) => {
                            e && ("chooseJoker" != e && "changeJoker" != e || this.mainRummy.onDealBtnAction(e, i));
                        }));
                        t.setLandscapeShow();
                        t.startShowAnim();
                        t.updateInfo(e, i, RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key).laizicard, this.mainRummy.cardsTs.getShouPaiCardValues());
                        t.updateBestLaizi(RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key).best_lz);
                    }
                }
                catch (e) {
                    TLog.printError("showSelectJokerAlert1 error= " + e);
                }
            }));
        }
        let m = this.mainRummy.switchJokerNode.getComponent(RummyBumpSwitchAlert);
        m.tid_key = this.mainRummy.tid_key;
        let s = !this.mainRummy.switchJokerNode.active;
        this.mainRummy.switchJokerNode.active = true;
        s && m.startShowAnim();
        m.updateInfo(e, i, t.laizicard, this.mainRummy.cardsTs.getShouPaiCardValues());
        m.updateBestLaizi(t.best_lz);
    }
    updateBestLaizi() {
        if (ToolUtils.isObjValid(this.mainRummy.switchJokerNode)) {
            this.mainRummy.switchJokerNode.getComponent(RummyBumpSwitchAlert).updateBestLaizi(RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key).best_lz);
        }
    }
    updateBatchJokerInfo(e) {
        if (!ToolUtils.judgeIfInRummy()) {
            return;
        }
        let i = RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key);
        if (ToolUtils.isObjValid(this.mainRummy.switchJokerNode)) {
            let t = this.mainRummy.switchJokerNode.getComponent(RummyBumpSwitchAlert);
            t.tid_key = this.mainRummy.tid_key;
            let a = !this.mainRummy.switchJokerNode.active;
            this.mainRummy.switchJokerNode.active = true;
            a && t.startShowAnim();
            t.updateInfo(null, null, i.laizicard, this.mainRummy.cardsTs.getShouPaiCardValues());
            t.updateBatchJokerInfo(e, i.lastLaizicard);
            t.updateBestLaizi(i.best_lz);
        }
        else {
            ToolUtils.loadCommonPrefab(this.mainRummy.switchJokerPrefab, BundleNameDefined.bundle_rummy, "prefab/rummy_bump_switch", (i => {
                this.mainRummy.switchJokerPrefab = i;
                try {
                    if (!ToolUtils.isObjValid(this.mainRummy.switchJokerNode) && ToolUtils.isObjValid(this.mainRummy.pop_layer4)) {
                        this.mainRummy.switchJokerNode = instantiate(this.mainRummy.switchJokerPrefab);
                        this.mainRummy.switchJokerNode.parent = this.mainRummy.pop_layer4;
                        this.mainRummy.switchJokerNode.active = true;
                        let i = this.mainRummy.switchJokerNode.getComponent(RummyBumpSwitchAlert);
                        i.tid_key = this.mainRummy.tid_key;
                        i.setCloseCallBack(((e, i) => {
                            e && ("chooseJoker" != e && "changeJoker" != e || this.mainRummy.onDealBtnAction(e, i));
                        }));
                        i.setLandscapeShow();
                        i.startShowAnim();
                        i.updateInfo(null, null, RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key).laizicard, this.mainRummy.cardsTs.getShouPaiCardValues());
                        i.updateBatchJokerInfo(e, RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key).lastLaizicard);
                        i.updateBestLaizi(RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key).best_lz);
                    }
                }
                catch (e) {
                    TLog.printError("updateBatchJokerInfo1 error= " + e);
                }
            }));
        }
    }
}
