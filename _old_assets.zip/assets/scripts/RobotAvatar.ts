import { isValid, Node, resources, Size, Sprite, SpriteFrame, UITransform } from 'cc';

/** Local practice display preference survives table reconnects. */
export default class RobotAvatar {
    static readonly KEY = 'robot_opponent';
    private static readonly NODE_NAME = '__robotAvatar';
    private static frame: SpriteFrame | null = null;
    private static pending: Promise<SpriteFrame> | null = null;

    private static roomModes = new Map<number, number>();

    static setRoomMode(vid: number, mode: number): void {
        this.roomModes.set(Number(vid), mode === 1 ? 1 : 0);
    }

    static roomMode(vid: number): number {
        return this.roomModes.get(Number(vid)) || 0;
    }

    static isRobot(player: { uid?: number | string; name?: string }, practiceRobotMode = false): boolean {
        const uid = Number(player?.uid);
        return Number.isInteger(uid) && uid > 0 && uid <= 300000 &&
            (practiceRobotMode || /^Robot [1-6]$/.test(player?.name || ''));
    }

    private static load(): Promise<SpriteFrame> {
        if (this.frame && isValid(this.frame)) return Promise.resolve(this.frame);
        if (!this.pending) {
            this.pending = new Promise<SpriteFrame>((resolve, reject) => {
                resources.load('picture/robot_opponent/spriteFrame', SpriteFrame, (error, frame) => {
                    if (error) { reject(error); return; }
                    this.frame = frame;
                    frame.addRef();
                    resolve(frame);
                });
            }).finally(() => { this.pending = null; });
        }
        return this.pending;
    }

    static apply(head: Node, robot: boolean, dimensions: Size): boolean {
        let overlay = head.getChildByName(this.NODE_NAME);
        if (!robot) {
            if (overlay) overlay.active = false;
            return false;
        }
        head.getComponent(UITransform).setContentSize(dimensions);
        if (!overlay) {
            overlay = new Node(this.NODE_NAME);
            overlay.layer = head.layer;
            overlay.addComponent(UITransform);
            overlay.addComponent(Sprite).sizeMode = Sprite.SizeMode.CUSTOM;
            head.addChild(overlay);
        }
        overlay.active = true;
        overlay.getComponent(UITransform).setContentSize(dimensions);
        // Render inside the existing head node and its circular mask. Older
        // network-avatar callbacks may finish, but cannot paint over this child.
        head.getComponent(Sprite).spriteFrame = null;
        const target = overlay;
        this.load().then(frame => {
            if (isValid(target)) target.getComponent(Sprite).spriteFrame = frame;
        }).catch(error => console.warn('Robot avatar could not be loaded', error));
        return true;
    }
}
