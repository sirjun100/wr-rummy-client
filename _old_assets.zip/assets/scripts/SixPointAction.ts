// @ts-nocheck
// Recovered from index.js:521
import { _decorator, Label, Node, sp, sys } from "cc";
import Parent from "./Parent";
import PushCenter from "./PushCenter";
import SoundManager from "./SoundManager";
import { SixPointManager } from "./SixPointManager";
import { ToolUtils } from "./ToolUtils";
import { AdapDirection } from "./BaseLayer";
const { ccclass, property } = _decorator;
@ccclass("SixPointAction")
export default class SixPointAction extends Parent {
    public _TAG: string = "SixPointAction";
    public lastClick: number = 0;
    public gameCallback: any = null;
    @property(Node)
    public operateView: Node = null;
    onLoad() {
        this.adapptationScreen();
    }
    onDestroy() {
        super.onDestroy();
        this.unscheduleAllCallbacks();
        PushCenter.shared().removeListenersByTag(this);
    }
    start() {
        this.initView();
        this.addPushNotify();
    }
    setCallBack(e) {
        this.gameCallback = e;
    }
    addPushNotify() {
    }
    initView() {
    }
    adapptationScreen() {
        let e = this.node.getChildByName("menu_btn"), t = this.node.getChildByName("add_chip_btn"), i = this.node.getChildByName("act_node");
        this.resetUiPos(e, AdapDirection.Left, true, 1, true);
        this.resetUiPos(t, AdapDirection.Right, true, 1, true, true);
        this.resetUiPos(i, AdapDirection.Right, true, 1, true, true);
    }
    updateGullakBtnStatus(e, t, i) {
        let n = this.node.getChildByName("act_node").getChildByName("gullak_btn");
        if (ToolUtils.isObjValid(n) && (n.active = 1 == e, 1 == e)) {
            let e = n.getChildByName("anim").getComponent(sp.Skeleton);
            e.clearTracks();
            e.setToSetupPose();
            i ? (e.setAnimation(0, "2", false), e.setCompleteListener((() => {
                e.setCompleteListener(null);
                e.clearTracks();
                e.setToSetupPose();
                0 == t ? e.setAnimation(0, "0", true) : e.setAnimation(0, "1", true);
            }))) : 0 == t ? e.setAnimation(0, "0", true) : e.setAnimation(0, "1", true);
        }
    }
    resetBetAmtView() {
        if (SixPointManager.shared().bet_configVec.length > 0) {
            for (let e = 0; e < SixPointManager.shared().bet_configVec.length; e++) {
                let t = SixPointManager.shared().bet_configVec[e], i = "bet" + e, n = this.operateView.getChildByName(i);
                ToolUtils.isObjValid(n) && (n.getChildByName("num").getComponent(Label).string = ToolUtils.parse_ChipNum2(t));
            }
        }
    }
    updateCurBetNum(e) {
        if (SixPointManager.shared().bet_configVec.length > 0) {
            for (let t = 0; t < SixPointManager.shared().bet_configVec.length; t++) {
                let i = SixPointManager.shared().bet_configVec[t], n = "bet" + t, a = this.operateView.getChildByName(n);
                ToolUtils.isObjValid(a) && (a.getChildByName("select").active = i == e);
            }
        }
    }
    touchBtnEvent(e, t) {
        SoundManager.shared().playFx("click");
        sys.now() - this.lastClick < 200 || (this.lastClick = sys.now(), sys.isObjectValid(this.gameCallback) && this.gameCallback(t));
    }
    setRandomAdBtnEnable(e) {
    }
    setAdTreasureBtnEnable(e) {
    }
    updatePlayerNum(e) {
        let t = this.node.getChildByName("player7");
        sys.isObjectValid(e) && e > 0 ? (t.getChildByName("numbg").active = true, t.getChildByName("numbg").getChildByName("num").getComponent(Label).string = String(e)) : t.getChildByName("numbg").active = false;
    }
}
