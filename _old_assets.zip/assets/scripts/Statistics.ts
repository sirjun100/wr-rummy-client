// @ts-nocheck
// Recovered from index.js:601
export let Statistics;
(Statistics = undefined);
(function (t) {
    t[t.ShareToFacebook = 10001] = "ShareToFacebook";
    t[t.ShareToWhatsapp = 10002] = "ShareToWhatsapp";
    t[t.SharetToFriends = 10003] = "SharetToFriends";
    t[t.SharetToCopy = 10004] = "SharetToCopy";
    t[t.ShareToTwitter = 10005] = "ShareToTwitter";
}(Statistics || (Statistics = {})));
