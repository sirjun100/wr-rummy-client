// @ts-nocheck
// Recovered from index.js:627
import { _decorator, Label } from "cc";
import Utils from "./Utils";
import SoundManager from "./SoundManager";
import BaseLayer from "./BaseLayer";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("TipAlert")
export default class TipAlert extends BaseLayer {
    @property(Label)
    public label: Label = null;
    @property
    public text: string = "hello";
    start() {
        super.start();
    }
    onclickByClose(e, t) {
        SoundManager.shared().playFx("click");
        ToolUtils.isObjValid(this.node) && this.node.destroy();
    }
    onClickByBtn(e, t) {
        SoundManager.shared().playFx("click");
        ToolUtils.isObjValid(this.node) && this.node.destroy();
    }
    setFlag(e) {
        1 == e ? (Utils.shared().setStr(this.node.getChildByName("flag"), "Deposit Cash"), this.node.getChildByName("label0").active = false, this.node.getChildByName("label1").active = true) : 2 == e && (Utils.shared().setStr(this.node.getChildByName("flag"), "Winnings Cash"), this.node.getChildByName("label0").active = false, this.node.getChildByName("label2").active = true);
    }
}
