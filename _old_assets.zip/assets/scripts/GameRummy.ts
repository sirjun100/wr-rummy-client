// @ts-nocheck
// Recovered from index.js:165
import { _decorator, assetManager, Button, color, director, game, instantiate, Label, macro, Node, Prefab, size, Sprite, SpriteFrame, sys, UITransform, v3, Vec3, view } from "cc";
import Parent, { AdapDirection } from "./Parent";
import { TransferPlatform } from "./TransferPlatform";
import PushCenter from "./PushCenter";
import { TLog } from "./TLog";
import TweenTool from "./TweenTool";
import Utils from "./Utils";
import GameConfig from "./GameConfig";
import BundleNameDefined from "./BundleNameDefined";
import NetConfig from "./NetConfig";
import PhpReportDefined from "./PhpReportDefined";
import PushEvent from "./PushEvent";
import ReportConfig from "./ReportConfig";
import { DeskInfo } from "./DeskInfo";
import User from "./User";
import gameNetworkDelay from "./gameNetworkDelay";
import HttpManager from "./HttpManager";
import LabaServer from "./LabaServer";
import Server from "./Server";
import SoundManager from "./SoundManager";
import MainRummy from "./MainRummy";
import RummyCmd from "./RummyCmd";
import RummyDataManager, { RUMMY_GAME_TYPE } from "./RummyDataManager";
import { RummyMutilDesk } from "./RummyMutilDesk";
import i18nMgr from "./i18nMgr";
import CommDefine from "./CommDefine";
import HowToPlayDefined from "./HowToPlayDefined";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("GameRummy")
export class GameRummy extends Parent {
    @property(Node)
    public contentNode: Node = null;
    @property([Node])
    public deskNodes: Node[] = [];
    @property(Node)
    public add_game_node: Node = null;
    public addGameAlert: any = null;
    @property(Prefab)
    public rummyPrefab: Prefab = null;
    public rummyNodes: any[] = [];
    public gameOverPrefab: any = null;
    public RummyTotalSettlementPrefab: any = null;
    public pointsMatchOverPrefab: any = null;
    @property(Node)
    public rootNode: Node = null;
    @property(Node)
    public room_bgNode: Node = null;
    @property(Node)
    public deskNode: Node = null;
    @property(Node)
    public circleBgNode: Node = null;
    @property(Node)
    public hallBgNode: Node = null;
    @property(Node)
    public createDeskBubble: Node = null;
    @property(Node)
    public bottom_bgNode: Node = null;
    @property(Sprite)
    public signal: Sprite = null;
    @property(Label)
    public delay_ms: Label = null;
    @property([SpriteFrame])
    public mobile_signals: SpriteFrame[] = [];
    @property([SpriteFrame])
    public wifi_signals: SpriteFrame[] = [];
    @property([SpriteFrame])
    public table_bg: SpriteFrame[] = [];
    @property([SpriteFrame])
    public desk_bg: SpriteFrame[] = [];
    @property(SpriteFrame)
    public hall_ipad_bg: SpriteFrame = null;
    @property([SpriteFrame])
    public fourDesk_bgs: SpriteFrame[] = [];
    @property(Node)
    public top_bgNode: Node = null;
    @property([SpriteFrame])
    public match_bgs: SpriteFrame[] = [];
    @property([SpriteFrame])
    public match_circles: SpriteFrame[] = [];
    @property([SpriteFrame])
    public chipsMasks: SpriteFrame[] = [];
    public mutil_desk_ts: any = null;
    public desk_tid_keys: any[] = [];
    public backgroundSatyTime: number = 0;
    public isNetworkDelay: boolean = true;
    public networkDelay: number = 0;
    public hasRequestCreateDesk: boolean = false;
    public createDelayAction: any = null;
    public nClickAddTime: number = 0;
    public _enterStartTime: number = 0;
    public syncDeskNode: any = null;
    public desk_bg_index: number = 0;
    public table_bg_index: number = 0;
    public gameSettingPrefab: any = null;
    public gameSettingAlert: any = null;
    public _bInitDesk: boolean = false;
    public createMultipleDeskInfo: any = null;
    onDestroy() {
        super.onDestroy();
        this.createDelayAction && TweenTool.stopAction(this.createDelayAction);
        gameNetworkDelay.shared().removechild();
        Server.shared().onBackGroundLink();
        PushCenter.shared().removeListenersByTag(this);
        this.unscheduleAllCallbacks();
    }
    onLoad() {
        ToolUtils.report_time_param.gameOnLoad = sys.now();
        sys.os !== sys.OS.IOS && sys.os !== sys.OS.OSX && TransferPlatform.shared().setAutoAdapt(1);
        this.initUi();
        i18nMgr.shared().initLanguage();
        this.fitLuckyTheme();
        1 == GameConfig.CHIPS_MODLE && (this.hallBgNode.getChildByName("hall").getChildByName("bg").getComponent(Sprite).spriteFrame = this.chipsMasks[0], this.hallBgNode.getChildByName("bottom").getComponent(Sprite).spriteFrame = this.chipsMasks[1], this.hall_ipad_bg = this.chipsMasks[2]);
    }
    fitLuckyTheme() {
        0 != GameConfig.NATIVE_GAME_APP_TYPE && (this.hallBgNode.getChildByName("hall").getChildByName("top_test_bg").getComponent(Sprite).color = color(12, 26, 60), this.hallBgNode.getChildByName("hall").getChildByName("top_bg").getComponent(Sprite).color = color(12, 26, 60));
    }
    start() {
        ToolUtils.report_time_param.gameStart = sys.now();
        RummyDataManager.shared().resetData();
        RummyDataManager.shared().history_data_open = User.shared().history_data_open;
        User.shared().fromGame = 1;
        this.hasRequestCreateDesk = false;
        ToolUtils.switchSceneTye = -1;
        ToolUtils.bSwitchToGame = false;
        view.getVisibleSize();
        this.resetBgView();
        window.InHallScene = false;
        window.InRummyScene = true;
        window.InSwitchScene = false;
        window.IsBackToHallLoad = false;
        macro.ENABLE_MULTI_TOUCH = false;
        SoundManager.shared().switchBgMusic(1);
        let e = new Node;
        this.node.addChild(e);
        RummyDataManager.shared().sceneNode = e;
        let t = new Node;
        if (RummyDataManager.shared().openCardInfos.clear(), RummyDataManager.shared().actionNode = t, RummyDataManager.shared().rummyInfos.clear(), RummyDataManager.shared().chat_Type = 0, RummyDataManager.shared().dailyTaskBubblePrefab = null, RummyDataManager.shared().taskBubblePrefab = null, RummyDataManager.shared().gameOverPrefab = this.gameOverPrefab, RummyDataManager.shared().RummyTotalSettlementPrefab = this.RummyTotalSettlementPrefab, RummyDataManager.shared().pointsMatchOverPrefab = this.pointsMatchOverPrefab, this.syncDeskNode = new Node, this.node.addChild(this.syncDeskNode), ToolUtils.deskInfos.size > 0) {
            let e = 1;
            for (let t of ToolUtils.deskInfos.keys()) {
                this.desk_tid_keys.push(t);
                let s = this, i = t;
                setTimeout((() => {
                    s.addRummyNode(i, true);
                }), game.frameTime / 1000 * e);
                e += 1;
            }
        }
        for (let e = 0, t = this.deskNodes.length; e < t; e++) {
            this.deskNodes[e].active = false;
        }
        User.shared().curDeskIndex = this.desk_tid_keys.indexOf(User.shared().curTid_key);
        -1 == User.shared().curDeskIndex && (User.shared().curDeskIndex = 0, User.shared().curTid_key = this.desk_tid_keys[User.shared().curDeskIndex]);
        ToolUtils.getOrientation() || this.node.setRotationFromEuler(new Vec3(0, 0, -90));
        this.resetUiPos(this.add_game_node, AdapDirection.Left, true, 1, true);
        this.initAddGameNode();
        this.initPushCenter();
        for (let e = 0, t = this.desk_tid_keys.length; e < t; e++) {
            this.deskNodes.length > e && (this.mutil_desk_ts.changeSmallDeskUIVisibile(e, true), this.mutil_desk_ts.resetSmallTable(e));
        }
        if (this.showSmallDeskAddImage(), this.changeRummyNodeVisibile(User.shared().curDeskIndex), this.changeSmallDeskNodeSelect(User.shared().curDeskIndex), ToolUtils.deskInfos.has(User.shared().curTid_key)) {
            let e = ToolUtils.deskInfos.get(User.shared().curTid_key);
            if (sys.isObjectValid(e) && 4 == e.mode) {
                let e = { lobby: 1, game: 0, data: null };
                sys.localStorage.setItem(User.shared().data.uid + "recommendRoomNew", ToolUtils.toJsonString(e));
                sys.localStorage.removeItem(User.shared().data.uid + "addRecommendRoomNew");
            }
        }
        if (gameNetworkDelay.shared().loadNode(), this.regEvent(), 1 == ToolUtils.heart_open && (this.unschedule(this.netWorkDelayUpdate), this.schedule(this.netWorkDelayUpdate, 2)), ToolUtils.in_isGuideRoom >= 1) {
            User.shared().isInPerformanceRoom = 0;
            User.shared().curTid_key = CommDefine.NewerGuideRoomTidkey;
            let e = new DeskInfo;
            e.tid_key = ToolUtils.isSafeString(CommDefine.NewerGuideRoomTidkey);
            e.vid = 0;
            e.pnum = 2;
            ToolUtils.deskInfos.set(ToolUtils.isSafeString(CommDefine.NewerGuideRoomTidkey), e);
            this.addRummyNode(User.shared().curTid_key);
            this.desk_tid_keys.push(User.shared().curTid_key);
        }
        this.desk_tid_keys.length > 1 || 0 === ToolUtils.in_isGuideRoom ? User.shared().send_request_game_tableinfo() : (gameNetworkDelay.shared().setActiveDisconnect(true), this.mutil_desk_ts.changeAddVisibile(1, false), this.mutil_desk_ts.changeAddLockVisible(1, false));
        Utils.shared().showLoading(15, false, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 2, 0, ToolUtils.getIsNormalDirection());
        }), ToolUtils.getIsNormalDirection(), 1);
        TweenTool.delayAct(this.node, (() => {
            ToolUtils.preLoadBundlePrefab(BundleNameDefined.bundle_public, "prefab/menu_alert", null);
        }), 0.8, true);
        let s = this, i = false;
        TweenTool.delayAct(this.node, (() => {
            let e = view.getVisibleSize();
            if (sys.isNative && Math.abs(e.height - GameConfig.REAL_SCREEN_WIDTH) > 10) {
                TLog.printError(" Rummy start VisibleSize err:", e.width, e.height);
                User.shared().alertTip = "There is something wrong, please try again";
                s.backToHall();
            }
            else {
                for (let e = 0, t = s.rummyNodes.length; e < t; e++) {
                    if (ToolUtils.isObjValid(s.rummyNodes[e])) {
                        let t = s.rummyNodes[e].getComponent(MainRummy);
                        sys.isObjectValid(t) && sys.isObjectValid(t.actionTs) && (t.actionTs.checkBtnPos() || (TLog.printError(" Rummy btn pos err!"), User.shared().alertTip = "There is something wrong, please try again", s.backToHall(), i = true));
                        break;
                    }
                }
                if (!i) {
                    sys.os !== sys.OS.IOS && sys.os !== sys.OS.OSX && Utils.shared().releaseHallBundleAssets(true);
                    let e = [{ dir: "rummy/main_sound", time: 0.5 }, { dir: "rummy/card_sound", time: 0.5 }, { dir: "rummy/chat_sound", time: 0.5 }];
                    s.loadRummySounds(e);
                }
            }
        }), 1.2, true);
        TweenTool.delayAct(this.node, (() => {
            RummyDataManager.shared().bCanGoBack = true;
        }), 3, true);
        this._enterStartTime = sys.now();
        User.shared().sw_reportGameTime && (User.shared().sw_reportGameTime = false, HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Login, event: ReportConfig.common.report_game_time, reportTime: ToolUtils.report_time_param }));
        ToolUtils.report_time_param = {};
        TransferPlatform.shared().logEvent_firebase(ReportConfig.firebase_evt.jump_to_game);
    }
    loadRummySounds(e, t) {
        let s = this, i = 0, a = () => {
            if (i >= e.length) {
                return void (t && t());
            }
            try {
                SoundManager.shared().preLoadBundleSounds(BundleNameDefined.bundle_sound, e[i].dir);
            }
            catch (e) {
                return i++, void s.scheduleOnce((() => {
                    a();
                }), 0.1);
            }
            let d = 0.5;
            sys.isObjectValid(e[i]) && sys.isObjectValid(e[i].time) && (d = e[i].time || 0.5);
            i++;
            s.scheduleOnce((() => {
                a();
            }), d);
        };
        a();
    }
    resetBgView() {
        this.hallBgNode.getComponent(UITransform).setContentSize(GameConfig.REAL_SCREEN_WIDTH, GameConfig.REAL_SCREEN_HEIGHT);
        let e = GameConfig.REAL_SCREEN_HEIGHT;
        e < 1560 && (e = 1560);
        this.room_bgNode.getComponent(UITransform).setContentSize(size(e, GameConfig.REAL_SCREEN_WIDTH));
        this.deskNode.getComponent(UITransform).setContentSize(size(e, GameConfig.REAL_SCREEN_WIDTH));
        this.circleBgNode.getComponent(UITransform).setContentSize(size(e, GameConfig.REAL_SCREEN_WIDTH));
        this.bottom_bgNode.getComponent(UITransform).setContentSize(size(e, 90));
        ToolUtils.isPadPlatform() && (this.resetUiPos(this.top_bgNode, AdapDirection.Up, true, 1, false), this.resetUiPos(this.signal.node, AdapDirection.Up, true, 1, false), this.resetUiPos(this.add_game_node, AdapDirection.Down, true, 1, false), this.resetUiPos(this.rootNode.getChildByName("share_btn"), AdapDirection.Down, true, 1, false), this.resetUiPos(this.bottom_bgNode, AdapDirection.Down, true, 1, false));
    }
    initUi(e = false) {
        if (!e && this._bInitDesk) {
            return;
        }
        this._bInitDesk = true;
        let t = 4 == User.shared().styles[0] ? 1 : 0;
        5 == User.shared().styles[0] && (t = 2);
        let s, i, a = User.shared().styles[0] - 1;
        if (this.table_bg_index = t, this.desk_bg_index = a, ToolUtils.deskInfos.get(User.shared().curTid_key) && 1 == ToolUtils.deskInfos.get(User.shared().curTid_key).special_mode || RummyDataManager.shared().rummyInfos.has(User.shared().curTid_key) && 1 == RummyDataManager.shared().rummyInfos.get(User.shared().curTid_key).gameRummyMode ? 0 == this.desk_bg_index ? this.deskNode.getComponent(Sprite).spriteFrame = this.fourDesk_bgs[this.desk_bg_index] : (i = this.desk_bg_index + 1, s = "rummy_big_four_table_" + i, User.shared().remoteImagesMap.has(s) && sys.isObjectValid(User.shared().remoteImagesMap.get(s)) ? this.deskNode.getComponent(Sprite).spriteFrame = User.shared().remoteImagesMap.get(s) : Utils.shared().loadRemoteDeskImage(this.deskNode, s)) : this.checkIsMatchRoom() ? (i = 7, s = "rummy_card_table_bg_0" + i, User.shared().remoteImagesMap.has(s) && sys.isObjectValid(User.shared().remoteImagesMap.get(s)) ? this.deskNode.getComponent(Sprite).spriteFrame = User.shared().remoteImagesMap.get(s) : Utils.shared().loadRemoteDeskImage(this.deskNode, s)) : 0 == this.desk_bg_index ? this.deskNode.getComponent(Sprite).spriteFrame = this.desk_bg[this.desk_bg_index] : (i = this.desk_bg_index, s = "rummy_card_table_bg_0" + i, User.shared().remoteImagesMap.has(s) && sys.isObjectValid(User.shared().remoteImagesMap.get(s)) ? this.deskNode.getComponent(Sprite).spriteFrame = User.shared().remoteImagesMap.get(s) : Utils.shared().loadRemoteDeskImage(this.deskNode, s)), this.checkIsPointsMatch()) {
            let e = 0;
            5 == User.shared().styles[0] && (e = 1);
            this.room_bgNode.getComponent(Sprite).spriteFrame = this.match_bgs[e];
            this.circleBgNode.getComponent(Sprite).spriteFrame = this.match_circles[e];
            this.circleBgNode.active = true;
        }
        else {
            this.checkIsMatchRoom() ? (i = 6, s = "rummy_game_bg_" + i, User.shared().remoteImagesMap.has(s) && sys.isObjectValid(User.shared().remoteImagesMap.get(s)) ? this.room_bgNode.getComponent(Sprite).spriteFrame = User.shared().remoteImagesMap.get(s) : Utils.shared().loadRemoteDeskImage(this.room_bgNode, s), this.circleBgNode.active = false) : (0 == this.table_bg_index ? this.room_bgNode.getComponent(Sprite).spriteFrame = this.table_bg[this.table_bg_index] : (i = this.table_bg_index + 1, s = "rummy_game_bg_" + i, User.shared().remoteImagesMap.has(s) && sys.isObjectValid(User.shared().remoteImagesMap.get(s)) ? this.room_bgNode.getComponent(Sprite).spriteFrame = User.shared().remoteImagesMap.get(s) : Utils.shared().loadRemoteDeskImage(this.room_bgNode, s)), this.circleBgNode.active = false);
        }
    }
    checkIsPointsMatch() {
        let e = ToolUtils.deskInfos.get(User.shared().curTid_key), t = false;
        e && 4 == e.mode && 3 == e.match_mode && (t = true);
        let s = RummyDataManager.shared().rummyInfos.get(User.shared().curTid_key);
        return sys.isObjectValid(s) && 4 == s.gameRummyType && 3 == s.gameMatchMode && (t = true), t;
    }
    checkIsMatchRoom() {
        let e = ToolUtils.deskInfos.get(User.shared().curTid_key), t = false;
        e && 4 == e.mode && 3 != e.match_mode && (t = true);
        let s = RummyDataManager.shared().rummyInfos.get(User.shared().curTid_key);
        return sys.isObjectValid(s) && 4 == s.gameRummyType && 3 != s.gameMatchMode && (t = true), t;
    }
    showSmallDeskAddImage() {
        for (let e = 0, t = this.deskNodes.length; e < t; e++) {
            this.desk_tid_keys.length < 3 && this.desk_tid_keys.length == e && (this.mutil_desk_ts.changeAddVisibile(e, true), this.mutil_desk_ts.changeAddLockVisible(e, true));
        }
    }
    netWorkDelayUpdate() {
        if (!(this.desk_tid_keys.length < 2 && ToolUtils.in_isGuideRoom >= 1 || (this.networkDelay = this.networkDelay + 1, User.shared().isGameDisconnectServer))) {
            if (this.isNetworkDelay) {
                let e = { cmd: NetConfig.HEARTBEAT_CMD };
                Server.shared().send(e);
                ToolUtils.lastSendHeartBeatTime = ToolUtils.getOsTime();
                this.isNetworkDelay = false;
                this.networkDelay = 0;
            }
            if (this.networkDelay > 10) {
                let e = { cmd: NetConfig.HEARTBEAT_CMD };
                Server.shared().send(e);
                ToolUtils.lastSendHeartBeatTime = ToolUtils.getOsTime();
                this.isNetworkDelay = false;
                this.networkDelay = 0;
            }
        }
    }
    regEvent() {
        Server.shared().regDispatch(NetConfig.HEARTBEAT_CMD, this.handler_server_HEARTBEAT_DELAY_return.bind(this), this);
        Server.shared().regDispatch(NetConfig.SM_CREATE_TABLE_RETURN, this.handler_server_create_table_return.bind(this), this);
    }
    handler_server_HEARTBEAT_DELAY_return(e) {
        this.isNetworkDelay = true;
        let t = ToolUtils.getOsTime() - ToolUtils.lastSendHeartBeatTime;
        ToolUtils.gamePing = t;
        t > 999 && (t = 999);
        1 == User.shared().games_delay_open && (User.shared().hasMaintain || 0 == window.InRummyScene || this.updateNetSignal(t));
    }
    updateNetSignal(e) {
        let t = sys.getNetworkType();
        this.signal.node.active || (e = 200);
        this.signal.node.active = true;
        0 == t ? this.signal.spriteFrame = this.mobile_signals[4] : (1 == t ? e <= 250 ? this.signal.spriteFrame = this.wifi_signals[0] : e > 250 && e <= 400 || e > 400 && e <= 700 ? this.signal.spriteFrame = this.wifi_signals[1] : e > 700 && (this.signal.spriteFrame = this.wifi_signals[2]) : 2 == t && (e <= 250 ? this.signal.spriteFrame = this.mobile_signals[0] : e > 250 && e <= 400 ? this.signal.spriteFrame = this.mobile_signals[1] : e > 400 && e <= 500 || e > 500 && e <= 700 ? this.signal.spriteFrame = this.mobile_signals[2] : e > 700 && (this.signal.spriteFrame = this.mobile_signals[3])), User.shared().sigal_delay_show ? (this.delay_ms.string = e + "ms", this.delay_ms.node.active = true) : this.delay_ms.node.active = false);
    }
    changeSmallDeskNodeSelect(e) {
        ToolUtils.isObjValid(this.deskNodes[e]) && (this.mutil_desk_ts.changeSmallDeskUIVisibile(e, true), this.mutil_desk_ts.chooseDesk(e));
    }
    addRummyNode(e, t = false) {
        try {
            ToolUtils.loadCommonPrefab(this.rummyPrefab, BundleNameDefined.bundle_rummy, "prefab/rummy_main", (s => {
                if (sys.isObjectValid(s) && s.isValid) {
                    this.rummyPrefab = s;
                    let i = instantiate(this.rummyPrefab);
                    this.contentNode.addChild(i);
                    this.rummyNodes.push(i);
                    i.getComponent(MainRummy).initDesk(e);
                    t && (User.shared().curTid_key === e ? (i.active = true, this.initUi(), this.send_switch_view_table_request(e)) : i.active = false);
                    User.shared().curTid_key;
                }
            }));
        }
        catch (e) {
            TLog.printError("trycatch laodRummyPrefab,error", e);
        }
    }
    checkIfHasDesk(e) {
        let t = false;
        for (let s = 0, i = this.rummyNodes.length; s < i; s++) {
            if (ToolUtils.isObjValid(this.rummyNodes[s])) {
                this.rummyNodes[s].getComponent(MainRummy).tid_key == e && (t = true);
            }
        }
        return t;
    }
    initPushCenter() {
        PushCenter.shared().addListener(GameConfig.CreateDesk, (e => {
            ToolUtils.isObjValid(this.node) && this.onCreateDesk(e);
        }), this);
        PushCenter.shared().addListener(GameConfig.DeleteDesk, (e => {
            let t = 0 === ToolUtils.in_isGuideRoom;
            e.switchCash && (t = false);
            e.tid_key === CommDefine.NewerGuideRoomTidkey && (t = true);
            this.deleteDesk(e.tid_key, t);
            this.rummyNodes.length < 3 && PushCenter.shared().pushEvent(GameConfig.ShowMatchJoinTips, "");
        }), this);
        PushCenter.shared().addListener(GameConfig.SwitchDesk, (e => {
            this.onSwitchDesk(e);
        }), this);
        PushCenter.shared().addListener(PushEvent.jumpToNewPlayerRoom, (e => {
            let t = true;
            3 == this.rummyNodes.length && this.checkIfHasDesk(e.cur_tidkey) && (this.deleteDesk(e.cur_tidkey, false), t = false);
            let s = e.table_keys[0], i = new DeskInfo;
            i.tid_key = ToolUtils.isSafeString(s.tid_key);
            i.vid = s.vid;
            i.pnum = s.pnum;
            ToolUtils.deskInfos.set(ToolUtils.isSafeString(s.tid_key), i);
            this.onCreateDesk(s);
            t && this.deleteDesk(e.cur_tidkey, false);
            let a = this.desk_tid_keys.indexOf(ToolUtils.isSafeString(s.tid_key));
            if (-1 !== a) {
                let e = { tid_key: s.tid_key, table_status: "", pnum: s.pnum, gametype: "Points", game_type: 0, players: [{ uid: User.shared().data.uid, seatid: 0, small_status: 1 }, { uid: CommDefine.GuidePlayerInfo.uid, seatid: 1, small_status: 0 }] };
                this.refreshSmallDeskUI(a, e, ToolUtils.isSafeString(s.tid_key));
            }
            HttpManager.shared().doReportPlayerGuideAct(PhpReportDefined.roomPlayerGuideEvent.jumpSuc);
        }), this);
        PushCenter.shared().addListener(GameConfig.RefreshSmallDesk, (e => {
            let t = this.desk_tid_keys.indexOf(ToolUtils.isSafeString(e.tid_key));
            -1 !== t && this.refreshSmallDeskUI(t, e, ToolUtils.isSafeString(e.tid_key));
        }), this);
        PushCenter.shared().addListener(GameConfig.BackToHall, (e => {
            this.backToHall();
        }), this);
        PushCenter.shared().addListener(GameConfig.Enter_Private_Room, (e => {
            0 != sys.getNetworkType() ? this.send_create_table_request(e.vid, e.roomType, e.tid, e.privateRoomData, null, null, true) : Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text91"), 2, 0, ToolUtils.getIsNormalDirection());
        }), this);
        PushCenter.shared().addListener(GameConfig.Create_New_Table, (e => {
            this.send_create_table_request(e.vid, null, null, null, e.tid_key, e.fromBeginnerTutorial);
        }), this);
        PushCenter.shared().addListener(GameConfig.onEnterForeground, (e => {
            if (ToolUtils.isGameBackground = false, ToolUtils.isObjValid(this.node)) {
                if (this.desk_tid_keys.length < 2 && ToolUtils.in_isGuideRoom >= 1) {
                    return;
                }
                let e = this, t = sys.now();
                if (this.scheduleOnce((() => {
                    e.isNetworkDelay = true;
                    User.shared().send_can_join_race_info_laba();
                }), 1), Utils.shared().checkScreenLandscape(), t / 1000 - this.backgroundSatyTime / 1000 > 30 || ToolUtils.backgroundWebSocketReconnection ? (ToolUtils.backgroundWebSocketReconnection = false, this.scheduleOnce((() => {
                    Server.shared().disconnectWebSocket();
                })), this.scheduleOnce((() => {
                    for (let t = 0, s = e.rummyNodes.length; t < s; t++) {
                        ToolUtils.isObjValid(e.rummyNodes[t]) && (e.rummyNodes[t].getComponent(MainRummy).onEnterForeground(), e.rummyNodes[t].getComponent(MainRummy).login());
                    }
                }), 0.2)) : this.scheduleOnce((() => {
                    for (let t = 0, s = e.rummyNodes.length; t < s; t++) {
                        ToolUtils.isObjValid(e.rummyNodes[t]) && (e.rummyNodes[t].getComponent(MainRummy).onEnterForeground(), e.rummyNodes[t].getComponent(MainRummy).rummyLogicProcessing.send_login_request());
                    }
                }), 0.2), 1 == User.shared().new_user_flopcash_open) {
                    let t = "";
                    for (let s = 0, i = e.rummyNodes.length; s < i; s++) {
                        if (ToolUtils.isObjValid(e.rummyNodes[s])) {
                            let a = e.rummyNodes[s].getComponent(MainRummy).getRoomVid() + "";
                            e.rummyNodes[s].getComponent(MainRummy).clearFlopData();
                            t.includes(a) || (t += a);
                            s != i - 1 && (t += ",");
                        }
                    }
                    User.shared().requestCheckFlopCashReward(t);
                    this.removeFlopCashView();
                    ToolUtils.flopActInGameData = null;
                    User.shared().clubUpgradeMsg = null;
                }
            }
        }), this);
        PushCenter.shared().addListener(GameConfig.onEnterBackground, (e => {
            let t;
            HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Rummy_Game, func: ReportConfig.func.Disconn, event: ReportConfig.cash_evt.game_cut_backstage });
            HttpManager.shared().doRequestSdkApiReport({ scene: ReportConfig.scece.Rummy_Game, func: ReportConfig.func.Disconn, event: ReportConfig.hall_evt.enterBackGround, reqTime: sys.now(), tid_key: User.shared().curTid_key });
            ToolUtils.isGameBackground = true;
            this.backgroundSatyTime = sys.now();
            for (let e = 0, s = this.rummyNodes.length; e < s; e++) {
                ToolUtils.isObjValid(this.rummyNodes[e]) && (t = this.rummyNodes[e].getComponent(MainRummy), t.send_request_enterBackGround());
            }
        }), this);
        PushCenter.shared().addListener(PushEvent.onBackGameCheckStatus, (e => {
            false === window.InRummyScene && (window.InRummyScene = true, this.backToHall());
        }), this);
        PushCenter.shared().addListener(GameConfig.RummyCompleteExit, (e => {
            this.backToHall();
        }), this);
        PushCenter.shared().addListener(PushEvent.Notice_VipUpdateHide, (e => {
            sys.isObjectValid(ToolUtils.flopActInGameData) && Utils.shared().showFlopCashActInGame(ToolUtils.flopActInGameData);
        }), this);
        PushCenter.shared().addListener(GameConfig.NetWorkErrorReconnection, (e => {
            let t = this;
            this.scheduleOnce((() => {
                Server.shared().disconnectWebSocket();
                for (let e = 0, s = t.rummyNodes.length; e < s; e++) {
                    if (ToolUtils.isObjValid(t.rummyNodes[e])) {
                        t.rummyNodes[e].getComponent(MainRummy).login();
                    }
                }
            }));
        }), this);
        PushCenter.shared().addListener(GameConfig.NetWorkDelayShow, (e => {
            this.isNetworkDelay = true;
            this.networkDelay = 0;
        }), this);
        PushCenter.shared().addListener(PushEvent.UpdateGameTableInfoNum, (e => {
            sys.isObjectValid(e) && sys.isObjectValid(e.in_room) && 0 == e.in_room || (User.shared().hallGamesTabInfo = null, ToolUtils.in_isGuideRoom >= 1 && sys.isObjectValid(e) && sys.isObjectValid(e.tableInfo) && e.tableInfo.push({ tid_key: CommDefine.NewerGuideRoomTidkey, vid: 0 }), this.syncTableNum(e));
        }), this);
        PushCenter.shared().addListener(GameConfig.NotifyRaceStart, (e => {
            if (0 === e.ret) {
                for (let t = 0, s = this.desk_tid_keys.length; t < s; t++) {
                    if (e.tid_key == this.desk_tid_keys[t]) {
                        return;
                    }
                }
                User.shared().send_request_game_tableinfo();
            }
        }), this);
        PushCenter.shared().addListener(PushEvent.BackToLogin, (e => {
            this.backToLogin();
        }), this);
        PushCenter.shared().addListener(PushEvent.UpdateRaceCSS, (() => {
            ToolUtils.isObjValid(this.node) && this.initUi(true);
        }), this);
        PushCenter.shared().addListener(PushEvent.RefreshRoomDesk, (() => {
            let e;
            for (let t = 0, s = this.rummyNodes.length; t < s; t++) {
                ToolUtils.isObjValid(this.rummyNodes[t]) && (e = this.rummyNodes[t].getComponent(MainRummy), e.send_request_tableinfo());
            }
        }), this);
        PushCenter.shared().addListener(PushEvent.OpenGameSettingAlert, (e => {
            if (ToolUtils.isObjValid(this.node)) {
                try {
                    ToolUtils.loadCommonPrefab(this.gameSettingPrefab, BundleNameDefined.bundle_public, "prefab/game_setting", (t => {
                        this.gameSettingPrefab = t;
                        this.showSettingAlert(e);
                    }));
                }
                catch (e) {
                    TLog.printError(" show add_game err:", e);
                }
            }
        }), this);
        PushCenter.shared().addListener(PushEvent.Low_Memory_Notice, (e => {
            ToolUtils.isObjValid(this.node) && this.releaseRes();
        }), this);
        PushCenter.shared().addListener(PushEvent.ShowWinShareBtn, (e => {
            if (ToolUtils.isObjValid(this.node)) {
                let t = !(!sys.isObjectValid(e) || !e);
                this.changeShareBtnStatus(t);
            }
        }), this);
        PushCenter.shared().addListener(PushEvent.SwitchRoomDesk, (e => {
            ToolUtils.isObjValid(this.node) && this.send_switch_view_table_request(User.shared().curTid_key);
        }), this);
        PushCenter.shared().addListener(PushEvent.UpdateRummyUnlockData, (e => {
            ToolUtils.isObjValid(this.node) && this.updateRummyUnlockData();
        }), this);
        PushCenter.shared().addListener(PushEvent.ShowCreateDeskBubble, (e => {
            ToolUtils.isObjValid(this.node) && this.showCreateDeskBubble(e);
        }), this);
        PushCenter.shared().addListener(PushEvent.ShowAddTableView, (e => {
            ToolUtils.isObjValid(this.node) && this.desk_tid_keys.length < 3 && this.showAddGameView();
        }), this);
        PushCenter.shared().addListener(PushEvent.EnterMatchRigestView, (e => {
            if (ToolUtils.isObjValid(this.node) && window.InRummyScene) {
                if (3 == this.desk_tid_keys.length) {
                    return;
                }
                if (sys.isObjectValid(e)) {
                    // The add-game view fetches the list itself; a partial
                    // lobby cache must not block a calendar reminder.
                    let tab = 1;
                    if (1 != User.shared().temp_pingbi.matchgame && User.shared().openGameTab && User.shared().openGameTab[tab + 1]) this.showAddGameView(true);
                }
            }
        }), this);
    }
    onCreateDesk(e) {
        if (this.rummyNodes.length < 3 && !this.checkIfHasDesk(e.tid_key)) {
            User.shared().curDeskIndex = ToolUtils.deskInfos.size - 1;
            User.shared().curDeskIndex < 0 && (User.shared().curDeskIndex = 0);
            User.shared().curTid_key = ToolUtils.isSafeString(e.tid_key);
            let t = ToolUtils.deskInfos.size - 1 < 0 ? 0 : ToolUtils.deskInfos.size - 1;
            this.desk_tid_keys[t] = ToolUtils.isSafeString(e.tid_key);
            this.mutil_desk_ts.refreshTidKeys(this.desk_tid_keys);
            1 == e.isNewTable && e.mode == RUMMY_GAME_TYPE.MATCH && this.mutil_desk_ts.setMatchTipsInfo(ToolUtils.isSafeString(e.tid_key), 5, e.race_name);
            this.addRummyNode(ToolUtils.isSafeString(e.tid_key));
            this.changeRummyNodeVisibile(User.shared().curDeskIndex);
            for (let t = 0, s = this.desk_tid_keys.length; t < s; t++) {
                ToolUtils.isSafeString(e.tid_key) == this.desk_tid_keys[t] && this.mutil_desk_ts.resetSmallTable(t);
                this.mutil_desk_ts.changeSmallDeskUIVisibile(t, true);
                this.mutil_desk_ts.refreshLocalDesk(this.deskNodes[t], t, this.desk_tid_keys[t]);
            }
            this.showSmallDeskAddImage();
            this.changeSmallDeskNodeSelect(User.shared().curDeskIndex);
            let s = User.shared().practice_guide_jump;
            for (let e of ToolUtils.deskInfos.keys()) {
                let t = ToolUtils.deskInfos.get(e);
                31 === t.vid && s && this.scheduleOnce((() => {
                    PushCenter.shared().pushEvent(PushEvent.RewardTipsBackToHall, t.tid_key);
                }));
            }
            User.shared().practice_guide_jump = false;
        }
    }
    removeFlopCashView() {
        let e = director.getScene().getChildByName("Canvas");
        if (sys.isObjectValid(e)) {
            let t = e.getChildByName("beginner_flip_task_game");
            ToolUtils.isObjValid(t) && (t.destroy(), t = null);
        }
    }
    updateRummyUnlockData() {
        if (this.deskNodes && this.mutil_desk_ts) {
            for (let e = 0, t = this.deskNodes.length; e < t; e++) {
                this.desk_tid_keys.length < 3 && this.desk_tid_keys.length == e && this.mutil_desk_ts.changeAddLockVisible(e, true);
            }
        }
    }
    changeShareBtnStatus(e) {
        let t = this.rootNode.getChildByName("share_btn");
        if (User.shared().private_share_open) {
            if (RummyDataManager.shared().rummyInfos.has(User.shared().curTid_key)) {
                let e = RummyDataManager.shared().rummyInfos.get(User.shared().curTid_key).gameRummyType;
                if (e != RUMMY_GAME_TYPE.PRIVATE && e != RUMMY_GAME_TYPE.PRI_POOL && e != RUMMY_GAME_TYPE.PRI_DEAL) {
                    return void (t && (t.active = false));
                }
            }
            t && (t.getComponent(Button).enabled = e, t.active = e);
        }
        else {
            t && (t.active = false);
        }
    }
    showSettingAlert(e) {
        try {
            if (!ToolUtils.isObjValid(this.node.getChildByName("game_setting"))) {
                let t = instantiate(this.gameSettingPrefab);
                t.name = "game_setting";
                t.parent = this.node;
                let s = t.getComponent("GameSetting");
                s.startShowAnim();
                s.updateInfo(1);
                s.setLandscapeShow();
                let i = RummyDataManager.shared().rummyInfos.get(e), a = i && 1 == i.crashModel, d = 0, r = false, n = false;
                i && (d = i.gameRummyMode, r = i.gameRummyType == RUMMY_GAME_TYPE.MULTIPLE, n = 1 == i.is_bump);
                s.showGameSwitchs(a, d, r, n);
            }
        }
        catch (e) {
            TLog.printError("show room setting err:", e);
        }
    }
    onSwitchDesk(e) {
        try {
            let t = ToolUtils.isSafeString(e.old_tid_key), s = ToolUtils.isSafeString(e.tid_key), i = this.desk_tid_keys.indexOf(t);
            if (-1 !== this.desk_tid_keys.indexOf(s)) {
                return;
            }
            if (-1 !== i) {
                User.shared().curDeskIndex === i && (User.shared().curTid_key = s);
                this.desk_tid_keys[i] = s;
                ToolUtils.deskInfos.has(t) && ToolUtils.deskInfos.delete(t);
                let a = new DeskInfo;
                a.tid_key = s;
                a.vid = e.vid;
                a.venuetype = e.venuetype;
                undefined !== e.game_type && (a.game_type = e.game_type);
                undefined !== e.pnum && (a.pnum = e.pnum);
                undefined !== e.base_money && (a.base_money = e.base_money);
                undefined !== e.round && (a.round = e.round);
                undefined !== e.currentRound && (a.currentRound = e.currentRound);
                undefined !== e.mode && (a.mode = e.mode);
                undefined !== e.special_mode && (a.special_mode = e.special_mode);
                sys.isObjectValid(e.match_mode) && (a.match_mode = e.match_mode);
                sys.isObjectValid(e.is_double) && (a.is_double = e.is_double);
                ToolUtils.deskInfos.set(ToolUtils.isSafeString(s), a);
                this.mutil_desk_ts.refreshTidKeys(this.desk_tid_keys);
                for (let e = 0, t = this.desk_tid_keys.length; e < t; e++) {
                    this.mutil_desk_ts.changeSmallDeskUIVisibile(e, true);
                    this.mutil_desk_ts.refreshLocalDesk(this.deskNodes[e], e, this.desk_tid_keys[e]);
                }
                this.showSmallDeskAddImage();
            }
        }
        catch (e) {
            TLog.printError("trycatch SwitchDesk error:", e);
        }
    }
    syncTableNum(e) {
        if (1 != User.shared().isInPerformanceRoom) {
            if (sys.isObjectValid(e) && sys.isObjectValid(e.ret) && 0 === e.ret) {
                if (sys.isObjectValid(e.tableInfo) && e.tableInfo.length > 0) {
                    let t = false;
                    if (sys.isObjectValid(e.isReplaceTidKey) && (t = e.isReplaceTidKey, t && e.tableInfo.length < this.desk_tid_keys.length)) {
                        return;
                    }
                    let s = false;
                    for (let t = 0; t < e.tableInfo.length; t++) {
                        if (!sys.isObjectValid(e.tableInfo[t])) {
                            s = true;
                            break;
                        }
                        if (!sys.isObjectValid(e.tableInfo[t].tid_key)) {
                            s = true;
                            break;
                        }
                    }
                    if (s) {
                        return;
                    }
                    TweenTool.stopNodeAction(this.syncDeskNode);
                    let i, a = [];
                    for (let e = 0, t = this.desk_tid_keys.length; e < t; e++) {
                        i = this.desk_tid_keys[e];
                        -1 === a.indexOf(i) && a.push(i);
                    }
                    this.desk_tid_keys = a;
                    let d, r, n = [], o = [];
                    if (Array.isArray(e.tableInfo)) {
                        for (let t = 0, s = e.tableInfo.length; t < s; t++) {
                            sys.isObjectValid(e.tableInfo[t]) && sys.isObjectValid(e.tableInfo[t].tid_key) && o.push(e.tableInfo[t].tid_key);
                        }
                    }
                    for (let t = 0, s = a.length; t < s; t++) {
                        if (d = o.indexOf(a[t]), d > -1) {
                            if (r = t, t >= o.length && (r = o.length - 1), r != d) {
                                let t = o[r];
                                o[r] = o[d];
                                o[d] = t;
                                let s = e.tableInfo[r];
                                e.tableInfo[r] = e.tableInfo[d];
                                e.tableInfo[d] = s;
                            }
                        }
                        else {
                            n.push(a[t]);
                        }
                    }
                    let l = 0;
                    t && (l = game.frameTime / 1000);
                    let m = 0;
                    null != e.isNewTable && null != e.isNewTable && (m = e.isNewTable);
                    let u = this;
                    if (1 != m && n.length < this.desk_tid_keys.length && n.length > 0) {
                        for (let e = 0, t = n.length; e < t; e++) {
                            const t = n[e];
                            TweenTool.delayAct(this.syncDeskNode, (() => {
                                u.deleteDesk(t, true);
                            }), l, true);
                            l += game.frameTime / 1000;
                        }
                    }
                    for (let t = 0, s = e.tableInfo.length; t < s; t++) {
                        const s = e.tableInfo[t];
                        TweenTool.delayAct(this.syncDeskNode, (() => {
                            if (t < u.desk_tid_keys.length) {
                                if (u.rummyNodes.length > t && ToolUtils.isObjValid(u.rummyNodes[t])) {
                                    let e = u.rummyNodes[t].getComponent(MainRummy);
                                    if (u.desk_tid_keys[t] !== s.tid_key) {
                                        let i = {};
                                        i.tid_key = s.tid_key;
                                        i.old_tid_key = u.desk_tid_keys[t];
                                        u.onSwitchDesk(i);
                                        e.refreshDestTid(s);
                                    }
                                }
                            }
                            else {
                                User.shared().getDeskInfo(s, false);
                                this.onCreateDesk(s);
                            }
                        }), l, true);
                        l += game.frameTime / 1000;
                    }
                }
                else {
                    LabaServer.shared().isEnable() && 0 === ToolUtils.in_isGuideRoom && this.backToHall();
                    ToolUtils.in_isGuideRoom >= 1 && (gameNetworkDelay.shared().setActiveDisconnect(true), Server.shared().onBackGroundLink());
                }
            }
            else {
                LabaServer.shared().isEnable() && 0 === ToolUtils.in_isGuideRoom && this.backToHall();
                ToolUtils.in_isGuideRoom >= 1 && (gameNetworkDelay.shared().setActiveDisconnect(true), Server.shared().onBackGroundLink());
            }
        }
    }
    deleteDesk(e, t = true) {
        try {
            let s, i = -1;
            for (let t = 0, a = this.rummyNodes.length; t < a; t++) {
                if (ToolUtils.isObjValid(this.rummyNodes[t]) && (s = this.rummyNodes[t].getComponent(MainRummy), s.tid_key == e)) {
                    i = t;
                    break;
                }
            }
            if (this.rummyNodes.length >= 3 && TweenTool.delayAct(this.node, (() => {
                User.shared().send_can_join_race_info_laba();
            }), 1, true), this.rummyNodes.length <= 1 && -1 !== i) {
                if (ToolUtils.in_isGuideRoom >= 1 && (gameNetworkDelay.shared().setActiveDisconnect(true), Server.shared().onBackGroundLink()), t) {
                    if (0 == ToolUtils.in_isGuideRoom) {
                        let t = RummyDataManager.shared().rummyInfos.get(e);
                        sys.isObjectValid(t) && (t.gameRummyType == RUMMY_GAME_TYPE.MATCH ? User.shared().exitRoomGameType = 1 : 1 == t.crashModel ? User.shared().exitRoomGameType = 3 : t.gameRummyType == RUMMY_GAME_TYPE.PRIVATE || t.gameRummyType == RUMMY_GAME_TYPE.PRI_POOL || t.gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL ? User.shared().exitRoomGameType = 2 : User.shared().exitRoomGameType = 0, 0 == t.gameRummyType && 1 == t.is_multiple ? User.shared().exitRoomRummyType = HowToPlayDefined.RUMMY_MULTIPLE : 0 == t.gameRummyType && 1 == t.is_bump ? User.shared().exitRoomRummyType = HowToPlayDefined.RUMMY_BUMP : t.gameRummyType == RUMMY_GAME_TYPE.PRIVATE ? User.shared().exitRoomRummyType = HowToPlayDefined.RUMMY_POINTS : t.gameRummyType == RUMMY_GAME_TYPE.PRI_POOL ? User.shared().exitRoomRummyType = HowToPlayDefined.RUMMY_POOL : t.gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL ? User.shared().exitRoomRummyType = HowToPlayDefined.RUMMY_DEALS : User.shared().exitRoomRummyType = t.gameRummyType, User.shared().exitRoomGameVid = t.vid, User.shared()._checkExitRoomVid = true);
                    }
                    this.backToHall();
                }
            }
            else {
                ToolUtils.deskInfos.has(e) && ToolUtils.deskInfos.delete(e);
                let t = this.desk_tid_keys.indexOf(e);
                if (-1 !== t) {
                    this.desk_tid_keys.splice(t, 1);
                    this.mutil_desk_ts.refreshTidKeys(this.desk_tid_keys);
                    let e = this.desk_tid_keys.length;
                    for (let t = 0, s = this.deskNodes.length; t < s; t++) {
                        ToolUtils.isObjValid(this.deskNodes[t]) && (e > t ? this.mutil_desk_ts.small_desks[t].active = true : e < 3 && e == t ? (this.mutil_desk_ts.changeAddVisibile(t, true), this.mutil_desk_ts.changeAddLockVisible(t, true)) : this.mutil_desk_ts.small_desks[t].active = false);
                    }
                }
                User.shared().curDeskIndex = this.desk_tid_keys.length - 1;
                User.shared().curDeskIndex < 0 && (User.shared().curDeskIndex = 0);
                this.changeSmallDeskNodeSelect(User.shared().curDeskIndex);
                for (let e = 0, t = this.desk_tid_keys.length; e < t; e++) {
                    this.mutil_desk_ts.refreshLocalDesk(this.deskNodes[e], e, this.desk_tid_keys[e]);
                }
                if (-1 === i) {
                    return;
                }
                ToolUtils.isObjValid(this.rummyNodes[i]) && this.rummyNodes[i].destroy();
                this.rummyNodes.splice(i, 1);
                this.changeRummyNodeVisibile(User.shared().curDeskIndex);
            }
        }
        catch (e) {
            TLog.printError("trycatch deleteDesk,error:", e);
        }
    }
    refreshSmallDeskUI(e, t, s) {
        let i = this.deskNodes[e];
        ToolUtils.isObjValid(i) && this.mutil_desk_ts.refreshSmallDesk(t, i, e, s);
    }
    initAddGameNode() {
        this.mutil_desk_ts = this.add_game_node.getComponent(RummyMutilDesk);
        this.mutil_desk_ts.setCallBack(this.dzCallback.bind(this));
        this.mutil_desk_ts.changeSmallDeskUIVisibile(0, true);
        this.mutil_desk_ts.refreshTidKeys(this.desk_tid_keys);
    }
    dzCallback(e) {
        let t = Number(e);
        if (1 === t || 2 === t || 3 === t) {
            const e = this.rummyNodes[t - 1];
            let s = "";
            if (ToolUtils.isObjValid(e)) {
                s = e.getComponent(MainRummy).tid_key;
            }
            HttpManager.shared().doRequestSdkApiReport({ scene: ReportConfig.scece.Rummy_Game, func: ReportConfig.func.Disconn, event: "changeSmallTable", reqTime: sys.now(), to_tid_key: s, from_tid_key: User.shared().curTid_key });
        }
        if (0 === t) {
            if (User.shared().curTid_key === CommDefine.NewerGuideRoomTidkey) {
                return;
            }
            if (HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Rummy_Game, func: ReportConfig.func.RummyRoom, event: ReportConfig.cash_evt.click_add_game }), sys.now() - this.nClickAddTime < 1000) {
                return;
            }
            this.nClickAddTime = sys.now();
            SoundManager.shared().playFx("click");
            this.showAddGameView();
            this.createDeskBubble.active = false;
        }
        else {
            (1 === t || 2 === t || 3 === t) && this.changeRummyNodeVisibile(t - 1, true);
        }
    }
    showAddGameView(e = false) {
        if (!ToolUtils.isObjValid(this.addGameAlert)) {
            try {
                ToolUtils.loadCommonPrefab(null, BundleNameDefined.bundle_chooseGame, "prefab/add_room", (t => {
                    if (ToolUtils.isObjValid(this.addGameAlert)) {
                        return;
                    }
                    this.addGameAlert = instantiate(t);
                    this.node.addChild(this.addGameAlert);
                    this.addGameAlert.getComponent("RummyAddRoom").initGameData(0, this.addGameCallBack.bind(this), e);
                }));
            }
            catch (e) {
                TLog.printError(" show add_game err:", e);
            }
        }
    }
    changeRummyNodeVisibile(e, t) {
        let s, i;
        for (let a = 0, d = this.rummyNodes.length; a < d; a++) {
            if (s = this.rummyNodes[a], ToolUtils.isObjValid(s)) {
                if (i = s.getComponent(MainRummy), a === e) {
                    if (t) {
                        if (User.shared().curTid_key == i.tid_key) {
                            return;
                        }
                        SoundManager.shared().playFx("switchTable");
                    }
                    if (this.send_switch_view_table_request(i.tid_key), User.shared().curTid_key = i.tid_key, s.active = true, this.changeShareBtnStatus(false), i.refreshCurDesk(), s.setSiblingIndex(d - 1), this.initUi(true), ToolUtils.deskInfos.has(i.tid_key)) {
                        let e = ToolUtils.deskInfos.get(i.tid_key);
                        sys.isObjectValid(e) && sys.isObjectValid(e.vid) && (ToolUtils.curRoomId = e.vid);
                    }
                }
                else {
                    s.active = false;
                    s.setSiblingIndex(0);
                }
            }
        }
    }
    addGameCallBack(e) {
        0 != sys.getNetworkType() ? this.send_create_table_request(Number(e), null, null, null, null, null, true) : Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text91"), 2, 0, ToolUtils.getIsNormalDirection());
    }
    send_create_table_request(e, t, s, i, a, d, r) {
        if (this.rummyNodes.length >= 3 && null == a) {
            return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text70"), 2, 0, ToolUtils.getIsNormalDirection());
        }
        if (User.shared().isGameDisconnectServer && (Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text71"), 2, 0, ToolUtils.getIsNormalDirection()), TweenTool.delayAct(this.node, (() => {
            this.backToHall();
        }), 2, true), null == a)) {
            return;
        }
        if (this.hasRequestCreateDesk) {
            return;
        }
        this.hasRequestCreateDesk = true;
        this.createDelayAction = TweenTool.delayAct(this.node, (() => {
            ToolUtils.isObjValid(this.node) && (this.hasRequestCreateDesk = false);
            r && (0 == sys.getNetworkType() ? Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text91"), 3, 0, ToolUtils.getIsNormalDirection()) : (Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection()), User.shared().send_request_game_tableinfo()));
        }), 3, true);
        let n = { cmd: NetConfig.GM_CREATE_TABLE_REQUEST, uid: User.shared().data.uid, version: GameConfig.Server_Api_Ver, skey: User.shared().getSkey(), vid: e, auto_sort: User.shared().auto_sort, ch_id: GameConfig.CHANNEL_ID };
        null != a && (a == CommDefine.NewerGuideRoomTidkey ? n.tid_key = "" : n.tid_key = a);
        n.from_beginner_tutorial = null != d && null != d ? Number(d) : 0;
        null != i && null != i && (n.room_type = 1, n.roomid = null != i.roomid && null != i.roomid ? i.roomid : 0, n.base_money = null != i.base_money && null != i.base_money ? i.base_money : 0, n.seat_max = null != i.seat_max && null != i.seat_max ? i.seat_max : 0, null !== i.disuse_score && (n.disuse_score = i.disuse_score), null !== i.rounds && (n.rounds = i.rounds), n.clubid = Number(TransferPlatform.shared().getChannelId()), n.enterScene = 1);
        Server.shared().send(n);
    }
    send_switch_view_table_request(e) {
        if (User.shared().curTid_key == CommDefine.NewerGuideRoomTidkey) {
            return;
        }
        let t = { cmd: RummyCmd.GM_SWITCH_VIEW_TABLE_REQUEST, uid: User.shared().data.uid, version: GameConfig.Server_Api_Ver, skey: User.shared().getSkey(), cur_tid_key: User.shared().curTid_key, switch_tid_key: e };
        Server.shared().send(t);
    }
    showCreateDeskBubble(e) {
        if (ToolUtils.isObjValid(this.addGameAlert)) {
            return;
        }
        if (!sys.isObjectValid(e) || !sys.isObjectValid(e.vid)) {
            return;
        }
        let t = User.shared().game_lock_data;
        !(this.rummyNodes.length <= 1 && sys.isObjectValid(t)) || sys.isObjectValid(t.multi_table) && sys.isObjectValid(t.multi_table.unlock) && 1 != t.multi_table.unlock || (this.createMultipleDeskInfo = e, this.createDeskBubble.active = true, TweenTool.stopNodeAction(this.createDeskBubble), this.createDeskBubble.setScale(v3(0.2, 0.2, 0.2)), TweenTool.scaleTo(this.createDeskBubble, 0.15, v3(1, 1, 1), "backOut", true, (() => {
            this.createDeskBubble.setScale(v3(1, 1, 1));
        })), this.createDeskBubble.getChildByName("tips").getComponent(Label).string = ToolUtils.format("Add game ₹${0}, Win big!", ToolUtils.parse_double(String(e.base_money), -1)));
    }
    buttonClick(e, t) {
        if (SoundManager.shared().playFx("click"), "win_share" == t) {
            let e, t, s;
            for (let i = 0, a = this.rummyNodes.length; i < a; i++) {
                if (e = this.rummyNodes[i], ToolUtils.isObjValid(e) && (t = e.getComponent(MainRummy), User.shared().curTid_key == t.tid_key)) {
                    s = t._lastGameOverMsg;
                    break;
                }
            }
            if (!sys.isObjectValid(s)) {
                return void this.changeShareBtnStatus(false);
            }
            this.reqWinShareInfo(s);
        }
        else if ("createDeskClose" == t) {
            this.createDeskBubble.active = false;
        }
        else if ("startMultipleDesk" == t && (this.createDeskBubble.active = false, sys.isObjectValid(this.createMultipleDeskInfo) && sys.isObjectValid(this.createMultipleDeskInfo.vid))) {
            let e = HowToPlayDefined.RUMMY_POINTS, t = User.shared().getRoomInfoByVid(e, this.createMultipleDeskInfo.vid);
            if (sys.isObjectValid(t) || (e = HowToPlayDefined.RUMMY_POOL, t = User.shared().getRoomInfoByVid(e, this.createMultipleDeskInfo.vid)), sys.isObjectValid(t) || (e = HowToPlayDefined.RUMMY_DEALS, t = User.shared().getRoomInfoByVid(e, this.createMultipleDeskInfo.vid)), t && t.vid) {
                let s = t.vid;
                User.shared().min_money = t.entry;
                ToolUtils.curRoomId = s;
                let i = { lobby: 0 };
                i.game = e;
                i.data = t;
                ToolUtils.saveData(User.shared().data.uid + "recommendRoom0" + e, ToolUtils.toJsonString(i));
                ToolUtils.saveData(User.shared().data.uid + "recommendRoomNew", ToolUtils.toJsonString(i));
                ToolUtils.saveData(User.shared().data.uid + "addRecommendRoomNew", ToolUtils.toJsonString(i));
                this.addGameCallBack(this.createMultipleDeskInfo.vid);
            }
        }
    }
    reqWinShareInfo(e) {
        let t = 0, s = 0, i = RummyDataManager.shared().rummyInfos.get(User.shared().curTid_key);
        if (i.gameRummyType == RUMMY_GAME_TYPE.PRIVATE) {
            if (e.players) {
                let i = e.players.length;
                for (let a = 0; a < i; a++) {
                    const i = e.players[a];
                    let d = i.gamesocre, r = i.winscore;
                    i.uid == User.shared().data.uid ? t = r : s += d;
                }
            }
        }
        else if ((i.gameRummyType == RUMMY_GAME_TYPE.PRI_POOL || i.gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL) && Array.isArray(e.settleinfo)) {
            let i = e.settleinfo.length;
            for (let a = 0; a < i; a++) {
                const i = e.settleinfo[a];
                let d = i.total_score, r = i.prize;
                if (i.uid == User.shared().data.uid) {
                    t = r;
                    s = d;
                    break;
                }
            }
        }
        let a = i.roomNum, d = i.tid, r = i.vid;
        HttpManager.shared().doGetWinShareInfo(a, "", 1, d, r, t, s, 1, ((e, t, s) => {
            if (ToolUtils.isObjValid(this.node)) {
                if (Utils.shared().hideLoading(), 200 !== s) {
                    Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
                }
                else {
                    let e = ToolUtils.parseJson(t);
                    if (0 === e.ret) {
                        let t = ToolUtils.isSafeString(e.data.content) + " " + ToolUtils.isSafeString(e.data.share_url);
                        TransferPlatform.shared().shareWebPage(t);
                        TransferPlatform.shared().copyContent(t);
                    }
                    else if (e.desc && ToolUtils.isSafeString(e.desc).length > 0) {
                        let t = ToolUtils.isSafeString(e.desc);
                        Utils.shared().showToast(t, 2);
                    }
                }
            }
        }));
    }
    backToHall() {
        ToolUtils.isInGameScene = 0;
        ToolUtils.flopActInGameData = null;
        let e = sys.now() - this._enterStartTime;
        e = e > 1000 ? 0 : 1000 - e;
        setTimeout((() => {
            User.shared().hasMaintain ? this.backToLogin() : window.InRummyScene && (window.InRummyScene = false, User.shared().getHallPopList(false), User.shared().isLoginHall = false, HttpManager.shared().doReportUserAct(PhpReportDefined.Click_Game_QuitGame), ToolUtils.isObjValid(this.addGameAlert) && (this.addGameAlert.destroy(), this.addGameAlert = null), this.signal.node.active = false, TransferPlatform.shared().setHighFrameRate(), window.InSwitchScene = true, window.IsBackToHallLoad = true, Utils.shared().preLoadBundleAsset(), Utils.shared().showLoading(10), this.enterSwitchScene(2));
        }), e);
    }
    enterSwitchScene(e) {
        let t = 100;
        sys.isNative ? sys.os !== sys.OS.IOS && sys.os !== sys.OS.OSX || (t = 50, ToolUtils.isPadPlatform() && (t = 30)) : t = 0;
        let s = e, i = this;
        ToolUtils.loadBundleScene(BundleNameDefined.bundle_switch, BundleNameDefined.switch_scence, ((e, a) => {
            null == e ? (ToolUtils.switchSceneTye = s, i.jumpToSwitchScene(t, a)) : ToolUtils.loadBundleScene(BundleNameDefined.bundle_switch, BundleNameDefined.switch_scence, ((e, a) => {
                null == e ? (ToolUtils.switchSceneTye = s, i.jumpToSwitchScene(t, a)) : (Utils.shared().hideLoading(), Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text27"), 2));
            }));
        }));
    }
    onSceneLaunched() {
        PushCenter.shared().pushEvent(PushEvent.BackToHall);
        Utils.shared().hideLoading();
    }
    jumpToSwitchScene(e, t) {
        if (ToolUtils.isObjValid(this.rootNode) && (this.rootNode.active = false), ToolUtils.isObjValid(this.bottom_bgNode) && (this.bottom_bgNode.active = false), ToolUtils.isObjValid(this.top_bgNode) && (this.top_bgNode.active = false), User.shared().checkIfHasLoadHallBundle()) {
            sys.os === sys.OS.IOS || sys.os === sys.OS.OSX ? (ToolUtils.isPadPlatform() ? Utils.shared().hideRummyNode(this.hall_ipad_bg) : setTimeout((() => {
                Utils.shared().hideRummyNode(this.hall_ipad_bg);
            }), e), TransferPlatform.shared().orientationToPortrait((() => {
                Utils.shared().hideRummyNode(this.hall_ipad_bg);
                Utils.shared().setLoadingPersist(true);
                director.runScene(t);
            }))) : (Utils.shared().hideRummyNode(), TransferPlatform.shared().orientationToPortrait((() => {
                setTimeout((() => {
                    Utils.shared().setLoadingPersist(true);
                    director.runScene(t);
                }), e);
            })));
        }
        else {
            let s = false, i = 0;
            this.schedule((a => {
                i += a;
                s || (User.shared().checkIfHasLoadHallBundle() || i >= 2) && (s = true, sys.os === sys.OS.IOS || sys.os === sys.OS.OSX ? (ToolUtils.isPadPlatform() ? Utils.shared().hideRummyNode(this.hall_ipad_bg) : setTimeout((() => {
                    Utils.shared().hideRummyNode(this.hall_ipad_bg);
                }), e), TransferPlatform.shared().orientationToPortrait((() => {
                    Utils.shared().hideRummyNode(this.hall_ipad_bg);
                    Utils.shared().setLoadingPersist(true);
                    director.runScene(t);
                }))) : (Utils.shared().hideRummyNode(), TransferPlatform.shared().orientationToPortrait((() => {
                    setTimeout((() => {
                        Utils.shared().setLoadingPersist(true);
                        director.runScene(t);
                    }), e);
                }))), this.unscheduleAllCallbacks());
            }));
        }
    }
    backToLogin() {
        window.InRummyScene && (window.InRummyScene = false, window.InHallScene = false, HttpManager.shared().doReportUserAct(PhpReportDefined.Click_Game_QuitGame), Utils.shared().hideRummyNode(), LabaServer.shared().reset(), Server.shared().reset(), User.shared().doSendMatchOnlineStatus(0), TransferPlatform.shared().setHighFrameRate(), this.enterSwitchScene(3));
    }
    onLoginSceneLaunched() {
        Utils.shared().hideLoading();
    }
    handler_server_create_table_return(e) {
        if (ToolUtils.isObjValid(this.node) && (this.hasRequestCreateDesk = false, this.createDelayAction && TweenTool.stopAction(this.createDelayAction)), 1 == parseInt("" + e.ret)) {
            if (sys.isObjectValid(e.venuetype) && 5 == e.venuetype && 1003 == e.code) {
                let t = { vid: ToolUtils.isSafeNumber(e.vid), parent_node: director.getScene().getChildByName("Canvas"), bShowNetTip: true, min_entry: ToolUtils.isSafeNumber(e.min_money) };
                return void Utils.shared().showQuickChipRecharge(t);
            }
            let t = false;
            return 1002 === e.code && this.desk_tid_keys.length < 3 && (t = true), void (t ? User.shared().send_request_game_tableinfo() : ToolUtils.isSafeString(e.alertStr).length > 0 && Utils.shared().showToast(e.alertStr, 2, 0, ToolUtils.getIsNormalDirection()));
        }
        if (0 == parseInt("" + e.ret)) {
            sys.isObjectValid(e.session_id) && (User.shared().session_id = e.session_id);
            let t = false, s = false;
            if (User.shared().curTid_key == CommDefine.NewerGuideRoomTidkey) {
                e.old_tid_key = User.shared().curTid_key;
                PushCenter.shared().pushEvent(PushEvent.replaceTableTidKey, e);
            }
            else if (null != e.old_tid_key && "" != e.old_tid_key && e.old_tid_key) {
                this.checkIfHasDesk(e.old_tid_key) ? (PushCenter.shared().pushEvent(PushEvent.replaceTableTidKey, e), s = true) : t = true;
            }
            else {
                t = true;
            }
            if (t && (PushCenter.shared().pushEvent(PushEvent.CloseJoinBuddyRoomDlg), PushCenter.shared().pushEvent(GameConfig.Close_Rummy_addGame), PushCenter.shared().pushEvent(PushEvent.Close_BuddyRoomJoin)), Array.isArray(e.table_keys) && e.table_keys.length > 0) {
                let t = false;
                for (let s = 0; s < e.table_keys.length; s++) {
                    if (!sys.isObjectValid(e.table_keys[s])) {
                        t = true;
                        break;
                    }
                    if (!sys.isObjectValid(e.table_keys[s].tid_key)) {
                        t = true;
                        break;
                    }
                }
                if (t) {
                    return;
                }
                let i = { tableInfo: e.table_keys, isNewTable: 1, isReplaceTidKey: s, ret: 0 };
                PushCenter.shared().pushEvent(PushEvent.UpdateGameTableInfoNum, i);
            }
        }
    }
    releaseRes() {
        this.releasePrefabRes(BundleNameDefined.bundle_firstRecharge, "first_buy", "FirstRecharge");
        this.releasePrefabRes(BundleNameDefined.bundle_payoneforthree, "payoneforthree", "BuyOneGetThree");
        this.releasePrefabRes(BundleNameDefined.bundle_rummyTopUI, "GameDisplay", "GameDisplay");
        this.releasePrefabRes(BundleNameDefined.bundle_freecash, "freecash", "freecash");
        ToolUtils.isObjValid(this.node) && !ToolUtils.isObjValid(this.node.getChildByName("game_setting")) && (this.gameSettingPrefab = null);
        let e = assetManager.getBundle(BundleNameDefined.bundle_rummy);
        e && (ToolUtils.isObjValid(this.addGameAlert) ? ToolUtils.isObjValid(this.addGameAlert) && !this.addGameAlert.active && (this.addGameAlert.destroy(), this.addGameAlert = null) : e.release("prefab/add_game"));
        let t, s = [{ name: "switch_notice", parent: "pop_layer4", prefab: "prefab/GameRummy_switch_notice", strBundle: BundleNameDefined.bundle_rummy }, { name: "GameRummy_pool_scoreboard", parent: "pop_layer4", prefab: "prefab/GameRummy_pool_scoreboard", strBundle: BundleNameDefined.bundle_rummy }, { name: "GameRummy_pool_rejoin", parent: "pop_layer4", prefab: "prefab/GameRummy_pool_rejoin", strBundle: BundleNameDefined.bundle_rummy }, { name: "GameRummy_deals_record", parent: "pop_layer4", prefab: "prefab/GameRummy_deals_record", strBundle: BundleNameDefined.bundle_rummy }, { name: "match_game_over", parent: "pop_layer4", prefab: "prefab/match_game_over", strBundle: BundleNameDefined.bundle_rummyTopUI }, { name: "match_game_wait", parent: "pop_layer4", prefab: "prefab/match_game_wait", strBundle: BundleNameDefined.bundle_rummyTopUI }, { name: "match_game_tips", parent: "pop_layer4", prefab: "prefab/match_game_tips", strBundle: BundleNameDefined.bundle_rummyTopUI }, { name: "match_game_rebuy", parent: "pop_layer4", prefab: "prefab/match_game_rebuy", strBundle: BundleNameDefined.bundle_rummyTopUI }, { name: "chat_alert", parent: "pop_layer4", prefab: "prefab/chat_alert", strBundle: BundleNameDefined.bundle_rummyTopUI }, { name: "Security_features", parent: "pop_layer4", prefab: "prefab/Security_features", strBundle: BundleNameDefined.bundle_rummyTopUI }, { name: "GameRunny_GuessHandCard", parent: "pop_layer4", prefab: "prefab/GameRunny_GuessHandCard", strBundle: BundleNameDefined.bundle_rummyTopUI }, { name: "practice_guide", parent: "pop_layer5", prefab: "prefab/practice_guide", strBundle: BundleNameDefined.bundle_rummy }, { name: "cash_guide", parent: "pop_layer5", prefab: "prefab/cash_guide", strBundle: BundleNameDefined.bundle_rummyTopUI }], i = false;
        for (let a = 0, d = s.length; a < d; a++) {
            if (e = assetManager.getBundle(s[a].strBundle), e) {
                i = false;
                for (let e = 0, d = this.rummyNodes.length; e < d; e++) {
                    if (ToolUtils.isObjValid(this.rummyNodes[e]) && (t = this.rummyNodes[e].getChildByName("rootNode").getChildByName(s[a].parent), ToolUtils.isObjValid(t) && ToolUtils.isObjValid(t.getChildByName(s[a].name)))) {
                        i = true;
                        break;
                    }
                }
                i || (e.release(s[a].prefab), s[a].func && s[a].func());
            }
        }
    }
    releasePrefabRes(e, t, s) {
        let i = assetManager.getBundle(e);
        if (!i) {
            return void TLog.printError("---------- releaseRes bundle is null:", e);
        }
        let a = director.getScene().getChildByName("Canvas");
        if (!a.isValid) {
            return;
        }
        let d = a.getChildByName(s);
        if (ToolUtils.isObjValid(d)) {
            return;
        }
        let r = false;
        for (let e = 0, t = this.rummyNodes.length; e < t; e++) {
            if (d = this.rummyNodes[e].getChildByName(s), ToolUtils.isObjValid(d)) {
                r = true;
                break;
            }
        }
        r || i.release(ToolUtils.format("prefab/${0}", t));
    }
}
