// @ts-nocheck
// Recovered from index.js:479
import { _decorator, Button, color, instantiate, Label, Node, Overflow, Prefab, RichText, size, sp, Sprite, SpriteAtlas, SpriteFrame, sys, UIOpacity, UITransform, v3, Vec3, view } from "cc";
import Utils from "./Utils";
import TweenTool from "./TweenTool";
import SoundManager from "./SoundManager";
import User from "./User";
import RummyDataManager, { RoomRewardType, RUMMY_GAME_TYPE, RUMMY_MATCH_MODE } from "./RummyDataManager";
import { TransferPlatform } from "./TransferPlatform";
import { TLog } from "./TLog";
import PushCenter from "./PushCenter";
import PushEvent from "./PushEvent";
import i18nMgr from "./i18nMgr";
import BaseLayer from "./BaseLayer";
import RummyCmd from "./RummyCmd";
import HttpManager from "./HttpManager";
import PhpReportDefined from "./PhpReportDefined";
import GameConfig from "./GameConfig";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("RummyPointsMatchOverAlert")
export default class RummyPointsMatchOverAlert extends BaseLayer {
    @property(Node)
    public rootNode: Node = null;
    @property(SpriteAtlas)
    public myAtlas: SpriteAtlas = null;
    @property(Prefab)
    public cardPrefab: Prefab = null;
    @property(Node)
    public mobanView: Node = null;
    @property(SpriteAtlas)
    public rummyAtlas: SpriteAtlas = null;
    @property([SpriteFrame])
    public bottom_card_img: SpriteFrame[] = [];
    @property(Node)
    public tipsMask: Node = null;
    @property(SpriteAtlas)
    public clubKuangAtlas: SpriteAtlas = null;
    @property(Node)
    public bgNode: Node = null;
    @property(Node)
    public pts_node: Node = null;
    @property(Node)
    public round_node: Node = null;
    @property(Node)
    public bottom_node: Node = null;
    @property([SpriteFrame])
    public ticket_images: SpriteFrame[] = [];
    @property(Node)
    public bubble_tipNode: Node = null;
    @property([SpriteFrame])
    public iconImages: SpriteFrame[] = [];
    @property(Node)
    public topInfoNode: Node = null;
    @property([SpriteFrame])
    public itemBgImages: SpriteFrame[] = [];
    public _callback: any = null;
    public cardScale: any = v3(0.32, 0.32, 0.32);
    public fromtype: number = 0;
    public laizicard: number = 0;
    public msg: any = null;
    public will_disuse: number = 0;
    public startTime: number = 0;
    public can_rejoin: number = 0;
    public ispoolRummyend: boolean = false;
    public all_end: number = 0;
    public bIsEnd: boolean = false;
    public cround: number = 0;
    public dealsMyTiebreak: boolean = false;
    public poolRejoin: boolean = false;
    public poolRejoinMoney: number = 0;
    public poolRejoinScore: number = 0;
    public is_auto_split: number = 0;
    public auto_split_money: number = 0;
    public hide_start: number = 0;
    public itemViewDate: any[] = [];
    public time_action: any = null;
    public isShowOkBtn: boolean = false;
    public isShowStartBtn: boolean = false;
    public isShowExitBtn: boolean = false;
    public isShowPoolRejoinBtn: boolean = false;
    public isShowPoolCencelBtn: boolean = false;
    public isShowSwitchBtn: boolean = false;
    public _bClickBtn: boolean = false;
    public isShowPoolYesBtn: boolean = false;
    public isShowPoolNoBtn: boolean = false;
    public _isWatching: number = 0;
    public pre_end: number = 0;
    public settle_type: number = 0;
    public win_prize: number = 0;
    public _showNewPlayerGuide: number = 0;
    public _showIndex: number = 0;
    public itemViewNodes: any[] = [];
    public itemViewPositons: any[] = [];
    public delayActs: any[] = [];
    public _hasShowAnim: boolean = false;
    public _hasShowWinAnim: boolean = false;
    public _meItem: any = null;
    public meWin: boolean = false;
    public _hasShowRewardAnim: boolean = false;
    public _showPointsChangeAnim: boolean = false;
    public _showPtsTipsAnim: boolean = false;
    public _myScore: number = 0;
    public _mylastScore: number = 0;
    public scoreNumArrs: any[] = [];
    public scoreNumNodes: any[] = [];
    public scoreRollActs: any[] = [];
    public hasShowMyPts: boolean = false;
    public ptsAnimType: any = -1;
    public rollcount: number = 0;
    public rewardItems: any[] = [];
    public infos: any[] = [];
    public rewardNames: any[] = ["reward_watch.png"];
    onLoad() {
        this.bIsInGame = true;
    }
    onEnable() {
        ToolUtils.isObjValid(this.rootNode) && ToolUtils.isObjValid(this.rootNode.getChildByName("playerView")) && this.rootNode.getChildByName("playerView").on("scrolling", this.onScrollView_Scrolling, this);
        ToolUtils.isObjValid(this.tipsMask) && (this.tipsMask.getChildByName("mask").on(Node.EventType.TOUCH_START, this.onTouchEvent, this), this.tipsMask.getChildByName("mask").on(Node.EventType.TOUCH_MOVE, this.onTouchEvent, this), this.tipsMask.getChildByName("mask").on(Node.EventType.TOUCH_END, this.onTouchEvent, this), this.tipsMask.getChildByName("mask").on(Node.EventType.TOUCH_CANCEL, this.onTouchEvent, this));
    }
    onDisable() {
        ToolUtils.isObjValid(this.rootNode) && ToolUtils.isObjValid(this.rootNode.getChildByName("playerView")) && this.rootNode.getChildByName("playerView").off("scrolling", this.onScrollView_Scrolling, this);
        ToolUtils.isObjValid(this.tipsMask) && (this.tipsMask.getChildByName("mask").off(Node.EventType.TOUCH_START, this.onTouchEvent, this), this.tipsMask.getChildByName("mask").off(Node.EventType.TOUCH_MOVE, this.onTouchEvent, this), this.tipsMask.getChildByName("mask").off(Node.EventType.TOUCH_END, this.onTouchEvent, this), this.tipsMask.getChildByName("mask").off(Node.EventType.TOUCH_CANCEL, this.onTouchEvent, this));
    }
    start() {
        super.start();
        ToolUtils.showFullScreen(this.node.getChildByName("bg"));
        this.bubble_tipNode.getChildByName("mask").getComponent(UITransform).setContentSize(view.getVisibleSize());
        PushCenter.shared().addListener(PushEvent.HideGameOverBg, (t => {
            this.node.getChildByName("bg").active = false;
        }), this);
        PushCenter.shared().addListener(PushEvent.ShowGameOverBg, (t => {
            this.node.getChildByName("bg").active = true;
        }), this);
    }
    onDestroy() {
        super.onDestroy();
        this.removePopNode();
        TweenTool.stopNodeAction(this.node);
        this.time_action && (TweenTool.stopAction(this.time_action), this.time_action = null);
        RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType == RUMMY_GAME_TYPE.PRIVATE && PushCenter.shared().pushEvent(PushEvent.ShowWinShareBtn, false);
        ToolUtils.isObjValid(this.rootNode) && this.rootNode.getChildByName("playerView").off("scrolling", this.onScrollView_Scrolling, this);
        for (let t = 0; t < this.scoreRollActs.length; t++) {
            sys.isObjectValid(this.scoreRollActs[t]) && TweenTool.stopAction(this.scoreRollActs[t]);
        }
        if (Array.isArray(this.delayActs) && this.delayActs.length > 0) {
            for (let t = 0; t < this.delayActs.length; t++) {
                TweenTool.stopAction(this.delayActs[t]);
            }
        }
        ToolUtils.isObjValid(this.node.getChildByName("bg")) && TweenTool.stopNodeAction(this.node.getChildByName("bg"));
        PushCenter.shared().removeListenersByTag(this);
        this.unscheduleAllCallbacks();
    }
    showPointsTipsAnim(t = true) {
        let e = this.pts_node.getChildByName("tips"), i = v3(0, -52);
        if (this._showPtsTipsAnim) {
            this.checkIsEnd() && (TweenTool.stopNodeAction(e), e.active = true, e.setPosition(i), e.getComponent(UIOpacity).opacity = 255);
        }
        else if (sys.isObjectValid(this.msg.next_score)) {
            if (this.checkIsZhangMangMatch() && 0 == this.msg.next_score) {
                return void (e.active = false);
            }
            if (this._showPtsTipsAnim = true, t) {
                let t = TweenTool.delayAct(RummyDataManager.shared().sceneNode, (() => {
                    ToolUtils.isObjValid(this.node) && (e.active = true, e.setPosition(v3(i.x, i.y - 50)), TweenTool.fadeMoveByEasing(e, 0.333, i, 0, 1, "sineOut", true));
                }), 0.233, true);
                this.delayActs.push(t);
            }
            else {
                e.active = true;
                e.setPosition(i);
                0 != this.msg.next_score ? TweenTool.fadeMoveByEasing(e, 0.333, i, 0, 1, "sineOut", true) : e.getComponent(UIOpacity).opacity = 255;
            }
        }
    }
    startShowAnim() {
        try {
            if (this._hasShowAnim) {
                return void (this.rootNode.active = true);
            }
            this._hasShowAnim = true;
            TweenTool.stopNodeAction(this.rootNode);
            this.rootNode.active = false;
            let t = this.node.getChildByName("bg"), e = 0.08, i = 0.333, s = 0.3, o = 0.366;
            if (TweenTool.fadeMoveByEasing(t, e, v3(0, 0), 0, 1, "sineOut", true), Array.isArray(this.delayActs) && this.delayActs.length > 0) {
                for (let t = 0; t < this.delayActs.length; t++) {
                    TweenTool.stopAction(this.delayActs[t]);
                }
            }
            this.delayActs = [];
            this.bgNode.active = false;
            this.pts_node.active = true;
            let a = this.pts_node.getChildByName("di"), h = this.pts_node.getChildByName("points"), n = this.pts_node.getChildByName("waiting"), m = this.pts_node.getChildByName("roll_node"), l = this.pts_node.getChildByName("tips"), d = this.pts_node.getChildByName("reward_title_bg"), _ = this.pts_node.getChildByName("reward_layout"), g = this.pts_node.getChildByName("down_arrow");
            m.active = false;
            g.active = false;
            a.active = false;
            h.active = false;
            n.active = false;
            l.active = false;
            d.active = false;
            _.active = false;
            this.bottom_node.active = false;
            this.topInfoNode.active = false;
            let c = v3(0, 34), p = v3(0, -91), u = v3(0, -147), b = v3(534, 237), f = v3(0, -221), B = v3(0, 0);
            if (TweenTool.stopNodeAction(h), TweenTool.stopNodeAction(n), this.itemViewNodes.length > 0) {
                for (let t = 0; t < this.itemViewNodes.length; t++) {
                    ToolUtils.isObjValid(this.itemViewNodes[t]) && (this.itemViewNodes[t].setPosition(v3(this.itemViewPositons[t].x + 200, this.itemViewPositons[t].y)), this.itemViewNodes[t].active = false);
                }
            }
            if (this.checkIsPointsMatch()) {
                let t = TweenTool.delayAct(RummyDataManager.shared().sceneNode, (() => {
                    ToolUtils.isObjValid(this.node) && (this.rootNode.active = true, a.active = true, TweenTool.fadeMoveByEasing(a, e, v3(0, 0), 0, 1, "sineOut", true), this.round_node.active = false, this.bgNode.active = true, this.bgNode.setScale(0, 1), TweenTool.fadeScaleByEasing(this.bgNode, e, v3(1, 1), 0, 1, "sineOut", true), m.active = true, this.setMyFormatPts(this._myScore), m.setScale(1, 1), m.setPosition(v3(c.x, c.y - 50)), TweenTool.fadeMoveByEasing(m, i, c, 0, 1, "sineOut", true));
                }), e, true);
                if (this.delayActs.push(t), this.meWin && this.checkIsEnd() && this._mylastScore == this._myScore && (this._showPointsChangeAnim = true), this.meWin) {
                    let t = e + 1, i = TweenTool.delayAct(RummyDataManager.shared().sceneNode, (() => {
                        ToolUtils.isObjValid(this.node) && this.showPtsAnim(false);
                    }), t, true);
                    this.delayActs.push(i);
                }
            }
            else {
                let t = TweenTool.delayAct(RummyDataManager.shared().sceneNode, (() => {
                    ToolUtils.isObjValid(this.node) && (this.rootNode.active = true, a.active = true, TweenTool.fadeMoveByEasing(a, e, v3(0, 0), 0, 1, "sineOut", true), this.round_node.active = false, this.bgNode.active = true, this.bgNode.setScale(0, 1), TweenTool.fadeScaleByEasing(this.bgNode, e, v3(1, 1), 0, 1, "sineOut", true), this.topInfoNode.active = true, this.topInfoNode.setPosition(v3(B.x, B.y - 50)), TweenTool.fadeMoveByEasing(this.topInfoNode, i, B, 0, 1, "sineOut", true));
                }), e, true);
                this.delayActs.push(t);
            }
            !this.checkIsEnd() && this.meWin || this.showPointsTipsAnim(true);
            let C = TweenTool.delayAct(RummyDataManager.shared().sceneNode, (() => {
                if (ToolUtils.isObjValid(this.node)) {
                    if (d.active = true, this.checkIsZhangMangMatch()) {
                        let t = d.getChildByName("layout").getChildByName("Label");
                        i18nMgr.shared().changeLocalizedLabelKey(t, "match_over.ranking_reward");
                    }
                    d.setPosition(v3(p.x, p.y - 50));
                    TweenTool.fadeMoveByEasing(d, i, p, 0, 1, "sineOut", true);
                }
            }), s, true);
            this.delayActs.push(C);
            let N = TweenTool.delayAct(RummyDataManager.shared().sceneNode, (() => {
                ToolUtils.isObjValid(this.node) && (_.active = true, _.setPosition(v3(u.x, u.y - 50)), TweenTool.fadeMoveByEasing(_, i, u, 0, 1, "sineOut", true, (() => {
                    if (this.checkIsEnd()) {
                        for (let t = 0; t < this.rewardItems.length; t++) {
                            const e = this.rewardItems[t];
                            ToolUtils.isObjValid(e) && (e.getChildByName("num").active = true);
                        }
                        this.meWin && sys.isObjectValid(this.msg.up_info) && 1 == this.msg.up_info || this.showNextRewardUpOrDown();
                    }
                })));
            }), o, true);
            this.delayActs.push(N);
            let v = 0.5, w = 0.5, T = 0.0666, P = 0.2, k = TweenTool.delayAct(RummyDataManager.shared().sceneNode, (() => {
                if (ToolUtils.isObjValid(this.node) && (this.round_node.active = true, this.round_node.setPosition(v3(b.x + 40, b.y)), TweenTool.fadeMoveByEasing(this.round_node, w, b, 0, 1, "sineOut", true), this.itemViewNodes.length > 0)) {
                    for (let t = 0; t < this.itemViewNodes.length; t++) {
                        ToolUtils.isObjValid(this.itemViewNodes[t]) && TweenTool.delayAct(this.node, (() => {
                            ToolUtils.isObjValid(this.itemViewNodes[t]) && (this.itemViewNodes[t].active = true, TweenTool.fadeMoveByEasing(this.itemViewNodes[t], P, this.itemViewPositons[t], 0, 1, "sineOut", true, (() => {
                                ToolUtils.isObjValid(this.node) && 0 == t && this.meWin && this.showMeItemWinAnim();
                            })));
                        }), T * t, true);
                    }
                }
            }), v, true);
            this.delayActs.push(k);
            let I = 0.833, O = 0.5, V = TweenTool.delayAct(RummyDataManager.shared().sceneNode, (() => {
                ToolUtils.isObjValid(this.node) && (this.bottom_node.active = true, this.bottom_node.setPosition(v3(f.x + 100, f.y)), TweenTool.fadeMoveByEasing(this.bottom_node, O, f, 0, 1, "sineOut", true));
            }), I, true);
            this.delayActs.push(V);
        }
        catch (t) {
            TLog.printError("trycatch RummyPointsMatchOverAlert startShowAnim ", t);
        }
    }
    showMeItemWinAnim() {
        if (ToolUtils.isObjValid(this._meItem) && this._meItem.active && sys.isObjectValid(this.msg) && this.msg.cmd == RummyCmd.SM_GAME_END_BC_INFORM && this.meWin && !this._hasShowWinAnim) {
            this._hasShowWinAnim = true;
            let t = this._meItem.getChildByName("win_anim");
            t.active = true;
            let e = t.getComponent(sp.Skeleton);
            e.clearTracks();
            e.setToSetupPose();
            e.setAnimation(0, "scores_update", false);
            e.setCompleteListener((() => {
                ToolUtils.isObjValid(t) && (t.active = false);
            }));
            let i = 0.833;
            if (this.checkIsPointsMatch()) {
                let t = TweenTool.delayAct(RummyDataManager.shared().sceneNode, (() => {
                    ToolUtils.isObjValid(this.node) && this.showPtsAnim(true);
                }), i, true);
                this.delayActs.push(t);
            }
            if (sys.isObjectValid(this.msg.up_info) && 1 == this.msg.up_info) {
                if (0 != this.msg.next_score) {
                    let t = TweenTool.delayAct(RummyDataManager.shared().sceneNode, (() => {
                        ToolUtils.isObjValid(this.node) && this.showNextRewardUpOrDown();
                    }), i, true);
                    this.delayActs.push(t);
                }
                else {
                    this.showNextRewardUpOrDown(true);
                }
            }
        }
    }
    showNextRewardUpOrDown(t = false) {
        let e = this.pts_node.getChildByName("reward_layout"), i = this.pts_node.getChildByName("down_arrow");
        if (sys.isObjectValid(this.msg) && this.msg.cmd == RummyCmd.SM_GAME_END_BC_INFORM && !this._hasShowRewardAnim && e && e.active) {
            this._hasShowRewardAnim = true;
            for (let t = 0; t < this.rewardItems.length; t++) {
                ToolUtils.isObjValid(this.rewardItems[t]) && (this.rewardItems[t].getChildByName("num").active = true);
            }
            if (t) {
                return;
            }
            if (sys.isObjectValid(this.msg.up_info) && 1 == this.msg.up_info) {
                for (let t = 0; t < this.rewardItems.length; t++) {
                    if (ToolUtils.isObjValid(this.rewardItems[t])) {
                        this.rewardItems[t].getChildByName("num").active = true;
                        let e = this.rewardItems[t].getChildByName("anim");
                        e.active = true;
                        let i = e.getComponent(sp.Skeleton);
                        i.clearTracks();
                        i.setToSetupPose();
                        i.setAnimation(0, "item_update", false);
                        i.setCompleteListener((() => {
                            ToolUtils.isObjValid(e) && (e.active = false);
                        }));
                    }
                }
            }
            else {
                sys.isObjectValid(this.msg.up_info) && 2 == this.msg.up_info && (i.active = true);
            }
        }
    }
    startHideAnim() {
        try {
            TweenTool.stopNodeAction(this.rootNode);
            this.rootNode.active = false;
            RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType == RUMMY_GAME_TYPE.PRIVATE && PushCenter.shared().pushEvent(PushEvent.ShowWinShareBtn, false);
        }
        catch (t) {
            TLog.printError("trycatch RummyPointsMatchOverAlert startHideAnim ", t);
        }
    }
    onClickClose(t, e = "") {
        SoundManager.shared().playFx("click");
        "close" == e && 1 == this.fromtype ? this.onBackView() : "ok" == e && (this.startHideAnim(), this.isShowEndView(false), 0 == this.fromtype ? this._callback && this._callback("private_gameOver_self_closed") : RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType == RUMMY_GAME_TYPE.PRIVATE && undefined !== this.msg.start_cd && this._callback && this._callback("private_close"));
    }
    onTouchEvent(t) {
        t.preventSwallow = true;
        t.getType() == Node.EventType.TOUCH_START && ToolUtils.isObjValid(this.tipsMask) && this.tipsMask.active && this.onCloseItemHelpTips(null);
    }
    onScrollView_Scrolling(t) {
        if (ToolUtils.isObjValid(this.tipsMask) && this.tipsMask.active) {
            let t = 0.5 * GameConfig.REAL_SCREEN_WIDTH;
            if (this.itemViewDate[this._showIndex].item && this.itemViewDate[this._showIndex].item.isValid) {
                let e = this.itemViewDate[this._showIndex].item, i = e.children.length + 1;
                e.getChildByName("help_btn").setSiblingIndex(i);
                let s = e.getChildByName("help_btn").getWorldPosition();
                1 == i18nMgr.shared().language ? (this.tipsMask.getComponent(UITransform).contentSize = size(770, 60), this.tipsMask.setPosition(v3(30, s.y - t - 50))) : (this.tipsMask.getComponent(UITransform).contentSize = size(810, 60), this.tipsMask.setPosition(v3(10, s.y - t - 50)));
            }
        }
    }
    updateInfo(t, e, i = null, s = false) {
        try {
            let o = RummyDataManager.shared().rummyInfos.get(this.tid_key);
            if (e.cmd == RummyCmd.SM_GAME_END_BC_INFORM && (o.gameRummyType != RUMMY_GAME_TYPE.POINTS && o.gameRummyType != RUMMY_GAME_TYPE.PRIVATE && o.gameRummyType != RUMMY_GAME_TYPE.MULTIPLE && o.gameRummyType != RUMMY_GAME_TYPE.MATCH || PushCenter.shared().pushEvent(PushEvent.GameOverShowFreeMatchPush)), this.bottom_node.getChildByName("ok_btn").getComponent(Button).clickEvents[0].customEventData = "ok", this.fromtype = t, this.bIsEnd = s, this.msg = null, this.win_prize = ToolUtils.isSafeNumber(e.win_prize), this.all_end = null != e.all_end ? e.all_end : 0, null != e.hide_start && (this.hide_start = e.hide_start), this.settle_type = ToolUtils.isSafeNumber(e.settle_type), e.players) {
                for (let t = 0, i = e.players.length; t < i; t++) {
                    const i = e.players[t];
                    if (i.uid == User.shared().data.uid) {
                        this.can_rejoin = ToolUtils.isSafeNumber(i.can_rejoin);
                        this.will_disuse = ToolUtils.isSafeNumber(i.will_disuse);
                        this.bIsEnd && sys.isObjectValid(i.show_new_player_guide) && (this._showNewPlayerGuide = i.show_new_player_guide);
                        break;
                    }
                }
            }
            if (o.gameRummyType == RUMMY_GAME_TYPE.POOL || o.gameRummyType == RUMMY_GAME_TYPE.PRI_POOL) {
                1 == e.all_end ? o.game_end_state = 5 : o.game_end_state = e.WaitState;
                let t = o.clientSeatId;
                if (e.pool_game_info && null != e.pool_game_info && e.pool_game_info.rejoin_seatids && e.pool_game_info.rejoin_seatids.length > 0) {
                    for (let i = 0, s = e.pool_game_info.rejoin_seatids.length; i < s; i++) {
                        t == e.pool_game_info.rejoin_seatids[i] && (this.poolRejoin = true, this.poolRejoinMoney = e.pool_game_info.rejoin_money, this.poolRejoinScore = e.pool_game_info.rejoin_score);
                    }
                }
                if (sys.isObjectValid(e.is_auto_split) && (this.is_auto_split = e.is_auto_split, sys.isObjectValid(e.is_auto_split) && (this.auto_split_money = e.split_prize)), null != e.cd) {
                    let t = e.cd;
                    null != e.isReissue && 1 == e.isReissue && 1 == this.poolRejoin && (t = e.cd, 0 == t && (this.startTime = t));
                    t > 0 && this.setPoolRummyCountDown(t);
                }
                this.bottom_node.getChildByName("exit_btn").active = false;
            }
            else if (o.gameRummyType == RUMMY_GAME_TYPE.DEALS || o.gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL) {
                this.bottom_node.getChildByName("no_btn").getComponent(Button).clickEvents[0].customEventData = "no";
                2 === this.settle_type && o.gameRummyType == RUMMY_GAME_TYPE.DEALS && (this.bottom_node.getChildByName("no_btn").getComponent(Button).clickEvents[0].customEventData = "pool_game_all_end", this.all_end = 1);
                o.gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL && 2 === this.settle_type && (this.bottom_node.getChildByName("ok_btn").getComponent(Button).clickEvents[0].customEventData = "no");
                this.pre_end = ToolUtils.isSafeNumber(e.pre_end);
                let t = o.clientSeatId;
                if (e.deals_tiebreak_seatids && null != e.deals_tiebreak_seatids && e.deals_tiebreak_seatids.length > 0) {
                    for (let i = 0, s = e.deals_tiebreak_seatids.length; i < s; i++) {
                        t == e.deals_tiebreak_seatids[i] && (this.dealsMyTiebreak = true);
                    }
                }
                if (null != e.cd && (o.dealsRummyCurrentRount = e.cround + 1, this.cround = e.cround, 1 == e.all_end ? o.game_end_state = 5 : (o.game_end_state = e.WaitState, o.dealsRummyCurrentRount = 1), null != e.cd)) {
                    let t = e.cd;
                    1 === this.settle_type && o.gameRummyType == RUMMY_GAME_TYPE.DEALS && (t = 0);
                    t > 0 && this.setPoolRummyCountDown(t);
                }
            }
            else if (o.gameRummyType == RUMMY_GAME_TYPE.POINTS || o.gameRummyType == RUMMY_GAME_TYPE.MULTIPLE || this.checkIsPointsMatch()) {
                if (this.checkIsPointsMatch() && (this.pts_node.getChildByName("di").getChildByName("pts_title").active = true), null != e.cd) {
                    let t = e.cd;
                    t > 0 && this.setPoolRummyCountDown(t);
                }
            }
            else {
                o.gameRummyType == RUMMY_GAME_TYPE.MATCH && o.gameMatchMode != RUMMY_MATCH_MODE.PointsMatch && (this.pts_node.getChildByName("di").getChildByName("pts_title").active = false);
            }
            this.sortPlayers(e);
            this._callback = i;
            1 === t ? this.showGameRecodeCountDownTips(e) : 1 == User.shared().isInPerformanceRoom ? this.showPerformanceRoomTips(e) : o.gameRummyType == RUMMY_GAME_TYPE.PRIVATE && PushCenter.shared().addListener(PushEvent.GameOverDowntimeTip, (t => {
                t.tid_key == this.tid_key && this.showPrivateTips(t.typeNum, t.TextStr);
            }), this);
            this.checkShowWinShareBtn();
        }
        catch (t) {
            TLog.printError("trycatch RummyPointsMatchOverAlert updateInfo set:", t);
        }
    }
    showPerformanceRoomTips(t) {
        let e = 0;
        if (null != t.cd && (e = t.cd, e > 0 && 1 == t.all_end)) {
            let t = RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType;
            if (t == RUMMY_GAME_TYPE.POOL || t == RUMMY_GAME_TYPE.PRI_POOL || t == RUMMY_GAME_TYPE.DEALS || t == RUMMY_GAME_TYPE.PRI_DEAL) {
                this.time_action && (TweenTool.stopAction(this.time_action), this.time_action = null);
                this.bottom_node.getChildByName("pool_time").setPosition(v3(390, 4));
                this.startTime = e;
                let t = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_gameover.over_tips4"), this.startTime);
                this.bottom_node.getChildByName("pool_time").active = true;
                this.bottom_node.getChildByName("ready_tips").active = false;
                this.bottom_node.getChildByName("pool_time").getComponent(RichText).string = t;
                this.bottom_node.getChildByName("pool_time").getComponent(RichText).fontSize = 28;
                this.updateReadyTipPos();
                let i = this;
                this.time_action = TweenTool.myschedule(RummyDataManager.shared().sceneNode, 1, (() => {
                    i.updatePerformanceTime();
                }));
            }
        }
    }
    updatePerformanceTime() {
        if (ToolUtils.isObjValid(this.rootNode)) {
            if (this.startTime = this.startTime - 1, this.startTime < 1) {
                this.stopPoolRummyCountDown();
                PushCenter.shared().pushEvent(PushEvent.RestoreRoomPerformance);
            }
            else {
                let t = "", e = 28;
                t = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_gameover.over_tips4"), this.startTime);
                this.bottom_node.getChildByName("pool_time").getComponent(RichText).string = t;
                this.bottom_node.getChildByName("pool_time").getComponent(RichText).fontSize = e;
                this.bottom_node.getChildByName("ready_tips").active = false;
            }
        }
    }
    showCommingSplitTips(t) {
        this.time_action && (TweenTool.stopAction(this.time_action), this.time_action = null);
        this.bottom_node.getChildByName("pool_time").setPosition(v3(390, 4));
        this.startTime = t;
        let e = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_gameover.over_tips15"), this.startTime);
        this.bottom_node.getChildByName("pool_time").active = true;
        this.bottom_node.getChildByName("ready_tips").active = false;
        this.bottom_node.getChildByName("pool_time").getComponent(RichText).string = e;
        this.bottom_node.getChildByName("pool_time").getComponent(RichText).fontSize = 28;
        this.updateReadyTipPos();
        let i = this;
        this.time_action = TweenTool.myschedule(RummyDataManager.shared().sceneNode, 1, (() => {
            i.updateCommingSplitTime();
        }));
    }
    updateCommingSplitTime() {
        if (ToolUtils.isObjValid(this.rootNode)) {
            if (this.startTime = this.startTime - 1, this.startTime < 1) {
                this.stopPoolRummyCountDown();
                ToolUtils.isObjValid(this.node) && this.node.destroy();
                this._callback && (this._callback("pool_game_all_end"), this._callback("gameOverAlertDestroy"), this._callback("cleanGameEndPointer"));
            }
            else if (RummyDataManager.shared().rummyInfos.has(this.tid_key)) {
                let t = "", e = 28;
                t = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_gameover.over_tips15"), this.startTime);
                this.bottom_node.getChildByName("pool_time").getComponent(RichText).string = t;
                this.bottom_node.getChildByName("pool_time").getComponent(RichText).fontSize = e;
                this.bottom_node.getChildByName("ready_tips").active = false;
            }
        }
    }
    showNotifyRejoinTips(t) {
        if (RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType == RUMMY_GAME_TYPE.POOL || RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType == RUMMY_GAME_TYPE.PRI_POOL) {
            this.time_action && (TweenTool.stopAction(this.time_action), this.time_action = null);
            this.bottom_node.getChildByName("pool_time").setPosition(v3(390, 4));
            this.startTime = t;
            let e = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_gameover.over_tips5"), this.startTime);
            this.bottom_node.getChildByName("pool_time").active = true;
            this.bottom_node.getChildByName("ready_tips").active = false;
            this.bottom_node.getChildByName("pool_time").getComponent(RichText).string = e;
            this.bottom_node.getChildByName("pool_time").getComponent(RichText).fontSize = 28;
            this.updateReadyTipPos();
            let i = this;
            this.time_action = TweenTool.myschedule(RummyDataManager.shared().sceneNode, 1, (() => {
                i.updateRejoinTime();
            }));
        }
    }
    updateRejoinTime() {
        if (ToolUtils.isObjValid(this.rootNode)) {
            if (this.startTime = this.startTime - 1, this.startTime < 1) {
                this.stopPoolRummyCountDown();
                ToolUtils.isObjValid(this.node) && this.node.destroy();
                this._callback && this._callback("cleanGameEndPointer");
            }
            else if (RummyDataManager.shared().rummyInfos.has(this.tid_key)) {
                let t = "", e = 28;
                t = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_gameover.over_tips5"), this.startTime);
                this.bottom_node.getChildByName("pool_time").getComponent(RichText).string = t;
                this.bottom_node.getChildByName("pool_time").getComponent(RichText).fontSize = e;
                this.bottom_node.getChildByName("ready_tips").active = false;
            }
        }
    }
    showGameRecodeCountDownTips(t) {
        let e = RummyDataManager.shared().rummyInfos.get(this.tid_key);
        if (e.gameRummyType == RUMMY_GAME_TYPE.POOL || e.gameRummyType == RUMMY_GAME_TYPE.PRI_POOL || e.gameRummyType == RUMMY_GAME_TYPE.DEALS || e.gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL) {
            if (this.time_action && (TweenTool.stopAction(this.time_action), this.time_action = null), ToolUtils.isSafeNumber(t.start_cd) > 0) {
                this.bottom_node.getChildByName("ok_btn").getComponent(Button).clickEvents[0].customEventData = "recode_ok";
                this.bottom_node.getChildByName("ok_btn").active = true;
                this.bottom_node.getChildByName("start_btn").active = false;
                this.bottom_node.getChildByName("split_prize_btn").active = false;
                this.bottom_node.getChildByName("pool_time").setPosition(v3(390, 4));
                this.startTime = t.start_cd;
                let i = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_gameover.over_tips5"), this.startTime);
                if (e.gameRummyType == RUMMY_GAME_TYPE.DEALS || e.gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL) {
                    this.cround = ToolUtils.isSafeNumber(this.msg.cround);
                    let t = this.cround;
                    i = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_gameover.over_tips7"), t, this.startTime);
                }
                this.bottom_node.getChildByName("pool_time").active = true;
                this.bottom_node.getChildByName("ready_tips").active = false;
                this.bottom_node.getChildByName("pool_time").getComponent(RichText).string = i;
                this.bottom_node.getChildByName("pool_time").getComponent(RichText).fontSize = 28;
                this.updateReadyTipPos();
                let s = this;
                this.time_action = TweenTool.myschedule(RummyDataManager.shared().sceneNode, 1, (() => {
                    s.updateRecodeTime();
                }));
            }
        }
        else if (e.gameRummyType == RUMMY_GAME_TYPE.PRIVATE && undefined !== t.start_cd) {
            this.time_action && (TweenTool.stopAction(this.time_action), this.time_action = null);
            this.isShowStartBtn = false;
            this.isShowExitBtn = false;
            this.isShowOkBtn = false;
            let t = this.bottom_node.getChildByName("start_btn"), e = this.bottom_node.getChildByName("exit_btn");
            t.active = this.isShowStartBtn;
            e.active = this.isShowExitBtn;
            let i = this.bottom_node.getChildByName("ready_tips"), s = this.bottom_node.getChildByName("pool_time");
            i.active = false;
            s.active = false;
            this.bottom_node.getChildByName("close_btn").active = true;
            this.updateReadyTipPos();
            PushCenter.shared().addListener(PushEvent.GameOverDowntimeTip, (t => {
                if (t.tid_key == this.tid_key) {
                    this.showPrivateTips(t.typeNum, t.TextStr);
                    let e = t.typeNum;
                    4 != e && 5 != e && 6 != e && 7 != e && 15 != e && 16 != e && 17 != e && 18 != e || (i.getComponent(Label).string = t.TextStr, i.active = true);
                }
            }), this);
        }
    }
    updateRecodeTime() {
        if (ToolUtils.isObjValid(this.rootNode)) {
            if (this.startTime = this.startTime - 1, this.startTime < 1) {
                this.stopPoolRummyCountDown();
                ToolUtils.isObjValid(this.node) && this.node.destroy();
                this._callback && this._callback("cleanGameEndPointer");
            }
            else if (RummyDataManager.shared().rummyInfos.has(this.tid_key)) {
                let t = "", e = 28;
                t = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_gameover.over_tips5"), this.startTime);
                let i = this.cround;
                RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType != RUMMY_GAME_TYPE.DEALS && RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType != RUMMY_GAME_TYPE.PRI_DEAL || (t = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_gameover.over_tips7"), i, this.startTime));
                this.bottom_node.getChildByName("pool_time").getComponent(RichText).string = t;
                this.bottom_node.getChildByName("pool_time").getComponent(RichText).fontSize = e;
                this.bottom_node.getChildByName("ready_tips").active = false;
            }
        }
    }
    onClickBtnEvent(t, e) {
        if (SoundManager.shared().playFx("click"), this._bClickBtn = true, "recode_ok" === e) {
            return ToolUtils.isObjValid(this.node) && this.node.destroy(), void (this._callback && this._callback("cleanGameEndPointer"));
        }
        "gameover_switch" === e && (this.bottom_node.getChildByName("switch_btn").getComponent(Button).interactable = false, TweenTool.delayAct(this.node, (() => {
            ToolUtils.isObjValid(this.node) && (this.bottom_node.getChildByName("switch_btn").getComponent(Button).interactable = true);
        }), 1, true));
        RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType != RUMMY_GAME_TYPE.POINTS && RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType != RUMMY_GAME_TYPE.MULTIPLE || "start" !== e || 1 != this._showNewPlayerGuide ? (this._callback && this._callback(e), "start" === e && this.dealStartClickLogic(), "end_ready" == e && (this._callback && this._callback("private_gameOver_self_closed"), this.isShowEndView(false))) : this._callback && this._callback("points_end_tip_guide");
    }
    dealStartClickLogic() {
        let t = RummyDataManager.shared().rummyInfos.get(this.tid_key).entry_fee;
        if (0 == RummyDataManager.shared().rummyInfos.get(this.tid_key).crashModel) {
            if (User.shared().data.money < t) {
                return;
            }
        }
        else if (1 == RummyDataManager.shared().rummyInfos.get(this.tid_key).crashModel && User.shared().data.money_exe < t) {
            return;
        }
        RummyDataManager.shared().rummyInfos.get(this.tid_key).stayInTable || (ToolUtils.isObjValid(this.node) && this.node.destroy(), this._callback && this._callback("cleanGameEndPointer"));
    }
    sortPlayers(t) {
        try {
            let e = 0;
            if (null != t.record_status && (e = t.record_status), 1 == this.fromtype && 1 == e) {
                let e = [], i = -1, s = t.players.length;
                if (t.players) {
                    for (let e = 0; e < s; e++) {
                        if (t.players[e].uid == User.shared().data.uid) {
                            i = e;
                            break;
                        }
                    }
                    if (i < 0) {
                        return;
                    }
                    e.push(t.players[i]);
                    for (let o = i + 1; o < s; o++) {
                        e.push(t.players[o]);
                    }
                    for (let s = 0; s < i; s++) {
                        e.push(t.players[s]);
                    }
                    t.players = [];
                    t.players = e;
                }
                this.msg = null;
                this.msg = t;
            }
            else {
                let e = [], i = [], s = -1, o = -1, a = RummyDataManager.shared().rummyInfos.get(this.tid_key).clientSeatId, h = t.players.length;
                if (t.players) {
                    if (sys.isObjectValid(t.is_tie) && 1 == t.is_tie) {
                        for (let i = 0; i < h; i++) {
                            let s = t.players[i];
                            if (s.uid == User.shared().data.uid && 1 != s.iswin) {
                                e.push(s);
                                break;
                            }
                        }
                    }
                    for (let n = 0; n < h; n++) {
                        let h = t.players[n];
                        h.uid == User.shared().data.uid ? (a = h.seatid, o = n, 1 == h.iswin ? (s = h.seatid, e.push(h)) : s >= 0 && e.push(h)) : 1 == h.iswin ? (s = h.seatid, e.push(h), o >= 0 && e.push(t.players[o])) : i.push(h);
                    }
                    if (i.length > 0) {
                        let t = this;
                        i.sort((function (e, i) {
                            return t.getPosBySeatid(e.seatid, a) - t.getPosBySeatid(i.seatid, a);
                        }));
                        let s = [];
                        for (let t = 0, o = i.length; t < o; t++) {
                            1 !== i[t].status && 5 !== i[t].status ? e.push(i[t]) : s.push(i[t]);
                        }
                        if (s.length > 0) {
                            for (let t = 0, i = s.length; t < i; t++) {
                                e.push(s[t]);
                            }
                        }
                    }
                    t.players = [];
                    t.players = e;
                }
                this.msg = null;
                this.msg = t;
            }
            this.refreshView();
        }
        catch (t) {
            TLog.printError("trycatch RummyPointsMatchOverAlert sortPlayers", t);
        }
    }
    getPosBySeatid(t, e) {
        let i = t - e;
        return i >= 0 ? i : i + RummyDataManager.shared().rummyInfos.get(this.tid_key).pnum;
    }
    checkIsEnd() {
        let t = false;
        return sys.isObjectValid(this.msg) && this.msg.cmd === RummyCmd.SM_GAME_END_BC_INFORM && (t = true), t;
    }
    showPtsRoll() {
        let t, e, i = "", s = this.pts_node.getChildByName("roll_node");
        for (let o = 0; o < 4; o++) {
            let a = 0.2 * o;
            this.scoreRollActs[o] = TweenTool.delayAct(RummyDataManager.shared().sceneNode, (() => {
                ToolUtils.isObjValid(this.node) && (t = this.scoreNumNodes[o], t.active = true, i = "roll" + o, t = s.getChildByName(i), e = t.getComponent(sp.Skeleton), e.setSkin(String(this.scoreNumArrs[o])), e.setAnimation(0, "roll1", false), e.addAnimation(0, "roll2", true));
            }), a, true);
        }
    }
    showPtsAnim(t = false) {
        if (this._showPointsChangeAnim) {
            return;
        }
        if (!this.checkIsPointsMatch()) {
            return;
        }
        let e, i, s = "", o = this.pts_node.getChildByName("roll_node"), a = String(this._myScore).length;
        o.active = true;
        for (let t = 0; t < this.scoreRollActs.length; t++) {
            sys.isObjectValid(this.scoreRollActs[t]) && TweenTool.stopAction(this.scoreRollActs[t]);
        }
        if (t) {
            this.ptsAnimType = 1;
            for (let t = 0; t < 4; t++) {
                let h = 0.2 * t;
                this.scoreRollActs[t] = TweenTool.delayAct(RummyDataManager.shared().sceneNode, (() => {
                    ToolUtils.isObjValid(this.node) && (e = this.scoreNumNodes[t], s = "roll" + t, e = o.getChildByName(s), e.active = true, this._showPointsChangeAnim = true, i = e.getComponent(sp.Skeleton), a > t ? i.setSkin(String(this._myScore)[a - 1 - t]) : i.setSkin("0"), i.setAnimation(0, "roll0", false), i.setAnimation(0, "roll3", false), i.addAnimation(0, "roll0", false));
                }), h, true);
            }
        }
        else {
            this.ptsAnimType = 0;
            this.showPtsRoll();
        }
    }
    setMyFormatPts(t) {
        let e, i, s = this.pts_node.getChildByName("roll_node"), o = "", a = String(t).length;
        for (let h = 0; h < 4; h++) {
            o = "roll" + h;
            e = s.getChildByName(o);
            i = e.getComponent(sp.Skeleton);
            i.clearTracks();
            i.setToSetupPose();
            a > h ? (e.active = true, this.scoreNumArrs[h] = Number(String(t)[a - 1 - h]), i.setSkin(String(t)[a - 1 - h])) : (e.active = true, this.scoreNumArrs[h] = 0, i.setSkin("0"));
            i.setAnimation(0, "roll0", false);
            this.scoreNumNodes[h] = e;
        }
    }
    showMyPtsScore() {
        let t = RummyDataManager.shared().rummyInfos.get(this.tid_key);
        if (this.meWin) {
            if (sys.isObjectValid(t)) {
                let e = t.playerModels[t.clientSeatId];
                sys.isObjectValid(e.score) && (this._mylastScore = e.score, this.hasShowMyPts || (this.setMyFormatPts(this._mylastScore), this.hasShowMyPts = true));
            }
        }
        else {
            this.setMyFormatPts(this._myScore);
        }
    }
    addRewardItem(t, e, i) {
        let s = this.rewardItems[i];
        ToolUtils.isObjValid(s) || (s = instantiate(e));
        s.active = true;
        let o = s.getChildByName("num").getComponent(Label), a = Number(t.type);
        sys.isObjectValid(t.value) && (o.string = 2 === a || 6 === a ? ToolUtils.parse_double(t.value, -1) : t.value + "");
        this.checkIsEnd() && (o.node.active = true);
        let h = s.getChildByName("icon").getComponent(Sprite), n = s.getChildByName("ticket_node"), m = n.getChildByName("discount").getComponent(Label), l = s.getChildByName("tips_btn"), d = s.getChildByName("tips_icon");
        if (2 == a) {
            h.spriteFrame = this.iconImages[0];
        }
        else if (6 == a) {
            h.spriteFrame = this.iconImages[1];
        }
        else if (11 == a) {
            if (h.spriteFrame = this.iconImages[2], n.active = true, sys.isObjectValid(t.discount)) {
                let e = t.discount;
                100 == Number(e) ? (h.spriteFrame = this.ticket_images[1], n.setPosition(v3(0, 0))) : (h.spriteFrame = this.ticket_images[0], n.setPosition(v3(-3, 0)));
                m.string = String(e);
            }
            l.active = true;
            d.active = true;
            l.getComponent(Button).clickEvents[0].customEventData = String(i);
        }
        else if (a == RoomRewardType.PHYSICAL) {
            l.active = true;
            d.active = true;
            l.getComponent(Button).clickEvents[0].customEventData = String(i);
            let e = ToolUtils.isSafeString(t.item_url), s = ToolUtils.getImageUrlPictureName(e);
            ToolUtils.isSafeString(s).length > 0 && (s != this.rewardNames[0] ? (h.spriteFrame = this.iconImages[4], Utils.shared().updateNetImage(h.node, e, size(134, 134), (() => {
            }))) : h.spriteFrame = this.iconImages[3]);
            sys.isObjectValid(t.item_num) && (o.string = t.item_num + "");
        }
        else {
            n.active = false;
            l.active = false;
            d.active = false;
        }
        return s;
    }
    refreshView() {
        try {
            let t = this.msg, e = RummyDataManager.shared().rummyInfos.get(this.tid_key), i = this.round_node.getChildByName("Label").getComponent(Label);
            i18nMgr.shared().changeLabelFont(i, true);
            this.checkIsPointsMatch() ? sys.isObjectValid(t.match_round) && (i.string = ToolUtils.format(i18nMgr.shared().getValueByKey("match_over.round"), t.match_round)) : sys.isObjectValid(t.match_base_money) && (i.string = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_main.match_points_score"), t.match_base_money));
            let s = this.pts_node.getChildByName("tips");
            sys.isObjectValid(t.next_score) && (this.checkIsEnd() && (s.active = true), 0 != i18nMgr.shared().language && (s.getComponent(Label).overflow = Overflow.SHRINK), i18nMgr.shared().changeLabelFont(s.getComponent(Label), false), 0 == t.next_score ? this.checkIsZhangMangMatch() ? s.active = false : s.getComponent(Label).string = i18nMgr.shared().getValueByKey("match_over.max_tips") : this.checkIsPointsMatch() ? s.getComponent(Label).string = ToolUtils.format(i18nMgr.shared().getValueByKey("match_over.next_tips"), t.next_score) : s.getComponent(Label).string = ToolUtils.format(i18nMgr.shared().getValueByKey("match_over.next_tips2"), t.next_score));
            let o = this.pts_node.getChildByName("reward_layout"), a = this.pts_node.getChildByName("item");
            a.active = false;
            let h = 0;
            if (o.removeAllChildren(), sys.isObjectValid(this.msg.infos2) && Array.isArray(this.msg.infos2) && this.msg.infos2.length > 0) {
                let t = [], e = this.msg.infos2.length;
                for (let i = 0; i < e; i++) {
                    let e = this.msg.infos2[i];
                    2 != e.type && 6 != e.type && 11 != e.type && e.type != RoomRewardType.PHYSICAL || t.push(e);
                }
                t.sort(((t, e) => t.type - e.type));
                h = t.length > 4 ? 4 : t.length;
                for (let e = 0; e < h; e++) {
                    let i = this.addRewardItem(t[e], a, e), s = v3(70 * (e - (h - 1) / 2) + 0, 0);
                    i.setPosition(s);
                    o.addChild(i);
                    i.active = true;
                    this.rewardItems[e] = i;
                }
                this.infos = t;
            }
            if (this.rewardItems.length > h) {
                for (let t = h; t < this.rewardItems.length; t++) {
                    ToolUtils.isObjValid(this.rewardItems[t]) && (this.rewardItems[t].active = false);
                }
            }
            this._isWatching = ToolUtils.isSafeNumber(t.isWatching);
            this.tipsMask.active = false;
            let n = 0, m = t.players.length;
            for (let e = 0; e < m; e++) {
                1 == t.players[e].isfold && (n += 1);
            }
            let d = t.lz_card, _ = 20, g = 54, u = 4, v = g + u - _, S = -200, T = 0, I = 484, V = -29, A = 12;
            if (this.laizicard = d, this.itemViewDate = [], this.itemViewNodes = [], this.itemViewPositons = [], t.players) {
                let i = "", s = "", o = this.rootNode.getChildByName("playerView").getChildByName("view").getChildByName("content");
                o.getComponent(UITransform).setContentSize(size(930, 102 * m + 10));
                let a = t.showcard || 0;
                for (let h = 0; h < m; h++) {
                    const d = t.players[h];
                    let C = d.uid, R = d.avatar, O = d.name, E = d.avatar_url, M = d.iswin, j = d.gamesocre, D = d.winscore, x = d.isfold, z = (d.club_level, false);
                    null != d.ready ? z = 1 == d.ready : null != d.zhunbei && (z = 1 == d.zhunbei);
                    let K = 0;
                    null != d.record_status && (K = d.record_status);
                    let H = 0;
                    sys.isObjectValid(d.avatar_frame_id) && (H = d.avatar_frame_id);
                    let U = o.getChildByName(ToolUtils.format("${0}", h));
                    null == U && (U = instantiate(this.mobanView), U.name = ToolUtils.format("${0}", h), o.addChild(U));
                    let G = v3(0, -104 * h);
                    if (U.setPosition(G), this.itemViewNodes[h] = U, this.itemViewPositons[h] = G, this.itemViewDate[h] = {}, this.itemViewDate[h].item = U, this.itemViewDate[h].players = d, e.gameRummyType != RUMMY_GAME_TYPE.POOL && e.gameRummyType != RUMMY_GAME_TYPE.PRI_POOL && e.gameRummyType != RUMMY_GAME_TYPE.DEALS && e.gameRummyType != RUMMY_GAME_TYPE.PRI_DEAL || (D = d.score, j = d.winscore), null == D && (D = ""), null == j && (j = ""), Utils.shared().updateHeadImg(U.getChildByName("head_mask").getChildByName("head"), R, E, size(70, 70)), sys.isObjectValid(User.shared().data.club) && 1 == User.shared().data.club.show_room_avatar_frame) {
                        let t = H;
                        U.getChildByName("club_kuang").active = t > 0;
                        t > 0 && t <= 9 && Utils.shared().setImage(U.getChildByName("club_kuang"), ToolUtils.format("club_headkuang${0}", t), this.clubKuangAtlas);
                    }
                    O = ToolUtils.GetShortName2(O, 8, true);
                    Utils.shared().setStr(U.getChildByName("name"), O);
                    U.getChildByName("help_btn").active = false;
                    U.getChildByName("final_score").active = false;
                    let W = "tip" + h;
                    U.getChildByName("help_btn").getComponent(Button).clickEvents[0].customEventData = W;
                    1 == d.isfinish && (0 == this.fromtype || 1 == this.fromtype && 0 == K) ? e.gameRummyType == RUMMY_GAME_TYPE.DEALS || e.gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL ? 1 === ToolUtils.isSafeNumber(t.all_finish) || this.bIsEnd || 1 != M ? Utils.shared().setStr(U.getChildByName("score"), "" + j) : Utils.shared().setStr(U.getChildByName("score"), "") : e.gameRummyType == RUMMY_GAME_TYPE.MULTIPLE && 1 == e.is_multiple && sys.isObjectValid(d.src_score) ? null != d.lose_half && 1 == d.lose_half || 1 == M || 2 != d.status && 3 != d.status || !sys.isObjectValid(d.src_score) ? Utils.shared().setStr(U.getChildByName("score"), "" + ToolUtils.parse_double("" + j, -2)) : Utils.shared().setStr(U.getChildByName("score"), d.src_score + "/" + ToolUtils.parse_double("" + j, -2)) : Utils.shared().setStr(U.getChildByName("score"), "" + j) : Utils.shared().setStr(U.getChildByName("score"), "");
                    C === User.shared().data.uid ? (U.getChildByName("me_img").active = true, this._meItem = U, sys.isObjectValid(d.score) && (this._myScore = d.score)) : U.getChildByName("me_img").active = false;
                    U.getChildByName("bg").active = true;
                    1 == M ? (U.getChildByName("bg").getComponent(Sprite).spriteFrame = this.itemBgImages[1], C === User.shared().data.uid && (this.meWin = true)) : U.getChildByName("bg").getComponent(Sprite).spriteFrame = this.itemBgImages[0];
                    let Y = U.getChildByName("win_money");
                    if (this.checkIsPointsMatch() && (Y.active = true, U.getChildByName("score").active = false), i = 1 == e.crashModel ? "" + Math.floor(D) : e.gameRummyType === RUMMY_GAME_TYPE.POINTS || e.gameRummyType === RUMMY_GAME_TYPE.MULTIPLE || e.gameRummyType === RUMMY_GAME_TYPE.PRIVATE ? ToolUtils.parse_double("" + D) : "" + D, e.gameRummyType == RUMMY_GAME_TYPE.PRIVATE || e.gameRummyType == RUMMY_GAME_TYPE.PRI_POOL || e.gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL) {
                        let t = U.getChildByName("head_mask").getChildByName("head").getChildByName("ready");
                        t && (t.active = z);
                    }
                    let $ = U.getChildByName("head_mask").getChildByName("head").getChildByName("state");
                    $ && ($.active = false);
                    let Z = U.getChildByName("status");
                    if (Z.getChildByName("flag").active = false, 1 == d.isfinish && (0 == this.fromtype || 1 == this.fromtype && 0 == K)) {
                        if (Z.active = true, 1 == M) {
                            Z.getComponent(Sprite).spriteFrame = this.bottom_card_img[11];
                            Z.getComponent(Sprite).color = color(255, 255, 255);
                            Z.getChildByName("flag").active = true;
                            let o = true;
                            e.gameRummyType != RUMMY_GAME_TYPE.DEALS && e.gameRummyType != RUMMY_GAME_TYPE.PRI_DEAL || this.bIsEnd || (o = 1 === ToolUtils.isSafeNumber(t.all_finish));
                            o ? (Number("" + i) > 0 ? (s = (e.gameRummyType == RUMMY_GAME_TYPE.POOL || e.gameRummyType == RUMMY_GAME_TYPE.PRI_POOL || e.gameRummyType == RUMMY_GAME_TYPE.DEALS || (e.gameRummyType, RUMMY_GAME_TYPE.PRI_DEAL), i), Utils.shared().setStr(Y, s)) : e.gameRummyType == RUMMY_GAME_TYPE.POOL || e.gameRummyType == RUMMY_GAME_TYPE.PRI_POOL ? Utils.shared().setStr(Y, "0") : Utils.shared().setStr(Y, ""), Y.getComponent(Label).color = color(0, 140, 22)) : Utils.shared().setStr(Y, "");
                        }
                        else {
                            Utils.shared().setStr(Y, i);
                            Y.getComponent(Label).color = color(51, 51, 51);
                            1 == d.status ? (Z.getComponent(Sprite).spriteFrame = this.bottom_card_img[7], Z.getComponent(Sprite).color = color(102, 102, 102)) : 3 == d.status ? (Z.getComponent(Sprite).spriteFrame = this.bottom_card_img[10], Z.getComponent(Sprite).color = color(102, 102, 102)) : 5 == d.status ? (Z.getComponent(Sprite).spriteFrame = this.bottom_card_img[9], Z.getComponent(Sprite).color = color(102, 102, 102)) : (Z.getComponent(Sprite).spriteFrame = this.bottom_card_img[8], Z.getComponent(Sprite).color = color(102, 102, 102));
                        }
                    }
                    else {
                        Utils.shared().setStr(Y, "");
                        1 == this.fromtype ? Z.active = false : (Z.getComponent(Sprite).spriteFrame = this.bottom_card_img[8], Z.getComponent(Sprite).color = color(102, 102, 102), Z.active = true);
                    }
                    sys.isObjectValid(t.is_tie) && 1 == t.is_tie && (Z.active = true, 0 == i18nMgr.shared().language ? (Z.getComponent(Sprite).spriteFrame = this.bottom_card_img[12], Z.getComponent(Sprite).color = color(102, 102, 102)) : 1 == i18nMgr.shared().language ? (Z.getComponent(Sprite).spriteFrame = this.bottom_card_img[13], Z.getComponent(Sprite).color = color(255, 255, 255)) : 2 == i18nMgr.shared().language ? (Z.getComponent(Sprite).spriteFrame = this.bottom_card_img[14], Z.getComponent(Sprite).color = color(255, 255, 255)) : 3 == i18nMgr.shared().language && (Z.getComponent(Sprite).spriteFrame = this.bottom_card_img[15], Z.getComponent(Sprite).color = color(255, 255, 255)));
                    let q = ToolUtils.shouldHideSettlementHand(d, a, n >= m - 1);
                    let J = U.getChildByName("cardNodes");
                    if (J.destroyAllChildren(), 1 == d.isfinish && (0 == this.fromtype || 1 == this.fromtype && 0 == K)) {
                        if (U.getChildByName("waiting").active = false, q) {
                            let t, e;
                            _ = 20;
                            for (let i = 0; i < 13; i++) {
                                t = instantiate(this.cardPrefab);
                                t.name = ToolUtils.format("card_${0}", i);
                                J.addChild(t);
                                e = t.getComponent("RummyCard");
                                e.init(1, true, 1);
                                t.setPosition(v3(S + _ * i, T));
                            }
                        }
                        else if (sys.isObjectValid(d.cardinfos) && d.cardinfos.length > 0) {
                            let t, e, i, s, o, a, h, n, m, y, p, b, C, N, w, P = 0, R = 0, k = d.cardinfos.length;
                            for (let e = 0; e < k; e++) {
                                t = d.cardinfos[e];
                                null != t.cards && (R += t.cards.length);
                            }
                            0 == R && (R = 13);
                            a = k;
                            h = (a - 1) * u;
                            n = a * g;
                            m = R - a;
                            _ = (I - h - n) / (1 * m);
                            v = g + u - _;
                            for (let e = 0; e < k; e++) {
                                if (t = d.cardinfos[e], null != t.cards) {
                                    for (let i = 0, s = t.cards.length; i < s; i++) {
                                        p = t.cards[i];
                                        b = instantiate(this.cardPrefab);
                                        b.name = ToolUtils.format("card_${0}_${1}", e, i);
                                        J.addChild(b);
                                        C = b.getComponent("RummyCard");
                                        C.init(p, false, 1);
                                        C.openCard();
                                        C.showJsLaiziFlag(this.isShowLaiziColor(p));
                                        y = S + _ * P + v * e;
                                        b.setPosition(v3(y, T));
                                        P += 1;
                                    }
                                }
                            }
                            P = 0;
                            for (let a = 0; a < k; a++) {
                                if (t = d.cardinfos[a], null != t.cards) {
                                    e = t.color;
                                    i = 0;
                                    s = t.cards.length;
                                    o = Math.floor(s / 2);
                                    for (let e = 0, s = t.cards.length; e < s; e++) {
                                        y = S + _ * P + v * a;
                                        P += 1;
                                        e == o && (i = y);
                                    }
                                    N = instantiate(U.getChildByName("zhegai"));
                                    N.name = ToolUtils.format("zhegai_${0}", a);
                                    J.addChild(N);
                                    0 == e || 1 == e ? N.getComponent(Sprite).spriteFrame = this.bottom_card_img[0] : 2 == e ? N.getComponent(Sprite).spriteFrame = this.bottom_card_img[2] : 3 == e && (N.getComponent(Sprite).spriteFrame = this.bottom_card_img[1]);
                                    0 == Math.floor(s % 2) && (i -= _ / 2);
                                    w = (s - 1) * _ + g;
                                    N.getComponent(UITransform).setContentSize(size(w, A));
                                    N.setSiblingIndex(100 + a);
                                    N.setPosition(v3(i, V));
                                    N.active = true;
                                }
                            }
                        }
                    }
                    else {
                        1 == this.fromtype && 1 == K ? i18nMgr.shared().changeLabelLanguage(U.getChildByName("waiting").getComponent(Label), "rummy_gameover.playing") : i18nMgr.shared().changeLabelLanguage(U.getChildByName("waiting").getComponent(Label), "rummy_gameover.waiting");
                        U.getChildByName("waiting").active = true;
                    }
                }
            }
            if (this.checkIsZhangMangMatch()) {
                let i = this.pts_node.getChildByName("reward_title_bg").getChildByName("layout").getChildByName("Label");
                i18nMgr.shared().changeLocalizedLabelKey(i, "match_over.ranking_reward");
                let s = this.topInfoNode.getChildByName("head_bg"), o = s.getChildByName("head_mask").getChildByName("head"), a = s.getChildByName("club_kuang"), h = this.topInfoNode.getChildByName("rank_num"), n = this.topInfoNode.getChildByName("pts_num"), m = e.clientSeatId, r = e.playerModels[m];
                if (r && (Utils.shared().updateHeadImg(o, r.avatar, r.avatar_url, size(126, 126)), sys.isObjectValid(User.shared().data.club) && 1 == User.shared().data.club.show_room_avatar_frame)) {
                    let t = r.avatar_frame_id;
                    a.active = t > 0;
                    t > 0 && t <= 9 && Utils.shared().setImage(a, ToolUtils.format("club_headkuang${0}", t), this.clubKuangAtlas);
                }
                null != this.msg.match_rank && (h.getComponent(Label).string = this.msg.match_rank + "");
                sys.isObjectValid(t.match_score) && (this._myScore = t.match_score, n.getComponent(Label).string = ToolUtils.parse_double(this._myScore + "", -2));
            }
            if (this.checkIsEnd() && this.showPointsTipsAnim(false), this.checkIsPointsMatch() && this.showMyPtsScore(), this.showMeItemWinAnim(), !sys.isObjectValid(this.msg.up_info) || 1 != this.msg.up_info) {
                let e = false;
                0 == t.next_score && (e = true);
                this.showNextRewardUpOrDown(e);
            }
            let E = this.bottom_node.getChildByName("ready_tips"), M = 0;
            null != t.record_status && (M = t.record_status);
            let j = this.bottom_node.getChildByName("pool_time");
            if (E) {
                if (i18nMgr.shared().changeLabelFontSize(E.getComponent(Label), 28), e.gameRummyType == RUMMY_GAME_TYPE.PRIVATE) {
                    if (this.bIsEnd) {
                        E.active = true;
                        this.showPrivateTipsText(e.gameTipsTextType);
                    }
                    else {
                        E.active = true;
                        i18nMgr.shared().changeLabelLanguage(E.getComponent(Label), "rummy_gameover.over_tips1");
                        let t = 1 == i18nMgr.shared().language ? 26 : 28;
                        i18nMgr.shared().changeLabelFontSize(E.getComponent(Label), t);
                        2 == i18nMgr.shared().language && (t = 22, i18nMgr.shared().changeLabelFontSize(E.getComponent(Label), t));
                    }
                }
                else if (1 == this.fromtype) {
                    1 == M ? (i18nMgr.shared().changeLabelLanguage(E.getComponent(Label), "rummy_gameover.over_tips10"), E.active = true) : 2 == M ? (i18nMgr.shared().changeLabelLanguage(E.getComponent(Label), "rummy_gameover.over_tips9"), E.active = !j.active, E.active) : E.active = false;
                }
                else if (this.bIsEnd) {
                    E.active = false;
                }
                else {
                    E.getComponent(Label).string = "Please wait for all the players to declare.";
                    i18nMgr.shared().changeLabelLanguage(E.getComponent(Label), "rummy_gameover.over_tips1");
                    let e = 1 == i18nMgr.shared().language ? 26 : 28;
                    i18nMgr.shared().changeLabelFontSize(E.getComponent(Label), e);
                    0 === ToolUtils.isSafeNumber(t.all_end) ? (E.active = !j.active, E.active) : E.active = false;
                    2 == i18nMgr.shared().language && (e = 22, i18nMgr.shared().changeLabelFontSize(E.getComponent(Label), e));
                }
            }
            if (1 != this.fromtype && (e.gameRummyType == RUMMY_GAME_TYPE.PRIVATE || e.gameRummyType == RUMMY_GAME_TYPE.PRI_POOL && 1 == this.all_end || e.gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL && 1 == this.all_end)) {
                let t = e.clientSeatId;
                if (1 != e.playerModels[t].ready) {
                    2 !== this.settle_type && this.show_ready_btn();
                    this.bottom_node.getChildByName("close_btn").active = false;
                }
                else {
                    this.hide_ready_btn();
                    this.bottom_node.getChildByName("close_btn").active = true;
                }
            }
            this.updateReadyTipPos();
            1 == this.fromtype && (0 == M && (E.active = false), this.bottom_node.getChildByName("pool_time").active = false);
        }
        catch (t) {
            TLog.printError("trycatch RummyPointsMatchOverAlert refreshView ", t);
        }
    }
    isShowLaiziColor(t) {
        if (78 == this.laizicard || 79 == this.laizicard) {
            if (78 == t || 79 == t || 1 == t || 17 == t || 33 == t || 49 == t) {
                return true;
            }
        }
        else {
            if (78 == t || 79 == t) {
                return true;
            }
            if (this.laizicard % 16 == t % 16) {
                return true;
            }
        }
        return false;
    }
    hide_ready_btn() {
        this.bottom_node.getChildByName("ready_btn").active = false;
        this.updateReadyTipPos();
    }
    show_ready_btn() {
        if (!this.isShowStartBtn) {
            if (1 != this.fromtype) {
                this.bottom_node.getChildByName("ready_btn").active = true;
            }
            this.updateReadyTipPos();
        }
    }
    checkEndFlag() {
        return this.bIsEnd;
    }
    show_btn() {
        this.bottom_node.getChildByName("ready_btn").active = false;
        let t = this.bottom_node.getChildByName("start_btn"), e = this.bottom_node.getChildByName("exit_btn"), i = this.bottom_node.getChildByName("ok_btn"), s = this.bottom_node.getChildByName("switch_btn"), a = this.bottom_node.getChildByName("rejoin_btn"), h = this.bottom_node.getChildByName("cencel_btn"), n = this.bottom_node.getChildByName("yes_btn"), m = this.bottom_node.getChildByName("no_btn"), d = this.bottom_node.getChildByName("ready_tips"), _ = this.bottom_node.getChildByName("pool_out_tips"), g = this.bottom_node.getChildByName("pool_time"), c = this.bottom_node.getChildByName("guide_tips");
        if (s.active = false, this.isShowOkBtn = false, this.isShowStartBtn = false, this.isShowExitBtn = false, this.isShowPoolCencelBtn = false, this.isShowPoolRejoinBtn = false, this.isShowPoolYesBtn = false, this.isShowPoolNoBtn = false, 1 == this.fromtype ? (this.isShowOkBtn = true, this.isShowStartBtn = false, this.isShowExitBtn = false) : (this.isShowStartBtn = true, this.isShowExitBtn = true, this.isShowOkBtn = false), 1 == User.shared().isInPerformanceRoom && this.msg.cmd == RummyCmd.SM_GAME_END_BC_INFORM) {
            return t.active = false, e.active = false, i.active = false, a.active = false, h.active = false, n.active = false, m.active = false, d.active = false, c.active = false, void this.updateReadyTipPos();
        }
        let p = RummyDataManager.shared().rummyInfos.get(this.tid_key);
        if (p.gameRummyType == RUMMY_GAME_TYPE.POOL || p.gameRummyType == RUMMY_GAME_TYPE.PRI_POOL) {
            this.isShowExitBtn = false;
            let e = 0, i = 0;
            this.can_rejoin = 0;
            for (let t = 0, s = this.msg.players.length; t < s; t++) {
                this.msg.players[t].uid == User.shared().data.uid && (e = this.msg.players[t].can_rejoin, i = this.msg.players[t].will_disuse, this.can_rejoin = e, this.will_disuse = i, 1 == i && (this.ispoolRummyend = true));
            }
            let s = this.msg.show_split_prize;
            if (g.setPosition(v3(390, 4)), 1 === this._isWatching && (s = 0, i = 0), 1 == e) {
                ;
            }
            else if (1 == i) {
                p.gameRummyType !== RUMMY_GAME_TYPE.PRI_POOL && this.stopPoolRummyCountDown();
                p.gameRummyType == RUMMY_GAME_TYPE.POOL ? (i18nMgr.shared().changeLabelFont(_.getComponent(Label)), _.getComponent(Label).string = i18nMgr.shared().getValueByKey("rummy_main.out_tip"), this.isShowPoolYesBtn = true, this.isShowPoolNoBtn = true, this.poolRejoin = false, d.active = false, _.active = true) : (this.isShowExitBtn = true, g.setPosition(v3(390, 4)));
            }
            else if (1 == s) {
                this.bottom_node.getChildByName("split_prize_btn").active = true;
                this.bottom_node.getChildByName("split_prize_btn").getChildByName("wz").getComponent(Label).fontSize = 0 == i18nMgr.shared().language ? 28 : 26;
                g.setPosition(v3(390, 4));
                User.shared().curTid_key != this.tid_key && (SoundManager.shared().playFx("rummySelfTurn"), TransferPlatform.shared().openVibrate());
            }
            if (1 == this.all_end ? (t.getChildByName("wz").getComponent(Label).string = i18nMgr.shared().getValueByKey("rummy_gameover.start"), this.isShowStartBtn = false, this.isShowOkBtn = true) : (t.getChildByName("wz").getComponent(Label).string = i18nMgr.shared().getValueByKey("rummy_gameover.okay"), this.isShowStartBtn = false, this.isShowOkBtn = !!this.bIsEnd), this.poolRejoin) {
                if (this.isShowPoolCencelBtn = true, this.isShowPoolRejoinBtn = true, this.isShowOkBtn = false, this.isShowStartBtn = false, this.isShowExitBtn = false, a.active = this.isShowPoolRejoinBtn, 1 == p.crashModel) {
                    let t = a.getChildByName("wz_money");
                    t.getComponent(Label).string = "   " + this.poolRejoinMoney;
                    t.getComponent(Label).updateRenderData(true);
                    let e = a.getChildByName("wz");
                    e.getComponent(Label).updateRenderData(true);
                    e.position = v3(-t.getComponent(UITransform).width / 2, 4);
                    t.position = v3(e.getComponent(UITransform).width / 2, 4);
                    a.getChildByName("icon").active = true;
                    a.getChildByName("icon").position = v3(t.position.x / 2 + 11, 2.5);
                }
                else {
                    let t = a.getChildByName("wz_money");
                    t.getComponent(Label).string = "₹" + this.poolRejoinMoney;
                    t.getComponent(Label).updateRenderData(true);
                    let e = a.getChildByName("wz");
                    e.getComponent(Label).updateRenderData(true);
                    e.position = v3(-t.getComponent(UITransform).width / 2 - 4, 4);
                    t.position = v3(e.getComponent(UITransform).width / 2 + 4, 4);
                    a.getChildByName("icon").active = false;
                }
                g.setPosition(v3(390, 4));
            }
        }
        else if (p.gameRummyType == RUMMY_GAME_TYPE.DEALS || p.gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL) {
            this.pre_end = ToolUtils.isSafeNumber(this.msg.pre_end);
            1 == this.all_end ? (this.isShowOkBtn = true, this.isShowStartBtn = false, this.isShowExitBtn = false, this.bottom_node.getChildByName("pool_time").setPosition(v3(390, 4))) : (this.isShowOkBtn = !!this.bIsEnd, this.isShowStartBtn = false, this.isShowExitBtn = false, this.bottom_node.getChildByName("pool_time").setPosition(v3(390, 4)));
            1 === this.settle_type ? p.gameRummyType == RUMMY_GAME_TYPE.DEALS ? (this.isShowPoolYesBtn = true, this.isShowPoolNoBtn = true, this.poolRejoin = false, d.active = false, g.active = false, _.active = true, this.isShowOkBtn = false, this.isShowStartBtn = false, this.isShowExitBtn = false, i18nMgr.shared().changeLabelFont(_.getComponent(Label)), _.getComponent(Label).string = i18nMgr.shared().getValueByKey("rummy_main.out_tip")) : p.gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL && (this.isShowOkBtn = true, this.isShowStartBtn = false, this.isShowExitBtn = false, this.isShowPoolYesBtn = false, this.isShowPoolNoBtn = false, this.poolRejoin = false) : 2 === this.settle_type ? (p.gameRummyType == RUMMY_GAME_TYPE.DEALS ? (this.isShowPoolYesBtn = true, this.isShowPoolNoBtn = true, this.isShowOkBtn = false, this.isShowExitBtn = false) : p.gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL && (this.isShowPoolYesBtn = false, this.isShowPoolNoBtn = false, this.isShowOkBtn = true, this.isShowExitBtn = true), this.poolRejoin = false, d.active = false, _.active = true, this.isShowStartBtn = false, g.active = false) : 3 === this.settle_type && (this.isShowOkBtn = true, this.isShowStartBtn = false, this.isShowExitBtn = false, this.isShowPoolYesBtn = false, this.isShowPoolNoBtn = false, this.poolRejoin = false);
            1 === this.pre_end && this.bottom_node.getChildByName("pool_time").setPosition(v3(372, 4));
        }
        else if (p.gameRummyType == RUMMY_GAME_TYPE.PRIVATE) {
            let e = p.clientSeatId;
            1 == p.playerModels[e].ready && (this.isShowOkBtn = false, this.isShowStartBtn = false, this.isShowExitBtn = false);
            this.msg.cmd !== RummyCmd.SM_GAME_END_BC_INFORM && this.msg.cmd !== RummyCmd.SM_FINISH_STATUS_INFO || i18nMgr.shared().changeLocalizedLabelKey(t.getChildByName("wz"), "rummy_gameover.ready");
        }
        else {
            p.gameRummyType == RUMMY_GAME_TYPE.MATCH ? (this.isShowOkBtn = true, this.isShowStartBtn = false, this.isShowExitBtn = false, 1 != this.fromtype && this.checkIsPointsMatch() && sys.isObjectValid(this.msg.match_over) && (this.isShowStartBtn = 0 == this.msg.match_over, this.isShowOkBtn = 1 == this.msg.match_over)) : p.gameRummyType != RUMMY_GAME_TYPE.POINTS && p.gameRummyType !== RUMMY_GAME_TYPE.MULTIPLE || !this.bIsEnd || 1 == this._showNewPlayerGuide && (HttpManager.shared().doReportPlayerGuideAct(PhpReportDefined.roomPlayerGuideEvent.loseGameSHow), c.getComponent(RichText).string = i18nMgr.shared().getValueByKey("rummy_gameover.guide_tips"), c.getComponent(RichText).node.on(Node.EventType.TOUCH_END, this.guideRichTextClick, this), c.active = true, d.active = false, _.active = false, g.active = false);
        }
        this.msg.cmd === RummyCmd.SM_FINISH_STATUS_INFO && (p.gameRummyType == RUMMY_GAME_TYPE.POOL || p.gameRummyType == RUMMY_GAME_TYPE.PRI_POOL || p.gameRummyType == RUMMY_GAME_TYPE.DEALS || (p.gameRummyType, RUMMY_GAME_TYPE.PRI_DEAL));
        t.active = this.isShowStartBtn;
        e.active = this.isShowExitBtn;
        i.active = this.isShowOkBtn;
        a.active = this.isShowPoolRejoinBtn;
        h.active = this.isShowPoolCencelBtn;
        n.active = this.isShowPoolYesBtn;
        m.active = this.isShowPoolNoBtn;
        0 !== this.hide_start && (this.isShowStartBtn = false, t.active = this.isShowStartBtn);
        1 == this.poolRejoin && 0 == this.startTime && this.showYesOrNobtn();
        this.updateReadyTipPos();
        this.checkShowWinShareBtn();
    }
    checkOverBtnsToDestroryEndAlert() {
        let t = this.bottom_node.getChildByName("ready_btn"), e = this.bottom_node.getChildByName("start_btn"), i = this.bottom_node.getChildByName("exit_btn"), s = this.bottom_node.getChildByName("ok_btn"), o = this.bottom_node.getChildByName("close_btn"), a = this.bottom_node.getChildByName("switch_btn"), h = this.bottom_node.getChildByName("split_prize_btn"), n = this.bottom_node.getChildByName("cencel_btn"), m = this.bottom_node.getChildByName("rejoin_btn"), r = this.bottom_node.getChildByName("yes_btn"), l = this.bottom_node.getChildByName("no_btn"), d = 0;
        d += t.active ? 1 : 0;
        d += e.active ? 1 : 0;
        d += i.active ? 1 : 0;
        d += s.active || o.active ? 1 : 0;
        d += a.active ? 1 : 0;
        d += h.active ? 1 : 0;
        d += n.active ? 1 : 0;
        d += m.active ? 1 : 0;
        d += r.active ? 1 : 0;
        d += l.active ? 1 : 0;
        let y = false;
        return 1 == d && (y = true), y;
    }
    guideRichTextClick(t) {
        SoundManager.shared().playFx("click");
        this._callback && this._callback("points_end_guide");
    }
    show_switch_btn(t) {
        let e = RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType;
        if (e == RUMMY_GAME_TYPE.POINTS || e === RUMMY_GAME_TYPE.MULTIPLE) {
            this.bottom_node.getChildByName("switch_btn").active = t;
            this.isShowSwitchBtn = t;
            this.updateReadyTipPos();
        }
    }
    reshow_btn(t = false) {
        this.bottom_node.getChildByName("ready_btn").active = false;
        let e = this.bottom_node.getChildByName("start_btn"), i = this.bottom_node.getChildByName("exit_btn"), s = this.bottom_node.getChildByName("ok_btn");
        e.active = this.isShowStartBtn;
        i.active = this.isShowExitBtn;
        s.active = this.isShowOkBtn;
        let o = this.bottom_node.getChildByName("rejoin_btn"), a = this.bottom_node.getChildByName("cencel_btn");
        o.active = this.isShowPoolRejoinBtn;
        a.active = this.isShowPoolCencelBtn;
        this.bottom_node.getChildByName("switch_btn").active = this.isShowSwitchBtn;
        let h = this.bottom_node.getChildByName("yes_btn"), n = this.bottom_node.getChildByName("no_btn");
        h.active = this.isShowPoolYesBtn;
        n.active = this.isShowPoolNoBtn;
        let m = this.bottom_node.getChildByName("ready_tips"), r = this.bottom_node.getChildByName("pool_out_tips");
        if (this.isShowPoolNoBtn && (m.active = false, RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType == RUMMY_GAME_TYPE.POOL && (i18nMgr.shared().changeLabelFont(r.getComponent(Label)), r.getComponent(Label).string = i18nMgr.shared().getValueByKey("rummy_main.out_tip")), r.active = true), this.updateReadyTipPos(), this.checkShowWinShareBtn(t), this.checkIsPointsMatch()) {
            if (this.pts_node.getChildByName("roll_node").active = true, this.hasShowMyPts) {
                for (let t = 0; t < this.scoreRollActs.length; t++) {
                    sys.isObjectValid(this.scoreRollActs[t]) && TweenTool.stopAction(this.scoreRollActs[t]);
                }
                if (0 == this.ptsAnimType) {
                    if (this.rollcount >= 1) {
                        return;
                    }
                    this.rollcount += 1;
                    this.showPtsRoll();
                }
                else {
                    this.setMyFormatPts(this._myScore);
                }
            }
            else {
                this.setMyFormatPts(this._myScore);
            }
        }
    }
    isAlreadyShow() {
        return this.node.active && this.rootNode.active;
    }
    checkShowWinShareBtn(t = false) {
        let e = 0;
        if (null != this.msg.record_status && (e = this.msg.record_status), this.bIsEnd && 0 == e && RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType == RUMMY_GAME_TYPE.PRIVATE && (this.msg.cmd === RummyCmd.SM_GAME_END_BC_INFORM || this.msg.cmd === RummyCmd.SM_LAST_CARD_RETURN) && sys.isObjectValid(this.msg.players)) {
            for (let e = 0, i = this.msg.players.length; e < i; e++) {
                if (this.msg.players[e].uid == User.shared().data.uid) {
                    1 == Number(this.msg.players[e].iswin) ? PushCenter.shared().pushEvent(PushEvent.ShowWinShareBtn, true) : t && PushCenter.shared().pushEvent(PushEvent.ShowWinShareBtn, false);
                    break;
                }
            }
        }
    }
    setLandscapeShow() {
        ToolUtils.getOrientation() || this.node.setRotationFromEuler(v3(0, 0, -90));
    }
    isShowEndView(t) {
        let e = this.node.active;
        this.node.active = t;
        t && !e && this.startShowAnim();
        t && !e ? this.pushGamePopNode() : !t && e && this.removePopNode();
    }
    onEnterLineUp() {
        this._bClickBtn && (ToolUtils.isObjValid(this.node) && this.node.destroy(), this._callback && this._callback("cleanGameEndPointer"));
    }
    showCountDown(t) {
        let e = RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType;
        if (e == RUMMY_GAME_TYPE.POINTS || e == RUMMY_GAME_TYPE.MULTIPLE || e == RUMMY_GAME_TYPE.MATCH) {
            let e = this.bottom_node.getChildByName("ready_tips");
            t && e && t.length > 0 ? (e.getComponent(Label).string = t, e.active = true) : e.active = false;
        }
    }
    showPrivateTips(t, e) {
        if (1 != this.fromtype && RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType == RUMMY_GAME_TYPE.PRIVATE) {
            let i = this.bottom_node.getChildByName("ready_tips");
            4 != t && 4 != t && 5 != t && 6 != t && 7 != t && 15 != t && 16 != t && 17 != t && 18 != t || (i.getComponent(Label).string = e, i.active = true);
        }
    }
    showPrivateTipsText(t) {
        if (1 == this.fromtype) {
            return;
        }
        let e = "", i = RummyDataManager.shared().rummyInfos.get(this.tid_key).gameTipsTextDownTime;
        if (RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType == RUMMY_GAME_TYPE.PRIVATE) {
            0 == t ? e = "" : 1 == t ? e = i18nMgr.shared().getValueByKey("rummy_main.gameTipstext13") : 2 == t ? i > 0 && (e = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_main.gameTipsText"), i)) : 3 == t ? e = i18nMgr.shared().getValueByKey("rummy_main.gameTipsText10") : 4 == t ? i > 0 && (e = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_main.gameTipsText1"), i)) : 5 == t ? e = i18nMgr.shared().getValueByKey("rummy_main.gameTipsText7") : 6 == t ? e = i18nMgr.shared().getValueByKey("rummy_main.gameTipsText8") : 7 == t || 8 == t || 9 == t ? i > 0 && (e = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_main.gameTipsText"), i)) : 10 == t || (11 == t || 12 == t ? i > 0 && (e = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_main.gameTipsText"), i)) : 13 == t ? e = i18nMgr.shared().getValueByKey("rummy_main.gameTipsText9") : 14 == t ? e = i18nMgr.shared().getValueByKey("rummy_main.gameTipstext13") : 15 == t ? e = i18nMgr.shared().getValueByKey("rummy_main.gameTipstext15") : 16 == t ? e = i18nMgr.shared().getValueByKey("rummy_main.gameTipstext16") : 17 == t ? i > 0 && (e = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_main.gameTipstext17"), i)) : 18 == t && (e = i18nMgr.shared().getValueByKey("rummy_main.gameTipstext18")));
            let s = this.bottom_node.getChildByName("ready_tips");
            0 != t && 4 != t && 5 != t && 6 != t && 7 != t && 15 != t && 16 != t && 17 != t && 18 != t || (s.getComponent(Label).string = e, s.active = true);
        }
    }
    showReadyView(t, e) {
        if (RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType == RUMMY_GAME_TYPE.PRIVATE) {
            for (let i = 0, s = this.itemViewDate.length; i < s; i++) {
                if (this.itemViewDate[i].item && this.itemViewDate[i].item.isValid) {
                    let s = this.itemViewDate[i].item, o = this.itemViewDate[i].players;
                    if (o.seatid == t) {
                        if (null != o.ready ? o.ready = e ? 1 : 0 : null != o.zhunbei && (o.zhunbei = e ? 1 : 0), e) {
                            let t = s.getChildByName("head_mask").getChildByName("head").getChildByName("ready");
                            t && (t.active = e);
                        }
                        break;
                    }
                }
            }
        }
    }
    updateReadyTipPos() {
        let t = this.bottom_node.getChildByName("ready_btn"), e = this.bottom_node.getChildByName("start_btn"), i = this.bottom_node.getChildByName("exit_btn"), s = this.bottom_node.getChildByName("ok_btn"), o = this.bottom_node.getChildByName("close_btn"), a = this.bottom_node.getChildByName("switch_btn"), h = this.bottom_node.getChildByName("split_prize_btn"), n = this.bottom_node.getChildByName("cencel_btn"), m = this.bottom_node.getChildByName("rejoin_btn"), l = this.bottom_node.getChildByName("yes_btn"), d = this.bottom_node.getChildByName("no_btn"), y = 0;
        y += t.active ? 1 : 0;
        y += e.active ? 1 : 0;
        y += i.active ? 1 : 0;
        y += s.active || o.active ? 1 : 0;
        y += a.active ? 1 : 0;
        y += h.active ? 1 : 0;
        RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType != RUMMY_GAME_TYPE.POOL && RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType != RUMMY_GAME_TYPE.PRI_POOL || (y += n.active ? 1 : 0, y += m.active ? 1 : 0, y += l.active ? 1 : 0, y += d.active ? 1 : 0);
        1 == y ? (this.bottom_node.getChildByName("ready_tips").setPosition(v3(390, 4)), this.bottom_node.getChildByName("pool_time").setPosition(v3(390, 4)), i.active && (i.position = e.position)) : 0 == y ? (this.bottom_node.getChildByName("ready_tips").setPosition(v3(619, 4)), this.bottom_node.getChildByName("pool_time").setPosition(v3(619, 4))) : (this.bottom_node.getChildByName("ready_tips").setPosition(v3(173, 4)), this.bottom_node.getChildByName("pool_time").setPosition(v3(173, 4)), i.active && (i.position = h.position));
    }
    setPoolRummyCountDown(t, e) {
        if (1 == User.shared().isInPerformanceRoom) {
            return;
        }
        if (!RummyDataManager.shared().rummyInfos.get(this.tid_key)) {
            return;
        }
        let i = RummyDataManager.shared().rummyInfos.get(this.tid_key);
        if (1 == this.all_end && e) {
            return void (i.game_end_state = 5);
        }
        if (i.gameRummyType !== RUMMY_GAME_TYPE.PRI_POOL && 1 == this.will_disuse) {
            return;
        }
        this.time_action && (TweenTool.stopAction(this.time_action), this.time_action = null);
        this.startTime = t;
        let s = 28;
        i.end_game_countdown = this.startTime;
        let o = "", a = true, h = false, n = this.bottom_node.getChildByName("pool_out_tips");
        if (this.poolRejoin ? (o = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_gameover.over_tips3"), this.poolRejoinScore, this.startTime), s = 22) : 5 == i.game_end_state ? o = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_gameover.over_tips4"), this.startTime) : (o = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_gameover.over_tips5"), this.startTime), i.gameRummyType != RUMMY_GAME_TYPE.POOL && i.gameRummyType != RUMMY_GAME_TYPE.PRI_POOL || 1 == i.game_end_state && (o = "<color=#000000>" + ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_main.gameTipsText6"), this.startTime) + "</color>", s = 18), i.gameRummyType == RUMMY_GAME_TYPE.PRI_POOL && 1 === this.will_disuse && (o = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_gameover.over_tips12"), this.startTime))), i.gameRummyType == RUMMY_GAME_TYPE.DEALS || i.gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL) {
            if (this.dealsMyTiebreak) {
                o = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_gameover.over_tips6"), this.startTime);
            }
            else if (5 == i.game_end_state) {
                o = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_gameover.over_tips4"), this.startTime);
            }
            else {
                let t = this.cround + 1;
                o = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_gameover.over_tips7"), t, this.startTime);
            }
            1 === this.pre_end && (o = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_gameover.over_tips11"), this.startTime));
            2 === this.settle_type ? (a = false, h = true, i18nMgr.shared().changeLabelFont(n.getComponent(Label)), i.gameRummyType == RUMMY_GAME_TYPE.DEALS ? n.getComponent(Label).string = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_gameover.over_tips13"), this.win_prize, this.startTime) : i.gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL && (n.getComponent(Label).string = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_gameover.over_tips14"), this.win_prize, this.startTime))) : 1 === this.settle_type ? i.gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL && (a = true, h = false, o = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_gameover.over_tips12"), this.startTime)) : 3 === this.settle_type && (a = true, h = false, o = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_gameover.over_tips5"), this.startTime));
        }
        (i.gameRummyType == RUMMY_GAME_TYPE.POINTS || i.gameRummyType == RUMMY_GAME_TYPE.MULTIPLE || this.checkIsPointsMatch()) && (this.startTime > 0 ? (this.bottom_node.getChildByName("pool_time").setPosition(v3(390, 4)), o = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_gameover.over_tips8"), this.startTime), this.checkIsPointsMatch() && (s = 28)) : o = "");
        1 == this.is_auto_split ? o = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_gameover.auto_split_tip"), ToolUtils.parse_double("" + this.auto_split_money, 0), this.startTime) : 2 == this.is_auto_split && (o = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_gameover.over_tips16"), this.startTime));
        this.bottom_node.getChildByName("pool_time").active = a;
        this.bottom_node.getChildByName("ready_tips").active = false;
        this.bottom_node.getChildByName("pool_time").getComponent(RichText).string = o;
        this.bottom_node.getChildByName("pool_time").getComponent(RichText).fontSize = s;
        n.active = h;
        this.updateReadyTipPos();
        let m = this;
        this.time_action = TweenTool.myschedule(RummyDataManager.shared().sceneNode, 1, (() => {
            m.updateTime();
        }));
    }
    stopPoolRummyCountDown() {
        this.time_action && (TweenTool.stopAction(this.time_action), this.time_action = null);
        RummyDataManager.shared().rummyInfos.has(this.tid_key) && (RummyDataManager.shared().rummyInfos.get(this.tid_key).end_game_countdown = 0);
        this.bottom_node.getChildByName("pool_time").active = false;
    }
    updateTime() {
        if (!ToolUtils.isObjValid(this.rootNode)) {
            return;
        }
        this.startTime = this.startTime - 1;
        let t = RummyDataManager.shared().rummyInfos.get(this.tid_key);
        sys.isObjectValid(t) && (t.end_game_countdown = this.startTime);
        let e = this.bottom_node.getChildByName("pool_out_tips");
        if (this.startTime <= 0) {
            if (!sys.isObjectValid(t) || t.gameRummyType != RUMMY_GAME_TYPE.POINTS && t.gameRummyType != RUMMY_GAME_TYPE.MULTIPLE) {
                if (2 === this.settle_type && (e.active = false), this.stopPoolRummyCountDown(), sys.isObjectValid(t) && t.gameRummyType == RUMMY_GAME_TYPE.POOL && this.poolRejoin) {
                    this.isShowPoolYesBtn = true;
                    this.isShowPoolNoBtn = true;
                    this.poolRejoin = false;
                    this.isShowStartBtn = false;
                    this.isShowExitBtn = false;
                    this.isShowOkBtn = false;
                    this.isShowPoolRejoinBtn = false;
                    this.isShowPoolCencelBtn = false;
                    this.isShowSwitchBtn = false;
                    this.reshow_btn();
                }
                else {
                    if (sys.isObjectValid(t) && t.gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL && 2 === this.settle_type) {
                        return this._callback("no"), ToolUtils.isObjValid(this.node) && this.node.destroy(), void (this._callback && this._callback("cleanGameEndPointer"));
                    }
                    1 == this.all_end && this._callback("pool_game_all_end");
                    ToolUtils.isObjValid(this.node) && this.node.destroy();
                    this._callback && (this._callback("gameOverAlertDestroy"), this._callback("cleanGameEndPointer"));
                }
            }
            else {
                this.bottom_node.getChildByName("pool_time").active = false;
                this.stopPoolRummyCountDown();
                this._callback && this._callback("points_time_out");
                this.dealStartClickLogic();
            }
        }
        else if (sys.isObjectValid(t)) {
            let i = "", s = 28;
            if (this.poolRejoin ? (i = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_gameover.over_tips3"), this.poolRejoinScore, this.startTime), s = 22) : 5 == t.game_end_state ? i = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_gameover.over_tips4"), this.startTime) : (i = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_gameover.over_tips5"), this.startTime), t.gameRummyType != RUMMY_GAME_TYPE.POOL && t.gameRummyType != RUMMY_GAME_TYPE.PRI_POOL || 1 == t.game_end_state && (i = "<color=#000000>" + ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_main.gameTipsText6"), this.startTime) + "</color>", s = 18), t.gameRummyType == RUMMY_GAME_TYPE.PRI_POOL && 1 === this.will_disuse && (i = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_gameover.over_tips12"), this.startTime))), t.gameRummyType == RUMMY_GAME_TYPE.DEALS || t.gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL) {
                if (this.dealsMyTiebreak) {
                    i = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_gameover.over_tips6"), this.startTime);
                }
                else if (5 == t.game_end_state) {
                    i = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_gameover.over_tips4"), this.startTime);
                }
                else {
                    let t = this.cround + 1;
                    i = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_gameover.over_tips7"), t, this.startTime);
                }
                1 === this.pre_end && (i = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_gameover.over_tips11"), this.startTime));
                2 === this.settle_type ? t.gameRummyType == RUMMY_GAME_TYPE.DEALS ? e.getComponent(Label).string = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_gameover.over_tips13"), this.win_prize, this.startTime) : t.gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL && (e.getComponent(Label).string = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_gameover.over_tips14"), this.win_prize, this.startTime)) : 1 === this.settle_type ? t.gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL && (i = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_gameover.over_tips12"), this.startTime)) : 3 === this.settle_type && (i = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_gameover.over_tips5"), this.startTime));
            }
            (t.gameRummyType == RUMMY_GAME_TYPE.POINTS || t.gameRummyType == RUMMY_GAME_TYPE.MULTIPLE || this.checkIsPointsMatch()) && (i = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_gameover.over_tips8"), this.startTime));
            1 == this.is_auto_split ? i = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_gameover.auto_split_tip"), ToolUtils.parse_double("" + this.auto_split_money, 0), this.startTime) : 2 == this.is_auto_split && (i = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_gameover.over_tips16"), this.startTime));
            this.bottom_node.getChildByName("pool_time").getComponent(RichText).string = i;
            this.bottom_node.getChildByName("pool_time").getComponent(RichText).fontSize = s;
            this.bottom_node.getChildByName("ready_tips").active = false;
        }
    }
    showYesOrNobtn() {
        this.stopPoolRummyCountDown();
        RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType != RUMMY_GAME_TYPE.POOL && RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType != RUMMY_GAME_TYPE.PRI_POOL || this.poolRejoin && (this.isShowPoolYesBtn = true, this.isShowPoolNoBtn = true, this.poolRejoin = false, this.isShowStartBtn = false, this.isShowExitBtn = false, this.isShowOkBtn = false, this.isShowPoolRejoinBtn = false, this.isShowPoolCencelBtn = false, this.isShowSwitchBtn = false, this.reshow_btn());
    }
    updateBtnShow() {
        let t = RummyDataManager.shared().rummyInfos.get(this.tid_key);
        if (0 == t.game_end_state) {
            this.bottom_node.getChildByName("start_btn").active = true;
            this.bottom_node.getChildByName("split_prize_btn").active = false;
            this.bottom_node.getChildByName("pool_time").setPosition(v3(390, 4));
        }
        else if (1 == t.game_end_state) {
            this.bottom_node.getChildByName("start_btn").active = false;
            this.bottom_node.getChildByName("ok_btn").active = true;
            this.bottom_node.getChildByName("split_prize_btn").active = false;
            this.bottom_node.getChildByName("pool_time").setPosition(v3(390, 4));
        }
        else if (2 == t.game_end_state) {
            if (this.bottom_node.getChildByName("start_btn").active = false, this.bottom_node.getChildByName("ok_btn").active = true, 1 !== this._isWatching) {
                this.bottom_node.getChildByName("split_prize_btn").active = true;
                this.bottom_node.getChildByName("split_prize_btn").getChildByName("wz").getComponent(Label).fontSize = 0 == i18nMgr.shared().language ? 28 : 26;
                User.shared().curTid_key != this.tid_key && (SoundManager.shared().playFx("rummySelfTurn"), TransferPlatform.shared().openVibrate());
            }
            this.bottom_node.getChildByName("pool_time").setPosition(v3(390, 4));
        }
        else {
            3 == t.game_end_state ? (this.bottom_node.getChildByName("start_btn").active = true, this.bottom_node.getChildByName("split_prize_btn").active = false, this.bottom_node.getChildByName("exit_btn").active = true, this.stopPoolRummyCountDown()) : 4 == t.game_end_state && (this.bottom_node.getChildByName("ok_btn").active = true, this.bottom_node.getChildByName("start_btn").active = false, this.bottom_node.getChildByName("split_prize_btn").active = false, this.bottom_node.getChildByName("pool_time").setPosition(v3(390, 4)));
        }
        t.gameRummyType == RUMMY_GAME_TYPE.POOL && this.poolRejoin && (this.isShowPoolCencelBtn = true, this.isShowPoolRejoinBtn = true, this.bottom_node.getChildByName("cencel_btn").active = true, this.bottom_node.getChildByName("rejoin_btn").active = true, this.bottom_node.getChildByName("pool_time").setPosition(v3(357, 4)), this.bottom_node.getChildByName("start_btn").active = false, this.bottom_node.getChildByName("ok_btn").active = false, this.bottom_node.getChildByName("exit_btn").active = false);
        this.isShowOkBtn = this.bottom_node.getChildByName("ok_btn").active;
        this.isShowStartBtn = this.bottom_node.getChildByName("start_btn").active;
        this.isShowExitBtn = this.bottom_node.getChildByName("exit_btn").active;
        0 !== this.hide_start && (this.isShowStartBtn = false, this.bottom_node.getChildByName("start_btn").active = false);
        this.updateReadyTipPos();
    }
    setPoolRummyIsEnd(t) {
        this.ispoolRummyend = t;
    }
    getPoolRummyIsEnd() {
        return this.ispoolRummyend;
    }
    updateDealsView() {
        this.bottom_node.getChildByName("start_btn").active = true;
        this.bottom_node.getChildByName("exit_btn").active = true;
        this.bottom_node.getChildByName("ok_btn").active = false;
        0 !== this.hide_start && (this.isShowStartBtn = false, this.bottom_node.getChildByName("start_btn").active = false);
        this.stopPoolRummyCountDown();
    }
    itemHelpBtnOnclick(t, e) {
        SoundManager.shared().playFx("click");
        let i = parseInt(e.substring("tip".length)), s = 0.5 * GameConfig.REAL_SCREEN_WIDTH;
        for (let t = 0, e = this.itemViewDate.length; t < e; t++) {
            if (t == i) {
                if (this._showIndex = t, this.itemViewDate[t].item && this.itemViewDate[t].item.isValid) {
                    let e = this.itemViewDate[t].item, i = e.children.length + 1;
                    e.getChildByName("help_btn").setSiblingIndex(i);
                    let o = e.getChildByName("help_btn").getWorldPosition();
                    1 == i18nMgr.shared().language ? (this.tipsMask.getComponent(UITransform).contentSize = size(780, 60), this.tipsMask.setPosition(v3(25, o.y - s - 50))) : (this.tipsMask.getComponent(UITransform).contentSize = size(730, 60), this.tipsMask.setPosition(v3(50, o.y - s - 50)));
                    this.tipsMask.active = true;
                }
                break;
            }
        }
    }
    onCloseItemHelpTips(t, e = "") {
        this.tipsMask.active = false;
    }
    itemCloseTipsClick(t, e) {
        SoundManager.shared().playFx("click");
        this.bubble_tipNode.active = false;
    }
    onItemTipsBtnClick(t, e) {
        SoundManager.shared().playFx("click");
        this.bubble_tipNode.active = true;
        let i = this.rewardItems[Number(e)], s = new Vec3;
        i.getWorldPosition(s);
        let o = this.bubble_tipNode.getChildByName("bubble"), a = this.bubble_tipNode.getChildByName("bubble2");
        if (Array.isArray(this.infos) && this.infos.length > Number(e)) {
            if (this.infos[Number(e)].type == RoomRewardType.TICKET) {
                o.active = true;
                a.active = false;
                0 == Number(e) && this.rewardItems.length >= 4 ? o.setPosition(v3(-429, 34)) : o.setPosition(v3(-399, 34));
                let t = v3();
                o.inverseTransformPoint(t, s);
                o.getChildByName("arrow").setPosition(v3(t.x, -122.5));
                let i = o.getChildByName("name").getComponent(Label), h = o.getChildByName("purpose").getComponent(Label), n = Number(this.infos[Number(e)].discount);
                i18nMgr.shared().changeLabelFont(i);
                i.string = ToolUtils.format(i18nMgr.shared().getValueByKey("ticket.reward_tip_name"), n);
                i18nMgr.shared().changeLabelFont(h);
                sys.isObjectValid(this.infos[Number(e)].match_name) && (h.string = ToolUtils.format(i18nMgr.shared().getValueByKey("ticket.reward_tip_purpose"), this.infos[Number(e)].match_name, n));
            }
            else if (this.infos[Number(e)].type == RoomRewardType.PHYSICAL) {
                o.active = false;
                a.active = true;
                0 == Number(e) && this.rewardItems.length >= 4 ? a.setPosition(v3(-429, -96)) : a.setPosition(v3(-399, -96));
                let t = v3();
                a.inverseTransformPoint(t, s);
                a.getChildByName("arrow").setPosition(v3(t.x, 7));
            }
        }
    }
    onBackView() {
        let t = false;
        1 == this.fromtype && (t = true, RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType === RUMMY_GAME_TYPE.PRIVATE && undefined !== this.msg.start_cd && (t = false));
        t && (this.startHideAnim(), this.isShowEndView(false));
    }
    pushGamePopNode() {
        let t = RummyDataManager.shared().rummyInfos.get(this.tid_key).popNode;
        if (t && t.length > 0) {
            for (let e = 0, i = t.length; e < i; e++) {
                if (this.node.name == t[e].name) {
                    return;
                }
            }
            let e = { node: this.node, tid_key: this.tid_key };
            PushCenter.shared().pushEvent(PushEvent.pushGamePopNode, e);
        }
    }
    removePopNode() {
        let t = RummyDataManager.shared().rummyInfos.get(this.tid_key).popNode;
        if (t && t.length > 0) {
            for (let e = 0, i = t.length; e < i; e++) {
                if (this.node.name == t[e].name) {
                    RummyDataManager.shared().rummyInfos.get(this.tid_key).popNode.splice(e, 1);
                    break;
                }
            }
        }
    }
    checkIsPointsMatch() {
        let t = false, e = RummyDataManager.shared().rummyInfos.get(this.tid_key);
        return sys.isObjectValid(e) && e.gameRummyType == RUMMY_GAME_TYPE.MATCH && e.gameMatchMode == RUMMY_MATCH_MODE.PointsMatch && (t = true), t;
    }
    checkIsZhangMangMatch() {
        let t = false, e = RummyDataManager.shared().rummyInfos.get(this.tid_key);
        return sys.isObjectValid(e) && e.gameRummyType == RUMMY_GAME_TYPE.MATCH && e.gameMatchMode != RUMMY_MATCH_MODE.PointsMatch && (t = true), t;
    }
}
