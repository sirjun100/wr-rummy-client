// @ts-nocheck
// Recovered from index.js:475
import { _decorator, Button, color, instantiate, Label, Node, Prefab, ScrollView, size, Size, Sprite, SpriteAtlas, SpriteFrame, sys, UITransform, v3, Vec3 } from "cc";
import Utils from "./Utils";
import SoundManager from "./SoundManager";
import RummyDataManager from "./RummyDataManager";
import TweenTool from "./TweenTool";
import BaseLayer from "./BaseLayer";
import PushCenter from "./PushCenter";
import PushEvent from "./PushEvent";
import GameConfig from "./GameConfig";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("RummyOpenCardsAlert")
export default class RummyOpenCardsAlert extends BaseLayer {
    @property({ type: Node, displayName: "" })
    public closeNode: Node = null;
    @property(Node)
    public rootNode: Node = null;
    @property(SpriteAtlas)
    public myAtlas: SpriteAtlas = null;
    @property(Prefab)
    public cardPrefab: Prefab = null;
    @property(Node)
    public mobanView: Node = null;
    @property([SpriteFrame])
    public select_frame: SpriteFrame[] = [];
    @property({ tooltip: "previous player flag", type: Node })
    public lastFlagNode: Node = null;
    @property({ tooltip: "next player flag", type: Node })
    public nextFlagNode: Node = null;
    @property({ tooltip: "small desk node", type: Node })
    public deskNode: Node = null;
    @property({ tooltip: "small desk player image", type: [SpriteFrame] })
    public deskPlayerImags: [
        SpriteFrame
    ] = [];
    @property({ tooltip: "jipaiqi di image", type: [SpriteFrame] })
    public jpqDiImags: [
        SpriteFrame
    ] = [];
    public selectCard: any = null;
    public _firstCardNode: any = null;
    public vecMobans: any[] = [];
    public _rummyCardText: any[] = [];
    public _callback: any = null;
    public cardScale: any = v3(0.3, 0.3, 0.3);
    public _showPos: any = v3(0, 0);
    public _curSelectPlayer: any = -1;
    public _tempcurSelectPlayer: any = -1;
    public _opencardSeatidArr: any[] = [];
    public playerPostions: any[] = [];
    onLoad() {
        this.bIsInGame = true;
        this.fitScreen();
        for (let e = 0; e < 13; e++) {
            this.vecMobans[e] = instantiate(this.mobanView);
            this.rootNode.getChildByName("below").addChild(this.vecMobans[e]);
            this.vecMobans[e].active = false;
            this.vecMobans[e].setPosition(v3(52 * e - 290.5, 424.6));
        }
        this._rummyCardText = ["A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"];
        this.playerPostions = [];
        for (let e = 0; e < 6; e++) {
            let t = "player" + e;
            const i = this.deskNode.getChildByName(t);
            i && (this.playerPostions[e] = i.getPosition());
        }
        PushCenter.shared().addListener(PushEvent.UpdateOpenCardDeskImage, (e => {
            ToolUtils.isObjValid(this.node) && this.refreshDeskImage();
        }), this);
    }
    start() {
        super.start();
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().removeListenersByTag(this);
    }
    fitScreen() {
        let e = ToolUtils.getFitBottomHeightDiff();
        e > 0 && (this._showPos.y += e);
        ToolUtils.isPadPlatform() && (this._showPos.y = this._showPos.y + (GameConfig.REAL_SCREEN_WIDTH - GameConfig.CONFIG_SCREEN_WIDTH) / 2);
    }
    startShowAnim() {
        this.rootNode.setPosition(v3(this._showPos.x, this._showPos.y + 300, 0));
        TweenTool.moveTo(this.rootNode, 0.2, this._showPos, "fade", true, (() => {
            this.rootNode.setPosition(this._showPos);
        }));
        this.refreshPokerListViewSize();
    }
    setCloseCallBack(e) {
        this._callback = e;
    }
    onClickClose(e, t = "") {
        "close" == t && SoundManager.shared().playFx("click");
        let i = new Vec3;
        this.rootNode.getPosition(i);
        let s = this;
        TweenTool.moveTo(this.rootNode, 0.15, v3(i.x, i.y + 300, i.z), null, true, (() => {
            s._callback && s._callback();
            s.removeGamePopNode();
            s.node.active = false;
        }));
    }
    onClickPlayer(e, t) {
        let i, s, r, o, a;
        SoundManager.shared().playFx("click");
        this._curSelectPlayer = parseInt("" + t);
        this._tempcurSelectPlayer = this._curSelectPlayer;
        for (let e = 0; e < 6; e++) {
            i = "btn_player" + e;
            s = "tx_nick" + e;
            r = this.rootNode.getChildByName("top").getChildByName(i);
            o = this.rootNode.getChildByName("top").getChildByName(s);
            a = r.getComponent(Button);
            this._curSelectPlayer == e ? (a.enabled = false, r.getComponent(Sprite).spriteFrame = this.select_frame[0], o.getComponent(Label).color = color(111, 0, 0)) : (a.enabled = true, r.getComponent(Sprite).spriteFrame = this.select_frame[1], o.getComponent(Label).color = color(0, 0, 0));
        }
        this.refreshCardList(this._tempcurSelectPlayer);
        this.showPlayerSelectImage(true);
    }
    onClickArrow(e, t = "") {
        SoundManager.shared().playFx("click");
        let i = 1;
        "left" == t && (i = 0.5, 1 == RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyMode && (i = 0));
        this.rootNode.getChildByName("below").getChildByName("pokerListView").getComponent(ScrollView).scrollToPercentHorizontal(i, 0.1, true);
    }
    removeListView() {
        this.initCardList([]);
    }
    showXiajiaPosition() {
        this._tempcurSelectPlayer = RummyDataManager.shared().rummyInfos.get(this.tid_key).opencardXiajiaIndex;
        this._curSelectPlayer = this._tempcurSelectPlayer;
    }
    updateInfo(e, t) {
        this.refreshPlayerInfo();
        this.initCardList(e);
        this.refreshCardList(this._tempcurSelectPlayer);
        this.refreshBelowInfo(e.cards_mark, t, e.dc_card, e.mark_idx);
        this.showPlayerSelectImage(false);
    }
    refreshDeskImage() {
        let e = this.deskNode.getChildByName("desk_ic");
        RummyDataManager.shared().openCardInfos.has(this.tid_key) && RummyDataManager.shared().openCardInfos.get(this.tid_key).spriteFrame && (e.getComponent(Sprite).spriteFrame = RummyDataManager.shared().openCardInfos.get(this.tid_key).spriteFrame);
    }
    changePlayerVisible(e, t, i) {
        let s = "player" + e;
        const r = t.getChildByName(s);
        ToolUtils.isObjValid(r) && (r.active = i);
    }
    changeJpqDiImage() {
        let e = this.rootNode.getChildByName("bg");
        1 == RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyMode ? (e.getComponent(Sprite).spriteFrame = this.jpqDiImags[1], this.closeNode.setPosition(new Vec3(306.756, 108))) : (e.getComponent(Sprite).spriteFrame = this.jpqDiImags[0], this.closeNode.setPosition(new Vec3(306.756, 74.5)));
    }
    refreshOpenCardPlayerPostion() {
        if (2 == RummyDataManager.shared().rummyInfos.get(this.tid_key).pnum) {
            for (let e = 0; e <= 5; e++) {
                e <= 1 ? this.changePlayerVisible(e, this.deskNode, true) : this.changePlayerVisible(e, this.deskNode, false);
            }
            let e = "player1";
            this.deskNode.getChildByName(e).setPosition(this.playerPostions[3]);
        }
        else if (4 == RummyDataManager.shared().rummyInfos.get(this.tid_key).pnum) {
            for (let e = 0; e <= 5; e++) {
                e <= 3 ? this.changePlayerVisible(e, this.deskNode, true) : this.changePlayerVisible(e, this.deskNode, false);
            }
            this.deskNode.getChildByName("player2").setPosition(this.playerPostions[3]);
            this.deskNode.getChildByName("player3").setPosition(this.playerPostions[5]);
        }
        else {
            for (let e = 0; e <= 5; e++) {
                this.changePlayerVisible(e, this.deskNode, true);
            }
            let e = "player1";
            this.deskNode.getChildByName(e).setPosition(this.playerPostions[1]);
        }
    }
    showPlayerSelectImage(e = false) {
        if (sys.isObjectValid(this._opencardSeatidArr[this._tempcurSelectPlayer] && RummyDataManager.shared().rummyInfos.has(this.tid_key))) {
            let t = this._opencardSeatidArr[this._tempcurSelectPlayer], i = RummyDataManager.shared().getPosBySeatid(t, this.tid_key);
            for (let e = 0; e < 6; e++) {
                let t = "player" + e, s = this.deskNode.getChildByName(t);
                if (s) {
                    if (i == e) {
                        s.getComponent(Sprite).spriteFrame = this.deskPlayerImags[1];
                    }
                    else {
                        let t = RummyDataManager.shared().getSeatidByPos(e, this.tid_key), i = RummyDataManager.shared().rummyInfos.get(this.tid_key).playerModels[t];
                        sys.isObjectValid(i) ? null == i.status || 1 == i.status || 2 == i.status || 3 == i.status || 5 == i.status || 9 == i.status || 0 == i.betting || 0 == i.isShow ? s.getComponent(Sprite).spriteFrame = this.deskPlayerImags[2] : s.getComponent(Sprite).spriteFrame = this.deskPlayerImags[0] : s.getComponent(Sprite).spriteFrame = this.deskPlayerImags[2];
                    }
                }
            }
            if (e) {
                let e = "player" + i, t = this.deskNode.getChildByName(e);
                if (t) {
                    let e = TweenTool.scaleTo(t, 0.2, new Vec3(1.2, 1.2), "linear", false), i = TweenTool.scaleTo(t, 0.2, new Vec3(1, 1), "linear", false);
                    TweenTool.sequence(t, true, (() => {
                        t.scale = new Vec3(1, 1);
                    }), e, i);
                }
            }
        }
    }
    refreshOpenCardPlayer() {
        this._curSelectPlayer >= RummyDataManager.shared().rummyInfos.get(this.tid_key).playerGiveCards.length && (this._curSelectPlayer = RummyDataManager.shared().rummyInfos.get(this.tid_key).opencardXiajiaIndex, this._tempcurSelectPlayer = this._curSelectPlayer);
        this.refreshPlayerInfo();
        this.refreshCardList(this._tempcurSelectPlayer);
        this.showPlayerSelectImage(false);
    }
    showLastNextPlayerFlag(e) {
        let t = false, i = false, s = 0;
        if (Array.isArray(e) && e.length > 0) {
            let r = RummyDataManager.shared().rummyInfos.get(this.tid_key), o = r.playerModels, a = [];
            for (let t = 0, l = e.length; t < l; t++) {
                sys.isObjectValid(e[t]) && 1 != o[e[t].seatid].status && 9 != o[e[t].seatid].status && (s += 1, a.push(e[t]), e[t].seatid == r.clientSeatId && (i = true));
            }
            let l = -1;
            if (s >= 2 && i) {
                if (s >= 3 && (t = true), a.length > 0) {
                    for (let e = 0; e < a.length; e++) {
                        if (a[e].seatid == r.clientSeatId) {
                            l = e;
                            break;
                        }
                    }
                    if (-1 != l && 1 != l) {
                        if (2 == s) {
                            [a[l], a[1]] = [a[1], a[l]];
                        }
                        else {
                            let e = a[l], t = a[a.length - 1];
                            a.splice(l, 1);
                            a.splice(a.length - 1, 1);
                            a.splice(0, 0, t);
                            a.splice(1, 0, e);
                        }
                    }
                }
                e = a;
            }
            s >= 1 && (-1 == this._tempcurSelectPlayer || -1 == this._curSelectPlayer || this._tempcurSelectPlayer >= s || this._curSelectPlayer >= s) && (s >= 3 ? (this._tempcurSelectPlayer = 2, this._curSelectPlayer = 2) : (this._tempcurSelectPlayer = 0, this._curSelectPlayer = 0));
        }
        return this.lastFlagNode.active = t, this.nextFlagNode.active = t, this.lastFlagNode.active = false, this.nextFlagNode.active = false, e;
    }
    refreshPlayerInfo() {
        let e = RummyDataManager.shared().rummyInfos.get(this.tid_key).playerGiveCards;
        e = this.showLastNextPlayerFlag(e);
        let t, i, s, r, o, a = 0, l = this.rootNode.getChildByName("top").getChildByName("img_banker"), n = RummyDataManager.shared().rummyInfos.get(this.tid_key).playerModels;
        l.active = false;
        this._opencardSeatidArr = [];
        for (let l = 0; l < 6; l++) {
            if (t = "btn_player" + l, i = "tx_nick" + l, s = this.rootNode.getChildByName("top").getChildByName(t), r = this.rootNode.getChildByName("top").getChildByName(i), o = true, sys.isObjectValid(e[l]) && (1 != n[e[l].seatid].status && 9 != n[e[l].seatid].status || (o = false)), Array.isArray(e) && e.length > l && o) {
                let t = 120 * a - 300;
                s.active = true;
                r.active = true;
                let i = new Vec3;
                s.getPosition(i);
                s.setPosition(v3(t, i.y, i.z));
                let o = new Vec3;
                r.getPosition(o);
                r.setPosition(v3(t, o.y, o.z));
                let n = ToolUtils.GetShortName2(e[l].name, 8, true);
                Utils.shared().setStr(r, n);
                r.getComponent(Label).string = r.getComponent(Label).string.length > 8 ? ToolUtils.GetShortName2(r.getComponent(Label).string, 8, true) : r.getComponent(Label).string;
                let d = s.getComponent(Button);
                this._tempcurSelectPlayer == l ? (d.enabled = false, s.getComponent(Sprite).spriteFrame = this.select_frame[0], r.getComponent(Label).color = color(111, 0, 0)) : (d.enabled = true, s.getComponent(Sprite).spriteFrame = this.select_frame[1], r.getComponent(Label).color = color(0, 0, 0));
                a += 1;
                this._opencardSeatidArr.push(e[l].seatid);
            }
            else {
                s.active = false;
                r.active = false;
            }
        }
    }
    isShowLaiziColor(e) {
        if (78 == RummyDataManager.shared().rummyInfos.get(this.tid_key).laizicard || 79 == RummyDataManager.shared().rummyInfos.get(this.tid_key).laizicard) {
            if (78 == e || 79 == e || 1 == e || 17 == e || 33 == e || 49 == e) {
                return true;
            }
        }
        else {
            if (78 == e || 79 == e) {
                return true;
            }
            if (RummyDataManager.shared().rummyInfos.get(this.tid_key).laizicard % 16 == e % 16) {
                return true;
            }
        }
        return false;
    }
    initCardList(e = []) {
        if (1 == RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyMode) {
            return this.rootNode.getChildByName("below").getChildByName("selectcard").active = false, void (this.rootNode.getChildByName("below").getChildByName("cardframe").active = false);
        }
        if (e.first_card) {
            if (0 != e.first_card) {
                let t = RummyDataManager.shared().rummyInfos.get(this.tid_key).is_bump;
                if (null == this._firstCardNode) {
                    let i = this.rootNode.getChildByName("below").getChildByName("selectcard");
                    this._firstCardNode = instantiate(this.cardPrefab);
                    let s = this._firstCardNode.getComponent("RummyCard");
                    s.init(e.first_card, false);
                    s.openCard();
                    1 == t ? s.showLaiziFlag(this.isShowLaiziColor(e.first_card), false, true) : s.showLaiziFlag(this.isShowLaiziColor(e.first_card));
                    this._firstCardNode.setScale(this.cardScale);
                    this._firstCardNode.setPosition(i.getPosition());
                    this.rootNode.getChildByName("below").addChild(this._firstCardNode);
                }
                else {
                    let i = this._firstCardNode.getComponent("RummyCard");
                    i.setCardValue(e.first_card);
                    i.openCard();
                    1 == t ? i.showLaiziFlag(this.isShowLaiziColor(e.first_card), false, true) : i.showLaiziFlag(this.isShowLaiziColor(e.first_card));
                }
                if (this._firstCardNode.active = true, null != e.comcard_iscatch) {
                    this._firstCardNode.getComponent("RummyCard").setMask(1 == e.comcard_iscatch);
                }
            }
        }
        else {
            this._firstCardNode && (this._firstCardNode.active = false);
        }
    }
    refreshPokerListViewSize() {
        let e = this.rootNode.getChildByName("below").getChildByName("pokerListView"), t = e.getChildByName("view").getChildByName("content"), i = this.rootNode.getChildByName("below").getChildByName("btn_left");
        1 == RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyMode && (e.setPosition(new Vec3(57, 540)), e.getComponent(UITransform).setContentSize(new Size(540, 80)), t.setPosition(new Vec3(-264, 0)), i.setPosition(new Vec3(-226, 538)));
    }
    refreshCardList(e) {
        let t = RummyDataManager.shared().rummyInfos.get(this.tid_key).playerGiveCards;
        if (null == t[e]) {
            return void this.rootNode.getChildByName("below").getChildByName("pokerListView").getComponent(ScrollView).content.destroyAllChildren();
        }
        let i, s, r = t[e].cards, o = this.rootNode.getChildByName("below").getChildByName("pokerListView"), a = o.getChildByName("view").getChildByName("content");
        a.destroyAllChildren();
        let l = RummyDataManager.shared().rummyInfos.get(this.tid_key).is_bump;
        for (let e = 0, t = r.length; e < t; e++) {
            if (78 != r[e].value && 79 != r[e].value) {
                i = instantiate(this.cardPrefab);
                s = i.getComponent("RummyCard");
                s.init(r[e].value, false);
                s.openCard();
                1 == l ? s.showLaiziFlag(this.isShowLaiziColor(r[e].value), false, true) : s.showLaiziFlag(this.isShowLaiziColor(r[e].value));
                s.setMask(1 == r[e].is_catch);
                i.setScale(this.cardScale);
                let t = i.getComponent(UITransform).contentSize;
                i.getComponent(UITransform).setContentSize(size(t.width * this.cardScale.x, t.height * this.cardScale.y));
                a.addChild(i);
            }
        }
        let n = o.getComponent(ScrollView);
        r.length > 10 && n.scrollToRight(0);
    }
    refreshBelowInfo(e = [], t, i, s) {
        let r, o, a, l, n, h, d, c, m;
        for (let y = 0; y < 13; y++) {
            if (this.vecMobans.length > y && ToolUtils.isObjValid(this.vecMobans[y])) {
                this.vecMobans[y].active = true;
                for (let u = 0; u < 4; u++) {
                    r = false;
                    o = false;
                    a = 0;
                    l = 0;
                    n = 0;
                    h = 0;
                    for (let t = 0, i = e.length; t < i; t++) {
                        78 != e[t].c && 79 != e[t].c && e[t].c % 16 == y + 1 && Math.floor(e[t].c / 16) == u && (r && (o = true, l = e[t].c, h = e[t].m), r || (r = true, a = e[t].c, n = e[t].m));
                    }
                    for (let e = 0; e < 2; e++) {
                        d = this.vecMobans[y].getChildByName(ToolUtils.format("card${0}_${1}", u, e));
                        d && (c = d.getChildByName("bg"), c.active = false, m = d.getChildByName("txt"), Utils.shared().setStr(m, this._rummyCardText[y]), 0 == e ? (m.getComponent(Label).color = 1 == n ? color(160, 160, 160) : color(206, 18, 18), d.active = r, !r || o && 1 != s || 1 == t && i == a && (c.active = true, m.getComponent(Label).color = color(255, 255, 255))) : (m.getComponent(Label).color = 1 == h ? color(160, 160, 160) : color(206, 18, 18), d.active = o, o && 1 != s && 1 == t && i == l && (c.active = true, m.getComponent(Label).color = color(255, 255, 255))));
                    }
                }
            }
        }
    }
    setLandscapeShow() {
        ToolUtils.getOrientation() || this.node.setRotationFromEuler(v3(0, 0, -90));
    }
    pushGamePopNode() {
        if (!this.node.active) {
            let e = { node: this.node, tid_key: this.tid_key };
            PushCenter.shared().pushEvent(PushEvent.pushGamePopNode, e);
        }
    }
    removeGamePopNode() {
        if (this.node.active) {
            let e = { node: this.node, tid_key: this.tid_key };
            PushCenter.shared().pushEvent(PushEvent.removeGamePopNode, e);
        }
    }
    onBackView() {
    }
}
