// @ts-nocheck
// Recovered from index.js:33
import { _decorator, Label, Node, size, Sprite, SpriteFrame, sys, tween, UIOpacity, Vec3 } from "cc";
import BaseLayer from "./BaseLayer";
import PushCenter from "./PushCenter";
import PushEvent from "./PushEvent";
import Utils from "./Utils";
import TweenTool from "./TweenTool";
import { TLog } from "./TLog";
import User from "./User";
import HttpManager from "./HttpManager";
import i18nMgr from "./i18nMgr";
import { HttpRequest } from "./HttpRequestName";
import RummyDataManager from "./RummyDataManager";
import { ToolUtils } from "./ToolUtils";
import NetConfig from "./NetConfig";
import Server from "./Server";
import SoundManager from "./SoundManager";
const { ccclass, property } = _decorator;
@ccclass("BeginnerFlipTaskActInGame")
export class BeginnerFlipTaskActInGame extends BaseLayer {
    public TAG: string = "BeginnerFlipTaskActInGame";
    @property(Node)
    public root: Node = null;
    @property(Node)
    public itemRoot: Node = null;
    @property([SpriteFrame])
    public bgImgs: SpriteFrame[] = [];
    public has_reportUI: boolean = false;
    public _lastClick: number = 0;
    public _initDelay: number = 0;
    public taskAwardIconMap: Map = new Map;
    @property([SpriteFrame])
    public taskIcons_cb: SpriteFrame[] = [];
    public _has_close: boolean = false;
    public _sourceData: any = null;
    public _time_count: number = 0;
    public _canGetReward: boolean = true;
    public _vid: string = "";
    public hasPlayAnim: boolean = false;
    public _tid_key: string = "";
    public _hasShowReward: boolean = false;
    public _hasGetReward: boolean = false;
    onLoad() {
        PushCenter.shared().addListener(PushEvent.commentDownloaderImg, (e => {
            if (sys.isObjectValid(this.node) && this.taskAwardIconMap.size > 0) {
                for (const [t, a] of this.taskAwardIconMap) {
                    a == e && Utils.shared().updateNetImage(t, e, size(158, 158));
                }
            }
        }), this);
    }
    start() {
        super.start();
        ToolUtils.showFullScreen(this.node.getChildByName("mask"));
        this.initView();
        TweenTool.delayAct(this.node, (() => {
            sys.isObjectValid(this._sourceData) && this.refreshView();
        }), this._initDelay, true);
        SoundManager.shared().playFx("act_popshow");
    }
    initView() {
        for (let e = 0; e < 5; e++) {
            let t = this.itemRoot.getChildByName("moban" + e);
            sys.isObjectValid(t) && (t.getComponent(UIOpacity).opacity = 0, t.getChildByName("bg").getComponent(Sprite).spriteFrame = this.bgImgs[0], t.getChildByName("icon").active = false, t.getChildByName("reward_node").active = false, t.getChildByName("total").active = false, t.getChildByName("effect").active = false, t.getChildByName("mask").active = false);
        }
        this.taskAwardIconMap.clear();
    }
    refreshView() {
        if (sys.isObjectValid(this._sourceData) && (this.initView(), this._time_count = 6, TweenTool.stopNodeAction(this.node), this.updateTime(), TweenTool.myschedule(this.node, 1, (() => {
            ToolUtils.isObjValid(this.node) && this.updateTime();
        })), !this.hasPlayAnim)) {
            this.hasPlayAnim = true;
            for (let e = 0; e < 5; e++) {
                let t = this.itemRoot.getChildByName("moban" + e), a = t.getComponent(UIOpacity);
                t.setScale(new Vec3(0.5, 0.5, 0.5));
                a.opacity = 0;
                tween(t).delay(0.08 * e).to(0.1, { scale: new Vec3(1.1, 1.1, 1.1) }, { onUpdate: (e, t) => {
                        a.opacity = 255 * t;
                    } }).to(0.1, { scale: new Vec3(1, 1, 1) }).call((() => {
                    t.scale = new Vec3(1, 1, 1);
                    a.opacity = 255;
                })).start();
            }
        }
    }
    updateTime() {
        if (this._time_count > 1) {
            this._time_count = this._time_count - 1;
            this.root.getChildByName("tip").getComponent(Label).string = ToolUtils.format(i18nMgr.shared().getValueByKey("flop_cash.choose_count"), this._time_count);
        }
        else {
            if (TweenTool.stopNodeAction(this.node), !this._canGetReward) {
                return;
            }
            this._canGetReward = false;
            let e = Math.floor(5 * Math.random());
            this.dealGetRewardLogic(e);
        }
    }
    initItemView(e, t) {
        if (sys.isObjectValid(e) && sys.isObjectValid(t)) {
            e.active = true;
            e.getChildByName("bg").getComponent(Sprite).spriteFrame = this.bgImgs[1];
            sys.isObjectValid(t.is_get) && (0 == t.is_get ? (e.getChildByName("mask").active = true, e.getChildByName("effect").active = false) : (e.getChildByName("mask").active = false, e.getChildByName("effect").active = true));
            let a = 0, i = -1;
            e.getChildByName("reward_node").active = true;
            sys.isObjectValid(t.cash) && t.cash > 0 ? (e.getChildByName("reward_node").getChildByName("cash_diban").active = true, e.getChildByName("reward_node").getChildByName("cash_diban").getChildByName("wz").getComponent(Label).string = String(t.cash), a = t.cash, i = 0) : e.getChildByName("reward_node").getChildByName("cash_diban").active = false;
            sys.isObjectValid(t.bonus) && t.bonus > 0 ? (e.getChildByName("reward_node").getChildByName("bonus_diban").active = true, e.getChildByName("reward_node").getChildByName("bonus_diban").getChildByName("wz").getComponent(Label).string = String(t.bonus), a += t.bonus, i = 0 == i ? 2 : 1) : e.getChildByName("reward_node").getChildByName("bonus_diban").active = false;
            sys.isObjectValid(t.icon_id) && (e.getChildByName("icon").active = true, 0 == i && t.icon_id >= 1 && t.icon_id <= 9 ? e.getChildByName("icon").getComponent(Sprite).spriteFrame = this.taskIcons_cb[0] : 1 == i && t.icon_id >= 1 && t.icon_id <= 6 ? e.getChildByName("icon").getComponent(Sprite).spriteFrame = this.taskIcons_cb[1] : 2 == i && t.icon_id >= 1 && t.icon_id <= 6 && (e.getChildByName("icon").getComponent(Sprite).spriteFrame = this.taskIcons_cb[2]));
            e.getChildByName("total").active = true;
            e.getChildByName("total").getComponent(Label).string = ToolUtils.format(i18nMgr.shared().getValueByKey("flip_act.total_get"), Number(a.toFixed(2)));
        }
    }
    initParaData(e) {
        sys.isObjectValid(e) && sys.isObjectValid(e.source) && (this._sourceData = e.source);
        sys.isObjectValid(e) && sys.isObjectValid(e.vid) && (this._vid = e.vid);
        sys.isObjectValid(e) && sys.isObjectValid(e.tid_key) && (this._tid_key = e.tid_key);
    }
    onClickItemEvent(e, t) {
        if (ToolUtils.isObjValid(this.node)) {
            if (sys.now() - this._lastClick < 500) {
                return;
            }
            this._lastClick = sys.now();
        }
        if (!this._canGetReward) {
            return;
        }
        this._canGetReward = false;
        let a = Number(t);
        this.dealGetRewardLogic(a);
    }
    onClickEvent(e, t) {
        if (ToolUtils.isObjValid(this.node)) {
            TweenTool.stopNodeAction(this.node);
            Utils.shared().hideLoading();
            let e = { task_id: this._sourceData.task_id, select_index: Math.floor(5 * Math.random()), vid: this._vid, tid_key: this._tid_key };
            this._hasGetReward || User.shared().requestGetFlopReward(e);
            this.reportSever();
            this.reportPushEvent();
            this.onBackView();
        }
    }
    reportPushEvent() {
        sys.isObjectValid(this._sourceData) && sys.isObjectValid(this._sourceData.tid_key) && (sys.isObjectValid(User.shared().clubUpgradeMsg) ? User.shared().clubUpgradeMsg.flop_tidkey = this._sourceData.tid_key : PushCenter.shared().pushEvent(PushEvent.NoticeFinishFlopStart, this._sourceData.tid_key));
        sys.isObjectValid(this._sourceData) && sys.isObjectValid(this._sourceData.tid_key) && (sys.isObjectValid(User.shared().clubUpgradeMsg) ? User.shared().clubUpgradeMsg.flop_tidkey = this._sourceData.tid_key : PushCenter.shared().pushEvent(PushEvent.NoticeFinishFlop, this._sourceData.tid_key));
    }
    reportSever() {
        if (sys.isObjectValid(User.shared().clubUpgradeMsg)) {
            return;
        }
        let e = { cmd: NetConfig.CLIENT_NOTIFY_GOBACK_GAME, uid: User.shared().data.uid, type: 2, tid_key: User.shared().curTid_key };
        Server.shared().send(e);
    }
    dealGetRewardLogic(e) {
        TweenTool.stopNodeAction(this.node);
        Utils.shared().showLoading(10, true, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
        }));
        let t = this._sourceData.task_id;
        HttpManager.shared().doGetCommonRequest({ task_id: t, select_index: e + 1, vid: this._vid, tid_key: this._tid_key }, HttpRequest.FlopCashTaskGetReward, ((t, a, i) => {
            if (ToolUtils.isObjValid(this.node)) {
                if (Utils.shared().hideLoading(), 200 != i) {
                    0 == sys.getNetworkType() ? Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text91"), 3, 0, ToolUtils.getIsNormalDirection()) : Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
                }
                else {
                    try {
                        let t = ToolUtils.parseJson(a);
                        if (0 == t.ret) {
                            this._hasGetReward = true;
                            let a = ToolUtils.format(i18nMgr.shared().getValueByKey("flop_cash.reward_tip"), t.data.next_play_num);
                            0 == t.data.next_play_num && (a = i18nMgr.shared().getValueByKey("flop_cash.cmp_tip"));
                            this.root.getChildByName("tip").getComponent(Label).string = a;
                            let i = null;
                            if (sys.isObjectValid(t.data.reward_data) && Array.isArray(t.data.reward_data) && t.data.reward_data.length > 0) {
                                for (let e = 0; e < t.data.reward_data.length; e++) {
                                    if (1 == t.data.reward_data[e].is_get) {
                                        i = t.data.reward_data[e];
                                        break;
                                    }
                                }
                            }
                            i && this.openTargetItem(e, i);
                            let s = [0, 1, 2, 3, 4].filter((t => t !== e)), d = 0;
                            TweenTool.delayAct(this.node, (() => {
                                if (sys.isObjectValid(t.data.reward_data) && Array.isArray(t.data.reward_data) && t.data.reward_data.length > 0) {
                                    for (let e = 0; e < t.data.reward_data.length; e++) {
                                        1 != t.data.reward_data[e].is_get && (this.openTargetItem(s[d], t.data.reward_data[e]), d += 1);
                                    }
                                }
                            }), 1, true);
                            TweenTool.delayAct(this.node, (() => {
                                let e = ToolUtils.format(i18nMgr.shared().getValueByKey("flop_cash.reward_tip1"), t.data.next_play_num);
                                0 == t.data.next_play_num && (e = i18nMgr.shared().getValueByKey("flop_cash.cmp_tip"));
                                this._hasShowReward = true;
                                this.showRewards(t.data.reward_list, e, t.data.task_data);
                            }), 2, true);
                            try {
                                ToolUtils.judgeIfInRummy() && (sys.isObjectValid(RummyDataManager.shared().rummyInfos.get(this._tid_key).flopCashTaskLaba) && (RummyDataManager.shared().rummyInfos.get(this._tid_key).flopCashTaskLaba = null), sys.isObjectValid(RummyDataManager.shared().rummyInfos.get(this._tid_key).flopTempTaskInfo) && (RummyDataManager.shared().rummyInfos.get(this._tid_key).flopTempTaskInfo = null));
                                sys.isObjectValid(t.data.task_data) && PushCenter.shared().pushEvent(PushEvent.UpdateRoomFlopCrashTaskProgess, t.data.task_data);
                            }
                            catch (e) {
                                TLog.printError(e);
                            }
                        }
                    }
                    catch (e) {
                        TLog.printError(this.TAG, "_dealGetRewardLogic  error:", e);
                    }
                }
            }
        }));
    }
    openTargetItem(e, t) {
        if (sys.isObjectValid(t)) {
            let a = this.itemRoot.getChildByName("moban" + e);
            sys.isObjectValid(a) && tween(a).to(0.2, { scale: new Vec3(0, 1, 1) }, { easing: "quadIn" }).call((() => {
                this.initItemView(a, t);
            })).to(0.2, { scale: new Vec3(1, 1, 1) }, { easing: "quadOut" }).start();
        }
    }
    showRewards(e, t = "", a) {
        let i = e;
        if (i && i.length > 0) {
            let e = null;
            sys.isObjectValid(t) && ToolUtils.isSafeString(t).length > 0 && (e = ToolUtils.isSafeString(t));
            this.node.active = false;
            User.shared().showChargeReward(i, (e => {
                1 == e ? (this.onBackView(), sys.isObjectValid(this._sourceData) && sys.isObjectValid(this._sourceData.tid_key) && (sys.isObjectValid(User.shared().clubUpgradeMsg) ? User.shared().clubUpgradeMsg.flop_tidkey = this._sourceData.tid_key : PushCenter.shared().pushEvent(PushEvent.NoticeFinishFlopStart, this._sourceData.tid_key))) : 3 == e && this.onBackView();
                sys.isObjectValid(this._sourceData) && sys.isObjectValid(this._sourceData.tid_key) && (sys.isObjectValid(User.shared().clubUpgradeMsg) ? User.shared().clubUpgradeMsg.flop_tidkey = this._sourceData.tid_key : PushCenter.shared().pushEvent(PushEvent.NoticeFinishFlop, this._sourceData.tid_key));
            }), e, 9);
        }
    }
    onBackView() {
        if (ToolUtils.flopActInGameData = null, ToolUtils.isObjValid(this.node) && this.node.destroy(), sys.isObjectValid(User.shared().clubUpgradeMsg)) {
            let e = { exe: {} };
            e.type = PushEvent.Custom_TO_MemberShipUpgrade;
            e.exe.ext = User.shared().clubUpgradeMsg;
            Utils.shared().doJumpLogic(PushEvent.Custom_TO_MemberShipUpgrade, e);
        }
    }
    onDestroy() {
        super.onDestroy();
        TweenTool.stopNodeAction(this.node);
        this.unscheduleAllCallbacks();
        PushCenter.shared().removeListenersByTag(this);
    }
}
