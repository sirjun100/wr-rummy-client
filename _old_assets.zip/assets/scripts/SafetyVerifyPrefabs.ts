// @ts-nocheck
// Recovered from index.js:497
import { _decorator, Button, EditBox, Label, LabelShadow, Node, sp, Sprite, SpriteFrame } from "cc";
import BaseLayer from "./BaseLayer";
import i18nMgr from "./i18nMgr";
import Utils from "./Utils";
import User from "./User";
import SoundManager from "./SoundManager";
import HttpManager from "./HttpManager";
import CommDefine from "./CommDefine";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("SafetyVerifyPrefabs")
export class SafetyVerifyPrefabs extends BaseLayer {
    @property(Node)
    public verify_node: Node = null;
    @property(Label)
    public telLabel: Label = null;
    @property(Label)
    public emailLabel: Label = null;
    @property(Node)
    public code_node: Node = null;
    @property(Node)
    public code_btnNode: Node = null;
    @property(Label)
    public codeLabel: Label = null;
    @property(Button)
    public submitBtn: Button = null;
    @property(EditBox)
    public otp_tf: EditBox = null;
    @property(Node)
    public btn_del_otp: Node = null;
    @property(Label)
    public tipLabel: Label = null;
    @property(sp.Skeleton)
    public kyc_logo_anim: any = null;
    @property([SpriteFrame])
    public buttonSpriteFrames: SpriteFrame[] = [];
    public _cb: any = null;
    public state: number = 0;
    start() {
        super.start();
        this.telLabel.string = "+91 " + User.shared().data.tel_no;
        this.emailLabel.string = User.shared().data.email;
        this.state = 0;
        this.refreshUI(this.state);
        ToolUtils.adaptSafeArea(this.node.getChildByName("bgView"));
        this.submitBtn && this.setUiEdgeDistance(this.submitBtn.node, 68, 3, false);
    }
    setCloseCallBack(e) {
        this._cb = e;
    }
    refreshUI(e) {
        if (0 === e) {
            this.verify_node.active = true;
            this.code_node.active = false;
            this.submitBtn.node.active = false;
            this.verify_node.getChildByName("email_verify").active = User.shared().data.email.length > 0;
        }
        else if (1 === e) {
            this.code_node.active = true;
            this.verify_node.active = false;
            this.submitBtn.node.active = true;
            this.otp_tf.string = "";
            this.otp_tf.focus();
            this.updateOtpClearStatus();
            User.shared().data.tel_no.length;
            let e = "+91 " + User.shared().data.tel_no;
            this.tipLabel.string = i18nMgr.shared().getValueByKey("settings.otp_has_sent") + e;
        }
        else if (2 === e) {
            this.code_node.active = true;
            this.verify_node.active = false;
            this.submitBtn.node.active = true;
            this.otp_tf.string = "";
            this.otp_tf.focus();
            this.updateOtpClearStatus();
            let e = Utils.emailFormat(User.shared().data.email);
            this.tipLabel.string = i18nMgr.shared().getValueByKey("settings.otp_has_sent2") + e;
        }
    }
    onCodeTextChanged(e, t, i) {
        this.updateOtpClearStatus();
    }
    onCodeTextEnd(e, t, i) {
        this.updateOtpClearStatus();
    }
    listenGetCodeCall(e, t, i) {
        if (Utils.shared().hideLoading(), 200 !== i) {
            ;
        }
        else {
            let e = ToolUtils.parseJson(t);
            if (0 === e.ret) {
                let t = e.data.timeout;
                User.shared().code_timeout = t;
                Utils.shared().showToast(i18nMgr.shared().getValueByKey("bind_mobile.verification_tips"), 2);
                this.unschedule(this.refreshCodeBtn);
                this.refreshCodeBtn();
                this.schedule(this.refreshCodeBtn, 1);
            }
            else {
                if (e.desc && ToolUtils.isSafeString(e.desc).length > 0) {
                    let t = ToolUtils.isSafeString(e.desc);
                    Utils.shared().showToast(t, 2);
                }
                let t = e.data.timeout;
                t && ToolUtils.isSafeNumber(t) > 0 && (User.shared().code_timeout = t, this.unschedule(this.refreshCodeBtn), this.refreshCodeBtn(), this.schedule(this.refreshCodeBtn, 1));
            }
        }
    }
    listenVerifyCodeCall(e, t, i) {
        if (Utils.shared().hideLoading(), 200 !== i) {
            ;
        }
        else {
            let e = ToolUtils.parseJson(t);
            if (0 === e.ret) {
                this.onVerifySuccess();
            }
            else if (e.desc && ToolUtils.isSafeString(e.desc).length > 0) {
                let t = ToolUtils.isSafeString(e.desc);
                Utils.shared().showToast(t, 2);
            }
        }
    }
    refreshCodeBtn() {
        User.shared().code_timeout = User.shared().code_timeout - 1;
        let e = this.code_btnNode.getComponent(Button), t = this.code_btnNode.getComponent(Sprite);
        User.shared().code_timeout <= 0 ? (this.unschedule(this.refreshCodeBtn), e.interactable = true, t.spriteFrame = this.buttonSpriteFrames[0], this.codeLabel.string = "OTP", Utils.updateLabelMaterial(this.codeLabel.node, CommDefine.gradient.btn_green), this.codeLabel.node.getComponent(LabelShadow).color = CommDefine.shadowcolor.green) : (e.interactable = false, t.spriteFrame = this.buttonSpriteFrames[1], Utils.updateLabelMaterial(this.codeLabel.node, CommDefine.gradient.btn_gray), this.codeLabel.node.getComponent(LabelShadow).color = CommDefine.shadowcolor.gray, this.codeLabel.string = `(${User.shared().code_timeout}s)`);
    }
    resethCodeBtn() {
        let e = this.code_btnNode.getComponent(Button), t = this.code_btnNode.getComponent(Sprite);
        this.unschedule(this.refreshCodeBtn);
        e.interactable = true;
        t.spriteFrame = this.buttonSpriteFrames[0];
        this.codeLabel.string = "OTP";
        Utils.updateLabelMaterial(this.codeLabel.node, CommDefine.gradient.btn_green);
        this.codeLabel.node.getComponent(LabelShadow).color = CommDefine.shadowcolor.green;
    }
    updateOtpClearStatus() {
        ToolUtils.isSafeString(this.otp_tf.string).length > 0 ? this.btn_del_otp.active = true : this.btn_del_otp.active = false;
    }
    onButtonClick(e, t) {
        if (SoundManager.shared().playFx("click"), "verifyMobile" === t) {
            this.state = 1;
            this.refreshUI(this.state);
        }
        else if ("verifyEmail" === t) {
            this.state = 2;
            this.refreshUI(this.state);
        }
        else if ("code" === t) {
            if (1 == this.state) {
                let e = User.shared().data.tel_no;
                Utils.shared().showLoading(10, true, (() => {
                    Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text37"), 3);
                }), ToolUtils.getIsNormalDirection());
                HttpManager.shared().doGetMobileCode(e, 12, 1, this.listenGetCodeCall.bind(this));
            }
            else {
                2 == this.state && (Utils.shared().showLoading(10, true, (() => {
                    Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text37"), 3);
                }), ToolUtils.getIsNormalDirection()), HttpManager.shared().doGetEmailCode(User.shared().data.email, 2, this.listenGetCodeCall.bind(this)));
            }
        }
        else if ("submit" === t) {
            let e = ToolUtils.isSafeString(this.otp_tf.string);
            if (0 == e.length) {
                return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("bind_mobile.enter_code_tips"), 2);
            }
            if (e.length < 6) {
                return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text63"), 3);
            }
            1 == this.state ? (Utils.shared().showLoading(10, true, (() => {
                Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text37"), 3);
            }), ToolUtils.getIsNormalDirection()), HttpManager.shared().doVerifyMobileCode(User.shared().data.tel_no, e, this.listenVerifyCodeCall.bind(this))) : 2 == this.state && (Utils.shared().showLoading(10, true, (() => {
                Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text37"), 3);
            }), ToolUtils.getIsNormalDirection()), HttpManager.shared().doVerifyEmailCode(User.shared().data.email, e, this.listenVerifyCodeCall.bind(this)));
        }
        else {
            "clearOTP" === t ? (this.otp_tf.string = "", this.otp_tf.blur(), this.updateOtpClearStatus()) : "close" === t && (0 != this.state ? (this.state = 0, this.refreshUI(this.state)) : this.onBackView());
        }
    }
    onVerifySuccess() {
        this._cb && this._cb(true);
        ToolUtils.isObjValid(this.node) && this.node.destroy();
    }
    onDestroy() {
        super.onDestroy();
        this.unschedule(this.refreshCodeBtn);
    }
    onBackView() {
        this._cb && this._cb();
        ToolUtils.isObjValid(this.node) && this.node.destroy();
    }
}
