// @ts-nocheck
// Recovered from index.js:11
import { _decorator, Node, ProgressBar, Sprite, SpriteFrame, sys, VideoPlayer } from "cc";
import SoundManager from "./SoundManager";
import BaseLayer from "./BaseLayer";
import AppInfo from "./AppInfo";
import PushCenter from "./PushCenter";
import PushEvent from "./PushEvent";
import i18nMgr from "./i18nMgr";
import User from "./User";
import GameConfig from "./GameConfig";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("AdView")
export class AdView extends BaseLayer {
    @property({ type: ProgressBar, displayName: "" })
    public progressBar: ProgressBar = null;
    @property({ type: Node, displayName: "" })
    public videoPlayer: Node = null;
    @property(Sprite)
    public soundSprite: Sprite = null;
    @property([SpriteFrame])
    public soundImages: SpriteFrame[] = [];
    public _video: any = null;
    public _leave_times: number = 0;
    public _has_complete: boolean = false;
    public _isMute: boolean = false;
    public _showAlert: boolean = false;
    public _video_url: any = null;
    public _scene: number = 1;
    public show_ask: number = 1;
    public _skip_url: any = null;
    public link_id: number = 0;
    public has_jump: boolean = false;
    public bg_enable: boolean = false;
    public _volum: number = 0;
    public _hasLoadVedio: boolean = false;
    public isNext: boolean = false;
    start() {
        if (super.start(), this._video = this.videoPlayer.getComponent(VideoPlayer), this._video && this._video.isValid && this._video_url) {
            let e = User.shared().vedioMap.get(this._video_url);
            sys.isObjectValid(e) && e.isValid ? (this._video.resourceType = VideoPlayer.ResourceType.LOCAL, this._video.clip = e) : (this._video.resourceType = VideoPlayer.ResourceType.REMOTE, this._video.remoteURL = this._video_url);
            this._video.play();
            this._video.mute = true;
        }
        this.link_id = sys.now();
        this._volum = AppInfo.shared().getMediaVolum();
        this._isMute = true;
        this.soundSprite.spriteFrame = this.soundImages[1];
        AppInfo.shared().setMediaVolum(0);
        this.bg_enable = SoundManager.shared().bg_enabled;
        SoundManager.shared().setEnabled(false);
        this.initPushCenter();
    }
    initPushCenter() {
        PushCenter.shared().addListener(PushEvent.CancleWatchVideo, (e => {
            ToolUtils.isObjValid(this.node) && (this._showAlert = false, this.closeView());
        }), this);
        PushCenter.shared().addListener(PushEvent.ContinueWatichVideo, (e => {
            ToolUtils.isObjValid(this.node) && (this._showAlert = false, this._has_complete || this._video.play());
        }), this);
        PushCenter.shared().addListener(GameConfig.onEnterForeground, (e => {
            ToolUtils.isObjValid(this.node) && (this._has_complete || this._video.play(), this.has_jump && (this.has_jump = false));
        }), this);
        PushCenter.shared().addListener(PushEvent.DeviceVolumeChanged, (e => {
            ToolUtils.isObjValid(this.node) && (0 == Number(e) ? (this._video.mute = true, this._isMute = true, this.soundSprite.spriteFrame = this.soundImages[1]) : (this._video.mute = false, this._isMute = false, this.soundSprite.spriteFrame = this.soundImages[0]));
        }), this);
        PushCenter.shared().addListener(PushEvent.DownLoadVedio, (e => {
            if (ToolUtils.isObjValid(this.node)) {
                let e = User.shared().vedioMap.get(this._video_url);
                sys.isObjectValid(e) && e.isValid && (this._hasLoadVedio || (this._video.resourceType = VideoPlayer.ResourceType.LOCAL, this._video.clip = e, this._video.play()));
            }
        }), this);
    }
    initParaData(e) {
        sys.isObjectValid(e) && (sys.isObjectValid(e.video_url) && (this._video_url = e.video_url), sys.isObjectValid(e.from_source) && (this._scene = e.from_source), sys.isObjectValid(e.show_ask) && (this.show_ask = e.show_ask), sys.isObjectValid(e.skip_url) && (this._skip_url = e.skip_url), sys.isObjectValid(e.isNext) && (this.isNext = e.isNext));
    }
    update(e) {
        this._video && this._video.isValid && this._video.isPlaying && (this.progressBar.progress = this._video.currentTime / this._video.duration);
    }
    buttonClick(e, i = "") {
        SoundManager.shared().playFx("click");
        "close" == i ? this.onBackView() : "jinyin" == i && (!sys.isNative || sys.os !== sys.OS.ANDROID && sys.os !== sys.OS.OHOS ? this._isMute ? (this._video.mute = false, this._isMute = false, this.soundSprite.spriteFrame = this.soundImages[0]) : (this._video.mute = true, this._isMute = true, this.soundSprite.spriteFrame = this.soundImages[1]) : this._isMute ? (this._video.mute = false, AppInfo.shared().setMediaVolum(this._volum), this._isMute = false, this.soundSprite.spriteFrame = this.soundImages[0]) : (this._video.mute = true, this._isMute = true, AppInfo.shared().setMediaVolum(0), this.soundSprite.spriteFrame = this.soundImages[1]));
    }
    showHalfwayAlert() {
        if (this._showAlert) {
            return;
        }
        this._showAlert = true;
        this._video.pause();
        let e = { message: i18nMgr.shared().getValueByKey("ad_video.tips"), ok_title: i18nMgr.shared().getValueByKey("ad_video.continue"), cancel_title: i18nMgr.shared().getValueByKey("ad_video.leave") };
        AppInfo.shared().showSysAlert(ToolUtils.toJsonString(e));
    }
    playcallback() {
        this._video.state == VideoPlayer.EventType.COMPLETED ? this._has_complete = true : this._video.state == VideoPlayer.EventType.CLICKED ? this._skip_url && (this.has_jump = true, sys.openURL(this._skip_url)) : this._video.state == VideoPlayer.EventType.META_LOADED && (this._hasLoadVedio = true);
    }
    closeView() {
        this.videoPlayer.active = false;
        this._video && this._video.isValid && this._video.destroy();
        ToolUtils.isObjValid(this.node) && (this._has_complete && User.shared().requestActAdVideoReceivReward(this._scene, this.link_id), AppInfo.shared().setMediaVolum(this._volum), this.bg_enable != SoundManager.shared().bg_enabled && SoundManager.shared().setEnabled(this.bg_enable), this.isNext && PushCenter.shared().pushEvent(PushEvent.Update_NextPopActivity), PushCenter.shared().pushEvent(PushEvent.ShowSuperLevelUpAlert), this.node.destroy());
    }
    onBackView() {
        !sys.isNative || sys.os !== sys.OS.ANDROID && sys.os !== sys.OS.OHOS ? this.closeView() : this._showAlert ? this.scheduleOnce((() => {
            ToolUtils.isObjValid(this.node) && (this._showAlert = false);
        }), 3) : (this._has_complete || this._leave_times >= 1 || 0 == this.show_ask ? this.closeView() : this.showHalfwayAlert(), this._leave_times += 1);
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().removeListenersByTag(this);
        this.unscheduleAllCallbacks();
    }
}
