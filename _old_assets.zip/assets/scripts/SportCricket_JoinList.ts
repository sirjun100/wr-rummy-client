// @ts-nocheck
// Recovered from index.js:567
import { _decorator, Button, color, instantiate, Label, Node, size, Sprite, SpriteFrame, sys, UITransform, v3, view } from "cc";
import SoundManager from "./SoundManager";
import PushCenter from "./PushCenter";
import { TLog } from "./TLog";
import Utils from "./Utils";
import BaseLayer from "./BaseLayer";
import i18nMgr from "./i18nMgr";
import PushEvent from "./PushEvent";
import TweenTool from "./TweenTool";
import SportCricket_Manager from "./SportCricket_Manager";
import { ToolUtils } from "./ToolUtils";
import User from "./User";
import GameConfig from "./GameConfig";
import PhpReportDefined from "./PhpReportDefined";
const { ccclass, property } = _decorator;
@ccclass("SportCricket_JoinList")
export class SportCricket_JoinList extends BaseLayer {
    public TAG: string = "SportCricket_JoinList";
    @property(Node)
    public rootNode: Node = null;
    @property(Node)
    public nextNode: Node = null;
    @property(Node)
    public contentNode: Node = null;
    @property([SpriteFrame])
    public teamBgImgs: SpriteFrame[] = [];
    @property([SpriteFrame])
    public capBgImgs: SpriteFrame[] = [];
    @property([SpriteFrame])
    public btnBgImgs: SpriteFrame[] = [];
    @property([SpriteFrame])
    public operateImgs: SpriteFrame[] = [];
    @property([SpriteFrame])
    public checkBtnImgs: SpriteFrame[] = [];
    @property(Node)
    public team_mobanView: Node = null;
    public _closed: boolean = false;
    public bShowPushAnim: boolean = false;
    public _lastClick: number = 0;
    public _sourceData: any = null;
    public _isSendMsg: boolean = false;
    public taskAwardIconMap: Map = new Map;
    public _match_id: number = 0;
    public _source: any = null;
    public _teamlistData: any = null;
    public _contest_id: number = 0;
    public _fromType: number = 0;
    public teamMap: Map = new Map;
    public _selectTeamIds: any[] = [];
    public teamIdDateMap: Map = new Map;
    public _startY: number = 0;
    public _closeAct: any = null;
    public _startAct: any = null;
    public _fee: number = 0;
    public _left_sign_number: number = 0;
    onLoad() {
        PushCenter.shared().addListener(PushEvent.commentDownloaderImg, (t => {
            try {
                if (ToolUtils.isObjValid(this.node) && this.taskAwardIconMap.size > 0) {
                    for (const [e, i] of this.taskAwardIconMap) {
                        i == t && sys.isObjectValid(e) && Utils.shared().updateNetImage(e, t, size(88, 88));
                    }
                }
            }
            catch (t) {
                TLog.printError(this.TAG, PushEvent.commentDownloaderImg, t);
            }
        }), this);
        PushCenter.shared().addListener(GameConfig.Update_Money, (t => {
            try {
                ToolUtils.isObjValid(this.node) && this.updateJoinBtnStatus();
            }
            catch (t) {
                TLog.printError(this.TAG, GameConfig.Update_Money, t);
            }
        }), this);
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().removeListenersByTag(this);
        this.unscheduleAllCallbacks();
    }
    init(t) {
        sys.isObjectValid(t) && sys.isObjectValid(t.match_id) && (this._match_id = t.match_id);
        sys.isObjectValid(t) && sys.isObjectValid(t.source) && (this._source = t.source);
        sys.isObjectValid(t) && sys.isObjectValid(t.fromType) && (this._fromType = t.fromType);
        sys.isObjectValid(t) && sys.isObjectValid(t.contest_id) && (this._contest_id = t.contest_id);
        sys.isObjectValid(t) && sys.isObjectValid(t.teamlistData) && (this._teamlistData = t.teamlistData);
    }
    start() {
        super.start();
        this.initView();
        this.refreshView();
        this.showSelectView();
        TweenTool.delayAct(this.node, (() => {
            this.reSortTeamInfo();
        }), 0.3, true);
    }
    showSelectView() {
        let t = -view.getVisibleSize().height / 2, e = this.rootNode.getComponent(UITransform).height;
        this._startY = t - e - 20;
        this.rootNode.setPosition(v3(0, this._startY));
        this._startAct = TweenTool.moveTo(this.rootNode, 0.2, v3(0, t), "sineIn", true);
    }
    hideSelectView() {
        this._startAct && TweenTool.stopAction(this._startAct);
        this._closeAct || (this._closeAct = TweenTool.moveTo(this.rootNode, 0.2, v3(0, this._startY), "sineIn", true, (() => {
            ToolUtils.isObjValid(this.node) && this.node.destroy();
        })));
    }
    refreshView() {
        this.rootNode.getChildByName("nodata").active = false;
        this.updateContestDetails();
    }
    updateContestDetails() {
        sys.isObjectValid(this._teamlistData) && (sys.isObjectValid(this._teamlistData.left_sign_num) && (this.rootNode.getChildByName("title").getComponent(Label).string = ToolUtils.format(i18nMgr.shared().getValueByKey("yes11.join_title"), this._teamlistData.left_sign_num), this._left_sign_number = this._teamlistData.left_sign_num), sys.isObjectValid(this._teamlistData.fee) && (this._fee = Number(this._teamlistData.fee)), this.updateNextButtonStatus());
    }
    reSortTeamInfo() {
        this.contentNode.removeAllChildren();
        this.teamMap.clear();
        this._selectTeamIds = [];
        sys.isObjectValid(this._teamlistData.list) && Array.isArray(this._teamlistData.list) && this._teamlistData.list.length > 0 && this.addTeamView(this.contentNode, this._teamlistData.list);
    }
    addTeamView(t, e) {
        for (let i = 0; i < e.length; i++) {
            let a = instantiate(this.team_mobanView);
            if (a.active = true, t.addChild(a), this.teamMap.set(String(e[i].team_id), a), this.teamIdDateMap.set(String(e[i].team_id), e[i]), sys.isObjectValid(e[i].name) && e[i].name.length > 0 && (a.getChildByName("name").getComponent(Label).string = e[i].name), a.getComponent(Button).clickEvents[0].customEventData = ToolUtils.toJsonString(e[i]), sys.isObjectValid(e[i].wk_num) && String(e[i].wk_num).length > 0 && (a.getChildByName("wk").getComponent(Label).string = "WK " + e[i].wk_num), sys.isObjectValid(e[i].bat_num) && String(e[i].bat_num).length > 0 && (a.getChildByName("bat").getComponent(Label).string = "BAT " + e[i].bat_num), sys.isObjectValid(e[i].ar_num) && String(e[i].ar_num).length > 0 && (a.getChildByName("ar").getComponent(Label).string = "AR " + e[i].ar_num), sys.isObjectValid(e[i].bowl_num) && String(e[i].bowl_num).length > 0 && (a.getChildByName("bowl").getComponent(Label).string = "BOWL " + e[i].bowl_num), sys.isObjectValid(e[i].teama_short_name) && String(e[i].teama_short_name).length > 0 && (a.getChildByName("team_name0").getComponent(Label).string = e[i].teama_short_name), sys.isObjectValid(e[i].teamb_short_name) && String(e[i].teamb_short_name).length > 0 && (a.getChildByName("team_name1").getComponent(Label).string = e[i].teamb_short_name), sys.isObjectValid(e[i].teama_num) && String(e[i].teama_num).length > 0 && (a.getChildByName("team_num0").getComponent(Label).string = e[i].teama_num), sys.isObjectValid(e[i].teamb_num) && String(e[i].teamb_num).length > 0 && (a.getChildByName("team_num1").getComponent(Label).string = e[i].teamb_num), this.updateItemCheckStatus(a, 0), sys.isObjectValid(e[i].members) && Array.isArray(e[i].members) && e[i].members.length > 0) {
                for (let t = 0; t < e[i].members.length; t++) {
                    let s = e[i].members[t];
                    1 == Number(s.captain_role) ? (a.getChildByName("cap_node0").getChildByName("wz").getComponent(Label).string = ToolUtils.GetShortName2(s.short_name, 13, false), s.out_team_id == e[i].teama_id ? (a.getChildByName("cap_node0").getChildByName("bg").getComponent(Sprite).spriteFrame = this.capBgImgs[0], a.getChildByName("cap_node0").getChildByName("wz").getComponent(Label).color = color(255, 255, 255), a.getChildByName("cap_node0").getChildByName("flag").getChildByName("wz").getComponent(Label).color = color(255, 255, 255), a.getChildByName("cap_node0").getChildByName("flag").getComponent(Sprite).spriteFrame = this.operateImgs[0]) : (a.getChildByName("cap_node0").getChildByName("bg").getComponent(Sprite).spriteFrame = this.capBgImgs[1], a.getChildByName("cap_node0").getChildByName("wz").getComponent(Label).color = color(51, 51, 51), a.getChildByName("cap_node0").getChildByName("flag").getChildByName("wz").getComponent(Label).color = color(51, 51, 51), a.getChildByName("cap_node0").getChildByName("flag").getComponent(Sprite).spriteFrame = this.operateImgs[1]), sys.isObjectValid(s.thumb_url) && s.thumb_url.length > 0 && (this.taskAwardIconMap.set(a.getChildByName("cap_node0").getChildByName("player_icon"), s.thumb_url), Utils.shared().updateNetImage(a.getChildByName("cap_node0").getChildByName("player_icon"), s.thumb_url, size(88, 88)))) : 2 == Number(s.captain_role) && (a.getChildByName("cap_node1").getChildByName("wz").getComponent(Label).string = ToolUtils.GetShortName2(s.short_name, 13, false), s.out_team_id == e[i].teama_id ? (a.getChildByName("cap_node1").getChildByName("bg").getComponent(Sprite).spriteFrame = this.capBgImgs[0], a.getChildByName("cap_node1").getChildByName("wz").getComponent(Label).color = color(255, 255, 255), a.getChildByName("cap_node1").getChildByName("flag").getChildByName("wz").getComponent(Label).color = color(255, 255, 255), a.getChildByName("cap_node1").getChildByName("flag").getComponent(Sprite).spriteFrame = this.operateImgs[0]) : (a.getChildByName("cap_node1").getChildByName("bg").getComponent(Sprite).spriteFrame = this.capBgImgs[1], a.getChildByName("cap_node1").getChildByName("wz").getComponent(Label).color = color(51, 51, 51), a.getChildByName("cap_node1").getChildByName("flag").getChildByName("wz").getComponent(Label).color = color(51, 51, 51), a.getChildByName("cap_node1").getChildByName("flag").getComponent(Sprite).spriteFrame = this.operateImgs[1]), sys.isObjectValid(s.thumb_url) && s.thumb_url.length > 0 && (this.taskAwardIconMap.set(a.getChildByName("cap_node1").getChildByName("player_icon"), s.thumb_url), Utils.shared().updateNetImage(a.getChildByName("cap_node1").getChildByName("player_icon"), s.thumb_url, size(88, 88))));
                }
            }
        }
    }
    updateNextButtonStatus() {
    }
    checkJoinTeam(t = 0, e) {
        let i = { match_id: this._match_id, session_id: this._contest_id, team_ids: this._selectTeamIds.join(",") };
        SportCricket_Manager.shared().requestYes11_CheckJoinTeamList(i, true, (t => {
            if (sys.isObjectValid(t.code) && 308501 == t.code) {
                return sys.isObjectValid(t.is_chip) && 1 == t.is_chip ? Utils.shared().showQuickRechargeByYes11({ fee: t.fee, is_chip: 1 }) : Utils.shared().showQuickRechargeByYes11({ fee: t.fee }), void User.shared().updatePayScene(PhpReportDefined.pay_scene.hall_cricket);
            }
            if (sys.isObjectValid(t.code) && 308503 == t.code) {
                let e = { match_id: this._match_id, contest_id: this._contest_id, assureInfo: t }, i = { fee: t.fee, list: [] };
                for (let t = 0; t < this._selectTeamIds.length; t++) {
                    let e = this.teamIdDateMap.get(this._selectTeamIds[t]);
                    i.list.push({ team_id: e.team_id, team_name: e.name });
                }
                i.list.sort(((t, e) => t.team_id - e.team_id));
                e.assureInfo = i;
                sys.isObjectValid(this._teamlistData) && sys.isObjectValid(this._teamlistData.is_chip) && 1 == this._teamlistData.is_chip && (e.assureInfo.is_chip = 1);
                Utils.shared().showSportCricket_assureJoin(e);
                ToolUtils.isObjValid(this.node) && this.node.destroy();
            }
        }));
    }
    onCloseButtonClick(t, e) {
        SoundManager.shared().playFx("click");
        sys.now() - this._lastClick < 500 || (this._lastClick = sys.now(), this.onBackView());
    }
    initView() {
        this.fitScreen();
    }
    onItemCheckClick(t, e) {
        if (SoundManager.shared().playFx("click"), sys.now() - this._lastClick < 500) {
            return;
        }
        this._lastClick = sys.now();
        let i = ToolUtils.parseJson(e).team_id, a = this._selectTeamIds.indexOf(i);
        if (-1 == a) {
            if (1 == this._left_sign_number && this._selectTeamIds.length > 0) {
                let t = this._selectTeamIds[0];
                return this.updateItemCheckStatus(this.teamMap.get(String(t)), 0), this._selectTeamIds = [i], void this.updateItemCheckStatus(this.teamMap.get(String(i)), 1);
            }
            if (this._selectTeamIds.length == Number(this._teamlistData.left_sign_num)) {
                return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("yes11.join_tip2"), 2);
            }
            this._selectTeamIds.push(i);
            this.updateItemCheckStatus(this.teamMap.get(String(i)), 1);
        }
        else {
            this._selectTeamIds.splice(a, 1);
            this.updateItemCheckStatus(this.teamMap.get(String(i)), 0);
        }
        this.updateJoinBtnStatus();
    }
    updateJoinBtnStatus() {
        let t = this._selectTeamIds.length * this._fee;
        User.shared().data.money >= t ? (this.nextNode.getChildByName("wz").getComponent(Label).string = "JOIN", this.nextNode.getComponent(Button).clickEvents[0].customEventData = "join") : (this.nextNode.getChildByName("wz").getComponent(Label).string = "ADD CASH", this.nextNode.getComponent(Button).clickEvents[0].customEventData = "add_cash");
    }
    updateItemCheckStatus(t, e) {
        ToolUtils.isObjValid(t) && (1 == e ? (t.getChildByName("select").active = true, 1 == this._left_sign_number ? t.getChildByName("check_btn").getChildByName("ico").getComponent(Sprite).spriteFrame = this.checkBtnImgs[3] : t.getChildByName("check_btn").getChildByName("ico").getComponent(Sprite).spriteFrame = this.checkBtnImgs[1], t.getChildByName("check_btn").getChildByName("ico").getComponent(Sprite).color = color(255, 255, 255)) : (1 == this._left_sign_number ? t.getChildByName("check_btn").getChildByName("ico").getComponent(Sprite).spriteFrame = this.checkBtnImgs[2] : t.getChildByName("check_btn").getChildByName("ico").getComponent(Sprite).spriteFrame = this.checkBtnImgs[0], t.getChildByName("check_btn").getChildByName("ico").getComponent(Sprite).color = color(225, 225, 225), t.getChildByName("select").active = false));
    }
    onButtonClick(t, e) {
        SoundManager.shared().playFx("click");
        sys.now() - this._lastClick < 500 || (this._lastClick = sys.now(), "join" == e ? 0 == this._selectTeamIds.length ? Utils.shared().showToast(i18nMgr.shared().getValueByKey("yes11.join_tip"), 2) : this.checkJoinTeam() : "add_cash" == e && (Utils.shared().showStoreView(null, null), User.shared().updatePayScene(PhpReportDefined.pay_scene.hall_cricket)));
    }
    onBackView(t = true) {
        t && (Utils.shared().hideLoading(), this.hideSelectView());
    }
    fitScreen() {
        ToolUtils.adaptSafeArea(this.rootNode);
        sys.getSafeAreaRect().y;
    }
}
