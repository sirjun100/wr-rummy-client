// @ts-nocheck
// Recovered from index.js:337
import { _decorator, Label, Node, Sprite, SpriteFrame, sys, v3 } from "cc";
import SoundManager from "./SoundManager";
import User from "./User";
import BaseLayer from "./BaseLayer";
import PushCenter from "./PushCenter";
import { ToolUtils } from "./ToolUtils";
import GameConfig from "./GameConfig";
const { ccclass, property } = _decorator;
@ccclass("PaymentSelect")
export class PaymentSelect extends BaseLayer {
    public rootNode: any = null;
    @property(Node)
    public rootNode_hall: Node = null;
    @property(Node)
    public rootNode_room: Node = null;
    @property([SpriteFrame])
    public selectBtnImgs: SpriteFrame[] = [];
    public _cb: any = null;
    public _data: any = null;
    public isSendMsg: boolean = false;
    public _lastClick: number = 0;
    public _has_close: boolean = false;
    public _isNext: boolean = false;
    public canClick: boolean = true;
    public lastTime: number = 0;
    public _paymentSelectPosY: number = 0;
    public cur_payment_index: number = 1;
    public isShop: boolean = false;
    public root_type: number = 0;
    setParaData(t, e) {
        this._cb = t;
        this._data = e;
        sys.isObjectValid(this._data) && sys.isObjectValid(this._data.isShop) && 1 == this._data.isShop && (this.isShop = true);
    }
    onLoad() {
        super.onLoad();
        ToolUtils.showFullScreen(this.node);
        ToolUtils.showFullScreen(this.node.getChildByName("mask"));
    }
    start() {
        super.start();
        ToolUtils.judgeIfInHall() || this.isShop ? (this.rootNode = this.rootNode_hall, this.root_type = 0) : (this.rootNode = this.rootNode_room, this.root_type = 1);
        this.rootNode_hall.active = 0 == this.root_type;
        this.rootNode_room.active = 1 == this.root_type;
        this._paymentSelectPosY = this.rootNode.getPosition().y;
        let t = this._paymentSelectPosY - (GameConfig.REAL_SCREEN_HEIGHT - GameConfig.CONFIG_SCREEN_HEIGHT) / 2;
        if (ToolUtils.judgeIfInHall() || this.isShop || (this._paymentSelectPosY = -310, t = this._paymentSelectPosY - (GameConfig.REAL_SCREEN_WIDTH - GameConfig.CONFIG_SCREEN_WIDTH) / 2), 0 == this.root_type ? ToolUtils.showPushAnim(this.node.getChildByName("root"), 3, null, { startPos: v3(0, t - 500), endPos: v3(0, t), moveTime: 0.2 }) : this.startShowAnim(this.rootNode), sys.isObjectValid(this._data) && sys.isObjectValid(this._data.price) && (this.rootNode.getChildByName("btn_pay").getChildByName("wz").getComponent(Label).string = `ADD ₹${this._data.price}`), sys.isObjectValid(User.shared().payment_cnt)) {
            if (sys.isObjectValid(User.shared().payment_cnt.pmode) && (this.cur_payment_index = User.shared().payment_cnt.pmode, 2 == this.cur_payment_index)) {
                User.shared().payment_cnt.upi2_select_amount.includes(Number(this._data.price)) || (this.cur_payment_index = 1);
            }
            if (sys.isObjectValid(User.shared().payment_cnt.upi_2_add) && User.shared().payment_cnt.upi_2_add > 0) {
                let t = this.rootNode.getChildByName("btnSelect2");
                t.getChildByName("flag").active = true;
                t.getChildByName("flag").getChildByName("wz").getComponent(Label).string = `+${User.shared().payment_cnt.upi_2_add}%`;
            }
        }
        this.updatePaymentSelect();
    }
    onButtonClick(t, e) {
        SoundManager.shared().playFx("click");
        "select_close" == e ? this.onBackView() : -1 != e.indexOf("pay_select_") ? (this.cur_payment_index = parseInt(e.split("pay_select_")[1]), this.updatePaymentSelect()) : "select_pay" == e && (this.dealPayLogic(), this.onBackView());
    }
    dealPayLogic() {
        this._cb && this._cb(this.cur_payment_index);
    }
    updatePaymentSelect() {
        let t = this.rootNode.getChildByName("btnSelect1"), e = this.rootNode.getChildByName("btnSelect2");
        t.getChildByName("kuang").getComponent(Sprite).spriteFrame = 1 == this.cur_payment_index ? this.selectBtnImgs[0] : this.selectBtnImgs[1];
        e.getChildByName("kuang").getComponent(Sprite).spriteFrame = 2 == this.cur_payment_index ? this.selectBtnImgs[0] : this.selectBtnImgs[1];
    }
    onBackView() {
        if (ToolUtils.isObjValid(this.node)) {
            if (this._has_close) {
                return;
            }
            this._has_close = true;
            PushCenter.shared().removeListenersByTag(this);
            ToolUtils.isObjValid(this.node) && this.node.destroy();
        }
    }
}
