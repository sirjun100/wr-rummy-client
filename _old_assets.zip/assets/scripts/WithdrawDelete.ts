// @ts-nocheck
// Recovered from index.js:695
import { _decorator, Label } from "cc";
import SoundManager from "./SoundManager";
import { TLog } from "./TLog";
import i18nMgr from "./i18nMgr";
import BaseLayer from "./BaseLayer";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("WithdrawDelete")
export class WithdrawDelete extends BaseLayer {
    @property(Label)
    public nameLabel: Label = null;
    @property(Label)
    public numberLabel: Label = null;
    public _callback: any = null;
    public _data: any = null;
    start() {
        super.start();
        ToolUtils.startShowAnim(this.node.getChildByName("bgVIew"));
    }
    initData(t, e) {
        try {
            this._callback = e;
            i18nMgr.shared().changeLabelFont(this.nameLabel);
            i18nMgr.shared().changeLabelFont(this.numberLabel);
            let a = i18nMgr.shared().getValueByKey("withdraw.name") + ToolUtils.getLimitLengthString(t.w_name, 30, false);
            this.nameLabel.string = a;
            let i = i18nMgr.shared().getValueByKey("withdraw.number") + ToolUtils.getLimitLengthString(t.w_account, 24, false);
            this.numberLabel.string = i;
        }
        catch (t) {
            TLog.printError("trycatch WithdrawConfim initData:", t);
        }
    }
    button_click(t, e) {
        SoundManager.shared().playFx("click");
        ToolUtils.isObjValid(this.node) && (this._data = e, this.onBackView());
    }
    onBackView() {
        ToolUtils.isObjValid(this.node) && (this._callback && this._callback(this._data), this.node.destroy());
    }
    onDestroy() {
        super.onDestroy();
    }
}
