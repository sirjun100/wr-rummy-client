// @ts-nocheck
// Recovered from index.js:311
import { _decorator, Button, Node, size, Sprite, SpriteFrame, UITransform, v3, Vec3 } from "cc";
import SoundManager from "./SoundManager";
import TweenTool from "./TweenTool";
import { AdapDirection } from "./Parent";
import { TLog } from "./TLog";
import PushCenter from "./PushCenter";
import GameConfig from "./GameConfig";
import BaseLayer from "./BaseLayer";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("MenuAlert")
export default class MenuAlert extends BaseLayer {
    @property(Node)
    public rootNode: Node = null;
    @property([SpriteFrame])
    public btnStatusSp: SpriteFrame[] = [];
    @property([SpriteFrame])
    public exitIconArr: SpriteFrame[] = [];
    @property([SpriteFrame])
    public switchIconArr: SpriteFrame[] = [];
    public cb_: any = null;
    onLoad() {
        if (this.fitScreen(), this.bIsInGame = true, PushCenter.shared().addListener(GameConfig.Update_Private_Exit_Status, (t => {
            t.tid_key === this.tid_key && ToolUtils.isObjValid(this.node) && this.setBtnEnable("exit", t.bEnable);
        }), this), PushCenter.shared().addListener(GameConfig.Update_Menu_Switch_Status, (t => {
            t.tid_key === this.tid_key && ToolUtils.isObjValid(this.node) && this.setBtnEnable("switch", t.bEnable);
        }), this), 1 == GameConfig.CHIPS_MODLE) {
            this.rootNode.getChildByName("top").getChildByName("layout").getChildByName("help").active = false;
        }
    }
    start() {
        super.start();
    }
    fitScreen() {
        ToolUtils.showFullScreen(this.node.getChildByName("pingbi"));
        ToolUtils.showFullScreen(this.node.getChildByName("bg"));
        ToolUtils.showFullScreen(this.node.getChildByName("cancel").getChildByName("bg2"));
        GameConfig.REAL_SCREEN_WIDTH <= GameConfig.CONFIG_SCREEN_WIDTH && (ToolUtils.isIosPlatform() ? this.resetUiPos(this.rootNode, AdapDirection.Left, true, 0.5, true) : this.resetUiPos(this.rootNode, AdapDirection.Left, true, 1, true));
        ToolUtils.judgeIfInRummy() || (this.rootNode.getChildByName("menu_bg").getChildByName("bg1").getComponent(UITransform).contentSize = size(322, 720));
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().removeListenersByTag(this);
    }
    startShowAnim() {
        this.node.position = v3(-479, 0, 0);
        let t = v3(0, 0, 0);
        TweenTool.moveTo(this.node, 0.15, t, "fade", true, (() => {
            this.node.setPosition(t);
        }));
    }
    setSevenUpMenuShow() {
        let t = this.rootNode.getChildByName("top").getChildByName("layout"), e = t.getChildByName("gamedisplay"), i = t.getChildByName("tableinfo"), o = t.getChildByName("switch");
        ToolUtils.isObjValid(e) && (e.active = false);
        ToolUtils.isObjValid(i) && (i.active = false);
        ToolUtils.isObjValid(o) && (o.active = false);
    }
    setLudoMenuShow() {
        let t = this.rootNode.getChildByName("top").getChildByName("layout"), e = t.getChildByName("gamedisplay"), i = t.getChildByName("tableinfo");
        if (ToolUtils.isObjValid(e) && (e.active = false), ToolUtils.isObjValid(i) && (i.active = false), 1 == GameConfig.CHIPS_MODLE) {
            let e = t.getChildByName("help");
            ToolUtils.isObjValid(e) && (e.active = false);
        }
    }
    onClickClose(t, e) {
        SoundManager.shared().playFx("click");
        try {
            let t = new Vec3;
            this.node.getPosition(t);
            let e = 350, i = v3(t.x, t.y + e, 0);
            ToolUtils.getOrientation() && (i = v3(t.x - e, t.y, 0));
            TweenTool.moveTo(this.node, 0.15, i, "fade", true, (() => {
                ToolUtils.isObjValid(this.node) && this.node.destroy();
            }));
        }
        catch (t) {
            TLog.printError("trycatch onClickClose:", t);
        }
    }
    setTidKey(t) {
        this.tid_key = t;
    }
    setCallback(t) {
        this.cb_ = t;
    }
    setBtnEnable(t, e) {
        try {
            let i = 0;
            "exit" == t ? i = 1 : "switch" == t && (i = 2);
            let o = this.rootNode.getChildByName("top").getChildByName("layout"), n = o.getChildByName("exit"), s = o.getChildByName("switch");
            null != e && null != e || (e = false);
            let a = o.getChildByName(t);
            if (ToolUtils.isObjValid(a)) {
                a.getComponent(Button).interactable = e;
                a.getComponent(Sprite).spriteFrame = e ? this.btnStatusSp[0] : this.btnStatusSp[1];
            }
            1 == i ? n.getChildByName("icon").getComponent(Sprite).spriteFrame = e ? this.exitIconArr[0] : this.exitIconArr[1] : 2 == i && (s.getChildByName("icon").getComponent(Sprite).spriteFrame = e ? this.switchIconArr[0] : this.switchIconArr[1]);
        }
        catch (t) {
            TLog.printError("trycatch menualert setBtnEnable:", t);
        }
    }
    onClickByBtn(t, e) {
        this.cb_(e);
        ToolUtils.isObjValid(this.node) && this.node.destroy();
    }
    setLandscapeShow() {
        ToolUtils.getOrientation() || this.node.setRotationFromEuler(v3(0, 0, -90));
    }
}
