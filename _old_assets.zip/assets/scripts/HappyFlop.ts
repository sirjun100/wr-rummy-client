// @ts-nocheck
// Recovered from index.js:183
import { _decorator, color, director, Label, Node, sp, Sprite, SpriteFrame, sys, UIOpacity, v3 } from "cc";
import SoundManager from "./SoundManager";
import User from "./User";
import PushEvent from "./PushEvent";
import BaseLayer from "./BaseLayer";
import Utils from "./Utils";
import HttpManager from "./HttpManager";
import { HttpRequest } from "./HttpRequestName";
import i18nMgr from "./i18nMgr";
import TweenTool from "./TweenTool";
import BundleNameDefined from "./BundleNameDefined";
import ReportConfig from "./ReportConfig";
import PushCenter from "./PushCenter";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("HappyFlop")
export class HappyFlop extends BaseLayer {
    @property(Node)
    public flipRootNode: Node = null;
    @property(Label)
    public rewardLabel: Label = null;
    @property(Node)
    public frontCardNode: Node = null;
    @property(Label)
    public time_tip1Label: Label = null;
    @property(Node)
    public cardNode: Node = null;
    @property(Node)
    public gd_node: Node = null;
    @property(sp.Skeleton)
    public fanfanleSkeleton: any = null;
    @property([SpriteFrame])
    public ico_imgs: SpriteFrame[] = [];
    @property(sp.Skeleton)
    public cardAnim: any = null;
    @property(Node)
    public rootMaskNode: Node = null;
    @property(Node)
    public ruleNode: Node = null;
    @property(Label)
    public ruleLabel: Label = null;
    public ruleData: any = null;
    public isNext: boolean = false;
    public lineSpace: number = 4.34;
    public isquick: boolean = false;
    public pageData: any = null;
    public _leftTime: number = 0;
    public _discountTime: number = 0;
    public _limit: number = 0;
    public _scheduleAct: any = null;
    public _lightAct: any = null;
    public _ui_type: number = 1;
    public _up_money: number = 0;
    public _amount: number = 0;
    public _gid: number = 0;
    public lastClick: number = 0;
    public _lineHei: number = 2;
    public _startFanPai: boolean = false;
    public _discountData: any = null;
    public _click_time: number = 0;
    public _hasGetDiscountData: boolean = false;
    public _showDiscountAnim: boolean = false;
    public _cur_cash: number = 0;
    public _cur_bonus: number = 0;
    public _nVid: number = 0;
    public _linkId: number = 0;
    public _reportScene: any = -1;
    public _pop_souce: number = 0;
    public _has_close: boolean = false;
    public _clickCardIndex: number = 1;
    public card_posX: any[] = [-238, -6, 226];
    public checkKyc: number = 0;
    public _hasLeftTime: boolean = false;
    start() {
        super.start();
        this._linkId = this._linkId > 0 ? this._linkId : sys.now();
        this._reportScene = this._reportScene >= 0 ? this._reportScene : ToolUtils.getIsInRoom() ? 2 : 1;
        this.ruleNode.active = false;
        ToolUtils.showFullScreen(this.node.getChildByName("mask"));
        ToolUtils.showFullScreen(this.ruleNode.getChildByName("mask"));
        let e = 1 == this._ui_type ? 2 : 3;
        3 != e && HttpManager.shared().doCommReportRechargeEvent(ReportConfig.Cmd_HappyFlop, this._reportScene, e, this._linkId, "", this._nVid);
        PushCenter.shared().addListener(PushEvent.RefreshHappyFlop, (e => {
            ToolUtils.isObjValid(this.node) && this.onBackView();
        }), this);
        this.dealMultipleLanguages();
    }
    dealMultipleLanguages() {
        2 == i18nMgr.shared().language && (this.flipRootNode.getChildByName("gd_node").getChildByName("Layout_en").getChildByName("top_tip").getComponent(Label).fontSize = 18, this.flipRootNode.getChildByName("gd_node").getChildByName("Layout_en").getChildByName("top_tip").getComponent(Label).lineHeight = 24);
    }
    showDiscountUIAnim(e, t = true) {
        this.fanfanleSkeleton.node.active = false;
        this._showDiscountAnim = true;
        this._ui_type = 2;
        this.gd_node.getChildByName("reflip_btn").active = false;
        this.gd_node.getChildByName("add_cash").active = false;
        this.gd_node.getChildByName("random_flip").active = false;
        this._hasLeftTime = false;
        sys.isObjectValid(e.leftTime) && (this._leftTime = e.leftTime, this._hasLeftTime = Number(e.leftTime) > 0);
        this.refereshHomePageUi(e);
        TweenTool.delayAct(this.node, (() => {
            this.refereshHomePageUi(e);
            this.gd_node.getChildByName("reflip_btn").active = true;
            this.gd_node.getChildByName("add_cash").active = true;
            TweenTool.moveToByFade(this.gd_node.getChildByName("reflip_btn"), 0.16, this.gd_node.getChildByName("reflip_btn").getPosition(), 0, 1, true, (() => {
                this.gd_node.getChildByName("reflip_btn").getComponent(UIOpacity).opacity = 255;
            }));
            TweenTool.moveToByFade(this.gd_node.getChildByName("add_cash"), 0.16, this.gd_node.getChildByName("add_cash").getPosition(), 0, 1, true, (() => {
                this.gd_node.getChildByName("add_cash").getComponent(UIOpacity).opacity = 255;
            }));
        }), 0.1, true);
        this.cardNode.getChildByName("card1").getChildByName("ico").active = true;
        this.cardNode.getChildByName("card2").getChildByName("ico").active = true;
        this.cardNode.getChildByName("card3").getChildByName("ico").active = true;
        this.frontCardNode.active = true;
        this.frontCardNode.setPosition(v3(this.card_posX[this._clickCardIndex - 1], -14, 0));
        t && this.startShowAnim(this.cardNode);
    }
    initCurMobanCallBack(e, t) {
        sys.isObjectValid(t) && (e.active = true, e.getChildByName("date").getComponent(Label).string = t.ctime + "", e.getChildByName("amounts").getComponent(Label).string = t.amount + "", e.getChildByName("rewards").getComponent(Label).string = t.reward + "");
    }
    update(e) {
    }
    initParaData(e) {
        sys.isObjectValid(e) && (sys.isObjectValid(e.data) && (this.isNext = e.data.isNext), sys.isObjectValid(e.isquick) && (this.isquick = e.isquick), sys.isObjectValid(e.pop_souce) && (this._pop_souce = e.pop_souce), sys.isObjectValid(e.checkKyc) && (this.checkKyc = e.checkKyc), sys.isObjectValid(e.reportScene) && (this._reportScene = e.reportScene), sys.isObjectValid(e.link_id) && e.link_id > 0 && (this._linkId = e.link_id));
        this._ui_type = 1;
        this._up_money = 0;
        e && sys.isObjectValid(e.page) && (this.pageData = e.page, sys.isObjectValid(this.pageData.ui) && (this._ui_type = this.pageData.ui), this._hasLeftTime = false, sys.isObjectValid(this.pageData.leftTime) && (this._leftTime = this.pageData.leftTime, this._discountTime = this.pageData.leftTime, this._hasLeftTime = Number(this.pageData.leftTime) > 0), sys.isObjectValid(this.pageData.card_index) && (this._clickCardIndex = Number(this.pageData.card_index)));
        1 == this._ui_type ? this.showFlipUI() : this.showDiscountUIAnim(this.pageData);
        this._scheduleAct = TweenTool.commonSchedule(this.node, 1, this.scheduleCallBack.bind(this));
    }
    showFlipUI() {
        this.flipRootNode.active = true;
        this.fanfanleSkeleton.node.active = false;
        TweenTool.moveSpriteByFade(this.rootMaskNode, 0.2, v3(0, 0, 0), 0, 0.8, true, (() => {
            this.rootMaskNode.getComponent(Sprite).color = color(0, 0, 0, 204);
            TweenTool.delayAct(this.node, (() => {
                this.fanfanleSkeleton.node.active = true;
                0 == i18nMgr.shared().language ? this.fanfanleSkeleton.setSkin("English") : 1 == i18nMgr.shared().language ? this.fanfanleSkeleton.setSkin("Hindi") : 2 == i18nMgr.shared().language ? this.fanfanleSkeleton.setSkin("Tamil") : 3 == i18nMgr.shared().language ? this.fanfanleSkeleton.setSkin("Urdu") : this.fanfanleSkeleton.setSkin("English");
                this.fanfanleSkeleton.setAnimation(0, "ffl_1", false);
                this.fanfanleSkeleton.addAnimation(0, "ffl_2", true);
                this.gd_node.active = true;
                this.refereshHomePageUi(this.pageData);
            }), 0.1, true);
        }));
        this.cardNode.getChildByName("card1").getChildByName("ico").active = false;
        this.cardNode.getChildByName("card2").getChildByName("ico").active = false;
        this.cardNode.getChildByName("card3").getChildByName("ico").active = false;
        this.frontCardNode.active = false;
        this.gd_node.getChildByName("reflip_btn").active = false;
        this.gd_node.getChildByName("add_cash").active = false;
        this.gd_node.getChildByName("random_flip").active = false;
        TweenTool.delayAct(this.node, (() => {
            this.gd_node.getChildByName("random_flip").active = true;
            TweenTool.moveToByFade(this.gd_node.getChildByName("random_flip"), 0.16, this.gd_node.getChildByName("random_flip").getPosition(), 0, 1, true, (() => {
                this.gd_node.getChildByName("random_flip").getComponent(UIOpacity).opacity = 255;
            }));
        }), 0.5, true);
    }
    refereshHomePageUi(e) {
        this.refreshLeftTime();
        sys.isObjectValid(e.limit) && (this._limit = e.limit);
        sys.isObjectValid(e.up) && (this._up_money = e.up);
        sys.isObjectValid(e.bmoney) && (this.frontCardNode.getChildByName("num0").getComponent(Label).string = "" + ToolUtils.parse_double(String(e.bmoney), -1), this._cur_cash = Number(e.bmoney));
        sys.isObjectValid(e.bonus) && (this.frontCardNode.getChildByName("num1").getComponent(Label).string = "" + ToolUtils.parse_double(String(e.bonus), -1), this._cur_bonus = Number(e.bonus));
        this.frontCardNode.getChildByName("total").getComponent(Label).string = ToolUtils.format(i18nMgr.shared().getValueByKey("flip_act.total_get"), this._cur_cash + this._cur_bonus);
        sys.isObjectValid(e.amount) && (this._amount = e.amount, this.gd_node.getChildByName("add_cash").getChildByName("money").getComponent(Label).string = "₹" + ToolUtils.parse_double(String(e.amount), -1));
        this.gd_node.getChildByName("add_cash").getChildByName("flag").active = false;
        sys.isObjectValid(e.title) && (this.gd_node.getChildByName("add_cash").getChildByName("flag").active = true, this.gd_node.getChildByName("add_cash").getChildByName("flag").getChildByName("wz").getComponent(Label).string = e.title);
        sys.isObjectValid(e.gid) && (this._gid = e.gid);
        this.gd_node.getChildByName("reflip_btn").getChildByName("Label").getComponent(Label).string = ToolUtils.format(i18nMgr.shared().getValueByKey("flip_act.try_again"), this._limit);
        this.rewardLabel.string = "₹" + ToolUtils.parse_double(String(this._up_money), -1) + "*";
    }
    refreshLeftTime() {
        this._leftTime <= 0 ? this.time_tip1Label.string = "Only once in a lifetime" : this.time_tip1Label.string = ToolUtils.format(i18nMgr.shared().getValueByKey("flip_act.time_left"), Utils.shared().parseCountDown(this._leftTime));
    }
    scheduleCallBack() {
        this._leftTime -= 1;
        this._leftTime < 0 && (this._leftTime = 0);
        this.refreshLeftTime();
    }
    onButtonClick(e, t) {
        if (SoundManager.shared().playFx("click"), "close" == t) {
            1 == this.checkKyc && Utils.shared().checkAddCashKyc();
            this.onBackView();
        }
        else if ("reflip" == t) {
            if (HttpManager.shared().doCommReportRechargeEvent(ReportConfig.Cmd_HappyFlop, this._reportScene, 9, this._linkId, "", this._nVid), this._limit <= 0) {
                let e = { bLandscape: ToolUtils.getIsNormalDirection(), bWithCancel: true, strContent: i18nMgr.shared().getValueByKey("flip_act.reflip_notice"), sureKey: "flip_act.yes", cancelKey: "flip_act.no", dialogType: 0 };
                return void Utils.shared().showCommonAlert(e, (e => {
                    1 === e && this.reflipAttemptsUi();
                }));
            }
            this.reflipAttemptsUi();
        }
        else if ("add_cash" == t) {
            if (!User.shared().checkCanRecharge()) {
                return void (ToolUtils.isObjValid(this.node) && this.node.destroy());
            }
            let e = { goodsId: this._gid + "", price: this._amount, act_id: PushEvent.JUMP_TO_HAPPYFLOP };
            if (HttpManager.shared().doCommReportRechargeEvent(ReportConfig.Cmd_HappyFlop, this._reportScene, 6, this._linkId, e, this._nVid), this._hasLeftTime && this._discountTime <= 0) {
                return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("flip_act.event_end"), 2, 0, ToolUtils.getIsNormalDirection());
            }
            if (sys.now() - this.lastClick < 1000) {
                return;
            }
            HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Hall, event: ReportConfig.common.try_recharge });
            this.lastClick = sys.now();
            let t = { goodsId: this._gid + "", price: this._amount, act_id: PushEvent.JUMP_TO_HAPPYFLOP, link_id: this._linkId };
            User.shared().startPay(t);
        }
        else {
            "help" == t && (sys.isObjectValid(this.ruleData) ? this.showRuleView() : this.requestActHappyFlopTips());
        }
    }
    requestActHappyFlopTips() {
        HttpManager.shared().doGetCommonRequest(null, HttpRequest.HappyFlipActTips, ((e, t, i) => {
            if (200 != i) {
                ;
            }
            else if (ToolUtils.isObjValid(this.node)) {
                let e = ToolUtils.parseJson(t);
                0 == e.ret && ToolUtils.isObjValid(this.node) && (this.ruleData = e.data, this.showRuleView());
            }
        }));
    }
    showRuleView() {
        ToolUtils.isObjValid(this.ruleNode) && (this.ruleNode.active ? (this.ruleLabel.string = this.ruleData.tips, i18nMgr.shared().changeLabelFont(this.ruleLabel)) : (this.ruleNode.active = true, this.startShowAnim(this.ruleNode.getChildByName("bg"), (() => {
            this.ruleLabel.string = this.ruleData.tips;
            i18nMgr.shared().changeLabelFont(this.ruleLabel);
        }))));
    }
    reflipAttemptsUi() {
        HttpManager.shared().doCommReportRechargeEvent(ReportConfig.Cmd_HappyFlop, this._reportScene, 2, this._linkId, "", this._nVid);
        this.flipRootNode.active = true;
        this.gd_node.active = true;
        this._ui_type = 1;
        this.refereshHomePageUi(this.pageData);
        this.fanfanleSkeleton.node.active = true;
        this.fanfanleSkeleton.clearTracks();
        this.restoreFanpaiAnim();
        this.requestActHappyFlopReFlip();
        this.cardNode.getChildByName("card1").getChildByName("ico").active = false;
        this.cardNode.getChildByName("card2").getChildByName("ico").active = false;
        this.cardNode.getChildByName("card3").getChildByName("ico").active = false;
        this.cardNode.getChildByName("front_card").active = false;
        this._showDiscountAnim = false;
        this.gd_node.getChildByName("reflip_btn").active = false;
        this.gd_node.getChildByName("add_cash").active = false;
        this.gd_node.getChildByName("random_flip").active = true;
        TweenTool.moveToByFade(this.gd_node.getChildByName("random_flip"), 0.16, this.gd_node.getChildByName("random_flip").getPosition(), 0, 1, true, (() => {
            this.gd_node.getChildByName("random_flip").getComponent(UIOpacity).opacity = 255;
        }));
    }
    cardFlipClick(e, t) {
        if (SoundManager.shared().playFx("click"), this._limit <= 0) {
            return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("flip_act.flip_tip"), 2, 0, ToolUtils.getIsNormalDirection());
        }
        if (this._hasLeftTime && this._leftTime <= 0) {
            return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("flip_act.event_end"), 2, 0, ToolUtils.getIsNormalDirection());
        }
        if (2 == this._ui_type) {
            return;
        }
        if (sys.now() - this._click_time < 1000) {
            return;
        }
        this._click_time = sys.now();
        this._clickCardIndex = Number(t);
        4 == this._clickCardIndex && (this._clickCardIndex = ToolUtils.getRandomInt(1, 3), t = this._clickCardIndex + "");
        let i = this.cardNode.getChildByName("card" + t);
        this.cardAnim.node.setPosition(v3(i.getPosition().x, 0.514));
        for (let e = 1; e < 4; e++) {
            this.cardNode.getChildByName("card" + e).active = true;
            this.cardNode.getChildByName("card" + e).getChildByName("ico").active = true;
            this.cardNode.getChildByName("card" + e).getChildByName("ico").getComponent(Sprite).spriteFrame = this.ico_imgs[0];
            this._clickCardIndex == e && (this.cardNode.getChildByName("card" + e).getChildByName("ico").getComponent(Sprite).spriteFrame = this.ico_imgs[1]);
        }
        this.fanfanleSkeleton.node.active = false;
        this.cardAnim.node.active = true;
        this._startFanPai = true;
        this.requestActHappyFlopFlip();
        0 == i18nMgr.shared().language ? this.cardAnim.setSkin("English") : 1 == i18nMgr.shared().language ? this.cardAnim.setSkin("Hindi") : 2 == i18nMgr.shared().language ? this.cardAnim.setSkin("Tamil") : 3 == i18nMgr.shared().language ? this.cardAnim.setSkin("Urdu") : this.cardAnim.setSkin("English");
        this.gd_node.getChildByName("random_flip").active = false;
        this.cardAnim.setAnimation(0, "ffl_3", false);
        this._hasGetDiscountData = false;
        this._showDiscountAnim = false;
        Utils.shared().hideToast();
        this.cardAnim.setCompleteListener((() => {
            this._startFanPai = false;
            this._hasGetDiscountData && (Utils.shared().hideToast(), this.showDiscountUIAnim(this._discountData, false));
        }));
    }
    restoreFanpaiAnim() {
        for (let e = 1; e < 4; e++) {
            this.cardNode.getChildByName("card" + e).getChildByName("ico").active = true;
        }
        this.frontCardNode.active = false;
        this.fanfanleSkeleton.node.active = true;
        0 == i18nMgr.shared().language ? this.fanfanleSkeleton.setSkin("English") : 1 == i18nMgr.shared().language ? this.fanfanleSkeleton.setSkin("Hindi") : 2 == i18nMgr.shared().language ? this.fanfanleSkeleton.setSkin("Tamil") : 3 == i18nMgr.shared().language ? this.fanfanleSkeleton.setSkin("Urdu") : this.fanfanleSkeleton.setSkin("English");
        this.fanfanleSkeleton.setAnimation(0, "ffl_2", true);
        this.cardAnim.node.active = false;
        this._startFanPai = false;
        this._showDiscountAnim = false;
    }
    requestActHappyFlopFlip() {
        HttpManager.shared().doGetCommonRequest({ card_index: this._clickCardIndex }, HttpRequest.HappyFlipActFlip, ((e, t, i) => {
            if (ToolUtils.isObjValid(this.node)) {
                if (200 != i) {
                    Utils.shared().showToast(i18nMgr.shared().getValueByKey("flip_act.request_timeout"), 3, 0, ToolUtils.getIsNormalDirection());
                    this.restoreFanpaiAnim();
                }
                else {
                    let e = ToolUtils.parseJson(t);
                    if (0 == e.ret) {
                        this._hasGetDiscountData = true;
                        this._discountData = e.data;
                        Utils.shared().hideToast();
                        this._showDiscountAnim || this._startFanPai ? (sys.isObjectValid(this._discountData.leftTime) && (this._discountTime = this._discountData.leftTime), this.refereshHomePageUi(this._discountData)) : this.showDiscountUIAnim(this._discountData, false);
                        director.getScene().name == BundleNameDefined.hall_scene && User.shared().getHallInfo();
                        let t = "";
                        sys.isObjectValid(e.data.num) && (t = { num: e.data.num });
                        HttpManager.shared().doCommReportRechargeEvent(ReportConfig.Cmd_HappyFlop, this._reportScene, 8, this._linkId, t, this._nVid);
                    }
                }
            }
        }));
    }
    requestActHappyFlopReFlip() {
        HttpManager.shared().doGetCommonRequest(null, HttpRequest.HappyFlipActReflip, ((e, t, i) => {
            if (200 != i) {
                ;
            }
            else if (ToolUtils.isObjValid(this.node)) {
                let e = ToolUtils.parseJson(t);
                0 == e.ret && sys.isObjectValid(e.data) && sys.isObjectValid(e.data.limit) && (sys.isObjectValid(e.data.leftTime) && (this._leftTime = e.data.leftTime), this.refereshHomePageUi(e.data), director.getScene().name == BundleNameDefined.hall_scene && User.shared().getHallInfo());
            }
        }));
    }
    requestActHappyFlopGetLog() {
        HttpManager.shared().doGetCommonRequest(null, HttpRequest.HappyFlipActGetLog, ((e, t, i) => {
            if (200 != i) {
                ;
            }
            else {
                0 == ToolUtils.parseJson(t).ret && ToolUtils.isObjValid(this.node);
            }
        }));
    }
    onBackView() {
        if (ToolUtils.isObjValid(this.node)) {
            if (ToolUtils.isObjValid(this.ruleNode) && this.ruleNode.active) {
                this.ruleNode.active = false;
            }
            else {
                if (this._has_close) {
                    return;
                }
                let e = { alert_node: this.node, rootNode: this.node.getChildByName("rootNode"), isNext: this.isNext, pop_type: PushEvent.JUMP_TO_HAPPYFLOP, pop_souce: this._pop_souce };
                Utils.shared().closeActivityView(e);
                this._has_close = true;
                User.shared().getHallInfo();
                Utils.shared().hideToast();
            }
        }
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().removeListenersByTag(this);
        TweenTool.stopNodeAction(this.node);
    }
}
