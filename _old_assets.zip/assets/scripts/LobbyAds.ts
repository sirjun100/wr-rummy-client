// @ts-nocheck
// Recovered from index.js:243
import { _decorator, Component, Button, instantiate, Node, PageView, size, Sprite, SpriteFrame, sys } from "cc";
import SoundManager from "./SoundManager";
import TweenTool from "./TweenTool";
import User from "./User";
import Utils from "./Utils";
import PushEvent from "./PushEvent";
import HttpManager from "./HttpManager";
import ReportConfig from "./ReportConfig";
import PushCenter from "./PushCenter";
import { TransferPlatform } from "./TransferPlatform";
import { ToolUtils } from "./ToolUtils";
import GameConfig from "./GameConfig";
import PhpReportDefined from "./PhpReportDefined";
const { ccclass, property } = _decorator;
@ccclass("LobbyAds")
export class LobbyAds extends Component {
    @property(PageView)
    public pageView: PageView = null;
    @property(Node)
    public moban: Node = null;
    @property(SpriteFrame)
    public chipsDefault: SpriteFrame = null;
    @property([SpriteFrame])
    public chip_imgs_617: SpriteFrame[] = [];
    public turningAction: any = null;
    public _items: any[] = [];
    public _banner_type: number = 0;
    public _bannerList: any[] = [];
    onLoad() {
        1 == GameConfig.CHIPS_MODLE && (this.moban.getChildByName("img").getComponent(Sprite).spriteFrame = this.chipsDefault);
    }
    fitChipMode() {
        if (0 == GameConfig.CHIPS_MODLE) {
            return;
        }
        let e = 2000617 == GameConfig.CHANNEL_ID;
        e && e && (this.moban.getChildByName("img").getComponent(Sprite).spriteFrame = this.chip_imgs_617[0]);
    }
    start() {
        this.moban.active = false;
        PushCenter.shared().addListener(PushEvent.commentDownloaderImg, (e => {
            if (ToolUtils.isObjValid(this.node)) {
                for (let t = 0, i = this._items.length; t < i; t++) {
                    try {
                        let i = this._items[t];
                        if (sys.isObjectValid(i)) {
                            let t = i.getComponent(Button).clickEvents[0].customEventData;
                            if (sys.isObjectValid(t)) {
                                let n = ToolUtils.parseJson(t);
                                sys.isObjectValid(n) && n.img == e && this.initCurMobanCallBack(i, n);
                            }
                        }
                    }
                    catch (e) {
                    }
                }
            }
        }), this);
        PushCenter.shared().addListener(PushEvent.CheckBannerReport, (e => {
            let t = this.pageView.getPages().length;
            if (t > 0) {
                let e = this.pageView.getCurrentPageIndex(), i = e - 1;
                if (0 == e ? i = this._bannerList.length - 1 : e == t - 1 && (i = 0), 1 == User.shared().s_uirp_2 && sys.isObjectValid(this._bannerList) && sys.isObjectValid(this._bannerList[i])) {
                    let e = [];
                    e[0] = this._bannerList[i].jump_info;
                    HttpManager.shared().doGetBannerShowRequest(ReportConfig.Cmd_UIBannerReport, e, ((e, t, i) => {
                    }));
                }
            }
        }), this);
    }
    onDestroy() {
        this.stopTurningAnim();
        PushCenter.shared().removeListenersByTag(this);
    }
    onEnable() {
        this.pageView.node.on("scroll-ended", this.onPageTurning, this);
        let e = this.pageView.getPages().length;
        if (e > 0) {
            let t = this.pageView.getCurrentPageIndex(), i = t - 1;
            if (0 == t ? (this.pageView.scrollToPage(e - 2, 0), i = this._bannerList.length - 1) : t == e - 1 ? (this.pageView.scrollToPage(1, 0), i = 0) : this.pageView.scrollToPage(t, 0), this.stopTurningAnim(), this.playTurningAnim(), 1 == User.shared().s_uirp_2 && sys.isObjectValid(this._bannerList) && sys.isObjectValid(this._bannerList[i])) {
                let e = [];
                e[0] = this._bannerList[i].jump_info;
                HttpManager.shared().doGetBannerShowRequest(ReportConfig.Cmd_UIBannerReport, e, ((e, t, i) => {
                }));
            }
        }
    }
    onDisable() {
        this.pageView.node.off("scroll-ended", this.onPageTurning, this);
        this.stopTurningAnim();
    }
    updateBanners(e = 0, t = []) {
        if (this._banner_type = e, 0 == this._banner_type ? (t = User.shared().data.bannerlist, this._bannerList = User.shared().data.bannerlist) : this._bannerList = t, t && t.length > 0) {
            if (this.pageView.getPages().length - 2 != t.length) {
                if (this.stopTurningAnim(), this.pageView.removeAllPages(), Array.isArray(this.pageView.content.children) && this.pageView.content.children.length > 0 && this.pageView.content.removeAllChildren(), this._items = [], 1 == t.length) {
                    let e = instantiate(this.moban);
                    e.active = true;
                    this.initCurMobanCallBack(e, t[0]);
                    this.pageView.addPage(e);
                    this.pageView.elastic = false;
                    this._items.push(e);
                }
                else if (t.length > 1) {
                    for (let e = 0, i = t.length; e < i + 2; e++) {
                        let n = instantiate(this.moban);
                        n.active = true;
                        let s = e - 1;
                        0 == e ? s = i - 1 : e == i + 1 && (s = 0);
                        this.initCurMobanCallBack(n, t[s]);
                        this.pageView.addPage(n);
                        this.pageView.elastic = true;
                        this._items.push(n);
                    }
                    this.pageView.scrollToPage(1, 0);
                    this.playTurningAnim();
                }
            }
            else if (1 == t.length) {
                let e = this._items[0];
                this.initCurMobanCallBack(e, t[0]);
            }
            else if (t.length > 1) {
                for (let e = 0, i = t.length; e < i + 2; e++) {
                    let n = this._items[e], s = e - 1;
                    0 == e ? s = i - 1 : e == i + 1 && (s = 0);
                    this.initCurMobanCallBack(n, t[s]);
                }
            }
        }
        else {
            this.stopTurningAnim();
            this.pageView.removeAllPages();
            Array.isArray(this.pageView.content.children) && this.pageView.content.children.length > 0 && this.pageView.content.removeAllChildren();
            let e = instantiate(this.moban);
            e.active = true;
            this.pageView.addPage(e);
            this.pageView.elastic = false;
            this._items.push(e);
        }
    }
    initCurMobanCallBack(e, t) {
        if (ToolUtils.isObjValid(e)) {
            let i = e.getChildByName("img");
            Utils.shared().updateNetImage(i, t.img, size(674, 104), (() => {
            }));
            e.getComponent(Button).clickEvents[0].customEventData = ToolUtils.toJsonString(t);
        }
    }
    playTurningAnim() {
        let e = 0 == this._banner_type ? 3 : 5, t = TweenTool.delayAct(this.pageView, this.pageTurning.bind(this), e, false);
        this.turningAction = TweenTool.sequence(this.pageView, false, null, t, null);
        this.turningAction.repeatForever();
        this.turningAction.start();
    }
    pageTurning() {
        let e = this.pageView.getPages().length, t = this.pageView.getCurrentPageIndex();
        e > 0 && this.pageView.scrollToPage(t + 1, 1);
    }
    stopTurningAnim() {
        this.turningAction && TweenTool.stopAction(this.turningAction);
    }
    onPageTurning(e, t) {
        let i = e.getPages().length, n = this.pageView.getCurrentPageIndex();
        if (i > 0) {
            let e = n - 1;
            if (0 == n ? (this.pageView.scrollToPage(i - 2, 0), e = this._bannerList.length - 1) : n == i - 1 && (this.pageView.scrollToPage(1, 0), e = 0), this.stopTurningAnim(), this.playTurningAnim(), 1 == User.shared().s_uirp_2 && sys.isObjectValid(this._bannerList) && sys.isObjectValid(this._bannerList[e])) {
                let t = [];
                t[0] = this._bannerList[e].jump_info;
                HttpManager.shared().doGetBannerShowRequest(ReportConfig.Cmd_UIBannerReport, t, ((e, t, i) => {
                }));
            }
        }
    }
    onButtonClick(e, t) {
        SoundManager.shared().playFx("click");
        try {
            let e = ToolUtils.parseJson(t);
            if (e) {
                if (!sys.isObjectValid(e.jump_info) || !sys.isObjectValid(e.jump_info.type)) {
                    return;
                }
                let t = e.jump_info.exe;
                sys.isObjectValid(t) || (t = {});
                e.jump_info.type == PushEvent.JUMP_TO_Adventrue ? t.from_source = 1 : e.jump_info.type == PushEvent.JUMP_TO_FREECASH ? t.from_source = 7 : e.jump_info.type == PushEvent.JUMP_TO_KYC_GUIDE && (t.from_source = 10);
                let i = 1;
                switch (Number(e.jump_info.type)) {
                    case PushEvent.JUMP_TO_PlayDraw:
                    case PushEvent.JUMP_TO_SuperVip:
                    case PushEvent.JUMP_TO_NOVICESTASK:
                    case PushEvent.JUMP_TO_NEW_NOVICESTASK:
                        i = 2;
                        break;
                    case PushEvent.JUMP_TO_SESSIONPACKGE:
                        i = 8;
                        break;
                    case PushEvent.JUMP_TO_LOTTERYACT:
                        i = 13;
                        break;
                    case PushEvent.JUMP_TO_Gullak:
                        i = 6;
                        break;
                    case PushEvent.JUMP_TO_DAILYTASK:
                        i = -1;
                        break;
                    case PushEvent.JUMP_TO_Treasure:
                    case PushEvent.JUMP_TO_BANKRUPTCARD:
                    case PushEvent.JUMP_TO_DAILYLOGIN:
                    case PushEvent.JUMP_TO_TREASURE_HUNT: i = 3;
                }
                let n = "ClickBanner_" + e.jump_info.type;
                if (TransferPlatform.shared().logEvent_firebase(n), 1 == this._banner_type && (e.jump_info.type != PushEvent.JUMP_TO_CASH_ROOM && e.jump_info.type != PushEvent.JUMP_TO_MATCH_ROOM && e.jump_info.type != PushEvent.JUMP_TO_PRIVATE_ROOM && e.jump_info.type != PushEvent.JUMP_TO_PRACTICE_ROOM || PushCenter.shared().pushEvent(PushEvent.OnJumpToChooseGame)), Utils.shared().doJumpLogic(e.jump_info.type, t, { isNext: false, bWithTip: true, reportEvtId: i, link_id: sys.now() }), 1 == this._banner_type) {
                    let e = ToolUtils.getIsInRoom() ? 2 : 1;
                    HttpManager.shared().doCommReportRechargeEvent(ReportConfig.Cmd_SuperVip, e, 20, sys.now(), "", 0);
                }
                User.shared().updatePayScene(PhpReportDefined.pay_scene.hall_banner);
            }
        }
        catch (e) {
        }
    }
}
