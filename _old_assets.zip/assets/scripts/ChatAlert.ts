// @ts-nocheck
// Recovered from index.js:65
import { _decorator, Button, color, instantiate, Label, Node, ScrollView, size, Sprite, SpriteFrame, UITransform, v3, Vec3 } from "cc";
import SoundManager from "./SoundManager";
import TweenTool from "./TweenTool";
import { AdapDirection } from "./Parent";
import BaseLayer from "./BaseLayer";
import User from "./User";
import Utils from "./Utils";
import i18nMgr from "./i18nMgr";
import GameConfig from "./GameConfig";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("ChatAlert")
export default class ChatAlert extends BaseLayer {
    @property(Node)
    public faceBtn: Node = null;
    @property(Node)
    public clubBtn: Node = null;
    @property(Node)
    public faceNode: Node = null;
    @property(Node)
    public faceModelNode: Node = null;
    @property(Node)
    public textBtn: Node = null;
    @property(Node)
    public textNode: Node = null;
    @property(Node)
    public textModelNode: Node = null;
    @property(Node)
    public textModelNode0: Node = null;
    @property(Node)
    public bgNode: Node = null;
    @property(ScrollView)
    public textList: ScrollView = null;
    @property(ScrollView)
    public faceList: ScrollView = null;
    @property([SpriteFrame])
    public chat_face_frame: SpriteFrame[] = [];
    @property([SpriteFrame])
    public club_face_frame: SpriteFrame[] = [];
    @property(Node)
    public rootNode: Node = null;
    public cb_face: any = null;
    public cb_text: any = null;
    public mseatid: number = 0;
    public tab_data: number = 0;
    public _showPos: any = v3(0, 0, 0);
    public chatTextTab: any[] = ["Hi all", "Bye all", "Hurry up", "Your turn", "Nice game", "Good job", "Thank you", "Oh no", "Uh...", "Oh my god", "Good luck", "I'm sorry", "let me see", "I'm waiting", "It's my time", "Bless me", "Namaste", "Saubhaagy Ho", "Jaldi", "Shaandaar Hai", "Phir Milenge", "Main Jeeta", "Aanand Le Lo"];
    public chatTextMoban: any[] = [0, 0, 0, 0, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1];
    public chatFaceCount: number = 10;
    public clubFaceCount: number = 10;
    public _bTextInit: boolean = false;
    public _bMemberShipOpen: boolean = false;
    public _chatType: number = 0;
    onLoad() {
        this.fitScreen();
        this.bIsInGame = true;
    }
    fitScreen() {
        if (GameConfig.REAL_SCREEN_WIDTH <= GameConfig.CONFIG_SCREEN_WIDTH && this.resetUiPos(this.rootNode, AdapDirection.Right, true, 1, true), ToolUtils.showFullScreen(this.node.getChildByName("pingbi")), ToolUtils.showFullScreen(this.node.getChildByName("bg").getChildByName("bg1")), ToolUtils.isPadPlatform()) {
            let t = (GameConfig.REAL_SCREEN_WIDTH - 720) / 2, e = this.bgNode.getComponent(UITransform).contentSize;
            this.bgNode.getComponent(UITransform).setContentSize(size(e.width, e.height + t));
            e = this.textList.getComponent(UITransform).contentSize;
            this.textList.getComponent(UITransform).setContentSize(size(e.width, e.height + t));
            this.faceList.getComponent(UITransform).setContentSize(size(e.width, e.height + t));
        }
    }
    setChatType(t) {
        this._chatType = t;
    }
    start() {
        super.start();
        this.updateMultipleList();
    }
    startShowAnim() {
        this.node.position = v3(480, 0);
        let t = v3(0, 0, 0);
        TweenTool.moveTo(this.node, 0.15, t, "fade", true, (() => {
            this.node.setPosition(t);
        }));
    }
    setFaceCallback(t) {
        this.cb_face = t;
    }
    setTextCallback(t) {
        this.cb_text = t;
    }
    setClientId(t) {
        this.mseatid = t;
    }
    onClickByText(t, e) {
        let i = this.chatTextTab.indexOf(e);
        this.cb_text(e, i);
        ToolUtils.isObjValid(this.node) && this.node.destroy();
    }
    onClickByFace(t, e) {
        e >= 50 && !this._bMemberShipOpen ? Utils.shared().showToast(i18nMgr.shared().getValueByKey("rummy_main.club_face_fail"), 2) : (this.cb_face(e), ToolUtils.isObjValid(this.node) && this.node.destroy());
    }
    onClickClose(t, e) {
        SoundManager.shared().playFx("click");
        let i = new Vec3;
        this.node.getPosition(i);
        let a = v3(i.x, i.y + 350, 0);
        ToolUtils.getOrientation() && (a = v3(i.x + 350, i.y, 0));
        TweenTool.moveTo(this.node, 0.15, a, "fade", true, (() => {
            ToolUtils.isObjValid(this.node) && this.node.destroy();
        }));
    }
    onClickChangeTab(t, e) {
        this.tab_data != e && (SoundManager.shared().playFx("click"), this.tab_data = e, this.showListByType(e));
    }
    showListByType(t) {
        let e = color(200, 111, 110, 255), i = color(168, 46, 60, 255), a = this.textBtn.getChildByName("icon"), o = this.faceBtn.getChildByName("icon"), n = this.clubBtn.getChildByName("icon");
        0 == t ? (a.getComponent(Sprite).color = e, o.getComponent(Sprite).color = n.getComponent(Sprite).color = i, this.textBtn.getChildByName("bg").active = false, this.faceBtn.getChildByName("bg").active = this.clubBtn.getChildByName("bg").active = true, this.faceNode.active = false, this.textNode.active = true, this.updateTextList()) : 1 == t ? (o.getComponent(Sprite).color = e, a.getComponent(Sprite).color = n.getComponent(Sprite).color = i, this.faceBtn.getChildByName("bg").active = false, this.textBtn.getChildByName("bg").active = this.clubBtn.getChildByName("bg").active = true, this.faceNode.active = true, this.textNode.active = false, this.updateFaceList()) : 2 == t && (n.getComponent(Sprite).color = e, a.getComponent(Sprite).color = o.getComponent(Sprite).color = i, this.clubBtn.getChildByName("bg").active = false, this.textBtn.getChildByName("bg").active = this.faceBtn.getChildByName("bg").active = true, this.faceNode.active = true, this.textNode.active = false, this.updateMemberShipList(), this.clubBtn.getChildByName("red_dot").active = false, ToolUtils.saveData("room_club_dot_" + User.shared().data.uid, "0"));
    }
    updateMemberShipList() {
        if (null != this.faceModelNode) {
            let t, e = this.faceNode.getChildByName("scrollView").getChildByName("view").getChildByName("content");
            e.destroyAllChildren();
            for (let i = 0; i < this.clubFaceCount; i++) {
                let a = instantiate(this.faceModelNode);
                a.getChildByName("face").getComponent(Sprite).spriteFrame = this.club_face_frame[i];
                this._bMemberShipOpen ? (a.getChildByName("face").getComponent(Sprite).color = color(255, 255, 255, 255), a.getChildByName("mask").active = a.getChildByName("lock").active = false) : (t = a.getChildByName("face").getComponent(Sprite).color, a.getChildByName("face").getComponent(Sprite).color = color(t.r, t.g, t.b, 0.5 * t.a), a.getChildByName("mask").active = a.getChildByName("lock").active = true);
                a.getComponent(Button).clickEvents[0].customEventData = String(50 + i);
                a.active = true;
                e.addChild(a);
            }
        }
    }
    updateFaceList() {
        if (null != this.faceModelNode) {
            let t = this.faceNode.getChildByName("scrollView").getChildByName("view").getChildByName("content");
            t.destroyAllChildren();
            for (let e = 0; e < this.chatFaceCount; e++) {
                let i = instantiate(this.faceModelNode);
                i.getChildByName("face").getComponent(Sprite).spriteFrame = this.chat_face_frame[e];
                i.getComponent(Button).clickEvents[0].customEventData = String(e);
                i.active = true;
                t.addChild(i);
            }
        }
    }
    updateTextList() {
        if (null != this.textModelNode && 0 == this._bTextInit) {
            let t = this.textNode.getChildByName("scrollView").getChildByName("view").getChildByName("content");
            t.destroyAllChildren();
            let e = this.chatTextTab.length;
            for (let i = 0; i < e; i++) {
                let e = instantiate(this.textModelNode);
                e.getChildByName("text").getComponent(Label).string = this.chatTextTab[i];
                e.getComponent(Button).clickEvents[0].customEventData = this.chatTextTab[i];
                e.active = true;
                t.addChild(e);
            }
        }
        this._bTextInit = true;
    }
    updateMultipleList() {
        let t = this.rootNode.getChildByName("faceList"), e = this.rootNode.getChildByName("faceItem"), i = t.getChildByName("view").getChildByName("content");
        if (i.destroyAllChildren(), ToolUtils.isObjValid(e)) {
            for (let t = 0; t < this.chatFaceCount; t++) {
                let a = instantiate(e);
                a.getChildByName("face").getComponent(Sprite).spriteFrame = this.chat_face_frame[t];
                a.getComponent(Button).clickEvents[0].customEventData = String(t);
                a.active = true;
                i.addChild(a);
            }
        }
        let a = this.rootNode.getChildByName("textList"), o = this.rootNode.getChildByName("textItem"), n = a.getChildByName("view").getChildByName("content");
        n.destroyAllChildren();
        let l = null;
        if (ToolUtils.isObjValid(o)) {
            let t = this.chatTextTab.length, e = 0;
            for (let i = 0; i < t; i++) {
                let t = null;
                0 == this.chatTextMoban[i] ? (0 == e ? (l = instantiate(this.textModelNode0), l.active = true, n.addChild(l), t = l.getChildByName("item0"), e++) : 1 == e && ToolUtils.isObjValid(l) && (t = l.getChildByName("item1"), e = 0), ToolUtils.isObjValid(t) && (t.getChildByName("text").getComponent(Label).string = this.chatTextTab[i], t.getComponent(Button).clickEvents[0].customEventData = this.chatTextTab[i])) : (t = instantiate(o), t.getChildByName("text").getComponent(Label).string = this.chatTextTab[i], t.getComponent(Button).clickEvents[0].customEventData = this.chatTextTab[i], t.active = true, n.addChild(t));
            }
        }
    }
    setLandscapeShow() {
        ToolUtils.getOrientation() || this.node.setRotationFromEuler(v3(0, 0, -90));
    }
    setTidKey(t) {
        this.tid_key = t;
    }
}
