// @ts-nocheck
// Recovered from index.js:357
import { _decorator, Button, color, director, instantiate, isValid, Label, Layers, Node, Prefab, ScrollView, Sprite, SpriteFrame, sys, UITransform, v3 } from "cc";
import Utils from "./Utils";
import SoundManager from "./SoundManager";
import HttpManager from "./HttpManager";
import TableViewUtils from "./TableViewUtils";
import { walletPayDetails } from "./walletPayDetails";
import "./TweenTool";
import i18nMgr from "./i18nMgr";
import PushCenter from "./PushCenter";
import GameConfig from "./GameConfig";
import User from "./User";
import BaseLayer from "./BaseLayer";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("PurseHistory")
export class PurseHistory extends BaseLayer {
    public TAG: string = "PurseHistory";
    @property(Node)
    public topRoot: Node = null;
    @property(Node)
    public date_siftRoot: Node = null;
    @property(Node)
    public mode_siftRoot: Node = null;
    @property(Node)
    public rummySift: Node = null;
    @property(Node)
    public depositSift: Node = null;
    @property([SpriteFrame])
    public filterSelect_Imgs: SpriteFrame[] = [];
    @property([SpriteFrame])
    public timeSelect_Imgs: SpriteFrame[] = [];
    @property([SpriteFrame])
    public btn_Imgs: SpriteFrame[] = [];
    @property(Node)
    public timeBtnList: Node = [];
    @property(Node)
    public modeBtnList: Node = [];
    @property(Prefab)
    public walletPayPre: Prefab = null;
    @property(Node)
    public walletHisMoban: Node = null;
    @property(ScrollView)
    public scollview: ScrollView = null;
    @property(Node)
    public nodataIC: Node = null;
    public TimeTag: number = 7;
    public TransactionTag: any[] = [0];
    public day: number = 0;
    public month: number = 0;
    public year: number = 0;
    public clickTimeType: number = 0;
    public sdate: string = "";
    public edate: string = "";
    public walletTabView: any = null;
    public walletData: any[] = [];
    public lastWalletData_md5: any = null;
    public lastid: number = 0;
    public page: number = 0;
    public callback: any = null;
    public isRequest: boolean = false;
    public scollToTop: boolean = false;
    public curTimeTag: any = -1;
    public curTransactionTag: any[] = [0];
    public sendHttpNum: number = 0;
    public historyType: number = 0;
    public menuList: any[] = [];
    public subMenuArr: any[] = [];
    public sift_dibu: number = 20;
    public sift_dingbu: number = 30;
    public _startY: number = 0;
    public _closeAct: any = null;
    public _startAct: any = null;
    public siftBgHeight: number = 748;
    public _bRummySelect: boolean = false;
    public _bDepositSelect: boolean = false;
    public select_color: any = color(151, 0, 0);
    setHistoryType(t) {
        this.historyType = t;
    }
    onLoad() {
        this.initTime();
        Utils.shared().hideLoading();
        this.fitScreen();
        this.fitLuckyTheme();
    }
    fitLuckyTheme() {
        0 != GameConfig.NATIVE_GAME_APP_TYPE && (this.select_color = color(38, 59, 152, 255), this.topRoot.getChildByName("top_bg").getComponent(Sprite).color = color(12, 26, 60));
    }
    start() {
        super.start();
        Utils.shared().showLoading(5, true, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3);
        }));
    }
    listenWalletHistoryCallback(t, e, i) {
        if (ToolUtils.isObjValid(this.node) && (this.isRequest = false), 0 != e.length) {
            if (200 != i) {
                Utils.shared().hideLoading();
                alert("The login timed out, please try again");
            }
            else {
                let t = ToolUtils.parseJson(e);
                0 == t.ret && ToolUtils.isObjValid(this.node) && (User.shared().walletData_history = t, this.Uishow(t));
            }
        }
        else {
            Utils.shared().hideLoading();
        }
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().removeListenersByTag(this);
        this.unscheduleAllCallbacks();
    }
    onBackView() {
        ToolUtils.isObjValid(this.node) && (User.shared().walletData_history = null, 0 == this.historyType && PushCenter.shared().pushEvent(GameConfig.Update_Wallet), this.callback && this.callback(), this.node.destroy());
    }
    reset() {
        this.initTime();
        this.TimeTag = 7;
        this.TransactionTag = [0];
        this.curTimeTag = -1;
        this.curTransactionTag = [0];
        for (let t = 0; t < this.timeBtnList.length; t++) {
            let e = this.timeBtnList[t];
            t == this.TimeTag ? e.getChildByName("bg").getComponent(Sprite).spriteFrame = this.timeSelect_Imgs[1] : e.getChildByName("bg").getComponent(Sprite).spriteFrame = this.timeSelect_Imgs[0];
        }
        this.refreshModelStatus();
    }
    initTime() {
        let t = new Date, e = 0, i = 0, s = 0;
        e = t.getFullYear();
        i = t.getMonth() + 1;
        s = t.getDate();
        this.edate = e.toString() + String("0" + i).slice(-2) + String("0" + s).slice(-2);
        let a = t.getTime();
        a -= 518400000;
        t.setTime(a);
        e = t.getFullYear();
        i = t.getMonth() + 1;
        s = t.getDate();
        this.sdate = e.toString() + String("0" + i).slice(-2) + String("0" + s).slice(-2);
    }
    showSelectView(t = null) {
    }
    initModeSift(t) {
        let e = 0;
        if (Array.isArray(t)) {
            e = t.length;
            for (let i, s = 0; s < e; s++) {
                i = this.modeBtnList[s];
                ToolUtils.isObjValid(i) && (i.active = true, sys.isObjectValid(t[s]) && (i.getChildByName("wz").getComponent(Label).string = t[s].name, i.getComponent(Button).clickEvents[0].customEventData = "" + s, t[s].menu == this.subMenuArr[0] ? this.curTransactionTag[s] = this._bRummySelect ? 1 : 0 : t[s].menu == this.subMenuArr[1] && (this.curTransactionTag[s] = this._bDepositSelect ? 1 : 0), 1 == ToolUtils.isSafeNumber(this.curTransactionTag[s]) ? (i.getChildByName("bg").getComponent(Sprite).spriteFrame = this.timeSelect_Imgs[1], i18nMgr.shared().changeLabelFont(i.getChildByName("wz").getComponent(Label), true)) : (i.getChildByName("bg").getComponent(Sprite).spriteFrame = this.timeSelect_Imgs[0], i18nMgr.shared().changeLabelFont(i.getChildByName("wz").getComponent(Label), false))));
            }
        }
        for (let t, i = e, s = this.modeBtnList.length; i < s; i++) {
            t = this.modeBtnList[i];
            ToolUtils.isObjValid(t) && (t.active = false);
        }
    }
    refreshModelStatus() {
        let t = this.topRoot.getChildByName("mode_sift_btn");
        if (this.curTransactionTag.includes(1)) {
            t.getChildByName("arrow").getComponent(Sprite).color = this.select_color;
            t.getChildByName("wz").getComponent(Label).color = this.select_color;
            t.getChildByName("ico").getComponent(Sprite).spriteFrame = this.filterSelect_Imgs[1];
            i18nMgr.shared().changeLabelFont(t.getChildByName("wz").getComponent(Label), true);
            for (let e = 0; e < this.curTransactionTag.length; e++) {
                if (1 == this.curTransactionTag[e]) {
                    t.getChildByName("wz").getComponent(Label).string = this.menuList[e].name;
                    break;
                }
            }
        }
        else {
            t.getChildByName("ico").getComponent(Sprite).spriteFrame = this.filterSelect_Imgs[0];
            t.getChildByName("arrow").getComponent(Sprite).color = color(51, 51, 51);
            t.getChildByName("wz").getComponent(Label).color = color(51, 51, 51);
            i18nMgr.shared().changeLabelFont(t.getChildByName("wz").getComponent(Label), false);
            t.getChildByName("wz").getComponent(Label).string = "Tran type";
        }
    }
    updateTime() {
        let t = new Date, e = 0, i = 0, s = 0;
        if (7 == this.curTimeTag) {
            this.initTime();
        }
        else {
            if (-1 == this.curTimeTag) {
                return;
            }
            {
                let a = [0, 1, 2, 3, 4, 5, 6, 6], l = t.getTime();
                l -= 86400 * a[this.curTimeTag] * 1000;
                t.setTime(l);
                e = t.getFullYear();
                i = t.getMonth() + 1;
                s = t.getDate();
                this.sdate = e.toString() + String("0" + i).slice(-2) + String("0" + s).slice(-2);
                this.edate = this.sdate;
            }
        }
    }
    setTimeByTag(t) {
        let e = new Date, i = 0, s = 0, a = 0;
        if (7 == t) {
            this.initTime();
        }
        else {
            if (-1 == t) {
                return;
            }
            {
                let l = [0, 1, 2, 3, 4, 5, 6, 7], n = e.getTime();
                n -= 86400 * (l[t] - 1) * 1000;
                e.setTime(n);
                i = e.getFullYear();
                s = e.getMonth() + 1;
                a = e.getDate();
                this.sdate = i.toString() + String("0" + s).slice(-2) + String("0" + a).slice(-2);
                this.edate = this.sdate;
            }
        }
    }
    requestWallet(t, e = "0", i = "0", s = 0, a = 2, l = 0) {
        this.walletTabView.stopAutoScroll();
        this.sendHttpNum = this.sendHttpNum + 1;
        HttpManager.shared().doReportWalletGetList(t, this.listenWalletCallback.bind(this), e, i, s, a, l);
    }
    listenWalletCallback(t, e, i) {
        if (Utils.shared().hideLoading(), 0 != e.length) {
            if (200 != i) {
                alert("The login timed out, please try again");
            }
            else {
                let t = ToolUtils.parseJson(e);
                if (0 == t.ret && (this.sendHttpNum <= 1 && (1 == this.historyType ? User.shared().walletData_bonus = t : User.shared().walletData_history = t, sys.isObjectValid(t.data.menuList) && (this.menuList = t.data.menuList, this.subMenuArr = t.data.menu)), isValid(this))) {
                    if (this.lastid = Number(t.data.lastid), Number.isNaN(this.lastid) && (this.lastid = 0), null == t.data.page ? this.page = 0 : this.page = t.data.page, null == t.data.list && this.walletData.length < 1) {
                        this.walletData = [];
                        this.nodataIC.active = true;
                    }
                    else if (null != t.data.list) {
                        for (let e = 0; e < t.data.list.length; e++) {
                            this.walletData.push(t.data.list[e]);
                        }
                        this.nodataIC.active = false;
                    }
                    let e = true;
                    if (sys.isObjectValid(this.lastWalletData_md5)) {
                        let t = ToolUtils.jsonToMd5(this.walletData);
                        this.lastWalletData_md5 == t && (e = false);
                    }
                    e && this.refreshWallet();
                }
            }
        }
    }
    Uishow(t, e = null) {
        if (sys.isObjectValid(e) && (this.callback = e), sys.isObjectValid(t) || Utils.shared().showLoading(5, true, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3);
        })), sys.isObjectValid(t) && sys.isObjectValid(t.data.menuList) && (this.menuList = t.data.menuList, this.subMenuArr = t.data.menu, this.initModeSift(this.menuList), Utils.shared().hideLoading()), this.reset(), isValid(this)) {
            if (sys.isObjectValid(t)) {
                if (this.lastid = Number(t.data.lastid), Number.isNaN(this.lastid) && (this.lastid = 0), null == t.data.page ? this.page = 0 : this.page = t.data.page, null == t.data.list && this.walletData.length < 1) {
                    this.walletData = [];
                    this.nodataIC.active = true;
                }
                else if (null != t.data.list) {
                    for (let e = 0; e < t.data.list.length; e++) {
                        this.walletData.push(t.data.list[e]);
                    }
                    this.nodataIC.active = false;
                }
            }
            let e = [this.walletHisMoban];
            this.walletTabView = this.node.addComponent(TableViewUtils);
            let i = this.walletHisMoban.getComponent(UITransform).height;
            this.walletTabView.init([], this.scollview.node, e, this.initCurMobanCallBack.bind(this), 20, i, this.scrollRefreshCallBack.bind(this));
            this.refreshWallet();
            this.walletData = [];
            1 == this.historyType ? this.requestWallet("0", this.sdate, this.edate, 0, 6, 1) : this.requestWallet("0", this.sdate, this.edate, 0, 2, 1);
        }
    }
    button_click(t, e) {
        if (SoundManager.shared().playFx("click"), this.scollToTop = false, "close" == e) {
            this.onBackView();
        }
        else if ("sift" == e) {
            this.initSifeTimeLabels();
            this.initModeSift(this.menuList);
            this.timeButton_click(null, this.curTimeTag, false);
            this.transactionButton_click(null, this.curTransactionTag, false);
            this.updateTimeSifeBtnSp();
            this._startAct || this.showSelectView();
        }
        else if ("time_sift" == e) {
            if (this.setTimeByTag(this.curTimeTag), this.initSifeTimeLabels(), !this.date_siftRoot.active) {
                let t = this.date_siftRoot.getChildByName("bgview");
                t.setPosition(v3(0, -500));
                this.date_siftRoot.active = true;
                let e = 0;
                sys.getSafeAreaRect().y > 0 && (e = -sys.getSafeAreaRect().y);
                let i = { startPos: v3(0, -500), endPos: v3(0, e) };
                ToolUtils.showPushAnim(t, 2, (() => {
                    t.setPosition(v3(0, e));
                }), i);
            }
            this.date_siftRoot.active = true;
        }
        else if ("mode_sift" == e) {
            for (let t = 0, e = this.curTransactionTag.length; t < e; t++) {
                this.TransactionTag[t] = ToolUtils.isSafeNumber(this.curTransactionTag[t]);
            }
            if (this.initModeSift(this.menuList), !this.mode_siftRoot.active) {
                let t = this.mode_siftRoot.getChildByName("bgview");
                t.setPosition(v3(0, -500));
                this.mode_siftRoot.active = true;
                let e = 0;
                sys.getSafeAreaRect().y > 0 && (e = -sys.getSafeAreaRect().y);
                let i = { startPos: v3(0, -500), endPos: v3(0, e) };
                ToolUtils.showPushAnim(t, 2, (() => {
                    t.setPosition(v3(0, e));
                }), i);
            }
            this.mode_siftRoot.active = true;
        }
        else if ("close_mode" == e || "cancel_mode" == e) {
            this.mode_siftRoot.active = false;
        }
        else if ("close_time" == e || "cancel" == e) {
            this.date_siftRoot.active = false;
        }
        else if ("clear_time" == e) {
            let t = -1;
            this.TimeTag = t;
            for (let e = 0; e < this.timeBtnList.length; e++) {
                let i = this.timeBtnList[e];
                i.getChildByName("bg").getComponent(Sprite).spriteFrame = e == t ? this.timeSelect_Imgs[1] : this.timeSelect_Imgs[0];
            }
            this.setTimeByTag(t);
        }
        else if ("filter_rummy" == e) {
            this._bRummySelect = !this._bRummySelect;
            this.updateRummySelect();
            this._bDepositSelect && (this._bDepositSelect = !this._bDepositSelect, this.updateDepositSelect());
            for (let t = 0, e = this.curTransactionTag.length; t < e; t++) {
                this.curTransactionTag[t] = 0;
            }
            this.refreshModelStatus();
            this.walletData = [];
            this.lastid = 0;
            this.requestWalletList();
        }
        else if ("filter_deposit" == e) {
            this._bDepositSelect = !this._bDepositSelect;
            this._bRummySelect && (this._bRummySelect = !this._bRummySelect, this.updateRummySelect());
            this.updateDepositSelect();
            for (let t = 0, e = this.curTransactionTag.length; t < e; t++) {
                this.curTransactionTag[t] = 0;
            }
            this.refreshModelStatus();
            this.walletData = [];
            this.lastid = 0;
            this.requestWalletList();
        }
        else if ("confirm" == e) {
            this.scollToTop = true;
            this.date_siftRoot.active = false;
            this.walletData = [];
            this.lastid = 0;
            this.curTimeTag = this.TimeTag;
            this.updateTime();
            this.updateTimeSifeBtnSp();
            this.requestWalletList();
        }
        else if ("confirm_mode" == e) {
            this.scollToTop = true;
            this.mode_siftRoot.active = false;
            this.curTimeTag = this.TimeTag;
            this.updateTime();
            for (let t = 0, e = this.TransactionTag.length; t < e; t++) {
                this.curTransactionTag[t] = ToolUtils.isSafeNumber(this.TransactionTag[t]);
            }
            this._bDepositSelect = false;
            this._bRummySelect = false;
            this.updateRummySelect();
            this.updateDepositSelect();
            this.refreshModelStatus();
            this.walletData = [];
            this.lastid = 0;
            this.requestWalletList();
        }
        else {
            "kefu" == e ? Utils.shared().showContactUsView() : "help" == e && Utils.shared().showWalletHelpView(1);
        }
    }
    requestWalletList() {
        let t = "";
        this._bRummySelect && sys.isObjectValid(this.subMenuArr[0]) && (t.length > 0 && (t += ","), t += "" + this.subMenuArr[0]);
        this._bDepositSelect && sys.isObjectValid(this.subMenuArr[1]) && (t.length > 0 && (t += ","), t += "" + this.subMenuArr[1]);
        for (let e = 0, i = this.menuList.length; e < i; e++) {
            1 == ToolUtils.isSafeNumber(this.curTransactionTag[e]) && this.menuList[e].menu != this.subMenuArr[0] && this.menuList[e].menu != this.subMenuArr[1] && (t.length > 0 && (t += ","), t += "" + this.menuList[e].menu);
        }
        1 == this.historyType ? this.requestWallet(t, this.sdate, this.edate, this.lastid, 6, 1) : this.requestWallet(t, this.sdate, this.edate, this.lastid, 2, 1);
    }
    updateRummySelect() {
        this._bRummySelect ? (this.rummySift.getChildByName("ico").getComponent(Sprite).spriteFrame = this.filterSelect_Imgs[1], this.rummySift.getChildByName("wz").getComponent(Label).color = this.select_color, i18nMgr.shared().changeLabelFont(this.rummySift.getChildByName("wz").getComponent(Label), true)) : (this.rummySift.getChildByName("ico").getComponent(Sprite).spriteFrame = this.filterSelect_Imgs[0], this.rummySift.getChildByName("wz").getComponent(Label).color = color(51, 51, 51), i18nMgr.shared().changeLabelFont(this.rummySift.getChildByName("wz").getComponent(Label), false));
    }
    updateDepositSelect() {
        this._bDepositSelect ? (this.depositSift.getChildByName("ico").getComponent(Sprite).spriteFrame = this.filterSelect_Imgs[1], this.depositSift.getChildByName("wz").getComponent(Label).color = this.select_color, i18nMgr.shared().changeLabelFont(this.depositSift.getChildByName("wz").getComponent(Label), true)) : (this.depositSift.getChildByName("ico").getComponent(Sprite).spriteFrame = this.filterSelect_Imgs[0], this.depositSift.getChildByName("wz").getComponent(Label).color = color(51, 51, 51), i18nMgr.shared().changeLabelFont(this.depositSift.getChildByName("wz").getComponent(Label), false));
    }
    initSifeTimeLabels() {
        for (let t = 2, e = this.timeBtnList.length - 1; t < e; t++) {
            let e = new Date, i = this.timeBtnList[t].getChildByName("wz"), s = 0, a = 0, l = e.getTime() - 86400 * t * 1000;
            e.setTime(l);
            s = e.getMonth() + 1;
            a = e.getDate();
            i.getComponent(Label).string = String("0" + a).slice(-2) + "/" + String("0" + s).slice(-2);
        }
    }
    updateTimeSifeBtnSp() {
        let t = this.topRoot.getChildByName("time_sift_btn");
        -1 == this.curTimeTag || 7 == this.curTimeTag ? (t.getChildByName("ico").getComponent(Sprite).spriteFrame = this.filterSelect_Imgs[0], t.getChildByName("wz").getComponent(Label).color = color(51, 51, 51), t.getChildByName("arrow").getComponent(Sprite).color = color(51, 51, 51), i18nMgr.shared().changeLabelFont(t.getChildByName("wz").getComponent(Label), false), t.getChildByName("wz").getComponent(Label).string = "Date") : (t.getChildByName("ico").getComponent(Sprite).spriteFrame = this.filterSelect_Imgs[1], t.getChildByName("wz").getComponent(Label).color = this.select_color, t.getChildByName("arrow").getComponent(Sprite).color = this.select_color, i18nMgr.shared().changeLabelFont(t.getChildByName("wz").getComponent(Label), true), ToolUtils.isObjValid(this.timeBtnList[this.curTimeTag]) && (t.getChildByName("wz").getComponent(Label).string = this.timeBtnList[this.curTimeTag].getChildByName("wz").getComponent(Label).string));
    }
    timeButton_click(t, e, i = true) {
        let s = Number(e);
        this.TimeTag == s ? (this.TimeTag = -1, this.initTime()) : this.TimeTag = s;
        i && SoundManager.shared().playFx("click");
        for (let t, e = 0, i = this.timeBtnList.length; e < i; e++) {
            t = this.timeBtnList[e];
            e == this.TimeTag ? (t.getChildByName("bg").getComponent(Sprite).spriteFrame = this.timeSelect_Imgs[1], i18nMgr.shared().changeLabelFont(t.getChildByName("wz").getComponent(Label), true)) : (t.getChildByName("bg").getComponent(Sprite).spriteFrame = this.timeSelect_Imgs[0], i18nMgr.shared().changeLabelFont(t.getChildByName("wz").getComponent(Label), false));
        }
        this.setTimeByTag(this.TimeTag);
    }
    transactionButton_click(t, e, i = true) {
        let s = Number(e);
        i && SoundManager.shared().playFx("click");
        for (let t = 0, e = this.TransactionTag.length; t < e; t++) {
            t != s && (this.TransactionTag[t] = 0, this.modeBtnList[t].getChildByName("bg").getComponent(Sprite).spriteFrame = this.timeSelect_Imgs[0], i18nMgr.shared().changeLabelFont(this.modeBtnList[t].getChildByName("wz").getComponent(Label), false));
        }
        this.TransactionTag[s] = (ToolUtils.isSafeNumber(this.TransactionTag[s]) + 1) % 2;
        ToolUtils.isObjValid(this.modeBtnList[s]) && (1 == this.TransactionTag[s] ? (this.modeBtnList[s].getChildByName("bg").getComponent(Sprite).spriteFrame = this.timeSelect_Imgs[1], i18nMgr.shared().changeLabelFont(this.modeBtnList[s].getChildByName("wz").getComponent(Label), true)) : (this.modeBtnList[s].getChildByName("bg").getComponent(Sprite).spriteFrame = this.timeSelect_Imgs[0], i18nMgr.shared().changeLabelFont(this.modeBtnList[s].getChildByName("wz").getComponent(Label), false)));
    }
    initCurMobanCallBack(t, e) {
        // Bind recycled rows to this controller and their current record explicitly.
        t.layer = Layers.Enum.UI_2D;
        t.getComponent(Button).clickEvents = [];
        if (t._walletClick) t.off(Button.EventType.CLICK, t._walletClick, this);
        t._walletClick = event => this.mobanCallBack(event, e);
        t.on(Button.EventType.CLICK, t._walletClick, this);
        null != e && (t.active = true, sys.isObjectValid(e.id) && (t.getChildByName("tid").getComponent(Label).string = `Transacton ID:${e.id}`), sys.isObjectValid(e.date) && (t.getChildByName("time").getComponent(Label).string = e.date), sys.isObjectValid(e.name) && (t.getChildByName("details").getComponent(Label).string = e.name), Number(e.alter) >= 0 ? t.getChildByName("before").getComponent(Label).string = "+₹" + ToolUtils.parse_double(e.alter) : t.getChildByName("before").getComponent(Label).string = "-₹" + ToolUtils.parse_double(Math.abs(Number(e.alter)) + ""));
    }
    scrollRefreshCallBack() {
        0 != this.page && (this.requestWalletList(), this.scollToTop = false);
    }
    refreshWallet() {
        this.lastWalletData_md5 = ToolUtils.jsonToMd5(this.walletData);
        this.walletTabView.reloadData(this.walletData, this.scollToTop);
    }
    mobanCallBack(t, e) {
        if (this.isRequest || !e || !e.id) return;
        SoundManager.shared().playFx("click");
        this.isRequest = true;
        Utils.shared().showLoading(10, false, () => { this.isRequest = false; });
        HttpManager.shared().doReportWalletGetOne(e.id, this.listenWalletPayCallback.bind(this));
    }
    listenWalletPayCallback(t, e, i) {
        if (Utils.shared().hideLoading(), this.isValid && (this.isRequest = false), 0 != e.length) {
            if (200 != i) {
                alert("The login timed out, please try again");
            }
            else {
                let t = ToolUtils.parseJson(e);
                0 == t.ret && this.isValid && this.showWalletPayDetails(t);
            }
        }
    }
    showWalletPayDetails(t) {
        let e = director.getScene().getChildByName("Canvas"), i = e.getChildByName("walletPayDetails");
        if (!i || !i.isValid) {
            let i = instantiate(this.walletPayPre);
            i.name = "walletPayDetails";
            e.addChild(i);
            this.node.active = false;
            i.getComponent(walletPayDetails).init(t, (() => {
                ToolUtils.isObjValid(this.node) && (this.node.active = true);
            }));
        }
    }
    fitScreen() {
        ToolUtils.showFullScreen(this.date_siftRoot.getChildByName("mask"));
        ToolUtils.showFullScreen(this.mode_siftRoot.getChildByName("mask"));
    }
}
