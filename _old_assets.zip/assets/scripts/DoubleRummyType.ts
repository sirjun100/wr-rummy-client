// @ts-nocheck
// Recovered from index.js:103
import { _decorator, Label, sys } from "cc";
import i18nMgr from "./i18nMgr";
import User from "./User";
import SoundManager from "./SoundManager";
import BaseLayer from "./BaseLayer";
import PushCenter from "./PushCenter";
import GameConfig from "./GameConfig";
import PushEvent from "./PushEvent";
import { ToolUtils } from "./ToolUtils";
const { ccclass } = _decorator;
@ccclass("DoubleRummyType")
export class DoubleRummyType extends BaseLayer {
    public rootNode: any = null;
    public _callback: any = null;
    public _infoStr: string = "";
    public _min_entry: number = 0;
    public cur_money: number = 0;
    public _isHelp: boolean = false;
    public game_type: number = 0;
    start() {
        super.start();
        ToolUtils.showFullScreen(this.node.getChildByName("mask"));
        for (let t = 1; t <= 3; t++) {
            this.node.getChildByName("node" + t).active = false;
        }
        this._isHelp ? this.rootNode = this.node.getChildByName("node3") : ToolUtils.getOrientation() ? this.rootNode = this.node.getChildByName("node2") : this.rootNode = this.node.getChildByName("node1");
        this.rootNode.active = true;
        ToolUtils.startShowAnim(this.rootNode);
        this.rootNode.getChildByName("info") && (this.rootNode.getChildByName("info").getComponent(Label).string = this._infoStr);
        0 == this.game_type ? (this.cur_money = User.shared().data.money, PushCenter.shared().addListener(GameConfig.Update_Money, (t => {
            ToolUtils.isObjValid(this.node) && this.cur_money != User.shared().data.money && (this.cur_money = User.shared().data.money, this.updateStartBtnState());
        }), this)) : 3 == this.game_type && (this.cur_money = User.shared().data.money_exe, PushCenter.shared().addListener(PushEvent.UpdatePractiseGold, (t => {
            ToolUtils.isObjValid(this.node) && this.cur_money != User.shared().data.money_exe && (this.cur_money = User.shared().data.money_exe, this.updateStartBtnState());
        }), this));
        this.updateStartBtnState();
    }
    updateStartBtnState() {
        let t = false;
        0 == this.game_type ? User.shared().data.money >= this._min_entry && (t = true) : 3 == this.game_type && User.shared().data.money_exe >= this._min_entry && (t = true);
        let e = this.rootNode.getChildByName("btn_start");
        e && (e.active = t);
        let s = this.rootNode.getChildByName("btn_addcash");
        if (s && (s.active = !t, 3 == this.game_type && i18nMgr.shared().changeLocalizedLabelKey(s.getChildByName("wz"), "choose_game.add_chips")), s && !t) {
            let t = s.getChildByName("wz");
            t && (3 == i18nMgr.shared().language ? t.getComponent(Label).fontSize = 32 : t.getComponent(Label).fontSize = 38);
        }
    }
    initParaData(t, e) {
        this._callback = e;
        sys.isObjectValid(t) && (sys.isObjectValid(t.info) && (this._infoStr = t.info), sys.isObjectValid(t.min_entry) && (this._min_entry = t.min_entry), sys.isObjectValid(t.isHelp) && (this._isHelp = t.isHelp), sys.isObjectValid(t.game_type) && (this.game_type = t.game_type));
    }
    onButtonClick(t, e) {
        "close" == e ? (SoundManager.shared().playFx("click"), this.onBackView()) : "start" == e ? (this._callback && this._callback(e), this.onBackView()) : "addcash" == e ? this._callback && this._callback(e) : "close_di" == e && this._isHelp && (SoundManager.shared().playFx("click"), this.onBackView());
    }
    onBackView() {
        ToolUtils.isObjValid(this.node) && this.node.destroy();
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().removeListenersByTag(this);
    }
}
