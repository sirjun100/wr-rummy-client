// @ts-nocheck
// Recovered from index.js:185
import { _decorator, Button, instantiate, Node, ScrollView, size, Sprite, SpriteFrame, sys, tween, v2, v3, Vec3 } from "cc";
import BaseLayer from "./BaseLayer";
import SoundManager from "./SoundManager";
import Utils from "./Utils";
import PushCenter from "./PushCenter";
import PushEvent from "./PushEvent";
import HttpManager from "./HttpManager";
import { TLog } from "./TLog";
import User from "./User";
import { HttpRequest } from "./HttpRequestName";
import TweenTool from "./TweenTool";
import GameConfig from "./GameConfig";
import i18nMgr from "./i18nMgr";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("HappyHoli")
export class HappyHoli extends BaseLayer {
    public TAG: string = "HappyHoli";
    @property(Node)
    public rootNode: Node = null;
    @property(Node)
    public title: Node = null;
    @property(ScrollView)
    public scrollView: ScrollView = null;
    @property(Node)
    public btn_more: Node = null;
    @property(Node)
    public moban: Node = null;
    @property(SpriteFrame)
    public title_Sprite: SpriteFrame = null;
    public aid: number = 0;
    public direction: number = 0;
    public isNext: boolean = false;
    public _netNodes: Map = new Map;
    public morePos: Vec3 = new Vec3;
    public moreAction: any = null;
    public happyHoliData_md5: any = null;
    initParaData(t) {
        sys.isObjectValid(t) && (this.isNext = t.isNext, this.aid = t.id);
    }
    requestHappyHoliPageData(t) {
        HttpManager.shared().doGetCommonRequest({ aid: t }, HttpRequest.HappyHoliPage, ((t, e, i) => {
            Utils.shared().hideLoading();
            try {
                if (200 != i) {
                    alert("The login timed out, please try again");
                }
                else {
                    let t = ToolUtils.parseJson(e);
                    if (0 == t.ret) {
                        let e = !sys.isObjectValid(User.shared().happyHoliData);
                        User.shared().happyHoliData = t.data;
                        let i = true;
                        if (sys.isObjectValid(this.happyHoliData_md5)) {
                            let t = ToolUtils.jsonToMd5(User.shared().happyHoliData);
                            this.happyHoliData_md5 == t && (i = false);
                        }
                        ToolUtils.isObjValid(this.node) && (sys.isObjectValid(t.data.act_list) && t.data.act_list.length > 0 ? i && this.initView(e) : this.onBackView());
                    }
                }
            }
            catch (t) {
                TLog.printError("getHappyHoliData:", t);
            }
        }));
    }
    onLoad() {
        PushCenter.shared().addListener(PushEvent.commentDownloaderImg, (t => {
            if (ToolUtils.isObjValid(this.node) && sys.isObjectValid(User.shared().happyHoliData)) {
                if (t == User.shared().happyHoliData.act_img_list.activity_flag) {
                    let t = this.scrollView.content.children;
                    if (sys.isObjectValid(t)) {
                        for (let e = 0, i = t.length; e < i; e++) {
                            Utils.shared().updateNetImage(t[e].getChildByName("flag"), User.shared().happyHoliData.act_img_list.activity_flag, size(48, 49));
                        }
                    }
                }
                else {
                    t == User.shared().happyHoliData.act_img_list.activity_title ? Utils.shared().updateNetImage(this.rootNode.getChildByName("title"), User.shared().happyHoliData.act_img_list.activity_title, size(720, 500)) : this._netNodes.has(t) && Utils.shared().updateNetImage(this._netNodes.get(t), t);
                }
            }
        }), this);
        sys.isObjectValid(User.shared().happyHoliData) && (sys.isObjectValid(User.shared().happyHoliData.act_img_list) ? Utils.shared().updateNetImage(this.rootNode.getChildByName("title"), User.shared().happyHoliData.act_img_list.activity_title, size(720, 500)) : this.rootNode.getChildByName("title").getComponent(Sprite).spriteFrame = this.title_Sprite);
    }
    start() {
        super.start();
        ToolUtils.showFullScreen(this.node.getChildByName("mask"));
        this.startShowAnim(this.rootNode);
        this.moban.active = false;
        this.btn_more.getPosition(this.morePos);
        this.btn_more.active = false;
        sys.isObjectValid(User.shared().happyHoliData) && this.initView(true);
        sys.isObjectValid(User.shared().happyHoliData) || Utils.shared().showLoading(10, true, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
        }));
        this.requestHappyHoliPageData(this.aid);
        PushCenter.shared().addListener(GameConfig.Jump_Hall_Choose_game, (() => {
            ToolUtils.isObjValid(this.node) && this.node.destroy();
        }), this);
        PushCenter.shared().addListener(PushEvent.Update_HappyHoli, (() => {
            ToolUtils.isObjValid(this.node) && this.requestHappyHoliPageData(this.aid);
        }), this);
    }
    onDestroy() {
        super.onDestroy();
        this.stopMoreAnim();
        TweenTool.stopNodeAction(this.node);
        PushCenter.shared().removeListenersByTag(this);
        Utils.shared().hideLoading();
    }
    onEnable() {
        this.scrollView.node.on("scrolling", this.onScrollView_Scrolling, this);
    }
    onDisable() {
        this.scrollView.node.off("scrolling", this.onScrollView_Scrolling, this);
    }
    initView(t = true) {
        if (this.happyHoliData_md5 = ToolUtils.jsonToMd5(User.shared().happyHoliData), this._netNodes.clear(), sys.isObjectValid(User.shared().happyHoliData.act_img_list) ? (this.pushNetNode(this.rootNode.getChildByName("title"), User.shared().happyHoliData.act_img_list.activity_title), Utils.shared().updateNetImage(this.rootNode.getChildByName("title"), User.shared().happyHoliData.act_img_list.activity_title, size(720, 500))) : this.rootNode.getChildByName("title").getComponent(Sprite).spriteFrame = this.title_Sprite, sys.isObjectValid(User.shared().happyHoliData.act_list) && User.shared().happyHoliData.act_list.length > 0) {
            if (this.scrollView.content.children.length > User.shared().happyHoliData.act_list.length) {
                for (let t = User.shared().happyHoliData.act_list.length - 1, e = this.scrollView.content.children.length; t < e; t++) {
                    this.scrollView.content.children[t].destroy();
                }
            }
            for (let e = 0, i = User.shared().happyHoliData.act_list.length; e < i; e++) {
                let i = null;
                ToolUtils.isObjValid(this.scrollView.content.children[e]) ? i = this.scrollView.content.children[e] : (i = instantiate(this.moban), i.active = !t, this.scrollView.content.addChild(i));
                this.updateMobanView(i, e, User.shared().happyHoliData.act_list[e], t);
            }
            User.shared().happyHoliData.act_list.length > 3 ? (this.pushNetNode(this.btn_more.getChildByName("img"), User.shared().happyHoliData.act_img_list.activity_more), Utils.shared().updateNetImage(this.btn_more.getChildByName("img"), User.shared().happyHoliData.act_img_list.activity_more, size(45, 45)), t && (this.btn_more.active = false, tween(this.btn_more).delay(1.15).call((() => {
                ToolUtils.isObjValid(this.btn_more) && (this.btn_more.active = true);
            })).call((() => {
                ToolUtils.isObjValid(this.btn_more) && this.playMoreAnim();
            })).union().start())) : this.btn_more.active = false;
        }
        else {
            this.scrollView.content.removeAllChildren();
        }
    }
    playMoreAnim() {
        this.moreAction = tween(this.btn_more).repeatForever(tween(this.btn_more).delay(0.5).to(0.3, { position: v3(this.morePos.x, this.morePos.y - 15) }).to(0.3, { position: v3(this.morePos.x, this.morePos.y) }).to(0.3, { position: v3(this.morePos.x, this.morePos.y - 15) }).to(0.3, { position: v3(this.morePos.x, this.morePos.y) })).union().start();
    }
    stopMoreAnim() {
        this.moreAction && (this.moreAction.stop(), this.moreAction = null);
    }
    updateMobanView(t, e, i, a) {
        if (ToolUtils.isObjValid(t) && sys.isObjectValid(i)) {
            if (Utils.shared().updateNetImage(t.getChildByName("bg"), i.img, size(720, 200)), this.pushNetNode(t.getChildByName("bg"), i.img), Utils.shared().updateNetImage(t.getChildByName("flag"), User.shared().happyHoliData.act_img_list.activity_flag, size(48, 49)), t.getChildByName("btn_view").getComponent(Button).clickEvents[0].customEventData = i.jump_info, a) {
                if (t.active = false, e < 3) {
                    if (t.setScale(v3(0.7, 0.7)), tween(t).delay(0.4 + 0.25 * e).call((() => {
                        ToolUtils.isObjValid(t) && (t.active = true);
                    })).to(0.1, { scale: v3(1.2, 1.2, 1) }, { easing: "quadInOut" }).to(0.05, { scale: v3(1, 1, 1) }, { easing: "quadInOut" }).union().start(), 1 == i.red) {
                        let e = User.shared().happyHoliData.act_list.length;
                        User.shared().happyHoliData.act_list.length > 3 && (e = 3);
                        let i = 0.4 + 0.25 * e, a = t.getChildByName("flag");
                        a.setScale(v3(0.7, 0.7));
                        tween(a).delay(i).call((() => {
                            ToolUtils.isObjValid(t) && (a.active = true);
                        })).to(0.1, { scale: v3(1.2, 1.2, 1) }, { easing: "quadInOut" }).to(0.05, { scale: v3(1, 1, 1) }, { easing: "quadInOut" }).union().start();
                    }
                    else {
                        t.getChildByName("flag").active = false;
                    }
                }
                else {
                    tween(t).delay(0.9).call((() => {
                        ToolUtils.isObjValid(t) && (t.active = true, t.getChildByName("flag").active = 1 == i.red);
                    })).union().start();
                }
            }
            else {
                t.getChildByName("flag").active = 1 == i.red;
            }
        }
    }
    pushNetNode(t, e) {
        this._netNodes.set(e, t);
    }
    onButtonClick(t, e) {
        if (SoundManager.shared().playFx("click"), "close" == e) {
            this.onBackView();
        }
        else if ("more" == e) {
            let t = this.scrollView.getScrollOffset().y;
            if (0 == this.direction) {
                let e = 200 - Math.ceil(t) % 200;
                e < 10 && (e = 200);
                this.scrollView.scrollToOffset(v2(0, Math.ceil(t + e)), 0.5);
            }
            else {
                let e = Math.ceil(t) % 200;
                e < 10 && (e = 200);
                this.scrollView.scrollToOffset(v2(0, Math.floor(t - e)), 0.5);
            }
        }
        else {
            Utils.shared().doJumpLogic(e.type, e.exe);
        }
    }
    onScrollView_Scrolling(t) {
        ToolUtils.isObjValid(this.node) && this.moreAction && (this.stopMoreAnim(), this.btn_more.setPosition(this.morePos));
        Math.floor(this.scrollView.getScrollOffset().y) <= 0 ? (this.direction = 0, this.btn_more.getChildByName("img").setScale(v3(1, 1, 1))) : sys.isObjectValid(User.shared().happyHoliData) && sys.isObjectValid(User.shared().happyHoliData.act_list) && User.shared().happyHoliData.act_list.length > 3 && Math.ceil(this.scrollView.getScrollOffset().y) >= 200 * (User.shared().happyHoliData.act_list.length - 3) && (this.direction = 1, this.btn_more.getChildByName("img").setScale(v3(1, -1, 1)));
    }
    startShowAnim(t, e) {
        t.setScale(v3(0.2, 0.2, 0.2));
        TweenTool.scaleTo(t, 0.35, v3(1, 1, 1), "backOut", true, (() => {
            t.setScale(v3(1, 1, 1));
            e && e();
        }));
    }
    onBackView() {
        ToolUtils.isObjValid(this.node) && (this.isNext && PushCenter.shared().pushEvent(PushEvent.Update_NextPopActivity), this.node.destroy());
    }
}
