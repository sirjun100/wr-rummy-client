// @ts-nocheck
// Recovered from index.js:319
import { _decorator, sys } from "cc";
import GameConfig from "./GameConfig";
import HttpManager from "./HttpManager";
import URLConfig from "./URLConfig";
import ReportConfig from "./ReportConfig";
import PushCenter from "./PushCenter";
import PushEvent from "./PushEvent";
import { TransferPlatform } from "./TransferPlatform";
import BundleNameDefined from "./BundleNameDefined";
import { ToolUtils } from "./ToolUtils";
const { ccclass } = _decorator;
@ccclass("NetHostManager")
export default class NetHostManager {
    static _instance = null;
    public hconfig: any = {};
    public curHostQueue: any[] = [];
    public roomServerQueue: any[] = [];
    public gateReconList: any[] = [];
    public hasGainHostFinished: boolean = false;
    public gainCallback: any = null;
    static shared() : NetHostManager {
        return null == this._instance && (this._instance = new NetHostManager, this._instance.init()), this._instance;
    }
    init() {
    }
    isGainHost() {
        return this.hasGainHostFinished;
    }
    doGainNewHost(t = null, e = 10000) {
        this.hasGainHostFinished = false;
        this.gainCallback = t;
        HttpManager.shared().doGainNewHost(this.listenHostServerCallback.bind(this), e);
        HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Login, event: ReportConfig.login_evt.getGainNewHost });
        TransferPlatform.shared().logEvent_firebase(ReportConfig.login_evt.getGainNewHost);
    }
    refreshCurNetUrll() {
        0 == this.curHostQueue.length && (this.curHostQueue = [], this.curHostQueue.push(URLConfig.orginHttp_CurHttpUrl));
    }
    chooseBestTcpPortConn(t) {
        if (!t || 0 == t) {
            return -1;
        }
        let e;
        for (let i = 0, r = this.roomServerQueue.length; i < r; i++) {
            if (e = this.roomServerQueue[i], e.roomId == t) {
                return e.roomPort;
            }
        }
        return sys.isObjectValid(this.roomServerQueue[0]) && -1 == this.roomServerQueue[0].roomId && this.roomServerQueue[0].roomPort || -1;
    }
    chooseBestTcpIpConn(t) {
        if (!t || 0 == t) {
            return "-1";
        }
        let e, i = "";
        for (let r = 0, s = this.roomServerQueue.length; r < s; r++) {
            if (e = this.roomServerQueue[r], e.roomId == t) {
                if (e.ips && e.ips.length > 0) {
                    let t = ToolUtils.getRandomInt(0, e.ips.length - 1);
                    i = e.ips[t];
                }
                break;
            }
        }
        if (0 == i.length) {
            if (sys.isObjectValid(this.roomServerQueue[0]) && -1 == this.roomServerQueue[0].roomId) {
                if (this.roomServerQueue[0].ips && this.roomServerQueue[0].ips.length > 0) {
                    let t = ToolUtils.getRandomInt(0, this.roomServerQueue[0].ips.length - 1);
                    i = this.roomServerQueue[0].ips[t];
                }
                if (i.length > 0) {
                    return i;
                }
            }
            return HttpManager.shared().doGainNewHost(null), "-1";
        }
        return i;
    }
    getGameGateReconAddr() {
        if (sys.isObjectValid(this.gateReconList) && this.gateReconList.length > 0) {
            if (this.gateReconList.length > 1) {
                let t = ToolUtils.getRandomInt(0, this.gateReconList.length - 1);
                return this.gateReconList[t];
            }
            return this.gateReconList[0];
        }
        return "";
    }
    listenHostServerCallback(t, e, i) {
        if (200 == i) {
            this.hasGainHostFinished = true;
            let t = ToolUtils.parseJson(e);
            0 == t.ret && (this.parseAppStartPacketData(t.data), this.refreshCurNetUrll(), this.gainCallback && this.gainCallback(1));
        }
        else {
            404 != i ? this.gainCallback && this.gainCallback(0) : this.gainCallback && this.gainCallback(-1);
        }
    }
    parseComInfo(t) {
        if (sys.isObjectValid(t.laba_conn)) {
            let e = [];
            e.roomId = 1000;
            e.roomPort = t.laba_conn.port;
            e.ips = [];
            t.laba_conn.ips.forEach((t => {
                e.ips.push(t);
            }));
            this.roomServerQueue.push(e);
        }
        if (this.curHostQueue = [], t.host_ip && t.host_ip.length > 0 && t.host_ip.forEach((t => {
            this.curHostQueue.push(t);
        })), sys.isObjectValid(t.showGuest) && (ToolUtils.showGuest = t.showGuest, PushCenter.shared().pushEvent(PushEvent.Update_GuestLogin)), sys.isObjectValid(t.pp_url) && (ToolUtils.pp_url = t.pp_url), sys.isObjectValid(t.tos_url) && (ToolUtils.tos_url = t.tos_url), sys.isObjectValid(t.feedback_url) && (ToolUtils.loginKeFu_url = t.feedback_url, PushCenter.shared().pushEvent(PushEvent.Update_Login_Kefu)), sys.isObjectValid(t.feedback_url_type) && (ToolUtils.feedback_url_type = t.feedback_url_type), Object.prototype.hasOwnProperty.call(t, "support_enabled") && (ToolUtils.support_enabled = t.support_enabled === true || t.support_enabled === 1), sys.isObjectValid(t.cloud_http) && (HttpManager.shared().setSdkUrl(t.cloud_http), TransferPlatform.shared().setReportHost(t.cloud_http)), sys.isObjectValid(t.contact_url) && (ToolUtils.contact_url = t.contact_url), sys.isObjectValid(t.about_url) && (ToolUtils.about_url = t.about_url), sys.isObjectValid(t.gst_url) && (ToolUtils.gst_url = t.gst_url), sys.isObjectValid(t.refund_url) && (ToolUtils.refund_url = t.refund_url), sys.isObjectValid(t.responsible_url) && (ToolUtils.responsible_url = t.responsible_url), sys.isObjectValid(t.tds_policy_url) && (ToolUtils.tds_policy_url = t.tds_policy_url), sys.isObjectValid(t.feedback_mode) && (ToolUtils.feedback_mode = t.feedback_mode), sys.isObjectValid(t.feedback_data) && (ToolUtils.feedback_data = t.feedback_data), sys.isObjectValid(t.logUDP) && (URLConfig.SDK_URL2 = t.logUDP), sys.isObjectValid(t.cpp_report_url) && (URLConfig.CPP_URL = t.cpp_report_url), sys.isObjectValid(t.wss_reconnect_list) && (this.gateReconList = t.wss_reconnect_list), sys.isObjectValid(t.play_back_conn) && sys.isObjectValid(t.play_back_conn.id) && (ToolUtils.play_back_vid = t.play_back_conn.id), sys.isObjectValid(t.remote)) {
            if (ToolUtils.remoteUrlList = t.remote, sys.isObjectValid(ToolUtils.remoteUrlList.image) && ToolUtils.remoteUrlList.image.length > 0) {
                let t = ToolUtils.remoteUrlList.image;
                "MOBILE_BROWSER" == sys.platform || "DESKTOP_BROWSER" == sys.platform ? t += "web/" + BundleNameDefined.bundle_translateHindi : t += "native/" + BundleNameDefined.bundle_translateHindi;
                ToolUtils.saveData("remoteImgUrl", t);
            }
            if (sys.isObjectValid(ToolUtils.remoteUrlList.tamil) && ToolUtils.remoteUrlList.tamil.length > 0) {
                let t = ToolUtils.remoteUrlList.tamil;
                "MOBILE_BROWSER" == sys.platform || "DESKTOP_BROWSER" == sys.platform ? t += "web/" + BundleNameDefined.bundle_translateTamil : t += "native/" + BundleNameDefined.bundle_translateTamil;
                ToolUtils.saveData("remoteTamilUrl", t);
            }
            if (sys.isObjectValid(ToolUtils.remoteUrlList.urdu) && ToolUtils.remoteUrlList.urdu.length > 0) {
                let t = ToolUtils.remoteUrlList.urdu;
                "MOBILE_BROWSER" == sys.platform || "DESKTOP_BROWSER" == sys.platform ? t += "web/" + BundleNameDefined.bundle_translateUrdu : t += "native/" + BundleNameDefined.bundle_translateUrdu;
                ToolUtils.saveData("remoteUrduUrl", t);
            }
        }
        sys.isObjectValid(t.vip_data) && (ToolUtils.vip_data = t.vip_data);
        sys.isObjectValid(t.tcp_url) && ToolUtils.isSafeString(t.tcp_url).length > 0 && (URLConfig.orginHttp_tcp = t.tcp_url);
        sys.isObjectValid(t.tawk_url) && (ToolUtils.login_tawk_url = t.tawk_url);
        sys.isObjectValid(t.sw_click) && (ToolUtils.report_sw_click = t.sw_click);
        sys.isObjectValid(t.chips_model) && (GameConfig.CHIPS_MODLE = 1 == ToolUtils.isSafeNumber(t.chips_model) ? 1 : 0);
    }
    parsePacketData(t, e) {
        if (!sys.isObjectValid(ToolUtils.report_time_param.getGainNewHostEnd)) {
            let e = {};
            e.time = sys.now();
            sys.isObjectValid(t.t1) && (e.t1 = t.t1);
            sys.isObjectValid(t.t2) && (e.t2 = t.t2);
            sys.isObjectValid(t.t3) && (e.t3 = t.t3);
            ToolUtils.report_time_param.getGainNewHostEnd = e;
        }
        this.roomServerQueue = [];
        let i = [];
        sys.isObjectValid(t.data.room_ips) && t.data.room_ips.length > 0 && t.data.room_ips.forEach((t => {
            let e = parseInt(t.rid) - 1;
            i[e] = [];
            i[e].ips = t.ips;
            i[e].port = t.port;
        }));
        t.data.room_conn && t.data.room_conn.conn.length > 0 && t.data.room_conn.conn.forEach((t => {
            if (sys.isObjectValid(t.ips)) {
                let e = [];
                e.roomId = parseInt(t.id);
                e.roomPort = t.port;
                e.ips = [];
                t.ips.forEach((t => {
                    e.ips.push(t);
                }));
                this.roomServerQueue.push(e);
            }
            else if (sys.isObjectValid(t.rid)) {
                let e = parseInt(t.rid) - 1;
                if (sys.isObjectValid(i[e])) {
                    let r = [];
                    r.roomId = parseInt(t.id);
                    r.roomPort = i[e].port;
                    r.ips = [];
                    i[e].ips.forEach((t => {
                        r.ips.push(t);
                    }));
                    this.roomServerQueue.push(r);
                }
            }
        }));
        this.parseComInfo(t.data);
    }
    parseAppStartPacketData(t) {
        if (this.hasGainHostFinished = true, this.roomServerQueue = [], sys.isObjectValid(t.comm_conn) && sys.isObjectValid(t.comm_conn.port) && sys.isObjectValid(t.comm_conn.ips)) {
            let e = [];
            e.roomId = -1;
            e.roomPort = t.comm_conn.port;
            e.ips = [];
            t.comm_conn.ips.forEach((t => {
                e.ips.push(t);
            }));
            this.roomServerQueue.push(e);
        }
        sys.isObjectValid(t.tawk_url_12) && t.tawk_url_12.length > 0 && (ToolUtils.tawk_url_12 = t.tawk_url_12);
        t.target_conn && t.target_conn.length > 0 && t.target_conn.forEach((t => {
            if (sys.isObjectValid(t.id)) {
                let e = [];
                e.roomId = parseInt(t.id);
                e.roomPort = t.port;
                e.ips = [];
                t.ips.forEach((t => {
                    e.ips.push(t);
                }));
                this.roomServerQueue.push(e);
            }
        }));
        this.parseComInfo(t);
    }
}
