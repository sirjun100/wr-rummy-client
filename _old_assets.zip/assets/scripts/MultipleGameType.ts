// @ts-nocheck
// Recovered from index.js:313
import { _decorator, Label, sys } from "cc";
import i18nMgr from "./i18nMgr";
import User from "./User";
import SoundManager from "./SoundManager";
import BaseLayer from "./BaseLayer";
import PushCenter from "./PushCenter";
import GameConfig from "./GameConfig";
import PushEvent from "./PushEvent";
import { ToolUtils } from "./ToolUtils";
const { ccclass } = _decorator;
@ccclass("MultipleGameType")
export class MultipleGameType extends BaseLayer {
    public rootNode: any = null;
    public _callback: any = null;
    public _infoStr: string = "";
    public _min_entry: number = 0;
    public cur_money: number = 0;
    public _isHelp: boolean = false;
    public game_type: number = 0;
    start() {
        super.start();
        ToolUtils.showFullScreen(this.node.getChildByName("mask"));
        for (let e = 1; e <= 3; e++) {
            this.node.getChildByName("node" + e).active = false;
        }
        if (this._isHelp ? this.rootNode = this.node.getChildByName("node3") : ToolUtils.getOrientation() ? this.rootNode = this.node.getChildByName("node2") : this.rootNode = this.node.getChildByName("node1"), this.rootNode.active = true, ToolUtils.startShowAnim(this.rootNode), this.rootNode.getChildByName("info") && (this.rootNode.getChildByName("info").getComponent(Label).string = this._infoStr), this.rootNode.getChildByName("item3") && i18nMgr.shared().changeLabelLanguage(this.rootNode.getChildByName("item3").getComponent(Label), "multiple_game_type.new_drop_points", true, User.shared().points_multiple_cfg.max_lose), this.rootNode.getChildByName("desc3") && i18nMgr.shared().changeLabelLanguage(this.rootNode.getChildByName("desc3").getComponent(Label), "multiple_game_type.new_drop_points_tips", false, User.shared().points_multiple_cfg.max_lose), ToolUtils.getOrientation()) {
            if (2 == i18nMgr.shared().language && (this.rootNode.getChildByName("desc1").getComponent(Label).fontSize = 16, this.rootNode.getChildByName("desc3") && (i18nMgr.shared().changeLabelLanguage(this.rootNode.getChildByName("desc3").getComponent(Label), "multiple_game_type.new_drop_points_tips2", false, User.shared().points_multiple_cfg.max_lose), this.rootNode.getChildByName("desc3").getComponent(Label).lineHeight = 22), ToolUtils.isObjValid(this.rootNode.getChildByName("btn_start")))) {
                let e = this.rootNode.getChildByName("btn_start").getChildByName("wz");
                ToolUtils.isObjValid(e) && (e.getComponent(Label).fontSize = 24, e.getComponent(Label).lineHeight = 34);
            }
        }
        else if (2 == i18nMgr.shared().language && (this.rootNode.getChildByName("item3").getComponent(Label).fontSize = 26, ToolUtils.isObjValid(this.rootNode.getChildByName("btn_start")))) {
            let e = this.rootNode.getChildByName("btn_start").getChildByName("wz");
            ToolUtils.isObjValid(e) && (e.getComponent(Label).fontSize = 24, e.getComponent(Label).lineHeight = 34);
        }
        0 == this.game_type ? (this.cur_money = User.shared().data.money, PushCenter.shared().addListener(GameConfig.Update_Money, (e => {
            ToolUtils.isObjValid(this.node) && this.cur_money != User.shared().data.money && (this.cur_money = User.shared().data.money, this.updateStartBtnState());
        }), this)) : 3 == this.game_type && (this.cur_money = User.shared().data.money_exe, PushCenter.shared().addListener(PushEvent.UpdatePractiseGold, (e => {
            ToolUtils.isObjValid(this.node) && this.cur_money != User.shared().data.money_exe && (this.cur_money = User.shared().data.money_exe, this.updateStartBtnState());
        }), this));
        this.updateStartBtnState();
    }
    updateStartBtnState() {
        let e = false;
        0 == this.game_type ? User.shared().data.money >= this._min_entry && (e = true) : 3 == this.game_type && User.shared().data.money_exe >= this._min_entry && (e = true);
        let t = this.rootNode.getChildByName("btn_start");
        t && (t.active = e);
        let a = this.rootNode.getChildByName("btn_addcash");
        if (a && (a.active = !e, 3 == this.game_type && i18nMgr.shared().changeLocalizedLabelKey(a.getChildByName("wz"), "choose_game.add_chips")), a && !e) {
            let e = a.getChildByName("wz");
            e && (3 == i18nMgr.shared().language ? e.getComponent(Label).fontSize = 32 : e.getComponent(Label).fontSize = 38);
        }
    }
    initParaData(e, t) {
        this._callback = t;
        sys.isObjectValid(e) && (sys.isObjectValid(e.info) && (this._infoStr = e.info), sys.isObjectValid(e.min_entry) && (this._min_entry = e.min_entry), sys.isObjectValid(e.isHelp) && (this._isHelp = e.isHelp), sys.isObjectValid(e.game_type) && (this.game_type = e.game_type));
    }
    onButtonClick(e, t) {
        "close" == t ? (SoundManager.shared().playFx("click"), this.onBackView()) : "start" == t ? (this._callback && this._callback(t), this.onBackView()) : "addcash" == t ? this._callback && this._callback(t) : "close_di" == t && this._isHelp && (SoundManager.shared().playFx("click"), this.onBackView());
    }
    onBackView() {
        ToolUtils.isObjValid(this.node) && this.node.destroy();
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().removeListenersByTag(this);
    }
}
