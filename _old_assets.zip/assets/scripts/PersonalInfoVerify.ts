// @ts-nocheck
// Recovered from index.js:343
import { _decorator, EditBox } from "cc";
import Utils from "./Utils";
import User from "./User";
import HttpManager from "./HttpManager";
import SoundManager from "./SoundManager";
import i18nMgr from "./i18nMgr";
import BaseLayer from "./BaseLayer";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("PersonalInfoVerify")
export class PersonalInfoVerify extends BaseLayer {
    @property(EditBox)
    public name_tf: EditBox = null;
    @property(EditBox)
    public phone_tf: EditBox = null;
    @property(EditBox)
    public email_tf: EditBox = null;
    public _from_type: number = 0;
    button_click(t, e) {
        if (SoundManager.shared().playFx("click"), "back_btn" === e) {
            ToolUtils.isObjValid(this.node) && this.node.destroy();
        }
        else if ("assure" === e) {
            let t = this.name_tf.string;
            if (t.length < 1) {
                return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text51"), 2);
            }
            let e = this.phone_tf.string;
            if (e.length < 1) {
                return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text52"), 2);
            }
            let i = this.email_tf.string;
            if (i.length < 1) {
                return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text53"), 2);
            }
            Utils.shared().showLoading(10, false, (() => {
                Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3);
            }));
            HttpManager.shared().doPaytx(t, e, i, this.listenPayTxCallBack.bind(this));
        }
    }
    listenPayTxCallBack(t, e, i) {
        if (Utils.shared().hideLoading(), 200 !== i) {
            ;
        }
        else {
            let t = ToolUtils.parseJson(e);
            if (0 === t.ret) {
                if (ToolUtils.isObjValid(this.node)) {
                    if (1 == this._from_type) {
                        let t = { price: User.shared().bc_gold };
                        User.shared().startPay(t);
                    }
                    else {
                        this._from_type;
                    }
                }
                ToolUtils.isObjValid(this.node) && this.node.destroy();
            }
            else if (t.desc && ToolUtils.isSafeString(t.desc).length > 0) {
                let e = ToolUtils.isSafeString(t.desc);
                Utils.shared().showToast(e, 2);
            }
        }
    }
    start() {
        super.start();
        ToolUtils.adaptSafeArea(this.node.getChildByName("root"));
    }
    updateUI(t) {
        t.name && (this.name_tf.string = "" + t.name);
        t.tel_no && (this.phone_tf.string = "" + t.tel_no);
        t.email && (this.email_tf.string = "" + t.email);
        t.from_type && (this._from_type = t.from_type);
    }
}
