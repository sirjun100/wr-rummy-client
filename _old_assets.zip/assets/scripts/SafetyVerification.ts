// @ts-nocheck
// Recovered from index.js:495
import { _decorator, Button, color, EditBox, Label, LabelShadow, Node, Sprite, SpriteFrame, sys } from "cc";
import BaseLayer from "./BaseLayer";
import i18nMgr from "./i18nMgr";
import { TLog } from "./TLog";
import Utils from "./Utils";
import User from "./User";
import SoundManager from "./SoundManager";
import HttpManager from "./HttpManager";
import PushEvent from "./PushEvent";
import ReportConfig from "./ReportConfig";
import { TransferPlatform } from "./TransferPlatform";
import CommDefine from "./CommDefine";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("SafetyVerification")
export class SafetyVerification extends BaseLayer {
    @property(Node)
    public code_btnNode: Node = null;
    @property(Label)
    public codeLabel: Label = null;
    @property(EditBox)
    public phone_tf: EditBox = null;
    @property(EditBox)
    public otp_tf: EditBox = null;
    @property(Node)
    public btn_del_phone: Node = null;
    @property(Node)
    public btn_del_otp: Node = null;
    @property([SpriteFrame])
    public buttonSpriteFrames: SpriteFrame[] = [];
    @property(Button)
    public submitBtn: Button = null;
    @property(Node)
    public titleNode: Node = null;
    @property(Node)
    public tipsNode: Node = null;
    public _cb: any = null;
    public m_nReq: number = 1;
    public _tel_no: string = "";
    public _type: number = 0;
    start() {
        super.start();
        ToolUtils.showFullScreen(this.node.getChildByName("bg"));
        0 == this._type && (this.phone_tf.enabled = false);
        ToolUtils.startShowAnim(this.node.getChildByName("rootNode"));
    }
    refreshUI(e, t) {
        this._cb = t;
        this._tel_no = ToolUtils.isSafeString(e.tel_no) + "";
        this.phone_tf.string = ToolUtils.isSafeString(e.show_verify) + "";
        undefined !== e.type && (this._type = e.type);
        1 == this._type ? (i18nMgr.shared().changeLocalizedLabelKey(this.titleNode, "utlis.fb_login"), i18nMgr.shared().changeLocalizedLabelKey(this.tipsNode, "utlis.fb_bind_tip")) : 2 == this._type && (i18nMgr.shared().changeLocalizedLabelKey(this.titleNode, "utlis.apple_login"), i18nMgr.shared().changeLocalizedLabelKey(this.tipsNode, "utlis.apple_bind_tip"));
    }
    onMobileTextChanged(e, t, i) {
    }
    onMobileTextEnd(e, t, i) {
    }
    onCodeTextChanged(e, t, i) {
        this.updateOtpClearStatus();
    }
    onCodeTextEnd(e, t, i) {
        this.updateOtpClearStatus();
    }
    listenGetCodeCall(e, t, i) {
        if (Utils.shared().hideLoading(), 200 !== i) {
            ;
        }
        else {
            let e = ToolUtils.parseJson(t);
            if (0 === e.ret) {
                let t = e.data.timeout;
                User.shared().code_timeout = t;
                Utils.shared().showToast(i18nMgr.shared().getValueByKey("bind_mobile.verification_tips"), 2);
                this.unschedule(this.refreshCodeBtn);
                this.refreshCodeBtn();
                this.schedule(this.refreshCodeBtn, 1);
            }
            else {
                if (e.desc && ToolUtils.isSafeString(e.desc).length > 0) {
                    let t = ToolUtils.isSafeString(e.desc);
                    Utils.shared().showToast(t, 2);
                }
                let t = e.data.timeout;
                t && ToolUtils.isSafeNumber(t) > 0 && (User.shared().code_timeout = t, this.unschedule(this.refreshCodeBtn), this.refreshCodeBtn(), this.schedule(this.refreshCodeBtn, 1));
            }
        }
    }
    refreshCodeBtn() {
        User.shared().code_timeout = User.shared().code_timeout - 1;
        let e = this.code_btnNode.getComponent(Button), t = this.code_btnNode.getComponent(Sprite);
        User.shared().code_timeout <= 0 ? (this.unschedule(this.refreshCodeBtn), e.interactable = true, t.spriteFrame = this.buttonSpriteFrames[0], this.codeLabel.string = "OTP") : (e.interactable = false, t.spriteFrame = this.buttonSpriteFrames[1], this.codeLabel.string = `(${User.shared().code_timeout}s)`);
        this.updateButtonWzColor(e, this.codeLabel.node);
    }
    resethCodeBtn() {
        let e = this.code_btnNode.getComponent(Button), t = this.code_btnNode.getComponent(Sprite);
        this.unschedule(this.refreshCodeBtn);
        e.interactable = true;
        t.spriteFrame = this.buttonSpriteFrames[0];
        this.codeLabel.string = "OTP";
        this.updateButtonWzColor(e, this.codeLabel.node);
    }
    updateButtonWzColor(e, t) {
        sys.isObjectValid(e) && (e.interactable ? (Utils.updateLabelMaterial(t, CommDefine.gradient.btn_green), t.getComponent(LabelShadow).color = color(5, 123, 58, 255)) : (Utils.updateLabelMaterial(t, CommDefine.gradient.btn_gray), t.getComponent(LabelShadow).color = color(103, 103, 103, 255)));
    }
    updateMobileClearStatus() {
        ToolUtils.isSafeString(this.phone_tf.string).length > 0 ? this.btn_del_phone.active = true : this.btn_del_phone.active = false;
    }
    updateOtpClearStatus() {
        ToolUtils.isSafeString(this.otp_tf.string).length > 0 ? this.btn_del_otp.active = true : this.btn_del_otp.active = false;
    }
    buttonClick(e, t) {
        if (SoundManager.shared().playFx("click"), "code" === t) {
            if (!(1 != this._type && 2 != this._type || 0 !== ToolUtils.isSafeString(this._tel_no).length && 10 === ToolUtils.isSafeString(this._tel_no).length)) {
                return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("login.error_number"), 3);
            }
            let e = this._tel_no;
            Utils.shared().showLoading(10, true, (() => {
                Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3);
            }));
            HttpManager.shared().doGetMobileCode(e, 3, 1, this.listenGetCodeCall.bind(this));
        }
        else if ("submit" === t) {
            if (!(1 != this._type && 2 != this._type || 0 !== ToolUtils.isSafeString(this._tel_no).length && 10 === ToolUtils.isSafeString(this._tel_no).length)) {
                return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("login.error_number"), 3);
            }
            let e = this._tel_no, t = ToolUtils.isSafeString(this.otp_tf.string);
            if (0 == t.length) {
                return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("bind_mobile.enter_code_tips"), 2);
            }
            if (t.length < 6) {
                return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text63"), 3);
            }
            this.submitBtn.interactable = false;
            Utils.shared().showLoading(10, true, (() => {
                Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3);
            }));
            this.m_nReq += 1;
            let i = {};
            i.tel_no = e;
            i.code = t;
            i.pwdtoken = "";
            i.logintype = 3;
            1 == this._type ? (i.access_token = User.shared().access_token, i.src = "facebook") : 2 == this._type && (i.access_token = User.shared().access_token, i.src = "apple");
            HttpManager.shared().doCommonLogin(i, this.listenMobileLoginCall.bind(this), this.m_nReq);
        }
        else {
            "clearMobile" === t ? (this.phone_tf.string = "", this.phone_tf.blur(), this.updateMobileClearStatus()) : "clearOTP" === t ? (this.otp_tf.string = "", this.otp_tf.blur(), this.updateOtpClearStatus()) : "close" === t ? (this._cb && this._cb(2), this.onBackView()) : "kefu" === t && Utils.shared().doJumpLogic(PushEvent.JUMP_TO_FEEDBACK);
        }
    }
    onBackView() {
        ToolUtils.isObjValid(this.node) && this.node.destroy();
    }
    showCodeError(e) {
        ToolUtils.isSafeString(e).length > 0 && Utils.shared().showToast(ToolUtils.isSafeString(e), 3);
    }
    listenMobileLoginCall(e, t, i) {
        if (sys.isObjectValid(this.node)) {
            if (200 !== i) {
                Utils.shared().hideLoading();
                this.showCodeError(i18nMgr.shared().getValueByKey("utlis.text7"));
                this.submitBtn.interactable = true;
                HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Login, event: ReportConfig.login_evt.phoneLoginFail, err_code: "req" + i });
                TransferPlatform.shared().logEvent_firebase(ReportConfig.login_evt.tel_login_timeout);
            }
            else {
                let e = ToolUtils.parseJson(t);
                if (0 === e.ret) {
                    if (Utils.shared().hideLoading(), e.data.req_key !== this.m_nReq) {
                        return void TLog.printError("------------ login req_key error!");
                    }
                    User.shared().bind_type = this._type;
                    User.shared().loginType = "3";
                    User.shared().initLoginMsg(e);
                    let t = sys.localStorage.getItem("Datastar");
                    if (null != t && "" != t) {
                        let i = ToolUtils.parseJson(t);
                        i.length > 6 && i.pop();
                        let n = [];
                        3 == e.data.logintype && i.unshift(e.data.tel_no);
                        6 == e.data.logintype && i.unshift(e.data.account);
                        for (let e = 0, t = i.length; e < t; e++) {
                            n.indexOf(i[e]) < 0 && null != i[e] && n.push(i[e]);
                        }
                        i = n;
                        ToolUtils.saveData("Datastar", ToolUtils.toJsonString(i));
                    }
                    else {
                        let t = [], i = [];
                        3 == e.data.logintype && t.unshift(e.data.tel_no);
                        6 == e.data.logintype && t.unshift(e.data.account);
                        for (let e = 0, n = t.length; e < n; e++) {
                            i.indexOf(t[e]) < 0 && null != t[e] && i.push(t[e]);
                        }
                        t = i;
                        ToolUtils.saveData("Datastar", ToolUtils.toJsonString(t));
                    }
                    this._cb && this._cb(0);
                    this.onBackView();
                }
                else {
                    Utils.shared().hideLoading();
                    HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Login, event: ReportConfig.login_evt.phoneLoginFail, err_code: e.ret });
                    TransferPlatform.shared().logEvent_firebase(ReportConfig.login_evt.phoneLoginFail);
                    9999 === e.ret ? (User.shared().maintainMsg = e.data, User.shared().hasMaintain = true, this._cb && this._cb(1), this.onBackView()) : (ToolUtils.saveData("logintype", "-1"), ToolUtils.isSafeString(e.desc).length > 0 && Utils.shared().showToast(ToolUtils.isSafeString(e.desc), 3), this.submitBtn.interactable = true);
                }
            }
        }
    }
}
