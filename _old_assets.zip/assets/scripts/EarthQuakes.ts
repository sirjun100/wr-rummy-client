// @ts-nocheck
// Recovered from index.js:105
import { _decorator, Button, color, director, instantiate, Label, Node, ScrollView, size, Sprite, SpriteAtlas, SpriteFrame, sys, UIOpacity, UITransform, v2, v3, Vec3 } from "cc";
import BaseLayer from "./BaseLayer";
import PushCenter from "./PushCenter";
import PushEvent from "./PushEvent";
import Utils from "./Utils";
import SoundManager from "./SoundManager";
import TweenTool from "./TweenTool";
import { TLog } from "./TLog";
import User from "./User";
import ReportConfig from "./ReportConfig";
import HttpManager from "./HttpManager";
import i18nMgr from "./i18nMgr";
import GameConfig from "./GameConfig";
import { HttpRequest } from "./HttpRequestName";
import { ScrollviewUtils } from "./ScrollviewUtils";
import { ToolUtils } from "./ToolUtils";
import PhpReportDefined from "./PhpReportDefined";
const { ccclass, property } = _decorator;
@ccclass("EarthQuakes")
export class EarthQuakes extends BaseLayer {
    public TAG: string = "EarthQuakes";
    @property(Node)
    public root: Node = null;
    @property(Node)
    public outRoot: Node = null;
    @property(Node)
    public ruleNode: Node = null;
    @property(Node)
    public taskNode: Node = null;
    @property(Node)
    public taskMoban: Node = null;
    @property(Node)
    public rankNode: Node = null;
    @property(Node)
    public rankMoban: Node = null;
    @property(Node)
    public vidTabList: Node = null;
    @property([Node])
    public gameTabNodes: Node[] = [];
    @property([SpriteFrame])
    public gameTabFrames: SpriteFrame[] = [];
    @property([SpriteFrame])
    public leftTabFrames: SpriteFrame[] = [];
    @property(SpriteFrame)
    public blankFrames: SpriteFrame = null;
    @property([SpriteFrame])
    public rankIconFrames: SpriteFrame[] = [];
    @property([SpriteFrame])
    public rankTabFrames: SpriteFrame[] = [];
    @property([SpriteFrame])
    public rankAwardFrames: SpriteFrame[] = [];
    @property([SpriteFrame])
    public shuBgFrames: SpriteFrame[] = [];
    @property(Node)
    public playNowBtn: Node = null;
    @property(Node)
    public vidTabMoban: Node = null;
    @property(Node)
    public ruleTipNode: Node = null;
    @property(SpriteAtlas)
    public rewardSpriteAtlas: SpriteAtlas = null;
    public cur_max_coin: number = 0;
    public taskDataMap: Map = new Map;
    public todayRankDataMap: Map = new Map;
    public yesRankDataMap: Map = new Map;
    public gameTabWzColors: any[] = [color(255, 232, 197), color(137, 46, 15)];
    public vidTabWzColors: any[] = [color(145, 94, 48), color(255, 255, 255)];
    public rankTabWzColors: any[] = [color(188, 140, 119), color(200, 64, 11)];
    public has_reportUI: boolean = false;
    public _lastClick: number = 0;
    public _linkId: number = 0;
    public _reportScene: any = -1;
    public _initDelay: number = 0;
    public _pop_souce: number = 0;
    public _cur_vid: number = 0;
    public _best_vid: number = 0;
    public _best_target_outVid: number = 0;
    public _best_entry: number = 0;
    public _best_player: number = 0;
    public _best_flag: any = -1;
    public _source_vid: number = 0;
    public _cur_player: number = 6;
    public _source_player: number = 6;
    public _source_pool: number = 0;
    public _cur_game: number = 0;
    public _source_game: number = 6;
    public _cur_mode: number = 0;
    public _cur_rank_mode: number = 0;
    public _cur_pool: number = 0;
    public _cur_points: number = 1;
    public _cur_deals: number = 0;
    public _curEntry: number = 0;
    public _curPoint: number = 0;
    public _vidTabItemList: any[] = [];
    public _cur_vidData: any = null;
    public taskScrollViewUtils: any = null;
    public _taskItems: any[] = [];
    public rankScrollViewUtils: any = null;
    public _taskIndex: any = -1;
    public _taskSize: number = 1;
    public _has_close: boolean = false;
    public isNext: boolean = false;
    public has_next_page: number = 0;
    public cur_page: number = 1;
    public _isSendMsg: boolean = false;
    public _canPlayTaskAnim: boolean = true;
    public taskAwardIconMap: Map = new Map;
    public _rankOpen: number = 0;
    public treasureType: number = 0;
    public _lastToastIndex: any = -1;
    public reportApiName: any = ReportConfig.Cmd_TreasureHunt;
    public treasureHuntMainData_md5: any = null;
    public pClick: number = 0;
    onLoad() {
        ToolUtils.judgeIfInHall() && (this.taskScrollViewUtils = this.node.addComponent(ScrollviewUtils), this.taskScrollViewUtils.initScrollviewUtils(this.taskNode.getChildByName("taskList").getComponent(ScrollView)), this.taskScrollViewUtils.setSrollCallBack((() => {
        })));
        this.taskAwardIconMap.clear();
    }
    start() {
        super.start();
        this._canPlayTaskAnim = true;
        this._linkId = this._linkId > 0 ? this._linkId : sys.now();
        this._reportScene = this._reportScene >= 0 ? this._reportScene : ToolUtils.getIsInRoom() ? 2 : 1;
        ToolUtils.showFullScreen(this.node.getChildByName("mask"));
        ToolUtils.showFullScreen(this.ruleNode.getChildByName("mask"));
        this.taskDataMap.clear();
        this._taskItems = [];
        ToolUtils.startShowAnim(this.outRoot, null, 0);
        let t = new Vec3;
        this.outRoot.getPosition(t);
        TweenTool.moveToByFade(this.outRoot, 0.2, t, 0, 1, true);
        1 == this.treasureType && (this.reportApiName = ReportConfig.Cmd_TreasureHunt_Chip, ToolUtils.judgeIfInHall() && (this.outRoot.getChildByName("bg").getComponent(Sprite).spriteFrame = this.shuBgFrames[1]));
        this.switchGameType();
        TweenTool.delayAct(this.node, (() => {
            sys.isObjectValid(this.node) && (null !== User.shared().treasureHuntMainData ? 0 != this._best_player && 0 != this._best_vid ? this.updateTreasureHuntPage(true) : this.updateTreasureHuntPage(false) : ToolUtils.judgeIfInHall());
            ToolUtils.judgeIfInHall() && 1 == this.pClick ? User.shared().requestTreaHuntMainData(true, 0, 0, null, this.treasureType) : User.shared().requestTreaHuntMainData(true, this._cur_vid, this._cur_player, null, this.treasureType);
        }), this._initDelay, true);
        PushCenter.shared().addListener(GameConfig.Recharge, (t => {
            ToolUtils.isObjValid(this.node) && this.updateOperateBtnStatus();
        }), this);
        PushCenter.shared().addListener(PushEvent.UpdateTreaHuntMain, (t => {
            if (sys.isObjectValid(this.node) && 0 == this.treasureType) {
                let t = true;
                if (sys.isObjectValid(this.treasureHuntMainData_md5)) {
                    let e = ToolUtils.jsonToMd5(User.shared().treasureHuntMainData);
                    this.treasureHuntMainData_md5 == e && (t = false, ToolUtils.judgeIfInHall() && this._cur_player != Number(User.shared().treasureHuntMainData.cplayer) && this._cur_vid != Number(User.shared().treasureHuntMainData.cvid) && (t = true));
                }
                t && this.updateTreasureHuntPage();
            }
        }), this);
        PushCenter.shared().addListener(PushEvent.commentDownloaderImg, (t => {
            if (sys.isObjectValid(this.node) && this.taskAwardIconMap.size > 0) {
                for (const [e, i] of this.taskAwardIconMap) {
                    i == t && Utils.shared().updateNetImage(e, t, size(158, 158));
                }
            }
        }), this);
        SoundManager.shared().playFx("act_popshow");
    }
    updateTreasureHuntPage(t = false) {
        let e = User.shared().treasureHuntMainData;
        this.treasureHuntMainData_md5 = ToolUtils.jsonToMd5(e);
        this._vidTabItemList = [];
        this.taskDataMap.clear();
        this._cur_mode = 0;
        sys.isObjectValid(e.ropen) && (this._rankOpen = Number(e.ropen));
        sys.isObjectValid(e.cpool) && (this._cur_pool = Number(e.cpool));
        sys.isObjectValid(e.cdeals) && (this._cur_deals = Number(e.cdeals));
        1 == this._cur_pool || 1 == this._cur_deals ? this._cur_points = 0 : this._cur_points = 1;
        sys.isObjectValid(e.ctask) && (sys.isObjectValid(e.ctask.list) && e.ctask.list.length > 0 && this.resortTaskData(e.ctask.list), this.taskDataMap.set(String(e.cvid) + "_" + String(e.cplayer), e.ctask));
        ToolUtils.judgeIfInHall() && (this._cur_vid = Number(e.cvid), this._cur_player = Number(e.cplayer));
        this.switchGameType();
        sys.isObjectValid(e.rule) && (this.ruleTipNode.getComponent(Label).string = e.rule);
        sys.isObjectValid(e.tip) && e.tip.length > 0 && (this.outRoot.getChildByName("tip").getComponent(Label).string = e.tip);
        this.updateVidTabList();
        this.changePlayerTab(this._cur_player);
        this.scrollTabListtoTargetVid(this._cur_vid);
        this.changePageMode(0);
        this.requestTaskData();
        this.has_reportUI || (this.has_reportUI = true, HttpManager.shared().doCommReportRechargeEvent(this.reportApiName, this._reportScene, 5, this._linkId, "", 0));
    }
    resortTaskData(t) {
        ToolUtils.judgeIfInHall() ? t.sort(((t, e) => t.st - e.st)) : t.sort(((t, e) => e.st - t.st));
    }
    requestTaskData() {
        let t = String(this._cur_vid) + "_" + String(this._cur_player), e = this.taskDataMap.get(t);
        if (sys.isObjectValid(e) && sys.isObjectValid(e.list) && e.list.length > 0) {
            this.updateTaskList();
        }
        else {
            Utils.shared().showLoading(10, true, (() => {
                Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
            }));
            let e = 0;
            ToolUtils.getIsInRoom() && (e = 1);
            let i = HttpRequest.GetTreaHuntTask;
            1 == this.treasureType && (i = HttpRequest.GetTreaHuntTask_CHIP);
            HttpManager.shared().doGetCommonRequest({ vid: this._cur_vid, inRoom: e, player: this._cur_player }, i, ((e, i, a) => {
                if (ToolUtils.isObjValid(this.node)) {
                    if (Utils.shared().hideLoading(), 200 != a) {
                        0 == sys.getNetworkType() ? Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text91"), 3, 0, ToolUtils.getIsNormalDirection()) : Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
                    }
                    else {
                        try {
                            let e = ToolUtils.parseJson(i);
                            if (0 == e.ret) {
                                let i = e.data;
                                sys.isObjectValid(i.list) && i.list.length > 0 && this.resortTaskData(i.list);
                                this.taskDataMap.set(t, i);
                            }
                            else {
                                ToolUtils.isSafeString(e.desc).length > 0 && Utils.shared().showToast(e.desc, 2, 0, ToolUtils.getIsNormalDirection());
                            }
                        }
                        catch (t) {
                            TLog.printError(this.TAG, "requestTaskData  error:", t);
                        }
                    }
                    this.updateTaskList();
                }
            }));
        }
    }
    updateTaskList_InGame() {
        let t = this.taskDataMap.get(String(this._cur_vid) + "_" + String(this._cur_player)), e = this.taskNode.getChildByName("taskList").getComponent(ScrollView).content;
        if (sys.isObjectValid(t) && sys.isObjectValid(t.list) && t.list.length > 0) {
            let i = t.list.length, a = 0, s = this.taskMoban.getComponent(UITransform).contentSize.width, r = 6;
            this._taskSize = i;
            this._taskIndex = -1;
            this.taskAwardIconMap.clear();
            for (let n = 0; n < i; n++) {
                if (ToolUtils.isObjValid(this._taskItems[n])) {
                    this._taskItems[n].setPosition(v3(a, 0));
                    this._taskItems[n].active = true;
                    e.addChild(this._taskItems[n]);
                }
                else {
                    let t = instantiate(this.taskMoban);
                    t.active = true;
                    t.setPosition(v3(a, 0));
                    e.addChild(t);
                    this._taskItems[n] = t;
                }
                this.initTaskItem(this._taskItems[n], t.list[n], n);
                a += s + r;
                for (let t = i, e = this._taskItems.length; t < e; t++) {
                    ToolUtils.isObjValid(this._taskItems[t]) && (this._taskItems[t].active = false);
                }
                e.getComponent(UITransform).setContentSize(size(s * i + r * (i - 1), 256));
                1 == t.list[n].st && (this._taskIndex = n);
            }
            this.taskNode.getChildByName("today_game").getComponent(Label).string = `Today's games:${String(t.cju)}/${String(t.tju)}`;
            this.taskNode.getChildByName("today_game").active = true;
            t.cju > t.tju && (this.taskNode.getChildByName("today_game").getComponent(Label).string = "Come back tomorrow");
            this.scrollTaskTolTargetPos();
            this._canPlayTaskAnim && this.playTaskInfoAnim();
            this._canPlayTaskAnim = false;
        }
        else {
            this._canPlayTaskAnim = false;
            e.destroyAllChildren();
            this._taskItems = [];
        }
    }
    updateTaskList() {
        let t = this.taskNode.getChildByName("taskList").getComponent(ScrollView).content, e = this.taskDataMap.get(String(this._cur_vid) + "_" + String(this._cur_player));
        if (this.taskNode.getChildByName("today_game").active = false, ToolUtils.getIsInRoom()) {
            this.updateTaskList_InGame();
        }
        else if (this.taskNode.getChildByName("taskList").getComponent(ScrollView).scrollToTop(), sys.isObjectValid(e) && sys.isObjectValid(e.list) && e.list.length > 0) {
            t.getComponent(UITransform).contentSize;
            let i = e.list.length, a = this.taskNode.getChildByName("taskList").getComponent(ScrollView).view, s = 0, r = this.taskMoban.getComponent(UITransform).contentSize.height, n = 4;
            t.removeAllChildren();
            this.taskAwardIconMap.clear();
            for (let o = 0; o < i; o++) {
                if (ToolUtils.isObjValid(this._taskItems[o])) {
                    this._taskItems[o].setPosition(v3(0, s));
                    this._taskItems[o].active = true;
                    t.addChild(this._taskItems[o]);
                }
                else {
                    let e = instantiate(this.taskMoban);
                    e.active = true;
                    e.setPosition(v3(0, s));
                    t.addChild(e);
                    this._taskItems[o] = e;
                }
                this.initTaskItem(this._taskItems[o], e.list[o], o);
                s += -(r + n);
                for (let t = i, e = this._taskItems.length; t < e; t++) {
                    ToolUtils.isObjValid(this._taskItems[t]) && (this._taskItems[t].active = false);
                }
                let l = t.getComponent(UITransform).contentSize;
                t.getComponent(UITransform).setContentSize(size(l.width, r * i + 4 * (i - 1)));
                this.taskScrollViewUtils.setScollDetails(r, a.height, e.list, true);
            }
            this.taskNode.getChildByName("today_game").getComponent(Label).string = `Today's games:${String(e.cju)}/${String(e.tju)}`;
            this.taskNode.getChildByName("today_game").active = true;
            this.scrollTaskTolTargetPos();
            this._canPlayTaskAnim && this.playTaskInfoAnim();
            this._canPlayTaskAnim = false;
        }
        else {
            t.destroyAllChildren();
            this._taskItems = [];
            this._canPlayTaskAnim = false;
        }
    }
    playTaskInfoAnim() {
        if (!this.taskNode.getChildByName("taskList").getComponent(ScrollView).isScrolling()) {
            let t, e = 0.08, i = this.taskDataMap.get(String(this._cur_vid) + "_" + String(this._cur_player));
            if (i.list && i.list.length > 0) {
                t = 0;
                for (let a = 0, s = i.list.length; a < s; a++) {
                    let i = this._taskItems[a];
                    if (ToolUtils.isObjValid(i) && i.active) {
                        let a = new Vec3;
                        TweenTool.stopNodeAction(i);
                        i.getPosition(a);
                        i.getComponent(UIOpacity).opacity = 0;
                        ToolUtils.judgeIfInHall() ? i.setPosition(v3(a.x, a.y - 40)) : i.setPosition(v3(a.x + 40, a.y));
                        let s = TweenTool.moveToByFade(i, 0.16, a, 0, 1, false), r = TweenTool.delayAct(i, null, t, false);
                        TweenTool.sequence(i, true, null, r, s);
                        t += e;
                    }
                }
            }
        }
    }
    scrollTaskTolTargetPos() {
        if (ToolUtils.judgeIfInHall()) {
            this.taskNode.getChildByName("taskList").getComponent(ScrollView).scrollToTop(0);
        }
        else if (this.taskNode.getChildByName("taskList").getComponent(ScrollView).stopAutoScroll(), -1 == this._taskIndex) {
            this.taskNode.getChildByName("taskList").getComponent(ScrollView).scrollToLeft();
        }
        else {
            this.taskNode.getChildByName("taskList").getComponent(ScrollView).scrollToLeft();
            let t = 157 * (this._taskIndex + 1) + 6 * this._taskIndex;
            this.taskNode.getChildByName("taskList").getComponent(ScrollView).scrollToOffset(v2(t - 78.5, 0), 0, false);
        }
    }
    initTaskItem(t, e, i) {
        t.getChildByName("wz").getComponent(Label).string = e.tc;
        1 == e.st ? t.getComponent(UIOpacity).opacity = 127.5 : t.getComponent(UIOpacity).opacity = 255;
        ToolUtils.judgeIfInHall() ? (t.getChildByName("reward").getChildByName("item0").active = false, t.getChildByName("reward").getChildByName("item1").active = false) : (t.getChildByName("gou0").active = 1 == e.st, t.getChildByName("top_num") && (t.getChildByName("top_num").active = false), t.getChildByName("reward").getChildByName("item0").active = false, t.getChildByName("reward").getChildByName("item1").active = false);
        for (let t = 0; t < e.reward.length; t++) {
            Number(e.reward[t].type);
        }
        for (let i = 0; i < e.reward.length; i++) {
            if (ToolUtils.judgeIfInHall()) {
                if (0 == Number(e.reward[i].type)) {
                    let a = t.getChildByName("reward").getChildByName("item0");
                    a.active = true;
                    a.getChildByName("num").getComponent(Label).string = e.reward[i].amt;
                    a.getChildByName("gou").active = 1 == e.st;
                }
                else if (1 == Number(e.reward[i].type)) {
                    let a = t.getChildByName("reward").getChildByName("item1");
                    a.active = true;
                    a.getChildByName("num").getComponent(Label).string = e.reward[i].amt;
                    a.getChildByName("gou").active = 1 == e.st;
                }
            }
            else {
                let a = null, s = Number(e.reward[i].type);
                0 == s ? (a = t.getChildByName("reward").getChildByName("item0"), a.active = true) : 1 == s && (a = t.getChildByName("reward").getChildByName("item1"), a.active = true);
                ToolUtils.isObjValid(a) && (a.getChildByName("num").getComponent(Label).string = "₹" + e.reward[i].amt);
                let r = t.getChildByName("top_num");
                r && (r.active = false);
            }
            ToolUtils.getIsInRoom() && sys.isObjectValid(e.icon) && e.icon.length > 0 && (this.taskAwardIconMap.set(t.getChildByName("ico"), e.icon), Utils.shared().updateNetImage(t.getChildByName("ico"), e.icon, size(158, 158)));
        }
    }
    scrollTabListtoTargetVid(t) {
    }
    updateVidTabList() {
        if (ToolUtils.getIsInRoom()) {
            return;
        }
        this.vidTabList.getComponent(ScrollView).content.destroyAllChildren();
        this._vidTabItemList = [];
        let t = null;
        if (1 == this._cur_points ? t = 2 == this._cur_player ? User.shared().treasureHuntMainData.p2 : User.shared().treasureHuntMainData.p6 : 1 == this._cur_pool ? t = 2 == this._cur_player ? User.shared().treasureHuntMainData.pool_p2 : User.shared().treasureHuntMainData.pool_p6 : 1 == this._cur_deals && (t = 2 == this._cur_player ? User.shared().treasureHuntMainData.deals_p2 : User.shared().treasureHuntMainData.deals_p6), sys.isObjectValid(t) && Array.isArray(t)) {
            for (let e = 0; e < t.length; e++) {
                let i = instantiate(this.vidTabMoban);
                i.active = true;
                this.vidTabList.getComponent(ScrollView).content.addChild(i);
                this.initVidTabItemData(i, t[e]);
                this._vidTabItemList.push(i);
            }
        }
        this.changeVidTab(this._cur_vid);
        this.updateOperateBtnStatus();
    }
    initVidTabItemData(t, e) {
        t.getChildByName("wz").getComponent(Label).string = e.point;
        t.getComponent(Button).clickEvents[0].customEventData = ToolUtils.toJsonString(e);
    }
    updateOperateBtnStatus() {
        if (ToolUtils.getIsInRoom()) {
            return;
        }
        let t = 1;
        if (sys.isObjectValid(this._cur_vidData)) {
            this.cur_max_coin = Number(this._cur_vidData.max_coin);
            let e = Number(this._cur_vidData.entry);
            if (this._curPoint = this._cur_vidData.point, t = Number(this._cur_vidData.mode), this._cur_vid != Number(this._cur_vidData.vid) && sys.isObjectValid(this._cur_vidData.vids) && Array.isArray(this._cur_vidData.vids) && this._cur_vidData.vids.length > 0) {
                for (let e = 0; e < this._cur_vidData.vids.length; e++) {
                    if (Number(this._cur_vidData.vids[e].vid) == this._cur_vid) {
                        t = Number(this._cur_vidData.vids[e].mode);
                        break;
                    }
                }
            }
            if (-1 != this._best_flag && this._cur_vidData.mode != this._best_flag && sys.isObjectValid(this._cur_vidData.vids) && Array.isArray(this._cur_vidData.vids) && this._cur_vidData.vids.length > 0) {
                for (let i = 0; i < this._cur_vidData.vids.length; i++) {
                    if (Number(this._cur_vidData.vids[i].mode) == this._best_flag) {
                        e = Number(this._cur_vidData.vids[i].entry);
                        t = this._best_flag;
                        break;
                    }
                }
            }
            this._curEntry = e;
            User.shared().data.coin < e ? (this.playNowBtn.getComponent(Button).clickEvents[0].customEventData = "addChip", i18nMgr.shared().changeLocalizedLabelKey(this.playNowBtn.getChildByName("wz"), "choose_game.add_chips")) : (this.playNowBtn.getComponent(Button).clickEvents[0].customEventData = "start", i18nMgr.shared().changeLocalizedLabelKey(this.playNowBtn.getChildByName("wz"), "choose_game.play_now"));
        }
        let e = " - " + String(this._curPoint);
        3 == User.shared().choose_game_type && (e = " - " + String(this._curPoint));
        let i = "treasurehunt.point_" + this._cur_player + "_t" + t;
        this.root.getChildByName("vid_bg").getChildByName("wz").getComponent(Label).string = String(this._curPoint);
        e = i18nMgr.shared().getValueByKey(i) + e;
        this.root.getChildByName("min_enty").getComponent(Label).string = e;
    }
    changePlayerTab(t) {
        ToolUtils.getIsInRoom() ? this._cur_player = t : (this.root.getChildByName("cnt_tabbg").active = true, this._cur_player = t, 6 == t ? (this.root.getChildByName("cnt_tabbg").getChildByName("tab0").getChildByName("ico").active = true, this.root.getChildByName("cnt_tabbg").getChildByName("tab1").getChildByName("ico").active = false, this.root.getChildByName("cnt_tabbg").getChildByName("tab0").getChildByName("wz").getComponent(Label).color = color(255, 255, 255), this.root.getChildByName("cnt_tabbg").getChildByName("tab1").getChildByName("wz").getComponent(Label).color = color(51, 51, 51)) : (this.root.getChildByName("cnt_tabbg").getChildByName("tab1").getChildByName("ico").active = true, this.root.getChildByName("cnt_tabbg").getChildByName("tab0").getChildByName("ico").active = false, this.root.getChildByName("cnt_tabbg").getChildByName("tab1").getChildByName("wz").getComponent(Label).color = color(255, 255, 255), this.root.getChildByName("cnt_tabbg").getChildByName("tab0").getChildByName("wz").getComponent(Label).color = color(51, 51, 51)));
    }
    changePageMode(t) {
        this._cur_mode = t;
        this.taskNode.active = 0 == t;
    }
    changeRankMode(t) {
        this._cur_rank_mode = t;
        this.cur_page = 1;
        0 == this._cur_rank_mode ? (this.rankNode.getChildByName("now_rank").getChildByName("line").getComponent(Sprite).spriteFrame = this.rankTabFrames[1], this.rankNode.getChildByName("yes_rank").getChildByName("line").getComponent(Sprite).spriteFrame = this.rankTabFrames[0], this.rankNode.getChildByName("now_rank").getChildByName("wz").getComponent(Label).color = this.rankTabWzColors[1], this.rankNode.getChildByName("yes_rank").getChildByName("wz").getComponent(Label).color = this.rankTabWzColors[0]) : (this.rankNode.getChildByName("now_rank").getChildByName("line").getComponent(Sprite).spriteFrame = this.rankTabFrames[0], this.rankNode.getChildByName("yes_rank").getChildByName("line").getComponent(Sprite).spriteFrame = this.rankTabFrames[1], this.rankNode.getChildByName("now_rank").getChildByName("wz").getComponent(Label).color = this.rankTabWzColors[0], this.rankNode.getChildByName("yes_rank").getChildByName("wz").getComponent(Label).color = this.rankTabWzColors[1]);
    }
    initParaData(t) {
        sys.isObjectValid(t) && sys.isObjectValid(t.isNext) && (this.isNext = t.isNext);
        sys.isObjectValid(t) && sys.isObjectValid(t.reportScene) && (this._reportScene = t.reportScene);
        sys.isObjectValid(t) && sys.isObjectValid(t.link_id) && t.link_id > 0 && (this._linkId = t.link_id);
        sys.isObjectValid(t) && sys.isObjectValid(t.pop_souce) && (this._pop_souce = t.pop_souce);
        sys.isObjectValid(t) && sys.isObjectValid(t.pClick) && (this.pClick = t.pClick);
        sys.isObjectValid(t) && sys.isObjectValid(t.vid) && (this._cur_vid = Number(t.vid), this._source_vid = Number(t.vid));
        sys.isObjectValid(t) && sys.isObjectValid(t.player) && (this._cur_player = t.player, this._source_player = t.player);
        sys.isObjectValid(t) && sys.isObjectValid(t.game) && (this._cur_game = Number(t.game), this._source_game = Number(t.game));
        sys.isObjectValid(t.cpool) && (this._cur_pool = Number(t.cpool), this._source_pool = Number(t.cpool));
    }
    getRecmmondVidData() {
        let t = null;
        if (0 == this._cur_game ? t = 0 == this._cur_pool ? 2 == this._cur_player ? User.shared().treasureHuntMainData.p2 : User.shared().treasureHuntMainData.p6 : 2 == this._cur_player ? User.shared().treasureHuntMainData.pool_p2 : User.shared().treasureHuntMainData.pool_p6 : 1 == this._cur_game ? t = User.shared().treasureHuntMainData.tp : 2 == this._cur_game && (t = User.shared().treasureHuntMainData.ab), sys.isObjectValid(t) && Array.isArray(t)) {
            let e = [...t].reverse(), i = Utils.shared().getRecommendRoomIndex(e)[1];
            if (i > 0) {
                return i -= 1, e[i];
            }
        }
        return null;
    }
    chooseBestVidInHall(t) {
        this._best_vid = 0;
        this._best_player = 0;
        let e = null;
        if (0 == this._cur_game && (1 == this._cur_points ? e = 2 == this._cur_player ? User.shared().treasureHuntMainData.p2 : User.shared().treasureHuntMainData.p6 : 1 == this._cur_pool ? e = 2 == this._cur_player ? User.shared().treasureHuntMainData.pool_p2 : User.shared().treasureHuntMainData.pool_p6 : 1 == this._cur_deals && (e = 2 == this._cur_player ? User.shared().treasureHuntMainData.deals_p2 : User.shared().treasureHuntMainData.deals_p6)), sys.isObjectValid(e) && Array.isArray(e)) {
            let t = e.length;
            this._cur_vid = Number(e[t - 1].vid);
        }
        if (sys.isObjectValid(e) && Array.isArray(e)) {
            let t = [...e].reverse(), i = Utils.shared().getRecommendRoomIndex(t)[1];
            if (i > 0) {
                return i -= 1, this._best_vid = Number(t[i].vid), this._best_player = 0, 1;
            }
        }
        return 0;
    }
    changeVidTab(t) {
        this._cur_vid = t;
        sys.isObjectValid(this._vidTabItemList) && Array.isArray(this._vidTabItemList) && this._vidTabItemList.length > 0 && this._vidTabItemList.forEach((t => {
            if (sys.isObjectValid(t)) {
                let e = ToolUtils.parseJson(t.getComponent(Button).clickEvents[0].customEventData);
                if (Number(e.vid) == Number(this._cur_vid)) {
                    this._cur_vidData = e;
                }
                else if (sys.isObjectValid(e.vids) && Array.isArray(e.vids) && e.vids.length > 0) {
                    for (let t = 0; t < e.vids.length; t++) {
                        if (Number(e.vids[t].vid) == this._cur_vid) {
                            this._cur_vidData = e;
                            break;
                        }
                    }
                }
            }
        }));
    }
    onVidTabButtonEvent(t, e) {
        if (SoundManager.shared().playFx("click"), ToolUtils.isObjValid(this.node)) {
            let t = ToolUtils.parseJson(e);
            if (this._cur_vid == Number(t.vid)) {
                return;
            }
            if (sys.now() - this._lastClick < 500) {
                return;
            }
            this._lastClick = sys.now();
            let i = Number(t.vid);
            if (-1 != this._best_flag && this._best_vid != t.flag && sys.isObjectValid(t.vids) && Array.isArray(t.vids) && t.vids.length > 0) {
                for (let e = 0; e < t.vids.length; e++) {
                    if (Number(t.vids[e].flag) == this._best_flag) {
                        i = Number(t.vids[e].vid);
                        break;
                    }
                }
            }
            this.changeVidTab(i);
            this.updateOperateBtnStatus();
            this.changePageMode(this._cur_mode);
            0 == this._cur_mode && (this._canPlayTaskAnim = true, this.requestTaskData());
            this.root.getChildByName("vid_root").active = false;
            this.root.getChildByName("vid_bg").getChildByName("arrow").angle = -180;
            HttpManager.shared().doCommReportRechargeEvent(this.reportApiName, this._reportScene, 8, this._linkId, "", 0);
        }
    }
    onSwitchGameTabEvent(t, e) {
        if (SoundManager.shared().playFx("click"), ToolUtils.isObjValid(this.node)) {
            if (1 == this._cur_points && 0 == Number(e)) {
                return;
            }
            if (1 == this._cur_pool && 1 == Number(e)) {
                return;
            }
            if (1 == this._cur_deals && 2 == Number(e)) {
                return;
            }
            if (sys.now() - this._lastClick < 500) {
                return;
            }
            0 == Number(e) ? (this._cur_points = 1, this._cur_pool = 0, this._cur_deals = 0) : 1 == Number(e) ? (this._cur_pool = 1, this._cur_points = 0, this._cur_deals = 0) : 2 == Number(e) && (this._cur_deals = 1, this._cur_points = 0, this._cur_pool = 0);
            this._cur_player = 6;
            this.switchGameType();
            this.root.getChildByName("vid_root").active = false;
            this.root.getChildByName("vid_bg").getChildByName("arrow").angle = -180;
            this.changePlayerTab(this._cur_player);
            this.onDealChooseVid();
            0 == this._cur_mode && (this._canPlayTaskAnim = true, this.requestTaskData());
            this.updateVidTabList();
            this.scrollTabListtoTargetVid(this._cur_vid);
        }
    }
    switchGameType() {
        if (ToolUtils.getIsInRoom()) {
            return;
        }
        let t = 0;
        1 == this._cur_points ? t = 0 : 1 == this._cur_pool ? t = 1 : 1 == this._cur_deals && (t = 2);
        for (let e = 0; e < 3; e++) {
            e == t ? (this.gameTabNodes[e].getChildByName("ico").getComponent(Sprite).spriteFrame = this.gameTabFrames[0], this.gameTabNodes[e].getChildByName("wz").getComponent(Label).color = color(255, 237, 67), this.gameTabNodes[e].getChildByName("ico").getComponent(UITransform).setContentSize(size(214, 84))) : (this.gameTabNodes[e].getChildByName("ico").getComponent(Sprite).spriteFrame = this.gameTabFrames[1], this.gameTabNodes[e].getChildByName("wz").getComponent(Label).color = color(163, 57, 57), this.gameTabNodes[e].getChildByName("ico").getComponent(UITransform).setContentSize(size(214, 70)));
        }
    }
    onSwitchTaskRankTabEvent(t, e) {
        if (SoundManager.shared().playFx("click"), ToolUtils.isObjValid(this.node)) {
            if (this._cur_mode == Number(e)) {
                return;
            }
            if (sys.now() - this._lastClick < 500) {
                return;
            }
            this._lastClick = sys.now();
            this.changePageMode(Number(e));
            0 == this._cur_mode && (this._canPlayTaskAnim = true, this.requestTaskData(), HttpManager.shared().doCommReportRechargeEvent(this.reportApiName, this._reportScene, 12, this._linkId, "", 0));
        }
    }
    onSwitchPlayerTabEvent(t, e) {
        if (SoundManager.shared().playFx("click"), ToolUtils.isObjValid(this.node)) {
            if (this._cur_player == Number(e)) {
                return;
            }
            if (sys.now() - this._lastClick < 500) {
                return;
            }
            this._lastClick = sys.now();
            let t = 0;
            "p6" == e ? t = 6 : "p2" == e && (t = 2);
            this.changePlayerTab(Number(t));
            this.onDealChooseVid();
            0 == this._cur_mode && (this._canPlayTaskAnim = true, this.requestTaskData());
            this.updateVidTabList();
            this.scrollTabListtoTargetVid(this._cur_vid);
        }
    }
    checkTheVidInList(t, e) {
        if (this._best_flag = -1, 2 == e) {
            for (let e = 0; e < User.shared().treasureHuntMainData.p2.length; e++) {
                if (Number(User.shared().treasureHuntMainData.p2[e].vid) == t) {
                    return this._best_target_outVid = Number(User.shared().treasureHuntMainData.p2[e].vid), this._best_flag = Number(User.shared().treasureHuntMainData.p2[e].flag), true;
                }
                if (sys.isObjectValid(User.shared().treasureHuntMainData.p2[e].vids) && Array.isArray(User.shared().treasureHuntMainData.p2[e].vids) && User.shared().treasureHuntMainData.p2[e].vids.length > 0) {
                    for (let i = 0; i < User.shared().treasureHuntMainData.p2[e].vids.length; i++) {
                        if (Number(User.shared().treasureHuntMainData.p2[e].vids[i].vid) == t) {
                            return this._best_target_outVid = Number(User.shared().treasureHuntMainData.p2[e].vid), this._best_flag = Number(User.shared().treasureHuntMainData.p2[e].vids[i].flag), true;
                        }
                    }
                }
            }
        }
        else {
            for (let e = 0; e < User.shared().treasureHuntMainData.p6.length; e++) {
                if (Number(User.shared().treasureHuntMainData.p6[e].vid) == t) {
                    return this._best_target_outVid = Number(User.shared().treasureHuntMainData.p6[e].vid), this._best_flag = Number(User.shared().treasureHuntMainData.p6[e].flag), true;
                }
                if (sys.isObjectValid(User.shared().treasureHuntMainData.p6[e].vids) && Array.isArray(User.shared().treasureHuntMainData.p6[e].vids) && User.shared().treasureHuntMainData.p6[e].vids.length > 0) {
                    for (let i = 0; i < User.shared().treasureHuntMainData.p6[e].vids.length; i++) {
                        if (Number(User.shared().treasureHuntMainData.p6[e].vids[i].vid) == t) {
                            return this._best_target_outVid = Number(User.shared().treasureHuntMainData.p6[e].vid), this._best_flag = Number(User.shared().treasureHuntMainData.p6[e].vids[i].flag), true;
                        }
                    }
                }
            }
        }
        return false;
    }
    onDealChooseVid() {
        if (ToolUtils.getIsInRoom()) {
            return;
        }
        let t = null;
        if (0 == this._cur_game && (1 == this._cur_points ? t = 2 == this._cur_player ? User.shared().treasureHuntMainData.p2 : User.shared().treasureHuntMainData.p6 : 1 == this._cur_pool ? t = 2 == this._cur_player ? User.shared().treasureHuntMainData.pool_p2 : User.shared().treasureHuntMainData.pool_p6 : 1 == this._cur_deals && (t = 2 == this._cur_player ? User.shared().treasureHuntMainData.deals_p2 : User.shared().treasureHuntMainData.deals_p6)), sys.isObjectValid(t) && Array.isArray(t)) {
            let e = t.length;
            this._cur_vid = Number(t[e - 1].vid);
        }
        1 == this.chooseBestVidInHall(this._cur_player) && (this._cur_vid = this._best_vid);
    }
    onDealButtonEvent(t, e) {
        if (SoundManager.shared().playFx("click"), ToolUtils.isObjValid(this.node)) {
            if (sys.now() - this._lastClick < 500) {
                return;
            }
            if (this._lastClick = sys.now(), "ruleclose" == e) {
                return void (this.ruleNode.active = false);
            }
            if ("rule" == e) {
                this.ruleNode.active = true;
                this.startShowAnim(this.ruleNode);
            }
            else if ("close" == e) {
                if (this._has_close) {
                    return;
                }
                this._has_close = true;
                this.onBackView();
            }
            else if ("start" == e) {
                this.onDealGameStartLogic();
                HttpManager.shared().doCommReportRechargeEvent(this.reportApiName, this._reportScene, 10, this._linkId, "", 0);
            }
            else if ("addChip" == e) {
                if (!User.shared().checkCanRecharge()) {
                    return void (ToolUtils.isObjValid(this.node) && this.node.destroy());
                }
                this.onDealAddGoldLogic();
                HttpManager.shared().doCommReportRechargeEvent(this.reportApiName, this._reportScene, 9, this._linkId, "", 0);
            }
            else {
                "vid_open" == e ? (this.root.getChildByName("vid_root").active = true, this.vidTabList.getComponent(ScrollView).scrollToTop(), this.root.getChildByName("vid_bg").getChildByName("arrow").angle = 0) : "vid_close" == e && (this.root.getChildByName("vid_root").active = false, this.root.getChildByName("vid_bg").getChildByName("arrow").angle = -180);
            }
        }
    }
    onDealGameStartLogic() {
        ToolUtils.curRoomId = Number(this._cur_vid);
        let t = { vid: Number(this._cur_vid), isNewTable: 1 };
        Utils.shared().showCommEnterRoom(t);
    }
    onDealAddGoldLogic() {
        let t = { vid: this._cur_vid, parent_node: director.getScene().getChildByName("Canvas"), bShowNetTip: true, min_entry: this._curEntry };
        Utils.shared().showQuickRecharge(t);
        User.shared().updatePayScene(PhpReportDefined.pay_scene.hall_less_money, Number(this._cur_vid));
    }
    onBackView() {
        this.isNext && PushCenter.shared().pushEvent(PushEvent.Update_NextPopActivity);
        PushCenter.shared().removeListenersByTag(this);
        ToolUtils.isObjValid(this.node) && this.node.destroy();
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().removeListenersByTag(this);
    }
}
