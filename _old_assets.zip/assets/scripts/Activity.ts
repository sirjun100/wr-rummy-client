// @ts-nocheck
// Recovered from index.js:1
import { _decorator, Button, color, director, instantiate, Label, Node, ScrollView, size, sp, sys, UITransform, v3, Vec3, view } from "cc";
import { TransferPlatform } from "./TransferPlatform";
import TweenTool from "./TweenTool";
import Utils from "./Utils";
import GameConfig from "./GameConfig";
import PushCenter from "./PushCenter";
import PushEvent from "./PushEvent";
import ReportConfig from "./ReportConfig";
import User from "./User";
import HttpManager from "./HttpManager";
import SoundManager from "./SoundManager";
import Parent from "./Parent";
import BundleNameDefined from "./BundleNameDefined";
import i18nMgr from "./i18nMgr";
import { ScrollviewUtils } from "./ScrollviewUtils";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("Activity")
export class Activity extends Parent {
    @property(ScrollView)
    public scrollView: ScrollView = null;
    @property(Node)
    public moban: Node = null;
    @property(Node)
    public rootNode: Node = null;
    public _scrollUtil: any = null;
    public _items: any[] = [];
    public scheduleList: any[] = [];
    public activityEndAllTimes: any[] = [];
    public isSendHttp: boolean = false;
    public isUIReport: boolean = false;
    onLoad() {
        this.fitScreen();
        PushCenter.shared().addListener(PushEvent.commentDownloaderImg, (t => {
            if (ToolUtils.isObjValid(this.node)) {
                for (let e = 0, i = User.shared().actList.length; e < i; e++) {
                    let i = this._items[e];
                    if (sys.isObjectValid(i)) {
                        let s = i.getChildByName("img"), a = User.shared().actList[e].imgurl;
                        a == t && Utils.shared().updateNetImage(s, a, size(680, 204), (t => {
                        }));
                    }
                }
            }
        }), this);
        PushCenter.shared().addListener(PushEvent.UpdateActivity, (t => {
            ToolUtils.isObjValid(this.node) && HttpManager.shared().doGetActivityList(this.listenActivityListCallback.bind(this));
        }), this);
        this._scrollUtil = this.node.addComponent(ScrollviewUtils);
        this._scrollUtil.initScrollviewUtils(this.scrollView);
        this._scrollUtil.setSrollCallBack((t => {
            if (1 == User.shared().s_uirp_1 && sys.isObjectValid(User.shared().actList[t]) && sys.isObjectValid(User.shared().actList[t].jump_info)) {
                let e = [];
                e.push(User.shared().actList[t].jump_info);
                HttpManager.shared().doGetBannerShowRequest(ReportConfig.Cmd_UIActivityReport, e, ((t, e, i) => {
                }));
            }
        }));
    }
    fitScreen() {
        ToolUtils.adaptSafeArea(this.node);
    }
    start() {
        this.moban.active = false;
        Array.isArray(User.shared().actList) ? this.refreshActivityList() : Utils.shared().showLoading(10, true, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
        }));
        setTimeout((() => {
            HttpManager.shared().doGetActivityList(this.listenActivityListCallback.bind(this));
        }));
        this.isSendHttp = true;
        PushCenter.shared().addListener(PushEvent.PurchasedFirstRecharge, (t => {
            ToolUtils.isObjValid(this.node) && HttpManager.shared().doGetActivityList(this.listenActivityListCallback.bind(this));
        }), this);
    }
    onDestroy() {
        PushCenter.shared().removeListenersByTag(this);
        this.unscheduleAllCallbacks();
        for (let t = 0, e = this.scheduleList.length; t < e; t++) {
            this.scheduleList[t].stop();
        }
    }
    onEnable() {
        TransferPlatform.shared().setNormalFrameRate();
        this.isSendHttp && (this.isUIReport = false, HttpManager.shared().doGetActivityList(this.listenActivityListCallback.bind(this)));
    }
    listenActivityListCallback(t, e, i) {
        if (Utils.shared().hideLoading(), 200 != i) {
            alert("The login timed out, please try again");
        }
        else {
            let t = ToolUtils.parseJson(e);
            if (0 == t.ret) {
                let e = false;
                if (User.shared().actList.length == t.data.actlist.length) {
                    for (let i = 0, s = t.data.actlist.length; i < s; i++) {
                        if (User.shared().actList[i].id != t.data.actlist[i].id) {
                            e = true;
                            break;
                        }
                    }
                }
                else {
                    e = true;
                }
                User.shared().actList = t.data.actlist;
                ToolUtils.isObjValid(this.node) && this.refreshActivityList(e);
            }
        }
    }
    refreshActivityList(t = true) {
        if (!sys.isObjectValid(User.shared().actList) || !Array.isArray(User.shared().actList)) {
            return;
        }
        let e = this.scrollView.content, i = 0, s = this.moban.getComponent(UITransform).contentSize.height, a = sys.getSafeAreaRect().y, n = view.getVisibleSize().height - GameConfig.CONFIG_SCREEN_HEIGHT - a;
        n <= 0 && (n = 0);
        let l = this.scrollView.view;
        if (l.height = 1186, l.setContentSize(size(l.width, l.height + n)), this.scrollView.getComponent(UITransform).setContentSize(size(l.width, l.height + n)), User.shared().actList.length > 0) {
            let t = User.shared().actList.length * s + 5 * (User.shared().actList.length - 1) + 150;
            t < l.height + n ? e.getComponent(UITransform).setContentSize(size(720, l.height + n)) : e.getComponent(UITransform).setContentSize(size(720, t));
        }
        else {
            e.getComponent(UITransform).setContentSize(size(720, l.height + n));
        }
        t && (e.destroyAllChildren(), this._items = [], this.activityEndAllTimes = []);
        for (let a = 0, n = User.shared().actList.length; a < n; a++) {
            if (t || !ToolUtils.isObjValid(this._items[a])) {
                let t = instantiate(this.moban);
                t.active = true;
                let n = t.getChildByName("ani_loading");
                n.getComponent(sp.Skeleton).clearTracks();
                n.getComponent(sp.Skeleton).setAnimation(0, "hdtd", true);
                0 == a ? t.setPosition(v3(0, 0)) : t.setPosition(v3(0, i));
                e.addChild(t);
                this._items.push(t);
                i += -(s + 5);
            }
            this.updataActivityView(a);
        }
        if (this._scrollUtil.setScollDetails(s, l.height + n, User.shared().actList, true), 1 == User.shared().s_uirp_1 && User.shared().actList.length > 0 && !this.isUIReport) {
            this.isUIReport = true;
            let t = [];
            for (let e = 0, i = User.shared().actList.length; e < i && (sys.isObjectValid(this._items[e]) && this._items[e].active); e++) {
                sys.isObjectValid(User.shared().actList[e]) && sys.isObjectValid(User.shared().actList[e].jump_info) && t.push(User.shared().actList[e].jump_info);
            }
            HttpManager.shared().doGetBannerShowRequest(ReportConfig.Cmd_UIActivityReport, t, ((t, e, i) => {
            }));
        }
    }
    updataActivityView(t) {
        let e = User.shared().actList[t], i = this._items[t], s = i.getChildByName("img"), a = i.getChildByName("ani_loading");
        director.getScene().name == BundleNameDefined.rummy_scence ? Utils.shared().updateNetImage(s, e.imgurl, size(330, 110), (t => {
            a.active = false;
        })) : Utils.shared().updateNetImage(s, e.imgurl, size(680, 204), (t => {
            a.active = false;
        }));
        e.index = t;
        i.getComponent(Button).clickEvents[0].customEventData = String(t);
        let n = i.getChildByName("desc");
        n.getComponent(Label).string = ToolUtils.isSafeString(e.flag.desc);
        n.getComponent(Label).color = color(ToolUtils.isSafeString(e.flag.color));
        n.getComponent(Label).updateRenderData(true);
        let l = i.getChildByName("date");
        l.getComponent(Label).string = e.date;
        let h = n.getPosition().x, c = new Vec3;
        l.getPosition(c);
        let u = n.getComponent(UITransform).contentSize.width;
        l.setPosition(v3(h + u + 16, c.y, 0));
        i.getChildByName("title").getComponent(Label).string = e.title;
        i.getChildByName("ani_new").active = null != e.red_status && 1 == e.red_status;
        this.activityEndAllTimes[t] = User.shared().actList[t].rest_time;
        this.activityEndAllTimes[t] < 600 && (sys.isObjectValid(this.scheduleList[t]) ? (this.scheduleList[t].stop(), this.scheduleList[t] = TweenTool.myschedule(this.node, 1, (() => {
            this.activityEndAllTimes[t] = this.activityEndAllTimes[t] - 1;
            this.activityEndAllTimes[t] <= 0 && (this.scheduleList[t].stop(), sys.isObjectValid(this.node) && HttpManager.shared().doGetActivityList(this.listenActivityListCallback.bind(this)));
        }))) : this.scheduleList[t] = TweenTool.myschedule(this.node, 1, (() => {
            this.activityEndAllTimes[t] = this.activityEndAllTimes[t] - 1;
            this.activityEndAllTimes[t] <= 0 && (this.scheduleList[t].stop(), sys.isObjectValid(this.node) && HttpManager.shared().doGetActivityList(this.listenActivityListCallback.bind(this)));
        })));
    }
    onButtonClick(t, e) {
        SoundManager.shared().playFx("click");
        try {
            if (!(Array.isArray(User.shared().actList) && User.shared().actList.length > Number(e))) {
                return;
            }
            let t = User.shared().actList[Number(e)];
            if (t) {
                if (this.activityEndAllTimes[t.index] <= 0) {
                    return void Utils.shared().showToast(t.msg, 2);
                }
                t.jump_info.type == PushEvent.JUMP_TO_GONGGAO && (t.jump_info.exe = t.jump_info.notice);
                t.jump_info.type == PushEvent.JUMP_TO_HAPPYREWARDS && HttpManager.shared().doGettHappyRewardsReportTo(2, t.id, null);
                let e = 1;
                switch (Number(t.jump_info.type)) {
                    case PushEvent.JUMP_TO_SESSIONPACKGE:
                        e = 6;
                        break;
                    case PushEvent.JUMP_TO_LOTTERYACT:
                        e = 11;
                        break;
                    case PushEvent.JUMP_TO_DAILYTASK:
                        e = -1;
                        break;
                    case PushEvent.JUMP_TO_Treasure:
                    case PushEvent.JUMP_TO_DAILYLOGIN:
                    case PushEvent.JUMP_TO_TREASURE_HUNT: e = 2;
                }
                let i = "ClickActivity_" + t.jump_info.type;
                TransferPlatform.shared().logEvent_firebase(i);
                let s = t.jump_info.exe;
                sys.isObjectValid(s) || (s = {});
                t.jump_info.type == PushEvent.JUMP_TO_Adventrue ? s.from_source = 1 : t.jump_info.type == PushEvent.JUMP_TO_FREECASH && (s.from_source = 8);
                Utils.shared().doJumpLogic(t.jump_info.type, s, { isNext: false, bWithTip: true, reportScene: 3, reportEvtId: e, link_id: sys.now() });
            }
        }
        catch (t) {
        }
    }
    onCloseButtonClick(t, e) {
        SoundManager.shared().playFx("click");
        "close" == e && this.node.destroy();
    }
}
