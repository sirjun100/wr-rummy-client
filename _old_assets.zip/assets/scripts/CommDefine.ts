// @ts-nocheck
// Recovered from index.js:71
import { color, Rect } from "cc";
export let BagItemType;
export let CUSTOM_REWARD_ENUM;
export let CheckModule;
export let CommonGameType;
export let HELPER_ENUM;
export let HallGameType;
export let PointsType;
export let RemoteGameList;
let CommDefine;
(BagItemType = undefined, CUSTOM_REWARD_ENUM = undefined, CheckModule = undefined, CommonGameType = undefined, HELPER_ENUM = undefined, HallGameType = undefined, PointsType = undefined);
(CommDefine = { FirstLocation: "FirstLocation", Has18Year: "Has18Year", FirstLogin: "FirstLogin", HasShowLocationAlert: "HasShowLocationAlert", LoginTime: "LoginTime", LocationGuideTime: "LocationGuideTime", LocationForbidTime: "LocationForbidTime", KycGuideTime: "KycGuideTime", forbidden_province: ["Assam", "Nagaland", "Meghalaya", "Odisha", "Sikkim", "Telangana", "Antra Pradesh"], UpdateTempPath: "HotUpdateTempPaths/", UpdateRenamePath: "HotUpdateRenamePaths/", NewerGuideRoomTidkey: "xsydroom", PerformanceRoomTidkey: "performanceroom", AppleTokenKey: "MASTERRUMMY_APPLE_TOKEN", AppName_rummy: "Master Rummy", AppName_circ: "Circ11 Game", GuidePlayerInfo: { name: "Player18921231", uid: 0, headname: "head_1.png", vlevel: 0, sex: 0, avatar_url: "", isinit: false, isLineUp: false, isHeadCallback: true }, LoadToHallStep: [{ start: 1, end: 10, stepRand: 2 }, { start: 11, end: 20, stepRand: 2 }, { start: 21, end: 85, stepRand: 0 }, { start: 86, end: 90, stepRand: 2 }, { start: 91, end: 95, stepRand: 2 }, { start: 96, end: 99, stepRand: 2 }, { start: 100, end: 100, stepRand: 0 }], LoadToLoginStep: [{ start: 1, end: 10, stepRand: 2 }, { start: 11, end: 20, stepRand: 2 }, { start: 21, end: 85, stepRand: 0 }, { start: 86, end: 99, stepRand: 4 }, { start: 100, end: 100, stepRand: 0 }], _passRometoImgFiles: { cell_bg: "pass_cellbg.png", vip_cell_bg: "pass_cellbg_vip.png", reward_bg: "pass_reward_bg.png", vip_reward_bg: "pass_vipReward_bg.png", bg: "pass_bg.png", title: "pass_title.png", title2: "pass_title2.png", title3: "pass_title3.png", btn_get_pts: "pass_btn_playGame.png", btn_purcharse: "pass_btn_purchase.png", btn_purcharsed: "pass_btn_purchased.png", purcharse_flag: "pass_purchase_flag.png", bottom_img_complate: "pass_tips_complate.png", bg1: "pass_sub_bg1.png", bg2: "pass_sub_bg2.png", sub_title: "pass_sub_title.png", sub_title2: "pass_sub_title2.png", sub_title3: "pass_sub_title3.png", sub2_title: "pass_sub2_title.png", sub2_title2: "pass_sub2_title2.png", sub2_title3: "pass_sub2_title3.png", btn_sub_purcharse: "pass_sub_purchase.png", btn_sub_purcharsed: "pass_sub_purchased.png", bottom_reward_bg: "pass_bottom_reward_bg.png", tip_bg: "pass_tip_bg.png" }, _honorteamRometoImgFiles: { honor_mainBg: "honor_mainbg.png", honor_mainLogo0: "honor_logo0.png", honor_mainLogo1: "honor_logo1.png", honor_mainLogo2: "honor_logo2.png", honor_mainLogo3: "honor_logo3.png", honor_dot: "honor_dot.png", honor_close: "honor_main_close.png", honor_help: "honor_main_help.png", honor_nodata: "honor_nodata.png", honor_mainTab: "honor_main_tabbg.png", honor_mainTabFenge: "honor_main_fenge.png", honor_mainBox1: "honor_main_box1.png", honor_mainBox2: "honor_main_box2.png", honor_mainPropBg: "honor_paopao.png", honor_myInfoBg: "honor_main_infobg.png", honor_mainBtn1: "honor_btn1.png", honor_mainBtn2: "honor_btn2.png", honor_mainBtn3: "honor_btn3.png", honor_mainBtn4: "honor_btn4.png", honor_suc_bg: "honor.suc_bg.png", honor_suc_logo0: "honor_suc_logo0.png", honor_suc_logo1: "honor_suc_logo1.png", honor_suc_logo2: "honor_suc_logo2.png", honor_suc_logo3: "honor_suc_logo3.png", honor_bigBtn_green: "honor_bigbtn_green.png", honor_bigBtn_gray: "honor_bigbtn_gray.png", honor_bigBtn_red: "honor_bigbtn_red.png", honor_bigBtn_yellow: "honor_bigbtn_yellow.png", honor_dialog_bg_small: "honor_dialogbg_small.png", honor_dialog_bg_big: "honor_dialogbg_big.png", honor_dialog_tab0: "honor_tab_select0.png", honor_dialog_tab1: "honor_tab_select1.png", honor_dialog_bottombg: "honor_bottemlist_bg.png", honor_inputbg: "honor_inputbg.png", honor_inputerr: "honor_inputbg_err.png", honor_input_clear: "honor_input_clear.png", honor_input_modify: "honor_input_modify.png", honor_smallBtn_green: "honor_sbtn_green.png", honor_smallBtn_gray: "honor_sbtn_gray.png", honor_smallBtn_red: "honor_sbtn_red.png", honor_btn_agree: "honor_opbtn1.png", honor_btn_agree_hui: "honor_opbtn2.png", honor_btn_refuse: "honor_opbtn0.png", honor_infobg: "honor_infobg.png", honor_help_infobg: "honor_help_cntbg.png", honor_help_titlebg: "honor_help_titlebg.png" }, _honorteam_pic_para: { honor_dialog_bg_big: { insetTop: 81, insetBottom: 21, insetLeft: 18, insetRight: 25, rect: new Rect(34, 30, 652, 129) }, honor_dialog_bg_small: { insetTop: 81, insetBottom: 21, insetLeft: 18, insetRight: 25, rect: new Rect(24, 40, 552, 129) }, honor_myInfoBg: { insetTop: 1, insetBottom: 0, insetLeft: 4, insetRight: 5, rect: new Rect(0, 0, 10, 10) }, honor_dialog_tab0: { insetTop: 12, insetBottom: 13, insetLeft: 1, insetRight: 1, rect: new Rect(0, 0, 4, 60) }, honor_dialog_tab1: { insetTop: 6, insetBottom: 7, insetLeft: 1, insetRight: 1, rect: new Rect(0, 0, 4, 60) }, honor_dialog_bottombg: { insetTop: 3, insetBottom: 7, insetLeft: 8, insetRight: 10, rect: new Rect(0, 0, 20, 20) }, honor_inputbg: { insetTop: 5, insetBottom: 4, insetLeft: 4, insetRight: 5, rect: new Rect(0, 0, 20, 20) }, honor_inputerr: { insetTop: 4, insetBottom: 6, insetLeft: 6, insetRight: 5, rect: new Rect(0, 0, 20, 20) }, honor_infobg: { insetTop: 5, insetBottom: 5, insetLeft: 5, insetRight: 6, rect: new Rect(0, 0, 20, 20) }, honor_help_infobg: { insetTop: 4, insetBottom: 4, insetLeft: 5, insetRight: 6, rect: new Rect(0, 0, 20, 20) }, honor_help_titlebg: { insetTop: 5, insetBottom: 6, insetLeft: 4, insetRight: 4, rect: new Rect(0, 0, 20, 20) } }, MatchVid: 431, gradient: { btn_blue: "gradient_blue_button", btn_gray: "gradient_gray_button", btn_green: "gradient_green_button", btn_orange: "gradient_orange_button", btn_red: "gradient_red_button", red_num: "gradient_rednum", title: "gradient_title", normal: "gradient", null: "gradient_null" }, shadowcolor: { green: color(5, 123, 58, 255), gray: color(103, 103, 103, 255), orange: color(155, 75, 21, 255), blue: color(45, 105, 178, 255), red: color(158, 45, 23, 255), white: color(255, 255, 255, 255) }, rewardPistName: ["reward_tips_cash", "reward_tips_bonus", "reward_tips_active", "reward_tips_coupons_match", "reward_tips_coupons_cash", "reward_tips_coupons_bonus", "reward_tips_coupons_club", "reward_tips_practice", "reward_tips_receipt", "", "", "reward_tips_ticket", "", "reward_tips_active", "", "reward_leaf", "reward_tips_key"], TawkUser_Feedback_Source: { Charge: 1, Charge_Group: { Store: 1, ChargeRecord: 2 }, Withdraw: 2, Withdraw_Group: { Main: 3, WithdrawRecord: 4, Pan: 5 }, Kyc: 3, Kyc_Group: { Verify: 6, Limit: 7, Checking: 8 }, Records: 4, Records_Group: { Wallet_Main: 9, Wallet_Records: 10, Wallet_Bonus_Records: 11 }, Login: 5, Login_Group: { Login_Main: 12 }, Suggestion: 6 } });
(!function (_) {
    _[_.LOGIN = 0] = "LOGIN";
    _[_.NEW_USER = 1] = "NEW_USER";
    _[_.CASH_PLAY = 2] = "CASH_PLAY";
    _[_.RECHARGE = 3] = "RECHARGE";
    _[_.WITH_DRAW = 4] = "WITH_DRAW";
    _[_.KYC = 5] = "KYC";
    _[_.HALL = 7] = "HALL";
    _[_.CHIPS_PLAY = 8] = "CHIPS_PLAY";
}(CheckModule || (CheckModule = {})));
(function (_) {
    _[_.HELPER_PICK = 1] = "HELPER_PICK";
    _[_.HELPER_DISCARD = 2] = "HELPER_DISCARD";
    _[_.HELPER_HU_NUM = 4] = "HELPER_HU_NUM";
    _[_.HELPER_HU_CONDITION = 8] = "HELPER_HU_CONDITION";
    _[_.HELPER_QUICK_HU = 16] = "HELPER_QUICK_HU";
    _[_.HELPER_PAILI_SCORE = 32] = "HELPER_PAILI_SCORE";
    _[_.HELPER_SORT_NEVER = 64] = "HELPER_SORT_NEVER";
    _[_.HELPER_SORT_FIRSTSORT = 128] = "HELPER_SORT_FIRSTSORT";
    _[_.HELPER_SORT_AUTOSORT = 256] = "HELPER_SORT_AUTOSORT";
}(HELPER_ENUM || (HELPER_ENUM = {})));
(function (_) {
    _[_.CLUB_LEVEL = -1] = "CLUB_LEVEL";
    _[_.HEADFRAME_LEVEL = -2] = "HEADFRAME_LEVEL";
    _[_.VIP_LEVEL = -3] = "VIP_LEVEL";
}(CUSTOM_REWARD_ENUM || (CUSTOM_REWARD_ENUM = {})));
(function (_) {
    _[_.Classic = 1] = "Classic";
    _[_.Easy = 2] = "Easy";
    _[_.Multiple = 3] = "Multiple";
    _[_.Wild = 4] = "Wild";
    _[_.Double = 5] = "Double";
}(PointsType || (PointsType = {})));
(function (_) {
    _[_.BonusAdd = 14] = "BonusAdd";
    _[_.LuckyLeaf = 15] = "LuckyLeaf";
    _[_.TreasureKey = 16] = "TreasureKey";
}(BagItemType || (BagItemType = {})));
(function (_) {
    _[_.Rummy = 0] = "Rummy";
    _[_.TpPotBlind = 4] = "TpPotBlind";
    _[_.TeenPatti = 44] = "TeenPatti";
    _[_.TpAK47 = 46] = "TpAK47";
    _[_.FruitMachine = 18] = "FruitMachine";
    _[_.Crash = 45] = "Crash";
    _[_.SevenUp = 2] = "SevenUp";
    _[_.SixDice = 10] = "SixDice";
    _[_.AB = 1] = "AB";
    _[_.LHD = 8] = "LHD";
    _[_.ClearMines = 48] = "ClearMines";
    _[_.Horse = 17] = "Horse";
    _[_.BrTp = 12] = "BrTp";
    _[_.LuckyLoto = 19] = "LuckyLoto";
    _[_.Ludo = 22] = "Ludo";
    _[_.SmallSlots = 47] = "SmallSlots";
    _[_.CricketSlot = 49] = "CricketSlot";
    _[_.LuckBall = 50] = "LuckBall";
    _[_.LudoFriend = 51] = "LudoFriend";
    _[_.Yes11 = 100] = "Yes11";
}(CommonGameType || (CommonGameType = {})));
(function (_) {
    _[_.LOBBY_GAME_TYPE_RUMMY = 1] = "LOBBY_GAME_TYPE_RUMMY";
    _[_.LOBBY_GAME_TYPE_TEENPATTI = 2] = "LOBBY_GAME_TYPE_TEENPATTI";
    _[_.LOBBY_GAME_TYPE_SHUIGUOJI = 3] = "LOBBY_GAME_TYPE_SHUIGUOJI";
    _[_.LOBBY_GAME_TYPE_PRIVATE_RUMMY = 4] = "LOBBY_GAME_TYPE_PRIVATE_RUMMY";
    _[_.LOBBY_GAME_TYPE_MATCH = 5] = "LOBBY_GAME_TYPE_MATCH";
    _[_.LOBBY_GAME_TYPE_YES11 = 6] = "LOBBY_GAME_TYPE_YES11";
    _[_.LOBBY_GAME_TYPE_CRASH = 7] = "LOBBY_GAME_TYPE_CRASH";
    _[_.LOBBY_GAME_TYPE_7UP = 8] = "LOBBY_GAME_TYPE_7UP";
    _[_.LOBBY_GAME_TYPE_SIXDICE = 9] = "LOBBY_GAME_TYPE_SIXDICE";
    _[_.LOBBY_GAME_TYPE_AB = 10] = "LOBBY_GAME_TYPE_AB";
    _[_.LOBBY_GAME_TYPE_LHD = 11] = "LOBBY_GAME_TYPE_LHD";
    _[_.LOBBY_GAME_TYPE_CLEARMINES = 12] = "LOBBY_GAME_TYPE_CLEARMINES";
    _[_.LOBBY_GAME_TYPE_HORSE = 13] = "LOBBY_GAME_TYPE_HORSE";
    _[_.LOBBY_GAME_TYPE_BRTP = 14] = "LOBBY_GAME_TYPE_BRTP";
    _[_.LOBBY_GAME_TYPE_CRICKETSLOT = 15] = "LOBBY_GAME_TYPE_CRICKETSLOT";
    _[_.LOBBY_GAME_TYPE_LuckBall = 16] = "LOBBY_GAME_TYPE_LuckBall";
    _[_.LOBBY_GAME_TYPE_Ludo = 17] = "LOBBY_GAME_TYPE_Ludo";
}(HallGameType || (HallGameType = {})));
(RemoteGameList = [HallGameType.LOBBY_GAME_TYPE_SIXDICE, HallGameType.LOBBY_GAME_TYPE_SHUIGUOJI, HallGameType.LOBBY_GAME_TYPE_CRASH, HallGameType.LOBBY_GAME_TYPE_LuckBall, HallGameType.LOBBY_GAME_TYPE_Ludo]);
export default CommDefine;
