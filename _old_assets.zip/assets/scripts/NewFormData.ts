// @ts-nocheck
// Recovered from index.js:323
import { _decorator } from "cc";
const { ccclass } = _decorator;
@ccclass("NewFormData")
export default class NewFormData {
    public _boundary_key: string = "";
    public _boundary: string = "";
    public _end_boundary: string = "";
    public _result: any[] = [];
    constructor(t) {
        this._boundary = String(t);
        this._end_boundary = String(t);
    }
    getBoundary() {
        return this._boundary;
    }
    getEndBoundary() {
        return this._end_boundary;
    }
    append(t, e) {
        let r = `${this._boundary}\r\n`;
        for (let t = 0, e = r.length; t < e; t++) {
            this._result.push(r.charCodeAt(t));
        }
        r = 'Content-Disposition: form-data; name="' + t + '"\r\n\r\n';
        for (let t = 0, e = r.length; t < e; t++) {
            this._result.push(r.charCodeAt(t));
        }
        this._result.push(e);
        r = "\r\n";
        for (let t = 0, e = r.length; t < e; t++) {
            this._result.push(r.charCodeAt(t));
        }
    }
    appendFile(t, e, r = "", n = "") {
        let s = `--${this._boundary}\r\n`;
        for (let t = 0, e = s.length; t < e; t++) {
            this._result.push(s.charCodeAt(t));
        }
        s = `Content-Disposition: form-data; name="${t}"; filename="${r}"\r\n`;
        for (let t = 0, e = s.length; t < e; t++) {
            this._result.push(s.charCodeAt(t));
        }
        if (n.length > 0) {
            s = `Content-Type: ${n}\r\n`;
            for (let t = 0, e = s.length; t < e; t++) {
                this._result.push(s.charCodeAt(t));
            }
        }
        s = "\r\n";
        for (let t = 0, e = s.length; t < e; t++) {
            this._result.push(s.charCodeAt(t));
        }
        let h = new Uint8Array(e);
        for (let t = 0, e = h.length; t < e; t++) {
            this._result.push(h[t]);
        }
        s = "\r\n";
        for (let t = 0, e = s.length; t < e; t++) {
            this._result.push(s.charCodeAt(t));
        }
        s = `--${this._boundary}--`;
        for (let t = 0, e = s.length; t < e; t++) {
            this._result.push(s.charCodeAt(t));
        }
    }
    getArrayBuffer() {
        return new Uint8Array(this._result).buffer;
    }
    getStrBuffer() {
        let t = "";
        for (let e = 0, r = this._result.length; e < r; e++) {
            t += this._result[e];
        }
        return t;
    }
}
