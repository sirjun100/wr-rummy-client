// @ts-nocheck
// Recovered from index.js:133
import { _decorator, Button, instantiate, Label, Node, ProgressBar, sp, Sprite, SpriteFrame, sys, UIOpacity, v3, Widget } from "cc";
import Parent from "./Parent";
import { TLog } from "./TLog";
import PushCenter from "./PushCenter";
import SoundManager from "./SoundManager";
import Utils from "./Utils";
import PushEvent from "./PushEvent";
import { FruitSlotGameManager } from "./FruitSlotGameManager";
import User from "./User";
import { ToolUtils } from "./ToolUtils";
import TweenTool from "./TweenTool";
import BundleNameDefined from "./BundleNameDefined";
import GameConfig from "./GameConfig";
import { CommonGameType } from "./CommDefine";
import { AdapDirection } from "./BaseLayer";
import i18nMgr from "./i18nMgr";
import PhpReportDefined from "./PhpReportDefined";
const { ccclass, property } = _decorator;
@ccclass("FruitSlotBtnPannel")
export default class FruitSlotBtnPannel extends Parent {
    public _TAG: string = "FruitSlotBtnPannel";
    @property(Node)
    public bottomNode: Node = null;
    @property(Node)
    public autoBtnNode: Node = null;
    @property(Node)
    public randomAdBtn: Node = null;
    @property(Node)
    public adTreasureBtn: Node = null;
    @property(Node)
    public winBgNode: Node = null;
    @property(Node)
    public autoSelectBgNode: Node = null;
    @property(Node)
    public text_betAmount: Node = null;
    @property(Node)
    public jcAmount: Node = null;
    @property(Node)
    public text_coin: Node = null;
    @property([SpriteFrame])
    public fastBtnImgs: SpriteFrame[] = [];
    @property([SpriteFrame])
    public smallBtnImgs: SpriteFrame[] = [];
    @property([SpriteFrame])
    public bigBtnImgs: SpriteFrame[] = [];
    @property([SpriteFrame])
    public autoImgs: SpriteFrame[] = [];
    public actRankPrefab: any = null;
    @property(SpriteFrame)
    public helpImg: SpriteFrame = null;
    public isAutoTouch: boolean = false;
    public lastClick: number = 0;
    public autoBets: any[] = [20, 50, 100, -1];
    public gameSettingPrefab: any = null;
    public menualertPrefab: any = null;
    public jackPotPrefab: any = null;
    onLoad() {
        this.node.getComponent(Widget).enabled = true;
        this.node.getComponent(Widget).updateAlignment();
        this.adapptationScreen();
    }
    onDestroy() {
        super.onDestroy();
        this.unscheduleAllCallbacks();
        PushCenter.shared().removeListenersByTag(this);
    }
    adapptationScreen() {
        let t = this.node.getChildByName("top_node").getChildByName("btn_close"), e = this.node.getChildByName("top_node").getChildByName("coin_bg"), a = this.node.getChildByName("top_node").getChildByName("add_coin"), i = this.node.getChildByName("top_node").getChildByName("act_node"), n = this.node.getChildByName("top_node").getChildByName("flopcash_btn");
        this.resetUiPos(t, AdapDirection.Left, true, 1, true);
        this.resetUiPos(e, AdapDirection.Left, true, 1, true);
        this.resetUiPos(n, AdapDirection.Left, true, 1, true);
        this.resetUiPos(a, AdapDirection.Right, true, 1, true, true);
        this.resetUiPos(i, AdapDirection.Right, true, 1, true, true);
    }
    start() {
        this.isAutoTouch = true;
        this.initView();
        this.addPushNotify();
        TweenTool.delayAct(this.node, (() => {
            ToolUtils.preLoadBundlePrefab(BundleNameDefined.bundle_public, "prefab/menu_alert", null);
        }), 0.5, true);
    }
    addPushNotify() {
        PushCenter.shared().addListener(GameConfig.Recharge, (t => {
            ToolUtils.isObjValid(this.node) && (FruitSlotGameManager.shared()._coin = User.shared().data.money, this.updateCoin(FruitSlotGameManager.shared()._coin));
        }), this);
        PushCenter.shared().addListener(PushEvent.UpdatePractiseGold_Room, (t => {
            ToolUtils.isObjValid(this.node) && (this.updateCoin(t), User.shared().send_refresh_laba());
        }), this);
        PushCenter.shared().addListener("slot_good_ani_finish", (t => {
            ToolUtils.isObjValid(this.node) && 1 != t && (3 == t ? this.show_win_num(true) : this.show_win_num(), 4 == t ? TweenTool.delayAct(this.node, (() => {
                this.button_state(0);
            }), 0, true) : this.button_state(0));
        }), this);
        PushCenter.shared().addListener("show_xyc_free_spins", (t => {
            ToolUtils.isObjValid(this.node) && 10 == FruitSlotGameManager.shared()._free_game_num && this.show_free_game(FruitSlotGameManager.shared()._free_game_num, true);
        }), this);
    }
    initView() {
        this.updateCoin(User.shared().data.money);
        this.autoSelectBgNode.active = false;
        this.winBgNode.getChildByName("win_num").active = false;
        this.winBgNode.getChildByName("free_bg").active = false;
        this.fast_return();
    }
    setRandomAdBtnEnable(t) {
        this.randomAdBtn.active = t;
    }
    setAdTreasureBtnEnable(t) {
        this.adTreasureBtn.active = t;
    }
    updateGullakBtnStatus(t, e, a) {
        let i = this.node.getChildByName("top_node").getChildByName("act_node").getChildByName("gullak_btn");
        if (ToolUtils.isObjValid(i) && (i.active = 1 == t, 1 == t)) {
            let t = i.getChildByName("anim").getComponent(sp.Skeleton);
            t.clearTracks();
            t.setToSetupPose();
            a ? (t.setAnimation(0, "2", false), t.setCompleteListener((() => {
                t.setCompleteListener(null);
                t.clearTracks();
                t.setToSetupPose();
                0 == e ? t.setAnimation(0, "0", true) : t.setAnimation(0, "1", true);
            }))) : 0 == e ? t.setAnimation(0, "0", true) : t.setAnimation(0, "1", true);
        }
    }
    updateJackPotPool(t, e) {
        Utils.playNumAnim(this.jcAmount.getComponent(Label), 0.8, t, e);
    }
    touchSelectAutoEvent(t, e) {
        if (SoundManager.shared().playFx("click"), sys.now() - this.lastClick < 500) {
            return;
        }
        this.lastClick = sys.now();
        let a = Number(e);
        if (this.autoSelectBgNode.active = false, a < this.autoBets.length) {
            let t = this.autoBets[a];
            FruitSlotGameManager.shared().sendAutoBetRequest(t);
        }
    }
    showMenuAlert() {
        try {
            ToolUtils.loadCommonPrefab(this.menualertPrefab, BundleNameDefined.bundle_public, "prefab/menu_alert", (t => {
                if (sys.isObjectValid(t) && t.isValid && sys.isObjectValid(this.node)) {
                    this.menualertPrefab = t;
                    let e = this.node.getChildByName("menu_alert");
                    if (!ToolUtils.isObjValid(e)) {
                        e = instantiate(t);
                        e.parent = this.node;
                        let a = e.getComponent("MenuAlert");
                        this.initMenu(a);
                    }
                }
            }));
        }
        catch (t) {
            TLog.printError("trycatch MainRummy onDealBtnAction set:", t);
        }
    }
    initMenu(t) {
        t.startShowAnim();
        t.setCallback(this.onMenuCallback.bind(this));
        t.setTidKey(User.shared().curTid_key);
        t.setLandscapeShow();
        t.setSevenUpMenuShow();
    }
    onMenuCallback(t) {
        SoundManager.shared().playFx("click");
        try {
            switch (String(t)) {
                case "exit":
                    this.dealCloseLogic();
                    break;
                case "setting":
                    this.dealSetLogic();
                    break;
                case "help": this.dealHelpLogic();
            }
        }
        catch (t) {
            TLog.printError("trycatch onMenuCallback:", t);
        }
    }
    touchBtnEvent(t, e) {
        if (SoundManager.shared().playFx("click"), !(sys.now() - this.lastClick < 500)) {
            switch ((this.lastClick = sys.now(), e)) {
                case "main_close":
                    this.showMenuAlert();
                    break;
                case "raisBetType1":
                    this.dealBetPlusOrMinusLogic(1);
                    break;
                case "raisBetType2":
                    this.dealBetPlusOrMinusLogic(2);
                    break;
                case "raisBetType_MAX":
                    this.dealBetPlusOrMinusLogic(3);
                    break;
                case "btn_auto":
                    this.dealAutoBtnLogic();
                    break;
                case "btn_spin":
                    this.dealSpinBtnLogic();
                    break;
                case "btn_fast":
                    this.dealFastBtnLogic();
                    break;
                case "add_chip":
                    let t = { vid: ToolUtils.curVId, min_entry: FruitSlotGameManager.shared()._raisBetlist[FruitSlotGameManager.shared()._betIndex], tid_key: FruitSlotGameManager.shared()._tidKey };
                    Utils.shared().showQuickRecharge(ToolUtils.curVId, FruitSlotGameManager.shared().popNode, true, User.shared().curTid_key, 0, t.min_entry, false, 0, 0, 0, 1), User.shared().updatePayScene(PhpReportDefined.pay_scene.game_desktop, ToolUtils.curVId);
                    break;
                case "jackpot":
                    this.dealJackPotLogic();
                    break;
                case "gullak":
                    let e = { vid: ToolUtils.curVId, parent_node: FruitSlotGameManager.shared().popNode };
                    Utils.shared().doJumpLogic(PushEvent.JUMP_TO_Gullak, e, { isNext: false, bWithTip: true, link_id: sys.now(), reportEvtId: 4, reportScene: 2 }), User.shared().updatePayScene(PhpReportDefined.pay_scene.game_desktop, ToolUtils.curVId);
                    break;
                case "flopcash": this.updateFlopGoldBannerStatus();
            }
        }
    }
    showRoomActRank(t) {
        ToolUtils.loadCommonPrefab(this.actRankPrefab, BundleNameDefined.bundle_public, "prefab/game_act_leaderboard", (e => {
            try {
                this.actRankPrefab = e;
                let a = FruitSlotGameManager.shared().popNode.getChildByName("game_act_leaderboard");
                ToolUtils.isObjValid(a) ? a.active = true : (a = instantiate(e), a.parent = FruitSlotGameManager.shared().popNode, a.setPosition(v3(0, -65)));
                a.getComponent("GameActLeaderBoard").initParaData(t);
            }
            catch (t) {
                TLog.printError("showRoomActRank error= " + t);
            }
        }));
    }
    updateFlopGoldBannerStatus() {
        let t = this.node.getChildByName("top_node").getChildByName("flopcash_btn");
        if (sys.isObjectValid(t)) {
            let e = t.getChildByName("banner").active;
            t.getChildByName("banner").active = !e;
        }
    }
    updateFlopGoldStatus(t, e) {
        let a = this.node.getChildByName("top_node").getChildByName("flopcash_btn");
        if (sys.isObjectValid(a)) {
            if (a.active = t, t) {
                if (sys.isObjectValid(e) && sys.isObjectValid(e.max_reward) ? (a.getChildByName("reward").getComponent(Label).string = String(e.max_reward) + "+", a.getChildByName("reward").active = true) : a.getChildByName("reward").active = false, sys.isObjectValid(e) && sys.isObjectValid(e.current_play_num) && sys.isObjectValid(e.target_play_num) && Number(e.target_play_num) > 0) {
                    a.getChildByName("progress").active = true;
                    a.getChildByName("progress").getComponent(ProgressBar).progress = Number(e.current_play_num) / Number(e.target_play_num);
                    a.getChildByName("wz").active = true;
                    a.getChildByName("wz").getComponent(Label).string = String(e.current_play_num) + "/" + String(e.target_play_num);
                    a.getChildByName("banner").getChildByName("task_progress").getComponent(ProgressBar).progress = e.current_play_num / e.target_play_num;
                    a.getChildByName("banner").getChildByName("task_progress_wz").getComponent(Label).string = String(e.current_play_num) + "/" + String(e.target_play_num);
                    let t = ToolUtils.format(i18nMgr.shared().getValueByKey("flop_cash.task"), e.target_play_num);
                    a.getChildByName("banner").getChildByName("task").getComponent(Label).string = t;
                }
                else {
                    a.getChildByName("progress").active = false;
                    a.getChildByName("wz").active = false;
                }
            }
            sys.isObjectValid(e) && sys.isObjectValid(e.today_task_status) && 2 == e.today_task_status && (a.active = false);
        }
    }
    dealJackPotLogic() {
        try {
            ToolUtils.loadCommonPrefab(this.jackPotPrefab, BundleNameDefined.Bundle_FruitMachine, "prefab/fruit_slot_game_jp", (t => {
                if (sys.isObjectValid(t) && t.isValid && sys.isObjectValid(this.node)) {
                    this.jackPotPrefab = t;
                    let e = this.node.getChildByName("fruit_slot_game_jp");
                    ToolUtils.isObjValid(e) || (e = instantiate(t), e.parent = this.node);
                }
            }));
        }
        catch (t) {
            TLog.printError("trycatch  set:", t);
        }
    }
    dealSetLogic() {
        ToolUtils.loadCommonPrefab(this.gameSettingPrefab, BundleNameDefined.bundle_public, "prefab/game_setting", (t => {
            this.gameSettingPrefab = t;
            this.showSettingAlert();
        }));
    }
    showSettingAlert() {
        try {
            if (!ToolUtils.isObjValid(FruitSlotGameManager.shared().popNode.getChildByName("game_setting"))) {
                let t = instantiate(this.gameSettingPrefab);
                t.name = "game_setting";
                t.parent = FruitSlotGameManager.shared().popNode;
                let e = t.getComponent("GameSetting");
                e.startShowAnim();
                e.updateInfo(1);
                e.setLandscapeShow();
            }
        }
        catch (t) {
            TLog.printError("show room setting err:", t);
        }
    }
    updateSmallBtnState(t, e) {
        ToolUtils.isObjValid(t) && (t.getComponent(Sprite).spriteFrame = 0 == e ? this.smallBtnImgs[0] : this.smallBtnImgs[1], t.getComponent(Button).interactable = 1 == e);
    }
    updateBigBtnState(t, e) {
        ToolUtils.isObjValid(t) && (t.getComponent(Sprite).spriteFrame = 0 == e ? this.bigBtnImgs[0] : this.bigBtnImgs[1], t.getComponent(Button).interactable = 1 == e);
    }
    updateAutoBtnState() {
        let t = FruitSlotGameManager.shared()._isAuto, e = this.autoBtnNode.getChildByName("auto_select"), a = this.autoBtnNode.getChildByName("Text"), i = this.autoBtnNode.getChildByName("auto_img"), n = this.autoBtnNode.getChildByName("auto_text");
        0 == t ? (i.active = false, n.active = true, a.active = false, this.isAutoTouch ? e.getComponent(Sprite).spriteFrame = this.autoImgs[1] : e.getComponent(Sprite).spriteFrame = this.autoImgs[0]) : (i.active = false, n.active = false, a.active = true, e.getComponent(Sprite).spriteFrame = this.autoImgs[2], FruitSlotGameManager.shared()._autoNum <= 0 ? (i.active = true, n.active = false, a.active = false) : a.getComponent(Label).string = "" + FruitSlotGameManager.shared()._autoNum);
    }
    show_win_num(t, e) {
        if (FruitSlotGameManager.shared()._winscore > 0 || FruitSlotGameManager.shared()._free_game_total_win > 0) {
            if (sys.isObjectValid(t)) {
                if (this.winBgNode.getChildByName("win_num").active = true, 2 == FruitSlotGameManager.shared()._game_state_type) {
                    let t = FruitSlotGameManager.shared()._free_game_total_win;
                    sys.isObjectValid(e) && (t = e);
                    this.winBgNode.getChildByName("win_num").getComponent(Label).string = ToolUtils.parse_double(t + "");
                }
                else {
                    let t = FruitSlotGameManager.shared()._winscore;
                    sys.isObjectValid(e) && (t = e);
                    this.winBgNode.getChildByName("win_num").getComponent(Label).string = ToolUtils.parse_double(t + "");
                }
            }
            else {
                this.number_beat_Anim();
            }
        }
        else {
            this.winBgNode.getChildByName("win_num").getComponent(Label).string = "0";
            this.winBgNode.getChildByName("win_num").active = false;
        }
    }
    hide_win_num() {
        this.winBgNode.getChildByName("win_num").getComponent(Label).string = "0";
        this.winBgNode.getChildByName("win_num").active = false;
    }
    button_state(t) {
        if (3 == t) {
            let t = FruitSlotGameManager.shared()._raisBetlist, e = FruitSlotGameManager.shared()._betIndex;
            0 == e ? this.updateSmallBtnState(this.bottomNode.getChildByName("btn_lessen"), 0) : this.updateSmallBtnState(this.bottomNode.getChildByName("btn_lessen"), 1);
            e == t.length - 1 ? (this.updateSmallBtnState(this.bottomNode.getChildByName("btn_add"), 0), this.updateSmallBtnState(this.bottomNode.getChildByName("btn_max"), 0)) : (this.updateSmallBtnState(this.bottomNode.getChildByName("btn_add"), 1), this.updateSmallBtnState(this.bottomNode.getChildByName("btn_max"), 1));
            this.updateBigBtnState(this.bottomNode.getChildByName("btn_spin"), 1);
            this.updateSmallBtnState(this.bottomNode.getChildByName("btn_auto"), 1);
            this.isAutoTouch = true;
            1 != FruitSlotGameManager.shared()._isAuto && (this.autoBtnNode.getChildByName("auto_img").active = false, this.autoBtnNode.getChildByName("auto_text").active = true, this.autoBtnNode.getChildByName("auto_select").getComponent(Sprite).spriteFrame = this.autoImgs[1]);
        }
        else if (1 == t || 1 == FruitSlotGameManager.shared()._isAuto || FruitSlotGameManager.shared()._free_game_num > 0) {
            this.updateSmallBtnState(this.bottomNode.getChildByName("btn_lessen"), 0);
            this.updateSmallBtnState(this.bottomNode.getChildByName("btn_add"), 0);
            this.updateSmallBtnState(this.bottomNode.getChildByName("btn_max"), 0);
            this.updateBigBtnState(this.bottomNode.getChildByName("btn_spin"), 0);
            1 == FruitSlotGameManager.shared()._isAuto || FruitSlotGameManager.shared()._free_game_num > 0 ? (this.updateSmallBtnState(this.bottomNode.getChildByName("btn_auto"), 1), this.isAutoTouch = true, 1 != FruitSlotGameManager.shared()._isAuto && (this.autoBtnNode.getChildByName("auto_img").active = false, this.autoBtnNode.getChildByName("auto_text").active = true, this.autoBtnNode.getChildByName("auto_select").getComponent(Sprite).spriteFrame = this.autoImgs[1])) : (this.updateSmallBtnState(this.bottomNode.getChildByName("btn_auto"), 0), this.isAutoTouch = false, this.autoBtnNode.getChildByName("auto_img").active = false, this.autoBtnNode.getChildByName("auto_text").active = true, this.autoBtnNode.getChildByName("auto_select").getComponent(Sprite).spriteFrame = this.autoImgs[0]);
        }
        else {
            let t = FruitSlotGameManager.shared()._raisBetlist, e = FruitSlotGameManager.shared()._betIndex;
            0 == e ? this.updateSmallBtnState(this.bottomNode.getChildByName("btn_lessen"), 0) : this.updateSmallBtnState(this.bottomNode.getChildByName("btn_lessen"), 1);
            e == t.length - 1 ? (this.updateSmallBtnState(this.bottomNode.getChildByName("btn_add"), 0), this.updateSmallBtnState(this.bottomNode.getChildByName("btn_max"), 0)) : (this.updateSmallBtnState(this.bottomNode.getChildByName("btn_add"), 1), this.updateSmallBtnState(this.bottomNode.getChildByName("btn_max"), 1));
            this.updateBigBtnState(this.bottomNode.getChildByName("btn_spin"), 1);
            this.updateSmallBtnState(this.bottomNode.getChildByName("btn_auto"), 1);
            this.isAutoTouch = true;
            1 != FruitSlotGameManager.shared()._isAuto && (this.autoBtnNode.getChildByName("auto_img").active = false, this.autoBtnNode.getChildByName("auto_text").active = true, this.autoBtnNode.getChildByName("auto_select").getComponent(Sprite).spriteFrame = this.autoImgs[1]);
        }
    }
    number_beat_Anim1(t, e, a) {
        let i = e - t, n = 0;
        n = i < 10 ? 3 : i > 9 && i < 100 ? 5 : i > 99 && i < 1000 ? 10 : i > 999 && i < 10000 ? 20 : i > 9999 && i < 100000 ? 30 : 40;
        n += 1;
        let s = Math.floor(i / n), o = 0;
        a.active = true;
        for (let e = 0; e < n; e++) {
            o += 0.03;
            TweenTool.delayAct(this.node, (() => {
                if (e == n - 1) {
                    a.getComponent(Label).string = ToolUtils.parse_double(i + "");
                }
                else {
                    let i = e * s, n = (e + 1) * s, o = ToolUtils.getRandomInt(i, n) + t, l = ToolUtils.parse_double(o + "");
                    a.getComponent(Label).string = l;
                }
            }), o);
        }
    }
    number_beat_Anim(t) {
        let e = t ?? FruitSlotGameManager.shared()._winscore;
        2 == FruitSlotGameManager.shared()._game_state_type && FruitSlotGameManager.shared()._jackpot_win > 0 && (e = FruitSlotGameManager.shared()._winscore + FruitSlotGameManager.shared()._jackpot_win);
        let a = 0;
        if (0 == e) {
            return;
        }
        a = e < 10 ? 3 : e > 9 && e < 100 ? 5 : e > 99 && e < 1000 ? 10 : e > 999 && e < 10000 ? 20 : e > 9999 && e < 100000 ? 30 : 40;
        a += 1;
        let i = Math.floor(t / a), n = 0, s = this.winBgNode.getChildByName("win_num").getComponent(Label);
        if (2 == FruitSlotGameManager.shared()._game_state_type) {
            let t = s.string;
            n = Number(t);
        }
        let o = 0;
        for (let t = 0; t < a; t++) {
            o += 0.03;
            TweenTool.delayAct(this.node, (() => {
                if (t == a - 1) {
                    2 == FruitSlotGameManager.shared()._game_state_type && FruitSlotGameManager.shared()._free_game_total_win > 0 ? s.string = ToolUtils.parse_double(FruitSlotGameManager.shared()._free_game_total_win + "") : s.string = ToolUtils.parse_double(e + "");
                }
                else {
                    let e = t * i, a = (t + 1) * i, o = ToolUtils.getRandomInt(e, a) + n, l = ToolUtils.parse_double(o + "");
                    s.node.active = true;
                    s.string = l;
                    SoundManager.shared().playFx("jinbitiaodong");
                }
            }), o, true);
        }
    }
    show_free_game(t, e) {
        if (t > 0) {
            if (e) {
                let t = TweenTool.fadeInOrOut(this.winBgNode.getChildByName("free_bg"), 0.2, 0, 255);
                this.winBgNode.getChildByName("free_bg").getComponent(UIOpacity).opacity = 0;
                this.winBgNode.getChildByName("free_bg").active = true;
                t.start();
            }
            else {
                this.winBgNode.getChildByName("free_bg").active = true;
            }
            this.winBgNode.getChildByName("free_bg").getChildByName("free_num").getComponent(Label).string = "" + t;
        }
        else {
            this.winBgNode.getChildByName("free_bg").active = false;
        }
    }
    updateMultiple() {
    }
    dealFastBtnLogic() {
        0 == FruitSlotGameManager.shared()._isfast ? FruitSlotGameManager.shared().sendSpeedRequest(1) : FruitSlotGameManager.shared().sendSpeedRequest(0);
    }
    fast_return() {
        1 == FruitSlotGameManager.shared()._isfast ? this.bottomNode.getChildByName("btn_fast").getChildByName("ico").getComponent(Sprite).spriteFrame = this.fastBtnImgs[1] : this.bottomNode.getChildByName("btn_fast").getChildByName("ico").getComponent(Sprite).spriteFrame = this.fastBtnImgs[0];
    }
    dealSpinBtnLogic() {
        this.autoSelectBgNode.active = false;
        FruitSlotGameManager.shared()._betIndex;
        FruitSlotGameManager.shared().sendBetRequest();
    }
    dealAutoBtnLogic() {
        if (0 == FruitSlotGameManager.shared()._isAuto) {
            let t = this.autoSelectBgNode.active;
            this.autoSelectBgNode.active = !t;
        }
        else {
            FruitSlotGameManager.shared().sendAutoBetRequest();
        }
    }
    dealBetPlusOrMinusLogic(t) {
        let e = FruitSlotGameManager.shared()._betIndex, a = FruitSlotGameManager.shared()._raisBetlist;
        1 == t && e > 0 ? e -= 1 : 2 == t && e < a.length - 1 ? e += 1 : 3 == t && (e = a.length - 1);
        FruitSlotGameManager.shared().sendBetChangeRequest(e);
    }
    updateCoin(t) {
        this.text_coin.getComponent(Label).string = ToolUtils.parse_double(t + "");
    }
    setLeaderBoardsBtnVisible(t) {
    }
    showLeaderBoardsFloatWord(t) {
    }
    judgeCoin(t) {
        let e = User.shared().data.money;
        if (sys.isObjectValid(FruitSlotGameManager.shared()._raisBetlist[t]) && e < FruitSlotGameManager.shared()._raisBetlist[t]) {
            let e = { vid: ToolUtils.curVId, min_entry: FruitSlotGameManager.shared()._raisBetlist[t] };
            return Utils.shared().showQuickRecharge(ToolUtils.curVId, FruitSlotGameManager.shared().popNode, true, User.shared().curTid_key, 0, e.min_entry), true;
        }
        return false;
    }
    dealHelpLogic() {
        let t = {};
        t.parent = FruitSlotGameManager.shared().popNode;
        t.isLandscape = true;
        t.target_sp = this.helpImg;
        t.game_type = CommonGameType.FruitMachine;
        Utils.shared().showSingleGameRuleHelpView(t);
    }
    dealCloseLogic() {
        let t = { bLandscape: ToolUtils.getIsNormalDirection(), bWithCancel: false, strContent: "Are you sure you want to leave the table?", bWithNativeAd: true };
        Utils.shared().showCommonAlert(t, (t => {
            1 == t && PushCenter.shared().pushEvent(PushEvent.ExitGameToHall);
        }), false);
    }
    updateTextBetAmount() {
        let t = FruitSlotGameManager.shared()._raisBetlist, e = FruitSlotGameManager.shared()._betIndex;
        1 == FruitSlotGameManager.shared()._isAuto && FruitSlotGameManager.shared()._free_game_num > 0 && (this.updateSmallBtnState(this.bottomNode.getChildByName("btn_lessen"), 0), this.updateSmallBtnState(this.bottomNode.getChildByName("btn_add"), 0), this.updateSmallBtnState(this.bottomNode.getChildByName("btn_max"), 0), this.text_betAmount.getComponent(Label).string = t[e]);
        0 == e ? this.updateSmallBtnState(this.bottomNode.getChildByName("btn_lessen"), 0) : this.updateSmallBtnState(this.bottomNode.getChildByName("btn_lessen"), 1);
        e == t.length - 1 ? (this.updateSmallBtnState(this.bottomNode.getChildByName("btn_add"), 0), this.updateSmallBtnState(this.bottomNode.getChildByName("btn_max"), 0)) : (this.updateSmallBtnState(this.bottomNode.getChildByName("btn_add"), 1), this.updateSmallBtnState(this.bottomNode.getChildByName("btn_max"), 1));
        this.text_betAmount.getComponent(Label).string = t[e];
    }
}
