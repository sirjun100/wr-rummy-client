// @ts-nocheck
// Recovered from index.js:43
import { _decorator, color, instantiate, Label, Node, ProgressBar, size, sp, Sprite, SpriteAtlas, SpriteFrame, sys, UIOpacity, UITransform, v3 } from "cc";
import BaseLayer from "./BaseLayer";
import SoundManager from "./SoundManager";
import PushEvent from "./PushEvent";
import Utils from "./Utils";
import User from "./User";
import TweenTool from "./TweenTool";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("BonusForestGuide")
export class BonusForestGuide extends BaseLayer {
    @property(Node)
    public rootNode: Node = null;
    @property(Label)
    public timeLabel: Label = null;
    @property(Node)
    public treeNode: Node = null;
    @property(ProgressBar)
    public progressBar: ProgressBar = null;
    @property(Node)
    public giftNode: Node = null;
    @property(Node)
    public giftMoban: Node = null;
    @property(Node)
    public growNode: Node = null;
    @property(SpriteAtlas)
    public forestTreeAtlas: SpriteAtlas = null;
    @property([SpriteFrame])
    public giftSpriteFrame: SpriteFrame[] = [];
    public isNext: boolean = false;
    public treeData: any = null;
    public _lastClick: number = 0;
    public _leftTime: number = 0;
    public _scheduleTime: any = null;
    public _scene: number = 1;
    public _linkId: number = 0;
    public _has_close: boolean = false;
    public _pop_souce: number = 0;
    initParaData(e) {
        sys.isObjectValid(e) && (sys.isObjectValid(e.isNext) && (this.isNext = e.isNext), sys.isObjectValid(e.pop_souce) && (this._pop_souce = e.pop_souce), sys.isObjectValid(e.reportScene) && (this._scene = e.reportScene), sys.isObjectValid(e.link_id) && e.link_id > 0 && (this._linkId = e.link_id), sys.isObjectValid(e.tree) && (this.treeData = e.tree));
    }
    onLoad() {
        this.giftMoban.active = false;
        this.startShowAnim(this.rootNode);
    }
    start() {
        super.start();
        this._linkId = this._linkId > 0 ? this._linkId : sys.now();
        sys.isObjectValid(this.treeData) && this.initView();
    }
    initView() {
        this._leftTime = this.treeData.left;
        this.refreshLeftTime();
        this._scheduleTime && this._scheduleTime.stop();
        this._scheduleTime = TweenTool.myschedule(this.node, 1, (() => {
            this._leftTime = this._leftTime - 1;
            this._leftTime >= 0 ? this.refreshLeftTime() : this._scheduleTime.stop();
        }));
        Utils.shared().setImage(this.treeNode, ToolUtils.format("tree${0}_${1}", this.treeData.sid, this.treeData.node), this.forestTreeAtlas);
        let e = this.getProgressBarPercent(this.treeData.current);
        this.progressBar.progress = e;
        this.growNode.active = 1 == this.treeData.status;
        let t = this.progressBar.node.getComponent(UITransform).contentSize.width;
        this.progressBar.node.getChildByName("Mask").getComponent(UITransform).setContentSize(size(518 - t * e + 3, 30));
        let i = this.getProgressBarPercent(this.treeData.current + this.treeData.water);
        if (this.progressBar.node.getChildByName("Mask").getChildByName("img").getComponent(UITransform).setContentSize(size(t * i + 10, 30)), this.playWateringProgressAnim(this.progressBar.node.getChildByName("Mask").getChildByName("img")), 1 == this.treeData.status) {
            this.growNode.setPosition(v3(t * e - t / 2, -190));
            this.growNode.getChildByName("num").getComponent(Label).string = String(Math.floor(Number(this.treeData.current)));
            this.growNode.getChildByName("num").getComponent(Label).updateRenderData(true);
            let i = this.growNode.getChildByName("num").getComponent(UITransform).contentSize.width, s = i > 20 ? i : 20;
            this.growNode.getComponent(UITransform).setContentSize(size(s + 30, 32));
        }
        if (this.giftNode.removeAllChildren(), this.giftMoban.active = false, sys.isObjectValid(this.treeData.node_list) && this.treeData.node_list.length) {
            for (let e = 0, i = this.treeData.node_list.length + 1; e < i; e++) {
                let i = instantiate(this.giftMoban);
                this.giftNode.addChild(i);
                i.setPosition(v3(0, 0));
                i.active = true;
                this.initGiftMoabnView(i, this.treeData.node_list[e - 1], e, this.treeData.node_list.length, t, this.treeData.current);
            }
        }
    }
    initGiftMoabnView(e, t, i, s, o, n = 0) {
        if (0 == i) {
            e.getChildByName("icon").active = false;
            e.getChildByName("num").getComponent(Label).string = "0";
            let t = 0 == n ? 255 : 153;
            e.getChildByName("num").getComponent(UIOpacity).opacity = t;
            e.setPosition(v3(-o / 2, 0));
        }
        else {
            e.getChildByName("icon").active = true;
            this.giftSpriteFrame[t.complete] && (e.getChildByName("icon").getComponent(Sprite).spriteFrame = this.giftSpriteFrame[t.complete]);
            0 == t.complete && t.grow <= this.treeData.current + this.treeData.water ? (e.getChildByName("anim").active = true, e.getChildByName("anim").getComponent(sp.Skeleton).clearTracks(), e.getChildByName("anim").getComponent(sp.Skeleton).setAnimation(0, "giftglow", true), e.getChildByName("icon").active = false) : (e.getChildByName("anim").active = false, e.getChildByName("icon").active = true);
            e.getChildByName("num").getComponent(Label).string = t.grow;
            let n = 0 == t.complete ? 255 : 153;
            e.getChildByName("num").getComponent(UIOpacity).opacity = n;
            let a = 0;
            s > 0 && (a = o / s);
            let l = i == s ? o / 2 - 10 : -o / 2 + a * i - 10;
            e.setPosition(v3(l, 0));
        }
    }
    getProgressBarPercent(e) {
        let t = 0, i = this.treeData.node_list.length;
        for (let s = i - 1; s >= 0; s--) {
            if (s > 0) {
                if (e >= this.treeData.node_list[s - 1].grow) {
                    t = ((e - this.treeData.node_list[s - 1].grow) / (this.treeData.node_list[s].grow - this.treeData.node_list[s - 1].grow) + s) / i;
                    break;
                }
            }
            else {
                t = e / this.treeData.node_list[0].grow / i;
            }
        }
        return t;
    }
    playWateringProgressAnim(e) {
        TweenTool.stopNodeAction(e);
        e.getComponent(Sprite).color = color(255, 255, 255, 255);
        let t = TweenTool.moveSpriteByFade(e, 20 / 30, v3(-528, 0), 1, 0.78, false), i = TweenTool.moveSpriteByFade(e, 20 / 30, v3(-528, 0), 0.78, 1, false), s = TweenTool.sequence(e, false, null, t, i);
        s.repeatForever();
        s.start();
    }
    refreshLeftTime() {
        this.timeLabel.string = Utils.shared().parseCountDownToSec(this._leftTime);
        this._leftTime <= 0 && (this.timeLabel.string = "0m 0s");
    }
    onButtonClick(e, t) {
        SoundManager.shared().playFx("click");
        sys.now() - this._lastClick < 500 || (this._lastClick = sys.now(), "close" == t ? this.onBackView() : "go" == t && (Utils.shared().doJumpLogic(PushEvent.JUMP_TO_BonusForest, { from_source: 1 }, { isNext: false, bWithTip: true, reportScene: this._scene, reportEvtId: 15, link_id: this._linkId }), ToolUtils.isObjValid(this.node) && this.node.destroy()));
    }
    onBackView() {
        if (this._has_close) {
            return;
        }
        let e = { alert_node: this.node, rootNode: this.rootNode, isNext: this.isNext, pop_type: PushEvent.JUMP_TO_BonusForest, pop_souce: this._pop_souce };
        Utils.shared().closeActivityView(e);
        this._has_close = true;
        User.shared().getHallInfo();
    }
}
