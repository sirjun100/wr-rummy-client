// @ts-nocheck
// Recovered from index.js:383
import { _decorator, color, isValid, Label, Node, ScrollView, HorizontalTextAlignment, VerticalTextAlignment, Overflow, Layout, size, Sprite, SpriteFrame, UITransform, v3, Vec3 } from "cc";
import SoundManager from "./SoundManager";
import BaseLayer from "./BaseLayer";
import { ToolUtils } from "./ToolUtils";
import User from "./User";
import i18nMgr from "./i18nMgr";
import GameConfig from "./GameConfig";
const { ccclass, property } = _decorator;
@ccclass("regular_node")
export default class regular_node extends BaseLayer {
    public lastNodeName: string = "";
    @property(Node)
    public bg: Node = null;
    @property(Node)
    public rummy_select: Node = null;
    @property(Node)
    public rule_sp: Node = null;
    @property(Node)
    public rule_type: Node = null;
    @property(Node)
    public rule_easy: Node = null;
    @property(Node)
    public rule_multiple: Node = null;
    @property(Node)
    public rule_bump: Node = null;
    @property(Node)
    public rule_double: Node = null;
    @property(Node)
    public rule_content: Node = null;
    @property([SpriteFrame])
    public game_rules: SpriteFrame[] = [];
    @property([SpriteFrame])
    public btn_imgs: SpriteFrame[] = [];
    public tab_data: any = null;
    public _isEasy: boolean = false;
    public _isMultiple: boolean = false;
    public _isBump: boolean = false;
    public tabWzColor: any = color(111, 0, 0);
    onLoad() {
        this.lastNodeName = "point";
        this.fitLuckyTheme();
    }
    fitLuckyTheme() {
        0 != GameConfig.NATIVE_GAME_APP_TYPE && (this.tabWzColor = color(38, 59, 152));
    }
    start() {
        super.start();
        ToolUtils.showFullScreen(this.node.getChildByName("bg_color"));
        this.startShowAnim(this.bg);
    }
    showByData(e) {
        let t;
        "" == this.lastNodeName && (this.lastNodeName = "point");
        this.rummy_select.getChildByName(this.lastNodeName).getChildByName("wz").getComponent(Label).color = color(0, 0, 0);
        this.rummy_select.getChildByName(this.lastNodeName).getChildByName("di").getComponent(Sprite).spriteFrame = this.btn_imgs[1];
        i18nMgr.shared().changeLabelFont(this.rummy_select.getChildByName(this.lastNodeName).getChildByName("wz").getComponent(Label), false);
        isValid(this.rummy_select.getChildByName(e), true) || (e = this.lastNodeName);
        this.rummy_select.getChildByName(e).getChildByName("wz").getComponent(Label).color = this.tabWzColor;
        this.rummy_select.getChildByName(e).getChildByName("di").getComponent(Sprite).spriteFrame = this.btn_imgs[0];
        i18nMgr.shared().changeLabelFont(this.rummy_select.getChildByName(e).getChildByName("wz").getComponent(Label), true);
        this.lastNodeName = e;
        "point" == e ? t = this.game_rules[0] : "pool" == e ? t = this.game_rules[1] : "deal" == e && (t = this.game_rules[2]);
        let i = this.bg.getChildByName("scrollview");
        i.getComponent(ScrollView).stopAutoScroll();
        i.getComponent(ScrollView).scrollToTop();
        this.rule_sp.getComponent(Sprite).spriteFrame = t;
        this.rule_sp.active = true;
        this.showDealsRules(e === "deal");
        "point" == e ? (1 == User.shared().double_6_open || 1 == User.shared().chip_double_6_open ? this.rule_type.active = this.rule_double.active = 1 == User.shared().double_6_open || 1 == User.shared().chip_double_6_open : this.rule_type.active = this.rule_double.active = false, this.rule_content.active = true) : this.rule_type.active = this.rule_double.active = this.rule_content.active = false;
    }
    showDealsRules(show) {
        // Deals rules used to be baked into an image describing only 2/3 deals.
        // Keep them as text so the six-player format is explicit and maintainable.
        this.rule_sp.getComponent(Sprite).enabled = !show;
        let node = this.rule_sp.getChildByName("deals_rules_text");
        if (!show) { if (node) node.active = false; return; }
        if (!node) {
            node = new Node("deals_rules_text");
            node.parent = this.rule_sp;
            node.layer = this.rule_sp.layer;
            const transform = node.addComponent(UITransform);
            transform.setAnchorPoint(0.5, 1);
            transform.setContentSize(this.bg.getChildByName("scrollview").getComponent(UITransform).width - 40, 2300);
            const label = node.addComponent(Label);
            label.fontSize = 24;
            label.lineHeight = 36;
            label.color = color(49, 49, 49);
            label.horizontalAlign = HorizontalTextAlignment.LEFT;
            label.verticalAlign = VerticalTextAlignment.TOP;
            label.overflow = Overflow.RESIZE_HEIGHT;
            label.enableWrapText = true;
            label.string = "GOAL\n\nArrange all 13 cards into valid sequences and sets. A valid declaration needs at least two sequences, including one pure sequence. The remaining cards must also form valid groups.\n\nDEAL FORMATS\n\n2 players: choose 2 or 3 deals.\n6 players: choose 3 or 6 deals.\nCheck Table Info for the number of deals, entry fee and prizes at your table. The entry fee is paid once for the match.\n\nPLAY\n\nOn your turn, draw one card from the closed deck or the open discard pile, then discard one card. Declare only when the remaining 13 cards form a valid hand. Other players submit their groups after a valid declaration.\n\nSCORING\n\nPlayers start with 80 chips per scheduled deal. The hand winner receives the chips lost by the other players. A losing hand is scored up to 80 points. A, K, Q and J count as 10; numbered cards count at face value; Jokers count as 0. Valid groups reduce the penalty only when the required sequences are present.\n\nThe winner of one hand is not necessarily the match winner. Match ranking uses the final chip totals. See the final scoreboard for prizes and any tie-break.\n\nDROP AND LEAVE\n\nVoluntary Drop is unavailable in 2-player Deals. In 6-player Deals, an early Drop costs 20 points; a middle Drop costs 40. Dropping a hand keeps you in the match. Leaving the match forfeits participation; it does not refund the entry fee.\n\nJOKERS AND GROUPS\n\nA pure sequence has at least three consecutive cards of the same suit without a substitute Joker. An impure sequence can use a Joker to replace a missing card. A set contains three or four cards of the same rank in different suits and may use Jokers.\n\nAces can be low (A-2-3) or high (Q-K-A), but K-A-2 is invalid. Printed Jokers and cards of the selected wild rank can substitute in valid groups.";
        }
        node.active = true;
        node.getComponent(Label).updateRenderData(true);
        const bounds = this.rule_sp.getComponent(UITransform);
        bounds.setContentSize(bounds.width, node.getComponent(UITransform).height + 40);
        node.setPosition(v3(0, -20, 0));
        const layout = this.rule_sp.parent.getComponent(Layout);
        if (layout) layout.updateLayout();
    }
    updateInfo(e, t = false, i = false, l = false) {
        this._isMultiple = t;
        this._isEasy = i;
        this._isBump = l;
        this.showByData(e);
    }
    onClickByTab(e, t) {
        this.tab_data != t && (SoundManager.shared().playFx("click"), this.tab_data = t, this.showByData(t));
    }
    hideBack() {
    }
    setLandscapeShow() {
        ToolUtils.getOrientation() || this.node.setRotationFromEuler(v3(0, 0, -90));
        let e = this.node.getChildByName("bg_color");
        ToolUtils.showFullScreen(e);
        let t = this.bg.getChildByName("bg").getComponent(UITransform).contentSize;
        this.bg.getChildByName("bg").getComponent(UITransform).setContentSize(size(t.width, 609));
        this.bg.getChildByName("bg").setPosition(v3(0, 35));
        let i = new Vec3;
        this.bg.getChildByName("top").getPosition(i);
        this.bg.getChildByName("top").setPosition(v3(i.x, -148, i.z));
        let l = this.bg.getChildByName("scrollview");
        l.setPosition(v3(0, -34));
        let o = l.getComponent(UITransform);
        o.setContentSize(size(o.contentSize.width, o.contentSize.height - 377));
    }
    onClickByBtn(e, t) {
        SoundManager.shared().playFx("click");
        "close" == t && ToolUtils.isObjValid(this.node) && this.node.destroy();
    }
    setTidKey(e) {
        this.tid_key = e;
        this.bIsInGame = true;
    }
}
