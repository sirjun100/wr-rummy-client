// @ts-nocheck
// Recovered from index.js:449
import { _decorator, Label, Node } from "cc";
import SoundManager from "./SoundManager";
import RummyDataManager from "./RummyDataManager";
import Utils from "./Utils";
import User from "./User";
import RummyCmd from "./RummyCmd";
import Server from "./Server";
import TweenTool from "./TweenTool";
import i18nMgr from "./i18nMgr";
import BaseLayer from "./BaseLayer";
import { ToolUtils } from "./ToolUtils";
import PhpReportDefined from "./PhpReportDefined";
const { ccclass, property } = _decorator;
@ccclass("RummyGamePoolPop")
export default class RummyGamePoolPop extends BaseLayer {
    @property(Label)
    public title: Label = null;
    @property(Node)
    public rejoin_layer: Node = null;
    @property(Node)
    public rejoin1_layer: Node = null;
    @property(Node)
    public playagain_layer: Node = null;
    @property(Node)
    public playagain1_layer: Node = null;
    @property(Node)
    public areyouthere_layer: Node = null;
    @property(Node)
    public autosplit_layer: Node = null;
    @property(Node)
    public playagain2_layer: Node = null;
    public typeNum: number = 0;
    public data: any = undefined;
    public gameController: any = undefined;
    public joinlayerTime: number = 0;
    public time_action: any = null;
    onLoad() {
        this.bIsInGame = true;
    }
    start() {
        super.start();
        ToolUtils.showFullScreen(this.node.getChildByName("bg1"));
        ToolUtils.startShowAnim(this.node.getChildByName("rootNode"));
    }
    onDestroy() {
        super.onDestroy();
        this.time_action && (TweenTool.stopAction(this.time_action), this.time_action = null);
    }
    initView(e, t, a, i) {
        this.time_action && (TweenTool.stopAction(this.time_action), this.time_action = null);
        this.typeNum = e;
        this.data = t;
        this.gameController = a;
        this.tid_key = i;
        this.hideAllLayer();
        1 == this.typeNum ? this.showRejoinLayer() : 2 == this.typeNum ? this.showRejoin1Layer() : 3 == this.typeNum ? this.showPlayagainLayer() : 4 == this.typeNum ? this.showPlayagain1Layer() : 5 == this.typeNum ? this.showAreyouthereLayer() : 6 == this.typeNum || (7 == this.typeNum ? this.showAutoSplitLayer() : 8 == this.typeNum && this.showPlayagain2Layer());
    }
    hideAllLayer() {
        this.rejoin_layer.active = false;
        this.rejoin1_layer.active = false;
        this.playagain_layer.active = false;
        this.playagain1_layer.active = false;
        this.areyouthere_layer.active = false;
        this.autosplit_layer.active = false;
        this.playagain2_layer.active = false;
    }
    isShowQuickChargeAlert() {
        let e = false, t = RummyDataManager.shared().rummyInfos.get(this.tid_key);
        if (1 == t.crashModel) {
            if (User.shared().data.money_exe < t.entry_fee) {
                e = true;
                let a = { vid: t.vid, isShowTip: true, parent_node: this.gameController.node, bShowNetTip: true, tid_key: this.tid_key, min_entry: t.entry_fee };
                Utils.shared().showQuickChipRecharge(a);
            }
        }
        else {
            User.shared().data.money < t.entry_fee && (e = true);
            e && (Utils.shared().showQuickRecharge(t.vid, this.gameController.node, true, this.tid_key, 0, t.entry_fee), User.shared().updatePayScene(PhpReportDefined.pay_scene.game_gameover_less_money, Number(t.vid)));
        }
        return e;
    }
    touchBtnEvent(e, t) {
        SoundManager.shared().playFx("click");
        "close" == t ? 1 == this.typeNum ? this.handler_server_rejoin_request(0) : 3 == this.typeNum ? (this.gameController.exitCallBack(1), ToolUtils.isObjValid(this.node) && this.node.destroy()) : ToolUtils.isObjValid(this.node) && this.node.destroy() : "btn1" == t ? this.handler_server_rejoin_request(0) : "btn2" == t ? this.handler_server_rejoin_request(1) : "btn3" == t ? ToolUtils.isObjValid(this.node) && this.node.destroy() : "btn4" == t ? (this.gameController.exitCallBack(1), ToolUtils.isObjValid(this.node) && this.node.destroy()) : "btn5" == t ? (User.shared().send_client_consume_table_record_laba(this.tid_key), this.gameController.isDisconnect = false, this.gameController.isNewTable = 0, this.gameController.removeGameOverView(), this.gameController.onDealBtnAction("start")) : "btn9" == t ? ToolUtils.isObjValid(this.node) && this.node.destroy() : "btn10" == t && ToolUtils.isObjValid(this.node) && this.node.destroy();
    }
    showRejoinLayer() {
        i18nMgr.shared().changeLabelLanguage(this.title, "gameRummy_pool_pop.rejoin");
        this.rejoin_layer.active = true;
        this.joinlayerTime = this.data.cd || 10;
        let e = "";
        if (this.data.rejoin_score && (e = ToolUtils.format(i18nMgr.shared().getValueByKey("gameRummy_pool_pop.rejoin_game"), ToolUtils.parse_double(this.data.rejoin_score + "")), this.rejoin_layer.getChildByName("text1").getComponent(Label).string = e), this.data.rejoin_money) {
            let t = User.shared().data.money - this.data.rejoin_money;
            e = ToolUtils.format(i18nMgr.shared().getValueByKey("gameRummy_pool_pop.current_balance"), ToolUtils.parse_double(t + ""));
            this.rejoin_layer.getChildByName("text2").getComponent(Label).string = e;
        }
        this.data.rejoin_money && (e = ToolUtils.format(i18nMgr.shared().getValueByKey("gameRummy_pool_pop.deducted_with"), ToolUtils.parse_double(this.data.rejoin_money + "")), this.rejoin_layer.getChildByName("text3").getComponent(Label).string = e);
        e = ToolUtils.format(i18nMgr.shared().getValueByKey("gameRummy_pool_pop.second_left"), this.joinlayerTime);
        this.rejoin_layer.getChildByName("text4").getComponent(Label).string = e;
        this.time_action = TweenTool.myschedule(RummyDataManager.shared().sceneNode, 1, this.updateTime.bind(this));
    }
    updateTime() {
        if (ToolUtils.isObjValid(this.node)) {
            if (this.joinlayerTime = this.joinlayerTime - 1, this.joinlayerTime < 1) {
                ToolUtils.isObjValid(this.node) && this.node.destroy();
            }
            else {
                let e = "";
                e = ToolUtils.format(i18nMgr.shared().getValueByKey("gameRummy_pool_pop.second_left"), this.joinlayerTime);
                this.rejoin_layer.getChildByName("text4").getComponent(Label).string = e;
            }
        }
    }
    showRejoin1Layer() {
        i18nMgr.shared().changeLabelLanguage(this.title, "gameRummy_pool_pop.rejoin");
        this.rejoin1_layer.active = true;
        this.rejoin1_layer.getChildByName("text2").active = false;
        this.rejoin1_layer.getChildByName("text3").active = false;
        let e, t, a = "";
        for (let i = 0, r = this.data.players.length; i < r; i++) {
            e = this.data.players[i].seatid;
            t = RummyDataManager.shared().rummyInfos.get(this.tid_key).playerModels[e].name;
            a = i == r - 1 ? ToolUtils.format(i18nMgr.shared().getValueByKey("gameRummy_pool_pop.rejoined_table"), a, ToolUtils.GetShortName2(t, 10, true)) : a + ToolUtils.GetShortName2(t, 10, true) + "、";
        }
        a = ToolUtils.format(i18nMgr.shared().getValueByKey("gameRummy_pool_pop.prize_pool_updated"), a, this.data.score, ToolUtils.parse_double(this.data.pool_money));
        this.rejoin1_layer.getChildByName("text1").getComponent(Label).string = a;
    }
    showPlayagainLayer() {
        let e = RummyDataManager.shared().rummyInfos.get(this.tid_key).entry_fee;
        this.data.entry_fee && ToolUtils.isSafeNumber(this.data.entry_fee) > 0 && (e = this.data.entry_fee);
        i18nMgr.shared().changeLabelLanguage(this.title, "match_game_over.play_again");
        this.playagain_layer.active = true;
        let t = "";
        t = ToolUtils.format(i18nMgr.shared().getValueByKey("gameRummy_pool_pop.entry_fee"), ToolUtils.parse_double(e + ""));
        this.playagain_layer.getChildByName("text3").getComponent(Label).string = t;
    }
    showPlayagain1Layer() {
        i18nMgr.shared().changeLabelLanguage(this.title, "match_game_over.play_again");
        this.playagain1_layer.active = true;
    }
    showPlayagain2Layer() {
        i18nMgr.shared().changeLabelLanguage(this.title, "match_game_over.play_again");
        this.playagain2_layer.active = true;
    }
    showAreyouthereLayer() {
        i18nMgr.shared().changeLabelLanguage(this.title, "gameRummy_pool_pop.are_you_there");
        this.areyouthere_layer.active = true;
    }
    showAutoSplitLayer() {
        if (i18nMgr.shared().changeLabelLanguage(this.title, "gameRummy_pool_pop.auto_split"), this.autosplit_layer.active = true, null != this.data.prize) {
            let e = ToolUtils.format(i18nMgr.shared().getValueByKey("gameRummy_pool_pop.won"), ToolUtils.parse_double(this.data.prize + ""));
            1 == RummyDataManager.shared().rummyInfos.get(this.tid_key).crashModel && (e = ToolUtils.format(i18nMgr.shared().getValueByKey("gameRummy_pool_pop.won_practice"), ToolUtils.parse_double(this.data.prize + "")));
            this.autosplit_layer.getChildByName("text3").getComponent(Label).string = e;
        }
    }
    gameControllerRemove() {
        7 == this.typeNum || ToolUtils.isObjValid(this.node) && this.node.destroy();
    }
    handler_server_rejoin_request(e) {
        let t = { cmd: RummyCmd.GM_REJOIN_REQUEST, uid: User.shared().data.uid, tid_key: this.tid_key, status: e };
        Server.shared().send(t);
    }
    onBackView() {
    }
}
