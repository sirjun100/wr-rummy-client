// @ts-nocheck
// Recovered from index.js:631
import { _decorator, Component, Label, Node, size, UITransform, v3 } from "cc";
import TweenTool from "./TweenTool";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("ToastNode")
export default class ToastNode extends Component {
    @property(Node)
    public tipLabel: Node = null;
    @property(Node)
    public bgImg: Node = null;
    public time: number = 2;
    public delayAct: any = null;
    start() {
    }
    onDestroy() {
        this.delayAct && (TweenTool.stopAction(this.delayAct), this.delayAct = null);
        this.unscheduleAllCallbacks();
    }
    setTip(t, e, i = 0, o) {
        this.time = e;
        this.tipLabel.getComponent(Label).string = t;
        o || (this.node.setRotationFromEuler(v3(0, 0, 90)), this.node.setPosition(v3(0, 0, 0)));
        ToolUtils.getIsInRoom() ? 4 == i ? o ? this.node.setPosition(v3(this.node.getPosition().x, 270, 0)) : this.node.setPosition(v3(240, 0, 0)) : o ? this.node.setPosition(v3(this.node.getPosition().x, 120, 0)) : this.node.setPosition(v3(-120, 0, 0)) : 1 == i && ToolUtils.judgeIfInHall() ? this.node.setPosition(v3(this.node.getPosition().x, -95, 0)) : 4 == i && this.node.setPosition(v3(this.node.getPosition().x, -240, 0));
        this.scheduleOnce((() => {
            let t = this.bgImg.getComponent(UITransform), e = this.tipLabel.getComponent(UITransform), i = t.contentSize, o = e.contentSize;
            ToolUtils.getIsInRoom() ? t.setContentSize(size(i.width, o.height + 10)) : t.setContentSize(size(i.width, o.height + 20));
        }), 0);
        this.delayAct && (TweenTool.stopAction(this.delayAct), this.delayAct = null);
        this.delayAct = TweenTool.delayAct(this.node, (() => {
            ToolUtils.isObjValid(this.node) && this.node.destroy();
        }), this.time, true);
    }
}
