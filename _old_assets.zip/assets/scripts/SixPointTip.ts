// @ts-nocheck
// Recovered from index.js:539
import { _decorator, instantiate, Label, Node, sp, Sprite, SpriteFrame, sys, tween, UIOpacity, v3 } from "cc";
import Parent from "./Parent";
import PushCenter from "./PushCenter";
import SoundManager from "./SoundManager";
import { ToolUtils } from "./ToolUtils";
import { SixPointManager } from "./SixPointManager";
import TweenTool from "./TweenTool";
const { ccclass, property } = _decorator;
@ccclass("SixPointTip")
export default class SixPointTip extends Parent {
    public _TAG: string = "SixPointTip";
    @property(Node)
    public rollDiceAnim: Node = null;
    @property(Node)
    public stateAnim: Node = null;
    @property(Node)
    public stateBg: Node = null;
    @property(Node)
    public chipMoban: Node = null;
    @property(Node)
    public diceMoban: Node = null;
    @property([SpriteFrame])
    public coinChipFrame: SpriteFrame[] = [];
    @property([SpriteFrame])
    public diceFrame: SpriteFrame[] = [];
    @property(Node)
    public m_batchNode: Node = null;
    public lastClick: number = 0;
    public gameCallback: any = null;
    public betPosVec: any[] = [];
    public mBetTime: number = 0;
    public isStartAlert: boolean = false;
    public winAnim: any = null;
    public areaGoldsVec: any[] = [[], [], [], [], [], []];
    public areaGoldsVec_comm: any[] = [[], [], [], [], [], []];
    public leftAreaGoldVec: any[] = [];
    public mType: number = 0;
    public gameData: any = {};
    public rollTable: any[] = [];
    onLoad() {
    }
    onDestroy() {
        super.onDestroy();
        this.unscheduleAllCallbacks();
        PushCenter.shared().removeListenersByTag(this);
    }
    start() {
        this.initView();
        this.addPushNotify();
    }
    setCallBack(e) {
        this.gameCallback = e;
    }
    addPushNotify() {
    }
    initView() {
        this.betPosVec = [];
        this.mBetTime = 0;
        this.mType = 0;
        this.isStartAlert = false;
        this.winAnim = null;
        this.areaGoldsVec = [[], [], [], [], [], []];
        this.areaGoldsVec_comm = [[], [], [], [], [], []];
        this.leftAreaGoldVec = [];
        this.rollTable = [];
        for (let e = 0; e < 6; e++) {
            let e = instantiate(this.diceMoban);
            e.active = false;
            this.rollTable.push(e);
            this.node.getChildByName("anim_root").addChild(e);
        }
        this.reset();
    }
    reset() {
        this.areaGoldsVec = [[], [], [], [], [], []];
        this.areaGoldsVec_comm = [[], [], [], [], [], []];
        this.leftAreaGoldVec = [];
        this.m_batchNode.removeAllChildren();
        this.stateAnim.active = false;
        this.hideAllWinKuang();
        this.hideAllWinAnim();
        this.hideAllRool();
    }
    updateGameState(e, t) {
        if (this.stateBg.active = e > 0, e > 0) {
            let i = this.stateBg.getChildByName("text");
            if (ToolUtils.isObjValid(i)) {
                if (1 == t) {
                    let t = `Betting ends in ${e} sec`;
                    i.getComponent(Label).string = t;
                }
                else if (2 == t) {
                    let e = "Billing";
                    i.getComponent(Label).string = e;
                }
                else if (3 == t) {
                    let t = `Betting starts in ${e} sec`;
                    i.getComponent(Label).string = t;
                }
            }
        }
    }
    playRolldiceAnim(e, t) {
        if (ToolUtils.isObjValid(this.rollDiceAnim)) {
            this.rollDiceAnim.active = true;
            let i = this.rollDiceAnim.getComponent(sp.Skeleton);
            if (i.clearTracks(), i.setToSetupPose(), 0 == e) {
                i.setAnimation(0, "rolldice0", false);
                i.setCompleteListener(null);
            }
            else if (1 == e && sys.isObjectValid(t) && Array.isArray(t) && t.length > 0) {
                let e = "rolldice1", l = "ani_kairajakai_dice_";
                for (let e = 0; e < t.length; e++) {
                    let o = l + t[e] + "-1";
                    i.setAttachment("face" + (e + 1), o);
                }
                i.setAnimation(0, e, false);
                i.setCompleteListener((() => {
                    ToolUtils.isObjValid(this.node) && (i.setCompleteListener(null), this.showRollEffect());
                }));
                TweenTool.delayAct(this.node, (() => {
                    SoundManager.shared().playFx("saizi");
                }), 2.6, true);
            }
        }
    }
    hideAllRool() {
        for (let e = 0; e < 6; e++) {
            ToolUtils.isObjValid(this.rollTable[e]) && (this.rollTable[e].active = false);
        }
    }
    showRollEffect() {
        let e = [v3(487, 394), v3(586, 435), v3(728, 420), v3(512, 290), v3(648, 304), v3(790, 308)], t = [277, 571, 861, 277, 571, 861], i = [433, 433, 433, 255, 255, 255], l = [[], [], [], [], [], []], o = this.node.getChildByName("anim_root");
        for (let t = 0; t < SixPointManager.shared().diceinfo.length; t++) {
            let i = SixPointManager.shared().diceinfo[t];
            o.active = true;
            ToolUtils.isObjValid(this.rollTable[t]) && (this.rollTable[t].active = true, this.rollTable[t].scale = v3(1, 1), this.rollTable[t].getComponent(Sprite).spriteFrame = this.diceFrame[i - 1], this.rollTable[t].setPosition(e[t]), this.rollTable[t].roll = i, l[i - 1].push(this.rollTable[t]));
        }
        TweenTool.delayAct(this.node, (() => {
            this.playRolldiceAnim(0);
        }), 1.5, true);
        let a = 1.5, s = tween(o).delay(a), n = tween(o).call((() => {
            for (let e = 0; e < l.length; e++) {
                let o = l[e];
                for (let l = 0; l < o.length; l++) {
                    let a = o[l];
                    if (ToolUtils.isObjValid(a)) {
                        a.scale = v3(0.7, 0.7);
                        let o = 0, s = 0;
                        l >= 3 ? (s = i[e] - 56, o = t[e] + 72 * (l - 3)) : (s = i[e], o = t[e] + 72 * l);
                        TweenTool.moveTo(a, 0.3, v3(o, s), null, true);
                    }
                }
            }
        }));
        a += 7;
        let r = tween(o).delay(a), h = tween(o).call((() => {
            o.active = false;
        }));
        TweenTool.sequence(o, true, null, s, n, r, h);
    }
    getMinPosX(e) {
        return [234, 526, 818, 234, 526, 818][e];
    }
    getMaxPosX(e) {
        return [467, 760, 1057, 467, 760, 1057][e];
    }
    getMinPosY(e) {
        return [392, 392, 392, 208, 208, 208][e];
    }
    getMaxPosY(e) {
        return [475, 475, 475, 289, 289, 289][e];
    }
    showGoldEffect(e, t, i) {
        if (!sys.isObjectValid(e) || !sys.isObjectValid(t)) {
            return;
        }
        let l = e.length, o = t.length;
        if (0 == l && 0 == o) {
            return;
        }
        l > 0 && TweenTool.delayAct(this.node, (() => {
            SoundManager.shared().playFx("js_flay_gold");
        }), 0.5, true);
        this.getMinPosX(i);
        this.getMaxPosX(i);
        this.getMinPosY(i);
        this.getMaxPosY(i);
        let a = 0, s = 1 / this.leftAreaGoldVec.length, n = Math.floor(this.leftAreaGoldVec.length / e.length);
        for (let t = 0; t < this.leftAreaGoldVec.length; t++) {
            let i = Math.floor(t / n), l = SixPointManager.shared().seatPosVec[7];
            e.length > i && (l = e[i]);
            a += s;
            let o = this.leftAreaGoldVec[t];
            if (ToolUtils.isObjValid(o)) {
                let e = tween(o).delay(a), t = TweenTool.moveTo(o, 0.3, l);
                TweenTool.sequence(o, true, (() => {
                    ToolUtils.isObjValid(o) && (o.active = false);
                }), e, t);
            }
        }
    }
    playStartGameAnim() {
        let e = this.stateAnim.getComponent(sp.Skeleton);
        this.stateAnim.active = true;
        e.clearTracks();
        e.setToSetupPose();
        e.setAnimation(0, "gamestart", false);
        e.setCompleteListener((() => {
            this.stateAnim.active = false;
            e.setCompleteListener(null);
        }));
    }
    showSendCoinEffect(e, t, i) {
        if (e > 8) {
            return;
        }
        let l = this.getMinPosX(t.option), o = this.getMaxPosX(t.option), a = this.getMinPosY(t.option), s = this.getMaxPosY(t.option), h = SixPointManager.shared().seatPosVec[e], f = 0, u = 0, C = [], _ = [];
        if (sys.isObjectValid(t.chip_info) && Array.isArray(t.chip_info)) {
            for (let e = 0; e < t.chip_info.length; e++) {
                let i = t.chip_info[e].num, l = t.chip_info[e].value;
                u += i;
                for (let e = 0; e < i; e++) {
                    C.push(this.getChipImgIndex(l));
                    _.push(l);
                }
            }
        }
        for (let e = 0; e < u; e++) {
            let u = v3(0, 0);
            f += 0.008;
            let b = l + Math.random() * (o - l), V = a + Math.random() * (s - a);
            u.x = b;
            u.y = V;
            let P = instantiate(this.chipMoban);
            if (P.active = true, P.angle = ToolUtils.getRandomInt(-180, 180), P.getChildByName("ico").getComponent(Sprite).spriteFrame = this.coinChipFrame[C[e]], P.getChildByName("ico").getComponent(Sprite).sizeMode = 2, P.getChildByName("num").getComponent(Label).string = ToolUtils.parse_ChipNum2(_[e]), 7 == C[e] ? P.getChildByName("num").getComponent(Label).fontSize = 14 : P.getChildByName("num").getComponent(Label).fontSize = 10, this.m_batchNode.addChild(P), sys.isObjectValid(this.areaGoldsVec[t.option]) && Array.isArray(this.areaGoldsVec[t.option]) && this.areaGoldsVec[t.option].push(P), P.setPosition(h), P.getComponent(UIOpacity).opacity = 255, i) {
                let e = 0.3, t = tween(P).delay(f), i = TweenTool.moveTo(P, e, u);
                TweenTool.sequence(P, true, null, t, i);
            }
            else {
                P.setPosition(u);
            }
        }
        TweenTool.delayAct(this.node, (() => {
            SoundManager.shared().playFx("xiazhu_flygold");
        }), 0.3, true);
    }
    flyGoldToZhuangJia() {
        TweenTool.delayAct(this.node, (() => {
            SoundManager.shared().playFx("js_flay_gold");
        }), 0.3, true);
        let e = [1, 1, 1, 1, 1, 1];
        for (let t = 0; t < SixPointManager.shared().win_op.length; t++) {
            e[SixPointManager.shared().win_op[t]] = 0;
        }
        for (let t = 0; t < e.length; t++) {
            if (1 == e[t]) {
                if (sys.isObjectValid(this.areaGoldsVec[t]) && Array.isArray(this.areaGoldsVec[t]) && this.areaGoldsVec[t].length > 0) {
                    let e = 0, i = 1 / this.areaGoldsVec[t].length;
                    for (let l = 0; l < this.areaGoldsVec[t].length; l++) {
                        let o = this.areaGoldsVec[t][l];
                        if (ToolUtils.isObjValid(o)) {
                            e += i;
                            let t = tween(o).delay(e), l = tween(o).to(0.3, { position: SixPointManager.shared().zhuangPoint });
                            TweenTool.sequence(o, true, (() => {
                                o.active = false;
                            }), t, l);
                        }
                    }
                }
            }
            else if (sys.isObjectValid(this.areaGoldsVec[t]) && Array.isArray(this.areaGoldsVec[t]) && this.areaGoldsVec[t].length > 0) {
                for (let e = 0; e < this.areaGoldsVec[t].length; e++) {
                    let i = this.areaGoldsVec[t][e];
                    ToolUtils.isObjValid(i) && this.leftAreaGoldVec.push(i);
                }
            }
        }
    }
    flyGoldToWinArea(e) {
        let t = this.getMinPosX(e.option), i = this.getMaxPosX(e.option), l = this.getMinPosY(e.option), o = this.getMaxPosY(e.option), a = SixPointManager.shared().zhuangPoint, s = 0, h = 0, f = [], u = [];
        if (sys.isObjectValid(e.chip_info) && Array.isArray(e.chip_info)) {
            for (let t = 0; t < e.chip_info.length; t++) {
                let i = e.chip_info[t].num, l = e.chip_info[t].value;
                h += i;
                for (let e = 0; e < i; e++) {
                    f.push(this.getChipImgIndex(l));
                    u.push(l);
                }
            }
        }
        for (let c = 0; c < h; c++) {
            let h = v3(0, 0);
            s += 0.008;
            let b = t + Math.random() * (i - t), V = l + Math.random() * (o - l);
            h.x = b;
            h.y = V;
            let C = instantiate(this.chipMoban);
            C.active = true;
            C.angle = ToolUtils.getRandomInt(-180, 180);
            C.getChildByName("ico").getComponent(Sprite).spriteFrame = this.coinChipFrame[f[c]];
            C.getChildByName("ico").getComponent(Sprite).sizeMode = 2;
            C.getChildByName("num").getComponent(Label).string = ToolUtils.parse_ChipNum2(u[c]);
            7 == f[c] ? C.getChildByName("num").getComponent(Label).fontSize = 14 : C.getChildByName("num").getComponent(Label).fontSize = 10;
            this.m_batchNode.addChild(C);
            this.areaGoldsVec[e.option].push(C);
            C.setPosition(a);
            C.getComponent(UIOpacity).opacity = 255;
            let _ = 0.3, P = tween(C).delay(s), G = TweenTool.moveTo(C, _, h);
            TweenTool.sequence(C, true, null, P, G);
            this.leftAreaGoldVec.push(C);
        }
        TweenTool.delayAct(this.node, (() => {
            SoundManager.shared().playFx("xiazhu_flygold");
        }), 0.3, true);
    }
    getChipImgIndex(e) {
        return 6 != SixPointManager.shared().bet_configVec.length ? 0 : e >= SixPointManager.shared().gold_limit ? 7 : e == SixPointManager.shared().bet_configVec[0] ? 0 : e == SixPointManager.shared().bet_configVec[1] ? 1 : e == SixPointManager.shared().bet_configVec[2] ? 2 : e == SixPointManager.shared().bet_configVec[3] ? 3 : e == SixPointManager.shared().bet_configVec[4] ? 4 : e == SixPointManager.shared().bet_configVec[5] ? 5 : undefined;
    }
    hideAllWinKuang() {
        for (let e = 0; e <= 5; e++) {
            let t = `win_effect${e}`, i = this.node.getChildByName(t);
            ToolUtils.isObjValid(i) && (i.active = false);
        }
    }
    hideAllWinAnim() {
        for (let e = 0; e <= 5; e++) {
            let t = `bei_bg${e}`, i = this.node.getChildByName(t);
            ToolUtils.isObjValid(i) && (i.active = false);
        }
    }
    playWinAnim(e) {
        let t = false;
        for (let i = 0; i < e.length; i++) {
            let l = e[i];
            if (l > 1) {
                t = true;
                let e = SixPointManager.shared().win_op[i], o = this.node.getChildByName("bei_bg" + e);
                ToolUtils.isObjValid(o) && (o.setScale(v3(0, 1)), o.active = true, o.getChildByName("beishu").getComponent(Label).string = "Win x" + l, TweenTool.scaleTo(o, 0.2, v3(1, 1), null, true));
            }
        }
        t && SoundManager.shared().playFx("rummyWin");
    }
    changeWinKuangStatus(e, t, i, l) {
        let o = `win_effect${t}`, a = this.node.getChildByName(o);
        ToolUtils.isObjValid(a) && (a.active = i);
    }
}
