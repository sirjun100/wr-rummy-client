// @ts-nocheck
// Recovered from index.js:179
import { _decorator, Button, color, EditBox, Label, LabelShadow, Material, Node, Sprite, SpriteFrame, sys } from "cc";
import BaseLayer from "./BaseLayer";
import User from "./User";
import SoundManager from "./SoundManager";
import HttpManager from "./HttpManager";
import ReportConfig from "./ReportConfig";
import i18nMgr from "./i18nMgr";
import Utils from "./Utils";
import { TransferPlatform } from "./TransferPlatform";
import PushEvent from "./PushEvent";
import PushCenter from "./PushCenter";
import TweenTool from "./TweenTool";
import CommDefine from "./CommDefine";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("HallSettingsPassword")
export class HallSettingsPassword extends BaseLayer {
    @property(Node)
    public verifyNode: Node = null;
    @property(Node)
    public otpNode: Node = null;
    @property(Node)
    public passwordNode: Node = null;
    @property(Node)
    public nextBtn: Node = null;
    @property(Node)
    public verifyBtn: Node = null;
    @property(Node)
    public passwordBtn: Node = null;
    @property(Node)
    public optBtn: Node = null;
    @property(EditBox)
    public editOtp: EditBox = null;
    @property(EditBox)
    public editPassword: EditBox = null;
    @property(EditBox)
    public editConfirm: EditBox = null;
    @property(Label)
    public tel_no: Label = null;
    @property([SpriteFrame])
    public lookSprite: SpriteFrame[] = [];
    @property([Material])
    public buttonWzMats: Material[] = [];
    public otpAction: any = null;
    public serialno: string = "";
    public codeNo: string = "";
    public isModifyPass: boolean = false;
    public _btnColor: any[] = [color(213, 213, 213), color(0, 140, 22)];
    start() {
        super.start();
        User.shared().bSetpassword ? (User.shared().bSetpassword = false, this.verifyNode.active = false, this.passwordNode.active = true, this.nextBtn.active = false, this.passwordBtn.active = true, this.passwordBtn.getComponent(Button).interactable = false, this.refreshPassordBtnColor()) : (this.verifyNode.active = true, this.passwordNode.active = false, this.nextBtn.active = true, this.passwordBtn.active = false);
        this.otpNode.active = false;
        this.verifyBtn.active = false;
        this.passwordNode.getChildByName("pass_tips").getChildByName("error_ic1").getComponent(Sprite).color = this._btnColor[0];
        this.passwordNode.getChildByName("pass_tips").getChildByName("error_ic2").getComponent(Sprite).color = this._btnColor[0];
        let t = User.shared().data.tel_no;
        if (User.shared().data.tel_no && User.shared().data.tel_no.length > 0) {
            let e = "+91 " + t;
            this.tel_no.string = e;
        }
        this.fitScreen();
    }
    setDataInfo(t, e) {
        this.codeNo = t;
        this.serialno = e;
    }
    onDestroy() {
        super.onDestroy();
        this.unscheduleAllCallbacks();
    }
    update(t) {
    }
    onButtonClick(t, e) {
        if (SoundManager.shared().playFx("click"), "close" == e) {
            ToolUtils.isObjValid(this.node) && this.node.destroy();
        }
        else if ("next" == e) {
            this.verifyNode.active = false;
            this.otpNode.active = true;
            this.nextBtn.active = false;
            this.verifyBtn.active = true;
            this.optBtn.getChildByName("wz").getComponent(Label).string = i18nMgr.shared().getValueByKey("bind_mobile.otp");
        }
        else if ("otp" == e) {
            let t = User.shared().data.tel_no;
            HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Login, event: ReportConfig.login_evt.getOptNum });
            HttpManager.shared().doGetMobileCode(t, 11, 1, this.listenGetCodeCall.bind(this));
        }
        else if ("clearotp" == e) {
            this.editOtp.string = "";
            this.otpNode.getChildByName("clear_btn").active = false;
        }
        else if ("verify" == e) {
            let t = User.shared().data.tel_no, e = this.editOtp.string;
            if (e.length < 1) {
                return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("bind_mobile.enter_code_tips"), 2);
            }
            HttpManager.shared().doPlayerRePassword(t, e, 11, this.serialno, this.listenVerfityCall.bind(this));
        }
        else if ("lookpassword" == e) {
            let t = 0 == this.editPassword.inputFlag ? 5 : 0;
            this.editPassword.inputFlag = t;
            let e = 0 == this.editPassword.inputFlag ? 0 : 1;
            this.passwordNode.getChildByName("password").getChildByName("look_btn").getChildByName("img").getComponent(Sprite).spriteFrame = this.lookSprite[e];
        }
        else if ("lookconfirm" == e) {
            let t = 0 == this.editConfirm.inputFlag ? 5 : 0;
            this.editConfirm.inputFlag = t;
            let e = 0 == this.editConfirm.inputFlag ? 0 : 1;
            this.passwordNode.getChildByName("confirm").getChildByName("look_btn").getChildByName("img").getComponent(Sprite).spriteFrame = this.lookSprite[e];
        }
        else if ("clearpassword" == e) {
            this.editPassword.string = "";
            this.passwordNode.getChildByName("password").getChildByName("clear_btn").active = false;
            this.passwordNode.getChildByName("pass_tips").getChildByName("error_ic1").getComponent(Sprite).color = this._btnColor[0];
            this.passwordNode.getChildByName("pass_tips").getChildByName("error_ic2").getComponent(Sprite).color = this._btnColor[0];
        }
        else if ("clearconfirm" == e) {
            this.editConfirm.string = "";
            this.passwordNode.getChildByName("confirm").getChildByName("clear_btn").active = false;
        }
        else if ("password" == e) {
            if (this.editPassword.string == this.editConfirm.string) {
                let t = User.shared().data.tel_no, e = this.codeNo, s = this.editPassword.string;
                HttpManager.shared().doPlayersetPassword(e, t, s, this.serialno, this.listenSetPass.bind(this));
            }
            else {
                Utils.shared().showToast("Passwords do not match", 3);
            }
        }
    }
    listenVerfityCall(t, e, s) {
        if (Utils.shared().hideLoading(), 200 !== s) {
            Utils.shared().showCommomDialog(i18nMgr.shared().getValueByKey("utlis.text7"), "", (() => {
            }));
        }
        else {
            let t = ToolUtils.parseJson(e);
            0 === t.ret ? (this.otpNode.active = false, this.verifyBtn.active = false, this.passwordNode.active = true, this.passwordBtn.active = true, this.passwordBtn.getComponent(Button).interactable = false, this.refreshPassordBtnColor(), this.codeNo = this.editOtp.string, this.isModifyPass = true, Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text61"), 3)) : t.desc && t.desc.length > 0 && Utils.shared().showToast(t.desc, 3);
        }
    }
    onTextChanged(t, e, s) {
        if (null == e.string || "" == e.string) {
            return this.otpNode.getChildByName("clear_btn").active = false, this.passwordNode.getChildByName("password").getChildByName("clear_btn").active = false, this.passwordNode.getChildByName("confirm").getChildByName("clear_btn").active = false, void this.checkPassWorld("");
        }
        if ("otp" == s) {
            this.otpNode.getChildByName("clear_btn").active = true;
            /^([0-9]{8,16})$/.test(e.string);
        }
        else {
            "password" == s ? (this.passwordNode.getChildByName("password").getChildByName("clear_btn").active = true, this.checkPassWorld(e.string)) : "confirm" == s && (this.passwordNode.getChildByName("confirm").getChildByName("clear_btn").active = true);
        }
    }
    onTextEnd(t, e) {
        this.otpNode.getChildByName("clear_btn").active = false;
        this.passwordNode.getChildByName("password").getChildByName("clear_btn").active = false;
        this.passwordNode.getChildByName("confirm").getChildByName("clear_btn").active = false;
        null != t.string && "" != t.string ? this.checkPassWorld(t.string) : this.checkPassWorld("");
    }
    checkPassWorld(t) {
        t.length > 7 && t.length < 17 ? this.passwordNode.getChildByName("pass_tips").getChildByName("error_ic1").getComponent(Sprite).color = this._btnColor[1] : (this.passwordBtn.getComponent(Button).interactable = false, this.refreshPassordBtnColor(), this.passwordNode.getChildByName("pass_tips").getChildByName("error_ic1").getComponent(Sprite).color = this._btnColor[0]);
        if (!/^(?=.*[0-9])(?=.*[a-zA-Z])(.[a-zA-Z0-9].{6,16})$/.test(t)) {
            return this.passwordBtn.getComponent(Button).interactable = false, this.refreshPassordBtnColor(), void (this.passwordNode.getChildByName("pass_tips").getChildByName("error_ic2").getComponent(Sprite).color = this._btnColor[0]);
        }
        this.passwordNode.getChildByName("pass_tips").getChildByName("error_ic2").getComponent(Sprite).color = this._btnColor[1];
        this.passwordBtn.getComponent(Button).interactable = true;
        this.refreshPassordBtnColor();
    }
    refreshPassordBtnColor() {
        let t = this.passwordBtn.getChildByName("wz");
        this.passwordBtn.getComponent(Button).interactable ? (t.getComponent(Label).customMaterial = this.buttonWzMats[0], t.getComponent(LabelShadow).color = CommDefine.shadowcolor.green) : (t.getComponent(Label).customMaterial = this.buttonWzMats[3], t.getComponent(LabelShadow).color = CommDefine.shadowcolor.gray);
    }
    refreshOptBtnColor() {
        let t = this.optBtn.getChildByName("wz");
        this.optBtn.getComponent(Button).interactable ? (t.getComponent(Label).customMaterial = this.buttonWzMats[0], t.getComponent(LabelShadow).color = CommDefine.shadowcolor.green) : (t.getComponent(Label).customMaterial = this.buttonWzMats[3], t.getComponent(LabelShadow).color = CommDefine.shadowcolor.gray);
    }
    listenSetPass(t, e, s) {
        if (Utils.shared().hideLoading(), 200 !== s) {
            Utils.shared().showCommomDialog(i18nMgr.shared().getValueByKey("utlis.text7"), "", (() => {
            }));
        }
        else {
            let t = ToolUtils.parseJson(e);
            0 === t.ret ? (t.data.password && (ToolUtils.saveData("save_pwdno", t.data.password + ""), User.shared().data.password = t.data.password), t.data.user && sys.localStorage.getItem("LoginProxy_user" + TransferPlatform.shared().getChannelId()) === "" + t.data.user && ToolUtils.saveData("LoginProxy_password" + TransferPlatform.shared().getChannelId(), ToolUtils.isSafeString(t.data.password)), t.desc && t.desc.length > 0 ? Utils.shared().showToast(t.desc, 3) : Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text39"), 3), User.shared().bSetpassword = false, PushCenter.shared().pushEvent(PushEvent.passsetting), ToolUtils.isObjValid(this.node) && this.node.destroy()) : Utils.shared().showToast(t.desc, 3);
        }
    }
    listenGetCodeCall(t, e, s) {
        if (Utils.shared().hideLoading(), 200 !== s) {
            Utils.shared().showCommomDialog(i18nMgr.shared().getValueByKey("utlis.text7"), "", (() => {
            }));
        }
        else {
            let t = ToolUtils.parseJson(e);
            if (0 === t.ret) {
                let e = t.data.timeout;
                if (User.shared().code_timeout = e, ToolUtils.isObjValid(this.node)) {
                    this.serialno = t.data.serialno;
                    this.refreshCode();
                    this.optBtn.getComponent(Button).interactable = false;
                    this.refreshOptBtnColor();
                    let e = TweenTool.delayAct(this.optBtn, this.refreshCode.bind(this), 1, false);
                    this.otpAction = TweenTool.sequence(this.optBtn, true, null, e, null);
                    this.otpAction.repeatForever();
                    this.otpAction.start();
                    Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text59"), 3);
                }
            }
            else {
                t.desc && t.desc.length > 0 && Utils.shared().showToast(t.desc, 3);
            }
        }
    }
    refreshCode() {
        if (User.shared().code_timeout <= 0) {
            return this.optBtn.getComponent(Button).interactable = true, this.refreshOptBtnColor(), this.optBtn.getChildByName("wz").getComponent(Label).string = i18nMgr.shared().getValueByKey("bind_mobile.resend"), void TweenTool.stopAction(this.otpAction);
        }
        if (User.shared().code_timeout >= 0) {
            User.shared().code_timeout = User.shared().code_timeout - 1;
            let t = ToolUtils.format("(${0}s)", User.shared().code_timeout);
            this.optBtn.getChildByName("wz").getComponent(Label).string = t;
        }
    }
    fitScreen() {
        ToolUtils.adaptSafeArea(this.node.getChildByName("root"));
    }
}
