// @ts-nocheck
// Recovered from index.js:349
import { _decorator, Button, HorizontalTextAlignment, Label, Node, ProgressBar, sp, Sprite, sys, UITransform, v3, Widget } from "cc";
import BaseLayer from "./BaseLayer";
import i18nMgr from "./i18nMgr";
import PushCenter from "./PushCenter";
import { ToolUtils } from "./ToolUtils";
import TweenTool from "./TweenTool";
import Utils from "./Utils";
import BundleNameDefined from "./BundleNameDefined";
import PushEvent from "./PushEvent";
import ReportConfig from "./ReportConfig";
import User from "./User";
import HttpManager from "./HttpManager";
import SoundManager from "./SoundManager";
const { ccclass, property } = _decorator;
@ccclass("PiggyBank")
export class PiggyBank extends BaseLayer {
    public TAG: string = "PiggyBank";
    @property(Node)
    public recordNode: Node = null;
    @property(Label)
    public ruleLabel: Label = null;
    @property(ProgressBar)
    public progressBar: ProgressBar = null;
    @property(Node)
    public buyNode: Node = null;
    @property(Node)
    public gullakRootNode: Node = null;
    @property(sp.Skeleton)
    public guanziSkeleton: any = null;
    @property(Node)
    public biaogeNode: Node = null;
    @property(Node)
    public topTipsNode: Node = null;
    @property(Node)
    public downTipNode: Node = null;
    public isNext: boolean = false;
    public gullak_type: number = 0;
    public lastClick: number = 0;
    public guanzi_anim_type: number = 0;
    public isZaKai: boolean = false;
    public repeatAction: any = null;
    public _nVid: number = 0;
    public _reportScene: any = -1;
    public _linkId: number = 0;
    public _bCanSend: boolean = false;
    public _has_close: boolean = false;
    public _pop_souce: number = 0;
    public gullak_data_md5: any = null;
    initParaData(e) {
        sys.isObjectValid(e) && sys.isObjectValid(e.isNext) && (this.isNext = e.isNext);
        sys.isObjectValid(e) && sys.isObjectValid(e.vid) ? this._nVid = e.vid : this._nVid = ToolUtils.curRoomId;
        sys.isObjectValid(e) && sys.isObjectValid(e.pop_souce) && (this._pop_souce = e.pop_souce);
        sys.isObjectValid(e) && sys.isObjectValid(e.reportScene) && (this._reportScene = e.reportScene);
        sys.isObjectValid(e) && sys.isObjectValid(e.link_id) && e.link_id > 0 && (this._linkId = e.link_id);
        this.isZaKai = false;
        SoundManager.shared().preLoadBundleSounds(BundleNameDefined.bundle_sound, "gullak");
        this.guanziSkeleton.node.active = true;
        this.progressBar.progress = 0;
        this.buyNode.active = false;
        this.guanziSkeleton.clearTracks();
        this.guanziSkeleton.setToSetupPose();
        this.guanziSkeleton.setAnimation(0, "cqg_cq", false);
        sys.isObjectValid(User.shared().gullak_data) || Utils.shared().showLoading(10, true, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
        }));
        this.refreshGullak();
    }
    refreshGullak() {
        if (!sys.isObjectValid(User.shared().gullak_data)) {
            return;
        }
        if (this.gullak_data_md5 = ToolUtils.jsonToMd5(User.shared().gullak_data), this.buyNode.active = true, this.guanziSkeleton.node.active = true, this.gullak_type = User.shared().gullak_data.status, Number(ToolUtils.isSafeString(sys.localStorage.getItem("Gullak_" + User.shared().data.uid))) != User.shared().gullak_data.progress) {
            ToolUtils.saveData("Gullak_" + User.shared().data.uid, String(User.shared().gullak_data.progress));
            SoundManager.shared().playFx("gullak_cq");
            this.guanziSkeleton.clearTracks();
            this.guanziSkeleton.setToSetupPose();
            this.guanziSkeleton.setAnimation(0, "cqg_cq", false);
            let e = false;
            this.guanziSkeleton.setCompleteListener((() => {
                e || (2 == this.gullak_type ? (this.guanziSkeleton.clearTracks(), this.guanziSkeleton.setToSetupPose(), this.guanziSkeleton.setAnimation(0, "ps_xh", true), this.isZaKai = true) : 1 == this.gullak_type ? (this.guanziSkeleton.clearTracks(), this.guanziSkeleton.setToSetupPose(), this.guanziSkeleton.setAnimation(0, "cqg_xh", true)) : 0 == this.gullak_type && (this.guanziSkeleton.clearTracks(), this.guanziSkeleton.setToSetupPose(), this.guanziSkeleton.setAnimation(0, "cqg_ct", true)));
                e = true;
                this.guanziSkeleton.setCompleteListener(null);
            }));
        }
        else {
            2 == this.gullak_type ? (this.guanziSkeleton.clearTracks(), this.guanziSkeleton.setToSetupPose(), this.guanziSkeleton.setAnimation(0, "ps_xh", true), this.isZaKai = true) : 1 == this.gullak_type ? (this.guanziSkeleton.clearTracks(), this.guanziSkeleton.setToSetupPose(), this.guanziSkeleton.setAnimation(0, "cqg_xh", true)) : 0 == this.gullak_type && (this.guanziSkeleton.clearTracks(), this.guanziSkeleton.setToSetupPose(), this.guanziSkeleton.setAnimation(0, "cqg_ct", true));
        }
        let e = User.shared().gullak_data.progress / User.shared().gullak_data.max;
        1 == e ? (this.progressBar.node.parent.getChildByName("progressBg").getChildByName("currpro").getComponent(Label).string = "80%", this.progressBar.node.parent.getChildByName("progressBg").getChildByName("currlabel").getComponent(Label).string = "MAX") : (User.shared().gullak_data.progress / User.shared().gullak_data.money - 1 < 0 ? this.progressBar.node.parent.getChildByName("progressBg").getChildByName("currpro").getComponent(Label).string = "0%" : this.progressBar.node.parent.getChildByName("progressBg").getChildByName("currpro").getComponent(Label).string = User.shared().gullak_data.discount_ratio, this.progressBar.node.parent.getChildByName("progressBg").getChildByName("currlabel").getComponent(Label).string = "Current");
        this.downTipNode.getComponent(Label).string = 2 != User.shared().gullak_data.status ? User.shared().gullak_data.currentDesc : User.shared().gullak_data.reset;
        let t = 0;
        User.shared().data.player_club.club_level && (t = User.shared().getGradeByMemberShipLevel(User.shared().data.player_club.club_level));
        sys.isObjectValid(t) && t >= 0 && (this.gullakRootNode.getChildByName("level").getComponent(Sprite).spriteFrame = this.gullakRootNode.getChildByName("clubicons").getChildByName("club_small_pic" + t).getComponent(Sprite).spriteFrame);
        this.progressBar.progress = e;
        let a = this.buyNode.getChildByName("Label"), i = this.buyNode.getChildByName("Label2");
        a.getComponent(Label).string = "₹" + ToolUtils.parse_double(String(User.shared().gullak_data.money), -1);
        i.getComponent(Label).string = "₹" + ToolUtils.parse_double(String(User.shared().gullak_data.money), -1);
        0 == this.gullak_type || 1 == this.gullak_type ? (this.buyNode.getComponent(Button).interactable = true, a.active = true, i.active = false) : 2 == this.gullak_type && (this.buyNode.getComponent(Button).interactable = false, a.active = false, i.active = true);
        let s = User.shared().gullak_data.max_tip;
        if (sys.isObjectValid(s)) {
            let e = s.split("to");
            this.topTipsNode.getChildByName("label1").getComponent(Label).string = e[0] + "to";
            this.topTipsNode.getChildByName("label2").getComponent(Label).string = e[1];
        }
        let r = this.gullakRootNode.getChildByName("items"), o = r.getChildByName("plus"), n = r.getChildByName("cashItem"), u = false, c = false;
        sys.isObjectValid(User.shared().gullak_data.cash) && Number(User.shared().gullak_data.cash) > 0 && (u = true, n.active = true, n.getChildByName("num").getComponent(Label).string = "" + User.shared().gullak_data.cash);
        let p = r.getChildByName("bonusItem");
        sys.isObjectValid(User.shared().gullak_data.bonus) && Number(User.shared().gullak_data.bonus) > 0 && (c = true, p.active = true, p.getChildByName("num").getComponent(Label).string = "" + User.shared().gullak_data.bonus);
        u && c && (o.active = true);
        let k = this.buyNode.getChildByName("flag");
        sys.isObjectValid(User.shared().gullak_data.discount_ratio) && String(User.shared().gullak_data.discount_ratio).length > 0 && (k.active = true, k.getChildByName("Label").getComponent(Label).string = "" + User.shared().gullak_data.discount_ratio);
        this.refreshRuleTips();
    }
    showChargeReward(e) {
        this.isZaKai = true;
        SoundManager.shared().playFx("gullak_ps");
        this.guanziSkeleton.clearTracks();
        this.guanziSkeleton.setToSetupPose();
        this.guanziSkeleton.setAnimation(0, "ps", false);
        let t = false;
        this.guanziSkeleton.setCompleteListener((() => {
            if (!t) {
                this.guanziSkeleton.setCompleteListener(null);
                this.guanziSkeleton.clearTracks();
                this.guanziSkeleton.setToSetupPose();
                this.guanziSkeleton.setAnimation(0, "ps_xh", true);
                let t = 10;
                User.shared().showChargeReward(e.reward, (e => {
                    User.shared().requestActGullakPage((() => {
                        ToolUtils.isObjValid(this.node) && this.refreshGullak();
                    }));
                }), e.msg, t, e.price_tips, e.recharge_id);
            }
            t = true;
        }));
    }
    refreshRuleTips() {
        if (3 == i18nMgr.shared().language && (this.ruleLabel.horizontalAlign = HorizontalTextAlignment.RIGHT), sys.isObjectValid(User.shared().gullak_data.tips)) {
            if (Array.isArray(User.shared().gullak_data.tips.bonus) && User.shared().gullak_data.tips.bonus.length >= 6) {
                let e, t, a;
                for (let i = 0; i < 9; i++) {
                    if (a = i + 1, e = "bonus" + a, t = User.shared().gullak_data.tips.bonus[i], sys.isObjectValid(t)) {
                        let a = this.biaogeNode.getChildByName(e);
                        a && (a.getComponent(Label).string = String(t));
                    }
                }
            }
            if (Array.isArray(User.shared().gullak_data.tips.cash) && User.shared().gullak_data.tips.cash.length >= 6) {
                let e, t, a;
                for (let i = 0; i < 9; i++) {
                    if (a = i + 1, e = "cash" + a, t = User.shared().gullak_data.tips.cash[i], sys.isObjectValid(t)) {
                        let a = this.biaogeNode.getChildByName(e);
                        a && (a.getComponent(Label).string = String(t));
                    }
                }
            }
            if (Array.isArray(User.shared().gullak_data.tips.daily) && User.shared().gullak_data.tips.daily.length >= 6) {
                let e, t, a;
                for (let i = 0; i < 9; i++) {
                    if (a = i + 1, e = "daily" + a, t = User.shared().gullak_data.tips.daily[i], sys.isObjectValid(t)) {
                        let a = this.biaogeNode.getChildByName(e);
                        a && (a.getComponent(Label).string = String(t));
                    }
                }
            }
            if (Array.isArray(User.shared().gullak_data.tips.spending) && User.shared().gullak_data.tips.spending.length >= 6) {
                let e, t, a;
                for (let i = 0; i < 9; i++) {
                    if (a = i + 1, e = "spending" + a, t = User.shared().gullak_data.tips.spending[i], sys.isObjectValid(t)) {
                        let a = this.biaogeNode.getChildByName(e);
                        a && (a.getComponent(Label).string = String(t));
                    }
                }
            }
            if (Array.isArray(User.shared().gullak_data.tips.storage) && User.shared().gullak_data.tips.storage.length >= 6) {
                let e, t, a;
                for (let i = 0; i < 9; i++) {
                    if (a = i + 1, e = "storage" + a, t = User.shared().gullak_data.tips.storage[i], sys.isObjectValid(t)) {
                        let a = this.biaogeNode.getChildByName(e);
                        a && (a.getComponent(Label).string = String(t));
                    }
                }
            }
        }
    }
    start() {
        if (super.start(), this._linkId = this._linkId > 0 ? this._linkId : sys.now(), this._reportScene = this._reportScene >= 0 ? this._reportScene : ToolUtils.getIsInRoom() ? 2 : 1, this.recordNode.active = false, ToolUtils.showFullScreen(this.node.getChildByName("mask")), ToolUtils.showFullScreen(this.recordNode.getChildByName("mask")), this.ShowAnim(this.gullakRootNode, (() => {
        }), true), User.shared().requestActGullakPage((() => {
            if (Utils.shared().hideLoading(), ToolUtils.isObjValid(this.node)) {
                let e = true;
                if (sys.isObjectValid(this.gullak_data_md5)) {
                    let t = ToolUtils.jsonToMd5(User.shared().gullak_data);
                    this.gullak_data_md5 == t && (e = false);
                }
                if (e && this.refreshGullak(), sys.isObjectValid(User.shared().gullak_data)) {
                    if (!this._bCanSend) {
                        let e = { status: User.shared().gullak_data.status, max: User.shared().gullak_data.max, progress: User.shared().gullak_data.progress, money: User.shared().gullak_data.money, club: User.shared().gullak_data.club };
                        HttpManager.shared().doCommReportRechargeEvent(ReportConfig.Cmd_Gullak, this._reportScene, 2, this._linkId, e, this._nVid);
                    }
                    this._bCanSend = true;
                }
            }
        })), sys.isObjectValid(User.shared().gullak_data)) {
            this._bCanSend = true;
            let e = { status: User.shared().gullak_data.status, max: User.shared().gullak_data.max, progress: User.shared().gullak_data.progress, money: User.shared().gullak_data.money, club: User.shared().gullak_data.club };
            HttpManager.shared().doCommReportRechargeEvent(ReportConfig.Cmd_Gullak, this._reportScene, 2, this._linkId, e, this._nVid);
        }
        PushCenter.shared().addListener(PushEvent.Update_Gullak_RewardInGame, (e => {
            ToolUtils.isObjValid(this.node) && sys.isObjectValid(e) && this.showChargeReward(e);
        }), this);
        let e = this.recordNode.getChildByName("bg").getChildByName("ScrollView");
        ToolUtils.getIsInRoom() ? (this.recordNode.getChildByName("bg").getComponent(UITransform).setContentSize(672, 600), e.getComponent(UITransform).setContentSize(637, 500), e.getChildByName("view").getComponent(Widget).updateAlignment()) : this.recordNode.getChildByName("bg").getComponent(UITransform).setContentSize(672, 992);
        SoundManager.shared().playFx("act_popshow");
    }
    ShowAnim(e, t, a = false) {
        e.setScale(v3(0.2, 0.2, 0.2));
        let i = ToolUtils.getIsInRoom() && a ? v3(0.8, 0.8, 0.8) : v3(1, 1, 1);
        TweenTool.scaleTo(e, 0.2, i, "backOut", true, (() => {
            e.setScale(i);
            t && t();
        }));
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().removeListenersByTag(this);
        this.unscheduleAllCallbacks();
    }
    update(e) {
    }
    onButtonClick(e, t) {
        if (SoundManager.shared().playFx("click"), "close" === t) {
            this.onBackView();
        }
        else if ("help" === t) {
            this._bCanSend && sys.isObjectValid(User.shared().gullak_data) && (User.shared().gullak_data.status, User.shared().gullak_data.max, User.shared().gullak_data.progress, User.shared().gullak_data.money, User.shared().gullak_data.club);
            this.showHelpView();
        }
        else if ("buy" === t) {
            if (!User.shared().checkCanRecharge()) {
                return void (ToolUtils.isObjValid(this.node) && this.node.destroy());
            }
            if (sys.now() - this.lastClick < 1000) {
                return;
            }
            this.lastClick = sys.now();
            this.dealPayLogic(0);
        }
        else {
            "levelbtn" == t && (this.gullakRootNode.getChildByName("leveltipnode").active = !this.gullakRootNode.getChildByName("leveltipnode").active);
        }
    }
    dealPayLogic(e = 0) {
        let t = { price: User.shared().gullak_data.money, act_id: PushEvent.JUMP_TO_Gullak, link_id: this._linkId, pmode: e };
        if (User.shared().startPay(t), this._bCanSend) {
            let e = "";
            sys.isObjectValid(User.shared().gullak_data) && (e = { status: User.shared().gullak_data.status, max: User.shared().gullak_data.max, progress: User.shared().gullak_data.progress, money: User.shared().gullak_data.money, club: User.shared().gullak_data.club });
            HttpManager.shared().doCommReportRechargeEvent(ReportConfig.Cmd_Gullak, this._reportScene, 5, this._linkId, e, this._nVid);
        }
    }
    showHelpView() {
        this.recordNode.active ? this.updateRecordView() : (this.recordNode.active = true, this.ShowAnim(this.recordNode.getChildByName("bg"), (() => {
            this.updateRecordView();
        })));
    }
    updateRecordView() {
    }
    onBackView() {
        if (ToolUtils.isObjValid(this.node)) {
            if (Utils.shared().hideLoading(), ToolUtils.isObjValid(this.recordNode) && this.recordNode.active) {
                this.recordNode.active = false;
            }
            else {
                if (this._has_close) {
                    return;
                }
                let e = { alert_node: this.node, rootNode: this.gullakRootNode, isNext: this.isNext, pop_type: PushEvent.JUMP_TO_Gullak, pop_souce: this._pop_souce };
                Utils.shared().closeActivityView(e);
                this._has_close = true;
                Utils.shared().hideToast();
                this._bCanSend && sys.isObjectValid(User.shared().gullak_data) && (User.shared().gullak_data.status, User.shared().gullak_data.max, User.shared().gullak_data.progress, User.shared().gullak_data.money, User.shared().gullak_data.club);
            }
        }
    }
}
