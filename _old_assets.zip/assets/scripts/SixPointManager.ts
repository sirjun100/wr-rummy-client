// @ts-nocheck
// Recovered from index.js:531
import { _decorator, v3 } from "cc";
import { ToolUtils } from "./ToolUtils";
import User from "./User";
import GameConfig from "./GameConfig";
import { TLog } from "./TLog";
import Server from "./Server";
import URLConfig from "./URLConfig";
import NetHostManager from "./NetHostManager";
import NetConfig from "./NetConfig";
import PushCenter from "./PushCenter";
import gameNetworkDelay from "./gameNetworkDelay";
import TweenTool from "./TweenTool";
import Utils from "./Utils";
import PushEvent from "./PushEvent";
import i18nMgr from "./i18nMgr";
import SixPointCmd from "./SixPointCmd";
const { ccclass } = _decorator;
@ccclass("SixPointManager")
export class SixPointManager {
    static _instance = null;
    public _TAG: string = "SixPointManager";
    public checkLoadingRefresh: boolean = false;
    public sceneNode: any = null;
    public popNode: any = null;
    public _tidKey: string = "";
    public _vid: number = 0;
    public _coin: number = 0;
    public history_recordVec: any[] = [];
    public history_record_gold: any[] = [];
    public bet_configVec: any[] = [];
    public playerModels: Map = new Map;
    public clientSeatId: number = 0;
    public all_seatid: number = 8;
    public isgold: number = 0;
    public win_op: any[] = [];
    public seatPosVec: any[] = [];
    public zhuangPoint: any = v3(0, 0);
    public speakermincoin: number = 0;
    public gold_limit: number = 10000;
    public diceinfo: any[] = [];
    public data: any = {};
    constructor() {
        this.init();
    }
    static shared() : SixPointManager {
        return null == this._instance && (this._instance = new SixPointManager), this._instance;
    }
    init() {
        this.history_recordVec = [];
        this.bet_configVec = [];
        this.playerModels.clear();
        this.all_seatid = 8;
        this.clientSeatId = 0;
        this.diceinfo = [];
        this.isgold = 0;
    }
    checkDiceNum(e) {
        for (let e = 0; e < this.diceinfo.length; e++) {
            this.diceinfo[e];
        }
    }
    resetPlayers() {
        this.playerModels.clear();
        for (let e = 0; e <= 8; e++) {
            let t = {};
            t.seatid = e;
            t.isShow = false;
            this.playerModels[e] = t;
        }
    }
    sendLoginRequest() {
        let e = { cmd: SixPointCmd.GM_LOGIN_REQUEST, ch_id: 0, uid: User.shared().data.uid, version: GameConfig.Server_Api_Ver, skey: User.shared().getSkey(), vid: ToolUtils.curRoomId, tid_key: this._tidKey };
        Server.shared().send(e);
    }
    sendGameInfoRequest() {
        let t = { cmd: SixPointCmd.GM_REQUEST_TABLE_INFO, uid: User.shared().data.uid, version: GameConfig.Server_Api_Ver, skey: User.shared().getSkey(), vid: ToolUtils.curRoomId, tid_key: this._tidKey };
        Server.shared().send(t);
        SixPointManager.shared().checkLoadingRefresh = true;
        TweenTool.delayAct(this.sceneNode, (() => {
            SixPointManager.shared().checkLoadingRefresh && (SixPointManager.shared().checkLoadingRefresh = false, ToolUtils.backgroundWebSocketReconnection = false, Server.shared().disconnectWebSocket(), TweenTool.delayAct(this.sceneNode, (() => {
                SixPointManager.shared().loginGameServer();
            }), 0.2, true));
        }), 5, true);
    }
    sendLoginOutRequest() {
        let e = { cmd: SixPointCmd.GM_LOGINOUT_REQUEST, uid: User.shared().data.uid, version: GameConfig.Server_Api_Ver, skey: User.shared().getSkey(), vid: ToolUtils.curRoomId, tid_key: this._tidKey };
        Server.shared().send(e);
    }
    judgeCoin(e, t) {
        if (e < t) {
            let e = { vid: ToolUtils.curVId, min_entry: t };
            return User.shared().fastBuy(e), true;
        }
        return false;
    }
    loginGameServer() {
        SixPointManager.shared().checkLoadingRefresh = false;
        Server.shared().setOpenCb((() => {
            User.shared().send_login_gate_request();
        }));
        Server.shared().setReconCb((() => {
            User.shared().send_request_game_tableinfo();
        }));
        let t = URLConfig.orginHttp_tcp, s = NetHostManager.shared().chooseBestTcpIpConn(ToolUtils.curRoomId), i = NetHostManager.shared().chooseBestTcpPortConn(ToolUtils.curRoomId);
        "-1" != s && -1 != i && (t = 443 == i ? "wss://" + s + ":443" : "ws://" + s + ":" + i);
        Server.shared().createSocket(t);
        User.shared().isGameDisconnectServer = false;
    }
    handler_server_login_gate_return(e) {
        try {
            if (0 == e.res) {
                this.send_login_request();
                PushCenter.shared().pushEvent(GameConfig.NetWorkDelayShow);
            }
            else if (2 == e.res) {
                gameNetworkDelay.shared().setActiveDisconnect(true);
                User.shared().isGameDisconnectServer = true;
                Server.shared().disconnectWebSocket();
                let t = "You are not in any table!", s = "NOTICE";
                ToolUtils.isSafeString(e.title).length > 0 && (s = e.title);
                ToolUtils.isSafeString(e.msg).length > 0 && (t = e.msg);
                TweenTool.delayAct(this.sceneNode, (() => {
                    window.InGameScene && Utils.shared().showCommomDialog(t, s, (e => {
                        PushCenter.shared().pushEvent(PushEvent.ExitGameToHall);
                    }), false, ToolUtils.getIsNormalDirection());
                }), 2, true);
            }
            else {
                Utils.shared().showCommomDialog(i18nMgr.shared().getValueByKey("rummy_main.gameTipstext11"), i18nMgr.shared().getValueByKey("gameRummy_notice_Pop.notice"), (e => {
                    PushCenter.shared().pushEvent(PushEvent.ExitGameToHall);
                }), false, ToolUtils.getIsNormalDirection(), null, null, null, null, null, null);
            }
        }
        catch (e) {
            TLog.printError("trycatch handler_server_login_gate_return ,error:", e);
        }
    }
    login(e = false) {
        User.shared().curTid_key === this._tidKey && this.loginGameServer();
    }
    create_new_table() {
        if (User.shared().isGameDisconnectServer) {
            return Server.shared().disconnectWebSocket(), void this.login(true);
        }
        this.send_create_table_request();
    }
    send_create_table_request() {
        let e = { cmd: NetConfig.GM_CREATE_TABLE_REQUEST, uid: User.shared().data.uid, version: GameConfig.Server_Api_Ver, skey: User.shared().getSkey(), vid: this._vid, auto_sort: User.shared().auto_sort, ch_id: GameConfig.CHANNEL_ID };
        e.tid_key = this._tidKey;
        Server.shared().send(e);
    }
    send_login_request() {
        let e = { cmd: NetConfig.GM_LOGIN_REQUEST, uid: User.shared().data.uid, skey: User.shared().getSkey(), version: GameConfig.Server_Api_Ver, ch_id: GameConfig.CHANNEL_ID, tid_key: this._tidKey };
        e.vid = ToolUtils.curVId;
        Server.shared().send(e);
    }
    static arrayUnique(e) {
        const t = {}, s = [];
        for (let i = 0; i < e.length; i++) {
            const n = e[i];
            t[n] || (s.push(n), t[n] = true);
        }
        return s.sort(((e, t) => e < t ? -1 : e > t ? 1 : 0)), s;
    }
}
