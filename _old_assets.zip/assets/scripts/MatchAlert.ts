// @ts-nocheck
// Recovered from index.js:295
import { _decorator, Label, Node, v3, Vec3 } from "cc";
import SoundManager from "./SoundManager";
import BaseLayer from "./BaseLayer";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("MatchAlert")
export class MatchAlert extends BaseLayer {
    @property(Node)
    public rootNode: Node = null;
    @property(Node)
    public mask: Node = null;
    @property(Node)
    public enter_game: Node = null;
    @property(Node)
    public opt_in_succ_old: Node = null;
    @property(Node)
    public opt_in_succ_new: Node = null;
    @property(Node)
    public opt_in_succ_reminded: Node = null;
    @property(Node)
    public upcoming: Node = null;
    @property(Node)
    public upcoming_reminded: Node = null;
    @property(Node)
    public upcoming_room: Node = null;
    @property(Node)
    public upcoming_reminded_room: Node = null;
    @property(Node)
    public opt_out: Node = null;
    @property(Node)
    public opt_out_succ: Node = null;
    @property(Node)
    public race_tips: Node = null;
    public _cb: any = null;
    public strFunc: string = "";
    public _nType: number = 0;
    start() {
        super.start();
        let t = this.node.getChildByName("mask");
        if (ToolUtils.showFullScreen(t), ToolUtils.showFullScreen(this.rootNode), ToolUtils.getIsNormalDirection() || this.node.setRotationFromEuler(v3(0, 0, 90)), 3 == this._nType || 4 == this._nType || 6 == this._nType || 8 == this._nType || 9 == this._nType) {
            this.startShowAnim(this.rootNode);
        }
        else {
            let t = new Vec3;
            this.rootNode.getPosition(t);
            let e = { startPos: v3(t.x, t.y - 500, t.z), endPos: t };
            ToolUtils.showPushAnim(this.rootNode, 2, null, e);
        }
    }
    onClickByBtn(t, e) {
        SoundManager.shared().playFx("click");
        "ok" != e && "enter" != e && "cancel" != e && "out" != e && "remind_next" != e || (this.strFunc.length > 0 ? this._cb && this._cb(this.strFunc) : this._cb && this._cb(e));
        ToolUtils.isObjValid(this.node) && this.node.destroy();
    }
    updateDlgInfo(t, e, i = "", n = null, o, r, s) {
        if (this._nType = t, this.enter_game.active = 0 == t, this.opt_in_succ_old.active = 1 == t, this.opt_out.active = 2 == t, this.opt_out_succ.active = 3 == t, this.race_tips.active = 4 == t, this.opt_in_succ_reminded.active = 5 == t, this.upcoming.active = 6 == t, this.upcoming_reminded.active = 7 == t, this.upcoming_room.active = 8 == t, this.upcoming_reminded_room.active = 9 == t, this.opt_in_succ_new.active = 10 == t, this.mask.active = true, 0 == t) {
            this.enter_game.getChildByName("title").getComponent(Label).string = e;
            this.enter_game.getChildByName("tips_tx").active = 0 == s;
            this.enter_game.getChildByName("rejoin_tips_tx").active = 1 == s;
            this.enter_game.getChildByName("latejoin_tips_tx").active = 2 == s;
        }
        else if (1 == t) {
            this.opt_in_succ_old.getChildByName("title").getComponent(Label).string = e;
        }
        else if (2 == t) {
            this.opt_out.getChildByName("title").getComponent(Label).string = e;
        }
        else if (4 == t) {
            e.length > 0 && (this.race_tips.getChildByName("wz").getComponent(Label).string = e);
            i.length > 0 && (this.race_tips.getChildByName("Button").getChildByName("wz").getComponent(Label).string = i);
        }
        else if (5 == t) {
            this.opt_in_succ_reminded.getChildByName("title").getComponent(Label).string = e;
            let t = r || "";
            this.opt_in_succ_reminded.getChildByName("time_tx").getComponent(Label).string = ToolUtils.format("Tournament starts at ${0}.", t);
        }
        else if (6 == t) {
            this.upcoming.getChildByName("bg").getChildByName("title").getComponent(Label).string = e;
        }
        else if (7 == t) {
            this.upcoming_reminded.getChildByName("title").getComponent(Label).string = e;
            let t = r || "";
            this.upcoming_reminded.getChildByName("regirst_time").getComponent(Label).string = ToolUtils.format("Registration starts at ${0}.", t);
        }
        else if (8 == t) {
            this.upcoming_room.getChildByName("bg").getChildByName("title").getComponent(Label).string = e;
        }
        else if (9 == t) {
            let t = this.upcoming_reminded_room.getChildByName("bg");
            t.getChildByName("title").getComponent(Label).string = e;
            let i = r || "";
            t.getChildByName("regirst_time").getComponent(Label).string = ToolUtils.format("Registration starts at ${0}.", i);
        }
        else if (10 == t) {
            this.opt_in_succ_new.getChildByName("title").getComponent(Label).string = e;
            let t = r || "";
            this.opt_in_succ_new.getChildByName("time_tx").getComponent(Label).string = ToolUtils.format("Tournament starts at ${0}.", t);
        }
        null != n && (this._cb = n);
        null != o && (this.strFunc = o);
    }
}
