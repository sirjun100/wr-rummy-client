// @ts-nocheck
// Recovered from index.js:201
import { _decorator, Button, color, instantiate, Label, Node, RichText, ScrollView, size, Sprite, SpriteAtlas, SpriteFrame, sys, UITransform, v3, Vec3, view, Widget } from "cc";
import Utils from "./Utils";
import SoundManager from "./SoundManager";
import BaseLayer from "./BaseLayer";
import i18nMgr from "./i18nMgr";
import { ToolUtils } from "./ToolUtils";
import PushCenter from "./PushCenter";
import GameConfig from "./GameConfig";
import User from "./User";
import PhpReportDefined from "./PhpReportDefined";
const { ccclass, property } = _decorator;
@ccclass("InboxDetail")
export default class InboxDetail extends BaseLayer {
    @property(Node)
    public detail_root: Node = null;
    @property(Node)
    public stateimg_node: Node = null;
    @property(Node)
    public info_bg: Node = null;
    @property(ScrollView)
    public maildetials_list: ScrollView = null;
    @property([SpriteFrame])
    public goldFrame: SpriteFrame[] = [];
    @property(SpriteFrame)
    public stateimgSp: SpriteFrame = null;
    @property([SpriteFrame])
    public btnStatusSp: SpriteFrame[] = [];
    @property(Node)
    public bottomNode: Node = null;
    @property([SpriteFrame])
    public ticket_images: SpriteFrame[] = [];
    @property(Node)
    public bubble_tipNode: Node = null;
    @property(SpriteAtlas)
    public skinPropsAtlas: SpriteAtlas = null;
    public rewardMoban: any = undefined;
    public goodsMoban: any[] = [];
    public _curItemDate: any = null;
    public _callback: any = null;
    public bShowPushAnim: boolean = false;
    public showUICallback: any = null;
    public closeUICallBack: any = null;
    public _closed: boolean = false;
    public infos: any[] = [];
    public move_distance: number = 0;
    onLoad() {
        this.rewardMoban = this.detail_root.getChildByName("info").getChildByName("reward_item");
        PushCenter.shared().addListener(GameConfig.Jump_Hall_Choose_game, (e => {
            ToolUtils.isObjValid(this.node) && this.onBackView();
        }), this);
        this.fitLuckyTheme();
    }
    fitLuckyTheme() {
        0 != GameConfig.NATIVE_GAME_APP_TYPE && (this.detail_root.getChildByName("top").getChildByName("top_bg").getComponent(Sprite).color = color(12, 26, 60));
    }
    fitChipMode() {
        if (0 == GameConfig.CHIPS_MODLE) {
            return;
        }
        let e = 2000617 == GameConfig.CHANNEL_ID;
        e && e && 0 == GameConfig.GAME_HALL_THEME && (this.detail_root.getChildByName("top").getChildByName("top_bg").getComponent(Sprite).color = color(9, 69, 68, 255));
    }
    start() {
        super.start();
        this.node.getComponent(UITransform).setContentSize(view.getVisibleSize());
        this.move_distance = ToolUtils.adaptSafeArea(this.detail_root);
        this.bubble_tipNode.getChildByName("mask").getComponent(UITransform).setContentSize(view.getVisibleSize());
        this._curItemDate && this.refreshMailContent(this._curItemDate);
        this.bShowPushAnim && ToolUtils.showPushAnim(this.node, 0, (() => {
            this.showUICallback && this.showUICallback();
        }));
    }
    init(e, t = null, i = null) {
        this.bShowPushAnim = e;
        this.showUICallback = t;
        this.closeUICallBack = i;
    }
    initData(e = null, t) {
        this._callback = e;
        this._curItemDate = t;
    }
    onDestroy() {
        super.onDestroy();
        Utils.shared().hideLoading();
    }
    onBackView(e) {
        e || this.closeUICallBack && this.closeUICallBack();
        this.bShowPushAnim ? (this._closed = true, ToolUtils.showPushAnim(this.node, 1, (() => {
            ToolUtils.isObjValid(this.node) && this.node.destroy();
        }))) : ToolUtils.isObjValid(this.node) && this.node.destroy();
    }
    onPlaynowclick(e, t) {
        t && (Utils.shared().doJumpLogic(t.type, t.exe), User.shared().updatePayScene(PhpReportDefined.pay_scene.hall_email));
    }
    onReceiveClick(e, t) {
        SoundManager.shared().playFx("click");
        let i = { eid: t.eid, hasLoading: true };
        this._callback && this._callback("receive", i);
    }
    onDeleteClick(e, t) {
        SoundManager.shared().playFx("click");
        let i = { eid: t.eid, hasLoading: true };
        this._callback && this._callback("delete", i);
    }
    onCloseClick(e, t) {
        this._closed || (SoundManager.shared().playFx("click"), this._callback && this._callback("refreshList"), ToolUtils.isObjValid(this.node) && this.onBackView());
    }
    refreshMailContent(e) {
        let t = this.move_distance;
        ToolUtils.isPadPlatform() || (t = view.getVisibleSize().height - 1280 - 2 * ToolUtils.getSafeDistance() + this.move_distance);
        this.goodsMoban = [];
        let i = ToolUtils.isSafeString(e.title), o = ToolUtils.isSafeString(e.from), n = ToolUtils.isSafeString(e.date), a = e.attach, s = e.content, l = e.jump_info, r = e.receive, d = e.timeout, N = ToolUtils.isSafeNumber(e.rich), B = e.img, k = this.detail_root.getChildByName("info"), P = k.getChildByName("mail_title"), L = k.getChildByName("from_title").getChildByName("tx"), z = k.getChildByName("time_title").getChildByName("tx"), A = k.getChildByName("maildetials_list").getChildByName("view").getChildByName("content").getChildByName("content"), I = this.detail_root.getChildByName("top").getChildByName("del_btn"), D = this.info_bg.getChildByName("reward_node"), V = this.bottomNode.getChildByName("playnow_btn"), x = this.bottomNode.getChildByName("receive_btn");
        I.active = false;
        x.active = false;
        V.active = false;
        let F = k.getChildByName("maildetials_list").getChildByName("view").getChildByName("content").getChildByName("label");
        P.getComponent(Label).string = i;
        L.getComponent(Label).string = o;
        z.getComponent(Label).string = n;
        let M = false;
        0 === N || -1 === s.indexOf("<color=#") || (M = true);
        M ? (A.active = true, F.active = false, A.getComponent(RichText).string = s) : (A.active = false, F.active = true, F.getComponent(Label).string = s);
        null == l ? 0 === a ? (I.active = true, this.bottomNode.active = false) : 1 === a && 1 === r ? (I.active = true, x.getComponent(Button).interactable = false, x.active = true, x.getComponent(Sprite).spriteFrame = this.btnStatusSp[1], this.bottomNode.active = true, x.getChildByName("Label").active = false, x.getChildByName("Label2").active = true) : 1 === a && 0 === r && (x.active = true, x.getComponent(Button).interactable = true, x.getComponent(Sprite).spriteFrame = this.btnStatusSp[0], i18nMgr.shared().changeLocalizedLabelKey(x.getChildByName("Label"), "daily_tasks.collect"), this.bottomNode.active = true, x.getChildByName("Label").active = true, x.getChildByName("Label2").active = false) : (1 === a && 0 === r ? (x.active = true, x.getComponent(Button).interactable = true, x.getComponent(Sprite).spriteFrame = this.btnStatusSp[0], i18nMgr.shared().changeLocalizedLabelKey(x.getChildByName("Label"), "daily_tasks.collect"), x.getChildByName("Label").active = true, x.getChildByName("Label2").active = false) : (I.active = true, V.active = true, V.getChildByName("Label").getComponent(Label).string = ToolUtils.isSafeString(e.jump_name)), this.bottomNode.active = true);
        x.getComponent(Button).clickEvents[0].customEventData = e;
        I.getComponent(Button).clickEvents[0].customEventData = e;
        V.getComponent(Button).clickEvents[0].customEventData = l;
        Utils.shared().hideLoading();
        let E = e.goods, T = 0;
        E && E.length && (T = E.length);
        this.infos = E;
        let U = this.maildetials_list.getComponent(UITransform);
        if (D.removeAllChildren(), this.rewardMoban.active = false, T > 0) {
            let e, t = 160;
            for (let i = 0; i < T; i++) {
                e = instantiate(this.rewardMoban);
                this.goodsMoban.push(e);
                D.addChild(e);
                e.active = true;
                let o = e.getChildByName("ticket_node"), n = e.getChildByName("tips_btn"), a = e.getChildByName("tips_icon"), s = o.getChildByName("discount").getComponent(Label), l = e.getChildByName("time");
                l.active = false;
                let r = e.getChildByName("icon");
                if (11 == E[i].gtype) {
                    o.active = true;
                    a.active = true;
                    sys.isObjectValid(E[i].discount) && (n.active = true, n.getComponent(Button).clickEvents[0].customEventData = String(i), s.string = String(E[i].discount), 100 == Number(E[i].discount) ? (e.getChildByName("icon").getComponent(Sprite).spriteFrame = this.ticket_images[1], o.setPosition(v3(0, 0))) : (e.getChildByName("icon").getComponent(Sprite).spriteFrame = this.ticket_images[0], o.setPosition(v3(-3, 0))));
                }
                else if (12 == E[i].gtype) {
                    if (sys.isObjectValid(E[i].left_seconds) && Number(E[i].left_seconds) > 0) {
                        l.active = true;
                        l.getChildByName("layout").getChildByName("Label").getComponent(Label).string = Utils.shared().parseCountDown(E[i].left_seconds);
                    }
                    if (sys.isObjectValid(E[i].prop_type) && sys.isObjectValid(E[i].prop_icon)) {
                        let t = Number(E[i].prop_type), o = Number(E[i].prop_icon), n = "";
                        1 == t ? n = "skin_props_head_" + o : 2 == t ? n = "skin_props_headkuang_" + o : 3 == t ? n = "skin_props_hupai_" + o : 4 == t ? n = "skin_props_enterance_" + o : 5 == t ? n = "skin_props_desk_" + o : 6 == t ? n = "skin_props_pokerback_" + o : 7 == t && (n = "skin_props_pokerfront_" + o);
                        n.length > 0 && Utils.shared().setImage(r, n, this.skinPropsAtlas);
                        let a = "skin_props_reward_bg";
                        Utils.shared().setImage(e.getChildByName("mail_bg"), a, this.skinPropsAtlas);
                    }
                }
                else {
                    o.active = false;
                    n.active = false;
                    a.active = false;
                    this.goldFrame.length > E[i].gtype && (e.getChildByName("icon").getComponent(Sprite).spriteFrame = this.goldFrame[E[i].gtype]);
                }
                let c = e.getChildByName("num");
                0 === E[i].gtype || 1 === E[i].gtype ? c.getComponent(Label).string = "x" + ToolUtils.parse_double(E[i].num) : c.getComponent(Label).string = "x" + E[i].num;
                12 == E[i].gtype && (c.getComponent(Label).string = "");
                e.setPosition(v3(t / 2 * -(T - 1) + i * t, 0));
                e.getChildByName("flag").active = 1 === d;
            }
        }
        if (ToolUtils.isSafeString(B).length > 0) {
            this.stateimg_node.active = true;
            let e = 800, i = 0;
            if (this.bottomNode.active ? T > 0 ? e = 800 : 0 == T && (e = 1000) : (e = 1080, i = 110), e += t, i += t, this.maildetials_list.getComponent(UITransform).setContentSize(size(U.width, e)), this.maildetials_list.node.getChildByName("view").getComponent(UITransform).setContentSize(size(U.width, e)), this.stateimg_node.getComponent(Sprite).spriteFrame = this.stateimgSp, Utils.shared().updateNetImage(this.stateimg_node, B, size(660, 180)), i > 0) {
                let e = this.info_bg.getComponent(UITransform).contentSize, t = 1020;
                this.info_bg.getComponent(UITransform).setContentSize(size(e.width, t + i));
            }
            this.info_bg.getChildByName("reward_node").getComponent(Widget).updateAlignment();
        }
        else {
            this.stateimg_node.active = false;
            let e = 800, i = 0;
            if (this.bottomNode.active ? T > 0 ? e = 800 : 0 == T && (e = 1000) : (e = 1080, i = 110), e += t, i += t, this.maildetials_list.getComponent(UITransform).setContentSize(size(U.width, e)), this.maildetials_list.node.getChildByName("view").getComponent(UITransform).setContentSize(size(U.width, e)), i > 0) {
                let e = this.info_bg.getComponent(UITransform).contentSize, t = 1020;
                this.info_bg.getComponent(UITransform).setContentSize(size(e.width, t + i));
            }
            this.info_bg.getChildByName("reward_node").getComponent(Widget).updateAlignment();
        }
    }
    itemCloseTipsClick(e, t) {
        SoundManager.shared().playFx("click");
        this.bubble_tipNode.active = false;
    }
    onItemTipsBtnClick(e, t) {
        SoundManager.shared().playFx("click");
        this.bubble_tipNode.active = true;
        let i = this.goodsMoban[Number(t)], o = this.bubble_tipNode.getChildByName("bubble"), n = o.getChildByName("arrow");
        o.active = true;
        o.setPosition(0, -282);
        let a = o.getChildByName("name").getComponent(Label), s = o.getChildByName("purpose").getComponent(Label), l = new Vec3;
        i.getWorldPosition(l);
        let r = v3();
        this.bubble_tipNode.inverseTransformPoint(r, l);
        let h = v3();
        o.inverseTransformPoint(h, l);
        Array.isArray(this.infos) && this.infos.length > Number(t) && (this.infos.length <= 3 ? (o.setPosition(0, r.y + 168), n.setPosition(v3(h.x, -110))) : 0 == Number(t) ? (o.setPosition(-160, r.y + 168), n.setPosition(v3(h.x + 160, -110))) : Number(t) == this.infos.length - 1 ? (o.setPosition(160, r.y + 168), n.setPosition(v3(h.x - 160, -110))) : (o.setPosition(0, r.y + 168), n.setPosition(v3(h.x, -110))));
        let d = Number(this.infos[Number(t)].discount);
        i18nMgr.shared().changeLabelFont(a);
        a.string = ToolUtils.format(i18nMgr.shared().getValueByKey("ticket.reward_tip_name"), d);
        i18nMgr.shared().changeLabelFont(s);
        sys.isObjectValid(this.infos[Number(t)].match_name) && (s.string = ToolUtils.format(i18nMgr.shared().getValueByKey("ticket.reward_tip_purpose"), this.infos[Number(t)].match_name, d));
    }
}
