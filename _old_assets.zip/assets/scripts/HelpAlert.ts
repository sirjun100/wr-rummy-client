// @ts-nocheck
// Recovered from index.js:187
import { _decorator, Label, sys } from "cc";
import BaseLayer from "./BaseLayer";
import SoundManager from "./SoundManager";
import i18nMgr from "./i18nMgr";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("HelpAlert")
export class HelpAlert extends BaseLayer {
    @property(Label)
    public tipsLabel: Label = null;
    start() {
        super.start();
        this.startShowAnim(this.node.getChildByName("bg"), (() => {
        }));
    }
    initParaData(t) {
        sys.isObjectValid(t) && sys.isObjectValid(t.tips) && (this.tipsLabel.string = t.tips, i18nMgr.shared().changeLabelFont(this.tipsLabel));
    }
    onButtonClick(t, e) {
        SoundManager.shared().playFx("click");
        "close" == e && this.onBackView();
    }
    onBackView() {
        ToolUtils.isObjValid(this.node) && (this.node.active = false);
    }
}
