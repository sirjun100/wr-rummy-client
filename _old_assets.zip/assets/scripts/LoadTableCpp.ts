// @ts-nocheck
// Recovered from index.js:239
import { _decorator, director, sys } from "cc";
import Parent from "./Parent";
import { TransferPlatform } from "./TransferPlatform";
import i18nMgr from "./i18nMgr";
import PushCenter from "./PushCenter";
import Utils from "./Utils";
import BundleNameDefined from "./BundleNameDefined";
import GameConfig from "./GameConfig";
import HowToPlayDefined from "./HowToPlayDefined";
import NetConfig from "./NetConfig";
import URLConfig from "./URLConfig";
import { DeskInfo } from "./DeskInfo";
import User from "./User";
import NetHostManager from "./NetHostManager";
import Server from "./Server";
import PushEvent from "./PushEvent";
import HttpManager from "./HttpManager";
import { HttpRequest } from "./HttpRequestName";
import ReportConfig from "./ReportConfig";
import TweenTool from "./TweenTool";
import { ToolUtils } from "./ToolUtils";
import { CommonGameType } from "./CommDefine";
const { ccclass } = _decorator;
@ccclass("LoadTableCpp")
export default class LoadTableCpp extends Parent {
    public roomType: number = 0;
    public roomId: number = 0;
    public tid: number = 0;
    public privateRoomData: any = undefined;
    public loadTableNode: any = null;
    public is_back: number = 0;
    public desk_index: number = 0;
    public tid_key: string = "";
    public raceid: number = 0;
    public isNewTable: number = 0;
    public fromBeginnerTutorial: number = 0;
    public game_id: number = 0;
    public round: number = 0;
    public robot_view: number = 0;
    public bHasSendLogin: boolean = false;
    public subLoadingDelay: any = null;
    onLoad() {
        this.baseExe();
    }
    showLoadTable(e, t, a, i, o = 0, r, h, m, u) {
        return window.InRummyScene ? (this.clearEventByThis(), void this.removeLoadTable()) : (ToolUtils.report_time_param.showLoadTable = sys.now(), this.roomType = null != t && null != t ? t : 1, this.roomId = e, this.roomId != ToolUtils.play_back_vid && (User.shared().isInPerformanceRoom = 0), this.tid = null != a && null != a ? a : 0, this.privateRoomData = i, this.is_back = null != o && null != o ? o : 0, this.tid_key = null != r && null != r ? r : "", this.raceid = null != h && null != h ? h : 0, this.isNewTable = null != m && null != m ? m : 0, this.fromBeginnerTutorial = null != u && null != u ? u : 0, 0 == sys.getNetworkType() ? (Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text91"), 3, 0, ToolUtils.getIsNormalDirection()), PushCenter.shared().pushEvent(PushEvent.HideSubLoadingAnim), this.clearEventByThis(), void this.removeLoadTable()) : (Utils.shared().showLoading(10, true, (() => {
            0 == sys.getNetworkType() ? Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text91"), 3, 0, ToolUtils.getIsNormalDirection()) : (Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection()), User.shared().send_request_hall_tableinfo());
        }), ToolUtils.getIsNormalDirection()), void this.doConnectRequest()));
    }
    showCommLoadTable(e) {
        if (window.InRummyScene) {
            return this.clearEventByThis(), void this.removeLoadTable();
        }
        ToolUtils.report_time_param.showLoadTable = sys.now();
        let t = e.vid, a = e.isNewTable, i = e.fromBeginnerTutorial, o = e.raceid, r = e.tid, h = e.privateRoomData, m = e.game_type, u = e.is_back, _ = e.tid_key, c = !!e.is_sub_loading;
        this.robot_view = null != e.robot_view ? e.robot_view : 0;
        if (this.roomType = null != m && null != m ? m : 1, this.roomId = t, this.roomId != ToolUtils.play_back_vid ? User.shared().isInPerformanceRoom = 0 : User.shared().isInPerformanceRoom = 1, this.tid = null != r && null != r ? r : 0, this.privateRoomData = h, this.is_back = null != u && null != u ? u : 0, this.tid_key = null != _ && null != _ ? _ : "", this.raceid = null != o && null != o ? o : 0, this.isNewTable = null != a && null != a ? a : 0, this.fromBeginnerTutorial = null != i && null != i ? i : 0, this.game_id = e.game_id, this.round = null != e.round ? e.round : 0, 0 == sys.getNetworkType()) {
            return Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text91"), 3, 0, ToolUtils.getIsNormalDirection()), PushCenter.shared().pushEvent(PushEvent.HideSubLoadingAnim), this.clearEventByThis(), void this.removeLoadTable();
        }
        User.shared().game_id = e.game_id;
        c ? (this.subLoadingDelay && (TweenTool.stopAction(this.subLoadingDelay), this.subLoadingDelay = null), this.subLoadingDelay = TweenTool.delayAct(ToolUtils.getPersistGlobalNode(), (() => {
            0 == sys.getNetworkType() ? Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text91"), 3, 0, ToolUtils.getIsNormalDirection()) : (Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection()), User.shared().send_request_hall_tableinfo());
            PushCenter.shared().pushEvent(PushEvent.HideSubLoadingAnim);
        }), 5, true)) : Utils.shared().showLoading(10, true, (() => {
            0 == sys.getNetworkType() ? Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text91"), 3, 0, ToolUtils.getIsNormalDirection()) : (Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection()), User.shared().send_request_hall_tableinfo());
        }), ToolUtils.getIsNormalDirection());
        this.doConnectRequest();
    }
    doConnectRequest() {
        let e = Server.shared().isEnable();
        if (e || Server.shared().reset(), 1 == User.shared().isInPerformanceRoom && (e && Server.shared().reset(), e = false), this.regEventinit(), Server.shared().setOpenCb((() => {
            User.shared().send_login_gate_request();
        })), Server.shared().setReconCb((() => {
        })), e) {
            Server.shared().pop_response();
            this.send_login_request();
        }
        else {
            let e = URLConfig.orginHttp_tcp, t = NetHostManager.shared().chooseBestTcpIpConn(this.roomId), s = NetHostManager.shared().chooseBestTcpPortConn(this.roomId);
            "-1" != t && -1 != s && (e = 443 == s ? "wss://" + t + ":443" : "ws://" + t + ":" + s);
            Server.shared().createSocket(e);
        }
    }
    send_login_request() {
        if (this.bHasSendLogin) {
            return;
        }
        if (this.bHasSendLogin = true, TweenTool.delayAct(ToolUtils.getPersistGlobalNode(), (() => {
            this.bHasSendLogin = false;
        }), 2, true), 1 == User.shared().isInPerformanceRoom) {
            let e = { cmd: NetConfig.GM_LOGIN_REQUEST, uid: User.shared().data.uid, skey: User.shared().getSkey(), version: GameConfig.Server_Api_Ver, ch_id: GameConfig.CHANNEL_ID, game_id: this.game_id, vid: this.roomId, step: 0 };
            return 0 != this.round && (e.round = this.round, User.shared().play_back_round = this.round), ToolUtils.curVId = this.roomId > 0 ? this.roomId : 0, void Server.shared().send(e);
        }
        User.shared().send_game_log_time = sys.now();
        let e = { cmd: NetConfig.GM_LOGIN_REQUEST, uid: User.shared().data.uid, skey: User.shared().getSkey(), version: GameConfig.Server_Api_Ver, auto_sort: User.shared().auto_sort, ch_id: GameConfig.CHANNEL_ID };
        null != this.privateRoomData && null != this.privateRoomData && (e.room_type = 1, e.roomid = null != this.privateRoomData.roomid && null != this.privateRoomData.roomid ? this.privateRoomData.roomid : 0, e.base_money = null != this.privateRoomData.base_money && null != this.privateRoomData.base_money ? this.privateRoomData.base_money : 0, e.seat_max = null != this.privateRoomData.seat_max && null != this.privateRoomData.seat_max ? this.privateRoomData.seat_max : 0, null !== this.privateRoomData.disuse_score && (e.disuse_score = this.privateRoomData.disuse_score), null !== this.privateRoomData.rounds && (e.rounds = this.privateRoomData.rounds));
        null != this.raceid && 0 != this.raceid && (e.raceid = this.raceid);
        null != this.game_id && null != this.game_id && (e.game_id = this.game_id);
        TransferPlatform.shared().getChannelId();
        User.shared().roomTable && 1 === User.shared().roomTable.pri_list_open && (e.clubid = Number(TransferPlatform.shared().getChannelId()));
        ToolUtils.curVId = this.roomId > 0 ? this.roomId : 0;
        ToolUtils.curGameType = CommonGameType.Rummy;
        let t = this.tid > 0 ? this.tid : 0;
        e.tid = t;
        e.vid = this.roomId;
        e.tid_key = this.tid_key;
        e.isNewTable = this.isNewTable;
        e.robot_view = this.robot_view;
        0 == this.is_back || this.roomId != HowToPlayDefined.gameVid_rummyPoint && this.roomId != HowToPlayDefined.gameVid_rummyPool && this.roomId != HowToPlayDefined.gameVid_rummyDeal || (e.is_back = 1);
        User.shared().enterRoomMoneyExe = User.shared().data && User.shared().data.money_exe ? User.shared().data.money_exe : 0;
        User.shared().enterRoomMoney = User.shared().data && User.shared().data.money ? User.shared().data.money : 0;
        Server.shared().send(e);
    }
    regEventinit() {
        Server.shared().regDispatch(NetConfig.SM_LOGIN_RETURN, this.handler_server_login_Rummy_return.bind(this), this);
        Server.shared().regDispatch(NetConfig.SERVER_LOGIN_GATE_RESP, this.handler_server_login_gate_return.bind(this), this);
        Server.shared().regDispatch(NetConfig.SM_LOGIN_ERR_UC, this.handler_server_sm_login_err.bind(this), this);
        Server.shared().regDispatch(NetConfig.SYSTEM_GATEWAY_CMD, this.handler_server_system_gateway_return.bind(this), this);
        Server.shared().regDispatch(NetConfig.SM_CREATE_TABLE_RETURN, this.handler_server_create_tabel_return.bind(this), this);
    }
    handler_server_system_gateway_return(e) {
        if (this.handler_server_login_error(e) && -1 === e.res) {
            let e = i18nMgr.shared().getValueByKey("utlis.service_upgrade");
            Utils.shared().showToast(e, 2, 0, ToolUtils.getIsNormalDirection());
            Server.shared().onBackGroundLink();
            this.removeLoadTable();
        }
    }
    handler_server_login_gate_return(e) {
        if (window.InRummyScene) {
            return this.clearEventByThis(), void this.removeLoadTable();
        }
        if (User.shared().send_gate_log_time > 0 && (ToolUtils.enter_game_ping = sys.now() - User.shared().send_gate_log_time), 0 == e.res) {
            Utils.shared().showLoading(10, true, (() => {
                Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
                User.shared().send_request_hall_tableinfo();
            }), ToolUtils.getIsNormalDirection(), 1);
            this.send_login_request();
        }
        else {
            Utils.shared().hideLoading();
            let t = ToolUtils.isSafeString(e.msg);
            0 === t.length && (t = i18nMgr.shared().getValueByKey("utlis.text4"));
            Utils.shared().showCommomDialog(t, i18nMgr.shared().getValueByKey("gameRummy_notice_Pop.notice"), (e => {
                1 == e ? (Utils.shared().showLoading(10, true, (() => {
                    Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
                    User.shared().send_request_hall_tableinfo();
                }), ToolUtils.getIsNormalDirection(), 1), this.regEventinit(), this.doConnectRequest()) : this.removeLoadTable();
            }), true, false);
        }
    }
    handler_server_login_error(e) {
        let t = i18nMgr.shared().getValueByKey("utlis.notice"), s = e.msg;
        return Utils.shared().hideLoading(), -1 !== e.res || null == e.code || null == e.code || (Server.shared().onBackGroundLink(), 1002 == e.code ? (ToolUtils.isSafeString(s).length > 0 ? Utils.shared().showCommomDialog(s, t, (t => {
            1 == t ? (this.roomId = e.in_vid, this.regEventinit(), Utils.shared().showLoading(10, true, (() => {
                Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
                User.shared().send_request_hall_tableinfo();
            }), ToolUtils.getIsNormalDirection(), 1), this.doConnectRequest()) : this.removeLoadTable();
        }), true, false) : this.removeLoadTable(), false) : 1001 != e.code || (this.removeLoadTable(), ToolUtils.isSafeString(s).length > 0 && Utils.shared().showCommomDialog(s, t, (e => {
            User.shared().showLogin();
        }), false), false));
    }
    handler_server_sm_login_err(e) {
        if (null != e.alertStr && null != e.alertStr && e.alertStr.length > 0) {
            let t = 2;
            sys.isObjectValid(e.type) && (12 != e.type && 37 != e.type && 38 != e.type || (t = 6));
            Utils.shared().showToast(e.alertStr, t);
        }
        this.removeLoadTable();
    }
    getDeskInfo(e) {
        if (User.shared().curDeskIndex = 0, Array.isArray(e.table_keys)) {
            for (const t in e.table_keys) {
                let a = e.table_keys[t], i = new DeskInfo;
                i.tid_key = ToolUtils.isSafeString(a.tid_key);
                i.vid = a.vid;
                sys.isObjectValid(a.venuetype) || (a.venuetype = 2);
                i.venuetype = a.venuetype;
                sys.isObjectValid(a.game_type) && (i.game_type = a.game_type);
                sys.isObjectValid(a.pnum) && (i.pnum = a.pnum);
                sys.isObjectValid(a.base_money) && (i.base_money = a.base_money);
                sys.isObjectValid(a.round) && (i.round = a.round);
                sys.isObjectValid(a.currentRound) && (i.currentRound = a.currentRound);
                sys.isObjectValid(a.mode) && (i.mode = a.mode);
                sys.isObjectValid(a.special_mode) && (i.special_mode = a.special_mode);
                sys.isObjectValid(a.match_mode) && (i.match_mode = a.match_mode);
                sys.isObjectValid(a.is_double) && (i.is_double = a.is_double);
                ToolUtils.deskInfos.set(ToolUtils.isSafeString(a.tid_key), i);
            }
        }
        else {
            User.shared().getDeskInfo(e);
        }
    }
    handler_server_login_Rummy_return(e) {
        if (sys.isObjectValid(e.session_id) && (User.shared().session_id = e.session_id), window.InRummyScene) {
            return this.clearEventByThis(), void this.removeLoadTable(false);
        }
        if (User.shared().send_game_log_time > 0 && (ToolUtils.enter_game_ping = sys.now() - User.shared().send_game_log_time), 0 == parseInt("" + e.ret)) {
            1 == e.isNewTable ? this.createNewTable() : window.InRummyScene || this.enterGameRoom(e);
        }
        else if (1002 == parseInt("" + e.code)) {
            ToolUtils.curRoomId = 0;
            User.shared().send_request_hall_tableinfo();
            let t = i18nMgr.shared().getValueByKey("utlis.notice"), s = e.alertStr || "", a = ToolUtils.isSafeNumber(e.in_vid), i = ToolUtils.isSafeNumber(e.game_type);
            ToolUtils.isSafeString(s).length > 0 && Utils.shared().showCommomDialog(s, t, (e => {
                1 == e && Utils.shared().showLoadTable(a, i);
            }), false);
            this.removeLoadTable();
        }
        else if (1001 == e.code) {
            let t = i18nMgr.shared().getValueByKey("utlis.notice"), s = e.alertStr || "";
            ToolUtils.isSafeString(s).length > 0 && Utils.shared().showCommomDialog(s, t, (e => {
                User.shared().showLogin();
            }), false);
            this.removeLoadTable();
        }
        else {
            Utils.shared().hideLoading();
            let t = i18nMgr.shared().getValueByKey("utlis.notice"), s = e.alertStr || "", a = e.code;
            ToolUtils.isSafeString(s).length > 0 && Utils.shared().showCommomDialog(s, t, (e => {
                1 == e && 1003 == a && PushCenter.shared().pushEvent(GameConfig.EnterRoom_LackMoney);
            }), false);
        }
        0 == parseInt("" + e.ret) || (Server.shared().onBackGroundLink(), this.removeLoadTable());
    }
    enterGameRoom(e) {
        null != e.old_tid_key && "" != e.old_tid_key || (!sys.isObjectValid(e.table_keys) || Array.isArray(e.table_keys) && e.table_keys.length <= 1) && 0 == this.tid_key.length && HttpManager.shared().doGetCommonRequest(null, HttpRequest.HallFirstInRoom, null);
        User.shared().curDeskIndex = 0;
        User.shared().curTid_key = ToolUtils.isSafeString(e.tid_key);
        ToolUtils.curGameType = CommonGameType.Rummy;
        ToolUtils.curRoomId = e.vid || this.roomId;
        User.shared().gameRummyType = e.mode;
        User.shared().isShowMatchEnterTips = false;
        this.getDeskInfo(e);
        this.enterGameScene();
        let t = ReportConfig.scece.Rummy_Game, a = ReportConfig.func.Rummy_Game_Point;
        this.roomType == HowToPlayDefined.RUMMY_POINTS ? t = ReportConfig.scece.CashPoint : this.roomType == HowToPlayDefined.RUMMY_POOL ? (t = ReportConfig.scece.CashPool, a = ReportConfig.func.Rummy_Game_Pool) : this.roomType == HowToPlayDefined.RUMMY_DEALS ? (t = ReportConfig.scece.CashDeals, a = ReportConfig.func.Rummy_Game_Deals) : this.roomType == HowToPlayDefined.RUMMY_MULTIPLE && (t = ReportConfig.scece.CashMultiple, a = ReportConfig.func.Rummy_Game_Multiple);
        let i = { scene: t, func: a, event: ReportConfig.cash_evt.enter_game_load_res };
        User.shared().first_click_play_time > 0 && (i.play_time = User.shared().first_click_play_time);
        HttpManager.shared().doSdkApiReport(i);
        User.shared().enter_game_loadRes_time = sys.now();
    }
    enterGameScene() {
        window.InRummyScene = true;
        window.InHallScene = false;
        Utils.shared().showLoading(10, true, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
            User.shared().send_request_hall_tableinfo();
        }), ToolUtils.getIsNormalDirection(), 1);
        PushCenter.shared().pushEvent(PushEvent.EnterSwitchScene);
        PushCenter.shared().pushEvent(PushEvent.Low_Memory_Notice);
        sys.isNative && sys.garbageCollect();
        TransferPlatform.shared().setHighFrameRate();
        this.enterSwitchScene();
    }
    enterSwitchScene() {
        ToolUtils.report_time_param.loadSwitchStart = sys.now();
        window.InSwitchScene = true;
        window.IsBackToHallLoad = false;
        let e = 100;
        sys.isNative ? sys.os !== sys.OS.IOS && sys.os !== sys.OS.OSX || (e = 50, ToolUtils.isPadPlatform() && (e = 30)) : e = 0;
        let t = this;
        ToolUtils.loadBundleScene(BundleNameDefined.bundle_switch, BundleNameDefined.switch_scence, ((s, a) => {
            null == s ? t.jumpToSwitchScene(t, e, a) : ToolUtils.loadBundleScene(BundleNameDefined.bundle_switch, BundleNameDefined.switch_scence, ((s, a) => {
                null == s ? t.jumpToSwitchScene(t, e, a) : (t.clearEventByThis(), Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text27"), 2), t.removeLoadTable(false), window.InRummyScene = false, window.InHallScene = true);
            }));
        }));
    }
    jumpToSwitchScene(e, t, i) {
        e.clearEventByThis();
        ToolUtils.report_time_param.loadSwitchEnd = sys.now();
        ToolUtils.bSwitchToGame = true;
        sys.os === sys.OS.IOS || sys.os === sys.OS.OSX ? (ToolUtils.isPadPlatform() ? Utils.shared().hideHallNode() : setTimeout((() => {
            Utils.shared().hideHallNode();
        }), t), TransferPlatform.shared().orientationToLandscape((() => {
            Utils.shared().hideHallNode();
            ToolUtils.isPadPlatform() ? setTimeout((() => {
                e && e.isValid && e.removeLoadTable(false);
                ToolUtils.switchSceneTye = 1;
                Utils.shared().setLoadingPersist(true);
                director.runScene(i);
            }), t) : (e && e.isValid && e.removeLoadTable(false), ToolUtils.switchSceneTye = 1, Utils.shared().setLoadingPersist(true), director.runScene(i));
        }))) : (Utils.shared().hideHallNode(), TransferPlatform.shared().orientationToLandscape((() => {
            setTimeout((() => {
                e && e.isValid && e.removeLoadTable(false);
                ToolUtils.switchSceneTye = 1;
                Utils.shared().setLoadingPersist(true);
                director.runScene(i);
            }), t);
        })));
    }
    createNewTable() {
        User.shared().send_game_create_tab_time = sys.now();
        let e = { cmd: NetConfig.GM_CREATE_TABLE_REQUEST, uid: User.shared().data.uid, version: GameConfig.Server_Api_Ver, skey: User.shared().getSkey(), vid: this.roomId, auto_sort: User.shared().auto_sort, ch_id: GameConfig.CHANNEL_ID };
        null != this.raceid && (e.raceid = this.raceid);
        e.robot_view = this.robot_view;
        e.from_beginner_tutorial = this.fromBeginnerTutorial;
        e.tid_key = null != this.tid_key ? this.tid_key : "";
        null != this.tid && null != this.tid && this.tid;
        null != this.privateRoomData && null != this.privateRoomData && (e.room_type = 1, e.roomid = null != this.privateRoomData.roomid && null != this.privateRoomData.roomid ? this.privateRoomData.roomid : 0, e.base_money = null != this.privateRoomData.base_money && null != this.privateRoomData.base_money ? this.privateRoomData.base_money : 0, e.seat_max = null != this.privateRoomData.seat_max && null != this.privateRoomData.seat_max ? this.privateRoomData.seat_max : 0, null !== this.privateRoomData.disuse_score && (e.disuse_score = this.privateRoomData.disuse_score), null !== this.privateRoomData.rounds && (e.rounds = this.privateRoomData.rounds), e.clubid = Number(TransferPlatform.shared().getChannelId()), e.enterScene = 0);
        Server.shared().send(e);
    }
    handler_server_create_tabel_return(e) {
        if (User.shared().send_game_create_tab_time > 0 && (ToolUtils.enter_game_ping = sys.now() - User.shared().send_game_create_tab_time), 0 == parseInt("" + e.ret)) {
            sys.isObjectValid(e.session_id) && (User.shared().session_id = e.session_id);
            window.InRummyScene || (this.enterGameRoom(e), PushCenter.shared().pushEvent(GameConfig.Close_Rummy_addGame), PushCenter.shared().pushEvent(PushEvent.Close_BuddyRoomJoin));
        }
        else if (1002 == parseInt("" + e.code)) {
            ToolUtils.curRoomId = 0;
            User.shared().send_request_hall_tableinfo();
            let t = i18nMgr.shared().getValueByKey("utlis.notice"), s = e.alertStr || "";
            Utils.shared().showCommomDialog(s, t, (e => {
            }), false);
            this.removeLoadTable();
        }
        else if (1001 == e.code) {
            let t = i18nMgr.shared().getValueByKey("utlis.notice"), s = e.alertStr || "";
            Utils.shared().showCommomDialog(s, t, (e => {
                User.shared().showLogin();
            }), false);
            this.removeLoadTable();
        }
        else {
            if (Utils.shared().hideLoading(), sys.isObjectValid(e.venuetype) && 5 == e.venuetype && 1003 == e.code) {
                let t = { vid: ToolUtils.isSafeNumber(e.vid), parent_node: director.getScene().getChildByName("Canvas"), bShowNetTip: true, min_entry: ToolUtils.isSafeNumber(e.min_money) };
                return void Utils.shared().showQuickChipRecharge(t);
            }
            let t = i18nMgr.shared().getValueByKey("utlis.notice"), i = e.alertStr || "", o = e.code;
            Utils.shared().showCommomDialog(i, t, (e => {
                1 == e && 1003 == o && PushCenter.shared().pushEvent(GameConfig.EnterRoom_LackMoney);
            }), false);
        }
    }
    removeLoadTable(e = true) {
        e && Utils.shared().hideLoading();
        let t = director.getScene();
        if (ToolUtils.isObjValid(t)) {
            let e = t.getChildByName("Canvas").getChildByName("loadTableCpp");
            ToolUtils.isObjValid(e) && e.destroy();
        }
    }
    clearEventByThis() {
        Server.shared().clearEventByTarget(this);
    }
    onDestroy() {
        this.clearEventByThis();
        window.InRummyScene || PushCenter.shared().pushEvent(GameConfig.Update_Match_Hall);
        this.subLoadingDelay && (TweenTool.stopAction(this.subLoadingDelay), this.subLoadingDelay = null);
    }
}
