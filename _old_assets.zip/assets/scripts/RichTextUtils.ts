// @ts-nocheck
// Recovered from index.js:391
import { _decorator, Component } from "cc";
import PushCenter from "./PushCenter";
import PushEvent from "./PushEvent";
const { ccclass } = _decorator;
@ccclass("RichTextUtils")
export class RichTextUtils extends Component {
    start() {
    }
    onClicked(t, e) {
        PushCenter.shared().pushEvent(PushEvent.RichTextClick, e);
    }
}
