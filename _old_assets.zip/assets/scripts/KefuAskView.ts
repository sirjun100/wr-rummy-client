// @ts-nocheck
// Recovered from index.js:209
import { _decorator, Button, Label, Node, Sprite, SpriteFrame, sys, Widget } from "cc";
import BaseLayer from "./BaseLayer";
import SoundManager from "./SoundManager";
import Utils from "./Utils";
import User from "./User";
import i18nMgr from "./i18nMgr";
import HttpManager from "./HttpManager";
import { HttpRequest } from "./HttpRequestName";
import ReportConfig from "./ReportConfig";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("KefuAskView")
export class KefuAskView extends BaseLayer {
    @property(Node)
    public rootNode: Node = null;
    @property([SpriteFrame])
    public selectImags: SpriteFrame[] = [];
    @property(Sprite)
    public selectSprite: Sprite = null;
    @property(Label)
    public reasonTitleLabel: Label = null;
    @property(Label)
    public reasonTipsLabel: Label = null;
    public _curAskView: any = null;
    public _linkId: number = 0;
    public _nVid: number = 0;
    public _ui_type: number = 1;
    public _hasSelect: number = 0;
    public _kefuSites: any = null;
    public _alert_type: number = 1;
    public _reason_type: number = 1;
    onLoad() {
        ToolUtils.showFullScreen(this.node.getChildByName("mask"));
        this.fitScreen();
    }
    fitScreen() {
        let e = ToolUtils.getSafeDistance();
        sys.os === sys.OS.IOS && ToolUtils.getSafeDistance() > 40 && (e = ToolUtils.getSafeDistance() - 40);
        this.rootNode.getComponent(Widget).bottom = 190 + e;
    }
    initParaData(e) {
        sys.isObjectValid(e) && sys.isObjectValid(e.vid) ? this._nVid = e.vid : this._nVid = ToolUtils.curRoomId;
        sys.isObjectValid(e) && sys.isObjectValid(e.ui_type) ? this._ui_type = e.ui_type : this._ui_type = 1;
        User.shared().soreTb && sys.isObjectValid(User.shared().soreTb.custom_buttons) && (this._kefuSites = User.shared().soreTb.custom_buttons);
        this._hasSelect = 0;
        this.refreshAskView();
        this._alert_type = 1;
        this._linkId = sys.now();
        4 == this._ui_type ? (this._alert_type = 2, this.requestStoreKefuIncrPopTimes(), HttpManager.shared().doCommReportRechargeEvent(ReportConfig.Cmd_StoreKefuEntry, 3, 22, this._linkId, { type: this._alert_type }, this._nVid)) : HttpManager.shared().doCommReportRechargeEvent(ReportConfig.Cmd_StoreKefuEntry, 3, 2, this._linkId, { type: this._alert_type }, this._nVid);
    }
    refreshAskView() {
        let e;
        for (let t = 0; t < 5; t++) {
            e = "ask" + t;
            let i = this.rootNode.getChildByName(e);
            i && (this._ui_type - 1 == t ? (this._curAskView = i, i.active = true) : i.active = false);
        }
        4 == this._ui_type && this.refreshSelect();
    }
    refreshSelect() {
        this.selectSprite.spriteFrame = this.selectImags[this._hasSelect];
    }
    start() {
        super.start();
    }
    onButtonClick(e, t) {
        if (SoundManager.shared().playFx("click"), "close" === t) {
            this.onBackView();
        }
        else if ("select" === t) {
            this._hasSelect = 1 == this._hasSelect ? 0 : 1;
            this.refreshSelect();
        }
        else if ("main_page" === t) {
            let e = 0;
            5 == this._ui_type && (1 == this._reason_type ? e = 16 : 2 == this._reason_type ? e = 18 : 3 == this._reason_type && (e = 20), HttpManager.shared().doCommReportRechargeEvent(ReportConfig.Cmd_StoreKefuEntry, 3, e, this._linkId, this._alert_type, this._nVid));
            this._ui_type = 1;
            this.refreshAskView();
        }
    }
    problemBtnClick(e, t) {
        SoundManager.shared().playFx("click");
        let i = Number(t), s = 3 + i;
        if (0 == i) {
            this._ui_type = 2;
            this.refreshAskView();
        }
        else if (i >= 1 && i <= 3) {
            this._ui_type = 5;
            this._reason_type = i;
            this.refreshAskView();
            let e = "kefu_ask.reason_title" + i, s = "kefu_ask.reason_text" + i;
            i18nMgr.shared().changeLocalizedLabelKey(this.reasonTitleLabel.node, e);
            i18nMgr.shared().changeLocalizedLabelKey(this.reasonTipsLabel.node, s);
            this._curAskView.getChildByName("button_nodes").getChildByName("Button1").getComponent(Button).clickEvents[0].customEventData = t + "";
        }
        else {
            4 == i && (this.showCustomerServiceAlert(5), this.closeView());
        }
        HttpManager.shared().doCommReportRechargeEvent(ReportConfig.Cmd_StoreKefuEntry, 3, s, this._linkId, { type: this._alert_type }, this._nVid);
    }
    paymentBtnClick(e, t) {
        SoundManager.shared().playFx("click");
        let i = 9 + Number(t);
        HttpManager.shared().doCommReportRechargeEvent(ReportConfig.Cmd_StoreKefuEntry, 3, i, this._linkId, { type: this._alert_type }, this._nVid);
        this._ui_type = 3;
        this.refreshAskView();
    }
    thankAdviceBtnClick(e, t) {
        SoundManager.shared().playFx("click");
        HttpManager.shared().doCommReportRechargeEvent(ReportConfig.Cmd_StoreKefuEntry, 3, 27, this._linkId, this._alert_type, this._nVid);
        this.showCustomerServiceAlert(1);
        this.closeView();
    }
    submitMoreBtnClick(e, t) {
        SoundManager.shared().playFx("click");
        let i = 0;
        5 == this._ui_type && (1 == this._reason_type ? i = 17 : 2 == this._reason_type ? i = 19 : 3 == this._reason_type && (i = 21), HttpManager.shared().doCommReportRechargeEvent(ReportConfig.Cmd_StoreKefuEntry, 3, i, this._linkId, this._alert_type, this._nVid));
        let s = Number(t) + 1;
        this.showCustomerServiceAlert(s);
        this.closeView();
    }
    closeView() {
        ToolUtils.isObjValid(this.node) && this.node.destroy();
    }
    showCustomerServiceAlert(e) {
        if (this._kefuSites) {
            let t = "button_" + e, i = this._kefuSites[t];
            if (ToolUtils.isSafeString(i).length > 0) {
                let e = { url: i, title: i18nMgr.shared().getValueByKey("utlis.feedback"), key: "utlis.feedback" };
                e && e.url && Utils.shared().openUrl(e);
            }
        }
    }
    helpBtnClick(e, t) {
        if (SoundManager.shared().playFx("click"), 0 == Number(t)) {
            let e = User.shared().data.feedback_url;
            Utils.shared().showContactUsView(e);
        }
        let i = 23 + Number(t);
        HttpManager.shared().doCommReportRechargeEvent(ReportConfig.Cmd_StoreKefuEntry, 3, i, this._linkId, this._alert_type, this._nVid);
        1 == this._hasSelect && (this.requestCheckCloseShopCustomerPassivePop(), HttpManager.shared().doCommReportRechargeEvent(ReportConfig.Cmd_StoreKefuEntry, 3, 25, this._linkId, { type: this._alert_type }, this._nVid));
        this.closeView();
    }
    requestCheckCloseShopCustomerPassivePop() {
        HttpManager.shared().doGetCommonRequest(null, HttpRequest.StoreCheckCloseShopCustomerPassivePop, ((e, t, i) => {
        }));
    }
    requestStoreKefuIncrPopTimes() {
        HttpManager.shared().doGetCommonRequest(null, HttpRequest.StoreKefuIncrPopTimes, ((e, t, i) => {
        }));
    }
    onBackView() {
        ToolUtils.isObjValid(this.node) && (4 == this._ui_type && 1 == this._hasSelect && (this.requestCheckCloseShopCustomerPassivePop(), HttpManager.shared().doCommReportRechargeEvent(ReportConfig.Cmd_StoreKefuEntry, 3, 25, this._linkId, { type: this._alert_type }, this._nVid)), 4 == this._ui_type || this._ui_type, this.node.destroy());
    }
}
