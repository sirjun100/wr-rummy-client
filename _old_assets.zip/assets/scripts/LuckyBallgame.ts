// @ts-nocheck
// Recovered from index.js:275
import { _decorator, color, director, find, instantiate, isValid, Label, Node, ScrollView, sp, Sprite, SpriteFrame, sys, tween, UITransform, v3, view, Widget } from "cc";
import i18nMgr from "./i18nMgr";
import { TLog } from "./TLog";
import { ToolUtils } from "./ToolUtils";
import TweenTool from "./TweenTool";
import Utils from "./Utils";
import BundleNameDefined from "./BundleNameDefined";
import GameConfig from "./GameConfig";
import PhpReportDefined from "./PhpReportDefined";
import PushEvent from "./PushEvent";
import User from "./User";
import Server from "./Server";
import SoundManager from "./SoundManager";
import { MyComponent } from "./MyComponent";
import { LuckBallAnteSucceed } from "./LuckBallAnteSucceed";
import { LuckBallAnteWinPop } from "./LuckBallAnteWinPop";
import { LuckCountDown } from "./LuckCountDown";
import { LucktBallAntePop } from "./LucktBallAntePop";
import { LuckyBallGameCmd } from "./LuckyBallGameCmd";
import { LuckyBallGameHandle } from "./LuckyBallGameHandle";
import { TScrollView } from "./TScrollView";
import PushCenter from "./PushCenter";
const { ccclass, property } = _decorator;
@ccclass("LuckyBallgame")
export class LuckyBallgame extends MyComponent {
    @property(Node)
    public topSw: Node = null;
    @property(Label)
    public currMoney: Label = null;
    @property(Node)
    public typeBtnNodePanel: Node = null;
    @property(Node)
    public currTimeType: Node = null;
    @property(Node)
    public topCountDownNode: Node = null;
    @property(LuckCountDown)
    public countDownNode: LuckCountDown = null;
    @property(Label)
    public nextSerialNumber: Label = null;
    @property(Node)
    public topRecordNodeList: Node = null;
    @property(Node)
    public recordTypeSelectNode: Node = null;
    @property(TScrollView)
    public ts: TScrollView = null;
    @property(Node)
    public listNode: Node = null;
    @property(SpriteFrame)
    public qiuIconArr: SpriteFrame = [];
    @property(Node)
    public nodataNode: Node = null;
    @property(Node)
    public glodAnimNode: Node = null;
    public tid_key: string = "";
    public mTimeTypeList: any[] = [30, 60, 180];
    public mCurrSelectTimeType: number = 0;
    public mCurrSelectRecordType: number = 0;
    public mData: any = null;
    public mCurrRecordList: any[] = [];
    public mCurrOrderRecordList: any[] = [];
    public isFirstEnter: boolean = false;
    public recordIsReq: boolean = false;
    public recordIsDi: boolean = false;
    public isReqData: boolean = false;
    public addRecordArr: any[] = [];
    public isPlayOpenAwardAnim: boolean = false;
    public lucktBallAntePopNode: any = null;
    onLoad() {
        Server.shared().regDispatch(LuckyBallGameCmd.SM_TABLE_INFO_BC_RETURN, this.UpdateGameRoomInfo.bind(this), this);
        Server.shared().regDispatch(LuckyBallGameCmd.SM_HISTORY_RECORD_RETURN, this.UpdateRecordListResult.bind(this), this);
        Server.shared().regDispatch(LuckyBallGameCmd.SM_NOTIFY_RESULT_INFO, this.openAwardResult.bind(this), this);
        Server.shared().regDispatch(LuckyBallGameCmd.SM_BET_RETURN, this.AnteResult.bind(this), this);
        Server.shared().regDispatch(LuckyBallGameCmd.SM_NOTIFY_GAME_STATUS, this.gameStateChangeResult.bind(this), this);
        Server.shared().regDispatch(LuckyBallGameCmd.SERVER_ALERT_RETURN, this.handler_server_alert_return.bind(this), this);
        this.addEvent(GameConfig.Update_Money, (e => {
            this.updatePlayerMoney(Number(e));
        }), this);
        this.glodAnimNode.getComponent(sp.Skeleton).setCompleteListener((() => {
            this.glodAnimNode.active = false;
        }));
        PushCenter.shared().addListener(PushEvent.Update_Gullak_RewardInGame, (e => {
            ToolUtils.isObjValid(this.node) && this.updateGullakBtnStatus(User.shared().act_68_open, User.shared().act_68_full_status, true);
        }), this);
        this.fitScreen();
        this.fitLuckyTheme();
    }
    start() {
        this.tid_key = this.node.getComponent(LuckyBallGameHandle).tid_key;
        this.sendGameInfoRequest();
        this.updatePlayerMoney();
        SoundManager.shared().preLoadBundleSounds(BundleNameDefined.bundle_sound, "luckball");
        this.updateGullakBtnStatus(User.shared().act_68_open, User.shared().act_68_full_status, true);
    }
    fitScreen() {
        ToolUtils.adaptSafeArea(this.node.getChildByName("bg"));
        let e = sys.getSafeAreaRect().y;
        this.node.getComponent(Widget).bottom = -e;
        this.node.getComponent(Widget).updateAlignment();
        this.node.getChildByName("bg").getComponent(Widget).updateAlignment();
        let t = view.getVisibleSize(), i = t.height - 1280 - e;
        this.topSw.getChildByName("list").getComponent(UITransform).height = i + 1160;
        this.listNode.parent.getComponent(UITransform).height = i;
        this.ts.node.getComponent(UITransform).height = i + 345;
        this.listNode.getComponent(UITransform).height = i;
        this.nodataNode.setPosition(this.nodataNode.position.x, this.nodataNode.position.y - (t.height - 1280) / 4 - e);
    }
    fitLuckyTheme() {
        if (0 == GameConfig.NATIVE_GAME_APP_TYPE) {
            return;
        }
        let e = color(12, 26, 60);
        find("bg/topnode/top_bg", this.node).getComponent(Sprite).color = e;
        find("antenode/countDown/bg1", this.topSw.getComponent(ScrollView).content).getComponent(Sprite).color = e;
        find("antenode/countDown/bg2", this.topSw.getComponent(ScrollView).content).getComponent(Sprite).color = e;
        this.topSw.getComponent(ScrollView).content.getChildByName("antenode").getChildByName("countDown").getChildByName("bg1").getComponent(Sprite).color = e;
        find("Node/bg", this.topSw.getComponent(ScrollView).content).getComponent(Sprite).color = color(250, 250, 250, 255);
        find("timeType/0/line", this.topSw.getComponent(ScrollView).content).getComponent(Sprite).color = color(221, 3, 3, 255);
        find("timeType/1/line", this.topSw.getComponent(ScrollView).content).getComponent(Sprite).color = color(221, 3, 3, 255);
        find("timeType/2/line", this.topSw.getComponent(ScrollView).content).getComponent(Sprite).color = color(221, 3, 3, 255);
        find("timeType/0/select", this.topSw.getComponent(ScrollView).content).getComponent(Label).color = color(221, 3, 3, 255);
        find("timeType/1/select", this.topSw.getComponent(ScrollView).content).getComponent(Label).color = color(221, 3, 3, 255);
        find("timeType/2/select", this.topSw.getComponent(ScrollView).content).getComponent(Label).color = color(221, 3, 3, 255);
    }
    onShowGlodAnim() {
        this.glodAnimNode.active = true;
        this.scheduleOnce((() => {
            this.glodAnimNode.getComponent(sp.Skeleton).setAnimation(0, 2 * Math.random() > 1 ? "win2" : "win", false);
        }));
    }
    sendGameInfoRequest() {
        this.isReqData = true;
        let e = { cmd: LuckyBallGameCmd.GM_GET_TABLE_INFO, uid: User.shared().data.uid, version: GameConfig.Server_Api_Ver, skey: User.shared().getSkey(), vid: ToolUtils.curRoomId, tid_key: this.tid_key };
        Server.shared().send(e);
    }
    requestGameRoomInfo() {
        this.isReqData = true;
        let e = { cmd: LuckyBallGameCmd.GM_SWITCH_MODE_REQUEST, mode: this.mCurrSelectTimeType, tid_key: this.tid_key };
        Server.shared().send(e);
    }
    requestRecordList() {
        this.isReqData = true;
        let e = { cmd: LuckyBallGameCmd.GM_HISTORY_RECORD_REQUSET, type: this.mCurrSelectRecordType, tid_key: this.tid_key };
        Server.shared().send(e);
    }
    updateGullakBtnStatus(e, t, i) {
        let o = this.node.getChildByName("bg").getChildByName("topnode").getChildByName("gullak_btn");
        if (ToolUtils.isObjValid(o) && (o.active = 1 == e, 1 == e)) {
            let e = o.getChildByName("anim").getComponent(sp.Skeleton);
            e.clearTracks();
            e.setToSetupPose();
            i ? (e.setAnimation(0, "2", false), e.setCompleteListener((() => {
                e.setCompleteListener(null);
                e.clearTracks();
                e.setToSetupPose();
                0 == t ? e.setAnimation(0, "0", true) : e.setAnimation(0, "1", true);
            }))) : 0 == t ? e.setAnimation(0, "0", true) : e.setAnimation(0, "1", true);
        }
    }
    UpdateGameRoomInfo(e) {
        JSON.stringify(e) != JSON.stringify(this.mData) && (this.isReqData = false, this.mData = e, this.isFirstEnter || (this.isFirstEnter = true, this.mCurrSelectTimeType = e.mode, this.createTimeSelectBtn()), this.deleteTweenAnim(), this.setListView(5, this.topRecordNodeList, ((t, i, o) => {
            i.name = o.toString();
            i.setPosition(v3(55 * o, 0));
            i.getComponent(Sprite).spriteFrame = this.qiuIconArr[e.history[t]];
            i.getChildByName("new").active = 0 == o;
        })), this.mCurrSelectRecordType = -1, this.onClikcRecordTypeBtn(null, 0), this.nextSerialNumber.string = Number(e.id).toString(), this.currTimeType.getComponent(Label).string = this.mTimeTypeList[e.mode] >= 60 ? `Win Go ${this.mTimeTypeList[e.mode] / 60}Min` : `Win Go ${this.mTimeTypeList[e.mode]}s`, 1 == e.status ? this.updateTopCountDownNode(0) : this.updateTopCountDownNode(-1), 0 == e.status && this.countDownNode.setData(e.cd, e.status, this.updateTopCountDownNode.bind(this)));
    }
    UpdateRecordListResult(e) {
        if (this.isReqData = false, this.recordIsReq = false, e.type == this.mCurrSelectRecordType) {
            if (0 == e.type) {
                let t = e.result ? e.result : [];
                this.mCurrRecordList != t && (this.mCurrRecordList = t, this.updateRecordList());
            }
            else {
                let t = e.order ? e.order : [];
                this.mCurrOrderRecordList != t && (this.mCurrOrderRecordList = t, this.updateRecordList());
            }
        }
    }
    async openAwardResult(e) {
        if (this.isReqData = false, this.updatePlayerMoney(e.coin), e.mode == this.mCurrSelectTimeType) {
            let t = { id: e.id, sicbo: e.sicbo, num: e.num };
            if (this.mCurrRecordList.includes(t)) {
                return;
            }
            this.addRecordArr.push(e.num);
            this.isPlayOpenAwardAnim || (this.isPlayOpenAwardAnim = true, this.playNewRecodAnim());
            0 == this.mCurrSelectRecordType && (this.mCurrRecordList.unshift(t), this.updateRecordList());
        }
        if (e.win_score <= 0) {
            return;
        }
        if (this.node.getChildByName("pop").getChildByName("LuckBallAnteWinPop")) {
            return;
        }
        let t = await this.loadPrefabToPop(BundleNameDefined.Bundle_LuckyBall, "prefab/LuckBallAnteWinPop", this.node.getChildByName("pop"));
        t.name = "LuckBallAnteWinPop";
        t.getComponent(LuckBallAnteWinPop).setData(e, (() => {
            this.glodAnimNode.active = true;
            this.glodAnimNode.getComponent(sp.Skeleton).setAnimation(0, 1 == e.sicbo ? "win2" : "win", false);
            SoundManager.shared().playFx("luckball_gold");
        }));
    }
    async AnteResult(e) {
        if (this.isReqData = false, 1 == e.ret) {
            return;
        }
        if (e.mode == this.mCurrSelectTimeType && 1 == this.mCurrSelectRecordType) {
            let t = { id: e.id, type: e.type, index: e.index, value: -e.bet };
            this.mCurrOrderRecordList.unshift(t);
            this.updateRecordList();
        }
        if (this.updatePlayerMoney(e.coin), this.node.getChildByName("pop").getChildByName("LuckBallAnteSucceed")) {
            return;
        }
        isValid(this.lucktBallAntePopNode) && (this.lucktBallAntePopNode.destroy(), this.lucktBallAntePopNode = null);
        let t = await this.loadPrefabToPop(BundleNameDefined.Bundle_LuckyBall, "prefab/LuckBallAnteSucceed", this.node.getChildByName("pop"));
        t.name = "LuckBallAnteSucceed";
        t.getComponent(LuckBallAnteSucceed).setData((() => {
            isValid(this.lucktBallAntePopNode) && (this.lucktBallAntePopNode.destroy(), this.lucktBallAntePopNode = null);
        }));
    }
    handler_server_alert_return(e) {
        let t = 0;
        sys.isObjectValid(e.type) && (t = Number(e.type));
        let i = e.alertStr;
        if (2 == t) {
            let t = 100;
            sys.isObjectValid(e.diff_coin) && e.diff_coin > 0 && (t = e.diff_coin);
            Utils.shared().showQuickRecharge(ToolUtils.curRoomId, this.node, true, this.tid_key, 0, t);
            User.shared().updatePayScene(PhpReportDefined.pay_scene.game_selectroom_less_money, ToolUtils.curVId);
        }
        else {
            11 != t && 0 != t || sys.isObjectValid(i) && String(i).length > 0 && Utils.shared().showToast(i, 2);
        }
    }
    gameStateChangeResult(e) {
        this.isReqData = false;
        this.mCurrSelectTimeType == e.mode && 0 == e.status ? (this.countDownNode.setData(e.cd, e.status, this.updateTopCountDownNode.bind(this)), this.updateTopCountDownNode(-1)) : (this.countDownNode.setData(-1, e.status, null), this.updateTopCountDownNode(0));
        this.nextSerialNumber.string = e.id;
    }
    updatePlayerMoney(e) {
        e ? (User.shared().updateMoney(e), this.currMoney.string = ToolUtils.parse_double(e.toString())) : this.currMoney.string = ToolUtils.parse_double(User.shared().data.money.toString());
    }
    updateTopCountDownNode(e) {
        if (e > -1) {
            this.topCountDownNode.active = true;
            for (let t = 0; t < 6; t++) {
                this.topCountDownNode.getChildByName("miao_" + t).active = t == e;
            }
        }
        else {
            this.topCountDownNode.active = false;
        }
    }
    onClickTimeTypeBtn(e) {
        if (SoundManager.shared().playFx("click"), !this.mData) {
            return;
        }
        let t = e.target;
        if (this.mCurrSelectTimeType == Number(t.name)) {
            return;
        }
        this.mCurrSelectTimeType = Number(t.name);
        this.typeBtnNodePanel.children.forEach((e => {
            Number(e.name) == this.mCurrSelectTimeType ? (e.getChildByName("select").active = true, i18nMgr.shared().changeLabelFont(e.getChildByName("select").getComponent(Label), true), e.getChildByName("com").active = false) : (e.getChildByName("select").active = false, e.getChildByName("com").active = true, i18nMgr.shared().changeLabelFont(e.getChildByName("select").getComponent(Label), false), e.getChildByName("line").active = false);
        }));
        let i = t.getChildByName("line");
        i.active = true;
        TweenTool.stopNodeAction(i);
        i.scale = v3(0, 1, 1);
        let o = TweenTool.scaleTo(i, 0.16, v3(1.1, 1, 1), null, false), n = TweenTool.scaleTo(i, 0.16, v3(1, 1, 1), null, false);
        TweenTool.sequence(i, true, null, o, n);
        this.mCurrRecordList = [];
        this.mCurrOrderRecordList = [];
        this.updateTopCountDownNode(-1);
        this.countDownNode.setData(-1, 1);
        this.deleteTweenAnim();
        this.requestGameRoomInfo();
    }
    onClikcRecordTypeBtn(e, t) {
        e && (SoundManager.shared().playFx("click"), !this.mData) || this.mCurrSelectRecordType != Number(t) && (this.recordIsDi = false, this.mCurrSelectRecordType = Number(t), this.recordTypeSelectNode.children.forEach((e => {
            e.getChildByName("select") && (e.name == t ? e.getChildByName("select").active = true : e.getChildByName("select").active = false);
        })), this.requestRecordList());
    }
    async onClickAnteBtn(e, t) {
        if (SoundManager.shared().playFx("click"), !this.mData) {
            return;
        }
        let i = Number(e.target.name), o = Number(t), n = this, s = await this.loadPrefabToPop(BundleNameDefined.Bundle_LuckyBall, "prefab/LucktBallAntePop", n.node.getChildByName("pop"));
        n.lucktBallAntePopNode = s;
        s.getComponent(LucktBallAntePop).setData(this.mData, o, i, (() => {
            n.lucktBallAntePopNode = null;
        }));
    }
    onClickShop() {
        SoundManager.shared().playFx("click");
        Utils.shared().showStoreView();
        User.shared().updatePayScene(PhpReportDefined.pay_scene.game_desktop, ToolUtils.curVId);
    }
    aaaaa() {
        this.updateRecordList();
    }
    updateRecordList() {
        let e = 1 == this.mCurrSelectRecordType ? this.mCurrOrderRecordList : this.mCurrRecordList;
        if (!e.length) {
            return this.nodataNode.active = true, this.listNode.active = true, this.ts.node.active = false, void this.setListView([], this.listNode);
        }
        this.nodataNode.active = false;
        let t = this.ts.node.getComponent(UITransform).height / 80;
        e.length <= t ? (this.listNode.active = true, this.ts.node.active = false, this.setListView(e, this.listNode, ((e, t, i) => {
            this.updateItemNode(t, e, i);
        }))) : (this.listNode.active = false, this.ts.node.active = true, this.ts.setData(e, ((e, t, i) => {
            this.updateItemNode(e, t, i);
        })));
    }
    updateItemNode(e, t, i) {
        e.getChildByName("bg").active = i % 2 == 0;
        e.getChildByName("time").getComponent(Label).string = t.id;
        let o = e.getChildByName("resultnode"), n = e.getChildByName("ordernode");
        if (0 == this.mCurrSelectRecordType) {
            o.active = true;
            n.active = false;
            o.getChildByName("cardicon").getComponent(Sprite).spriteFrame = this.qiuIconArr[t.num];
            1 == t.sicbo ? o.getChildByName("label").getComponent(Label).string = "BIG" : o.getChildByName("label").getComponent(Label).string = "SMALL";
        }
        else {
            o.active = false;
            n.active = true;
            let e = n.getChildByName("targeticon");
            e.children.forEach((e => e.active = false));
            let i = "";
            0 == t.type ? (0 == t.index ? i = "GREEN" : 1 == t.index ? i = "RED" : 2 == t.index && (i = "VIOLET"), e.getChildByName("label").active = true, e.getChildByName("label").getComponent(Label).string = i) : 1 == t.type ? (0 == t.index ? i = "SMALL" : 1 == t.index && (i = "BIG"), e.getChildByName("label").active = true, e.getChildByName("label").getComponent(Label).string = i) : 2 == t.type && (e.getChildByName("qiu").active = true, e.getChildByName("qiu").getComponent(Sprite).spriteFrame = this.qiuIconArr[t.index]);
            let a = n.getChildByName("win"), l = n.getChildByName("lose");
            if (t.value > 0) {
                a.active = true;
                l.active = false;
                a.getComponent(Label).string = `+₹${t.value}`;
            }
            else {
                a.active = false;
                l.active = true;
                let e = (t.value + "").split("-")[1];
                l.getComponent(Label).string = `-₹${e}`;
            }
        }
    }
    onItemSwEvent() {
    }
    createTimeSelectBtn() {
        this.setListView(this.mTimeTypeList, this.typeBtnNodePanel, ((e, t, i) => {
            this.mData.able_game_mode.includes(i) ? (t.name = i.toString(), e >= 60 ? (t.getChildByName("com").getComponent(Label).string = e / 60 + "Min", t.getChildByName("select").getComponent(Label).string = e / 60 + "Min") : (t.getChildByName("com").getComponent(Label).string = e + "s", t.getChildByName("select").getComponent(Label).string = e + "s"), t.getChildByName("line").active = i == this.mData.mode, t.getChildByName("com").active = i != this.mData.mode, t.getChildByName("select").active = i == this.mData.mode) : t.active = false;
        }), null, 0);
    }
    playNewRecodAnim() {
        if (0 == this.addRecordArr.length) {
            return void (this.isPlayOpenAwardAnim = false);
        }
        let e = this.addRecordArr.shift();
        this.deleteTweenAnim();
        this.setListView(5, this.topRecordNodeList, ((e, t, i) => {
            t.setPosition(v3(55 * Number(t.name), 0));
            "5" == t.name && (this.topRecordNodeList.removeChild(t), t.destroy());
        }));
        this.topRecordNodeList.children.forEach((e => {
            e.name = (Number(e.name) + 1).toString();
            e.getChildByName("new").active = false;
            let t = tween(e).by(0.3, { position: v3(55, 0, 0) }).call((() => {
                "5" == e.name && (this.topRecordNodeList.removeChild(e), e.destroy());
                this.deleteTweenAnim(t);
            })).start();
            this.addTweenAnim(t);
        }));
        let t = instantiate(this.topRecordNodeList.children[0]);
        t.active = true;
        t.name = "0";
        this.topRecordNodeList.addChild(t);
        t.getChildByName("new").active = false;
        t.setPosition(v3(-40, 40));
        t.getComponent(Sprite).spriteFrame = this.qiuIconArr[e];
        let i = tween(t).to(0.3, { position: v3(0, 0, 0) }).call((() => {
            t.getChildByName("new").active = true;
            t.setPosition(v3(0, 0));
            this.deleteTweenAnim(i);
            this.playNewRecodAnim();
        })).start();
        this.addTweenAnim(i);
    }
    showExplainPop() {
        ToolUtils.loadCommonPrefab(null, BundleNameDefined.Bundle_LuckyBall, "prefab/LuckBallExplainPop", (e => {
            try {
                let t = instantiate(e);
                director.getScene().getChildByName("Canvas").addChild(t);
            }
            catch (e) {
                TLog.printError("createLuckBallAnteWinPop error:", e);
            }
        }));
    }
    onGullakBtn() {
        SoundManager.shared().playFx("click");
        let e = { vid: ToolUtils.curVId };
        Utils.shared().doJumpLogic(PushEvent.JUMP_TO_Gullak, e, { isNext: false, bWithTip: true, link_id: sys.now(), reportEvtId: 4, reportScene: 2 });
        User.shared().updatePayScene(PhpReportDefined.pay_scene.game_desktop, ToolUtils.curVId);
    }
    onCloseBtn() {
        SoundManager.shared().playFx("click");
        this.emitEvent(PushEvent.ExitLuckyBallGame);
        this.node.destroy();
        User.shared().getHallPopList(true);
    }
}
