// @ts-nocheck
// Recovered from index.js:443
import { _decorator, Label, Node, size, Sprite, SpriteFrame, sys } from "cc";
import SoundManager from "./SoundManager";
import RummyDataManager from "./RummyDataManager";
import Utils from "./Utils";
import User from "./User";
import RummyCmd from "./RummyCmd";
import Server from "./Server";
import TweenTool from "./TweenTool";
import i18nMgr from "./i18nMgr";
import BaseLayer from "./BaseLayer";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("RummyGameManualSplit")
export default class RummyGameManualSplit extends BaseLayer {
    @property(Node)
    public bgView: Node = null;
    @property([SpriteFrame])
    public replace_img: SpriteFrame[] = [];
    public gameController: any = undefined;
    public playerDate: any = undefined;
    public countDown: any = undefined;
    public couuntDownFun: any = null;
    public isSelected: boolean = false;
    public time_action: any = null;
    onLoad() {
        this.bIsInGame = true;
    }
    start() {
        super.start();
        ToolUtils.showFullScreen(this.node.getChildByName("bg1"));
        ToolUtils.startShowAnim(this.node.getChildByName("rootNode"));
        this.dealMultipleLanguages();
    }
    dealMultipleLanguages() {
        if (2 == i18nMgr.shared().language) {
            for (let e = 1; e <= 3; e++) {
                this.bgView.getChildByName("select_bg").getChildByName("item_model" + e).getChildByName("waiting").getComponent(Label).fontSize = 20;
            }
            this.bgView.getChildByName("text5").getComponent(Label).fontSize = 22;
            this.bgView.getChildByName("text5").getComponent(Label).lineHeight = 26;
        }
    }
    initView(e, t) {
        this.gameController = e;
        this.tid_key = t;
        let i = this.bgView.getChildByName("select_bg");
        for (let e = 1; e < 4; e++) {
            let t = i.getChildByName("item_model" + e);
            sys.isObjectValid(t) && (t.active = false);
        }
    }
    onDestroy() {
        super.onDestroy();
        this.time_action && (TweenTool.stopAction(this.time_action), this.time_action = null);
    }
    updateCountDown(e) {
        this.countDown = e;
        let t = "";
        t = ToolUtils.format(i18nMgr.shared().getValueByKey("gameRummy_pool_manual.prize_pool"), this.countDown);
        let i = 1 == i18nMgr.shared().language ? 24 : 28;
        this.bgView.getChildByName("text5").getComponent(Label).string = t;
        this.bgView.getChildByName("text5").getComponent(Label).fontSize = i;
        this.time_action = TweenTool.myschedule(RummyDataManager.shared().sceneNode, 1, this.updateTime.bind(this));
    }
    updateTime() {
        if (ToolUtils.isObjValid(this.bgView)) {
            if (this.countDown = this.countDown - 1, this.countDown < 1) {
                ToolUtils.isObjValid(this.node) && this.node.destroy();
            }
            else {
                let e = "";
                e = ToolUtils.format(i18nMgr.shared().getValueByKey("gameRummy_pool_manual.prize_pool"), this.countDown);
                this.bgView.getChildByName("text5").getComponent(Label).string = e;
            }
        }
    }
    updateSelect(e) {
        let t = this.bgView.getChildByName("select_bg"), i = this.sortPlayers(e);
        this.playerDate = i;
        for (let e = 0, a = i.length; e < a; e++) {
            let a = t.getChildByName("item_model" + (e + 1));
            if (sys.isObjectValid(a)) {
                a.active = true;
                i[e].uid == User.shared().data.uid ? a.getChildByName("me_img").active = true : a.getChildByName("me_img").active = false;
                a.getChildByName("name").getComponent(Label).string = ToolUtils.GetShortName2(i[e].name, 8, true);
                Utils.shared().updateHeadImg(a.getChildByName("head_mask").getChildByName("head"), i[e].avatar, i[e].avatar_url, size(70, 70));
                let t = "₹" + ToolUtils.parse_double(i[e].prize);
                1 == RummyDataManager.shared().rummyInfos.get(this.tid_key).crashModel && (t = ToolUtils.parse_double(i[e].prize));
                a.getChildByName("prize").getComponent(Label).string = t;
                a.getChildByName("drops").getComponent(Label).string = i[e].drops + "";
                a.getChildByName("score").getComponent(Label).string = i[e].score + "";
                0 == i[e].status ? (a.getChildByName("accepted").active = false, a.getChildByName("waiting").active = true) : 1 == i[e].status ? (a.getChildByName("accepted").active = true, a.getChildByName("accepted").getComponent(Sprite).spriteFrame = this.replace_img[0], a.getChildByName("waiting").active = false) : 2 == i[e].status && (a.getChildByName("accepted").active = true, a.getChildByName("accepted").getComponent(Sprite).spriteFrame = this.replace_img[1], a.getChildByName("waiting").active = false);
            }
            i[e].uid == User.shared().data.uid && 0 != i[e].status && (this.isSelected = true, this.bgView.getChildByName("no_btn").active = false, this.bgView.getChildByName("yes_btn").active = false);
        }
    }
    sortPlayers(e) {
        let t = e, i = [];
        for (let e = 0, a = t.length; e < a; e++) {
            User.shared().data.uid == t[e].uid ? i.unshift(t[e]) : i.push(t[e]);
        }
        return i;
    }
    updatePlayerInfo(e) {
        let t = this.bgView.getChildByName("select_bg");
        for (let i = 0, a = this.playerDate.length; i < a; i++) {
            let a = t.getChildByName("item_model" + (i + 1));
            sys.isObjectValid(a) && 1 == a.active && this.playerDate[i].uid == e.uid && (0 == e.status ? (a.getChildByName("accepted").active = false, a.getChildByName("waiting").active = true) : 1 == e.status ? (a.getChildByName("accepted").active = true, a.getChildByName("accepted").getComponent(Sprite).spriteFrame = this.replace_img[0], a.getChildByName("waiting").active = false) : 2 == e.status && (a.getChildByName("accepted").active = true, a.getChildByName("accepted").getComponent(Sprite).spriteFrame = this.replace_img[1], a.getChildByName("waiting").active = false), e.uid == User.shared().data.uid && 0 != e.status && (this.isSelected = true, this.bgView.getChildByName("no_btn").active = false, this.bgView.getChildByName("yes_btn").active = false));
        }
    }
    handler_server_end_game_request(e, t) {
        let i = { cmd: RummyCmd.GM_END_GAME_REQUEST, uid: User.shared().data.uid, tid_key: this.tid_key, status: e, close: t || 0 };
        Server.shared().send(i);
    }
    touchBtnEvent(e, t) {
        SoundManager.shared().playFx("click");
        "close" == t ? (this.isSelected ? this.handler_server_end_game_request(0, 1) : this.handler_server_end_game_request(2, 1), ToolUtils.isObjValid(this.node) && this.node.destroy()) : "btn1" == t ? this.handler_server_end_game_request(2) : "btn2" == t && this.handler_server_end_game_request(1);
    }
    onBackView() {
    }
}
