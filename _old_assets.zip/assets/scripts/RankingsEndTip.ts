// @ts-nocheck
// Recovered from index.js:363
import { _decorator, Label, Node, sp, sys, v3 } from "cc";
import BaseLayer from "./BaseLayer";
import SoundManager from "./SoundManager";
import Utils from "./Utils";
import PushCenter from "./PushCenter";
import PushEvent from "./PushEvent";
import User from "./User";
import TweenTool from "./TweenTool";
import GameConfig from "./GameConfig";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("RankingsEndTip")
export class RankingsEndTip extends BaseLayer {
    public TAG: string = "RankingsEndTip";
    @property(Node)
    public rootNode_noReward: Node = null;
    @property(Node)
    public rootNode_reward: Node = null;
    public isNext: boolean = false;
    public _data: any = null;
    @property(Node)
    public animNode: Node = null;
    initParaData(t) {
        sys.isObjectValid(t) && (this._data = t, sys.isObjectValid(t.isNext) && (this.isNext = t.isNext));
    }
    onLoad() {
    }
    start() {
        super.start();
        ToolUtils.showFullScreen(this.node.getChildByName("mask"));
        this.refreshView();
    }
    refreshView() {
        sys.isObjectValid(this._data.has_reward) && (1 == this._data.has_reward ? (this.rootNode_reward.active = true, sys.isObjectValid(this._data.rank) && (this.rootNode_reward.getChildByName("rankNo").getComponent(Label).string = "" + this._data.rank), sys.isObjectValid(this._data.reward) && (this.rootNode_reward.getChildByName("reward_no").getComponent(Label).string = "" + this._data.reward), sys.isObjectValid(this._data.tips) && (this.rootNode_reward.getChildByName("tip2").getComponent(Label).string = "" + this._data.tips), this.animNode.active = true, this.animNode.setPosition(v3(0, 70)), this.animNode.getComponent(sp.Skeleton).clearTracks(), this.animNode.getComponent(sp.Skeleton).setToSetupPose(), this.animNode.getComponent(sp.Skeleton).setSkin("congratulation"), this.animNode.getComponent(sp.Skeleton).setAnimation(0, "hall", false)) : (this.rootNode_noReward.active = true, sys.isObjectValid(this._data.rank) && (this.rootNode_noReward.getChildByName("rankNo").getComponent(Label).string = "" + this._data.rank), sys.isObjectValid(this._data.tips) && (this.rootNode_noReward.getChildByName("tip2").getComponent(Label).string = "" + this._data.tips), sys.isObjectValid(this._data.distance_reward_rank) && (this.rootNode_noReward.getChildByName("spots").getComponent(Label).string = "" + this._data.distance_reward_rank), this.startShowAnim(this.rootNode_noReward)));
    }
    onButtonClick(t, e) {
        SoundManager.shared().playFx("click");
        "close" == e ? this.onBackView() : "details" == e ? (0 == GameConfig.GAME_HALL_THEME ? PushCenter.shared().pushEvent(GameConfig.Jump_Hall_Tab_View, "1") : PushCenter.shared().pushEvent(PushEvent.Show_Challenge), this.onBackView()) : "playnow" == e && (this.dealPlayerLogic(), this.onBackView());
    }
    dealPlayerLogic() {
        User.shared().poplist = [];
        PushCenter.shared().pushEvent(PushEvent.FastStartGame);
    }
    onDestroy() {
        super.onDestroy();
        TweenTool.stopNodeAction(this.node);
        PushCenter.shared().removeListenersByTag(this);
        Utils.shared().hideLoading();
    }
    onBackView() {
        ToolUtils.isObjValid(this.node) && (this.isNext && PushCenter.shared().pushEvent(PushEvent.Update_NextPopActivity), this.node.destroy());
    }
}
