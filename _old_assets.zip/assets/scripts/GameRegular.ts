// @ts-nocheck
// Recovered from index.js:161
import { _decorator, Label, Node, ScrollView, size, Sprite, UITransform, v3, Vec3, Widget } from "cc";
import SoundManager from "./SoundManager";
import BaseLayer from "./BaseLayer";
import { ToolUtils } from "./ToolUtils";
import { CommonGameType } from "./CommDefine";
const { ccclass, property } = _decorator;
@ccclass("GameRegular")
export default class GameRegular extends BaseLayer {
    public lastNodeName: string = "";
    @property(Node)
    public bg: Node = null;
    @property(Node)
    public pageView: Node = null;
    @property(Node)
    public rule_sp: Node = null;
    @property(Node)
    public rule_wz: Node = null;
    public _nGameType: any = CommonGameType.Rummy;
    onLoad() {
        this.lastNodeName = "point";
    }
    start() {
        super.start();
        ToolUtils.showFullScreen(this.node.getChildByName("bg_color"));
        this.startShowAnim(this.bg);
    }
    showByData(e, t, i) {
        this.pageView.getComponent(ScrollView).stopAutoScroll();
        this.pageView.getComponent(ScrollView).scrollToTop();
        i ? (this.rule_sp.active = false, this.rule_wz.active = true, this.rule_wz.getComponent(Label).string = t) : (this.rule_sp.active = true, this.rule_wz.active = false, this.rule_sp.getComponent(Sprite).spriteFrame = e);
    }
    setGameType(e) {
        this._nGameType = e;
    }
    onClickByBtn(e, t) {
        SoundManager.shared().playFx("click");
        "close" == t && ToolUtils.isObjValid(this.node) && this.node.destroy();
    }
    setLandscapeShow() {
        ToolUtils.getOrientation() || this.node.setRotationFromEuler(v3(0, 0, -90));
        let e = this.node.getChildByName("bg_color");
        ToolUtils.showFullScreen(e);
        let t = this.bg.getChildByName("bg").getComponent(UITransform).contentSize;
        if (this.bg.getChildByName("bg").getComponent(UITransform).setContentSize(size(t.width, 609)), this._nGameType == CommonGameType.Rummy) {
            this.bg.getChildByName("bg").setPosition(v3(0, 35));
            let e = new Vec3;
            this.bg.getChildByName("top").getPosition(e);
            this.bg.getChildByName("top").setPosition(v3(e.x, -148, e.z));
        }
        else {
            let e = new Vec3;
            this.bg.getChildByName("top").getPosition(e);
            this.bg.getChildByName("top").setPosition(v3(e.x, -187, e.z));
        }
        let i = this.bg.getChildByName("scrollview");
        if (ToolUtils.getOrientation()) {
            if (this._nGameType == CommonGameType.Rummy) {
                i.setPosition(v3(0, 250.784));
                let e = i.getComponent(UITransform);
                e.setContentSize(size(e.contentSize.width, 510));
                i.getChildByName("view").getComponent(Widget).updateAlignment();
            }
            else {
                i.setPosition(v3(0, 213.784));
                let e = i.getComponent(UITransform);
                e.setContentSize(size(e.contentSize.width, 510));
                i.getChildByName("view").getComponent(Widget).updateAlignment();
            }
        }
        else {
            i.setPosition(v3(0, 403.393));
            let e = i.getComponent(UITransform);
            e.setContentSize(size(e.contentSize.width, 890));
            i.getChildByName("view").getComponent(Widget).updateAlignment();
        }
    }
}
