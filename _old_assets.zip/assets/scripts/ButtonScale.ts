// @ts-nocheck
// Recovered from index.js:55
import { _decorator, Component, Button, lerp, Node, Vec3 } from "cc";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("ButtonScale")
export class ButtonScale extends Component {
    @property({ tooltip: "Is the button Swallow" })
    public swallowable: boolean = false;
    @property({ tooltip: "Is the button scalable" })
    public scaleable: boolean = true;
    @property({ tooltip: "Button Zoom Size" })
    public zoomScale: number = 1.1;
    public duration: number = 0.1;
    public time: number = 0;
    public pressed: boolean = false;
    public fromScale: Vec3 = new Vec3;
    public toScale: Vec3 = new Vec3;
    public originalScale: Vec3 = new Vec3;
    public targetScale: Vec3 = new Vec3;
    public transitionFinished: boolean = true;
    start() {
        Vec3.copy(this.originalScale, this.node.getScale());
    }
    onEnable() {
        this.node.on(Node.EventType.TOUCH_START, this.onTouchBegan, this);
        this.node.on(Node.EventType.TOUCH_MOVE, this.onTouchMove, this);
        this.node.on(Node.EventType.TOUCH_END, this.onTouchEnd, this);
        this.node.on(Node.EventType.TOUCH_CANCEL, this.onTouchCancel, this);
    }
    onDisable() {
        this.node.off(Node.EventType.TOUCH_START, this.onTouchBegan, this);
        this.node.off(Node.EventType.TOUCH_MOVE, this.onTouchMove, this);
        this.node.off(Node.EventType.TOUCH_END, this.onTouchEnd, this);
        this.node.off(Node.EventType.TOUCH_CANCEL, this.onTouchCancel, this);
    }
    update(t) {
        const i = this.node;
        if (this.transitionFinished || !i) {
            return;
        }
        this.time += t;
        let e = 1;
        this.duration > 0 && (e = this.time / this.duration);
        e >= 1 && (e = 1);
        i.getScale(this.targetScale);
        this.targetScale.x = lerp(this.fromScale.x, this.toScale.x, e);
        this.targetScale.y = lerp(this.fromScale.y, this.toScale.y, e);
        i.setScale(this.targetScale);
        1 === e && (this.transitionFinished = true);
    }
    onTouchBegan(t) {
        ToolUtils.isObjValid(this.node) && (this.swallowable && (t.preventSwallow = true), this.pressed = true, this.updateScaleTransition());
    }
    onTouchMove(t) {
        let i = this.node.getComponent(Button);
        if (i && i.interactable && (this.swallowable && (t.preventSwallow = true), this.scaleable && i.transition != Button.Transition.SCALE)) {
            const i = t.touch;
            if (i) {
                this.node._uiProps.uiTransformComp.hitTest(i.getLocation()) ? ToolUtils.isObjValid(this.node) && (Vec3.copy(this.fromScale, this.originalScale), Vec3.multiplyScalar(this.toScale, this.originalScale, this.zoomScale), this.transitionFinished = false) : ToolUtils.isObjValid(this.node) && (this.time = 0, this.transitionFinished = true, this.node.setScale(this.originalScale));
            }
        }
    }
    onTouchEnd(t) {
        ToolUtils.isObjValid(this.node) && (this.swallowable && (t.preventSwallow = true), this.pressed = false, this.updateScaleTransition());
    }
    onTouchCancel(t) {
        ToolUtils.isObjValid(this.node) && (this.swallowable && (t.preventSwallow = true), this.pressed = false, this.updateScaleTransition());
    }
    updateScaleTransition() {
        if (ToolUtils.isObjValid(this.node)) {
            let t = this.node.getComponent(Button);
            t && t.interactable && this.scaleable && t.transition != Button.Transition.SCALE && (this.pressed ? this.zoomUp() : this.zoomBack());
        }
    }
    zoomUp() {
        this.originalScale && (Vec3.copy(this.fromScale, this.originalScale), Vec3.multiplyScalar(this.toScale, this.originalScale, this.zoomScale), this.time = 0, this.transitionFinished = false);
    }
    zoomBack() {
        this.node && this.originalScale && (Vec3.copy(this.fromScale, this.node.getScale()), Vec3.copy(this.toScale, this.originalScale), this.time = 0, this.transitionFinished = false);
    }
}
