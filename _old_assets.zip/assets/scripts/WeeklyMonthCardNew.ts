// @ts-nocheck
// Recovered from index.js:675
import { _decorator, Button, Label, Node, sp, sys } from "cc";
import BaseLayer from "./BaseLayer";
import SoundManager from "./SoundManager";
import PushCenter from "./PushCenter";
import PushEvent from "./PushEvent";
import User from "./User";
import Utils from "./Utils";
import { TLog } from "./TLog";
import i18nMgr from "./i18nMgr";
import HttpManager from "./HttpManager";
import ReportConfig from "./ReportConfig";
import GameConfig from "./GameConfig";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("WeeklyMonthCardNew")
export class WeeklyMonthCardNew extends BaseLayer {
    public TAG: string = "WeeklyMonthCardNew";
    @property(Node)
    public cardNode: Node = null;
    @property(Node)
    public ruleNode: Node = null;
    @property(Label)
    public ruleLabel: Label = null;
    public _total_getDays: any[] = ["3", "7", "14"];
    public _login_rewardDays: any[] = [3, 5, 5];
    public _login_perccent0: any[] = [0, 0.2, 0.5, 1];
    public _login_perccent1: any[] = [0, 0.1, 0.3, 0.55, 0.8, 1];
    public weekmonthData: any = null;
    public weekmonthData_md5: any = null;
    public ruleData: any = null;
    public isNext: boolean = false;
    public isquick: boolean = false;
    public _lastClick: number = 0;
    public curTab: number = 0;
    public _nVid: number = 0;
    public _linkId: number = 0;
    public _reportScene: any = -1;
    public _pop_souce: number = 0;
    public _has_close: boolean = false;
    public _cardArray: any[] = [];
    public _flashAnimIndex: number = 0;
    public lastClick: number = 0;
    public checkKyc: number = 0;
    onLoad() {
    }
    start() {
        super.start();
        this._linkId = this._linkId > 0 ? this._linkId : sys.now();
        this._reportScene = this._reportScene >= 0 ? this._reportScene : ToolUtils.getIsInRoom() ? 2 : 1;
        this.ruleNode.active = false;
        ToolUtils.showFullScreen(this.node.getChildByName("mask"));
        ToolUtils.showFullScreen(this.ruleNode.getChildByName("mask"));
        PushCenter.shared().addListener(PushEvent.updataWeekMonth, (() => {
            ToolUtils.isObjValid(this.node) && HttpManager.shared().doGetCommonRequest({ open_act: 1 }, "Activity.Act_104.page", this.listenGetWeekMonthInfoCallBack.bind(this));
        }), this);
        PushCenter.shared().addListener(GameConfig.Recharge, (() => {
            ToolUtils.isObjValid(this.node) && HttpManager.shared().doGetCommonRequest({ open_act: 1 }, "Activity.Act_104.page", this.listenGetWeekMonthInfoCallBack.bind(this));
        }), this);
        let e = this.cardNode.getChildByName("anim").getComponent(sp.Skeleton);
        e.clearTracks();
        e.setToSetupPose();
        e.setAnimation(0, "title", false);
        this.startShowAnim(this.cardNode);
        SoundManager.shared().playFx("act_popshow");
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().removeListenersByTag(this);
    }
    listenGetWeekMonthInfoCallBack(e, t, i) {
        if (Utils.shared().hideLoading(), 200 != i) {
            alert("The login timed out, please try again");
        }
        else {
            try {
                let e = ToolUtils.parseJson(t);
                if (0 == e.ret && ToolUtils.isObjValid(this.node)) {
                    let t = !sys.isObjectValid(User.shared().weekmonthData);
                    User.shared().weekmonthData = e.data;
                    ToolUtils.saveData("weekmonth_data" + String(User.shared().data.uid), ToolUtils.toJsonString(User.shared().weekmonthData));
                    let i = true;
                    if (sys.isObjectValid(this.weekmonthData_md5)) {
                        let t = ToolUtils.jsonToMd5(e.data);
                        this.weekmonthData_md5 == t && (i = false);
                    }
                    if (this.weekmonthData = e.data, !sys.isObjectValid(this.weekmonthData)) {
                        return void this.onBackView();
                    }
                    i && this.showCardNodeView(t);
                }
            }
            catch (e) {
                TLog.printError("listengetLotteryInfoCallBack:", e.toString());
            }
        }
    }
    initParaData(e) {
        if (ToolUtils.isObjValid(this.node)) {
            if (sys.isObjectValid(e) && (this.isNext = e.isNext, sys.isObjectValid(e.isquick) && (this.isquick = e.isquick), sys.isObjectValid(e.checkKyc) && (this.checkKyc = e.checkKyc), sys.isObjectValid(e) && sys.isObjectValid(e.reportScene) && (this._reportScene = e.reportScene), sys.isObjectValid(e) && sys.isObjectValid(e.link_id) && e.link_id > 0 && (this._linkId = e.link_id)), sys.isObjectValid(e) && sys.isObjectValid(e.pop_souce) && (this._pop_souce = e.pop_souce), sys.isObjectValid(e) && sys.isObjectValid(e.vid) ? this._nVid = e.vid : this._nVid = ToolUtils.curRoomId, this.weekmonthData = User.shared().weekmonthData, sys.isObjectValid(this.weekmonthData)) {
                this.showCardNodeView(true);
            }
            else {
                let e = ToolUtils.isSafeString(sys.localStorage.getItem("weekmonth_data" + String(User.shared().data.uid)));
                sys.isObjectValid(e) && e.length > 0 && (this.weekmonthData = ToolUtils.parseJson(e), this.showCardNodeView(true));
            }
            sys.isObjectValid(this.weekmonthData) || Utils.shared().showLoading(10, true, (() => {
                Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
            }));
            HttpManager.shared().doGetCommonRequest({ open_act: 1 }, "Activity.Act_104.page", this.listenGetWeekMonthInfoCallBack.bind(this));
        }
    }
    showCardNodeView(e = true) {
        if (ToolUtils.isObjValid(this.cardNode)) {
            this.weekmonthData_md5 = ToolUtils.jsonToMd5(this.weekmonthData);
            this.cardNode.active = true;
            sys.isObjectValid(this.weekmonthData) && sys.isObjectValid(this.weekmonthData.title_tip) && (this.cardNode.getChildByName("tips").getComponent(Label).string = this.weekmonthData.title_tip);
            for (let e = 0; e < 3; e++) {
                this.initWeekMonthCard(this.cardNode.getChildByName("card" + e), e);
            }
            sys.isObjectValid(this.weekmonthData.pop_reward) && Array.isArray(this.weekmonthData.pop_reward) && this.weekmonthData.pop_reward.length > 0 && User.shared().showChargeReward(this.weekmonthData.pop_reward);
        }
        else {
            TLog.printError("showCardNodeView error");
        }
    }
    initWeekMonthCard(e, t) {
        let i = this.weekmonthData.cards[t];
        sys.isObjectValid(i.total_amt) && String(i.total_amt).length > 0 && (e.getChildByName("total_get").getComponent(Label).string = ToolUtils.format("₹${0}*", i.total_amt));
        sys.isObjectValid(i.amt) && String(i.amt).length > 0 && (e.getChildByName("buy_btn").getChildByName("amt").getComponent(Label).string = ToolUtils.format("₹${0}", i.amt));
        sys.isObjectValid(i.rate) && String(i.rate).length > 0 && (e.getChildByName("buy_btn").getChildByName("zhekou_layout").getChildByName("zhekou").getComponent(Label).string = "" + i.rate, e.getChildByName("buy_btn").getChildByName("zhekou_layout").active = true, e.getChildByName("buy_btn").getChildByName("flag").active = true);
        e.getChildByName("buy_btn").getComponent(Button).clickEvents[0].customEventData = i;
        let a = "";
        if (sys.isObjectValid(i.daily_cash) && String(i.loginreward_cash).length > 0 && 0 != Number(i.loginreward_cash) && (a = ToolUtils.format(i18nMgr.shared().getValueByKey("weekmonth.login_tip1"), i.loginreward_cash)), sys.isObjectValid(i.loginreward_bonus) && String(i.loginreward_bonus).length > 0 && 0 != Number(i.loginreward_bonus)) {
            let e = ToolUtils.format(i18nMgr.shared().getValueByKey("weekmonth.login_tip2"), i.loginreward_bonus);
            a = a.length > 0 ? a + " & " + e : e;
        }
        sys.isObjectValid(i.daily_cash) && String(i.daily_cash).length > 0 && 0 != Number(i.daily_cash) ? (e.getChildByName("login_reward_root").getChildByName("item0").getChildByName("num").getComponent(Label).string = "₹" + String(i.daily_cash), e.getChildByName("login_reward_root").getChildByName("item0").active = true) : e.getChildByName("login_reward_root").getChildByName("item0").active = false;
        sys.isObjectValid(i.daily_bonus) && String(i.daily_bonus).length > 0 && 0 != Number(i.daily_bonus) ? (e.getChildByName("login_reward_root").getChildByName("item1").getChildByName("num").getComponent(Label).string = "₹" + String(i.daily_bonus), e.getChildByName("login_reward_root").getChildByName("item1").active = true) : e.getChildByName("login_reward_root").getChildByName("item1").active = false;
        sys.isObjectValid(i.status) && 0 != Number(i.status) ? Number(i.leftday) <= 1 ? e.getChildByName("valid_tip").getComponent(Label).string = `Validity:${String(i.leftday)} Day` : e.getChildByName("valid_tip").getComponent(Label).string = `Validity:${String(i.leftday)} Days` : e.getChildByName("valid_tip").getComponent(Label).string = "";
        this.updateCardReward(e.getChildByName("reward_root"), i);
    }
    updateCardReward(e, t) {
        let i = false, a = false;
        sys.isObjectValid(t.get_cash) && String(t.get_cash).length > 0 && 0 != Number(t.get_cash) && (i = true);
        sys.isObjectValid(t.get_bonus) && String(t.get_bonus).length > 0 && 0 != Number(t.get_bonus) && (a = true);
        a && i ? (e.getChildByName("item0").getChildByName("num").getComponent(Label).string = "₹" + String(t.get_cash), e.getChildByName("item1").getChildByName("num").getComponent(Label).string = "₹" + String(t.get_bonus), e.getChildByName("item0").active = true, e.getChildByName("item1").active = true) : a ? (e.getChildByName("item1").getChildByName("num").getComponent(Label).string = "₹" + String(t.get_bonus), e.getChildByName("item1").active = true, e.getChildByName("item0").active = false) : (e.getChildByName("item0").getChildByName("num").getComponent(Label).string = "₹" + String(t.get_cash), e.getChildByName("item0").active = true, e.getChildByName("item1").active = false);
    }
    showRuleView() {
        sys.isObjectValid(this.ruleNode) && (this.ruleNode.active = true, this.ruleLabel.string = this.ruleData.tips, i18nMgr.shared().changeLabelFont(this.ruleLabel), this.startShowAnim(this.ruleNode.getChildByName("bg")));
    }
    onButtonClick(e, t) {
        if (SoundManager.shared().playFx("click"), "close" == t) {
            1 == this.checkKyc && Utils.shared().checkAddCashKyc();
            this.onBackView();
        }
        else if ("rule" == t) {
            if (sys.now() - this.lastClick < 1000) {
                return;
            }
            this.lastClick = sys.now();
            sys.isObjectValid(this.ruleData) ? this.showRuleView() : HttpManager.shared().doGetCommonRequest(null, "Activity.Act_104.tips", ((e, t, i) => {
                if (200 != i) {
                    alert("The login timed out, please try again");
                }
                else {
                    try {
                        let e = ToolUtils.parseJson(t);
                        0 == e.ret && (this.ruleData = e.data, ToolUtils.isObjValid(this.node) && this.showRuleView());
                    }
                    catch (e) {
                        TLog.printError("listengetRuleCallBack:", e.toString());
                    }
                }
            }));
        }
    }
    onBuyClick(e, t) {
        if (SoundManager.shared().playFx("click"), User.shared().checkCanRecharge()) {
            if (!(sys.now() - this._lastClick < 500) && (this._lastClick = sys.now(), sys.isObjectValid(t))) {
                HttpManager.shared().doCommReportRechargeEvent(ReportConfig.Cmd_WeekMonth, this._reportScene, 5, this._linkId, "", this._nVid);
                let e = { pway: this.weekmonthData.pways + "", price: Number(t.amt), card: t.card_id, act_id: PushEvent.JUMP_TO_WEEK_MONTH, link_id: this._linkId, goodsId: t.gid };
                User.shared().startPay(e);
            }
        }
        else {
            ToolUtils.isObjValid(this.node) && this.node.destroy();
        }
    }
    onBackView() {
        if (ToolUtils.isObjValid(this.node)) {
            if (Utils.shared().hideLoading(), ToolUtils.isObjValid(this.ruleNode) && this.ruleNode.active) {
                this.ruleNode.active = false;
            }
            else {
                if (this._has_close) {
                    return;
                }
                this._has_close = true;
                let e = { alert_node: this.node, rootNode: this.node.getChildByName("rootNode"), isNext: this.isNext, pop_type: PushEvent.JUMP_TO_WEEK_MONTH, pop_souce: this._pop_souce };
                Utils.shared().closeActivityView(e);
                User.shared().getHallInfo();
                Utils.shared().hideToast();
            }
        }
    }
}
