// @ts-nocheck
// Recovered from index.js:549
import { _decorator, Button, color, instantiate, Label, Node, ScrollView, size, sp, Sprite, SpriteFrame, sys, UITransform, v3, view, Widget } from "cc";
import SoundManager from "./SoundManager";
import PushCenter from "./PushCenter";
import { TLog } from "./TLog";
import Utils from "./Utils";
import User from "./User";
import i18nMgr from "./i18nMgr";
import BaseLayer from "./BaseLayer";
import GameConfig from "./GameConfig";
import PushEvent from "./PushEvent";
import TweenTool from "./TweenTool";
import { ToolUtils } from "./ToolUtils";
import SportCricket_Manager from "./SportCricket_Manager";
import BundleNameDefined from "./BundleNameDefined";
import PhpReportDefined from "./PhpReportDefined";
const { ccclass, property } = _decorator;
@ccclass("SportCricket_CreateTeam")
export class SportCricket_CreateTeam extends BaseLayer {
    public TAG: string = "SportCricket_CreateTeam";
    @property(Node)
    public rootNode: Node = null;
    @property(Node)
    public goldNode: Node = null;
    @property(Node)
    public teamTopNode: Node = null;
    public tabNode: any = null;
    @property(Node)
    public nextNode: Node = null;
    @property(Node)
    public detailsNode: Node = null;
    @property(Node)
    public bottomNode: Node = null;
    @property(Node)
    public contentNode: Node = null;
    @property([SpriteFrame])
    public teamBgImgs: SpriteFrame[] = [];
    @property([SpriteFrame])
    public btnBgImgs: SpriteFrame[] = [];
    @property([SpriteFrame])
    public styleImgs: SpriteFrame[] = [];
    @property([SpriteFrame])
    public sortArrowImgs: SpriteFrame[] = [];
    @property([SpriteFrame])
    public progressImgs: SpriteFrame[] = [];
    @property([SpriteFrame])
    public operateImgs: SpriteFrame[] = [];
    public leader_listData: any[] = [];
    @property(Node)
    public team_mobanView: Node = null;
    @property(Node)
    public fast_scrollView: Node = null;
    @property(Node)
    public fastManger: Node = null;
    public _closed: boolean = false;
    public bShowPushAnim: boolean = true;
    public _lastClick: number = 0;
    public _sourceData: any = null;
    public _itemArr: any[] = [];
    public _isSendMsg: boolean = false;
    public curTab: number = 0;
    public tabWzColor: any[] = [color(147, 11, 11), color(102, 102, 102)];
    public taskAwardIconMap: Map = new Map;
    public _match_id: number = 0;
    public _contest_id: number = 0;
    public _contest_source: any = null;
    public _player_source: any = null;
    public _team_id: number = 0;
    public _source: any = null;
    public _fromType: number = 0;
    public lastClick: number = 0;
    public _creditsLeft: number = 100;
    public _teamAPlayerNum: number = 0;
    public _teamBPlayerNum: number = 0;
    public _selectPlayerNum: number = 0;
    public _teamSortType: number = 1;
    public _pointsSortType: number = 1;
    public _creditsSortType: number = 1;
    public _rateSortType: number = 1;
    public _curSortType: number = 1;
    public _selectPlayerIds: any[] = [];
    public _wkSelectNum: number = 0;
    public _batSelectNum: number = 0;
    public _arSelectNum: number = 0;
    public _bowlSelectNum: number = 0;
    public _allPlayerMsg: Map = new Map;
    public _allPlayerView: any[] = [];
    public _backupPlayers: any[] = [];
    public notLineUpPlayers: any[] = [];
    public playerViewMap: Map = new Map;
    public _match_state: number = 1;
    public _lastNode: any = null;
    public _lineup: number = 0;
    public _join_last_match: number = 0;
    public _call: any = null;
    public _is_chip: number = 0;
    public _hasLoadSubView: boolean = false;
    public sort_select_color: any = color(183, 0, 0);
    public _hasFastTab: boolean = false;
    public _hasForceSignMatch: number = 0;
    onLoad() {
        PushCenter.shared().addListener(GameConfig.Update_Money, (e => {
            try {
                ToolUtils.isObjValid(this.node) && this.updateGold(e);
            }
            catch (e) {
                TLog.printError(this.TAG, GameConfig.Update_Money, e);
            }
        }), this);
        PushCenter.shared().addListener(PushEvent.CloseYes11CreateTeam, (e => {
            try {
                ToolUtils.isObjValid(this.node) && (ToolUtils.isObjValid(this._lastNode) && (this._lastNode.active = true), sys.isObjectValid(e) && sys.isObjectValid(e.team_id) && sys.isObjectValid(e.lineUpNum) && this._call && this._call(e), this.node.destroy());
            }
            catch (e) {
                TLog.printError(this.TAG, PushEvent.CloseYes11CreateTeam, e);
            }
        }), this);
        PushCenter.shared().addListener(PushEvent.commentDownloaderImg, (e => {
            try {
                if (ToolUtils.isObjValid(this.node) && this.taskAwardIconMap.size > 0) {
                    for (const [t, s] of this.taskAwardIconMap) {
                        s == e && sys.isObjectValid(t) && ("player_icon" == t.name ? Utils.shared().updateNetImage(t, e, size(110, 110)) : Utils.shared().updateNetImage(t, e, size(76, 76)));
                    }
                }
            }
            catch (e) {
                TLog.printError(this.TAG, PushEvent.commentDownloaderImg, e);
            }
        }), this);
        this.fitLuckyTheme();
    }
    fitLuckyTheme() {
        if (0 == GameConfig.NATIVE_GAME_APP_TYPE) {
            return;
        }
        this.sort_select_color = color(38, 59, 152);
        this.tabWzColor = [color(221, 3, 3), color(102, 102, 102)];
        this.rootNode.getChildByName("top_node").getChildByName("top_bg").getComponent(Sprite).color = color(12, 26, 60, 255);
        this.rootNode.getChildByName("details").getChildByName("bg").getComponent(Sprite).color = color(12, 26, 60, 255);
        this.rootNode.getChildByName("details").getChildByName("lefttime_tip").getComponent(Label).color = color(153, 164, 221, 255);
        this.rootNode.getChildByName("details").getChildByName("title").getComponent(Label).color = color(153, 164, 221, 255);
        this.goldNode.getChildByName("coin").getComponent(Label).color = color(251, 220, 0, 255);
        let e = this.rootNode.getChildByName("select_diban_fast"), t = this.rootNode.getChildByName("select_diban");
        for (let s = 0; s < 4; s++) {
            ToolUtils.isObjValid(t.getChildByName("tab" + s)) && (t.getChildByName("tab" + s).getChildByName("line").getComponent(Sprite).color = this.tabWzColor[0]);
            ToolUtils.isObjValid(e.getChildByName("tab" + s)) && (e.getChildByName("tab" + s).getChildByName("line").getComponent(Sprite).color = this.tabWzColor[0]);
        }
        t.getChildByName("bg").getComponent(Sprite).color = color(250, 250, 250, 255);
        e.getChildByName("bg").getComponent(Sprite).color = color(250, 250, 250, 255);
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().removeListenersByTag(this);
        this.unscheduleAllCallbacks();
    }
    init(e) {
        sys.isObjectValid(e) && sys.isObjectValid(e.match_id) && (this._match_id = e.match_id);
        sys.isObjectValid(e) && sys.isObjectValid(e.player_source) && (this._player_source = e.player_source, sys.isObjectValid(this._player_source.force) && 1 == this._player_source.force && (this._hasForceSignMatch = this._player_source.force));
        sys.isObjectValid(e) && sys.isObjectValid(e.source) && (this._source = { ...e.source });
        sys.isObjectValid(e) && sys.isObjectValid(e.fromType) && (this._fromType = e.fromType);
        sys.isObjectValid(e) && sys.isObjectValid(e.contest_id) && (this._contest_id = e.contest_id);
        sys.isObjectValid(e) && sys.isObjectValid(e.team_id) && (this._team_id = e.team_id);
        sys.isObjectValid(e) && sys.isObjectValid(e.lastNode) && (this._lastNode = e.lastNode);
        sys.isObjectValid(e) && sys.isObjectValid(e.call) && (this._call = e.call);
        sys.isObjectValid(e) && sys.isObjectValid(e.is_chip) && (this._is_chip = e.is_chip);
    }
    start() {
        super.start();
        this.initView();
        this.bShowPushAnim ? ToolUtils.showPushAnim(this.node, 0, (() => {
            ToolUtils.isObjValid(this._lastNode) && (this._lastNode.active = false);
            this.refreshView();
        })) : this.refreshView();
        this.updateGold(User.shared().data.money);
    }
    updateSortView() {
        try {
            0 == this._curSortType ? (this.teamTopNode.getChildByName("team_sort").getChildByName("wz").getComponent(Label).color = this.sort_select_color, this.teamTopNode.getChildByName("team_sort").getChildByName("arrow").getComponent(Sprite).color = color(255, 255, 255), 1 == this._teamSortType ? this.teamTopNode.getChildByName("team_sort").getChildByName("arrow").getComponent(Sprite).spriteFrame = this.sortArrowImgs[2] : this.teamTopNode.getChildByName("team_sort").getChildByName("arrow").getComponent(Sprite).spriteFrame = this.sortArrowImgs[1], this.teamTopNode.getChildByName("point_sort").getChildByName("wz").getComponent(Label).color = color(102, 102, 102), this.teamTopNode.getChildByName("point_sort").getChildByName("arrow").getComponent(Sprite).color = color(102, 102, 102), this.teamTopNode.getChildByName("point_sort").getChildByName("arrow").getComponent(Sprite).spriteFrame = this.sortArrowImgs[0], this.teamTopNode.getChildByName("credits_sort").getChildByName("wz").getComponent(Label).color = color(102, 102, 102), this.teamTopNode.getChildByName("credits_sort").getChildByName("arrow").getComponent(Sprite).color = color(102, 102, 102), this.teamTopNode.getChildByName("credits_sort").getChildByName("arrow").getComponent(Sprite).spriteFrame = this.sortArrowImgs[0], this.teamTopNode.getChildByName("sel_sort").getChildByName("wz").getComponent(Label).color = color(102, 102, 102), this.teamTopNode.getChildByName("sel_sort").getChildByName("arrow").getComponent(Sprite).color = color(102, 102, 102), this.teamTopNode.getChildByName("sel_sort").getChildByName("arrow").getComponent(Sprite).spriteFrame = this.sortArrowImgs[0]) : 1 == this._curSortType ? (this.teamTopNode.getChildByName("point_sort").getChildByName("wz").getComponent(Label).color = this.sort_select_color, this.teamTopNode.getChildByName("point_sort").getChildByName("arrow").getComponent(Sprite).color = color(255, 255, 255), 1 == this._pointsSortType ? this.teamTopNode.getChildByName("point_sort").getChildByName("arrow").getComponent(Sprite).spriteFrame = this.sortArrowImgs[2] : this.teamTopNode.getChildByName("point_sort").getChildByName("arrow").getComponent(Sprite).spriteFrame = this.sortArrowImgs[1], this.teamTopNode.getChildByName("team_sort").getChildByName("wz").getComponent(Label).color = color(102, 102, 102), this.teamTopNode.getChildByName("team_sort").getChildByName("arrow").getComponent(Sprite).color = color(102, 102, 102), this.teamTopNode.getChildByName("team_sort").getChildByName("arrow").getComponent(Sprite).spriteFrame = this.sortArrowImgs[0], this.teamTopNode.getChildByName("credits_sort").getChildByName("wz").getComponent(Label).color = color(102, 102, 102), this.teamTopNode.getChildByName("credits_sort").getChildByName("arrow").getComponent(Sprite).color = color(102, 102, 102), this.teamTopNode.getChildByName("credits_sort").getChildByName("arrow").getComponent(Sprite).spriteFrame = this.sortArrowImgs[0], this.teamTopNode.getChildByName("sel_sort").getChildByName("wz").getComponent(Label).color = color(102, 102, 102), this.teamTopNode.getChildByName("sel_sort").getChildByName("arrow").getComponent(Sprite).color = color(102, 102, 102), this.teamTopNode.getChildByName("sel_sort").getChildByName("arrow").getComponent(Sprite).spriteFrame = this.sortArrowImgs[0]) : 2 == this._curSortType ? (this.teamTopNode.getChildByName("credits_sort").getChildByName("wz").getComponent(Label).color = this.sort_select_color, this.teamTopNode.getChildByName("credits_sort").getChildByName("arrow").getComponent(Sprite).color = color(255, 255, 255), 1 == this._creditsSortType ? this.teamTopNode.getChildByName("credits_sort").getChildByName("arrow").getComponent(Sprite).spriteFrame = this.sortArrowImgs[2] : this.teamTopNode.getChildByName("credits_sort").getChildByName("arrow").getComponent(Sprite).spriteFrame = this.sortArrowImgs[1], this.teamTopNode.getChildByName("team_sort").getChildByName("wz").getComponent(Label).color = color(102, 102, 102), this.teamTopNode.getChildByName("team_sort").getChildByName("arrow").getComponent(Sprite).color = color(102, 102, 102), this.teamTopNode.getChildByName("team_sort").getChildByName("arrow").getComponent(Sprite).spriteFrame = this.sortArrowImgs[0], this.teamTopNode.getChildByName("point_sort").getChildByName("wz").getComponent(Label).color = color(102, 102, 102), this.teamTopNode.getChildByName("point_sort").getChildByName("arrow").getComponent(Sprite).color = color(102, 102, 102), this.teamTopNode.getChildByName("point_sort").getChildByName("arrow").getComponent(Sprite).spriteFrame = this.sortArrowImgs[0], this.teamTopNode.getChildByName("sel_sort").getChildByName("wz").getComponent(Label).color = color(102, 102, 102), this.teamTopNode.getChildByName("sel_sort").getChildByName("arrow").getComponent(Sprite).color = color(102, 102, 102), this.teamTopNode.getChildByName("sel_sort").getChildByName("arrow").getComponent(Sprite).spriteFrame = this.sortArrowImgs[0]) : 3 == this._curSortType && (this.teamTopNode.getChildByName("sel_sort").getChildByName("wz").getComponent(Label).color = this.sort_select_color, this.teamTopNode.getChildByName("sel_sort").getChildByName("arrow").getComponent(Sprite).color = color(255, 255, 255), 1 == this._rateSortType ? this.teamTopNode.getChildByName("sel_sort").getChildByName("arrow").getComponent(Sprite).spriteFrame = this.sortArrowImgs[2] : this.teamTopNode.getChildByName("sel_sort").getChildByName("arrow").getComponent(Sprite).spriteFrame = this.sortArrowImgs[1], this.teamTopNode.getChildByName("team_sort").getChildByName("wz").getComponent(Label).color = color(102, 102, 102), this.teamTopNode.getChildByName("team_sort").getChildByName("arrow").getComponent(Sprite).color = color(102, 102, 102), this.teamTopNode.getChildByName("team_sort").getChildByName("arrow").getComponent(Sprite).spriteFrame = this.sortArrowImgs[0], this.teamTopNode.getChildByName("point_sort").getChildByName("wz").getComponent(Label).color = color(102, 102, 102), this.teamTopNode.getChildByName("point_sort").getChildByName("arrow").getComponent(Sprite).color = color(102, 102, 102), this.teamTopNode.getChildByName("point_sort").getChildByName("arrow").getComponent(Sprite).spriteFrame = this.sortArrowImgs[0], this.teamTopNode.getChildByName("credits_sort").getChildByName("wz").getComponent(Label).color = color(102, 102, 102), this.teamTopNode.getChildByName("credits_sort").getChildByName("arrow").getComponent(Sprite).color = color(102, 102, 102), this.teamTopNode.getChildByName("credits_sort").getChildByName("arrow").getComponent(Sprite).spriteFrame = this.sortArrowImgs[0]);
        }
        catch (e) {
            TLog.printError(this.TAG, "updateSortView:", e);
        }
    }
    updateTabView(e = true) {
        let t = this._hasFastTab ? 5 : 4, s = [];
        for (let e = 0; e < t; e++) {
            this.tabNode.getChildByName("tab" + e).getChildByName("di").active = false;
            this.tabNode.getChildByName("tab" + e).getChildByName("line").active = this.curTab == e;
            this.curTab == e ? this.tabNode.getChildByName("tab" + e).getChildByName("Label").getComponent(Label).color = this.tabWzColor[0] : this.tabNode.getChildByName("tab" + e).getChildByName("Label").getComponent(Label).color = this.tabWzColor[1];
            i18nMgr.shared().changeLabelFont(this.tabNode.getChildByName("tab" + e).getChildByName("Label").getComponent(Label), this.curTab == e);
            s.push(this.tabNode.getChildByName("tab" + e).getChildByName("line"));
        }
        if (4 == this.curTab ? this.bottomNode.getChildByName("tip").getComponent(Label).string = "Pick 11 Players" : this.bottomNode.getChildByName("tip").getComponent(Label).string = i18nMgr.shared().getValueByKey("yes11.create_role_tip" + this.curTab), e) {
            for (let e = 0; e < t; e++) {
                if (this.curTab == e) {
                    s[e].scale = v3(0, 1, 1);
                    let t = TweenTool.scaleTo(s[e], 0.16, v3(1.1, 1, 1), null, false), i = TweenTool.scaleTo(s[e], 0.16, v3(1, 1, 1), null, false);
                    TweenTool.sequence(s[e], true, null, t, i);
                }
                else {
                    s[e].scale = v3(1, 1, 1);
                }
            }
        }
    }
    filterSelectPlayer() {
        if (this._selectPlayerIds = [], this._allPlayerMsg.clear(), this._backupPlayers = [], this._creditsLeft = 100, this._teamAPlayerNum = 0, this._teamBPlayerNum = 0, this._wkSelectNum = 0, this._batSelectNum = 0, this._arSelectNum = 0, this._bowlSelectNum = 0, sys.isObjectValid(this._player_source)) {
            if (sys.isObjectValid(this._player_source.credits) && (this._creditsLeft = this._player_source.credits), sys.isObjectValid(this._player_source.wk) && this._player_source.wk.length > 0) {
                for (let e = 0; e < this._player_source.wk.length; e++) {
                    1 == this._player_source.wk[e].playing11 && (this._lineup = 1);
                    1 == this._player_source.wk[e].join_last_match && (this._join_last_match = 1);
                    this._player_source.wk[e].role = "WK";
                    this._allPlayerMsg.set(this._player_source.wk[e].player_id, this._player_source.wk[e]);
                    1 == this._player_source.wk[e].select_status && (this._selectPlayerIds.push(this._player_source.wk[e].player_id), this._creditsLeft -= this._player_source.wk[e].credits, this._wkSelectNum += 1, this._player_source.wk[e].team_id == this._player_source.teama.tid ? this._teamAPlayerNum += 1 : this._teamBPlayerNum += 1);
                    sys.isObjectValid(this._player_source.wk[e].backup) && this._player_source.wk[e].backup > 0 && this._backupPlayers.push(this._player_source.wk[e]);
                }
            }
            if (sys.isObjectValid(this._player_source.bat) && this._player_source.bat.length > 0) {
                for (let e = 0; e < this._player_source.bat.length; e++) {
                    1 == this._player_source.bat[e].playing11 && (this._lineup = 1);
                    1 == this._player_source.bat[e].join_last_match && (this._join_last_match = 1);
                    this._player_source.bat[e].role = "BAT";
                    this._allPlayerMsg.set(this._player_source.bat[e].player_id, this._player_source.bat[e]);
                    1 == this._player_source.bat[e].select_status && (this._selectPlayerIds.push(this._player_source.bat[e].player_id), this._creditsLeft -= this._player_source.bat[e].credits, this._batSelectNum += 1, this._player_source.bat[e].team_id == this._player_source.teama.tid ? this._teamAPlayerNum += 1 : this._teamBPlayerNum += 1);
                    sys.isObjectValid(this._player_source.bat[e].backup) && this._player_source.bat[e].backup > 0 && this._backupPlayers.push(this._player_source.bat[e]);
                }
            }
            if (sys.isObjectValid(this._player_source.ar) && this._player_source.ar.length > 0) {
                for (let e = 0; e < this._player_source.ar.length; e++) {
                    1 == this._player_source.ar[e].playing11 && (this._lineup = 1);
                    this._player_source.ar[e].role = "AR";
                    this._allPlayerMsg.set(this._player_source.ar[e].player_id, this._player_source.ar[e]);
                    1 == this._player_source.ar[e].select_status && (this._arSelectNum += 1, this._selectPlayerIds.push(this._player_source.ar[e].player_id), this._creditsLeft -= this._player_source.ar[e].credits, this._player_source.ar[e].team_id == this._player_source.teama.tid ? this._teamAPlayerNum += 1 : this._teamBPlayerNum += 1);
                    sys.isObjectValid(this._player_source.ar[e].backup) && this._player_source.ar[e].backup > 0 && this._backupPlayers.push(this._player_source.ar[e]);
                }
            }
            if (sys.isObjectValid(this._player_source.bowl) && this._player_source.bowl.length > 0) {
                for (let e = 0; e < this._player_source.bowl.length; e++) {
                    1 == this._player_source.bowl[e].playing11 && (this._lineup = 1);
                    this._player_source.bowl[e].role = "BOWL";
                    this._allPlayerMsg.set(this._player_source.bowl[e].player_id, this._player_source.bowl[e]);
                    1 == this._player_source.bowl[e].select_status && (this._bowlSelectNum += 1, this._selectPlayerIds.push(this._player_source.bowl[e].player_id), this._creditsLeft -= this._player_source.bowl[e].credits, this._player_source.bowl[e].team_id == this._player_source.teama.tid ? this._teamAPlayerNum += 1 : this._teamBPlayerNum += 1);
                    sys.isObjectValid(this._player_source.bowl[e].backup) && this._player_source.bowl[e].backup > 0 && this._backupPlayers.push(this._player_source.bowl[e]);
                }
            }
        }
    }
    refreshView() {
        if (this.notLineUpPlayers = [], this._hasFastTab ? (this.curTab = 4, this.switchFastOrNormal(true)) : (this.curTab = 0, this.switchFastOrNormal(false)), this.updateTabView(false), this.updateTabContent(), this.updateStatInfo(), 3 == this._fromType && TweenTool.delayAct(this.node, (() => {
            this.dealNotLineUpLogic();
        }), 0.3, true), this._hasLoadSubView || (this._hasLoadSubView = true, TweenTool.delayAct(this.node, (() => {
            ToolUtils.preLoadBundlePrefab(BundleNameDefined.Bundle_Yes11, "prefab/cricket_captainselect", null);
        }), 2, true)), 1 == this._hasForceSignMatch && 1 == User.shared().forceSignCricket) {
            this.bottomNode.getChildByName("fingerNode").active = true;
            let e = this.bottomNode.getChildByName("fingerNode").getComponent(sp.Skeleton);
            e.clearTracks();
            e.setToSetupPose();
            e.setAnimation(0, "click", true);
        }
    }
    updateStatInfo() {
        sys.isObjectValid(this._player_source) && (sys.isObjectValid(this._player_source.pitch) && (this.detailsNode.getChildByName("stat_node").getChildByName("pitch_desc").getComponent(Label).string = this._player_source.pitch), sys.isObjectValid(this._player_source.goodfor) && (this.detailsNode.getChildByName("stat_node").getChildByName("goodfor_desc").getComponent(Label).string = this._player_source.goodfor), sys.isObjectValid(this._player_source.avg) && (this.detailsNode.getChildByName("stat_node").getChildByName("avg_desc").getComponent(Label).string = this._player_source.avg));
    }
    dealNotLineUpLogic() {
        let e = false;
        if (sys.isObjectValid(this._player_source.wk) && Array.isArray(this._player_source.wk) && this._player_source.wk.length > 0) {
            for (let t = 0; t < this._player_source.wk.length; t++) {
                sys.isObjectValid(this._player_source.wk[t].playing11) && 1 == this._player_source.wk[t].playing11 && (e = true);
                sys.isObjectValid(this._player_source.wk[t].select_status) && 1 == this._player_source.wk[t].select_status && sys.isObjectValid(this._player_source.wk[t].playing11) && 0 == this._player_source.wk[t].playing11 && this.notLineUpPlayers.push(this._player_source.wk[t]);
            }
        }
        if (sys.isObjectValid(this._player_source.bat) && Array.isArray(this._player_source.bat) && this._player_source.bat.length > 0) {
            for (let t = 0; t < this._player_source.bat.length; t++) {
                sys.isObjectValid(this._player_source.bat[t].playing11) && 1 == this._player_source.bat[t].playing11 && (e = true);
                sys.isObjectValid(this._player_source.bat[t].select_status) && 1 == this._player_source.bat[t].select_status && sys.isObjectValid(this._player_source.bat[t].playing11) && 0 == this._player_source.bat[t].playing11 && this.notLineUpPlayers.push(this._player_source.bat[t]);
            }
        }
        if (sys.isObjectValid(this._player_source.ar) && Array.isArray(this._player_source.ar) && this._player_source.ar.length > 0) {
            for (let t = 0; t < this._player_source.ar.length; t++) {
                sys.isObjectValid(this._player_source.ar[t].playing11) && 1 == this._player_source.ar[t].playing11 && (e = true);
                sys.isObjectValid(this._player_source.ar[t].select_status) && 1 == this._player_source.ar[t].select_status && sys.isObjectValid(this._player_source.ar[t].playing11) && 0 == this._player_source.ar[t].playing11 && this.notLineUpPlayers.push(this._player_source.ar[t]);
            }
        }
        if (sys.isObjectValid(this._player_source.bowl) && Array.isArray(this._player_source.bowl) && this._player_source.bowl.length > 0) {
            for (let t = 0; t < this._player_source.bowl.length; t++) {
                sys.isObjectValid(this._player_source.bowl[t].playing11) && 1 == this._player_source.bowl[t].playing11 && (e = true);
                sys.isObjectValid(this._player_source.bowl[t].select_status) && 1 == this._player_source.bowl[t].select_status && sys.isObjectValid(this._player_source.bowl[t].playing11) && 0 == this._player_source.bowl[t].playing11 && this.notLineUpPlayers.push(this._player_source.bowl[t]);
            }
        }
        if (e) {
            if (this.notLineUpPlayers.length > 0) {
                let e = { match_id: this._match_id, fromType: this._fromType, teamlistData: this.notLineUpPlayers, source: { teama: this._player_source.teama, teamb: this._player_source.teamb }, callFunc: e => {
                        this.checkRemovePlayer(e);
                    } };
                Utils.shared().showSportCricket_notLineUp(e);
            }
        }
        else {
            this._fromType = 2;
        }
    }
    checkRemovePlayer(e) {
        if (sys.isObjectValid(this._player_source.wk) && Array.isArray(this._player_source.wk) && this._player_source.wk.length > 0) {
            for (let t = 0; t < this._player_source.wk.length; t++) {
                sys.isObjectValid(this._player_source.wk[t].select_status) && 1 == this._player_source.wk[t].select_status && sys.isObjectValid(this._player_source.wk[t].playing11) && 0 == this._player_source.wk[t].playing11 && -1 != e.indexOf(this._player_source.wk[t].player_id) && (this._player_source.wk[t].select_status = 0);
            }
        }
        if (sys.isObjectValid(this._player_source.bat) && Array.isArray(this._player_source.bat) && this._player_source.bat.length > 0) {
            for (let t = 0; t < this._player_source.bat.length; t++) {
                sys.isObjectValid(this._player_source.bat[t].select_status) && 1 == this._player_source.bat[t].select_status && sys.isObjectValid(this._player_source.bat[t].playing11) && 0 == this._player_source.bat[t].playing11 && -1 != e.indexOf(this._player_source.bat[t].player_id) && (this._player_source.bat[t].select_status = 0);
            }
        }
        if (sys.isObjectValid(this._player_source.ar) && Array.isArray(this._player_source.ar) && this._player_source.ar.length > 0) {
            for (let t = 0; t < this._player_source.ar.length; t++) {
                sys.isObjectValid(this._player_source.ar[t].select_status) && 1 == this._player_source.ar[t].select_status && sys.isObjectValid(this._player_source.ar[t].playing11) && 0 == this._player_source.ar[t].playing11 && -1 != e.indexOf(this._player_source.ar[t].player_id) && (this._player_source.ar[t].select_status = 0);
            }
        }
        if (sys.isObjectValid(this._player_source.bowl) && Array.isArray(this._player_source.bowl) && this._player_source.bowl.length > 0) {
            for (let t = 0; t < this._player_source.bowl.length; t++) {
                sys.isObjectValid(this._player_source.bowl[t].select_status) && 1 == this._player_source.bowl[t].select_status && sys.isObjectValid(this._player_source.bowl[t].playing11) && 0 == this._player_source.bowl[t].playing11 && -1 != e.indexOf(this._player_source.bowl[t].player_id) && (this._player_source.bowl[t].select_status = 0);
            }
        }
        this.filterSelectPlayer();
        this._selectPlayerNum = this._selectPlayerIds.length;
        this.updateSelectPlayerNum();
        this.updateTeamASelectPlayerNum();
        this.updateTeamBSelectPlayerNum();
        this.updateLeftCredits();
        this.updateProgress();
        this.updateSelectPlayerNumByType();
        this.updateNextButtonStatus();
        this.updateTabContent();
    }
    updateSelectPlayerNum() {
        this.detailsNode.getChildByName("pnum").getComponent(Label).string = String(this._selectPlayerNum) + "/11";
    }
    updateTeamASelectPlayerNum() {
        this.detailsNode.getChildByName("team_num0").getComponent(Label).string = String(this._teamAPlayerNum);
    }
    updateTeamBSelectPlayerNum() {
        this.detailsNode.getChildByName("team_num1").getComponent(Label).string = String(this._teamBPlayerNum);
    }
    updateProgress() {
        for (let e = 0; e < 11; e++) {
            e < this._selectPlayerNum ? this.detailsNode.getChildByName("progress" + e).getComponent(Sprite).spriteFrame = 0 == e ? this.progressImgs[3] : 10 == e ? this.progressImgs[2] : this.progressImgs[0] : this.detailsNode.getChildByName("progress" + e).getComponent(Sprite).spriteFrame = 0 == e ? this.progressImgs[5] : 10 == e ? this.progressImgs[4] : this.progressImgs[1];
        }
        if (this.detailsNode.getChildByName("progress_wz0").getComponent(Label).string = String(this._selectPlayerNum), this.detailsNode.getChildByName("progress_wz0").active = this._selectPlayerNum > 0, this._selectPlayerNum > 0) {
            let e = this.detailsNode.getChildByName("progress" + (this._selectPlayerNum - 1)).getPosition();
            this.detailsNode.getChildByName("progress_wz0").setPosition(e);
        }
        this.detailsNode.getChildByName("progress_wz1").active = 11 != this._selectPlayerNum;
        this.detailsNode.getChildByName("progress_wz1").active = false;
        this.detailsNode.getChildByName("progress_wz0").active = false;
    }
    updateLeftCredits() {
        this.bottomNode.getChildByName("credits_num").getComponent(Label).string = String(this._creditsLeft);
    }
    updateSelectPlayerNumByType() {
        this.tabNode.getChildByName("tab0").getChildByName("Label").getComponent(Label).string = ToolUtils.format(i18nMgr.shared().getValueByKey("yes11.wk"), this._wkSelectNum);
        this.tabNode.getChildByName("tab1").getChildByName("Label").getComponent(Label).string = ToolUtils.format(i18nMgr.shared().getValueByKey("yes11.bat"), this._batSelectNum);
        this.tabNode.getChildByName("tab2").getChildByName("Label").getComponent(Label).string = ToolUtils.format(i18nMgr.shared().getValueByKey("yes11.ar"), this._arSelectNum);
        this.tabNode.getChildByName("tab3").getChildByName("Label").getComponent(Label).string = ToolUtils.format(i18nMgr.shared().getValueByKey("yes11.bowl"), this._bowlSelectNum);
    }
    updateContestDetails() {
        if (0 == this._fromType && (this._teamAPlayerNum = 0, this._teamBPlayerNum = 0, this._selectPlayerNum = 0), !sys.isObjectValid(this._player_source)) {
            return;
        }
        this.filterSelectPlayer();
        this._selectPlayerNum = this._selectPlayerIds.length;
        this.updateSelectPlayerNum();
        this.updateTeamASelectPlayerNum();
        this.updateTeamBSelectPlayerNum();
        this.updateLeftCredits();
        this.updateProgress();
        1 == this._lineup || 1 == this._join_last_match ? (this._hasFastTab = true, this.tabNode = this.rootNode.getChildByName("select_diban_fast"), 1 == this._lineup ? this.tabNode.getChildByName("tab4").getChildByName("Label").getComponent(Label).string = i18nMgr.shared().getValueByKey("yes11.fast_icon_tip1") : this.tabNode.getChildByName("tab4").getChildByName("Label").getComponent(Label).string = i18nMgr.shared().getValueByKey("yes11.fast_icon_tip2")) : (this._hasFastTab = false, this.tabNode = this.rootNode.getChildByName("select_diban"));
        this.rootNode.getChildByName("select_diban_fast").active = this._hasFastTab;
        this.rootNode.getChildByName("select_diban").active = !this._hasFastTab;
        this.updateSelectPlayerNumByType();
        this.updateNextButtonStatus();
        let e = this._player_source.teama, t = this._player_source.teamb;
        sys.isObjectValid(e.abbr) && e.abbr.length > 0 && (this.detailsNode.getChildByName("team_short_name0").getComponent(Label).string = e.abbr);
        sys.isObjectValid(t.abbr) && t.abbr.length > 0 && (this.detailsNode.getChildByName("team_short_name1").getComponent(Label).string = t.abbr);
        sys.isObjectValid(e.thumb_url) && e.thumb_url.length > 0 && (this.taskAwardIconMap.set(this.detailsNode.getChildByName("team_icon0"), e.thumb_url), Utils.shared().updateNetImage(this.detailsNode.getChildByName("team_icon0"), e.thumb_url, size(76, 76)));
        sys.isObjectValid(t.thumb_url) && t.thumb_url.length > 0 && (this.taskAwardIconMap.set(this.detailsNode.getChildByName("team_icon1"), t.thumb_url), Utils.shared().updateNetImage(this.detailsNode.getChildByName("team_icon1"), t.thumb_url, size(76, 76)));
    }
    checkHasPlayingPlayer() {
        let e = 0, t = 0;
        if (0 == this.curTab) {
            if (sys.isObjectValid(this._player_source.wk) && Array.isArray(this._player_source.wk) && this._player_source.wk.length > 0) {
                for (let s = 0; s < this._player_source.wk.length; s++) {
                    sys.isObjectValid(this._player_source.wk[s].playing11) && 1 == this._player_source.wk[s].playing11 ? e = 1 : sys.isObjectValid(this._player_source.wk[s].subplayer) && 1 == this._player_source.wk[s].subplayer && (t = 1);
                }
            }
        }
        else if (1 == this.curTab) {
            if (sys.isObjectValid(this._player_source.bat) && Array.isArray(this._player_source.bat) && this._player_source.bat.length > 0) {
                for (let s = 0; s < this._player_source.bat.length; s++) {
                    sys.isObjectValid(this._player_source.bat[s].playing11) && 1 == this._player_source.bat[s].playing11 ? e = 1 : sys.isObjectValid(this._player_source.bat[s].subplayer) && 1 == this._player_source.bat[s].subplayer && (t = 1);
                }
            }
        }
        else if (2 == this.curTab) {
            if (sys.isObjectValid(this._player_source.ar) && Array.isArray(this._player_source.ar) && this._player_source.ar.length > 0) {
                for (let s = 0; s < this._player_source.ar.length; s++) {
                    sys.isObjectValid(this._player_source.ar[s].playing11) && 1 == this._player_source.ar[s].playing11 ? e = 1 : sys.isObjectValid(this._player_source.ar[s].subplayer) && 1 == this._player_source.ar[s].subplayer && (t = 1);
                }
            }
        }
        else if (3 == this.curTab && sys.isObjectValid(this._player_source.bowl) && Array.isArray(this._player_source.bowl) && this._player_source.bowl.length > 0) {
            for (let s = 0; s < this._player_source.bowl.length; s++) {
                sys.isObjectValid(this._player_source.bowl[s].playing11) && 1 == this._player_source.bowl[s].playing11 ? e = 1 : sys.isObjectValid(this._player_source.bowl[s].subplayer) && 1 == this._player_source.bowl[s].subplayer && (t = 1);
            }
        }
        return { lineup: e, subup: t };
    }
    getTargetSourceData() {
        if (0 == this.curTab) {
            if (sys.isObjectValid(this._player_source.wk) && Array.isArray(this._player_source.wk) && this._player_source.wk.length > 0) {
                return this._player_source.wk;
            }
        }
        else if (1 == this.curTab) {
            if (sys.isObjectValid(this._player_source.bat) && Array.isArray(this._player_source.bat) && this._player_source.bat.length > 0) {
                return this._player_source.bat;
            }
        }
        else if (2 == this.curTab) {
            if (sys.isObjectValid(this._player_source.ar) && Array.isArray(this._player_source.ar) && this._player_source.ar.length > 0) {
                return this._player_source.ar;
            }
        }
        else if (3 == this.curTab && sys.isObjectValid(this._player_source.bowl) && Array.isArray(this._player_source.bowl) && this._player_source.bowl.length > 0) {
            return this._player_source.bowl;
        }
    }
    sortPlayerInfoByType(e) {
        let t = [], s = [], i = [];
        for (let a = 0; a < e.length; a++) {
            1 == e[a].playing11 ? t.push(e[a]) : 1 == e[a].subplayer ? i.push(e[a]) : s.push(e[a]);
        }
        return 0 == this._curSortType ? 0 == this._teamSortType ? (t.sort(((e, t) => e.team_id - t.team_id)), s.sort(((e, t) => e.team_id - t.team_id)), i.sort(((e, t) => e.team_id - t.team_id))) : (t.sort(((e, t) => t.team_id - e.team_id)), s.sort(((e, t) => t.team_id - e.team_id)), i.sort(((e, t) => t.team_id - e.team_id))) : 1 == this._curSortType ? 0 == this._pointsSortType ? (t.sort(((e, t) => e.pts !== t.pts ? e.pts - t.pts : t.credits - e.credits)), s.sort(((e, t) => e.pts !== t.pts ? e.pts - t.pts : t.credits - e.credits)), i.sort(((e, t) => e.pts !== t.pts ? e.pts - t.pts : t.credits - e.credits))) : (t.sort(((e, t) => e.pts !== t.pts ? t.pts - e.pts : t.credits - e.credits)), s.sort(((e, t) => e.pts !== t.pts ? t.pts - e.pts : t.credits - e.credits)), i.sort(((e, t) => e.pts !== t.pts ? t.pts - e.pts : t.credits - e.credits))) : 2 == this._curSortType ? 0 == this._creditsSortType ? (t.sort(((e, t) => e.credits - t.credits)), s.sort(((e, t) => e.credits - t.credits)), i.sort(((e, t) => e.credits - t.credits))) : (t.sort(((e, t) => t.credits - e.credits)), s.sort(((e, t) => t.credits - e.credits)), i.sort(((e, t) => t.credits - e.credits))) : 3 == this._curSortType && (0 == this._rateSortType ? (t.sort(((e, t) => e.member_prob - t.member_prob)), s.sort(((e, t) => e.member_prob - t.member_prob)), i.sort(((e, t) => e.member_prob - t.member_prob))) : (t.sort(((e, t) => t.member_prob - e.member_prob)), s.sort(((e, t) => t.member_prob - e.member_prob)), i.sort(((e, t) => t.member_prob - e.member_prob)))), { pArr: t, nArr: s, sArr: i };
    }
    reSortPlayerInfo() {
        let e = this.checkHasPlayingPlayer();
        0 == e.lineup && (e.subup = 0);
        this.updateSortView();
        this.contentNode.getChildByName("playing_node").active = 1 == e.lineup;
        this.contentNode.getChildByName("noplay_node").active = 1 == e.lineup;
        this.contentNode.getChildByName("sub_node").active = 1 == e.subup;
        this.contentNode.getChildByName("playing_layout").removeAllChildren();
        this.contentNode.getChildByName("notplay_layout").removeAllChildren();
        this.contentNode.getChildByName("sub_layout").removeAllChildren();
        this.rootNode.getChildByName("all_ScrollView").getComponent(ScrollView).scrollToTop(0);
        this._allPlayerView = [];
        this.playerViewMap.clear();
        let t = this.getTargetSourceData();
        if (sys.isObjectValid(t) && t.length > 0) {
            let s = this.sortPlayerInfoByType(t);
            1 == e.lineup ? (this.addPlayerView(this.contentNode.getChildByName("playing_layout"), s.pArr), this.addPlayerView(this.contentNode.getChildByName("notplay_layout"), s.nArr), this.addPlayerView(this.contentNode.getChildByName("sub_layout"), s.sArr), this.contentNode.getChildByName("noplay_node").active = s.nArr.length > 0) : this.addPlayerView(this.contentNode.getChildByName("notplay_layout"), s.nArr);
        }
        let s = 11 - this._selectPlayerNum, i = 0, a = false;
        0 == this._wkSelectNum && (i += 1);
        0 == this._batSelectNum && (i += 1);
        0 == this._arSelectNum && (i += 1);
        0 == this._bowlSelectNum && (i += 1);
        s <= i && ((0 == this.curTab && 0 != this._wkSelectNum || 1 == this.curTab && 0 != this._batSelectNum || 2 == this.curTab && 0 != this._arSelectNum || 3 == this.curTab && 0 != this._bowlSelectNum) && (a = true), a && this.updatePlayerViewMask(1));
        10 == this._teamAPlayerNum && 0 == this._teamBPlayerNum ? this.updatePlayerViewMask(1, 1) : 10 == this._teamBPlayerNum && 0 == this._teamAPlayerNum && this.updatePlayerViewMask(1, 0);
    }
    addPlayerView(e, t) {
        for (let s = 0; s < t.length; s++) {
            let i = instantiate(this.team_mobanView);
            i.active = true;
            e.addChild(i);
            this._allPlayerView.push(i);
            let a = ToolUtils.toJsonString(t[s]);
            i.getChildByName("op_btn").getComponent(Button).clickEvents[0].customEventData = a;
            this.playerViewMap.set(t[s].player_id, i);
            i.getChildByName("player_btn").getComponent(Button).clickEvents[0].customEventData = a;
            -1 != this._selectPlayerIds.indexOf(t[s].player_id) ? (i.getChildByName("bg").getComponent(Sprite).color = color(255, 247, 224), i.getChildByName("op_btn").getChildByName("ico").getComponent(Sprite).spriteFrame = this.operateImgs[1]) : (i.getChildByName("bg").getComponent(Sprite).color = color(255, 255, 255), i.getChildByName("op_btn").getChildByName("ico").getComponent(Sprite).spriteFrame = this.operateImgs[0], 0 == this.curTab ? i.getChildByName("mask").active = 8 == this._wkSelectNum : 1 == this.curTab ? i.getChildByName("mask").active = 8 == this._batSelectNum : 2 == this.curTab ? i.getChildByName("mask").active = 8 == this._arSelectNum : 3 == this.curTab && (i.getChildByName("mask").active = 8 == this._bowlSelectNum));
            i.getChildByName("team_bg").getChildByName("wz").getComponent(Label).string = t[s].team_abbr;
            i.getChildByName("team_bg").getChildByName("wz").getComponent(Label).updateRenderData(true);
            let r = i.getChildByName("team_bg").getChildByName("wz").getComponent(UITransform).width;
            if (r > 25 && (i.getChildByName("team_bg").getComponent(UITransform).contentSize = size(r + 10, 20)), t[s].team_id == this._player_source.teama.tid ? (i.getChildByName("team_bg").getComponent(Sprite).spriteFrame = this.teamBgImgs[0], i.getChildByName("team_bg").getChildByName("wz").getComponent(Label).color = color(255, 255, 255)) : (i.getChildByName("team_bg").getComponent(Sprite).spriteFrame = this.teamBgImgs[1], i.getChildByName("team_bg").getChildByName("wz").getComponent(Label).color = color(51, 51, 51)), sys.isObjectValid(t[s].thumb_url) && t[s].thumb_url.length > 0 && (this.taskAwardIconMap.set(i.getChildByName("player_icon"), t[s].thumb_url), Utils.shared().updateNetImage(i.getChildByName("player_icon"), t[s].thumb_url, size(110, 110))), sys.isObjectValid(t[s].pts) && (i.getChildByName("pts").getComponent(Label).string = "" + t[s].pts), sys.isObjectValid(t[s].join_last_match) ? i.getChildByName("tip").active = 1 == t[s].join_last_match : i.getChildByName("tip").active = false, sys.isObjectValid(t[s].credits) && (i.getChildByName("credits").getComponent(Label).string = String(t[s].credits)), sys.isObjectValid(t[s].member_prob) ? i.getChildByName("rate").getComponent(Label).string = t[s].member_prob + "%" : i.getChildByName("rate").getComponent(Label).string = "0%", sys.isObjectValid(t[s].short_name) && (i.getChildByName("pname").getComponent(Label).string = String(t[s].short_name), i.getChildByName("pname").getComponent(Label).updateRenderData(true)), ("AR" == t[s].role || "BOWL" == t[s].role) && sys.isObjectValid(t[s].bowling_style) && Number(t[s].bowling_style) > 0) {
                1 == Number(t[s].bowling_style) ? (i.getChildByName("role").getComponent(Sprite).spriteFrame = this.styleImgs[0], i.getChildByName("role").active = true) : 2 == Number(t[s].bowling_style) && (i.getChildByName("role").getComponent(Sprite).spriteFrame = this.styleImgs[1], i.getChildByName("role").active = true);
                let e = i.getChildByName("pname").getComponent(UITransform).width;
                i.getChildByName("role").setPosition(v3(-208.665 + e + 25, -29.925));
            }
        }
    }
    updateGold(e) {
        let t = this.goldNode.getChildByName("coin");
        null != e && t && (t.getComponent(Label).string = ToolUtils.parse_double(e));
    }
    onPlayerInfoClick(e, t) {
        if (SoundManager.shared().playFx("click"), sys.now() - this._lastClick < 500) {
            return;
        }
        if (this._lastClick = sys.now(), 3 == this._match_state) {
            return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("yes11.live_tip"), 2);
        }
        if (4 == this._match_state) {
            return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("yes11.cancel_tip"), 2);
        }
        if (sys.isObjectValid(this._player_source.wk) && this._player_source.wk.length > 0) {
            for (let e = 0; e < this._player_source.wk.length; e++) {
                -1 != this._selectPlayerIds.indexOf(this._player_source.wk[e].player_id) ? this._player_source.wk[e].select_status = 1 : this._player_source.wk[e].select_status = 0;
            }
        }
        if (sys.isObjectValid(this._player_source.bat) && this._player_source.bat.length > 0) {
            for (let e = 0; e < this._player_source.bat.length; e++) {
                -1 != this._selectPlayerIds.indexOf(this._player_source.bat[e].player_id) ? this._player_source.bat[e].select_status = 1 : this._player_source.bat[e].select_status = 0;
            }
        }
        if (sys.isObjectValid(this._player_source.ar) && this._player_source.ar.length > 0) {
            for (let e = 0; e < this._player_source.ar.length; e++) {
                -1 != this._selectPlayerIds.indexOf(this._player_source.ar[e].player_id) ? this._player_source.ar[e].select_status = 1 : this._player_source.ar[e].select_status = 0;
            }
        }
        if (sys.isObjectValid(this._player_source.bowl) && this._player_source.bowl.length > 0) {
            for (let e = 0; e < this._player_source.bowl.length; e++) {
                -1 != this._selectPlayerIds.indexOf(this._player_source.bowl[e].player_id) ? this._player_source.bowl[e].select_status = 1 : this._player_source.bowl[e].select_status = 0;
            }
        }
        let s = ToolUtils.parseJson(t), i = { source: this._source, select_player_soucrce: this._player_source, match_id: this._match_id, team_id: this._team_id, contest_id: this._contest_id, player_id: s.player_id, lastNode: this.node, playerInfo: t, select_status: 0, join_team: s.join_team, fromType: 0, call: e => {
                this.onPlayerOperateClick(null, e);
            } };
        -1 != this._selectPlayerIds.indexOf(s.player_id) && (i.select_status = 1);
        SportCricket_Manager.shared().requestYes11_PlayerInfo(i, true);
    }
    onPlayerOperateClick(e, t) {
        if (SoundManager.shared().playFx("click"), this._lastClick = sys.now(), 3 == this._match_state) {
            return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("yes11.live_tip"), 2);
        }
        if (4 == this._match_state) {
            return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("yes11.cancel_tip"), 2);
        }
        let s = ToolUtils.parseJson(t);
        this.dealPlayerOperate(s);
    }
    dealPlayerOperate(e, t = 0) {
        let s = e.player_id, i = this._selectPlayerIds.indexOf(s);
        if (-1 != i) {
            this._selectPlayerIds.splice(i, 1);
            this._selectPlayerNum -= 1;
            e.team_id == this._player_source.teama.tid ? this._teamAPlayerNum -= 1 : this._teamBPlayerNum -= 1;
            this._creditsLeft += e.credits;
            this.updateTargetPlayerViewStatus(0, s);
            this.updateOperatePlayerNum(0, e);
            this.updatePlayerViewMask();
        }
        else {
            if (11 == this._selectPlayerNum) {
                return;
            }
            if (10 == this._teamAPlayerNum && e.team_id == this._player_source.teama.tid) {
                if (1 == t) {
                    return;
                }
                return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("yes11.cteam_limit"), 3, 0, ToolUtils.getIsNormalDirection());
            }
            if (10 == this._teamBPlayerNum && e.team_id == this._player_source.teamb.tid) {
                if (1 == t) {
                    return;
                }
                return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("yes11.cteam_limit"), 3, 0, ToolUtils.getIsNormalDirection());
            }
            let i = this.playerViewMap.get(s);
            if (sys.isObjectValid(i) && i.getChildByName("mask").active) {
                if (1 == t) {
                    return;
                }
                return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("yes11.ctip1"), 3, 0, ToolUtils.getIsNormalDirection());
            }
            if (this._creditsLeft - e.credits < 0) {
                if (1 == t) {
                    return;
                }
                return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("yes11.credit_tip"), 3, 0, ToolUtils.getIsNormalDirection());
            }
            this._selectPlayerIds.push(s);
            this._selectPlayerNum += 1;
            e.team_id == this._player_source.teama.tid ? this._teamAPlayerNum += 1 : this._teamBPlayerNum += 1;
            this._creditsLeft -= e.credits;
            this.updateTargetPlayerViewStatus(1, s);
            this.updateOperatePlayerNum(1, e);
            let a = 11 - this._selectPlayerNum, r = 0;
            0 == this._wkSelectNum && (r += 1);
            0 == this._batSelectNum && (r += 1);
            0 == this._arSelectNum && (r += 1);
            0 == this._bowlSelectNum && (r += 1);
            a <= r && (0 != this._wkSelectNum && 0 == this.curTab && this.updatePlayerViewMask(1), 0 != this._batSelectNum && 1 == this.curTab && this.updatePlayerViewMask(1), 0 != this._arSelectNum && 2 == this.curTab && this.updatePlayerViewMask(1), 0 != this._bowlSelectNum && 3 == this.curTab && this.updatePlayerViewMask(1));
            10 == this._teamAPlayerNum && 0 == this._teamBPlayerNum ? this.updatePlayerViewMask(1, 1) : 10 == this._teamBPlayerNum && 0 == this._teamAPlayerNum && this.updatePlayerViewMask(1, 0);
        }
        this.updateNextButtonStatus();
    }
    updateNextButtonStatus() {
        11 == this._selectPlayerNum ? (this.nextNode.getComponent(Sprite).spriteFrame = this.btnBgImgs[0], this.nextNode.getComponent(Button).interactable = true) : (this.nextNode.getComponent(Sprite).spriteFrame = this.btnBgImgs[1], this.nextNode.getComponent(Button).interactable = true);
    }
    dealFastCreateLogic() {
        if (sys.isObjectValid(this._player_source.wk) && this._player_source.wk.length > 0) {
            for (let e = 0; e < this._player_source.wk.length; e++) {
                -1 != this._selectPlayerIds.indexOf(this._player_source.wk[e].player_id) ? this._player_source.wk[e].select_status = 1 : this._player_source.wk[e].select_status = 0;
            }
        }
        if (sys.isObjectValid(this._player_source.bat) && this._player_source.bat.length > 0) {
            for (let e = 0; e < this._player_source.bat.length; e++) {
                -1 != this._selectPlayerIds.indexOf(this._player_source.bat[e].player_id) ? this._player_source.bat[e].select_status = 1 : this._player_source.bat[e].select_status = 0;
            }
        }
        if (sys.isObjectValid(this._player_source.ar) && this._player_source.ar.length > 0) {
            for (let e = 0; e < this._player_source.ar.length; e++) {
                -1 != this._selectPlayerIds.indexOf(this._player_source.ar[e].player_id) ? this._player_source.ar[e].select_status = 1 : this._player_source.ar[e].select_status = 0;
            }
        }
        if (sys.isObjectValid(this._player_source.bowl) && this._player_source.bowl.length > 0) {
            for (let e = 0; e < this._player_source.bowl.length; e++) {
                -1 != this._selectPlayerIds.indexOf(this._player_source.bowl[e].player_id) ? this._player_source.bowl[e].select_status = 1 : this._player_source.bowl[e].select_status = 0;
            }
        }
        let e = { player_source: this._player_source, backkup_Players: this._backupPlayers, source: this._source, match_id: this._match_id, team_id: this._team_id, contest_id: this._contest_id, lastNode: this.node, lineup: this._lineup, fromType: this._fromType, is_chip: this._is_chip, call: e => {
                this.dealPlayerOperate(e, 1);
            } }, t = this.fastManger.getComponent("SportCricket_FastCreateTeam");
        t.init(e);
        t.updateContestDetails();
        t.refreshView();
    }
    dealPreviewLogic() {
        let e = [], t = [], s = [], i = [];
        for (let a = 0; a < this._selectPlayerIds.length; a++) {
            this._allPlayerMsg.has(this._selectPlayerIds[a]) && ("WK" == this._allPlayerMsg.get(this._selectPlayerIds[a]).role ? e.push(this._allPlayerMsg.get(this._selectPlayerIds[a])) : "BAT" == this._allPlayerMsg.get(this._selectPlayerIds[a]).role ? t.push(this._allPlayerMsg.get(this._selectPlayerIds[a])) : "AR" == this._allPlayerMsg.get(this._selectPlayerIds[a]).role ? s.push(this._allPlayerMsg.get(this._selectPlayerIds[a])) : "BOWL" == this._allPlayerMsg.get(this._selectPlayerIds[a]).role && i.push(this._allPlayerMsg.get(this._selectPlayerIds[a])));
        }
        let a = { wk_Players: e, bat_Players: t, ar_Players: s, bowl_Players: i, backkup_Players: this._backupPlayers, teama: this._player_source.teama, teamb: this._player_source.teamb, teamAPnum: this._teamAPlayerNum, teamBPnum: this._teamBPlayerNum, credits: this._player_source.credits, left_credits: this._creditsLeft, lastNode: this.node, lineup: this._lineup };
        Utils.shared().showSportCricket_teamPreview(a);
    }
    dealShowCaptainSelectView() {
        let e = [], t = [], s = [], i = [], a = [];
        for (let r = 0; r < this._selectPlayerIds.length; r++) {
            this._allPlayerMsg.has(this._selectPlayerIds[r]) && (e.push(this._allPlayerMsg.get(this._selectPlayerIds[r])), "WK" == this._allPlayerMsg.get(this._selectPlayerIds[r]).role ? t.push(this._allPlayerMsg.get(this._selectPlayerIds[r])) : "BAT" == this._allPlayerMsg.get(this._selectPlayerIds[r]).role ? s.push(this._allPlayerMsg.get(this._selectPlayerIds[r])) : "AR" == this._allPlayerMsg.get(this._selectPlayerIds[r]).role ? i.push(this._allPlayerMsg.get(this._selectPlayerIds[r])) : "BOWL" == this._allPlayerMsg.get(this._selectPlayerIds[r]).role && a.push(this._allPlayerMsg.get(this._selectPlayerIds[r])));
        }
        let r = 0;
        1 == this._hasForceSignMatch && 1 == User.shared().forceSignCricket && (r = 1);
        let l = { source: this._source, player_source: this._player_source, selectPlayers: e, match_id: this._match_id, fromType: this._fromType, contest_id: this._contest_id, team_id: this._team_id, lineup: this._lineup, is_chip: this._is_chip, force: r, previewInfo: { wk_Players: t, bat_Players: s, ar_Players: i, bowl_Players: a, teama: this._player_source.teama, teamb: this._player_source.teamb, teamAPnum: this._teamAPlayerNum, teamBPnum: this._teamBPlayerNum, backkup_Players: this._backupPlayers, credits: this._player_source.credits, left_credits: this._creditsLeft, lineup: this._lineup }, lastNode: this.node };
        Utils.shared().showSportCricket_selectCaptain(l);
    }
    updateOperatePlayerNum(e, t) {
        0 == e ? "WK" == t.role ? this._wkSelectNum -= 1 : "BAT" == t.role ? this._batSelectNum -= 1 : "AR" == t.role ? this._arSelectNum -= 1 : "BOWL" == t.role && (this._bowlSelectNum -= 1) : "WK" == t.role ? this._wkSelectNum += 1 : "BAT" == t.role ? this._batSelectNum += 1 : "AR" == t.role ? this._arSelectNum += 1 : "BOWL" == t.role && (this._bowlSelectNum += 1);
        this.updateSelectPlayerNum();
        this.updateSelectPlayerNumByType();
        this.updateTeamASelectPlayerNum();
        this.updateTeamBSelectPlayerNum();
        this.updateLeftCredits();
        this.updateProgress();
    }
    updatePlayerViewMask(e, t) {
        for (let s = 0; s < this._allPlayerView.length; s++) {
            let i = this._allPlayerView[s];
            if (ToolUtils.isObjValid(i)) {
                let s = ToolUtils.parseJson(i.getChildByName("op_btn").getComponent(Button).clickEvents[0].customEventData), a = s.player_id;
                -1 == this._selectPlayerIds.indexOf(a) && (0 == this.curTab ? 8 == this._wkSelectNum ? (i.getChildByName("mask").active = true, i.getChildByName("op_btn").getComponent(Button).interactable = true) : (i.getChildByName("mask").active = false, i.getChildByName("op_btn").getComponent(Button).interactable = true, sys.isObjectValid(e) && 1 == e && (sys.isObjectValid(t) ? 1 == t ? s.team_id == this._player_source.teama.tid && (i.getChildByName("mask").active = true, i.getChildByName("op_btn").getComponent(Button).interactable = true) : s.team_id == this._player_source.teamb.tid && (i.getChildByName("mask").active = true, i.getChildByName("op_btn").getComponent(Button).interactable = true) : (i.getChildByName("mask").active = true, i.getChildByName("op_btn").getComponent(Button).interactable = true))) : 1 == this.curTab ? 8 == this._batSelectNum ? (i.getChildByName("mask").active = true, i.getChildByName("op_btn").getComponent(Button).interactable = true) : (i.getChildByName("mask").active = false, i.getChildByName("op_btn").getComponent(Button).interactable = true, sys.isObjectValid(e) && 1 == e && (sys.isObjectValid(t) ? 1 == t ? s.team_id == this._player_source.teama.tid && (i.getChildByName("mask").active = true, i.getChildByName("op_btn").getComponent(Button).interactable = true) : s.team_id == this._player_source.teamb.tid && (i.getChildByName("mask").active = true, i.getChildByName("op_btn").getComponent(Button).interactable = true) : (i.getChildByName("mask").active = true, i.getChildByName("op_btn").getComponent(Button).interactable = true))) : 2 == this.curTab ? 8 == this._arSelectNum ? (i.getChildByName("mask").active = true, i.getChildByName("op_btn").getComponent(Button).interactable = true) : (i.getChildByName("mask").active = false, i.getChildByName("op_btn").getComponent(Button).interactable = true, sys.isObjectValid(e) && 1 == e && (sys.isObjectValid(t) ? 1 == t ? s.team_id == this._player_source.teama.tid && (i.getChildByName("mask").active = true, i.getChildByName("op_btn").getComponent(Button).interactable = true) : s.team_id == this._player_source.teamb.tid && (i.getChildByName("mask").active = true, i.getChildByName("op_btn").getComponent(Button).interactable = true) : (i.getChildByName("mask").active = true, i.getChildByName("op_btn").getComponent(Button).interactable = true))) : 3 == this.curTab && (8 == this._bowlSelectNum ? (i.getChildByName("mask").active = true, i.getChildByName("op_btn").getComponent(Button).interactable = true) : (i.getChildByName("mask").active = false, i.getChildByName("op_btn").getComponent(Button).interactable = true, sys.isObjectValid(e) && 1 == e && (sys.isObjectValid(t) ? 1 == t ? s.team_id == this._player_source.teama.tid && (i.getChildByName("mask").active = true, i.getChildByName("op_btn").getComponent(Button).interactable = true) : s.team_id == this._player_source.teamb.tid && (i.getChildByName("mask").active = true, i.getChildByName("op_btn").getComponent(Button).interactable = true) : (i.getChildByName("mask").active = true, i.getChildByName("op_btn").getComponent(Button).interactable = true)))));
            }
        }
    }
    updateTargetPlayerViewStatus(e, t) {
        if (this.playerViewMap.has(t)) {
            let s = this.playerViewMap.get(t);
            ToolUtils.isObjValid(s) && (0 == e ? (s.getChildByName("bg").getComponent(Sprite).color = color(255, 255, 255), s.getChildByName("op_btn").getChildByName("ico").getComponent(Sprite).spriteFrame = this.operateImgs[0]) : (s.getChildByName("bg").getComponent(Sprite).color = color(255, 247, 224), s.getChildByName("op_btn").getChildByName("ico").getComponent(Sprite).spriteFrame = this.operateImgs[1]));
        }
    }
    onCloseButtonClick(e, t) {
        if (1 != this._hasForceSignMatch && (SoundManager.shared().playFx("click"), "back_btn" == t)) {
            if (this._closed) {
                return;
            }
            this.onBackView();
        }
    }
    initView() {
        if (this.fitScreen(), sys.isObjectValid(this._source)) {
            this.rootNode.getChildByName("top_node").getChildByName("title").getComponent(Label).string = this._source.teama.short_name + " vs " + this._source.teamb.short_name;
            let e = this.rootNode.getChildByName("details").getChildByName("lefttime");
            e.getComponent(Label).string = Utils.shared().parseCountDown(this._source.time_left);
            sys.isObjectValid(this._source.status) && (this._match_state = this._source.status);
            0 == this._source.time_left && 1 == this._source.status ? (e.getComponent(Label).string = this._source.start_day, sys.isObjectValid(this._source.is_current_day) && 1 == Number(this._source.is_current_day) && (this._source.status = 3, e.getComponent(Label).string = "Live")) : 1 == this._source.status ? TweenTool.myschedule(e, 1, (() => {
                ToolUtils.isObjValid(this.node) && (this._source.time_left > 0 ? e.getComponent(Label).string = Utils.shared().parseCountDown(this._source.time_left) : (this._source.status = 3, e.getComponent(Label).string = "Live", TweenTool.stopNodeAction(e)));
            })) : 3 == this._source.status ? (TweenTool.stopNodeAction(e), e.getComponent(Label).string = "Live") : 4 == this._source.status && (TweenTool.stopNodeAction(e), e.getComponent(Label).string = "Cancel");
            PushCenter.shared().addListener(PushEvent.UpdateYes11CurMatchLeftTime, (t => {
                try {
                    ToolUtils.isObjValid(this.node) && t.match_id == this._match_id && (this._source.time_left = t.time_left, this._source.is_current_day = t.is_current_day, this._match_state = t.status, 3 == t.status ? (TweenTool.stopNodeAction(e), e.getComponent(Label).string = "Live") : 4 == t.status && (TweenTool.stopNodeAction(e), e.getComponent(Label).string = "Cancel"));
                }
                catch (e) {
                    TLog.printError(this.TAG, PushEvent.UpdateYes11CurMatchLeftTime, e);
                }
            }), this);
            this.updateContestDetails();
        }
    }
    onButtonClick(e, t) {
        if (SoundManager.shared().playFx("click"), !(sys.now() - this._lastClick < 500)) {
            if (this._lastClick = sys.now(), 3 != this._match_state) {
                if (4 != this._match_state) {
                    if ("tab0" == t) {
                        if (4 == this.curTab && this.switchFastOrNormal(false), 0 == this.curTab) {
                            return;
                        }
                        this.curTab = 0;
                        this.updateTabView();
                        this.updateTabContent();
                    }
                    else if ("tab1" == t) {
                        if (4 == this.curTab && this.switchFastOrNormal(false), 1 == this.curTab) {
                            return;
                        }
                        this.curTab = 1;
                        this.updateTabView();
                        this.updateTabContent();
                    }
                    else if ("tab2" == t) {
                        if (4 == this.curTab && this.switchFastOrNormal(false), 2 == this.curTab) {
                            return;
                        }
                        this.curTab = 2;
                        this.updateTabView();
                        this.updateTabContent();
                    }
                    else if ("tab3" == t) {
                        if (4 == this.curTab && this.switchFastOrNormal(false), 3 == this.curTab) {
                            return;
                        }
                        this.curTab = 3;
                        this.updateTabView();
                        this.updateTabContent();
                    }
                    else if ("tab4" == t) {
                        if (4 == this.curTab) {
                            return;
                        }
                        this.switchFastOrNormal(true);
                        this.curTab = 4;
                        this.updateTabView();
                        this.updateTabContent();
                    }
                    else if ("next" == t) {
                        11 == this._selectPlayerNum ? this.dealShowCaptainSelectView() : Utils.shared().showToast(i18nMgr.shared().getValueByKey("yes11.ctip"), 3, 0, ToolUtils.getIsNormalDirection());
                    }
                    else if ("team_sort" == t) {
                        0 != this._curSortType ? this._curSortType = 0 : 0 == this._teamSortType ? this._teamSortType = 1 : this._teamSortType = 0;
                        this.reSortPlayerInfo();
                    }
                    else if ("pts_sort" == t) {
                        1 != this._curSortType ? this._curSortType = 1 : 0 == this._pointsSortType ? this._pointsSortType = 1 : this._pointsSortType = 0;
                        this.reSortPlayerInfo();
                    }
                    else if ("credits_sort" == t) {
                        2 != this._curSortType ? this._curSortType = 2 : 0 == this._creditsSortType ? this._creditsSortType = 1 : this._creditsSortType = 0;
                        this.reSortPlayerInfo();
                    }
                    else if ("sel_sort" == t) {
                        3 != this._curSortType ? this._curSortType = 3 : 0 == this._rateSortType ? this._rateSortType = 1 : this._rateSortType = 0;
                        this.reSortPlayerInfo();
                    }
                    else if ("preview" == t) {
                        this.dealPreviewLogic();
                    }
                    else if ("fast_create" == t) {
                        this.dealFastCreateLogic();
                    }
                    else if ("stat" == t) {
                        let e = { match_id: this._match_id, fromType: 1, source: this._source, lastNode: this.node };
                        SportCricket_Manager.shared().requestYes11_statTeamInfo(e, true);
                    }
                    else {
                        "add_chip" == t && (Utils.shared().showStoreView(null, null), User.shared().updatePayScene(PhpReportDefined.pay_scene.hall_cricket));
                    }
                }
                else {
                    Utils.shared().showToast(i18nMgr.shared().getValueByKey("yes11.cancel_tip"), 2);
                }
            }
            else {
                Utils.shared().showToast(i18nMgr.shared().getValueByKey("yes11.live_tip"), 2);
            }
        }
    }
    switchFastOrNormal(e) {
        this.rootNode.getChildByName("all_ScrollView").active = !e;
        this.rootNode.getChildByName("tab_top").active = !e;
        this.rootNode.getChildByName("score_tab").active = e;
        this.rootNode.getChildByName("fast_ScrollView").active = e;
        e && (this.bottomNode.getChildByName("tip").getComponent(Label).string = "Pick 11 Players");
    }
    updateTabContent() {
        this.curTab <= 3 ? this.reSortPlayerInfo() : this.dealFastCreateLogic();
    }
    onBackView(e = true) {
        e && (Utils.shared().hideLoading(), this.bShowPushAnim ? (this._closed = true, ToolUtils.isObjValid(this._lastNode) && (this._lastNode.active = true), ToolUtils.showPushAnim(this.node, 1, (() => {
            ToolUtils.isObjValid(this.node) && this.node.destroy();
        }))) : (ToolUtils.isObjValid(this._lastNode) && (this._lastNode.active = true), ToolUtils.isObjValid(this.node) && this.node.destroy()));
    }
    fitScreen() {
        ToolUtils.adaptSafeArea(this.rootNode);
        let e = sys.getSafeAreaRect().y, t = view.getVisibleSize();
        if (this.node.getComponent(UITransform).setContentSize(t.width, t.height), 0 != e) {
            let t = this.rootNode.getChildByName("all_ScrollView").getComponent(Widget).bottom;
            this.rootNode.getChildByName("all_ScrollView").getComponent(Widget).bottom = t - e;
            t = this.rootNode.getChildByName("bottom_node").getComponent(Widget).bottom;
            this.rootNode.getChildByName("bottom_node").getComponent(Widget).bottom = t - e;
            t = this.rootNode.getChildByName("fast_ScrollView").getComponent(Widget).bottom;
            this.rootNode.getChildByName("fast_ScrollView").getComponent(Widget).bottom = t - e;
        }
    }
}
