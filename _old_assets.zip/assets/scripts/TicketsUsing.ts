// @ts-nocheck
// Recovered from index.js:625
import { _decorator, Button, instantiate, Label, Node, ScrollView, size, Sprite, SpriteFrame, sys, UITransform, v3, view } from "cc";
import SoundManager from "./SoundManager";
import i18nMgr from "./i18nMgr";
import BaseLayer from "./BaseLayer";
import TweenTool from "./TweenTool";
import { ScrollviewUtils } from "./ScrollviewUtils";
import User from "./User";
import HttpManager from "./HttpManager";
import ReportConfig from "./ReportConfig";
import PushCenter from "./PushCenter";
import PushEvent from "./PushEvent";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("TicketsUsing")
export class TicketsUsing extends BaseLayer {
    @property(ScrollView)
    public scollview: ScrollView = null;
    @property([SpriteFrame])
    public ticket_images: SpriteFrame[] = [];
    @property(Node)
    public itemNode: Node = null;
    @property(Node)
    public bgNode: Node = null;
    public _scrollUtil: any = null;
    public listData: any[] = [];
    public _itemNodes: any[] = [];
    public _startY: number = 0;
    public _closeAct: any = null;
    public _startAct: any = null;
    public select_tk_no: string = "";
    public click_time: number = 0;
    public link_id: number = 0;
    onLoad() {
        this.fitScreen();
        this._scrollUtil = this.node.addComponent(ScrollviewUtils);
        this._scrollUtil.initScrollviewUtils(this.scollview);
        PushCenter.shared().addListener(PushEvent.CloseMatchTicketUsingView, (() => {
            this.node && this.node.active && this.onBackView();
        }), this);
    }
    start() {
        super.start();
        this.itemNode.active = false;
        this.link_id = sys.now();
        HttpManager.shared().doCommReportRechargeEvent(ReportConfig.Cmd_MatchTicket, 1, 8, this.link_id, null, 0);
        this.showSelectView();
        this.refreshListUi();
    }
    initParaData(t = null) {
        sys.isObjectValid(t) && sys.isObjectValid(t.data) && (this.listData = t.data);
    }
    ticketItem_click(t, e) {
        SoundManager.shared().playFx("click");
        for (let t = 0, i = this._itemNodes.length; t < i; t++) {
            let i = this._itemNodes[t];
            if (ToolUtils.isObjValid(i)) {
                i.getChildByName("select").active = Number(e) == t;
                Number(e) == t && this.listData.length > t && (this.select_tk_no = this.listData[t].tk_no);
            }
        }
        HttpManager.shared().doCommReportRechargeEvent(ReportConfig.Cmd_MatchTicket, 1, 7, this.link_id, null, 0);
    }
    initCurMobanCallBack(t, e, i) {
        if (null == e) {
            return;
        }
        t.active = true;
        let s = e.match_name, n = Number(e.discount), l = e.reward, o = e.tk_no, a = e.expries, u = t.getChildByName("ticket").getComponent(Sprite), g = t.getChildByName("circle"), m = t.getChildByName("select"), _ = t.getChildByName("flag_di"), f = t.getChildByName("flag_wz");
        t.getChildByName("name").getComponent(Label).string = s;
        let p = t.getChildByName("money").getComponent(Label), C = ToolUtils.parse_double(String(l), 0);
        sys.isObjectValid(e.mixed) && 1 == e.mixed && (C += "*");
        p.string = "₹" + C;
        t.getChildByName("discount").getComponent(Label).string = String(n);
        t.getChildByName("number").getComponent(Label).string = String(o);
        let b = t.getChildByName("date").getComponent(Label);
        0 != i18nMgr.shared().language && i18nMgr.shared().changeLabelFont(b);
        b.string = ToolUtils.format(i18nMgr.shared().getValueByKey("ticket.expired_date"), a);
        t.getComponent(Button).interactable = true;
        t.getComponent(Button).clickEvents[0].customEventData = String(i);
        u.spriteFrame = n >= 100 ? this.ticket_images[1] : this.ticket_images[0];
        g.active = true;
        m.active = 0 == i;
        0 == i && (this.select_tk_no = o);
        _.active = false;
        f.active = false;
    }
    refreshListUi() {
        if (sys.isObjectValid(this.listData) && Array.isArray(this.listData) && this.listData.length > 0) {
            Array.isArray(this.scollview.content.children) && this.scollview.content.children.length > 0 && this.scollview.content.removeAllChildren();
            let t, e = 0, i = 0, s = this.listData.length, n = this.itemNode.getComponent(UITransform).height, l = n;
            for (let i = 0; i < s; i++) {
                e = -i * l;
                ToolUtils.isObjValid(this._itemNodes[i]) ? (t = this._itemNodes[i], t.active = true, t.setPosition(v3(0, e)), this.scollview.content.addChild(t)) : (t = instantiate(this.itemNode), t.active = true, t.setPosition(v3(0, e)), this.scollview.content.addChild(t), this._itemNodes[i] = t);
                this.initCurMobanCallBack(t, this.listData[i], i);
            }
            let o = this.scollview.getComponent(UITransform).contentSize;
            i = l * (s - 1) + n;
            this.scollview.content.getComponent(UITransform).setContentSize(size(o.width, i));
            this._scrollUtil.setScollDetails2(1, 430, s, true);
        }
    }
    button_click(t, e) {
        if (SoundManager.shared().playFx("click"), "close" == e) {
            this.onBackView();
        }
        else if ("assure" == e) {
            if (sys.now() - this.click_time <= 1000) {
                return;
            }
            HttpManager.shared().doCommReportRechargeEvent(ReportConfig.Cmd_MatchTicket, 1, 9, this.link_id, null, 0);
            this.click_time = sys.now();
            User.shared().send_try_join_race_by_ticket(0, this.select_tk_no);
        }
    }
    fitScreen() {
    }
    onBackView() {
        ToolUtils.isObjValid(this.node) && this.hideSelectView();
    }
    showSelectView() {
        let t = -view.getVisibleSize().height / 2, e = this.bgNode.getComponent(UITransform).height;
        this._startY = t - e - 20;
        this.bgNode.setPosition(v3(0, this._startY));
        this._startAct = TweenTool.moveTo(this.bgNode, 0.2, v3(0, t), "sineIn", true);
    }
    hideSelectView() {
        this._startAct && TweenTool.stopAction(this._startAct);
        this._closeAct || (this._closeAct = TweenTool.moveTo(this.bgNode, 0.2, v3(0, this._startY), "sineIn", true, (() => {
            ToolUtils.isObjValid(this.node) && this.node.destroy();
        })));
    }
}
