// @ts-nocheck
// Recovered from index.js:229
import { director } from "cc";
import { TLog } from "./TLog";
export let init;
export let t;
export let updateSceneRenderers;
(init = o, t = function (e) {
    const t = window;
    if (!t.languages) {
        return e;
    }
    const n = e.split(".");
    let l = t.languages[_language];
    for (let e = 0; e < n.length; e++) {
        l = l[n[e]];
        l || (l = "");
    }
    if ("" === l) {
        TLog.printMsg("no i18 key:", e);
        l = t.languages.en;
        for (let e = 0; e < n.length; e++) {
            if (l = l[n[e]], !l) {
                return "";
            }
        }
    }
    return l || "";
}, updateSceneRenderers = g);
export let _language = "en";
export let ready = false;
function o(t) {
    ready = true;
    _language = t;
}
function g() {
    const e = director.getScene().children, t = [];
    for (let n = 0; n < e.length; ++n) {
        let r = e[n].getComponentsInChildren("LocalizedLabel");
        Array.prototype.push.apply(t, r);
    }
    for (let e = 0; e < t.length; ++e) {
        t[e].updateLabel();
    }
    const r = [];
    for (let t = 0; t < e.length; ++t) {
        let n = e[t].getComponentsInChildren("LocalizedSprite");
        Array.prototype.push.apply(r, n);
    }
    for (let e = 0; e < r.length; ++e) {
        r[e].updateSprite();
    }
}
(window._languageData = { get language() {
        return _language;
    }, init(e) {
        o(e);
    }, updateSceneRenderers() {
        g();
    } });
