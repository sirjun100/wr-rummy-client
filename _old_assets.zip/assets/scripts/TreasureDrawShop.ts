// @ts-nocheck
// Recovered from index.js:643
import { _decorator, color, Label, Node, SpriteAtlas, sys, Vec3 } from "cc";
import BaseLayer from "./BaseLayer";
import { ToolUtils } from "./ToolUtils";
import PushCenter from "./PushCenter";
import PushEvent from "./PushEvent";
import SoundManager from "./SoundManager";
import Utils from "./Utils";
import CommDefine from "./CommDefine";
import User from "./User";
import i18nMgr from "./i18nMgr";
const { ccclass, property } = _decorator;
@ccclass("TreasureDrawShop")
export class TreasureDrawShop extends BaseLayer {
    public TAG: string = "TreasureDrawShop";
    @property(Node)
    public rootNode: Node = null;
    @property(Node)
    public maskNode: Node = null;
    @property(Node)
    public content: Node = null;
    @property(Node)
    public btnConfirm: Node = null;
    @property(SpriteAtlas)
    public rewardPlist: SpriteAtlas = null;
    public rechargeNode: any[] = [];
    public isNext: boolean = false;
    public isquick: boolean = false;
    public _nVid: number = 0;
    public _linkId: number = 0;
    public _reportScene: any = -1;
    public _pop_souce: number = 0;
    public _has_close: boolean = false;
    public checkKyc: number = 0;
    public rechragePos: any[] = [];
    public _lastClick: number = 0;
    public btnLabelColor: any[] = [color(153, 153, 153, 255), color(0, 140, 22, 255)];
    public _goodsList: any[] = [];
    public _selItemIndex: number = 0;
    initParaData(e, t = 0) {
        this.isNext = e.isNext;
        sys.isObjectValid(e.vid) ? this._nVid = e.vid : this._nVid = ToolUtils.curRoomId;
        sys.isObjectValid(e) && (sys.isObjectValid(e.isquick) && (this.isquick = e.isquick), sys.isObjectValid(e.checkKyc) && (this.checkKyc = e.checkKyc), sys.isObjectValid(e.pop_souce) && (this._pop_souce = e.pop_souce), sys.isObjectValid(e.reportScene) && (this._reportScene = e.reportScene), sys.isObjectValid(e.link_id) && e.link_id > 0 && (this._linkId = e.link_id), sys.isObjectValid(e.goods_list) && Array.isArray(e.goods_list) && (this._goodsList = e.goods_list || []));
    }
    start() {
        super.start();
        this._linkId = this._linkId > 0 ? this._linkId : sys.now();
        this._reportScene = this._reportScene >= 0 ? this._reportScene : ToolUtils.getIsInRoom() ? 2 : 1;
        this.startShowAnim(this.rootNode);
        for (let e, t = 0; t < 4; t++) {
            if (e = this.content.getChildByName("item" + t), ToolUtils.isObjValid(e)) {
                this.rechargeNode[t] = e;
                let i = new Vec3;
                this.rechargeNode[t].getPosition(i);
                this.rechragePos.push(i);
            }
        }
        ToolUtils.showFullScreen(this.maskNode);
        sys.isObjectValid(this._goodsList) && this._goodsList && this.updateGoodsScrollView();
        PushCenter.shared().pushEvent(PushEvent.HideGameOverBg);
    }
    updateGoodsScrollView() {
        if (sys.isObjectValid(this._goodsList) && this._goodsList && Array.isArray(this._goodsList)) {
            for (let e = 0, t = this.rechargeNode.length; e < t; e++) {
                if (sys.isObjectValid(this._goodsList) && sys.isObjectValid(this._goodsList[e])) {
                    let t = this._goodsList[e];
                    this.rechargeNode[e].active = true;
                    this.initGoodsItemView(this.rechargeNode[e], t, e);
                }
                else {
                    this.rechargeNode[e].active = false;
                }
            }
            this.updateSelItemUI();
        }
    }
    initGoodsItemView(e, t, i) {
        if (!e || !t) {
            return;
        }
        let s = e.getChildByName("di"), r = e.getChildByName("select_di"), a = e.getChildByName("Node").getChildByName("ico"), o = e.getChildByName("Node").getChildByName("lab");
        s.active = true;
        r.active = false;
        sys.isObjectValid(t.type) && sys.isObjectValid(t.num) && (this.updateRewardSprite(a, t.type), o.getComponent(Label).string = t.num || "");
    }
    updateRewardSprite(e, t) {
        ToolUtils.isSafeString(CommDefine.rewardPistName[t]).length > 0 && Utils.shared().setImage(e, CommDefine.rewardPistName[t], this.rewardPlist);
    }
    updateSelItemUI() {
        if (!(sys.isObjectValid(this._goodsList) && this._goodsList && Array.isArray(this._goodsList) && [0, 1, 2, 3].includes(this._selItemIndex))) {
            return;
        }
        if (this._goodsList.length != this.rechargeNode.length) {
            return;
        }
        let e = this._goodsList[this._selItemIndex], t = this.btnConfirm.getChildByName("Node").getChildByName("lab");
        e && sys.isObjectValid(e.buy_price) && (t.getComponent(Label).string = e.buy_price);
        for (let e = 0, t = this.rechargeNode.length; e < t; e++) {
            let t = this.rechargeNode[e].getChildByName("di"), i = this.rechargeNode[e].getChildByName("select_di"), s = this.rechargeNode[e].getChildByName("Node").getChildByName("lab");
            t.active = this._selItemIndex != e;
            i.active = this._selItemIndex == e;
            s.getComponent(Label).color = this._selItemIndex == e ? this.btnLabelColor[1] : this.btnLabelColor[0];
        }
    }
    onButtonClick(e, t) {
        SoundManager.shared().playFx("click");
        "close" == t && (1 == this.checkKyc && Utils.shared().checkAddCashKyc(), this.onBackView());
    }
    onItemClick(e, t) {
        SoundManager.shared().playFx("click");
        let i = Number(t);
        i != this._selItemIndex && (this._selItemIndex = i, this.updateSelItemUI());
    }
    onBtnConfirmClick(e, t) {
        if (sys.now() - this._lastClick < 300) {
            return;
        }
        if (this._lastClick = sys.now(), SoundManager.shared().playFx("click"), !(sys.isObjectValid(this._goodsList) && this._goodsList && Array.isArray(this._goodsList) && [0, 1, 2, 3].includes(this._selItemIndex))) {
            return;
        }
        let i = this._goodsList[this._selItemIndex];
        if (i && sys.isObjectValid(i.buy_price) && sys.isObjectValid(i.num) && sys.isObjectValid(i.id)) {
            if (User.shared().data.money >= i.buy_price) {
                let e = ToolUtils.format(i18nMgr.shared().getValueByKey("treasuredraw.exchange_cont"), i.buy_price, i.num), t = { bLandscape: ToolUtils.getIsNormalDirection(), bWithCancel: true, strContent: e, strTitle: i18nMgr.shared().getValueByKey("treasuredraw.exchange_title"), dialogType: 2, lastNodeVisible: false, last_node: this.node };
                Utils.shared().showCommonAlert(t, (e => {
                    this.node.active = true;
                    1 === e && User.shared().requestTreasureDrawExchangeProp({ id: i.id }, (e => {
                        e && sys.isObjectValid(e.is_exchange) && sys.isObjectValid(e.key_num) && sys.isObjectValid(e.show_key) && (1 == e.is_exchange ? sys.isObjectValid(User.shared().treasuredrawData) && User.shared().treasuredrawData && sys.isObjectValid(User.shared().treasuredrawData.key_num) && (User.shared().treasuredrawData.key_num = e.key_num >= 0 ? e.key_num : 0, e.key_num && PushCenter.shared().pushEvent(PushEvent.UpdateTreasureDrawKey, e.key_num), Utils.shared().showToast(ToolUtils.format(i18nMgr.shared().getValueByKey("treasuredraw.exchange_succ_tips"), e.show_key), 2)) : Utils.shared().showToast(i18nMgr.shared().getValueByKey("treasuredraw.exchange_error"), 2));
                    }));
                }));
            }
            else {
                Utils.shared().showQuickRecharge(431, null, true, "", 0, i.buy_price);
            }
        }
    }
}
