// @ts-nocheck
// Recovered from index.js:265
import { _decorator, Component, game, Label, Node, sp, Sprite, SpriteFrame, tween, UIOpacity, v3 } from "cc";
import SoundManager from "./SoundManager";
const { ccclass, property } = _decorator;
@ccclass("LuckBallAnteWinPop")
export class LuckBallAnteWinPop extends Component {
    @property(Node)
    public bg: Node = null;
    @property(Node)
    public titleNode: Node = [];
    @property(Sprite)
    public qiuSp: Sprite = null;
    @property(SpriteFrame)
    public qiuIconArr: SpriteFrame = [];
    @property(Label)
    public daxiaoLabel: Label = null;
    @property(Label)
    public awardCountLabel: Label = null;
    @property(Label)
    public explainLabel: Label = null;
    @property(Label)
    public countDownLabel: Label = null;
    @property(Node)
    public animNode: Node = null;
    public countDownNum: number = 10000;
    public mcallback: any = null;
    public mTimeTypeList: any[] = [30, 60, 180];
    onLoad() {
        this.schedule((t => {
            this.countDownNum -= t;
            this.countDownNum <= 5 && this.countDownNum >= 0 ? (this.countDownLabel.string = `${Math.floor(this.countDownNum).toString()} seconds auto close`, 0 == Math.floor(this.countDownNum) && this.onCloseBtn(null)) : this.countDownLabel.string = "";
        }));
    }
    setData(t, e) {
        SoundManager.shared().playFx("luckball_win");
        this.mcallback = e;
        let i = 1 / Number(game.frameRate);
        this.bg.scale = v3(0, 0, 0);
        tween(this.bg).sequence(tween(this.bg).to(7 * i, { scale: v3(1.2, 1.2) }), tween(this.bg).to(4 * i, { scale: v3(0.9, 0.9) }), tween(this.bg).to(4 * i, { scale: v3(1, 1) })).call((() => {
            this.countDownLabel.string = "3 seconds auto close";
            this.countDownNum = 5;
        })).start();
        this.titleNode[t.sicbo].getComponent(UIOpacity).opacity = 0;
        tween(this.titleNode[t.sicbo].getComponent(UIOpacity)).delay(4 * i).to(7 * i, { opacity: 255 }).call((() => {
        })).start();
        this.qiuSp.spriteFrame = this.qiuIconArr[t.num];
        1 == t.sicbo ? (this.daxiaoLabel.string = "BIG", this.animNode.getComponent(sp.Skeleton).setAnimation(0, "animation", false)) : this.daxiaoLabel.string = "SMALL";
        this.awardCountLabel.string = "₹" + t.win_score.toString();
        let n = this.mTimeTypeList[t.mode];
        this.explainLabel.string = `WinGo ${n >= 60 ? n / 60 + "Min" : n + "s"} | ${t.id}`;
    }
    onCloseBtn(t) {
        t && SoundManager.shared().playFx("click");
        this.mcallback && this.mcallback();
        this.node.destroy();
    }
}
