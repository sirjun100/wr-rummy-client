// @ts-nocheck
// Recovered from index.js:143
import { _decorator, Button, color, instantiate, Label, Node, ScrollView, sys, UITransform, v3 } from "cc";
import BaseLayer from "./BaseLayer";
import PushCenter from "./PushCenter";
import SoundManager from "./SoundManager";
import { ToolUtils } from "./ToolUtils";
import TableViewUtils from "./TableViewUtils";
import HttpManager from "./HttpManager";
import { HttpRequest } from "./HttpRequestName";
import TweenTool from "./TweenTool";
const { ccclass, property } = _decorator;
@ccclass("FruitSlotJackPot")
export class FruitSlotJackPot extends BaseLayer {
    public TAG: string = "FruitSlotJackPot";
    @property(Node)
    public root: Node = null;
    @property(Node)
    public moban: Node = null;
    @property(Node)
    public rate_moban: Node = null;
    @property(Node)
    public switchNode: Node = null;
    @property([Node])
    public switchItems: Node[] = [];
    @property([Node])
    public listTitles: Node[] = [];
    @property(Node)
    public scrollView: Node = null;
    @property(Node)
    public rateScrollView: Node = null;
    public _lastClick: number = 0;
    public _has_close: boolean = false;
    public gameCallback: any = null;
    public last_times: number = 0;
    public recordTabView: any = null;
    public scollToTop: boolean = false;
    public jackPotData: any[] = [];
    public rateHasInit: boolean = false;
    public _nType: number = 0;
    onLoad() {
    }
    start() {
        super.start();
        this.startShowAnim(this.root);
        ToolUtils.showFullScreen(this.node.getChildByName("bg"));
        this.initView();
    }
    initParaData(t) {
        sys.isObjectValid(t) && sys.isObjectValid(t.cb) && (this.gameCallback = t.cb);
    }
    initView() {
        let t = [this.moban];
        this.recordTabView = this.node.addComponent(TableViewUtils);
        let e = this.moban.getComponent(UITransform).height;
        this.recordTabView.init([], this.scrollView, t, this.initCurMobanCallBack.bind(this), 10, e, this.scrollRefreshCallBack.bind(this));
        this.scollToTop = true;
        this.updateSwitchStatus(0);
        this.requestRecord();
    }
    updateSwitchStatus(t) {
        for (let e = 0, i = this.switchItems.length; e < i; e++) {
            let i = this.switchItems[e], a = i.getChildByName("wz"), s = i.getChildByName("line"), l = i.getChildByName("di");
            if (e == t) {
                if (i.getComponent(Button).interactable = false, a.getComponent(Label).color = color(203, 50, 50, 255), s.active = true, this._nType != t) {
                    s.scale = v3(0, 1, 1);
                    let t = TweenTool.scaleTo(s, 0.16, v3(1.1, 1, 1), null, false), e = TweenTool.scaleTo(s, 0.16, v3(1, 1, 1), null, false);
                    TweenTool.sequence(s, true, null, t, e);
                }
                else {
                    s.scale = v3(1, 1, 1);
                }
                l.active = false;
            }
            else {
                i.getComponent(Button).interactable = true;
                a.getComponent(Label).color = color(154, 154, 154, 255);
                s.scale = v3(1, 1, 1);
                e == this._nType ? TweenTool.scaleTo(s, 0.1, v3(0.2, 1, 1), null, true, (() => {
                    s.scale = v3(1, 1, 1);
                    s.active = false;
                })) : s.active = false;
                l.active = true;
            }
            l.active = false;
        }
        this._nType = t;
        for (let t = 0, e = this.listTitles.length; t < e; t++) {
            t == this._nType ? this.listTitles[t].active = true : this.listTitles[t].active = false;
        }
    }
    initCurMobanCallBack(t, e) {
        null != e && (t.active = true, sys.isObjectValid(e.date_text) && (t.getChildByName("date").getComponent(Label).string = e.date_text), sys.isObjectValid(e.ratio) && (t.getChildByName("ratio").getComponent(Label).string = e.ratio), sys.isObjectValid(e.reward) && (t.getChildByName("reward").getComponent(Label).string = e.reward), sys.isObjectValid(e.win_name) && (t.getChildByName("winner").getComponent(Label).string = ToolUtils.GetShortName2(e.win_name, 20, false)));
    }
    requestRecord() {
        this.recordTabView.stopAutoScroll();
        HttpManager.shared().doGetCommonRequest({ last_times: this.last_times }, HttpRequest.GetGameFruitMachineJackPot, ((t, e, i) => {
            if (200 == i) {
                let t = ToolUtils.parseJson(e);
                if (0 == t.ret) {
                    if (0 == this._nType) {
                        if (this.last_times = t.data.last_times, sys.isObjectValid(t.data.list) && Array.isArray(t.data.list) && t.data.list.length > 0) {
                            for (let e = 0; e < t.data.list.length; e++) {
                                this.jackPotData.push(t.data.list[e]);
                            }
                        }
                        this.recordTabView.reloadData(this.jackPotData, this.scollToTop);
                        this.root.getChildByName("nodata").active = 0 == this.jackPotData.length;
                    }
                    sys.isObjectValid(t.data.ratio_table) && Array.isArray(t.data.ratio_table) && (this.rateHasInit || (this.rateHasInit = true, this.initRateTable(t.data.ratio_table)));
                }
            }
        }));
    }
    initRateTable(t) {
        let e = this.rateScrollView.getChildByName("view").getChildByName("content");
        for (let i = 0; i < t.length; i++) {
            let a = instantiate(this.rate_moban);
            a.active = true;
            let s = t[i];
            sys.isObjectValid(s.bet) && (a.getChildByName("bet").getComponent(Label).string = ToolUtils.parse_ChipNum2(s.bet));
            sys.isObjectValid(s.ratio_three) && (a.getChildByName("ratio3").getComponent(Label).string = s.ratio_three);
            sys.isObjectValid(s.ratio_four) && (a.getChildByName("ratio4").getComponent(Label).string = s.ratio_four);
            sys.isObjectValid(s.ratio_five) && (a.getChildByName("ratio5").getComponent(Label).string = s.ratio_five);
            e.addChild(a);
        }
    }
    scrollRefreshCallBack() {
        0 != this.last_times && (this.requestRecord(), this.scollToTop = false);
    }
    touchBtnEvent(t, e) {
        SoundManager.shared().playFx("click");
        sys.now() - this._lastClick < 500 || (this._lastClick = sys.now(), "close" == e ? this.onBackView() : "btn_record" == e ? (this.updateSwitchStatus(Number(0)), this.dealReqServerData(true)) : "radio" == e && (this.updateSwitchStatus(Number(1)), this.dealReqServerData(true)));
    }
    dealReqServerData(t) {
        t && (this.jackPotData = []);
        this.root.getChildByName("nodata").active = false;
        1 == this._nType ? this.rateHasInit ? (this.scrollView.active = false, this.rateScrollView.active = true, this.rateScrollView.getComponent(ScrollView).scrollToTop()) : (this.scrollView.active = false, this.rateScrollView.active = true, this.requestRecord()) : (this.scrollView.active = true, this.rateScrollView.active = false, this.scrollView.getComponent(ScrollView).scrollToTop(), this.last_times = 0, this.requestRecord());
    }
    onBackView() {
        ToolUtils.isObjValid(this.node) && (this.gameCallback && this.gameCallback[-1], this.node.destroy());
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().removeListenersByTag(this);
    }
}
