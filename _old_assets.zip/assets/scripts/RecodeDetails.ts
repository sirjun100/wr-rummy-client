// @ts-nocheck
// Recovered from index.js:379
import { _decorator, color, game, instantiate, Label, Node, Prefab, ScrollView, size, Sprite, SpriteAtlas, SpriteFrame, sys, UITransform, v3, Widget } from "cc";
import SoundManager from "./SoundManager";
import Utils from "./Utils";
import PushCenter from "./PushCenter";
import PushEvent from "./PushEvent";
import HttpManager from "./HttpManager";
import { HttpRequest } from "./HttpRequestName";
import BaseLayer from "./BaseLayer";
import User from "./User";
import i18nMgr from "./i18nMgr";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("RecodeDetails")
export class RecodeDetails extends BaseLayer {
    @property(Node)
    public topInfoNode: Node = null;
    @property(Label)
    public titleLabel: Label = null;
    @property(Node)
    public detailsNode: Node = null;
    @property(Node)
    public nomalInfoNode: Node = null;
    @property(Node)
    public matchInfoNode: Node = null;
    @property(Node)
    public recodeBtn: Node = null;
    @property([SpriteFrame])
    public bottom_card_img: SpriteFrame[] = [];
    @property(Prefab)
    public cardPrefab: Prefab = null;
    @property([SpriteAtlas])
    public smallCardAtlas: SpriteAtlas[] = [];
    @property([SpriteFrame])
    public game_status_img: SpriteFrame[] = [];
    public gtype: number = 0;
    public game_id: string = "";
    public game_time: number = 0;
    public gameInfoData: any = null;
    public gameDetailsData: any = null;
    public game_type: number = 0;
    public callback: any = null;
    public roundArray: any[] = [];
    public roundIndex: number = 0;
    public lastClick: number = 0;
    public movieIndex: number = 0;
    start() {
        super.start();
        ToolUtils.adaptSafeArea(this.node.getChildByName("root"));
        0 === this.game_type ? (this.nomalInfoNode.active = false, this.matchInfoNode.active = false, this.detailsNode.active = true, this.updateRoundNode(false), this.initTopNodeInfo(this.gameDetailsData), this.updateLaiziCard(true, this.gameDetailsData.ghost), this.updateGameDetailsInfo()) : (this.nomalInfoNode.active = true, this.matchInfoNode.active = false, this.detailsNode.active = false, this.updateLaiziCard(false), this.initTopNodeInfo(this.gameInfoData), this.updateRoundNode(true, 0), this.initNomalGameInfo(), sys.isObjectValid(User.shared().detalisIndex) && 0 != User.shared().detalisIndex && this.requestGameRecodeDetails(User.shared().detalisIndex));
        this.detailsNode.getChildByName("ScrollView").getComponent(ScrollView).node.getComponent(Widget).bottom = -ToolUtils.getSafeDistance();
    }
    initUI(e, t) {
        this.callback = t;
        this.gtype = e.gtype;
        this.game_id = e.game_id;
        this.game_time = e.game_time;
        3 == this.gtype || 27 == this.gtype ? (this.game_type = 0, this.titleLabel.string = "POINTS", this.gameDetailsData = e) : 30 == this.gtype || 31 == this.gtype ? (this.game_type = 1, this.titleLabel.string = "POOL", this.gameInfoData = e) : 28 != this.gtype && 32 != this.gtype || (this.game_type = 2, this.titleLabel.string = "DEALS", this.gameInfoData = e);
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().removeListenersByTag(this);
    }
    requestGameRecodeDetails(e, t = true) {
        let a = { gtype: this.gtype, game_id: this.game_id, game_time: this.game_time, round: e };
        t && Utils.shared().showLoading(10, false, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3);
        }));
        HttpManager.shared().doGetCommonRequest(a, HttpRequest.GameRecodeeDetail, this.listenGetGameRecodeDetailsback.bind(this));
    }
    listenGetGameRecodeDetailsback(e, t, a) {
        if (Utils.shared().hideLoading(), 0 != t.length) {
            if (200 != a) {
                alert("The login timed out, please try again");
            }
            else {
                try {
                    let e = ToolUtils.parseJson(t);
                    0 == e.ret && ToolUtils.isObjValid(this.node) && (this.gameDetailsData = e.data, this.nomalInfoNode.active = false, this.matchInfoNode.active = false, this.detailsNode.active = true, this.updateLaiziCard(true, this.gameDetailsData.ghost), this.gameDetailsData.round && this.updateRoundNode(true, this.gameDetailsData.round), this.updateGameDetailsInfo());
                }
                catch (e) {
                }
            }
        }
    }
    initNomalGameInfo() {
        this.updateRecodeStatus(true);
        let e = this.nomalInfoNode.getChildByName("di"), t = this.nomalInfoNode.getChildByName("ScrollView").getComponent(ScrollView);
        t.content.removeAllChildren();
        let a = this.nomalInfoNode.getChildByName("moban");
        if (a.active = false, t.node.getComponent(Widget).bottom = -ToolUtils.getSafeDistance(), sys.isObjectValid(this.gameInfoData)) {
            if (sys.isObjectValid(this.gameInfoData.rounds)) {
                for (let e = 0; e <= this.gameInfoData.rounds; e++) {
                    0 == e ? this.roundArray.push("ALL") : this.roundArray.push(ToolUtils.format("Round ${0}", e));
                }
            }
            if (sys.isObjectValid(this.gameInfoData.card_list) && this.gameInfoData.card_list.length > 0) {
                let i = this.gameInfoData.card_list.length;
                for (let e = 0; e < i; e++) {
                    let i = this.gameInfoData.card_list[e], s = instantiate(a);
                    s.active = true;
                    t.content.addChild(s);
                    let n = s.getChildByName("imageNodes");
                    n.getChildByName("me").active = 1 == i.is_me;
                    n.getChildByName("rebirth_di").active = i.rejoin > 0;
                    Utils.shared().updateHeadImg(n.getChildByName("kuang").getChildByName("head"), i.avatar, i.avatar_url, size(56, 56));
                    let l = s.getChildByName("LabelNodes"), d = l.getChildByName("name").getComponent(Label), r = l.getChildByName("scores").getComponent(Label), h = l.getChildByName("money").getComponent(Label), m = l.getChildByName("rebirth").getComponent(Label);
                    d.string = ToolUtils.GetShortName2(i.name, 12, true);
                    r.string = i.score;
                    m.node.active = i.rejoin > 0;
                    i.rejoin > 1 ? m.string = "REJOIN x" + i.rejoin : m.string = "REJOIN";
                    if (i.winnings_available === false || i.winnings == null) {
                        h.string = "—";
                        h.color = color(102, 102, 102);
                    } else i.winnings >= 0 ? (h.string = ToolUtils.format("+₹${0}", ToolUtils.parse_double(i.winnings + "")), h.color = color(0, 131, 21)) : (h.string = ToolUtils.format("-₹${0}", ToolUtils.parse_double(Math.abs(i.winnings) + "")), h.color = color(203, 41, 50));
                }
                e.getComponent(UITransform).contentSize = size(674, 100 * i + 70);
            }
            sys.isObjectValid(this.gameInfoData.movie_round) && (this.movieIndex = this.gameInfoData.movie_round);
        }
    }
    initTopNodeInfo(e) {
        let t = this.topInfoNode.getChildByName("label_nodes"), a = t.getChildByName("game_id").getComponent(Label), i = t.getChildByName("players").getComponent(Label), s = t.getChildByName("value").getComponent(Label), n = t.getChildByName("date").getComponent(Label);
        sys.isObjectValid(e) && (sys.isObjectValid(e.game_id) && (a.string = "" + e.game_id), sys.isObjectValid(e.player_count_text) && (i.string = "" + e.player_count_text), sys.isObjectValid(e.base_money) && (s.string = "" + e.base_money), sys.isObjectValid(e.date) && (n.string = "" + e.date));
        // Older saved hands do not contain the table stake; do not show an empty value.
        s.string = e && e.base_money !== undefined && e.base_money !== "" ? String(e.base_money) : "—";
        0 == this.game_type ? i18nMgr.shared().changeLabelLanguage(t.getChildByName("item3").getComponent(Label), "performance.value") : (i18nMgr.shared().changeLabelLanguage(t.getChildByName("item3").getComponent(Label), "choose_game.entry_fee"), 2 == i18nMgr.shared().language && (i18nMgr.shared().changeLabelLanguage(t.getChildByName("item3").getComponent(Label), "choose_game.entry_fee2"), t.getChildByName("item3").getComponent(Label).fontSize = 20, t.getChildByName("item3").getComponent(Label).lineHeight = 24));
    }
    updateRecodeStatus(e) {
        1 == User.shared().temp_pingbi.performance_playback && (e = false);
        this.recodeBtn.active = e;
    }
    updateLaiziCard(e, t) {
        let a = this.topInfoNode.getChildByName("label_nodes"), i = this.topInfoNode.getChildByName("img_nodes");
        if (a.getChildByName("joker").active = e, i.getChildByName("card_bg").active = e, i.getChildByName("card").active = e, e && t && (t > 0 || t < 80)) {
            let e = "s_rm_scard_" + ToolUtils.cardTo16(t);
            User.shared().styles[1] - 1 == 1 && (e = "s2_rm_scard_" + ToolUtils.cardTo16(t));
            Utils.shared().setImage(i.getChildByName("card"), e, this.smallCardAtlas[User.shared().styles[1] - 1]);
        }
    }
    updateRoundNode(e, t) {
        let a = this.topInfoNode.getChildByName("img_nodes"), i = this.topInfoNode.getChildByName("label_nodes");
        this.topInfoNode.getChildByName("round_btn").active = e;
        a.getChildByName("arrow").active = e;
        let s = i.getChildByName("round");
        s.active = e;
        e && null != t && (s.getComponent(Label).string = t > 0 ? ToolUtils.format("Round ${0}", t) : "Select Round");
    }
    updateGameDetailsInfo() {
        if (this.gameDetailsData) {
            this.gameDetailsData.my_card_row && this.initGameDetailsItemNode(this.detailsNode.getChildByName("mynode"), this.gameDetailsData.my_card_row, this.gameDetailsData.ghost);
            let e = this.detailsNode.getChildByName("ScrollView").getComponent(ScrollView);
            e.content.removeAllChildren();
            let t = this.detailsNode.getChildByName("moban");
            if (t.active = false, this.gameDetailsData.other_card_list) {
                let a = this.gameDetailsData.other_card_list;
                for (let i = 0, s = a.length; i < s; i++) {
                    let s = instantiate(t);
                    s.active = true;
                    this.initGameDetailsItemNode(s, a[i], this.gameDetailsData.ghost);
                    e.content.addChild(s);
                }
            }
            this.updateRecodeStatus(this.gameDetailsData.show_movie);
        }
    }
    initGameDetailsItemNode(e, t, a) {
        let i = e.getChildByName("imageNodes");
        sys.isObjectValid(t.is_tie) && 1 == t.is_tie ? i18nMgr.shared().changeSpriteLanguage(i.getChildByName("status"), "rummy_img.status_tie", this.game_status_img[4]) : this.game_status_img[t.end_result - 1] && (i.getChildByName("status").getComponent(Sprite).spriteFrame = this.game_status_img[t.end_result - 1]);
        i.getChildByName("rebirth_di").active = t.rejoin > 0;
        Utils.shared().updateHeadImg(i.getChildByName("kuang").getChildByName("head"), t.avatar, t.avatar_url, size(56, 56));
        let s = e.getChildByName("LabelNodes"), n = s.getChildByName("name").getComponent(Label), l = s.getChildByName("score").getComponent(Label), d = s.getChildByName("money").getComponent(Label), r = s.getChildByName("rebirth").getComponent(Label);
        n.string = ToolUtils.GetShortName2(t.name, 12, true);
        l.string = "Scores: " + t.score;
        r.node.active = t.rejoin > 0;
        t.rejoin > 1 ? r.string = "REJOIN x" + t.rejoin : r.string = "REJOIN";
        t.winnings >= 0 ? 0 === this.game_type ? (d.string = ToolUtils.format("+₹${0}", ToolUtils.parse_double(t.winnings + "")), d.color = color(0, 140, 22)) : 1 === this.game_type ? (t.winnings > 0 ? d.color = color(102, 102, 102) : d.color = color(0, 140, 22), d.string = ToolUtils.format("${0}", t.winnings)) : (d.string = ToolUtils.format("+${0}", t.winnings), d.color = color(0, 140, 22)) : 0 === this.game_type ? (d.string = ToolUtils.format("-₹${0}", ToolUtils.parse_double(Math.abs(t.winnings) + "")), d.color = color(203, 41, 50)) : 1 === this.game_type ? (d.string = ToolUtils.format("${0}", Math.abs(t.winnings)), d.color = color(102, 102, 102)) : (d.string = ToolUtils.format("-${0}", Math.abs(t.winnings)), d.color = color(102, 102, 102));
        let m = e.getChildByName("cardNodes");
        m.removeAllChildren();
        m.destroyAllChildren();
        let g = i.getChildByName("zhegai"), _ = 32, C = 54, D = 57 - _, I = -283, B = 3 == t.end_result || 4 == t.end_result ? 0 : 1;
        sys.isObjectValid(t.is_tie) && 1 == t.is_tie && (B = 0);
        if (0 === B) {
            let e, t;
            for (let i = 0; i < 13; i++) {
                e = instantiate(this.cardPrefab);
                e.name = ToolUtils.format("card_${0}", i);
                m.addChild(e);
                t = e.getComponent("RecodeCard");
                t.init(1, true, a);
                e.setPosition(v3(I + _ * i, 0));
            }
        }
        else {
            let e = null;
            try {
                e = ToolUtils.parseJson(t.cardinfos);
            }
            catch (e) {
            }
            if (e && e.length > 0) {
                let t = 0, i = 0, s = e.length;
                for (let t = 0; t < s; t++) {
                    let a = e[t];
                    null != a.cards && (i += a.cards.length);
                }
                0 == i && (i = 13);
                for (let o = 0; o < s; o++) {
                    let n = e[o];
                    if (null == n.cards) {
                        continue;
                    }
                    let l, d, r, h, g = n.cards.length;
                    _ = (455 - 3 * (s - 1) - s * C) / (1 * (i - s));
                    D = 57 - _;
                    for (let e = 0; e < g; e++) {
                        l = Number(n.cards[e]);
                        d = instantiate(this.cardPrefab);
                        d.name = ToolUtils.format("card_${0}_${1}", o, e);
                        m.addChild(d);
                        r = d.getComponent("RecodeCard");
                        r.init(l, false, a);
                        h = I + _ * t + D * o;
                        d.setPosition(v3(h, 0));
                        t += 1;
                    }
                }
                t = 0;
                for (let a = 0; a < s; a++) {
                    let o = e[a];
                    if (null == o.cards) {
                        continue;
                    }
                    let n = o.color, l = 0, d = o.cards.length, r = Math.floor(d / 2);
                    _ = (455 - 3 * (s - 1) - s * C) / (1 * (i - s));
                    D = 57 - _;
                    for (let e = 0; e < d; e++) {
                        let i = I + _ * t + D * a;
                        t += 1;
                        e == r && (l = i);
                    }
                    let h = instantiate(g);
                    h.name = ToolUtils.format("zhegai_${0}", a);
                    m.addChild(h);
                    0 == n || 1 == n ? h.getComponent(Sprite).spriteFrame = this.bottom_card_img[0] : 2 == n ? h.getComponent(Sprite).spriteFrame = this.bottom_card_img[2] : 3 == n && (h.getComponent(Sprite).spriteFrame = this.bottom_card_img[1]);
                    0 == Math.floor(d % 2) && (l -= _ / 2);
                    let p = (d - 1) * _ + C;
                    h.getComponent(UITransform).setContentSize(size(p, 12));
                    h.setSiblingIndex(100 + a);
                    h.setPosition(v3(l, -30));
                    let b = true;
                    h.active = b;
                }
            }
        }
    }
    onButtonClick(e, t) {
        if (SoundManager.shared().playFx("click"), "close" === t) {
            this.onBackView();
        }
        else if ("recode" === t) {
            if (sys.now() - this.lastClick < 1000) {
                return;
            }
            if (this.lastClick = sys.now(), 1 == Utils.shared().showFastKyc()) {
                return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("kyc.kyc_club_exchange"), 2);
            }
            0 == this.game_type || 0 != this.roundIndex ? PushCenter.shared().pushEvent(PushEvent.rummyPlayback, { game_id: this.game_id, round: this.roundIndex }) : this.movieIndex > 0 ? PushCenter.shared().pushEvent(PushEvent.rummyPlayback, { game_id: this.game_id, round: this.movieIndex }) : Utils.shared().showToast("No replay available for the current game", 2);
        }
        else {
            "round" === t && (this.roundIndex < 0 && (this.roundIndex = 0), Utils.shared().showSelectAreaView(this.node, (e => {
                let t = Number(e);
                User.shared().detalisIndex = Number(e);
                this.roundIndex = t;
                0 == t ? (this.nomalInfoNode.active = true, this.matchInfoNode.active = false, this.detailsNode.active = false, this.updateRecodeStatus(true), this.updateLaiziCard(false), this.updateRoundNode(true, 0)) : this.requestGameRecodeDetails(t, true);
            }), this.roundIndex, this.roundArray));
        }
    }
    onBackView() {
        3 != this.gtype && 27 != this.gtype && this.detailsNode.active ? (this.nomalInfoNode.active = true, this.matchInfoNode.active = false, this.detailsNode.active = false, this.updateRecodeStatus(true), this.updateLaiziCard(false), this.updateRoundNode(true, 0)) : (sys.isObjectValid(User.shared().performanceData) ? PushCenter.shared().pushEvent(PushEvent.showPerformanceView) : sys.isObjectValid(User.shared().walletPayDetailsData) && PushCenter.shared().pushEvent(PushEvent.showWalletPayDetailsView, User.shared().walletPayDetailsData), User.shared().detalisData = null, User.shared().detalisIndex = 0, this.scheduleOnce((() => {
            ToolUtils.isObjValid(this.node) && (this.callback && this.callback(), this.node.destroy());
        }), game.frameTime / 1000));
    }
}
