// @ts-nocheck
// Recovered from index.js:619
import { _decorator, Label, Node, RichText, ScrollView, size, sys, UITransform, view } from "cc";
import SoundManager from "./SoundManager";
import Utils from "./Utils";
import PushEvent from "./PushEvent";
import User from "./User";
import TableViewUtils from "./TableViewUtils";
import HttpManager from "./HttpManager";
import BaseLayer from "./BaseLayer";
import GameConfig from "./GameConfig";
import i18nMgr from "./i18nMgr";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("Tds")
export class Tds extends BaseLayer {
    @property(ScrollView)
    public scrollview: ScrollView = null;
    @property(Node)
    public moban: Node = null;
    @property(Node)
    public noData: Node = null;
    public tdsTabView: any = null;
    onLoad() {
        this.moban.active = false;
        this.noData.active = false;
        this.fitScreen();
    }
    start() {
        super.start();
        let t = [this.moban];
        this.tdsTabView = this.node.addComponent(TableViewUtils);
        let e = this.moban.getComponent(UITransform).height;
        this.tdsTabView.init([], this.scrollview.node, t, this.initCurMobanCallBack.bind(this), 20, e, this.scrollRefreshCallBack.bind(this));
        sys.isObjectValid(User.shared().tdsList) ? this.refreshTdsData() : Utils.shared().showLoading(10, true, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3);
        }));
        HttpManager.shared().doGetCommonRequest(null, "Tds.getList", ((t, e, s) => {
            if (Utils.shared().hideLoading(), 200 != s) {
                ;
            }
            else {
                let t = ToolUtils.parseJson(e);
                0 == t.ret && (User.shared().tdsList = t.data, ToolUtils.isObjValid(this.node) && this.refreshTdsData());
            }
        }));
    }
    scrollRefreshCallBack(t, e) {
    }
    refreshTdsData() {
        User.shared().tdsList && User.shared().tdsList.length > 0 ? (this.noData.active = false, this.tdsTabView.reloadData(User.shared().tdsList, true)) : this.noData.active = true;
    }
    initCurMobanCallBack(t, e) {
        let s = t.getChildByName("tds_from").getComponent(RichText), i = t.getChildByName("balance_date").getComponent(Label), a = t.getChildByName("winnings").getComponent(Label), n = t.getChildByName("withdrawals").getComponent(Label), o = t.getChildByName("deposits").getComponent(Label), l = t.getChildByName("balance").getComponent(Label), r = t.getChildByName("tds_winnings").getComponent(Label), c = t.getChildByName("tax").getComponent(Label), u = ToolUtils.format(i18nMgr.shared().getValueByKey("tds.tds_from"), e.sdate, e.edate);
        s.string = u;
        i18nMgr.shared().changeLabelFont(s);
        let g = ToolUtils.format(i18nMgr.shared().getValueByKey("tds.balance_on"), e.sdate);
        i.string = g;
        i18nMgr.shared().changeLabelFont(i);
        a.string = ToolUtils.parse_double(e.ABC);
        n.string = ToolUtils.parse_double(e.A);
        o.string = ToolUtils.parse_double(e.B);
        l.string = ToolUtils.parse_double(e.C);
        r.string = ToolUtils.parse_double(e.tds);
        c.string = ToolUtils.parse_double(e.tax);
    }
    onButtonClick(t, e) {
        SoundManager.shared().playFx("click");
        "close" == e ? ToolUtils.isObjValid(this.node) && this.node.destroy() : "help" == e && ToolUtils.isSafeString(ToolUtils.tds_policy_url).length > 0 && Utils.shared().doJumpLogic(PushEvent.JUMP_TO_TDSPolicy);
    }
    fitScreen() {
        let t = ToolUtils.adaptSafeArea(this.node.getChildByName("root")), e = sys.getSafeAreaRect().y - t, s = view.getVisibleSize(), i = this.scrollview.getComponent(UITransform).contentSize, a = s.height - GameConfig.CONFIG_SCREEN_HEIGHT + i.height - e;
        this.scrollview.getComponent(UITransform).contentSize = size(i.width, a);
    }
}
