// @ts-nocheck
// Recovered from index.js:175
import { _decorator, Label, Node } from "cc";
import i18nMgr from "./i18nMgr";
import Utils from "./Utils";
import LoadTableCpp from "./LoadTableCpp";
import User from "./User";
import SoundManager from "./SoundManager";
import PushEvent from "./PushEvent";
import BaseLayer from "./BaseLayer";
import { ToolUtils } from "./ToolUtils";
const { ccclass } = _decorator;
@ccclass("HallHelp")
export class HallHelp extends BaseLayer {
    start() {
        super.start();
        ToolUtils.adaptSafeArea(this.node.getChildByName("root"));
        let e = this.node.getChildByName("root").getChildByName("info_top").getChildByName("label_nodes");
        i18nMgr.shared().changeLabelLanguage(e.getChildByName("item1").getComponent(Label), "menu.how_to_play");
        i18nMgr.shared().changeLabelLanguage(e.getChildByName("item2").getComponent(Label), "menu.new_player_guide");
        i18nMgr.shared().changeLabelLanguage(e.getChildByName("item3").getComponent(Label), "menu.contact_us");
        i18nMgr.shared().changeLabelLanguage(e.getChildByName("item4").getComponent(Label), "menu.about_us");
    }
    clickCallback(e, t) {
        if (SoundManager.shared().playFx("click"), "how" === t) {
            Utils.shared().showRuleHelpView({ isEasy: User.shared().easy_mode_show, isMultiple: 1 == User.shared().multiple_rummy_open, isBump: 1 == User.shared().bump_rummy_open });
        }
        else if ("teaching" === t) {
            ToolUtils.in_isGuideRoom = 1;
            Utils.shared().showLoading(20, true);
            let e = new Node;
            e.addComponent(LoadTableCpp);
            this.node.addChild(e);
            e.name = "loadTableCpp";
            e.getComponent(LoadTableCpp).enterGameScene();
        }
        else {
            "contact" === t ? Utils.shared().doJumpLogic(PushEvent.JUMP_TO_CONTACT_US) : "about" === t ? Utils.shared().doJumpLogic(PushEvent.JUMP_TO_ABOUT_US) : "tc" === t ? Utils.shared().doCustomJump(PushEvent.Custom_TO_TC) : "privacy" === t ? Utils.shared().doJumpLogic(PushEvent.JUMP_TO_PrivacyPolicy) : "refund" === t ? Utils.shared().doJumpLogic(PushEvent.JUMP_TO_Refund) : "faq" === t ? Utils.shared().showFaqMain() : "close" === t && ToolUtils.isObjValid(this.node) && this.node.destroy();
        }
    }
}
