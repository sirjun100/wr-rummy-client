// @ts-nocheck
// Recovered from index.js:77
import { _decorator } from "cc";
const { ccclass } = _decorator;
@ccclass("CompressUtils")
export default class CompressUtils {
    static compress(t, s = null) {
        return zlib.deflateSync(t, { dictionary: s });
    }
    static uncompress(t, s = null) {
        return zlib.inflateSync(t, { dictionary: s });
    }
}
