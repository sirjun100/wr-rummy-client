// @ts-nocheck
// Recovered from index.js:687
import { _decorator, Button, color, EditBox, Label, Node, Sprite, SpriteFrame, sys, UITransform, v3 } from "cc";
import { TLog } from "./TLog";
import SoundManager from "./SoundManager";
import Utils from "./Utils";
import i18nMgr from "./i18nMgr";
import HttpManager from "./HttpManager";
import PushCenter from "./PushCenter";
import PushEvent from "./PushEvent";
import BaseLayer from "./BaseLayer";
import TweenTool from "./TweenTool";
import ReportConfig from "./ReportConfig";
import { ToolUtils } from "./ToolUtils";
import "./GameConfig";
const { ccclass, property } = _decorator;
@ccclass("Withdrawal_Edit")
export class Withdrawal_Edit extends BaseLayer {
    @property(EditBox)
    public numberEdit: EditBox = null;
    @property(EditBox)
    public confirmEdit: EditBox = null;
    @property(EditBox)
    public ifscEdit: EditBox = null;
    @property(Node)
    public titleNode: Node = null;
    @property(Node)
    public tipsNode: Node = null;
    @property(Node)
    public submitNode: Node = null;
    @property(Node)
    public inputNode: Node = null;
    @property(Node)
    public verify_btn: Node = null;
    @property(Node)
    public ruleNode: Node = null;
    @property(Node)
    public confirmNode: Node = null;
    @property([SpriteFrame])
    public tip_imgs: SpriteFrame[] = [];
    @property([SpriteFrame])
    public verifyBtnDiImags: SpriteFrame[] = [];
    public callback: any = null;
    public _accountData: any = null;
    public _has_edit: number = 0;
    public _keyboardHei: number = 740;
    public _closed: boolean = false;
    public _record_id: number = 0;
    public _account_check: number = 0;
    public _confirm_check: number = 0;
    public _ifsc_check: number = 0;
    public ifsc_err: number = 0;
    initData(t, e = null) {
        sys.isObjectValid(t) && (this._accountData = t, this._account_check = 1, this._confirm_check = 1, this._ifsc_check = 1, sys.isObjectValid(t.ifsc_err) && (this.ifsc_err = t.ifsc_err));
        this.callback = e;
    }
    start() {
        super.start();
        1 == this._account_check ? this.titleNode.getComponent(Label).string = "Enter Bank Account Details" : this.titleNode.getComponent(Label).string = "Add Bank Account";
        this.node.getChildByName("root");
        ToolUtils.showFullScreen(this.ruleNode.getChildByName("mask"));
        ToolUtils.showFullScreen(this.confirmNode.getChildByName("mask"));
        this.refreshView();
        this.startShowAnim();
        PushCenter.shared().addListener(PushEvent.changeWebViewHeight, (t => {
            ToolUtils.isObjValid(this.node);
        }), this);
    }
    startShowAnim() {
        this.node.getChildByName("bg").getComponent(UITransform).contentSize;
        let t = v3(0, 0);
        this.node.getChildByName("root").getChildByName("cnt").setPosition(v3(0, -1035, 0));
        TweenTool.moveTo(this.node.getChildByName("root").getChildByName("cnt"), 0.15, t, "fade", true, (() => {
            this.node.getChildByName("root").getChildByName("cnt").setPosition(t);
        }));
    }
    refreshView() {
        sys.isObjectValid(this._accountData) && (sys.isObjectValid(this._accountData.w_account) && (this.numberEdit.string = this._accountData.w_account), sys.isObjectValid(this._accountData.w_account) && (this.confirmEdit.string = this._accountData.w_account), sys.isObjectValid(this._accountData.w_ifsc) && (this.ifscEdit.string = this._accountData.w_ifsc), this.dealFirstLogic());
        this.checkBtnStatus();
    }
    dealFirstLogic() {
        if (0 == this.ifsc_err) {
            return;
        }
        let t = this.inputNode.getChildByName("ac_num_node"), e = this.inputNode.getChildByName("confirm_node"), i = this.inputNode.getChildByName("ifsc_node");
        0 == this._has_edit ? (t.getChildByName("bg").getComponent(Sprite).color = color(170, 0, 0), t.getChildByName("status").active = true, e.getChildByName("bg").getComponent(Sprite).color = color(170, 0, 0), e.getChildByName("status").active = true, i.getChildByName("bg").getComponent(Sprite).color = color(170, 0, 0), i.getChildByName("status").active = true) : 1 == this._has_edit && (t.getChildByName("bg").getComponent(Sprite).color = color(177, 177, 177), t.getChildByName("status").active = true, e.getChildByName("bg").getComponent(Sprite).color = color(177, 177, 177), e.getChildByName("status").active = true, i.getChildByName("bg").getComponent(Sprite).color = color(177, 177, 177), i.getChildByName("status").active = true, this.dealConfirmAccountNoLogic(), this.dealIfscNoLogic(), this.dealAccountNoLogic());
        this.inputNode.getChildByName("title_error").active = true;
        this.submitNode.getChildByName("bottem_err").active = true;
    }
    onTextChanged(t, e, i) {
    }
    onTextIfscChanged(t, e, i) {
        let s = e.string;
        s.length > 0 && (s = s.toUpperCase(), e.string = s);
    }
    dealAccountNoLogic() {
        let t = this.numberEdit.string;
        if (t.length < 8) {
            return this.inputNode.getChildByName("account_error").active = true, this.inputNode.getChildByName("account_error").getComponent(Label).string = "Number should be between 8 ~ 20 digits", this.inputNode.getChildByName("ac_num_node").getChildByName("status").active = true, this.inputNode.getChildByName("ac_num_node").getChildByName("status").getComponent(Sprite).spriteFrame = this.tip_imgs[0], void (this._account_check = 0);
        }
        this._account_check = 1;
        this.inputNode.getChildByName("account_error").active = false;
        this.inputNode.getChildByName("ac_num_node").getChildByName("status").active = true;
        this.inputNode.getChildByName("ac_num_node").getChildByName("status").getComponent(Sprite).spriteFrame = this.tip_imgs[1];
        sys.isObjectValid(this._accountData) && sys.isObjectValid(this._accountData.w_account) && t != this._accountData.w_account && (this.submitNode.getChildByName("bottem_err").active = false);
    }
    dealConfirmAccountNoLogic() {
        let t = this.confirmEdit.string;
        return t.length < 8 ? (this.inputNode.getChildByName("confirm_error").active = true, this.inputNode.getChildByName("confirm_error").getComponent(Label).string = "Number should be between 8 ~ 20 digits", this.inputNode.getChildByName("confirm_node").getChildByName("status").active = true, this.inputNode.getChildByName("confirm_node").getChildByName("status").getComponent(Sprite).spriteFrame = this.tip_imgs[0], void (this._confirm_check = 0)) : t != this.numberEdit.string ? (this.inputNode.getChildByName("confirm_error").active = true, this.inputNode.getChildByName("confirm_error").getComponent(Label).string = "Please enter the same number", this.inputNode.getChildByName("confirm_node").getChildByName("status").active = true, this.inputNode.getChildByName("confirm_node").getChildByName("status").getComponent(Sprite).spriteFrame = this.tip_imgs[0], void (this._confirm_check = 0)) : (this._confirm_check = 1, this.inputNode.getChildByName("confirm_error").active = false, this.inputNode.getChildByName("confirm_node").getChildByName("status").active = true, void (this.inputNode.getChildByName("confirm_node").getChildByName("status").getComponent(Sprite).spriteFrame = this.tip_imgs[1]));
    }
    dealIfscNoLogic() {
        let t = this.ifscEdit.string;
        return t.length < 11 ? (this.inputNode.getChildByName("ifsc_error").active = true, this.inputNode.getChildByName("ifsc_error").getComponent(Label).string = "Invalid lFSC, lFSC is an 11 digit alphanumeric code", this.inputNode.getChildByName("ifsc_node").getChildByName("status").active = true, this.inputNode.getChildByName("ifsc_node").getChildByName("status").getComponent(Sprite).spriteFrame = this.tip_imgs[0], void (this._ifsc_check = 0)) : "0" != t.charAt(4) ? (this.inputNode.getChildByName("ifsc_error").active = true, this.inputNode.getChildByName("ifsc_error").getComponent(Label).string = "Invalid lFSC, the fifth character from the front is 0", this.inputNode.getChildByName("ifsc_node").getChildByName("status").active = true, this.inputNode.getChildByName("ifsc_node").getChildByName("status").getComponent(Sprite).spriteFrame = this.tip_imgs[0], void (this._ifsc_check = 0)) : /^[A-Za-z0-9]+$/.test(t) ? (this._ifsc_check = 1, this.inputNode.getChildByName("ifsc_error").active = false, this.inputNode.getChildByName("ifsc_node").getChildByName("status").active = true, this.inputNode.getChildByName("ifsc_node").getChildByName("status").getComponent(Sprite).spriteFrame = this.tip_imgs[1], void (sys.isObjectValid(this._accountData) && sys.isObjectValid(this._accountData.w_ifsc) && t != this._accountData.w_ifsc && (this.submitNode.getChildByName("bottem_err").active = false))) : (this.inputNode.getChildByName("ifsc_error").active = true, this.inputNode.getChildByName("ifsc_error").getComponent(Label).string = "Invalid lFSC, Special characters cannot be included", this.inputNode.getChildByName("ifsc_node").getChildByName("status").active = true, this.inputNode.getChildByName("ifsc_node").getChildByName("status").getComponent(Sprite).spriteFrame = this.tip_imgs[0], void (this._ifsc_check = 0));
    }
    onConfirmTextEnd(t, e, i) {
        this._has_edit += 1;
        this.dealFirstLogic();
        this.dealConfirmAccountNoLogic();
        this.checkBtnStatus();
        this.restoreScrollviewTop();
    }
    onIfscTextEnd(t, e, i) {
        this._has_edit += 1;
        this.dealFirstLogic();
        this.dealIfscNoLogic();
        this.checkBtnStatus();
        this.restoreScrollviewTop();
    }
    onNumberTextEnd(t, e, i) {
        this._has_edit += 1;
        this.dealFirstLogic();
        this.dealAccountNoLogic();
        this.checkBtnStatus();
        this.restoreScrollviewTop();
    }
    checkBtnStatus() {
        1 == this._account_check && 1 == this._confirm_check && 1 == this._ifsc_check ? this.verify_btn.getComponent(Sprite).spriteFrame = this.verifyBtnDiImags[1] : this.verify_btn.getComponent(Sprite).spriteFrame = this.verifyBtnDiImags[0];
    }
    onTextNumberBegan(t) {
        this.showScrollivewUp(this.numberEdit.node);
    }
    onTextConfirmBegan(t) {
        this.showScrollivewUp(this.confirmEdit.node);
    }
    onTextIFSCBegan(t) {
        this.showScrollivewUp(this.ifscEdit.node);
    }
    button_click(t, e) {
        SoundManager.shared().playFx("click");
        "close" == e ? this.onBackView() : "okay" == e ? (this.restoreScrollviewTop(), 1 == this._account_check && 1 == this._confirm_check && 1 == this._ifsc_check ? sys.isObjectValid(this._accountData) && sys.isObjectValid(this._accountData.record_id) && this.numberEdit.string == this._accountData.w_account && this.ifscEdit.string == this._accountData.w_ifsc ? this.dealConfirmLogic() : this.requestEditWithdrawAccount() : (this.dealAccountNoLogic(), this.dealConfirmAccountNoLogic(), this.dealIfscNoLogic())) : "about_ifsc" == e ? (this.ruleNode.active = true, ToolUtils.startShowAnim(this.ruleNode.getChildByName("bg"))) : "close_rule" == e ? this.ruleNode.active = false : "close_confirm" == e || "confirm_change" == e ? this.confirmNode.active = false : "confirm_submit" == e && this.requestEditWithdrawAccount();
    }
    dealConfirmLogic() {
        this.confirmNode.active = true;
        ToolUtils.startShowAnim(this.confirmNode.getChildByName("bg"));
        let t = this.confirmNode.getChildByName("bg").getChildByName("board1");
        sys.isObjectValid(this._accountData.w_account) && (t.getChildByName("acoount").getComponent(Label).string = this._accountData.w_account);
        sys.isObjectValid(this._accountData.w_ifsc) && (t.getChildByName("ifsc").getComponent(Label).string = this._accountData.w_ifsc);
        let e = this.confirmNode.getChildByName("bg").getChildByName("board0");
        e.getChildByName("acoount").getComponent(Label).string = this.numberEdit.string;
        e.getChildByName("ifsc").getComponent(Label).string = this.ifscEdit.string;
    }
    showVerifyBtnStatus(t) {
        1 == t ? (this.verify_btn.getComponent(Button).interactable = true, this.verify_btn.getChildByName("di").getComponent(Sprite).spriteFrame = this.verifyBtnDiImags[1], this.verify_btn.getChildByName("di").active = true) : 0 == t && (this.verify_btn.getComponent(Button).interactable = true, this.verify_btn.getChildByName("di").getComponent(Sprite).spriteFrame = this.verifyBtnDiImags[0], this.verify_btn.getChildByName("di").active = true);
    }
    requestEditWithdrawAccount() {
        let t = { w_account: this.numberEdit.string, repeat_account: this.confirmEdit.string, w_ifsc: this.ifscEdit.string };
        sys.isObjectValid(this._accountData) && sys.isObjectValid(this._accountData.record_id) && (t.record_id = this._accountData.record_id);
        Utils.shared().showLoading(10, false, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3);
        }));
        HttpManager.shared().doGetCommonRequest(t, "WithdrawAcc.doSaveV3", ((t, e, i) => {
            if (Utils.shared().hideLoading(), 200 != i) {
                ToolUtils.isObjValid(this.node) && (Utils.shared().showToast(i18nMgr.shared().getValueByKey("withdraw.tips10"), 2), HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Withdraw, event: ReportConfig.hall_evt.withdraw_submit_fail, err_code: i }));
            }
            else {
                try {
                    let t = ToolUtils.parseJson(e);
                    if (ToolUtils.isObjValid(this.node)) {
                        if (0 === t.ret) {
                            this._record_id = t.data.record_id;
                            sys.isObjectValid(this.callback) && this.callback(t.data);
                            Utils.shared().showToast("The bank account has been submitted.", 2);
                            this.confirmNode.active = false;
                            sys.isObjectValid(this._accountData) && sys.isObjectValid(this._accountData.record_id) && PushCenter.shared().pushEvent(PushEvent.RefreshWithdrawRecord);
                            this.onBackView();
                        }
                        else if (Utils.shared().hideLoading(), ToolUtils.isObjValid(this.node)) {
                            t.desc && ToolUtils.isSafeString(t.desc).length > 0 && Utils.shared().showToast(t.desc, 2);
                            let e = t.ret + ToolUtils.isSafeString(t.desc);
                            HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Withdraw, event: ReportConfig.hall_evt.withdraw_submit_fail, err_code: e });
                        }
                    }
                }
                catch (t) {
                    TLog.printError("trycatch requestAddWithdrawAccount,error:", t);
                }
            }
        }));
    }
    onCloseLogic() {
        this.onRemoveWindow();
    }
    onRemoveWindow() {
        this._closed || ToolUtils.isObjValid(this.node) && (this._closed = true, this.onBackView());
    }
    onBackView() {
        this.onCloseLogic();
        ToolUtils.isObjValid(this.node) && this.node.destroy();
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().removeListenersByTag(this);
    }
    showScrollivewUp(t) {
        if (ToolUtils.getIsInRoom()) {
            return;
        }
        if (sys.isBrowser) {
            return;
        }
        let e = v3(0, 0);
        this.node.getChildByName("root").getChildByName("cnt").inverseTransformPoint(e, t.getWorldPosition());
        ToolUtils.getIsInRoom();
        let i = e.y - 34 - 80;
        i < this._keyboardHei ? this.node.getChildByName("root").getChildByName("cnt").setPosition(v3(0, this._keyboardHei - i)) : this.node.getChildByName("root").getChildByName("cnt").setPosition(v3(0, 0));
    }
    restoreScrollviewTop() {
        this.node.getChildByName("root").getChildByName("cnt").setPosition(v3(0, 0));
    }
}
