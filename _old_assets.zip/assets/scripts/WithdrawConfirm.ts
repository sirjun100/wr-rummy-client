// @ts-nocheck
// Recovered from index.js:693
import { _decorator, Label, Node } from "cc";
import { TLog } from "./TLog";
import SoundManager from "./SoundManager";
import BaseLayer from "./BaseLayer";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("WithdrawConfirm")
export class WithdrawConfirm extends BaseLayer {
    @property(Node)
    public bank_node: Node = null;
    @property(Node)
    public upi_node: Node = null;
    public _callback: any = null;
    public _data: any = null;
    button_click(t, e) {
        SoundManager.shared().playFx("click");
        ToolUtils.isObjValid(this.node) && (this._data = e, this.onBackView());
    }
    start() {
        super.start();
        ToolUtils.startShowAnim(this.node.getChildByName("bgVIew"));
    }
    initData(t, e) {
        try {
            this._callback = e;
            let i = null;
            if (1 === Number(t.w_type)) {
                this.bank_node.active = false;
                this.upi_node.active = true;
                i = this.upi_node;
            }
            else if (4 === Number(t.w_type)) {
                this.bank_node.active = true;
                this.upi_node.active = false;
                i = this.bank_node;
                this.bank_node.getChildByName("ifsc").getComponent(Label).string = t.w_ifsc + "";
            }
            if (i) {
                let e = i.getChildByName("account").getComponent(Label), n = i.getChildByName("name").getComponent(Label), a = i.getChildByName("email").getComponent(Label), o = i.getChildByName("mobile").getComponent(Label);
                n.string = ToolUtils.getLimitLengthString(t.w_name, 10, false);
                e.string = ToolUtils.getLimitLengthString(t.w_account, 20, false);
                a.string = t.w_email + "";
                o.string = t.w_mobile + "";
            }
        }
        catch (t) {
            TLog.printError("trycatch WithdrawConfim initData:", t);
        }
    }
    update(t) {
    }
    onBackView() {
        ToolUtils.isObjValid(this.node) && (this._callback && this._callback(this._data), this.node.destroy());
    }
    onDestroy() {
        super.onDestroy();
    }
}
