// @ts-nocheck
// Recovered from index.js:421
import { _decorator, Button, Label, LabelShadow, Material, Node, Sprite, SpriteFrame, sys, v3 } from "cc";
import SoundManager from "./SoundManager";
import RummyDataManager, { RUMMY_GAME_TYPE, RUMMY_MATCH_MODE } from "./RummyDataManager";
import Utils from "./Utils";
import RummyCmd from "./RummyCmd";
import User from "./User";
import Server from "./Server";
import TweenTool from "./TweenTool";
import PushCenter from "./PushCenter";
import PushEvent from "./PushEvent";
import Parent, { AdapDirection } from "./Parent";
import i18nMgr from "./i18nMgr";
import CommDefine, { CheckModule } from "./CommDefine";
import { ToolUtils } from "./ToolUtils";
import GameConfig from "./GameConfig";
import PhpReportDefined from "./PhpReportDefined";
import HttpManager from "./HttpManager";
const { ccclass, property } = _decorator;
@ccclass("RummyAutoDrop")
export default class RummyAutoDrop extends Parent {
    @property(Node)
    public dropBtn: Node = null;
    @property(Node)
    public pingbi: Node = null;
    @property(Node)
    public bg: Node = null;
    @property(Node)
    public label1: Node = null;
    @property(Node)
    public label2: Node = null;
    @property(Node)
    public rootNode: Node = null;
    @property([SpriteFrame])
    public buttonImages: SpriteFrame[] = [];
    @property([Material])
    public buttonWzMats: Material[] = [];
    @property([SpriteFrame])
    public bonusImages: SpriteFrame[] = [];
    public tid_key: any = null;
    public dropType: number = 0;
    public red_shadow_color: any = CommDefine.shadowcolor.red;
    public green_shadow_color: any = CommDefine.shadowcolor.green;
    public _cb: any = null;
    public _bReportSwitch: boolean = false;
    public _bDropHigh: boolean = false;
    onLoad() {
        ToolUtils.showFullScreen(this.pingbi);
        ToolUtils.showFullScreen(this.bg);
        ToolUtils.showFullScreen(this.rootNode.getChildByName("mask"));
        ToolUtils.isPadPlatform() && this.resetUiPos(this.dropBtn, AdapDirection.Down, true, 1, false);
        this._bReportSwitch = ToolUtils.checkIsModuleReport(PhpReportDefined.module.room_drop_high);
    }
    setCallBack(e) {
        this._cb = e;
    }
    isshowAutoDropBtn(e, t) {
        this.dropBtn.active = e;
        this.tid_key = t;
        0 == RummyDataManager.shared().rummyInfos.get(t).auto_drop_type ? this.dropBtn.getChildByName("autogou").active = false : this.dropBtn.getChildByName("autogou").active = true;
    }
    setAutoDropBtn(e) {
    }
    isAutoDropSelect(e) {
        0 == e ? (this.pingbi.active = false, this.bg.active = false, this.label1.active = false, this.label2.active = false, this.dropBtn.getChildByName("autogou").active = false) : 1 == e ? (this.pingbi.active = true, this.bg.active = true, this.label1.active = true, this.label2.active = false, this.dropBtn.getChildByName("autogou").active = true) : 2 != e && 3 != e || (this.pingbi.active = true, this.bg.active = true, this.label1.active = false, this.label2.active = true, this.dropBtn.getChildByName("autogou").active = true);
    }
    checkHasShowDropAlert() {
        return this.rootNode.active;
    }
    touchBtnEvent(e, t) {
        if ("close" == t) {
            SoundManager.shared().playFx("click");
            this.removeGamePopNode();
            this.rootNode.active = false;
            this.pingbi.active = false;
            this.bg.active = false;
            this.label1.active = false;
            this.label2.active = false;
        }
        else if ("yes" == t) {
            SoundManager.shared().playFx("click");
            let e = RummyDataManager.shared().rummyInfos.get(this.tid_key);
            this._bReportSwitch && this._bDropHigh && HttpManager.shared().doReportClick({ module: PhpReportDefined.module.room_drop_high, scene: PhpReportDefined.scece.cash_room_drop, event: PhpReportDefined.room_drop_high_event.click_drop_and_stay, vid: e.vid });
            0 == this.dropType ? this.send_drop_card_request(1) : this.handler_auto_drop_request(this.tid_key, 1);
        }
        else if ("Dropgo" == t) {
            SoundManager.shared().playFx("click");
            let e = RummyDataManager.shared().rummyInfos.get(this.tid_key);
            this._bReportSwitch && this._bDropHigh && HttpManager.shared().doReportClick({ module: PhpReportDefined.module.room_drop_high, scene: PhpReportDefined.scece.cash_room_drop, event: PhpReportDefined.room_drop_high_event.click_drop_and_go, vid: e.vid });
            let t = 0;
            for (let i = 0; i < 6; i++) {
                let o = e.playerModels[i];
                1 != o.betting && 4 != o.status || (t += 1);
            }
            let i = 2;
            t <= 2 && (i = 1);
            (e.gameRummyType == RUMMY_GAME_TYPE.POINTS || e.gameRummyType == RUMMY_GAME_TYPE.MULTIPLE || this.checkIsPointsMatch()) && (0 == this.dropType ? this.send_drop_card_request(i) : this.handler_auto_drop_request(this.tid_key, i));
        }
        else if ("play" == t) {
            let e = RummyDataManager.shared().rummyInfos.get(this.tid_key);
            this._bReportSwitch && this._bDropHigh && HttpManager.shared().doReportClick({ module: PhpReportDefined.module.room_drop_high, scene: PhpReportDefined.scece.cash_room_drop, event: PhpReportDefined.room_drop_high_event.click_play_with_cash, entry_fee: ToolUtils.isSafeNumber(e.tf_venue.entry_fee), vid: e.vid, tf_venue: e.tf_venue });
            let t = User.shared().checkRoomCanPlayCashGame(CheckModule.CASH_PLAY, false);
            if (t < 2) {
                if (0 == t) {
                    let e = 0 == GameConfig.GAME_APP_THEME ? CommDefine.AppName_rummy : CommDefine.AppName_circ;
                    Utils.shared().showToast(ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_main.band_cash_game_tip"), e), 5);
                }
                return;
            }
            if (sys.isObjectValid(e.tf_venue)) {
                let t = ToolUtils.isSafeNumber(e.tf_venue.entry_fee);
                if (User.shared().data.money >= t) {
                    1 == this.dropType ? this.send_auto_drop_card_request(3) : this.send_drop_card_request(3);
                    this.hideDropNode();
                }
                else {
                    let t = false;
                    User.shared().data.money < e.tf_venue.entry_fee && (t = true);
                    Utils.shared().showQuickRecharge(e.tf_venue.vid, this.node, t, this.tid_key, 0, e.tf_venue.entry_fee);
                    User.shared().updatePayScene(PhpReportDefined.pay_scene.game_gameover_less_money, Number(e.tf_venue.vid));
                }
            }
        }
        else if ("bonus_gift" == t) {
            let e = RummyDataManager.shared().rummyInfos.get(this.tid_key), t = true;
            User.shared().data.money < e.entry_fee && (t = true);
            Utils.shared().showBonusRecharge(e.vid, null, t, this.tid_key, 0, e.entry_fee);
            0 == this.dropType ? this.send_drop_card_request(1) : this.handler_auto_drop_request(this.tid_key, 1);
        }
        else {
            if ("up_tocash_close" == t) {
                return RummyDataManager.shared().hasCloseUpToCashTips = true, void (this.rootNode.getChildByName("bgView2").getChildByName("notice_layer").getChildByName("play_tips").active = false);
            }
            if ("cash_play" == t) {
                let e = RummyDataManager.shared().rummyInfos.get(this.tid_key);
                this._bReportSwitch && this._bDropHigh && HttpManager.shared().doReportClick({ module: PhpReportDefined.module.room_drop_high, scene: PhpReportDefined.scece.cash_room_drop, event: PhpReportDefined.room_drop_high_event.click_play_with_cash, entry_fee: ToolUtils.isSafeNumber(e.force_up_venue.entry_fee), vid: e.vid, force_up_venue: e.force_up_venue });
                let t = User.shared().checkRoomCanPlayCashGame(CheckModule.CASH_PLAY, false);
                if (t < 2) {
                    if (0 == t) {
                        let e = 0 == GameConfig.GAME_APP_THEME ? CommDefine.AppName_rummy : CommDefine.AppName_circ;
                        Utils.shared().showToast(ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_main.band_cash_game_tip"), e), 5);
                    }
                    return;
                }
                if (sys.isObjectValid(e.force_up_venue)) {
                    let t = ToolUtils.isSafeNumber(e.force_up_venue.entry_fee);
                    if (User.shared().data.money >= t) {
                        this.hideDropNode();
                        this._cb && this._cb("cash_up_play");
                    }
                    else {
                        let i = false;
                        User.shared().data.money < t && (i = true);
                        Utils.shared().showQuickRecharge(e.force_up_venue.vid, this.node, i, this.tid_key, 0, e.force_up_venue.entry_fee);
                        User.shared().updatePayScene(PhpReportDefined.pay_scene.game_gameover_less_money, Number(e.force_up_venue.vid));
                    }
                }
            }
        }
        this.hideDropNode();
    }
    handler_auto_drop_request(e, t) {
        this.tid_key = e;
        let i = RummyDataManager.shared().rummyInfos.get(e);
        i.gameRummyType == RUMMY_GAME_TYPE.POOL || i.gameRummyType == RUMMY_GAME_TYPE.PRIVATE || i.gameRummyType == RUMMY_GAME_TYPE.PRI_POOL || i.gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL || i.gameRummyType == RUMMY_GAME_TYPE.DEALS || i.gameRummyType == RUMMY_GAME_TYPE.POINTS || i.gameRummyType == RUMMY_GAME_TYPE.MATCH || i.gameRummyType == RUMMY_GAME_TYPE.MULTIPLE ? 0 != i.auto_drop_type ? this.send_auto_drop_card_request(0) : this.send_auto_drop_card_request(t) : 0 != i.auto_drop_type ? this.send_auto_drop_card_request(0) : (this.pushGamePopNode(), this.pingbi.active = true, this.bg.active = true, this.rootNode.active = true);
    }
    send_drop_card_request(e) {
        RummyDataManager.shared().rummyInfos.get(this.tid_key)._drop_time = sys.now();
        let t = { cmd: RummyCmd.GM_DROP_CARD_REQUEST, uid: User.shared().data.uid, tid_key: this.tid_key, drop_type: e };
        Server.shared().send(t);
    }
    send_auto_drop_card_request(e) {
        let t = { cmd: RummyCmd.GM_AUTO_DROP_REQUEST, uid: User.shared().data.uid, tid_key: this.tid_key, auto_drop: e };
        RummyDataManager.shared().rummyInfos.get(this.tid_key)._pre_drop_type = e;
        Server.shared().send(t);
    }
    hideAllLayer() {
        this.removeGamePopNode();
        this.pingbi.active = false;
        this.bg.active = false;
        this.label1.active = false;
        this.label2.active = false;
        this.rootNode.active = false;
        this.dropBtn.active = false;
    }
    showDropNode(e, t, i, o, s, a = 0, r = false) {
        if (ToolUtils.isObjValid(this.rootNode)) {
            let n;
            this.pushGamePopNode();
            this.rootNode.active = true;
            this.dropType = i;
            this.tid_key = e;
            let p = this.rootNode.getChildByName("bgView2"), g = this.rootNode.getChildByName("bgView"), f = RummyDataManager.shared().rummyInfos.get(this.tid_key);
            if (this._bDropHigh = false, 1 == f.crashModel && sys.isObjectValid(f.tf_venue)) {
                n = p;
                p.active = true;
                g.active = false;
                let e = n.getChildByName("notice_layer");
                if (RummyDataManager.shared().hasCloseUpToCashTips) {
                    e.getChildByName("play_tips").active = false;
                }
                else if (RummyDataManager.shared().enterPracticeCount + 1 <= RummyDataManager.shared().rummyInfos.get(this.tid_key).tf_entry_tips_times) {
                    let t = sys.localStorage.getItem("tf_show_tips_count_" + User.shared().data.uid);
                    null == t || Number.isNaN(Number(t)) ? t = 1 : (t = Number(t), t += 1);
                    t <= RummyDataManager.shared().rummyInfos.get(this.tid_key).tf_max_tips_times ? (RummyDataManager.shared().enterPracticeCount += 1, ToolUtils.saveData("tf_show_tips_count_" + User.shared().data.uid, "" + t), e.getChildByName("play_tips").active = true) : e.getChildByName("play_tips").active = false;
                }
                else {
                    e.getChildByName("play_tips").active = false;
                }
                e.getChildByName("text1").getComponent(Label).string = t;
                let i = e.getChildByName("play_btn").getChildByName("Layout"), o = i.getChildByName("num"), s = i.getChildByName("Label");
                1 == i18nMgr.shared().language && (o.setSiblingIndex(0), s.setSiblingIndex(1));
                let a = o.getComponent(Label), r = ToolUtils.isSafeNumber(f.tf_venue.ispractice), _ = ToolUtils.isSafeNumber(f.tf_venue.base_money), u = 1 == r ? "" : "₹";
                a.string = u + ToolUtils.parse_double(String(_), -1);
            }
            else {
                p.active = false;
                g.active = true;
                n = g;
                let e = n.getChildByName("notice_layer");
                e.getChildByName("text1").getComponent(Label).string = t;
                f.gameRummyType == RUMMY_GAME_TYPE.MATCH || f.gameRummyType == RUMMY_GAME_TYPE.POOL || f.gameRummyType == RUMMY_GAME_TYPE.PRI_POOL || f.gameRummyType == RUMMY_GAME_TYPE.DEALS || f.gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL || (f.gameRummyType, RUMMY_GAME_TYPE.PRIVATE);
                e.getChildByName("bonus_tip").active = false;
                e.getChildByName("text1").setPosition(v3(0, 25));
                1 == f.crashModel && (e.getChildByName("bonus_tip").active = false, e.getChildByName("text1").setPosition(v3(0, 2)));
                let i = e.getChildByName("Exit_btn").getChildByName("wz"), c = e.getChildByName("start_btn").getChildByName("wz"), b = e.getChildByName("Exit_btn"), v = e.getChildByName("start_btn"), N = e.getChildByName("play_btn"), C = e.getChildByName("drop_stay_btn"), B = -154;
                if (v.getComponent(Button).clickEvents[0].customEventData = "Dropgo", this.dropType = 0, 0 == this.dropType && (f.gameRummyType == RUMMY_GAME_TYPE.POINTS || f.gameRummyType == RUMMY_GAME_TYPE.MULTIPLE) && f.force_up_venue && this.checkShowForceUpVenue()) {
                    B = -116;
                    b.active = false;
                    N.active = true;
                    v.active = true;
                    C.active = true;
                    v.setPosition(v3(119, B));
                    N.setPosition(v3(-119, B));
                    C.setPosition(v3(-119, B));
                    v.getChildByName("wz").getComponent(Label).string = i18nMgr.shared().getValueByKey("rummy_main.drop_go");
                    let e = N.getChildByName("Layout").getChildByName("num");
                    return sys.isObjectValid(f.force_up_venue) && sys.isObjectValid(f.force_up_venue.base_money) && (e.getComponent(Label).string = "₹" + f.force_up_venue.base_money), this._bReportSwitch && HttpManager.shared().doReportClick({ module: PhpReportDefined.module.room_drop_high, scene: PhpReportDefined.scece.cash_room_drop, event: PhpReportDefined.room_drop_high_event.show, vid: f.vid }), this._bDropHigh = true, void (N.active = false);
                }
                b.active = true;
                N.active = false;
                C.active = false;
                1 === a ? (b.setPosition(v3(-119, B)), v.setPosition(v3(119, B))) : (b.setPosition(v3(119, B)), v.setPosition(v3(-119, B)), r && (v.getComponent(Button).clickEvents[0].customEventData = "cancel"), f.gameRummyType != RUMMY_GAME_TYPE.POOL && f.gameRummyType != RUMMY_GAME_TYPE.PRI_POOL && f.gameRummyType != RUMMY_GAME_TYPE.DEALS && f.gameRummyType != RUMMY_GAME_TYPE.PRI_DEAL || (t == i18nMgr.shared().getValueByKey("rummy_main.drop_text1") ? (e.getChildByName("Exit_btn").getComponent(Sprite).spriteFrame = this.buttonImages[1], e.getChildByName("start_btn").getComponent(Sprite).spriteFrame = this.buttonImages[0], i.getComponent(Label).customMaterial = this.buttonWzMats[1], c.getComponent(Label).customMaterial = this.buttonWzMats[0], i.getComponent(LabelShadow).color = this.green_shadow_color, c.getComponent(LabelShadow).color = this.red_shadow_color) : (e.getChildByName("Exit_btn").getComponent(Sprite).spriteFrame = this.buttonImages[0], e.getChildByName("start_btn").getComponent(Sprite).spriteFrame = this.buttonImages[1], i.getComponent(Label).customMaterial = this.buttonWzMats[0], c.getComponent(Label).customMaterial = this.buttonWzMats[1], i.getComponent(LabelShadow).color = this.red_shadow_color, c.getComponent(LabelShadow).color = this.green_shadow_color)));
                e.getChildByName("Exit_btn").getChildByName("wz").getComponent(Label).string = o;
                e.getChildByName("start_btn").getChildByName("wz").getComponent(Label).string = s;
            }
            ToolUtils.startShowAnim(n);
            TweenTool.scaleTo(n, 0.2, v3(1, 1, 1), "backOut", true, (() => {
                n.setScale(v3(1, 1, 1));
            }));
        }
    }
    hideDropNode() {
        this.rootNode && this.rootNode.active && (this.removeGamePopNode(), this.rootNode.active = false);
    }
    pushGamePopNode() {
        if (0 == this.rootNode.active) {
            let e = { node: this.rootNode, tid_key: this.tid_key };
            PushCenter.shared().pushEvent(PushEvent.pushGamePopNode, e);
        }
    }
    removeGamePopNode() {
        if (this.rootNode.active) {
            let e = { node: this.rootNode, tid_key: this.tid_key };
            PushCenter.shared().pushEvent(PushEvent.removeGamePopNode, e);
        }
    }
    setAutoDropBtnMoney(e) {
        let t = this.dropBtn.getChildByName("goldNum");
        if (t) {
            let i = e + "";
            RummyDataManager.shared().rummyInfos.get(this.tid_key) && 1 == RummyDataManager.shared().rummyInfos.get(this.tid_key).crashModel && (i = ToolUtils.parse_ChipNum2(i));
            Utils.shared().setStr(t, i);
        }
    }
    checkIsPointsMatch() {
        let e = false, t = RummyDataManager.shared().rummyInfos.get(this.tid_key);
        return sys.isObjectValid(t) && t.gameRummyType == RUMMY_GAME_TYPE.MATCH && t.gameMatchMode == RUMMY_MATCH_MODE.PointsMatch && (e = true), e;
    }
    checkShowForceUpVenue() {
        let e = RummyDataManager.shared().rummyInfos.get(this.tid_key), t = false;
        return e.force_up_venue_tips_drop_touch_ts >= e.force_up_venue_tips_drop_times ? t = false : e.first_force_up_venue_tips_drop ? (e.first_force_up_venue_tips_drop = false, e.force_up_venue_tips_drop_touch_ts += 1, e.drop_tips_count = 0, t = true) : (e.drop_tips_count += 1, e.drop_tips_count >= e.force_up_venue_tips_drop_every && (e.force_up_venue_tips_drop_touch_ts += 1, e.drop_tips_count = 0, t = true)), RummyDataManager.shared().send_request_touch_drop_up_venue_alert(this.tid_key, t ? 1 : 0, 1, e.drop_tips_count), t;
    }
}
