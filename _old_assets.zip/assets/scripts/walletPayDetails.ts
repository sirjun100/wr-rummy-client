// @ts-nocheck
// Recovered from index.js:669
import { _decorator, Button, game, instantiate, isValid, Label, Node, size, sys, UITransform, v3, Vec3 } from "cc";
import PushCenter from "./PushCenter";
import Utils from "./Utils";
import User from "./User";
import SoundManager from "./SoundManager";
import HttpManager from "./HttpManager";
import i18nMgr from "./i18nMgr";
import PushEvent from "./PushEvent";
import BaseLayer from "./BaseLayer";
import { HttpRequest } from "./HttpRequestName";
import TweenTool from "./TweenTool";
import { TransferPlatform } from "./TransferPlatform";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("walletPayDetails")
export class walletPayDetails extends BaseLayer {
    @property(Label)
    public amount: Label = null;
    @property(Label)
    public todalNode: Label = null;
    @property(Node)
    public tipBtn: Node = null;
    @property(Node)
    public tipsDi: Node = null;
    @property(Node)
    public bgNode: Node = null;
    @property(Node)
    public moban: Node = null;
    @property(Node)
    public layout: Node = null;
    @property(Node)
    public detailsNode: Node = null;
    @property(Node)
    public help_node: Node = null;
    public id: number = 0;
    public loading: boolean = false;
    public callback: any = null;
    public amountPositions: any[] = [];
    public detailsInfo: any = null;
    public gst_id: string = "";
    public _isBack: boolean = false;
    onLoad() {
        this.amountPositions = [v3(-23.695, 14.492), v3(-21.461, 14.492)];
        this.fitScreen();
        this.dealMultipleLanguages();
    }
    dealMultipleLanguages() {
        2 == i18nMgr.shared().language && (this.moban.getChildByName("type").getComponent(Label).fontSize = 24, this.moban.getChildByName("content").getComponent(Label).fontSize = 22);
    }
    start() {
        super.start();
        PushCenter.shared().addListener(PushEvent.commentDownloaderFile, (t => {
            TransferPlatform.shared().openFileByApp(t, "application/pdf");
        }), this);
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().removeListenersByTag(this);
    }
    button_click(t, e) {
        if ("bg" !== e && SoundManager.shared().playFx("click"), "close" === e) {
            this.onBackView();
        }
        else if ("kefu" === e) {
            if (1 == User.shared().temp_pingbi.feedback) {
                return void Utils.shared().showToast("Coming soon", 2);
            }
            Utils.shared().doJumpLogic(PushEvent.JUMP_TO_FEEDBACK);
        }
        else if ("gst" == e) {
            let t = Utils.shared().checkDownNetFileExsits(this.gst_id, "pdf");
            1 == t.ret ? (Utils.shared().showToast(i18nMgr.shared().getValueByKey("store.gst_downloaded"), 2), TweenTool.delayAct(this.node, (() => {
                TransferPlatform.shared().openFileByApp(t.path, "application/pdf");
            }), 2, true)) : (Utils.shared().showToast(i18nMgr.shared().getValueByKey("store.gst_download"), 5), User.shared().requestGstDownUrl(this.gst_id, (t => {
                Utils.shared().downNetFile(t, this.gst_id, "pdf");
            })));
        }
        else if ("tip" === e) {
            this.tipsDi.active = !this.tipsDi.active;
        }
        else if ("bg" === e) {
            this.tipsDi.active = false;
        }
        else if ("details" === e && sys.isObjectValid(this.detailsInfo)) {
            let t = { gtype: this.detailsInfo.gtype, game_id: this.detailsInfo.game_id, game_time: this.detailsInfo.game_time };
            Utils.shared().showLoading(10, false, (() => {
                Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3);
            }));
            3 == this.detailsInfo.gtype || 27 == this.detailsInfo.gtype || 38 == this.detailsInfo.gtype ? HttpManager.shared().doGetCommonRequest(t, HttpRequest.GameRecodeeDetail, this.listenGetGameRecodeback.bind(this)) : HttpManager.shared().doGetCommonRequest(t, HttpRequest.GameRecodeInfo, this.listenGetGameRecodeback.bind(this));
        }
    }
    listenGetGameRecodeback(t, e, i) {
        if (Utils.shared().hideLoading(), 0 != e.length) {
            if (200 != i) {
                alert("The login timed out, please try again");
            }
            else {
                try {
                    let t = ToolUtils.parseJson(e);
                    0 == t.ret ? ToolUtils.isObjValid(this.node) && (User.shared().detalisData = t.data, PushCenter.shared().pushEvent(PushEvent.showRecodeDetailsView, t.data)) : t.desc && t.desc.length > 0 && Utils.shared().showToast(t.desc, 2);
                }
                catch (t) {
                }
            }
        }
    }
    fitScreen() {
        ToolUtils.adaptSafeArea(this.node.getChildByName("root"));
    }
    requestWallet() {
        this.loading = false;
        Utils.shared().showLoading(10, false);
        HttpManager.shared().doReportWalletGetOne(this.id, this.listenWalletPayCallback.bind(this));
    }
    setAmount(t) {
        Number(t) >= 0 ? this.amount.string = "+₹" + ToolUtils.parse_double(t) : this.amount.string = "-₹" + ToolUtils.parse_double(Math.abs(Number(t)) + "");
        this.checkShowTipBtn(ToolUtils.parse_double(Math.abs(Number(t)) + ""));
    }
    setID(t) {
        this.id = t;
    }
    setRootVisible(t) {
        this.node.getChildByName("root").active = t;
    }
    init(t, e = null) {
        if (User.shared().walletPayDetailsData = t, this.callback = e, !isValid(this.node, true)) {
            return;
        }
        if (null == t.data) {
            return;
        }
        if (t.data.alter >= 0 ? this.amount.string = "+₹" + ToolUtils.parse_double(t.data.alter) : this.amount.string = "-₹" + ToolUtils.parse_double(Math.abs(t.data.alter) + ""), this.checkShowTipBtn(ToolUtils.parse_double(Math.abs(t.data.alter) + "")), this.todalNode.string = t.data.current, sys.isObjectValid(t.data.list)) {
            for (let e = 0; e < t.data.list.length; e++) {
                let i = instantiate(this.moban);
                i.parent = this.layout;
                i.active = true;
                i.getChildByName("type").getComponent(Label).string = t.data.list[e].name;
                i.getChildByName("content").getComponent(Label).string = t.data.list[e].value;
            }
        }
        let i = instantiate(this.help_node);
        i.parent = this.layout;
        i.active = true;
        let a = i.getChildByName("bonus_tanstion");
        if (sys.isObjectValid(t.data.gst_id) && t.data.gst_id.length > 0 && (i.getChildByName("gstBtn").active = true, this.gst_id = t.data.gst_id, 2 == i18nMgr.shared().language && (i.getChildByName("gstBtn").getChildByName("wz").getComponent(Label).fontSize = 20)), sys.isObjectValid(t.data.bonus_boost_text)) {
            let e = t.data.bonus_boost_text;
            a.active = true;
            ToolUtils.isSafeString(this.gst_id).length > 0 ? a.setPosition(v3(0, -60)) : a.setPosition(v3(0, 0));
            a.getChildByName("rate").getComponent(Label).string = "+" + e;
            a.getChildByName("desc").getComponent(Label).string = `BONUS transtion extra ${e}`;
        }
        if (0 == User.shared().temp_pingbi.performance && sys.isObjectValid(t.data.game_id) && t.data.game_id.length > 0) {
            let e = instantiate(this.detailsNode);
            e.parent = this.layout;
            e.active = true;
            this.detailsInfo = { game_id: t.data.game_id, game_time: t.data.game_time, gtype: t.data.gtype };
        }
    }
    listenWalletPayCallback(t, e, i) {
        if (Utils.shared().hideLoading(), this.loading = true, 0 != e.length) {
            if (200 != i) {
                alert("The login timed out, please try again");
            }
            else {
                let t = ToolUtils.parseJson(e);
                if (0 == t.ret && this.loading) {
                    if (null == t.data) {
                        return;
                    }
                    t.data.alter >= 0 ? this.amount.string = "+₹" + ToolUtils.parse_double(t.data.alter) : this.amount.string = "-₹" + ToolUtils.parse_double(Math.abs(t.data.alter) + "");
                    this.checkShowTipBtn(ToolUtils.parse_double(Math.abs(t.data.alter) + ""));
                    this.todalNode.string = t.data.current;
                }
            }
        }
    }
    updateTitlePos(t) {
        let e = this.node.getChildByName("root").getChildByName("amount"), i = new Vec3;
        e.getPosition(i);
        1 == t ? e.setPosition(i) : 2 == t && e.setPosition(v3(i.x, i.y - 20, i.z));
    }
    checkShowTipBtn(t) {
        0 === Math.abs(Number(t)) ? (this.amount.node.setPosition(this.amountPositions[1]), this.tipBtn.active = true, this.bgNode.getComponent(Button).interactable = true, 1 === i18nMgr.shared().language && this.tipsDi.getComponent(UITransform).setContentSize(size(522, 70))) : (this.amount.node.setPosition(this.amountPositions[0]), this.tipBtn.active = false, this.bgNode.getComponent(Button).interactable = false);
    }
    onBackView() {
        this._isBack || (this._isBack = true, User.shared().walletPayDetailsData = null, sys.isObjectValid(User.shared().walletData_history) && PushCenter.shared().pushEvent(PushEvent.showWalletHistoryView, User.shared().walletData_history), this.scheduleOnce((() => {
            ToolUtils.isObjValid(this.node) && (this.callback && this.callback(), this.node.destroy());
        }), game.frameTime / 1000));
    }
}
