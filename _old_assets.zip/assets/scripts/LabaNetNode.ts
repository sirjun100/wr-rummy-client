// @ts-nocheck
// Recovered from index.js:223
import { _decorator, Component, director } from "cc";
import LabaServer from "./LabaServer";
import GameConfig from "./GameConfig";
import Base64 from "./Base64";
import { TLog } from "./TLog";
import CompressUtils from "./CompressUtils";
import { ToolUtils } from "./ToolUtils";
const { ccclass } = _decorator;
@ccclass("labaNetNode")
export default class LabaNetNode extends Component {
    onLoad() {
        LabaServer.shared().setCloseCb((() => {
        }));
    }
    onDestroy() {
        director.getScheduler().unschedule(this.onUpdate.bind(this), this);
    }
    start() {
        this.schedule(this.onUpdate.bind(this), 0.05);
    }
    onUpdate(e) {
        // Catch up after a stalled frame/background period; one packet per
        // rendered frame replays stale balances over a newer game settlement.
        const deadline = Date.now() + 4;
        for (let count = 0; count < 32; count++) {
            const message = LabaServer.shared().update(e);
            if (message == null) break;
            this.processMessage(message);
            if (!this.isValid || Date.now() >= deadline) break;
        }
    }
    processMessage(t) {
        if (null != t) {
            try {
                let e = null;
                if (1 == GameConfig.SOCKET_COMPRESS_SWITCH) {
                    let r = null;
                    "string" == typeof t ? (r = Base64.shared().decode(t), e = LabaServer.shared().arrayBuf2Str(LabaServer.shared().xorfunc(r))) : (r = CompressUtils.uncompress(new Uint8Array(t)), e = LabaServer.shared().arrayBuf2Str(LabaServer.shared().xorfunc(r)));
                }
                else {
                    let r = LabaServer.shared().arrayBuf2Str(LabaServer.shared().xorfunc(t));
                    e = Base64.shared().decode(r);
                }
                let r = ToolUtils.parseJson(e);
                r.cmd && (GameConfig.LABA_SOCKET_MSG_DEBUG, LabaServer.shared().dispatch(r.cmd, r));
            }
            catch (e) {
                TLog.printError("trycatch labaNetNode,error:", e);
            }
        }
    }
}
