// @ts-nocheck
// Recovered from index.js:339
import { _decorator, Button, color, director, Label, Layout, Node, Sprite, SpriteFrame, sys, UITransform, v3, Vec3, Widget } from "cc";
import BaseLayer from "./BaseLayer";
import Utils from "./Utils";
import User from "./User";
import PushEvent from "./PushEvent";
import PushCenter from "./PushCenter";
import BundleNameDefined from "./BundleNameDefined";
import TweenTool from "./TweenTool";
import { TransferPlatform } from "./TransferPlatform";
import SoundManager from "./SoundManager";
import i18nMgr from "./i18nMgr";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("PayOneForThreeRecharge")
export class PayOneForThreeRecharge extends BaseLayer {
    public TAG: string = "PayOneForThreeRecharge";
    @property(Node)
    public rootNode: Node = null;
    @property(Node)
    public maskNode: Node = null;
    @property(Node)
    public contentNode: Node = null;
    @property(Node)
    public bgNode: Node = null;
    @property(Node)
    public btnCloseNode: Node = null;
    @property(Node)
    public topNode: Node = null;
    @property(Node)
    public midNode: Node = null;
    @property(Node)
    public bottomNode: Node = null;
    @property(Node)
    public btnSubmit: Node = null;
    @property([SpriteFrame])
    public rewBtnBg: SpriteFrame[] = [];
    @property([SpriteFrame])
    public priceTabbg: SpriteFrame[] = [];
    @property([SpriteFrame])
    public dayIcons: SpriteFrame[] = [];
    @property([SpriteFrame])
    public rewardIcons: SpriteFrame[] = [];
    public rechargeNode: any[] = [];
    public isNext: boolean = false;
    public _linkId: number = 0;
    public _pop_souce: number = 0;
    public rechragePos: any[] = [];
    public _has_close: boolean = false;
    public _flag: number = 0;
    public _mPara: any[] = [];
    public _payOneForThreeData: any = null;
    public checkKyc: number = 0;
    public _finishAnim: any = undefined;
    public _needReqPage: boolean = true;
    public _priceTabIndex: number = 0;
    initParaData(e) {
        this._mPara = e;
        this.isNext = e.isNext;
        sys.isObjectValid(e.flag) && (this._flag = e.flag);
        sys.isObjectValid(e.checkKyc) && (this.checkKyc = e.checkKyc);
        sys.isObjectValid(e) && sys.isObjectValid(e.pop_souce) && (this._pop_souce = e.pop_souce);
        sys.isObjectValid(e) && sys.isObjectValid(e.link_id) && e.link_id > 0 && (this._linkId = e.link_id);
        sys.isObjectValid(e.ext) && this.setBuyOneGetThreeData(e.ext);
        sys.isObjectValid(e.needReqPage) && (this._needReqPage = e.needReqPage);
    }
    setBuyOneGetThreeData(e = null) {
        sys.isObjectValid(e) && Object.keys(e).length > 0 && (this._payOneForThreeData = e, sys.isObjectValid(e.idx) && e.idx >= 0 && e.idx <= 2 && (this._priceTabIndex = e.idx));
    }
    start() {
        super.start();
        this._linkId = this._linkId > 0 ? this._linkId : sys.now();
        for (let e, t = 0; t < 3; t++) {
            if (e = this.bottomNode.getChildByName("item" + t), ToolUtils.isObjValid(e)) {
                this.rechargeNode[t] = e;
                let i = new Vec3;
                this.rechargeNode[t].getPosition(i);
                this.rechragePos.push(i);
            }
        }
        if (ToolUtils.showFullScreen(this.maskNode), sys.isObjectValid(this._payOneForThreeData) && this.refreshView(), this._needReqPage && (sys.isObjectValid(this._mPara.vid) && 0 != Number(this._mPara.vid) && sys.isObjectValid(this._payOneForThreeData) || User.shared().requestBuyOneGetThreePageData((e => {
            ToolUtils.isObjValid(this.node) && e && (this.setBuyOneGetThreeData(e), this.refreshView());
        }))), PushCenter.shared().addListener(PushEvent.CloseBuyOneGetThree, (e => {
            ToolUtils.isObjValid(this.node) && (this.isNext && PushCenter.shared().pushEvent(PushEvent.Update_NextPopActivity), this.node.destroy());
        }), this), PushCenter.shared().addListener(PushEvent.UpdateBuyOneGetThree, (e => {
            ToolUtils.isObjValid(this.node) && e && (this.setBuyOneGetThreeData(e), this.refreshView());
        }), this), PushCenter.shared().pushEvent(PushEvent.HideGameOverBg), director.getScene().name == BundleNameDefined.hall_scene) {
            for (let e = 0, t = this.rechargeNode.length; e < t; e++) {
                this.rechargeNode[e].active = false;
            }
        }
        this._finishAnim = false;
        this.startShowAnim2(this.rootNode, 1, (() => {
            if (director.getScene().name != BundleNameDefined.switch_scence) {
                let e = this._payOneForThreeData;
                if (e) {
                    for (let t = 0, i = this.rechargeNode.length; t < i; t++) {
                        if (TweenTool.stopNodeAction(this.rechargeNode[t]), ToolUtils.getIsInRoom()) {
                            this.rechargeNode[t].active = true;
                            this._finishAnim = true;
                        }
                        else {
                            this.rechargeNode[t].setPosition(v3(this.rechragePos[t].x + 660, this.rechragePos[t].y));
                            let i = TweenTool.delayAct(this.rechargeNode[t], (() => {
                                this._finishAnim = true;
                                sys.isObjectValid(e.good_list) && sys.isObjectValid(e.good_list[t]) && (this.rechargeNode[t].active = true);
                            }), 0.04 * t, false), r = TweenTool.moveToByFade(this.rechargeNode[t], 0.15, v3(this.rechragePos[t].x - 20, this.rechragePos[t].y), 0, 1, false), a = TweenTool.moveTo(this.rechargeNode[t], 0.1, v3(this.rechragePos[t].x + 15, this.rechragePos[t].y), null, false), s = TweenTool.moveTo(this.rechargeNode[t], 0.06, v3(this.rechragePos[t].x, this.rechragePos[t].y), null, false);
                            TweenTool.sequence(this.rechargeNode[t], true, (() => {
                            }), i, r, a, s);
                        }
                    }
                }
            }
        }));
        SoundManager.shared().playFx("act_popshow");
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().pushEvent(PushEvent.ShowGameOverBg);
        PushCenter.shared().removeListenersByTag(this);
        TweenTool.stopNodeAction(this.node);
        this.unscheduleAllCallbacks();
    }
    onEnable() {
        TransferPlatform.shared().setNormalFrameRate();
    }
    refreshView() {
        this.setNodePos();
        this.updatePriceTabUI();
        this.updateBottomUI();
    }
    getHaveBuyState() {
        let e = false;
        return sys.isObjectValid(this._payOneForThreeData) && this._payOneForThreeData && sys.isObjectValid(this._payOneForThreeData.have_buy) && (e = 1 == this._payOneForThreeData.have_buy), e;
    }
    getGoodList() {
        let e = [];
        return sys.isObjectValid(this._payOneForThreeData) && this._payOneForThreeData && sys.isObjectValid(this._payOneForThreeData.good_list) && Array.isArray(this._payOneForThreeData.good_list) && (e = this._payOneForThreeData.good_list), !Array.isArray(e) || e.length, e || [];
    }
    setNodePos() {
        let e = this.getHaveBuyState();
        this.midNode.active = !e;
        ToolUtils.getIsInRoom() || (this.midNode.setPosition(v3(0, 299)), e ? (this.btnCloseNode.setPosition(v3(318, 459)), this.bgNode.setPosition(v3(0, -95)), this.topNode.setPosition(v3(0, -50)), this.bottomNode.setPosition(v3(0, 41))) : (this.btnCloseNode.setPosition(v3(318, 508)), this.bgNode.setPosition(v3(0, -133)), this.topNode.setPosition(v3(0, 0)), this.bottomNode.setPosition(v3(0, 0))));
    }
    updateBottomUI() {
        let e = null, t = this.getHaveBuyState(), i = this.getGoodList();
        if (!i.length) {
            return;
        }
        if (!sys.isObjectValid(this._payOneForThreeData)) {
            return;
        }
        if (t && !sys.isObjectValid(this._payOneForThreeData.buy_price)) {
            return;
        }
        if (t) {
            for (let t = 0; t < i.length; t++) {
                if (sys.isObjectValid(i[t].price) && i[t].price && Number(i[t].price) == Number(this._payOneForThreeData.buy_price)) {
                    e = i[t];
                    break;
                }
            }
        }
        else {
            this._priceTabIndex >= 0 && sys.isObjectValid(i[this._priceTabIndex]) && i[this._priceTabIndex] && sys.isObjectValid(i[this._priceTabIndex].price) && i[this._priceTabIndex].price && (e = i[this._priceTabIndex]);
        }
        if (!(e && sys.isObjectValid(e.price) && sys.isObjectValid(e.origin_price) && sys.isObjectValid(e.reward) && e.reward && Array.isArray(e.reward) && e.reward.length)) {
            return;
        }
        sys.isObjectValid(this.rechargeNode) && Array.isArray(this.rechargeNode);
        for (let t = 0, i = this.rechargeNode.length; t < i; t++) {
            if (sys.isObjectValid(e.reward[t]) && sys.isObjectValid(e.reward[t].day) && e.reward[t].day && ToolUtils.isSafeNumber(e.reward[t].day) >= 1) {
                let i = e.reward[t];
                if (!sys.isObjectValid(i) || !sys.isObjectValid(i.day) || i.day > 3) {
                    break;
                }
                let r = 0, a = false, s = false;
                if (!sys.isObjectValid(this.rechargeNode[i.day - 1])) {
                    break;
                }
                let o = this.rechargeNode[i.day - 1].getChildByName("icon"), h = this.rechargeNode[i.day - 1].getChildByName("gou");
                if (this.rechargeNode[i.day - 1].active = !!this._finishAnim, sys.isObjectValid(i.cash) && i.cash > 0 && (a = true, r += i.cash), sys.isObjectValid(i.bouns) && i.bouns > 0 && (s = true, r += i.bouns), this.rechargeNode[i.day - 1].getChildByName("reward").getChildByName("item0").active = a, a && (this.rechargeNode[i.day - 1].getChildByName("reward").getChildByName("item0").getChildByName("num").getComponent(Label).string = "" + i.cash), this.rechargeNode[i.day - 1].getChildByName("reward").getChildByName("item1").active = s, s && (this.rechargeNode[i.day - 1].getChildByName("reward").getChildByName("item1").getChildByName("num").getComponent(Label).string = "" + i.bouns), this.rechargeNode[i.day - 1].getChildByName("reward").getChildByName("add").active = false, a && s) {
                    if (this.rechargeNode[i.day - 1].getChildByName("reward").getChildByName("item0").getComponent(Layout).updateLayout(), this.rechargeNode[i.day - 1].getChildByName("reward").getChildByName("item1").getComponent(Layout).updateLayout(), this.rechargeNode[i.day - 1].getChildByName("reward").getComponent(Layout).updateLayout(), ToolUtils.judgeIfInHall()) {
                        this.rechargeNode[i.day - 1].getChildByName("reward").getComponent(UITransform).contentSize.width > 195 && this.rechargeNode[i.day - 1].getChildByName("reward").setScale(v3(0.8, 0.8));
                    }
                    else {
                        this.rechargeNode[i.day - 1].getChildByName("reward").getComponent(UITransform).contentSize.width > 200 && this.rechargeNode[i.day - 1].getChildByName("reward").setScale(v3(0.8, 0.8));
                    }
                }
                let d = -1;
                i.day;
                a && s ? d = 2 : a ? d = 0 : s && (d = 1);
                d >= 0 && this.rewardIcons[d] && (o.getComponent(Sprite).spriteFrame = this.rewardIcons[d]);
                let p = "";
                p = a && s ? "₹" + r + "*" : "₹" + r;
                ToolUtils.getIsInRoom() ? 0 == t && (p += "\n") : p += " ";
                0 == t ? this.rechargeNode[i.day - 1].getChildByName("tips").getComponent(Label).string = "GET " + p + "NOW" : 1 == t ? ToolUtils.getIsInRoom() ? this.rechargeNode[i.day - 1].getChildByName("tips").getComponent(Label).string = "DAY 2\nGET " + p : this.rechargeNode[i.day - 1].getChildByName("tips").getComponent(Label).string = "DAY 2 GET " + p : 2 == t && (ToolUtils.getIsInRoom() ? this.rechargeNode[i.day - 1].getChildByName("tips").getComponent(Label).string = "DAY 3\nGET " + p : this.rechargeNode[i.day - 1].getChildByName("tips").getComponent(Label).string = "DAY 3 GET " + p);
                sys.isObjectValid(i.state) ? h.active = 2 == i.state : h.active = false;
            }
            else {
                this.rechargeNode[t].active = false;
            }
        }
        let r = this.btnSubmit.getChildByName("price").getChildByName("cur"), a = this.btnSubmit.getChildByName("price").getChildByName("origin"), s = a.getChildByName("originline");
        if (r.active = true, this.btnSubmit.getComponent(Button).interactable = true, t) {
            let t = e.reward.length;
            a.active = false;
            r.getComponent(Label).fontSize = 36;
            this.btnSubmit.getChildByName("flag").active = false;
            for (let i = 0; i < t; i++) {
                if (3 == e.reward[i].day && 2 == e.reward[i].state) {
                    this.btnSubmit.getComponent(Button).interactable = false;
                    this.btnSubmit.getComponent(Sprite).spriteFrame = this.rewBtnBg[2];
                    r.getComponent(Label).string = i18nMgr.shared().getValueByKey("buyonegetthree.claimed");
                    break;
                }
                if (2 == e.reward[i].day && 1 == e.reward[i].state || 3 == e.reward[i].day && 1 == e.reward[i].state) {
                    this.btnSubmit.getComponent(Sprite).spriteFrame = this.rewBtnBg[0];
                    r.getComponent(Label).string = i18nMgr.shared().getValueByKey("buyonegetthree.claim");
                    break;
                }
                let t = 0;
                if (2 == e.reward[i].day && 0 == e.reward[i].state || 3 == e.reward[i].day && 0 == e.reward[i].state) {
                    sys.isObjectValid(e.reward[i].cash) && e.reward[i].cash >= 0 && (t += e.reward[i].cash);
                    sys.isObjectValid(e.reward[i].bouns) && e.reward[i].bouns >= 0 && (t += e.reward[i].bouns);
                    this.btnSubmit.getComponent(Sprite).spriteFrame = this.rewBtnBg[1];
                    r.getComponent(Label).string = ToolUtils.format(i18nMgr.shared().getValueByKey("buyonegetthree.claim_tomo"), t);
                    break;
                }
            }
        }
        else {
            a.active = true;
            sys.isObjectValid(e.add_ratio_txt) && e.add_ratio_txt ? (this.btnSubmit.getChildByName("flag").active = true, this.btnSubmit.getChildByName("flag").getChildByName("wz").getComponent(Label).string = e.add_ratio_txt) : this.btnSubmit.getChildByName("flag").active = false;
            this.btnSubmit.getComponent(Sprite).spriteFrame = this.rewBtnBg[0];
            r.getComponent(Label).string = "₹" + e.price;
            a.getComponent(Label).string = "₹" + e.origin_price;
            a.getComponent(Label).updateRenderData(true);
            s.getComponent(Widget).updateAlignment();
        }
    }
    onButtonClick(e, t) {
        if (SoundManager.shared().playFx("click"), "close" == t) {
            if (1 == Utils.shared().checkPopRestartGift(this._mPara)) {
                return void this.onBackView();
            }
            1 == this.checkKyc && Utils.shared().checkAddCashKyc();
            this.onBackView();
        }
    }
    priceTabClick(e, t) {
        if (SoundManager.shared().playFx("click"), this.getHaveBuyState()) {
            return;
        }
        if ("0" != t && "1" != t && "2" != t) {
            return;
        }
        if (0 == this._priceTabIndex && "0" == t) {
            return;
        }
        if (1 == this._priceTabIndex && "1" == t) {
            return;
        }
        if (2 == this._priceTabIndex && "2" == t) {
            return;
        }
        let i = this.getGoodList();
        i && Array.isArray(i) && Number(t) >= this.getGoodList().length || ("0" != t && "1" != t && "2" != t || (this._priceTabIndex = Number(t)), null == this._priceTabIndex || null == this._priceTabIndex || this._priceTabIndex < 0 || (this.updatePriceTabUI(), this.updateBottomUI()));
    }
    updatePriceTabUI() {
        if (this.getHaveBuyState()) {
            return;
        }
        let e = "", t = this.getGoodList();
        if (t && Array.isArray(t)) {
            for (let i = 0; i < t.length; i++) {
                e = "btn" + i;
                let r = this.midNode.getChildByName(e);
                if (!r) {
                    return;
                }
                let a = r.getChildByName("sel_lab"), s = r.getChildByName("bg").getComponent(Sprite);
                a.getComponent(Label).string = "₹" + t[i].price || "";
                this._priceTabIndex == i ? (r.getComponent(Button).interactable = false, a.getComponent(Label).color = color(255, 237, 87), s.getComponent(Sprite).spriteFrame = this.priceTabbg[1]) : (r.getComponent(Button).interactable = true, a.getComponent(Label).color = color(163, 57, 57), s.getComponent(Sprite).spriteFrame = this.priceTabbg[0]);
            }
        }
    }
    onBtnSubmitClick(e, t) {
        SoundManager.shared().playFx("click");
        let i = null, r = this.getHaveBuyState(), a = this.getGoodList();
        if (a.length && sys.isObjectValid(this._payOneForThreeData) && (!r || sys.isObjectValid(this._payOneForThreeData.buy_price))) {
            if (r) {
                for (let e = 0; e < a.length; e++) {
                    if (sys.isObjectValid(a[e].price) && a[e].price && Number(a[e].price) == Number(this._payOneForThreeData.buy_price)) {
                        i = a[e];
                        break;
                    }
                }
            }
            else {
                this._priceTabIndex >= 0 && sys.isObjectValid(a[this._priceTabIndex].price) && a[this._priceTabIndex].price && (i = a[this._priceTabIndex]);
            }
            if (i && sys.isObjectValid(i.price) && sys.isObjectValid(i.origin_price) && sys.isObjectValid(i.reward) && i.reward && Array.isArray(i.reward) && i.reward.length) {
                if (r) {
                    let e = i.reward.length;
                    for (let t = 0; t < e; t++) {
                        if (3 == i.reward[t].day && 2 == i.reward[t].state) {
                            return;
                        }
                        if (2 == i.reward[t].day && 1 == i.reward[t].state || 3 == i.reward[t].day && 1 == i.reward[t].state) {
                            return void User.shared().requestClaimBuyOneGetThreeRward((e => {
                                ToolUtils.isObjValid(this.node) && e && (this.setBuyOneGetThreeData(e), this.refreshView());
                            }));
                        }
                        if (2 == i.reward[t].day && 0 == i.reward[t].state || 3 == i.reward[t].day && 0 == i.reward[t].state) {
                            return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("buyonegetthree.claim_tomo_tips"), 2);
                        }
                    }
                }
                else if (ToolUtils.isObjValid(this.node)) {
                    if (!User.shared().checkCanRecharge()) {
                        return void this.node.destroy();
                    }
                    if (!sys.isObjectValid(i.price)) {
                        return;
                    }
                    if (!sys.isObjectValid(i.good_id)) {
                        return;
                    }
                    let e = { pway: this._payOneForThreeData.pways + "", price: i.price, goodsId: i.good_id, link_id: this._linkId, act_id: PushEvent.JUMP_TO_BuyOneGetThree };
                    User.shared().startPay(e);
                }
            }
        }
    }
    onBackView() {
        if (ToolUtils.isObjValid(this.node)) {
            if (this._has_close) {
                return;
            }
            this._has_close = true;
            let e = { alert_node: this.node, rootNode: this.rootNode, isNext: this.isNext, pop_type: PushEvent.JUMP_TO_BuyOneGetThree, pop_souce: this._pop_souce };
            Utils.shared().closeActivityView(e);
        }
    }
}
