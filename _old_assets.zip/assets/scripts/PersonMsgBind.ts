// @ts-nocheck
// Recovered from index.js:345
import { _decorator, Button, EditBox, Label, Node, SpriteFrame, sys, UIOpacity, v3 } from "cc";
import BaseLayer from "./BaseLayer";
import i18nMgr from "./i18nMgr";
import PushCenter from "./PushCenter";
import { ToolUtils } from "./ToolUtils";
import Utils from "./Utils";
import GameConfig from "./GameConfig";
import PushEvent from "./PushEvent";
import User from "./User";
import HttpManager from "./HttpManager";
import SoundManager from "./SoundManager";
import TweenTool from "./TweenTool";
const { ccclass, property } = _decorator;
@ccclass("PersonMsgBind")
export class PersonMsgBind extends BaseLayer {
    @property(Node)
    public root_node: Node = null;
    @property(Node)
    public bind_phone: Node = null;
    @property(Node)
    public bind_email: Node = null;
    @property(Node)
    public phone_otp: Node = null;
    @property(Node)
    public email_otp: Node = null;
    @property(EditBox)
    public phone_tf: EditBox = null;
    @property(EditBox)
    public email_tf: EditBox = null;
    @property(EditBox)
    public phone_otp_tf: EditBox = null;
    @property(EditBox)
    public email_otp_tf: EditBox = null;
    @property(Node)
    public phone_del: Node = null;
    @property(Node)
    public email_del: Node = null;
    @property([Label])
    public phone_otp_Label: Label[] = [];
    @property([Label])
    public email_otp_Label: Label[] = [];
    @property(Button)
    public phoneSubmitBtn: Button = null;
    @property(Button)
    public emailSubmitBtn: Button = null;
    @property(Button)
    public phoneOtpBtn: Button = null;
    @property(Button)
    public emailOtpBtn: Button = null;
    @property(Node)
    public phoneResendNode: Node = null;
    @property(Node)
    public emailResendNode: Node = null;
    @property([SpriteFrame])
    public buttonSpriteFrames: SpriteFrame[] = [];
    public input_node: any = null;
    public _cb: any = null;
    public state: number = 0;
    public serialno: string = "";
    public bShowPushAnim: boolean = false;
    public _closed: boolean = false;
    public showUICallback: any = null;
    public _keyboardHei: number = 780;
    public code_btnNode: any = null;
    public editBoxNodePos: any = v3(0, 0, 0);
    public skewingPos: number = 529;
    public _rootPos: any = v3(0, 0, 0);
    init(e, t = null) {
        this.bShowPushAnim = e;
        this.showUICallback = t;
    }
    onLoad() {
        for (let e = 0; e < 6; e++) {
            this.phone_otp_Label[e] && (this.phone_otp_Label[e].string = "");
            this.email_otp_Label[e] && (this.email_otp_Label[e].string = "");
        }
        this.root_node.getPosition(this._rootPos);
    }
    onDestroy() {
        PushCenter.shared().removeListenersByTag(this);
        this.unscheduleAllCallbacks();
    }
    start() {
        if (super.start(), PushCenter.shared().addListener(PushEvent.changeWebViewHeight, (e => {
            ToolUtils.isObjValid(this.node);
        }), this), this.refreshUI(this.state), ToolUtils.showFullScreen(this.node.getChildByName("bg")), sys.isNative) {
            this.refreshEditBoxFocus();
        }
        else {
            let e = { startPos: v3(this._rootPos.x, 0, this._rootPos.z), endPos: v3(this._rootPos.x, this.skewingPos, this._rootPos.z) };
            ToolUtils.showPushAnim(this.root_node, 2, null, e);
            TweenTool.delayAct(this.node, (() => {
                this.refreshEditBoxFocus();
            }), 0.27, true);
        }
    }
    showScrollivewUp(e) {
        if (ToolUtils.getIsInRoom()) {
            return;
        }
        if (sys.isBrowser) {
            return;
        }
        let t = v3(0, this.skewingPos);
        this.node.inverseTransformPoint(t, this.editBoxNodePos);
        let i = GameConfig.REAL_SCREEN_HEIGHT;
        ToolUtils.getIsInRoom() && (i = GameConfig.REAL_SCREEN_WIDTH);
        let s = i / 2 + t.y - 34 - 80;
        s < this._keyboardHei ? this.root_node.setPosition(v3(0, this._keyboardHei - s)) : this.root_node.setPosition(v3(0, this.skewingPos));
    }
    restoreScrollviewTop() {
        this.root_node.setPosition(v3(0, this.skewingPos));
    }
    setState(e) {
        this.state = e;
    }
    setCloseCallBack(e) {
        this._cb = e;
    }
    refreshUI(e) {
        if (0 === e) {
            this.bind_phone.active = true;
            this.bind_email.active = false;
            this.phone_otp.active = false;
            this.email_otp.active = false;
            this.input_node = this.phone_tf.node;
            this.updateMobileClearStatus();
            this.updateSubmitStatus();
        }
        else if (1 === e) {
            this.bind_phone.active = true;
            this.bind_email.active = false;
            this.phone_otp.active = false;
            this.email_otp.active = false;
            this.input_node = this.phone_tf.node;
        }
        else if (2 === e) {
            this.bind_email.active = true;
            this.bind_phone.active = false;
            this.phone_otp.active = false;
            this.email_otp.active = false;
            this.input_node = this.email_tf.node;
        }
        else if (3 == e) {
            ;
        }
        else if (4 == e) {
            this.bind_email.active = true;
            this.bind_phone.active = false;
            this.phone_otp.active = false;
            this.email_otp.active = false;
            this.input_node = this.email_tf.node;
        }
        else if (5 == e) {
            this.phone_otp.active = true;
            this.bind_email.active = false;
            this.bind_phone.active = false;
            this.email_otp.active = false;
            User.shared().data.email && "" != User.shared().data.email ? (this.phone_otp.getChildByName("title").getComponent(Label).string = "Email Address", this.phone_otp.getChildByName("tips").getComponent(Label).string = "OTP has been sent to your Mobile") : (this.phone_otp.getChildByName("title").getComponent(Label).string = "Mobile Number", this.phone_otp.getChildByName("tips").getComponent(Label).string = "OTP has been sent to your Mobile");
            let e = ToolUtils.isSafeString(User.shared().data.tel_no);
            if (0 == e.length) {
                return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("bind_mobile.input_number_tips"), 2);
            }
            if (10 != e.length) {
                return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("bind_mobile.invalid_mobile_number"), 2);
            }
            Utils.shared().showLoading(10, true, (() => {
                Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
            }));
            HttpManager.shared().doGetMobileCode(e, 4, 1, this.listenGetCodeCall.bind(this));
            this.input_node = this.phone_otp_tf.node;
        }
        else if (6 == e) {
            this.email_otp.active = true;
            this.phone_otp.active = false;
            this.bind_email.active = false;
            this.bind_phone.active = false;
            this.email_otp_tf.string = "";
            this.input_node = this.email_otp_tf.node;
            User.shared().data.tel_no && "" != User.shared().data.tel_no ? (this.email_otp.getChildByName("title").getComponent(Label).string = "Mobile Number", this.email_otp.getChildByName("tips").getComponent(Label).string = "OTP has been sent to your email") : User.shared().data.email && "" != User.shared().data.email || (this.email_otp.getChildByName("title").getComponent(Label).string = "Email Address", this.email_otp.getChildByName("tips").getComponent(Label).string = "OTP has been sent to your email");
            let e = ToolUtils.isSafeString(User.shared().data.email);
            if (0 == e.length) {
                return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("bind_mobile.input_email_tips"), 2);
            }
            if (-1 == e.search("@")) {
                return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("bind_mobile.invalid_email"), 2);
            }
            Utils.shared().showLoading(10, true, (() => {
                Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
            }));
            HttpManager.shared().doGetEmailCode(e, 2, this.listenGetEmailCodeCall.bind(this));
        }
        this.editBoxNodePos = this.input_node.getWorldPosition();
    }
    refreshEditBoxFocus() {
        0 === this.state || 1 === this.state ? (this.phone_tf.getComponent(EditBox).focus(), this.input_node = this.phone_tf.node) : 5 === this.state ? (this.phone_otp_tf.getComponent(EditBox).focus(), this.input_node = this.phone_otp_tf.node) : 2 === this.state || 4 === this.state ? (this.email_tf.getComponent(EditBox).focus(), this.input_node = this.email_tf.node) : 6 === this.state && (this.email_otp_tf.getComponent(EditBox).focus(), this.input_node = this.email_otp_tf.node);
    }
    checkMobileOtpLogic(e) {
        let t = e.length;
        for (let i = 0; i < this.phone_otp_Label.length; i++) {
            this.phone_otp_Label[i].string = i < t ? e.charAt(i) : "";
        }
        this.updateOtpVerifyStatus();
    }
    checkEmailOtpLogic(e) {
        let t = e.length;
        for (let i = 0; i < this.email_otp_Label.length; i++) {
            this.email_otp_Label[i].string = i < t ? e.charAt(i) : "";
        }
        this.updateOtpVerifyStatus();
    }
    onEditBoxBegan(e, t, i) {
        this.showScrollivewUp(this.input_node);
    }
    onEditBoxChanged(e, t, i) {
        // VERIFY 按钮也要在输入过程中实时刷新：原来只在 onEditBoxEnded（失焦/
        // 收键盘）时重算，光标还在输入框里时输满 10 位按钮也保持灰色。
        "bind_mobile" == i ? (this.updateMobileClearStatus(), this.updateSubmitStatus()) : "mobile_otp" == i ? this.checkMobileOtpLogic(e) : "bind_email" == i ? (this.updateEmailClearStatus(), this.updateSubmitStatus()) : "email_otp" == i && this.checkEmailOtpLogic(e);
    }
    onEditBoxEnded(e, t) {
        "bind_mobile" == t ? (this.updateMobileClearStatus(), this.updateSubmitStatus()) : "mobile_otp" == t ? this.updateOtpVerifyStatus() : "bind_email" == t ? (this.updateEmailClearStatus(), this.updateSubmitStatus()) : "email_otp" == t && this.updateOtpVerifyStatus();
        this.restoreScrollviewTop();
    }
    listenBlindPhoneCall(e, t, i) {
        if (Utils.shared().hideLoading(), 200 !== i) {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text37"), 2);
        }
        else {
            let e = ToolUtils.parseJson(t);
            if (0 === e.ret) {
                let t = e.data.tel_no;
                if (User.shared().data.tel_no = t, ToolUtils.saveData("code_phoneno", t + ""), sys.isObjectValid(e.data.kyc_update_status) && (User.shared().data.kyc_update_status = e.data.kyc_update_status), null != e.data.kyc_check && null != e.data.kyc_check && (User.shared().data.kyc_check = e.data.kyc_check), PushCenter.shared().pushEvent(GameConfig.Update_Kyc, User.shared().data.kyc_check), sys.isObjectValid(e.data.reward_list) && e.data.reward_list.length > 0) {
                    Utils.shared().showKycVerifySucTip(e.data.reward_list, i18nMgr.shared().getValueByKey("bind_mobile.phone_binding_success2"));
                }
                else if (User.shared().code_timeout = e.data.timeout, e.desc && ToolUtils.isSafeString(e.desc).length > 0) {
                    let t = ToolUtils.isSafeString(e.desc);
                    Utils.shared().showToast(t, 2);
                }
                else {
                    Utils.shared().showToast(i18nMgr.shared().getValueByKey("bind_mobile.phone_binding_success"), 2);
                }
                PushCenter.shared().pushEvent(GameConfig.MobileBlind_State, User.shared().data.tel_no);
                PushCenter.shared().pushEvent(PushEvent.updateBannerList);
                this.onBackView();
            }
            else if (e.desc && ToolUtils.isSafeString(e.desc).length > 0) {
                let t = ToolUtils.isSafeString(e.desc);
                Utils.shared().showToast(t, 2);
            }
        }
    }
    listenBlindEmailCall(e, t, i) {
        if (Utils.shared().hideLoading(), 200 !== i) {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text37"), 2);
        }
        else {
            let e = ToolUtils.parseJson(t);
            if (0 === e.ret) {
                if (e.data.email) {
                    let t = e.data.email;
                    User.shared().data.email = t + "";
                }
                if (sys.isObjectValid(e.data.kyc_update_status) && (User.shared().data.kyc_update_status = e.data.kyc_update_status), null != e.data.kyc_check && null != e.data.kyc_check && (User.shared().data.kyc_check = e.data.kyc_check), sys.isObjectValid(e.data.email_bind_red_dot) && (User.shared().data.email_bind_red_dot = e.data.email_bind_red_dot), sys.isObjectValid(e.data.email_bind_reward) && e.data.email_bind_reward && Array.isArray(e.data.email_bind_reward) && (User.shared().data.email_bind_reward = e.data.email_bind_reward), PushCenter.shared().pushEvent(GameConfig.Update_Kyc, User.shared().data.kyc_check), sys.isObjectValid(e.data.reward_list) && e.data.reward_list.length > 0) {
                    Utils.shared().showKycVerifySucTip(e.data.reward_list, i18nMgr.shared().getValueByKey("bind_mobile.email_binding_success2"));
                }
                else if (e.desc && ToolUtils.isSafeString(e.desc).length > 0) {
                    let t = ToolUtils.isSafeString(e.desc);
                    Utils.shared().showToast(t, 2);
                }
                else {
                    Utils.shared().showToast(i18nMgr.shared().getValueByKey("bind_mobile.email_binding_success"), 2);
                }
                User.shared().code_timeout = 0;
                PushCenter.shared().pushEvent(GameConfig.EmailBlind_State, User.shared().data.email);
                this.onBackView();
            }
            else if (e.desc && ToolUtils.isSafeString(e.desc).length > 0) {
                let t = ToolUtils.isSafeString(e.desc);
                Utils.shared().showToast(t, 2);
            }
        }
    }
    listenGetCodeCall(e, t, i) {
        if (Utils.shared().hideLoading(), 200 !== i) {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text37"), 2);
        }
        else {
            let e = ToolUtils.parseJson(t);
            if (0 === e.ret) {
                if (ToolUtils.isObjValid(this.node)) {
                    this.phone_otp.active = true;
                    this.bind_email.active = false;
                    this.bind_phone.active = false;
                    this.email_otp.active = false;
                    this.phone_otp_tf.string = "";
                    let t = e.data.timeout;
                    this.serialno = e.data.serialno;
                    User.shared().code_timeout = t;
                    this.unschedule(this.refreshCodeBtn);
                    this.refreshCodeBtn();
                    this.schedule(this.refreshCodeBtn, 1);
                }
            }
            else if (ToolUtils.isObjValid(this.node)) {
                if (e.desc && ToolUtils.isSafeString(e.desc).length > 0) {
                    let t = ToolUtils.isSafeString(e.desc);
                    Utils.shared().showToast(t, 2);
                }
                let t = e.data.timeout;
                t && ToolUtils.isSafeNumber(t) > 0 && (User.shared().code_timeout = t, this.unschedule(this.refreshCodeBtn), this.refreshCodeBtn(), this.schedule(this.refreshCodeBtn, 1));
            }
        }
    }
    listenGetEmailCodeCall(e, t, i) {
        if (Utils.shared().hideLoading(), 200 !== i) {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text37"), 2);
        }
        else {
            let e = ToolUtils.parseJson(t);
            if (0 === e.ret) {
                if (ToolUtils.isObjValid(this.node)) {
                    this.email_otp.active = true;
                    this.phone_otp.active = false;
                    this.bind_email.active = false;
                    this.bind_phone.active = false;
                    this.email_otp_tf.string = "";
                    let t = e.data.timeout;
                    User.shared().code_timeout = t;
                    this.refreshCodeBtn();
                    this.unschedule(this.refreshCodeBtn);
                    this.schedule(this.refreshCodeBtn, 1);
                }
            }
            else if (ToolUtils.isObjValid(this.node) && e.desc && ToolUtils.isSafeString(e.desc).length > 0) {
                let t = ToolUtils.isSafeString(e.desc);
                Utils.shared().showToast(t, 2);
            }
        }
    }
    listenChangePhoneCall(e, t, i) {
        if (Utils.shared().hideLoading(), 200 !== i) {
            ;
        }
        else {
            let e = ToolUtils.parseJson(t);
            if (0 === e.ret) {
                Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text36"), 2);
                e.data && e.data.phone && (User.shared().data.tel_no = "" + e.data.phone, ToolUtils.saveData("code_phoneno", "" + e.data.phone));
                PushCenter.shared().pushEvent(GameConfig.MobileBlind_State, User.shared().data.tel_no);
                this.onBackView();
            }
            else if (e.desc && ToolUtils.isSafeString(e.desc).length > 0) {
                let t = ToolUtils.isSafeString(e.desc);
                Utils.shared().showToast(t, 2);
            }
        }
    }
    listenVerifyCodeCall(e, t, i) {
        if (Utils.shared().hideLoading(), 200 !== i) {
            ;
        }
        else {
            let e = ToolUtils.parseJson(t);
            if (0 === e.ret) {
                ToolUtils.isObjValid(this.node) && (PushCenter.shared().pushEvent(PushEvent.OTP_Verify_Succ, this.state), this.onBackView());
            }
            else if (ToolUtils.isObjValid(this.node) && e.desc && ToolUtils.isSafeString(e.desc).length > 0) {
                let t = ToolUtils.isSafeString(e.desc);
                Utils.shared().showToast(t, 2);
            }
        }
    }
    refreshCodeBtn() {
        User.shared().code_timeout = User.shared().code_timeout - 1;
        let e = this.phoneResendNode.getChildByName("otp_time_info"), t = this.phoneResendNode.getChildByName("resend_btn"), i = this.emailResendNode.getChildByName("otp_time_info"), s = this.emailResendNode.getChildByName("resend_btn");
        User.shared().code_timeout <= 0 ? (this.unschedule(this.refreshCodeBtn), t.active = true, s.active = true, e.active = false, i.active = false) : (e.active = true, e.getChildByName("wz").getComponent(Label).string = ToolUtils.format("Resend OTP in ${0} secs", User.shared().code_timeout), i.active = true, i.getChildByName("wz").getComponent(Label).string = ToolUtils.format("Resend OTP in ${0} secs", User.shared().code_timeout), t.active = false, s.active = false);
    }
    resethCodeBtn() {
    }
    updateMobileClearStatus() {
        ToolUtils.isSafeString(this.phone_tf.string).length > 0 ? this.phone_del.active = true : this.phone_del.active = false;
    }
    updateEmailClearStatus() {
        ToolUtils.isSafeString(this.email_tf.string).length > 0 ? this.email_del.active = true : this.email_del.active = false;
    }
    updateSubmitStatus() {
        10 == ToolUtils.isSafeString(this.phone_tf.string).length ? (this.phoneSubmitBtn.interactable = true, this.phoneSubmitBtn.node.getComponent(UIOpacity).opacity = 255) : (this.phoneSubmitBtn.interactable = false, this.phoneSubmitBtn.node.getComponent(UIOpacity).opacity = 78);
        let e = ToolUtils.isSafeString(this.email_tf.string);
        e.length > 0 && -1 != e.search("@") && !/^-?\d+(\.\d+)?$/.test(e) && !/^[a-zA-Z]+$/.test(e) ? (this.emailSubmitBtn.interactable = true, this.emailSubmitBtn.node.getComponent(UIOpacity).opacity = 255) : (this.emailSubmitBtn.interactable = false, this.emailSubmitBtn.node.getComponent(UIOpacity).opacity = 78);
    }
    updateOtpVerifyStatus() {
        6 == ToolUtils.isSafeString(this.phone_otp_tf.string).length ? (this.phoneOtpBtn.interactable = true, this.phoneOtpBtn.node.getComponent(UIOpacity).opacity = 255) : (this.phoneOtpBtn.interactable = false, this.phoneOtpBtn.node.getComponent(UIOpacity).opacity = 78);
        6 == ToolUtils.isSafeString(this.email_otp_tf.string).length ? (this.emailOtpBtn.interactable = true, this.emailOtpBtn.node.getComponent(UIOpacity).opacity = 255) : (this.emailOtpBtn.interactable = false, this.emailOtpBtn.node.getComponent(UIOpacity).opacity = 78);
    }
    buttonClick(e, t) {
        SoundManager.shared().playFx("click");
        this.dealClickEvent(t);
    }
    dealClickEvent(e) {
        if ("submit" === e) {
            if (0 == this.state || 1 == this.state || 3 == this.state) {
                let e = ToolUtils.isSafeString(this.phone_tf.string);
                if (0 == e.length) {
                    return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("bind_mobile.input_number_tips"), 2);
                }
                if (10 != e.length) {
                    return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("bind_mobile.invalid_mobile_number"), 2);
                }
                if (1 == this.state && User.shared().data.tel_no == e) {
                    return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("bind_mobile.same_number"), 2);
                }
                Utils.shared().showLoading(10, true, (() => {
                    Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
                }));
                HttpManager.shared().doGetMobileCode(e, 4, 1, this.listenGetCodeCall.bind(this));
            }
            else if (2 == this.state || 4 == this.state) {
                let e = ToolUtils.isSafeString(this.email_tf.string);
                if (0 == e.length) {
                    return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("bind_mobile.input_email_tips"), 2);
                }
                if (-1 == e.search("@")) {
                    return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("bind_mobile.invalid_email"), 2);
                }
                Utils.shared().showLoading(10, true, (() => {
                    Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
                }));
                let t = 1;
                4 == this.state && (t = 3);
                HttpManager.shared().doGetEmailCode(e, t, this.listenGetEmailCodeCall.bind(this));
            }
        }
        else if ("verify" === e) {
            if (0 === this.state || 3 === this.state) {
                let e = ToolUtils.isSafeString(this.phone_tf.string), t = ToolUtils.isSafeString(this.phone_otp_tf.string);
                if (0 == e.length) {
                    return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("bind_mobile.input_number_tips"), 2);
                }
                if (e.length < 10) {
                    return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("bind_mobile.invalid_mobile_number"), 2);
                }
                if (0 == t.length) {
                    return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("bind_mobile.enter_code_tips"), 2);
                }
                if (t.length < 6) {
                    return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text63"), 3);
                }
                Utils.shared().showLoading(10, true, (() => {
                    Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
                }));
                HttpManager.shared().doBlindPhoneAccount(e, t, "", this.serialno, this.listenBlindPhoneCall.bind(this));
            }
            else if (1 === this.state) {
                let e = ToolUtils.isSafeString(this.phone_tf.string), t = ToolUtils.isSafeString(this.phone_otp_tf.string);
                if (0 == e.length) {
                    return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("bind_mobile.input_number_tips"), 2);
                }
                if (e.length < 10) {
                    return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("bind_mobile.invalid_mobile_number"), 2);
                }
                if (User.shared().data.tel_no == ToolUtils.isSafeString(e)) {
                    return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("bind_mobile.same_number"), 2);
                }
                if (0 == t.length) {
                    return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("bind_mobile.enter_code_tips"), 2);
                }
                if (t.length < 6) {
                    return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text63"), 3);
                }
                Utils.shared().showLoading(10, true, (() => {
                    Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
                }));
                HttpManager.shared().doChangePhoneAccount("", ToolUtils.isSafeString(this.phone_tf.string), t, this.listenChangePhoneCall.bind(this));
            }
            else if (2 === this.state || 4 == this.state) {
                let e = ToolUtils.isSafeString(this.email_tf.string), t = ToolUtils.isSafeString(this.email_otp_tf.string);
                if (0 == e.length) {
                    return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("bind_mobile.input_email_tips"), 2);
                }
                if (-1 == e.search("@")) {
                    return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("bind_mobile.invalid_email"), 2);
                }
                if (0 == t.length) {
                    return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("bind_mobile.enter_code_tips"), 2);
                }
                if (t.length < 6) {
                    return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text63"), 3);
                }
                Utils.shared().showLoading(10, true, (() => {
                    Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
                }));
                let i = 1;
                4 == this.state && (i = 3);
                4 == this.state ? HttpManager.shared().doChangeBindingEmail(e, t, this.listenBlindEmailCall.bind(this)) : HttpManager.shared().doBindingEmail(i, e, t, this.listenBlindEmailCall.bind(this));
            }
            else if (5 === this.state) {
                let e = ToolUtils.isSafeString(this.phone_otp_tf.string);
                if (0 == e.length) {
                    return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("bind_mobile.enter_code_tips"), 2);
                }
                if (e.length < 6) {
                    return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text63"), 3);
                }
                Utils.shared().showLoading(10, true, (() => {
                    Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text37"), 3);
                }), ToolUtils.getIsNormalDirection());
                HttpManager.shared().doVerifyMobileCode(User.shared().data.tel_no, e, this.listenVerifyCodeCall.bind(this));
            }
            else if (6 === this.state) {
                let e = ToolUtils.isSafeString(this.email_otp_tf.string);
                if (0 == e.length) {
                    return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("bind_mobile.enter_code_tips"), 2);
                }
                if (e.length < 6) {
                    return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text63"), 3);
                }
                Utils.shared().showLoading(10, true, (() => {
                    Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text37"), 3);
                }), ToolUtils.getIsNormalDirection());
                HttpManager.shared().doVerifyEmailCode(User.shared().data.email, e, this.listenVerifyCodeCall.bind(this));
            }
        }
        else if ("clearMobile" === e) {
            this.phone_tf.string = "";
            this.phone_tf.blur();
            this.updateMobileClearStatus();
            this.updateSubmitStatus();
        }
        else if ("clearEmail" === e) {
            this.email_tf.string = "";
            this.email_tf.blur();
            this.updateEmailClearStatus();
            this.updateSubmitStatus();
        }
        else if ("otp" === e) {
            this.dealClickEvent("submit");
        }
        else if ("close" === e) {
            if (this._closed) {
                return;
            }
            this.onBackView();
        }
    }
    onBindSuccess(e, t) {
        this._cb && this._cb(true, e, t);
        ToolUtils.isObjValid(this.node) && this.node.destroy();
    }
    onBackView() {
        this._cb && this._cb();
        ToolUtils.isObjValid(this.node) && this.node.destroy();
    }
}
