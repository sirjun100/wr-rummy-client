// @ts-nocheck
// Recovered from index.js:303
import { _decorator, Button, color, director, instantiate, Label, Node, Prefab, ProgressBar, ScrollView, size, Sprite, SpriteAtlas, SpriteFrame, sys, UIOpacity, UITransform, v3, Vec3, view } from "cc";
import Parent from "./Parent";
import PushCenter from "./PushCenter";
import { TLog } from "./TLog";
import TweenTool from "./TweenTool";
import Utils from "./Utils";
import GameConfig from "./GameConfig";
import HowToPlayDefined from "./HowToPlayDefined";
import NetConfig from "./NetConfig";
import URLConfig from "./URLConfig";
import User from "./User";
import HttpManager from "./HttpManager";
import AppInfo from "./AppInfo";
import i18nMgr from "./i18nMgr";
import { ScrollviewUtils } from "./ScrollviewUtils";
import { ToolUtils } from "./ToolUtils";
import CommDefine, { CheckModule } from "./CommDefine";
import PushEvent from "./PushEvent";
import RummyCmd from "./RummyCmd";
import NetHostManager from "./NetHostManager";
import Server from "./Server";
import SoundManager from "./SoundManager";
import PhpReportDefined from "./PhpReportDefined";
const { ccclass, property } = _decorator;
@ccclass("MatchRoom")
export class MatchRoom extends Parent {
    public TAG: string = "MatchRoom";
    @property(Node)
    public root: Node = null;
    @property([Node])
    public switchBtn: Node[] = [];
    @property([SpriteFrame])
    public btnStateFrame: SpriteFrame[] = [];
    @property(Node)
    public btnSelect: Node = null;
    @property([Node])
    public sortBtns: Node[] = [];
    @property(Node)
    public matchSortNode: Node = null;
    @property([SpriteFrame])
    public matchTypeFrame: SpriteFrame[] = [];
    @property([SpriteFrame])
    public sortBtnFrame: SpriteFrame[] = [];
    @property([SpriteFrame])
    public sortFlagFrame: SpriteFrame[] = [];
    @property([SpriteFrame])
    public remindFlagFrame: SpriteFrame[] = [];
    @property(Node)
    public roomlist: Node = null;
    @property(Node)
    public room_moban: Node = null;
    @property(Node)
    public nodata: Node = null;
    @property(Prefab)
    public selectMatchPrefab: Prefab = null;
    @property(Node)
    public ticket_entryNode: Node = null;
    @property([SpriteFrame])
    public ticket_flagImages: SpriteFrame[] = [];
    @property([SpriteFrame])
    public mobanBgFrames: SpriteFrame[] = [];
    @property(SpriteAtlas)
    public rewardAtlas: SpriteAtlas = null;
    public selectView: any = null;
    public isDisconnectServer: boolean = false;
    public lastType: number = 0;
    public networkDelay: number = 0;
    public matchInfoList: any = null;
    public histroyList: any = null;
    public backgroundSatyTime: number = 0;
    public curPage: number = 1;
    public totalPage: number = 0;
    public _scrollUtil: any = null;
    public _items: any[] = [];
    public _listData: any[] = [];
    public curMatchFilterTag: any = { 0: { gameStatus: [1], gameFee: [0], startTime: [1], prizePool: [1] }, 1: { gameStatus: [1], gameFee: [0], startTime: [1], prizePool: [1] } };
    public _sortStart: number = 0;
    public _sortEntry: number = 0;
    public _sortPrize: number = 0;
    public _sortJoin: number = 0;
    public btnClickStatus: Map = new Map;
    public matchInfoPrefab: any = null;
    public ticketsList: any[] = [];
    public _hasLoginServer: boolean = false;
    public delayAct: any = null;
    public reconnectTimes: number = 3;
    public rewardNames: any[] = ["reward_watch.png"];
    public pageIndex: number = 0;
    public raceQueryId: number = 0;
    public racePagePending: boolean = false;
    public raceQueryRefreshPending: boolean = false;
    public serverRaceStates: Map<number, number> = new Map();
    public total_num: number = 0;
    public matchBtnStatus: any[] = ["tournament.upcoming", "tournament.join_now", "tournament.withdraw", "tournament.full", "tournament.enter", "tournament.eliminated2", "tournament.running", "tournament.completed", "tournament.rejoin2", "tournament.late_registing2", "tournament.late_join2", "tournament.early_seating2"];
    public RegisterButtonStatus: any = { UPCOMING: 0, JOINNOW: 1, WITHDRAW: 2, FULL: 3, ENTER: 4, ELIMINATED: 5, RUNNING: 6, COMPLETED: 7, REJOIN: 8, LATEREGISTER: 9, LATE_JOIN: 10, EARLY_SEATING: 11 };
    public curEventData: any = {};
    public remindMatchInfo: any = {};
    public _isOpenCalendar: boolean = false;
    public time_node: any = null;
    public tab_select_color: any = color(147, 11, 11, 255);
    public filter_select_color: any = color(151, 0, 0, 255);
    onLoad() {
        this._scrollUtil = this.node.addComponent(ScrollviewUtils);
        this._scrollUtil.initScrollviewUtils(this.roomlist.getComponent(ScrollView));
        this._isOpenCalendar = AppInfo.shared().isCalendarSupport();
        this.fitLuckyTheme();
    }
    fitLuckyTheme() {
        if (0 == GameConfig.NATIVE_GAME_APP_TYPE) {
            return;
        }
        this.tab_select_color = color(221, 3, 3, 255);
        this.filter_select_color = color(38, 59, 152, 255);
        let t = this.root.getChildByName("list_switch");
        t.getChildByName("bg").getComponent(Sprite).color = color(250, 250, 250, 255);
        t.getChildByName("btn_all").getChildByName("line").getComponent(Sprite).color = color(221, 3, 3, 255);
        t.getChildByName("btn_my").getChildByName("line").getComponent(Sprite).color = color(221, 3, 3, 255);
    }
    onEnable() {
        this.doConnectRequest();
        this.curPage = 1;
        this.send_get_race_list(this.curPage);
        this.send_get_available_tickets();
        User.shared().clearUserMatchTarget();
        PushCenter.shared().pushEvent(PushEvent.PreChangeMatchRoomBg);
    }
    onDisable() {
        this.delayAct && (TweenTool.stopAction(this.delayAct), this.delayAct = null);
    }
    start() {
        this.fitScreen();
        this.room_moban.active = false;
        this.refreshSwitchTab(0);
        PushCenter.shared().addListener(GameConfig.Update_Match_Hall, (() => {
            this.node && this.node.active && this.doConnectRequest();
        }), this);
        PushCenter.shared().addListener(GameConfig.onEnterForeground, (t => {
            if (ToolUtils.isGameBackground = false, ToolUtils.isObjValid(this.node)) {
                let t = this;
                sys.now() / 1000 - this.backgroundSatyTime / 1000 > 30 || ToolUtils.backgroundWebSocketReconnection ? (ToolUtils.backgroundWebSocketReconnection = false, this._hasLoginServer = false, this.scheduleOnce((() => {
                    Server.shared().disconnectWebSocket();
                    t.doConnectRequest();
                }))) : this.scheduleOnce((() => {
                    Server.shared().pop_response();
                    this.curPage = 1;
                    t.send_get_race_list(this.curPage);
                    t.send_get_available_tickets();
                }));
            }
        }), this);
        PushCenter.shared().addListener(GameConfig.onEnterBackground, (t => {
            ToolUtils.isGameBackground = true;
            this.backgroundSatyTime = sys.now();
        }), this);
        PushCenter.shared().addListener(PushEvent.CancelEnterMatch, (t => {
            this.node && this.node.active && (this.send_get_race_list(1), this.send_get_available_tickets());
        }), this);
        PushCenter.shared().addListener(PushEvent.RefreshHallMatchList, (t => {
            this.node && this.node.active && (this.send_get_race_list(1), this.send_get_available_tickets());
        }), this);
        PushCenter.shared().addListener(PushEvent.OnCalendarPermissionSucc, (t => {
            this.node && this.node.active && 1 == t && (this.remindMatchInfo.status == this.RegisterButtonStatus.UPCOMING || this.remindMatchInfo.btn_status == this.RegisterButtonStatus.UPCOMING ? this.setMatchRemind(0) : (this.setMatchRemind(1), Utils.shared().showToast(ToolUtils.format("You will get a reminder when the tournament about to starts at ${0}", this.remindMatchInfo.time_info), 3)), this.updateMatchRoomList());
        }), this);
        1 == ToolUtils.heart_open && (this.unschedule(this.netWorkDelayUpdate), this.schedule(this.netWorkDelayUpdate, 1));
        this.matchInfoList = User.shared().matchInfoList;
        sys.isObjectValid(this.matchInfoList) && (this.updateMatchRoomList(), this.matchSortNode.active = this.matchInfoList.length > 0);
        this.time_node = new Node;
        this.node.addChild(this.time_node);
        TweenTool.myschedule(this.time_node, 1, this.updateMatchTime.bind(this));
        Utils.shared().loadRemoteDeskImage(null, "rummy_card_table_bg_07");
        Utils.shared().loadRemoteDeskImage(null, "rummy_game_bg_6");
    }
    updateMatchTime(t) {
        if (sys.isObjectValid(this.matchInfoList)) {
            for (let t, e = 0, i = this.matchInfoList.length; e < i; e++) {
                t = this.matchInfoList[e];
                t.will_ready_time > 0 && (t.will_ready_time -= 1);
                t.will_start_time > 0 && (t.will_start_time -= 1);
            }
            for (let t, e = 0, i = this._listData.length; e < i; e++) {
                if (sys.isObjectValid(this._listData[e]) && (t = this._listData[e], ToolUtils.isObjValid(this._items[e]) && this._items[e].active && (1 == t.mode || 3 == t.mode))) {
                    let i = this._items[e].getChildByName("time");
                    t.btn_status == this.RegisterButtonStatus.UPCOMING ? t.will_ready_time > 0 && Number(t.will_ready_time) <= 10800 && (i.getComponent(Label).string = ToolUtils.timeStr2(t.will_ready_time, true)) : t.btn_status != this.RegisterButtonStatus.JOINNOW && t.btn_status != this.RegisterButtonStatus.WITHDRAW || t.will_start_time > 0 && Number(t.will_start_time) <= 10800 && (i.getComponent(Label).string = ToolUtils.timeStr2(t.will_start_time, true));
                }
            }
        }
    }
    refreshSwitchTab(t) {
        for (let e = 0, i = this.switchBtn.length; e < i; e++) {
            let i = this.switchBtn[e], s = i.getChildByName("wz"), a = i.getChildByName("line");
            if (e == t) {
                i.getComponent(Button).interactable = false;
                s.getComponent(Label).color = this.tab_select_color;
                i18nMgr.shared().changeLabelFont(s.getComponent(Label), true);
                a.active = true;
                a.scale = v3(0, 1, 1);
                let t = TweenTool.scaleTo(a, 0.16, v3(1.1, 1, 1), null, false), e = TweenTool.scaleTo(a, 0.16, v3(1, 1, 1), null, false);
                TweenTool.sequence(a, true, null, t, e);
            }
            else {
                i.getComponent(Button).interactable = true;
                s.getComponent(Label).color = color(102, 102, 102, 255);
                i18nMgr.shared().changeLabelFont(s.getComponent(Label), false);
                a.scale = v3(1, 1, 1);
                TweenTool.scaleTo(a, 0.1, v3(0.2, 1, 1), null, true, (() => {
                    a.scale = v3(1, 1, 1);
                    a.active = false;
                }));
            }
        }
    }
    netWorkDelayUpdate() {
        if (this.networkDelay = this.networkDelay + 1, !this.isDisconnectServer && this.networkDelay > 10) {
            let t = { cmd: NetConfig.HEARTBEAT_CMD };
            Server.shared().send(t);
            ToolUtils.lastSendHeartBeatTime = ToolUtils.getOsTime();
            this.networkDelay = 0;
        }
    }
    doConnectRequest() {
        this.delayAct && (TweenTool.stopAction(this.delayAct), this.delayAct = null);
        let t = Server.shared().isEnable();
        if (t || (Server.shared().reset(), this.matchInfoList && this.matchInfoList.length > 0 || Utils.shared().showLoading(10, true)), Server.shared().clearEventByTarget(this), this.regEventinit(), Server.shared().setOpenCb((() => {
            User.shared().send_match_login_gate_request();
        })), Server.shared().setReconCb((() => {
            Utils.shared().hideLoading();
        })), t) {
            Server.shared().pop_response();
            User.shared().send_match_login_request();
            User.shared().doSendMatchOnlineStatus(1);
        }
        else {
            let t = URLConfig.orginHttp_tcp, e = User.shared().getSmallPointRoomVid(), i = NetHostManager.shared().chooseBestTcpIpConn(e), s = NetHostManager.shared().chooseBestTcpPortConn(e);
            "-1" != i && -1 != s && (t = 443 == s ? "wss://" + i + ":443" : "ws://" + i + ":" + s);
            Server.shared().createSocket(t);
            this.reconnectTimes >= 1 ? this.delayAct = TweenTool.delayAct(this.node, (() => {
                ToolUtils.isObjValid(this.node) && (this._hasLoginServer || this.doConnectRequest());
            }), 2, true) : this.reconnectTimes--;
        }
        this.isDisconnectServer = false;
    }
    send_get_available_tickets() {
        let t = { cmd: NetConfig.GM_AVAILABLE_TICKETS, uid: User.shared().data.uid, skey: User.shared().getSkey(), version: GameConfig.Server_Api_Ver, session_id: User.shared().session_id };
        Server.shared().send(t);
    }
    send_get_race_list(t) {
        if (t === 1) { this.raceQueryId++; this.curPage = 0; this.totalPage = 0; }
        else if (this.racePagePending) return;
        const filter = this.curMatchFilterTag[this.lastType];
        const sorts = [["start", this._sortStart], ["entry", this._sortEntry], ["prize", this._sortPrize], ["join", this._sortJoin]];
        const selected = sorts.find(row => Number(row[1]) > 0) || ["default", 0];
        this.racePagePending = true;
        Server.shared().send({ cmd: NetConfig.GM_GET_RACE_LIST, uid: User.shared().data.uid,
            skey: User.shared().getSkey(), version: GameConfig.Server_Api_Ver, page: t,
            session_id: User.shared().session_id, in_hall: 1, list_version: 2,
            query_id: this.raceQueryId, my_games: this.lastType,
            sort_field: selected[0], sort_direction: selected[1],
            filter_status: filter.gameStatus, filter_fee: filter.gameFee,
            filter_start: filter.startTime, filter_prize: filter.prizePool });
    }
    send_get_race_detaild_request(t) {
        let e = { cmd: NetConfig.GM_GET_RACE_DETAILD_REQUEST, uid: User.shared().data.uid, skey: User.shared().getSkey(), version: GameConfig.Server_Api_Ver, raceid: t, session_id: User.shared().session_id, in_hall: 1 };
        Server.shared().send(e);
    }
    send_race_rejoin_request(t, e) {
        let i = { cmd: NetConfig.GM_RACE_REJOIN_REQUEST, uid: User.shared().data.uid, skey: User.shared().getSkey(), version: GameConfig.Server_Api_Ver, raceid: t, pay_type: e, isNewTable: 1, from: 0, session_id: User.shared().session_id, in_hall: 1 };
        Server.shared().send(i);
    }
    send_race_cancel_join_request(t) {
        let e = { cmd: NetConfig.GM_CANCEL_JOIN_RACE_REQUEST, uid: User.shared().data.uid, skey: User.shared().getSkey(), version: GameConfig.Server_Api_Ver, raceid: t, session_id: User.shared().session_id };
        Server.shared().send(e);
    }
    regEventinit() {
        Server.shared().regDispatch(NetConfig.SYSTEM_GATEWAY_CMD, this.handler_server_login_error.bind(this), this);
        Server.shared().regDispatch(NetConfig.SERVER_LOGIN_GATE_RESP, this.handler_server_login_gate_return.bind(this), this);
        Server.shared().regDispatch(NetConfig.SM_LOGIN_RETURN, this.handler_server_login_Rummy_return.bind(this), this);
        Server.shared().regDispatch(NetConfig.SM_LOGIN_ERR_UC, this.handler_server_sm_login_err.bind(this), this);
        Server.shared().regDispatch(NetConfig.SM_RACE_LIST, this.handler_server_race_list.bind(this), this);
        Server.shared().regDispatch(NetConfig.SM_GET_RACE_DETAILD_RESPOND, this.handler_server_get_race_detaild_return.bind(this), this);
        Server.shared().regDispatch(NetConfig.SM_JOIN_RETRUN, this.handler_server_join_return.bind(this), this);
        Server.shared().regDispatch(NetConfig.SM_JOIN_BC_RETRUN, this.handler_server_join_bc_return.bind(this), this);
        Server.shared().regDispatch(NetConfig.SM_CANCEL_JOIN_RACE_RESPOND, this.handler_server_cancel_join_return.bind(this), this);
        Server.shared().regDispatch(NetConfig.SM_NOTIFY_BTN_STATUS, this.handler_server_notify_btn_status_return.bind(this), this);
        Server.shared().regDispatch(NetConfig.SM_ADD_RACE, this.handler_server_add_race_return.bind(this), this);
        Server.shared().regDispatch(NetConfig.SM_NOTIFY_RACE_DELETE, this.handler_server_notify_race_delete_return.bind(this), this);
        Server.shared().regDispatch(NetConfig.HEARTBEAT_CMD, this.handler_server_heartbeat_return.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_RANK_INFO_RESPOND, this.handler_server_race_points_rewardlist_return.bind(this), this);
        Server.shared().regDispatch(NetConfig.SM_AVAILABLE_TICKETS, this.handler_server_available_tickets_return.bind(this), this);
        Server.shared().regDispatch(NetConfig.SM_JOIN_RACE_SUCC_V2, this.handler_server_sm_join_race_succ_v2.bind(this), this);
        Server.shared().regDispatch(NetConfig.SM_TRY_JOIN_RACE_BY_TICKET, this.handler_server_try_join_race_by_ticket_return.bind(this), this);
        Server.shared().regDispatch(NetConfig.SM_NOTIFY_REFLUSH_TICKET_LOGO, this.handler_server_notify_reflush_ticket_logo.bind(this), this);
    }
    handler_server_heartbeat_return(t) {
        this.isDisconnectServer = false;
    }
    handler_server_sm_login_err(t) {
        null != t.alertStr && null != t.alertStr && t.alertStr.length > 0 && Utils.shared().showToast(t.alertStr, 2);
        Utils.shared().hideLoading();
        Server.shared().reset();
    }
    handler_server_login_gate_return(t) {
        if (0 == t.res) {
            User.shared().send_match_login_request();
            this.isDisconnectServer = false;
        }
        else {
            Utils.shared().hideLoading();
            let e = ToolUtils.isSafeString(t.msg);
            0 === e.length && (e = i18nMgr.shared().getValueByKey("utlis.text4"));
            Utils.shared().showCommomDialog(e, i18nMgr.shared().getValueByKey("rummy_main.notice"), (t => {
                1 == t && this.doConnectRequest();
            }), true, false);
            2 != t.res && 3 != t.res || (this.isDisconnectServer = true);
        }
    }
    handler_server_login_Rummy_return(t) {
        if (this._hasLoginServer = true, 0 == parseInt("" + t.ret)) {
            sys.isObjectValid(t.session_id) && (User.shared().session_id = t.session_id);
            this.curPage = 1;
            sys.isObjectValid(t.vid) && 431 == t.vid && (this.send_get_race_list(1), this.send_get_available_tickets());
            User.shared().send_request_hall_tableinfo();
        }
        else if (1002 == parseInt("" + t.code)) {
            let e = i18nMgr.shared().getValueByKey("rummy_main.notice"), i = t.alertStr || "", s = ToolUtils.isSafeNumber(t.in_vid), a = ToolUtils.isSafeNumber(t.game_type);
            Utils.shared().showCommomDialog(i, e, (t => {
                1 == t && Utils.shared().showLoadTable(s, a);
            }), false);
        }
        else if (1001 == t.code) {
            let e = i18nMgr.shared().getValueByKey("rummy_main.notice"), i = t.alertStr || "";
            Utils.shared().showCommomDialog(i, e, (t => {
                User.shared().showLogin();
            }), false);
        }
        else {
            let e = i18nMgr.shared().getValueByKey("rummy_main.notice"), i = t.alertStr || "", s = t.code;
            Utils.shared().showCommomDialog(i, e, (t => {
                1 == t && 1003 == s && PushCenter.shared().pushEvent(GameConfig.EnterRoom_LackMoney);
            }), false);
        }
        0 == parseInt("" + t.ret) || Utils.shared().hideLoading();
    }
    handler_server_login_error(t) {
        let e = i18nMgr.shared().getValueByKey("rummy_main.notice"), i = t.msg;
        Server.shared().reset();
        Utils.shared().hideLoading();
        1002 == t.code ? Utils.shared().showCommomDialog(i, e, (t => {
            1 == t && this.doConnectRequest();
        }), true, false) : 1001 == t.code ? Utils.shared().showCommomDialog(i, e, (t => {
            User.shared().showLogin();
        }), false) : (Server.shared().reset(), -1 === t.res && (i = i18nMgr.shared().getValueByKey("utlis.service_upgrade")), Utils.shared().showCommomDialog(i, e, (t => {
        }), false));
    }
    handler_server_race_list(t) {
        if (t.query_id !== this.raceQueryId || t.list_version !== 2) return;
        this.racePagePending = false;
        Utils.shared().hideLoading();
        if (GameConfig.CHIPS_MODLE === 1) {
            this.curPage = 1; this.totalPage = 0; this.matchInfoList = [];
            User.shared().matchInfoList = []; this.renderServerRaceList(); return;
        }
        if (t.ret) { this.send_get_race_list(1); return; }
        if (t.page !== 1 && t.page !== this.curPage + 1) return;
        this.curPage = t.page; this.totalPage = t.total;
        const rows = t.race_info || [];
        this.matchInfoList = t.page === 1 ? rows : (this.matchInfoList || []).concat(rows);
        this.serverRaceStates.clear();
        for (const row of this.matchInfoList) this.serverRaceStates.set(row.raceid, row.btn_status);
        User.shared().matchInfoList = this.matchInfoList;
        const scroll = this.roomlist.getComponent(ScrollView);
        const offset = t.page > 1 ? scroll.getScrollOffset() : null;
        this.renderServerRaceList();
        if (offset) { scroll.stopAutoScroll(); scroll.scrollToOffset(offset, 0); }
        // Fill a short viewport without requiring an impossible scroll gesture.
        if (this.curPage < this.totalPage && this.matchInfoList.length < 4) this.send_get_race_list(this.curPage + 1);
    }
    handler_server_get_race_detaild_return(t) {
        Utils.shared().hideLoading();
        0 == t.ret ? this.showMatchInfoView(t, this.onMobanBtnClick.bind(this)) : 1 != User.shared().match_isDetail && Utils.shared().showToast(t.msg, 2);
    }
    onDealMatchAction(t) {
    }
    handler_server_join_return(t) {
        if (Utils.shared().hideLoading(), 0 == t.ret) {
            let e = t.raceid, i = t.signup_cnt, s = t.btn_status, a = (t.mode, t.discount);
            this.updateMatchInfoList(e, i, 1, s, null, null, a);
            let n = this.getMatchInfoById(e);
            if (this.remindMatchInfo = n || {}, sys.isObjectValid(t.is_rejoin) && 1 == Number(t.is_rejoin) || sys.isObjectValid(t.is_late_join) && 1 == Number(t.is_late_join) || (this._isOpenCalendar ? 1 == AppInfo.shared().getIsCalendarContractAllow() ? (this.setMatchRemind(1), this.updateMatchRoomList(), Utils.shared().showMatchAlertView(5, { parentNode: director.getScene().getChildByName("Canvas"), strContent: t.race_name, strTime: this.remindMatchInfo.time_info })) : Utils.shared().showMatchAlertView(10, { parentNode: director.getScene().getChildByName("Canvas"), strContent: t.race_name, strFunc: "remind_next", callfun: (t = "") => {
                    "remind_next" == t && ToolUtils.isObjValid(this.node) && (1 == AppInfo.shared().getIsCalendarContractAllow() ? (this.setMatchRemind(1), this.updateMatchRoomList()) : AppInfo.shared().requestCalendarContractAllow());
                }, strTime: this.remindMatchInfo.time_info }) : Utils.shared().showMatchAlertView(1, { parentNode: director.getScene().getChildByName("Canvas"), strContent: t.race_name })), n && this.updateMatchView(e, n), User.shared().updateMoney(t.money), null != t.prop_info && t.prop_info.length > 0) {
                for (let e = 0, i = t.prop_info.length; e < i; e++) {
                    User.shared().setPropNumById(t.prop_info[e].pid, t.prop_info[e].value);
                }
            }
            null != t.money && null != t.money && User.shared().updateMoney(t.money);
            let r = { raceid: e, num: t.signup_cnt };
            PushCenter.shared().pushEvent(GameConfig.UpdateRaceJoined, r);
            let o = { raceid: e, btn_status: s };
            PushCenter.shared().pushEvent(GameConfig.UpdateRaceBtnStatus, o);
            let h = { lobby: 1, game: 0, data: null };
            sys.localStorage.setItem(User.shared().data.uid + "recommendRoomNew", ToolUtils.toJsonString(h));
            sys.localStorage.removeItem(User.shared().data.uid + "addRecommendRoomNew");
            this.send_get_available_tickets();
        }
        else if (0 == t.code) {
            t.match_vid;
            let e = ToolUtils.isSafeNumber(t.min_enter);
            Utils.shared().showQuickRecharge(431, null, true, "", 0, e);
            User.shared().updatePayScene(PhpReportDefined.pay_scene.hall_less_money, 431);
        }
        else {
            t.msg && Utils.shared().showToast(t.msg, 2);
        }
    }
    handler_server_join_bc_return(t) {
        let e = t.raceid, i = t.signup_cnt, s = t.reward_value, a = t.btn_status, n = t.discount;
        this.updateMatchInfoList(e, i, null, a, s, null, n);
        let r = this.getMatchInfoById(e);
        if (r) {
            let i = false;
            sys.isObjectValid(t.only_reflush_cnt) && 1 == t.only_reflush_cnt && (i = true);
            this.updateMatchView(e, r, i);
        }
        let o = { raceid: e, num: i, reward_value: s };
        PushCenter.shared().pushEvent(GameConfig.UpdateRaceJoined, o);
    }
    handler_server_cancel_join_return(t) {
        if (0 == t.ret) {
            let e = t.raceid, i = t.signup_cnt, s = t.btn_status;
            sys.isObjectValid(s) || (s = this.RegisterButtonStatus.JOINNOW);
            let a = t.discount;
            if (this.updateMatchInfoList(e, i, 0, s, null, null, a), 1 == this.lastType) {
                this.updateMatchRoomList();
            }
            else {
                let t = this.getMatchInfoById(e);
                t && this.updateMatchView(e, t);
            }
            if (User.shared().updateMoney(t.money), null != t.prop_info && t.prop_info.length > 0) {
                for (let e = 0, i = t.prop_info.length; e < i; e++) {
                    User.shared().setPropNumById(t.prop_info[e].pid, t.prop_info[e].value);
                }
            }
            null != t.money && null != t.money && User.shared().updateMoney(t.money);
            let n = { raceid: e, num: i };
            PushCenter.shared().pushEvent(GameConfig.UpdateRaceJoined, n);
            let r = { raceid: e, btn_status: s };
            if (PushCenter.shared().pushEvent(GameConfig.UpdateRaceBtnStatus, r), Utils.shared().showMatchAlertView(3, { parentNode: director.getScene().getChildByName("Canvas"), strContent: t.race_name, strFunc: "out" }), this._isOpenCalendar) {
                let t = {};
                t.raceid = e;
                t.upcoming_remind = sys.localStorage.getItem("upcoming_" + e);
                t.start_remind = sys.localStorage.getItem("start_" + e);
                this.cancelMatchRemind(t);
            }
        }
        else {
            t.msg && Utils.shared().showToast(t.msg, 2);
        }
    }
    handler_server_notify_btn_status_return(t) {
        let e = t.raceid, i = t.btn_status, s = t.time_info, a = t.discount, n = t.running_entry;
        this.updateMatchInfoList(e, null, null, i, null, s, a, n);
        let r = this.getMatchInfoById(e);
        r && this.updateMatchView(e, r);
        let o = { raceid: e, btn_status: i };
        PushCenter.shared().pushEvent(GameConfig.UpdateRaceBtnStatus, o);
    }
    handler_server_sm_join_race_succ_v2(t) {
        let e = { lobby: 1, game: 0, data: null };
        sys.localStorage.setItem(User.shared().data.uid + "recommendRoomNew", ToolUtils.toJsonString(e));
        sys.localStorage.removeItem(User.shared().data.uid + "addRecommendRoomNew");
    }
    handler_server_add_race_return(t) {
        if (Utils.shared().hideLoading(), 1 == GameConfig.CHIPS_MODLE) {
            return User.shared().matchInfoList = this.matchInfoList = [], void this.updateMatchRoomList();
        }
        let e = t.race_info;
        if (this.matchInfoList && this.matchInfoList.length > 0) {
            null == this.getMatchInfoIndexById(e.raceid) && this.matchInfoList.splice(0, 0, e);
        }
        else {
            this.matchInfoList = [];
            this.matchInfoList.push(e);
        }
        User.shared().matchInfoList = this.matchInfoList;
        this.updateMatchTime(0);
        this.updateMatchTime(0);
        this.updateMatchRoomList();
    }
    handler_server_notify_race_delete_return(t) {
        let e = t.raceid, i = this.getMatchInfoIndexById(e);
        null != i && this.matchInfoList.splice(i, 1);
        this.updateMatchRoomList();
    }
    handler_server_race_points_rewardlist_return(t) {
        PushCenter.shared().pushEvent(PushEvent.RefreshRacePointsRewardList, t);
    }
    handler_server_available_tickets_return(t) {
        let e = t.ret;
        this.ticketsList = [];
        1 == e ? this.ticket_entryNode.active = false : sys.isObjectValid(t.tickets) && Array.isArray(t.tickets) && t.tickets.length > 0 ? (this.ticket_entryNode.active = true, this.ticketsList = t.tickets) : this.ticket_entryNode.active = false;
    }
    handler_server_try_join_race_by_ticket_return(t) {
        let e = t.ret;
        if (0 == e) {
            Utils.shared().showTicketSelectView({ data: t, parent_node: director.getScene().getChildByName("Canvas") });
        }
        else if (1 == e) {
            if (sys.isObjectValid(t.err_code) && 1 == t.err_code) {
                let e = ToolUtils.isSafeNumber(t.entry_fee);
                Utils.shared().showQuickRecharge(431, null, true, "", 0, e);
                User.shared().updatePayScene(PhpReportDefined.pay_scene.hall_less_money, 431);
            }
            else {
                sys.isObjectValid(t.raceid) && this.send_race_rejoin_request(t.raceid, null);
            }
        }
    }
    handler_server_notify_reflush_ticket_logo(t) {
        let e = false, i = 0;
        for (let s = 0, a = this.matchInfoList.length; s < a; s++) {
            let a = this.matchInfoList[s];
            if (e = false, sys.isObjectValid(t.tk_discount)) {
                for (let s = 0; s < t.tk_discount.length; s++) {
                    let n = t.tk_discount[s];
                    if (sys.isObjectValid(n) && n.raceid == a.raceid) {
                        e = true;
                        i = s;
                        break;
                    }
                }
            }
            a.discount = e ? t.tk_discount[i].discount : 0;
        }
        this.updateMatchRoomList();
        this.send_get_available_tickets();
    }
    listenMatchHistoryCallback(t, e, i) {
        if (Utils.shared().hideLoading(), ToolUtils.isObjValid(this.node)) {
            if (200 != i) {
                Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text29"), 2);
            }
            else {
                try {
                    let t = ToolUtils.parseJson(e);
                    0 == t.ret && ToolUtils.isObjValid(this.node) && (this.histroyList = t.data, this.renderServerRaceList());
                }
                catch (t) {
                    TLog.printError("listenMatchHistoryCallback err:", t);
                }
            }
        }
    }
    listenMatchHistoryContentCallback(t, e, i) {
        if (Utils.shared().hideLoading(), ToolUtils.isObjValid(this.node)) {
            if (200 != i) {
                Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text29"), 2);
            }
            else {
                try {
                    let t = ToolUtils.parseJson(e);
                    if (0 == t.ret && t.data) {
                        let e = t.data.raceinfo;
                        this.showMatchInfoView(e, this.onMobanBtnClick.bind(this));
                    }
                }
                catch (t) {
                    TLog.printError("listenMatchHistoryContentCallback err:", t);
                }
            }
        }
    }
    initMatchRoomItem(t, e) {
        if (!ToolUtils.isObjValid(t)) {
            return;
        }
        t.active = true;
        let i = t.getChildByName("title"), s = t.getChildByName("title_time"), a = t.getChildByName("time"), n = (t.getChildByName("icon"), t.getChildByName("reward")), r = t.getChildByName("progress"), o = t.getChildByName("join"), h = t.getChildByName("status_btn"), c = h.getChildByName("layout").getChildByName("flag"), g = h.getChildByName("layout").getChildByName("wz"), p = (t.getChildByName("bg"), t.getChildByName("entry").getChildByName("wz"));
        i.getComponent(Label).string = e.race_name + ">";
        e.btn_status == this.RegisterButtonStatus.UPCOMING ? i18nMgr.shared().changeLabelLanguage(s.getComponent(Label), "match_info.regist_at") : i18nMgr.shared().changeLabelLanguage(s.getComponent(Label), "match_info.starts_at");
        1 == e.mode || 3 == e.mode ? e.btn_status == this.RegisterButtonStatus.UPCOMING && Number(e.will_ready_time) > 0 && Number(e.will_ready_time) <= 10800 ? (a.getComponent(Label).string = ToolUtils.timeStr2(e.will_ready_time, true), i18nMgr.shared().changeLabelLanguage(s.getComponent(Label), "match_info.regist_in")) : (e.btn_status == this.RegisterButtonStatus.JOINNOW || e.btn_status == this.RegisterButtonStatus.WITHDRAW) && e.will_start_time > 0 && Number(e.will_start_time) <= 10800 ? (a.getComponent(Label).string = ToolUtils.timeStr2(e.will_start_time, true), i18nMgr.shared().changeLabelLanguage(s.getComponent(Label), "match_info.starts_in")) : a.getComponent(Label).string = e.time_info : a.getComponent(Label).string = i18nMgr.shared().getValueByKey("tournament.start_full");
        let y = "" + ToolUtils.parse_double(e.reward_value, 0);
        if (sys.isObjectValid(e.mixed) && 1 == e.mixed && (y += "*"), n.getComponent(Label).string = ToolUtils.format("Reward: Rs ${0}", y), 3 == e.mode ? sys.isObjectValid(e.can_join_times) && sys.isObjectValid(e.entry_times) && i18nMgr.shared().changeLabelLanguage(o.getComponent(Label), "tournament.entry_times", false, e.can_join_times, e.entry_times) : o.getComponent(Label).string = ToolUtils.format("${0} Joined", e.num), 3 == e.mode ? r.active = false : (r.active = true, r.getComponent(ProgressBar).progress = e.num / e.total_num), e.btn_status != this.RegisterButtonStatus.REJOIN && e.btn_status != this.RegisterButtonStatus.LATE_JOIN || !sys.isObjectValid(e.running_entry)) {
            let t = "", i = 0;
            if (e.ticket_mode && e.ticket_mode.length > 0) {
                for (let s = 0, a = e.ticket_mode.length; s < a; s++) {
                    if (e.ticket_mode[s].pay_info && e.ticket_mode[s].pay_info.length > 0) {
                        for (let a = 0, n = e.ticket_mode[s].pay_info.length; a < n; a++) {
                            0 == e.ticket_mode[s].pay_info[a].type ? (t = ToolUtils.format("${0}₹${1}", t, e.ticket_mode[s].pay_info[a].value), i += e.ticket_mode[s].pay_info[a].value) : 1 == e.ticket_mode[s].pay_info[a].type && (t += i18nMgr.shared().getValueByKey("tournament.ticket"));
                            a != n - 1 && (t = ToolUtils.format("${0}&&", t));
                        }
                    }
                    s != a - 1 && (t = ToolUtils.format("${0}/", t));
                }
            }
            else {
                t = i18nMgr.shared().getValueByKey("tournament.free");
            }
            p.getComponent(Label).string = t;
        }
        else {
            let t = "Free";
            Number(e.running_entry) > 0 && (t = ToolUtils.format("₹${0}", e.running_entry));
            p.getComponent(Label).string = t;
        }
        let b = this.matchBtnStatus[e.btn_status];
        this._isOpenCalendar ? c.active = e.btn_status == this.RegisterButtonStatus.UPCOMING : c.active = false;
        e.btn_status == this.RegisterButtonStatus.UPCOMING ? (h.getComponent(Button).interactable = true, h.getComponent(Button).normalSprite = this.btnStateFrame[2], this._isOpenCalendar ? sys.isObjectValid(e.upcoming_remind) && ToolUtils.isSafeString(e.upcoming_remind).length > 0 ? (b = "tournament.upcoming5", c.getComponent(Sprite).spriteFrame = this.remindFlagFrame[1], h.getComponent(Sprite).color = color(139, 198, 142), g.getComponent(Label).color = color(70, 153, 72), c.getComponent(Sprite).color = color(70, 153, 72)) : (b = "tournament.upcoming4", c.getComponent(Sprite).spriteFrame = this.remindFlagFrame[0], h.getComponent(Sprite).color = color(220, 220, 220), g.getComponent(Label).color = color(69, 69, 69), c.getComponent(Sprite).color = color(69, 69, 69)) : (h.getComponent(Sprite).color = color(220, 220, 220), g.getComponent(Label).color = color(69, 69, 69), 3 == e.mode && (b = "tournament.upcoming"))) : e.btn_status == this.RegisterButtonStatus.JOINNOW ? (h.getComponent(Button).interactable = true, h.getComponent(Button).normalSprite = this.btnStateFrame[1], h.getComponent(Sprite).color = color(255, 255, 255), g.getComponent(Label).color = color(255, 255, 255), 3 == e.mode && (b = "tournament.join_now")) : e.btn_status == this.RegisterButtonStatus.WITHDRAW ? (h.getComponent(Button).interactable = true, h.getComponent(Button).normalSprite = this.btnStateFrame[2], h.getComponent(Sprite).color = color(220, 220, 220), g.getComponent(Label).color = color(69, 69, 69), 3 == e.mode && (b = "tournament.withdraw")) : e.btn_status == this.RegisterButtonStatus.FULL ? (h.getComponent(Button).interactable = true, h.getComponent(Button).normalSprite = this.btnStateFrame[2], h.getComponent(Sprite).color = color(220, 220, 220), g.getComponent(Label).color = color(69, 69, 69), 3 == e.mode && (b = "tournament.full")) : e.btn_status == this.RegisterButtonStatus.ENTER ? 3 == e.mode ? (h.getComponent(Button).interactable = true, b = "tournament.enter", h.getComponent(Button).normalSprite = this.btnStateFrame[0], h.getComponent(Sprite).color = color(255, 255, 255), g.getComponent(Label).color = color(255, 255, 255)) : (h.getComponent(Button).interactable = true, b = "tournament.running", h.getComponent(Button).normalSprite = this.btnStateFrame[3], h.getComponent(Sprite).color = color(255, 255, 255), g.getComponent(Label).color = color(70, 153, 75)) : e.btn_status == this.RegisterButtonStatus.ELIMINATED ? 3 == e.mode ? (h.getComponent(Button).interactable = true, b = "tournament.join_now", h.getComponent(Button).normalSprite = this.btnStateFrame[1], h.getComponent(Sprite).color = color(255, 255, 255), g.getComponent(Label).color = color(255, 255, 255)) : (h.getComponent(Button).interactable = true, b = "tournament.eliminated2", h.getComponent(Button).normalSprite = this.btnStateFrame[4], h.getComponent(Sprite).color = color(240, 240, 240), g.getComponent(Label).color = color(207, 65, 65)) : e.btn_status == this.RegisterButtonStatus.RUNNING ? (h.getComponent(Button).interactable = true, b = "tournament.running", h.getComponent(Button).normalSprite = this.btnStateFrame[3], h.getComponent(Sprite).color = color(255, 255, 255), g.getComponent(Label).color = color(70, 153, 75)) : e.btn_status == this.RegisterButtonStatus.REJOIN ? (h.getComponent(Button).interactable = true, b = "tournament.rejoin2", h.getComponent(Button).normalSprite = this.btnStateFrame[1], h.getComponent(Sprite).color = color(255, 255, 255), g.getComponent(Label).color = color(255, 255, 255)) : e.btn_status == this.RegisterButtonStatus.LATE_JOIN ? (h.getComponent(Button).interactable = true, h.getComponent(Button).normalSprite = this.btnStateFrame[1], h.getComponent(Sprite).color = color(255, 255, 255), g.getComponent(Label).color = color(255, 255, 255)) : e.btn_status == this.RegisterButtonStatus.EARLY_SEATING ? (h.getComponent(Button).interactable = true, h.getComponent(Button).normalSprite = this.btnStateFrame[0], h.getComponent(Sprite).color = color(255, 255, 255), g.getComponent(Label).color = color(255, 255, 255)) : (h.getComponent(Button).interactable = true, h.getComponent(Button).normalSprite = this.btnStateFrame[2], h.getComponent(Sprite).color = color(138, 190, 142), g.getComponent(Label).color = color(70, 153, 72), b = "tournament.viewWinner2");
        g.getComponent(Label).string = ToolUtils.format("${0}", i18nMgr.shared().getValueByKey(b));
        let C = ToolUtils.isSafeNumber(e.isphp), S = { raceid: e.raceid, race_name: e.race_name, status: e.btn_status, payinfo: e.ticket_mode, isphp: C, mode: e.mode, time_info: e.time_info, upcoming_remind: e.upcoming_remind, will_ready_time: e.will_ready_time, will_start_time: e.will_start_time };
        h.getComponent(Button).clickEvents[0].customEventData = ToolUtils.toJsonString(S);
        t.getComponent(Button).clickEvents[0].customEventData = ToolUtils.toJsonString(S);
    }
    updateMatchRoomList(t = false) {
        const scroll = this.roomlist.getComponent(ScrollView);
        scroll.stopAutoScroll(); scroll.scrollToTop(0);
        this.send_get_race_list(1);
    }
    renderServerRaceList() {
        this.sortMatchInfo(); // Restore local reminder metadata; preserves server order.
        const f = this.curMatchFilterTag[this.lastType];
        this.reFreshList(this.getMatchListByStatusAndType2(f.gameStatus, f.gameFee, f.startTime, f.prizePool));
    }
    scrollRefreshCallBack() {
        if (!this.racePagePending && this.curPage < this.totalPage) this.send_get_race_list(this.curPage + 1);
    }
    addListItem(t, e = false) {
        let i = 0, s = this.room_moban.getComponent(UITransform).contentSize.height, a = this.roomlist.getComponent(ScrollView).view, n = this.roomlist.getComponent(ScrollView).content, r = t.length;
        for (let a = 0; a < r; a++) {
            if (ToolUtils.isObjValid(this._items[a])) {
                this._items[a].setPosition(v3(0, i));
                this._items[a].active = true;
            }
            else {
                let t = instantiate(this.room_moban);
                t.active = true;
                t.setPosition(v3(0, i));
                n.addChild(t);
                this._items[a] = t;
            }
            this._items[a].getComponent(UIOpacity).opacity = e ? 0 : 255;
            this.initMatchRoomItem(this._items[a], t[a]);
            i += -(s + 0);
        }
        for (let t = r, e = this._items.length; t < e; t++) {
            ToolUtils.isObjValid(this._items[t]) && (this._items[t].active = false);
        }
        let o = n.getComponent(UITransform).contentSize;
        n.getComponent(UITransform).setContentSize(size(o.width, s * r));
        this._scrollUtil.setScollDetails2(2, a.height, r, true, 40, this.scrollRefreshCallBack.bind(this));
    }
    reFreshList(t, e = false) {
        let i = this.roomlist.getComponent(ScrollView).content;
        if (t && t.length > 0) {
            let i = t.length;
            return this.total_num = i, this._listData = t, this.nodata.active = false, this.matchSortNode.active = true, this.addListItem(t, e), void (e && this.playRoomInfoAnim());
        }
        Array.isArray(i.children) && i.children.length > 0 && i.removeAllChildren();
        this._items = [];
        this._listData = [];
        this.nodata.active = true;
        this.matchSortNode.active = this.matchInfoList.length > 0;
        this.total_num = 0;
        this.pageIndex = 0;
        0 == this.lastType ? this.nodata.getChildByName("tips").getComponent(Label).string = "No tournaments scheduled right now" : 1 == GameConfig.CHIPS_MODLE ? this.nodata.getChildByName("tips").getComponent(Label).string = "You haven't join any tournaments till now." : this.nodata.getChildByName("tips").getComponent(Label).string = "You haven't join any tournaments till now.\nJoin to win big cash prize";
    }
    updateMatchView(t, e, i = false) {
        // Broadcasts update the same race by identity, never by a new sorted index.
        const index = this._listData.findIndex(row => row.raceid === t);
        if (index >= 0) { this._listData[index] = e; this.initMatchRoomItem(this._items[index], e); }
        const stateChanged = this.serverRaceStates.get(t) !== e.btn_status;
        if ((!i || stateChanged) && !this.raceQueryRefreshPending) {
            this.raceQueryRefreshPending = true;
            this.scheduleOnce(() => {
                this.raceQueryRefreshPending = false;
                if (this.node && this.node.active) this.send_get_race_list(1);
            }, 0.2);
        }
    }
    getMatchInfoById(t) {
        if (this.matchInfoList && this.matchInfoList.length > 0) {
            for (let e = 0, i = this.matchInfoList.length; e < i; e++) {
                if (this.matchInfoList[e].raceid == t) {
                    return this.matchInfoList[e];
                }
            }
        }
        return null;
    }
    getMatchInfoIndexById(t) {
        if (this.matchInfoList && this.matchInfoList.length > 0) {
            for (let e = 0, i = this.matchInfoList.length; e < i; e++) {
                if (this.matchInfoList[e].raceid == t) {
                    return e;
                }
            }
        }
        return null;
    }
    sortMatchInfo() {
        // Sorting and filtering are owned by 7208/7209. Calendar IDs are local.
        for (const row of this.matchInfoList || []) {
            row.upcoming_remind = sys.localStorage.getItem("upcoming_" + row.raceid);
            row.start_remind = sys.localStorage.getItem("start_" + row.raceid);
        }
        User.shared().matchInfoList = this.matchInfoList;
    }
    checkIsUnderFilter(t, e, i, s, a, n, r, o, h) {
        let l = 1 == ToolUtils.isSafeNumber(t[0]);
        if (e = Number(e), !l && (1 == ToolUtils.isSafeNumber(t[1]) && (l = e == this.RegisterButtonStatus.JOINNOW || e == this.RegisterButtonStatus.REJOIN || e == this.RegisterButtonStatus.WITHDRAW || e == this.RegisterButtonStatus.FULL || e == this.RegisterButtonStatus.ELIMINATED && 3 == h), l || 1 != ToolUtils.isSafeNumber(t[2]) || (l = e == this.RegisterButtonStatus.ELIMINATED && 3 != h || e == this.RegisterButtonStatus.RUNNING || e == this.RegisterButtonStatus.ENTER || e == this.RegisterButtonStatus.LATE_JOIN), l || 1 != ToolUtils.isSafeNumber(t[3]) || (l = e == this.RegisterButtonStatus.UPCOMING || e == this.RegisterButtonStatus.EARLY_SEATING), l || 1 != ToolUtils.isSafeNumber(t[4]) || (l = e == this.RegisterButtonStatus.COMPLETED), !l)) {
            return false;
        }
        let c = !i.includes(1);
        if (!c && (s = Number(s), 1 == ToolUtils.isSafeNumber(i[0]) && (c = 0 == s), c || 1 != ToolUtils.isSafeNumber(i[1]) || (c = s > 0.1 && s <= 10), c || 1 != ToolUtils.isSafeNumber(i[2]) || (c = s > 10), !c)) {
            return false;
        }
        let d = 1 == ToolUtils.isSafeNumber(a[0]);
        if (!d && (n = Number(n), n = Math.abs(n), 1 == ToolUtils.isSafeNumber(a[1]) && (d = n <= 600), d || 1 != ToolUtils.isSafeNumber(a[2]) || (d = n <= 1800), d || 1 != ToolUtils.isSafeNumber(a[3]) || (d = n <= 3600), d || 1 != ToolUtils.isSafeNumber(a[4]) || (d = n > 3600), d && (e == this.RegisterButtonStatus.ELIMINATED && 3 != h || e == this.RegisterButtonStatus.RUNNING || e == this.RegisterButtonStatus.ENTER) && (d = false), d && e == this.RegisterButtonStatus.COMPLETED && (d = false), !d)) {
            return false;
        }
        let m = 1 == ToolUtils.isSafeNumber(r[0]);
        return !(!m && (o = Number(o), 1 == ToolUtils.isSafeNumber(r[1]) && (m = o <= 100), m || 1 != ToolUtils.isSafeNumber(r[2]) || (m = o > 100 && o <= 500), m || 1 != ToolUtils.isSafeNumber(r[3]) || (m = o > 500 && o <= 1000), m || 1 != ToolUtils.isSafeNumber(r[4]) || (m = o > 1000), !m));
    }
    getMatchListByStatusAndType2(t, e, i, s) {
        const rows = (this.matchInfoList || []).slice();
        // Completed history is a separate HTTP resource, with its existing UI.
        if (this.lastType === 1) {
            const ids = new Set(rows.map(row => row.raceid));
            for (const row of this.histroyList || []) {
                if (!ids.has(row.raceid) && (t[0] === 1 || this.checkIsUnderFilter(t, row.status, [0], 0, [1], 0, [1], 0, 0))) rows.push(row);
            }
        }
        return rows;
    }
    updateMatchInfoList(t, e, i, s, a, n, r, o) {
        if (this.matchInfoList && this.matchInfoList.length > 0) {
            for (let h = 0, l = this.matchInfoList.length; h < l; h++) {
                if (this.matchInfoList[h].raceid == t) {
                    if (null != e && (this.matchInfoList[h].num = e), null != i && (this.matchInfoList[h].isjoin = i), a && (this.matchInfoList[h].reward_value = a), n && (this.matchInfoList[h].time_info = n), o && (this.matchInfoList[h].running_entry = o), null != s) {
                        this.matchInfoList[h].btn_status = s;
                        s == this.RegisterButtonStatus.UPCOMING ? this.matchInfoList[h].state = 5 : s == this.RegisterButtonStatus.JOINNOW || s == this.RegisterButtonStatus.WITHDRAW || s == this.RegisterButtonStatus.FULL ? this.matchInfoList[h].state = 1 : s == this.RegisterButtonStatus.ENTER || s == this.RegisterButtonStatus.ELIMINATED || s == this.RegisterButtonStatus.RUNNING ? this.matchInfoList[h].state = 3 : this.matchInfoList[h].state = 4;
                        // The following broadcast handler requests server filtering when state changes.
                    }
                    this.matchInfoList[h].discount = r;
                    break;
                }
            }
        }
    }
    updateGameType(t) {
        if (t === this.lastType) return;
        this.refreshSwitchTab(t); this.lastType = t;
        this.histroyList = [];
        this.roomlist.getComponent(ScrollView).stopAutoScroll();
        this.roomlist.getComponent(ScrollView).scrollToTop(0);
        this.send_get_race_list(1);
        if (t === 1) HttpManager.shared().doGetMatchHistory(this.listenMatchHistoryCallback.bind(this));
        this.updateFilterBtnStatus();
    }
    initSelectView() {
        if (1 == this.lastType) {
            this.selectView.getChildByName("bg").getComponent(UITransform).contentSize = size(view.getVisibleSize().width, 336);
            this.selectView.getChildByName("reset_btn").setPosition(v3(-120, -286));
            this.selectView.getChildByName("confirm_btn").setPosition(v3(120, -286));
            this.selectView.getChildByName("type_title").active = false;
            for (let t = 1; t < 6; t++) {
                this.selectView.getChildByName(ToolUtils.format("type_btn${0}", t)).active = false;
            }
            let t = 1;
            for (let e = 1; e < 7; e++) {
                let i = this.selectView.getChildByName(ToolUtils.format("status_btn${0}", e));
                if (3 == e || 6 == e) {
                    i.active = false;
                }
                else {
                    i.active = true;
                    let e = 230 * Math.floor((t - 1) % 3) - 230, s = -113 - 80 * Math.floor((t - 1) / 3);
                    i.setPosition(v3(e, s));
                    t += 1;
                }
            }
        }
        else {
            this.selectView.getChildByName("bg").getComponent(UITransform).contentSize = size(view.getVisibleSize().width, 476);
            this.selectView.getChildByName("reset_btn").setPosition(v3(-120, -426));
            this.selectView.getChildByName("confirm_btn").setPosition(v3(120, -426));
            this.selectView.getChildByName("status_title").active = true;
            for (let t = 1; t < 7; t++) {
                let e = this.selectView.getChildByName(ToolUtils.format("status_btn${0}", t));
                e.active = true;
                let i = 230 * Math.floor((t - 1) % 3) - 230, s = -113 - 80 * Math.floor((t - 1) / 3);
                e.setPosition(v3(i, s));
            }
            this.selectView.getChildByName("type_title").active = true;
            for (let t = 1; t < 6; t++) {
                let e = this.selectView.getChildByName(ToolUtils.format("type_btn${0}", t));
                e.active = 4 != t && 5 != t;
            }
        }
    }
    updateFilterBtnStatus() {
        let t = this.btnSelect.getChildByName("img"), e = t.getChildByName("all"), i = this.curMatchFilterTag[this.lastType].gameStatus, s = this.curMatchFilterTag[this.lastType].gameFee, a = this.curMatchFilterTag[this.lastType].startTime, n = this.curMatchFilterTag[this.lastType].prizePool;
        1 != ToolUtils.isSafeNumber(i[0]) || s.includes(1) || 1 != ToolUtils.isSafeNumber(a[0]) || 1 != ToolUtils.isSafeNumber(n[0]) ? (t.getComponent(Sprite).color = this.filter_select_color, e.getComponent(Label).color = this.filter_select_color) : (t.getComponent(Sprite).color = color(102, 102, 102, 255), e.getComponent(Label).color = color(102, 102, 102, 255));
    }
    showMatchInfoView(t, e) {
        let i = -1;
        sys.isObjectValid(this.curEventData.btn_status) && (this.curEventData.btn_status == this.RegisterButtonStatus.UPCOMING || this.curEventData.btn_status == this.RegisterButtonStatus.FULL || this.curEventData.btn_status == this.RegisterButtonStatus.RUNNING || this.curEventData.btn_status == this.RegisterButtonStatus.REJOIN ? i = 0 : this.curEventData.btn_status != this.RegisterButtonStatus.ELIMINATED && this.curEventData.btn_status != this.RegisterButtonStatus.COMPLETED || (i = 2));
        Utils.shared().showMatchInfoView(t, e, i);
    }
    onButtonClick(t, e) {
        if (SoundManager.shared().playFx("click"), "close" == e) {
            User.shared().doSendMatchOnlineStatus(0);
        }
        else if ("select" == e) {
            try {
                if (sys.isObjectValid(this.selectMatchPrefab) && this.selectMatchPrefab.isValid && !ToolUtils.isObjValid(this.selectView) && 2 == User.shared().hall_select_tab) {
                    this.selectView = instantiate(this.selectMatchPrefab);
                    let t = null, e = director.getScene().getChildByName("Canvas");
                    if (e) {
                        let i = e.getChildByName("hall_root");
                        ToolUtils.isObjValid(i) && ToolUtils.isObjValid(i.getChildByName("pageRoot")) && (t = i.getChildByName("pageRoot").getChildByName("page2").getChildByName("lobby_root"));
                    }
                    ToolUtils.isObjValid(t) ? this.selectView.parent = t : this.selectView.parent = e;
                    let i = this.selectView.getComponent("FilterMatchView"), s = this.curMatchFilterTag[this.lastType], a = [[1], [0], [1], [1]];
                    a[0] = s.gameStatus;
                    a[1] = s.gameFee;
                    a[2] = s.startTime;
                    a[3] = s.prizePool;
                    let n = { curMatchFilterTag: a };
                    i.initData(n, (t => {
                        let e = this.curMatchFilterTag[this.lastType];
                        e.gameStatus = [1];
                        for (let i = 0, s = t.MatchFilterTag[0].length; i < s; i++) {
                            e.gameStatus[i] = t.MatchFilterTag[0][i];
                        }
                        e.gameFee = [0];
                        for (let i = 0, s = t.MatchFilterTag[1].length; i < s; i++) {
                            e.gameFee[i] = t.MatchFilterTag[1][i];
                        }
                        e.startTime = [1];
                        for (let i = 0, s = t.MatchFilterTag[2].length; i < s; i++) {
                            e.startTime[i] = t.MatchFilterTag[2][i];
                        }
                        e.prizePool = [1];
                        for (let i = 0, s = t.MatchFilterTag[3].length; i < s; i++) {
                            e.prizePool[i] = t.MatchFilterTag[3][i];
                        }
                        this.updateFilterBtnStatus();
                        this.updateMatchRoomList();
                    }));
                }
            }
            catch (t) {
                TLog.printError("MatchRoom init selectView:", t);
            }
        }
        else {
            "sort_start" == e ? (this._sortStart = (this._sortStart + 1) % 3, this._sortEntry = this._sortPrize = this._sortJoin = 0, this.updateSortBtnStatus(), this.updateMatchRoomList()) : "sort_entry" == e ? (this._sortEntry = (this._sortEntry + 1) % 3, this._sortStart = this._sortPrize = this._sortJoin = 0, this.updateSortBtnStatus(), this.updateMatchRoomList()) : "sort_prize" == e ? (this._sortPrize = (this._sortPrize + 1) % 3, this._sortStart = this._sortEntry = this._sortJoin = 0, this.updateSortBtnStatus(), this.updateMatchRoomList()) : "sort_join" == e ? (this._sortJoin = (this._sortJoin + 1) % 3, this._sortStart = this._sortEntry = this._sortPrize = 0, this.updateSortBtnStatus(), this.updateMatchRoomList()) : "ticket_entry" == e && Utils.shared().showTicketUsingView({ data: this.ticketsList, parent_node: director.getScene().getChildByName("Canvas") });
        }
    }
    setMatchRemind(t = 0) {
        let e = 0 == GameConfig.GAME_APP_THEME ? URLConfig.calendar_master_url : URLConfig.calendar_circ_url, i = 0 == GameConfig.GAME_APP_THEME ? CommDefine.AppName_rummy : CommDefine.AppName_circ;
        if (0 == t) {
            let t = ToolUtils.format(i18nMgr.shared().getValueByKey("tournament.register_title"), i, this.remindMatchInfo.race_name, this.remindMatchInfo.time_info), s = ToolUtils.format(i18nMgr.shared().getValueByKey("tournament.register_content"), i, this.remindMatchInfo.race_name, e + "?reg=" + this.remindMatchInfo.raceid), a = AppInfo.shared().setCalendarContract(this.remindMatchInfo.will_ready_time, 300, 0, t, s);
            a.length > 0 && (ToolUtils.saveData("upcoming_" + this.remindMatchInfo.raceid, a), this.saveCurRaceId(this.remindMatchInfo.raceid), Utils.shared().showToast(ToolUtils.format("You will get a reminder when the tournament registration starts at ${0}", this.remindMatchInfo.time_info), 3));
        }
        else {
            let t = ToolUtils.format(i18nMgr.shared().getValueByKey("tournament.start_title"), i, this.remindMatchInfo.race_name, this.remindMatchInfo.time_info), s = ToolUtils.format(i18nMgr.shared().getValueByKey("tournament.start_content"), i, this.remindMatchInfo.race_name, e + "?enter=" + this.remindMatchInfo.raceid), a = AppInfo.shared().setCalendarContract(this.remindMatchInfo.will_start_time, 600, 5, t, s);
            a.length > 0 && (ToolUtils.saveData("start_" + this.remindMatchInfo.raceid, a), this.saveCurRaceId(this.remindMatchInfo.raceid));
        }
    }
    cancelMatchRemind(t, e = true) {
        e && sys.isObjectValid(t.upcoming_remind) && t.upcoming_remind.length > 0 && AppInfo.shared().cancelCalendarContract(t.upcoming_remind);
        sys.localStorage.removeItem("upcoming_" + t.raceid);
        e && sys.isObjectValid(t.start_remind) && t.start_remind.length > 0 && AppInfo.shared().cancelCalendarContract(t.start_remind);
        sys.localStorage.removeItem("start_" + t.raceid);
    }
    saveCurRaceId(t) {
        if (String(t).length > 0) {
            let e = [], i = localStorage.getItem("RemainRaceData");
            sys.isObjectValid(i) && "" != i ? (e = ToolUtils.parseJson(i), e.includes(t) || e.push(t)) : e.push(t);
            ToolUtils.saveData("RemainRaceData", ToolUtils.toJsonString(e));
        }
    }
    updateSortBtnStatus() {
        let t = [this._sortStart, this._sortEntry, this._sortPrize, this._sortJoin];
        for (let e, i, s = 0, a = this.sortBtns.length; s < a; s++) {
            e = this.sortBtns[s];
            i = t[s];
            ToolUtils.isObjValid(e) && sys.isObjectValid(this.sortFlagFrame[i]) && (e.getChildByName("arrow").getComponent(Sprite).spriteFrame = this.sortFlagFrame[i], 0 == i ? (e.getChildByName("wz").getComponent(Label).color = color(102, 102, 102), e.getChildByName("ico").getComponent(Sprite).spriteFrame = this.sortBtnFrame[0], e.getChildByName("arrow").getComponent(Sprite).color = color(102, 102, 102)) : (e.getChildByName("wz").getComponent(Label).color = this.filter_select_color, e.getChildByName("ico").getComponent(Sprite).spriteFrame = this.sortBtnFrame[1], e.getChildByName("arrow").getComponent(Sprite).color = color(255, 255, 255)));
        }
    }
    onSwitchGameTypeClick(t, e) {
        SoundManager.shared().playFx("click");
        this.updateGameType(Number(e));
    }
    onGameDetaildClick(t, e) {
        if (SoundManager.shared().playFx("click"), !User.shared().checkCanPlayCashGame(CheckModule.CASH_PLAY)) {
            return;
        }
        let i = ToolUtils.parseJson(e);
        this.onReqGameDetail(i);
    }
    onReqGameDetail(t) {
        Utils.shared().showLoading(10, true);
        this.curEventData = t;
        let e = t.raceid;
        1 == t.isphp ? HttpManager.shared().doGetMatchHistoryContent(e, this.listenMatchHistoryContentCallback.bind(this)) : this.send_get_race_detaild_request(e);
    }
    onMobanBtnClick(t, e) {
        if (SoundManager.shared().playFx("click"), !User.shared().checkCanPlayCashGame(CheckModule.CASH_PLAY)) {
            return;
        }
        if (1 == Utils.shared().showFastKyc()) {
            return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("kyc.kyc_match"), 2);
        }
        let i = Utils.shared().judgeMatchRoomUnlock();
        if (i && !i.openBol) {
            return void Utils.shared().showRoomUnlockDialog(1, i.num);
        }
        let s = ToolUtils.parseJson(e), a = false;
        this.btnClickStatus.has(s.raceid) && (a = this.btnClickStatus.get(s.raceid));
        this.btnClickStatus.set(s.raceid, true);
        let n = t.target;
        if (TweenTool.delayAct(n, (() => {
            this.btnClickStatus.set(s.raceid, false);
        }), 1, true), !a) {
            if (s.status == this.RegisterButtonStatus.JOINNOW || s.status == this.RegisterButtonStatus.REJOIN || s.status == this.RegisterButtonStatus.LATE_JOIN) {
                let t = 0, e = 0, i = s.payinfo;
                if (i && i.length > 1) {
                    for (let s = 0, a = i.length; s < a; s++) {
                        0 == i[s].pay_type ? (t = i[s].pay_info[0].value, i[s].pay_type) : 1 == i[s].pay_type && (e = i[s].pay_info[0].value, i[s].pay_type);
                    }
                    let a = "", n = false, r = i18nMgr.shared().getValueByKey("match_info.register"), o = "", h = User.shared().getPropNumById(100001);
                    if (0 != t && 0 != e && e <= h) {
                        if (a = ToolUtils.format(i18nMgr.shared().getValueByKey("utlis.text8"), t, e), n = true, r = i18nMgr.shared().getValueByKey("utlis.cash"), o = i18nMgr.shared().getValueByKey("menu.ticket"), "" != a) {
                            let t = i18nMgr.shared().getValueByKey("gameRummy_notice_Pop.notice");
                            Utils.shared().showCommomDialog(a, t, (t => {
                                (1 == t || 3 == t) && (Utils.shared().showLoading(10, true), User.shared().send_try_join_race_by_ticket(s.raceid, null));
                            }), n, false, r, o);
                            Utils.shared().setCommomDialogBtnText(r, o);
                        }
                    }
                    else {
                        0 != t ? (a = ToolUtils.format(i18nMgr.shared().getValueByKey("utlis.text9"), t), User.shared().send_try_join_race_by_ticket(s.raceid, null)) : (a = ToolUtils.format(i18nMgr.shared().getValueByKey("utlis.text10"), e), User.shared().send_try_join_race_by_ticket(s.raceid, null));
                    }
                }
                else if (i && i.length > 0) {
                    for (let s = 0, a = i[0].pay_info.length; s < a; s++) {
                        0 == i[0].pay_info[s].type ? t = i[0].pay_info[s].value : e = i[0].pay_info[s].value;
                    }
                    User.shared().send_try_join_race_by_ticket(s.raceid, null);
                }
                else {
                    User.shared().send_try_join_race_by_ticket(s.raceid, null);
                }
            }
            else {
                s.status == this.RegisterButtonStatus.WITHDRAW ? Utils.shared().showMatchAlertView(2, { parentNode: director.getScene().getChildByName("Canvas"), strContent: s.race_name, callfun: t => {
                        "out" == t && sys.isObjectValid(this.node) && this.send_race_cancel_join_request(s.raceid);
                    } }) : s.status == this.RegisterButtonStatus.ENTER || s.status == this.RegisterButtonStatus.EARLY_SEATING ? Utils.shared().showLoadTable(430, HowToPlayDefined.gameId_RaceRummy, null, null, null, null, s.raceid, 1) : this._isOpenCalendar && s.status == this.RegisterButtonStatus.UPCOMING ? sys.isObjectValid(s.upcoming_remind) && ToolUtils.isSafeString(s.upcoming_remind).length > 0 ? Utils.shared().showMatchAlertView(7, { parentNode: director.getScene().getChildByName("Canvas"), strContent: s.race_name, strTime: s.time_info }) : (this.remindMatchInfo = s, 1 == AppInfo.shared().getIsCalendarContractAllow() ? (this.setMatchRemind(), this.updateMatchRoomList()) : Utils.shared().showMatchAlertView(6, { parentNode: director.getScene().getChildByName("Canvas"), strContent: s.race_name, strFunc: "remind_next", strTime: s.time_info, callfun: (t = "") => {
                        "remind_next" == t && ToolUtils.isObjValid(this.node) && (1 == AppInfo.shared().getIsCalendarContractAllow() ? (this.setMatchRemind(), this.updateMatchRoomList()) : AppInfo.shared().requestCalendarContractAllow());
                    } })) : this.onReqGameDetail(s);
            }
        }
    }
    fitScreen() {
        let t = sys.getSafeAreaRect().y;
        ToolUtils.isPadPlatform() && (t = 0);
        let e = 0;
        ToolUtils.getSafeDistance() > 40 && (e = 20);
        let i = view.getVisibleSize().height - GameConfig.CONFIG_SCREEN_HEIGHT - t, s = this.roomlist.getComponent(ScrollView).view;
        this.roomlist.getComponent(UITransform).setContentSize(size(s.width, s.height + i + e));
        this.ticket_entryNode.setPosition(new Vec3(305, -736 - i));
    }
    onDestroy() {
        PushCenter.shared().removeListenersByTag(this);
        Server.shared().clearEventByTarget(this);
        User.shared().doSendMatchOnlineStatus(0);
        TweenTool.stopNodeAction(this.time_node);
    }
    playRoomInfoAnim() {
        if (!this.roomlist.getComponent(ScrollView).isScrolling()) {
            let t, e = 0.08;
            if (this._listData && this._listData.length > 0) {
                t = 0;
                for (let i = 0, s = this._listData.length; i < s; i++) {
                    let s = this._items[i];
                    if (ToolUtils.isObjValid(s) && s.active) {
                        let i = new Vec3;
                        TweenTool.stopNodeAction(s);
                        s.getPosition(i);
                        s.getComponent(UIOpacity).opacity = 0;
                        s.setPosition(v3(i.x, i.y - 40));
                        let a = TweenTool.moveToByFade(s, 0.16, i, 0, 1, false), n = TweenTool.delayAct(s, null, t, false);
                        TweenTool.sequence(s, true, null, n, a);
                        t += e;
                    }
                    else {
                        s.getComponent(UIOpacity).opacity = 255;
                    }
                }
            }
        }
    }
}
