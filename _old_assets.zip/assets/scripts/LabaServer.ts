// @ts-nocheck
// Recovered from index.js:225
import { _decorator, Component, director, EventTarget, instantiate, Prefab, resources, sys } from "cc";
import Base64 from "./Base64";
import GameConfig from "./GameConfig";
import CompressUtils from "./CompressUtils";
import HttpManager from "./HttpManager";
import { ToolUtils } from "./ToolUtils";
import PushCenter from "./PushCenter";
import PushEvent from "./PushEvent";
const { ccclass } = _decorator;
@ccclass("LabaServer")
export default class LabaServer extends Component {
    static instance = null;
    public _webHost: string = "";
    public ws: any = null;
    public _msg_queue: any[] = [];
    public is_lock: boolean = false;
    public is_Reconnect: boolean = false;
    public _key: number = 13;
    public _open_cb: any = null;
    public _close_cb: any = null;
    public netNode: any = null;
    public isLoadNetNode: boolean = false;
    public eventDisptch: EventTarget = new EventTarget;
    public _eventArr: any[] = [];
    public isSocketUsed: boolean = false;
    static shared() : LabaServer {
        return null == this.instance && (this.instance = new LabaServer, this.instance.loadNetNode()), this.instance;
    }
    dispatch(e, t) {
        this.eventDisptch.emit(e, t);
    }
    regDispatch(e, t, s) {
        let n = { name: e, cb: this.eventDisptch.on(e, t, s), tg: s };
        this._eventArr.push(n);
    }
    clearEventByTarget(e) {
        for (let t = this._eventArr.length - 1; t >= 0; t--) {
            const s = this._eventArr[t];
            s.tg == e && (this.eventDisptch.off(s.name, s.cb, s.tg), this._eventArr.splice(t, 1));
        }
    }
    clearEventByName(e) {
        this.eventDisptch.off(e);
    }
    getWSState() {
        let e = false;
        switch (this.ws.readyState) {
            case WebSocket.CONNECTING:
            case WebSocket.OPEN:
                e = true;
                break;
            case WebSocket.CLOSING:
            case WebSocket.CLOSED: e = false;
        }
        return e;
    }
    isEnable() {
        return null != this.ws && this.ws.readyState === WebSocket.OPEN;
    }
    reset() {
        this.isSocketUsed = false;
        this.unscheduleAllCallbacks();
        this.closeWS();
        this.pop_response();
        for (let e = this._eventArr.length - 1; e >= 0; e--) {
            const t = this._eventArr[e];
            this.eventDisptch.off(t.name, t.cb, t.tg);
            this._eventArr.splice(e, 1);
        }
        this._eventArr = [];
        this._open_cb = null;
        this.is_lock = false;
        this.is_Reconnect && PushCenter.shared().pushEvent(PushEvent.HideCommLoading);
        this.is_Reconnect = false;
        this._webHost = "";
    }
    createSocket(e) {
        this.isSocketUsed = true;
        this._webHost = e;
        this.closeWS();
        this.ws = new WebSocket(e);
        this.ws.binaryType = "arraybuffer";
        this.ws.onopen = this.onOpen.bind(this);
        this.ws.onmessage = this.onMessage.bind(this);
        this.ws.onclose = this.onClose.bind(this);
        this.ws.onerror = this.onError.bind(this);
    }
    onReconnect() {
        this.is_Reconnect = true;
        null != this.netNode && this._webHost.length > 0 && (HttpManager.shared().doRequestSdkApiReport({ event: "Laba reconnect", reqTime: sys.now() }), this.scheduleOnce((() => {
            null == this.ws && (ToolUtils.isInGameScene, this.createSocket(this._webHost));
        }), 2));
    }
    onError(e) {
        this._close_cb && (this._close_cb(), this._close_cb = null);
        this.closeWS();
        this.isSocketUsed && (this.is_Reconnect ? this.scheduleOnce((() => {
            this.onReconnect();
        }), 2) : this.onReconnect());
    }
    setOpenCb(e) {
        this._open_cb = e;
    }
    setCloseCb(e) {
        this._close_cb = e;
    }
    requestAfterConnect() {
        Number(ToolUtils.uid) > 0 ? PushCenter.shared().pushEvent(PushEvent.LoginLabaSocket) : this.reset();
    }
    onOpen(e) {
        this.requestAfterConnect();
        this._open_cb && (this._open_cb(), this._open_cb = null);
        this.is_Reconnect && (this.is_Reconnect = false, ToolUtils.isInGameScene);
    }
    closeWS() {
        this.ws && (this.ws.onopen = null, this.ws.onmessage = null, this.ws.onclose = null, this.ws.onerror = null, this.ws.close(), this.ws = null);
    }
    onClose(e) {
        this._close_cb && (this._close_cb(), this._close_cb = null);
        this.closeWS();
        this.isSocketUsed && (this.is_Reconnect ? this.scheduleOnce((() => {
            this.onReconnect();
        }), 4) : this.onReconnect());
    }
    onMessage(e) {
        this.lock();
        this._msg_queue.push(e.data);
        this.unlock();
        this.is_Reconnect && (this.is_Reconnect = false, ToolUtils.isInGameScene);
    }
    pop_response() {
        this.lock();
        this._msg_queue = [];
        this.unlock();
    }
    lock() {
        this.is_lock = true;
    }
    unlock() {
        this.is_lock = false;
    }
    update(e) {
        if (1 == this.is_lock) {
            return null;
        }
        if (this._msg_queue.length > 0) {
            return this._msg_queue.shift();
        }
        return null;
    }
    arrayBuf2Str(e) {
        return (new TextDecoder).decode(new Uint8Array(e));
    }
    str2ArrayBuf(e) {
        let t = new ArrayBuffer(e.length), s = new Uint8Array(t);
        for (let t = 0, n = e.length; t < n; t++) {
            s[t] = e.charCodeAt(t);
        }
        return t;
    }
    xorfunc(e, t = -1) {
        if (t = t > 0 ? t : this._key, "string" == typeof e) {
            let s = new ArrayBuffer(ToolUtils.getUtf8StrLen(e)), n = new DataView(s, 0, ToolUtils.getUtf8StrLen(e));
            ToolUtils.write_utf8(n, 0, e);
            for (let e = 0, s = n.byteLength; e < s; e++) {
                n.setUint8(e, n.getUint8(e) ^ t);
            }
            return n.buffer;
        }
        {
            let s = new Uint8Array(e.length);
            for (let n = 0, i = e.length; n < i; n++) {
                s[n] = e[n] ^ t;
            }
            return s;
        }
    }
    send(e) {
        if (null == this.ws) {
            return;
        }
        if (this.ws.readyState !== WebSocket.OPEN) {
            return;
        }
        let t = ToolUtils.toJsonString(e);
        if (1 == GameConfig.SOCKET_COMPRESS_SWITCH) {
            let e = ToolUtils.getUtf8StrLen(t), s = this.arrayBuf2Str(this.xorfunc(t)), n = null;
            n = e > 256 ? CompressUtils.compress(s) : Base64.shared().encode(s);
            this.ws.send(n);
        }
        else {
            let e = Base64.shared().encode(t);
            this.ws.send(this.xorfunc(e));
        }
    }
    loadNetNode() {
        1 != this.isLoadNetNode && (this.isLoadNetNode = true, resources.load("prefabs/net/labaNetNode", Prefab, ((e, t) => {
            if (null != e) {
                return;
            }
            let s = t;
            this.netNode = instantiate(s);
            director.addPersistRootNode(this.netNode);
        })));
    }
}
