// @ts-nocheck
// Recovered from index.js:641
import { _decorator, instantiate, Label, Node, RichText, sp, Sprite, SpriteAtlas, SpriteFrame, sys, Tween, UITransform, v3, Vec3 } from "cc";
import BaseLayer from "./BaseLayer";
import { ToolUtils } from "./ToolUtils";
import User from "./User";
import PushCenter from "./PushCenter";
import PushEvent from "./PushEvent";
import i18nMgr from "./i18nMgr";
import Utils from "./Utils";
import TweenTool from "./TweenTool";
import BundleNameDefined from "./BundleNameDefined";
import CommDefine, { BagItemType } from "./CommDefine";
import SoundManager from "./SoundManager";
import { TransferPlatform } from "./TransferPlatform";
const { ccclass, property } = _decorator;
@ccclass("TreasureDraw")
export class TreasureDraw extends BaseLayer {
    public TAG: string = "TreasureDraw";
    @property(Node)
    public rootNode: Node = null;
    @property(Node)
    public maskNode: Node = null;
    @property(Node)
    public marquee: Node = null;
    @property(Node)
    public marqueetxt: Node = null;
    @property(Label)
    public leftTimeLabel: Label = null;
    @property(Node)
    public giftScrollContent: Node = null;
    @property(Node)
    public btn_shop: Node = null;
    @property(Node)
    public btn_cashspend: Node = null;
    @property(Node)
    public winAnim: Node = null;
    @property(SpriteAtlas)
    public rewardPlist: SpriteAtlas = null;
    @property([SpriteFrame])
    public icons_cb: SpriteFrame[] = [];
    @property([SpriteFrame])
    public giftItemBg: SpriteFrame[] = [];
    public rechargeNode: any[] = [];
    public rechragePos: any[] = [];
    public line1_nodes: any[] = [];
    public line2_nodes: any[] = [];
    public line3_nodes: any[] = [];
    public line1_nodes_pos: any[] = [];
    public line2_nodes_pos: any[] = [];
    public line3_nodes_pos: any[] = [];
    public lightNodes: any[] = [];
    public isNext: boolean = false;
    public isquick: boolean = false;
    public _nVid: number = 0;
    public _lastClick: number = 0;
    public _bStartCountDown: boolean = false;
    public _nCountcd: any = -1;
    public _linkId: number = 0;
    public _reportScene: any = -1;
    public _pop_souce: number = 0;
    public _has_close: boolean = false;
    public _flag: number = 0;
    public _mPara: any[] = [];
    public checkKyc: number = 0;
    public _duration: number = 2;
    public _speed: number = 200;
    public _isMarPlaying: boolean = false;
    public _showMarqueeList: any[] = [];
    public _reqReward: boolean = false;
    public _bDrawRun: boolean = false;
    public _runingReward: boolean = false;
    public _treasuredrawData: any = null;
    initParaData(e, t = 0) {
        this._mPara = e;
        this.isNext = e.isNext;
        sys.isObjectValid(e.vid) ? this._nVid = e.vid : this._nVid = ToolUtils.curRoomId;
        sys.isObjectValid(e) && (sys.isObjectValid(e.isquick) && (this.isquick = e.isquick), sys.isObjectValid(e.flag) && (this._flag = e.flag), sys.isObjectValid(e.checkKyc) && (this.checkKyc = e.checkKyc), sys.isObjectValid(e) && sys.isObjectValid(e.pop_souce) && (this._pop_souce = e.pop_souce), sys.isObjectValid(e) && sys.isObjectValid(e.reportScene) && (this._reportScene = e.reportScene), sys.isObjectValid(e) && sys.isObjectValid(e.link_id) && e.link_id > 0 && (this._linkId = e.link_id), sys.isObjectValid(e.ext) && this.setTreasureDrawData(e.ext));
    }
    setTreasureDrawData(e = null) {
        sys.isObjectValid(e) && Object.keys(e).length && (this._treasuredrawData = e, this.stopMarquee());
    }
    start() {
        super.start();
        this._linkId = this._linkId > 0 ? this._linkId : sys.now();
        this._reportScene = this._reportScene >= 0 ? this._reportScene : ToolUtils.getIsInRoom() ? 2 : 1;
        PushCenter.shared().pushEvent(PushEvent.UpdateTreasureDrawRewarding, 0);
        SoundManager.shared().preLoadBundleSounds(BundleNameDefined.bundle_sound, "treasuredraw");
        this.resetLineNode();
        this.startShowAnim(this.rootNode);
        for (let e, t = 0; t < 9; t++) {
            if (e = this.giftScrollContent.getChildByName("giftItem" + t), ToolUtils.isObjValid(e)) {
                this.rechargeNode[t] = e;
                let i = new Vec3;
                this.rechargeNode[t].getPosition(i);
                this.rechragePos.push(i);
                t < 3 ? (this.line1_nodes.push(e), this.line1_nodes_pos.push(i)) : t < 6 ? (this.line2_nodes.push(e), this.line2_nodes_pos.push(i)) : t < 9 && (this.line3_nodes.push(e), this.line3_nodes_pos.push(i));
            }
        }
        if (this.rechargeNode && Array.isArray(this.rechargeNode)) {
            let e = this.rechargeNode.length;
            for (let t = 0; t < e; t++) {
                let e = this.rechargeNode[t].getChildByName("light");
                ToolUtils.isObjValid(e) && (e.active = false, this.lightNodes.push(e));
            }
        }
        ToolUtils.showFullScreen(this.maskNode);
        sys.isObjectValid(this._treasuredrawData) && this._treasuredrawData && this.refreshView();
        sys.isObjectValid(this._mPara.vid) && 0 != Number(this._mPara.vid) && sys.isObjectValid(this._treasuredrawData) || User.shared().requestTreasureDrawPageData((e => {
            ToolUtils.isObjValid(this.node) && sys.isObjectValid(e) && e && Object.keys(e).length && (this.setTreasureDrawData(e), this.refreshView());
        }));
        PushCenter.shared().addListener(PushEvent.UpdateTreasureDrawKey, (e => {
            ToolUtils.isObjValid(this.node) && sys.isObjectValid(this._treasuredrawData) && this._treasuredrawData && sys.isObjectValid(e) && (this._treasuredrawData.key_num = e, this._treasuredrawData.key_num >= 0 && this.updateShopKeyUI());
        }), this);
        PushCenter.shared().addListener(PushEvent.CloseTreasureDraw, (e => {
            ToolUtils.isObjValid(this.node) && (this.isNext && PushCenter.shared().pushEvent(PushEvent.Update_NextPopActivity), this.node.destroy());
        }), this);
        PushCenter.shared().addListener(PushEvent.UpdateBagItem, (e => {
            if (ToolUtils.isObjValid(this.node) && sys.isObjectValid(e) && e && Array.isArray(e) && e.length > 0) {
                if (e.includes(BagItemType.TreasureKey)) {
                    if (User.shared().backPackData) {
                        let e = User.shared().getBackPackItemCount(BagItemType.TreasureKey) || 0;
                        this.updateShopKeyUI(e);
                    }
                    else {
                        User.shared().requestTreasureDrawPageData((e => {
                            e && (this.setTreasureDrawData(e), this.refreshView());
                        }));
                    }
                }
            }
        }), this);
        PushCenter.shared().pushEvent(PushEvent.HideGameOverBg);
        TweenTool.commonSchedule(this.node, 1, this.scheduleCallBack.bind(this));
    }
    getGoodList() {
        let e = [];
        if (sys.isObjectValid(this._treasuredrawData)) {
            let t = this._treasuredrawData.good_list;
            sys.isObjectValid(t) && Array.isArray(t) && (e = t);
        }
        return e.length, e;
    }
    getDrawIndex(e) {
        let t = this.getGoodList();
        if (t) {
            for (let i = 0; i < t.length; i++) {
                if (sys.isObjectValid(t[i].id) && t[i].id == e) {
                    return i;
                }
            }
        }
        return -1;
    }
    judgeExistUnDraw() {
        let e = this.getGoodList();
        if (e) {
            for (let t = 0; t < e.length; t++) {
                if (sys.isObjectValid(e[t].state) && 0 == e[t].state) {
                    return true;
                }
            }
        }
        return false;
    }
    getSingleDrawState(e) {
        if (!(e < 0) && sys.isObjectValid(User.shared().treasuredrawData) && User.shared().treasuredrawData) {
            let t = User.shared().treasuredrawData.good_list;
            if (t && Array.isArray(t)) {
                for (let i = 0; i < t.length; i++) {
                    if (e == t[i].id && sys.isObjectValid(t[i].state)) {
                        return 1 != t[i].state;
                    }
                }
            }
        }
    }
    updateSingleDrawState(e, t) {
        if (!(e < 0 || t < 0)) {
            if (sys.isObjectValid(User.shared().treasuredrawData) && User.shared().treasuredrawData) {
                let i = User.shared().treasuredrawData.good_list;
                if (i && Array.isArray(i)) {
                    for (let s = 0; s < i.length; s++) {
                        if (e == i[s].id) {
                            i[s].state = t;
                            break;
                        }
                    }
                }
            }
            this._treasuredrawData && sys.isObjectValid(this._treasuredrawData.good_list) && (this._treasuredrawData.good_list = User.shared().treasuredrawData.good_list);
        }
    }
    resetAllDrawState() {
        if (sys.isObjectValid(User.shared().treasuredrawData) && User.shared().treasuredrawData) {
            let e = User.shared().treasuredrawData.good_list;
            if (e && Array.isArray(e)) {
                for (let t = 0; t < e.length; t++) {
                    e[t].state = 0;
                }
            }
        }
        this._treasuredrawData && sys.isObjectValid(this._treasuredrawData.good_list) && (this._treasuredrawData.good_list = User.shared().treasuredrawData.good_list);
    }
    refreshView() {
        if (sys.isObjectValid(this._treasuredrawData) && this._treasuredrawData) {
            sys.isObjectValid(this._treasuredrawData.time_left) && this.startLeftTime(Number(this._treasuredrawData.time_left));
            this.playMarquee();
            this.updateShopKeyUI();
            this.updateBtnCashSpendUI();
            let e = this.getGoodList();
            e && this.updateGiftScrollView(e);
        }
    }
    updateShopKeyUI(e) {
        let t = e || 0;
        t || (t = sys.isObjectValid(this._treasuredrawData) && sys.isObjectValid(this._treasuredrawData.key_num) ? ToolUtils.isSafeNumber(this._treasuredrawData.key_num) : 0);
        this.btn_shop.getChildByName("money").getComponent(Label).string = ToolUtils.parse_double(String(t), -1);
    }
    updateBtnCashSpendUI() {
        let e = "", t = this.btn_cashspend.getChildByName("Node").getChildByName("Node").getChildByName("lab");
        sys.isObjectValid(this._treasuredrawData) && sys.isObjectValid(this._treasuredrawData.spin_spend_num) && (e = "x" + this._treasuredrawData.spin_spend_num);
        t.getComponent(Label).string = e;
    }
    startLeftTime(e) {
        let t = i18nMgr.shared().getValueByKey("customselgift.left_time");
        if (Number.isNaN(e) || e <= 0) {
            return User.shared().getHallInfo(), void (this.leftTimeLabel.string = "");
        }
        this._bStartCountDown = true;
        this._nCountcd = e;
        t = ToolUtils.format("${0} ${1}", t, Utils.shared().parseCountDown(this._nCountcd));
        this.leftTimeLabel.string = t;
        i18nMgr.shared().changeLabelFont(this.leftTimeLabel, false);
    }
    scheduleCallBack() {
        if (sys.isObjectValid(this._treasuredrawData) && this._treasuredrawData && this._bStartCountDown) {
            if (this._nCountcd -= 1, this._treasuredrawData.time_left = this._nCountcd, this._nCountcd < 0) {
                return this._treasuredrawData.time_left = -1, User.shared().getHallInfo(), void this.onBackView();
            }
            this.leftTimeLabel.string = ToolUtils.format("${0} ${1}", i18nMgr.shared().getValueByKey("customselgift.left_time"), Utils.shared().parseCountDown(this._nCountcd));
        }
    }
    updateGiftScrollView(e) {
        if (sys.isObjectValid(this.rechargeNode) && Array.isArray(this.rechargeNode), sys.isObjectValid(e) && e && Array.isArray(e)) {
            for (let t = 0, i = this.rechargeNode.length; t < i; t++) {
                if (sys.isObjectValid(e) && sys.isObjectValid(e[t])) {
                    let i = e[t];
                    this.rechargeNode[t].active = true;
                    this.initGiftItemView(this.rechargeNode[t], i);
                }
                else {
                    this.rechargeNode[t].active = false;
                }
            }
        }
    }
    initGiftItemView(e, t) {
        if (!(e && t && sys.isObjectValid(t.state) && sys.isObjectValid(t.icon_type))) {
            return;
        }
        let i = e.getChildByName("bg"), s = e.getChildByName("icon"), a = e.getChildByName("rew"), n = e.getChildByName("state"), h = e.getChildByName("super"), d = e.getChildByName("super_lab"), o = a.getChildByName("ico_1"), _ = a.getChildByName("num_1"), c = a.getChildByName("ico_2"), w = a.getChildByName("num_2");
        n.active = 1 == t.state;
        this.icons_cb && this.icons_cb[t.icon_type - 1] && (s.getComponent(Sprite).spriteFrame = this.icons_cb[t.icon_type - 1]);
        sys.isObjectValid(t.reward) && t.reward && Array.isArray(t.reward) && t.reward.length > 0 ? (o.active = _.active = c.active = w.active = false, t.reward[0] && (o.active = _.active = true, this.updateRewardSprite(o, t.reward[0].type), t.reward[1] ? _.getComponent(Label).string = t.reward[0].num + " " : _.getComponent(Label).string = "" + t.reward[0].num), t.reward[1] && (c.active = w.active = true, this.updateRewardSprite(c, t.reward[1].type), w.getComponent(Label).string = "" + t.reward[1].num)) : o.active = _.active = c.active = w.active = false;
        let p = false;
        sys.isObjectValid(t.best) && (p = 1 == t.best && 0 == t.state);
        h.active = d.active = p;
        i.getComponent(Sprite).spriteFrame = this.giftItemBg[0];
    }
    updateGiftItemStateUI() {
        if (!this.rechargeNode || !Array.isArray(this.rechargeNode)) {
            return;
        }
        let e = this.getGoodList();
        if (e) {
            let t = e.length;
            if (t != this.rechargeNode.length) {
                return;
            }
            for (let i = 0; i < t; i++) {
                if (sys.isObjectValid(e[i].state) && ToolUtils.isObjValid(this.rechargeNode[i])) {
                    let t = this.rechargeNode[i].getChildByName("state"), s = this.rechargeNode[i].getChildByName("super"), a = this.rechargeNode[i].getChildByName("super_lab");
                    ToolUtils.isObjValid(t) && (t.active = 1 == e[i].state);
                    let r = false;
                    sys.isObjectValid(e[i].best) && (r = 1 == e[i].best && 0 == e[i].state);
                    ToolUtils.isObjValid(s) && (s.active = r);
                    ToolUtils.isObjValid(a) && (a.active = r);
                }
            }
        }
    }
    updateRewardSprite(e, t) {
        ToolUtils.isSafeString(CommDefine.rewardPistName[t]).length > 0 && Utils.shared().setImage(e, CommDefine.rewardPistName[t], this.rewardPlist);
    }
    onButtonClick(e, t) {
        if (SoundManager.shared().playFx("click"), "close" == t) {
            if (this._flag > 0 && sys.isObjectValid(this._mPara) && this._mPara) {
                return Utils.shared().showQuickRecharge(this._mPara.vid, this._mPara.parent_node, true, this._mPara.tid_key, 0, this._mPara.score, true, this._flag, this.checkKyc), void this.onBackView();
            }
            1 == this.checkKyc && Utils.shared().checkAddCashKyc();
            this.onBackView();
        }
        else if ("shop" == t) {
            if (this._runingReward) {
                return;
            }
            this._treasuredrawData && sys.isObjectValid(this._treasuredrawData.shop_list) && this._treasuredrawData.shop_list && Array.isArray(this._treasuredrawData.shop_list) && Utils.shared().doCustomJump(PushEvent.Custom_TO_TREASUREDRAW_SHOP, { goods_list: this._treasuredrawData.shop_list });
        }
    }
    onBtnCashSpendClick(e, t) {
        if (!(sys.now() - this._lastClick < 500) && (this._lastClick = sys.now(), SoundManager.shared().playFx("click"), sys.isObjectValid(this._treasuredrawData) && this._treasuredrawData)) {
            if (this._bDrawRun) {
                return;
            }
            if (this._reqReward) {
                return;
            }
            if (this.judgeExistUnDraw() && User.shared().treasuredrawData && sys.isObjectValid(User.shared().treasuredrawData.key_num) && sys.isObjectValid(this._treasuredrawData.spin_spend_num)) {
                if (User.shared().treasuredrawData.key_num >= this._treasuredrawData.spin_spend_num) {
                    this._reqReward = true;
                    PushCenter.shared().pushEvent(PushEvent.UpdateTreasureDrawRewarding, 1);
                    User.shared().requestTreasureDrawReward((e => {
                        if (this._reqReward = false, !e || !sys.isObjectValid(e.is_reward) || 1 != e.is_reward) {
                            return Utils.shared().showToast(i18nMgr.shared().getValueByKey("treasuredraw.spin_error"), 2), void PushCenter.shared().pushEvent(PushEvent.UpdateTreasureDrawRewarding, 0);
                        }
                        if (sys.isObjectValid(e.id) && sys.isObjectValid(e.key_num) && sys.isObjectValid(e.reward_list) && e.reward_list && Array.isArray(e.reward_list) && sys.isObjectValid(e.spin_spend_num)) {
                            if (sys.isObjectValid(User.shared().treasuredrawData) && User.shared().treasuredrawData && this._treasuredrawData) {
                                User.shared().treasuredrawData.key_num = e.key_num;
                                this._treasuredrawData.key_num = e.key_num;
                                User.shared().treasuredrawData.spin_spend_num = e.spin_spend_num;
                                this._treasuredrawData.spin_spend_num = e.spin_spend_num;
                                this.updateSingleDrawState(e.id, 1);
                                let t = { uid: User.shared().data.uid, name: User.shared().data.name, reward: e.reward_list }, i = null;
                                sys.isObjectValid(e.is_insert) && 1 == e.is_insert && (i = t);
                                this.judgeExistUnDraw() ? this.onSpinResult({ id: e.id, reward: e.reward_list, mar_msg: i }) : this.onRewLastDraw({ id: e.id, reward: e.reward_list, mar_msg: i });
                            }
                        }
                        else {
                            PushCenter.shared().pushEvent(PushEvent.UpdateTreasureDrawRewarding, 0);
                        }
                    }));
                }
                else {
                    if (this._runingReward) {
                        return;
                    }
                    Utils.shared().doCustomJump(PushEvent.Custom_TO_TREASUREDRAW_SHOP, { goods_list: this._treasuredrawData.shop_list });
                }
            }
        }
    }
    onEnable() {
        TransferPlatform.shared().setNormalFrameRate();
    }
    onBackView() {
        if (ToolUtils.isObjValid(this.node)) {
            if (this._has_close) {
                return;
            }
            this._has_close = true;
            this.stopMarquee();
            this._showMarqueeList = [];
            Utils.shared().hideToast();
            let e = { alert_node: this.node, rootNode: this.rootNode, isNext: this.isNext, pop_type: PushEvent.JUMP_TO_TreasureDraw, pop_souce: this._pop_souce };
            Utils.shared().closeActivityView(e);
        }
    }
    playMarquee() {
        if (this._isMarPlaying) {
            return;
        }
        if (!ToolUtils.isObjValid(this.node) || !ToolUtils.isObjValid(this.marqueetxt)) {
            return void this.stopMarquee();
        }
        let e = this.getMarqueeMsg();
        if (!e) {
            return void this.stopMarquee();
        }
        let t = this.formatMarqueeMsg(e);
        if (!t) {
            return void this.stopMarquee();
        }
        this._isMarPlaying = true;
        this.marqueetxt.getComponent(RichText).string = t;
        this.insertMarquee(e, 2);
        let i = this.marquee.getComponent(UITransform).width / 2 + this.marqueetxt.getComponent(UITransform).width / 2, s = -i, a = new Vec3(i, 0, 0), r = new Vec3(0, 0, 0), n = new Vec3(s, 0, 0);
        Tween.stopAllByTarget(this.marqueetxt);
        let h = Math.abs(a.x - r.x) / this._speed, d = Math.abs(r.x - n.x) / this._speed;
        TweenTool.delayAct(this.node, (() => {
            ToolUtils.isObjValid(this.marqueetxt) ? new Tween(this.marqueetxt).set({ position: a }).to(h, { position: r }).delay(this._duration).to(d, { position: n }).call((() => {
                this._isMarPlaying = false;
                this.playMarquee();
            })).start() : this.stopMarquee();
        }), 0, true);
    }
    stopMarquee(e = true) {
        this._isMarPlaying = false;
        TweenTool.stopNodeAction(this.marqueetxt);
        e && (this._treasuredrawData && Array.isArray(this._treasuredrawData.marquees) ? this._showMarqueeList = [...this._treasuredrawData.marquees] : this._showMarqueeList = []);
    }
    getMarqueeMsg() {
        if (!Array.isArray(this._showMarqueeList) || 0 === this._showMarqueeList.length) {
            return null;
        }
        let e = this._showMarqueeList.shift();
        return e && "string" == typeof e.name && Array.isArray(e.reward) ? e : null;
    }
    insertMarquee(e, t) {
        !e || 1 !== t && 2 !== t || (Array.isArray(this._showMarqueeList) || (this._showMarqueeList = []), 1 === t ? this._showMarqueeList.unshift(e) : 2 === t && this._showMarqueeList.push(e));
    }
    formatMarqueeMsg(e) {
        let t = "", i = e.name || "", s = e.reward || [];
        if (!Array.isArray(s) || 0 === s.length) {
            return null;
        }
        let a = s.length;
        for (let e = 0; e < a; e++) {
            let i = s[e];
            i && sys.isObjectValid(i.type) && (sys.isObjectValid(i.num) ? 0 == i.type ? t += i.num + " CASH" : 1 == i.type && (t += i.num + " BONUS") : sys.isObjectValid(i.amt) && (sys.isObjectValid(i.desc) ? t += i.amt + i.desc : 0 == i.type ? t += i.amt + " CASH" : 1 == i.type && (t += i.amt + " BONUS")), a > 1 && e < a - 1 && (t += ", "));
        }
        return i && t ? ToolUtils.format(i18nMgr.shared().getValueByKey("treasuredraw.marquee_msg"), i, t) : null;
    }
    onRewLastDraw(e) {
        if (!(e && sys.isObjectValid(e.id) && sys.isObjectValid(e.reward) && Array.isArray(e.reward))) {
            return void PushCenter.shared().pushEvent(PushEvent.UpdateTreasureDrawRewarding, 0);
        }
        if (!this.lightNodes || !Array.isArray(this.lightNodes) || this.lightNodes.length != this.rechargeNode.length) {
            return void PushCenter.shared().pushEvent(PushEvent.UpdateTreasureDrawRewarding, 0);
        }
        let t = this.getDrawIndex(e.id);
        t >= 0 ? this.rewLastDrawAnim(e.id, t, (() => {
            sys.isObjectValid(e.mar_msg) && this.insertMarquee(e.mar_msg, 1);
            this.showLotteryRun(t, true, (() => {
                this.showLotteryReward(t, e, (() => {
                    this.resetAllDrawAnim((() => {
                        this.resetAllDrawState();
                        this.hideMaskLight();
                        this.hideStateNode();
                        this.updateGiftItemStateUI();
                        this.updateBtnCashSpendUI();
                    }), (() => {
                        this._bDrawRun = false;
                    }));
                }));
            }));
        })) : PushCenter.shared().pushEvent(PushEvent.UpdateTreasureDrawRewarding, 0);
    }
    rewLastDrawAnim(e, t, i) {
        ToolUtils.isObjValid(this.lightNodes[t]) && (this.lightNodes[t].active = true, this._runingReward = true);
        ToolUtils.isObjValid(this.node) && TweenTool.delayAct(this.node, (() => {
            i && i();
        }), 0.5, true);
    }
    onSpinResult(e) {
        if (!(e && sys.isObjectValid(e.id) && sys.isObjectValid(e.reward) && Array.isArray(e.reward))) {
            return void PushCenter.shared().pushEvent(PushEvent.UpdateTreasureDrawRewarding, 0);
        }
        if (!this.lightNodes || !Array.isArray(this.lightNodes) || this.lightNodes.length != this.rechargeNode.length) {
            return void PushCenter.shared().pushEvent(PushEvent.UpdateTreasureDrawRewarding, 0);
        }
        let t = this.getDrawIndex(e.id);
        t >= 0 ? this.runDrawRun(e.id, t, (() => {
            sys.isObjectValid(e.mar_msg) && this.insertMarquee(e.mar_msg, 1);
            this.showLotteryRun(t, false, (() => {
                this.showLotteryReward(t, e, (() => {
                    this.updateBtnCashSpendUI();
                }));
            }));
        })) : PushCenter.shared().pushEvent(PushEvent.UpdateTreasureDrawRewarding, 0);
    }
    showLotteryReward(e, t, i) {
        let s = instantiate(this.winAnim);
        this.winAnim.parent.addChild(s);
        s ? (s.setWorldPosition(this.lightNodes[e].worldPosition), s.active = true, s.getComponent(sp.Skeleton).clearTracks(), s.getComponent(sp.Skeleton).setToSetupPose(), s.getComponent(sp.Skeleton).setAnimation(0, "reward", false), TweenTool.delayAct(this.node, (() => {
            this.Poprewards(t.reward, i);
            TweenTool.delayAct(this.node, (() => {
                this.showNomalRun();
            }), 0.2, true);
            s.destroy();
        }), 0.9, true)) : (this.Poprewards(t.reward, i), TweenTool.delayAct(this.node, (() => {
            this.showNomalRun();
        }), 0.2, true));
    }
    runDrawRun(e, t, i) {
        let s = this.getNewCanRunDrawIndexArr(e);
        if (!Array.isArray(s) || s.length < 1) {
            return void (i && i());
        }
        let a = [0.01, 0.22, 0.16, 0.11, 0.08, 0.1, 0.16, 0.22, 0.3], r = [], n = 0, h = s.length;
        for (let e = 0; e < h; e++) {
            if (e < 4) {
                n += a[e];
            }
            else if (e >= h - 4) {
                n += a[5 + (e - (h - 4))];
            }
            else {
                n += a[4];
            }
            r.push(n);
        }
        if (r && Array.isArray(r) && r.length && r.length == s.length) {
            this._bDrawRun = true;
            this._runingReward = true;
            for (let e = 0, t = r.length; e < t; e++) {
                TweenTool.delayAct(this.node, (() => {
                    let t;
                    if (e < r.length - 1 && SoundManager.shared().playFx("treasuredraw_slots_run"), e > 0 && (t = s[e - 1], this.lightNodes[t].active = false), t = s[e], !this.lightNodes[t]) {
                        return this._bDrawRun = false, this._runingReward = false, void (i && i());
                    }
                    this.lightNodes[t].active = true;
                    e == r.length - 1 && TweenTool.delayAct(this.node, (() => {
                        i && i();
                    }), 0.3, true);
                }), r[e], true);
            }
        }
        else {
            i && i();
        }
    }
    showLotteryRun(e, t, i) {
        SoundManager.shared().playFx("treasuredraw_slots_winning");
        this.lightNodes[e].active = true;
        this._runingReward = false;
        i && i();
    }
    Poprewards(e, t) {
        let i = e;
        i && i.length > 0 && User.shared().showChargeReward(i, t);
        PushCenter.shared().pushEvent(PushEvent.UpdateTreasureDrawRewarding, 0);
    }
    showNomalRun() {
        this._bDrawRun = false;
        this.hideMaskLight();
        this.updateGiftItemStateUI();
        this.updateShopKeyUI();
    }
    hideMaskLight() {
        if (this.lightNodes && Array.isArray(this.lightNodes) && this.lightNodes.length == this.rechargeNode.length) {
            for (let e = 0; e < this.lightNodes.length; e++) {
                this.lightNodes[e].active = false;
            }
        }
    }
    hideStateNode() {
        for (let e = 0, t = this.rechargeNode.length; e < t; e++) {
            let t = this.rechargeNode[e].getChildByName("state");
            ToolUtils.isObjValid(t) && (t.active = false);
        }
    }
    getNewCanRunDrawIndexArr(e) {
        if (!e) {
            return [];
        }
        let t = this.getGoodList();
        if (!Array.isArray(t)) {
            return [];
        }
        let i = this.getDrawIndex(e);
        if (i < 0) {
            return [];
        }
        let s = [], a = 2 * t.length, r = 0;
        for (;;) {
            for (let e = 0; e < t.length; e++) {
                let a = t[e], r = null == a ? undefined : a.id;
                if (!sys.isObjectValid(r)) {
                    continue;
                }
                let n = this.getDrawIndex(r);
                if (n < 0) {
                    continue;
                }
                let h = this.getSingleDrawState(r);
                if ((n === i || h) && s.push(n), s.length >= 9 && s[s.length - 1] === i) {
                    return s;
                }
            }
            if (r++, r >= a) {
                break;
            }
        }
        return [];
    }
    resetAllDrawAnim(e, t) {
        let i = 0.1, s = 0.3, a = 47.5, r = 660;
        if (this.judgeExistUnDraw()) {
            return e && e(), void (t && t());
        }
        try {
            for (let e = 0, t = this.line1_nodes.length; e < t; e++) {
                TweenTool.stopNodeAction(this.line1_nodes[e]);
                let t = TweenTool.delayAct(this.line1_nodes[e], (() => {
                }), 0, false), n = TweenTool.moveTo(this.line1_nodes[e], i, v3(this.line1_nodes_pos[e].x + a + 110, this.line1_nodes_pos[e].y), null, false), h = TweenTool.moveTo(this.line1_nodes[e], s, v3(this.line1_nodes_pos[e].x - r, this.line1_nodes_pos[e].y), null, false, (() => {
                    this.line1_nodes[e].setPosition(v3(this.line1_nodes_pos[e].x + 1320, this.line1_nodes_pos[e].y));
                })), d = TweenTool.moveTo(this.line1_nodes[e], s, v3(this.line1_nodes_pos[e].x - a - 110, this.line1_nodes_pos[e].y), null, false), l = TweenTool.moveTo(this.line1_nodes[e], i, v3(this.line1_nodes_pos[e].x, this.line1_nodes_pos[e].y), null, false);
                TweenTool.sequence(this.line1_nodes[e], true, null, t, n, h, d, l);
            }
            for (let e = 0, t = this.line2_nodes.length; e < t; e++) {
                TweenTool.stopNodeAction(this.line2_nodes[e]);
                let t = TweenTool.delayAct(this.line2_nodes[e], (() => {
                }), 0.04, false), n = TweenTool.moveTo(this.line2_nodes[e], i, v3(this.line2_nodes_pos[e].x + a + 70, this.line2_nodes_pos[e].y), null, false), h = TweenTool.moveTo(this.line2_nodes[e], s, v3(this.line2_nodes_pos[e].x - r, this.line2_nodes_pos[e].y), null, false, (() => {
                    this.line2_nodes[e].setPosition(v3(this.line2_nodes_pos[e].x + 1320, this.line2_nodes_pos[e].y));
                })), d = TweenTool.moveTo(this.line2_nodes[e], s, v3(this.line2_nodes_pos[e].x - a - 70, this.line2_nodes_pos[e].y), null, false), l = TweenTool.moveTo(this.line2_nodes[e], i, v3(this.line2_nodes_pos[e].x, this.line2_nodes_pos[e].y), null, false);
                TweenTool.sequence(this.line2_nodes[e], true, null, t, n, h, d, l);
            }
            for (let n = 0, h = this.line3_nodes.length; n < h; n++) {
                TweenTool.stopNodeAction(this.line3_nodes[n]);
                let d = TweenTool.delayAct(this.line3_nodes[n], (() => {
                }), 0.08, false), l = TweenTool.moveTo(this.line3_nodes[n], i, v3(this.line3_nodes_pos[n].x + a + 30, this.line3_nodes_pos[n].y), null, false), o = TweenTool.moveTo(this.line3_nodes[n], s, v3(this.line3_nodes_pos[n].x - r, this.line3_nodes_pos[n].y), null, false, (() => {
                    n == h - 1 && e && e();
                    this.line3_nodes[n].setPosition(v3(this.line3_nodes_pos[n].x + 1320, this.line3_nodes_pos[n].y));
                })), u = TweenTool.moveTo(this.line3_nodes[n], s, v3(this.line3_nodes_pos[n].x - a - 30, this.line3_nodes_pos[n].y), null, false), _ = TweenTool.moveTo(this.line3_nodes[n], i, v3(this.line3_nodes_pos[n].x, this.line3_nodes_pos[n].y), null, false);
                TweenTool.sequence(this.line3_nodes[n], true, (() => {
                    n == h - 1 && t && t();
                }), d, l, o, u, _);
            }
        }
        catch (e) {
            t && t();
        }
    }
    resetLineNode() {
        this.line1_nodes = [];
        this.line2_nodes = [];
        this.line3_nodes = [];
        this.line1_nodes_pos = [];
        this.line2_nodes_pos = [];
        this.line3_nodes_pos = [];
    }
    onDestroy() {
        super.destroy();
        PushCenter.shared().pushEvent(PushEvent.UpdateTreasureDrawRewarding, 0);
        PushCenter.shared().removeListenersByTag(this);
        this.unscheduleAllCallbacks();
    }
}
