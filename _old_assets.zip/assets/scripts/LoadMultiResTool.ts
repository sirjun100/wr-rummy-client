// @ts-nocheck
// Recovered from index.js:237
import { assetManager, sys} from "cc";
import { PREVIEW, DEBUG } from 'cc/env';
import { TLog } from "./TLog";
let LoadMultiResTool;
class a {
    static getInstance() {
        return a.instance || (a.instance = new a), a.instance;
    }
    async preLoadRes(e, r) {
        return new Promise((async (l, n) => {
            let o = await a.getInstance()._MultiLoadRes(e, r);
            for (let e = 0; e < o.length; e++) {
                if (!o[e]) {
                    return void l(false);
                }
            }
            l(true);
        }));
    }
    _MultiLoadRes(e, l) {
        let n = new Map, t = (e, r, o) => {
            let t = o.path, a = n.get(t);
            null == a ? (a = { t: r, c: e }, n.set(t, a)) : (a.t = r, a.c = e);
            let s = 0, d = 0;
            n.forEach((e => {
                d += e.t;
                s += e.c;
            }));
            l && l(s, d);
        }, a = new Array;
        return e.forEach((async (e, l) => {
            if (sys.isNative && !DEBUG && e.bundleName, e.bundlePaht && e.isFile) {
                let r = this.preloadRemoteDir(e.bundleName, e.bundlePaht, e.path, ((r, l) => {
                    t(r, l, e);
                }));
                a.push(r);
            }
            else if (e.bundlePaht && e.isScene) {
                let r = this.preloadRemoteScene(e.bundleName, e.bundlePaht, e.path, ((r, l) => {
                    t(r, l, e);
                }));
                a.push(r);
            }
            else if (e.bundlePaht) {
                let r = this.preloadRemoteRes(e.bundleName, e.bundlePaht, e.path, ((r, l) => {
                    t(r, l, e);
                }));
                a.push(r);
            }
            else if (e.isFile) {
                let r = this.preloadDir(e.bundleName, e.path, ((r, l) => {
                    t(r, l, e);
                }));
                a.push(r);
            }
            else if (e.isScene) {
                let r = this.preloadResFromScene(e.bundleName, e.path, ((r, l) => {
                    t(r, l, e);
                }));
                a.push(r);
            }
            else {
                let r = this.preloadResFromBundle(e.bundleName, e.path, ((r, l) => {
                    t(r, l, e);
                }));
                a.push(r);
            }
        })), Promise.all(a);
    }
    async preloadResFromBundle(e, r, n) {
        return e = e || "resources", new Promise(((o, a) => {
            assetManager.loadBundle(e, null, ((l, a) => {
                l ? (o(false), TLog.printError("preloadResFromBundle bundle res error ", e, r)) : r ? a.preload(r, n, ((l, n) => {
                    l ? (TLog.printError("preloadResFromBundle bundle res error ", e, r), o(false)) : o(true);
                })) : (n && n(1, 1), o(true));
            }));
        }));
    }
    async preloadDir(e, r, n) {
        return e = e || "resources", new Promise(((o, a) => {
            assetManager.loadBundle(e, null, ((l, a) => {
                l ? (o(false), TLog.printError("preloadDir bundle res error ", e, r)) : a.preloadDir(r, n, ((l, n) => {
                    l ? (TLog.printError("preloadDir bundle res error ", e, r), o(false)) : o(true);
                }));
            }));
        }));
    }
    async preloadResFromScene(e, r, n) {
        return e = e || "resources", new Promise(((o, a) => {
            assetManager.loadBundle(e, null, ((l, a) => {
                l ? (o(false), TLog.printError("bundleloadScene bundle res error ", e, r)) : a.preloadScene(r, n, (l => {
                    l ? (TLog.printError("bundleloadScene bundle res error ", e, r), o(false)) : o(true);
                }));
            }));
        }));
    }
    async preloadRemoteRes(e, r, n, o) {
        return new Promise(((a, s) => {
            let d = (e, r) => {
                e.preload(n, o, (e => {
                    e ? (a(false), TLog.printError("preloadRemoteRes bundle res error ", r, n)) : a(true);
                }));
            };
            assetManager.loadBundle(e, null, ((n, o) => {
                o ? d(o, e) : assetManager.loadBundle(r, null, ((e, l) => {
                    d(l, r);
                }));
            }));
        }));
    }
    async preloadRemoteDir(e, r, n, o) {
        return new Promise(((a, s) => {
            let d = (e, r) => {
                e.preloadDir(n, o, (e => {
                    e ? (a(false), TLog.printError("preloadResFromRemoteDir bundle res error ", r, n)) : a(true);
                }));
            };
            assetManager.loadBundle(e, null, ((n, o) => {
                o ? d(o, e) : assetManager.loadBundle(r, null, ((e, l) => {
                    d(l, r);
                }));
            }));
        }));
    }
    async preloadRemoteScene(e, r, n, o) {
        return new Promise(((a, s) => {
            let d = (e, r) => {
                e.preloadScene(n, o, (e => {
                    e ? (TLog.printError("preloadRemoteScene bundle res error ", r, n), a(false)) : a(true);
                }));
            };
            assetManager.loadBundle(e, null, ((n, o) => {
                o ? d(o, e) : assetManager.loadBundle(r, null, ((e, l) => {
                    d(l, r);
                }));
            }));
        }));
    }
}
(LoadMultiResTool = a);
(a.instance = null);
export default LoadMultiResTool;
