// @ts-nocheck
// Recovered from index.js:425
import { _decorator, Button, color, instantiate, Label, Node, Prefab, size, Sprite, SpriteFrame, sys, UITransform, v3, Vec3 } from "cc";
import SoundManager from "./SoundManager";
import RummyDataManager from "./RummyDataManager";
import TweenTool from "./TweenTool";
import { TLog } from "./TLog";
import BaseLayer from "./BaseLayer";
import PushCenter from "./PushCenter";
import PushEvent from "./PushEvent";
import GameConfig from "./GameConfig";
import BundleNameDefined from "./BundleNameDefined";
import i18nMgr from "./i18nMgr";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("RummyBumpSwitchAlert")
export default class RummyBumpSwitchAlert extends BaseLayer {
    @property(Node)
    public rootNode: Node = null;
    @property({ tooltip: "card modal", type: Prefab })
    public cardPrefab: Prefab = null;
    @property([SpriteFrame])
    public laizi_imgs: SpriteFrame[] = [];
    @property(Node)
    public cardsNode: Node = null;
    @property(Node)
    public finishTx: Node = null;
    @property(Node)
    public scoreTx: Node = null;
    @property(Node)
    public readHandTx: Node = null;
    @property(Node)
    public laiziCard: Node = null;
    @property(Node)
    public arrowNode: Node = null;
    @property([Node])
    public arrCardBtn: Node[] = [];
    @property([SpriteFrame])
    public zhegaiImags: SpriteFrame[] = [];
    @property([SpriteFrame])
    public tipBgImags: SpriteFrame[] = [];
    public _rummyCardText: any[] = [];
    public _cardValue: any[] = [];
    public _callback: any = null;
    public cardScale: any = v3(0.3, 0.3, 0.3);
    public _showPos: any = v3(0, 0);
    public _cardWidth: number = 0;
    public _lastSelectIndex: any = -1;
    public _hasInit: boolean = false;
    public _myCard: any = null;
    public _msg: any = null;
    public _tmpLaizi: number = 0;
    public _curLaizi: number = 0;
    public _posLeftScore: any[] = [-90, -227];
    public _colorTips: any[] = [color(170, 0, 0), color(255, 255, 255)];
    public _batchJokerInfo: any = null;
    onLoad() {
        this.bIsInGame = true;
        this.fitScreen();
        this._rummyCardText = ["2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A"];
        this._cardValue = [34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 33];
        this.initSelectBtns();
        3 == i18nMgr.shared().language && (this.rootNode.getChildByName("cancel_btn").getChildByName("wz").getComponent(Label).fontSize = 24);
    }
    start() {
        super.start();
        this.cardPrefab = RummyDataManager.shared().cardPrefab;
        sys.isObjectValid(this.cardPrefab) ? (this._hasInit = true, this.initContectView()) : ToolUtils.loadCommonPrefab(null, BundleNameDefined.bundle_rummy, "prefab/card", (t => {
            RummyDataManager.shared().cardPrefab = t;
            ToolUtils.isObjValid(this.node) && (this.cardPrefab = t, this._hasInit = true, this.initContectView());
        }));
    }
    initContectView() {
        try {
            this._msg ? this.initCardList(this._msg) : this._myCard ? this.initCardList(this._myCard) : this._batchJokerInfo && this.switchLaizi(this._curLaizi);
        }
        catch (t) {
            TLog.printError("RummyBumpSwitchAlert initContectView err:", t);
        }
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().removeListenersByTag(this);
    }
    fitScreen() {
        let t = ToolUtils.getFitBottomHeightDiff();
        t > 0 && (this._showPos.y += t);
        ToolUtils.isPadPlatform() && (this._showPos.y = this._showPos.y + (GameConfig.REAL_SCREEN_WIDTH - GameConfig.CONFIG_SCREEN_WIDTH) / 2);
        let i = this.node.getChildByName("close_bg");
        i && i.getComponent(UITransform).setContentSize(ToolUtils.getHorizontalSize());
    }
    startShowAnim() {
        this.rootNode.setPosition(v3(this._showPos.x, this._showPos.y + 300, 0));
        TweenTool.moveTo(this.rootNode, 0.2, this._showPos, "fade", true, (() => {
            this.rootNode.setPosition(this._showPos);
        }));
    }
    setCloseCallBack(t) {
        this._callback = t;
    }
    onBtnClick(t, i = "") {
        if (SoundManager.shared().playFx("click"), "cancel" == i || "close" == i) {
            let t = new Vec3;
            this.rootNode.getPosition(t);
            let i = this;
            TweenTool.moveTo(this.rootNode, 0.15, v3(t.x, t.y + 300, t.z), null, true, (() => {
                i._callback && i._callback();
                i.removeGamePopNode();
                i.node.active = false;
            }));
        }
        else if ("ok" == i) {
            let t = new Vec3;
            this.rootNode.getPosition(t);
            let i = this;
            TweenTool.moveTo(this.rootNode, 0.15, v3(t.x, t.y + 300, t.z), null, true, (() => {
                this._callback && this._callback("changeJoker", Number(this._tmpLaizi));
                i.removeGamePopNode();
                i.node.active = false;
            }));
        }
        else {
            Number(i) > 0 && this.switchLaizi(Number(i));
        }
    }
    initSelectBtns() {
        for (let t = 0, i = this.arrCardBtn.length; t < i; t++) {
            this.arrCardBtn[t].getComponent(Button).interactable = true;
            this.arrCardBtn[t].getComponent(Button).clickEvents[0].customEventData = "" + this._cardValue[t];
        }
    }
    updateBestLaizi(t) {
        if (t > 0) {
            let i = ToolUtils.getCardInfo(t), e = ToolUtils.getCardShowValue(i.point), a = this._rummyCardText.indexOf(e);
            if (-1 != a && this.arrCardBtn && ToolUtils.isObjValid(this.arrCardBtn[a])) {
                for (let t = 0, i = this.arrCardBtn.length; t < i; t++) {
                    t == a ? this.arrCardBtn[a].getChildByName("flag").active = true : this.arrCardBtn[t].getChildByName("flag").active = false;
                }
            }
        }
        else {
            for (let t = 0, i = this.arrCardBtn.length; t < i; t++) {
                this.arrCardBtn[t].getChildByName("flag").active = false;
            }
        }
    }
    updateChooseLaizi(t) {
        this._tmpLaizi = t;
        let i = ToolUtils.getCardInfo(t), e = ToolUtils.getCardShowValue(i.point), a = this._rummyCardText.indexOf(e);
        if (-1 != a && this.arrCardBtn && ToolUtils.isObjValid(this.arrCardBtn[a])) {
            for (let t = 0, i = this.arrCardBtn.length; t < i; t++) {
                t == a ? this.arrCardBtn[a].getChildByName("select").active = true : this.arrCardBtn[t].getChildByName("select").active = false;
            }
        }
        let r = this.laiziCard.getChildByName("laiCardNode");
        sys.isObjectValid(r) || (r = instantiate(this.cardPrefab), r.name = "laiCardNode", r.setPosition(v3(0, 44)), this.laiziCard.addChild(r));
        let s = r.getComponent("RummyCard");
        if (s.init(this._curLaizi, false, 1), s.openCard(), s.showJsLaiziFlag(true, true), ToolUtils.getCardInfo(this._tmpLaizi).point == ToolUtils.getCardInfo(this._curLaizi).point) {
            this.arrowNode.active = false;
            s.setMask(false, true);
        }
        else {
            this.arrowNode.active = true;
            s.setMask(true, true);
            let t = this.arrowNode.getChildByName("JokerCard").getChildByName("laiCardNode");
            if (sys.isObjectValid(t)) {
                let i = t.getComponent("RummyCard");
                i.init(this._tmpLaizi, false, 1);
                i.openCard();
                i.showJsLaiziFlag(true, true);
            }
            else {
                t = instantiate(this.cardPrefab);
                t.name = "laiCardNode";
                let i = t.getComponent("RummyCard");
                i.init(this._tmpLaizi, false, 1);
                i.openCard();
                i.showJsLaiziFlag(true, true);
                t.setPosition(v3(0, 44));
                this.arrowNode.getChildByName("JokerCard").addChild(t);
            }
        }
    }
    updateInfo(t, i = null, e = 0, a) {
        if (this._myCard = t, this._msg = i, this._curLaizi = e, a) {
            let t, i, e, r = [];
            for (let s = 0, o = a.length; s < o; s++) {
                t = ToolUtils.getCardInfo(a[s]);
                i = ToolUtils.getCardShowValue(t.point);
                e = this._rummyCardText.indexOf(i);
                -1 != e && r.push(e);
            }
            for (let t = 0, i = this.arrCardBtn.length; t < i; t++) {
                -1 != r.indexOf(t) ? (this.arrCardBtn[t].getComponent(Button).interactable = true, this.arrCardBtn[t].getChildByName("mask").active = false) : (this.arrCardBtn[t].getComponent(Button).interactable = false, this.arrCardBtn[t].getChildByName("mask").active = true);
            }
        }
        this._hasInit && this.initContectView();
    }
    hideAllReadyFinishShow() {
        for (let t = 0, i = this.arrCardBtn.length; t < i; t++) {
            this.arrCardBtn[t].getChildByName("tips_bg").active = false;
        }
    }
    updateFinishShow(t) {
        let i, e, a, r, s = 0;
        for (let o, n = 0, h = t.infos.length; n < h; n++) {
            o = t.infos[n];
            1 == o.is_hu && (i = ToolUtils.getCardInfo(o.laizi_card), e = ToolUtils.getCardShowValue(i.point), a = this._rummyCardText.indexOf(e), -1 != a && this.arrCardBtn && ToolUtils.isObjValid(this.arrCardBtn[a]) && (r = this.arrCardBtn[a].getChildByName("tips_bg"), r.active = true, r.getComponent(Sprite).spriteFrame = this.tipBgImags[0], i18nMgr.shared().changeLocalizedLabelKey(r.getChildByName("wz"), "rummy_main.bump_finish"), r.getChildByName("wz").getComponent(Label).color = this._colorTips[0]), s = o.laizi_card);
        }
        return s;
    }
    updateReadyShow(t) {
        if (1 == t.is_listen) {
            let i = t.laizi_card, e = ToolUtils.getCardInfo(i), a = ToolUtils.getCardShowValue(e.point), r = this._rummyCardText.indexOf(a);
            if (-1 != r && this.arrCardBtn && ToolUtils.isObjValid(this.arrCardBtn[r])) {
                let t = this.arrCardBtn[r].getChildByName("tips_bg");
                t.active = true;
                t.getComponent(Sprite).spriteFrame = this.tipBgImags[0];
                i18nMgr.shared().changeLocalizedLabelKey(t.getChildByName("wz"), "rummy_main.bump_ready");
                t.getChildByName("wz").getComponent(Label).color = this._colorTips[0];
            }
        }
    }
    updateLastLaizi(t) {
        if (t > 0) {
            let i = ToolUtils.getCardInfo(t), e = ToolUtils.getCardShowValue(i.point), a = this._rummyCardText.indexOf(e);
            if (-1 != a && this.arrCardBtn && ToolUtils.isObjValid(this.arrCardBtn[a])) {
                let t = this.arrCardBtn[a].getChildByName("tips_bg");
                t.active = true;
                t.getComponent(Sprite).spriteFrame = this.tipBgImags[1];
                i18nMgr.shared().changeLocalizedLabelKey(t.getChildByName("wz"), "rummy_main.bump_last");
                t.getChildByName("wz").getComponent(Label).color = this._colorTips[1];
            }
        }
    }
    updateBatchJokerInfo(t, i) {
        if (this._batchJokerInfo = t, this.hideAllReadyFinishShow(), sys.isObjectValid(t)) {
            let e = this.updateFinishShow(t);
            if (e > 0) {
                ToolUtils.getCardInfo(e).point != ToolUtils.getCardInfo(i).point && this.updateLastLaizi(i);
            }
            else {
                if (sys.isObjectValid(t.infos)) {
                    for (let i = 0, e = t.infos.length; i < e; i++) {
                        this.updateReadyShow(t.infos[i]);
                    }
                }
                this.updateLastLaizi(i);
            }
        }
        this._hasInit && this.initContectView();
    }
    switchLaizi(t) {
        if (this._batchJokerInfo) {
            for (let i, e = 0, a = this._batchJokerInfo.infos.length; e < a; e++) {
                if (i = this._batchJokerInfo.infos[e], ToolUtils.getCardInfo(t).point == ToolUtils.getCardInfo(i.laizi_card).point) {
                    this.initCardList(i);
                    break;
                }
            }
        }
    }
    isShowLaiziColor(t, i = 0) {
        if (0 == i && (i = RummyDataManager.shared().rummyInfos.get(this.tid_key).laizicard), 78 == i || 79 == i) {
            if (78 == t || 79 == t || 1 == t || 17 == t || 33 == t || 49 == t) {
                return true;
            }
        }
        else {
            if (78 == t || 79 == t) {
                return true;
            }
            if (i % 16 == t % 16) {
                return true;
            }
        }
        return false;
    }
    initCardList(t) {
        let i = t.cardinfos;
        if (!sys.isObjectValid(i)) {
            return;
        }
        if (sys.isObjectValid(t.laizi_card) ? this.updateChooseLaizi(t.laizi_card) : this._tmpLaizi = this._curLaizi, 1 == t.is_hu) {
            this.finishTx.active = true;
            this.scoreTx.active = false;
            this.readHandTx.active = false;
        }
        else {
            this.finishTx.active = false;
            this.scoreTx.active = true;
            sys.isObjectValid(t.score) && ToolUtils.isObjValid(this.scoreTx) && (this.scoreTx.getComponent(Label).string = "Score left: " + t.score);
            let i = new Vec3;
            this.scoreTx.getPosition(i);
            sys.isObjectValid(t.finish_num) && t.finish_num > 0 && ToolUtils.isObjValid(this.readHandTx) ? (this.scoreTx.setPosition(v3(this._posLeftScore[1], i.y, i.z)), this.readHandTx.active = true, this.readHandTx.getComponent(Label).string = "Ready Hands: " + t.finish_num) : (this.scoreTx.setPosition(v3(this._posLeftScore[0], i.y, i.z)), ToolUtils.isObjValid(this.readHandTx) && (this.readHandTx.active = false));
        }
        this.cardsNode.removeAllChildren();
        let e, a, r, s, o, n = 0, l = 0.38, f = i.length;
        this._cardWidth = 63.84;
        let _ = 0;
        for (let t, e = 0; e < f; e++) {
            t = i[e];
            _ += null != t.cards ? t.cards.length : 0;
        }
        0 == _ && (_ = 13);
        let b, y = (760 - 15 * (f - 1) - f * this._cardWidth) / (1 * (_ - f)), B = this._cardWidth + 15 - y;
        for (let t = 0, d = f; t < d; t++) {
            let d = i[t].cards;
            b = instantiate(this.rootNode.getChildByName("zhegai"));
            b.active = true;
            this.cardsNode.addChild(b);
            let c = i[t].color;
            o = d.length;
            let f = Math.floor(o / 2);
            s = 0;
            for (let i = 0; i < o; i++) {
                let r = instantiate(this.cardPrefab);
                e = r.getComponent("RummyCard");
                e.init(d[i], false, 0);
                e.openCard();
                e.showLaiziFlag(this.isShowLaiziColor(d[i], this._tmpLaizi), false, true);
                r.setScale(v3(l, l));
                a = y * n - 346 + B * t;
                r.setPosition(new Vec3(a, 0));
                this.cardsNode.addChild(r);
                n += 1;
                i == f && (s = a);
            }
            0 == c ? b.getComponent(Sprite).spriteFrame = this.zhegaiImags[0] : 2 == c ? b.getComponent(Sprite).spriteFrame = this.zhegaiImags[1] : 3 == c && (b.getComponent(Sprite).spriteFrame = this.zhegaiImags[2]);
            0 == Math.floor(o % 2) && (s -= y / 2);
            r = (o - 1) * y + this._cardWidth;
            b.getComponent(UITransform).setContentSize(size(r, 14));
            b.setSiblingIndex(100 + t);
            b.setPosition(v3(s, -37));
        }
    }
    setLandscapeShow() {
        ToolUtils.getOrientation() || this.node.setRotationFromEuler(v3(0, 0, -90));
    }
    pushGamePopNode() {
        if (!this.node.active) {
            let t = { node: this.node, tid_key: this.tid_key };
            PushCenter.shared().pushEvent(PushEvent.pushGamePopNode, t);
        }
    }
    removeGamePopNode() {
        if (this.node.active) {
            let t = { node: this.node, tid_key: this.tid_key };
            PushCenter.shared().pushEvent(PushEvent.removeGamePopNode, t);
        }
    }
    onBackView() {
    }
}
