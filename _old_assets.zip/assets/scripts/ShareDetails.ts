// @ts-nocheck
// Recovered from index.js:511
import { _decorator, Label, Layout, Node, ScrollView, sys, UITransform, Vec3 } from "cc";
import TableViewUtils from "./TableViewUtils";
import { TLog } from "./TLog";
import Utils from "./Utils";
import HttpManager from "./HttpManager";
import SoundManager from "./SoundManager";
import BaseLayer from "./BaseLayer";
import TweenTool from "./TweenTool";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("ShareDetails")
export class ShareDetails extends BaseLayer {
    @property(ScrollView)
    public detailList: ScrollView = null;
    @property(Node)
    public moban: Node = null;
    @property(Node)
    public contentNode: Node = null;
    public detailTabView: any = null;
    public _data: any = null;
    public isSendMsg: boolean = false;
    public _lastClick: number = 0;
    public _page: number = 0;
    public _hasNextPage: number = 0;
    public already_data: any[] = [];
    setParaData(t, e) {
        this._data = e;
    }
    start() {
        super.start();
        ToolUtils.showFullScreen(this.node.getChildByName("bg"));
        this.moban.active = false;
        let t = [this.moban];
        this.detailTabView = this.node.addComponent(TableViewUtils);
        let e = this.moban.getComponent(UITransform).height;
        this.detailTabView.init([], this.detailList.node, t, this.initCurMobanCallBack.bind(this), 0, e, this.scrollRefreshCallBack.bind(this), false);
        this.startShowAnim(this.contentNode);
        let a = new Vec3;
        this.contentNode.getPosition(a);
        TweenTool.moveToByFade(this.contentNode, 0.2, a, 0, 1, true);
        this.initNormalData();
        this.refreshDetailList(true);
    }
    initNormalData() {
        this.already_data = [];
        this._page = 0;
        this._hasNextPage = 0;
        this._page = Number(this._data.cpage);
        this._hasNextPage = Number(this._data.has_next);
        sys.isObjectValid(this._data) && sys.isObjectValid(this._data.list) && this._data.list.length > 0 && (this.already_data = this._data.list);
    }
    doGetMoreDetails() {
        let t = this._page;
        HttpManager.shared().doGetCommonRequest({ cpage: t + 1 }, "Share.earnDetails", ((t, e, a) => {
            Utils.shared().hideLoading();
            this.isSendMsg = false;
            try {
                if (200 != a) {
                    alert("The login timed out, please try again");
                }
                else if (200 === a) {
                    let t = ToolUtils.parseJson(e);
                    if (0 === t.ret && ToolUtils.isObjValid(this.node)) {
                        if (ToolUtils.isObjValid(this.node)) {
                            if (sys.isObjectValid(t.data) && (this._page = t.data.cpage, this._hasNextPage = t.data.has_next, sys.isObjectValid(t.data.list) && t.data.list.length > 0)) {
                                for (let e = 0, a = t.data.list.length; e < a; e++) {
                                    this.already_data.push(t.data.list[e]);
                                }
                                this.refreshDetailList(false);
                            }
                        }
                        else {
                            t.desc && ToolUtils.isSafeString(t.desc).length > 0 && Utils.shared().showToast(t.desc, 3);
                        }
                    }
                }
            }
            catch (t) {
                TLog.printError("----- doGetMoreDetails error:", t);
            }
        }));
    }
    refreshDetailList(t) {
        if (t && (this.detailList.getComponent(ScrollView).stopAutoScroll(), this.detailList.getComponent(ScrollView).scrollToTop()), this.already_data && this.already_data.length > 0) {
            return this.contentNode.active = true, this.detailTabView.reloadData(this.already_data, t), void (this.contentNode.getChildByName("nodata_node").active = false);
        }
        this.detailTabView.clearAllItem();
        this.contentNode.getChildByName("nodata_node").active = true;
    }
    initCurMobanCallBack(t, e, a) {
        t.active = true;
        sys.isObjectValid(e.name) && (t.getChildByName("name").getComponent(Label).string = e.name);
        sys.isObjectValid(e.date) && (t.getChildByName("date").getComponent(Label).string = e.date);
        sys.isObjectValid(e.reason) && (t.getChildByName("htype").getComponent(Label).string = e.reason);
        sys.isObjectValid(e.cash) && e.cash > 0 ? (t.getChildByName("reward_root").getChildByName("reward0").active = true, t.getChildByName("reward_root").getChildByName("reward0").getChildByName("wz").getComponent(Label).string = ToolUtils.parse_double(e.cash), t.getChildByName("reward_root").getChildByName("reward0").getComponent(Layout).updateLayout()) : t.getChildByName("reward_root").getChildByName("reward0").active = false;
        sys.isObjectValid(e.bonus) && e.bonus > 0 ? (t.getChildByName("reward_root").getChildByName("reward1").active = true, t.getChildByName("reward_root").getChildByName("reward1").getChildByName("wz").getComponent(Label).string = ToolUtils.parse_double(e.bonus), t.getChildByName("reward_root").getChildByName("reward1").getComponent(Layout).updateLayout()) : t.getChildByName("reward_root").getChildByName("reward1").active = false;
        t.getChildByName("reward_root").getComponent(Layout).updateLayout();
    }
    scrollRefreshCallBack() {
        1 != this._hasNextPage || this.isSendMsg || (this.isSendMsg = true, this.doGetMoreDetails());
    }
    onButtonClick(t, e) {
        "close" == e && (SoundManager.shared().playFx("click"), ToolUtils.isObjValid(this.node) && this.node.destroy());
    }
}
