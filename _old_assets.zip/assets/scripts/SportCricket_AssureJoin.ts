// @ts-nocheck
// Recovered from index.js:545
import { _decorator, instantiate, Label, Node, sp, sys } from "cc";
import SoundManager from "./SoundManager";
import PushCenter from "./PushCenter";
import { TLog } from "./TLog";
import Utils from "./Utils";
import BaseLayer from "./BaseLayer";
import i18nMgr from "./i18nMgr";
import PushEvent from "./PushEvent";
import HttpManager from "./HttpManager";
import { HttpRequest } from "./HttpRequestName";
import { ToolUtils } from "./ToolUtils";
import User from "./User";
import PhpReportDefined from "./PhpReportDefined";
const { ccclass, property } = _decorator;
@ccclass("SportCricket_AssureJoin")
export class SportCricket_AssureJoin extends BaseLayer {
    public TAG: string = "SportCricket_AssureJoin";
    @property(Node)
    public rootNode: Node = null;
    @property(Node)
    public signOkNode: Node = null;
    @property(Node)
    public nextNode: Node = null;
    @property(Node)
    public contentNode: Node = null;
    @property(Node)
    public team_mobanView: Node = null;
    public _closed: boolean = false;
    public bShowPushAnim: boolean = false;
    public _lastClick: number = 0;
    public _isSendMsg: boolean = false;
    public _match_id: number = 0;
    public _source: any = null;
    public _assureInfo: any = null;
    public _contest_id: number = 0;
    public _fromType: number = 0;
    public _hasForceSignMatch: number = 0;
    onLoad() {
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().removeListenersByTag(this);
        this.unscheduleAllCallbacks();
    }
    init(e) {
        sys.isObjectValid(e) && sys.isObjectValid(e.match_id) && (this._match_id = e.match_id);
        sys.isObjectValid(e) && sys.isObjectValid(e.source) && (this._source = { ...e.source });
        sys.isObjectValid(e) && sys.isObjectValid(e.fromType) && (this._fromType = e.fromType);
        sys.isObjectValid(e) && sys.isObjectValid(e.contest_id) && (this._contest_id = e.contest_id);
        sys.isObjectValid(e) && sys.isObjectValid(e.assureInfo) && (this._assureInfo = e.assureInfo);
        sys.isObjectValid(e) && sys.isObjectValid(e.force) && (this._hasForceSignMatch = e.force);
    }
    start() {
        super.start();
        this.initView();
        this.refreshView();
        this.startShowAnim(this.rootNode);
    }
    refreshView() {
        if (this.updateContestDetails(), 1 == this._hasForceSignMatch && 1 == User.shared().forceSignCricket) {
            this.rootNode.getChildByName("fingerNode").active = true;
            let e = this.rootNode.getChildByName("fingerNode").getComponent(sp.Skeleton);
            e.clearTracks();
            e.setToSetupPose();
            e.setAnimation(0, "click", true);
        }
    }
    updateContestDetails() {
        sys.isObjectValid(this._assureInfo) && (this.rootNode.getChildByName("join_tip").getComponent(Label).string = ToolUtils.format(i18nMgr.shared().getValueByKey("yes11.join_team"), this._assureInfo.list.length), sys.isObjectValid(this._assureInfo.is_chip) && 1 == this._assureInfo.is_chip ? (this.rootNode.getChildByName("node").getChildByName("price").getComponent(Label).string = String(this._assureInfo.fee), this.rootNode.getChildByName("node").getChildByName("ico").active = true) : (this.rootNode.getChildByName("node").getChildByName("price").getComponent(Label).string = "₹" + String(this._assureInfo.fee), this.rootNode.getChildByName("node").getChildByName("ico").active = false), this.reSortTeamInfo());
    }
    reSortTeamInfo() {
        this.contentNode.removeAllChildren();
        sys.isObjectValid(this._assureInfo.list) && Array.isArray(this._assureInfo.list) && this._assureInfo.list.length > 0 && this.addTeamView(this.contentNode, this._assureInfo.list);
    }
    addTeamView(e, t) {
        for (let i = 0; i < t.length; i++) {
            let s = instantiate(this.team_mobanView);
            s.active = true;
            e.addChild(s);
            sys.isObjectValid(t[i].team_name) && t[i].team_name.length > 0 && (s.getChildByName("wz").getComponent(Label).string = t[i].team_name);
        }
    }
    checkJoinTeam(e = 0, t) {
        let i = 0;
        1 == this._hasForceSignMatch && 1 == User.shared().forceSignCricket && (i = 1);
        let s = [];
        for (let e = 0; e < this._assureInfo.list.length; e++) {
            s.push(this._assureInfo.list[e].team_id);
        }
        let o = { match_id: this._match_id, session_id: this._contest_id, team_ids: s.join(","), force: i };
        Utils.shared().showLoading(10, true, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
        }), ToolUtils.getIsNormalDirection());
        HttpManager.shared().doGetCommonRequest(o, HttpRequest.Yes11_AssureJoinGame, ((e, t, i) => {
            if (Utils.shared().hideLoading(), 200 != i) {
                ;
            }
            else {
                try {
                    let e = ToolUtils.parseJson(t);
                    if (0 == e.ret) {
                        User.shared().forceSignCricket = 0;
                        PushCenter.shared().pushEvent(PushEvent.Yes11SignOk, e.data);
                        let t = false, i = User.shared().data.cricket_guide;
                        sys.isObjectValid(i) && sys.isObjectValid(i.cricket_sign_guide) && 1 == i.cricket_sign_guide && (t = true);
                        this.showSignOk(t);
                    }
                    else {
                        308501 == e.ret ? (sys.isObjectValid(this._assureInfo._is_chip) && 1 == this._assureInfo._is_chip ? Utils.shared().showQuickRechargeByYes11({ fee: this._assureInfo.fee, is_chip: 1 }) : Utils.shared().showQuickRechargeByYes11({ fee: this._assureInfo.fee }), User.shared().updatePayScene(PhpReportDefined.pay_scene.hall_cricket)) : sys.isObjectValid(e.desc) && e.desc.length > 0 && Utils.shared().showToast(e.desc, 2);
                    }
                }
                catch (e) {
                    TLog.printError("User requestYes11_assureJoin err:", e.toString());
                }
            }
        }));
    }
    showSignOk(e = false) {
        this.signOkNode.active = true;
        ToolUtils.showFullScreen(this.signOkNode.getChildByName("mask"));
        this.signOkNode.getChildByName("anim").active = true;
        this.signOkNode.getChildByName("anim").getComponent(sp.Skeleton).clearTracks();
        this.signOkNode.getChildByName("anim").getComponent(sp.Skeleton).setToSetupPose();
        this.signOkNode.getChildByName("anim").getComponent(sp.Skeleton).setSkin("congratulation");
        this.signOkNode.getChildByName("anim").getComponent(sp.Skeleton).setAnimation(0, "hall", false);
        this.signOkNode.getChildByName("root").getChildByName("assure_btn").active = !e;
        this.signOkNode.getChildByName("root").getChildByName("rummy_btn").active = e;
        this.signOkNode.getChildByName("root").getChildByName("joinmore_btn").active = e;
        this._hasForceSignMatch = 0;
        User.shared().data.cricket_guide = null;
    }
    onCloseButtonClick(e, t) {
        1 != this._hasForceSignMatch && (SoundManager.shared().playFx("click"), sys.now() - this._lastClick < 500 || (this._lastClick = sys.now(), this.onBackView()));
    }
    initView() {
        this.fitScreen();
    }
    onButtonClick(e, t) {
        1 == this._hasForceSignMatch && "join" != t || (SoundManager.shared().playFx("click"), sys.now() - this._lastClick < 500 || (this._lastClick = sys.now(), "join" == t ? this.checkJoinTeam() : "close_sign" == t ? this.onBackView() : "join_more" == t ? (PushCenter.shared().pushEvent(PushEvent.CricketForceSign_JoinMore), this.onBackView()) : "play_rummy" == t && (PushCenter.shared().pushEvent(PushEvent.CricketForceSign_PlayRummy), this.onBackView())));
    }
    onBackView(e = true) {
        e && (Utils.shared().hideLoading(), this.bShowPushAnim ? (this._closed = true, ToolUtils.showPushAnim(this.node, 1, (() => {
            ToolUtils.isObjValid(this.node) && this.node.destroy();
        }))) : ToolUtils.isObjValid(this.node) && this.node.destroy());
    }
    fitScreen() {
        ToolUtils.adaptSafeArea(this.rootNode);
        sys.getSafeAreaRect().y;
    }
}
