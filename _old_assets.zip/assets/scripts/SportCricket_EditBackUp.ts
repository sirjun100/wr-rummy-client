// @ts-nocheck
// Recovered from index.js:551
import { _decorator, Button, color, instantiate, Label, Node, size, Sprite, SpriteFrame, sys, UIOpacity, UITransform, v3, view, Widget } from "cc";
import SoundManager from "./SoundManager";
import PushCenter from "./PushCenter";
import { TLog } from "./TLog";
import Utils from "./Utils";
import User from "./User";
import HttpManager from "./HttpManager";
import i18nMgr from "./i18nMgr";
import BaseLayer from "./BaseLayer";
import { HttpRequest } from "./HttpRequestName";
import GameConfig from "./GameConfig";
import PushEvent from "./PushEvent";
import CommDefine from "./CommDefine";
import TweenTool from "./TweenTool";
import SportCricket_Manager from "./SportCricket_Manager";
import { ToolUtils } from "./ToolUtils";
import PhpReportDefined from "./PhpReportDefined";
const { ccclass, property } = _decorator;
@ccclass("SportCricket_EditBackUp")
export class SportCricket_EditBackUp extends BaseLayer {
    public TAG: string = "SportCricket_EditBackUp";
    @property(Node)
    public rootNode: Node = null;
    @property(Node)
    public goldNode: Node = null;
    @property(Node)
    public teamTopNode: Node = null;
    @property(Node)
    public topNode: Node = null;
    @property(Node)
    public saveNode: Node = null;
    @property(Node)
    public detailsNode: Node = null;
    @property(Node)
    public contentNode: Node = null;
    @property([SpriteFrame])
    public teamBgImgs: SpriteFrame[] = [];
    @property([SpriteFrame])
    public capBgImgs: SpriteFrame[] = [];
    @property([SpriteFrame])
    public btnBgImgs: SpriteFrame[] = [];
    @property([SpriteFrame])
    public sortArrowImgs: SpriteFrame[] = [];
    @property([SpriteFrame])
    public operateImgs: SpriteFrame[] = [];
    public leader_listData: any[] = [];
    @property(Node)
    public team_mobanView: Node = null;
    public _closed: boolean = false;
    public bShowPushAnim: boolean = true;
    public _lastClick: number = 0;
    public _sourceData: any = null;
    public _itemArr: any[] = [];
    public _isSendMsg: boolean = false;
    public taskAwardIconMap: Map = new Map;
    public _match_id: number = 0;
    public _player_source: any = null;
    public _team_id: number = 0;
    public _source: any = null;
    public lastClick: number = 0;
    public _teamSortType: number = 1;
    public _pointsSortType: number = 1;
    public _rateSortType: number = 1;
    public _curSortType: number = 1;
    public _wkPlayMsgs: any[] = [];
    public _batPlayMsgs: any[] = [];
    public _arPlayMsgs: any[] = [];
    public _bowlPlayMsgs: any[] = [];
    public _fromType: number = 0;
    public backupPlayerMap: Map = new Map;
    public backupPlayerMapByPid: Map = new Map;
    public _allPlayerMsg: Map = new Map;
    public _allPlayerView: any[] = [];
    public playerViewMap: Map = new Map;
    public _match_state: number = 1;
    public _hasChooseBackUp: number = 0;
    public _lastNode: any = null;
    public _lineup: number = 0;
    public _call: any = null;
    public sort_select_color: any = color(183, 0, 0);
    onLoad() {
        PushCenter.shared().addListener(GameConfig.Update_Money, (t => {
            try {
                ToolUtils.isObjValid(this.node) && this.updateGold(t);
            }
            catch (t) {
                TLog.printError(this.TAG, GameConfig.Update_Money, t);
            }
        }), this);
        PushCenter.shared().addListener(PushEvent.CloseYes11CreateTeam, (t => {
            try {
                ToolUtils.isObjValid(this.node) && this.node.destroy();
            }
            catch (t) {
                TLog.printError(this.TAG, PushEvent.CloseYes11CreateTeam, t);
            }
        }), this);
        PushCenter.shared().addListener(PushEvent.commentDownloaderImg, (t => {
            try {
                if (ToolUtils.isObjValid(this.node) && this.taskAwardIconMap.size > 0) {
                    for (const [e, i] of this.taskAwardIconMap) {
                        i == t && sys.isObjectValid(e) && ("player_icon" == e.name ? Utils.shared().updateNetImage(e, t, size(110, 110)) : Utils.shared().updateNetImage(e, t, size(40, 40)));
                    }
                }
            }
            catch (t) {
                TLog.printError(this.TAG, PushEvent.commentDownloaderImg, t);
            }
        }), this);
        this.fitLuckyTheme();
    }
    fitLuckyTheme() {
        0 != GameConfig.NATIVE_GAME_APP_TYPE && (this.sort_select_color = color(38, 59, 152), this.rootNode.getChildByName("top_node").getChildByName("top_bg").getComponent(Sprite).color = color(12, 26, 60, 255), this.goldNode.getChildByName("coin").getComponent(Label).color = color(251, 220, 0, 255));
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().removeListenersByTag(this);
        this.unscheduleAllCallbacks();
    }
    init(t) {
        sys.isObjectValid(t) && sys.isObjectValid(t.match_id) && (this._match_id = t.match_id);
        sys.isObjectValid(t) && sys.isObjectValid(t.player_source) && (this._player_source = t.player_source);
        sys.isObjectValid(t) && sys.isObjectValid(t.source) && (this._source = { ...t.source });
        sys.isObjectValid(t) && sys.isObjectValid(t.fromType) && (this._fromType = t.fromType);
        sys.isObjectValid(t) && sys.isObjectValid(t.team_id) && (this._team_id = t.team_id);
        sys.isObjectValid(t) && sys.isObjectValid(t.lastNode) && (this._lastNode = t.lastNode);
        sys.isObjectValid(t) && sys.isObjectValid(t.call) && (this._call = t.call);
    }
    start() {
        super.start();
        this.initView();
        this.bShowPushAnim && ToolUtils.showPushAnim(this.node, 0, (() => {
            this.refreshView();
            ToolUtils.isObjValid(this._lastNode) && (this._lastNode.active = false);
        }));
        this.updateGold(User.shared().data.money);
    }
    filterSelectPlayer() {
        if (this._allPlayerMsg.clear(), this._wkPlayMsgs = [], this._batPlayMsgs = [], this._arPlayMsgs = [], this._bowlPlayMsgs = [], sys.isObjectValid(this._player_source)) {
            if (sys.isObjectValid(this._player_source.wk) && this._player_source.wk.length > 0) {
                for (let t = 0; t < this._player_source.wk.length; t++) {
                    1 == this._player_source.wk[t].playing11 && (this._lineup = 1);
                    this._player_source.wk[t].role = "WK";
                    0 == this._player_source.wk[t].select_status && this._wkPlayMsgs.push(this._player_source.wk[t]);
                }
            }
            if (sys.isObjectValid(this._player_source.bat) && this._player_source.bat.length > 0) {
                for (let t = 0; t < this._player_source.bat.length; t++) {
                    1 == this._player_source.bat[t].playing11 && (this._lineup = 1);
                    this._player_source.bat[t].role = "BAT";
                    0 == this._player_source.bat[t].select_status && this._batPlayMsgs.push(this._player_source.bat[t]);
                }
            }
            if (sys.isObjectValid(this._player_source.ar) && this._player_source.ar.length > 0) {
                for (let t = 0; t < this._player_source.ar.length; t++) {
                    1 == this._player_source.ar[t].playing11 && (this._lineup = 1);
                    this._player_source.ar[t].role = "AR";
                    0 == this._player_source.ar[t].select_status && this._arPlayMsgs.push(this._player_source.ar[t]);
                }
            }
            if (sys.isObjectValid(this._player_source.bowl) && this._player_source.bowl.length > 0) {
                for (let t = 0; t < this._player_source.bowl.length; t++) {
                    1 == this._player_source.bowl[t].playing11 && (this._lineup = 1);
                    this._player_source.bowl[t].role = "BOWL";
                    0 == this._player_source.bowl[t].select_status && this._bowlPlayMsgs.push(this._player_source.bowl[t]);
                }
            }
        }
    }
    updateBackUpInBoard() {
        this._hasChooseBackUp = 0;
        for (let t = 0; t < 4; t++) {
            let e = this.detailsNode.getChildByName("cap_node" + t);
            this.backupPlayerMap.has(t + 1) && sys.isObjectValid(this.backupPlayerMap.get(t + 1).player_id) ? (e.getComponent(UIOpacity).opacity = 255, this.backupPlayerMap.get(t + 1).backup = t + 1, this._hasChooseBackUp += 1, this.backupPlayerMap.get(t + 1).team_id == this._player_source.teama.tid ? (e.getChildByName("bg").getComponent(Sprite).spriteFrame = this.capBgImgs[0], e.getChildByName("wz").getComponent(Label).color = color(255, 255, 255)) : (e.getChildByName("bg").getComponent(Sprite).spriteFrame = this.capBgImgs[1], e.getChildByName("wz").getComponent(Label).color = color(51, 51, 51)), this.backupPlayerMap.get(t + 1).short_name.length > 13 ? e.getChildByName("wz").getComponent(Label).string = ToolUtils.GetShortName2(this.backupPlayerMap.get(t + 1).short_name, 10, true) : e.getChildByName("wz").getComponent(Label).string = this.backupPlayerMap.get(t + 1).short_name) : (e.getChildByName("bg").getComponent(Sprite).spriteFrame = this.capBgImgs[1], e.getChildByName("wz").getComponent(Label).color = color(51, 51, 51), e.getChildByName("wz").getComponent(Label).string = "Backup " + (t + 1), e.getComponent(UIOpacity).opacity = 128);
        }
    }
    refreshView() {
        this.updateContestDetails();
        this.reSortPlayerInfo();
        this.updateBackUpInBoard();
        this.updateNextButtonStatus();
    }
    updateTopContestDetails() {
        if (!sys.isObjectValid(this._source)) {
            return;
        }
        let t = this._source.teama, e = this._source.teamb;
        sys.isObjectValid(t.short_name) && t.short_name.length > 0 && (this.topNode.getChildByName("team_short_name0").getComponent(Label).string = t.short_name);
        sys.isObjectValid(e.short_name) && e.short_name.length > 0 && (this.topNode.getChildByName("team_short_name1").getComponent(Label).string = e.short_name);
        sys.isObjectValid(t.logo_url) && t.logo_url.length > 0 && (this.taskAwardIconMap.set(this.topNode.getChildByName("team_icon0"), t.logo_url), Utils.shared().updateNetImage(this.topNode.getChildByName("team_icon0"), t.logo_url, size(76, 76)));
        sys.isObjectValid(e.logo_url) && e.logo_url.length > 0 && (this.taskAwardIconMap.set(this.topNode.getChildByName("team_icon1"), e.logo_url), Utils.shared().updateNetImage(this.topNode.getChildByName("team_icon1"), e.logo_url, size(76, 76)));
        sys.isObjectValid(this._source.location) && this._source.location.length > 0 && (this.topNode.getChildByName("location").getComponent(Label).string = this._source.location);
    }
    updateContestDetails() {
        sys.isObjectValid(this._player_source) && this.filterSelectPlayer();
    }
    sortPlayerInfoByType() {
        0 == this._curSortType ? 0 == this._teamSortType ? (this._wkPlayMsgs.sort(((t, e) => t.team_id - e.team_id)), this._batPlayMsgs.sort(((t, e) => t.team_id - e.team_id)), this._arPlayMsgs.sort(((t, e) => t.team_id - e.team_id)), this._bowlPlayMsgs.sort(((t, e) => t.team_id - e.team_id))) : (this._wkPlayMsgs.sort(((t, e) => e.team_id - t.team_id)), this._batPlayMsgs.sort(((t, e) => e.team_id - t.team_id)), this._arPlayMsgs.sort(((t, e) => e.team_id - t.team_id)), this._bowlPlayMsgs.sort(((t, e) => e.team_id - t.team_id))) : 1 == this._curSortType ? 0 == this._pointsSortType ? (this._wkPlayMsgs.sort(((t, e) => t.pts !== e.pts ? t.pts - e.pts : e.credits - t.credits)), this._batPlayMsgs.sort(((t, e) => t.pts !== e.pts ? t.pts - e.pts : e.credits - t.credits)), this._arPlayMsgs.sort(((t, e) => t.pts !== e.pts ? t.pts - e.pts : e.credits - t.credits)), this._bowlPlayMsgs.sort(((t, e) => t.pts !== e.pts ? t.pts - e.pts : e.credits - t.credits))) : (this._wkPlayMsgs.sort(((t, e) => t.pts !== e.pts ? e.pts - t.pts : e.credits - t.credits)), this._batPlayMsgs.sort(((t, e) => t.pts !== e.pts ? e.pts - t.pts : e.credits - t.credits)), this._arPlayMsgs.sort(((t, e) => t.pts !== e.pts ? e.pts - t.pts : e.credits - t.credits)), this._bowlPlayMsgs.sort(((t, e) => t.pts !== e.pts ? e.pts - t.pts : e.credits - t.credits))) : 2 == this._curSortType && (0 == this._rateSortType ? (this._wkPlayMsgs.sort(((t, e) => t.backup_prob !== e.backup_prob ? t.backup_prob - e.backup_prob : e.credits - t.credits)), this._batPlayMsgs.sort(((t, e) => t.backup_prob !== e.backup_prob ? t.backup_prob - e.backup_prob : e.credits - t.credits)), this._arPlayMsgs.sort(((t, e) => t.backup_prob !== e.backup_prob ? t.backup_prob - e.backup_prob : e.credits - t.credits)), this._bowlPlayMsgs.sort(((t, e) => t.backup_prob !== e.backup_prob ? t.backup_prob - e.backup_prob : e.credits - t.credits))) : (this._wkPlayMsgs.sort(((t, e) => t.backup_prob !== e.backup_prob ? e.backup_prob - t.backup_prob : e.credits - t.credits)), this._batPlayMsgs.sort(((t, e) => t.backup_prob !== e.backup_prob ? e.backup_prob - t.backup_prob : e.credits - t.credits)), this._arPlayMsgs.sort(((t, e) => t.backup_prob !== e.backup_prob ? e.backup_prob - t.backup_prob : e.credits - t.credits)), this._bowlPlayMsgs.sort(((t, e) => t.backup_prob !== e.backup_prob ? e.backup_prob - t.backup_prob : e.credits - t.credits))));
    }
    updateSortView() {
        try {
            0 == this._curSortType ? (this.teamTopNode.getChildByName("team_sort").getChildByName("wz").getComponent(Label).color = this.sort_select_color, this.teamTopNode.getChildByName("team_sort").getChildByName("arrow").getComponent(Sprite).color = color(255, 255, 255), 1 == this._teamSortType ? this.teamTopNode.getChildByName("team_sort").getChildByName("arrow").getComponent(Sprite).spriteFrame = this.sortArrowImgs[2] : this.teamTopNode.getChildByName("team_sort").getChildByName("arrow").getComponent(Sprite).spriteFrame = this.sortArrowImgs[1], this.teamTopNode.getChildByName("point_sort").getChildByName("wz").getComponent(Label).color = color(102, 102, 102), this.teamTopNode.getChildByName("point_sort").getChildByName("arrow").getComponent(Sprite).color = color(102, 102, 102), this.teamTopNode.getChildByName("point_sort").getChildByName("arrow").getComponent(Sprite).spriteFrame = this.sortArrowImgs[0], this.teamTopNode.getChildByName("sel_sort").getChildByName("wz").getComponent(Label).color = color(102, 102, 102), this.teamTopNode.getChildByName("sel_sort").getChildByName("arrow").getComponent(Sprite).color = color(102, 102, 102), this.teamTopNode.getChildByName("sel_sort").getChildByName("arrow").getComponent(Sprite).spriteFrame = this.sortArrowImgs[0]) : 1 == this._curSortType ? (this.teamTopNode.getChildByName("point_sort").getChildByName("wz").getComponent(Label).color = this.sort_select_color, this.teamTopNode.getChildByName("point_sort").getChildByName("arrow").getComponent(Sprite).color = color(255, 255, 255), 1 == this._pointsSortType ? this.teamTopNode.getChildByName("point_sort").getChildByName("arrow").getComponent(Sprite).spriteFrame = this.sortArrowImgs[2] : this.teamTopNode.getChildByName("point_sort").getChildByName("arrow").getComponent(Sprite).spriteFrame = this.sortArrowImgs[1], this.teamTopNode.getChildByName("team_sort").getChildByName("wz").getComponent(Label).color = color(102, 102, 102), this.teamTopNode.getChildByName("team_sort").getChildByName("arrow").getComponent(Sprite).color = color(102, 102, 102), this.teamTopNode.getChildByName("team_sort").getChildByName("arrow").getComponent(Sprite).spriteFrame = this.sortArrowImgs[0], this.teamTopNode.getChildByName("sel_sort").getChildByName("wz").getComponent(Label).color = color(102, 102, 102), this.teamTopNode.getChildByName("sel_sort").getChildByName("arrow").getComponent(Sprite).color = color(102, 102, 102), this.teamTopNode.getChildByName("sel_sort").getChildByName("arrow").getComponent(Sprite).spriteFrame = this.sortArrowImgs[0]) : 2 == this._curSortType && (this.teamTopNode.getChildByName("sel_sort").getChildByName("wz").getComponent(Label).color = this.sort_select_color, this.teamTopNode.getChildByName("sel_sort").getChildByName("arrow").getComponent(Sprite).color = color(255, 255, 255), 1 == this._rateSortType ? this.teamTopNode.getChildByName("sel_sort").getChildByName("arrow").getComponent(Sprite).spriteFrame = this.sortArrowImgs[2] : this.teamTopNode.getChildByName("sel_sort").getChildByName("arrow").getComponent(Sprite).spriteFrame = this.sortArrowImgs[1], this.teamTopNode.getChildByName("team_sort").getChildByName("wz").getComponent(Label).color = color(102, 102, 102), this.teamTopNode.getChildByName("team_sort").getChildByName("arrow").getComponent(Sprite).color = color(102, 102, 102), this.teamTopNode.getChildByName("team_sort").getChildByName("arrow").getComponent(Sprite).spriteFrame = this.sortArrowImgs[0], this.teamTopNode.getChildByName("point_sort").getChildByName("wz").getComponent(Label).color = color(102, 102, 102), this.teamTopNode.getChildByName("point_sort").getChildByName("arrow").getComponent(Sprite).color = color(102, 102, 102), this.teamTopNode.getChildByName("point_sort").getChildByName("arrow").getComponent(Sprite).spriteFrame = this.sortArrowImgs[0]);
        }
        catch (t) {
            TLog.printError(this.TAG, "updateSortView:", t);
        }
    }
    reSortPlayerInfo() {
        this.contentNode.getChildByName("wk_layout").removeAllChildren();
        this.contentNode.getChildByName("bat_layout").removeAllChildren();
        this.contentNode.getChildByName("ar_layout").removeAllChildren();
        this.contentNode.getChildByName("bowl_layout").removeAllChildren();
        this._allPlayerView = [];
        this.playerViewMap.clear();
        this.updateSortView();
        this.sortPlayerInfoByType();
        this.contentNode.getChildByName("bat_bg").active = this._wkPlayMsgs.length > 0 && this._batPlayMsgs.length > 0;
        this.contentNode.getChildByName("ar_bg").active = this._arPlayMsgs.length > 0;
        this.contentNode.getChildByName("bowl_bg").active = this._bowlPlayMsgs.length > 0;
        this.addPlayerView(this.contentNode.getChildByName("wk_layout"), this._wkPlayMsgs);
        this.addPlayerView(this.contentNode.getChildByName("bat_layout"), this._batPlayMsgs);
        this.addPlayerView(this.contentNode.getChildByName("ar_layout"), this._arPlayMsgs);
        this.addPlayerView(this.contentNode.getChildByName("bowl_layout"), this._bowlPlayMsgs);
    }
    addPlayerView(t, e) {
        for (let i = 0; i < e.length; i++) {
            let s = instantiate(this.team_mobanView);
            s.active = true;
            t.addChild(s);
            this._allPlayerView.push(s);
            this.playerViewMap.set(e[i].player_id, s);
            s.getChildByName("bg").getComponent(Sprite).color = color(255, 255, 255);
            let a = ToolUtils.toJsonString(e[i]);
            s.getChildByName("player_btn").getComponent(Button).clickEvents[0].customEventData = a;
            for (let t = 0; t < 4; t++) {
                let o = s.getChildByName("backup" + (t + 1));
                o.getComponent(Button).clickEvents[0].customEventData = a;
                o.getChildByName("ico").getComponent(Sprite).spriteFrame = this.operateImgs[0];
                o.getChildByName("role").getComponent(Label).color = color(102, 102, 102);
                sys.isObjectValid(e[i].backup) && Number(e[i].backup) > 0 && (this.backupPlayerMap.set(Number(e[i].backup), e[i]), this.backupPlayerMapByPid.set(e[i].player_id, Number(e[i].backup)), Number(e[i].backup) == t + 1 && (s.getChildByName("bg").getComponent(Sprite).color = color(255, 247, 224), o.getChildByName("ico").getComponent(Sprite).spriteFrame = this.operateImgs[1], o.getChildByName("role").getComponent(Label).color = color(255, 255, 255)));
            }
            s.getChildByName("team_bg").getChildByName("wz").getComponent(Label).string = e[i].team_abbr;
            s.getChildByName("team_bg").getChildByName("wz").getComponent(Label).updateRenderData(true);
            let o = s.getChildByName("team_bg").getChildByName("wz").getComponent(UITransform).width;
            o > 25 && (s.getChildByName("team_bg").getComponent(UITransform).contentSize = size(o + 10, 20));
            e[i].team_id == this._player_source.teama.tid ? (s.getChildByName("team_bg").getComponent(Sprite).spriteFrame = this.teamBgImgs[0], s.getChildByName("team_bg").getChildByName("wz").getComponent(Label).color = color(255, 255, 255)) : (s.getChildByName("team_bg").getComponent(Sprite).spriteFrame = this.teamBgImgs[1], s.getChildByName("team_bg").getChildByName("wz").getComponent(Label).color = color(51, 51, 51));
            sys.isObjectValid(e[i].thumb_url) && e[i].thumb_url.length > 0 && (this.taskAwardIconMap.set(s.getChildByName("player_icon"), e[i].thumb_url), Utils.shared().updateNetImage(s.getChildByName("player_icon"), e[i].thumb_url, size(110, 110)));
            sys.isObjectValid(e[i].pts) && (s.getChildByName("pts").getComponent(Label).string = "" + e[i].pts);
            sys.isObjectValid(e[i].role) && (s.getChildByName("role").getComponent(Label).string = e[i].role);
            sys.isObjectValid(e[i].short_name) && (s.getChildByName("pname").getComponent(Label).string = String(e[i].short_name));
            sys.isObjectValid(e[i].backup_prob) ? (s.getChildByName("rate").getComponent(Label).string = e[i].backup_prob + "%", s.getChildByName("line").active = true) : (s.getChildByName("rate").getComponent(Label).string = "0%", s.getChildByName("line").active = true);
            let r = 0;
            0 == this._lineup && (r = -20);
            s.getChildByName("role").setPosition(v3(-210.095 + r, -74.462));
            "WK" == e[i].role ? (s.getChildByName("rate").setPosition(v3(-156.677 + r, -74.462)), s.getChildByName("line").setPosition(v3(-168.636 + r, -75.703))) : "AR" == e[i].role ? (s.getChildByName("rate").setPosition(v3(-161.677 + r, -74.462)), s.getChildByName("line").setPosition(v3(-173.636 + r, -75.703))) : "BAT" == e[i].role ? (s.getChildByName("rate").setPosition(v3(-151.677 + r, -74.462)), s.getChildByName("line").setPosition(v3(-163.636 + r, -75.703))) : "BOWL" == e[i].role && (s.getChildByName("rate").setPosition(v3(-131.677 + r, -74.462)), s.getChildByName("line").setPosition(v3(-143.636 + r, -75.703)));
            s.getChildByName("dot").active = 1 == this._lineup;
            1 == this._lineup && (1 == e[i].playing11 ? s.getChildByName("dot").getComponent(Label).color = color(0, 140, 22) : sys.isObjectValid(e[i].subplayer) && 1 == e[i].subplayer ? s.getChildByName("dot").getComponent(Label).color = color(56, 95, 223) : s.getChildByName("dot").getComponent(Label).color = color(215, 60, 69));
        }
    }
    updateGold(t) {
        let e = this.goldNode.getChildByName("coin");
        null != t && e && (e.getComponent(Label).string = ToolUtils.parse_double(t));
    }
    dealSelectBackUpLogic(t, e) {
        if (3 != this._match_state) {
            if (4 != this._match_state) {
                if (this.backupPlayerMap.has(t)) {
                    let i = this.backupPlayerMap.get(t);
                    if (this.updateTargetPlayerViewStatus(0, i.player_id), this.backupPlayerMapByPid.has(i.player_id)) {
                        let t = this.backupPlayerMapByPid.get(i.player_id);
                        this.backupPlayerMap.has(t) && this.backupPlayerMap.delete(t);
                        this.backupPlayerMapByPid.delete(i.player_id);
                    }
                    if (this.backupPlayerMapByPid.has(e.player_id)) {
                        let t = this.backupPlayerMapByPid.get(e.player_id);
                        this.backupPlayerMap.has(t) && this.backupPlayerMap.delete(t);
                    }
                    i.player_id != e.player_id && (this.backupPlayerMap.set(t, e), this.backupPlayerMapByPid.set(e.player_id, t), this.updateTargetPlayerViewStatus(t, e.player_id));
                }
                else {
                    if (this.backupPlayerMapByPid.has(e.player_id)) {
                        let t = this.backupPlayerMapByPid.get(e.player_id);
                        this.backupPlayerMap.has(t) && this.backupPlayerMap.delete(t);
                    }
                    this.backupPlayerMap.set(t, e);
                    this.backupPlayerMapByPid.set(e.player_id, t);
                    this.updateTargetPlayerViewStatus(t, e.player_id);
                }
                this.updateBackUpInBoard();
                this.updateNextButtonStatus();
            }
            else {
                Utils.shared().showToast(i18nMgr.shared().getValueByKey("yes11.cancel_tip"), 2);
            }
        }
        else {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("yes11.live_tip"), 2);
        }
    }
    updatePlayerViewAfterSort() {
        if (3 != this._match_state && 4 != this._match_state) {
            for (let t = 1; t < 5; t++) {
                if (this.backupPlayerMap.has(t)) {
                    let e = this.backupPlayerMap.get(t);
                    this.updateTargetPlayerViewStatus(t, e.player_id);
                }
            }
        }
    }
    onSelectBackUp1Click(t, e) {
        SoundManager.shared().playFx("click");
        this._lastClick = sys.now();
        let i = ToolUtils.parseJson(e);
        this.dealSelectBackUpLogic(1, i);
    }
    onPlayerInfoClick(t, e) {
        if (SoundManager.shared().playFx("click"), sys.now() - this._lastClick < 500) {
            return;
        }
        if (this._lastClick = sys.now(), 3 == this._match_state) {
            return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("yes11.live_tip"), 2);
        }
        if (4 == this._match_state) {
            return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("yes11.cancel_tip"), 2);
        }
        let i = ToolUtils.parseJson(e), s = { source: this._source, match_id: this._match_id, team_id: this._team_id, player_id: i.player_id, lastNode: this.node, join_team: i.join_team, select_status: 0, fromType: 3 };
        SportCricket_Manager.shared().requestYes11_PlayerInfo(s, true);
    }
    onSelectBackUp2Click(t, e) {
        if (SoundManager.shared().playFx("click"), sys.now() - this._lastClick < 500) {
            return;
        }
        this._lastClick = sys.now();
        let i = ToolUtils.parseJson(e);
        this.dealSelectBackUpLogic(2, i);
    }
    onSelectBackUp3Click(t, e) {
        if (SoundManager.shared().playFx("click"), sys.now() - this._lastClick < 500) {
            return;
        }
        this._lastClick = sys.now();
        let i = ToolUtils.parseJson(e);
        this.dealSelectBackUpLogic(3, i);
    }
    onSelectBackUp4Click(t, e) {
        if (SoundManager.shared().playFx("click"), sys.now() - this._lastClick < 500) {
            return;
        }
        this._lastClick = sys.now();
        let i = ToolUtils.parseJson(e);
        this.dealSelectBackUpLogic(4, i);
    }
    updateNextButtonStatus() {
        let t = false;
        for (let e = 1; e <= 4; e++) {
            this.backupPlayerMap.has(e) && (t = true);
        }
        t ? (this.saveNode.getComponent(Sprite).spriteFrame = this.btnBgImgs[0], Utils.updateLabelMaterial(this.saveNode.getChildByName("wz"), CommDefine.gradient.btn_blue), this.saveNode.getComponent(Button).interactable = true) : (this.saveNode.getComponent(Sprite).spriteFrame = this.btnBgImgs[1], Utils.updateLabelMaterial(this.saveNode.getChildByName("wz"), CommDefine.gradient.btn_gray), this.saveNode.getComponent(Button).interactable = true);
    }
    dealCreateLogic() {
        let t = [];
        for (let e = 1; e <= 4; e++) {
            if (this.backupPlayerMap.has(e) && sys.isObjectValid(this.backupPlayerMap.get(e)) && sys.isObjectValid(this.backupPlayerMap.get(e).player_id)) {
                let i = { player_id: this.backupPlayerMap.get(e).player_id, tid: this.backupPlayerMap.get(e).team_id, backup: e };
                t.push(i);
            }
        }
        let e = { match_id: this._match_id, team_id: this._team_id, members: ToolUtils.toJsonString(t) }, i = HttpRequest.Yes11_UpdateBackUpTeam;
        Utils.shared().showLoading(10, true, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
        }), ToolUtils.getIsNormalDirection());
        HttpManager.shared().doGetCommonRequest(e, i, ((t, e, i) => {
            if (Utils.shared().hideLoading(), 200 != i) {
                Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.request_fail"), 2);
                ToolUtils.isObjValid(this.node) && (this._isSendMsg = false);
            }
            else {
                try {
                    let t = ToolUtils.parseJson(e);
                    0 == t.ret ? sys.isObjectValid(t.data) && ToolUtils.isObjValid(this.node) && (this._isSendMsg = false, Utils.shared().showToast(i18nMgr.shared().getValueByKey("yes11.suc_backup"), 2), PushCenter.shared().pushEvent(PushEvent.RefreshYes11TeamList), sys.isObjectValid(this._call) && this._call(this._team_id), this.onBackView()) : sys.isObjectValid(t.desc) && t.desc.length > 0 && Utils.shared().showToast(t.desc, 2);
                }
                catch (t) {
                }
            }
        }));
    }
    updateTargetPlayerViewStatus(t, e) {
        if (this.playerViewMap.has(e)) {
            let i = this.playerViewMap.get(e);
            if (ToolUtils.isObjValid(i)) {
                i.getChildByName("bg").getComponent(Sprite).color = color(255, 255, 255);
                for (let e = 0; e < 4; e++) {
                    let s = i.getChildByName("backup" + (e + 1));
                    s.getChildByName("ico").getComponent(Sprite).spriteFrame = this.operateImgs[0];
                    s.getChildByName("role").getComponent(Label).color = color(102, 102, 102);
                    t > 0 && t == e + 1 && (i.getChildByName("bg").getComponent(Sprite).color = color(255, 247, 224), s.getChildByName("ico").getComponent(Sprite).spriteFrame = this.operateImgs[1], s.getChildByName("role").getComponent(Label).color = color(255, 255, 255));
                }
            }
        }
    }
    onCloseButtonClick(t, e) {
        if (SoundManager.shared().playFx("click"), "back_btn" == e) {
            if (this._closed) {
                return;
            }
            this.onBackView();
        }
    }
    initView() {
        if (this.fitScreen(), this.updateTopContestDetails(), sys.isObjectValid(this._source)) {
            this.rootNode.getChildByName("top_node").getChildByName("title").getComponent(Label).string = this._source.teama.short_name + " vs " + this._source.teamb.short_name;
            this.topNode.getChildByName("time_state").active = false;
            let t = this.rootNode.getChildByName("top_node").getChildByName("lefttime");
            sys.isObjectValid(this._source.status) && (this._match_state = this._source.status);
            let e = this.topNode.getChildByName("daybg"), i = this.topNode.getChildByName("hourbg"), s = this.topNode.getChildByName("minbg"), a = Utils.shared().parseTimeCount(this._source.time_left);
            e.getChildByName("time").getComponent(Label).string = a[0] > 9 ? String(a[0]) : "0" + String(a[0]);
            i.getChildByName("time").getComponent(Label).string = a[1] > 9 ? String(a[1]) : "0" + String(a[1]);
            s.getChildByName("time").getComponent(Label).string = a[2] > 9 ? String(a[2]) : "0" + String(a[2]);
            0 == this._source.time_left && 1 == this._source.status ? (t.getComponent(Label).string = this._source.start_day, sys.isObjectValid(this._source.is_current_day) && 1 == Number(this._source.is_current_day) && (this._source.status = 3, t.getComponent(Label).string = "Live", this.topNode.getChildByName("time_state").active = true, this.topNode.getChildByName("time_state").getComponent(Label).string = "Live", e.active = false, i.active = false, s.active = false)) : 1 == this._source.status ? TweenTool.myschedule(t, 1, (() => {
                if (ToolUtils.isObjValid(this.node)) {
                    if (this._source.time_left > 0) {
                        this._source.time_left = this._source.time_left - 1;
                        let t = Utils.shared().parseTimeCount(this._source.time_left);
                        e.getChildByName("time").getComponent(Label).string = t[0] > 9 ? String(t[0]) : "0" + String(t[0]);
                        i.getChildByName("time").getComponent(Label).string = t[1] > 9 ? String(t[1]) : "0" + String(t[1]);
                        s.getChildByName("time").getComponent(Label).string = t[2] > 9 ? String(t[2]) : "0" + String(t[2]);
                    }
                    else {
                        this._source.status = 3;
                        t.getComponent(Label).string = "Live";
                        TweenTool.stopNodeAction(t);
                        this.topNode.getChildByName("time_state").active = true;
                        this.topNode.getChildByName("time_state").getComponent(Label).string = "Live";
                        e.active = false;
                        i.active = false;
                        s.active = false;
                    }
                }
            })) : 3 == this._source.status ? (TweenTool.stopNodeAction(t), t.getComponent(Label).string = "Live", this.topNode.getChildByName("time_state").active = true, this.topNode.getChildByName("time_state").getComponent(Label).string = "Live", e.active = false, i.active = false, s.active = false) : 4 == this._source.status && (TweenTool.stopNodeAction(t), t.getComponent(Label).string = "Cancel", this.topNode.getChildByName("time_state").active = true, this.topNode.getChildByName("time_state").getComponent(Label).string = "Cancel", e.active = false, i.active = false, s.active = false);
            PushCenter.shared().addListener(PushEvent.UpdateYes11CurMatchLeftTime, (e => {
                try {
                    ToolUtils.isObjValid(this.node) && e.match_id == this._match_id && (this._source.time_left = e.time_left, this._source.is_current_day = e.is_current_day, this._match_state = e.status, 3 == e.status ? (TweenTool.stopNodeAction(t), t.getComponent(Label).string = "Live") : 4 == e.status && (TweenTool.stopNodeAction(t), t.getComponent(Label).string = "Cancel"));
                }
                catch (t) {
                    TLog.printError(this.TAG, PushEvent.UpdateYes11CurMatchLeftTime, t);
                }
            }), this);
        }
    }
    onButtonClick(t, e) {
        SoundManager.shared().playFx("click");
        sys.now() - this._lastClick < 500 || (this._lastClick = sys.now(), 3 != this._match_state ? 4 != this._match_state ? "save" == e ? 0 != this._hasChooseBackUp ? this.dealCreateLogic() : Utils.shared().showToast(i18nMgr.shared().getValueByKey("yes11.backup_tip2"), 3, 0, ToolUtils.getIsNormalDirection()) : "team_sort" == e ? (0 != this._curSortType ? this._curSortType = 0 : 0 == this._teamSortType ? this._teamSortType = 1 : this._teamSortType = 0, this.reSortPlayerInfo(), this.updatePlayerViewAfterSort(), this.updateBackUpInBoard(), this.updateNextButtonStatus()) : "pts_sort" == e ? (1 != this._curSortType ? this._curSortType = 1 : 0 == this._pointsSortType ? this._pointsSortType = 1 : this._pointsSortType = 0, this.reSortPlayerInfo(), this.updatePlayerViewAfterSort(), this.updateBackUpInBoard(), this.updateNextButtonStatus()) : "sel_sort" == e ? (2 != this._curSortType ? this._curSortType = 2 : 0 == this._rateSortType ? this._rateSortType = 1 : this._rateSortType = 0, this.reSortPlayerInfo(), this.updatePlayerViewAfterSort(), this.updateBackUpInBoard(), this.updateNextButtonStatus()) : "preview" == e ? this.dealPreviewLogic() : "add_chip" == e && (Utils.shared().showStoreView(null, null), User.shared().updatePayScene(PhpReportDefined.pay_scene.hall_cricket)) : Utils.shared().showToast(i18nMgr.shared().getValueByKey("yes11.cancel_tip"), 2) : Utils.shared().showToast(i18nMgr.shared().getValueByKey("yes11.live_tip"), 2));
    }
    dealPreviewLogic() {
        let t = [];
        for (let e = 0; e < 4; e++) {
            this.backupPlayerMap.has(e + 1) && ToolUtils.isObjValid(this.backupPlayerMap.get(e + 1).player_id) && t.push(this.backupPlayerMap.get(e + 1));
        }
        SportCricket_Manager.shared().dealCominePreviewLogic(this._player_source, this.node, t);
    }
    onBackView(t = true) {
        t && (Utils.shared().hideLoading(), this.bShowPushAnim ? (this._closed = true, ToolUtils.isObjValid(this._lastNode) && (this._lastNode.active = true), ToolUtils.showPushAnim(this.node, 1, (() => {
            ToolUtils.isObjValid(this.node) && this.node.destroy();
        }))) : (ToolUtils.isObjValid(this._lastNode) && (this._lastNode.active = true), ToolUtils.isObjValid(this.node) && this.node.destroy()));
    }
    fitScreen() {
        ToolUtils.adaptSafeArea(this.rootNode);
        let t = sys.getSafeAreaRect().y, e = view.getVisibleSize();
        if (this.node.getComponent(UITransform).setContentSize(e.width, e.height), 0 != t) {
            let e = this.rootNode.getChildByName("all_ScrollView").getComponent(Widget).bottom;
            this.rootNode.getChildByName("all_ScrollView").getComponent(Widget).bottom = e - t;
            e = this.rootNode.getChildByName("bottom_node").getComponent(Widget).bottom;
            this.rootNode.getChildByName("bottom_node").getComponent(Widget).bottom = e - t;
        }
    }
}
