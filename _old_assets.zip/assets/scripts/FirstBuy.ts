// @ts-nocheck
// Recovered from index.js:125
import { _decorator, Label, Node, sp, sys, UIOpacity, v3, Vec3 } from "cc";
import PushCenter from "./PushCenter";
import Utils from "./Utils";
import PushEvent from "./PushEvent";
import SoundManager from "./SoundManager";
import BaseLayer from "./BaseLayer";
import { TransferPlatform } from "./TransferPlatform";
import TweenTool from "./TweenTool";
import { ToolUtils } from "./ToolUtils";
import User from "./User";
const { ccclass, property } = _decorator;
@ccclass("FirstBuy")
export class FirstBuy extends BaseLayer {
    @property(Node)
    public rootNode: Node = null;
    @property(Node)
    public maskNode: Node = null;
    @property(Label)
    public flagLabel: Label = null;
    @property(Label)
    public timeLabel: Label = null;
    @property(Label)
    public percentLabel: Label = null;
    public isNext: boolean = false;
    public isBackKey: boolean = true;
    public lastPayTime: number = 0;
    public isEnterStore: boolean = false;
    public isquick: boolean = false;
    public _nVid: number = 0;
    public _bStartCountDown: boolean = false;
    public _nCountcd: any = -1;
    public _linkId: number = 0;
    public _reportScene: any = -1;
    public _bCanSend: boolean = false;
    public _pop_souce: number = 0;
    public _has_close: boolean = false;
    public _firstrechargeData: any = null;
    public TAG: string = "FirstRecharge";
    public checkKyc: number = 0;
    public _flag: number = 0;
    public _mPara: any = null;
    initParaData(t, e = 0) {
        sys.isObjectValid(t) && (this._mPara = t, this.isNext = t.isNext, sys.isObjectValid(t.vid) ? this._nVid = t.vid : this._nVid = ToolUtils.curRoomId, sys.isObjectValid(t.isquick) && (this.isquick = t.isquick), sys.isObjectValid(t.flag) && (this._flag = t.flag), sys.isObjectValid(t.pop_souce) && (this._pop_souce = t.pop_souce), sys.isObjectValid(t.reportScene) && (this._reportScene = t.reportScene), sys.isObjectValid(t.link_id) && t.link_id > 0 && (this._linkId = t.link_id), sys.isObjectValid(t.ext) && (this._firstrechargeData = t.ext));
    }
    start() {
        if (super.start(), this._linkId = this._linkId > 0 ? this._linkId : sys.now(), this._reportScene = this._reportScene >= 0 ? this._reportScene : ToolUtils.getIsInRoom() ? 2 : 1, 1 == User.shared().first_recharge_type) {
            sys.isObjectValid(this._firstrechargeData) && (sys.isObjectValid(this._firstrechargeData.ratio) && (this.percentLabel.string = this._firstrechargeData.ratio), sys.isObjectValid(this._firstrechargeData.max) && (this.flagLabel.string = `UP TO ₹${this._firstrechargeData.max}*`));
            let t = 1;
            this.startShowAnim2(this.rootNode, t);
        }
        else {
            let t = this.rootNode.getChildByName("anim").getComponent(sp.Skeleton);
            t.clearTracks();
            t.setToSetupPose();
            t.setAnimation(0, "animation", false);
            ToolUtils.getIsInRoom() && (this.rootNode.setPosition(v3(0, 10, 0)), this.rootNode.setScale(v3(0.72, 0.72, 1)), this.rootNode.getChildByName("btn_close").setPosition(v3(345.594, 423.492, 0)));
            this.refreshView();
            let e, i = 0.12;
            e = 0;
            for (let t = 0; t < 4; t++) {
                let s = this.rootNode.getChildByName("item" + t);
                if (ToolUtils.isObjValid(s) && s.active) {
                    let t = new Vec3;
                    TweenTool.stopNodeAction(s);
                    s.getPosition(t);
                    s.getComponent(UIOpacity).opacity = 0;
                    s.setPosition(v3(t.x, t.y - 80));
                    let r = TweenTool.moveToByFade(s, 0.1, t, 0, 1, false), a = TweenTool.delayAct(s, null, e, false);
                    TweenTool.sequence(s, true, null, a, r);
                    e += i;
                }
                else {
                    s.getComponent(UIOpacity).opacity = 255;
                }
            }
        }
        ToolUtils.showFullScreen(this.maskNode);
        SoundManager.shared().playFx("act_popshow");
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().pushEvent(PushEvent.ShowGameOverBg);
        PushCenter.shared().removeListenersByTag(this);
        TweenTool.stopNodeAction(this.node);
        this.unscheduleAllCallbacks();
    }
    onEnable() {
        TransferPlatform.shared().setNormalFrameRate();
    }
    refreshView() {
        if (sys.isObjectValid(this._firstrechargeData)) {
            if (sys.isObjectValid(this._firstrechargeData.sub_title) && (this.flagLabel.string = this._firstrechargeData.sub_title), sys.isObjectValid(this._firstrechargeData.good_list) && Array.isArray(this._firstrechargeData.good_list)) {
                for (let t = 0; t < this._firstrechargeData.good_list.length; t++) {
                    let e = this.rootNode.getChildByName("item" + t);
                    if (ToolUtils.isObjValid(e)) {
                        let i = this._firstrechargeData.good_list[t];
                        sys.isObjectValid(i.cash) && (e.getChildByName("cash").getComponent(Label).string = `₹${i.cash}`);
                        sys.isObjectValid(i.bonus) && (e.getChildByName("bonus").getComponent(Label).string = `₹${i.bonus}`);
                        sys.isObjectValid(i.price) && (e.getChildByName("pay_btn").getChildByName("wz").getComponent(Label).string = `₹${i.price}`);
                        sys.isObjectValid(i.ratio) && (e.getChildByName("percent").getComponent(Label).string = `+${i.ratio}`);
                    }
                }
            }
            sys.isObjectValid(this._firstrechargeData.time_left) && this.startLeftTime(Number(this._firstrechargeData.time_left));
        }
    }
    startLeftTime(t) {
        if (Number.isNaN(t) || t <= 0) {
            return User.shared().getHallInfo(), void (this.timeLabel.string = "");
        }
        this._bStartCountDown = true;
        this._nCountcd = t;
        this.timeLabel.string = Utils.shared().parseCountDown(this._nCountcd);
        TweenTool.commonSchedule(this.node, 1, this.scheduleCallBack.bind(this));
    }
    scheduleCallBack() {
        if (sys.isObjectValid(this._firstrechargeData) && this._firstrechargeData.time_left && this._bStartCountDown) {
            if (this._nCountcd -= 1, this._firstrechargeData.time_left = this._nCountcd, this._nCountcd < 0) {
                return this._firstrechargeData.time_left = -1, User.shared().getHallInfo(), void this.onBackView();
            }
            this.timeLabel.string = Utils.shared().parseCountDown(this._nCountcd);
        }
    }
    onPayClick(t, e) {
        SoundManager.shared().playFx("click");
        let i = Number(e);
        if (sys.isObjectValid(this._firstrechargeData) && sys.isObjectValid(this._firstrechargeData.good_list) && Array.isArray(this._firstrechargeData.good_list) && i >= 0 && i < this._firstrechargeData.good_list.length) {
            let t = { price: this._firstrechargeData.good_list[i].price, act_id: PushEvent.JUMP_TO_SCLB, link_id: this._linkId, coupon_id: this._firstrechargeData.coupon_id };
            User.shared().startPay(t);
        }
    }
    onButtonClick(t, e) {
        if (SoundManager.shared().playFx("click"), "close" == e) {
            if (1 == Utils.shared().checkPopRestartGift(this._mPara)) {
                return void this.onBackView();
            }
            this.onBackView();
        }
        else if ("toshop" == e && ToolUtils.isObjValid(this.node)) {
            this.isEnterStore = true;
            let t = 0;
            sys.isObjectValid(this._firstrechargeData.recommend_price) && (t = Number(this._firstrechargeData.recommend_price));
            Utils.shared().showStoreView({ link_id: this._linkId, coupon_id: this._firstrechargeData.coupon_id, recommend_price: t }, this.node);
        }
    }
    onBackView() {
        if (ToolUtils.isObjValid(this.node)) {
            if (this._has_close) {
                return;
            }
            this._has_close = true;
            let t = { alert_node: this.node, rootNode: this.rootNode, isNext: this.isNext, pop_type: PushEvent.JUMP_TO_SCLB, pop_souce: this._pop_souce };
            Utils.shared().closeActivityView(t);
        }
    }
}
