// @ts-nocheck
// Recovered from index.js:9
const t = window;
export const languages = {};
(t.languages || (t.languages = {}));
(t.languages.ur = languages);
