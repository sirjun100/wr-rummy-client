// @ts-nocheck
// Recovered from index.js:299
import { _decorator, instantiate, Label, Node, ScrollView, size, Sprite, SpriteAtlas, SpriteFrame, sys, UITransform, v3 } from "cc";
import Utils from "./Utils";
import SoundManager from "./SoundManager";
import BaseLayer from "./BaseLayer";
import i18nMgr from "./i18nMgr";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("MatchPrizesRank")
export class MatchPrizesRank extends BaseLayer {
    @property(ScrollView)
    public rankList: ScrollView = null;
    @property(Node)
    public rankMoban: Node = null;
    @property([SpriteFrame])
    public rankSpriteFrame: SpriteFrame[] = [];
    @property([SpriteFrame])
    public ticket_images: SpriteFrame[] = [];
    @property(SpriteAtlas)
    public rewardAtlas: SpriteAtlas = null;
    public rewardNames: any[] = ["reward_watch.png"];
    start() {
        super.start();
        let e = this.node.getChildByName("mask");
        ToolUtils.showFullScreen(e);
        this.rankMoban.active = false;
    }
    refreshUI(e) {
        let t = this.rankList.content;
        if (sys.isObjectValid(t) && Array.isArray(t.children) && t.children.length > 0 && t.removeAllChildren(), e && e.length > 0) {
            let i = 465;
            e.length > 6 && (i = 70 * e.length);
            t.getComponent(UITransform).contentSize = size(660, i);
            for (let i = 0, a = e.length; i < a; i++) {
                let a = e[i], n = instantiate(this.rankMoban);
                n.active = true;
                t.addChild(n);
                let r = n.getChildByName("prize"), l = n.getChildByName("prize_root");
                if (l && sys.isObjectValid(a.infos2) && Array(a.infos2) && a.infos2.length > 0) {
                    l.active = true;
                    r.active = false;
                    let e = l.getChildByName("layout0"), t = l.getChildByName("layout1"), i = l.getChildByName("layout2"), n = l.getChildByName("layout3"), s = e.getChildByName("gold").getComponent(Label), o = t.getChildByName("bonus").getComponent(Label), d = i.getChildByName("discount").getComponent(Label), u = i.getChildByName("ic").getComponent(Sprite);
                    e.active = false;
                    t.active = false;
                    i.active = false;
                    n.active = false;
                    for (let r = 0; r < a.infos2.length; r++) {
                        const l = a.infos2[r];
                        if (sys.isObjectValid(l)) {
                            if (sys.isObjectValid(l.type) && 2 == l.type) {
                                e.active = true;
                                sys.isObjectValid(l.value) && (s.string = "" + l.value);
                            }
                            else if (sys.isObjectValid(l.type) && 6 == l.type) {
                                t.active = true;
                                sys.isObjectValid(l.value) && (o.string = "" + l.value);
                            }
                            else if (sys.isObjectValid(l.type) && 11 == l.type) {
                                if (i.active = true, sys.isObjectValid(l.discount)) {
                                    0 != i18nMgr.shared().language && i18nMgr.shared().changeLabelFont(d);
                                    let e = ToolUtils.format(i18nMgr.shared().getValueByKey("ticket.off"), l.discount);
                                    sys.isObjectValid(l.value) && Number(l.value) >= 2 && (e = e + "*" + l.value);
                                    d.string = e;
                                    let t = Number(l.discount);
                                    u.spriteFrame = 100 == t ? this.ticket_images[1] : this.ticket_images[0];
                                }
                            }
                            else if (sys.isObjectValid(l.type) && 13 == l.type) {
                                n.active = true;
                                let e = n.getChildByName("ic"), t = n.getChildByName("desc"), i = ToolUtils.isSafeString(l.item_url), a = ToolUtils.getImageUrlPictureName(i);
                                ToolUtils.isSafeString(a).length > 0 && (a != this.rewardNames[0] ? (Utils.shared().setImage(e, "reward_unload", this.rewardAtlas), Utils.shared().updateNetImage(e, i, size(48.24, 48.24), (() => {
                                }))) : Utils.shared().setImage(e, "reward_watch", this.rewardAtlas));
                                sys.isObjectValid(l.item_name) && (i18nMgr.shared().changeLabelFont(t.getComponent(Label)), t.getComponent(Label).string = "" + l.item_name);
                            }
                        }
                    }
                }
                else {
                    r.active = true;
                    r.getComponent(Label).string = "--";
                    l.active = false;
                }
                let s = a.rank;
                a.desc && a.desc + "" && (s = a.desc);
                n.getChildByName("rank").getComponent(Label).string = s;
                n.getChildByName("line").active = i != e.length - 1;
                n.getChildByName("rank").active = true;
                n.getChildByName("rank_icon").active = false;
                i < 3 && (n.getChildByName("rank").active = false, n.getChildByName("rank_icon").active = true, n.getChildByName("rank_icon").getComponent(Sprite).spriteFrame = this.rankSpriteFrame[i]);
            }
        }
    }
    onButtonClick(e, t) {
        SoundManager.shared().playFx("click");
        "close" == t && ToolUtils.isObjValid(this.node) && this.node.destroy();
    }
    setLandscapeShow() {
        ToolUtils.getOrientation() || this.node.setRotationFromEuler(v3(0, 0, -90));
    }
    setTidKey(e) {
        this.bIsInGame = true;
        this.tid_key = e;
    }
}
