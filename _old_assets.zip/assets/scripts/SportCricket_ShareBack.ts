// @ts-nocheck
// Recovered from index.js:583
import { _decorator, color, Label, Node, size, Sprite, SpriteFrame, sys, UITransform, v3, view } from "cc";
import SoundManager from "./SoundManager";
import PushCenter from "./PushCenter";
import { TLog } from "./TLog";
import Utils from "./Utils";
import BaseLayer from "./BaseLayer";
import PushEvent from "./PushEvent";
import TweenTool from "./TweenTool";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("SportCricket_ShareBack")
export class SportCricket_ShareBack extends BaseLayer {
    public TAG: string = "SportCricket_ShareBack";
    @property(Node)
    public gotteam_rootNode: Node = null;
    @property(Node)
    public viewmatch_rootNode: Node = null;
    public rootNode: any = null;
    @property([SpriteFrame])
    public teamBgImgs: SpriteFrame[] = [];
    @property([SpriteFrame])
    public capBgImgs: SpriteFrame[] = [];
    @property([SpriteFrame])
    public operateImgs: SpriteFrame[] = [];
    public _closed: boolean = false;
    public bShowPushAnim: boolean = false;
    public _lastClick: number = 0;
    public _isSendMsg: boolean = false;
    public taskAwardIconMap: Map = new Map;
    public _match_id: number = 0;
    public _source: any = null;
    public _fromType: number = 0;
    public callFuc: any = null;
    public _startY: number = 0;
    public _closeAct: any = null;
    public _startAct: any = null;
    onLoad() {
        PushCenter.shared().addListener(PushEvent.commentDownloaderImg, (e => {
            try {
                if (ToolUtils.isObjValid(this.node) && this.taskAwardIconMap.size > 0) {
                    for (const [t, a] of this.taskAwardIconMap) {
                        a == e && (!sys.isObjectValid(t) || "team_icon1" != t.name && "team_icon0" != t.name || Utils.shared().updateNetImage(t, e, size(56, 56)));
                    }
                }
            }
            catch (e) {
                TLog.printError(this.TAG, PushEvent.commentDownloaderImg, e);
            }
        }), this);
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().removeListenersByTag(this);
        this.unscheduleAllCallbacks();
    }
    init(e) {
        sys.isObjectValid(e) && sys.isObjectValid(e.match_id) && (this._match_id = e.match_id);
        sys.isObjectValid(e) && sys.isObjectValid(e.fromType) && (this._fromType = e.fromType);
        sys.isObjectValid(e) && sys.isObjectValid(e.source) && (this._source = { ...e.source });
        sys.isObjectValid(e) && sys.isObjectValid(e.callFunc) && (this.callFuc = e.callFunc);
    }
    start() {
        super.start();
        this.initView();
        this.refreshView();
        this.showSelectView();
    }
    showSelectView() {
        let e = -view.getVisibleSize().height / 2;
        this._startY = e - 0 - 20;
        this.rootNode.setPosition(v3(0, this._startY));
        this._startAct = TweenTool.moveTo(this.rootNode, 0.2, v3(0, e), "sineIn", true);
    }
    hideSelectView() {
        this._startAct && TweenTool.stopAction(this._startAct);
        this._closeAct || (this._closeAct = TweenTool.moveTo(this.rootNode, 0.2, v3(0, this._startY), "sineIn", true, (() => {
            ToolUtils.isObjValid(this.node) && this.node.destroy();
        })));
    }
    refreshView() {
        this.updateContestDetails();
    }
    updateContestDetails() {
        if (!sys.isObjectValid(this._source)) {
            return;
        }
        if (1 == this._fromType) {
            return;
        }
        let e = this.rootNode.getChildByName("match_info"), t = this.rootNode.getChildByName("team_info");
        if (sys.isObjectValid(this._source.teama.logo_url) && this._source.teama.logo_url.length > 0 && (this.taskAwardIconMap.set(e.getChildByName("team_icon0"), this._source.teama.logo_url), Utils.shared().updateNetImage(e.getChildByName("team_icon0"), this._source.teama.logo_url, size(56, 56))), sys.isObjectValid(this._source.teamb.logo_url) && this._source.teamb.logo_url.length > 0 && (this.taskAwardIconMap.set(e.getChildByName("team_icon1"), this._source.teamb.logo_url), Utils.shared().updateNetImage(e.getChildByName("team_icon1"), this._source.teamb.logo_url, size(56, 56))), sys.isObjectValid(this._source.teama.short_name) && this._source.teama.short_name.length > 0 && (e.getChildByName("team_short_name0").getComponent(Label).string = this._source.teama.short_name, e.getChildByName("team_short_name0").getComponent(Label).updateRenderData(true)), sys.isObjectValid(this._source.teama.name) && this._source.teama.name.length > 0) {
            e.getChildByName("team_full_name0").getComponent(Label).string = this._source.teama.name;
            let t = e.getChildByName("team_short_name0").position, a = e.getChildByName("team_short_name0").getComponent(UITransform).contentSize.width;
            e.getChildByName("team_full_name0").getComponent(UITransform).contentSize = size(320 - a - 10, 40);
            e.getChildByName("team_full_name0").setPosition(v3(t.x + a + 10, t.y));
        }
        if (sys.isObjectValid(this._source.teamb.short_name) && this._source.teamb.short_name.length > 0 && (e.getChildByName("team_short_name1").getComponent(Label).string = this._source.teamb.short_name, e.getChildByName("team_short_name1").getComponent(Label).updateRenderData(true)), sys.isObjectValid(this._source.teamb.name) && this._source.teamb.name.length > 0) {
            e.getChildByName("team_full_name1").getComponent(Label).string = this._source.teamb.name;
            let t = e.getChildByName("team_short_name1").position, a = e.getChildByName("team_short_name1").getComponent(UITransform).contentSize.width;
            e.getChildByName("team_full_name1").getComponent(UITransform).contentSize = size(320 - a - 10, 40);
            e.getChildByName("team_full_name1").setPosition(v3(t.x + a + 10, t.y));
        }
        let a = 0, i = this._source.status;
        sys.isObjectValid(this._source.time_left) && (a = Number(this._source.time_left));
        let o = e.getChildByName("left_time");
        1 == i && (o.getComponent(Label).string = Utils.shared().parseCountDown(a), sys.isObjectValid(this._source.start_time) && this._source.start_time.length > 0 && (e.getChildByName("start_date").getComponent(Label).string = this._source.start_time), TweenTool.myschedule(o, 1, (() => {
            ToolUtils.isObjValid(this.node) && (this._source.time_left > 0 ? (this._source.time_left = this._source.time_left - 1, o.getComponent(Label).string = Utils.shared().parseCountDown(this._source.time_left)) : TweenTool.stopNodeAction(o));
        })));
        let s = this._source.team;
        if (!sys.isObjectValid(s)) {
            return;
        }
        let n = t.getChildByName("head_mask").getChildByName("head_img");
        if (s.avatar && s.avatar.length > 0 && Utils.shared().updateHeadImg(n, s.avatar, s.avatar_url, size(44, 44)), sys.isObjectValid(s.wk_num) && String(s.wk_num).length > 0 && (t.getChildByName("wk").getComponent(Label).string = "WK " + s.wk_num), sys.isObjectValid(s.bat_num) && String(s.bat_num).length > 0 && (t.getChildByName("bat").getComponent(Label).string = "BAT " + s.bat_num), sys.isObjectValid(s.ar_num) && String(s.ar_num).length > 0 && (t.getChildByName("ar").getComponent(Label).string = "AR " + s.ar_num), sys.isObjectValid(s.bowl_num) && String(s.bowl_num).length > 0 && (t.getChildByName("bowl").getComponent(Label).string = "BOWL " + s.bowl_num), sys.isObjectValid(s.teama_short_name) && String(s.teama_short_name).length > 0 && (t.getChildByName("team_name0").getComponent(Label).string = s.teama_short_name), sys.isObjectValid(s.teamb_short_name) && String(s.teamb_short_name).length > 0 && (t.getChildByName("team_name1").getComponent(Label).string = s.teamb_short_name), sys.isObjectValid(s.teama_num) && String(s.teama_num).length > 0 && (t.getChildByName("team_num0").getComponent(Label).string = s.teama_num), sys.isObjectValid(s.teamb_num) && String(s.teamb_num).length > 0 && (t.getChildByName("team_num1").getComponent(Label).string = s.teamb_num), sys.isObjectValid(s.members) && Array.isArray(s.members) && s.members.length > 0) {
            for (let e = 0; e < s.members.length; e++) {
                let a = s.members[e];
                1 == Number(a.captain_role) ? (t.getChildByName("cap_node0").getChildByName("wz").getComponent(Label).string = a.short_name, a.out_team_id == s.teama_id ? (t.getChildByName("cap_node0").getChildByName("bg").getComponent(Sprite).spriteFrame = this.capBgImgs[0], t.getChildByName("cap_node0").getChildByName("wz").getComponent(Label).color = color(255, 255, 255), t.getChildByName("cap_node0").getChildByName("flag").getChildByName("wz").getComponent(Label).color = color(255, 255, 255), t.getChildByName("cap_node0").getChildByName("flag").getComponent(Sprite).spriteFrame = this.operateImgs[0]) : (t.getChildByName("cap_node0").getChildByName("bg").getComponent(Sprite).spriteFrame = this.capBgImgs[1], t.getChildByName("cap_node0").getChildByName("wz").getComponent(Label).color = color(51, 51, 51), t.getChildByName("cap_node0").getChildByName("flag").getChildByName("wz").getComponent(Label).color = color(51, 51, 51), t.getChildByName("cap_node0").getChildByName("flag").getComponent(Sprite).spriteFrame = this.operateImgs[1]), sys.isObjectValid(a.thumb_url) && a.thumb_url.length > 0 && (this.taskAwardIconMap.set(t.getChildByName("cap_node0").getChildByName("player_icon"), a.thumb_url), Utils.shared().updateNetImage(t.getChildByName("cap_node0").getChildByName("player_icon"), a.thumb_url, size(88, 88)))) : 2 == Number(a.captain_role) && (t.getChildByName("cap_node1").getChildByName("wz").getComponent(Label).string = a.short_name, a.out_team_id == s.teama_id ? (t.getChildByName("cap_node1").getChildByName("bg").getComponent(Sprite).spriteFrame = this.capBgImgs[0], t.getChildByName("cap_node1").getChildByName("wz").getComponent(Label).color = color(255, 255, 255), t.getChildByName("cap_node1").getChildByName("flag").getChildByName("wz").getComponent(Label).color = color(255, 255, 255), t.getChildByName("cap_node1").getChildByName("flag").getComponent(Sprite).spriteFrame = this.operateImgs[0]) : (t.getChildByName("cap_node1").getChildByName("bg").getComponent(Sprite).spriteFrame = this.capBgImgs[1], t.getChildByName("cap_node1").getChildByName("wz").getComponent(Label).color = color(51, 51, 51), t.getChildByName("cap_node1").getChildByName("flag").getChildByName("wz").getComponent(Label).color = color(51, 51, 51), t.getChildByName("cap_node1").getChildByName("flag").getComponent(Sprite).spriteFrame = this.operateImgs[1]), sys.isObjectValid(a.thumb_url) && a.thumb_url.length > 0 && (this.taskAwardIconMap.set(t.getChildByName("cap_node1").getChildByName("player_icon"), a.thumb_url), Utils.shared().updateNetImage(t.getChildByName("cap_node1").getChildByName("player_icon"), a.thumb_url, size(88, 88))));
            }
        }
    }
    onCloseButtonClick(e, t) {
        SoundManager.shared().playFx("click");
        sys.now() - this._lastClick < 500 || (this._lastClick = sys.now(), this.onBackView());
    }
    initView() {
        this.gotteam_rootNode.active = 0 == this._fromType;
        this.viewmatch_rootNode.active = 1 == this._fromType;
        0 == this._fromType ? this.rootNode = this.gotteam_rootNode : this.rootNode = this.viewmatch_rootNode;
        this.fitScreen();
    }
    onButtonClick(e, t) {
        SoundManager.shared().playFx("click");
        sys.now() - this._lastClick < 500 || (this._lastClick = sys.now(), ("pick" == t || "skviewip" == t) && this.onBackView(true));
    }
    onBackView(e = true) {
        e && (Utils.shared().hideLoading(), this.hideSelectView());
    }
    fitScreen() {
        ToolUtils.adaptSafeArea(this.gotteam_rootNode);
        ToolUtils.adaptSafeArea(this.viewmatch_rootNode);
        sys.getSafeAreaRect().y;
    }
}
