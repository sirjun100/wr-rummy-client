// @ts-nocheck
// Recovered from index.js:439
import { _decorator, Button, color, Color, game, instantiate, Label, Layout, Node, NodePool, Prefab, rect, size, sp, Sprite, SpriteAtlas, SpriteFrame, sys, tween, UIOpacity, UITransform, v2, v3, Vec3 } from "cc";
import Utils from "./Utils";
import User from "./User";
import RummyDataManager, { RUMMY_CARD_GROUP_TYPE } from "./RummyDataManager";
import TweenTool from "./TweenTool";
import RummyCard from "./RummyCard";
import { TLog } from "./TLog";
import RummyCardConstant, { isMeldedGroup, setHandRatingStarSprite } from "./RummyCardConstant";
import PushCenter from "./PushCenter";
import PushEvent from "./PushEvent";
import { TransferPlatform } from "./TransferPlatform";
import i18nMgr from "./i18nMgr";
import GameConfig from "./GameConfig";
import SoundManager from "./SoundManager";
import Parent, { AdapDirection } from "./Parent";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("RummyGameCards")
export default class RummyGameCards extends Parent {
    @property(Node)
    public shoupaiLayout: Node = null;
    @property(Node)
    public testShoupaiLayout: Node = null;
    @property(Node)
    public zhezhaoView: Node = null;
    @property(Prefab)
    public cardPrefab: Prefab = null;
    @property([SpriteFrame])
    public card_kuang_anim: SpriteFrame[] = [];
    @property([Node])
    public arrow_anim_nodes: Node[] = [];
    @property(sp.Skeleton)
    public hc_anim: any = null;
    @property(sp.Skeleton)
    public mopai_tip_anim: any = null;
    public _mopaiTipAnimUpdated: boolean = false;
    @property(Node)
    public paidui_node: Node = null;
    @property(Node)
    public qipai_node: Node = null;
    @property(Node)
    public hupai_node: Node = null;
    @property(Node)
    public xipai_anim_node: Node = null;
    @property(Node)
    public cardValueNode: Node = null;
    @property(Node)
    public pickCardNode: Node = null;
    @property([SpriteAtlas])
    public discardLineAtlas: SpriteAtlas[] = [];
    @property([Color])
    public discardLine_color: Color[] = [];
    @property([SpriteFrame])
    public cardStarIco: SpriteFrame[] = [];
    @property([sp.SkeletonData])
    public hcAnimData: sp.SkeletonData[] = [];
    @property(Node)
    public fade_node: Node = null;
    @property([SpriteFrame])
    public availableSpites: SpriteFrame[] = [];
    @property(Node)
    public autoSortAnimNode: Node = null;
    @property(Node)
    public sortCardAnimMoban: Node = null;
    public sortCardAnimVec: any[] = [];
    public seatPosVec: any[] = [];
    public cardViewVec: any[] = [];
    public groupFlags: any[] = [];
    public otherGroupFlags: any[] = [];
    public cardValueVec: any[] = [];
    public paiduiCardVec: any[] = [];
    public hupaiCardVec: any[] = [];
    public myGroupcardValueVec: any[] = [];
    public qipaiCards: any[] = [];
    public spXpositionDeq: any[] = [];
    public add_btnArray: any[] = [];
    public availableFlagNodes: any[] = [];
    public availabeFlagInfos: any[] = [];
    public cardScale: any = undefined;
    public cardWidth: any = undefined;
    public cardHeight: any = undefined;
    public otherCardWidth: any = undefined;
    public mpScale: any = undefined;
    public otherCardScale: any = undefined;
    public outcardScale: any = undefined;
    public allPaiNum: any = undefined;
    public hasFaPaiAnimEnded: any = undefined;
    public hasClickCardArea: any = undefined;
    public qipaiPoint: any = undefined;
    public paiduiPoint: any = undefined;
    public finishPoint: any = undefined;
    public beginPos: any = undefined;
    public laiziPoint: any = undefined;
    public syoffset: any = undefined;
    public callback: any = undefined;
    public selectedPosY: any = undefined;
    public unSelectedPosY: any = undefined;
    public moveCard: any = undefined;
    public fadeCard: any = undefined;
    public cardsPostions: any[] = [];
    public lastOffsetX: any = undefined;
    public lzCard: any = undefined;
    public isMove: boolean = false;
    public lastSelectedCardIndex: any = -1;
    public lastZorder: any = undefined;
    public lastPosX: any = undefined;
    public lastPoint: any = undefined;
    public lastTouchPoint: any = undefined;
    public outScreenTouchPoint: any = undefined;
    public moveValue: any = undefined;
    public isChange: any = undefined;
    public mopaiPos: any = undefined;
    public mpType: any = undefined;
    public qipaiValue: any = undefined;
    public hasQipai: any = undefined;
    public _offSetX: number = 0;
    public _screenSize: any = undefined;
    public _diffY: any = undefined;
    public _lastMovePos: any = undefined;
    public arrowAnimArray: any[] = [];
    public middlePosY: number = 0;
    public touchCardWidth: number = 0;
    public touchCardHight: number = 0;
    public cardStartPosX: number = 0;
    public cardSpaceGroup: number = 0;
    public drawCallFun: any = null;
    public drawCards: any[] = [];
    public tid_key: string = "";
    public is_fapai_over: boolean = false;
    public otherCardsVec: any[] = [];
    public seeverOpenCards: any[] = [];
    public cardsViewPool: any = null;
    public _groupFlagsPool: any = null;
    public availableFlagsPool: any = null;
    public touchCardMove: boolean = false;
    public touchCardMoveReduction: boolean = false;
    public touchCardDirection: number = 0;
    public delay_node: any = null;
    public is_shuffle: boolean = false;
    public initialCardNodes: any[] = [];
    public clickDelayAct: any = null;
    public last3CardsVec: any[] = [];
    public bShowLast3Cards: boolean = false;
    public cardTipsAct: any = null;
    public tipCardMsg: any = null;
    public _cardValuePos: Vec3 = new Vec3;
    public _nHandCardValue: any = -1;
    public _nHandCardStar: any = -1;
    public _nHandCardColor: any = -1;
    public _with_open: number = 0;
    public handCardDataAnalysis: any = null;
    public tingpaiCallback: any = undefined;
    public _localPickAnimEnd: boolean = true;
    private _openPileSync: any = null;
    onLoad() {
        this.delay_node = new Node;
        RummyDataManager.shared().actionNode.addChild(this.delay_node);
        this.cardScale = RummyCardConstant.CardScale;
        this.cardWidth = RummyCardConstant.CardWidth;
        this.cardHeight = RummyCardConstant.CardHeight;
        this.touchCardWidth = this.cardWidth;
        this.touchCardHight = this.cardHeight;
        this.cardStartPosX = RummyCardConstant.CardStartPosX;
        this.cardSpaceGroup = RummyCardConstant.CardSpaceGroup;
        this.mpScale = RummyCardConstant.mpScale;
        this.outcardScale = RummyCardConstant.OutcardScale;
        this.otherCardScale = RummyCardConstant.OtherCardScale;
        this.otherCardWidth = RummyCardConstant.OtherCardWidth;
        this.allPaiNum = RummyCardConstant.allPaiNum;
        this.middlePosY = RummyCardConstant.middlePosY;
        this.hasFaPaiAnimEnded = false;
        this.hasClickCardArea = false;
        let i = ToolUtils.getRealViewSize();
        this.cardsViewPool = new NodePool("RummyGameCard");
        this._groupFlagsPool = new NodePool("GroupFlags");
        this.availableFlagsPool = new NodePool("AvailableFlags");
        this.zhezhaoView && this.zhezhaoView.setSiblingIndex(0);
        let e, t = i.height + 200, a = i.width + 200;
        this.shoupaiLayout.getComponent(UITransform).setContentSize(size(t, a));
        this.testShoupaiLayout.getComponent(UITransform).setContentSize(size(t, a));
        this.qipaiPoint = RummyCardConstant.qipaiPoint;
        this.paiduiPoint = RummyCardConstant.paiduiPoint;
        this.finishPoint = RummyCardConstant.finishPoint;
        this.beginPos = RummyCardConstant.beginPos;
        this.laiziPoint = RummyCardConstant.laiziPoint;
        ToolUtils.isObjValid(this.cardValueNode) && this.cardValueNode.getPosition(this._cardValuePos);
        for (let i = 0; i < 6; i++) {
            e = "grop_flag" + i;
            let t = this.node.getChildByName(e);
            ToolUtils.isObjValid(t) || (t = instantiate(this.node.getChildByName("grop_flag")), t.name = e, t.parent = this.node.getChildByName("grop_flag").getParent());
        }
        if (ToolUtils.isPadPlatform()) {
            let i, e = (GameConfig.REAL_SCREEN_WIDTH - 720) / 4;
            RummyCardConstant.GroupFlagPosY = -240 - e;
            this._cardValuePos.y = this._cardValuePos.y - e;
            this.middlePosY = this.middlePosY - e;
            this.resetUiPos(this.zhezhaoView, AdapDirection.Down, true, 0.5, false);
            this.resetUiPos(this.cardValueNode, AdapDirection.Down, true, 0.5, false);
            this.node.getChildByName("grop_flag") && this.resetUiPos(this.cardValueNode, AdapDirection.Down, true, 0.5, false);
            for (let e = 0; e < 6; e++) {
                i = "grop_flag" + e;
                let t = this.node.getChildByName(i);
                t && this.resetUiPos(t, AdapDirection.Down, true, 0.5, false);
            }
        }
        this.add_btnArray = [];
        this._diffY = 0;
        this.cardViewVec = [];
        this.groupFlags = [];
        this.otherGroupFlags = [];
        this.cardValueVec = [];
        this.paiduiCardVec = [];
        this.hupaiCardVec = [];
        this.myGroupcardValueVec = [];
        this.qipaiCards = [];
        this.spXpositionDeq = [];
        this._diffY = ToolUtils.getFitBottomHeightDiff();
        this.showDropCardsZheZhao(false);
        this.initPushCenter();
    }
    onEnable() {
        this.shoupaiLayout.on(Node.EventType.TOUCH_START, this.onTouchBegan, this);
        this.shoupaiLayout.on(Node.EventType.TOUCH_MOVE, this.onTouchMoved, this);
        this.shoupaiLayout.on(Node.EventType.TOUCH_END, this.onTouchEnded, this);
        this.shoupaiLayout.on(Node.EventType.TOUCH_CANCEL, this.onTouchCancel, this);
    }
    onDisable() {
        this.cancelOpenPileSync();
        this.shoupaiLayout.off(Node.EventType.TOUCH_START, this.onTouchBegan, this);
        this.shoupaiLayout.off(Node.EventType.TOUCH_MOVE, this.onTouchMoved, this);
        this.shoupaiLayout.off(Node.EventType.TOUCH_END, this.onTouchEnded, this);
        this.shoupaiLayout.off(Node.EventType.TOUCH_CANCEL, this.onTouchCancel, this);
    }
    onDestroy() {
        this.cancelOpenPileSync();
        super.onDestroy();
        PushCenter.shared().removeListenersByTag(this);
        this.unscheduleAllCallbacks();
        for (let i = 0, e = this.qipaiCards.length; i < e; i++) {
            ToolUtils.isObjValid(this.qipaiCards[i]) && TweenTool.stopNodeAction(this.qipaiCards[i]);
        }
        for (let i = 0, e = this.paiduiCardVec.length; i < e; i++) {
            ToolUtils.isObjValid(this.paiduiCardVec[i]) && TweenTool.stopNodeAction(this.paiduiCardVec[i]);
        }
        TweenTool.stopNodeAction(this.delay_node);
        this.cardsViewPool.clear();
        this._groupFlagsPool.clear();
        this.availableFlagsPool.clear();
        this.delay_node.destroy();
    }
    setCallBack(i) {
        this.callback = i;
    }
    setTingPaiCallBack(i) {
        this.tingpaiCallback = i;
    }
    onDropReset() {
        this.resetMyShouPai();
        this.playArrowAnim(RummyCardConstant.arrowAnimType.mopai, false);
        this.playArrowAnim(RummyCardConstant.arrowAnimType.finish, false);
        this.playArrowAnim(RummyCardConstant.arrowAnimType.qipai, false);
        this.showMoPaiTisAnim(false, false);
        this.showFinishTisiAnim(false);
        this.hideCardTipsGlow();
        this.showPickCardTips(false);
        this.hideSortCardAnim();
        this._localPickAnimEnd = true;
    }
    changeCardPlayOutLineStatus(i) {
        let e = this.node.getChildByName("discard_line");
        ToolUtils.isObjValid(e) && (e.active = i);
    }
    preInintCardPool() {
        try {
            if (this.cardsViewPool) {
                let i = 0;
                for (let e = this.cardsViewPool.size(); e < RummyCardConstant.preInitCardNum; e++) {
                    TweenTool.delayAct(this.delay_node, (() => {
                        if (this.cardsViewPool.size() < RummyCardConstant.preInitCardNum) {
                            let i = instantiate(this.cardPrefab);
                            i.active = false;
                            null === i.getComponent("RummyCard") || i.getComponent("RummyCard");
                            i.getComponent(RummyCard).resetCards();
                            this.cardsViewPool.put(i);
                        }
                    }), game.frameTime / 1000 * 5 * i, true);
                    i += 1;
                }
            }
        }
        catch (i) {
            TLog.printError("trycatch preInintCardPool,error:", i);
        }
    }
    checkIsMatchRoom() {
        let i = ToolUtils.deskInfos.get(User.shared().curTid_key), e = false;
        i && 4 == i.mode && 3 != i.match_mode && (e = true);
        let t = RummyDataManager.shared().rummyInfos.get(User.shared().curTid_key);
        return sys.isObjectValid(t) && 4 == t.gameRummyType && 3 != t.gameMatchMode && (e = true), e;
    }
    refreshdisCardLineBg() {
        let i = this.node.getChildByName("discard_line");
        if (ToolUtils.isObjValid(i)) {
            let e = this.checkIsMatchRoom() ? 5 : 0;
            Utils.shared().setImage(i, "rummy_dz_fold_card_line", this.discardLineAtlas[e]);
            i.getComponent(Sprite).color = 5 == e ? new Color(0, 255, 156, 255) : new Color(255, 255, 255, 255);
            i.getChildByName("wz").getComponent(Label).color = this.discardLine_color[e];
        }
    }
    refreshArrowAnim() {
        if (this.arrow_anim_nodes[4].active) {
            this.arrow_anim_nodes[0].active = false;
            this.mopai_tip_anim.clearTracks();
            this.mopai_tip_anim.setToSetupPose();
            this.mopai_tip_anim.setAnimation(0, "txdh", true);
        }
        else {
            let i = "kuang_yellow";
            for (let e = 0; e <= 3; e++) {
                this.arrow_anim_nodes[e].active && (this.arrow_anim_nodes[e].getComponent(sp.Skeleton).clearTracks(), this.arrow_anim_nodes[e].getComponent(sp.Skeleton).setToSetupPose(), 1 != e && 3 != e || (i = "kuang_green", RummyDataManager.shared().rummyInfos.has(this.tid_key) && 1 == RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyMode && (i = "kuang_green_wjt")), this.arrow_anim_nodes[e].getComponent(sp.Skeleton).setAnimation(0, i, true));
            }
        }
    }
    resetView(i = true) {
        this.cancelOpenPileSync();
        let e;
        this.is_fapai_over = false;
        for (let i = 0, t = this.cardViewVec.length; i < t; i++) {
            e = this.cardViewVec[i];
            ToolUtils.isObjValid(e) && this.putCardNode(e);
        }
        for (let i = 0, t = this.initialCardNodes.length; i < t; i++) {
            e = this.initialCardNodes[i];
            ToolUtils.isObjValid(e) && this.putCardNode(e);
        }
        for (let i = 0, e = this.groupFlags.length; i < e; i++) {
            ToolUtils.isObjValid(this.groupFlags[i]) && this.groupFlags[i].destroy();
        }
        for (let i = 0, e = this.qipaiCards.length; i < e; i++) {
            ToolUtils.isObjValid(this.qipaiCards[i]) && this.putCardNode(this.qipaiCards[i]);
        }
        for (let i = 0, e = this.paiduiCardVec.length; i < e; i++) {
            ToolUtils.isObjValid(this.paiduiCardVec[i]) && this.putCardNode(this.paiduiCardVec[i]);
        }
        for (let i = 0, e = this.hupaiCardVec.length; i < e; i++) {
            ToolUtils.isObjValid(this.hupaiCardVec[i]) && this.putCardNode(this.hupaiCardVec[i]);
        }
        for (let i = 0; i < 6; i++) {
            this.hideRobotPlayerCards(i);
        }
        for (let i = 0, e = this.availableFlagNodes.length; i < e; i++) {
            ToolUtils.isObjValid(this.availableFlagNodes[i]) && this.putAvailableFlagNode(this.availableFlagNodes[i]);
        }
        this.availableFlagNodes = [];
        this.availabeFlagInfos = [];
        this.clearTemeMoveCardData();
        RummyDataManager.shared().stopTweenAction(this.cardTipsAct);
        TweenTool.stopNodeAction(this.paidui_node);
        TweenTool.stopNodeAction(this.delay_node);
        TweenTool.stopNodeAction(this.hupai_node);
        this.seeverOpenCards = [];
        this.initialCardNodes = [];
        this.paiduiCardVec = [];
        this.myGroupcardValueVec = [];
        this.cardViewVec = [];
        this.cardValueVec = [];
        this.qipaiCards = [];
        this.groupFlags = [];
        this.spXpositionDeq = [];
        this.add_btnArray = [];
        this.shoupaiLayout.removeAllChildren();
        this.testShoupaiLayout.removeAllChildren();
        this.paidui_node.removeAllChildren();
        this.qipai_node.removeAllChildren();
        this.hupai_node.removeAllChildren();
        this.fade_node.removeAllChildren();
        this.hasFaPaiAnimEnded = false;
        this.hasClickCardArea = false;
        RummyDataManager.shared().rummyInfos.get(this.tid_key).hasChupai = false;
        this.showDropCardsZheZhao(false);
        this.selectedPosY = 178;
        this.unSelectedPosY = 210;
        0 == RummyDataManager.shared().data.direction && (this.selectedPosY = 176, this.unSelectedPosY = 210);
        this.moveCard = null;
        this.fadeCard = null;
        this.changeCardPlayOutLineStatus(false);
        this.drawClear();
        this.lzCard = null;
        this.playArrowAnim(RummyCardConstant.arrowAnimType.mopai, false);
        this.playArrowAnim(RummyCardConstant.arrowAnimType.finish, false);
        this.playArrowAnim(RummyCardConstant.arrowAnimType.qipai, false);
        this.xipai_anim_node.active = false;
        this.hc_anim.node.active = false;
        this.is_shuffle = false;
        this.hidehuAnimCards();
        this.deleteClickCountDown();
        this.setCardValueTipShow(false);
        this.showPickCardTips(false);
        i && this.clearHandCardValue();
        this._with_open = 0;
        this.hideBestLaiziBubble();
        this._localPickAnimEnd = true;
        this.hideSortCardAnim();
    }
    clearHandCardValue() {
        this._nHandCardValue = -1;
        this._nHandCardStar = -1;
        this._nHandCardColor = -1;
    }
    hidehuAnimCards() {
        for (let i = 0, e = this.hupaiCardVec.length; i < e; i++) {
            ToolUtils.isObjValid(this.hupaiCardVec[i]) && this.putCardNode(this.hupaiCardVec[i]);
        }
        TweenTool.stopNodeAction(this.hupai_node);
        this.hupai_node.removeAllChildren();
    }
    hideMyHandCards() {
        let i;
        for (let e = 0, t = this.cardViewVec.length; e < t; e++) {
            i = this.cardViewVec[e];
            ToolUtils.isObjValid(i) && this.putCardNode(i);
        }
        this.cardViewVec = [];
        for (let e = 0, t = this.initialCardNodes.length; e < t; e++) {
            i = this.initialCardNodes[e];
            ToolUtils.isObjValid(i) && this.putCardNode(i);
        }
        this.initialCardNodes = [];
        for (let i = 0, e = this.availableFlagNodes.length; i < e; i++) {
            ToolUtils.isObjValid(this.availableFlagNodes[i]) && this.putAvailableFlagNode(this.availableFlagNodes[i]);
        }
        this.availableFlagNodes = [];
        this.availabeFlagInfos = [];
        this.shoupaiLayout.removeAllChildren();
        this.changeCardValueTipsVisible(0);
        this.fade_node.removeAllChildren();
    }
    initPushCenter() {
        PushCenter.shared().addListener(PushEvent.UpdateRaceCSS, (() => {
            let i, e;
            if (true === this.xipai_anim_node.active && this.refreshxipaicolor(), this.refreshdisCardLineBg(), this.paiduiCardVec && this.paiduiCardVec.length > 0) {
                for (let t = 0, a = this.paiduiCardVec.length; t < a; t++) {
                    i = this.paiduiCardVec[t];
                    ToolUtils.isObjValid(i) && (e = i.getComponent("RummyCard"), e.refreshcardbg("rummy_card_bg_0" + User.shared().styles[2]), e.refreshlazi("rm_kingcard_mask", User.shared().styles[1] - 1));
                }
            }
            if (this.initialCardNodes && this.initialCardNodes.length > 0) {
                for (let t = 0, a = this.initialCardNodes.length; t < a; t++) {
                    i = this.initialCardNodes[t];
                    ToolUtils.isObjValid(i) && (e = i.getComponent("RummyCard"), e.refreshcardbg("rummy_card_bg_0" + User.shared().styles[2]), e.refreshlazi("rm_kingcard_mask", User.shared().styles[1] - 1));
                }
            }
            if (this.cardViewVec && this.cardViewVec.length > 0) {
                for (let t = 0, a = this.cardViewVec.length; t < a; t++) {
                    if (i = this.cardViewVec[t], ToolUtils.isObjValid(i)) {
                        e = i.getComponent("RummyCard");
                        let t = "rm_scard_" + ToolUtils.cardTo16(e.mCardValue);
                        User.shared().styles[1] - 1 == 2 && (t = "club_rm_scard_" + ToolUtils.cardTo16(e.mCardValue));
                        e.refreshcard(t, User.shared().styles[1] - 1);
                        e.refreshlazi("rm_kingcard_mask", User.shared().styles[1] - 1);
                    }
                }
            }
            if (this.qipaiCards && this.qipaiCards.length > 0) {
                for (let t = 0, a = this.qipaiCards.length; t < a; t++) {
                    if (i = this.qipaiCards[t], ToolUtils.isObjValid(i)) {
                        e = i.getComponent("RummyCard");
                        let t = "rm_scard_" + ToolUtils.cardTo16(e.mCardValue);
                        User.shared().styles[1] - 1 == 2 && (t = "club_rm_scard_" + ToolUtils.cardTo16(e.mCardValue));
                        e.refreshcard(t, User.shared().styles[1] - 1);
                        e.refreshcardbg("rummy_card_bg_0" + User.shared().styles[2]);
                        e.refreshlazi("rm_kingcard_mask", User.shared().styles[1] - 1);
                    }
                }
            }
            if (ToolUtils.isObjValid(this.lzCard) && (i = this.lzCard, ToolUtils.isObjValid(i))) {
                e = i.getComponent("RummyCard");
                e.refreshlazi("rm_kingcard_mask", User.shared().styles[1] - 1);
                let t = "rm_scard_" + ToolUtils.cardTo16(e.mCardValue);
                User.shared().styles[1] - 1 == 2 && (t = "club_rm_scard_" + ToolUtils.cardTo16(e.mCardValue));
                e.refreshcard(t, User.shared().styles[1] - 1);
            }
        }), this);
        PushCenter.shared().addListener(PushEvent.RummyGameShowHC, (i => {
            if (this.tid_key == i.tid_key && 1 == RummyDataManager.shared().rummyInfos.get(this.tid_key).is_showhuAnim_status) {
                let e = RummyDataManager.shared().getSeatidByPos(i.pos, this.tid_key), t = RummyDataManager.shared().rummyInfos.get(this.tid_key).playerModels[e], a = sys.localStorage.getItem("play_effect_def");
                null == a && (a = User.shared().help_setting.play_effect_def);
                TweenTool.delayAct(this.delay_node, (() => {
                    let e = ToolUtils.isSafeNumber(t.play_effect_id);
                    this.hc_anim.node.active = true;
                    this.hc_anim.clearTracks();
                    this.hc_anim.setToSetupPose();
                    let s = ["hp_hc", "animation", "hupai2", "animation"];
                    sys.isObjectValid(a) && 1 == Number(a) && e > 0 && this.hcAnimData[e] ? (this.hc_anim.skeletonData = this.hcAnimData[t.play_effect_id], this.hc_anim.setAnimation(0, s[t.play_effect_id], false)) : (this.hc_anim.skeletonData = this.hcAnimData[0], this.hc_anim.setAnimation(0, "hp_hc", false));
                    TweenTool.delayAct(this.delay_node, (() => {
                        this.hc_anim.node.active = false;
                        User.shared().curTid_key === this.tid_key && TransferPlatform.shared().setNormalFrameRate();
                    }), 1.1, true);
                    this.huPaiPaiduiAnim();
                    this.huPaiQiPaiduiAnim();
                    PushCenter.shared().pushEvent(PushEvent.RummyGameBGZD, i);
                }), i.delTime, true);
            }
        }), this);
    }
    huPaiPaiduiAnim(i = true) {
        let e = this.getCardNode(), t = e.getComponent("RummyCard");
        t.init(8, true);
        e.setScale(this.outcardScale);
        e.setPosition(this.paiduiPoint);
        this.hupai_node.addChild(e);
        this.hupaiCardVec.push(e);
        let a = this.getCardNode();
        t = a.getComponent("RummyCard");
        t.init(9, true);
        a.setScale(this.outcardScale);
        a.setPosition(this.paiduiPoint);
        this.hupai_node.addChild(a);
        this.hupaiCardVec.push(a);
        let s = this.getCardNode();
        if (t = s.getComponent("RummyCard"), t.init(10, true), s.setScale(this.outcardScale), s.setPosition(this.paiduiPoint), this.hupai_node.addChild(s), this.hupaiCardVec.push(s), 0 == i) {
            TweenTool.delayAct(this.delay_node, (() => {
                ToolUtils.isObjValid(s) && (s.position = new Vec3(this.paiduiPoint.x + 6.7, this.paiduiPoint.y + 13.5, this.paiduiPoint.z), s.angle = -3.6, s.scale = new Vec3(this.outcardScale.x + 0.1 * this.outcardScale.x, this.outcardScale.x + 0.1 * this.outcardScale.x, 0));
                ToolUtils.isObjValid(a) && (a.position = new Vec3(this.paiduiPoint.x - 17, this.paiduiPoint.y + 22, this.paiduiPoint.z), a.angle = 7.2, a.scale = new Vec3(this.outcardScale.x + 0.08 * this.outcardScale.x, this.outcardScale.x + 0.08 * this.outcardScale.x, 0));
                ToolUtils.isObjValid(e) && (e.position = new Vec3(this.paiduiPoint.x, this.paiduiPoint.y + 17, this.paiduiPoint.z + 7.8), e.angle = 7.8, e.scale = new Vec3(this.outcardScale.x + 0.05 * this.outcardScale.x, this.outcardScale.x + 0.05 * this.outcardScale.x, 0));
                ToolUtils.isObjValid(this.lzCard) && (this.lzCard.position = new Vec3(this.laiziPoint.x + 2, this.laiziPoint.y - 6, this.laiziPoint.z));
            }), 1 / 60, true);
        }
        else {
            let i = TweenTool.rotateBy(e, 0.957 - 0.891, new Vec3(0, 0, 8.4), "linear", false), t = TweenTool.moveBy(e, 0.957 - 0.891, new Vec3(-4, 42.25, 0), "linear", false), r = this.outcardScale.x + 0.05 * this.outcardScale.x, d = TweenTool.scaleTo(e, 0.957 - 0.891, new Vec3(r, r, 0), "linear", false), o = TweenTool.parallel(e, false, null, i, t, d), h = TweenTool.rotateBy(e, 0.99 - 0.957, new Vec3(0, 0, -0.6), "linear", false), l = TweenTool.moveBy(e, 0.957 - 0.891, new Vec3(4, -25.08, 0), "linear", false), n = TweenTool.parallel(e, false, null, h, l);
            TweenTool.sequence(e, false, null, o, n).start();
            i = TweenTool.rotateBy(a, 0.957 - 0.891, new Vec3(0, 0, 8.4), "linear", false);
            t = TweenTool.moveBy(a, 0.957 - 0.891, new Vec3(-18, 33.25, 0), "linear", false);
            r = this.outcardScale.x + 0.08 * this.outcardScale.x;
            d = TweenTool.scaleTo(a, 0.957 - 0.891, new Vec3(r, r, 0), "linear", false);
            o = TweenTool.parallel(a, false, null, i, t, d);
            h = TweenTool.rotateBy(a, 0.99 - 0.957, new Vec3(0, 0, -1.2), "linear", false);
            l = TweenTool.moveBy(a, 0.957 - 0.891, new Vec3(0.6, -9.32, 0), "linear", false);
            n = TweenTool.parallel(a, false, null, h, l);
            TweenTool.sequence(a, false, null, o, n).start();
            i = TweenTool.rotateBy(s, 0.957 - 0.891, new Vec3(0, 0, -1.2), "linear", false);
            t = TweenTool.moveBy(s, 0.957 - 0.891, new Vec3(6, 21.5, 0), "linear", false);
            r = this.outcardScale.x + 0.1 * this.outcardScale.x;
            d = TweenTool.scaleTo(s, 0.957 - 0.891, new Vec3(r, r, 0), "linear", false);
            o = TweenTool.parallel(s, false, null, i, t, d);
            h = TweenTool.rotateBy(s, 0.99 - 0.957, new Vec3(0, 0, -6), "linear", false);
            l = TweenTool.moveBy(s, 0.957 - 0.891, new Vec3(0.7, -8, 0), "linear", false);
            n = TweenTool.parallel(s, false, null, h, l);
            TweenTool.sequence(s, false, null, o, n).start();
            i = TweenTool.rotateBy(this.lzCard, 0.957 - 0.891, new Vec3(0, 0, -2.4), "linear", false);
            t = TweenTool.moveBy(this.lzCard, 0.957 - 0.891, new Vec3(-2, 10, 0), "linear", false);
            o = TweenTool.parallel(this.lzCard, false, null, i, t);
            h = TweenTool.rotateBy(this.lzCard, 0.99 - 0.957, new Vec3(0, 0, 2.4), "linear", false);
            l = TweenTool.moveBy(this.lzCard, 0.99 - 0.957, new Vec3(2, -6, 0), "linear", false);
            n = TweenTool.parallel(this.lzCard, false, null, h, l);
            TweenTool.sequence(this.lzCard, false, null, o, n).start();
        }
    }
    huPaiQiPaiduiAnim(i = true) {
        if (this.seeverOpenCards && this.seeverOpenCards.length >= 2) {
            this.qipai_node.removeAllChildren();
            let e = RummyDataManager.shared().rummyInfos.get(this.tid_key), t = e.winLaizicard > 0 ? e.winLaizicard : e.laizicard;
            if (0 == i) {
                for (let i = 0; i < 2; i++) {
                    let e = this.seeverOpenCards.length - 3 + i;
                    if (e >= 0 && this.seeverOpenCards[e]) {
                        let a = this.getCardNode(), s = a.getComponent("RummyCard");
                        if (s.init(this.seeverOpenCards[e], false), s.openCard(), s.showLaiziFlag(this.isShowLaiziColor(this.seeverOpenCards[e], t)), a.setScale(this.outcardScale), a.setPosition(this.qipaiPoint), a.active = true, this.hupai_node.addChild(a), this.hupaiCardVec.push(a), 1 == i) {
                            let i = this.qipaiPoint, e = this.outcardScale.x + 0.05 * this.outcardScale.x;
                            a.position = new Vec3(i.x + 7.6, i.y + 12, i.z);
                            a.scale = new Vec3(e, e, 0);
                            a.angle = -1.2;
                        }
                    }
                }
            }
            else {
                if (this.seeverOpenCards.length >= 3) {
                    let i = this.getCardNode(), e = i.getComponent("RummyCard"), a = this.seeverOpenCards[this.seeverOpenCards.length - 3];
                    e.init(a, false);
                    e.openCard();
                    e.showLaiziFlag(this.isShowLaiziColor(a, t));
                    i.setScale(this.outcardScale);
                    i.setPosition(this.qipaiPoint);
                    i.active = true;
                    this.hupai_node.addChild(i);
                    this.hupaiCardVec.push(i);
                }
                if (this.seeverOpenCards.length >= 2) {
                    let i = this.getCardNode(), e = i.getComponent("RummyCard"), a = this.seeverOpenCards[this.seeverOpenCards.length - 2];
                    e.init(a, false);
                    e.openCard();
                    e.showLaiziFlag(this.isShowLaiziColor(a, t));
                    i.setScale(this.outcardScale);
                    i.setPosition(this.qipaiPoint);
                    i.active = true;
                    this.hupai_node.addChild(i);
                    this.hupaiCardVec.push(i);
                    let s = TweenTool.rotateTo(i, 0.957 - 0.891, new Vec3(0, 0, 8.4), "linear", false), r = TweenTool.moveBy(i, 0.957 - 0.891, new Vec3(2, 20, 0), "linear", false), d = this.outcardScale.x + 0.05 * this.outcardScale.x, o = TweenTool.scaleTo(i, 0.957 - 0.891, new Vec3(d, d, 0), "linear", false), h = TweenTool.parallel(i, false, null, s, r, o), l = TweenTool.rotateTo(i, 0.99 - 0.957, new Vec3(0, 0, -1.2), "linear", false), n = TweenTool.moveBy(i, 0.957 - 0.891, new Vec3(5.6, -8.87, 0), "linear", false), u = TweenTool.parallel(i, false, null, l, n);
                    TweenTool.sequence(i, false, null, h, u).start();
                }
            }
        }
        else {
            this.qipai_node.removeAllChildren();
        }
    }
    showRobotPlayerCards(i, e, t = 0) {
        if (this.hideRobotPlayerCards(e), null == i || null == i) {
            return;
        }
        let a = this.seatPosVec[e].x, s = this.seatPosVec[e].y + 84, r = RummyDataManager.shared().rummyInfos.get(this.tid_key).pnum;
        2 == r ? (a = this.seatPosVec[e].x + 100, s = this.seatPosVec[e].y) : 1 == e ? (a = this.seatPosVec[e].x - 163, s = this.seatPosVec[e].y - 81, 4 == r && (a = this.seatPosVec[e].x - 230)) : 2 == e ? (a = this.seatPosVec[e].x - 38, 4 == r && (a = this.seatPosVec[e].x - 130)) : 3 == e ? (a = this.seatPosVec[e].x - 132, 4 == r && (a = this.seatPosVec[e].x - 60, s = this.seatPosVec[e].y - 70)) : 4 == e ? a = this.seatPosVec[e].x - 224 : 5 == e && (a = this.seatPosVec[e].x - 108, s = this.seatPosVec[e].y - 81);
        let d, o, h = i.length, l = 0;
        sys.isObjectValid(this.otherCardsVec[e]) || (this.otherCardsVec[e] = []);
        sys.isObjectValid(this.otherGroupFlags[e]) || (this.otherGroupFlags[e] = []);
        let n = [];
        for (let r = 0; r < h; r++) {
            let h = i[r].cards;
            n = [];
            for (let i = 0, c = h.length; i < c; i++) {
                d = this.getCardNode();
                o = d.getComponent("RummyCard");
                this.testShoupaiLayout.addChild(d);
                o.init(h[i], true, 2);
                o.openCard();
                o.showRobotLaiziFlag(this.isShowLaiziColor(h[i], t));
                o.setCardTag(r);
                d.setScale(this.otherCardScale);
                d.active = true;
                let c = a + 19 * l + 11 * r;
                n.push(c);
                d.setPosition(v3(c, s));
                this.otherCardsVec[e].push(d);
                l += 1;
            }
            let c = this.getGroupFlagNode();
            if (c) {
                c.getChildByName("btn").active = false;
                c.getChildByName("left_btn").active = false;
                c.getChildByName("right_btn").active = false;
                let t = c.getChildByName("grop_flag");
                t.active = true;
                c.active = true;
                t.getChildByName("text").active = false;
                0 == i[r].color ? t.getChildByName("flag").getComponent(Sprite).spriteFrame = this.card_kuang_anim[14] : 2 == i[r].color ? t.getChildByName("flag").getComponent(Sprite).spriteFrame = this.card_kuang_anim[16] : 3 == i[r].color && (t.getChildByName("flag").getComponent(Sprite).spriteFrame = this.card_kuang_anim[15]);
                let a, d = 19 * (h.length - 1) + this.otherCardWidth + 0.5, o = Math.floor(h.length / 2);
                a = h.length % 2 == 0 ? n[o] - 9.5 : n[o];
                c.getComponent(UITransform).setContentSize(size(d, RummyCardConstant.OtherGroupFlagHeight));
                t.getComponent(UITransform).setContentSize(size(d, RummyCardConstant.OtherGroupFlagHeight));
                let l = s - RummyCardConstant.OtherCardHeight / 2 + RummyCardConstant.OtherGroupFlagHeight / 2;
                c.setPosition(v3(a, l, 0));
                t.getComponent(Layout).updateLayout();
                c.setSiblingIndex(30 + r);
                this.testShoupaiLayout.addChild(c);
                this.otherGroupFlags[e].push(c);
            }
        }
    }
    hideRobotPlayerCards(i) {
        if (sys.isObjectValid(this.otherCardsVec[i]) && this.otherCardsVec[i].length > 0) {
            for (let e = 0, t = this.otherCardsVec[i].length; e < t; e++) {
                ToolUtils.isObjValid(this.otherCardsVec[i][e]) && this.putCardNode(this.otherCardsVec[i][e]);
            }
        }
        if (this.otherCardsVec[i] = [], sys.isObjectValid(this.otherGroupFlags[i]) && this.otherGroupFlags[i].length > 0) {
            for (let e = 0, t = this.otherGroupFlags[i].length; e < t; e++) {
                ToolUtils.isObjValid(this.otherGroupFlags[i][e]) && this.putGroupFlagNode(this.otherGroupFlags[i][e]);
            }
        }
        this.otherGroupFlags[i] = [];
    }
    refreshAllGroupInfo(i = []) {
        this.clearTemeMoveCardData();
        for (let i = 0, e = this.cardViewVec.length; i < e; i++) {
            let e = this.cardViewVec[i];
            ToolUtils.isObjValid(e) && e.setPosition(this.cardsPostions[i]);
        }
        this.hasFaPaiAnimEnded = true;
        let e = this.myGroupcardValueVec.length, t = this.cardViewVec.length, a = 2 * RummyCardConstant.cebianW, r = (e - 1) * this.cardSpaceGroup, d = e * this.cardWidth, h = t - e, l = (RummyCardConstant.ScreenWidth - a - r - d) / (1 * h);
        if (this.lastOffsetX = l, this.groupFlags.length > 0) {
            for (let i = 0, e = this.groupFlags.length; i < e; i++) {
                ToolUtils.isObjValid(this.groupFlags[i]) && (this.groupFlags[i].active = false);
            }
        }
        this.changeAddBtnStatus(false);
        this.add_btnArray = [];
        let n, c, u, C, P, S, v, I, x, A, N, z, F, O, q, j, R = 0, G = RummyDataManager.shared().rummyInfos.get(this.tid_key), B = false;
        for (let t = 0; t < e; t++) {
            if (n = this.myGroupcardValueVec[t].cardVec, sys.isObjectValid(this.groupFlags[t]) ? (v = this.groupFlags[t], v.active = true) : (v = instantiate(this.node.getChildByName("grop_flag")), this.groupFlags.push(v)), v) {
                I = v.getChildByName("grop_flag");
                j = I.getChildByName("flag").getComponent(Sprite);
                x = v.getChildByName("btn");
                x.active = false;
                c = "Add_Btn" + t;
                x.getComponent(Button).clickEvents[0].customEventData = c;
                c = "left_btn" + t;
                A = v.getChildByName("left_btn");
                A.getComponent(Button).clickEvents[0].customEventData = c;
                c = "right_btn" + t;
                N = v.getChildByName("right_btn");
                N.getComponent(Button).clickEvents[0].customEventData = c;
                let i = I.getChildByName("text");
                q = i.getComponent(Label);
                v.active = true;
                I.active = true;
                n.length < 2 ? i.active = false : i.active = true;
                Utils.shared().setStr(i, this.myGroupcardValueVec[t].desc);
                F = A.getChildByName("Sprite");
                F.getComponent(Sprite);
                O = N.getChildByName("Sprite");
                O.getComponent(Sprite);
                0 == this.myGroupcardValueVec[t].color ? 1 == G.dropType ? j.spriteFrame = this.card_kuang_anim[17] : j.spriteFrame = this.card_kuang_anim[14] : 2 == this.myGroupcardValueVec[t].color ? 1 == G.dropType ? j.spriteFrame = this.card_kuang_anim[17] : j.spriteFrame = this.card_kuang_anim[16] : 3 == this.myGroupcardValueVec[t].color && (1 == G.dropType ? j.spriteFrame = this.card_kuang_anim[18] : j.spriteFrame = this.card_kuang_anim[15]);
                u = (n.length - 1) * l + this.cardWidth + 15;
                C = this.spXpositionDeq[R];
                P = Math.floor(n.length / 2) + R;
                C = n.length % 2 == 0 ? this.spXpositionDeq[P] - l / 2 : this.spXpositionDeq[P];
                q.fontSize = 48;
                v.getComponent(UITransform).setContentSize(size(u, RummyCardConstant.GroupFlagHeight));
                v.setPosition(v3(C, RummyCardConstant.GroupFlagPosY, 0));
                v.setSiblingIndex(30 + t);
                A.setPosition(v3(-u / 2 + 20, 3, 0));
                N.setPosition(v3(u / 2 - 20, 3, 0));
                this.shoupaiLayout.addChild(v);
                I.getComponent(Layout).updateLayout();
                ToolUtils.isObjValid(x) && (x.active = false, this.add_btnArray.push(x));
                S = true;
                z = true;
                0 == t ? S = false : t == e - 1 && (z = false);
                1 === this.myGroupcardValueVec.length && (S = false, z = false);
                S = false;
                z = false;
                A.active = S;
                N.active = z;
            }
            if (i.includes(t)) {
                if (this.autoSortAnimNode.active = true, !ToolUtils.isObjValid(this.sortCardAnimVec[t])) {
                    this.sortCardAnimVec[t] = new Node;
                    let i = instantiate(this.sortCardAnimMoban);
                    i.active = true;
                    i.name = "animA";
                    this.sortCardAnimVec[t].addChild(i);
                    let e = instantiate(this.sortCardAnimMoban);
                    e.active = true;
                    e.name = "animB";
                    this.sortCardAnimVec[t].addChild(e);
                    let a = instantiate(this.sortCardAnimMoban);
                    a.active = true;
                    a.name = "animC";
                    this.sortCardAnimVec[t].addChild(a);
                    this.autoSortAnimNode.addChild(this.sortCardAnimVec[t]);
                }
                this.sortCardAnimVec[t].active = true;
                this.sortCardAnimVec[t].setPosition(v3(C, this.middlePosY, 0));
                let i = u - 70, e = this.sortCardAnimVec[t].getChildByName("animA");
                e.setPosition(v3(-i / 2 - 22.5, 0, 0));
                let a = e.getComponent(sp.Skeleton);
                a.setToSetupPose();
                a.setAnimation(0, "A", false);
                let r = this.sortCardAnimVec[t].getChildByName("animB");
                r.setScale(v3(i / 100, 1, 1));
                r.setPosition(v3(0, 0, 0));
                a = r.getComponent(sp.Skeleton);
                a.setToSetupPose();
                a.setAnimation(0, "B", false);
                let d = this.sortCardAnimVec[t].getChildByName("animC");
                d.setPosition(v3(u / 2 - 13, 0, 0));
                a = d.getComponent(sp.Skeleton);
                a.setToSetupPose();
                a.setAnimation(0, "C", false);
                a.setCompleteListener((() => {
                    this.sortCardAnimVec[t].active = false;
                }));
                B = true;
            }
            R += n.length;
        }
        B && this.playEffectByName("autoSortCard");
        this.showAvailableCardFlag(this.myGroupcardValueVec);
    }
    hideSortCardAnim() {
        this.autoSortAnimNode.active = false;
        for (let i = 0; i < 7; i++) {
            ToolUtils.isObjValid(this.sortCardAnimVec[i]) && (this.sortCardAnimVec[i].active = false);
        }
    }
    showAvailableCardFlag(i) {
        if (!RummyDataManager.shared().getCanShowAvailableCardTips()) {
            return;
        }
        let e, t, a = 0, s = [], r = [], d = RummyDataManager.shared().rummyInfos.get(this.tid_key);
        for (let i = 0, e = this.availableFlagNodes.length; i < e; i++) {
            ToolUtils.isObjValid(this.availableFlagNodes[i]) && this.putAvailableFlagNode(this.availableFlagNodes[i]);
        }
        this.availableFlagNodes = [];
        let o = [];
        for (let d = 0; d < i.length; d++) {
            if (s = i[d].inputs, t = i[d].cardVec, s && Array.isArray(s) && s.length > 0) {
                a = s.length;
                for (let i = 0; i < a; i++) {
                    let a = s[i].index, h = s[i].cards;
                    if (Array.isArray(a) && Array.isArray(h) && 2 == a.length && 2 == h.length && t.length > a[0] && t.length > a[1]) {
                        let l = t[a[0]], n = t[a[1]];
                        if (l == h[0] && n == h[1]) {
                            for (let t = 0; t < this.cardViewVec.length; t++) {
                                let l = this.cardViewVec[t];
                                if (ToolUtils.isObjValid(l) && (e = l.getComponent("RummyCard"), e.groupIndex == d && e.cardIndex == a[1] && e.mCardValue == h[1])) {
                                    r.push(t);
                                    o.push(s[i]);
                                    break;
                                }
                            }
                        }
                    }
                }
            }
        }
        if (this.availabeFlagInfos = [], r.length > 0) {
            let i = new Vec3;
            for (let t = 0; t < r.length; t++) {
                let a = r[t], s = this.cardViewVec[a];
                s.getPosition(i);
                e = s.getComponent("RummyCard");
                let h = this.getAvailableFlagNode();
                this.shoupaiLayout.addChild(h);
                h.setSiblingIndex(60 + t);
                h.active = true;
                h.getComponent(Sprite).color = new Color(255, 255, 255, 255);
                h.getChildByName("Label").getComponent(Label).string = "" + o[t].num;
                this.refreshAvailableFlagType(0, h);
                let n = { availableCardTip: true, inputs: o[t], flagNode: h, groupIndex: e.groupIndex, cardIndex: e.cardIndex, cardValue: e.mCardValue };
                this.availabeFlagInfos[t] = n;
                h.setPosition(new Vec3(i.x - this.cardWidth / 2, -189));
                h.getComponent(Button).clickEvents[0].customEventData = t + "";
                this.availableFlagNodes[t] = h;
                1 == d.dropType && (h.getComponent(Sprite).color = new Color(130, 130, 130, 255), h.active = false);
                h.getComponent(Button).interactable = 1 != d.dropType;
                ToolUtils.isObjValid(this.add_btnArray[e.groupIndex]) && this.add_btnArray[e.groupIndex].active && (h.active = false);
            }
        }
    }
    refreshAvailableFlagType(i, e) {
        ToolUtils.isObjValid(e) && (e.getComponent(Sprite).spriteFrame = this.availableSpites[i]);
    }
    changeAddBtnStatus(i) {
        let e, t, a = RummyDataManager.shared().rummyInfos.get(this.tid_key);
        if (i) {
            let i, s, r, d, o = this.getSelectedCards(), h = o.length;
            for (let l = 0, n = this.myGroupcardValueVec.length; l < n; l++) {
                if (e = this.myGroupcardValueVec[l].cardVec, t = e.length, i = false, h >= 1 && (i = true), ToolUtils.isObjValid(this.groupFlags[l]) && ToolUtils.isObjValid(this.add_btnArray[l])) {
                    this.add_btnArray[l].active = i;
                    this.add_btnArray[l].getComponent(Button).interactable = i;
                    s = this.groupFlags[l].getChildByName("grop_flag").getChildByName("text");
                    s.active = !(t < 2) && !i;
                    for (let e = 0; e < h; e++) {
                        d = o[e];
                        ToolUtils.isObjValid(d) && (r = d.getComponent("RummyCard"), r.groupIndex == l && (this.add_btnArray[l].active = false, this.add_btnArray[l].getComponent(Button).interactable = false, i = false));
                    }
                    if (RummyDataManager.shared().getCanShowAvailableCardTips()) {
                        for (let e = 0; e < this.availabeFlagInfos.length; e++) {
                            let t = this.availabeFlagInfos[e], s = t.flagNode, r = t.groupIndex;
                            ToolUtils.isObjValid(s) && r == l && (s.active = !i);
                            1 == a.dropType && (s.active = false);
                        }
                    }
                }
            }
        }
        else {
            for (let i = 0, e = this.add_btnArray.length; i < e; i++) {
                ToolUtils.isObjValid(this.add_btnArray[i]) && (this.add_btnArray[i].active = false, this.add_btnArray[i].getComponent(Button).interactable = false);
            }
            let i;
            for (let a = 0, s = this.myGroupcardValueVec.length; a < s; a++) {
                e = this.myGroupcardValueVec[a].cardVec;
                t = e.length;
                ToolUtils.isObjValid(this.groupFlags[a]) && (i = this.groupFlags[a].getChildByName("grop_flag").getChildByName("text"), i.active = !(t < 2));
            }
            if (RummyDataManager.shared().getCanShowAvailableCardTips()) {
                for (let i = 0; i < this.availabeFlagInfos.length; i++) {
                    let e = this.availabeFlagInfos[i].flagNode;
                    ToolUtils.isObjValid(e) && (1 == a.dropType ? e.active = false : e.active = true);
                }
            }
        }
    }
    showMoPaiTisAnim(i, e, t = false) {
        t ? (this.playArrowAnim(RummyCardConstant.arrowAnimType.getWin, true), this.playArrowAnim(RummyCardConstant.arrowAnimType.finish, false), this.playArrowAnim(RummyCardConstant.arrowAnimType.mopai, false)) : (i ? (this.playArrowAnim(RummyCardConstant.arrowAnimType.mopai, true), this.playArrowAnim(RummyCardConstant.arrowAnimType.finish, false)) : this.playArrowAnim(RummyCardConstant.arrowAnimType.mopai, false), e ? this.playArrowAnim(RummyCardConstant.arrowAnimType.qipai, true, i) : this.playArrowAnim(RummyCardConstant.arrowAnimType.qipai, false));
    }
    showFinishTisiAnim(i) {
        i ? (this.playArrowAnim(RummyCardConstant.arrowAnimType.finish, true), this.playArrowAnim(RummyCardConstant.arrowAnimType.mopai, false)) : this.playArrowAnim(RummyCardConstant.arrowAnimType.finish, false);
    }
    playArrowAnim(i, e, t = false, a = true) {
        i == RummyCardConstant.arrowAnimType.mopai ? this.arrow_anim_nodes[0].active = false : i == RummyCardConstant.arrowAnimType.finish ? this.arrow_anim_nodes[1].active = false : (i == RummyCardConstant.arrowAnimType.qipai || i == RummyCardConstant.arrowAnimType.getWin) && (this.arrow_anim_nodes[2].active = false, this.arrow_anim_nodes[3].active = false, this.arrow_anim_nodes[4].active = false);
        e && (i == RummyCardConstant.arrowAnimType.mopai ? 0 == RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyMode ? (this.arrow_anim_nodes[0].active = true, this.arrow_anim_nodes[0].getComponent(sp.Skeleton).clearTracks(), a ? this.arrow_anim_nodes[0].getComponent(sp.Skeleton).setAnimation(0, "kuang_yellow", true) : this.arrow_anim_nodes[0].getComponent(sp.Skeleton).setAnimation(0, "kuang_yellow_wjt", true)) : this.arrow_anim_nodes[0].active = false : i == RummyCardConstant.arrowAnimType.finish || (i == RummyCardConstant.arrowAnimType.qipai ? 1 == RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyMode ? t ? this.arrow_anim_nodes[2].active = false : (this.arrow_anim_nodes[3].active = true, this.arrow_anim_nodes[3].getComponent(sp.Skeleton).clearTracks(), this.arrow_anim_nodes[3].getComponent(sp.Skeleton).setAnimation(0, "kuang_green_wjt", true)) : t ? (this.arrow_anim_nodes[2].active = true, this.arrow_anim_nodes[2].getComponent(sp.Skeleton).clearTracks(), this.arrow_anim_nodes[2].getComponent(sp.Skeleton).setAnimation(0, "kuang_yellow", true)) : (this.arrow_anim_nodes[3].active = true, this.arrow_anim_nodes[3].getComponent(sp.Skeleton).clearTracks(), this.arrow_anim_nodes[3].getComponent(sp.Skeleton).setAnimation(0, "kuang_green", true)) : i == RummyCardConstant.arrowAnimType.getWin && (this.arrow_anim_nodes[4].active = true, this.mopai_tip_anim.clearTracks(), this.mopai_tip_anim.setToSetupPose(), this._mopaiTipAnimUpdated || (this._mopaiTipAnimUpdated = true, Utils.shared().updateAnimMaterial(this.mopai_tip_anim)), this.mopai_tip_anim.setAnimation(0, "txdh", true))));
    }
    addPaiDuiCard() {
        let i = this.getCardNode();
        i.getComponent("RummyCard").init(1, true);
        i.setScale(this.outcardScale);
        i.setPosition(this.paiduiPoint);
        this.paidui_node.addChild(i);
        this.paiduiCardVec.push(i);
        i.setSiblingIndex(this.paiduiCardVec.length + 1);
    }
    resetQiPaiDui() {
        if (0 == this.qipaiCards.length) {
            return;
        }
        let i = this.qipaiCards[this.qipaiCards.length - 1];
        i.active = true;
        i.setScale(this.outcardScale);
        i.setPosition(this.qipaiPoint);
        i.setSiblingIndex(this.paiduiCardVec.length + 1);
        i.parent = this.qipai_node;
    }
    getLocalMoPai(i, e, t) {
        if (isNaN(i)) {
            return;
        }
        if (i < 0 || i > 5) {
            return;
        }
        this.cancelOpenPileSync();
        let a, s = null, r = 1;
        if (0 == this.qipaiCards.length) {
            let i = this.getCardNode();
            a = i.getComponent("RummyCard");
            a.init(e, false);
            1 == RummyDataManager.shared().rummyInfos.get(this.tid_key).is_bump ? a.showLaiziFlag(this.isShowLaiziColor(e), false, true) : a.showLaiziFlag(this.isShowLaiziColor(e));
            i.setScale(this.outcardScale);
            i.setPosition(this.qipaiPoint);
            i.setSiblingIndex(0);
            this.qipai_node.addChild(i);
            this.qipaiCards.push(i);
            r = RummyDataManager.shared().rummyInfos.get(this.tid_key).dc_card;
        }
        if (this.qipaiCards.length >= 2) {
            let i = this.qipaiCards[this.qipaiCards.length - 2];
            i && i.isValid && (i.active = true);
        }
        if (this.qipaiCards.length > 0) {
            if (s = this.qipaiCards[this.qipaiCards.length - 1], ToolUtils.isObjValid(s)) {
                let i = s.getComponent("RummyCard");
                i.mCardValue != e && i.setCardValue(e);
            }
            for (let i = 0, e = this.qipaiCards.length; i < e - 1; i++) {
                ToolUtils.isObjValid(this.qipaiCards[i]) && this.qipaiCards[i].setSiblingIndex(i);
            }
            r = e;
        }
        ToolUtils.isObjValid(s) || (s = this.getCardNode(), a = s.getComponent("RummyCard"), a.init(e, false), 1 == RummyDataManager.shared().rummyInfos.get(this.tid_key).is_bump ? a.showLaiziFlag(this.isShowLaiziColor(e), false, true) : a.showLaiziFlag(this.isShowLaiziColor(e)), s.setScale(this.outcardScale), s.setPosition(this.qipaiPoint), s.setSiblingIndex(0), this.qipai_node.addChild(s), this.qipaiCards.push(s));
        s.setPosition(this.qipaiPoint);
        ToolUtils.isObjValid(this.paidui_node) && s.setSiblingIndex(this.paidui_node.children.length);
        s.active = true;
        let d = s.getComponent("RummyCard"), o = v3(this.seatPosVec[i].x, this.seatPosVec[i].y + 14), h = this.mpScale, l = 0.2;
        if (0 == i) {
            let i = new Vec3;
            s.getPosition(i);
            s.active = false;
            this.putCardNode(s);
            this.qipaiCards.pop();
            let e = this.getCardNode();
            d = e.getComponent("RummyCard");
            d.init(r, false);
            d.showLaiziFlag(this.isShowLaiziColor(r));
            e.setScale(this.outcardScale);
            e.setPosition(i);
            this.shoupaiLayout.insertChild(e, 1);
            e.setSiblingIndex(13);
            s = e;
            this.qipaiCards.push(s);
            d.openCard();
            d.setCardValue(r);
            d.showLaiziFlag(this.isShowLaiziColor(r));
            let a = RummyCardConstant.ScreenWidth / 2;
            this.spXpositionDeq.length > 0 && (a = this.spXpositionDeq[this.spXpositionDeq.length - 1]);
            let n = t[t.length - 1].cardVec, u = 52, g = -463 - this._diffY + u * n.length;
            g = this.middlePosY;
            o = v3(a, g);
            h = this.cardScale;
            l = 0.45;
        }
        if (ToolUtils.isObjValid(s)) {
            s.active = true;
            let i = [];
            for (let a = 0, s = t.length; a < s; a++) {
                i[a] = {};
                i[a].type = t[a].type;
                i[a].desc = t[a].desc;
                i[a].color = t[a].color;
                i[a].score = t[a].score;
                i[a].isShowAnime = t[a].isShowAnime;
                i[a].isCatchGroup = t[a].isCatchGroup;
                i[a].inputs = t[a].inputs;
                i[a].index = t[a].index;
                i[a].catchIndex = t[a].catchIndex;
                i[a].cardVec = [];
                for (let e = 0, s = t[a].cardVec.length; e < s; e++) {
                    i[a].cardVec.push(t[a].cardVec[e]);
                }
                a == s - 1 && i[a].cardVec.push(e);
            }
            this._localPickAnimEnd = false;
            tween(s).parallel(tween().to(l, { position: o }, { easing: "expoOut" }), tween().to(l, { scale: h }, { easing: "expoOut" }), tween().delay(l - 0.2).call((() => {
                this.begainLocalFaPaiWithoutAnim(i);
            }))).call((() => {
                this._localPickAnimEnd = true;
            })).start();
        }
    }
    getMoPai(i, e, t, a, s, r, d, o) {
        if (isNaN(i)) {
            return;
        }
        if (i < 0 || i > 5) {
            return;
        }
        this.cancelOpenPileSync();
        this.xipai_anim_node.active = false;
        this.mopaiPos = i;
        this.mpType = e;
        this.playEffectByName("rummyPickDiscard");
        0 == i && (this.myGroupcardValueVec = a, RummyDataManager.shared().rummyInfos.get(this.tid_key).isCanTouchCard = false);
        let h, l = null, n = 1;
        if (0 == e) {
            if (0 !== t && (n = t), ToolUtils.isObjValid(this.lzCard) && this.lzCard.setSiblingIndex(0), 0 === this.paiduiCardVec.length && this.addPaiDuiCard(), this.paiduiCardVec.length >= 2) {
                let i = this.paiduiCardVec[this.paiduiCardVec.length - 2];
                this.restoreDeckCard(i);
            }
            else {
                1 !== RummyDataManager.shared().rummyInfos.get(this.tid_key).is_reshuffle && RummyDataManager.shared().rummyInfos.get(this.tid_key).close_cardnum > 1 && this.addPaiDuiCard();
            }
            l = this.paiduiCardVec[this.paiduiCardVec.length - 1];
            this.paiduiCardVec.length >= 2 && this.restoreDeckCard(this.paiduiCardVec[this.paiduiCardVec.length - 2]);
            ToolUtils.isObjValid(l) || (l = this.getCardNode(), h = l.getComponent("RummyCard"), h.init(1, true), l.setScale(this.outcardScale), l.setPosition(this.paiduiPoint), this.paidui_node.addChild(l), this.paiduiCardVec.push(l), l.setSiblingIndex(this.paiduiCardVec.length + 1));
            this.restoreDeckCard(l);
        }
        else if (1 == e) {
            if (0 == i && d) {
                return RummyDataManager.shared().rummyInfos.get(this.tid_key).mp_refresh = true, this.qipaiCards.length > 0 && (l = this.qipaiCards[this.qipaiCards.length - 1], this.qipaiCards.pop()), void (this._localPickAnimEnd ? this.mopaiCallback(l, s, r, t, o) : TweenTool.delayAct(this.node, (() => {
                    this.mopaiCallback(l, s, r, t, o);
                }), 0.18, true));
            }
            if (0 == this.qipaiCards.length) {
                let i = this.getCardNode();
                h = i.getComponent("RummyCard");
                h.init(t, false);
                1 == RummyDataManager.shared().rummyInfos.get(this.tid_key).is_bump ? h.showLaiziFlag(this.isShowLaiziColor(t), false, true) : h.showLaiziFlag(this.isShowLaiziColor(t));
                i.setScale(this.outcardScale);
                i.setPosition(this.qipaiPoint);
                i.setSiblingIndex(0);
                this.qipai_node.addChild(i);
                this.qipaiCards.push(i);
                n = RummyDataManager.shared().rummyInfos.get(this.tid_key).dc_card;
            }
            if (this.qipaiCards.length >= 2) {
                let i = this.qipaiCards[this.qipaiCards.length - 2];
                i && i.isValid && (i.active = true);
            }
            if (this.qipaiCards.length > 0) {
                if (l = this.qipaiCards[this.qipaiCards.length - 1], ToolUtils.isObjValid(l)) {
                    let i = l.getComponent("RummyCard");
                    i.mCardValue != t && i.setCardValue(t);
                }
                for (let i = 0, e = this.qipaiCards.length; i < e - 1; i++) {
                    ToolUtils.isObjValid(this.qipaiCards[i]) && this.qipaiCards[i].setSiblingIndex(i);
                }
                n = t;
            }
            ToolUtils.isObjValid(l) || (l = this.getCardNode(), h = l.getComponent("RummyCard"), h.init(t, false), 1 == RummyDataManager.shared().rummyInfos.get(this.tid_key).is_bump ? h.showLaiziFlag(this.isShowLaiziColor(t), false, true) : h.showLaiziFlag(this.isShowLaiziColor(t)), l.setScale(this.outcardScale), l.setPosition(this.qipaiPoint), l.setSiblingIndex(0), this.qipai_node.addChild(l), this.qipaiCards.push(l));
            l.setPosition(this.qipaiPoint);
        }
        ToolUtils.isObjValid(this.paidui_node) && l.setSiblingIndex(this.paidui_node.children.length);
        l.active = true;
        let u = l.getComponent("RummyCard"), g = v3(this.seatPosVec[i].x, this.seatPosVec[i].y + 14), p = this.mpScale, m = 0.3;
        if (0 == e && 1 == i && (m = 0.38), 0 == i) {
            let i = new Vec3;
            l.getPosition(i);
            l.active = false;
            ToolUtils.isObjValid(l) && this.putCardNode(l);
            let e = this.getCardNode();
            u = e.getComponent("RummyCard");
            u.init(n, false);
            u.showLaiziFlag(this.isShowLaiziColor(n));
            e.setScale(this.outcardScale);
            e.setPosition(i);
            this.shoupaiLayout.insertChild(e, 1);
            e.setSiblingIndex(500);
            l = e;
            RummyDataManager.shared().rummyInfos.get(this.tid_key).mp_refresh = true;
            u.openCard();
            u.setCardValue(n);
            u.showLaiziFlag(this.isShowLaiziColor(n));
            let t = RummyCardConstant.ScreenWidth / 2;
            this.spXpositionDeq.length > 0 && (t = this.spXpositionDeq[this.spXpositionDeq.length - 1]);
            let s = a[a.length - 1].cardVec, r = 52, d = -463 - this._diffY + r * s.length;
            d = this.middlePosY;
            g = v3(t, d);
            p = this.cardScale;
        }
        if (ToolUtils.isObjValid(l)) {
            l.active = true;
            let a = 0;
            if (0 == this.mpType ? this.paiduiCardVec.pop() : 1 == this.mpType && this.qipaiCards.pop(), 0 == i) {
                m = 1 == e ? 0.45 : 0.65;
                let i = 1 == e ? 0.2 : 0.35;
                tween(l).parallel(tween().to(m, { position: g }, { easing: "expoOut" }), tween().to(m, { scale: p }, { easing: "expoOut" }), tween().delay(m - i).call((() => {
                    this.begainLocalFaPaiWithoutAnim(s);
                }))).union().call((() => {
                    this.mopaiCallback(l, s, r, t, o);
                })).start();
            }
            else {
                tween(l).parallel(tween().to(m, { position: g }, { easing: "sineOut" }), tween().to(m, { scale: p }, { easing: "sineOut" })).delay(a).union().call((() => {
                    this.mopaiCallback(l, s, r, t);
                })).start();
            }
        }
    }
    mopaiCallback(i, e, t, a, s = []) {
        try {
            let r;
            ToolUtils.isObjValid(i) && (i.active = false, TweenTool.stopNodeAction(i), ToolUtils.isObjValid(i) && this.putCardNode(i));
            for (let i = 0, e = this.paiduiCardVec.length; i < e; i++) {
                r = this.paiduiCardVec[i];
                ToolUtils.isObjValid(r) && (r.setSiblingIndex(i + 1), r.active = !(i < e - 1));
            }
            this.restoreDeckCard(this.paiduiCardVec[this.paiduiCardVec.length - 1]);
            ToolUtils.isObjValid(this.lzCard) && this.lzCard.setSiblingIndex(0);
            0 == this.mopaiPos && (RummyDataManager.shared().rummyInfos.get(this.tid_key).mp_refresh = false, RummyDataManager.shared().rummyInfos.get(this.tid_key).isCanTouchCard = true);
            1 === RummyDataManager.shared().rummyInfos.get(this.tid_key).is_reshuffle && (RummyDataManager.shared().rummyInfos.get(this.tid_key).is_reshuffle = 0);
            0 === this.mopaiPos && (e && e.length > 0 ? (TweenTool.delayAct(this.delay_node, (() => {
                this.beginFaPaiWithoutAnim(e, e.length, null, null, null, false);
            }), game.frameTime / 1000, true), TweenTool.delayAct(this.delay_node, (() => {
                this.callback ? this.callback("freshMyCard", { isCheckCards: true, catch_groupindex: t, cardvalue: a, isShowDiscardTips: true, autoSortGroupIds: s }) : this.beginFaPaiWithoutAnim(RummyDataManager.shared().rummyInfos.get(this.tid_key).cardInfoModelVec, RummyDataManager.shared().rummyInfos.get(this.tid_key).cardInfoModelVec.length, true, t, a, true, s);
            }), 0.5, true)) : TweenTool.delayAct(this.delay_node, (() => {
                this.beginFaPaiWithoutAnim(RummyDataManager.shared().rummyInfos.get(this.tid_key).cardInfoModelVec, RummyDataManager.shared().rummyInfos.get(this.tid_key).cardInfoModelVec.length, null, null, null, true, s);
            }), game.frameTime / 1000, true));
        }
        catch (i) {
        }
    }
    isJokerCard(i) {
        return 78 == i || 79 == i;
    }
    isShowLaiziColor(i, e = 0) {
        if (0 == e && (e = RummyDataManager.shared().rummyInfos.get(this.tid_key).laizicard), 78 == e || 79 == e) {
            if (78 == i || 79 == i || 1 == i || 17 == i || 33 == i || 49 == i) {
                return true;
            }
        }
        else {
            if (78 == i || 79 == i) {
                return true;
            }
            if (e % 16 == i % 16) {
                return true;
            }
        }
        return false;
    }
    resetMyShouPai() {
        this.beginFaPaiWithoutAnim(this.myGroupcardValueVec, this.myGroupcardValueVec.length);
    }
    playOutCallBack(i) {
        if (ToolUtils.isObjValid(i)) {
            i.setSiblingIndex(this.qipaiCards.length);
            for (let i = 0, e = this.qipaiCards.length; i < e; i++) {
                ToolUtils.isObjValid(this.qipaiCards[i]) && (this.qipaiCards[i].setSiblingIndex(i), this.qipaiCards[i].active = false);
            }
            let e = this.getCardNode(), t = e.getComponent("RummyCard");
            t.init(this.qipaiValue, false);
            t.openCard();
            1 == RummyDataManager.shared().rummyInfos.get(this.tid_key).is_bump ? t.showLaiziFlag(this.isShowLaiziColor(this.qipaiValue), false, true) : t.showLaiziFlag(this.isShowLaiziColor(this.qipaiValue));
            e.setScale(this.outcardScale);
            e.setPosition(this.qipaiPoint);
            0 == this.hasQipai && e.setPosition(this.finishPoint);
            e.active = true;
            this.qipai_node.addChild(e);
            this.changeEasyModeOutCardGray(e);
            let a = this.qipaiCards.length;
            e.setSiblingIndex(a);
            this.hasQipai && this.qipaiCards.push(e);
            RummyDataManager.shared().rummyInfos.get(this.tid_key).mp_refresh = false;
            ToolUtils.isObjValid(i) && this.putCardNode(i);
        }
        TweenTool.delayAct(this.delay_node, (() => {
            this.beginFaPaiWithoutAnim(RummyDataManager.shared().rummyInfos.get(this.tid_key).cardInfoModelVec, RummyDataManager.shared().rummyInfos.get(this.tid_key).cardInfoModelVec.length);
        }), game.frameTime / 1000, true);
    }
    playOutCards(i, e, t, a, s, r, d) {
        if (isNaN(e)) {
            return;
        }
        if (e < 0 || e > 5) {
            return;
        }
        this.cancelOpenPileSync();
        if (this.qipaiCards.length > 0) {
            let i = this.qipaiCards.length;
            if (ToolUtils.isObjValid(this.qipaiCards[i - 1])) {
                let e = this.qipaiCards[i - 1].getComponent("RummyCard").mCardValue;
                if (t) {
                    for (let e = 0; e < i; e++) {
                        this.qipaiCards[e].active = false;
                        this.putCardNode(this.qipaiCards[e]);
                    }
                    this.qipaiCards = [];
                    let t = this.getCardNode();
                    this.qipai_node.insertChild(t, 0);
                    let a = t.getComponent("RummyCard");
                    a.init(e, false);
                    a.openCard();
                    1 == RummyDataManager.shared().rummyInfos.get(this.tid_key).is_bump ? a.showLaiziFlag(this.isShowLaiziColor(e), false, true) : a.showLaiziFlag(this.isShowLaiziColor(e));
                    t.setScale(this.outcardScale);
                    t.setPosition(this.qipaiPoint);
                    t.active = true;
                    this.qipaiCards.push(t);
                    this.changeEasyModeOutCardGray(t);
                }
            }
        }
        if (s && s.length > 0 && (this.seeverOpenCards = s), this.hasQipai = t, this.qipaiValue = i, 0 == e) {
            if (RummyDataManager.shared().rummyInfos.get(this.tid_key).mp_refresh = true, t && this.playEffectByName("rummyOutCard"), 0 == RummyDataManager.shared().rummyInfos.get(this.tid_key).hasChupai && t) {
                if (1 == User.shared().isInPerformanceRoom) {
                    let e = null;
                    for (let t = this.cardViewVec.length - 1; t >= 0; t--) {
                        if (ToolUtils.isObjValid(this.cardViewVec[t])) {
                            if (this.cardViewVec[t].getComponent("RummyCard").mCardValue == i) {
                                e = this.cardViewVec[t];
                                break;
                            }
                        }
                    }
                    if (null != e) {
                        let i = this.qipaiPoint;
                        0 == t && (i = this.finishPoint);
                        e.setSiblingIndex(200);
                        this.changeEasyModeOutCardGray(e);
                        let a = 0.15;
                        tween(e).parallel(tween().to(a, { position: i }, { easing: "sineOut" }), tween().to(a, { scale: this.outcardScale })).call((() => {
                            ToolUtils.isObjValid(e) && this.playOutCallBack(e);
                        })).start();
                    }
                    else {
                        let e = this.qipaiPoint;
                        0 == t && (e = this.finishPoint);
                        let a = this.getCardNode(), s = a.getComponent("RummyCard");
                        s.init(i, false);
                        s.openCard();
                        1 == RummyDataManager.shared().rummyInfos.get(this.tid_key).is_bump && t ? s.showLaiziFlag(this.isShowLaiziColor(i), false, true) : s.showLaiziFlag(this.isShowLaiziColor(i));
                        a.setScale(this.outcardScale);
                        a.active = true;
                        a.setPosition(e);
                        this.qipai_node.insertChild(a, this.qipaiCards.length);
                        this.qipaiCards.push(a);
                        this.changeEasyModeOutCardGray(a);
                        TweenTool.delayAct(this.delay_node, (() => {
                            this.beginFaPaiWithoutAnim(RummyDataManager.shared().rummyInfos.get(this.tid_key).cardInfoModelVec, RummyDataManager.shared().rummyInfos.get(this.tid_key).cardInfoModelVec.length);
                        }), game.frameTime / 1000, true);
                    }
                    return;
                }
                let e = this.getSelectedCards();
                if (1 == e.length) {
                    let i = this.qipaiPoint;
                    0 == t && (i = this.finishPoint);
                    e[0].setSiblingIndex(200);
                    this.changeEasyModeOutCardGray(e[0]);
                    let a = 0.15;
                    tween(e[0]).parallel(tween().to(a, { position: i }, { easing: "sineOut" }), tween().to(a, { scale: this.outcardScale })).call((() => {
                        ToolUtils.isObjValid(e[0]) && this.playOutCallBack(e[0]);
                    })).start();
                }
                else {
                    let e = this.qipaiPoint;
                    0 == t && (e = this.finishPoint);
                    let a = this.getCardNode(), s = a.getComponent("RummyCard");
                    s.init(i, false);
                    s.openCard();
                    1 == RummyDataManager.shared().rummyInfos.get(this.tid_key).is_bump && t ? s.showLaiziFlag(this.isShowLaiziColor(i), false, true) : s.showLaiziFlag(this.isShowLaiziColor(i));
                    a.setScale(this.outcardScale);
                    a.active = true;
                    a.setPosition(e);
                    this.qipai_node.insertChild(a, this.qipaiCards.length);
                    this.qipaiCards.push(a);
                    this.changeEasyModeOutCardGray(a);
                    TweenTool.delayAct(this.delay_node, (() => {
                        this.beginFaPaiWithoutAnim(RummyDataManager.shared().rummyInfos.get(this.tid_key).cardInfoModelVec, RummyDataManager.shared().rummyInfos.get(this.tid_key).cardInfoModelVec.length);
                    }), game.frameTime / 1000, true);
                }
            }
            else {
                RummyDataManager.shared().rummyInfos.get(this.tid_key).mp_refresh = false;
                for (let i = 0, e = this.qipaiCards.length; i < e; i++) {
                    ToolUtils.isObjValid(this.qipaiCards[i]) && (this.qipaiCards[i].setSiblingIndex(i), this.qipaiCards[i].active = true, i == this.qipaiCards.length - 1 && this.changeEasyModeOutCardGray(this.qipaiCards[i]));
                }
                let a = this.getCardNode(), s = a.getComponent("RummyCard");
                s.init(i, false);
                s.openCard();
                1 == RummyDataManager.shared().rummyInfos.get(this.tid_key).is_bump && t ? s.showLaiziFlag(this.isShowLaiziColor(i), false, true) : s.showLaiziFlag(this.isShowLaiziColor(i));
                let o = this.qipaiPoint;
                a.setScale(this.outcardScale);
                a.setPosition(o);
                this.qipai_node.insertChild(a, this.qipaiCards.length);
                this.qipaiCards.push(a);
                let h = 0.01;
                if (0 == t) {
                    a.active = false;
                    let t = this.finishPoint;
                    if (1 == RummyDataManager.shared().rummyInfos.get(this.tid_key).hasChupai) {
                        t = this.finishPoint;
                    }
                    else {
                        h = 0.2;
                        let i = this.getShowHuCard(r, d);
                        if (ToolUtils.isObjValid(i)) {
                            let e = new Vec3;
                            i.getPosition(e);
                            t = e;
                        }
                    }
                    this.showHucardAnim(e, i, t, v3(0.8, 0.8, 0.8), this.tid_key);
                }
                else {
                    a.active = true;
                    this.changeEasyModeOutCardGray(a);
                }
                RummyDataManager.shared().rummyInfos.get(this.tid_key).hasChupai = false;
                TweenTool.delayAct(this.delay_node, (() => {
                    this.beginFaPaiWithoutAnim(RummyDataManager.shared().rummyInfos.get(this.tid_key).cardInfoModelVec, RummyDataManager.shared().rummyInfos.get(this.tid_key).cardInfoModelVec.length, false);
                }), h, true);
            }
            this.hasClickCardArea = false;
        }
        else {
            let s = this.getCardNode(), r = s.getComponent("RummyCard");
            if (a ? r.init(i, true) : (r.init(i, false), r.openCard(), 1 == RummyDataManager.shared().rummyInfos.get(this.tid_key).is_bump ? t ? r.showLaiziFlag(this.isShowLaiziColor(i), false, true) : r.showLaiziFlag(this.isShowLaiziColor(i, RummyDataManager.shared().rummyInfos.get(this.tid_key).winLaizicard)) : r.showLaiziFlag(this.isShowLaiziColor(i))), s.setScale(this.mpScale), s.setPosition(v3(this.seatPosVec[e].x, this.seatPosVec[e].y + 14)), this.qipai_node.addChild(s), t) {
                for (let i = 0, e = this.qipaiCards.length; i < e; i++) {
                    ToolUtils.isObjValid(this.qipaiCards[i]) && (this.qipaiCards[i].setSiblingIndex(i), this.qipaiCards[i].active = true, i == this.qipaiCards.length - 1 && this.changeEasyModeOutCardGray(this.qipaiCards[i]));
                }
                s.active = true;
                this.qipaiCards.push(s);
                s.setSiblingIndex(this.qipai_node.children.length);
                let i = 0.3;
                if (5 == e && (i = 0.38), 1 == RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyMode) {
                    let e = s.getChildByName("mask");
                    e.active = true;
                    e.getComponent(UIOpacity).opacity = 0;
                    let t = TweenTool.moveToByFade(e, i, e.getPosition(), 0, 1);
                    tween(e).then(t).start();
                }
                tween(s).parallel(tween().to(i, { position: this.qipaiPoint }, { easing: "sineOut" }), tween().to(i, { scale: this.outcardScale })).call((() => {
                    ToolUtils.isObjValid(s) && this.otherPlayCallBack(s);
                })).start();
            }
            else {
                this.qipaiCards.push(s);
                s.active = false;
                this.showHucardAnim(e, i, v3(this.seatPosVec[e].x, this.seatPosVec[e].y + 14), this.mpScale, this.tid_key);
            }
        }
        let o = sys.localStorage.getItem("card_reading_def");
        if (sys.isObjectValid(o) || (o = User.shared().help_setting.card_reading_def), 1 == User.shared().help_setting.card_reading && 1 == Number(o)) {
            let t = RummyDataManager.shared().getSeatidByPos(e, this.tid_key), a = RummyDataManager.shared().rummyInfos.get(this.tid_key).playerModels[t];
            if (a && this.tid_key == User.shared().curTid_key) {
                let e = 2 == a.sex ? "female" : "male";
                if (this.hasQipai) {
                    if (sys.isObjectValid(i)) {
                        if (78 == i || 79 == i) {
                            SoundManager.shared().playSound(ToolUtils.format("joker_${0}", e), null, null, 0.2);
                        }
                        else {
                            let t = ToolUtils.getCardInfo(i);
                            1 == t.point || t.point > 10 ? SoundManager.shared().playSound(ToolUtils.format("card_${0}_${1}", t.point, e)) : SoundManager.shared().playSound(ToolUtils.format("card_${0}_${1}", t.point, e), null, (() => {
                                let i = "diamond";
                                0 == t.color ? i = "diamond" : 16 == t.color ? i = "club" : 32 == t.color ? i = "heart" : 48 == t.color && (i = "spade");
                                SoundManager.shared().playSound(ToolUtils.format("${0}_${1}", i, e));
                            }), 0.2);
                        }
                    }
                }
                else {
                    TweenTool.delayAct(this.delay_node, (() => {
                        SoundManager.shared().playSound(ToolUtils.format("rummy_win_${0}", e), null, null, 1);
                    }), 0.2, true);
                }
            }
        }
    }
    changeEasyModeOutCardGray(i) {
        if (RummyDataManager.shared().rummyInfos.has(this.tid_key) && 1 == RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyMode && ToolUtils.isObjValid(i)) {
            i.getComponent("RummyCard").setMask(true);
        }
    }
    showHucardAnim(i, e, t, a, s) {
        User.shared().curTid_key === this.tid_key && TransferPlatform.shared().setHighFrameRate();
        let r = e, d = this.getCardNode(), o = RummyDataManager.shared().rummyInfos.get(s), h = o.winLaizicard > 0 ? o.winLaizicard : o.laizicard, l = d.getComponent("RummyCard");
        l.init(r, true);
        l.openCard();
        l.showLaiziFlag(this.isShowLaiziColor(r, h));
        let n = this.finishPoint;
        d.active = true;
        l.showHuAcion(i, t, n, a, s);
        this.hupai_node.addChild(d);
        this.hupaiCardVec.push(d);
        0 == i && o.hasChupai;
        this.arrow_anim_nodes[0].active = false;
        this.arrow_anim_nodes[1].active = false;
        this.arrow_anim_nodes[2].active = false;
        this.arrow_anim_nodes[3].active = false;
    }
    checkShowHupaiAnim(i, e, t, a) {
        (this.hasQipai || i != this.qipaiValue) && (RummyDataManager.shared().rummyInfos.get(this.tid_key).is_showhuAnim_status = false, ToolUtils.isObjValid(this.moveCard) && (this.moveCard.active = false), this.playerHupaiReturn(i, e, t, a, true));
    }
    playerHupaiReturn(i, e, t, a, s = false) {
        if (t && t.length > 0 && (this.seeverOpenCards = t), this.qipaiCards.length > 0) {
            let r = this.qipaiCards[this.qipaiCards.length - 1];
            if (ToolUtils.isObjValid(r)) {
                if (!s) {
                    let e = r.getComponent("RummyCard");
                    e.init(i, false);
                    e.openCard();
                    e.showLaiziFlag(this.isShowLaiziColor(i));
                }
                if (r.setScale(this.outcardScale), 1 == e) {
                    r.setPosition(this.qipaiPoint);
                }
                else if (null != a && 1 == a) {
                    let i = this.getCardNode(), e = i.getComponent("RummyCard");
                    e.init(t[t.length - 1], false);
                    e.openCard();
                    e.showLaiziFlag(this.isShowLaiziColor(this.qipaiValue));
                    i.setScale(this.outcardScale);
                    i.setPosition(this.finishPoint);
                    this.hupai_node.addChild(i);
                    this.hupaiCardVec.push(i);
                    this.hc_anim.node.active = false;
                    this.huPaiPaiduiAnim(false);
                    this.huPaiQiPaiduiAnim(false);
                    TransferPlatform.shared().setNormalFrameRate();
                }
                else {
                    0 == RummyDataManager.shared().rummyInfos.get(this.tid_key).is_showhuAnim_status && (s || (r.active = false), RummyDataManager.shared().rummyInfos.get(this.tid_key).hasChupai = true, RummyDataManager.shared().rummyInfos.get(this.tid_key).is_showhuAnim_status = true, this.showHucardAnim(0, i, this.finishPoint, this.outcardScale, this.tid_key));
                }
            }
        }
        else {
            null != a && a || 0 == RummyDataManager.shared().rummyInfos.get(this.tid_key).is_showhuAnim_status && (RummyDataManager.shared().rummyInfos.get(this.tid_key).hasChupai = true, RummyDataManager.shared().rummyInfos.get(this.tid_key).is_showhuAnim_status = true, this.showHucardAnim(0, i, this.finishPoint, this.outcardScale, this.tid_key));
        }
    }
    HuCardShowFinish(i, e) {
        e && (this.playEffectByName("rummyFlip"), RummyDataManager.shared().rummyInfos.get(this.tid_key).mp_refresh = false, RummyDataManager.shared().rummyInfos.get(this.tid_key).hasChupai = false);
        let t = this.getCardNode(), a = t.getComponent("RummyCard");
        e ? (a.init(i, true), a.openCard(), a.showLaiziFlag(this.isShowLaiziColor(i))) : (a.init(i, false), a.changeCardToBack(), a.showLaiziFlag(this.isShowLaiziColor(i)));
        t.setScale(this.outcardScale);
        t.setPosition(this.finishPoint);
        t.setSiblingIndex(this.qipaiCards.length);
        t.active = true;
        this.qipai_node.addChild(t);
        this.qipaiCards.push(t);
    }
    readyHuCardShowFinish(i, e) {
        let t = this.getCardNode(), a = t.getComponent("RummyCard");
        e ? a.init(i, true) : (a.init(i, false), a.openCard(), a.showLaiziFlag(this.isShowLaiziColor(i)));
        t.setScale(this.outcardScale);
        t.setPosition(this.finishPoint);
        t.setSiblingIndex(this.qipaiCards.length);
        t.active = true;
        this.qipai_node.addChild(t);
        this.qipaiCards.push(t);
    }
    getSelectedCards() {
        let i = [];
        for (let e = 0, t = this.cardViewVec.length; e < t; e++) {
            if (ToolUtils.isObjValid(this.cardViewVec[e])) {
                let t = this.cardViewVec[e].getComponent("RummyCard");
                this.cardViewVec[e].getPosition().y !== this.middlePosY + RummyCardConstant.SelectSpaceY && (t.hasSelected = false);
                t.hasSelected && i.push(this.cardViewVec[e]);
            }
        }
        return i;
    }
    getShowHuCard(i, e) {
        let t = null;
        for (let a = 0, s = this.cardViewVec.length; a < s; a++) {
            if (ToolUtils.isObjValid(this.cardViewVec[a])) {
                let s = this.cardViewVec[a].getComponent("RummyCard");
                if (s.groupIndex == i && s.cardIndex == e) {
                    t = this.cardViewVec[a];
                    break;
                }
            }
        }
        return t;
    }
    groupShoupaiArrange() {
        this.dayingshoupaiData(7);
        let i = this.getSelectedCards();
        if (this.dayingshoupaiData(8), this.handCardDataAnalysis.groupBtnClickAnalysis(this.myGroupcardValueVec, i, RummyDataManager.shared().rummyInfos.get(this.tid_key).laizicard)) {
            let i = this.handCardDataAnalysis.getFinalHandCardData();
            for (let e = 0, t = i.length; e < t; e++) {
                i[e].index = e;
            }
            this.beginFaPaiWithoutAnim(i, i.length);
        }
        else {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.max_group_tips"), 2, 0, ToolUtils.getIsNormalDirection());
        }
    }
    otherPlayCallBack(i) {
        let e;
        this.playEffectByName("rummyOutCard");
        ToolUtils.isObjValid(i) && i.setSiblingIndex(this.qipaiCards.length);
        for (let i = 0, t = this.qipaiCards.length; i < t; i++) {
            e = this.qipaiCards[i];
            ToolUtils.isObjValid(e) && (this.qipaiCards[i].setSiblingIndex(i), i < t - 2 ? this.qipaiCards[i].active = false : (this.qipaiCards[i].active = true, this.changeEasyModeOutCardGray(e)));
        }
    }
    showDropCardsZheZhao(i) {
        let e = this.node.getChildByName("zhezhao");
        ToolUtils.isObjValid(e) && (i ? e.setSiblingIndex(100) : e.setSiblingIndex(0), e.active = i, e.active = false);
    }
    begainLocalFaPaiWithoutAnim(i) {
        if (!(sys.isObjectValid(i) && i.length > 0)) {
            return;
        }
        let e, t = RummyDataManager.shared().rummyInfos.get(this.tid_key);
        if (this.cardViewVec.length > 0) {
            for (let i = 0, t = this.cardViewVec.length; i < t; i++) {
                e = this.cardViewVec[i];
                ToolUtils.isObjValid(e) && (e.removeFromParent(), this.putCardNode(e));
            }
            this.cardViewVec = [];
        }
        if (this.initialCardNodes.length > 0) {
            for (let i = 0, t = this.initialCardNodes.length; i < t; i++) {
                e = this.initialCardNodes[i];
                ToolUtils.isObjValid(e) && this.putCardNode(e);
            }
            this.initialCardNodes = [];
        }
        this.fade_node.removeAllChildren();
        let a = this.middlePosY, s = this.cardStartPosX;
        this.allPaiNum = t.close_cardnum;
        this.allPaiNum <= 0 && (this.allPaiNum = 56);
        let r = i.length, d = 0;
        for (let e = 0; e < r; e++) {
            d += i[e].cardVec.length;
        }
        let o = 2 * RummyCardConstant.cebianW, h = (r - 1) * this.cardSpaceGroup, l = r * this.cardWidth, n = d - r, c = (RummyCardConstant.ScreenWidth - o - h - l) / (1 * n), u = this.cardWidth + RummyCardConstant.CardSpaceGroup - c;
        this.spXpositionDeq = [];
        this.cardsPostions = [];
        let g, p = 0, m = 0, C = a, f = 1 == t.is_bump && t.game_state < 4;
        for (let e = 0; e < r; e++) {
            let t = i[e].cardVec;
            for (let a = 0, d = t.length; a < d; a++) {
                m = s + c * p + e * u;
                let o = this.getCardNode();
                this.shoupaiLayout.addChild(o);
                g = o.getComponent("RummyCard");
                g.init(t[a], false);
                g.setCardSize(this.cardWidth, this.cardHeight);
                g.setCardTag(p);
                g.cardIndex = a;
                g.groupIndex = e;
                g.unSelectedPosY = C;
                g.selectedPosY = C + RummyCardConstant.SelectSpaceY;
                g.setCardTouchAreaX(this.touchCardWidth / 2, this.touchCardWidth / 2);
                g.setCardTouchAreaY(this.cardHeight / 2, this.cardHeight / 2);
                g.hasSelected = false;
                g.rowType = 0;
                g.groupCardVecLenth = t.length;
                g.totalIndex = p;
                g.groupColor = i[e].color;
                g.groupType = i[e].type;
                g.groupText = i[e].desc;
                o.setScale(this.cardScale);
                o.setPosition(v3(m, C));
                o.active = true;
                o.getPosition(g.beforeMovingPos);
                o.setSiblingIndex(p);
                g.openCard();
                g.showLaiziFlag(this.isShowLaiziColor(t[a]), false, f);
                this.cardViewVec.push(o);
                p += 1;
                this.spXpositionDeq.push(m);
                this.cardsPostions.push(v3(m, C));
                e == r - 1 && a == d - 1 ? (g.showNewFlag(true), g.isNewCard = true) : g.isNewCard = false;
            }
        }
    }
    beginFaPaiWithoutAnim(i, e, t = true, a, s, r, d = []) {
        let o, h = RummyDataManager.shared().rummyInfos.get(this.tid_key);
        if (this.changeCardPlayOutLineStatus(false), this.hasFaPaiAnimEnded = true, this.moveCard = null, this.cardViewVec.length > 0) {
            for (let i = 0, e = this.cardViewVec.length; i < e; i++) {
                o = this.cardViewVec[i];
                ToolUtils.isObjValid(o) && this.putCardNode(o);
            }
            this.cardViewVec = [];
        }
        if (this.initialCardNodes.length > 0) {
            for (let i = 0, e = this.initialCardNodes.length; i < e; i++) {
                o = this.initialCardNodes[i];
                ToolUtils.isObjValid(o) && this.putCardNode(o);
            }
            this.initialCardNodes = [];
        }
        for (let i = 0, e = this.availableFlagNodes.length; i < e; i++) {
            ToolUtils.isObjValid(this.availableFlagNodes[i]) && this.putAvailableFlagNode(this.availableFlagNodes[i]);
        }
        this.availableFlagNodes = [];
        this.availabeFlagInfos = [];
        this.cardValueVec = [];
        this.initialCardNodes = [];
        this.shoupaiLayout.removeAllChildren();
        this.fade_node.removeAllChildren();
        let l = this.middlePosY, n = this.cardStartPosX;
        this.allPaiNum = h.close_cardnum;
        this.allPaiNum <= 0 && (this.allPaiNum = 56);
        this.myGroupcardValueVec = i;
        let c = i.length;
        for (let e = 0; e < c; e++) {
            let t = i[e].cardVec;
            for (let i = 0, e = t.length; i < e; i++) {
                this.cardValueVec.push(t[i]);
            }
        }
        let u = this.cardValueVec.length, g = 2 * RummyCardConstant.cebianW, p = (c - 1) * this.cardSpaceGroup, m = c * this.cardWidth, C = u - c, f = (RummyCardConstant.ScreenWidth - g - p - m) / (1 * C), V = this.cardWidth + RummyCardConstant.CardSpaceGroup - f;
        this.spXpositionDeq = [];
        this.cardsPostions = [];
        let b, w = 0, P = 0, S = l;
        h.newCardValue = 0;
        let v = 1 == h.is_bump && h.game_state < 4;
        for (let e = 0; e < c; e++) {
            let t = i[e].cardVec, r = [];
            for (let a = 0, s = t.length; a < s; a++) {
                P = n + f * w + e * V;
                let s = this.getCardNode();
                this.shoupaiLayout.addChild(s);
                b = s.getComponent("RummyCard");
                b.init(t[a], false);
                b.setCardSize(this.cardWidth, this.cardHeight);
                b.setCardTag(w);
                b.cardIndex = a;
                b.groupIndex = e;
                b.unSelectedPosY = S;
                b.selectedPosY = S + RummyCardConstant.SelectSpaceY;
                b.setCardTouchAreaX(this.touchCardWidth / 2, this.touchCardWidth / 2);
                b.setCardTouchAreaY(this.cardHeight / 2, this.cardHeight / 2);
                b.hasSelected = false;
                b.rowType = 0;
                b.groupCardVecLenth = t.length;
                b.totalIndex = w;
                b.groupColor = i[e].color;
                b.groupType = i[e].type;
                b.groupText = i[e].desc;
                s.setScale(this.cardScale);
                s.setPosition(v3(P, S));
                s.active = true;
                s.getPosition(b.beforeMovingPos);
                s.setSiblingIndex(w);
                b.openCard();
                b.showLaiziFlag(this.isShowLaiziColor(t[a]), false, v);
                this.cardViewVec.push(s);
                r.push(s);
                w += 1;
                this.spXpositionDeq.push(P);
                this.cardsPostions.push(v3(P, S));
                1 == i[e].isCatchGroup && i[e].catchIndex == a ? (1 == h.isAbleAutoGroup && b.showNewFlag(true), b.isNewCard = true, h.newCardValue = t[a]) : b.isNewCard = false;
                b.setMask(1 == h.dropType);
            }
            e == a && e != c - 1 && this.refreshGroupInfo(r, s);
        }
        let I = sys.localStorage.getItem("discard_def");
        null == I && (I = User.shared().help_setting.discard_def);
        1 != User.shared().help_setting.discard || null == I || 0 == Number(I) || null != r && 1 != r || this.showDiscardTips();
        this.refreshAllGroupInfo(d);
        this.callback && t && this.callback("checkCards");
        sys.isObjectValid(this.tipCardMsg) && this.refreshTipCard(this.tipCardMsg);
    }
    refreshGroupInfo(i, e) {
        let t, a, s = null;
        for (let r = i.length - 1; r >= 0; r--) {
            t = 0;
            let d = new Vec3;
            i[r].getPosition(d);
            a = i[r].getComponent(RummyCard).getCardValue();
            null == s && a == e && (s = r);
            null != s ? r < s && (t = -15) : t = 15;
            let o = TweenTool.moveTo(i[r], 0.2, v3(d.x + t, d.y), "linear", false), h = TweenTool.moveTo(i[r], 0.2, d, "linear", false);
            TweenTool.sequence(i[r], true, (() => {
                if (0 == r) {
                    let i = { check_quick: true };
                    this.tingpaiCallback && this.tingpaiCallback(i);
                }
            }), o, h);
        }
    }
    showPaiduiCards() {
        if (this.paiduiCardVec.length > 0) {
            for (let i = 0, e = this.paiduiCardVec.length; i < e; i++) {
                ToolUtils.isObjValid(this.paiduiCardVec[i]) && this.putCardNode(this.paiduiCardVec[i]);
            }
        }
        let i, e;
        this.paiduiCardVec = [];
        this.allPaiNum = RummyDataManager.shared().rummyInfos.get(this.tid_key).close_cardnum;
        for (let t = 0; t < this.allPaiNum; t++) {
            i = this.getCardNode();
            e = i.getComponent("RummyCard");
            e.refreshcardbg("rummy_card_bg_0" + User.shared().styles[2]);
            e.init(1, true);
            e.setCardTag(t);
            i.setScale(this.outcardScale);
            t < this.allPaiNum - 1 ? i.active = false : i.active = true;
            i.setPosition(this.paiduiPoint);
            this.paidui_node.addChild(i);
            i.setSiblingIndex(t + 1);
            this.paiduiCardVec.push(i);
        }
        ToolUtils.isObjValid(this.lzCard) && this.lzCard.setSiblingIndex(0);
    }
    showLaiziCard(i) {
        if (i) {
            if (this.playEffectByName("rummyFlip"), this.paiduiCardVec.length > 0) {
                let i;
                for (let e = 0, t = this.paiduiCardVec.length; e < t; e++) {
                    i = this.paiduiCardVec[e];
                    ToolUtils.isObjValid(i) && (i.active = true, TweenTool.moveTo(i, 0.3, this.paiduiPoint, null, true, (() => {
                        ToolUtils.isObjValid(i) && this.paiduiMoveCallBack(i);
                    })));
                }
            }
        }
        else {
            let i, e;
            for (let t = 0, a = this.paiduiCardVec.length; t < a; t++) {
                i = this.paiduiCardVec[t];
                ToolUtils.isObjValid(i) && (e = i.getComponent("RummyCard"), e.setCardTag(t), i.setPosition(this.paiduiPoint), i.active = !(t < a - 1), e.changeCardToBack());
            }
            if (this.paiduiCardVec.length > 0) {
                ToolUtils.isObjValid(this.lzCard) || (this.lzCard = this.getCardNode(), e = this.lzCard.getComponent("RummyCard"), 1 == RummyDataManager.shared().rummyInfos.get(this.tid_key).is_bump ? (e.init(RummyDataManager.shared().rummyInfos.get(this.tid_key).laiziFlopCard, false, 3), e.openCard(), e.showLaiziFlag(this.isShowLaiziColor(RummyDataManager.shared().rummyInfos.get(this.tid_key).laizicard), true, true)) : (e.init(RummyDataManager.shared().rummyInfos.get(this.tid_key).laiziFlopCard, false), e.openCard(), e.showLaiziFlag(this.isShowLaiziColor(RummyDataManager.shared().rummyInfos.get(this.tid_key).laizicard), true)), this.lzCard.setScale(this.outcardScale), this.lzCard.setPosition(this.laiziPoint), this.lzCard.angle = 90, this.lzCard.active = true, this.paidui_node.addChild(this.lzCard));
                for (let i = 0, e = this.paiduiCardVec.length; i < e; i++) {
                    ToolUtils.isObjValid(this.paiduiCardVec[i]) && this.paiduiCardVec[i].setSiblingIndex(i + 1);
                }
                this.lzCard.setSiblingIndex(0);
            }
        }
    }
    paiduiMoveCallBack(i) {
        if (ToolUtils.isObjValid(i)) {
            i.setPosition(this.paiduiPoint);
            i.getComponent("RummyCard").getCardTag() != this.paiduiCardVec.length - 1 || this.is_fapai_over || (this.is_fapai_over = true, TweenTool.delayAct(this.delay_node, (() => {
                this.lzCardReset(i);
            }), 0.5, true));
        }
    }
    lzCardReset(i) {
        let e, t;
        if (ToolUtils.isObjValid(i)) {
            for (let i = 0, t = this.paiduiCardVec.length; i < t; i++) {
                e = this.paiduiCardVec[i];
                ToolUtils.isObjValid(e) && (e.setPosition(this.paiduiPoint), e.active = true);
            }
            if (this.paiduiCardVec.length > 0) {
                ToolUtils.isObjValid(this.lzCard) || (this.lzCard = this.getCardNode(), t = this.lzCard.getComponent("RummyCard"), t.init(RummyDataManager.shared().rummyInfos.get(this.tid_key).laiziFlopCard, false), t.openCard(), t.showLaiziFlag(this.isShowLaiziColor(RummyDataManager.shared().rummyInfos.get(this.tid_key).laizicard), true), this.lzCard.setScale(this.outcardScale), this.lzCard.setPosition(this.laiziPoint), this.lzCard.angle = 90, this.lzCard.active = true, this.paidui_node.insertChild(this.lzCard, 0));
                for (let i = 0, e = this.paiduiCardVec.length; i < e; i++) {
                    ToolUtils.isObjValid(this.paiduiCardVec[i]) && (this.paiduiCardVec[i].setSiblingIndex(i + 1), this.paiduiCardVec[i].active = true, t = this.paiduiCardVec[i].getComponent("RummyCard"), t.changeCardToBack());
                }
                this.lzCard.setSiblingIndex(0);
                for (let i = 0, t = this.paiduiCardVec.length; i < t; i++) {
                    e = this.paiduiCardVec[i];
                    ToolUtils.isObjValid(e) && ToolUtils.isObjValid(this.lzCard) && (e.getSiblingIndex(), this.lzCard.getSiblingIndex());
                }
            }
            for (let i = 0, e = this.cardViewVec.length; i < e; i++) {
                ToolUtils.isObjValid(this.cardViewVec[i]) && (t = this.cardViewVec[i].getComponent("RummyCard"), t.openCard(), t.showLaiziFlag(this.isShowLaiziColor(t.mCardValue)));
            }
            this.callback && this.callback("faPai_Over");
        }
    }
    cancelOpenPileSync() {
        if (this._openPileSync) this.unschedule(this._openPileSync);
        this._openPileSync = null;
    }
    syncOpenPile(cards) {
        this.cancelOpenPileSync();
        if (!Array.isArray(cards)) return;
        const values = cards.slice(), tid = this.tid_key;
        if (values.some(value => !Number.isInteger(value) || value <= 0 || value > 79)) return;
        const info = RummyDataManager.shared().rummyInfos.get(tid);
        if (!info) return;
        const topValue = values.length > 0 ? values[values.length - 1] : 0;
        const reconcile = () => {
            if (this._openPileSync !== reconcile) return;
            if (this.tid_key !== tid || RummyDataManager.shared().rummyInfos.get(tid) !== info ||
                !ToolUtils.isObjValid(this.qipai_node) || info.dc_card !== topValue ||
                info.is_showhuAnim_status || info.game_state === 5) {
                this.cancelOpenPileSync();
                return;
            }
            // Keep normal deal, pick, discard and reshuffle animations intact.
            if (this.is_shuffle || !this.hasFaPaiAnimEnded || !this._localPickAnimEnd || info.bHasLocalPickUp) {
                return;
            }
            this.cancelOpenPileSync();
            // Stale references may already belong to a hand or the node pool.
            this.qipaiCards = this.qipaiCards.filter(card => ToolUtils.isObjValid(card) && card.parent === this.qipai_node);
            if (values.length === 0) {
                for (const card of this.qipaiCards) this.putCardNode(card);
                this.qipaiCards = [];
                return;
            }
            const top = this.qipaiCards[this.qipaiCards.length - 1];
            if (!top || top.getComponent("RummyCard").mCardValue !== topValue) {
                this.showQipaiWithAnim(values);
                return;
            }
            TweenTool.stopNodeAction(top);
            const card = top.getComponent("RummyCard");
            card.initChangeOpacity(255);
            card.openCard();
            top.active = true;
            top.setPosition(this.qipaiPoint);
            top.setScale(this.outcardScale);
            top.setSiblingIndex(this.qipai_node.children.length - 1);
            this.changeEasyModeOutCardGray(top);
        };
        this._openPileSync = reconcile;
        // The longest normal pick/discard tween is 0.65s. Engine time also pauses
        // in the background, so its animation cannot be overtaken by wall time.
        this.schedule(reconcile, 0.2, undefined, 0.75);
    }
    showQipaiWithAnim(i) {
        this.cancelOpenPileSync();
        if (i.length > 0) {
            if (this.qipaiCards.length > 0) {
                for (let i = 0, e = this.qipaiCards.length; i < e; i++) {
                    ToolUtils.isObjValid(this.qipaiCards[i]) && this.putCardNode(this.qipaiCards[i]);
                }
            }
            let e, t;
            this.qipaiCards = [];
            let a = RummyDataManager.shared().rummyInfos.get(this.tid_key);
            for (let s = 0, r = i.length; s < r; s++) {
                e = this.getCardNode();
                t = e.getComponent("RummyCard");
                t.init(i[s], false);
                t.openCard();
                1 == a.is_bump ? a.winLaizicard > 0 ? t.showLaiziFlag(this.isShowLaiziColor(i[s], a.winLaizicard)) : t.showLaiziFlag(this.isShowLaiziColor(i[s]), false, true) : t.showLaiziFlag(this.isShowLaiziColor(i[s]));
                e.setPosition(this.qipaiPoint);
                e.setScale(this.outcardScale);
                e.active = false;
                (1 == i.length || s >= i.length - 2) && (e.active = true, this.changeEasyModeOutCardGray(e));
                this.qipai_node.insertChild(e, s);
                this.qipaiCards.push(e);
            }
        }
    }
    isOneOnlyPureCard() {
        let i = false, e = 0, t = false, a = [];
        for (let i = 0, e = this.myGroupcardValueVec.length; i < e; i++) {
            a.push(this.myGroupcardValueVec[i]);
        }
        let s = RummyDataManager.shared().rummyInfos.get(this.tid_key).groupIndex;
        if (RummyDataManager.shared().rummyInfos.get(this.tid_key).bHandCardSynchronous) {
            for (let i = 0, r = a.length; i < r && !(a[i].type == RUMMY_CARD_GROUP_TYPE.eGroup_PureSeq && (e++, s == i && (t = true), e > 1)); i++) {
                ;
            }
        }
        else {
            for (let i = 0, r = a.length; i < r; i++) {
                let r = a[i];
                if (r.cardVec.length > 0) {
                    if (RummyDataManager.shared().isPureSeq(r.cardVec) && (e += 1, s == i && (t = true), e > 1)) {
                        break;
                    }
                }
            }
        }
        if (t && 1 == e) {
            let e = [], t = a[s];
            t && t.cardVec && (e = t.cardVec);
            let r = e, d = [];
            if (r.length > 0) {
                let i = false, e = RummyDataManager.shared().rummyInfos.get(this.tid_key).playCardValue;
                for (let t = 0, a = r.length; t < a; t++) {
                    i ? d.push(r[t]) : r[t] == e ? i = true : d.push(r[t]);
                }
            }
            RummyDataManager.shared().isPureSeq(d) || (i = true);
        }
        return i;
    }
    updateLast3Card() {
        this.bShowLast3Cards && (this.hideLast3Cards(), this.showLast3Cards());
    }
    showLast3Cards() {
        let i, e, t, a, s, r, d = [], o = [], h = RummyDataManager.shared().rummyInfos.get(this.tid_key), l = h.playerGiveCards;
        for (let n = 0, c = l.length; n < c; n++) {
            let c = l[n];
            if (c && c.cards.length > 0) {
                t = RummyDataManager.shared().getPosBySeatid(c.seatid, this.tid_key);
                d = [];
                o = [];
                r = v3(this.seatPosVec[t].x, 0 == t ? this.seatPosVec[t].y - 10 : this.seatPosVec[t].y);
                c.cards.length >= 3 ? (a = c.cards.length - 3, d[0] = v3(r.x - 16, r.y + 12), d[1] = v3(r.x, r.y + 14), d[2] = v3(r.x + 16, r.y + 9), o[0] = v3(0, 0, 10), o[1] = v3(0, 0, 0), o[2] = v3(0, 0, -10)) : (a = 0, 2 == c.cards.length ? (d[0] = v3(r.x - 10, r.y + 13), d[1] = v3(r.x + 10, r.y + 13), o[0] = v3(0, 0, 5), o[1] = v3(0, 0, -5)) : (d[0] = v3(r.x, r.y + 14), o[0] = v3(0, 0, 0)));
                s = 0;
                for (let r = a, l = c.cards.length; r < l; r++) {
                    i = this.getCardNode();
                    e = i.getComponent("RummyCard");
                    this.testShoupaiLayout.addChild(i);
                    e.init(c.cards[r].value, true);
                    e.openCard();
                    1 == h.is_bump ? e.showLaiziFlag(this.isShowLaiziColor(c.cards[r].value), false, true) : e.showLaiziFlag(this.isShowLaiziColor(c.cards[r].value));
                    e.setMask(1 == c.cards[r].is_catch);
                    i.setScale(this.mpScale);
                    i.setPosition(d[s]);
                    i.setRotationFromEuler(o[s]);
                    i.active = true;
                    this.last3CardsVec[t].push(i);
                    s++;
                }
            }
        }
        this.bShowLast3Cards = true;
    }
    hideLast3Cards() {
        for (let i = 0; i < 6; i++) {
            if (sys.isObjectValid(this.last3CardsVec[i]) && this.last3CardsVec[i].length > 0) {
                for (let e = 0, t = this.last3CardsVec[i].length; e < t; e++) {
                    ToolUtils.isObjValid(this.last3CardsVec[i][e]) && (this.last3CardsVec[i][e].setRotationFromEuler(v3(0, 0, 0)), this.putCardNode(this.last3CardsVec[i][e]));
                }
            }
            this.last3CardsVec[i] = [];
        }
        this.bShowLast3Cards = false;
    }
    startClickCountDown() {
        this.clickDelayAct = TweenTool.delayAct(this.delay_node, (() => {
            this.showLast3Cards();
        }), RummyCardConstant.show3CardDelay, true);
    }
    deleteClickCountDown() {
        this.clickDelayAct && TweenTool.stopAction(this.clickDelayAct);
        this.clickDelayAct = null;
        this.hideLast3Cards();
    }
    onTouchBegan(i) {
        try {
            if (1 == User.shared().isInPerformanceRoom) {
                return;
            }
            let e = v3(0, 0), t = i.getUILocation();
            if (this.shoupaiLayout.inverseTransformPoint(e, v3(t.x, t.y, 0)), !this.hasFaPaiAnimEnded) {
                return;
            }
            if (0 == RummyDataManager.shared().rummyInfos.get(this.tid_key).isInGameing) {
                return;
            }
            let a, s, r = this.cardViewVec.length - 1, d = v3(e.x, e.y);
            for (; r > -1 && (a = this.cardViewVec[r], !ToolUtils.isObjValid(a) || (s = a.getComponent("RummyCard"), !s.isContainPos(d, this._diffY)));) {
                r -= 1;
            }
            if (-1 == r && !RummyDataManager.shared().rummyInfos.get(this.tid_key).bIsHasHu) {
                let i = 0;
                GameConfig.REAL_SCREEN_HEIGHT > 1280 && (i = (GameConfig.REAL_SCREEN_HEIGHT - 1280) / 2);
                let e = rect(i - 60, 90, 1400, 500), t = v3();
                this.shoupaiLayout.inverseTransformPoint(t, d);
                let a = v2(t.x, t.y);
                t.x < 0 && (a.x = GameConfig.REAL_SCREEN_HEIGHT + t.x);
                t.y < 0 && (a.y = GameConfig.REAL_SCREEN_WIDTH + t.y);
                e.contains(a) && this.startClickCountDown();
            }
            if (RummyDataManager.shared().rummyInfos.get(this.tid_key).hasChupai) {
                return;
            }
            if (0 == RummyDataManager.shared().rummyInfos.get(this.tid_key).isCanTouchCard) {
                return;
            }
            if (RummyDataManager.shared().rummyInfos.get(this.tid_key).isPlayingCard) {
                return;
            }
            if (this.hasClickCardArea) {
                return;
            }
            if (this.is_shuffle) {
                if (13 != this.cardViewVec.length) {
                    return void (User.shared().curTid_key == this.tid_key && Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text73"), 1.5, 0, ToolUtils.getIsNormalDirection()));
                }
                this.is_shuffle = false;
            }
            this.isMove = false;
            this.lastSelectedCardIndex = -1;
            this.hasClickCardArea = false;
            let o = this.cardViewVec.length - 1, h = v3(t.x, t.y);
            if (r > -1 && !this.hasClickCardArea) {
                a = this.cardViewVec[r];
                this.moveCard = a;
                this.lastZorder = a.getSiblingIndex();
                let i = new Vec3;
                a.getPosition(i);
                this.lastPosX = i.x;
                this.lastPoint = v3(i.x, i.y);
                this.hasClickCardArea = true;
                this.lastSelectedCardIndex = r;
                this.lastTouchPoint = v3();
                this.shoupaiLayout.inverseTransformPoint(this.lastTouchPoint, h);
                s.changeCardSelectedStatus(true);
                this.moveValue = s.mCardValue;
                this.touchCardMove = false;
                this.touchCardMoveReduction = true;
            }
            else {
                for (; o > -1;) {
                    if (a = this.cardViewVec[o], ToolUtils.isObjValid(a) && (s = a.getComponent("RummyCard"), s.isContainPos(d, this._diffY) && !this.hasClickCardArea)) {
                        this.moveCard = a;
                        this.lastZorder = a.getSiblingIndex();
                        let i = new Vec3;
                        a.getPosition(i);
                        this.lastPosX = i.x;
                        this.lastPoint = v3(i.x, i.y);
                        this.hasClickCardArea = true;
                        this.lastSelectedCardIndex = o;
                        this.lastTouchPoint = v3();
                        this.shoupaiLayout.inverseTransformPoint(this.lastTouchPoint, h);
                        s.changeCardSelectedStatus(true);
                        this.moveValue = s.mCardValue;
                        this.touchCardMove = false;
                        this.touchCardMoveReduction = true;
                        break;
                    }
                    o -= 1;
                }
            }
        }
        catch (i) {
            TLog.printError("-------- RummyGameCards onTouchBegan error!");
        }
    }
    onTouchMoved(i) {
        try {
            let e = i.getUILocation();
            if (1 == User.shared().isInPerformanceRoom) {
                return;
            }
            if (!this.hasFaPaiAnimEnded) {
                return;
            }
            if (0 == RummyDataManager.shared().rummyInfos.get(this.tid_key).isInGameing) {
                return;
            }
            if (RummyDataManager.shared().rummyInfos.get(this.tid_key).hasChupai) {
                return;
            }
            if (0 == RummyDataManager.shared().rummyInfos.get(this.tid_key).isCanTouchCard) {
                return;
            }
            if (RummyDataManager.shared().rummyInfos.get(this.tid_key).isPlayingCard) {
                return;
            }
            if (!this.hasClickCardArea) {
                return;
            }
            let t = v3(e.x, e.y), a = this.lastTouchPoint, s = v3();
            if (this.shoupaiLayout.inverseTransformPoint(s, t), !a) {
                return;
            }
            let r = s.x - a.x, d = s.y - a.y, o = Math.abs(r), h = Math.abs(d);
            this.isMove = true;
            let l = r + this.lastPoint.x, n = d + this.lastPoint.y;
            if (ToolUtils.isObjValid(this.moveCard)) {
                RummyDataManager.shared().rummyInfos.get(this.tid_key).isMovingCard = true;
                let i = new Vec3;
                this.moveCard.getPosition(i);
                this.moveCard.setPosition(v3(l, n));
                let e = l - this.lastPoint.x, t = n - this.lastPoint.y, a = Math.abs(e), s = Math.abs(t);
                if ((a >= 20 || s >= 20) && (this.touchCardMove = true), o > 5 || h > 5) {
                    if (n < RummyCardConstant.tuodongCardHeight) {
                        let e = i.x - l;
                        Math.abs(e) > 1 && (i.x > l ? this.touchCardDirection = 2 : this.touchCardDirection = 1);
                        this.touchCardMoveReduction = true;
                        14 == this.cardViewVec.length && n >= RummyCardConstant.chuCardHeight ? this.chupaiMoveCard() : this.refreshMoveCardsPosition();
                    }
                    else {
                        this.touchCardMoveReduction && (14 == this.cardViewVec.length ? this.chupaiMoveCard() : this.reductionMoveCard());
                    }
                    if (14 == this.cardViewVec.length) {
                        let i = n, e = l;
                        i >= -80 ? this.changeCardPlayOutLineStatus(true) : this.changeCardPlayOutLineStatus(false);
                        i >= RummyCardConstant.chuCardHeight ? e >= -80 && e <= 80 ? this.showCopyCard(true, true) : e < -80 || e > 80 ? this.showCopyCard(true, false) : this.showCopyCard(false) : this.showCopyCard(false);
                    }
                }
            }
        }
        catch (i) {
            TLog.printError("-------- RummyGameCards onTouchMoved error!");
        }
    }
    refreshMoveCardsPosition() {
        if (!this.moveCard || !this.moveCard) {
            return;
        }
        let i = this.moveCard.getComponent("RummyCard"), e = new Vec3;
        this.moveCard.getPosition(e);
        let t = this.myGroupcardValueVec.length;
        1 == i.groupCardVecLenth && (t -= 1);
        let a = this.middlePosY, s = this.cardStartPosX;
        this.allPaiNum = RummyDataManager.shared().rummyInfos.get(this.tid_key).close_cardnum;
        this.allPaiNum <= 0 && (this.allPaiNum = 56);
        let r, d, o = this.cardViewVec.length, h = 2 * RummyCardConstant.cebianW, l = (t - 1) * this.cardSpaceGroup, n = t * this.cardWidth, u = o - t, m = (RummyCardConstant.ScreenWidth - h - l - n) / (1 * u), C = this.cardWidth + RummyCardConstant.CardSpaceGroup - m, y = m / 2, P = 0, S = a, v = 0, I = false, x = false, A = false, N = new Vec3;
        for (let t = 0; t < o; t++) {
            if (r = this.cardViewVec[t].getComponent("RummyCard"), this.cardViewVec[t].getPosition(N), r.totalIndex != i.totalIndex) {
                if (d = e.x - N.x, Math.abs(d) < y) {
                    v = t;
                    I = true;
                    break;
                }
                if (1 == this.touchCardDirection) {
                    if (0 == r.cardIndex && (d = e.x - N.x, Math.abs(d) < this.cardWidth - 40)) {
                        if (i.fromToGroupIndex && null != i.fromToGroupIndex) {
                            if (i.fromToGroupIndex != r.groupIndex) {
                                v = t;
                                I = true;
                                x = true;
                                break;
                            }
                        }
                        else if (i.groupIndex != r.groupIndex) {
                            v = t;
                            I = true;
                            x = true;
                            break;
                        }
                    }
                }
                else if (r.cardIndex == r.groupCardVecLenth - 1 && (d = e.x - N.x, Math.abs(d) < this.cardWidth - 40)) {
                    if (i.fromToGroupIndex && null != i.fromToGroupIndex) {
                        if (i.fromToGroupIndex != r.groupIndex) {
                            v = t;
                            I = true;
                            x = true;
                            break;
                        }
                    }
                    else if (i.groupIndex != r.groupIndex) {
                        v = t;
                        I = true;
                        x = true;
                        break;
                    }
                }
            }
        }
        e.x < s - 20 && (I = true, v = 0, A = true);
        e.x > 0 - s + 20 && (I = true, v = o - 1, A = true);
        let z = e.x - this.lastPoint.x, F = e.y - this.lastPoint.y, O = Math.abs(z), q = Math.abs(F);
        if ((O >= 20 || q >= 20) && 14 == o && !I) {
            let t = 1280, a = 0, s = 0, d = true;
            for (let e = 0; e < o; e++) {
                if (r = this.cardViewVec[e].getComponent("RummyCard"), r.totalIndex != i.totalIndex) {
                    let t, r = e + 1, h = false;
                    if (r < o) {
                        t = this.cardViewVec[r];
                        t.getComponent("RummyCard").totalIndex == i.totalIndex ? (r = e + 2, r < o && (t = this.cardViewVec[r], h = true)) : h = true;
                    }
                    if (h && ToolUtils.isObjValid(t)) {
                        let i = this.cardViewVec[e].getPosition(), r = t.getPosition().x - i.x;
                        0 == a ? a = r : Math.abs(a - r) < 1 || (0 == s ? s = r : Math.abs(s - r) < 1 || (d = false));
                    }
                }
            }
            let h, l = 0;
            for (let e = 0; e < o; e++) {
                if (r = this.cardViewVec[e].getComponent("RummyCard"), l = 0, 0 == e) {
                    h = r.totalIndex == i.totalIndex ? this.cardViewVec[e + 1] : this.cardViewVec[e];
                    ToolUtils.isObjValid(h) && (l = h.getPosition().x);
                    let t = l + RummyCardConstant.lastCardPosx;
                    d = Math.abs(t) < 3;
                }
                if (e == o - 1) {
                    h = r.totalIndex == i.totalIndex ? this.cardViewVec[e - 1] : this.cardViewVec[e];
                    ToolUtils.isObjValid(h) && (l = h.getPosition().x);
                    let t = l + RummyCardConstant.lastCardPosx;
                    d = Math.abs(t) < 3;
                }
            }
            if (d) {
                let a;
                for (let s = 0; s < o; s++) {
                    r = this.cardViewVec[s].getComponent("RummyCard");
                    this.cardViewVec[s].getPosition(N);
                    r.totalIndex != i.totalIndex && (a = e.x - N.x, Math.abs(t) > Math.abs(a) && (t = a, v = s, I = true, x = true));
                }
            }
        }
        if (I) {
            let a = [], d = [], h = 0;
            for (let t = 0; t < o; t++) {
                if (r = this.cardViewVec[t].getComponent("RummyCard"), h = s + m * P + r.groupIndex * C, 1 == i.groupCardVecLenth && r.groupIndex > i.groupIndex && (h = s + m * P + (r.groupIndex - 1) * C), this.cardViewVec[t].getPosition(N), r.totalIndex != i.totalIndex) {
                    if (v == t) {
                        if (A) {
                            0 == v ? (this.moveCard.setSiblingIndex(P), i.fromToGroupIndex = r.groupIndex, i.fromToCardIndex = r.cardIndex, i.AfterMovingPos = v3(h, S), d.push(h), P += 1, h = s + m * P + r.groupIndex * C, 1 == i.groupCardVecLenth && r.groupIndex > i.groupIndex && (h = s + m * P + (r.groupIndex - 1) * C), this.cardViewVec[t].setSiblingIndex(P), this.cardViewVec[t].setPosition(v3(h, S)), d.push(h)) : (this.cardViewVec[t].setSiblingIndex(P), this.cardViewVec[t].setPosition(v3(h, S)), d.push(h), P += 1, h = s + m * P + r.groupIndex * C, 1 == i.groupCardVecLenth && r.groupIndex > i.groupIndex && (h = s + m * P + (r.groupIndex - 1) * C), this.moveCard.setSiblingIndex(P), i.fromToGroupIndex = r.groupIndex, i.fromToCardIndex = r.cardIndex + 1, i.AfterMovingPos = v3(h, S), d.push(h));
                        }
                        else if (e.x > N.x) {
                            x ? (this.cardViewVec[t].setSiblingIndex(P), this.cardViewVec[t].setPosition(v3(h, S)), d.push(h), P += 1, h = s + m * P + r.groupIndex * C, 1 == i.groupCardVecLenth && r.groupIndex > i.groupIndex && (h = s + m * P + (r.groupIndex - 1) * C), this.moveCard.setSiblingIndex(P), i.fromToGroupIndex = r.groupIndex, i.fromToCardIndex = r.cardIndex + 1, i.AfterMovingPos = v3(h, S), d.push(h)) : (this.moveCard.setSiblingIndex(P), i.fromToGroupIndex = r.groupIndex, i.fromToCardIndex == r.cardIndex ? i.fromToCardIndex = r.cardIndex - 1 : i.fromToCardIndex = r.cardIndex, i.fromToCardIndex < 0 && (i.fromToCardIndex = 0), i.AfterMovingPos = v3(h, S), d.push(h), P += 1, h = s + m * P + r.groupIndex * C, 1 == i.groupCardVecLenth && r.groupIndex > i.groupIndex && (h = s + m * P + (r.groupIndex - 1) * C), this.cardViewVec[t].setSiblingIndex(P), this.cardViewVec[t].setPosition(v3(h, S)), d.push(h));
                        }
                        else if (x) {
                            this.moveCard.setSiblingIndex(P);
                            i.fromToGroupIndex = r.groupIndex;
                            i.fromToCardIndex = r.cardIndex;
                            let e = s + m * P + r.groupIndex * C;
                            i.AfterMovingPos = v3(e, S);
                            d.push(e);
                            P += 1;
                            h = s + m * P + r.groupIndex * C;
                            1 == i.groupCardVecLenth && r.groupIndex > i.groupIndex && (h = s + m * P + (r.groupIndex - 1) * C);
                            this.cardViewVec[t].setPosition(v3(h, S));
                            d.push(h);
                            this.cardViewVec[t].setSiblingIndex(P);
                        }
                        else {
                            this.cardViewVec[t].setPosition(v3(h, S));
                            d.push(h);
                            this.cardViewVec[t].setSiblingIndex(P);
                            P += 1;
                            this.moveCard.setSiblingIndex(P);
                            i.fromToGroupIndex = r.groupIndex;
                            i.groupIndex != r.groupIndex ? i.fromToCardIndex = r.cardIndex + 1 : i.fromToCardIndex = r.cardIndex;
                            let e = s + m * P + r.groupIndex * C;
                            1 == i.groupCardVecLenth && r.groupIndex > i.groupIndex && (e = s + m * P + (r.groupIndex - 1) * C);
                            i.AfterMovingPos = v3(e, S);
                            d.push(e);
                        }
                        a[r.groupIndex] ? (a[r.groupIndex].cardVec || (a[r.groupIndex].cardVec = []), a[r.groupIndex].cardVec.push(i.mCardValue)) : (a[r.groupIndex] = {}, a[r.groupIndex].cardVec || (a[r.groupIndex].cardVec = []), a[r.groupIndex].cardVec.push(i.mCardValue));
                    }
                    else {
                        this.cardViewVec[t].setPosition(v3(h, S));
                        d.push(h);
                        this.cardViewVec[t].setSiblingIndex(P);
                    }
                    a[r.groupIndex] ? (a[r.groupIndex].cardVec || (a[r.groupIndex].cardVec = []), a[r.groupIndex].cardVec.push(i.mCardValue), a[r.groupIndex].color = r.groupColor, a[r.groupIndex].groupText = r.groupText) : (a[r.groupIndex] = {}, a[r.groupIndex].cardVec || (a[r.groupIndex].cardVec = []), a[r.groupIndex].cardVec.push(i.mCardValue), a[r.groupIndex].color = r.groupColor, a[r.groupIndex].groupText = r.groupText);
                    P += 1;
                    r.cardIndex;
                }
                else if (A) {
                    if (0 == i.totalIndex && 0 == v) {
                        let e = this.cardViewVec[1].getComponent("RummyCard");
                        this.moveCard.setSiblingIndex(v);
                        i.fromToGroupIndex = e.groupIndex;
                        i.fromToCardIndex = v;
                        i.AfterMovingPos = v3(h, S);
                        d.push(h);
                        a[e.groupIndex] ? (a[e.groupIndex].cardVec || (a[e.groupIndex].cardVec = []), a[e.groupIndex].cardVec.push(i.mCardValue)) : (a[e.groupIndex] = {}, a[e.groupIndex].cardVec || (a[e.groupIndex].cardVec = []), a[e.groupIndex].cardVec.push(i.mCardValue));
                        P += 1;
                    }
                    if (i.totalIndex == o - 1 && v == o - 1) {
                        let e = this.cardViewVec[o - 2].getComponent("RummyCard");
                        this.moveCard.setSiblingIndex(v);
                        i.fromToGroupIndex = e.groupIndex;
                        i.fromToCardIndex = e.cardIndex + 1;
                        i.AfterMovingPos = v3(h, S);
                        d.push(h);
                        a[e.groupIndex] ? (a[e.groupIndex].cardVec || (a[e.groupIndex].cardVec = []), a[e.groupIndex].cardVec.push(i.mCardValue)) : (a[e.groupIndex] = {}, a[e.groupIndex].cardVec || (a[e.groupIndex].cardVec = []), a[e.groupIndex].cardVec.push(i.mCardValue));
                    }
                }
            }
            if (a.length > 0) {
                if (1 == i.groupCardVecLenth) {
                    for (let i = a.length - 1; i >= 0; i--) {
                        a[i] && a[i].cardVec && a[i].cardVec.length > 0 || a.splice(i, 1);
                    }
                }
                if (this.groupFlags.length > 0) {
                    for (let i = 0, e = this.groupFlags.length; i < e; i++) {
                        ToolUtils.isObjValid(this.groupFlags[i]) && (this.groupFlags[i].active = false);
                    }
                }
                let e = false;
                for (let i = 0, t = a.length; i < t; i++) {
                    a[i] && a[i].cardVec && a[i].cardVec.length > 0 || (e = true);
                }
                if (e) {
                    return;
                }
                this.clearTemeMoveCardData();
                let s, r, o, h, l, n, c, u, C, y, P, S, v, I, x, A, T, N = 0;
                for (let i = 0, e = a.length; i < e; i++) {
                    r = "grop_flag" + i;
                    c = this.node.getChildByName(r);
                    c && (s = a[i].cardVec, u = c.getChildByName("grop_flag"), T = u.getChildByName("flag").getComponent(Sprite), C = c.getChildByName("btn"), C.active = false, r = "Add_Btn" + i, C.getComponent(Button).clickEvents[0].customEventData = r, r = "left_btn" + i, y = c.getChildByName("left_btn"), y.getComponent(Button).clickEvents[0].customEventData = r, r = "right_btn" + i, P = c.getChildByName("right_btn"), P.getComponent(Button).clickEvents[0].customEventData = r, v = u.getChildByName("text"), A = v.getComponent(Label), c.active = true, u.active = true, s.length < 2 || t < 2 ? v.active = false : v.active = true, Utils.shared().setStr(v, a[i].groupText), I = y.getChildByName("Sprite"), I.getComponent(Sprite), x = P.getChildByName("Sprite"), x.getComponent(Sprite), 0 == a[i].color ? T.spriteFrame = this.card_kuang_anim[14] : 2 == a[i].color ? T.spriteFrame = this.card_kuang_anim[16] : 3 == a[i].color && (T.spriteFrame = this.card_kuang_anim[15]), o = (s.length - 1) * m + this.cardWidth + 15, h = d[N], l = Math.floor(s.length / 2) + N, h = s.length % 2 == 0 ? d[l] - m / 2 : d[l], A.fontSize = 48, c.getComponent(UITransform).setContentSize(size(o, RummyCardConstant.GroupFlagHeight)), c.setPosition(v3(h, RummyCardConstant.GroupFlagPosY, 0)), c.setSiblingIndex(30 + i), u.getComponent(Layout).updateLayout(), y.setPosition(v3(-o / 2 + 20, 3, 0)), P.setPosition(v3(o / 2 - 20, 3, 0)), C && (C.active = false, this.add_btnArray.push(C)), n = true, S = true, 0 == i ? n = false : i == t - 1 && (S = false), 1 === a.length && (n = false, S = false), n = false, S = false, y.active = n, P.active = S, N += s.length);
                }
            }
        }
    }
    reductionMoveCard() {
        if (!this.moveCard || !this.moveCard) {
            return;
        }
        let i = this.moveCard.getComponent("RummyCard");
        for (let e = 0, t = this.cardViewVec.length; e < t; e++) {
            this.cardViewVec[e].getComponent("RummyCard").totalIndex != i.totalIndex && this.cardViewVec[e].setPosition(this.cardsPostions[e]);
        }
        this.clearTemeMoveCardData();
        let e = this.myGroupcardValueVec.length, t = this.cardViewVec.length, a = 2 * RummyCardConstant.cebianW, s = (e - 1) * this.cardSpaceGroup, r = e * this.cardWidth, d = t - e, o = (RummyCardConstant.ScreenWidth - a - s - r) / (1 * d);
        if (this.lastOffsetX = o, this.groupFlags.length > 0) {
            for (let i = 0, e = this.groupFlags.length; i < e; i++) {
                ToolUtils.isObjValid(this.groupFlags[i]) && this.groupFlags[i].destroy();
            }
            this.groupFlags = [];
        }
        this.changeAddBtnStatus(false);
        this.add_btnArray = [];
        let h, l, n, c, u, m, C, y, b, P, S, v, I, x, A, T, N, z = 0;
        for (let i = 0; i < e; i++) {
            h = this.myGroupcardValueVec[i].cardVec;
            l = "grop_flag" + i;
            C = this.node.getChildByName(l);
            C && (y = C.getChildByName("grop_flag"), N = y.getChildByName("flag").getComponent(Sprite), b = C.getChildByName("btn"), b.active = false, l = "Add_Btn" + i, b.getComponent(Button).clickEvents[0].customEventData = l, l = "left_btn" + i, P = C.getChildByName("left_btn"), P.getComponent(Button).clickEvents[0].customEventData = l, l = "right_btn" + i, S = C.getChildByName("right_btn"), S.getComponent(Button).clickEvents[0].customEventData = l, I = y.getChildByName("text"), T = I.getComponent(Label), C.active = true, y.active = true, h.length < 2 || e < 2 ? I.active = false : I.active = true, Utils.shared().setStr(I, this.myGroupcardValueVec[i].desc), x = P.getChildByName("Sprite"), x.getComponent(Sprite), A = S.getChildByName("Sprite"), A.getComponent(Sprite), 0 == this.myGroupcardValueVec[i].color ? N.spriteFrame = this.card_kuang_anim[14] : 2 == this.myGroupcardValueVec[i].color ? N.spriteFrame = this.card_kuang_anim[16] : 3 == this.myGroupcardValueVec[i].color && (N.spriteFrame = this.card_kuang_anim[15]), n = (h.length - 1) * o + this.cardWidth + 15, c = this.spXpositionDeq[z], u = Math.floor(h.length / 2) + z, c = h.length % 2 == 0 ? this.spXpositionDeq[u] - o / 2 : this.spXpositionDeq[u], T.fontSize = 48, C.getComponent(UITransform).setContentSize(size(n, RummyCardConstant.GroupFlagHeight)), C.setPosition(v3(c, RummyCardConstant.GroupFlagPosY, 0)), C.setSiblingIndex(30 + i), P.setPosition(v3(-n / 2 + 20, 3, 0)), S.setPosition(v3(n / 2 - 20, 3, 0)), b && (b.active = false, this.add_btnArray.push(b)), m = true, v = true, 0 == i ? m = false : i == e - 1 && (v = false), 1 === this.myGroupcardValueVec.length && (m = false, v = false), m = false, v = false, P.active = m, S.active = v);
            z += h.length;
        }
        this.touchCardMoveReduction = false;
    }
    chupaiMoveCard() {
        if (!this.moveCard || !this.moveCard) {
            return;
        }
        let i = this.moveCard.getComponent("RummyCard"), e = new Vec3;
        this.moveCard.getPosition(e);
        let t = this.myGroupcardValueVec.length;
        1 == i.groupCardVecLenth && (t -= 1);
        let a = this.middlePosY, s = this.cardStartPosX;
        this.allPaiNum = RummyDataManager.shared().rummyInfos.get(this.tid_key).close_cardnum;
        this.allPaiNum <= 0 && (this.allPaiNum = 56);
        let r = this.cardViewVec.length - 1, d = 2 * RummyCardConstant.cebianW, o = (t - 1) * this.cardSpaceGroup, h = t * this.cardWidth, l = (RummyCardConstant.ScreenWidth - d - o - h) / (1 * (r - t)), n = this.cardWidth + RummyCardConstant.CardSpaceGroup - l, u = 0, m = a, C = [], y = [];
        for (let e = 0, t = this.cardViewVec.length; e < t; e++) {
            let t = this.cardViewVec[e].getComponent("RummyCard"), a = s + l * u + t.groupIndex * n;
            1 == i.groupCardVecLenth && t.groupIndex > i.groupIndex && (a = s + l * u + (t.groupIndex - 1) * n);
            let r = new Vec3;
            this.cardViewVec[e].getPosition(r);
            t.totalIndex != i.totalIndex && (this.cardViewVec[e].setPosition(v3(a, m)), y.push(a), this.cardViewVec[e].setSiblingIndex(u), C[t.groupIndex] ? (C[t.groupIndex].cardVec || (C[t.groupIndex].cardVec = []), C[t.groupIndex].cardVec.push(i.mCardValue), C[t.groupIndex].color = t.groupColor, C[t.groupIndex].groupText = t.groupText) : (C[t.groupIndex] = {}, C[t.groupIndex].cardVec || (C[t.groupIndex].cardVec = []), C[t.groupIndex].cardVec.push(i.mCardValue), C[t.groupIndex].color = t.groupColor, C[t.groupIndex].groupText = t.groupText), u += 1);
        }
        let b = C.length;
        if (b > 0) {
            if (1 == i.groupCardVecLenth) {
                for (let i = b - 1; i >= 0; i--) {
                    C[i] && C[i].cardVec && C[i].cardVec.length > 0 || C.splice(i, 1);
                }
                b = C.length;
            }
            if (this.groupFlags.length > 0) {
                for (let i = 0, e = this.groupFlags.length; i < e; i++) {
                    ToolUtils.isObjValid(this.groupFlags[i]) && (this.groupFlags[i].active = false);
                }
            }
            let e = false;
            for (let i = 0; i < b; i++) {
                C[i] && C[i].cardVec && C[i].cardVec.length > 0 || (e = true);
            }
            if (e) {
                return;
            }
            this.clearTemeMoveCardData();
            let a, s, r, d, o, h, n, c, u, m, P, S, v, I, x, A, T, N, z, F = 0;
            for (let i = 0; i < b; i++) {
                s = "grop_flag" + i;
                n = this.node.getChildByName(s);
                n && (a = C[i].cardVec, c = n.getChildByName("grop_flag"), T = c.getChildByName("flag").getComponent(Sprite), u = n.getChildByName("btn"), u.active = false, s = "Add_Btn" + i, u.getComponent(Button).clickEvents[0].customEventData = s, s = "left_btn" + i, m = n.getChildByName("left_btn"), m.getComponent(Button).clickEvents[0].customEventData = s, s = "right_btn" + i, P = n.getChildByName("right_btn"), P.getComponent(Button).clickEvents[0].customEventData = s, v = c.getChildByName("text"), A = v.getComponent(Label), n.active = true, c.active = true, a.length < 2 || t < 2 ? v.active = false : v.active = true, Utils.shared().setStr(v, C[i].groupText), I = m.getChildByName("Sprite"), N = I.getComponent(Sprite), x = P.getChildByName("Sprite"), z = x.getComponent(Sprite), 0 == C[i].color ? (T.spriteFrame = this.card_kuang_anim[14], N.spriteFrame = this.card_kuang_anim[6], z.spriteFrame = this.card_kuang_anim[5]) : 2 == C[i].color ? (T.spriteFrame = this.card_kuang_anim[16], N.spriteFrame = this.card_kuang_anim[10], z.spriteFrame = this.card_kuang_anim[9]) : 3 == C[i].color && (T.spriteFrame = this.card_kuang_anim[15], N.spriteFrame = this.card_kuang_anim[8], z.spriteFrame = this.card_kuang_anim[7]), r = (a.length - 1) * l + this.cardWidth + 15, d = y[F], o = Math.floor(a.length / 2) + F, d = a.length % 2 == 0 ? y[o] - l / 2 : y[o], A.fontSize = 48, n.getComponent(UITransform).setContentSize(size(r, RummyCardConstant.GroupFlagHeight)), c.getComponent(UITransform).setContentSize(size(r, RummyCardConstant.GroupFlagHeight)), n.setPosition(v3(d, RummyCardConstant.GroupFlagPosY, 0)), n.setSiblingIndex(30 + i), m.setPosition(v3(-r / 2 + 20, 3, 0)), P.setPosition(v3(r / 2 - 20, 3, 0)), u && (u.active = false, this.add_btnArray.push(u)), h = true, S = true, 0 == i ? h = false : i == t - 1 && (S = false), 1 === C.length && (h = false, S = false), h = false, S = false, m.active = h, P.active = S, F += a.length);
            }
        }
    }
    clearTemeMoveCardData() {
        for (let i = 0; i < 6; i++) {
            this.node.getChildByName("grop_flag" + i).active = false;
        }
    }
    showCopyCard(i, e = false) {
        if (i && ToolUtils.isObjValid(this.moveCard)) {
            if (null == this.fadeCard) {
                this.fadeCard = this.getCardNode();
                let i = this.fadeCard.getComponent("RummyCard"), e = this.moveCard.getComponent("RummyCard");
                i.init(e.mCardValue, false);
                i.openCard();
                i.showLaiziFlag(this.isShowLaiziColor(e.mCardValue));
                RummyDataManager.shared().rummyInfos.has(this.tid_key) && 1 == RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyMode ? i.setMask(true) : i.changeOpacity(175);
                this.fadeCard.setScale(this.outcardScale);
                this.fadeCard.active = true;
                this.fade_node.addChild(this.fadeCard);
                this.fadeCard.setSiblingIndex(1);
            }
            e ? this.fadeCard.setPosition(this.finishPoint) : this.fadeCard.setPosition(this.qipaiPoint);
            this.fadeCard.active = true;
        }
        else {
            this.fadeCard && (this.fadeCard.active = false);
        }
    }
    containsPoint(i, e) {
        let t = false;
        return e.x >= i.x && e.x <= i.x + i.width && e.y >= i.y && e.y <= i.y + i.height && (t = true), t;
    }
    resetCardUnSelected() {
        let i = true;
        for (let e = 0, t = this.cardViewVec.length; e < t; e++) {
            let t = this.cardViewVec[e];
            if (ToolUtils.isObjValid(t)) {
                t.getPosition().y > -80 && (i = false);
            }
        }
        if (i) {
            let i, e, t = v3();
            for (let a = 0, s = this.cardViewVec.length; a < s; a++) {
                i = this.cardViewVec[a];
                ToolUtils.isObjValid(i) && (i.getPosition(t), e = i.getComponent("RummyCard"), e.changeCardSelectedStatus(false), e.hasSelected && this.playEffectByName("rummyCardDeselect"), e.changeCardStatus(false), this.cardsPostions[a] && null != this.cardsPostions[a] && i.setPosition(this.cardsPostions[a]));
            }
            this.changeAddBtnStatus(false);
        }
    }
    onTouchCancel(i) {
        try {
            let e = i.getUILocation(), t = v3(e.x, e.y), a = v3();
            if (this.shoupaiLayout.inverseTransformPoint(a, t), this.checkTouchInTingPaiArea(a)) {
                return void (this.hasClickCardArea = false);
            }
            if (RummyDataManager.shared().rummyInfos.get(this.tid_key).isMovingCard = false, this.deleteClickCountDown(), !this.hasFaPaiAnimEnded) {
                return void (this.hasClickCardArea = false);
            }
            this.clearTemeMoveCardData();
            ToolUtils.isObjValid(this.moveCard) && (this.moveCard.setSiblingIndex(this.lastZorder), this.moveCard.setPosition(this.lastPoint), this.resetMyShouPai());
            this.hasClickCardArea = false;
        }
        catch (i) {
            TLog.printError("-------- RummyGameCards onTouchCancel error!");
        }
    }
    onTouchEnded(i) {
        try {
            if (RummyDataManager.shared().rummyInfos.get(this.tid_key).able_local_discard && 0 == RummyDataManager.shared().rummyInfos.get(this.tid_key).isCanTouchCard) {
                return;
            }
            RummyDataManager.shared().rummyInfos.get(this.tid_key).isMovingCard && this.callback && this.callback("moveCardEnd");
            this.deleteClickCountDown();
            let e = i.getUILocation();
            if (this.changeCardPlayOutLineStatus(false), ToolUtils.isObjValid(this.fadeCard) && (this.putCardNode(this.fadeCard), this.fadeCard = null), !this.hasFaPaiAnimEnded) {
                return void (this.hasClickCardArea = false);
            }
            let t = v3(e.x, e.y), a = v3();
            if (this.shoupaiLayout.inverseTransformPoint(a, t), !this.hasClickCardArea) {
                if (!this.isTouchInSideBtnArea(a, true)) {
                    if (this.checkTouchInTingPaiArea(a)) {
                        return void (this.hasClickCardArea = false);
                    }
                    this.resetCardUnSelected();
                    this.callback && this.callback("reSetCards");
                }
                return void (this.hasClickCardArea = false);
            }
            if (!ToolUtils.isObjValid(this.moveCard)) {
                return void (this.hasClickCardArea = false);
            }
            let s = this.moveCard.getComponent("RummyCard");
            this.hasClickCardArea = false;
            let r = v3(0, 0), d = new Vec3;
            this.moveCard.getPosition(d);
            let o = d.x - this.lastPoint.x, h = d.y - this.lastPoint.y, l = Math.abs(o), n = Math.abs(h);
            this.isChange = false;
            let u = 809, g = false;
            this.dayingshoupaiData(4);
            let p = false;
            if (14 == this.cardViewVec.length) {
                if (r.y + d.y >= RummyCardConstant.chuCardHeight) {
                    if (0 == RummyDataManager.shared().rummyInfos.get(this.tid_key).hasChupai) {
                        RummyDataManager.shared().rummyInfos.get(this.tid_key).playCardValue = s.mCardValue;
                        RummyDataManager.shared().data.selectCardIndex = this.lastSelectedCardIndex;
                        RummyDataManager.shared().rummyInfos.get(this.tid_key).groupIndex = s.groupIndex;
                        let i = false;
                        d.x >= -80 && d.x <= 80 && (i = true);
                        RummyDataManager.shared().rummyInfos.get(this.tid_key).card_index = s.cardIndex;
                        i ? (ToolUtils.isObjValid(this.moveCard) && (this.moveCard.setScale(this.outcardScale), this.moveCard.setPosition(this.finishPoint), s.showNewFlag(false), s.showDiscardTipsFlag(false)), this.callback && this.callback("finish"), g = true) : (ToolUtils.isObjValid(this.moveCard) && (this.moveCard.setScale(this.outcardScale), this.moveCard.setPosition(this.qipaiPoint), s.showNewFlag(false), s.showDiscardTipsFlag(false), this.changeEasyModeOutCardGray(this.moveCard)), this.callback && this.callback("discard"), g = true);
                    }
                    else {
                        ToolUtils.isObjValid(this.moveCard) && (r.y + d.y < RummyCardConstant.chuCardHeight ? this.refreshCardsPosition1(this.moveCard) : (d.x = this.lastPosX, this.moveCard.setSiblingIndex(this.lastZorder), p = true, 0 == RummyDataManager.shared().data.direction && this.moveCard.setPosition(this.lastPoint)), this.isChange || (l < 20 && n < 20 ? this.touchCardMove ? p = true : s.hasSelecting && (s.changeCardStatus(!s.hasSelected), this.moveCard.setSiblingIndex(this.lastZorder)) : (p = true, s.changeCardStatus(false), this.moveCard.setSiblingIndex(this.lastZorder))));
                        this.callback && this.callback("checkCards");
                    }
                }
                else {
                    if (ToolUtils.isObjValid(this.moveCard)) {
                        if (r.y + d.y >= u) {
                            d.x = this.lastPosX;
                            this.moveCard.setSiblingIndex(this.lastZorder);
                            s.hasSelecting = false;
                            0 == RummyDataManager.shared().data.direction && (this.moveCard.setPosition(this.lastPoint), p = true);
                        }
                        else {
                            let i;
                            r.y + d.y < RummyCardConstant.chuCardHeight ? this.refreshCardsPosition1(this.moveCard) : (d.x = this.lastPosX, this.moveCard.setSiblingIndex(this.lastZorder), p = true, 0 == RummyDataManager.shared().data.direction && this.moveCard.setPosition(this.lastPoint));
                            this.isChange || (l < 20 && n < 20 ? this.touchCardMove ? p = true : s.hasSelecting && (s.changeCardStatus(!s.hasSelected), this.moveCard.setSiblingIndex(this.lastZorder)) : (p = true, s.changeCardStatus(false), this.moveCard.setSiblingIndex(this.lastZorder)));
                            for (let e = 0, t = this.cardViewVec.length; e < t; e++) {
                                if (i = this.cardViewVec[e], ToolUtils.isObjValid(i)) {
                                    let t = this.cardViewVec[e].getComponent("RummyCard");
                                    i.setSiblingIndex(t.cardIndex);
                                }
                            }
                        }
                    }
                    this.callback && this.callback("checkCards");
                }
            }
            else {
                if (ToolUtils.isObjValid(this.moveCard) && (r.y + d.y < RummyCardConstant.tuodongCardHeight ? this.refreshCardsPosition1(this.moveCard) : (d.x = this.lastPosX, this.moveCard.setSiblingIndex(this.lastZorder), this.moveCard.setPosition(this.lastPoint), p = true), !this.isChange)) {
                    let i;
                    l < 20 && n < 20 ? this.touchCardMove ? p = true : s.hasSelecting && (s.changeCardStatus(!s.hasSelected), this.moveCard.setSiblingIndex(this.lastZorder)) : (p = true, s.changeCardStatus(false), this.moveCard.setSiblingIndex(this.lastZorder));
                    for (let e = 0, t = this.cardViewVec.length; e < t; e++) {
                        if (i = this.cardViewVec[e], ToolUtils.isObjValid(i)) {
                            let t = this.cardViewVec[e].getComponent("RummyCard");
                            i.setSiblingIndex(t.cardIndex);
                        }
                    }
                }
                this.callback && this.callback("checkCards");
            }
            if (p && this.resetMyShouPai(), s && l < 20 && n < 20 && (s.hasSelected ? this.playEffectByName("rummyCardSelect") : this.playEffectByName("rummyCardDeselect")), g) {
                ;
            }
            else if (this.clearTemeMoveCardData(), this.groupFlags.length > 0) {
                for (let i = 0, e = this.groupFlags.length; i < e; i++) {
                    ToolUtils.isObjValid(this.groupFlags[i]) && (this.groupFlags[i].active = true);
                }
            }
            this.dayingshoupaiData(3);
        }
        catch (i) {
            TLog.printError("-------- RummyGameCards onTouchEnded error!");
        }
    }
    refreshCardsPosition1(i) {
        if (!ToolUtils.isObjValid(this.moveCard)) {
            return;
        }
        this.isChange = false;
        let e = i.getComponent("RummyCard");
        if (null != e.fromToGroupIndex && null != e.fromToCardIndex) {
            if (e.fromToGroupIndex == e.groupIndex && e.fromToCardIndex == e.cardIndex) {
                this.dayingshoupaiData(1);
                let i = new Vec3;
                this.moveCard.getPosition(i);
                this.moveCard.setPosition(v3(this.lastPosX, i.y, i.z));
                this.moveCard.setSiblingIndex(this.lastZorder);
            }
            else {
                this.isChange = true;
                let i = this.myGroupcardValueVec[e.groupIndex], t = i.cardVec;
                t.length > 0 && (t.splice(e.cardIndex, 1), i.cardVec = t, e.isNewCard && (this.myGroupcardValueVec[e.groupIndex].isCatchGroup = 0));
                let a = this.myGroupcardValueVec.length;
                if (e.fromToGroupIndex >= a) {
                    e.fromToGroupIndex = a;
                    e.fromToCardIndex = 0;
                    let i = [];
                    i.type = 1;
                    i.index = 0;
                    i.score = 0;
                    i.desc = "";
                    i.color = 3;
                    let t = [];
                    t.push(this.moveValue);
                    i.cardVec = t;
                    this.myGroupcardValueVec.push(i);
                }
                else {
                    let i = this.myGroupcardValueVec[e.fromToGroupIndex], t = i.cardVec;
                    t.splice(e.fromToCardIndex, 0, this.moveValue);
                    i.cardVec = t;
                    e.isNewCard && (this.myGroupcardValueVec[e.fromToGroupIndex].isCatchGroup = 1);
                }
                let s = e.groupIndex, r = e.fromToGroupIndex, d = this.myGroupcardValueVec[e.groupIndex].cardVec.length;
                if (e.fromToGroupIndex != e.groupIndex && 0 == d && (this.myGroupcardValueVec.splice(e.groupIndex, 1), s < r && r--, s = -1), RummyDataManager.shared().rummyInfos.get(this.tid_key).from_index = e.groupIndex, RummyDataManager.shared().rummyInfos.get(this.tid_key).from_card_index = e.cardIndex, RummyDataManager.shared().rummyInfos.get(this.tid_key).to_index = e.fromToGroupIndex, RummyDataManager.shared().rummyInfos.get(this.tid_key).to_card_index = e.fromToCardIndex, RummyDataManager.shared().rummyInfos.get(this.tid_key).playCardValue = e.mCardValue, a = this.myGroupcardValueVec.length, RummyDataManager.shared().rummyInfos.get(this.tid_key).able_client_group) {
                    for (let i = 0; i < a; i++) {
                        this.myGroupcardValueVec[i].index = i;
                    }
                    this.handCardDataAnalysis.startAnalysisMoveHandCard(this.myGroupcardValueVec, RummyDataManager.shared().rummyInfos.get(this.tid_key).laizicard, s, r);
                    let i = this.handCardDataAnalysis.getFinalHandCardData();
                    this.setNewCardIndex(i);
                    this.beginFaPaiWithoutAnim(i, i.length);
                    this.dayingshoupaiData(2);
                }
                else {
                    this.setNewCardIndex(this.myGroupcardValueVec);
                    this.beginFaPaiWithoutAnim(this.myGroupcardValueVec, a);
                }
                this.callback && this.callback("moveCards");
            }
        }
        else {
            let i = new Vec3;
            this.moveCard.getPosition(i);
            this.moveCard.setPosition(v3(this.lastPosX, i.y, i.z));
            this.moveCard.setSiblingIndex(this.lastZorder);
        }
    }
    setNewCardIndex(i) {
        let e = RummyDataManager.shared().rummyInfos.get(this.tid_key).newCardValue;
        for (let t = 0, a = i.length; t < a; t++) {
            if (1 == i[t].isCatchGroup) {
                let a = i[t];
                if (a.cardVec.length > 0) {
                    for (let i = a.cardVec.length - 1; i >= 0; i--) {
                        if (a.cardVec[i] == e) {
                            a.catchIndex = i;
                            break;
                        }
                    }
                }
            }
        }
    }
    checkTouchInTingPaiArea(i) {
        let e, t = size(64 * this.cardScale.x, 70 * this.cardScale.y), a = v3(), s = false;
        for (let r = 0; r < this.cardViewVec.length; r++) {
            let d = this.cardViewVec[r].getComponent("RummyCard");
            if ((1 == d.tingpai_type || 2 == d.tingpai_type) && (this.shoupaiLayout.inverseTransformPoint(a, d.tingpaiTipsNode.getWorldPosition()), e = rect(a.x - t.width / 2, a.y - t.height / 2, t.width, t.height), e.x <= i.x && e.x + e.width >= i.x && e.y <= i.y && e.y + e.height >= i.y)) {
                s = true;
                break;
            }
        }
        return s;
    }
    isTouchInSideBtnArea(i, e) {
        let t, a = size(105, 70), s = new Vec3, r = v3();
        for (let e = 0, d = this.add_btnArray.length; e < d; e++) {
            if (ToolUtils.isObjValid(this.add_btnArray[e]) && this.add_btnArray[e].active && (this.add_btnArray[e].getPosition(s), this.shoupaiLayout.inverseTransformPoint(r, this.add_btnArray[e].getWorldPosition()), t = rect(r.x - a.width / 2, r.y - a.height / 2, a.width, a.height), t.x <= i.x && t.x + t.width >= i.x && t.y <= i.y && t.y + t.height >= i.y)) {
                return this.callback && this.callback("Add_Btn" + e), true;
            }
        }
        return false;
    }
    playEffectByName(i, e) {
        this.tid_key === User.shared().curTid_key && SoundManager.shared().playFx(i, null, e);
    }
    initGameCardView() {
        this.zhezhaoView.active = false;
        this.changeCardPlayOutLineStatus(false);
        this.node.getChildByName("open_btn_img_show").active = false;
        this.node.getChildByName("bump_switch_btn_img").active = false;
    }
    cardCheshi() {
    }
    drawCard(i, e, t, a, s, r, d) {
        if (this.seatPosVec[i]) {
            this.playEffectByName("rummyPickDiscard");
            this.drawCallFun = r;
            try {
                let r = this.getCardNode(), o = r.getComponent("RummyCard");
                o.init(e, true);
                o.isZhuang = a;
                r.setScale(RummyCardConstant.dingzhuangCardScale);
                r.setPosition(RummyCardConstant.DrawBeginPos);
                r.active = true;
                this.node.addChild(r);
                let h = { cardNode: r, oldPos: i, newPos: d, isZhuang: a };
                this.drawCards.push(h);
                let l = v3(this.seatPosVec[i].x, this.seatPosVec[i].y - 120);
                0 == i && (l = v3(this.seatPosVec[i].x, this.seatPosVec[i].y + 130));
                let n = TweenTool.delayAct(this.delay_node, null, t), c = TweenTool.moveTo(r, 0.4, l, "cubicOut"), u = TweenTool.scaleTo(r, 0.1, RummyCardConstant.dingzhuangCardScale3), g = TweenTool.scaleTo(r, 0.07, RummyCardConstant.dingzhuangCardScale), p = TweenTool.delayAct(this.delay_node, (() => {
                    o.openCard();
                }), 0, false);
                TweenTool.sequence(r, true, null, n, c, u, p, g);
                let m = 1.02;
                TweenTool.delayAct(this.delay_node, (() => {
                    s && this.drawCallFun(true);
                }), m, true);
            }
            catch (i) {
                this.drawCallFun(true);
                TLog.printError("trycatch drawCard,error:", i);
            }
        }
        else {
            TLog.printError("------------- rummyGameCards drawCard pos, value:", i, e);
        }
    }
    drawCardAnim(i) {
        for (let e = 0, t = this.drawCards.length; e < t; e++) {
            if (ToolUtils.isObjValid(this.drawCards[e].cardNode)) {
                let t = this.drawCards[e].cardNode.getComponent("RummyCard"), a = TweenTool.scaleTo(this.drawCards[e].cardNode, 0.1, RummyCardConstant.dingzhuangCardScale4), s = TweenTool.scaleTo(this.drawCards[e].cardNode, 0.06, RummyCardConstant.dingzhuangCardScale1), r = TweenTool.delayAct(this.delay_node, (() => {
                    if (this.drawCards[e] && ToolUtils.isObjValid(this.drawCards[e].cardNode)) {
                        let i = this.drawCards[e].newPos, t = v3(this.seatPosVec[i].x, this.seatPosVec[i].y - 120);
                        0 == i && (t = v3(this.seatPosVec[i].x, this.seatPosVec[i].y + 130));
                        this.drawCards[e].cardNode.setPosition(t);
                    }
                }), 0), d = TweenTool.scaleTo(this.drawCards[e].cardNode, 0.14, RummyCardConstant.dingzhuangCardScale), o = TweenTool.delayAct(this.delay_node, (() => {
                }), 0.2), h = TweenTool.scaleTo(this.drawCards[e].cardNode, 0.2, RummyCardConstant.dingzhuangCardScale2), l = TweenTool.scaleTo(this.drawCards[e].cardNode, 0.23, RummyCardConstant.dingzhuangCardScale), n = TweenTool.scaleTo(this.drawCards[e].cardNode, 0.3, RummyCardConstant.dingzhuangCardScale2), c = TweenTool.delayAct(this.delay_node, (() => {
                    this.drawCards[e] && (this.drawCards[e].isZhuang ? (this.playEffectByName("rummyZhuang"), t.setMask(false)) : t.setMask(true));
                }), 0), u = TweenTool.delayAct(this.delay_node, (() => {
                }), 1.2), g = TweenTool.delayAct(this.delay_node, (() => {
                    this.drawClear();
                }), 0.5);
                i ? this.drawCards[e] && (this.drawCards[e].isZhuang ? TweenTool.sequence(this.drawCards[e].cardNode, true, null, c, h, l, n, l, g) : TweenTool.sequence(this.drawCards[e].cardNode, true, null, c, u, g)) : this.drawCards[e] && (this.drawCards[e].isZhuang ? TweenTool.sequence(this.drawCards[e].cardNode, true, null, a, s, c, r, d, o, h, l, n, l, g) : TweenTool.sequence(this.drawCards[e].cardNode, true, null, a, s, c, r, d, o, u, g));
            }
        }
    }
    drawFinish() {
    }
    drawClear() {
        for (let i = 0, e = this.drawCards.length; i < e; i++) {
            ToolUtils.isObjValid(this.drawCards[i].cardNode) && this.putCardNode(this.drawCards[i].cardNode);
        }
        this.drawCards = [];
    }
    changeXipaiAnimVisibile(i) {
        if (i) {
            ToolUtils.isObjValid(this.lzCard) && this.lzCard.setSiblingIndex(0);
            let i, e = this.qipaiCards.length;
            for (let t = 0; t < e; t++) {
                i = this.qipaiCards[t];
                ToolUtils.isObjValid(i) && (i.active = !(t < e - 2));
            }
            if (e <= 0) {
                let i = this.getCardNode();
                this.qipai_node.insertChild(i, 0);
                let e = i.getComponent("RummyCard"), t = RummyDataManager.shared().rummyInfos.get(this.tid_key);
                e.init(t.dc_card, false);
                e.openCard();
                1 == t.is_bump ? e.showLaiziFlag(this.isShowLaiziColor(t.dc_card), false, true) : e.showLaiziFlag(this.isShowLaiziColor(t.dc_card));
                i.setScale(this.outcardScale);
                i.setPosition(this.qipaiPoint);
                i.active = true;
                this.qipaiCards.push(i);
            }
            if (e > 0) {
                let i = this.qipaiCards[e - 1];
                if (ToolUtils.isObjValid(i)) {
                    this.is_shuffle = true;
                    i.active = true;
                    i.setSiblingIndex(this.qipai_node.children.length);
                    this.playEffectByName("rummyRedealCard");
                    let e = TweenTool.scaleTo(i, 0.1, v3(0, this.outcardScale.y)), t = TweenTool.delayAct(this.delay_node, (() => {
                        let e = i.getComponent("RummyCard");
                        e.refreshcardbg("rummy_card_bg_0" + User.shared().styles[2]);
                        e.changeCardToBack();
                    }), 0, false), a = TweenTool.scaleTo(i, 0.1, v3(this.outcardScale.x, this.outcardScale.y));
                    TweenTool.sequence(i, true, (() => {
                        this.showXipaiCallback(i);
                    }), e, t, a);
                    TweenTool.delayAct(this.delay_node, (() => {
                        this.qipaiCards = [];
                        this.qipai_node.removeAllChildren();
                        this.showPaiduiCards();
                    }), 1, true);
                    TweenTool.delayAct(this.delay_node, (() => {
                        this.is_shuffle = false;
                    }), 2, true);
                }
            }
        }
    }
    refreshxipaicolor() {
        if (this.xipai_anim_node && this.xipai_anim_node.isValid) {
            let i = this.xipai_anim_node.getComponent(sp.Skeleton);
            1 == User.shared().styles[2] ? i.setSkin("red") : 2 == User.shared().styles[2] ? i.setSkin("yellow") : 3 == User.shared().styles[2] ? i.setSkin("blue") : 4 == User.shared().styles[2] ? i.setSkin("purple") : 5 == User.shared().styles[2] && i.setSkin("green");
        }
    }
    showXipaiCallback(i) {
        ToolUtils.isObjValid(i) && TweenTool.delayAct(this.delay_node, (() => {
            if (this.xipai_anim_node && this.xipai_anim_node.isValid) {
                this.xipai_anim_node.active = true;
                let i = this.xipai_anim_node.getComponent(sp.Skeleton);
                this.refreshxipaicolor();
                i.setToSetupPose();
                i.setAnimation(0, "pd_xpdh", false);
                i.setEndListener((() => {
                }));
            }
        }), 0.01, true);
    }
    showAutoSortBtn() {
        let i = false, e = RummyDataManager.shared().rummyInfos.get(this.tid_key).clientSeatId;
        return 1 == RummyDataManager.shared().rummyInfos.get(this.tid_key).playerModels[e].betting && 1 === this.myGroupcardValueVec.length && 0 === this.getSelectedCards().length && (i = true), i;
    }
    ceshiceshi1() {
        let i = this.getCardNode(), e = i.getComponent("RummyCard");
        e.init(10, true);
        this.node.addChild(i);
        i.setPosition(v3(200, 200, 0));
        let t = TweenTool.scaleTo(i, 0.1, v3(0, this.cardScale.y)), a = TweenTool.scaleTo(i, 0.1, v3(this.cardScale.x, this.cardScale.y)), s = TweenTool.delayAct(this.delay_node, (() => {
            e.openCard();
        }), 0, false);
        TweenTool.sequence(i, true, null, t, s, a);
    }
    beginFaPaiWithAnim(i, e) {
        this.cancelOpenPileSync();
        let t = [];
        i.initial_cardinfos && "object" == typeof i.initial_cardinfos && i.initial_cardinfos[0] && i.initial_cardinfos[0].cards && (t = i.initial_cardinfos[0].cards);
        let a, s, r = i.players;
        if (this.is_fapai_over = false, this.cardViewVec.length > 0) {
            for (let i = 0, e = this.cardViewVec.length; i < e; i++) {
                a = this.cardViewVec[i];
                ToolUtils.isObjValid(a) && this.putCardNode(a);
            }
        }
        if (this.cardViewVec = [], this.paiduiCardVec.length > 0) {
            for (let i = 0, e = this.paiduiCardVec.length; i < e; i++) {
                a = this.paiduiCardVec[i];
                ToolUtils.isObjValid(a) && this.putCardNode(a);
            }
        }
        if (this.paiduiCardVec = [], this.qipaiCards.length > 0) {
            for (let i = 0, e = this.qipaiCards.length; i < e; i++) {
                a = this.qipaiCards[i];
                ToolUtils.isObjValid(a) && this.putCardNode(a);
            }
        }
        for (let i = 0, e = this.availableFlagNodes.length; i < e; i++) {
            ToolUtils.isObjValid(this.availableFlagNodes[i]) && this.putAvailableFlagNode(this.availableFlagNodes[i]);
        }
        if (this.availableFlagNodes = [], this.availabeFlagInfos = [], this.qipaiCards = [], this.qipai_node.removeAllChildren(), this.paidui_node.removeAllChildren(), this.shoupaiLayout.removeAllChildren(), this.fade_node.removeAllChildren(), this.initialCardNodes.length > 0) {
            for (let i = 0, e = this.initialCardNodes.length; i < e; i++) {
                a = this.initialCardNodes[i];
                ToolUtils.isObjValid(a) && this.putCardNode(a);
            }
            this.initialCardNodes = [];
        }
        this.cardValueVec = [];
        let d = this.middlePosY, o = 0.3 + 0.15, h = 0.2, l = 0.1, n = [12, -15, -20, 0, 20, 10], c = 93;
        undefined !== r && Array.isArray(r) && r.length > 0 && (c = 13 * r.length + 1);
        for (let i = 0; i <= c - 1; i++) {
            a = this.getCardNode();
            s = a.getComponent("RummyCard");
            s.init(1, true);
            s.setCardTag(i);
            a.setScale(RummyCardConstant.OutcardScale);
            a.active = i == c - 1;
            a.setPosition(RummyCardConstant.centerPos);
            this.paidui_node.addChild(a);
            a.setSiblingIndex(i);
            a.angle = 0;
            TweenTool.moveToByFade(a, 0.15, a.getPosition(), 0, 1, true, (() => {
            }));
            this.paiduiCardVec.push(a);
        }
        let u = 0;
        if (undefined !== r && "object" == typeof r) {
            for (let i = 0, e = r.length; i < e; i++) {
                const e = r[i];
                let t = RummyDataManager.shared().getPosBySeatid(e.seatid, this.tid_key);
                if (0 != t) {
                    for (let i = 0; i < RummyCardConstant.shouPaiNum; i++) {
                        if (this.paiduiCardVec.length > i + 13 * u) {
                            let e = i + 13 * u, a = this.paiduiCardVec[e], s = v3(this.seatPosVec[t].x, this.seatPosVec[t].y), r = 0.034 * i + o;
                            TweenTool.delayAct(this.delay_node, (() => {
                                let i = n[t];
                                if (2 != RummyDataManager.shared().rummyInfos.get(this.tid_key).pnum && 4 != RummyDataManager.shared().rummyInfos.get(this.tid_key).pnum || (i = 0), ToolUtils.isObjValid(a)) {
                                    a.active = true;
                                    let e = TweenTool.moveTo(a, h, s), t = TweenTool.scaleTo(a, h, RummyCardConstant.OtherHeadCardScale), r = tween(a).to(l, { eulerAngles: v3(0, 0, i) }).to(l, { eulerAngles: v3(0, 0, 0) });
                                    TweenTool.parallel(a, true, (() => {
                                    }), e, t, r);
                                }
                                TweenTool.delayAct(this.delay_node, (() => {
                                    null !== s.x && ToolUtils.isObjValid(a) && (a.setPosition(s), a.active = true, TweenTool.moveTo(a, 0.15, v3(s.x, s.y + 6), null, true, (() => {
                                        a.active = false;
                                    })));
                                }), h, true);
                            }), r, true);
                        }
                    }
                    u += 1;
                }
            }
        }
        this.allPaiNum = RummyDataManager.shared().rummyInfos.get(this.tid_key).close_cardnum;
        let g = 0, p = this.getFapaiGroupCardValues(e);
        if (t && "object" == typeof t) {
            let i, e;
            for (let a = 0, s = t.length; a < s; a++) {
                i = this.getCardNode();
                this.shoupaiLayout.addChild(i);
                e = i.getComponent("RummyCard");
                0 == Number(TransferPlatform.shared().getDeviceLevel()) && sys.isObjectValid(p[a]) ? e.init(p[a], true) : e.init(t[a], true);
                e.setCardSize(this.cardWidth, this.cardHeight);
                e.setCardTag(g);
                e.cardIndex = a;
                e.unSelectedPosY = d;
                e.selectedPosY = d + RummyCardConstant.SelectSpaceY;
                e.groupIndex = 0;
                e.setCardTouchAreaX(this.touchCardWidth / 2, this.touchCardWidth / 2);
                e.setCardTouchAreaY(this.touchCardHight / 2, this.touchCardHight / 2);
                e.rowType = 0;
                i.setScale(RummyCardConstant.OutcardScale);
                i.active = !(a < s - 1);
                i.setPosition(RummyCardConstant.centerPos);
                e.totalIndex = g;
                i.setSiblingIndex(g);
                this.initialCardNodes.push(i);
                g += 1;
            }
        }
        this.myGroupcardValueVec = e;
        let m = 0, C = 0.2, f = 0.034;
        if (e.length > 0) {
            this.getshouPaiPositions(e, this.initialCardNodes.length);
            let i = 12;
            this.cardsPostions = [];
            let t = 0.06, a = 0.1, s = 10, r = -550.4, h = 90, n = (12 * h + s) / 12, c = 0, u = 0;
            for (let e = 0, g = this.initialCardNodes.length; e < g; e++) {
                let g = this.initialCardNodes[e];
                if (ToolUtils.isObjValid(g)) {
                    g.getComponent("RummyCard").setCardTag(e);
                    g.active = true;
                    m = f * e + o;
                    TweenTool.delayAct(this.delay_node, (() => {
                        if (ToolUtils.isObjValid(g)) {
                            0 === e && this.playEffectByName("rummyDeal");
                            let o = tween(g).to(l, { eulerAngles: v3(0, 0, i) }).to(l, { eulerAngles: v3(0, 0, 0) });
                            c = r + n * e;
                            1 == this.myGroupcardValueVec.length && this.spXpositionDeq.length > e && (c = this.spXpositionDeq[e]);
                            let p = tween().to(C, { position: v3(c, d) });
                            u = r + s + h * e;
                            1 == this.myGroupcardValueVec.length && (u = this.spXpositionDeq[e]);
                            let m = tween().to(C, { scale: this.cardScale }), y = null;
                            y = 1 == this.myGroupcardValueVec.length ? tween(g).delay(C).to(t, { scale: v3(0, 0.8) }).call((() => {
                                if (ToolUtils.isObjValid(g)) {
                                    let i = g.getComponent("RummyCard");
                                    i.openCard();
                                    1 == RummyDataManager.shared().rummyInfos.get(this.tid_key).is_bump && i.showLaiziFlag(this.isShowLaiziColor(i.mCardValue), false, true);
                                }
                            })).to(a, { scale: v3(0.8, 0.8) }) : tween(g).delay(C).to(0.17, { position: v3(u, d) }).delay(f).to(t, { scale: v3(0, 0.8) }).call((() => {
                                if (ToolUtils.isObjValid(g)) {
                                    let i = g.getComponent("RummyCard");
                                    i.openCard();
                                    1 == RummyDataManager.shared().rummyInfos.get(this.tid_key).is_bump && i.showLaiziFlag(this.isShowLaiziColor(i.mCardValue), false, true);
                                }
                            })).to(a, { scale: v3(0.8, 0.8) });
                            tween(g).parallel(o, p, m, y).target(g).call((() => {
                            })).start();
                        }
                    }), m, true);
                }
            }
        }
        TweenTool.delayAct(this.delay_node, (() => {
            this.fanLaizi();
        }), 1.358, true);
        let V = 1.5;
        1 == this.myGroupcardValueVec.length && (V = 1.5);
        e.length > 0 && TweenTool.delayAct(this.delay_node, (() => {
            0 == Number(TransferPlatform.shared().getDeviceLevel()) ? this.refreshMyShouPaiValues() : this.sortShouPai();
        }), V, true);
    }
    sortShouPai() {
        if (1 == this.myGroupcardValueVec.length) {
            this.refreshMyShouPaiValues();
        }
        else {
            let i, e = 4, t = new Vec3, a = 0, s = 0, r = 0;
            for (let d = 0, o = this.initialCardNodes.length; d < o; d++) {
                i = this.initialCardNodes[d];
                ToolUtils.isObjValid(i) && (r = Math.floor(o / 2), a = 0, i.getPosition(t), s = 0, d < r ? (a = -8, s = -d * e) : d > r && (a = 8, s = (d - r) * e), tween(i).to(0.1, { position: v3(t.x + a, this.middlePosY) }).to(0.16, { position: v3(s, this.middlePosY) }).start());
            }
            TweenTool.delayAct(this.delay_node, (() => {
                this.refreshMyShouPaiValues();
            }), 0.26, true);
        }
    }
    refreshMyShouPaiValues() {
        this.cardValueVec = [];
        let i = this.myGroupcardValueVec.length;
        this.cardViewVec = [];
        let e, t, a = [], s = 0, r = RummyDataManager.shared().rummyInfos.get(this.tid_key), d = 1 == r.is_bump && r.game_state < 4;
        for (let r = 0; r < i; r++) {
            a = this.myGroupcardValueVec[r].cardVec;
            for (let i = 0, o = a.length; i < o; i++) {
                this.cardValueVec.push(a[i]);
                e = this.initialCardNodes[s];
                ToolUtils.isObjValid(e) && (t = e.getComponent("RummyCard"), t.init(a[i], false), t.setCardSize(this.cardWidth, this.cardHeight), t.setCardTag(s), t.cardIndex = i, t.unSelectedPosY = this.middlePosY, t.selectedPosY = this.middlePosY + RummyCardConstant.SelectSpaceY, t.groupIndex = r, t.setCardTouchAreaX(this.touchCardWidth / 2, this.touchCardWidth / 2), t.setCardTouchAreaY(this.touchCardHight / 2, this.touchCardHight / 2), t.rowType = 0, t.groupCardVecLenth = o, t.totalIndex = s, t.groupType = this.myGroupcardValueVec[r].type, t.groupText = this.myGroupcardValueVec[r].desc, t.showLaiziFlag(this.isShowLaiziColor(a[i]), false, d), e.setScale(this.cardScale), e.setSiblingIndex(s), this.cardViewVec.push(e), s += 1);
            }
        }
        this.showMyGroupCards(this.myGroupcardValueVec);
    }
    fanLaizi() {
        if (this.paiduiCardVec.length > 0) {
            for (let i = 0, e = this.paiduiCardVec.length; i < e; i++) {
                ToolUtils.isObjValid(this.paiduiCardVec[i]) && this.putCardNode(this.paiduiCardVec[i]);
            }
        }
        if (this.paiduiCardVec = [], !ToolUtils.isObjValid(this.lzCard)) {
            this.lzCard = this.getCardNode();
            this.lzCard.getComponent("RummyCard").init(RummyDataManager.shared().rummyInfos.get(this.tid_key).laiziFlopCard, false);
            this.lzCard.setScale(this.outcardScale);
            this.lzCard.setPosition(this.paiduiPoint);
            this.lzCard.active = false;
            this.paidui_node.insertChild(this.lzCard, 0);
            this.lzCard.setSiblingIndex(0);
        }
        let i, e, t = RummyDataManager.shared().rummyInfos.get(this.tid_key).close_cardnum;
        for (let a = 0; a < t; a++) {
            i = this.getCardNode();
            e = i.getComponent("RummyCard");
            e.init(1, true);
            e.setCardTag(a);
            i.setScale(this.outcardScale);
            i.active = !(a < t - 1);
            i.setPosition(RummyCardConstant.centerPos);
            this.paidui_node.addChild(i);
            i.setSiblingIndex(a + 1);
            this.paiduiCardVec.push(i);
        }
        if (this.playEffectByName("rummyFlip"), this.paiduiCardVec.length > 0) {
            let i = 0.26 - 0.02, e = i + 0.06;
            for (let e = 0, t = this.paiduiCardVec.length; e < t; e++) {
                let a = this.paiduiCardVec[e];
                ToolUtils.isObjValid(a) && e === t - 1 && (a.active = true, TweenTool.moveTo(a, i, this.paiduiPoint, null, true, (() => {
                    ToolUtils.isObjValid(a) && a.setPosition(this.paiduiPoint);
                })));
            }
            TweenTool.delayAct(this.delay_node, (() => {
                let i = 0.3 - 0.1;
                if (!this.is_fapai_over) {
                    for (let i = 0, e = this.paiduiCardVec.length; i < e; i++) {
                        let t = this.paiduiCardVec[i];
                        ToolUtils.isObjValid(t) && (t.setPosition(this.paiduiPoint), t.active = !(i <= e - 2));
                    }
                    if (this.is_fapai_over = true, ToolUtils.isObjValid(this.lzCard)) {
                        this.lzCard.setSiblingIndex(0);
                        let e = this.lzCard.getComponent("RummyCard");
                        this.lzCard.active = true;
                        1 == RummyDataManager.shared().rummyInfos.get(this.tid_key).is_bump ? (e.init(RummyDataManager.shared().rummyInfos.get(this.tid_key).laiziFlopCard, false, 3), e.openCard(), e.showLaiziFlag(this.isShowLaiziColor(RummyDataManager.shared().rummyInfos.get(this.tid_key).laizicard), true, true)) : (e.init(RummyDataManager.shared().rummyInfos.get(this.tid_key).laiziFlopCard, false), e.openCard(), e.showLaiziFlag(this.isShowLaiziColor(RummyDataManager.shared().rummyInfos.get(this.tid_key).laizicard), true));
                        this.lzCard.setScale(this.outcardScale);
                        let t = TweenTool.moveTo(this.lzCard, 0.17, v3(this.paiduiPoint.x, this.paiduiPoint.y + 36.8)), a = i - 0.17, s = TweenTool.delayAct(this.delay_node, (() => {
                            let i = TweenTool.moveTo(this.lzCard, a, v3(this.laiziPoint.x, this.laiziPoint.y)), e = TweenTool.rotateTo(this.lzCard, a, v3(0, 0, 90));
                            TweenTool.parallel(this.lzCard, true, (() => {
                                ToolUtils.isObjValid(this.lzCard) && (this.lzCard.setPosition(this.laiziPoint), this.lzCard.angle = 90, this.lzCard.active = true);
                            }), i, e);
                        }), 0);
                        TweenTool.sequence(this.lzCard, true, null, t, s);
                    }
                    if (0 == RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyMode) {
                        let i = 0.2, e = 0.2;
                        TweenTool.delayAct(this.delay_node, (() => {
                            let i = this.createQiPaiCard(RummyDataManager.shared().rummyInfos.get(this.tid_key).dc_card);
                            ToolUtils.isObjValid(i) && TweenTool.moveTo(i, e, this.qipaiPoint, null, true, (() => {
                                let e = TweenTool.scaleTo(i, 0.1, v3(0, RummyCardConstant.OutcardScale.y), null, false, (() => {
                                    if (ToolUtils.isObjValid(i)) {
                                        let e = i.getComponent("RummyCard");
                                        e.openCard();
                                        1 == RummyDataManager.shared().rummyInfos.get(this.tid_key).is_bump ? e.showLaiziFlag(this.isShowLaiziColor(RummyDataManager.shared().rummyInfos.get(this.tid_key).dc_card), false, true) : e.showLaiziFlag(this.isShowLaiziColor(RummyDataManager.shared().rummyInfos.get(this.tid_key).dc_card));
                                    }
                                })), t = TweenTool.scaleTo(i, 0.16, RummyCardConstant.OutcardScale, null, false, (() => {
                                    this.changeEasyModeOutCardGray(i);
                                }));
                                TweenTool.sequence(i, true, null, e, t);
                            }));
                        }), i, true);
                    }
                }
            }), e, true);
        }
    }
    createQiPaiCard(i) {
        let e, t = this.getCardNode();
        for (let i = 0, t = this.qipaiCards.length; i < t; i++) {
            e = this.qipaiCards[i];
            ToolUtils.isObjValid(e) && this.putCardNode(e);
        }
        return this.qipaiCards = [], this.qipai_node.removeAllChildren(), t.getComponent("RummyCard").init(RummyDataManager.shared().rummyInfos.get(this.tid_key).dc_card, true), t.setScale(this.outcardScale), t.setPosition(this.paiduiPoint), this.qipaiCards.push(t), this.qipai_node.addChild(t), t;
    }
    getshouPaiPositions(i, e) {
        this.myGroupcardValueVec = i;
        let t = i.length, a = e, s = 2 * RummyCardConstant.cebianW, r = (t - 1) * this.cardSpaceGroup, d = t * this.cardWidth, o = (RummyCardConstant.ScreenWidth - s - r - d) / (1 * (a - t)), h = this.cardStartPosX, l = this.cardWidth + this.cardSpaceGroup - o;
        this.spXpositionDeq = [];
        let n = 0, c = 0, u = [];
        this.cardsPostions = [];
        for (let e = 0; e < t; e++) {
            u = i[e].cardVec;
            for (let i = 0, t = u.length; i < t; i++) {
                c = h + o * n + e * l;
                this.cardsPostions.push(v3(c, this.middlePosY));
                n += 1;
                this.spXpositionDeq.push(c);
            }
        }
    }
    showMyGroupCards(i) {
        this.myGroupcardValueVec = i;
        let e = i.length;
        if (this.getshouPaiPositions(i, 13), this.cardValueVec.length > 0) {
            this.cardValueVec = [];
            let t = [];
            for (let a = 0; a < e; a++) {
                t = i[a].cardVec;
                for (let i = 0, e = t.length; i < e; i++) {
                    this.cardValueVec.push(t[i]);
                }
            }
        }
        let t, a = 0.18;
        1 == e && (a = 0);
        for (let i = 0, e = this.cardViewVec.length; i < e; i++) {
            let e = this.cardViewVec[i];
            ToolUtils.isObjValid(e) && (t = e.getComponent("RummyCard"), t.setCardTag(i), t.changeCardStatus(false), TweenTool.moveTo(e, a, v3(this.spXpositionDeq[i], this.middlePosY, 0), null, true, (() => {
                ToolUtils.isObjValid(e) && (t.beforeMovingPos = this.cardsPostions[i], e.getPosition(t.beforeMovingPos));
            })));
        }
        let s = a + 0;
        1 == e && (s = 0);
        TweenTool.delayAct(this.delay_node, (() => {
            this.hasFaPaiAnimEnded = true;
            this.refreshAllGroupInfo();
        }), s, true);
    }
    showTipsCards(i) {
        this.hideCardTipsGlow();
        this.refreshTipCard(i);
        sys.isObjectValid(i.cards) && (this.tipCardMsg = i, this.cardTipsAct = TweenTool.delayAct(this.delay_node, (() => {
            this.hideCardTipsGlow();
        }), 3, true));
    }
    showHighTipsCards(i, e = -1) {
        this.hideCardTipsGlow();
        this.refreshTipCard({ cards: i, group_index: e });
        this.tipCardMsg = { cards: i, group_index: e };
    }
    showDiscardTips() {
        if (0 != RummyDataManager.shared().rummyInfos.get(this.tid_key).disCardTipsValue) {
            for (let i = this.cardViewVec.length - 1; i >= 0; i--) {
                let e = this.cardViewVec[i].getComponent("RummyCard");
                if (e.mCardValue == RummyDataManager.shared().rummyInfos.get(this.tid_key).disCardTipsValue) {
                    e.showDiscardTipsFlag(true);
                    break;
                }
            }
        }
    }
    showPickCardTips(i, e) {
        this.pickCardNode.active = i;
        sys.isObjectValid(e) && (1 == e ? i18nMgr.shared().changeLabelLanguage(this.pickCardNode.getChildByName("wz").getComponent(Label), "game_setting.draw", true) : 2 == e && i18nMgr.shared().changeLabelLanguage(this.pickCardNode.getChildByName("wz").getComponent(Label), "game_setting.finish", true));
    }
    hideDiscardTips() {
        RummyDataManager.shared().rummyInfos.get(this.tid_key).disCardTipsValue = 0;
        for (let i = this.cardViewVec.length - 1; i >= 0; i--) {
            let e = this.cardViewVec[i];
            if (ToolUtils.isObjValid(e)) {
                let t = this.cardViewVec[i].getComponent("RummyCard");
                t = e.getComponent("RummyCard");
                t.showDiscardTipsFlag(false);
            }
        }
    }
    refreshTipCard(i) {
        let e = false, t = i.group_index;
        if (sys.isObjectValid(t) && t >= 0 && sys.isObjectValid(this.myGroupcardValueVec[t]) && sys.isObjectValid(i.cards)) {
            let a = this.myGroupcardValueVec[t].cardVec;
            for (let t = 0, s = i.cards.length; t < s; t++) {
                e = false;
                for (let s = 0, r = a.length; s < r; s++) {
                    if (a[s] == i.cards[t]) {
                        e = true;
                        break;
                    }
                }
                if (!e) {
                    break;
                }
            }
        }
        if (sys.isObjectValid(i.cards)) {
            let a;
            for (let s = 0, r = i.cards.length; s < r; s++) {
                for (let r = this.cardViewVec.length - 1; r >= 0; r--) {
                    if (a = this.cardViewVec[r].getComponent("RummyCard"), e) {
                        if (a.groupIndex == t && a.mCardValue == i.cards[s]) {
                            a.showGlowFlag(true);
                            break;
                        }
                    }
                    else if (a.mCardValue == i.cards[s]) {
                        a.showGlowFlag(true);
                        break;
                    }
                }
            }
        }
    }
    hideCardTipsGlow() {
        let i;
        this.tipCardMsg = null;
        RummyDataManager.shared().stopTweenAction(this.cardTipsAct);
        for (let e = 0, t = this.cardViewVec.length; e < t; e++) {
            i = this.cardViewVec[e].getComponent("RummyCard");
            i.showGlowFlag(false);
        }
    }
    dayingshoupaiData(i) {
    }
    getCardNode() {
        let i = null;
        i = this.cardsViewPool.size() > 0 ? this.cardsViewPool.get() : instantiate(this.cardPrefab);
        i.active = true;
        try {
            null === i.getComponent("RummyCard") || i.getComponent("RummyCard");
            i.getComponent("RummyCard").resetCards();
        }
        catch (i) {
            TLog.printError("trycatch getCardNode,error:", i);
        }
        return i;
    }
    putCardNode(i) {
        ToolUtils.isObjValid(i) && (i.getComponent(RummyCard).resetCards(), TweenTool.stopNodeAction(i), i.active = false, this.cardsViewPool && this.cardsViewPool.put(i));
    }
    getGroupFlagNode() {
        let i = null;
        return i = this._groupFlagsPool.size() > 0 ? this._groupFlagsPool.get() : instantiate(this.node.getChildByName("grop_flag")), i.active = true, i;
    }
    putGroupFlagNode(i) {
        TweenTool.stopNodeAction(i);
        i.active = false;
        this._groupFlagsPool && this._groupFlagsPool.put(i);
    }
    getAvailableFlagNode() {
        let i = null;
        return i = this.availableFlagsPool.size() > 0 ? this.availableFlagsPool.get() : instantiate(this.node.getChildByName("available_flag")), i.active = true, i;
    }
    putAvailableFlagNode(i) {
        TweenTool.stopNodeAction(i);
        i.active = false;
        this.availableFlagsPool && this.availableFlagsPool.put(i);
    }
    // A stationary deck card must not inherit a partial fade or an open face.
    // Do not touch cards already moved into the hand/discard animation layers.
    restoreDeckCard(card) {
        if (!ToolUtils.isObjValid(card) || card.parent !== this.paidui_node || card === this.lzCard) {
            return;
        }
        TweenTool.stopNodeAction(card);
        const opacity = card.getComponent(UIOpacity);
        if (opacity) opacity.opacity = 255;
        card.getComponent("RummyCard").changeCardToBack();
        card.active = true;
        card.setScale(this.outcardScale);
        card.setPosition(this.paiduiPoint);
    }
    checkIfHasPaidui(i) {
        let e = this.paiduiCardVec.length;
        if (e !== i) {
            this.showPaiduiCards();
        }
        else {
            let i, t = 0;
            for (let a = 0; a < e; a++) {
                i = this.paiduiCardVec[a];
                ToolUtils.isObjValid(i) && (a === e - 1 && this.restoreDeckCard(i), t += 1);
            }
            0 === t && this.addPaiDuiCard();
        }
    }
    setHandCardValueStar(i = -1, e = -1, t = -1) {
        this._nHandCardValue = i;
        this._nHandCardStar = e;
        this._nHandCardColor = t;
    }
    refreshCardValueTip(i) {
        this._with_open = i;
        this.cardValueNode.active && this.setCardValueTipShow(true, true);
    }
    changeCardValueTipsVisible(i) {
        let e = this.cardValueNode.getChildByName("tips");
        e && (e.active = 0 != i);
    }
    setCardValueTipShow(i, e = false) {
        if ((!i || -1 != this._nHandCardValue && -1 != this._nHandCardStar && -1 != this._nHandCardColor) && ToolUtils.isObjValid(this.cardValueNode)) {
            try {
                if (i && this.cardValueNode.active && true, this.cardValueNode.active = i, i) {
                    TweenTool.stopNodeAction(this.cardValueNode);
                    this.cardValueNode.getChildByName("num").active = false;
                    let i = Math.floor(10 * this._nHandCardValue) / 10, e = Math.floor(10 * this._nHandCardStar) / 10;
                    e > 5 && (e = 5);
                    let t, a = ToolUtils.parse_double("" + i, 1), s = ToolUtils.parse_double("" + e, 1), r = color(181, 181, 181, 255);
                    3 == this._nHandCardColor ? r = color(40, 238, 59, 255) : 2 == this._nHandCardColor && (r = color(243, 163, 8, 255));
                    for (let i = 0; i < 5; i++) {
                        t = this.cardValueNode.getChildByName("star" + i);
                        t.active = false;
                    }
                    let d = 0.17, o = v3(this._cardValuePos.x - 6, this._cardValuePos.y, this._cardValuePos.z);
                    this.cardValueNode.setPosition(v3(this._cardValuePos.x + 500, this._cardValuePos.y, this._cardValuePos.z));
                    TweenTool.moveTo(this.cardValueNode, 0.17, o, "cubicOut", true, (() => {
                        this.cardValueNode.setPosition(o);
                        TweenTool.moveTo(this.cardValueNode, 0.1, this._cardValuePos, "cubicOut", true, (() => {
                            this.cardValueNode.setPosition(this._cardValuePos);
                        }));
                    }));
                    d += 0.17;
                    let h = Math.floor(s), l = h;
                    for (let i = 0; i < h; i++) {
                        TweenTool.delayAct(this.delay_node, (() => {
                            t = this.cardValueNode.getChildByName("star" + i);
                            setHandRatingStarSprite(t.getComponent(Sprite), this.cardStarIco[0], false);
                            t.getComponent(Sprite).color = color(r.r, r.g, r.b, 0);
                            t.setScale(v3(0.3, 0.3, 0.3));
                            t.active = true;
                            TweenTool.stopNodeAction(t);
                            let e = tween(t).to(0.1, { scale: v3(1.3, 1.3, 1.3) }).to(0.1, { scale: v3(1.4, 1.4, 1.4) }).to(0.17, { scale: v3(1, 1, 1) }), a = TweenTool.moveSpriteByFade(t, 0.37, t.position, 0, 1);
                            TweenTool.parallel(t, true, (() => {
                                t.setScale(v3(1, 1, 1));
                                t.getComponent(Sprite).color = r;
                            }), e, a);
                        }), d + 0.07 * i, true);
                    }
                    s - h >= 0.1 && (TweenTool.delayAct(this.delay_node, (() => {
                        t = this.cardValueNode.getChildByName("star" + h);
                        setHandRatingStarSprite(t.getComponent(Sprite), this.cardStarIco[0], true);
                        t.getComponent(Sprite).color = color(r.r, r.g, r.b, 0);
                        t.setScale(v3(0.3, 0.3, 0.3));
                        t.active = true;
                        TweenTool.stopNodeAction(t);
                        let i = tween(t).to(0.1, { scale: v3(1.3, 1.3, 1.3) }).to(0.1, { scale: v3(1.4, 1.4, 1.4) }).to(0.17, { scale: v3(1, 1, 1) }), e = TweenTool.moveSpriteByFade(t, 0.37, t.position, 0, 1);
                        TweenTool.parallel(t, true, (() => {
                            t.setScale(v3(1, 1, 1));
                            t.getComponent(Sprite).color = r;
                        }), i, e);
                    }), d + 0.07 * h, true), l = h + 1);
                    for (let i = l; i < 5; i++) {
                        t = this.cardValueNode.getChildByName("star" + i);
                        t.active = false;
                    }
                    d += 0.07 * l;
                    d += 0.17;
                    TweenTool.delayAct(this.delay_node, (() => {
                        let i = this.cardValueNode.getChildByName("num");
                        i.getComponent(Label).string = "" + a;
                        i.getComponent(Label).color = color(r.r, r.g, r.b, 0);
                        i.setScale(v3(0.5, 0.5, 0.5));
                        i.active = true;
                        TweenTool.stopNodeAction(i);
                        let e = tween(i).to(0.1, { scale: v3(1.3, 1.3, 1.3) }).to(0.1, { scale: v3(1.4, 1.4, 1.4) }).to(0.17, { scale: v3(1, 1, 1) }), t = TweenTool.moveLabelByFade(i, 0.37, i.position, 0, 1);
                        TweenTool.parallel(i, true, (() => {
                            i.setScale(v3(1, 1, 1));
                            i.getComponent(Label).color = r;
                        }), e, t);
                    }), d, true);
                }
            }
            catch (i) {
                TLog.printError("---- showCardValueTip error:", i);
            }
        }
    }
    hideTingPaiTips() {
        let i, e;
        for (let t = this.cardViewVec.length - 1; t >= 0; t--) {
            i = this.cardViewVec[t];
            ToolUtils.isObjValid(i) && (e = i.getComponent("RummyCard"), e.showTingPaiTipsFlag(false), e.showLightTingPaiTipsFlag(false));
        }
    }
    checkHasTingPaiTip(i, hand) {
        let t = false;
        if (RummyDataManager.shared().getCanShowTingPai() && i && i.listen_info && Array.isArray(i.listen_info) && Array.isArray(hand)) {
            let a, s, r;
            for (let d = 0; d < hand.length; d++) {
                if (s = hand[d], s.cards) {
                    for (let e = 0; e < s.cards.length; e++) {
                        r = s.cards[e];
                        for (let e = 0; e < i.listen_info.length; e++) {
                            if (a = i.listen_info[e], (0 == a.lost || a.card == r) && !isMeldedGroup(s, hand)) {
                                t = true;
                                break;
                            }
                        }
                        if (t) {
                            break;
                        }
                    }
                }
                if (t) {
                    break;
                }
            }
        }
        return t;
    }
    showTingPaiTips(i, e = false) {
        if (i && i.listen_info && Array.isArray(i.listen_info) && 14 == this.cardViewVec.length) {
            let t, a, s, r = false, d = false;
            for (let o = this.cardViewVec.length - 1; o >= 0; o--) {
                if (t = this.cardViewVec[o], ToolUtils.isObjValid(t)) {
                    a = t.getComponent("RummyCard");
                    for (let t = 0; t < i.listen_info.length; t++) {
                        if (s = i.listen_info[t], 0 == s.lost && s.card == a.mCardValue) {
                            d = true;
                            let i = -1;
                            e ? (r = true, a.showLightTingPaiTipsFlag(false, false, i), a.showTingPaiTipsFlag(false)) : !isMeldedGroup(a, this.myGroupcardValueVec) && (i = s.finish_num, a.showTingPaiTipsFlag(true, i, (i => {
                                this.transferTingPaiInfo(i);
                            })));
                            break;
                        }
                    }
                    if (r) {
                        break;
                    }
                }
            }
            if (!r) {
                let e = 0, r = -1;
                for (let o = this.cardViewVec.length - 1; o >= 0; o--) {
                    if (t = this.cardViewVec[o], ToolUtils.isObjValid(t)) {
                        a = t.getComponent("RummyCard");
                        for (let t = 0; t < i.listen_info.length; t++) {
                            if (s = i.listen_info[t], 0 != s.card && s.card == a.mCardValue && !isMeldedGroup(a, this.myGroupcardValueVec)) {
                                s.finish_num > e && (e = s.finish_num);
                                (-1 == r || ToolUtils.getCardInfo(s.card).cardFen > ToolUtils.getCardInfo(r).cardFen) && (r = s.card);
                                a.showTingPaiTipsFlag(true, s.finish_num, (i => {
                                    this.transferTingPaiInfo(i);
                                }));
                                d = true;
                                break;
                            }
                        }
                    }
                }
                let o = RummyDataManager.shared().rummyInfos.get(this.tid_key);
                if (o && 1 == o.all_finish_num_open) {
                    let o = [], h = [], l = [], n = [];
                    for (let d = this.cardViewVec.length - 1; d >= 0; d--) {
                        if (t = this.cardViewVec[d], ToolUtils.isObjValid(t)) {
                            a = t.getComponent("RummyCard");
                            for (let d = 0; d < i.listen_info.length; d++) {
                                s = i.listen_info[d];
                                0 != s.card && s.card == a.mCardValue && isMeldedGroup(a, this.myGroupcardValueVec) && s.finish_num > e && 3 == a.groupType && s.finish_num > e ? (l.push(t), n.push(s)) : 0 != s.card && s.card == a.mCardValue && isMeldedGroup(a, this.myGroupcardValueVec) && 3 == a.groupType && ToolUtils.getCardInfo(s.card).cardFen > ToolUtils.getCardInfo(r).cardFen && (o.push(t), h.push(s));
                            }
                        }
                    }
                    if (n.length > 0) {
                        let i = this.getBestBlueTingPaiInfo(n);
                        for (let e = 0; e < l.length; e++) {
                            if (t = l[e], ToolUtils.isObjValid(t) && (a = t.getComponent("RummyCard"), i && i.card == a.mCardValue)) {
                                a.showTingPaiTipsFlag(true, i.finish_num, (i => {
                                    this.transferTingPaiInfo(i);
                                }));
                                d = true;
                                break;
                            }
                        }
                    }
                    let c = [], u = [], g = 0, p = 0, m = 0;
                    for (let i = 0; i < this.myGroupcardValueVec.length; i++) {
                        1 == this.myGroupcardValueVec[i].type ? g += 1 : 2 == this.myGroupcardValueVec[i].type ? p += 1 : 3 == this.myGroupcardValueVec[i].type && (m += 1);
                    }
                    if (g >= 1 || p >= 1) {
                        for (let d = 0; d < this.cardViewVec.length; d++) {
                            if (t = this.cardViewVec[d], ToolUtils.isObjValid(t)) {
                                a = t.getComponent("RummyCard");
                                for (let d = 0; d < i.listen_info.length; d++) {
                                    if (s = i.listen_info[d], 0 != s.card && s.card == a.mCardValue && a.groupColor, 0 != s.card && s.card == a.mCardValue && isMeldedGroup(a, this.myGroupcardValueVec) && s.finish_num > e && (1 == a.groupType || 2 == a.groupType)) {
                                        c.push(t);
                                        u.push(s);
                                    }
                                    else if (0 != s.card && s.card == a.mCardValue && isMeldedGroup(a, this.myGroupcardValueVec) && ToolUtils.getCardInfo(s.card).cardFen > ToolUtils.getCardInfo(r).cardFen && (p + m >= 1 || g >= 2) && (1 == a.groupType || 2 == a.groupType)) {
                                        let i = 0 == o.length;
                                        if (o.length > 0) {
                                            let e = o[0].getComponent("RummyCard");
                                            ToolUtils.getCardInfo(s.card).cardFen > ToolUtils.getCardInfo(e.mCardValue).cardFen ? (o = [], h = [], i = true) : i = ToolUtils.getCardInfo(s.card).cardFen == ToolUtils.getCardInfo(e.mCardValue).cardFen;
                                        }
                                        i && (o.push(t), h.push(s));
                                    }
                                }
                            }
                        }
                    }
                    if (u.length > 0) {
                        let i = this.getBestBlueTingPaiInfo(u);
                        for (let e = 0; e < c.length; e++) {
                            if (t = c[e], ToolUtils.isObjValid(t) && (a = t.getComponent("RummyCard"), i && i.card == a.mCardValue)) {
                                a.showTingPaiTipsFlag(1 == i.after_out_tow_vaild, i.finish_num, (i => {
                                    this.transferTingPaiInfo(i);
                                }));
                                d = true;
                                break;
                            }
                        }
                    }
                    if (h.length > 0) {
                        for (let i, e = 0; e < o.length; e++) {
                            t = o[e];
                            i = h[e];
                            ToolUtils.isObjValid(t) && (a = t.getComponent("RummyCard"), a.showTingPaiTipsFlag(1 == i.after_out_tow_vaild, i.finish_num, (i => {
                                this.transferTingPaiInfo(i);
                            })), d = true);
                        }
                    }
                }
            }
            if (d) {
                RummyDataManager.shared().rummyInfos.get(this.tid_key).disCardTipsValue = 0;
                for (let i = this.cardViewVec.length - 1; i >= 0; i--) {
                    t = this.cardViewVec[i];
                    ToolUtils.isObjValid(t) && (a = t.getComponent("RummyCard"), a.showDiscardTipsFlag(false));
                }
            }
        }
    }
    getBestBlueTingPaiInfo(i) {
        let e = (t = i, t.reduce(((i, e) => e.finish_num >= i.finish_num ? e : i))).finish_num;
        var t;
        return function (i) {
            return i.reduce(((i, e) => e.card >= i.card ? e : i));
        }(i.filter((i => i.finish_num == e)));
    }
    getTingPaiMinLostInfos(i) {
        if (i && Array.isArray(i) && i.length > 0) {
            let t, a, s, r = [];
            for (let e = this.cardViewVec.length - 1; e >= 0; e--) {
                if (t = this.cardViewVec[e], ToolUtils.isObjValid(t)) {
                    a = t.getComponent("RummyCard");
                    for (let e = 0; e < i.length; e++) {
                        if (s = i[e], 0 != s.card && s.card == a.mCardValue && !isMeldedGroup(a, this.myGroupcardValueVec)) {
                            r.push(s);
                            break;
                        }
                    }
                }
            }
            if (Array.isArray(r) && r.length > 0) {
                let i = (e = r, e.reduce(((i, e) => e.finish_num > i.finish_num ? e : i))).finish_num, t = r.filter((e => e.finish_num == i));
                let a = function (i) {
                    return i.reduce(((i, e) => e.lost < i.lost ? e : i));
                }(t).lost;
                return t.filter((i => i.lost == a));
            }
        }
        var e;
        return [];
    }
    findMaxNumber(i) {
        return i.reduce(((i, e) => e > i ? e : i));
    }
    showHelperQuickFinishCard(i, e = true, t = null) {
        for (let t = this.cardViewVec.length - 1; t >= 0; t--) {
            let a = this.cardViewVec[t];
            if (ToolUtils.isObjValid(a)) {
                let t = a.getComponent("RummyCard");
                if (t.mCardValue == i) {
                    e && t.changeCardStatus(true);
                    break;
                }
            }
        }
    }
    transferTingPaiInfo(i) {
        let e = { tingPai: true, cardCompent: i };
        this.tingpaiCallback && this.tingpaiCallback(e);
    }
    resetMyCardsPostion() {
        for (let i = this.cardViewVec.length - 1; i >= 0; i--) {
            let e = this.cardViewVec[i];
            if (ToolUtils.isObjValid(e)) {
                e.getComponent("RummyCard").changeCardStatus(false);
            }
        }
    }
    getQuickHuCard(i) {
        let e = null;
        for (let t = this.cardViewVec.length - 1; t >= 0; t--) {
            let a = this.cardViewVec[t];
            if (ToolUtils.isObjValid(a)) {
                if (a.getComponent("RummyCard").mCardValue == i) {
                    e = a;
                    break;
                }
            }
        }
        return e;
    }
    changeHandRating(i) {
        this.cardValueNode && (this.cardValueNode.active = i);
    }
    showLastQipaiCard(i) {
        let e, t, a;
        if (this.qipaiCards.length > 0) {
            let e = this.qipaiCards.length - 1;
            ToolUtils.isObjValid(this.qipaiCards[e]) && (t = this.qipaiCards[e].getComponent("RummyCard"), t.mCardValue == i && (a = true));
        }
        if (!a) {
            e = this.getCardNode();
            t = e.getComponent("RummyCard");
            t.init(i, false);
            t.openCard();
            let a = RummyDataManager.shared().rummyInfos.get(this.tid_key);
            1 == a.is_bump ? a.winLaizicard > 0 ? t.showLaiziFlag(this.isShowLaiziColor(i, a.winLaizicard)) : t.showLaiziFlag(this.isShowLaiziColor(i), false, true) : t.showLaiziFlag(this.isShowLaiziColor(i));
            e.setPosition(this.qipaiPoint);
            e.setScale(this.outcardScale);
            e.active = true;
            this.qipai_node.insertChild(e, this.qipaiCards.length);
            this.qipaiCards.push(e);
        }
    }
    restoreTingPaiTips() {
        for (let i = this.cardViewVec.length - 1; i >= 0; i--) {
            let e = this.cardViewVec[i];
            if (ToolUtils.isObjValid(e)) {
                let i = e.getComponent("RummyCard");
                (i.tingpaiTips2Node.active || 2 == i.tingpai_type) && i.changTingPaiTipsStatus(false);
            }
        }
    }
    changeTingPaiStatus(i) {
        for (let e = this.cardViewVec.length - 1; e >= 0; e--) {
            let t = this.cardViewVec[e];
            if (ToolUtils.isObjValid(t)) {
                let e = t.getComponent("RummyCard");
                i == e ? 2 == i.tingpai_type ? i.changTingPaiTipsStatus(false) : 1 == i.tingpai_type && i.changTingPaiTipsStatus(true) : (2 == e.tingpai_type || e.tingpaiTips2Node.active) && e.changTingPaiTipsStatus(false);
            }
        }
    }
    getLightTingPaiIndex() {
        let i = -1;
        for (let e = this.cardViewVec.length - 1; e >= 0; e--) {
            let t = this.cardViewVec[e];
            if (ToolUtils.isObjValid(t)) {
                if (2 == t.getComponent("RummyCard").tingpai_type) {
                    i = e;
                    break;
                }
            }
        }
        return i;
    }
    showtLightTingPai(i) {
        let e = -1;
        for (let t = this.cardViewVec.length - 1; t >= 0; t--) {
            let a = this.cardViewVec[t];
            if (ToolUtils.isObjValid(a)) {
                let s = a.getComponent("RummyCard");
                if (1 == s.tingpai_type && i == s.mCardValue) {
                    e = t;
                    break;
                }
            }
        }
        for (let i = this.cardViewVec.length - 1; i >= 0; i--) {
            let t = this.cardViewVec[i];
            if (ToolUtils.isObjValid(t)) {
                let a = t.getComponent("RummyCard");
                if (1 == a.tingpai_type && i == e) {
                    a.changTingPaiTipsStatus(true);
                    break;
                }
            }
        }
    }
    getShouPaiCardValues() {
        let i = [];
        for (let e = 0, t = this.cardViewVec.length; e < t; e++) {
            let t = this.cardViewVec[e];
            if (ToolUtils.isObjValid(t)) {
                let e = t.getComponent("RummyCard");
                i.push(e.mCardValue);
            }
        }
        return i;
    }
    getShouPaiGroupCardValues() {
        let i = [];
        for (let e = 0, t = this.myGroupcardValueVec.length; e < t; e++) {
            i[e] = [];
            let t = this.myGroupcardValueVec[e].cardVec;
            for (let a = 0, s = t.length; a < s; a++) {
                i[e][a] = t[a];
            }
        }
        return i;
    }
    getFapaiGroupCardValues(i) {
        let e = [];
        for (let t = 0, a = i.length; t < a; t++) {
            let a = i[t].cardVec;
            for (let i = 0, t = a.length; i < t; i++) {
                e.push(a[i]);
            }
        }
        return e;
    }
    getCardValueShow() {
        let i = false;
        return ToolUtils.isObjValid(this.cardValueNode) && (i = this.cardValueNode.active), i;
    }
    updateOpenLaiziCard() {
        if (this.qipaiCards.length > 0 && this.seeverOpenCards.length > 0) {
            let i = this.seeverOpenCards[this.qipaiCards.length - 1], e = this.qipaiCards[this.qipaiCards.length - 1];
            if (ToolUtils.isObjValid(e)) {
                let t = e.getComponent("RummyCard");
                if (t.mCardValue == i) {
                    let e = RummyDataManager.shared().rummyInfos.get(this.tid_key), a = 1 == e.is_bump && e.game_state < 4;
                    t.init(i);
                    t.showLaiziFlag(this.isShowLaiziColor(i), false, a);
                }
            }
        }
    }
    updateRealLaiziCard(i) {
        RummyDataManager.shared().rummyInfos.get(this.tid_key);
        if (ToolUtils.isObjValid(this.lzCard)) {
            let e = this.lzCard.getComponent("RummyCard");
            e.init(i.lz_card);
            e.showLaiziFlag(this.isShowLaiziColor(i.lz_card), true);
        }
        this.updateOpenLaiziCard();
    }
    updateBestLaizi() {
        let i = RummyDataManager.shared().rummyInfos.get(this.tid_key), e = this.node.getChildByName("bump_best_bubble");
        if (i.best_lz > 0) {
            if (ToolUtils.getCardInfo(i.best_lz).point == ToolUtils.getCardInfo(i.laizicard).point) {
                e.active = false;
            }
            else {
                let t = e.getChildByName("card").getChildByName("bestLaizi");
                ToolUtils.isObjValid(t) || (t = instantiate(this.cardPrefab));
                t.name = "bestLaizi";
                t.setScale(v3(0.58, 0.58, 0.58));
                t.setPosition(v3(0, 0, 0));
                let a = t.getComponent("RummyCard");
                a.init(i.best_lz, false, 1);
                a.openCard();
                a.showJsLaiziFlag(false);
                e.getChildByName("card").addChild(t);
                e.active = true;
            }
        }
        else {
            e.active = false;
        }
    }
    hideBestLaiziBubble() {
        let i = this.node.getChildByName("bump_best_bubble");
        ToolUtils.isObjValid(i) && (i.active = false);
    }
    updateCurBumpLaizi() {
        let i = RummyDataManager.shared().rummyInfos.get(this.tid_key);
        if (ToolUtils.isObjValid(this.lzCard) && 1 == i.is_bump) {
            let e = this.lzCard.getComponent("RummyCard");
            e.init(i.laizicard, false, 3);
            e.openCard();
            e.showLaiziFlag(this.isShowLaiziColor(i.laizicard), true, true);
        }
        if (this.qipaiCards.length > 0 && 1 == i.is_bump) {
            let e = this.qipaiCards.length;
            if (ToolUtils.isObjValid(this.qipaiCards[e - 1])) {
                let t = this.qipaiCards[e - 1].getComponent("RummyCard");
                t.showLaiziFlag(this.isShowLaiziColor(t.mCardValue, i.laizicard), false, true);
            }
        }
    }
    showBumpLaiziTipAnim() {
        if (this.cardViewVec && this.cardViewVec.length > 0) {
            let i, e, t = RummyDataManager.shared().rummyInfos.get(this.tid_key).laizicard;
            for (let a = 0, s = this.cardViewVec.length; a < s; a++) {
                i = this.cardViewVec[a];
                ToolUtils.isObjValid(i) && (e = i.getComponent("RummyCard"), this.isShowLaiziColor(e.mCardValue, t) && e.showBumpLaiziTipAnim());
            }
        }
    }
    hideBumpLaiziTipAnim() {
        if (this.cardViewVec && this.cardViewVec.length > 0) {
            let i, e;
            for (let t = 0, a = this.cardViewVec.length; t < a; t++) {
                i = this.cardViewVec[t];
                ToolUtils.isObjValid(i) && (e = i.getComponent("RummyCard"), e.hideBumpLaiziTipAnim());
            }
        }
    }
    setAvailableCardTipsClose() {
        if (this.availableFlagNodes && this.availableFlagNodes.length > 0) {
            let i;
            for (let e = 0, t = this.availableFlagNodes.length; e < t; e++) {
                i = this.availableFlagNodes[e];
                ToolUtils.isObjValid(i) && this.refreshAvailableFlagType(0, this.availableFlagNodes[e]);
            }
        }
    }
    availableFlagbuttonClick(i, e) {
        SoundManager.shared().playFx("click");
        let t = Number(e);
        this.availableFlagNodes[t] && (this.refreshAvailableFlagType(1, this.availableFlagNodes[t]), this.tingpaiCallback(this.availabeFlagInfos[t]));
    }
}
