// @ts-nocheck
// Recovered from index.js:651
import { _decorator, Label, Node, RichText, sys } from "cc";
import BaseLayer from "./BaseLayer";
import AppInfo from "./AppInfo";
import PushCenter from "./PushCenter";
import { ToolUtils } from "./ToolUtils";
import Utils from "./Utils";
import PushEvent from "./PushEvent";
import SoundManager from "./SoundManager";
const { ccclass, property } = _decorator;
@ccclass("UpdateGuide")
export class UpdateGuide extends BaseLayer {
    @property(Label)
    public tips1: Label = null;
    @property(RichText)
    public tips2: RichText = null;
    @property(Label)
    public tips3: Label = null;
    @property(Label)
    public tips4: Label = null;
    @property(Label)
    public tips5: Label = null;
    @property(Label)
    public tips6: Label = null;
    @property(Label)
    public tips7: Label = null;
    @property(Node)
    public kefuBtnNode: Node = null;
    @property(Node)
    public closeBtn: Node = null;
    public _isNext: boolean = false;
    public _link_url: string = "";
    public _packageName: string = "";
    public mData: any = null;
    start() {
        super.start();
        ToolUtils.startShowAnim(this.node.getChildByName("bgView"));
    }
    initAnnoucement(e, t = false) {
        if (this.mData = e, e) {
            if (e.exe.reward_num && e.exe.tip2) {
                let t = e.exe.tip2.split("{0}"), i = e.exe.tip2;
                1 == t.length ? i = `<color=#FE8484>${t[0]}</color>` : 2 == t.length && (i = `<color=#FE8484>${t[0]}</color><color=#FFF25E> ${"₹" + e.exe.reward_num}</color><color=#FE8484>${t[1]}</color>`);
                this.tips2.string = i;
            }
            else {
                this.tips2.string = `<color=#FE8484>${e.exe.tip2}</color>`;
            }
            e.exe.tip1 && (this.tips1.string = e.exe.tip1);
            e.exe.tip3 && (this.tips3.string = e.exe.tip3);
            e.exe.tip4 && (this.tips4.string = e.exe.tip4);
            e.exe.tip5 && (this.tips5.string = e.exe.tip5);
            e.exe.tip6 && (this.tips6.string = e.exe.tip6);
            e.exe.tip7 && (this.tips7.string = e.exe.tip7);
            sys.isObjectValid(e.exe.contact_us) && 1 == e.exe.contact_us ? this.kefuBtnNode.active = true : this.kefuBtnNode.active = false;
            sys.isObjectValid(e.exe.can_close) && 1 == e.exe.can_close ? this.closeBtn.active = true : this.closeBtn.active = false;
            sys.isObjectValid(e.exe.link_url) && e.exe.link_url.length > 0 && (this._link_url = e.exe.link_url);
            sys.isObjectValid(e.exe.packageName) && e.exe.packageName.length > 0 && (this._packageName = e.exe.packageName);
        }
        this._isNext = t;
    }
    onButtonClick(e, t) {
        if (SoundManager.shared().playFx("click"), "close" == t) {
            sys.isObjectValid(this.mData) && sys.isObjectValid(this.mData.exe.can_close) && 1 == this.mData.exe.can_close && ToolUtils.isObjValid(this.node) && (this._isNext && PushCenter.shared().pushEvent(PushEvent.Update_NextPopActivity), this.node.destroy());
        }
        else if ("okay" == t) {
            if (this._packageName.length > 0 && 1 === AppInfo.shared().checkPackageInstalled(this._packageName)) {
                return void AppInfo.shared().shareTextToApp(this._packageName, "");
            }
            this._link_url.length > 0 && sys.openURL(this._link_url);
        }
        else {
            "kefu" == t && Utils.shared().showContactUsView();
        }
    }
    onBackView() {
        sys.isObjectValid(this.mData) && sys.isObjectValid(this.mData.exe.can_close) && 1 == this.mData.exe.can_close && ToolUtils.isObjValid(this.node) && (this._isNext && PushCenter.shared().pushEvent(PushEvent.Update_NextPopActivity), this.node.destroy());
    }
}
