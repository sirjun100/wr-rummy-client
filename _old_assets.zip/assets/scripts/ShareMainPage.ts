// @ts-nocheck
// Recovered from index.js:513
import { _decorator, Component, color, find, instantiate, Label, Layout, Node, RichText, ScrollView, size, Sprite, SpriteAtlas, SpriteFrame, sys, tween, UITransform, v3, Widget } from "cc";
import PushCenter from "./PushCenter";
import { TLog } from "./TLog";
import { TransferPlatform } from "./TransferPlatform";
import Utils from "./Utils";
import i18nMgr from "./i18nMgr";
import User from "./User";
import HttpManager from "./HttpManager";
import SoundManager from "./SoundManager";
import TableViewUtils from "./TableViewUtils";
import { ToolUtils } from "./ToolUtils";
import TweenTool from "./TweenTool";
import CommDefine from "./CommDefine";
import GameConfig from "./GameConfig";
import PushEvent from "./PushEvent";
import ReportConfig from "./ReportConfig";
import PhpReportDefined from "./PhpReportDefined";
const { ccclass, property } = _decorator;
@ccclass("ShareMainPage")
export class ShareMainPage extends Component {
    @property(Node)
    public earnNode: Node = null;
    @property(Node)
    public workNode: Node = null;
    @property(Node)
    public homeNode: Node = null;
    @property(Node)
    public scrollViewNode: Node = null;
    @property(Node)
    public rankMoban: Node = null;
    @property(Node)
    public tabNode: Node = null;
    @property(Node)
    public bannerNode: Node = null;
    @property(Node)
    public rewardTipNode: Node = null;
    @property(Node)
    public hisTitleNode: Node = null;
    @property(Node)
    public hisboardNode: Node = null;
    @property(Node)
    public hisNoDataNode: Node = null;
    @property(Node)
    public hisMobanNode: Node = null;
    @property([SpriteFrame])
    public bannerImgs: SpriteFrame[] = [];
    @property(Node)
    public hisScrollViewNode: Node = null;
    @property(Node)
    public whatsappNode: Node = null;
    @property(SpriteAtlas)
    public spAtlas617: SpriteAtlas = null;
    @property(SpriteFrame)
    public shareBannerSpFrame: SpriteFrame = null;
    @property(Label)
    public broadcastLabel: Label = null;
    @property(RichText)
    public broadcastRichLabel: RichText = null;
    public share_url: any = null;
    public share_text: string = "";
    public inviteData: any = null;
    public lastTime: number = 0;
    public curTab: number = 0;
    public tabWzColor: any[] = [color(147, 11, 11), color(102, 102, 102)];
    public detailTabView: any = null;
    public _hasNextPage: number = 0;
    public _hasNextRankPage: number = 0;
    public isSendMsg: boolean = false;
    public already_data: any[] = [];
    public _page: number = 0;
    public _rank_page: number = 0;
    public carouseldata: any[] = [];
    public broadcastLabelTween: any = null;
    onLoad() {
        if (this.addNotify(), this.fitLuckyTheme(), ToolUtils.adaptSafeArea(this.node.getChildByName("root")), 1 == GameConfig.CHIPS_MODLE ? (this.bannerNode.getComponent(Sprite).spriteFrame = this.bannerImgs[2], this.workNode.getChildByName("ico").getComponent(Sprite).spriteFrame = this.bannerImgs[3], this.node.getChildByName("root").getChildByName("titlenode").getChildByName("title").getComponent(Label).string = "REFER", this.broadcastLabel.node.parent.active = false, this.scrollViewNode.getComponent(Widget).bottom = 0) : (this.bannerNode.getComponent(Sprite).spriteFrame = this.bannerImgs[GameConfig.GAME_HALL_THEME], this.workNode.getChildByName("ico").getComponent(Sprite).spriteFrame = this.bannerImgs[4], this.broadcastLabel.node.parent.active = true, this.scrollViewNode.getComponent(Widget).bottom = 10), 1 == GameConfig.GAME_HALL_THEME) {
            this.node.getChildByName("root").getChildByName("titlenode").getChildByName("back_btn").active = true;
            this.node.getChildByName("root").getChildByName("content").getComponent(Widget).bottom = 10;
            this.node.getChildByName("root").getChildByName("content").getComponent(Widget).updateAlignment();
            this.node.getChildByName("root").getChildByName("content").getChildByName("center").getComponent(Widget).updateAlignment();
        }
        else {
            this.node.getChildByName("root").getChildByName("titlenode").getChildByName("back_btn").active = false;
            let e = sys.getSafeAreaRect().y;
            e > 0 && (this.node.getChildByName("root").getChildByName("content").getComponent(Widget).bottom = 120 - e, this.node.getChildByName("root").getChildByName("content").getComponent(Widget).updateAlignment(), this.node.getChildByName("root").getChildByName("content").getChildByName("center").getComponent(Widget).updateAlignment());
        }
        this.share_url = User.shared().data.share_addr;
        User.shared().shareMainInfo ? this.refreshUI() : Utils.shared().showLoading(10, true, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3);
        }));
        PushCenter.shared().addListener(PushEvent.NoticeRefreshShare, (e => {
            ToolUtils.isObjValid(this.node) && window.InHallScene && this.doGetMainPage(false);
        }), this);
        this.detailTabView = this.node.addComponent(TableViewUtils);
        let e = this.hisMobanNode.getComponent(UITransform).height, t = [this.hisMobanNode];
        if (this.detailTabView.init([], this.hisScrollViewNode, t, this.initCurMobanCallBack.bind(this), 0, e, this.scrollRefreshCallBack.bind(this), false), sys.isObjectValid(User.shared().data.hall_invite_earn)) {
            let e = 0 == GameConfig.GAME_APP_THEME ? CommDefine.AppName_rummy : CommDefine.AppName_circ, t = `I won Rs ${User.shared().data.hall_invite_earn} on ${e} via Referrals,\n You can too! Pradeep kumar\n------\nPradeep kumar`;
            this.rewardTipNode.getComponent(Label).string = t;
        }
        this.updateTabView();
        this.dealTabContentLogic();
        this.fitGameName();
    }
    dealShareRankListLogic(e) {
        -1 == e ? (this._rank_page = 0, this.doGetMoreRankList()) : (this.addRankList(User.shared().share_rank_data.rank_list, 1), this._hasNextRankPage = User.shared().share_rank_data.hasNextPage, this.homeNode.getChildByName("btn_more").active = 1 == this._hasNextRankPage);
    }
    fitLuckyTheme() {
        0 != GameConfig.NATIVE_GAME_APP_TYPE && (this.tabWzColor = [color(221, 3, 3), color(102, 102, 102)], this.node.getChildByName("root").getChildByName("titlenode").getChildByName("top_bg").getComponent(Sprite).color = color(12, 26, 60, 255), this.tabNode.getChildByName("bg").getComponent(Sprite).color = color(250, 250, 250, 255), this.tabNode.getChildByName("hone_btn").getChildByName("line").getComponent(Sprite).color = this.tabWzColor[0], this.tabNode.getChildByName("history_btn").getChildByName("line").getComponent(Sprite).color = this.tabWzColor[0]);
    }
    fitGameName() {
        1 == GameConfig.CHIPS_MODLE && 2000617 == GameConfig.CHANNEL_ID && 0 == GameConfig.GAME_HALL_THEME && (find("root/titlenode/top_bg", this.node).getComponent(Sprite).color = color("#094544"), find("root/content/earn_node/earn_bg", this.node).getComponent(Sprite).spriteAtlas = this.spAtlas617, find("root/content/earn_node/earn_bg", this.node).getComponent(Sprite).spriteFrame = this.shareBannerSpFrame, find("root/content/select_diban/bg", this.node).getComponent(Sprite).color = color("#fafafa"));
    }
    scrollRefreshCallBack() {
        1 != this._hasNextPage || this.isSendMsg || (this.isSendMsg = true, this.doGetMoreDetails());
    }
    doGetMoreRankList() {
        let e = this._rank_page;
        HttpManager.shared().doGetCommonRequest({ cpage: e + 1 }, "Share.getRankList", ((e, t, a) => {
            Utils.shared().hideLoading();
            this.isSendMsg = false;
            try {
                if (200 != a) {
                    alert("The login timed out, please try again");
                }
                else if (200 === a) {
                    let e = ToolUtils.parseJson(t);
                    if (0 === e.ret && ToolUtils.isObjValid(this.node)) {
                        if (ToolUtils.isObjValid(this.node)) {
                            if (sys.isObjectValid(e.data)) {
                                if (this._rank_page = e.data.cpage, this._hasNextRankPage = e.data.has_next, User.shared().share_rank_data.page = e.data.cpage, User.shared().share_rank_data.hasNextPage = e.data.has_next, sys.isObjectValid(e.data.user_share_data) && (User.shared().share_rank_data.user_share_data = e.data.user_share_data), sys.isObjectValid(e.data.rank_list) && e.data.rank_list.length > 0) {
                                    for (let t = 0, a = e.data.rank_list.length; t < a; t++) {
                                        User.shared().share_rank_data.rank_list.push(e.data.rank_list[t]);
                                    }
                                    this.addRankList(e.data.rank_list, e.data.cpage);
                                }
                                this.homeNode.getChildByName("btn_more").active = 1 == this._hasNextRankPage;
                            }
                        }
                        else {
                            e.desc && ToolUtils.isSafeString(e.desc).length > 0 && Utils.shared().showToast(e.desc, 3);
                        }
                    }
                }
            }
            catch (e) {
                TLog.printError("----- doGetMoreRankList error:", e);
            }
        }));
    }
    addRankList(e, t) {
        this.homeNode.getChildByName("earn_rank").active = true;
        this.homeNode.getChildByName("list_title").active = true;
        this.homeNode.getChildByName("rank_root").active = true;
        let a = 0;
        if (1 == t) {
            if (a = 3, this.homeNode.getChildByName("rank_root").removeAllChildren(), sys.isObjectValid(e) && Array.isArray(e) && e.length > 0) {
                let t = 0;
                for (e.length; t < 3; t++) {
                    let a = this.homeNode.getChildByName("earn_rank").getChildByName("player" + t);
                    sys.isObjectValid(e[t].name) && (a.getChildByName("name").getComponent(Label).string = e[t].name);
                    sys.isObjectValid(e[t].avatar) && Utils.shared().updateHeadImg(a.getChildByName("head_mask").getChildByName("head_img"), e[t].avatar, "", size(135, 135));
                    sys.isObjectValid(e[t].cash) && (a.getChildByName("cash").getComponent(Label).string = ToolUtils.parse_double2(e[t].cash));
                    sys.isObjectValid(e[t].bonus) && (a.getChildByName("bonus").getComponent(Label).string = ToolUtils.parse_double2(e[t].bonus));
                }
            }
            if (sys.isObjectValid(User.shared().share_rank_data.user_share_data)) {
                let e = instantiate(this.rankMoban);
                e.active = true;
                e.getChildByName("image").getComponent(Sprite).color = color(255, 247, 224);
                this.homeNode.getChildByName("rank_root").addChild(e);
                this.refreshRankMobanData(e, User.shared().share_rank_data.user_share_data);
                sys.isObjectValid(User.shared().share_rank_data.user_share_data.rank) && 4 == Number(User.shared().share_rank_data.user_share_data.rank) && (a = 4);
            }
        }
        if (sys.isObjectValid(e) && Array.isArray(e) && e.length > a) {
            for (let t = a; t < e.length; t++) {
                let a = instantiate(this.rankMoban);
                a.active = true;
                this.homeNode.getChildByName("rank_root").addChild(a);
                this.refreshRankMobanData(a, e[t]);
            }
        }
        this.homeNode.getChildByName("rank_root").getComponent(Layout).updateLayout();
        this.homeNode.getComponent(Layout).updateLayout();
    }
    refreshRankMobanData(e, t) {
        sys.isObjectValid(t.rank) && (0 == Number(t.rank) ? e.getChildByName("num").getComponent(Label).string = "Not\nListed" : e.getChildByName("num").getComponent(Label).string = t.rank);
        sys.isObjectValid(t.name) && (e.getChildByName("name").getComponent(Label).string = t.name);
        sys.isObjectValid(t.invite_num) && (e.getChildByName("refer").getComponent(Label).string = t.invite_num);
        sys.isObjectValid(t.avatar) && Utils.shared().updateHeadImg(e.getChildByName("head_mask").getChildByName("head_img"), t.avatar, "", size(84, 84));
        let a = e.getChildByName("prize_node");
        sys.isObjectValid(t.cash) ? (a.getChildByName("cash").active = true, a.getChildByName("cash").getChildByName("num").getComponent(Label).string = ToolUtils.parse_double2(t.cash), a.getChildByName("cash").getComponent(Layout).updateLayout()) : a.getChildByName("cash").active = false;
        sys.isObjectValid(t.bonus) ? (a.getChildByName("bonus").active = true, a.getChildByName("bonus").getChildByName("num").getComponent(Label).string = ToolUtils.parse_double2(t.bonus), a.getChildByName("bonus").getComponent(Layout).updateLayout()) : a.getChildByName("bonus").active = false;
        a.getComponent(Layout).updateLayout();
    }
    doGetMoreDetails() {
        let e = this._page;
        HttpManager.shared().doGetCommonRequest({ cpage: e + 1 }, "Share.earnDetails", ((e, t, a) => {
            Utils.shared().hideLoading();
            this.isSendMsg = false;
            try {
                if (200 != a) {
                    alert("The login timed out, please try again");
                }
                else if (200 === a) {
                    let e = ToolUtils.parseJson(t);
                    if (0 === e.ret && ToolUtils.isObjValid(this.node)) {
                        if (ToolUtils.isObjValid(this.node)) {
                            if (sys.isObjectValid(e.data) && (this._page = e.data.cpage, this._hasNextPage = e.data.has_next, sys.isObjectValid(e.data.list) && e.data.list.length > 0)) {
                                for (let t = 0, a = e.data.list.length; t < a; t++) {
                                    this.already_data.push(e.data.list[t]);
                                }
                                this.refreshDetailList(false);
                            }
                        }
                        else {
                            e.desc && ToolUtils.isSafeString(e.desc).length > 0 && Utils.shared().showToast(e.desc, 3);
                        }
                    }
                }
            }
            catch (e) {
                TLog.printError("----- doGetMoreDetails error:", e);
            }
        }));
    }
    refreshDetailList(e) {
        if (e && (this.hisScrollViewNode.getComponent(ScrollView).stopAutoScroll(), this.hisScrollViewNode.getComponent(ScrollView).scrollToTop()), this.already_data && this.already_data.length > 0) {
            return this.detailTabView.reloadData(this.already_data, e), void (this.hisNoDataNode.active = false);
        }
        this.detailTabView.clearAllItem();
        1 == this.curTab && (this.hisNoDataNode.active = true);
    }
    refreshUI() {
        try {
            this.share_url = User.shared().shareMainInfo.share_url;
            this.share_text = User.shared().shareMainInfo.share_text;
            this.inviteData = User.shared().shareMainInfo;
        }
        catch (e) {
            TLog.printError("trycatch listenGetSharePageCall error:", e);
        }
    }
    initCurMobanCallBack(e, t, a) {
        e.active = true;
        sys.isObjectValid(t.name) && (e.getChildByName("name").getComponent(Label).string = t.name);
        sys.isObjectValid(t.date) && (e.getChildByName("date").getComponent(Label).string = t.date);
        sys.isObjectValid(t.reason) && (e.getChildByName("htype").getComponent(Label).string = t.reason);
        sys.isObjectValid(t.cash) && t.cash > 0 ? (e.getChildByName("reward_root").getChildByName("reward0").active = true, e.getChildByName("reward_root").getChildByName("reward0").getChildByName("wz").getComponent(Label).string = ToolUtils.parse_double(t.cash), e.getChildByName("reward_root").getChildByName("reward0").getComponent(Layout).updateLayout()) : e.getChildByName("reward_root").getChildByName("reward0").active = false;
        sys.isObjectValid(t.bonus) && t.bonus > 0 ? (e.getChildByName("reward_root").getChildByName("reward1").active = true, e.getChildByName("reward_root").getChildByName("reward1").getChildByName("wz").getComponent(Label).string = ToolUtils.parse_double(t.bonus), e.getChildByName("reward_root").getChildByName("reward1").getComponent(Layout).updateLayout()) : e.getChildByName("reward_root").getChildByName("reward1").active = false;
        e.getChildByName("reward_root").getComponent(Layout).updateLayout();
    }
    onEnable() {
        User.shared().shareMainInfo || this.doGetMainPage(true);
        User.shared().shareMainInfo && (this.carouseldata = User.shared().shareMainInfo.carousel, this.playBroadcast(0));
        this.scrollViewNode.getComponent(ScrollView).scrollToTop();
        this.curTab = 0;
        this.updateTabView();
        this.dealTabContentLogic();
        this.homeNode.active = true;
        HttpManager.shared().doReportClick({ module: PhpReportDefined.module.share, scene: PhpReportDefined.scece.share_main_page, event: PhpReportDefined.share_event.show });
        TweenTool.delayAct(this.node, (() => {
            User.shared().share_rank_data = { rank_list: [], total_bouns: 0, total_cash: 0, user_share_data: {}, page: -1, hasNextPage: 0 };
            sys.isObjectValid(User.shared().share_rank_data) && (this._rank_page = User.shared().share_rank_data.page);
            this.dealShareRankListLogic(this._rank_page);
        }), 0.5, true);
    }
    onDisable() {
        this.homeNode.active = false;
        this.homeNode.getChildByName("rank_root").removeAllChildren();
    }
    onDestroy() {
        PushCenter.shared().removeListenersByTag(this);
        this.unscheduleAllCallbacks();
    }
    addNotify() {
    }
    doGetMainPage(e) {
        HttpManager.shared().doSharePage(this.listenGetSharePageCall.bind(this));
    }
    listenGetSharePageCall(e, t, a) {
        if (Utils.shared().hideLoading(), 200 != a) {
            alert("The login timed out, please try again");
        }
        else if (ToolUtils.isObjValid(this.node)) {
            let e = ToolUtils.parseJson(t);
            if (0 == e.ret) {
                User.shared().shareMainInfo = e.data;
                this.carouseldata = e.data.carousel;
                this.playBroadcast(0);
                try {
                    this.share_url = e.data.share_url;
                    this.share_text = e.data.share_text;
                    this.inviteData = e.data;
                }
                catch (e) {
                    TLog.printError("trycatch listenGetSharePageCall error:", e);
                }
            }
            else {
                e.desc && e.desc.length > 0 && Utils.shared().showToast(e.desc, 3);
            }
        }
    }
    updateTabView() {
        this.tabNode.getChildByName("hone_btn").getChildByName("line").active = 0 == this.curTab;
        this.tabNode.getChildByName("history_btn").getChildByName("line").active = 1 == this.curTab;
        0 == this.curTab ? (this.tabNode.getChildByName("hone_btn").getChildByName("Label").getComponent(Label).color = this.tabWzColor[0], this.tabNode.getChildByName("history_btn").getChildByName("Label").getComponent(Label).color = this.tabWzColor[1]) : (this.tabNode.getChildByName("hone_btn").getChildByName("Label").getComponent(Label).color = this.tabWzColor[1], this.tabNode.getChildByName("history_btn").getChildByName("Label").getComponent(Label).color = this.tabWzColor[0]);
        i18nMgr.shared().changeLabelFont(this.tabNode.getChildByName("hone_btn").getChildByName("Label").getComponent(Label), 0 == this.curTab);
        i18nMgr.shared().changeLabelFont(this.tabNode.getChildByName("history_btn").getChildByName("Label").getComponent(Label), 1 == this.curTab);
        let e = [];
        e.push(this.tabNode.getChildByName("hone_btn").getChildByName("line"));
        e.push(this.tabNode.getChildByName("history_btn").getChildByName("line"));
        for (let t = 0; t < 2; t++) {
            if (this.curTab == t) {
                e[t].scale = v3(0, 1, 1);
                let a = TweenTool.scaleTo(e[t], 0.16, v3(1.1, 1, 1), null, false), i = TweenTool.scaleTo(e[t], 0.16, v3(1, 1, 1), null, false);
                TweenTool.sequence(e[t], true, null, a, i);
            }
            else {
                e[t].scale = v3(1, 1, 1);
            }
        }
    }
    onBackView() {
        ToolUtils.isObjValid(this.node) && this.node.destroy();
        PushCenter.shared().pushEvent(PushEvent.Close_Invite);
    }
    onBtnClick(e, t) {
        SoundManager.shared().playFx("click");
        let a = sys.now();
        if ("whatsapp" == t) {
            if (TransferPlatform.shared().logEvent_firebase(ReportConfig.firebase_evt.click_invite_whats), 0 === TransferPlatform.shared().checkPackageInstalled("com.whatsapp")) {
                let e = this.share_text + " " + this.share_url;
                return TransferPlatform.shared().shareWebPage(ToolUtils.isSafeString(e)), void HttpManager.shared().doReportClick({ module: PhpReportDefined.module.share, scene: PhpReportDefined.scece.share_main_page, event: PhpReportDefined.share_event.click_share });
            }
            if (a - this.lastTime < 500) {
                return;
            }
            this.lastTime = a;
            let e = this.share_text + " " + this.share_url;
            this.inviteData && ToolUtils.isSafeString(e).length > 0 && (User.shared().shareImageAndTextToThirdApp(1, "", e), HttpManager.shared().doReportClick({ module: PhpReportDefined.module.share, scene: PhpReportDefined.scece.share_main_page, event: PhpReportDefined.share_event.click_share }));
        }
        else if ("link" == t) {
            if (a - this.lastTime < 500) {
                return;
            }
            if (this.lastTime = a, ToolUtils.isSafeString(this.share_url).length > 0 || ToolUtils.isSafeString(this.share_text).length > 0) {
                let e = this.share_text + " " + this.share_url;
                TransferPlatform.shared().shareWebPage(e);
                TransferPlatform.shared().copyContent(e);
                HttpManager.shared().doReportClick({ module: PhpReportDefined.module.share, scene: PhpReportDefined.scece.share_main_page, event: PhpReportDefined.share_event.click_share });
            }
        }
        else {
            "history" == t ? this.showTaskDetailLogic() : "tab0" == t ? (0 != this.curTab && (this.curTab = 0), this.updateTabView(), this.dealTabContentLogic()) : "tab1" == t ? (1 != this.curTab && (this.curTab = 1), this.isSendMsg = false, this.updateTabView(), this.dealTabContentLogic(), this.showTaskDetailLogic()) : "close" == t ? this.onBackView() : "more" == t && (1 != this._hasNextRankPage || this.isSendMsg || (this.isSendMsg = true, this.doGetMoreRankList()));
        }
    }
    dealTabContentLogic() {
        this.scrollViewNode.active = 0 == this.curTab;
        this.scrollViewNode.getComponent(ScrollView).scrollToTop();
        this.hisScrollViewNode.getComponent(ScrollView).scrollToTop();
        sys.isObjectValid(this.already_data) && this.already_data.length > 0 && 1 == this.curTab ? (this.hisTitleNode.active = true, this.hisboardNode.active = true) : (this.hisTitleNode.active = false, this.hisboardNode.active = false);
        this.hisScrollViewNode.active = 1 == this.curTab;
        this.hisNoDataNode.active = false;
    }
    initNormalData(e) {
        if (this.already_data = [], this._page = 0, this._hasNextPage = 0, this._page = Number(e.cpage), this._hasNextPage = Number(e.has_next), sys.isObjectValid(e) && sys.isObjectValid(e.list) && e.list.length > 0 && (this.already_data = e.list), this.refreshDetailList(true), sys.isObjectValid(this.already_data) && this.already_data.length > 0 && 1 == this.curTab) {
            if (this.hisTitleNode.active = true, this.hisboardNode.active = true, sys.isObjectValid(User.shared().share_rank_data.user_share_data)) {
                let e = User.shared().share_rank_data.user_share_data;
                sys.isObjectValid(e.cash) && (this.hisboardNode.getChildByName("cash").getComponent(Label).string = ToolUtils.parse_double2(e.cash));
                sys.isObjectValid(e.bonus) && (this.hisboardNode.getChildByName("bonus").getComponent(Label).string = ToolUtils.parse_double2(e.bonus));
            }
        }
        else {
            this.hisTitleNode.active = false;
            this.hisboardNode.active = false;
            this.curTab;
        }
    }
    showTaskDetailLogic() {
        Utils.shared().showLoading(10, true, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3);
        }));
        HttpManager.shared().doGetCommonRequest({ cpage: 1 }, "Share.earnDetails", ((e, t, a) => {
            Utils.shared().hideLoading();
            try {
                if (200 != a) {
                    alert("The login timed out, please try again");
                }
                else if (200 === a) {
                    let e = ToolUtils.parseJson(t);
                    0 === e.ret ? ToolUtils.isObjValid(this.node) && this.initNormalData(e.data) : e.desc && ToolUtils.isSafeString(e.desc).length > 0 && Utils.shared().showToast(e.desc, 3);
                }
            }
            catch (e) {
                TLog.printError("----- listenDailyDetailCallback error:", e);
            }
        }));
    }
    playBroadcast(e) {
        if (this.broadcastLabelTween) {
            return;
        }
        e >= this.carouseldata.length && (e = 0);
        let t = this.carouseldata[e];
        this.broadcastLabel.string = t;
        this.broadcastRichLabel.string = t;
        this.scheduleOnce((() => {
            let t = this.broadcastRichLabel.node.parent.getComponent(UITransform).height;
            this.broadcastRichLabel.node.setPosition(v3(0, -this.broadcastRichLabel.node.parent.getComponent(UITransform).height, 0));
            this.broadcastLabelTween = tween(this.broadcastRichLabel.node).sequence(tween(this.broadcastRichLabel.node).to(0.7, { position: v3(0, -8, 0) }), tween(this.broadcastRichLabel.node).delay(3), tween(this.broadcastRichLabel.node).to(0.7, { position: v3(0, t, 0) }), tween(this.broadcastRichLabel.node).delay(1)).call((() => {
                this.broadcastLabelTween && (this.broadcastLabelTween.removeSelf(), this.broadcastLabelTween = null);
                this.playBroadcast(e + 1);
            })).start();
        }));
    }
}
