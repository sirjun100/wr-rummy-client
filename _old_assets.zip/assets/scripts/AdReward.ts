// @ts-nocheck
// Recovered from index.js:7
import { _decorator, Label, sys } from "cc";
import SoundManager from "./SoundManager";
import BaseLayer from "./BaseLayer";
import Utils from "./Utils";
import PushCenter from "./PushCenter";
import PushEvent from "./PushEvent";
import i18nMgr from "./i18nMgr";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("AdReward")
export class AdReward extends BaseLayer {
    @property(Label)
    public tipsLable: Label = null;
    public _video_url: any = null;
    public _scene: number = 1;
    public isNext: boolean = false;
    public link_id: number = 0;
    public show_ask: number = 1;
    public _data: any = {};
    start() {
        super.start();
        ToolUtils.showFullScreen(this.node.getChildByName("bg"));
        this.startShowAnim(this.node.getChildByName("rootNode"), (() => {
        }));
        this.link_id = sys.now();
    }
    initParaData(t) {
        sys.isObjectValid(t) && (sys.isObjectValid(t.content) && (i18nMgr.shared().changeLabelFont(this.tipsLable), this.tipsLable.string = ToolUtils.isSafeString(t.content)), sys.isObjectValid(t.video_url) && (this._video_url = t.video_url), sys.isObjectValid(t.from_source) && (this._scene = t.from_source, ToolUtils.report_scene = this._scene), sys.isObjectValid(t.isNext) && (this.isNext = t.isNext), this._data = t);
    }
    update(t) {
    }
    buttonClick(t, e = "") {
        SoundManager.shared().playFx("click");
        "close" == e ? this.onBackView() : "ok" == e && (ToolUtils.isObjValid(this.node) && this.node.destroy(), Utils.shared().showAdView(this._data));
    }
    onBackView() {
        ToolUtils.isObjValid(this.node) && (this.isNext && PushCenter.shared().pushEvent(PushEvent.Update_NextPopActivity), this.node.destroy());
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().removeListenersByTag(this);
    }
}
