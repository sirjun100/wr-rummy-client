// Design-space geometry for the portrait Games dialog (720-unit canvas).
// Cocos' auto Layout uses remote sprite dimensions, so tile positions must not
// depend on the size of the downloaded image.
export const GAME_ENTRY_PANEL_WIDTH = 580;
export const GAME_ENTRY_ICON_SIZE = 128;
export const GAME_ENTRY_LABEL_WIDTH = 150;
export const GAME_ENTRY_LABEL_HEIGHT = 68;

export function computeCircularIconSize(_gameId: string, imageWidth: number, imageHeight: number) {
    const width = imageWidth > 0 ? imageWidth : GAME_ENTRY_ICON_SIZE;
    const height = imageHeight > 0 ? imageHeight : GAME_ENTRY_ICON_SIZE;
    // Most catalog images are rounded-square thumbnails with transparent
    // corners. Slightly overscan those so they fill the circular stencil.
    // Every catalog icon is a square game thumbnail. Use one consistent crop
    // so the artwork fills the same circular tile for every H5 game.
    const overscan = 1.3;
    const longestSide = Math.max(width, height);
    return {
        width: GAME_ENTRY_ICON_SIZE * overscan * width / longestSide,
        height: GAME_ENTRY_ICON_SIZE * overscan * height / longestSide,
    };
}

export function computeGameEntryGeometry(count: number) {
    const rows = Math.max(1, Math.ceil(count / 3));
    const panelHeight = 360 + (rows - 1) * 210;
    const cells = Array.from({ length: count }, (_, index) => {
        const row = Math.floor(index / 3);
        const column = index % 3;
        return {
            // Keep every row on the same three-column grid. An incomplete
            // last row starts at the left edge instead of recentering.
            x: (column - 1) * 176,
            y: panelHeight / 2 - 180 - row * 210,
        };
    });
    return { panelHeight, cells };
}
