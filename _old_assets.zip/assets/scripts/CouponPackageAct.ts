// @ts-nocheck
// Recovered from index.js:85
import { _decorator, Label, Node, sys, Vec3 } from "cc";
import BaseLayer from "./BaseLayer";
import i18nMgr from "./i18nMgr";
import PushCenter from "./PushCenter";
import { ToolUtils } from "./ToolUtils";
import Utils from "./Utils";
import PushEvent from "./PushEvent";
import User from "./User";
import SoundManager from "./SoundManager";
const { ccclass, property } = _decorator;
@ccclass("CouponPackageAct")
export class CouponPackageAct extends BaseLayer {
    @property(Node)
    public bgView: Node = null;
    public _linkId: number = 0;
    public _callback: any = null;
    public lastClick: number = 0;
    public coupon_id: number = 0;
    public _has_close: boolean = false;
    public _pop_souce: number = 0;
    public coupon_act_data: any = null;
    public isNext: boolean = false;
    public recommend_price: number = 0;
    public isEnterStore: boolean = false;
    public _mPara: any[] = [];
    onLoad() {
    }
    dealMultipleLanguages() {
        if (2 == i18nMgr.shared().language) {
            new Vec3;
        }
    }
    initParaData(t) {
        this._mPara = t;
        sys.isObjectValid(t) && sys.isObjectValid(t.callback) && (this._callback = t.callback);
        sys.isObjectValid(t.pop_souce) && (this._pop_souce = t.pop_souce);
        sys.isObjectValid(t.isNext) && (this.isNext = t.isNext);
        this.coupon_act_data = t;
        this.refreshUI();
    }
    refreshUI() {
        if (sys.isObjectValid(this.coupon_act_data) && sys.isObjectValid(this.coupon_act_data.ext) && sys.isObjectValid(this.coupon_act_data.ext.coupon_info)) {
            let t = this.coupon_act_data.ext.coupon_info;
            this.coupon_id = t.coupon_id;
            this.updateCouponItem(t);
            sys.isObjectValid(this.coupon_act_data.ext.recommend_price) && (this.recommend_price = Number(this.coupon_act_data.ext.recommend_price));
        }
    }
    updateCouponItem(t) {
        let e = this.bgView.getChildByName("cur_coupon");
        sys.isObjectValid(t) && (sys.isObjectValid(t.rate_text) && (e.getChildByName("type_wz").getComponent(Label).string = t.rate_text), sys.isObjectValid(t.content) && (e.getChildByName("title_wz").getComponent(Label).string = t.content, this.bgView.getChildByName("flag").getComponent(Label).string = t.content), sys.isObjectValid(t.coupon_code) && t.coupon_code.length > 0 && (e.getChildByName("kuang_img").active = true, e.getChildByName("kuang").active = true, e.getChildByName("kuang").getChildByName("title_wz").getComponent(Label).string = t.coupon_code), sys.isObjectValid(t.expire_text) && (e.getChildByName("date_ez").getComponent(Label).string = t.expire_text));
    }
    start() {
        super.start();
        ToolUtils.showFullScreen(this.node.getChildByName("mask"));
        this.startShowAnim2(this.bgView, 1);
        this.lastClick = sys.now();
        this._linkId = this.lastClick;
        SoundManager.shared().playFx("act_popshow");
    }
    onButtonClick(t, e) {
        if (SoundManager.shared().playFx("click"), "close" === e) {
            if (1 == Utils.shared().checkPopRestartGift(this._mPara)) {
                return void this.onBackView();
            }
            this.onBackView();
        }
        else if ("add_cash" === e) {
            if (sys.now() - this.lastClick < 1000) {
                return;
            }
            ToolUtils.isObjValid(this.node) && (User.shared().poplist = [], this.isEnterStore = true, Utils.shared().showStoreView({ link_id: this._linkId, coupon_id: this.coupon_id, recommend_price: this.recommend_price }, this.node), ToolUtils.isObjValid(this.node) && this.node.destroy());
        }
        else if ("date_open" == e) {
            let t = this.bgView.getChildByName("cur_coupon"), e = t.getChildByName("date_ez").active;
            t.getChildByName("date_ez").active = !e;
            t.getChildByName("date_open").getChildByName("wz").getComponent(Label).string = e ? "+ MORE" : "- CLOSE";
        }
    }
    onBackView() {
        if (ToolUtils.isObjValid(this.node)) {
            if (this._has_close) {
                return;
            }
            this._has_close = true;
            let t = { alert_node: this.node, rootNode: this.node.getChildByName("root"), isNext: this.isNext, pop_type: PushEvent.JUMP_TO_COUPON_ACT, pop_souce: this._pop_souce };
            Utils.shared().closeActivityView(t);
        }
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().removeListenersByTag(this);
        this.unscheduleAllCallbacks();
    }
    update(t) {
    }
}
