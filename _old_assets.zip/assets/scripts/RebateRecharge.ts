// @ts-nocheck
// Recovered from index.js:371
import { _decorator, director, instantiate, Label, Node, Sprite, SpriteFrame, sys, v3, Vec3 } from "cc";
import PushCenter from "./PushCenter";
import Utils from "./Utils";
import PushEvent from "./PushEvent";
import User from "./User";
import SoundManager from "./SoundManager";
import BaseLayer from "./BaseLayer";
import { TransferPlatform } from "./TransferPlatform";
import BundleNameDefined from "./BundleNameDefined";
import { CheckModule } from "./CommDefine";
import HttpManager from "./HttpManager";
import ReportConfig from "./ReportConfig";
import TweenTool from "./TweenTool";
import i18nMgr from "./i18nMgr";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("RebateRecharge")
export class RebateRecharge extends BaseLayer {
    @property(Node)
    public rootNode: Node = null;
    @property(Node)
    public maskNode: Node = null;
    @property(Label)
    public leftTimeLabel: Label = null;
    @property(Label)
    public flagLabel: Label = null;
    @property(Node)
    public amountNode: Node = null;
    @property(Node)
    public modalNode: Node = null;
    @property([SpriteFrame])
    public cash_icons: SpriteFrame[] = [];
    @property([SpriteFrame])
    public bonus_icons: SpriteFrame[] = [];
    public rechargeNode: any[] = [];
    public isNext: boolean = false;
    public isBackKey: boolean = true;
    public lastPayTime: number = 0;
    public goods_id: any = null;
    public isEnterStore: boolean = false;
    public isquick: boolean = false;
    public _nVid: number = 0;
    public _bStartCountDown: boolean = false;
    public _nCountcd: any = -1;
    public rechragePos: any[] = [];
    public _linkId: number = 0;
    public _reportScene: any = -1;
    public _bCanSend: boolean = false;
    public _pop_souce: number = 0;
    public _has_close: boolean = false;
    public _curContent: any = null;
    public _flag: number = 0;
    public _mPara: any[] = [];
    public _rebaterechargeData: any = null;
    public _finishAnim: boolean = false;
    public TAG: string = "RebateRecharge";
    public checkKyc: number = 0;
    initParaData(e, t = 0) {
        this._mPara = e;
        this.isNext = e.isNext;
        sys.isObjectValid(e.vid) ? this._nVid = e.vid : this._nVid = ToolUtils.curRoomId;
        sys.isObjectValid(e.isquick) && (this.isquick = e.isquick);
        sys.isObjectValid(e.flag) && (this._flag = e.flag);
        sys.isObjectValid(e.flag) && (this.checkKyc = e.checkKyc);
        sys.isObjectValid(e) && sys.isObjectValid(e.pop_souce) && (this._pop_souce = e.pop_souce);
        sys.isObjectValid(e) && sys.isObjectValid(e.reportScene) && (this._reportScene = e.reportScene);
        sys.isObjectValid(e) && sys.isObjectValid(e.link_id) && e.link_id > 0 && (this._linkId = e.link_id);
        sys.isObjectValid(e.ext) && e.ext && Object.keys(e.ext).length && (this._rebaterechargeData = e.ext);
    }
    start() {
        super.start();
        this._linkId = this._linkId > 0 ? this._linkId : sys.now();
        this._reportScene = this._reportScene >= 0 ? this._reportScene : ToolUtils.getIsInRoom() ? 2 : 1;
        ToolUtils.isObjValid(this._curContent) || (this._curContent = this.rootNode.getChildByName("content"));
        for (let e, t = 0; t < 3; t++) {
            if (e = this._curContent.getChildByName("item" + t), ToolUtils.isObjValid(e)) {
                this.rechargeNode[t] = e;
                let i = new Vec3;
                this.rechargeNode[t].getPosition(i);
                this.rechragePos.push(i);
            }
        }
        if (ToolUtils.showFullScreen(this.maskNode), sys.isObjectValid(this._rebaterechargeData) && this.refreshView(), sys.isObjectValid(this._mPara.vid) && 0 != Number(this._mPara.vid) && sys.isObjectValid(this._rebaterechargeData) || User.shared().requestRebateRechargePageData((e => {
            ToolUtils.isObjValid(this.node) && sys.isObjectValid(e) && e && Object.keys(e).length && (this._rebaterechargeData = e, this.refreshView());
        })), PushCenter.shared().addListener(PushEvent.CloseRebateRecharge, (e => {
            ToolUtils.isObjValid(this.node) && (this.isNext && PushCenter.shared().pushEvent(PushEvent.Update_NextPopActivity), this.node.destroy());
        }), this), PushCenter.shared().pushEvent(PushEvent.HideGameOverBg), TweenTool.commonSchedule(this.node, 1, this.scheduleCallBack.bind(this)), director.getScene().name == BundleNameDefined.hall_scene) {
            this.amountNode.active = false;
            for (let e = 0, t = this.rechargeNode.length; e < t; e++) {
                this.rechargeNode[e].active = false;
            }
        }
        this._finishAnim = false;
        this.startShowAnim(this.rootNode, (() => {
            if (director.getScene().name == BundleNameDefined.hall_scene) {
                let e = this._rebaterechargeData;
                if (e) {
                    for (let t = 0, i = this.rechargeNode.length; t < i; t++) {
                        TweenTool.stopNodeAction(this.rechargeNode[t]);
                        this.rechargeNode[t].setPosition(v3(this.rechragePos[t].x + 660, this.rechragePos[t].y));
                        let i = TweenTool.delayAct(this.rechargeNode[t], (() => {
                            this._finishAnim = true;
                            sys.isObjectValid(e.good_list) && sys.isObjectValid(e.good_list[t]) && (this.rechargeNode[t].active = true);
                        }), 0.04 * t, false), a = TweenTool.moveToByFade(this.rechargeNode[t], 0.15, v3(this.rechragePos[t].x - 20, this.rechragePos[t].y), 0, 1, false), s = TweenTool.moveTo(this.rechargeNode[t], 0.1, v3(this.rechragePos[t].x + 15, this.rechragePos[t].y), null, false), r = TweenTool.moveTo(this.rechargeNode[t], 0.06, v3(this.rechragePos[t].x, this.rechragePos[t].y), null, false);
                        TweenTool.sequence(this.rechargeNode[t], true, (() => {
                        }), i, a, s, r);
                    }
                }
            }
        }));
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().pushEvent(PushEvent.ShowGameOverBg);
        PushCenter.shared().removeListenersByTag(this);
        TweenTool.stopNodeAction(this.node);
        this.unscheduleAllCallbacks();
    }
    onEnable() {
        TransferPlatform.shared().setNormalFrameRate();
    }
    refreshView() {
        this.updateCashContent();
    }
    updateCashContent() {
        let e = this._rebaterechargeData;
        if (sys.isObjectValid(this.rechargeNode) && Array.isArray(this.rechargeNode), sys.isObjectValid(e)) {
            this.startLeftTime(Number(e.time_left));
            this.flagLabel.string = ToolUtils.format(i18nMgr.shared().getValueByKey("first_recharge_text.get_up_to"), e.max);
            for (let t = 0, i = this.rechargeNode.length; t < i; t++) {
                if (this.rechargeNode[t].getChildByName("layout").removeAllChildren(), sys.isObjectValid(e.good_list) && sys.isObjectValid(e.good_list[t])) {
                    let i = e.good_list[t];
                    this.rechargeNode[t].active = !!this._finishAnim;
                    let a = sys.isObjectValid(i.add_cash) ? Number(i.add_cash) + Number(i.cash) : Number(i.cash), s = instantiate(this.modalNode);
                    this.cash_icons[t] ? s.getChildByName("ico").getComponent(Sprite).spriteFrame = this.cash_icons[t] : s.getChildByName("ico").getComponent(Sprite).spriteFrame = this.cash_icons[0];
                    s.getChildByName("num").getComponent(Label).string = "₹" + a;
                    s.active = true;
                    this.rechargeNode[t].getChildByName("layout").addChild(s);
                    let o = Number(i.bonus);
                    s = instantiate(this.modalNode);
                    this.bonus_icons[t] ? s.getChildByName("ico").getComponent(Sprite).spriteFrame = this.bonus_icons[t] : s.getChildByName("ico").getComponent(Sprite).spriteFrame = this.bonus_icons[0];
                    s.getChildByName("num").getComponent(Label).string = "₹" + o;
                    s.active = true;
                    this.rechargeNode[t].getChildByName("layout").addChild(s);
                    this.rechargeNode[t].getChildByName("btn_addcash").getChildByName("price").getComponent(Label).string = ToolUtils.format("₹${0}", i.price);
                    this.showCashAddPercent(t, Number(i.ratio));
                }
                else {
                    this.rechargeNode[t].active = false;
                    this.showCashAddPercent(t, 0);
                }
            }
        }
    }
    showCashAddPercent(e, t) {
        let i = this._curContent.getChildByName("item" + e);
        ToolUtils.isObjValid(i) && (sys.isObjectValid(t) && t > 100 ? (i.getChildByName("add_bg").active = true, i.getChildByName("add_value").getComponent(Label).string = "+" + t + "%", i.getChildByName("add_value").active = true) : (i.getChildByName("add_bg").active = false, i.getChildByName("add_value").active = false));
    }
    startLeftTime(e) {
        let t = i18nMgr.shared().getValueByKey("first_recharge_text.left_time");
        if (Number.isNaN(e) || e <= 0) {
            return User.shared().getHallInfo(), void (this.leftTimeLabel.string = "");
        }
        this._bStartCountDown = true;
        this._nCountcd = e;
        t = ToolUtils.format("${0} ${1}", t, Utils.shared().parseCountDown(this._nCountcd));
        this.leftTimeLabel.string = t;
        i18nMgr.shared().changeLabelFont(this.leftTimeLabel, false);
    }
    scheduleCallBack() {
        let e = this._rebaterechargeData;
        if (sys.isObjectValid(e) && this._bStartCountDown) {
            if (this._nCountcd -= 1, e.time_left = this._nCountcd, this._nCountcd < 0) {
                return e.time_left = -1, User.shared().getHallInfo(), void this.onBackView();
            }
            this.leftTimeLabel.string = ToolUtils.format("${0} ${1}", i18nMgr.shared().getValueByKey("first_recharge_text.left_time"), Utils.shared().parseCountDown(this._nCountcd));
        }
    }
    onButtonClick(e, t) {
        if (SoundManager.shared().playFx("click"), "close" == t) {
            if (1 == Utils.shared().checkPopRestartGift(this._mPara)) {
                return void this.onBackView();
            }
            1 == this.checkKyc && Utils.shared().checkAddCashKyc();
            this.onBackView();
        }
        else if ("amount" == t) {
            if (ToolUtils.isObjValid(this.node)) {
                if (HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Hall, event: ReportConfig.common.try_recharge }), ToolUtils.getOrientation() && !User.shared().checkKyc(CheckModule.RECHARGE)) {
                    return void this.node.destroy();
                }
                if (!User.shared().checkCanPlayCashGame(CheckModule.RECHARGE)) {
                    return void this.node.destroy();
                }
                this.isEnterStore = true;
                sys.isObjectValid(this._rebaterechargeData) && sys.isObjectValid(this._rebaterechargeData.coupon_id) && Utils.shared().showStoreView({ link_id: this._linkId, coupon_id: this._rebaterechargeData.coupon_id }, this.node);
            }
        }
        else if (sys.isObjectValid(this._rebaterechargeData) && sys.isObjectValid(this._rebaterechargeData.good_list) && Array.isArray(this._rebaterechargeData.good_list) && sys.isObjectValid(this._rebaterechargeData.good_list[Number(t)]) && ToolUtils.isObjValid(this.node)) {
            if (!User.shared().checkCanRecharge()) {
                return void this.node.destroy();
            }
            if (!sys.isObjectValid(this._rebaterechargeData.good_list[Number(t)].goodsId) || !sys.isObjectValid(this._rebaterechargeData.good_list[Number(t)].price) || !sys.isObjectValid(this._rebaterechargeData.coupon_id)) {
                return;
            }
            let e = { pway: this._rebaterechargeData.pways + "", goodsId: this._rebaterechargeData.good_list[Number(t)].goodsId + "", price: this._rebaterechargeData.good_list[Number(t)].price, coupon_id: this._rebaterechargeData.coupon_id, link_id: this._linkId, act_id: PushEvent.JUMP_TO_RebateRecharge };
            User.shared().startPay(e);
        }
    }
    onBackView() {
        if (ToolUtils.isObjValid(this.node)) {
            if (this._has_close) {
                return;
            }
            this._has_close = true;
            let e = { alert_node: this.node, rootNode: this.rootNode, isNext: this.isNext, pop_type: PushEvent.JUMP_TO_RebateRecharge, pop_souce: this._pop_souce };
            Utils.shared().closeActivityView(e);
        }
    }
}
