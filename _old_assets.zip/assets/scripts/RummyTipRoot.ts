// @ts-nocheck
// Recovered from index.js:491
import { _decorator, Button, color, Font, game, instantiate, Label, Node, Prefab, RichText, ScrollView, size, Size, sp, Sprite, SpriteFrame, sys, UIOpacity, UITransform, v2, v3, Vec3, view } from "cc";
import Parent, { AdapDirection } from "./Parent";
import i18nMgr from "./i18nMgr";
import PushCenter from "./PushCenter";
import { TLog } from "./TLog";
import { ToolUtils } from "./ToolUtils";
import TweenTool from "./TweenTool";
import Utils from "./Utils";
import PushEvent from "./PushEvent";
import User from "./User";
import SoundManager from "./SoundManager";
import RummyCardConstant, { setHandRatingStarSprite } from "./RummyCardConstant";
import RummyDataManager, { Rating_Type, RUMMY_GAME_TYPE, RUMMY_MATCH_MODE } from "./RummyDataManager";
const { ccclass, property } = _decorator;
@ccclass("RummyTipRoot")
export default class RummyTipRoot extends Parent {
    @property(Node)
    public winnode: Node = null;
    @property(sp.Skeleton)
    public winAnim: any = null;
    @property(Node)
    public multipleWinNode: Node = null;
    @property(Node)
    public ribbonNode: Node = null;
    @property(sp.Skeleton)
    public sc_Anim: any = null;
    @property(sp.Skeleton)
    public autosortAnim: any = null;
    @property(Node)
    public wrongTips: Node = null;
    @property([SpriteFrame])
    public cardIcon: SpriteFrame[] = [];
    @property([SpriteFrame])
    public cardStarIco: SpriteFrame[] = [];
    @property([sp.SkeletonData])
    public winSkeletonData: sp.SkeletonData[] = [];
    @property([Font])
    public textFont: Font[] = [];
    @property([sp.SkeletonData])
    public headSkeletonData: sp.SkeletonData[] = [];
    @property(Prefab)
    public cardPrefab: Prefab = null;
    public seatPosVec: any[] = [];
    public moneyPosVec: any[] = [];
    public winPos: number = 0;
    public tid_key: string = "";
    public gameTipsTextTime: number = 0;
    public gameTipsTextType: number = 0;
    public gameTipsTextback: string = "";
    private gameTipsDeadline: number = 0;
    public time_node: any = null;
    public _tips_Pos: Vec3 = new Vec3;
    public PoolJackPotData: any[] = [];
    public poolPrize: number = 0;
    public viewFinalTimeAction: any = null;
    public viewFinalTime: number = 0;
    public last_declare_type: number = 0;
    public tmpFaceArr: any = {};
    public autoDeclareAction: any = null;
    public finishTimeAction: any = null;
    public ratingDetailBgPostion: Vec3 = new Vec3;
    public _cb: any = null;
    public start_tipMsg: any = null;
    public freeMatchPushMsg: any = null;
    public leftPushTime: number = 0;
    public free_match_action: any = null;
    public hasShowMatchRoundAnim: boolean = false;
    public user_round: number = 0;
    public delayLineUpAct: any = null;
    public headAnimTimeAction: any = null;
    public finish_multiple: number = 0;
    public hasShowWin: boolean = false;
    public availableCardTipsTs: any = null;
    public topFlagPos: any = null;
    onLoad() {
        this.time_node = new Node;
        this.node.addChild(this.time_node);
        for (let e = 0; e < 6; e++) {
            this.tmpFaceArr[e] = [];
        }
        this.node.getChildByName("pick_tip").getPosition(this._tips_Pos);
        this.adapptationScreen();
        this.initPushCenter();
        let e = new Node("wz"), t = e.addComponent(Label);
        t.color = color(255, 255, 0, 255);
        t.font = this.textFont[0];
        t.fontSize = 20;
        this.multipleWinNode.addChild(e);
        let i = new sp.SpineSocket("root/diban/jiedian", e);
        this.multipleWinNode.getComponent(sp.Skeleton).sockets.push(i);
        this.availableCardTipsTs = this.node.getChildByName("available_cards_tip").getComponent("RummyAvailableCardTip");
    }
    onEnable() {
        this.refreshcolor();
    }
    update() {
        if (this.gameTipsDeadline <= 0) {
            return;
        }
        // Tween 的累计帧时间和 sys.now() 存在边界偏差；只每秒检查一次
        // 会把提前的回调算成原秒数，直到下一次检查才跳到更小的数。
        // 每帧检查截止时间，但只在秒数变化时重绘，后台返回也按实际剩余时间恢复。
        let remaining = Math.max(0, Math.ceil((this.gameTipsDeadline - sys.now()) / 1000));
        if (remaining !== this.gameTipsTextTime) {
            this.updateTipsTimeText();
        }
    }
    initPushCenter() {
        PushCenter.shared().addListener(PushEvent.UpdateRaceCSS, (() => {
            this.refreshcolor();
        }), this);
    }
    onDestroy() {
        this.gameTipsDeadline = 0;
        RummyDataManager.shared().stopTweenAction(this.viewFinalTimeAction);
        this.viewFinalTimeAction = null;
        RummyDataManager.shared().stopTweenActionByNode(this.wrongTips);
        RummyDataManager.shared().stopTweenAction(this.free_match_action);
        this.free_match_action = null;
        PushCenter.shared().removeListenersByTag(this);
        this.unscheduleAllCallbacks();
    }
    resetAll() {
        this.showMatchWaitTip(false);
        this.hideTipRootTimeTips();
        this.resetFamaToReadyModel();
        this.hideWinEffect();
        this.show_wait_declare(false);
        this.changeTuoguanVisible(false);
        this.showConfimTips("", "", false);
        this.changePickTipsVisible(0, false);
        this.hideWrongTips();
        this.showQuickFinishTips(false);
        this.showRatingDetail(false);
        this.setMultipleTipsShow(false);
        this.setMultipleCenterTipsShow(false);
        this.setFreeMatchPushActive(false);
        this.setBumpTipShow(false);
        this.setAvailableCardTipsVisible(false);
        this.setManulaRejoinSelect(false);
        this.setManulaTipsShow(false);
    }
    setCallBack(e) {
        this._cb = e;
    }
    onBtnClick(e, t) {
        if ("multipleTipClose" == String(t)) {
            this.setMultipleTipsShow(false);
        }
        else if ("multipleCenterTipClose" == String(t)) {
            this.setMultipleCenterTipsShow(false);
        }
        else if ("bumpTipClose" == String(t)) {
            this.setBumpTipShow(false);
        }
        else if (SoundManager.shared().playFx("click"), "manula_rejoin" == String(t)) {
            let e = RummyDataManager.shared().rummyInfos.get(this.tid_key);
            e.manule_rejoin_select = !e.manule_rejoin_select;
            this.node.getChildByName("pool_manula_rejoin_tips").getChildByName("rejoin_btn").getChildByName("gou").active = e.manule_rejoin_select;
            this._cb && this._cb("manula_rejoin", e.manule_rejoin_select);
        }
        else {
            this._cb && this._cb(t);
        }
    }
    onSwitchJokerClick(e, t) {
        SoundManager.shared().playFx("click");
        this._cb && this._cb("changeJoker", Number(t));
    }
    setMultipleTipsShow(e) {
        let t = this.node.getChildByName("multiple_tip");
        if (ToolUtils.isObjValid(t)) {
            if (e) {
                let e = t.getChildByName("bg").getChildByName("txt");
                i18nMgr.shared().changeLabelLanguage(e.getComponent(Label), "rummy_main.multi_tip", false, RummyDataManager.shared().rummyInfos.get(this.tid_key).max_lost_score);
            }
            t.active = e;
        }
    }
    setMultipleCenterTipsShow(e) {
        let t = this.node.getChildByName("multiple_center_tip"), i = RummyDataManager.shared().rummyInfos.get(this.tid_key);
        if (ToolUtils.isObjValid(t) && sys.isObjectValid(i) && 1 == i.is_multiple) {
            if (e) {
                let e = t.getChildByName("bg").getChildByName("ScrollView"), a = t.getChildByName("bg").getChildByName("item"), s = e.getComponent(ScrollView).content;
                s.destroyAllChildren();
                s.getComponent(UITransform).setContentSize(size(320, 84));
                let n = i.multiple_cfg, o = i.multiple_midle_drop_cfg;
                if (sys.isObjectValid(n)) {
                    for (let e, t, i, l = 1; l <= 100 && sys.isObjectValid(n[l]); l++) {
                        t = instantiate(a);
                        sys.isObjectValid(n[l + 1]) ? t.getChildByName("turn").getComponent(Label).string = "" + l : t.getChildByName("turn").getComponent(Label).string = l + "+";
                        t.getChildByName("multiple").getComponent(Label).string = n[l];
                        sys.isObjectValid(o) && (sys.isObjectValid(o[l]) ? (e = o[l], i = e) : e = i, t.getChildByName("multiple2").getComponent(Label).string = ToolUtils.format("${0}", e));
                        t.active = true;
                        s.addChild(t);
                    }
                }
            }
            t.active = e;
        }
    }
    setBumpTipShow(e) {
        let t = this.node.getChildByName("bump_tip");
        if (ToolUtils.isObjValid(t) && (e && (TweenTool.stopNodeAction(t.getChildByName("bg")), t.getChildByName("bg").setScale(v3(0, 0, 0)), t.getChildByName("closeBtn").getComponent(Button).interactable = false), t.active = e, e)) {
            TweenTool.scaleTo(t.getChildByName("bg"), 0.15, v3(1, 1, 1), "backOut", true, (() => {
                t.getChildByName("bg").setScale(v3(1, 1, 1));
                t.getChildByName("closeBtn").getComponent(Button).interactable = true;
            }));
            let e = t.getChildByName("bg").getChildByName("tips");
            i18nMgr.shared().changeLabelLanguage(e.getComponent(Label), "rummy_main.bump_tip");
            TweenTool.delayAct(RummyDataManager.shared().sceneNode, (() => {
                t.active = false;
            }), 10, true);
        }
    }
    dealWrongTips(e, t = false) {
        if (!sys.isObjectValid(this.wrongTips)) {
            return void TLog.printError("------- RummyTipRoot dealWrongTips wrongTips node is null");
        }
        this.wrongTips.active = true;
        let i = "", a = null, s = 2;
        t ? 1 == e.discard_laizi ? (i = "rummy_main.discard_laizi", this.wrongTips.getChildByName("card_ico").active = false, s = 1) : sys.isObjectValid(e.card) && (i = "rummy_main.discard_wrongCard", a = ToolUtils.getCardInfo(e.card), s = 2) : sys.isObjectValid(e.pick_laizi) && 1 == e.pick_laizi ? (i = "rummy_main.pick_laizi", this.wrongTips.getChildByName("card_ico").active = false, s = 3) : sys.isObjectValid(e.open_card) && (i = "rummy_main.pick_openCard", a = ToolUtils.getCardInfo(e.open_card), s = 4);
        i18nMgr.shared().changeLabelLanguage(this.wrongTips.getChildByName("label").getComponent(Label), i);
        0 == i18nMgr.shared().language ? i18nMgr.shared().changeLabelFontSize(this.wrongTips.getChildByName("label").getComponent(Label), 28) : 1 == i18nMgr.shared().language || 2 == i18nMgr.shared().language ? i18nMgr.shared().changeLabelFontSize(this.wrongTips.getChildByName("label").getComponent(Label), 22) : 3 == i18nMgr.shared().language && (2 == s || 4 == s ? i18nMgr.shared().changeLabelFontSize(this.wrongTips.getChildByName("label").getComponent(Label), 28) : 1 != s && 3 != s || i18nMgr.shared().changeLabelFontSize(this.wrongTips.getChildByName("label").getComponent(Label), 22));
        a && (this.wrongTips.getChildByName("label").getComponent(Label).updateRenderData(true), 0 == a.color ? this.wrongTips.getChildByName("card_ico").getComponent(Sprite).spriteFrame = this.cardIcon[0] : 16 == a.color ? this.wrongTips.getChildByName("card_ico").getComponent(Sprite).spriteFrame = this.cardIcon[1] : 32 == a.color ? this.wrongTips.getChildByName("card_ico").getComponent(Sprite).spriteFrame = this.cardIcon[2] : 48 == a.color && (this.wrongTips.getChildByName("card_ico").getComponent(Sprite).spriteFrame = this.cardIcon[3]), this.wrongTips.getChildByName("card_ico").getChildByName("num").getComponent(Label).string = ToolUtils.getCardShowValue(a.point), t ? 0 == i18nMgr.shared().language ? this.wrongTips.getChildByName("card_ico").setPosition(v3(-165, 61)) : 1 == i18nMgr.shared().language ? this.wrongTips.getChildByName("card_ico").setPosition(v3(56, 61)) : 2 == i18nMgr.shared().language ? this.wrongTips.getChildByName("card_ico").setPosition(v3(-138.517, 23.968)) : 3 == i18nMgr.shared().language && (2 != s && 4 != s || this.wrongTips.getChildByName("card_ico").setPosition(v3(-165, 61))) : 0 == i18nMgr.shared().language ? this.wrongTips.getChildByName("card_ico").setPosition(v3(-50, 61)) : 1 == i18nMgr.shared().language ? this.wrongTips.getChildByName("card_ico").setPosition(v3(-191, 30)) : 2 == i18nMgr.shared().language ? this.wrongTips.getChildByName("card_ico").setPosition(v3(4, 61)) : 3 == i18nMgr.shared().language && (2 != s && 4 != s || this.wrongTips.getChildByName("card_ico").setPosition(v3(-50, 61))), this.wrongTips.getChildByName("card_ico").active = true);
        TweenTool.delayAct(this.wrongTips, (() => {
            this.hideWrongTips();
        }), 3, true);
    }
    hideWrongTips() {
        this.wrongTips && (RummyDataManager.shared().stopTweenActionByNode(this.wrongTips), this.wrongTips.active = false, this.wrongTips.getChildByName("card_ico").active = false);
    }
    hideTipRootTimeTips() {
        this.gameTipsTextTime = 0;
        this.gameTipsDeadline = 0;
        this.node.getChildByName("state_tips").active && (this.node.getChildByName("state_tips").active = false);
        this.node.getChildByName("start_tips").active && (this.node.getChildByName("start_tips").active = false);
        this.node.getChildByName("lineup_anim").active && (this.node.getChildByName("lineup_anim").active = false);
        this.node.getChildByName("match_point_start_tip").active && (this.node.getChildByName("match_point_start_tip").active = false);
    }
    refreshcolor() {
        let e = RummyDataManager.shared().rummyInfos.get(User.shared().curTid_key);
        sys.isObjectValid(e) && 4 == e.gameRummyType && 3 != e.gameMatchMode ? this.sc_Anim.setSkin("tourne_1") : this.sc_Anim.setSkin("green");
    }
    resetFamaToReadyModel() {
        this.node.getChildByName("gameover_tip").active = false;
        this.node.getChildByName("finish_tip").active = false;
        this.node.getChildByName("hupai_tip").active = false;
        this.node.getChildByName("wait_declare").active = false;
        this.node.getChildByName("tuoguan_bg").active = false;
    }
    updateTableTipsInfo(e, t = "", i = 0) {
        let a = this.node.getChildByName("state_tips");
        a && (a.active = e, e && (Utils.shared().setStr(a.getChildByName("text"), t), a.getChildByName("text").getComponent(Label).updateRenderData(true), TweenTool.delayAct(a, (() => {
            let e = a.getChildByName("text").getComponent(UITransform).height + 20, t = a.getChildByName("text").getComponent(UITransform).width + 50;
            t < 540 && (t = 540);
            a.getComponent(UITransform).setContentSize(size(t, e));
        }), game.frameTime / 1000, true)));
    }
    playEffectByName(e) {
        this.tid_key === User.shared().curTid_key && SoundManager.shared().playFx(e);
    }
    showMatchRoundTip(e = 0, t = false) {
        let i = this.node.getChildByName("match_point_start_tip"), a = i.getChildByName("anim");
        if (t) {
            if (e <= 0 || e > 99) {
                return void (i.active = false);
            }
            if (this.hasShowMatchRoundAnim) {
                return;
            }
            this.hasShowMatchRoundAnim = true;
            i.active = true;
            a.active = true;
            try {
                let t = a.getComponent(sp.Skeleton);
                t.clearTracks();
                t.setToSetupPose();
                let i = "", s = "", o = "", l = "";
                if (e < 10) {
                    i = "0x";
                    s = "x1";
                    o = "x2";
                    l = "ani_room_tourneys_round_0" + e;
                    t.setAttachment(s, l);
                    t.setAttachment(o, l);
                    t.setAnimation(0, i, false);
                }
                else if (e >= 10 && e <= 19) {
                    i = "1x";
                    s = "xx1";
                    o = "xx2";
                    l = "ani_room_tourneys_round_0" + (e - 10);
                    t.setAttachment(s, l);
                    t.setAttachment(o, l);
                    t.setAnimation(0, i, false);
                }
                else if (e >= 20 && e <= 99) {
                    i = "xx";
                    let a = "ani_room_tourneys_round_0" + Math.floor(e / 10), s = "ani_room_tourneys_round_0" + e % 10;
                    t.setAttachment("x1", a);
                    t.setAttachment("x2", a);
                    t.setAttachment("xx1", s);
                    t.setAttachment("xx2", s);
                    t.setAnimation(0, i, false);
                }
                t.setCompleteListener((() => {
                }));
            }
            catch (e) {
                TLog.printError("showMatchRoundTip,error:", e);
            }
            this.playEffectByName("match_round_tip");
            TweenTool.delayAct(RummyDataManager.shared().sceneNode, (() => {
                ToolUtils.isObjValid(i) && (i.active = false, this.hasShowMatchRoundAnim = false);
            }), 2, true);
        }
        else {
            i.active = false;
            this.hasShowMatchRoundAnim = false;
        }
    }
    showLineUpAnim(e) {
        this.node.getChildByName("lineup_anim").active = true;
        this.hideWinEffect();
        this.refreshcolor();
        let t = this.node.getChildByName("lineup_anim").getChildByName("tittle");
        i18nMgr.shared().changeLabelFont(t.getComponent(Label));
        Utils.shared().setStr(t, e);
        t.getComponent(Label).updateRenderData(true);
        let i = this.node.getChildByName("lineup_anim").getComponent(UITransform).height, a = t.scale.x, s = t.getComponent(UITransform).width * a + 50;
        s < 640 && (s = 640);
        this.node.getChildByName("lineup_anim").getComponent(UITransform).setContentSize(size(s, i));
    }
    showGameTipsText(e, t, i, a = null) {
        this.gameTipsDeadline = 0;
        this.start_tipMsg = a;
        sys.isObjectValid(a) && sys.isObjectValid(a.user_round) && (this.user_round = a.user_round);
        this.checkIsPointsMatch() && (sys.isObjectValid(this.delayLineUpAct) && (TweenTool.stopAction(this.delayLineUpAct), this.delayLineUpAct = null), this.node.getChildByName("lineup_anim").active = false);
        let s = this.node.getChildByName("state_tips"), n = this.node.getChildByName("start_tips");
        if (n.active = false, RummyDataManager.shared().rummyInfos.get(this.tid_key).gameTipsTextType = e, t <= 0 && (0 == e || 2 == e || 4 == e || 7 == e || 8 == e || 9 == e || 10 == e || 11 == e || 12 == e || 17 == e || 19 == e)) {
            return s.active = false, void (this.node.getChildByName("lineup_anim").active = false);
        }
        if (this.gameTipsTextType = e, this.gameTipsTextback = i, s.active = false, this.node.getChildByName("lineup_anim").active = false, RummyDataManager.shared().rummyInfos.get(this.tid_key).hasShowTotalSettlement) {
            return;
        }
        let o = "";
        if (0 == e) {
            o = "";
        }
        else if (1 == e) {
            o = i18nMgr.shared().getValueByKey("rummy_main.gameTipstext13");
            this.checkIsPointsMatch() ? (this.showMatchRoundTip(this.user_round, true), sys.isObjectValid(this.delayLineUpAct) && (TweenTool.stopAction(this.delayLineUpAct), this.delayLineUpAct = null), this.delayLineUpAct = TweenTool.delayAct(RummyDataManager.shared().sceneNode, (() => {
                ToolUtils.isObjValid(this.node) && (sys.isObjectValid(this.delayLineUpAct) && (TweenTool.stopAction(this.delayLineUpAct), this.delayLineUpAct = null), this.showLineUpAnim(o));
            }), 2, true)) : this.showLineUpAnim(o);
        }
        else if (2 == e) {
            o = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_main.gameTipsText"), t);
            t > 0 && (s.active = false, n.active = true, n.getChildByName("cd").getComponent(Label).string = t + "s");
        }
        else if (3 == e) {
            o = i18nMgr.shared().getValueByKey("rummy_main.gameTipsText10");
            this.showLineUpAnim(o);
        }
        else if (4 == e) {
            o = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_main.gameTipsText1"), t);
            PushCenter.shared().pushEvent(PushEvent.RummyGameTotalSettlementTime, t);
            t > 0 && (s.active = true);
        }
        else if (5 == e) {
            o = i18nMgr.shared().getValueByKey("rummy_main.gameTipsText7");
            s.active = true;
        }
        else if (6 == e) {
            o = i18nMgr.shared().getValueByKey("rummy_main.gameTipsText8");
            s.active = true;
        }
        else if (7 == e) {
            o = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_main.gameTipsText"), t);
            t > 0 && (s.active = true);
        }
        else if (8 == e) {
            o = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_main.gameTipsText2"), t);
            t > 0 && (s.active = true);
        }
        else if (9 == e) {
            o = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_main.gameTipsText3"), t);
            t > 0 && (n.active = true, n.getChildByName("cd").getComponent(Label).string = t + "s");
        }
        else if (10 == e) {
            o = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_main.gameTipsText4"), this.gameTipsTextback, t);
            s.active = true;
        }
        else if (11 == e) {
            o = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_main.gameTipsText5"), ToolUtils.timeStr2(t, true));
            RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType == RUMMY_GAME_TYPE.MATCH && t > 0 && (s.active = true);
        }
        else if (12 == e) {
            o = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_main.gameTipsText6"), t);
            t > 0 && (s.active = true);
        }
        else if (13 == e) {
            o = i18nMgr.shared().getValueByKey("rummy_main.gameTipsText9");
            s.active = true;
        }
        else if (14 == e) {
            o = i18nMgr.shared().getValueByKey("rummy_main.gameTipstext13");
            s.active = true;
        }
        else if (15 == e) {
            o = i18nMgr.shared().getValueByKey("rummy_main.gameTipstext15");
            s.active = true;
        }
        else if (16 == e) {
            o = i18nMgr.shared().getValueByKey("rummy_main.gameTipstext16");
            s.active = true;
        }
        else if (17 == e) {
            o = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_main.gameTipstext17"), t);
            s.active = true;
        }
        else if (18 == e) {
            o = i18nMgr.shared().getValueByKey("rummy_main.gameTipstext18");
            s.active = true;
        }
        else if (19 == e) {
            this.setManulaTipsShow(true);
            this.node.getChildByName("wait_pool_manula").getChildByName("content").getComponent(Label).string = ToolUtils.format("Wait for player's decision for ${0}s", t);
        }
        Utils.shared().setStr(s.getChildByName("text"), o);
        let l = { typeNum: e, TextStr: o, tid_key: this.tid_key };
        PushCenter.shared().pushEvent(PushEvent.GameOverDowntimeTip, l);
        s.getChildByName("text").getComponent(Label).updateRenderData(true);
        let h = s.getComponent(UITransform).height, m = s.getChildByName("text").getComponent(UITransform).width + 50;
        m < 540 && (m = 540);
        s.getComponent(UITransform).setContentSize(size(m, h));
        RummyDataManager.shared().rummyInfos.get(this.tid_key).gameTipsTextDownTime = t;
        null != t && t > 0 && (this.gameTipsTextTime = t, this.gameTipsDeadline = sys.now() + t * 1000);
    }
    updateMatchPointsTip() {
        if (2 == this.gameTipsTextType && this.checkIsPointsMatch()) {
            let e = this.node.getChildByName("match_point_start_tip"), t = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_main.gameTipsText"), this.gameTipsTextTime);
            Utils.shared().setStr(e.getChildByName("text"), t);
            e.getChildByName("text").getComponent(Label).updateRenderData(true);
            let i = e.getChildByName("round_root").getChildByName("round").getComponent(Label);
            sys.isObjectValid(this.start_tipMsg) && sys.isObjectValid(this.start_tipMsg.user_round) && sys.isObjectValid(this.start_tipMsg.max_round) && (i.string = this.start_tipMsg.user_round + "/" + this.start_tipMsg.max_round);
        }
    }
    updateTipsTimeText() {
        this.gameTipsTextTime = Math.max(0, Math.ceil((this.gameTipsDeadline - sys.now()) / 1000));
        let e = this.node.getChildByName("state_tips"), t = this.node.getChildByName("start_tips");
        RummyDataManager.shared().rummyInfos.get(this.tid_key).gameTipsTextDownTime = this.gameTipsTextTime;
        let i = this.gameTipsTextTime;
        if (i < 1) {
            this.gameTipsDeadline = 0;
            e.active = false;
            t.active = false;
            this.node.getChildByName("lineup_anim").active = false;
            RummyDataManager.shared().rummyInfos.get(this.tid_key).gameTipsTextType = 0;
            return;
        }
        RummyDataManager.shared().rummyInfos.get(this.tid_key).gameTipsTextType = this.gameTipsTextType;
        let a = "";
        if (2 == this.gameTipsTextType) {
            a = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_main.gameTipsText"), i);
            t.getChildByName("cd").getComponent(Label).string = i + "s";
        }
        else if (4 == this.gameTipsTextType) {
            a = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_main.gameTipsText1"), i);
        }
        else if (7 == this.gameTipsTextType) {
            a = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_main.gameTipsText"), i);
        }
        else if (8 == this.gameTipsTextType) {
            a = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_main.gameTipsText2"), i);
        }
        else if (9 == this.gameTipsTextType) {
            a = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_main.gameTipsText3"), i);
            t.getChildByName("cd").getComponent(Label).string = i + "s";
        }
        else if (10 == this.gameTipsTextType) {
            a = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_main.gameTipsText4"), this.gameTipsTextback, i);
        }
        else if (11 == this.gameTipsTextType) {
            a = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_main.gameTipsText5"), ToolUtils.timeStr2(i, true));
        }
        else if (12 == this.gameTipsTextType) {
            a = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_main.gameTipsText6"), i);
            e.active = true;
        }
        else if (17 == this.gameTipsTextType) {
            a = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_main.gameTipstext17"), i);
        }
        else if (19 == this.gameTipsTextType) {
            return e.active = false, void (this.node.getChildByName("wait_pool_manula").getChildByName("content").getComponent(Label).string = ToolUtils.format("Wait for player's decision for ${0}s", i));
        }
        let s = { typeNum: this.gameTipsTextType, TextStr: a, tid_key: this.tid_key };
        PushCenter.shared().pushEvent(PushEvent.GameOverDowntimeTip, s);
        Utils.shared().setStr(e.getChildByName("text"), a);
        e.getChildByName("text").getComponent(Label).updateRenderData(true);
        let n = e.getComponent(UITransform).height, o = e.getChildByName("text").getComponent(UITransform).width + 50;
        o < 540 && (o = 540);
        e.getComponent(UITransform).setContentSize(size(o, n));
    }
    changePickTipsVisible(e, t) {
        let i = this.node.getChildByName("pick_tip");
        if (i) {
            1 == User.shared().isInPerformanceRoom && (t = false);
            i.active = t;
            let a = i.getChildByName("label");
            if (0 == e ? 0 == RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyMode ? Utils.shared().setStr(a, i18nMgr.shared().getValueByKey("rummy_main.wzLabel")) : Utils.shared().setStr(a, i18nMgr.shared().getValueByKey("rummy_main.wzLabel2")) : 1 == e ? Utils.shared().setStr(a, i18nMgr.shared().getValueByKey("rummy_main.wait_for_your_turn")) : 2 == e && Utils.shared().setStr(a, i18nMgr.shared().getValueByKey("rummy_main.wzLabel1")), t && (0 == e ? (i.active = true, i.setPosition(v3(this._tips_Pos.x, this._tips_Pos.y - 20, this._tips_Pos.z))) : (i.setPosition(this._tips_Pos), i.active = true, TweenTool.delayAct(this.time_node, this.hidePickTip.bind(this), 3, true))), 2 == i18nMgr.shared().language) {
                let e = i.getComponent(UITransform).contentSize;
                i.getComponent(UITransform).contentSize = new Size(700, e.height);
            }
        }
    }
    hidePickTip() {
        this.node.getChildByName("pick_tip").active = false;
    }
    refreshLoseMoneyPostion() {
        2 == RummyDataManager.shared().rummyInfos.get(this.tid_key).pnum && (this.seatPosVec[1] = this.seatPosVec[3]);
    }
    showConfimTips(e, t, i, a = 0) {
        let s, n = RummyDataManager.shared().rummyInfos.get(this.tid_key), o = n.laizicard, l = false;
        if (n && 1 == n.is_bump ? (s = this.node.getChildByName("bump_gameover_tip"), l = true) : s = this.node.getChildByName("gameover_tip"), s) {
            s.active = i;
            i ? s.setSiblingIndex(5) : s.setSiblingIndex(0);
            let h = s.getChildByName("confirm_btn").getComponent(Button);
            h && (h.enabled = i);
            let m = s.getChildByName("tittle");
            Utils.shared().setStr(m, e);
            let d = s.getChildByName("content");
            if (Utils.shared().setStr(d, t), i && RummyDataManager.shared().reSetTouchCardState(this.tid_key), 1 == n.autoBsetDeclareOpen ? (this.changeConfimTips(n.autoDeclareStatus, a, a), s.getChildByName("auto_declare_tips").active = true, s.getChildByName("auto_declare_tx").active = true, s.getChildByName("auto_declare_btn").active = true, l ? s.getChildByName("bg").getComponent(UITransform).contentSize = size(738, 230) : (s.getComponent(UITransform).contentSize = size(740, 132), s.getChildByName("tittle").setPosition(v3(-350, 32)), s.getChildByName("content").setPosition(v3(-350, 2.5)), s.getChildByName("confirm_btn").setPosition(v3(272, 13)))) : (s.getChildByName("auto_declare_tips").active = false, s.getChildByName("auto_declare_tx").active = false, s.getChildByName("auto_declare_btn").active = false, l ? s.getChildByName("bg").getComponent(UITransform).contentSize = size(738, 202) : (s.getComponent(UITransform).contentSize = size(740, 80), s.getChildByName("tittle").setPosition(v3(-350, 16)), s.getChildByName("content").setPosition(v3(-350, -16)), s.getChildByName("confirm_btn").setPosition(v3(272, -3)))), 2 == i18nMgr.shared().language && (s.getChildByName("tittle").getComponent(Label).fontSize = 20, s.getChildByName("content").getComponent(Label).fontSize = 20), l && o > 0) {
                let e = instantiate(this.cardPrefab), t = e.getComponent("RummyCard");
                t.init(o);
                t.openCard();
                t.showLaiziFlag(true);
                e.setScale(v3(0.62, 0.62, 0.62));
                s.getChildByName("card").addChild(e);
                let i = ToolUtils.getCardInfo(o);
                s.getChildByName("bump_tittle").getComponent(Label).string = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_main.bump_winner_tip"), ToolUtils.getCardShowValue(i.point));
            }
        }
    }
    changeConfimTips(e, t, i) {
        let a, s = RummyDataManager.shared().rummyInfos.get(this.tid_key);
        if (a = s && 1 == s.is_bump ? this.node.getChildByName("bump_gameover_tip") : this.node.getChildByName("gameover_tip"), a && a.active) {
            let s = a.getChildByName("auto_declare_tips").getComponent(Label), n = a.getChildByName("auto_declare_tx");
            if (n && (n.getChildByName("check").active = 1 == e, n.getChildByName("check_bg").active = true), this.autoDeclareAction && TweenTool.stopAction(this.autoDeclareAction), 1 == e && t && t > 0) {
                let e = RummyDataManager.shared().rummyInfos.get(this.tid_key).op_cd;
                i - Math.floor(e) >= 0 ? (s.string = ToolUtils.format("${0} (${1}s)", i18nMgr.shared().getValueByKey("rummy_main.auto_declare_tips"), Math.floor(e)), this.autoDeclareAction = TweenTool.commonSchedule(RummyDataManager.shared().sceneNode, 0.05, (() => {
                    ToolUtils.isObjValid(s.node) && (e = RummyDataManager.shared().rummyInfos.get(this.tid_key).op_cd, e >= 0 ? Math.floor(10 * e) % 10 == 0 && (s.string = ToolUtils.format("${0} (${1}s)", i18nMgr.shared().getValueByKey("rummy_main.auto_declare_tips"), Math.floor(e))) : (s.string = ToolUtils.format("${0} (${1}s)", i18nMgr.shared().getValueByKey("rummy_main.auto_declare_tips"), 0), this.autoDeclareAction && TweenTool.stopAction(this.autoDeclareAction)));
                }))) : (s.string = ToolUtils.format("${0} (${1}s)", i18nMgr.shared().getValueByKey("rummy_main.auto_declare_tips"), t), this.autoDeclareAction = TweenTool.commonSchedule(RummyDataManager.shared().sceneNode, 1, (() => {
                    ToolUtils.isObjValid(s.node) && ((t -= 1) >= 0 ? s.string = ToolUtils.format("${0} (${1}s)", i18nMgr.shared().getValueByKey("rummy_main.auto_declare_tips"), t) : (s.string = ToolUtils.format("${0} (${1}s)", i18nMgr.shared().getValueByKey("rummy_main.auto_declare_tips"), 0), this.autoDeclareAction && TweenTool.stopAction(this.autoDeclareAction)));
                })));
            }
            else {
                s.string = i18nMgr.shared().getValueByKey("rummy_main.auto_declare_tips");
            }
        }
    }
    show_finish_tip(e) {
        this.node.getChildByName("finish_tip").active = e;
        1 == e && ToolUtils.startShowAnim(this.node.getChildByName("finish_tip"));
    }
    show_hupai_tip(e) {
        this.node.getChildByName("hupai_tip").active = e;
    }
    show_wait_declare(e, t = 0, i = 0) {
        if (this.node.getChildByName("wait_declare").active = e, e) {
            if (1 === this.last_declare_type && 0 === t) {
                return;
            }
            this.viewFinalTimeAction && (TweenTool.stopAction(this.viewFinalTimeAction), this.viewFinalTimeAction = null);
            this.node.getChildByName("wait_declare").getChildByName("confirm_btn").getComponent(Button).clickEvents[0].customEventData = 0 == t ? "wait_declare_btn" : "view_final_score";
            let e = 0 === t;
            if (this.node.getChildByName("wait_declare").getChildByName("tittle").active = e, this.node.getChildByName("wait_declare").getChildByName("content").active = e, this.node.getChildByName("wait_declare").getChildByName("tips").active = !e, 2 == i18nMgr.shared().language && (this.node.getChildByName("wait_declare").getChildByName("tips").getComponent(Label).fontSize = 20), 1 === t) {
                i18nMgr.shared().changeLabelFont(this.node.getChildByName("wait_declare").getChildByName("tips").getComponent(Label));
                let e = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_main.view_final_tips"), i);
                this.node.getChildByName("wait_declare").getChildByName("tips").getComponent(Label).string = e;
                this.viewFinalTime = i;
                this.viewFinalTimeAction = TweenTool.myschedule(RummyDataManager.shared().sceneNode, 1, this.updateViewFinalTimeTips.bind(this));
            }
            this.last_declare_type = t;
        }
        else {
            this.last_declare_type = 0;
            this.viewFinalTimeAction && (TweenTool.stopAction(this.viewFinalTimeAction), this.viewFinalTimeAction = null);
        }
    }
    updateViewFinalTimeTips() {
        if (this.viewFinalTime = this.viewFinalTime - 1, this.viewFinalTime <= 0) {
            return this.viewFinalTimeAction && (TweenTool.stopAction(this.viewFinalTimeAction), this.viewFinalTimeAction = null), void this.show_wait_declare(false);
        }
        let e = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_main.view_final_tips"), this.viewFinalTime);
        this.node.getChildByName("wait_declare").getChildByName("tips").getComponent(Label).string = e;
    }
    changeTuoguanVisible(e, t, i, a) {
        if (e && (null == t || null == i)) {
            return void TLog.printError("--------------- rummy tips changeTuoguanVisible:", t, i);
        }
        let s = true;
        this.node.getChildByName("tuoguan_bg").active == e && (s = false);
        this.node.getChildByName("tuoguan_bg").active = e;
        1 == s && ToolUtils.startShowAnim(this.node.getChildByName("tuoguan_bg"));
        let n = "";
        sys.isObjectValid(a) && (1 == a ? n = i18nMgr.shared().getValueByKey("rummy_main.auto_discards_new") : 2 == a ? n = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_main.auto_discards"), t, i) : 3 == a && (n = i18nMgr.shared().getValueByKey("rummy_main.tittle_txt")));
        let o = this.node.getChildByName("tuoguan_bg").getChildByName("tittle");
        if (Utils.shared().setStr(o, n), 2 == i18nMgr.shared().language) {
            let e = this.node.getChildByName("tuoguan_bg").getChildByName("confirm_btn").getChildByName("wz");
            e.getComponent(Label).fontSize = 22;
            e.getComponent(Label).lineHeight = 26;
        }
    }
    hideWinEffect() {
        this.winnode && (this.winnode.active = false, this.winAnim.clearTracks());
        ToolUtils.isObjValid(this.ribbonNode) && (this.ribbonNode.active = false, this.ribbonNode.getComponent(sp.Skeleton).clearTracks());
        this.multipleWinNode && (this.multipleWinNode.active = false, this.multipleWinNode.getComponent(sp.Skeleton).clearTracks());
        this.hasShowWin = false;
    }
    refreshWinEffect() {
        if (null === this.seatPosVec[this.winPos] || undefined === this.seatPosVec[this.winPos]) {
            return;
        }
        if (!this.hasShowWin) {
            return;
        }
        if (1 == User.shared().isInPerformanceRoom) {
            return;
        }
        let e = this.seatPosVec[this.winPos];
        RummyDataManager.shared().rummyInfos.get(this.tid_key).round_per_game;
        RummyDataManager.shared().rummyInfos.get(this.tid_key).winner_effects_round;
        if (1 == RummyDataManager.shared().rummyInfos.get(this.tid_key).is_multiple) {
            if (ToolUtils.isObjValid(this.multipleWinNode)) {
                this.multipleWinNode.active = true;
                let t = this.multipleWinNode.getComponent(sp.Skeleton);
                t.clearTracks();
                t.setToSetupPose();
                0 == this.winPos ? this.multipleWinNode.setPosition(v3(e.x, e.y, e.z)) : this.multipleWinNode.setPosition(v3(e.x, e.y + 10, e.z));
                sys.isObjectValid(this.finish_multiple) && this.finish_multiple > 0 ? this.multipleWinNode.getChildByName("wz").getComponent(Label).string = ToolUtils.format("x${0}", this.finish_multiple) : sys.isObjectValid(RummyDataManager.shared().rummyInfos.get(this.tid_key).finish_multiple) && (this.multipleWinNode.getChildByName("wz").getComponent(Label).string = ToolUtils.format("x${0}", RummyDataManager.shared().rummyInfos.get(this.tid_key).finish_multiple));
                t.setAnimation(0, "animation2", false);
            }
        }
        else {
            ToolUtils.isObjValid(this.winnode) && (this.winnode.active = true, this.winAnim.clearTracks(), this.winAnim.setToSetupPose(), 0 == this.winPos ? this.winnode.setPosition(v3(e.x, e.y, e.z)) : this.winnode.setPosition(v3(e.x, e.y + 10, e.z)), this.winPos, this.winAnim.node.scale = v3(1, 1, 1), this.winAnim.skeletonData = this.winSkeletonData[1], this.winAnim.setAnimation(0, "animation2", true));
        }
        TweenTool.delayAct(RummyDataManager.shared().sceneNode, (() => {
            if (ToolUtils.isObjValid(this.winnode)) {
                if (1 == User.shared().isInPerformanceRoom) {
                    this.winnode.active = false;
                    this.hasShowWin = false;
                }
                else {
                    let e = RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType;
                    e == RUMMY_GAME_TYPE.POOL || e == RUMMY_GAME_TYPE.PRI_POOL || e == RUMMY_GAME_TYPE.DEALS || e == RUMMY_GAME_TYPE.PRI_DEAL || e == RUMMY_GAME_TYPE.POINTS || e == RUMMY_GAME_TYPE.MULTIPLE || e == RUMMY_GAME_TYPE.PRIVATE || (this.winnode.active = false, this.hasShowWin = false);
                }
            }
            ToolUtils.isObjValid(this.multipleWinNode) && (1 == User.shared().isInPerformanceRoom ? (this.multipleWinNode.active = false, this.hasShowWin = false) : 1 == RummyDataManager.shared().rummyInfos.get(this.tid_key).is_multiple || (this.multipleWinNode.active = false, this.hasShowWin = false));
        }), 1.83, true);
    }
    showWinEffect(e, t = 0) {
        if (null === this.seatPosVec[e] || undefined === this.seatPosVec[e]) {
            return;
        }
        if (RummyDataManager.shared().rummyInfos.get(this.tid_key).able_local_discard && RummyDataManager.shared().rummyInfos.get(this.tid_key).hasShowWinAnim) {
            return;
        }
        this.hasShowWin = true;
        this.winPos = e;
        this.finish_multiple = t;
        let i = this.seatPosVec[e];
        RummyDataManager.shared().rummyInfos.get(this.tid_key).round_per_game;
        RummyDataManager.shared().rummyInfos.get(this.tid_key).winner_effects_round;
        if (1 == RummyDataManager.shared().rummyInfos.get(this.tid_key).is_multiple) {
            this.multipleWinNode.active = true;
            let a = this.multipleWinNode.getComponent(sp.Skeleton);
            a.clearTracks();
            a.setToSetupPose();
            0 == e ? this.multipleWinNode.setPosition(v3(i.x, i.y, i.z)) : this.multipleWinNode.setPosition(v3(i.x, i.y + 10, i.z));
            sys.isObjectValid(t) && t > 0 ? this.multipleWinNode.getChildByName("wz").getComponent(Label).string = ToolUtils.format("x${0}", t) : sys.isObjectValid(RummyDataManager.shared().rummyInfos.get(this.tid_key).finish_multiple) && (this.multipleWinNode.getChildByName("wz").getComponent(Label).string = ToolUtils.format("x${0}", RummyDataManager.shared().rummyInfos.get(this.tid_key).finish_multiple));
            a.setAnimation(0, "animation", false);
        }
        else if (ToolUtils.isObjValid(this.winnode)) {
            if (this.winnode.active = true, this.winAnim.clearTracks(), this.winAnim.setToSetupPose(), 0 == e ? this.winnode.setPosition(v3(i.x, i.y, i.z)) : this.winnode.setPosition(v3(i.x, i.y + 10, i.z)), 0 == e) {
                if (ToolUtils.isObjValid(this.ribbonNode) && !this.checkIsPointsMatch()) {
                    let e = this.ribbonNode.getComponent(sp.Skeleton);
                    e.clearTracks();
                    e.setToSetupPose();
                    TweenTool.delayAct(RummyDataManager.shared().sceneNode, (() => {
                        ToolUtils.isObjValid(this.ribbonNode) && (this.ribbonNode.active = true, e.setAnimation(0, "zk2", false));
                    }), 25 / 30, true);
                    TweenTool.delayAct(RummyDataManager.shared().sceneNode, (() => {
                        ToolUtils.isObjValid(this.ribbonNode) && (this.ribbonNode.active = false);
                    }), 3, true);
                }
                this.winAnim.skeletonData = this.winSkeletonData[1];
                this.winAnim.node.scale = v3(1, 1, 1);
                this.winAnim.setAnimation(0, "animation", false);
                this.winAnim.addAnimation(0, "animation2", true);
                User.shared().curTid_key == this.tid_key && SoundManager.shared().playFx("winB");
            }
            else {
                this.winAnim.node.scale = v3(1, 1, 1);
                this.winAnim.skeletonData = this.winSkeletonData[1];
                this.winAnim.setAnimation(0, "animation", false);
                this.winAnim.addAnimation(0, "animation2", true);
            }
        }
        TweenTool.delayAct(RummyDataManager.shared().sceneNode, (() => {
            if (ToolUtils.isObjValid(this.winnode)) {
                if (1 == User.shared().isInPerformanceRoom) {
                    this.winnode.active = false;
                    this.hasShowWin = false;
                }
                else {
                    let e = RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType;
                    e == RUMMY_GAME_TYPE.POOL || e == RUMMY_GAME_TYPE.PRI_POOL || e == RUMMY_GAME_TYPE.DEALS || e == RUMMY_GAME_TYPE.PRI_DEAL || e == RUMMY_GAME_TYPE.POINTS || e == RUMMY_GAME_TYPE.MULTIPLE || e == RUMMY_GAME_TYPE.PRIVATE || (this.winnode.active = false, 1 != RummyDataManager.shared().rummyInfos.get(this.tid_key).is_multiple && (this.hasShowWin = false));
                }
            }
            ToolUtils.isObjValid(this.multipleWinNode) && (1 == User.shared().isInPerformanceRoom ? (this.multipleWinNode.active = false, this.hasShowWin = false) : 1 == RummyDataManager.shared().rummyInfos.get(this.tid_key).is_multiple || (this.multipleWinNode.active = false));
        }), 1.83, true);
    }
    showscEffect(e) {
        if (null === this.sc_Anim[e] || undefined === this.sc_Anim[e]) {
            return;
        }
        this.sc_Anim[e];
        this.winnode.active = true;
        this.sc_Anim.clearTracks();
        this.sc_Anim.setAnimation(0, "dp_sl3", false);
        this.sc_Anim.setEndListener((() => {
            this.winnode.active = false;
            this.ribbonNode.active = false;
            this.multipleWinNode.active = false;
            this.hasShowWin = false;
        }));
        this.sc_Anim.setCompleteListener((() => {
            this.winnode.active = false;
            this.ribbonNode.active = false;
            this.multipleWinNode.active = false;
            this.hasShowWin = false;
        }));
    }
    showPoolFuhuoAnim(e, t) {
    }
    showPoolFuhuoTips(e) {
        let t = this.node.getChildByName("poolfuhuo_tip"), i = this.node.getChildByName("state_tips");
        t.active = true;
        i.active = !t.active;
        let a = "";
        for (let t = 0, i = e.players.length; t < i; t++) {
            let s = e.players[t].name;
            t == i - 1 ? a += ToolUtils.GetShortName2(s, 10, true) : a = a + ToolUtils.GetShortName2(s, 10, true) + "、";
        }
        a = 1 == RummyDataManager.shared().rummyInfos.get(this.tid_key).crashModel ? ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_main.prize_pool_updated_practice"), a, ToolUtils.parse_double(e.pool_money)) : ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_main.prize_pool_updated"), a, ToolUtils.parse_double(e.pool_money));
        t.getChildByName("content").getComponent(Label).string = a;
        TweenTool.delayAct(this.node, (() => {
            ToolUtils.isObjValid(t) && (t.active = false);
        }), 2, true);
    }
    showPoolJackPot(e) {
        if (sys.isObjectValid(this.PoolJackPotData) && this.PoolJackPotData.length > 0) {
            let t = this.node.getChildByName("pool_info_node"), i = t.getChildByName("pool_info"), a = i.getChildByName("bg");
            ToolUtils.showFullScreen(t.getChildByName("Mask"));
            t.active = e;
            let s = RummyDataManager.shared().rummyInfos.get(this.tid_key), n = 1 == s.crashModel ? "" : "₹";
            if (1 == e) {
                let e = n + ToolUtils.parse_double("" + this.poolPrize);
                1 == s.crashModel && (e = n + Math.floor(this.poolPrize));
                a.getChildByName("all_value").getComponent(Label).string = e;
                let t = this.PoolJackPotData.length;
                this.PoolJackPotData.length >= 5 && (t = 5);
                a.getComponent(UITransform).contentSize = size(266, 32 * t + 40);
                a.getChildByName("all_value").position = v3(125, -30 - 32 * (t - 1));
                a.getChildByName("total_prize").position = v3(-123, -30 - 32 * (t - 1));
                let o = i.getChildByName("info_list").getComponent(ScrollView), l = o.content;
                l.destroyAllChildren();
                let h = i.getChildByName("info_moban");
                for (let e = 0, t = this.PoolJackPotData.length; e < t; e++) {
                    let t = instantiate(h);
                    t.active = true;
                    t.getChildByName("name").getComponent(Label).string = 0 == e ? ToolUtils.parse_double("" + this.PoolJackPotData[e].name) : ToolUtils.GetShortName2(this.PoolJackPotData[e].name, 16, true);
                    let i = n + ToolUtils.parse_double("" + this.PoolJackPotData[e].value);
                    1 == s.crashModel && (i = n + Math.floor(this.PoolJackPotData[e].value));
                    t.getChildByName("value").getComponent(Label).string = i;
                    l.addChild(t);
                }
                this.PoolJackPotData.length > 5 && o.scrollToBottom(0);
            }
        }
    }
    setPoolJackPotData(e, t) {
        this.PoolJackPotData = e;
        this.poolPrize = t;
    }
    getMatchJoinTipsActive() {
        let e = this.node.getChildByName("match_start_tip");
        return !!ToolUtils.isObjValid(e) && e.active;
    }
    changeMatchJoinTipsActive(e, t) {
        let i = this.node.getChildByName("match_start_tip");
        if (ToolUtils.isObjValid(i) && (i.active = e, null != t && "" != t)) {
            let e = i.getChildByName("tips");
            i18nMgr.shared().changeLabelLanguage(e.getComponent(Label), "rummy_main.joined_automatically", false, t);
            this.scheduleOnce((() => {
                if (ToolUtils.isObjValid(e)) {
                    let t = e.getComponent(UITransform).contentSize;
                    i.getComponent(UITransform).contentSize = size(310, t.height + 10);
                }
            }), 1 / 60);
        }
    }
    showMatchFlowTips(e, t, i) {
        let a = this.node.getChildByName("match_flow_tip");
        if (ToolUtils.isObjValid(a)) {
            a.active = true;
            let s = a.getChildByName("layout");
            s.getChildByName("wz").getComponent(Label).string = e;
            s.getChildByName("wz").getComponent(Label).updateRenderData(true);
            let n = s.getChildByName("wz").getComponent(UITransform);
            TweenTool.stopNodeAction(a);
            TweenTool.delayAct(a, (() => {
                if (2 == t && ToolUtils.isObjValid(i) && !i.active) {
                    this.topFlagPos || (this.topFlagPos = i.getPosition());
                    TweenTool.stopNodeAction(i);
                    let e = s.getChildByName("flag").getWorldPosition();
                    i.setWorldPosition(e);
                    i.active = true;
                    TweenTool.moveTo(i, 0.2, this.topFlagPos, "cubicOut", true, (() => {
                        i.setPosition(this.topFlagPos);
                    }));
                }
                this.onMatchFlowTipsActivite();
            }), 5, true);
            let o = new Vec3, l = 76;
            s.getChildByName("wz").getPosition(o);
            2 == t ? (s.getChildByName("flag").active = true, l = 106) : (s.getChildByName("flag").active = false, ToolUtils.isObjValid(i) && (i.active = false));
            n.height >= 60 ? a.getComponent(UITransform).contentSize = size(n.width + l, 90) : a.getComponent(UITransform).contentSize = size(n.width + l, 60);
            this.showFlowTipsAnim();
        }
    }
    showFlowTipsAnim() {
        let e = this.node.getChildByName("match_flow_tip");
        e.setPosition(v3(0, 298));
        TweenTool.moveTo(e, 0.2, v3(0, 208), "fade", true, (() => {
            e.setPosition(v3(0, 208));
        }));
    }
    showAutoSortAnim(e) {
        this.autosortAnim && this.autosortAnim.isValid && (this.autosortAnim.node.active = true, this.autosortAnim.clearTracks(), 0 == e ? this.autosortAnim.setAnimation(0, "best", false) : 1 == e && this.autosortAnim.setAnimation(0, "least", false), this.autosortAnim.setCompleteListener((() => {
            this.autosortAnim && this.autosortAnim.isValid && (this.autosortAnim.node.active = false);
        })), TweenTool.stopNodeAction(this.autosortAnim), TweenTool.delayAct(this.autosortAnim, (() => {
            this.autosortAnim && this.autosortAnim.isValid && (this.autosortAnim.node.active = false);
        }), 1.83, true));
    }
    onMatchFlowTipsActivite() {
        let e = this.node.getChildByName("match_flow_tip");
        ToolUtils.isObjValid(e) && (e.active = false);
    }
    getMatchLevelActive() {
        let e = this.node.getChildByName("match_level");
        return !ToolUtils.isObjValid(e) || e.active;
    }
    setMatchLevelActive(e, t, i) {
        let a = this.node.getChildByName("match_level");
        if (ToolUtils.isObjValid(a) && (a.active = e, e)) {
            let e = a.getChildByName("level_moban");
            e.active = false;
            let s = a.getChildByName("level_list").getComponent(ScrollView), n = s.content;
            n.destroyAllChildren();
            let o = a.getChildByName("bg"), l = 0;
            if (t && t.length > 0) {
                let a = t.length;
                l = a;
                let o = 0;
                for (let s = 0; s < a; s++) {
                    let a = t[s], l = instantiate(e);
                    n.addChild(l);
                    l.active = true;
                    let h = l.getChildByName("value").getComponent(Label), m = l.getChildByName("point").getComponent(Label), d = l.getChildByName("tt").getComponent(Label);
                    h.string = ToolUtils.format("${0}", a.base_money);
                    m.string = ToolUtils.format("${0}", a.qualify);
                    d.string = ToolUtils.format("${0}s", a.think_time);
                    let c = l.getChildByName("select");
                    i == a.level && (c.active = true, o = s);
                }
                o > 4 ? TweenTool.delayAct(this.node, (() => {
                    s.scrollToOffset(v2(0, 32 * (o - 4)), 0);
                }), game.frameTime / 1000, true) : s.scrollToTop(0);
            }
            let h = 40;
            h += l >= 5 ? 160 : 32 * l;
            o.getComponent(UITransform).setContentSize(size(306, h));
        }
    }
    showMatchWaitTip(e) {
        let t = this.node.getChildByName("match_wait_tip");
        t && (t.active = e);
    }
    adapptationScreen() {
        this.resetUiPos(this.node.getChildByName("switch_skin_tip"), AdapDirection.Left, true, 1, true);
        let e = this.node.getChildByName("quick_finish_tip");
        e = this.node.getChildByName("bump_quick_finish_tip");
        let t = this.node.getChildByName("rating_detail");
        if (t) {
            t.getChildByName("mask").getComponent(UITransform).setContentSize(Utils.shared().getHorizontalSize());
            let e = t.getChildByName("desc");
            if (e.getChildByName("bg").getPosition(this.ratingDetailBgPostion), 1 == i18nMgr.shared().language) {
                let t = e.getChildByName("bg").getChildByName("detail"), i = new Vec3;
                for (let e = 1; e < 5; e++) {
                    let a = t.getChildByName("title" + e), s = t.getChildByName("desc" + e);
                    a.getPosition(i);
                    a.setPosition(v3(i.x - 5, i.y));
                    s.getPosition(i);
                    s.setPosition(v3(i.x - 5, i.y));
                }
            }
        }
        let i = this.node.getChildByName("pool_info_node");
        if (i) {
            let e = i.getChildByName("pool_info");
            e && ToolUtils.isPadPlatform() && this.resetUiPos(e, AdapDirection.Up, true, 1, false);
        }
        let a = this.node.getChildByName("multiple_tip");
        ToolUtils.isObjValid(a) && (a.getChildByName("closeBtn").getComponent(UITransform).setContentSize(view.getVisibleSize()), this.resetUiPos(a, AdapDirection.Down, true, 1));
    }
    showQuickFinishTips(e, t = 0, i = 0) {
        let a = this.node.getChildByName("quick_finish_tip"), s = this.node.getChildByName("bump_quick_finish_tip"), n = t > 0 ? s : a;
        if (n && (this.node.getChildByName("tuoguan_bg").active && (e = false), e ? n.active = e : (a.active = false, s.active = false), this.finishTimeAction && TweenTool.stopAction(this.finishTimeAction), n.active)) {
            let e = RummyDataManager.shared().rummyInfos.get(this.tid_key), a = e.timeout_cd;
            if (e.op_cd > 0 && (a = e.op_cd + e.timeout_cd), 2 == i18nMgr.shared().language && (n.getChildByName("tittle").getComponent(Label).fontSize = 22), t > 0) {
                n.getChildByName("last_card").removeAllChildren();
                let e = instantiate(this.cardPrefab), a = e.getComponent("RummyCard");
                a.init(i);
                a.openCard();
                a.showLaiziFlag(true, false, true);
                a.setMask(true, true);
                e.setScale(v3(0.62, 0.62, 0.62));
                n.getChildByName("last_card").addChild(e);
                n.getChildByName("final_card").removeAllChildren();
                e = instantiate(this.cardPrefab);
                a = e.getComponent("RummyCard");
                a.init(t);
                a.openCard();
                a.showLaiziFlag(true);
                e.setScale(v3(0.62, 0.62, 0.62));
                n.getChildByName("final_card").addChild(e);
                let s = ToolUtils.getCardInfo(t);
                n.getChildByName("bump_tittle").getComponent(Label).string = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_main.bump_winner_tip2"), ToolUtils.getCardShowValue(s.point));
                n.getChildByName("tittle").getComponent(Label).string = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_main.bump_ready_finish"), ToolUtils.getCardShowValue(s.point));
            }
        }
    }
    getQuickFinishTips() {
        let e = this.node.getChildByName("quick_finish_tip"), t = false;
        e && (t = e.active);
        let i = this.node.getChildByName("bump_quick_finish_tip"), a = false;
        return i && (a = i.active), t || a;
    }
    showRatingDetail(e, t = false) {
        let i = this.node.getChildByName("rating_detail");
        if (i) {
            let a = i.getChildByName("desc").getChildByName("bg"), s = i.getChildByName("content");
            if (e) {
                let e = RummyDataManager.shared().rummyInfos.get(this.tid_key).ev_score, t = RummyDataManager.shared().rummyInfos.get(this.tid_key).star, i = Math.floor(10 * e) / 10, a = Math.floor(10 * t) / 10;
                a > 5 && (a = 5);
                let n = ToolUtils.parse_double("" + i, 1), o = ToolUtils.parse_double("" + a, 1), l = RummyDataManager.shared().getHandRatingType(t), h = RummyCardConstant.rating_colors[l], m = s.getChildByName("num");
                m.getComponent(Label).color = h;
                m.getComponent(Label).string = "" + n;
                m.active = true;
                let d = s.getChildByName("rating");
                d.getComponent(Label).color = h;
                let c = "rummy_main.bad";
                l == Rating_Type.bad ? c = "rummy_main.bad" : l == Rating_Type.risky ? c = "rummy_main.risky" : l == Rating_Type.good ? c = "rummy_main.good" : l == Rating_Type.pefect && (c = "rummy_main.perfect");
                i18nMgr.shared().changeLocalizedLabelKey(d, c);
                d.active = true;
                let g, p = Math.floor(o), u = p;
                for (let e = 0; e < p; e++) {
                    g = s.getChildByName("star" + e);
                    setHandRatingStarSprite(g.getComponent(Sprite), this.cardStarIco[0], false);
                    g.getComponent(Sprite).color = h;
                    g.active = true;
                }
                o - p >= 0.1 && (g = s.getChildByName("star" + p), setHandRatingStarSprite(g.getComponent(Sprite), this.cardStarIco[0], true), g.getComponent(Sprite).color = h, g.active = true, u = p + 1);
                for (let e = u; e < 5; e++) {
                    g = s.getChildByName("star" + e);
                    g.active = false;
                }
            }
            if (s.getComponent(UIOpacity).opacity = 255, t) {
                i.active = true;
                let t = a.getComponent(UITransform).height;
                TweenTool.stopNodeAction(a);
                e ? (a.setPosition(new Vec3(0, -t, 0)), s.active = true, TweenTool.moveTo(a, 0.2, this.ratingDetailBgPostion, "cubicOut", true)) : (a.setPosition(this.ratingDetailBgPostion), TweenTool.moveTo(a, 0.2, new Vec3(0, -t, 0), "cubicOut", true, (() => {
                    i.active = false;
                })));
            }
            else {
                i.active = e;
            }
        }
    }
    showSwitchSkinTips(e) {
        let t = this.node.getChildByName("switch_skin_tip");
        if (ToolUtils.isObjValid(t)) {
            t.active = e;
            let i = 0;
            if (User.shared().data.club && (i = User.shared().getGradeByMemberShipLevel(User.shared().data.club.club)), e && i > 0 && i <= 9) {
                let e = ["#ffbc7f", "#bbd4f1", "#fea801", "#88b8ff", "#c79efe", "#f7a2ff", "#ff7e37", "#16d6ff", "#ffd906"], a = ToolUtils.format("<color=${0}>${1}</color>", e[i - 1], User.shared().data.club.name);
                i18nMgr.shared().changeLabelLanguage(t.getChildByName("bg").getChildByName("tips").getComponent(RichText), "club.switch_skin", true, a);
                2 == i18nMgr.shared().language && (t.getChildByName("bg").getChildByName("tips").getComponent(RichText).fontSize = 18, t.getChildByName("bg").getComponent(UITransform).contentSize = new Size(482, 309));
                t.getChildByName("head").setScale(v3(0, 0, 1));
                let s = TweenTool.scaleTo(t.getChildByName("head"), 5 / 30, v3(1.2, 1.2, 1), null, false), n = TweenTool.scaleTo(t.getChildByName("head"), 5 / 30, v3(1, 1, 1), null, false);
                TweenTool.sequence(t.getChildByName("head"), true, (() => {
                    t.getChildByName("head").setScale(v3(1, 1, 1));
                }), s, n);
                let o = new Vec3;
                t.getChildByName("bg").getPosition(o);
                t.getChildByName("bg").getComponent(Sprite).color = color(255, 255, 255, 0);
                let l = TweenTool.delayAct(t.getChildByName("bg"), null, 10 / 30, false), h = TweenTool.moveSpriteByFade(t.getChildByName("bg"), 4 / 30, o, 0, 1, false), m = TweenTool.scaleTo(t.getChildByName("bg"), 4 / 30, v3(1.05, 1.05, 1), null, false), r = TweenTool.parallel(t.getChildByName("bg"), false, null, h, m), g = TweenTool.scaleTo(t.getChildByName("bg"), 0.2, v3(1, 1, 1), null, false);
                TweenTool.sequence(t.getChildByName("bg"), true, (() => {
                    t.getChildByName("bg").getComponent(Sprite).color = color(255, 255, 255, 255);
                    t.getChildByName("bg").setScale(v3(1, 1, 1));
                }), l, r, g);
            }
        }
    }
    checkIsPointsMatch() {
        let e = false, t = RummyDataManager.shared().rummyInfos.get(this.tid_key);
        return sys.isObjectValid(t) && t.gameRummyType == RUMMY_GAME_TYPE.MATCH && t.gameMatchMode == RUMMY_MATCH_MODE.PointsMatch && (e = true), e;
    }
    setFreeMatchPushActive(e = false) {
        let t = this.node.getChildByName("free_match_push");
        t && (t.active = e);
    }
    refreshFreeMatchPush(e) {
        let t = this.node.getChildByName("free_match_push");
        if (this.freeMatchPushMsg = e, t) {
            let i = t.getChildByName("entry").getComponent(Label), a = t.getChildByName("ddl").getComponent(Label);
            if (sys.isObjectValid(e)) {
                if (sys.isObjectValid(e.match_name) && (i.string = "" + e.match_name), 0 == ToolUtils.isSafeNumber(e.mode)) {
                    sys.isObjectValid(e.joined) && sys.isObjectValid(e.max_join) && (a.string = e.joined + "/" + e.max_join);
                }
                else if (1 == ToolUtils.isSafeNumber(e.mode) || 3 == ToolUtils.isSafeNumber(e.mode)) {
                    this.leftPushTime = ToolUtils.isSafeNumber(e.cd);
                    let t = Utils.shared().getCountDownString(this.leftPushTime);
                    a.string = t;
                    this.free_match_action && TweenTool.stopAction(this.free_match_action);
                    3 == ToolUtils.isSafeNumber(e.mode) && this.leftPushTime <= 0 ? (a.string = i18nMgr.shared().getValueByKey("freeMatchPush.enter"), i18nMgr.shared().changeLabelFontBold(a, true)) : this.free_match_action = TweenTool.myschedule(RummyDataManager.shared().sceneNode, 1, this.updateFreeMatchPushTime.bind(this));
                }
            }
        }
    }
    updateFreeMatchPushTime() {
        this.leftPushTime = this.leftPushTime - 1;
        let e = this.node.getChildByName("free_match_push").getChildByName("ddl").getComponent(Label);
        if (this.leftPushTime <= 0 && (this.free_match_action && (TweenTool.stopAction(this.free_match_action), this.free_match_action = null), sys.isObjectValid(this.freeMatchPushMsg) && 3 == this.freeMatchPushMsg.mode)) {
            return e.string = i18nMgr.shared().getValueByKey("freeMatchPush.enter"), void i18nMgr.shared().changeLabelFontBold(e, true);
        }
        let t = Utils.shared().getCountDownString(this.leftPushTime);
        e.string = t;
    }
    getFreeMatchPushActive() {
        let e = this.node.getChildByName("free_match_push"), t = false;
        return e && (t = e.active), t;
    }
    showPlayerHeadAnim(e, t, i, a = null) {
        if (null === this.seatPosVec[e] || undefined === this.seatPosVec[e]) {
            return;
        }
        let s = this.node.getChildByName("head_anim_root");
        s.active = true;
        let o = "head_anim" + e, l = s.getChildByName(o);
        if (-1 == i) {
            return void (l && (this.headAnimTimeAction && (TweenTool.stopAction(this.headAnimTimeAction), this.headAnimTimeAction = null), l.active = false));
        }
        if (null == this.headSkeletonData[i]) {
            return;
        }
        let h = this.seatPosVec[e];
        if (l) {
            if (this.headAnimTimeAction && (TweenTool.stopAction(this.headAnimTimeAction), this.headAnimTimeAction = null), 6 == t) {
                return void (l.active = false);
            }
            l.active = true;
            let s = h.y;
            s += 0 == e ? 4 : 9;
            l.setPosition(v3(h.x, s));
            let o = l.getComponent(sp.Skeleton);
            o.setToSetupPose();
            o.clearTracks();
            let m = "", d = false;
            1 == t ? (m = "1_welcome", 1 == i && (m = "1_welcome_2")) : 2 == t ? m = "2_cry" : 3 == t ? m = "3_take" : 4 == t ? m = "4_goout" : 5 == t ? (m = "5_win", 1 == i && (m = "5_win_2")) : 6 == t && (m = "6_Standby", d = true);
            o.skeletonData = this.headSkeletonData[i];
            o.setAnimation(0, m, d);
            o.setCompleteListener((() => {
                ToolUtils.isObjValid(this.node) && (l.active = false, 6 != t && a && a());
            }));
        }
    }
    showMatchPeopleAnimTips(e, t) {
        let i = this.node.getChildByName("match_people_tip");
        if (i && (i.active = e, e)) {
            let e = i.getChildByName("anim"), a = e.getChildByName("wz");
            e.active = true;
            a.active = true;
            let s = e.getComponent(sp.Skeleton);
            if (sys.isObjectValid(t)) {
                let e = t.total_user_count, i = t.now_user_count;
                a.getComponent(Label).string = i + "/" + e;
            }
            s.setToSetupPose();
            s.clearTracks();
            s.setAnimation(0, "Session_remind", false);
            s.setCompleteListener((() => {
                ToolUtils.isObjValid(this.node) && (i.active = false);
            }));
            TweenTool.delayAct(RummyDataManager.shared().sceneNode, (() => {
                ToolUtils.isObjValid(this.node) && (i.active = false);
            }), 2.1, true);
        }
    }
    setAvailableCardTipsVisible(e, t = null) {
        let i = this.node.getChildByName("available_cards_tip");
        ToolUtils.isObjValid(i) && (i.active = e, e && this.availableCardTipsTs && this.availableCardTipsTs.showTips(t));
    }
    refreshAvailableCardTips(e = null, t = null) {
        let i = this.node.getChildByName("available_cards_tip");
        ToolUtils.isObjValid(i) && i.active && this.availableCardTipsTs && this.availableCardTipsTs.refreshTips(e);
    }
    setManulaRejoinSelect(e, t = 0) {
        let i = this.node.getChildByName("pool_manula_rejoin_tips"), a = this.node.getChildByName("pool_manula_swtich_tips");
        e ? 1 == t ? (ToolUtils.isObjValid(i) && (i.active = true, i.getChildByName("rejoin_btn").getChildByName("gou").active = RummyDataManager.shared().rummyInfos.get(this.tid_key).manule_rejoin_select), ToolUtils.isObjValid(a) && (a.active = false)) : (ToolUtils.isObjValid(a) && (a.active = true), ToolUtils.isObjValid(i) && (i.active = false)) : (ToolUtils.isObjValid(a) && (a.active = false), ToolUtils.isObjValid(i) && (i.active = false));
    }
    getIsManulaSwitchShow() {
        return this.node.getChildByName("pool_manula_swtich_tips").active;
    }
    setManulaTipsShow(e) {
        let t = this.node.getChildByName("wait_pool_manula");
        ToolUtils.isObjValid(t) && (t.active = e);
    }
}
