// @ts-nocheck
// Recovered from index.js:241
import { _decorator, director, instantiate, sys } from "cc";
import Parent from "./Parent";
import i18nMgr from "./i18nMgr";
import PushCenter from "./PushCenter";
import { TLog } from "./TLog";
import { ToolUtils } from "./ToolUtils";
import { TransferPlatform } from "./TransferPlatform";
import TweenTool from "./TweenTool";
import Utils from "./Utils";
import BundleNameDefined from "./BundleNameDefined";
import { CommonGameType } from "./CommDefine";
import GameConfig from "./GameConfig";
import { HttpRequest } from "./HttpRequestName";
import NetConfig from "./NetConfig";
import PushEvent from "./PushEvent";
import URLConfig from "./URLConfig";
import User from "./User";
import HttpManager from "./HttpManager";
import NetHostManager from "./NetHostManager";
import Server from "./Server";
const { ccclass } = _decorator;
@ccclass("LoadTableGame")
export default class LoadTableGame extends Parent {
    public _TAG: string = "LoadTableGame";
    public roomId: number = 0;
    public gameType: number = 0;
    public loadTableNode: any = null;
    public is_back: number = 0;
    public isNewTable: number = 0;
    public bHasSendLogin: boolean = false;
    public tid_key: string = "";
    public tid: number = 0;
    public subLoadingDelay: any = null;
    onLoad() {
        this.baseExe();
    }
    showCommLoadTable(e) {
        if (window.InGameScene) {
            return this.clearEventByThis(), void this.removeLoadTable();
        }
        ToolUtils.report_time_param.showLoadTable = sys.now();
        let t = e.vid;
        if (this.roomId = t, this.gameType = e.game_type, sys.isObjectValid(e.tid_key) && (this.tid_key = e.tid_key), sys.isObjectValid(e.isNewTable) && (this.isNewTable = e.isNewTable), sys.isObjectValid(e.tid) && (this.tid = e.tid), 0 == sys.getNetworkType()) {
            return Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text91"), 3, 0, ToolUtils.getIsNormalDirection()), PushCenter.shared().pushEvent(PushEvent.HideSubLoadingAnim), this.clearEventByThis(), void this.removeLoadTable();
        }
        User.shared().game_id = e.game_id;
        !!e.is_sub_loading ? (this.subLoadingDelay && (TweenTool.stopAction(this.subLoadingDelay), this.subLoadingDelay = null), this.subLoadingDelay = TweenTool.delayAct(ToolUtils.getPersistGlobalNode(), (() => {
            0 == sys.getNetworkType() ? Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text91"), 3, 0, ToolUtils.getIsNormalDirection()) : (Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection()), User.shared().send_request_hall_tableinfo());
            PushCenter.shared().pushEvent(PushEvent.HideSubLoadingAnim);
        }), 5, true)) : Utils.shared().showLoading(5, true, (() => {
            0 == sys.getNetworkType() ? Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text91"), 3, 0, ToolUtils.getIsNormalDirection()) : (Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection()), User.shared().send_request_hall_tableinfo());
        }), ToolUtils.getIsNormalDirection());
        this.doConnectRequest();
    }
    doConnectRequest() {
        let e = Server.shared().isEnable();
        if (e || Server.shared().reset(), this.regEventinit(), Server.shared().setOpenCb((() => {
            User.shared().send_login_gate_request();
        })), Server.shared().setReconCb((() => {
        })), e) {
            Server.shared().pop_response();
            this.send_login_request();
        }
        else {
            let e = URLConfig.orginHttp_tcp, t = NetHostManager.shared().chooseBestTcpIpConn(this.roomId), a = NetHostManager.shared().chooseBestTcpPortConn(this.roomId);
            "-1" != t && -1 != a && (e = 443 == a ? "wss://" + t + ":443" : "ws://" + t + ":" + a);
            Server.shared().createSocket(e);
        }
    }
    send_login_request() {
        if (this.bHasSendLogin) {
            return;
        }
        this.bHasSendLogin = true;
        TweenTool.delayAct(ToolUtils.getPersistGlobalNode(), (() => {
            this.bHasSendLogin = false;
        }), 2, true);
        User.shared().send_game_log_time = sys.now();
        let e = { uid: User.shared().data.uid, skey: User.shared().getSkey(), version: GameConfig.Server_Api_Ver, ch_id: GameConfig.CHANNEL_ID, cmd: NetConfig.GM_LOGIN_REQUEST };
        ToolUtils.curVId = this.roomId > 0 ? this.roomId : 0;
        e.vid = this.roomId;
        e.isNewTable = this.isNewTable;
        e.tid_key = this.tid_key;
        0 != this.tid && (e.tid = this.tid);
        Server.shared().send(e);
        User.shared().enterRoomMoney = User.shared().data && User.shared().data.money ? User.shared().data.money : 0;
    }
    regEventinit() {
        Server.shared().regDispatch(NetConfig.SM_LOGIN_RETURN, this.handler_server_login_return.bind(this), this);
        Server.shared().regDispatch(NetConfig.SERVER_LOGIN_GATE_RESP, this.handler_server_login_gate_return.bind(this), this);
        Server.shared().regDispatch(NetConfig.SM_LOGIN_ERR_UC, this.handler_server_sm_login_err.bind(this), this);
        Server.shared().regDispatch(NetConfig.SYSTEM_GATEWAY_CMD, this.handler_server_system_gateway_return.bind(this), this);
        Server.shared().regDispatch(NetConfig.SM_CREATE_TABLE_RETURN, this.handler_server_create_tabel_return.bind(this), this);
    }
    handler_server_create_tabel_return(e) {
        if (User.shared().send_game_create_tab_time > 0 && (ToolUtils.enter_game_ping = sys.now() - User.shared().send_game_create_tab_time), 0 == parseInt("" + e.ret)) {
            sys.isObjectValid(e.session_id) && (User.shared().session_id = e.session_id);
            window.InGameScene || this.enterGameRoom(e);
        }
        else if (1002 == parseInt("" + e.code)) {
            ToolUtils.curRoomId = 0;
            User.shared().send_request_hall_tableinfo();
            let t = i18nMgr.shared().getValueByKey("utlis.notice"), a = e.alertStr || "";
            Utils.shared().showCommomDialog(a, t, (e => {
            }), false);
            this.removeLoadTable();
        }
        else if (1001 == e.code) {
            let t = i18nMgr.shared().getValueByKey("utlis.notice"), a = e.alertStr || "";
            Utils.shared().showCommomDialog(a, t, (e => {
                User.shared().showLogin();
            }), false);
            this.removeLoadTable();
        }
        else {
            if (Utils.shared().hideLoading(), sys.isObjectValid(e.venuetype) && 5 == e.venuetype && 1003 == e.code) {
                let t = { vid: ToolUtils.isSafeNumber(e.vid), parent_node: director.getScene().getChildByName("Canvas"), bShowNetTip: true, min_entry: ToolUtils.isSafeNumber(e.min_coin), hasFreeCoinReq: true };
                return void Utils.shared().showQuickChipRecharge(t);
            }
            let t = i18nMgr.shared().getValueByKey("utlis.notice"), i = e.alertStr || "", r = e.code;
            Utils.shared().showCommomDialog(i, t, (e => {
                1 == e && 1003 == r && PushCenter.shared().pushEvent(GameConfig.EnterRoom_LackMoney);
            }), false);
        }
    }
    handler_server_system_gateway_return(e) {
        if (this.handler_server_login_error(e) && -1 === e.res) {
            let e = i18nMgr.shared().getValueByKey("utlis.service_upgrade");
            Utils.shared().showToast(e, 2, 0, ToolUtils.getIsNormalDirection());
            Server.shared().onBackGroundLink();
            this.removeLoadTable();
        }
    }
    handler_server_login_gate_return(e) {
        if (window.InGameScene) {
            return this.clearEventByThis(), void this.removeLoadTable();
        }
        if (User.shared().send_gate_log_time > 0 && (ToolUtils.enter_game_ping = sys.now() - User.shared().send_gate_log_time), 0 == e.res) {
            Utils.shared().showLoading(5, true, (() => {
                Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
                User.shared().send_request_hall_tableinfo();
            }), ToolUtils.getIsNormalDirection(), 1);
            this.send_login_request();
        }
        else {
            Utils.shared().hideLoading();
            let t = ToolUtils.isSafeString(e.msg);
            0 === t.length && (t = i18nMgr.shared().getValueByKey("utlis.text4"));
            Utils.shared().showCommomDialog(t, i18nMgr.shared().getValueByKey("gameRummy_notice_Pop.notice"), (e => {
                1 == e ? (Utils.shared().showLoading(5, true, (() => {
                    Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
                }), ToolUtils.getIsNormalDirection(), 1), this.regEventinit(), this.doConnectRequest()) : this.removeLoadTable();
            }), true, false);
        }
    }
    handler_server_login_error(e) {
        let t = i18nMgr.shared().getValueByKey("utlis.notice"), a = e.msg;
        return Utils.shared().hideLoading(), -1 !== e.res || null == e.code || null == e.code || (Server.shared().onBackGroundLink(), 1002 == e.code ? (ToolUtils.isSafeString(a).length > 0 ? Utils.shared().showCommomDialog(a, t, (t => {
            1 == t ? (this.roomId = e.in_vid, this.regEventinit(), Utils.shared().showLoading(5, true, (() => {
                Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
            }), ToolUtils.getIsNormalDirection(), 1), this.doConnectRequest()) : this.removeLoadTable();
        }), true, false) : this.removeLoadTable(), false) : 1001 != e.code || (this.removeLoadTable(), ToolUtils.isSafeString(a).length > 0 && Utils.shared().showCommomDialog(a, t, (e => {
            User.shared().showLogin();
        }), false), false));
    }
    handler_server_sm_login_err(e) {
        if (null != e.alertStr && null != e.alertStr && e.alertStr.length > 0) {
            let t = 2;
            sys.isObjectValid(e.type) && (12 != e.type && 37 != e.type && 38 != e.type || (t = 6));
            Utils.shared().showToast(e.alertStr, t);
        }
        this.removeLoadTable();
    }
    handler_server_login_return(e) {
        if (sys.isObjectValid(e.session_id) && (User.shared().session_id = e.session_id), window.InGameScene) {
            return this.clearEventByThis(), void this.removeLoadTable();
        }
        if (User.shared().send_game_log_time > 0 && (ToolUtils.enter_game_ping = sys.now() - User.shared().send_game_log_time), 0 == parseInt("" + e.ret)) {
            1 == e.isNewTable ? this.createNewTable() : window.InGameScene || this.enterGameRoom(e);
        }
        else if (1002 == parseInt("" + e.code)) {
            ToolUtils.curRoomId = 0;
            User.shared().send_request_hall_tableinfo();
            let t = i18nMgr.shared().getValueByKey("utlis.notice"), a = e.alertStr || "", s = ToolUtils.isSafeNumber(e.in_vid), i = ToolUtils.isSafeNumber(e.game_type);
            ToolUtils.isSafeString(a).length > 0 && Utils.shared().showCommomDialog(a, t, (e => {
                if (1 == e) {
                    if (ToolUtils.checkIsRummy(i)) {
                        Utils.shared().showLoadTable(s, i);
                    }
                    else {
                        let e = { vid: s, game_type: i };
                        Utils.shared().showCommEnterGame(e);
                    }
                }
            }), false);
            this.removeLoadTable();
        }
        else {
            Utils.shared().hideLoading();
            let t = i18nMgr.shared().getValueByKey("utlis.notice"), a = e.alertStr || "", s = e.code;
            ToolUtils.isSafeString(a).length > 0 && Utils.shared().showCommomDialog(a, t, (e => {
                1 == e && 1003 == s && PushCenter.shared().pushEvent(GameConfig.EnterRoom_LackMoney);
            }), false);
        }
        0 == parseInt("" + e.ret) || (Server.shared().onBackGroundLink(), this.removeLoadTable());
    }
    createNewTable() {
        User.shared().send_game_create_tab_time = sys.now();
        let e = { cmd: NetConfig.GM_CREATE_TABLE_REQUEST, uid: User.shared().data.uid, version: GameConfig.Server_Api_Ver, skey: User.shared().getSkey(), vid: this.roomId, ch_id: GameConfig.CHANNEL_ID };
        e.tid_key = null != this.tid_key ? this.tid_key : "";
        Server.shared().send(e);
    }
    showLaFangAlert(e) {
        this.removeLoadTable();
        let t = i18nMgr.shared().getValueByKey("utlis.notice");
        if (sys.isObjectValid(e.game_type) && sys.isObjectValid(e.in_vid)) {
            e.game_type;
            e.in_vid;
            let a = e.alertStr;
            Utils.shared().showCommomDialog(a, t, (t => {
                1 == t && Utils.shared().showCommEnterGame(e);
            }), false);
        }
    }
    enterGameRoom(e) {
        null != e.old_tid_key && "" != e.old_tid_key || (!sys.isObjectValid(e.table_keys) || Array.isArray(e.table_keys) && e.table_keys.length <= 1) && 0 == this.tid_key.length && HttpManager.shared().doGetCommonRequest(null, HttpRequest.HallFirstInRoom, null);
        User.shared().curTid_key = ToolUtils.isSafeString(e.tid_key);
        ToolUtils.curRoomId = e.vid || this.roomId;
        ToolUtils.curGameType = e.game_type;
        User.shared().isShowMatchEnterTips = false;
        this.gameType == CommonGameType.Ludo && (ToolUtils.curGameType = CommonGameType.Ludo);
        this.gameType == CommonGameType.LuckBall ? (Utils.shared().hideLoading(), this.enterLuckyBallGame()) : this.enterGameScene();
        User.shared().enter_game_loadRes_time = sys.now();
    }
    enterLuckyBallGame() {
        if (!director.getScene().getChildByName("Canvas").getChildByName("LuckyBallGame")) {
            let e = this;
            ToolUtils.loadCommonPrefab(null, BundleNameDefined.Bundle_LuckyBall, "prefab/LuckyBallGame", (t => {
                try {
                    let a = instantiate(t), r = director.getScene().getChildByName("Canvas");
                    r.getChildByName("LuckyBallGame") ? a.destroy() : r.addChild(a);
                    e.removeLoadTable();
                }
                catch (e) {
                    TLog.printError("createLuckBallAnteWinPop error:", e);
                }
            }));
        }
    }
    enterGameScene() {
        window.InGameScene = true;
        window.InHallScene = false;
        Utils.shared().showLoading(5, true, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
            User.shared().send_request_hall_tableinfo();
        }), ToolUtils.getIsNormalDirection(), 1);
        PushCenter.shared().pushEvent(PushEvent.EnterSwitchScene);
        PushCenter.shared().pushEvent(PushEvent.Low_Memory_Notice);
        sys.isNative && sys.garbageCollect();
        TransferPlatform.shared().setHighFrameRate();
        this.enterSwitchScene();
    }
    enterSwitchScene() {
        ToolUtils.report_time_param.loadSwitchStart = sys.now();
        window.InSwitchScene = true;
        window.IsBackToHallLoad = false;
        let e = 100;
        sys.isNative ? sys.os !== sys.OS.IOS && sys.os !== sys.OS.OSX || (e = 50, ToolUtils.isPadPlatform() && (e = 30)) : e = 0;
        let t = this;
        ToolUtils.loadBundleScene(BundleNameDefined.bundle_switch, BundleNameDefined.switch_scence, ((a, s) => {
            null == a ? t.jumpToSwitchScene(t, e, s) : ToolUtils.loadBundleScene(BundleNameDefined.bundle_switch, BundleNameDefined.switch_scence, ((a, s) => {
                null == a ? t.jumpToSwitchScene(t, e, s) : (t.clearEventByThis(), Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text27"), 2), t.removeLoadTable(), window.InGameScene = false, window.InHallScene = true);
            }));
        }));
    }
    jumpToSwitchScene(e, t, i) {
        e.clearEventByThis();
        ToolUtils.report_time_param.loadSwitchEnd = sys.now();
        ToolUtils.bSwitchToGame = true;
        sys.os === sys.OS.IOS || sys.os === sys.OS.OSX ? (ToolUtils.isPadPlatform() ? Utils.shared().hideHallNode() : setTimeout((() => {
            Utils.shared().hideHallNode();
        }), t), TransferPlatform.shared().orientationToLandscape((() => {
            Utils.shared().hideHallNode();
            ToolUtils.isPadPlatform() ? setTimeout((() => {
                e && e.isValid && e.removeLoadTable();
                ToolUtils.switchSceneTye = 1;
                director.runScene(i);
            }), t) : (e && e.isValid && e.removeLoadTable(), ToolUtils.switchSceneTye = 1, director.runScene(i));
        }))) : (Utils.shared().hideHallNode(), TransferPlatform.shared().orientationToLandscape((() => {
            setTimeout((() => {
                e && e.isValid && e.removeLoadTable();
                ToolUtils.switchSceneTye = 1;
                director.runScene(i);
            }), t);
        })));
    }
    removeLoadTable() {
        Utils.shared().hideLoading();
        let e = director.getScene();
        if (ToolUtils.isObjValid(e)) {
            let t = e.getChildByName("Canvas").getChildByName("LoadTableGame");
            ToolUtils.isObjValid(t) && t.destroy();
        }
    }
    clearEventByThis() {
        Server.shared().clearEventByTarget(this);
    }
    onDestroy() {
        this.clearEventByThis();
        window.InGameScene || PushCenter.shared().pushEvent(GameConfig.Update_Match_Hall);
        this.subLoadingDelay && (TweenTool.stopAction(this.subLoadingDelay), this.subLoadingDelay = null);
    }
}
