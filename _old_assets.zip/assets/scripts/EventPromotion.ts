// @ts-nocheck
// Recovered from index.js:113
import { _decorator, Button, instantiate, Label, Node, Prefab, size, Sprite, SpriteAtlas, SpriteFrame, sys, UIOpacity, UITransform, v3 } from "cc";
import BaseLayer from "./BaseLayer";
import { TLog } from "./TLog";
import Utils from "./Utils";
import SoundManager from "./SoundManager";
import PushEvent from "./PushEvent";
import User from "./User";
import TweenTool from "./TweenTool";
import CommDefine, { CheckModule } from "./CommDefine";
import PushCenter from "./PushCenter";
import i18nMgr from "./i18nMgr";
import { TransferPlatform } from "./TransferPlatform";
import GameConfig from "./GameConfig";
import HttpManager from "./HttpManager";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("EventPromotion")
export class EventPromotion extends BaseLayer {
    public TAG: string = "EventPromotion";
    @property(Node)
    public rootNode: Node = null;
    @property(Node)
    public couponNode: Node = null;
    @property([Node])
    public couponTaskItems: Node[] = [];
    @property(Node)
    public rewardModel: Node = null;
    @property(Node)
    public linksNode: Node = null;
    @property([SpriteFrame])
    public bgImgs: SpriteFrame[] = [];
    @property(Prefab)
    public couponItemPrefab: Prefab = null;
    @property(SpriteAtlas)
    public rewardPlist: SpriteAtlas = null;
    @property([SpriteFrame])
    public shareImgs: SpriteFrame[] = [];
    @property(Node)
    public ruleNode: Node = null;
    @property(Label)
    public ruleLabel: Label = null;
    public ruleData: string = "";
    public image_url: string = "";
    public bg_names: any[] = ["tourneys_format.png"];
    public isNext: boolean = false;
    public _actId: any = PushEvent.JUMP_TO_TOURNESFORMAT;
    public _targetRoom: any = {};
    public leftPushTime: number = 0;
    public free_match_action: any = null;
    public gameType: number = 0;
    public rummyType: number = 0;
    public _ext: any = null;
    public _curListIdx: number = 0;
    public _couponList: any[] = [];
    public _payAmt: any[] = [];
    public _endPosArr: any[] = [];
    public lastPlayNowClick: number = 0;
    public lastAddCashClick: number = 0;
    public lastSwitchClick: number = 0;
    public startShareTime: number = 0;
    public finish_seconds: number = 15;
    public raceId: any = null;
    public _has_close: boolean = false;
    public _hasShareReward: boolean = false;
    public _canGetReward: boolean = true;
    public _hasWhatsApp: any = 1 === TransferPlatform.shared().checkPackageInstalled("com.whatsapp");
    public _hasTelegram: any = 1 === TransferPlatform.shared().checkPackageInstalled("org.telegram.messenger") || 1 === TransferPlatform.shared().checkPackageInstalled("org.telegram.messenger.web");
    onLoad() {
        for (let t = 0, e = this.couponTaskItems.length; t < e; t++) {
            this._endPosArr.push(this.couponTaskItems[t].getPosition());
        }
    }
    initParaData(t) {
        this._ext = t;
        sys.isObjectValid(t) && (sys.isObjectValid(t.pop_url) && (this.image_url = t.pop_url), sys.isObjectValid(t.isNext) && (this.isNext = t.isNext), sys.isObjectValid(t.act_id) && (this._actId = Number(t.act_id)), sys.isObjectValid(t.raceid) && (this.raceId = Number(t.raceid)), sys.isObjectValid(t.race_id) && (this.raceId = Number(t.race_id)));
    }
    start() {
        super.start();
        ToolUtils.showFullScreen(this.node.getChildByName("mask"));
        this.ruleNode.active = false;
        ToolUtils.showFullScreen(this.ruleNode.getChildByName("mask"));
        this.startShowAnim(this.rootNode, (() => {
        }));
        this._actId == PushEvent.JUMP_TO_GoldenLinks && (sys.isObjectValid(User.shared().golden_link_data) && (this._ext = User.shared().golden_link_data), User.shared().doGetActGoldenLinksInfo((() => {
            ToolUtils.isObjValid(this.node) && (this._ext = User.shared().golden_link_data, this.refreshUI());
        })));
        this.refreshUI();
        PushCenter.shared().addListener(PushEvent.HideSubLoadingAnim, (t => {
            ToolUtils.isObjValid(this.node) && (this.rootNode.getChildByName("playnow_btn").getChildByName("loading").active = false);
        }), this);
        PushCenter.shared().addListener(PushEvent.RefreshCouponRecharge, (t => {
            ToolUtils.isObjValid(this.node) && this._actId == PushEvent.JUMP_TO_Act_RechangeCoupon && this.onBackView();
        }), this);
        PushCenter.shared().addListener(PushEvent.OrderSuccess, (t => {
            ToolUtils.isObjValid(this.node) && this._actId == PushEvent.JUMP_TO_Act_RechangeCoupon && this.onBackView();
        }), this);
        PushCenter.shared().addListener(GameConfig.onEnterForeground, (t => {
            if (ToolUtils.isObjValid(this.node) && this._actId == PushEvent.JUMP_TO_GoldenLinks) {
                let t = Math.ceil((sys.now() - this.startShareTime) / 1000);
                this._hasShareReward && this._canGetReward && this.startShareTime > 0 && t >= this.finish_seconds && (this._canGetReward = false, this.requestShareRewards(t), TweenTool.delayAct(this.node, (() => {
                    this._canGetReward = true;
                }), 3, true));
            }
        }), this);
    }
    initBtnTips() {
        let t = this.rootNode.getChildByName("close_btn"), e = this.rootNode.getChildByName("ok_btn"), i = this.rootNode.getChildByName("playnow_btn"), s = this.rootNode.getChildByName("other_amount");
        t.setPosition(v3(308, 466));
        this._actId == PushEvent.JUMP_TO_Act_RechangeCoupon || this._actId == PushEvent.JUMP_TO_GoldenLinks ? (s.active = false, i.active = false, e.active = false) : (this._actId == PushEvent.JUMP_TO_Act_MemberShipRpExchange && (i.getChildByName("wz").getComponent(Label).string = "REDEMPTION"), i.active = true, e.active = false, s.active = false);
        this._actId != PushEvent.JUMP_TO_Act_MemberShipRpExchange && this._actId != PushEvent.JUMP_TO_TOURNESFORMAT && (this._actId == PushEvent.JUMP_TO_GoldenLinks ? this.initGoldenLinkContent() : this._actId == PushEvent.JUMP_TO_Act_RechangeCoupon ? (this.initCouponContent(), s.active = !!(sys.isObjectValid(this._couponList) && this._couponList.length > 1)) : this.updateBtnTips());
    }
    initGoldenLinkContent() {
        if (this.linksNode.active = true, !sys.isObjectValid(this._ext)) {
            return;
        }
        if (ToolUtils.isSafeString(String(this._ext.subtitle)).length > 0) {
            this.linksNode.getChildByName("sub_title").getComponent(Label).string = this._ext.subtitle;
            this.linksNode.getChildByName("sub_title").getComponent(Label).updateRenderData(true);
            let t = this.linksNode.getChildByName("sub_title").getComponent(UITransform).contentSize, e = this.linksNode.getChildByName("title_bg").getComponent(UITransform).contentSize;
            this.linksNode.getChildByName("title_bg").getComponent(UITransform).setContentSize(size(t.width + 60, e.height));
        }
        ToolUtils.isSafeString(String(this._ext.reward_content)).length > 0 && (this.linksNode.getChildByName("tx_reward").getComponent(Label).string = this._ext.reward_content);
        ToolUtils.isSafeString(String(this._ext.times_left_content)).length > 0 && (this.linksNode.getChildByName("tx_left").getComponent(Label).string = this._ext.times_left_content);
        this._hasShareReward = !!sys.isObjectValid(this._ext.has_reward) && 1 == this._ext.has_reward;
        let t = "SEND & INVITE";
        this._hasShareReward && sys.isObjectValid(this._ext.amount_text) && (t = "SEND & GET " + this._ext.amount_text);
        let e = this.linksNode.getChildByName("link_btn");
        this._hasWhatsApp ? (e.getChildByName("Layout").getChildByName("ico").active = true, e.getChildByName("Layout").getChildByName("ico").getComponent(Sprite).spriteFrame = this.shareImgs[0]) : this._hasTelegram ? (e.getChildByName("Layout").getChildByName("ico").active = true, e.getChildByName("Layout").getChildByName("ico").getComponent(Sprite).spriteFrame = this.shareImgs[1]) : e.getChildByName("Layout").getChildByName("ico").active = false;
        this.linksNode.getChildByName("other_methons").active = this._hasWhatsApp || this._hasTelegram;
        e.getChildByName("Layout").getChildByName("wz").getComponent(Label).string = t;
        sys.isObjectValid(this._ext.finish_seconds) && (this.finish_seconds = this._ext.finish_seconds);
        sys.isObjectValid(this._ext.rule) && (this.ruleData = this._ext.rule);
    }
    updateBtnTips() {
        if (this._actId == PushEvent.JUMP_TO_Act_BestHighScore || this._actId == PushEvent.JUMP_TO_Act_Wild || this._actId == PushEvent.JUMP_TO_Act_Multiple || this._actId == PushEvent.JUMP_TO_Act_Double) {
            let t = User.shared().getBestRoomInfoByActId(this._actId);
            sys.isObjectValid(t) && sys.isObjectValid(t.strTip) && sys.isObjectValid(t.targetRoom) && (this.rummyType = t.rummyType, this._targetRoom = t.targetRoom, this.rootNode.getChildByName("tips").getComponent(Label).string = t.strTip, this.rootNode.getChildByName("tips").active = true);
        }
        else if (this._actId == PushEvent.JUMP_TO_FreeMatch) {
            if (!sys.isObjectValid(this._ext)) {
                return;
            }
            let t = ToolUtils.format("${0}: ${1}", i18nMgr.shared().getValueByKey("freeMatchPush.game_name"), this._ext.name);
            0 == Number(this._ext.mode) ? sys.isObjectValid(this._ext.end) && (t += "\n" + ToolUtils.format("${0}: ${1}", i18nMgr.shared().getValueByKey("freeMatchPush.ddl"), this._ext.end)) : 1 != Number(this._ext.mode) && 3 != Number(this._ext.mode) || (this.leftPushTime = Number(this._ext.end), this.free_match_action && TweenTool.stopAction(this.free_match_action), 3 == Number(this._ext.mode) && this.leftPushTime <= 0 ? t += "\n" + ToolUtils.format("${0}: ${1}", i18nMgr.shared().getValueByKey("freeMatchPush.ddl"), i18nMgr.shared().getValueByKey("freeMatchPush.enter")) : (t += "\n" + ToolUtils.format("${0}: ${1}", i18nMgr.shared().getValueByKey("freeMatchPush.ddl"), Utils.shared().getCountDownString(this.leftPushTime)), this.free_match_action = TweenTool.myschedule(this.node, 1, this.updateFreeMatchPushTime.bind(this))));
            this.rootNode.getChildByName("match_tips").getComponent(Label).string = t;
            this.rootNode.getChildByName("match_tips").active = true;
        }
    }
    initCouponContent() {
        if (this.couponNode.active = true, sys.isObjectValid(this._ext)) {
            if (sys.isObjectValid(this._ext.title_url) && this._ext.title_url.length > 0 && Utils.shared().updateNetImage(this.couponNode.getChildByName("title"), this._ext.title_url), sys.isObjectValid(this._ext.coupon)) {
                let t = this.couponNode.getChildByName("coupon_item").getChildByName("top_coupon");
                if (ToolUtils.isObjValid(t)) {
                    let e = t.getComponent("CouponItem");
                    e.updateUI(this._ext.coupon, 0, 1, null);
                    e.hideSeletctCircle();
                }
                else if (t = instantiate(this.couponItemPrefab), ToolUtils.isObjValid(t)) {
                    t.name = "top_coupon";
                    t.position = v3(0, -2, 0);
                    this.couponNode.getChildByName("coupon_item").addChild(t);
                    let e = t.getComponent("CouponItem");
                    e.updateUI(this._ext.coupon, 0, 1, null);
                    e.hideSeletctCircle();
                }
            }
            sys.isObjectValid(this._ext.rewardList) && (this.progressConponData(Number(this._ext.coupon.price)), this.initCouponList());
        }
    }
    progressConponData(t) {
        this._couponList = [];
        this._payAmt = [];
        this._curListIdx = 0;
        let e = -1, i = this._ext.coupon.allow_price.length;
        if (i <= 3) {
            let t = [], e = [];
            for (let s = 0; s < i; s++) {
                t.push(this._ext.rewardList[s]);
                e.push(this._ext.coupon.allow_price[s]);
            }
            return this._couponList.push(t), void this._payAmt.push(e);
        }
        for (let s = 0; s < i; s++) {
            if (Number(this._ext.coupon.allow_price[s]) == t) {
                e = s;
                break;
            }
        }
        if (e < 0) {
            return;
        }
        let s = true, a = true;
        if (e >= i - 2) {
            let t = [], e = [];
            for (let s = i - 3; s < i; s++) {
                t.push(this._ext.rewardList[s]);
                e.push(this._ext.coupon.allow_price[s]);
            }
            this._couponList.push(t);
            this._payAmt.push(e);
            s = false;
        }
        else if (e < 2) {
            let t = [], e = [];
            for (let i = 0; i < 3; i++) {
                t.push(this._ext.rewardList[i]);
                e.push(this._ext.coupon.allow_price[i]);
            }
            this._couponList.push(t);
            this._payAmt.push(e);
            a = false;
        }
        else {
            let t = [], i = [];
            for (let s = e - 1; s < e + 2; s++) {
                t.push(this._ext.rewardList[s]);
                i.push(this._ext.coupon.allow_price[s]);
            }
            this._couponList.push(t);
            this._payAmt.push(i);
        }
        if (s) {
            let t = [], e = [];
            for (let s = i - 3; s < i; s++) {
                t.push(this._ext.rewardList[s]);
                e.push(this._ext.coupon.allow_price[s]);
            }
            this._couponList.push(t);
            this._payAmt.push(e);
        }
        if (a) {
            let t = [], e = [];
            for (let i = 0; i < 3; i++) {
                t.push(this._ext.rewardList[i]);
                e.push(this._ext.coupon.allow_price[i]);
            }
            this._couponList.push(t);
            this._payAmt.push(e);
        }
    }
    initCouponList(t = -1) {
        let e = this._curListIdx, i = this._couponList[e], s = this._payAmt[e];
        if (t >= 0 && sys.isObjectValid(this._couponList[t])) {
            e = t;
            i = this._couponList[e];
            s = this._payAmt[e];
            for (let t = 0; t < i.length && t < 3; t++) {
                let e = this._endPosArr[t];
                TweenTool.stopNodeAction(this.couponTaskItems[t]);
                this.couponTaskItems[t].getComponent(UIOpacity).opacity = 0;
                this.couponTaskItems[t].setPosition(v3(e.x, e.y - 400));
                let i = TweenTool.delayAct(this.couponTaskItems[t], null, (13 + 3 * t) / 40, false), s = TweenTool.moveToByFade(this.couponTaskItems[t], 0.2, v3(e.x, e.y + 20), 0, 1, false), a = TweenTool.moveTo(this.couponTaskItems[t], 0.05, e, null, false);
                TweenTool.sequence(this.couponTaskItems[t], true, null, i, s, a);
            }
            TweenTool.delayAct(this.node, (() => {
                for (let t = 0; t < i.length && t < 3; t++) {
                    TweenTool.stopNodeAction(this.couponTaskItems[t]);
                    this.couponTaskItems[t].active = true;
                    this.couponTaskItems[t].getComponent(UIOpacity).opacity = 255;
                    this.couponTaskItems[t].setPosition(this._endPosArr[t]);
                }
            }), 0.8, true);
        }
        else if (sys.isObjectValid(i)) {
            for (let t = 0; t < i.length && t < 3; t++) {
                this.couponTaskItems[t].getComponent(UIOpacity).opacity = 255;
                this.couponTaskItems[t].setPosition(this._endPosArr[t]);
            }
        }
        if (this._curListIdx = e, sys.isObjectValid(i)) {
            for (let t = 0; t < i.length && t < 3; t++) {
                this.couponTaskItems[t].active = true;
                let e = this.couponTaskItems[t].getChildByName("rewardList").getChildByName("view").getChildByName("content");
                e.removeAllChildren();
                for (let s = 0, a = i[t].length; s < a; s++) {
                    let a = instantiate(this.rewardModel);
                    this.updateRewardSprite(a.getChildByName("ico"), Number(i[t][s].type));
                    a.getChildByName("num").getComponent(Label).string = i[t][s].amt;
                    a.active = true;
                    a.name = "reward" + s;
                    e.addChild(a);
                }
                this.couponTaskItems[t].getChildByName("btn").active = true;
                this.couponTaskItems[t].getChildByName("btn").getChildByName("wz").getComponent(Label).string = ToolUtils.format("₹${0}", s[t]);
            }
        }
    }
    updateRewardSprite(t, e) {
        ToolUtils.isSafeString(CommDefine.rewardPistName[e]).length > 0 && Utils.shared().setImage(t, CommDefine.rewardPistName[e], this.rewardPlist);
    }
    switchCouponList() {
        let t = -1;
        sys.isObjectValid(this._couponList) && sys.isObjectValid(this._couponList[this._curListIdx + 1]) ? t = this._curListIdx + 1 : sys.isObjectValid(this._couponList) && this._couponList.length > 1 && (t = 0);
        t >= 0 && this.initCouponList(t);
    }
    showRuleView() {
        ToolUtils.isObjValid(this.ruleNode) && (this.ruleNode.active ? (this.ruleLabel.string = this.ruleData, i18nMgr.shared().changeLabelFont(this.ruleLabel)) : (this.ruleNode.active = true, this.startShowAnim(this.ruleNode.getChildByName("bg"), (() => {
            this.ruleLabel.string = this.ruleData;
        }))));
    }
    updateFreeMatchPushTime() {
        this.leftPushTime = this.leftPushTime - 1;
        let t = ToolUtils.format("${0}: ${1}", i18nMgr.shared().getValueByKey("freeMatchPush.game_name"), this._ext.name);
        if (this.leftPushTime <= 0 && (this.free_match_action && (TweenTool.stopAction(this.free_match_action), this.free_match_action = null), 3 == Number(this._ext.mode))) {
            return t += "\n" + ToolUtils.format("${0}: ${1}", i18nMgr.shared().getValueByKey("freeMatchPush.ddl"), i18nMgr.shared().getValueByKey("freeMatchPush.enter")), void (this.rootNode.getChildByName("match_tips").getComponent(Label).string = t);
        }
        t += "\n" + ToolUtils.format("${0}: ${1}", i18nMgr.shared().getValueByKey("freeMatchPush.ddl"), Utils.shared().getCountDownString(this.leftPushTime));
        this.rootNode.getChildByName("match_tips").getComponent(Label).string = t;
    }
    refreshUI() {
        let t = this.rootNode.getChildByName("bg"), e = this.rootNode.getChildByName("close_btn"), i = this.rootNode.getChildByName("ok_btn"), s = this.rootNode.getChildByName("playnow_btn");
        switch (this._actId) {
            case PushEvent.JUMP_TO_TOURNESFORMAT:
                e.setPosition(v3(318, 510)), i.active = true, s.active = false;
                break;
            case PushEvent.JUMP_TO_Act_BestHighScore:
                sys.isObjectValid(this.bgImgs[0]) && (t.getComponent(Sprite).spriteFrame = this.bgImgs[0]), this.initBtnTips();
                break;
            case PushEvent.JUMP_TO_Act_Wild:
                sys.isObjectValid(this.bgImgs[1]) && (t.getComponent(Sprite).spriteFrame = this.bgImgs[1]), this.initBtnTips();
                break;
            case PushEvent.JUMP_TO_Act_Multiple:
                sys.isObjectValid(this.bgImgs[2]) && (t.getComponent(Sprite).spriteFrame = this.bgImgs[2]), this.initBtnTips();
                break;
            case PushEvent.JUMP_TO_Act_Double:
                sys.isObjectValid(this.bgImgs[1]) && (t.getComponent(Sprite).spriteFrame = this.bgImgs[1]), this.initBtnTips();
                break;
            case PushEvent.JUMP_TO_Act_MemberShipRpExchange:
                sys.isObjectValid(this.bgImgs[3]) && (t.getComponent(Sprite).spriteFrame = this.bgImgs[3]), this.initBtnTips();
                break;
            case PushEvent.JUMP_TO_Act_RechangeCoupon:
                sys.isObjectValid(this.bgImgs[4]) && (t.getComponent(Sprite).spriteFrame = this.bgImgs[4]), this.initBtnTips();
                break;
            case PushEvent.JUMP_TO_FreeMatch:
                sys.isObjectValid(this.bgImgs[5]) && (t.getComponent(Sprite).spriteFrame = this.bgImgs[5]), this.initBtnTips();
                break;
            case PushEvent.JUMP_TO_GoldenLinks: sys.isObjectValid(this.bgImgs[6]) && (t.getComponent(Sprite).spriteFrame = this.bgImgs[6]), this.initBtnTips();
        }
        let a = ToolUtils.getImageUrlPictureName(this.image_url);
        if (ToolUtils.isSafeString(a).length > 0 && a != this.bg_names[0]) {
            let e = this._actId == PushEvent.JUMP_TO_TOURNESFORMAT ? size(720, 1280) : null;
            Utils.shared().updateNetImage(t, this.image_url, e, (() => {
            }));
        }
    }
    onButtonClick(t, e) {
        if (SoundManager.shared().playFx("click"), "close" === e) {
            this.onBackView();
        }
        else if ("ok" === e) {
            if (sys.now() - this.lastPlayNowClick < 1000) {
                return;
            }
            switch ((this.lastPlayNowClick = sys.now(), this._actId)) {
                case PushEvent.JUMP_TO_TOURNESFORMAT:
                    this.isNext = false, sys.isObjectValid(this.raceId) && 0 == this.raceId ? Utils.shared().doJumpLogic(PushEvent.JUMP_TO_MATCH_ROOM) : User.shared().sendJoinMatch({ raceid: this.raceId, is_detail: 1 }), this.onBackView();
                    break;
                case PushEvent.JUMP_TO_FreeMatch:
                    User.shared().sendJoinMatch({ raceid: this.raceId, is_detail: 1 }), this.onBackView();
                    break;
                case PushEvent.JUMP_TO_Act_BestHighScore:
                case PushEvent.JUMP_TO_Act_Wild:
                case PushEvent.JUMP_TO_Act_Multiple:
                case PushEvent.JUMP_TO_Act_Double:
                    if (sys.isObjectValid(this._targetRoom.vid) || this.updateBtnTips(), !User.shared().checkCanPlayCashGame(CheckModule.CASH_PLAY)) {
                        return;
                    }
                    if (this.rootNode.getChildByName("playnow_btn").getComponent(Button).interactable = false, TweenTool.delayAct(this.rootNode, (() => {
                        ToolUtils.isObjValid(this.rootNode) && (this.rootNode.getChildByName("playnow_btn").getComponent(Button).interactable = true);
                    }), 1, true), this._targetRoom && User.shared().data.money < this._targetRoom.entry) {
                        let t = this._targetRoom.vid, e = this._targetRoom.entry;
                        Utils.shared().showQuickRecharge(t, null, true, "", 0, e, true, 0, 1);
                    }
                    else if (this._targetRoom && this._targetRoom.vid) {
                        0 == this.gameType && (User.shared().first_click_play_time = Math.floor(sys.now() / 1000));
                        let t = this.rootNode.getChildByName("playnow_btn").getChildByName("loading");
                        if (ToolUtils.isObjValid(t)) {
                            t.active = true;
                            TweenTool.stopNodeAction(t);
                            let e = TweenTool.rotateBy(t, 1, v3(0, 0, 360));
                            TweenTool.repeatForever(e);
                            e.start();
                        }
                        User.shared().enterGame({ gameType: this.gameType, rummyType: this.rummyType, roomInfo: this._targetRoom, is_sub_loading: 1 });
                    }
                    break;
                case PushEvent.JUMP_TO_Act_MemberShipRpExchange: Utils.shared().doJumpLogic(PushEvent.JUMP_TO_CLUB), this.isNext = false, this.onBackView();
            }
        }
        else if ("otherAmounts" === e) {
            if (sys.now() - this.lastSwitchClick < 850) {
                return;
            }
            this.lastSwitchClick = sys.now();
            this.switchCouponList();
        }
        else if ("link_help" === e) {
            this.showRuleView();
        }
        else if ("send_btn" === e) {
            if (sys.now() - this.lastPlayNowClick < 800) {
                return;
            }
            this.lastPlayNowClick = sys.now();
            let t = this._ext.share_text + " " + this._ext.share_url;
            this.startShareTime = 0;
            this._hasWhatsApp ? (User.shared().shareImageAndTextToThirdApp(1, this._ext.img_whatsapp, t), this._hasShareReward && (this.startShareTime = sys.now())) : this._hasTelegram ? (!sys.isNative || sys.os !== sys.OS.ANDROID && sys.os !== sys.OS.OHOS ? sys.isNative && sys.os === sys.OS.IOS ? User.shared().shareImageAndTextToThirdApp(4, this._ext.img_whatsapp, t) : TransferPlatform.shared().shareWebPage(ToolUtils.isSafeString(t)) : 1 === TransferPlatform.shared().checkPackageInstalled("org.telegram.messenger") ? TransferPlatform.shared().shareTextToApp("org.telegram.messenger", t) : 1 === TransferPlatform.shared().checkPackageInstalled("org.telegram.messenger.web") && TransferPlatform.shared().shareTextToApp("org.telegram.messenger.web", t), this._hasShareReward && (this.startShareTime = sys.now())) : (this._hasShareReward && (this.startShareTime = sys.now()), TransferPlatform.shared().shareWebPage(ToolUtils.isSafeString(t)));
        }
        else if ("other_methons" === e) {
            if (sys.now() - this.lastPlayNowClick < 800) {
                return;
            }
            this.lastPlayNowClick = sys.now();
            this.startShareTime = 0;
            let t = this._ext.share_text + " " + this._ext.share_url;
            TransferPlatform.shared().shareWebPage(ToolUtils.isSafeString(t));
        }
        else {
            "helpClose" === e && (this.ruleNode.active = false);
        }
    }
    onAddCashButtonClick(t, e) {
        SoundManager.shared().playFx("click");
        let i = this._payAmt[this._curListIdx];
        if (i && sys.isObjectValid(i[e])) {
            if (!User.shared().checkCanRecharge()) {
                return void (ToolUtils.isObjValid(this.node) && (this.isNext && PushCenter.shared().pushEvent(PushEvent.Update_NextPopActivity), this.node.destroy()));
            }
            if (sys.now() - this.lastAddCashClick < 800) {
                return;
            }
            this.lastAddCashClick = sys.now();
            let t = { price: ToolUtils.isSafeNumber(i[e]), act_id: PushEvent.JUMP_TO_Act_RechangeCoupon, coupon_id: this._ext.coupon.coupon_id };
            User.shared().startPay(t);
        }
        else {
            TLog.printError("onAddCashButtonClick Amt err!");
        }
    }
    requestShareRewards(t) {
        Utils.shared().showLoading(10, true, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
        }), ToolUtils.getIsNormalDirection());
        HttpManager.shared().doGetCommonRequest({ finish_seconds: t }, "Activity.Act_122.reward", ((t, e, i) => {
            Utils.shared().hideLoading();
            try {
                if (200 != i) {
                    0 == sys.getNetworkType() ? Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text91"), 3, 0, ToolUtils.getIsNormalDirection()) : Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
                }
                else {
                    let t = ToolUtils.parseJson(e);
                    if (0 == t.ret && ToolUtils.isObjValid(this.node)) {
                        if (0 == t.data.has_reward) {
                            return void User.shared().doGetActGoldenLinksInfo((() => {
                                this.initBtnTips();
                            }));
                        }
                        sys.isObjectValid(t.data.reward_list) && (User.shared().doGetActGoldenLinksInfo(), User.shared().showChargeReward(t.data.reward_list, (() => {
                            ToolUtils.isObjValid(this.node) && this.onBackView();
                            User.shared().getHallInfo();
                            Utils.shared().hideToast();
                        }), t.data.msg));
                    }
                }
            }
            catch (t) {
                TLog.printError("requestShareRewards Callback:", t);
            }
        }));
    }
    onBackView() {
        if (ToolUtils.isObjValid(this.node)) {
            if (ToolUtils.isObjValid(this.ruleNode) && this.ruleNode.active) {
                this.ruleNode.active = false;
            }
            else {
                if (this._has_close) {
                    return;
                }
                let t = { alert_node: this.node, rootNode: this.rootNode, isNext: this.isNext, pop_type: this._actId };
                Utils.shared().closeActivityView(t);
                this._has_close = true;
            }
        }
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().removeListenersByTag(this);
    }
}
