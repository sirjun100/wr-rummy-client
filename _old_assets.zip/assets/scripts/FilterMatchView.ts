// @ts-nocheck
// Recovered from index.js:123
import { _decorator, Label, Node, Sprite, SpriteFrame, v3, Vec3 } from "cc";
import BaseLayer from "./BaseLayer";
import TweenTool from "./TweenTool";
import SoundManager from "./SoundManager";
import i18nMgr from "./i18nMgr";
import { ToolUtils } from "./ToolUtils";
import GameConfig from "./GameConfig";
const { ccclass, property } = _decorator;
@ccclass("FilterMatchView")
export class FilterMatchView extends BaseLayer {
    @property(Node)
    public bgNode: Node = null;
    @property([Node])
    public selectStatusBtn: Node[] = [];
    @property([Node])
    public selectTypeBtn: Node[] = [];
    @property([Node])
    public selectStartBtn: Node[] = [];
    @property([Node])
    public selectPrizeBtn: Node[] = [];
    @property(Node)
    public resetWzNode: Node = null;
    @property(Node)
    public confirmWzNode: Node = null;
    @property([SpriteFrame])
    public timeSelect_Imgs: SpriteFrame[] = [];
    public _startY: number = 0;
    public _closeAct: any = null;
    public _startAct: any = null;
    public curGameStatus: number = 0;
    public curGameType: number = 0;
    public _callback: any = null;
    public MatchFilterTag: any[] = [[1], [0], [1], [1]];
    start() {
        super.start();
        ToolUtils.showFullScreen(this.node);
        this.showSelectView();
    }
    initData(e = null, t = null) {
        if (e) {
            for (let t = 0, i = e.curMatchFilterTag.length; t < i; t++) {
                this.MatchFilterTag[t] = [];
                for (let i = 0, a = e.curMatchFilterTag[t].length; i < a; i++) {
                    this.MatchFilterTag[t][i] = ToolUtils.isSafeNumber(e.curMatchFilterTag[t][i]);
                }
            }
        }
        this.updateSelectView();
        this._callback = t;
    }
    onButtonClick(e, t) {
        if (SoundManager.shared().playFx("click"), "close" == t) {
            this.hideSelectView();
        }
        else if ("reset" == t) {
            this.MatchFilterTag = [[1], [0], [1], [1]];
            this.updateSelectView();
        }
        else if ("confirm" == t) {
            let e = { MatchFilterTag: this.MatchFilterTag };
            this._callback && this._callback(e);
            this.hideSelectView();
        }
    }
    onGameStatusClick(e, t) {
        SoundManager.shared().playFx("click");
        let i = Number(t);
        0 == i ? this.MatchFilterTag[0] = [1] : (this.MatchFilterTag[0][0] = 0, this.MatchFilterTag[0][i] = (ToolUtils.isSafeNumber(this.MatchFilterTag[0][i]) + 1) % 2, this.MatchFilterTag[0].includes(1) || (this.MatchFilterTag[0] = [1]));
        this.updateSelectView();
    }
    onGameTypeClick(e, t) {
        SoundManager.shared().playFx("click");
        let i = Number(t);
        this.MatchFilterTag[1][i] = (ToolUtils.isSafeNumber(this.MatchFilterTag[1][i]) + 1) % 2;
        this.updateSelectView();
    }
    onGameStartClick(e, t) {
        SoundManager.shared().playFx("click");
        let i = Number(t);
        0 == i ? this.MatchFilterTag[2] = [1] : (this.MatchFilterTag[2][0] = 0, this.MatchFilterTag[2][i] = (ToolUtils.isSafeNumber(this.MatchFilterTag[2][i]) + 1) % 2, this.MatchFilterTag[2].includes(1) || (this.MatchFilterTag[2] = [1]));
        this.updateSelectView();
    }
    onGamePrizeClick(e, t) {
        SoundManager.shared().playFx("click");
        this.MatchFilterTag[3][0] = Number(t);
        let i = Number(t);
        0 == i ? this.MatchFilterTag[3] = [1] : (this.MatchFilterTag[3][0] = 0, this.MatchFilterTag[3][i] = (ToolUtils.isSafeNumber(this.MatchFilterTag[3][i]) + 1) % 2, this.MatchFilterTag[3].includes(1) || (this.MatchFilterTag[3] = [1]));
        this.updateSelectView();
    }
    updateSelectView() {
        for (let e, t = 0, i = this.selectStatusBtn.length; t < i; t++) {
            e = this.selectStatusBtn[t];
            ToolUtils.isSafeNumber(1 == this.MatchFilterTag[0][0]) ? 0 == t ? (e.getChildByName("bg").getComponent(Sprite).spriteFrame = this.timeSelect_Imgs[1], i18nMgr.shared().changeLabelFont(e.getChildByName("wz").getComponent(Label), true)) : (this.MatchFilterTag[0][t] = 0, e.getChildByName("bg").getComponent(Sprite).spriteFrame = this.timeSelect_Imgs[0], i18nMgr.shared().changeLabelFont(e.getChildByName("wz").getComponent(Label), false)) : 1 == ToolUtils.isSafeNumber(this.MatchFilterTag[0][t]) ? (e.getChildByName("bg").getComponent(Sprite).spriteFrame = this.timeSelect_Imgs[1], i18nMgr.shared().changeLabelFont(e.getChildByName("wz").getComponent(Label), true)) : (e.getChildByName("bg").getComponent(Sprite).spriteFrame = this.timeSelect_Imgs[0], i18nMgr.shared().changeLabelFont(e.getChildByName("wz").getComponent(Label), false));
        }
        for (let e, t = 0, i = this.selectTypeBtn.length; t < i; t++) {
            e = this.selectTypeBtn[t];
            1 == ToolUtils.isSafeNumber(this.MatchFilterTag[1][t]) ? (e.getChildByName("bg").getComponent(Sprite).spriteFrame = this.timeSelect_Imgs[1], i18nMgr.shared().changeLabelFont(e.getChildByName("wz").getComponent(Label), true)) : (e.getChildByName("bg").getComponent(Sprite).spriteFrame = this.timeSelect_Imgs[0], i18nMgr.shared().changeLabelFont(e.getChildByName("wz").getComponent(Label), false));
        }
        for (let e, t = 0, i = this.selectStartBtn.length; t < i; t++) {
            e = this.selectStartBtn[t];
            ToolUtils.isSafeNumber(1 == this.MatchFilterTag[2][0]) ? 0 == t ? (e.getChildByName("bg").getComponent(Sprite).spriteFrame = this.timeSelect_Imgs[1], i18nMgr.shared().changeLabelFont(e.getChildByName("wz").getComponent(Label), true)) : (this.MatchFilterTag[2][t] = 0, e.getChildByName("bg").getComponent(Sprite).spriteFrame = this.timeSelect_Imgs[0], i18nMgr.shared().changeLabelFont(e.getChildByName("wz").getComponent(Label), false)) : 1 == ToolUtils.isSafeNumber(this.MatchFilterTag[2][t]) ? (e.getChildByName("bg").getComponent(Sprite).spriteFrame = this.timeSelect_Imgs[1], i18nMgr.shared().changeLabelFont(e.getChildByName("wz").getComponent(Label), true)) : (e.getChildByName("bg").getComponent(Sprite).spriteFrame = this.timeSelect_Imgs[0], i18nMgr.shared().changeLabelFont(e.getChildByName("wz").getComponent(Label), false));
        }
        for (let e, t = 0, i = this.selectPrizeBtn.length; t < i; t++) {
            e = this.selectPrizeBtn[t];
            ToolUtils.isSafeNumber(1 == this.MatchFilterTag[3][0]) ? 0 == t ? (e.getChildByName("bg").getComponent(Sprite).spriteFrame = this.timeSelect_Imgs[1], i18nMgr.shared().changeLabelFont(e.getChildByName("wz").getComponent(Label), true)) : (this.MatchFilterTag[3][t] = 0, e.getChildByName("bg").getComponent(Sprite).spriteFrame = this.timeSelect_Imgs[0], i18nMgr.shared().changeLabelFont(e.getChildByName("wz").getComponent(Label), false)) : 1 == ToolUtils.isSafeNumber(this.MatchFilterTag[3][t]) ? (e.getChildByName("bg").getComponent(Sprite).spriteFrame = this.timeSelect_Imgs[1], i18nMgr.shared().changeLabelFont(e.getChildByName("wz").getComponent(Label), true)) : (e.getChildByName("bg").getComponent(Sprite).spriteFrame = this.timeSelect_Imgs[0], i18nMgr.shared().changeLabelFont(e.getChildByName("wz").getComponent(Label), false));
        }
    }
    showSelectView() {
        let e = this.bgNode, t = new Vec3(0, -GameConfig.REAL_SCREEN_HEIGHT / 2), i = { startPos: v3(0, -GameConfig.REAL_SCREEN_HEIGHT / 2 - 500), endPos: t };
        ToolUtils.showPushAnim(e, 2, (() => {
            e.setPosition(t);
        }), i);
    }
    hideSelectView() {
        this._startAct && TweenTool.stopAction(this._startAct);
        this._closeAct || (this._closeAct = TweenTool.moveTo(this.bgNode, 0.2, v3(0, -GameConfig.REAL_SCREEN_HEIGHT / 2 - 500), "sineIn", true, (() => {
            ToolUtils.isObjValid(this.node) && this.node.destroy();
        })));
    }
    onBackView() {
        this.hideSelectView();
    }
    onDestroy() {
        super.onDestroy();
    }
}
