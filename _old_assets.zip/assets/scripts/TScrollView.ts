// @ts-nocheck
// Recovered from index.js:647
import { _decorator, Component, BlockInputEvents, instantiate, isValid, Layout, Node, Prefab, ScrollView, tween, UIOpacity, UITransform, v2, v3, Widget } from "cc";
const { ccclass, property } = _decorator;
@ccclass("TScrollView")
export class TScrollView extends ScrollView {
    @property({ type: Node, visible() {
            return !this._itemPrefab;
        } })
    public _itemNode: Node = null;
    @property({ type: Prefab, visible() {
            return !this._itemNode;
        } })
    public _itemPrefab: Prefab = null;
    @property
    public isGrid: boolean = false;
    @property({ visible() {
            return this.isGrid || this.horizontal;
        } })
    public spacingX: number = 0;
    @property({ visible() {
            return this.isGrid || this.vertical;
        } })
    public spacingY: number = 0;
    @property({ visible() {
            return this.vertical;
        } })
    public paddingTop: number = 0;
    @property({ visible() {
            return this.vertical;
        } })
    public paddingDown: number = 0;
    @property({ visible() {
            return this.horizontal;
        } })
    public paddingLeft: number = 0;
    @property({ visible() {
            return this.horizontal;
        } })
    public paddingRight: number = 0;
    @property
    public framesTime: number = 0;
    @property
    public isPlayAnim: boolean = false;
    public mdata: any[] = [];
    public mRefreshCallback: any = null;
    public mEventSWcallback: any = null;
    public mnodesize: any = null;
    public mHuaIdx: number = 0;
    public mIdexArr: any[] = [];
    public mItemNodeList: any[] = [];
    public mcurrOffsetDistanceDataIdx: number = 0;
    public mcreateNum: number = 0;
    public maxNodeNum: number = 0;
    public mIsSetdata: boolean = true;
    public initialoffset: number = 0;
    public mItemNode: any = null;
    public gridAuxiliaryNum: number = 1;
    public joinWidth: number = 0;
    public joinHeight: number = 0;
    public recordiSorizontal: boolean = false;
    public recordiSvertical: boolean = false;
    public currDataIsscroll: boolean = false;
    public enablecount: number = 2;
    public mzhezhao: any = null;
    public mMaxDeviation: number = 5000;
    public tweenArr: any[] = [];
    onLoad() {
        this.recordiSorizontal = this.horizontal;
        this.recordiSvertical = this.vertical;
        this._itemNode ? this.mItemNode = this._itemNode : this.mItemNode = instantiate(this._itemPrefab);
        this.mItemNode.active = false;
        this.joinWidth = this.spacingX + this.mItemNode.getComponent(UITransform).width;
        this.joinHeight = this.spacingY + this.mItemNode.getComponent(UITransform).height;
        this.mnodesize = this.mItemNode.getComponent(UITransform).contentSize;
        const t = new Component.EventHandler;
        if (t.target = this.node, t.component = "TScrollView", t.handler = "onEventSw", this.scrollEvents.push(t), this._calculateCurrPageMaxNode(), this.isGrid && (this.brake = 0.9), this.paddingTop = 0, this.paddingDown = 0, this.paddingLeft = 0, this.paddingRight = 0, this.isPlayAnim && !this.mItemNode.getComponent(UIOpacity)) {
            (new UIOpacity).opacity = 255;
            this.mItemNode.addComponent(UIOpacity);
        }
        this.content.getComponent(Widget) && (this.content.getComponent(Widget).enabled = false);
        this.content.getComponent(Layout) && (this.content.getComponent(Layout).enabled = false);
        this.mzhezhao = new Node;
        this.mzhezhao.active = false;
        this.mzhezhao.addComponent(UITransform);
        this.mzhezhao.getComponent(UITransform).setContentSize(this.node.getComponent(UITransform).contentSize);
        this.mzhezhao.addComponent(BlockInputEvents);
        this.node.addChild(this.mzhezhao);
        this.schedule((() => {
        }));
    }
    onDestroy() {
    }
    onDisable() {
        super.onDisable();
        this.removeTween();
    }
    onEnable() {
        super.onEnable();
        this.isPlayAnim;
    }
    setData(t, i, e, s = 0) {
        if (this.stopAutoScroll(), this.vertical = this.recordiSvertical, this.horizontal = this.recordiSorizontal, this.mdata.length == t.length) {
            return this.mItemNodeList.forEach(((i, e) => {
                let s = i._dataIdx;
                s >= 0 && s < t.length && this.setNodeData(i, t[s], s);
            })), this.mdata = [].concat(t), this.recordiSvertical && (this.vertical = this.currDataIsscroll), void (this.recordiSorizontal && (this.horizontal = this.currDataIsscroll));
        }
        this.initialoffset = s;
        this.mcurrOffsetDistanceDataIdx = s;
        this.mdata = [].concat(t);
        this.mRefreshCallback = i;
        e && (this.mEventSWcallback = e);
        this.mdata.length >= this.maxNodeNum * this.gridAuxiliaryNum ? this.mcreateNum = this.maxNodeNum * this.gridAuxiliaryNum : this.gridAuxiliaryNum > 1 ? this.mcreateNum = this.mdata.length + (this.gridAuxiliaryNum - this.mdata.length % this.gridAuxiliaryNum) + this.gridAuxiliaryNum : this.mcreateNum = this.mdata.length + 1;
        this.mIsSetdata = 0 == s;
        this._setListContentSize(t.length);
        this._createItem((() => {
            if (this.recordiSvertical) {
                this.paddingTop + this.paddingDown + Math.ceil(this.mdata.length / this.gridAuxiliaryNum) * this.mnodesize.height + (this.mdata.length - 1) * this.spacingY > this.node.getComponent(UITransform).height ? (this.vertical = true, this.currDataIsscroll = true) : (this.vertical = false, this.currDataIsscroll = false);
            }
            else {
                this.paddingLeft + this.paddingRight + Math.ceil(this.mdata.length / this.gridAuxiliaryNum) * this.mnodesize.width + (this.mdata.length - 1) * this.spacingX > this.node.getComponent(UITransform).width ? (this.horizontal = true, this.currDataIsscroll = true) : (this.horizontal = false, this.currDataIsscroll = false);
            }
            this.enabled = true;
        }));
    }
    addData(t) {
        this.mdata = this.mdata.concat(t);
        this.recordiSvertical ? this._setNodeContentSize(this.content, this.content.getComponent(UITransform).width, this.mdata.length * this.joinHeight) : this._setNodeContentSize(this.content, this.mdata.length * this.joinWidth, this.content.getComponent(UITransform).height);
        this.mdata.length >= this.maxNodeNum || (this.mdata.length >= this.maxNodeNum * this.gridAuxiliaryNum ? this.mcreateNum = this.maxNodeNum * this.gridAuxiliaryNum : this.mcreateNum = this.mdata.length + (this.gridAuxiliaryNum - this.mdata.length % this.gridAuxiliaryNum) + this.gridAuxiliaryNum, this.mIsSetdata = false, this._createItem());
    }
    _setListContentSize(t) {
        if (this.recordiSvertical) {
            let i = 0;
            if (i = this.isGrid ? this.node.getComponent(UITransform).width : this.content.getComponent(UITransform).width, !t) {
                return this.content.removeAllChildren(), void this._setNodeContentSize(this.content, i, 0);
            }
            {
                const t = Math.ceil(this.mdata.length / this.gridAuxiliaryNum);
                this._setNodeContentSize(this.content, i, t * this.joinHeight);
            }
            let e = this.initialoffset * this.joinHeight + this.paddingTop;
            this.getMaxScrollOffset().y < e && (e = this.getMaxScrollOffset().y);
            this.scrollToOffset(v2(0, e));
        }
        else if (this.recordiSorizontal) {
            let i = 0;
            if (i = this.isGrid ? this.node.getComponent(UITransform).height : this.content.getComponent(UITransform).height, !t) {
                return this.content.removeAllChildren(), void this._setNodeContentSize(this.content, 0, i);
            }
            {
                const t = Math.ceil(this.mdata.length / this.gridAuxiliaryNum);
                this._setNodeContentSize(this.content, t * this.joinWidth, i);
            }
            let e = this.initialoffset * this.joinWidth + this.paddingLeft;
            this.getMaxScrollOffset().x < e && (e = this.getMaxScrollOffset().x);
            this.scrollToOffset(v2(e, 0));
        }
    }
    _createItem(t) {
        if (this.mcreateNum < this.mItemNodeList.length) {
            for (let t = 0; t < this.mItemNodeList.length - this.mcreateNum; t++) {
                this.mItemNodeList[this.mItemNodeList.length - 1 - t].active = false;
            }
        }
        if (this.mIsSetdata && (this.scrollToOffset(v2(0, 0)), this.mIdexArr = [], this.mHuaIdx = 0), this.content.removeAllChildren(), this.mIdexArr = [], this.recordiSvertical) {
            let t = Math.ceil((this.node.getComponent(UITransform).height - this.paddingDown - this.paddingTop) / this.joinHeight);
            this.initialoffset > (this.mdata.length - t) * this.gridAuxiliaryNum && (this.initialoffset = (this.mdata.length - t) * this.gridAuxiliaryNum, this.mcurrOffsetDistanceDataIdx = this.initialoffset);
        }
        else {
            let t = Math.ceil((this.node.getComponent(UITransform).width - this.paddingLeft - this.paddingRight) / this.joinWidth);
            this.initialoffset > (this.mdata.length - t) * this.gridAuxiliaryNum && (this.initialoffset = (this.mdata.length - t) * this.gridAuxiliaryNum, this.mcurrOffsetDistanceDataIdx = this.initialoffset);
        }
        this.mHuaIdx = this.initialoffset;
        let i = this;
        i.isPlayAnim && (i.vertical = false, i.horizontal = false);
        let e = (t, e) => {
            isValid(t) && (i.framesTime > 0 ? i.scheduleOnce((() => {
                0 != e && (i.isGrid ? i.gridAuxiliaryNum <= e && e < i.mdata.length + i.gridAuxiliaryNum ? t.active = true : t.active = false : t.active = true);
            }), i.framesTime / 1000 * e) : 0 != e && (i.isGrid ? i.gridAuxiliaryNum <= e && e < i.mdata.length + i.gridAuxiliaryNum ? t.active = true : t.active = false : t.active = true));
        };
        this.enabled = false;
        for (let s = 0; s < i.mcreateNum; s++) {
            let h = i.mItemNodeList[s];
            if (h || (h = instantiate(i.mItemNode), i.mItemNodeList.push(h)), h._dataIdx = -1, e(h, s), i.content.addChild(h), i.initialoffset > 0) {
                let e = i.initialoffset + s - 1;
                i.recordiSvertical ? this.isPlayAnim ? (h.mrealpos = v3(e % i.gridAuxiliaryNum * i.joinWidth, -Math.floor(e / i.gridAuxiliaryNum) * i.joinHeight), i.playNodeAnim(h, e - (i.initialoffset - 1), (e => {
                    i.mcreateNum - 1 == e && t && t();
                }))) : i._setNodePosition(h, e % i.gridAuxiliaryNum * i.joinWidth, -Math.floor(e / i.gridAuxiliaryNum) * i.joinHeight) : i.recordiSorizontal && (this.isPlayAnim ? (h.mrealpos = v3(Math.floor(e / i.gridAuxiliaryNum) * i.joinWidth, e % i.gridAuxiliaryNum * i.joinHeight), i.playNodeAnim(h, e - (i.initialoffset - 1), (e => {
                    i.mcreateNum - 1 == e && t && t();
                }))) : i._setNodePosition(h, Math.floor(e / i.gridAuxiliaryNum) * i.joinWidth, e % i.gridAuxiliaryNum * i.joinHeight));
                const o = i.mdata[e];
                (o || 0 == o) && (h._dataIdx = Math.abs(e), i.setNodeData(h, o, e));
            }
            else if (0 == Math.floor(s / i.gridAuxiliaryNum)) {
                h.active = false;
                i.recordiSvertical ? i.gridAuxiliaryNum > 1 ? i._setNodePosition(h, s % i.gridAuxiliaryNum * i.joinWidth, i.joinHeight) : i._setNodePosition(h, 0, i.joinHeight) : i.recordiSorizontal && (i.gridAuxiliaryNum > 1 ? i._setNodePosition(h, -i.spacingX - i.mnodesize.width, -s % i.gridAuxiliaryNum * i.joinHeight) : i._setNodePosition(h, -i.spacingX - i.mnodesize.width, 0));
            }
            else {
                i.recordiSvertical ? this.isPlayAnim ? (h.mrealpos = v3(s % i.gridAuxiliaryNum * i.joinWidth, -Math.floor((s - i.gridAuxiliaryNum) / i.gridAuxiliaryNum) * i.joinHeight), i.playNodeAnim(h, s - 1, (e => {
                    i.mcreateNum - 2 == e && t && t();
                }))) : i._setNodePosition(h, s % i.gridAuxiliaryNum * i.joinWidth, -Math.floor((s - i.gridAuxiliaryNum) / i.gridAuxiliaryNum) * i.joinHeight) : i.recordiSorizontal && (this.isPlayAnim ? (h.mrealpos = v3(Math.floor((s - i.gridAuxiliaryNum) / i.gridAuxiliaryNum) * i.joinWidth, -(s - i.gridAuxiliaryNum) % i.gridAuxiliaryNum * i.joinHeight), i.playNodeAnim(h, s - 1, (e => {
                    i.mcreateNum - 2 == e && t && t();
                }))) : i._setNodePosition(h, Math.floor((s - i.gridAuxiliaryNum) / i.gridAuxiliaryNum) * i.joinWidth, -(s - i.gridAuxiliaryNum) % i.gridAuxiliaryNum * i.joinHeight));
                const e = i.mdata[s - i.gridAuxiliaryNum];
                (e || 0 == e) && (h._dataIdx = Math.abs(s - i.gridAuxiliaryNum), i.setNodeData(h, e, s - i.gridAuxiliaryNum));
            }
            i.mIdexArr.push(s);
        }
        i.isPlayAnim || t && t();
    }
    onEventSw() {
        if (!(this.getScrollOffset().y > this.getMaxScrollOffset().y || this.getScrollOffset().y < 0) && (this.vertical || !this.recordiSvertical) && (this.horizontal || !this.recordiSorizontal) && (this.recordiSvertical || this.recordiSorizontal) && this.mItemNodeList.length && !this._isObstruct()) {
            this._scrollUpdateView();
            {
                let t = this.getScrollOffset(), i = 0;
                i = this.recordiSvertical ? Math.floor((t.y - this.paddingTop) / this.joinHeight) : Math.floor((-t.x - this.paddingLeft) / this.joinWidth);
                this.mcurrOffsetDistanceDataIdx = i;
            }
            this.mEventSWcallback && this.mEventSWcallback(this.mcurrOffsetDistanceDataIdx);
        }
    }
    _slide_Top(t) {
        const i = Math.ceil((t.y - this.paddingTop - this.mnodesize.height) / this.joinHeight) - this.mHuaIdx;
        for (let t = 0; t < i; t++) {
            this.mHuaIdx += 1;
            const t = this.mIdexArr.length - 1, i = this.mItemNodeList[this.mIdexArr[t]].position.y, e = this.mItemNodeList[this.mIdexArr[t]]._dataIdx + 1;
            for (let t = 0; t < this.gridAuxiliaryNum; t++) {
                const s = this.mItemNodeList[this.mIdexArr[0]];
                this._setNodePosition(s, s.getPosition().x, i - this.joinHeight, false);
                let h = e + t, o = null;
                h < this.mdata.length && (o = this.mdata[h]);
                o || 0 == o ? (s.active = true, s._dataIdx = h, this.setNodeData(s, o, h)) : (s._dataIdx = -1, s.active = false);
                this._updateItemIdx(true);
            }
        }
    }
    _slide_Down(t) {
        const i = this.mHuaIdx - Math.floor((t.y - this.paddingTop) / this.joinHeight);
        for (let t = 0; t < i; t++) {
            this.mHuaIdx -= 1;
            const t = this.mIdexArr.length - 1, i = this.mItemNodeList[this.mIdexArr[0]].position.y, e = this.mItemNodeList[this.mIdexArr[0]]._dataIdx - 1;
            for (let s = 0; s < this.gridAuxiliaryNum; s++) {
                const h = this.mItemNodeList[this.mIdexArr[t]];
                this._setNodePosition(h, h.getPosition().x, i + this.joinHeight, false);
                let o = e - s;
                const a = this.mdata[o];
                a || 0 == a ? (h.active = true, h._dataIdx = o, this.setNodeData(h, a, o)) : (h._dataIdx = -1, h.active = false);
                this._updateItemIdx();
            }
        }
    }
    _slide_Left(t) {
        const i = Math.ceil(-(t.x + this.paddingLeft + this.mnodesize.width) / this.joinWidth) - this.mHuaIdx;
        for (let t = 0; t < i; t++) {
            this.mHuaIdx += 1;
            const t = this.mIdexArr.length - 1, i = this.mItemNodeList[this.mIdexArr[t]].position.x, e = this.mItemNodeList[this.mIdexArr[t]]._dataIdx + 1;
            for (let t = 0; t < this.gridAuxiliaryNum; t++) {
                const s = this.mItemNodeList[this.mIdexArr[0]];
                this._setNodePosition(s, i + this.joinWidth, s.getPosition().y, false);
                let h = e + t;
                const o = this.mdata[h];
                o || 0 == o ? (s.active = true, s._dataIdx = h, this.setNodeData(s, o, h)) : (s.active = false, s._dataIdx = -1);
                this._updateItemIdx(true);
            }
        }
    }
    _slide_Right(t) {
        const i = this.mHuaIdx - Math.floor(-(t.x - this.paddingLeft) / this.joinWidth);
        for (let t = 0; t < i; t++) {
            this.mHuaIdx -= 1;
            const t = this.mIdexArr.length - 1, i = this.mItemNodeList[this.mIdexArr[0]].position.x, e = this.mItemNodeList[this.mIdexArr[0]]._dataIdx - 1;
            for (let s = 0; s < this.gridAuxiliaryNum; s++) {
                const h = this.mItemNodeList[this.mIdexArr[t]];
                this._setNodePosition(h, i - this.joinWidth, h.getPosition().y, false);
                let o = e - s;
                const a = this.mdata[o];
                a || 0 == a ? (h.active = true, h._dataIdx = o, this.setNodeData(h, a, o)) : (h.active = false, h._dataIdx = -1);
                this._updateItemIdx();
            }
        }
    }
    _updateItemIdx(t = false) {
        this.mIdexArr.forEach(((i, e) => {
            t ? i += 1 : i -= 1;
            -1 == i && (i = this.mIdexArr.length - 1);
            i == this.mIdexArr.length && (i = 0);
            this.mIdexArr[e] = i;
        }));
    }
    _scrollUpdateView() {
        const t = this.getScrollOffset();
        if (this.recordiSvertical) {
            t.y >= this.mHuaIdx * this.joinHeight + this.paddingTop ? this._slide_Top(t) : t.y <= (this.mHuaIdx - 1) * this.joinHeight + this.paddingTop && this._slide_Down(t);
        }
        else {
            const i = Math.abs(t.x);
            i >= this.mHuaIdx * this.joinWidth + this.paddingLeft ? this._slide_Left(t) : i <= this.mHuaIdx * this.joinWidth + this.paddingLeft && this._slide_Right(t);
        }
        this._updateNodeIsShow();
    }
    _isObstruct() {
        if (this.getScrollOffset().y > this.getMaxScrollOffset().y || this.getScrollOffset().y < 0) {
            return;
        }
        if (0 == this.mdata.length) {
            if (!this.recordiSvertical) {
                return true;
            }
            if (!this.recordiSorizontal) {
                return true;
            }
        }
        this._updateNodeIsShow();
        const t = this.getScrollOffset();
        if (this.recordiSorizontal) {
            if (t.x >= -this.paddingLeft) {
                return true;
            }
            if (Math.abs(t.x) >= this.getMaxScrollOffset().x - this.paddingLeft) {
                return true;
            }
        }
        else {
            if (t.y <= this.paddingTop) {
                return true;
            }
            if (t.y >= this.getMaxScrollOffset().y - this.paddingTop) {
                return true;
            }
        }
        return false;
    }
    _updateNodeIsShow() {
        const t = Math.ceil(this.mdata.length / this.gridAuxiliaryNum);
        this.mItemNodeList.forEach((i => {
            if (this.recordiSvertical) {
                const e = (t - 1) * this.spacingY + t * this.mnodesize.height + this.paddingTop;
                -i.getPosition().y < this.paddingTop || i.getPosition().y <= -e || -1 == i._dataIdx ? i.active = false : i.active = true;
            }
            else if (this.recordiSorizontal) {
                const e = (t - 1) * this.spacingX + t * this.mnodesize.width + this.paddingLeft;
                i.getPosition().x < this.paddingLeft || i.getPosition().x > e || -1 == i._dataIdx ? i.active = false : i.active = true;
            }
        }));
    }
    _calculateCurrPageMaxNode() {
        if (this.recordiSvertical) {
            if (this.maxNodeNum = Math.ceil(this.node.getComponent(UITransform).height / this.joinHeight) + 2, this.isGrid) {
                let t = this.node.getComponent(UITransform).width - this.paddingLeft - this.paddingRight, i = Math.floor((t - this.mnodesize.width) / this.joinWidth);
                this.gridAuxiliaryNum = i + 1;
            }
        }
        else if (this.recordiSorizontal && (this.maxNodeNum = Math.ceil(this.node.getComponent(UITransform).width / this.joinWidth) + 2, this.isGrid)) {
            let t = this.node.getComponent(UITransform).height - this.paddingTop - this.paddingDown, i = Math.floor((t - this.mnodesize.height) / this.joinHeight);
            this.gridAuxiliaryNum = i + 1;
        }
    }
    setNodeData(t, i, e) {
        let s = this;
        (async () => {
            isValid(t) && s.mRefreshCallback(t, i, e);
        })();
    }
    _setNodePosition(t, i, e, s = true) {
        this.recordiSvertical && s ? e -= this.paddingTop : this.recordiSorizontal && s && (i += this.paddingLeft);
        t.mrealpos = v3(i, e);
        t.setPosition(v3(i, e));
    }
    _setNodeContentSize(t, i, e) {
        i += this.paddingLeft + this.paddingRight;
        e += this.paddingDown + this.paddingTop;
        t.getComponent(UITransform).setContentSize(i, e);
    }
    playNodeAnim(t, i, e) {
        const s = t.getComponent(UIOpacity);
        if (!s) {
            return;
        }
        s.opacity = 0;
        s.opacity;
        let h = t.mrealpos;
        if (this.recordiSvertical) {
            let o = 3 * this.joinHeight, a = v3(h.x, h.y - o);
            t.setPosition(a);
            let r = tween(t).delay(0.05 * i).sequence(tween(t).to(0.0005 * o, { position: v3(h.x, h.y + this.joinHeight / 7) }, { easing: "sineOut" }), tween(t).to(0.2, { position: h }, { easing: "sineOut" })).call((() => {
                e && e(i);
                this.removeTween(r);
            })).start(), n = tween(s).delay(0.05 * i).to(0.0005 * o, { opacity: 255 }, { easing: "sineOut" }).call((() => {
                this.removeTween(n);
            })).start();
            this.tweenArr.push(r);
            this.tweenArr.push(n);
        }
        else {
            let o = 3 * this.joinWidth, a = v3(h.x + o, h.y);
            t.setPosition(a);
            let r = tween(t).delay(0.05 * i).sequence(tween(t).parallel(tween(t).to(0.0005 * o, { position: v3(h.x - this.joinWidth / 7, h.y) }, { easing: "quadInOut" })), tween(t).to(0.2, { position: h }, { easing: "sineOut" })).call((() => {
                e && e(i);
                this.removeTween(r);
            })).start(), n = tween(s).delay(0.05 * i).to(0.0005 * o, { opacity: 255 }, { easing: "quadInOut" }).call((() => {
                this.removeTween(n);
            })).start();
            this.tweenArr.push(r);
            this.tweenArr.push(n);
        }
    }
    removeTween(t) {
        if (t) {
            let i = this.tweenArr.indexOf(t);
            -1 != i && this.tweenArr.splice(i, i + 1);
            t.stop();
            t.removeSelf();
        }
        else {
            this.tweenArr.forEach((t => {
                t.stop();
                t.removeSelf();
            }));
            this.tweenArr = [];
        }
    }
}
