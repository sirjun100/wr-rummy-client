// @ts-nocheck
// Recovered from index.js:453
import { _decorator, Component, Label, Node, RichText, sys } from "cc";
import i18nMgr from "./i18nMgr";
import TweenTool from "./TweenTool";
import User from "./User";
import SoundManager from "./SoundManager";
import RummyDataManager from "./RummyDataManager";
import RummyCmd from "./RummyCmd";
import Server from "./Server";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("RummyGamePoolRejoin")
export class RummyGamePoolRejoin extends Component {
    @property(RichText)
    public contentlabel: RichText = null;
    @property(Label)
    public leftTimelabel: Label = null;
    @property(Node)
    public root: Node = null;
    public time_action: any = null;
    public money: number = 0;
    public reload: number = 0;
    public leftTime: number = 0;
    public lastClick: number = 0;
    public tid_key: string = "";
    setParaData(e, t, i, n) {
        this.money = e;
        this.reload = t;
        this.leftTime = i;
        this.tid_key = n;
    }
    start() {
        this.initView();
        ToolUtils.showFullScreen(this.node.getChildByName("bg"));
        ToolUtils.startShowAnim(this.node.getChildByName("rootNode"));
        let e = this.root.getChildByName("sure").getChildByName("layout"), t = e.getChildByName("layout1"), i = t.getChildByName("wz_money"), n = e.getChildByName("wz"), o = t.getChildByName("icon");
        n.getComponent(Label).updateRenderData(true);
        1 == RummyDataManager.shared().rummyInfos.get(this.tid_key).crashModel ? (o.active = true, i.getComponent(Label).string = ToolUtils.parse_ChipNum2(String(this.money))) : (i.getComponent(Label).string = "₹" + this.money, o.active = false);
        i.getComponent(Label).updateRenderData(true);
    }
    initView() {
        let e = ToolUtils.format(i18nMgr.shared().getValueByKey("gameRummy_pool_rejoin.tips2"), this.money, this.reload);
        this.contentlabel.string = e;
        i18nMgr.shared().changeLabelFont(this.contentlabel);
        this.leftTime > 0 ? (this.leftTimelabel.string = ToolUtils.format(i18nMgr.shared().getValueByKey("gameRummy_pool_rejoin.Remaining"), this.leftTime), i18nMgr.shared().changeLabelFont(this.leftTimelabel), this.leftTimelabel.node.active = true) : this.leftTimelabel.node.active = false;
        this.time_action = TweenTool.myschedule(RummyDataManager.shared().sceneNode, 1, this.updateTime.bind(this));
    }
    updateTime() {
        ToolUtils.isObjValid(this.node) && (this.leftTime = this.leftTime - 1, this.leftTime > 0 ? (this.leftTimelabel.string = ToolUtils.format(i18nMgr.shared().getValueByKey("gameRummy_pool_rejoin.Remaining"), this.leftTime), i18nMgr.shared().changeLabelFont(this.leftTimelabel)) : ToolUtils.isObjValid(this.node) && (this.sendRejoinResult(2), this.node.destroy()));
    }
    onButtonClick(e, t) {
        if (SoundManager.shared().playFx("click"), "rejoin" == t) {
            if (sys.now() - this.lastClick < 1000) {
                return;
            }
            this.lastClick = sys.now();
            this.sendRejoinResult(1);
            0 == RummyDataManager.shared().rummyInfos.get(this.tid_key).crashModel && User.shared().data.money < RummyDataManager.shared().rummyInfos.get(this.tid_key).entry_fee || ToolUtils.isObjValid(this.node) && this.node.destroy();
        }
        else {
            "cancel" == t && (this.sendRejoinResult(2), ToolUtils.isObjValid(this.node) && this.node.destroy());
        }
    }
    sendRejoinResult(e) {
        let t = { cmd: RummyCmd.GM_REJOIN_REQUEST, uid: User.shared().data.uid, tid_key: this.tid_key, status: e };
        Server.shared().send(t);
    }
    stopAction() {
        this.time_action && (TweenTool.stopAction(this.time_action), this.time_action = null);
    }
    onDestroy() {
        this.stopAction();
    }
}
