// @ts-nocheck
// Recovered from index.js:393
import { _decorator, Button, color, instantiate, Label, LabelShadow, Node, ScrollView, sp, Sprite, SpriteFrame, sys, v3, Widget } from "cc";
import Parent from "./Parent";
import PushCenter from "./PushCenter";
import SoundManager from "./SoundManager";
import Utils from "./Utils";
import { ToolUtils } from "./ToolUtils";
import { RocketGameManager } from "./RocketGameManager";
import CommDefine from "./CommDefine";
import TweenTool from "./TweenTool";
import { AdapDirection } from "./BaseLayer";
const { ccclass, property } = _decorator;
@ccclass("RocketGameAction")
export default class RocketGameAction extends Parent {
    public _TAG: string = "RocketGameAction";
    public lastClick: number = 0;
    @property([Node])
    public operateRootNode: Node[] = [];
    @property(Node)
    public coinNumLabel: Node = null;
    @property([Node])
    public curBetNumLabels: Node[] = [];
    @property(Node)
    public selectBetViewNode: Node = null;
    @property([SpriteFrame])
    public btnImgs: SpriteFrame[] = [];
    @property([SpriteFrame])
    public addImgs: SpriteFrame[] = [];
    @property([SpriteFrame])
    public reduceImgs: SpriteFrame[] = [];
    @property([SpriteFrame])
    public autoSwitchImgs: SpriteFrame[] = [];
    @property([SpriteFrame])
    public smallBeilvImgs: SpriteFrame[] = [];
    @property(Node)
    public trendMoban: Node = null;
    public gameCallback: any = null;
    onLoad() {
        this.node.getComponent(Widget).enabled = true;
        this.node.getComponent(Widget).updateAlignment();
        this.adapptationScreen();
    }
    onDestroy() {
        super.onDestroy();
        this.unscheduleAllCallbacks();
        PushCenter.shared().removeListenersByTag(this);
    }
    start() {
        this.initView();
        this.addPushNotify();
    }
    setCallBack(e) {
        this.gameCallback = e;
    }
    addPushNotify() {
    }
    adapptationScreen() {
        let e = this.node.getChildByName("top_node").getChildByName("btn_close"), t = this.node.getChildByName("top_node").getChildByName("add_coin"), i = this.node.getChildByName("top_node").getChildByName("coin_bg"), o = this.node.getChildByName("top_node").getChildByName("act_node");
        this.resetUiPos(e, AdapDirection.Left, true, 1, true);
        this.resetUiPos(i, AdapDirection.Left, true, 1, true);
        this.resetUiPos(t, AdapDirection.Right, true, 1, true, true);
        this.resetUiPos(o, AdapDirection.Right, true, 1, true, true);
    }
    updateGullakBtnStatus(e, t, i) {
        let o = this.node.getChildByName("top_node").getChildByName("act_node").getChildByName("gullak_btn");
        if (ToolUtils.isObjValid(o) && (o.active = 1 == e, 1 == e)) {
            let e = o.getChildByName("anim").getComponent(sp.Skeleton);
            e.clearTracks();
            e.setToSetupPose();
            i ? (e.setAnimation(0, "2", false), e.setCompleteListener((() => {
                e.setCompleteListener(null);
                e.clearTracks();
                e.setToSetupPose();
                0 == t ? e.setAnimation(0, "0", true) : e.setAnimation(0, "1", true);
            }))) : 0 == t ? e.setAnimation(0, "0", true) : e.setAnimation(0, "1", true);
        }
    }
    initView() {
        this.updateAutoPlaySwitchStatus(0, 0);
        this.updateAutoPlaySwitchStatus(1, 0);
    }
    isSelectBetViewVisible() {
        return this.selectBetViewNode.active;
    }
    updateSelectBetVisbile(e, t) {
        e ? (this.selectBetViewNode.active = e, 0 == t ? (this.selectBetViewNode.setPosition(v3(-217.42, -116.924)), this.selectBetViewNode.getChildByName("arrow").setPosition(v3(-4, -85))) : (this.selectBetViewNode.setPosition(v3(310.656, -116.924)), this.selectBetViewNode.getChildByName("arrow").setPosition(v3(38.153, -85)))) : this.selectBetViewNode.active = e;
    }
    updateButtonState(e, t, i) {
        if (this.operateRootNode[t].getChildByName("cashout_btn").active = e == RocketGameManager.eXiaZhuStatus.Checkout, this.operateRootNode[t].getChildByName("autobet_btn").active = e == RocketGameManager.eXiaZhuStatus.Stop_AutoPlay, this.operateRootNode[t].getChildByName("cancel_btn").active = e == RocketGameManager.eXiaZhuStatus.Cancel, this.operateRootNode[t].getChildByName("bet_btn").active = e == RocketGameManager.eXiaZhuStatus.Bet, this.operateRootNode[t].getChildByName("bet_btn").active) {
            let e = this.operateRootNode[t].getChildByName("bet_btn");
            e.getChildByName("wz").getComponent(Label).string = "BET";
            e.getChildByName("ico").getComponent(Sprite).spriteFrame = this.btnImgs[0];
            e.getChildByName("wz").getComponent(LabelShadow).color = CommDefine.shadowcolor.green;
            Utils.updateLabelMaterial(e.getChildByName("wz"), CommDefine.gradient.btn_green);
        }
        if (e == RocketGameManager.eXiaZhuStatus.Starting_Bet || e == RocketGameManager.eXiaZhuStatus.Starting_UnBet) {
            this.operateRootNode[t].getChildByName("bet_btn").active = true;
            this.operateRootNode[t].getChildByName("bet_btn").getComponent(Button).interactable = false;
            let i = this.operateRootNode[t].getChildByName("bet_btn");
            i.getChildByName("wz").getComponent(Label).string = "STARTING";
            e == RocketGameManager.eXiaZhuStatus.Starting_Bet ? (i.getChildByName("ico").getComponent(Sprite).spriteFrame = this.btnImgs[1], i.getChildByName("wz").getComponent(LabelShadow).color = CommDefine.shadowcolor.blue, Utils.updateLabelMaterial(i.getChildByName("wz"), CommDefine.gradient.btn_blue)) : (i.getChildByName("ico").getComponent(Sprite).spriteFrame = this.btnImgs[0], i.getChildByName("wz").getComponent(LabelShadow).color = CommDefine.shadowcolor.green, Utils.updateLabelMaterial(i.getChildByName("wz"), CommDefine.gradient.btn_green));
        }
        if (e == RocketGameManager.eXiaZhuStatus.Checkout || e == RocketGameManager.eXiaZhuStatus.Stop_AutoPlay) {
            let o = null;
            if (sys.isObjectValid(i)) {
                if (Array.isArray(i) && 2 == i.length) {
                    let e = i[t];
                    sys.isObjectValid(e) && (sys.isObjectValid(e.win) || sys.isObjectValid(e.round)) && (o = e);
                }
                else {
                    (sys.isObjectValid(i.win) || sys.isObjectValid(i.round)) && (o = i);
                }
                sys.isObjectValid(o) && (e == RocketGameManager.eXiaZhuStatus.Checkout && sys.isObjectValid(o.win) ? this.operateRootNode[t].getChildByName("cashout_btn").getChildByName("num").getComponent(Label).string = ToolUtils.parse_double(o.win) : e == RocketGameManager.eXiaZhuStatus.Stop_AutoPlay && sys.isObjectValid(o.round) && (this.operateRootNode[t].getChildByName("autobet_btn").getChildByName("num").getComponent(Label).string = o.round));
            }
        }
    }
    updateGoldoutNum(e, t) {
        this.operateRootNode[t].getChildByName("cashout_btn").getChildByName("num").getComponent(Label).string = ToolUtils.parse_ChipNum2(e);
    }
    updateAutoPlaySwitchStatus(e, t, i = 0) {
        this.operateRootNode[e].getChildByName("auto_btn").getChildByName("ico").getComponent(Sprite).spriteFrame = this.autoSwitchImgs[t];
        let o = this.operateRootNode[e].getChildByName("auto_btn").getChildByName("wz");
        0 == t ? (o.getComponent(Label).color = color(155, 74, 74), o.setPosition(v3(-17.953, 1.155)), o.getComponent(Label).string = "Auto", this.operateRootNode[e].getChildByName("fix_auto_btn").active = false) : (o.getComponent(Label).color = color(255, 255, 255), o.setPosition(v3(17.848, 1.155)), o.getComponent(Label).string = String(i.toFixed(2)) + "X", this.operateRootNode[e].getChildByName("fix_auto_btn").active = true);
    }
    updateSelectBetView() {
        let e = RocketGameManager.shared().bet_configVec.length;
        e > 8 && (e = 8);
        this.selectBetViewNode.getChildByName("root").removeAllChildren();
        for (let t = 0; t < e; t++) {
            let e = instantiate(this.selectBetViewNode.getChildByName("bet_moban"));
            e.active = true;
            e.getComponent(Button).clickEvents[0].customEventData = "selectbet_" + t;
            e.getChildByName("wz").getComponent(Label).string = ToolUtils.parse_ChipNum2(RocketGameManager.shared().bet_configVec[t]);
            this.selectBetViewNode.getChildByName("root").addChild(e);
        }
    }
    updateCurBetNum(e, t) {
        this.curBetNumLabels[t].getComponent(Label).string = ToolUtils.parse_ChipNum2(e);
    }
    updateAddBetBtnStatus(e, t) {
        this.operateRootNode[t].getChildByName("add_btn").getChildByName("ico").getComponent(Sprite).spriteFrame = e ? this.addImgs[1] : this.addImgs[0];
    }
    updateReduceBetBtnStatus(e, t) {
        this.operateRootNode[t].getChildByName("reduce_btn").getChildByName("ico").getComponent(Sprite).spriteFrame = e ? this.reduceImgs[1] : this.reduceImgs[0];
    }
    updateCoin(e) {
        this.coinNumLabel.getComponent(Label).string = ToolUtils.parse_double(e);
    }
    touchBtnEvent(e, t) {
        SoundManager.shared().playFx("click");
        sys.now() - this.lastClick < 200 || (this.lastClick = sys.now(), sys.isObjectValid(this.gameCallback) && this.gameCallback(t));
    }
    changeWinNodeVisible(e, t, i) {
        let o = this.node.getChildByName("win_node");
        if (e) {
            let e = 0;
            o.active && (e = 0);
            o.active = true;
            TweenTool.delayAct(o, (() => {
                o.getChildByName("bl").getComponent(Label).string = t;
                o.getChildByName("win_money").getComponent(Label).string = ToolUtils.parse_double(i);
            }), e, true);
        }
        else {
            o.active = false;
        }
    }
    clearCheckOutTrend(e) {
        this.operateRootNode[e].getChildByName("trend_list").getComponent(ScrollView).content.removeAllChildren();
    }
    addCheckOutTrend(e, t, i) {
        let o = instantiate(this.trendMoban);
        o.active = true;
        let a = o.getChildByName("wz");
        i == RocketGameManager.eCrashTrendColor.emGreen ? (a.getComponent(Label).color = RocketGameManager.eCrashColorValue.green, o.getComponent(Sprite).spriteFrame = this.smallBeilvImgs[0]) : i == RocketGameManager.eCrashTrendColor.emBlue ? (a.getComponent(Label).color = RocketGameManager.eCrashColorValue.blue, o.getComponent(Sprite).spriteFrame = this.smallBeilvImgs[1]) : i == RocketGameManager.eCrashTrendColor.emPurple ? (a.getComponent(Label).color = RocketGameManager.eCrashColorValue.purple, o.getComponent(Sprite).spriteFrame = this.smallBeilvImgs[2]) : i == RocketGameManager.eCrashTrendColor.emOrange && (a.getComponent(Label).color = RocketGameManager.eCrashColorValue.orange, o.getComponent(Sprite).spriteFrame = this.smallBeilvImgs[3]);
        a.getComponent(Label).string = t;
        this.operateRootNode[e].getChildByName("trend_list").getComponent(ScrollView).content.addChild(o);
        this.operateRootNode[e].getChildByName("trend_list").getComponent(ScrollView).content.children.length > 3 && this.operateRootNode[e].getChildByName("trend_list").getComponent(ScrollView).scrollToPercentHorizontal(1, 0, true);
    }
    setRandomAdBtnEnable(e) {
    }
    setAdTreasureBtnEnable(e) {
    }
    updatePlayerNum(e) {
        let t = this.node.getChildByName("player7");
        sys.isObjectValid(e) && e > 0 ? (t.getChildByName("numbg").active = true, t.getChildByName("numbg").getChildByName("num").getComponent(Label).string = String(e)) : t.getChildByName("numbg").active = false;
    }
}
