// @ts-nocheck
// Recovered from index.js:573
import { _decorator, Button, color, instantiate, Label, Node, size, Sprite, SpriteFrame, sys, UITransform, v3, view } from "cc";
import SoundManager from "./SoundManager";
import PushCenter from "./PushCenter";
import { TLog } from "./TLog";
import Utils from "./Utils";
import BaseLayer from "./BaseLayer";
import i18nMgr from "./i18nMgr";
import PushEvent from "./PushEvent";
import TweenTool from "./TweenTool";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("SportCricket_NotLineUp")
export class SportCricket_NotLineUp extends BaseLayer {
    public TAG: string = "SportCricket_NotLineUp";
    @property(Node)
    public rootNode: Node = null;
    @property(Node)
    public removeBtnNode: Node = null;
    @property(Node)
    public skipBtnNode: Node = null;
    @property(Node)
    public contentNode: Node = null;
    @property([SpriteFrame])
    public teamBgImgs: SpriteFrame[] = [];
    @property([SpriteFrame])
    public checkBtnImgs: SpriteFrame[] = [];
    @property(Node)
    public team_mobanView: Node = null;
    public _closed: boolean = false;
    public bShowPushAnim: boolean = false;
    public _lastClick: number = 0;
    public _isSendMsg: boolean = false;
    public taskAwardIconMap: Map = new Map;
    public _match_id: number = 0;
    public _source: any = null;
    public _teamlistData: any = null;
    public _fromType: number = 0;
    public playerSelectMap: Map = new Map;
    public playerViewMap: Map = new Map;
    public callFuc: any = null;
    public _startY: number = 0;
    public _closeAct: any = null;
    public _startAct: any = null;
    onLoad() {
        PushCenter.shared().addListener(PushEvent.commentDownloaderImg, (t => {
            try {
                if (ToolUtils.isObjValid(this.node) && this.taskAwardIconMap.size > 0) {
                    for (const [e, i] of this.taskAwardIconMap) {
                        i == t && sys.isObjectValid(e) && Utils.shared().updateNetImage(e, t, size(88, 88));
                    }
                }
            }
            catch (t) {
                TLog.printError(this.TAG, PushEvent.commentDownloaderImg, t);
            }
        }), this);
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().removeListenersByTag(this);
        this.unscheduleAllCallbacks();
    }
    init(t) {
        sys.isObjectValid(t) && sys.isObjectValid(t.match_id) && (this._match_id = t.match_id);
        sys.isObjectValid(t) && sys.isObjectValid(t.fromType) && (this._fromType = t.fromType);
        sys.isObjectValid(t) && sys.isObjectValid(t.source) && (this._source = t.source);
        sys.isObjectValid(t) && sys.isObjectValid(t.teamlistData) && (this._teamlistData = t.teamlistData);
        sys.isObjectValid(t) && sys.isObjectValid(t.callFunc) && (this.callFuc = t.callFunc);
    }
    start() {
        super.start();
        this.initView();
        this.refreshView();
        this.showSelectView();
        TweenTool.delayAct(this.node, (() => {
            this.reSortTeamInfo();
            this.updateNextButtonStatus();
        }), 0.3, true);
    }
    showSelectView() {
        let t = -view.getVisibleSize().height / 2, e = this.rootNode.getComponent(UITransform).height;
        this._startY = t - e - 20;
        this.rootNode.setPosition(v3(0, this._startY));
        this._startAct = TweenTool.moveTo(this.rootNode, 0.2, v3(0, t), "sineIn", true);
    }
    hideSelectView() {
        this._startAct && TweenTool.stopAction(this._startAct);
        this._closeAct || (this._closeAct = TweenTool.moveTo(this.rootNode, 0.2, v3(0, this._startY), "sineIn", true, (() => {
            ToolUtils.isObjValid(this.node) && this.node.destroy();
        })));
    }
    refreshView() {
        this.updateContestDetails();
    }
    updateContestDetails() {
        sys.isObjectValid(this._teamlistData) && (this.rootNode.getChildByName("title").getComponent(Label).string = ToolUtils.format(i18nMgr.shared().getValueByKey("yes11.lineup_tip2"), this._teamlistData.length), this.contentNode.removeAllChildren(), this.playerSelectMap.clear(), this.playerViewMap.clear());
    }
    reSortTeamInfo() {
        sys.isObjectValid(this._teamlistData) && Array.isArray(this._teamlistData) && this._teamlistData.length > 0 && (this._teamlistData.sort(((t, e) => e.credits - t.credits)), this.addPlayerView(this.contentNode, this._teamlistData));
    }
    addPlayerView(t, e) {
        for (let i = 0; i < e.length; i++) {
            let a = instantiate(this.team_mobanView);
            a.active = true;
            t.addChild(a);
            this.playerSelectMap.set(e[i].player_id, 1);
            this.playerViewMap.set(e[i].player_id, a);
            a.getChildByName("check").getComponent(Button).clickEvents[0].customEventData = ToolUtils.toJsonString(e[i]);
            a.getChildByName("check").getChildByName("ico").getComponent(Sprite).spriteFrame = this.checkBtnImgs[0];
            a.getChildByName("check").getChildByName("ico").getComponent(Sprite).color = color(255, 255, 255);
            a.getChildByName("team_bg").getChildByName("wz").getComponent(Label).string = e[i].team_abbr;
            a.getChildByName("team_bg").getChildByName("wz").getComponent(Label).updateRenderData(true);
            let s = a.getChildByName("team_bg").getChildByName("wz").getComponent(UITransform).width;
            s > 25 && (a.getChildByName("team_bg").getComponent(UITransform).contentSize = size(s + 10, 20));
            e[i].team_id == this._source.teama.tid ? (a.getChildByName("team_bg").getComponent(Sprite).spriteFrame = this.teamBgImgs[0], a.getChildByName("team_bg").getChildByName("wz").getComponent(Label).color = color(255, 255, 255)) : (a.getChildByName("team_bg").getComponent(Sprite).spriteFrame = this.teamBgImgs[1], a.getChildByName("team_bg").getChildByName("wz").getComponent(Label).color = color(51, 51, 51));
            sys.isObjectValid(e[i].thumb_url) && e[i].thumb_url.length > 0 && (this.taskAwardIconMap.set(a.getChildByName("player_icon"), e[i].thumb_url), Utils.shared().updateNetImage(a.getChildByName("player_icon"), e[i].thumb_url, size(110, 110)));
            sys.isObjectValid(e[i].pts) && (a.getChildByName("pts").getComponent(Label).string = ToolUtils.format(i18nMgr.shared().getValueByKey("yes11.p_pts"), e[i].pts));
            sys.isObjectValid(e[i].credits) && (a.getChildByName("credits").getComponent(Label).string = String(e[i].credits));
            sys.isObjectValid(e[i].short_name) && (a.getChildByName("pname").getComponent(Label).string = String(e[i].short_name));
            sys.isObjectValid(e[i].role) && (a.getChildByName("role").getComponent(Label).string = e[i].role);
            "WK" == e[i].role || "AR" == e[i].role ? (a.getChildByName("pts").setPosition(v3(-153.555, -64.834)), a.getChildByName("line").setPosition(v3(-166.019, -65.808))) : "BAT" == e[i].role ? (a.getChildByName("pts").setPosition(v3(-143.555, -64.834)), a.getChildByName("line").setPosition(v3(-156.019, -65.808))) : "BOWL" == e[i].role && (a.getChildByName("pts").setPosition(v3(-133.555, -64.834)), a.getChildByName("line").setPosition(v3(-146.019, -65.808)));
        }
    }
    getSelectRemovePlayers() {
        let t = [];
        for (let e = 0; e < this._teamlistData.length; e++) {
            let i = this._teamlistData[e].player_id;
            1 == this.playerSelectMap.get(i) && t.push(i);
        }
        return t;
    }
    updateNextButtonStatus() {
        this.getSelectRemovePlayers().length > 0 ? (this.removeBtnNode.active = true, this.skipBtnNode.active = false) : (this.removeBtnNode.active = false, this.skipBtnNode.active = true);
    }
    onCloseButtonClick(t, e) {
        SoundManager.shared().playFx("click");
        sys.now() - this._lastClick < 500 || (this._lastClick = sys.now(), this.onBackView());
    }
    initView() {
        this.fitScreen();
    }
    onItemCheckClick(t, e) {
        if (SoundManager.shared().playFx("click"), sys.now() - this._lastClick < 500) {
            return;
        }
        this._lastClick = sys.now();
        let i = ToolUtils.parseJson(e).player_id;
        1 == this.playerSelectMap.get(i) ? (this.playerSelectMap.set(i, 0), this.updateItemCheckStatus(this.playerViewMap.get(i), 0)) : (this.playerSelectMap.set(i, 1), this.updateItemCheckStatus(this.playerViewMap.get(i), 1));
        this.updateNextButtonStatus();
    }
    updateItemCheckStatus(t, e) {
        sys.isObjectValid(t) && (1 == e ? (t.getChildByName("check").getChildByName("ico").getComponent(Sprite).spriteFrame = this.checkBtnImgs[0], t.getChildByName("check").getChildByName("ico").getComponent(Sprite).color = color(255, 255, 255)) : (t.getChildByName("check").getChildByName("ico").getComponent(Sprite).spriteFrame = this.checkBtnImgs[1], t.getChildByName("check").getChildByName("ico").getComponent(Sprite).color = color(200, 200, 200)));
    }
    onButtonClick(t, e) {
        if (SoundManager.shared().playFx("click"), !(sys.now() - this._lastClick < 500)) {
            if (this._lastClick = sys.now(), "edit" == e) {
                let t = this.getSelectRemovePlayers();
                this.callFuc && this.callFuc(t);
                this.onBackView(true);
            }
            else {
                "skip" == e && this.onBackView(true);
            }
        }
    }
    onBackView(t = true) {
        t && (Utils.shared().hideLoading(), this.hideSelectView());
    }
    fitScreen() {
        ToolUtils.adaptSafeArea(this.rootNode);
        sys.getSafeAreaRect().y;
    }
}
