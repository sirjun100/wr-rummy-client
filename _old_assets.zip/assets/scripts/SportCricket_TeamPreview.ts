// @ts-nocheck
// Recovered from index.js:591
import { _decorator, color, instantiate, Label, Layout, Node, size, Sprite, SpriteFrame, sys, UITransform, v3, view, Widget } from "cc";
import SoundManager from "./SoundManager";
import PushCenter from "./PushCenter";
import { TLog } from "./TLog";
import Utils from "./Utils";
import User from "./User";
import i18nMgr from "./i18nMgr";
import BaseLayer from "./BaseLayer";
import GameConfig from "./GameConfig";
import PushEvent from "./PushEvent";
import SportCricket_Manager from "./SportCricket_Manager";
import { ToolUtils } from "./ToolUtils";
import PhpReportDefined from "./PhpReportDefined";
const { ccclass, property } = _decorator;
@ccclass("SportCricket_TeamPreview")
export class SportCricket_TeamPreview extends BaseLayer {
    public TAG: string = "SportCricket_TeamPreview";
    @property(Node)
    public rootNode: Node = null;
    @property(Node)
    public goldNode: Node = null;
    @property(Node)
    public contentNode: Node = null;
    @property(Node)
    public bottomNode: Node = null;
    @property(Node)
    public teamDetailsNode: Node = null;
    @property(Node)
    public backUpRootNode: Node = null;
    @property(Node)
    public compareBtn: Node = null;
    @property(Node)
    public noSelectNode: Node = null;
    @property([SpriteFrame])
    public backupFlagImgs: SpriteFrame[] = [];
    @property([SpriteFrame])
    public capBgImgs: SpriteFrame[] = [];
    @property([SpriteFrame])
    public operateImgs: SpriteFrame[] = [];
    @property([SpriteFrame])
    public dotImgs: SpriteFrame[] = [];
    @property(Node)
    public player_mobanView: Node = null;
    @property(Node)
    public backup_used_moban: Node = null;
    public _wk_Players: any[] = [];
    public _bat_Players: any[] = [];
    public _ar_Players: any[] = [];
    public _bowl_Players: any[] = [];
    public _teama: any = null;
    public _teamb: any = null;
    public _teamAPnum: number = 0;
    public _teamBPnum: number = 0;
    public _backkup_Players: any[] = [];
    public _left_credits: number = 0;
    public _hasInitBackUp: boolean = false;
    public _lineup: number = 0;
    public _closed: boolean = false;
    public bShowPushAnim: boolean = true;
    public _lastClick: number = 0;
    public _isSendMsg: boolean = false;
    public _fromType: number = 0;
    public _bestPts: number = 0;
    public taskAwardIconMap: Map = new Map;
    public _lastNode: any = null;
    public _backupUseNum: number = 0;
    public _hasBackUp: number = 0;
    public _used_backups: any[] = [];
    public _team_id: number = 0;
    public _mteam_id: number = 0;
    public _match_id: number = 0;
    public _session_id: number = 0;
    onLoad() {
        PushCenter.shared().addListener(GameConfig.Update_Money, (t => {
            try {
                ToolUtils.isObjValid(this.node) && this.updateGold(t);
            }
            catch (t) {
                TLog.printError(this.TAG, GameConfig.Update_Money, t);
            }
        }), this);
        PushCenter.shared().addListener(PushEvent.commentDownloaderImg, (t => {
            try {
                if (ToolUtils.isObjValid(this.node) && this.taskAwardIconMap.size > 0) {
                    for (const [e, i] of this.taskAwardIconMap) {
                        i == t && ToolUtils.isObjValid(e) && ("bplayer" == e.name ? Utils.shared().updateNetImage(e, t, size(66, 66)) : Utils.shared().updateNetImage(e, t, size(88, 88)));
                    }
                }
            }
            catch (t) {
                TLog.printError(this.TAG, PushEvent.commentDownloaderImg, t);
            }
        }), this);
        this.fitLuckyTheme();
    }
    fitLuckyTheme() {
        0 != GameConfig.NATIVE_GAME_APP_TYPE && (this.rootNode.getChildByName("top_node").getChildByName("top_bg").getComponent(Sprite).color = color(12, 26, 60, 255), this.goldNode.getChildByName("coin").getComponent(Label).color = color(251, 220, 0, 255), this.rootNode.getChildByName("details").getChildByName("bg").getComponent(Sprite).color = color(0, 0, 0, 255));
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().removeListenersByTag(this);
        this.unscheduleAllCallbacks();
    }
    init(t) {
        sys.isObjectValid(t) && sys.isObjectValid(t.wk_Players) && (this._wk_Players = t.wk_Players);
        sys.isObjectValid(t) && sys.isObjectValid(t.bat_Players) && (this._bat_Players = t.bat_Players);
        sys.isObjectValid(t) && sys.isObjectValid(t.ar_Players) && (this._ar_Players = t.ar_Players);
        sys.isObjectValid(t) && sys.isObjectValid(t.bowl_Players) && (this._bowl_Players = t.bowl_Players);
        sys.isObjectValid(t) && sys.isObjectValid(t.teama) && (this._teama = t.teama);
        sys.isObjectValid(t) && sys.isObjectValid(t.teamb) && (this._teamb = t.teamb);
        sys.isObjectValid(t) && sys.isObjectValid(t.teamAPnum) && (this._teamAPnum = t.teamAPnum);
        sys.isObjectValid(t) && sys.isObjectValid(t.teamBPnum) && (this._teamBPnum = t.teamBPnum);
        sys.isObjectValid(t) && sys.isObjectValid(t.backkup_Players) && (this._backkup_Players = t.backkup_Players);
        sys.isObjectValid(t) && sys.isObjectValid(t.left_credits) && (this._left_credits = t.left_credits);
        sys.isObjectValid(t) && sys.isObjectValid(t.lastNode) && (this._lastNode = t.lastNode);
        sys.isObjectValid(t) && sys.isObjectValid(t.lineup) && (this._lineup = t.lineup);
        sys.isObjectValid(t) && sys.isObjectValid(t.fromType) && (this._fromType = t.fromType);
        sys.isObjectValid(t) && sys.isObjectValid(t.bestPts) && (this._bestPts = t.bestPts);
        sys.isObjectValid(t) && sys.isObjectValid(t.have_backups) && (this._hasBackUp = t.have_backups);
        sys.isObjectValid(t) && sys.isObjectValid(t.used_backups) && (this._used_backups = t.used_backups);
        sys.isObjectValid(t) && sys.isObjectValid(t.team_id) && (this._team_id = t.team_id);
        sys.isObjectValid(t) && sys.isObjectValid(t.compare_team_id) && (this._mteam_id = t.compare_team_id);
        sys.isObjectValid(t) && sys.isObjectValid(t.match_id) && (this._match_id = t.match_id);
        sys.isObjectValid(t) && sys.isObjectValid(t.session_id) && (this._session_id = t.session_id);
    }
    start() {
        super.start();
        this.bShowPushAnim && (ToolUtils.showPushAnim(this.node, 0, (() => {
            sys.isObjectValid(this._lastNode) && (this._lastNode.active = false);
        })), this.refreshView());
        this.updateGold(User.shared().data.money);
        this.initView();
    }
    refreshView() {
        this.updateContestDetails();
    }
    updateContestDetails() {
        sys.isObjectValid(this._teama) && sys.isObjectValid(this._teamb) && (this.refreshTopInfo(), this.refreshTeamView(), this.rootNode.getChildByName("content").active = true);
    }
    refreshBottomView() {
        if (2 == this._fromType) {
            let t = 0;
            return sys.isObjectValid(this._used_backups) && Array.isArray(this._used_backups) && this._used_backups.length > 0 && (t = this._used_backups.length), this._backupUseNum = t, this.bottomNode.getChildByName("backup_tip").getComponent(Label).string = "Backups used " + t, void (this.bottomNode.getChildByName("backup_tip").active = true);
        }
        this._backkup_Players.sort(((t, e) => t.backup - e.backup));
        for (let t = 0; t < this._backkup_Players.length; t++) {
            let e = this.bottomNode.getChildByName("backup_node" + t);
            if (sys.isObjectValid(e)) {
                e.active = true;
                let i = ToolUtils.format(i18nMgr.shared().getValueByKey("yes11.backup_wz"), this._backkup_Players[t].backup, ToolUtils.GetShortName2(this._backkup_Players[t].short_name, 10, true));
                e.getChildByName("wz").getComponent(Label).string = i;
                this._backkup_Players[t].team_id == this._teama.tid ? (e.getChildByName("wz").getComponent(Label).color = color(255, 255, 255), e.getChildByName("ico").getComponent(Sprite).spriteFrame = this.capBgImgs[0]) : (e.getChildByName("ico").getComponent(Sprite).spriteFrame = this.capBgImgs[1], e.getChildByName("wz").getComponent(Label).color = color(51, 51, 51));
                0 == this._lineup ? e.getChildByName("dot").active = false : 1 == this._backkup_Players[t].playing11 ? e.getChildByName("dot").getComponent(Sprite).spriteFrame = this.dotImgs[1] : sys.isObjectValid(this._backkup_Players[t].subplayer) && 1 == this._backkup_Players[t].subplayer ? e.getChildByName("dot").getComponent(Sprite).spriteFrame = this.dotImgs[2] : e.getChildByName("dot").getComponent(Sprite).spriteFrame = this.dotImgs[0];
            }
        }
    }
    refreshTeamView() {
        let t = 0;
        0 == SportCricket_Manager.shared().cricket_backup_open && (this._backkup_Players = []);
        2 == this._fromType && 0 == this._hasBackUp ? (this.bottomNode.active = false, this.contentNode.parent.getComponent(Widget).bottom = 0, t = 1070 / 720) : 2 == this._fromType && 1 == this._hasBackUp ? (this.bottomNode.active = true, this.contentNode.parent.getComponent(Widget).bottom = 60, t = 1010 / 720, this.refreshBottomView()) : 0 == this._backkup_Players.length ? (this.bottomNode.active = false, this.contentNode.parent.getComponent(Widget).bottom = 0, t = 1070 / 720) : (this.bottomNode.active = true, this.contentNode.parent.getComponent(Widget).bottom = 60, t = 1010 / 720, this.refreshBottomView());
        let e = 0;
        if (this.contentNode.parent.getComponent(Widget).updateAlignment(), this._teamBPnum + this._teamAPnum == 0) {
            return this.contentNode.active = false, void (this.rootNode.getChildByName("no_select").active = true);
        }
        let i = this.contentNode.parent.getComponent(UITransform).contentSize, a = 465, o = i.height / i.width, s = 108;
        o > t && (a += 50 * (o - t), s = 108 + 108 * (o - t));
        let l = a, h = a, n = [0, 90, 50, 30];
        if (this.contentNode.active = true, this.rootNode.getChildByName("no_select").active = false, this.contentNode.getChildByName("wk_root0").active = false, this.contentNode.getChildByName("wk_root1").active = false, this.contentNode.getChildByName("wk_flag").setPosition(v3(0, a)), this._wk_Players.sort(((t, e) => e.credits - t.credits)), this._bat_Players.sort(((t, e) => e.credits - t.credits)), this._ar_Players.sort(((t, e) => e.credits - t.credits)), this._bowl_Players.sort(((t, e) => e.credits - t.credits)), sys.isObjectValid(this._wk_Players) && this._wk_Players.length > 0) {
            if (this._wk_Players.length <= 4) {
                this.contentNode.getChildByName("wk_root0").active = true;
                this.contentNode.getChildByName("wk_root0").getComponent(Layout).spacingX = n[this._wk_Players.length - 1];
                this.addPlayerView(this.contentNode.getChildByName("wk_root0"), this._wk_Players);
                a -= 100;
                this.contentNode.getChildByName("wk_root0").setPosition(v3(0, a));
                a -= s;
                e += 1;
            }
            else {
                let t = 4;
                5 != this._wk_Players.length && 6 != this._wk_Players.length || (t = 3);
                this.contentNode.getChildByName("wk_root0").active = true;
                this.contentNode.getChildByName("wk_root1").active = true;
                this.contentNode.getChildByName("wk_root0").getComponent(Layout).spacingX = n[t - 1];
                this.contentNode.getChildByName("wk_root1").getComponent(Layout).spacingX = n[this._wk_Players.length - t - 1];
                this.addPlayerView(this.contentNode.getChildByName("wk_root0"), this._wk_Players.slice(0, t));
                this.addPlayerView(this.contentNode.getChildByName("wk_root1"), this._wk_Players.slice(t, this._wk_Players.length));
                a -= 100;
                this.contentNode.getChildByName("wk_root0").setPosition(v3(0, a));
                a -= 170;
                this.contentNode.getChildByName("wk_root1").setPosition(v3(0, a));
                a -= s;
                e += 2;
            }
        }
        else {
            a -= 100;
            a -= s;
            e += 1;
        }
        if (this.contentNode.getChildByName("bat_flag").setPosition(v3(0, a)), this.contentNode.getChildByName("bat_root0").active = false, this.contentNode.getChildByName("bat_root1").active = false, sys.isObjectValid(this._bat_Players) && this._bat_Players.length > 0) {
            if (this._bat_Players.length <= 4) {
                this.contentNode.getChildByName("bat_root0").active = true;
                this.contentNode.getChildByName("bat_root0").getComponent(Layout).spacingX = n[this._bat_Players.length - 1];
                this.addPlayerView(this.contentNode.getChildByName("bat_root0"), this._bat_Players);
                a -= 100;
                this.contentNode.getChildByName("bat_root0").setPosition(v3(0, a));
                a -= s;
                e += 1;
            }
            else {
                let t = 4;
                5 != this._bat_Players.length && 6 != this._bat_Players.length || (t = 3);
                this.contentNode.getChildByName("bat_root0").active = true;
                this.contentNode.getChildByName("bat_root1").active = true;
                this.contentNode.getChildByName("bat_root0").getComponent(Layout).spacingX = n[t - 1];
                this.contentNode.getChildByName("bat_root1").getComponent(Layout).spacingX = n[this._bat_Players.length - t - 1];
                this.addPlayerView(this.contentNode.getChildByName("bat_root0"), this._bat_Players.slice(0, t));
                this.addPlayerView(this.contentNode.getChildByName("bat_root1"), this._bat_Players.slice(t, this._bat_Players.length));
                a -= 100;
                this.contentNode.getChildByName("bat_root0").setPosition(v3(0, a));
                a -= 170;
                this.contentNode.getChildByName("bat_root1").setPosition(v3(0, a));
                a -= s;
                e += 2;
            }
        }
        else {
            a -= 100;
            a -= s;
            e += 1;
        }
        if (this.contentNode.getChildByName("ar_flag").setPosition(v3(0, a)), this.contentNode.getChildByName("ar_root0").active = false, this.contentNode.getChildByName("ar_root1").active = false, sys.isObjectValid(this._ar_Players) && this._ar_Players.length > 0) {
            if (this._ar_Players.length <= 4) {
                this.contentNode.getChildByName("ar_root0").active = true;
                this.contentNode.getChildByName("ar_root0").getComponent(Layout).spacingX = n[this._ar_Players.length - 1];
                this.addPlayerView(this.contentNode.getChildByName("ar_root0"), this._ar_Players);
                a -= 100;
                this.contentNode.getChildByName("ar_root0").setPosition(v3(0, a));
                a -= s;
                e += 1;
            }
            else {
                let t = 4;
                5 != this._ar_Players.length && 6 != this._ar_Players.length || (t = 3);
                this.contentNode.getChildByName("ar_root0").active = true;
                this.contentNode.getChildByName("ar_root1").active = true;
                this.contentNode.getChildByName("ar_root0").getComponent(Layout).spacingX = n[t - 1];
                this.contentNode.getChildByName("ar_root1").getComponent(Layout).spacingX = n[this._ar_Players.length - t - 1];
                this.addPlayerView(this.contentNode.getChildByName("ar_root0"), this._ar_Players.slice(0, t));
                this.addPlayerView(this.contentNode.getChildByName("ar_root1"), this._ar_Players.slice(t, this._ar_Players.length));
                a -= 100;
                this.contentNode.getChildByName("ar_root0").setPosition(v3(0, a));
                a -= 170;
                this.contentNode.getChildByName("ar_root1").setPosition(v3(0, a));
                a -= s;
                e += 2;
            }
        }
        else {
            a -= 100;
            a -= s;
            e += 1;
        }
        if (this.contentNode.getChildByName("bowl_flag").setPosition(v3(0, a)), this.contentNode.getChildByName("bowl_root0").active = false, this.contentNode.getChildByName("bowl_root1").active = false, sys.isObjectValid(this._bowl_Players) && this._bowl_Players.length > 0) {
            if (this._bowl_Players.length <= 4) {
                this.contentNode.getChildByName("bowl_root0").active = true;
                this.contentNode.getChildByName("bowl_root0").getComponent(Layout).spacingX = n[this._bowl_Players.length - 1];
                this.addPlayerView(this.contentNode.getChildByName("bowl_root0"), this._bowl_Players);
                a -= 100;
                this.contentNode.getChildByName("bowl_root0").setPosition(v3(0, a));
                h = a - 73;
                a -= s;
                e += 1;
            }
            else {
                let t = 4;
                5 != this._bowl_Players.length && 6 != this._bowl_Players.length || (t = 3);
                this.contentNode.getChildByName("bowl_root0").active = true;
                this.contentNode.getChildByName("bowl_root1").active = true;
                this.contentNode.getChildByName("bowl_root0").getComponent(Layout).spacingX = n[t - 1];
                this.contentNode.getChildByName("bowl_root1").getComponent(Layout).spacingX = n[this._bowl_Players.length - t - 1];
                this.addPlayerView(this.contentNode.getChildByName("bowl_root0"), this._bowl_Players.slice(0, t));
                this.addPlayerView(this.contentNode.getChildByName("bowl_root1"), this._bowl_Players.slice(4, this._bowl_Players.length));
                a -= 100;
                this.contentNode.getChildByName("bowl_root0").setPosition(v3(0, a));
                a -= 170;
                this.contentNode.getChildByName("bowl_root1").setPosition(v3(0, a));
                h = a - 73;
                a -= s;
                e += 2;
            }
        }
        else {
            a -= 100;
            h = a - 73;
            e += 1;
            a -= s;
        }
        let r = i.height / 2 - l - 15, d = i.height / 2 - Math.abs(h);
        e >= 4 && o > t && (r > d ? this.contentNode.setPosition(v3(0, Math.abs(r - d) / 2)) : this.contentNode.setPosition(v3(0, -Math.abs(d - r) / 2)));
    }
    refreshTopInfo() {
        sys.isObjectValid(this._teama) && sys.isObjectValid(this._teamb) && 1 != this._fromType && (this.teamDetailsNode.getChildByName("team_num0").getComponent(Label).string = String(this._teamAPnum), this.teamDetailsNode.getChildByName("team_num1").getComponent(Label).string = String(this._teamBPnum), this.teamDetailsNode.getChildByName("pnum").getComponent(Label).string = String(this._teamAPnum + this._teamBPnum) + "/11", this.teamDetailsNode.getChildByName("credits_num").getComponent(Label).string = String(this._left_credits), 2 == this._fromType ? (this.teamDetailsNode.getChildByName("credits_title").getComponent(Label).string = "Points", sys.isObjectValid(this._teama.short_name) && this._teama.short_name.length > 0 && (this.teamDetailsNode.getChildByName("team_short_name0").getComponent(Label).string = this._teama.short_name), sys.isObjectValid(this._teamb.short_name) && this._teamb.short_name.length > 0 && (this.teamDetailsNode.getChildByName("team_short_name1").getComponent(Label).string = this._teamb.short_name), sys.isObjectValid(this._teama.logo_url) && this._teama.logo_url.length > 0 && (this.taskAwardIconMap.set(this.teamDetailsNode.getChildByName("team_icon0"), this._teama.logo_url), Utils.shared().updateNetImage(this.teamDetailsNode.getChildByName("team_icon0"), this._teama.logo_url, size(54, 54))), sys.isObjectValid(this._teamb.logo_url) && this._teamb.logo_url.length > 0 && (this.taskAwardIconMap.set(this.teamDetailsNode.getChildByName("team_icon1"), this._teamb.logo_url), Utils.shared().updateNetImage(this.teamDetailsNode.getChildByName("team_icon1"), this._teamb.logo_url, size(54, 54)))) : (sys.isObjectValid(this._teama.abbr) && this._teama.abbr.length > 0 && (this.teamDetailsNode.getChildByName("team_short_name0").getComponent(Label).string = this._teama.abbr), sys.isObjectValid(this._teamb.abbr) && this._teamb.abbr.length > 0 && (this.teamDetailsNode.getChildByName("team_short_name1").getComponent(Label).string = this._teamb.abbr), sys.isObjectValid(this._teama.thumb_url) && this._teama.thumb_url.length > 0 && (this.taskAwardIconMap.set(this.teamDetailsNode.getChildByName("team_icon0"), this._teama.thumb_url), Utils.shared().updateNetImage(this.teamDetailsNode.getChildByName("team_icon0"), this._teama.thumb_url, size(54, 54))), sys.isObjectValid(this._teamb.thumb_url) && this._teamb.thumb_url.length > 0 && (this.taskAwardIconMap.set(this.teamDetailsNode.getChildByName("team_icon1"), this._teamb.thumb_url), Utils.shared().updateNetImage(this.teamDetailsNode.getChildByName("team_icon1"), this._teamb.thumb_url, size(54, 54)))));
    }
    addPlayerView(t, e) {
        for (let i = 0; i < e.length; i++) {
            let a = instantiate(this.player_mobanView);
            a.active = true;
            t.addChild(a);
            a.active = true;
            a.getChildByName("wz").getComponent(Label).string = ToolUtils.GetShortName2(e[i].short_name, 13, true);
            1 == this._fromType || 2 == this._fromType ? a.getChildByName("credit").getComponent(Label).string = e[i].pts + " pts" : a.getChildByName("credit").getComponent(Label).string = e[i].credits + " Cr";
            a.getChildByName("flag").active = false;
            sys.isObjectValid(e[i].thumb_url) && e[i].thumb_url.length > 0 && (this.taskAwardIconMap.set(a.getChildByName("player"), e[i].thumb_url), Utils.shared().updateNetImage(a.getChildByName("player"), e[i].thumb_url, size(88, 88)));
            e[i].team_id == this._teama.tid ? (a.getChildByName("wz").getComponent(Label).color = color(255, 255, 255), a.getChildByName("ico").getComponent(Sprite).spriteFrame = this.capBgImgs[0], 1 == e[i].captain_role ? (a.getChildByName("flag").active = true, a.getChildByName("flag").getComponent(Sprite).spriteFrame = this.operateImgs[0], a.getChildByName("flag").getChildByName("wz").getComponent(Label).color = color(255, 255, 255), a.getChildByName("flag").getChildByName("wz").getComponent(Label).string = "C") : 2 == e[i].captain_role && (a.getChildByName("flag").active = true, a.getChildByName("flag").getComponent(Sprite).spriteFrame = this.operateImgs[0], a.getChildByName("flag").getChildByName("wz").getComponent(Label).color = color(255, 255, 255), a.getChildByName("flag").getChildByName("wz").getComponent(Label).string = "VC")) : (a.getChildByName("ico").getComponent(Sprite).spriteFrame = this.capBgImgs[1], a.getChildByName("wz").getComponent(Label).color = color(51, 51, 51), 1 == e[i].captain_role ? (a.getChildByName("flag").active = true, a.getChildByName("flag").getComponent(Sprite).spriteFrame = this.operateImgs[1], a.getChildByName("flag").getChildByName("wz").getComponent(Label).color = color(51, 51, 51), a.getChildByName("flag").getChildByName("wz").getComponent(Label).string = "C") : 2 == e[i].captain_role && (a.getChildByName("flag").active = true, a.getChildByName("flag").getComponent(Sprite).spriteFrame = this.operateImgs[1], a.getChildByName("flag").getChildByName("wz").getComponent(Label).color = color(51, 51, 51), a.getChildByName("flag").getChildByName("wz").getComponent(Label).string = "VC"));
            sys.isObjectValid(e[i].is_backup) && 1 == e[i].is_backup ? (a.getChildByName("backup_flag").active = true, 1 != e[i].captain_role && 2 != e[i].captain_role || a.getChildByName("backup_flag").setPosition(v3(85, 58.682))) : a.getChildByName("backup_flag").active = false;
            1 == e[i].playing11 ? a.getChildByName("dot").getComponent(Sprite).spriteFrame = this.dotImgs[1] : sys.isObjectValid(e[i].subplayer) && 1 == e[i].subplayer ? a.getChildByName("dot").getComponent(Sprite).spriteFrame = this.dotImgs[2] : a.getChildByName("dot").getComponent(Sprite).spriteFrame = this.dotImgs[0];
            0 == this._lineup && (a.getChildByName("dot").active = false);
            sys.isObjectValid(this._fromType) && 1 == this._fromType || sys.isObjectValid(e[i].is_best) && 1 == Number(e[i].is_best) ? a.getChildByName("logo").active = true : a.getChildByName("logo").active = false;
        }
    }
    updateGold(t) {
        let e = this.goldNode.getChildByName("coin");
        null != t && e && (e.getComponent(Label).string = ToolUtils.parse_double(t));
    }
    onCloseButtonClick(t, e) {
        SoundManager.shared().playFx("click");
        this._closed || this.onBackView();
    }
    initView() {
        if (1 == this._fromType) {
            this.rootNode.getChildByName("details").active = false;
            this.rootNode.getChildByName("details2").active = true;
            this.rootNode.getChildByName("details2").getChildByName("pts").getComponent(Label).string = String(this._bestPts);
            this.rootNode.getChildByName("details2").getChildByName("pts").getComponent(Label).updateRenderData(true);
            let t = this.rootNode.getChildByName("details2").getChildByName("pts").getComponent(UITransform).width;
            this.rootNode.getChildByName("details2").getChildByName("label").setPosition(v3(-42.769 + t + 10, -70.141));
            this.rootNode.getChildByName("bg").getComponent(Widget).top = 100;
            this.rootNode.getChildByName("bg").getComponent(Widget).updateAlignment();
        }
        if (0 != this._fromType && this._mteam_id != this._team_id) {
            this.compareBtn.active = true;
            this.rootNode.getChildByName("top_node").getChildByName("title").active = false;
            this.rootNode.getChildByName("top_node").getChildByName("title2").active = true;
            this.rootNode.getChildByName("top_node").getChildByName("desc").active = true;
            let t = this._teama.abbr + " vs " + this._teamb.abbr;
            sys.isObjectValid(this._teama.short_name) && this._teama.short_name.length > 0 && (t = this._teama.short_name + " vs " + this._teamb.short_name);
            this.rootNode.getChildByName("top_node").getChildByName("desc").getComponent(Label).string = t;
            1 == this._fromType ? this.compareBtn.getComponent(Widget).top = 137.694 : this.compareBtn.getComponent(Widget).top = 221;
            this.compareBtn.getComponent(Widget).updateAlignment();
        }
        this.fitScreen();
    }
    onButtonClick(t, e) {
        SoundManager.shared().playFx("click");
        sys.now() - this._lastClick < 500 || (this._lastClick = sys.now(), "show_backup" == e ? this.showBackUpView() : "hide_backup" == e ? this.backUpRootNode.active = false : "compare" == e ? this.dealCompareTeamLogic() : "add_chip" == e && (Utils.shared().showStoreView(null, null), User.shared().updatePayScene(PhpReportDefined.pay_scene.hall_cricket)));
    }
    dealCompareTeamLogic() {
        let t = false;
        1 == this._fromType && (t = true);
        SportCricket_Manager.shared().requestYes11_showCompareTeam(this._match_id, this._mteam_id, this._team_id, this._session_id, true, t, this.node);
    }
    reSizeEndBackUpView() {
        if (this._used_backups.length > 0) {
            this.backUpRootNode.getChildByName("in_title").active = true;
            this.backUpRootNode.getChildByName("out_title").active = true;
            this.backUpRootNode.getChildByName("use_layout").active = true;
            for (let t = 0; t < this._used_backups.length; t++) {
                let e = instantiate(this.backup_used_moban);
                e.active = true;
                this.backUpRootNode.getChildByName("use_layout").addChild(e);
                let i = e.getChildByName("in_node"), a = e.getChildByName("out_node"), o = this._used_backups[t];
                i.getChildByName("wz").getComponent(Label).string = ToolUtils.GetShortName2(o.in_short_name, 13, false);
                i.getChildByName("wz").getComponent(Label).updateRenderData(true);
                let s = i.getChildByName("wz").getComponent(UITransform).contentSize.width, l = i.getChildByName("wz").getPosition().x;
                i.getChildByName("backup_flag").setPosition(v3(l + s + 20, -22.551));
                i.getChildByName("role_credit").getComponent(Label).string = o.in_role + "｜" + o.in_pts + " pts";
                sys.isObjectValid(o.in_thumb_url) && o.in_thumb_url.length > 0 && (this.taskAwardIconMap.set(i.getChildByName("bplayer"), o.in_thumb_url), Utils.shared().updateNetImage(i.getChildByName("bplayer"), o.in_thumb_url, size(66, 66)));
                sys.isObjectValid(o.backup) && (i.getChildByName("no").getComponent(Label).string = "B" + o.backup);
                a.getChildByName("wz").getComponent(Label).string = ToolUtils.GetShortName2(o.out_short_name, 13, false);
                a.getChildByName("wz").getComponent(Label).updateRenderData(true);
                s = a.getChildByName("wz").getComponent(UITransform).contentSize.width;
                l = a.getChildByName("wz").getPosition().x;
                a.getChildByName("backup_flag").setPosition(v3(l + s + 20, -22.551));
                a.getChildByName("role_credit").getComponent(Label).string = o.out_role + "｜" + o.out_pts + " pts";
                sys.isObjectValid(o.out_thumb_url) && o.out_thumb_url.length > 0 && (this.taskAwardIconMap.set(a.getChildByName("bplayer"), o.out_thumb_url), Utils.shared().updateNetImage(a.getChildByName("bplayer"), o.out_thumb_url, size(66, 66)));
            }
            let t = 80 * this._used_backups.length, e = 250, i = 85, a = 85;
            0 == this._backkup_Players.length && (e = 0);
            let o = t + e + i + a;
            this.backUpRootNode.getComponent(UITransform).contentSize = size(720, o);
            this.backUpRootNode.getChildByName("bg").getComponent(UITransform).contentSize = size(720, o + 120);
            this.backUpRootNode.getChildByName("title").setPosition(v3(-326.512, o - 20));
            this.backUpRootNode.getChildByName("line").setPosition(v3(0, o - 20 - 60));
            this.backUpRootNode.getChildByName("arrow").setPosition(v3(329.954, o - 40));
            this.backUpRootNode.getChildByName("arrow_btn").setPosition(v3(329.954, o - 40));
            this.backUpRootNode.getChildByName("in_title").setPosition(v3(-320.282, o - 90));
            this.backUpRootNode.getChildByName("out_title").setPosition(v3(94.37, o - 90));
            this.backUpRootNode.getChildByName("use_layout").setPosition(v3(0, o - 140));
        }
    }
    showBackUpView() {
        if (!this._hasInitBackUp) {
            this._hasInitBackUp = true;
            2 == this._fromType && (this._backkup_Players.length > 0 && (this.backUpRootNode.getChildByName("desc").active = true), this.reSizeEndBackUpView());
            for (let t = 0; t < this._backkup_Players.length; t++) {
                let e = this.backUpRootNode.getChildByName("backup_node" + t);
                ToolUtils.isObjValid(e) && (e.active = true, e.getChildByName("no").getComponent(Label).string = "B" + this._backkup_Players[t].backup, e.getChildByName("wz").getComponent(Label).string = ToolUtils.GetShortName2(this._backkup_Players[t].short_name, 10, false), 2 == this._fromType ? e.getChildByName("credit").getComponent(Label).string = this._backkup_Players[t].role + "｜" + this._backkup_Players[t].pts + " pts" : e.getChildByName("credit").getComponent(Label).string = this._backkup_Players[t].role + "｜" + this._backkup_Players[t].credits + " Cr", sys.isObjectValid(this._backkup_Players[t].thumb_url) && this._backkup_Players[t].thumb_url.length > 0 && (this.taskAwardIconMap.set(e.getChildByName("player"), this._backkup_Players[t].thumb_url), Utils.shared().updateNetImage(e.getChildByName("player"), this._backkup_Players[t].thumb_url, size(88, 88))), this._backkup_Players[t].team_id == this._teama.tid ? (e.getChildByName("wz").getComponent(Label).color = color(255, 255, 255), e.getChildByName("ico").getComponent(Sprite).spriteFrame = this.capBgImgs[0]) : (e.getChildByName("ico").getComponent(Sprite).spriteFrame = this.capBgImgs[1], e.getChildByName("wz").getComponent(Label).color = color(51, 51, 51)), 0 == this._lineup ? e.getChildByName("dot").active = false : 1 == this._backkup_Players[t].playing11 ? e.getChildByName("dot").getComponent(Sprite).spriteFrame = this.dotImgs[1] : sys.isObjectValid(this._backkup_Players[t].subplayer) && 1 == this._backkup_Players[t].subplayer ? e.getChildByName("dot").getComponent(Sprite).spriteFrame = this.dotImgs[2] : e.getChildByName("dot").getComponent(Sprite).spriteFrame = this.dotImgs[0]);
            }
        }
        this.backUpRootNode.active = true;
    }
    onBackView(t = true) {
        t && (Utils.shared().hideLoading(), this.bShowPushAnim ? (this._closed = true, ToolUtils.isObjValid(this._lastNode) && (this._lastNode.active = true), ToolUtils.showPushAnim(this.node, 1, (() => {
            ToolUtils.isObjValid(this.node) && this.node.destroy();
        }))) : (ToolUtils.isObjValid(this._lastNode) && (this._lastNode.active = true), ToolUtils.isObjValid(this.node) && this.node.destroy()));
    }
    fitScreen() {
        ToolUtils.adaptSafeArea(this.rootNode);
        let t = sys.getSafeAreaRect().y, e = view.getVisibleSize();
        if (this.node.getComponent(UITransform).setContentSize(e.width, e.height), 0 != t) {
            let e = this.rootNode.getChildByName("content").getComponent(Widget).bottom;
            this.rootNode.getChildByName("content").getComponent(Widget).bottom = e - t;
            e = this.bottomNode.getComponent(Widget).bottom;
            this.bottomNode.getComponent(Widget).bottom = e - t + 20;
            e = this.backUpRootNode.getComponent(Widget).bottom;
            this.backUpRootNode.getComponent(Widget).bottom = e - t;
        }
    }
}
