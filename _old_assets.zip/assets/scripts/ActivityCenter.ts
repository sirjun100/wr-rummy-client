// @ts-nocheck
// Recovered from index.js:3
import { _decorator, Button, instantiate, Label, Node, ScrollView, size, sys, UIOpacity, UITransform, v3, Vec3, Widget } from "cc";
import TweenTool from "./TweenTool";
import Utils from "./Utils";
import PushCenter from "./PushCenter";
import PushEvent from "./PushEvent";
import User from "./User";
import SoundManager from "./SoundManager";
import Parent from "./Parent";
import { ToolUtils } from "./ToolUtils";
import PhpReportDefined from "./PhpReportDefined";
const { ccclass, property } = _decorator;
@ccclass("ActivityCenter")
export class ActivityCenter extends Parent {
    @property(ScrollView)
    public scrollView: ScrollView = null;
    @property(Node)
    public moban: Node = null;
    @property(Node)
    public rootNode: Node = null;
    public _scrollUtil: any = null;
    public _items: any[] = [];
    public scheduleList: any[] = [];
    public activityEndAllTimes: any[] = [];
    public isSendHttp: boolean = false;
    public isUIReport: boolean = false;
    public lastClick: number = 0;
    onLoad() {
        ToolUtils.showFullScreen(this.node.getChildByName("mask"));
        PushCenter.shared().addListener(PushEvent.commentDownloaderImg, (t => {
            if (ToolUtils.isObjValid(this.node)) {
                let e = User.shared().data.act_collect_open.list;
                e.sort(((t, e) => t.has_red !== e.has_red ? e.has_red - t.has_red : e.sort - t.sort));
                for (let i = 0, o = e.length; i < o; i++) {
                    let o = this._items[i];
                    if (sys.isObjectValid(o)) {
                        let a = o.getChildByName("ico"), l = e[i].imgurl;
                        l == t && (o.getChildByName("check").active = true, Utils.shared().updateNetImage(a, l, size(637, 279), (t => {
                        })));
                    }
                }
            }
        }), this);
        PushCenter.shared().addListener(PushEvent.updateActCollectOpen, (t => {
            ToolUtils.isObjValid(this.node) && this.refreshView(false);
        }), this);
    }
    fitScreen() {
    }
    start() {
        this.moban.active = false;
        this.refreshView();
        this.playActAnim();
        SoundManager.shared().playFx("act_popshow");
    }
    refreshView(t = true) {
        let e = false;
        if (sys.isObjectValid(User.shared().data.act_collect_open) && sys.isObjectValid(User.shared().data.act_collect_open.list) && User.shared().data.act_collect_open.list.length > 0 && (e = true), !e) {
            return void this.onBackView();
        }
        let i = false;
        for (let t = 0; t < this._items.length; t++) {
            ToolUtils.isObjValid(this._items[t]) && this._items[t].removeFromParent();
        }
        this._items = [];
        i = true;
        let o = -172, l = 0, s = User.shared().data.act_collect_open.list.length, u = User.shared().data.act_collect_open.list;
        u.sort(((t, e) => t.has_red !== e.has_red ? e.has_red - t.has_red : e.sort - t.sort));
        let g = [[142, -113], [284, 29, -255], [426, 171, -113, -397]];
        this.rootNode.getChildByName("layout").active = false;
        this.rootNode.getChildByName("layout2").active = false;
        s <= 3 ? (this.rootNode.getChildByName("layout2").getChildByName("title_node").setPosition(v3(0, g[s - 1][0])), this.rootNode.getChildByName("layout2").active = true) : this.rootNode.getChildByName("layout").active = true;
        for (let e = 0; e < s; e++) {
            let i = null;
            0;
            ToolUtils.isObjValid(i) || (i = instantiate(this.moban), this._items.push(i));
            i.active = true;
            e > 0 && (o = o - 279 - 10);
            s >= 4 ? (i.setPosition(v3(0, o)), this.scrollView.getComponent(ScrollView).content.addChild(i), t && (i.getComponent(UIOpacity).opacity = 0)) : (i.setPosition(v3(0, g[s - 1][e + 1])), this.rootNode.getChildByName("layout2").addChild(i));
            this.initCurMobanCallBack(i, u[e]);
        }
        let p = User.shared().data.act_collect_open.list.length;
        l = 279 * p + 10 * (p - 1) + 30;
        this.scrollView.getComponent(ScrollView).content.getComponent(UITransform).contentSize = size(676, l);
    }
    playActAnim() {
        let t = 0;
        if (this._items.length >= 4) {
            for (let e = 0; e < this._items.length; e++) {
                let i = this._items[e], o = new Vec3;
                i.getPosition(o);
                i.setPosition(v3(o.x, o.y - 30));
                let a = TweenTool.moveToByFade(i, 0.16, o, 0, 1, false, (() => {
                    i.getComponent(UIOpacity).opacity = 255;
                    i.setPosition(o);
                })), l = TweenTool.delayAct(i, null, t, false);
                TweenTool.sequence(i, true, null, l, a);
                i.getComponent(UIOpacity).opacity = 0;
                t += 0.08;
            }
        }
        else {
            this.startShowAnim(this.rootNode.getChildByName("layout2"));
        }
    }
    initCurMobanCallBack(t, e) {
        t.getChildByName("check").getComponent(Button).clickEvents[0].customEventData = e;
        let i = t.getChildByName("time_left");
        i.active = false;
        sys.isObjectValid(e.time_left) && (i.active = true, i.getChildByName("wz").getComponent(Label).string = Utils.shared().parseCountDown(e.time_left), i.getChildByName("wz").getComponent(Label).updateRenderData(true), i.getChildByName("wz").getChildByName("ico").getComponent(Widget).updateAlignment(), TweenTool.myschedule(i, 1, (() => {
            ToolUtils.isObjValid(this.node) && (e.time_left > 0 ? (e.time_left = e.time_left - 1, i.getChildByName("wz").getComponent(Label).string = Utils.shared().parseCountDown(e.time_left), i.getChildByName("wz").getComponent(Label).updateRenderData(true), i.getChildByName("wz").getChildByName("ico").getComponent(Widget).updateAlignment()) : (User.shared().getHallInfo(), TweenTool.stopNodeAction(i)));
        })));
        sys.isObjectValid(e.imgurl) && e.imgurl.length > 0 && Utils.shared().updateNetImage(t.getChildByName("ico"), e.imgurl, size(637, 279), (e => {
            t.getChildByName("check").active = true;
        }));
        sys.isObjectValid(e.has_red) && 1 == e.has_red ? t.getChildByName("check").getChildByName("wz").getComponent(Label).string = "COLLECT" : t.getChildByName("check").getChildByName("wz").getComponent(Label).string = "CHECK";
    }
    onDestroy() {
        PushCenter.shared().removeListenersByTag(this);
        this.unscheduleAllCallbacks();
    }
    onEnable() {
    }
    onBackView() {
        ToolUtils.isObjValid(this.node) && this.node.destroy();
    }
    onButtonClick(t, e) {
        SoundManager.shared().playFx("click");
        try {
            if ("close" == e) {
                return void this.onBackView();
            }
            this.lastClick = sys.now();
            let t = e.ext, i = 1;
            sys.isObjectValid(t) || (t = {});
            e.act_id == PushEvent.JUMP_TO_Adventrue ? t.from_source = 1 : e.act_id == PushEvent.JUMP_TO_FREECASH ? t.from_source = 6 : e.act_id == PushEvent.JUMP_TO_BANKRUPTCARD && (i = 2);
            Utils.shared().doJumpLogic(e.act_id, t, { reportEvtId: i, link_id: sys.now() });
            User.shared().updatePayScene(PhpReportDefined.pay_scene.hall_activity_center);
        }
        catch (t) {
        }
    }
    onCloseButtonClick(t, e) {
        SoundManager.shared().playFx("click");
        "close" == e && this.node.destroy();
    }
}
