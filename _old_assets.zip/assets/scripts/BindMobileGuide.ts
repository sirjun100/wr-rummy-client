// @ts-nocheck
// Recovered from index.js:37
import { _decorator, Button, EditBox, Label, LabelShadow, Node, Sprite, SpriteFrame, sys, v3 } from "cc";
import BaseLayer from "./BaseLayer";
import i18nMgr from "./i18nMgr";
import Utils from "./Utils";
import User from "./User";
import PushCenter from "./PushCenter";
import GameConfig from "./GameConfig";
import SoundManager from "./SoundManager";
import HttpManager from "./HttpManager";
import PushEvent from "./PushEvent";
import CommDefine from "./CommDefine";
import { TransferPlatform } from "./TransferPlatform";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("BindMobileGuide")
export class BindMobileGuide extends BaseLayer {
    @property(Node)
    public rootNode: Node = null;
    @property(Node)
    public newTel_node: Node = null;
    @property(Node)
    public code_node: Node = null;
    @property(Node)
    public code_btnNode: Node = null;
    @property(Label)
    public codeLabel: Label = null;
    @property(Button)
    public submitBtn: Button = null;
    @property(EditBox)
    public phone_tf: EditBox = null;
    @property(EditBox)
    public otp_tf: EditBox = null;
    @property(Node)
    public btn_del_phone: Node = null;
    @property(Node)
    public btn_del_otp: Node = null;
    @property(Label)
    public bind_tips: Label = null;
    @property([SpriteFrame])
    public buttonSpriteFrames: SpriteFrame[] = [];
    public _cb: any = null;
    public state: number = 0;
    public serialno: string = "";
    public bShowPushAnim: boolean = false;
    public _closed: boolean = false;
    public showUICallback: any = null;
    public _keyboardHei: number = 740;
    public input_node: any = null;
    init(e, t = null) {
    }
    onLoad() {
        let e = this.node.getChildByName("mask");
        ToolUtils.showFullScreen(e);
    }
    onDestroy() {
        super.onDestroy();
        TransferPlatform.shared().setSoftInputMode(0);
        Utils.shared().hideLoading();
        PushCenter.shared().removeListenersByTag(this);
    }
    start() {
        super.start();
        TransferPlatform.shared().setSoftInputMode(1);
        this.startShowAnim(this.rootNode);
        this.refreshUI(this.state);
        this.updateRewardList();
        this.refreshEditBoxFocus(this.state);
        this.refreshCodeBtn();
        User.shared().code_timeout > 0 && this.schedule(this.refreshCodeBtn, 1);
        PushCenter.shared().addListener(PushEvent.changeWebViewHeight, (e => {
            ToolUtils.isObjValid(this.node) && (this._keyboardHei = ToolUtils.isSafeNumber(Number(e)), sys.isObjectValid(this.input_node) ? this.showScrollivewUp(this.input_node) : this.showScrollivewUp(this.otp_tf.node));
        }), this);
    }
    setCloseCallBack(e) {
        this._cb = e;
    }
    refreshUI(e) {
        0 === e && (this.newTel_node.active = true, this.code_node.active = true, this.phone_tf.string = ToolUtils.isSafeString(User.shared().data.tel_no), this.bind_tips.node.active = true, this.submitBtn.node.active = true, this.updateMobileClearStatus());
    }
    updateRewardList() {
        let e = User.shared().data.kyc_list;
        if (sys.isObjectValid(e) && Array.isArray(e) && e.length > 0) {
            for (let t = 0; t < e.length; t++) {
                if (1 == ToolUtils.isSafeNumber(e[t].type)) {
                    let i = 0, s = 0;
                    if (sys.isObjectValid(e[t].cash) && (i = Number(e[t].cash)), sys.isObjectValid(e[t].bonus) && (s = Number(e[t].bonus)), i > 0 && s > 0) {
                        let e = ToolUtils.format(i18nMgr.shared().getValueByKey("kyc.mobile_top_tip"), "₹" + String(i + s) + "*");
                        this.rootNode.getChildByName("top_tip").getComponent(Label).string = e;
                    }
                    else if (i > 0) {
                        let e = ToolUtils.format(i18nMgr.shared().getValueByKey("kyc.mobile_top_tip"), "CASH ₹" + String(i));
                        this.rootNode.getChildByName("top_tip").getComponent(Label).string = e;
                    }
                    else if (s > 0) {
                        let e = ToolUtils.format(i18nMgr.shared().getValueByKey("kyc.mobile_top_tip"), "BONUS ₹" + String(s));
                        this.rootNode.getChildByName("top_tip").getComponent(Label).string = e;
                    }
                    else {
                        this.rootNode.getChildByName("top_tip").getComponent(Label).string = i18nMgr.shared().getValueByKey("kyc.kyc_top_tip1") || "";
                    }
                    break;
                }
            }
        }
    }
    refreshEditBoxFocus(e) {
        0 === e && this.phone_tf.getComponent(EditBox).focus();
    }
    onMobileTextBegan(e, t, i) {
        this.input_node = this.phone_tf.node;
    }
    onMobileTextChanged(e, t, i) {
        this.updateMobileClearStatus();
    }
    onMobileTextEnd(e, t, i) {
        this.updateMobileClearStatus();
    }
    onCodeTextBegan(e, t, i) {
        this.input_node = this.otp_tf.node;
    }
    onCodeTextChanged(e, t, i) {
        this.updateOtpClearStatus();
    }
    onCodeTextEnd(e, t, i) {
        this.updateOtpClearStatus();
    }
    listenBlindPhoneCall(e, t, i) {
        if (Utils.shared().hideLoading(), 200 !== i) {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text37"), 2);
        }
        else {
            let e = ToolUtils.parseJson(t);
            if (0 === e.ret) {
                let t = e.data.tel_no;
                if (User.shared().data.tel_no = t, ToolUtils.saveData("code_phoneno", t + ""), sys.isObjectValid(e.data.kyc_update_status) && (User.shared().data.kyc_update_status = e.data.kyc_update_status), null != e.data.kyc_check && null != e.data.kyc_check && (User.shared().data.kyc_check = e.data.kyc_check), PushCenter.shared().pushEvent(GameConfig.Update_Kyc, User.shared().data.kyc_check), sys.isObjectValid(e.data.reward_list) && e.data.reward_list.length > 0) {
                    Utils.shared().showKycVerifySucTip(e.data.reward_list, i18nMgr.shared().getValueByKey("bind_mobile.phone_binding_success2"));
                }
                else if (User.shared().code_timeout = e.data.timeout, e.desc && ToolUtils.isSafeString(e.desc).length > 0) {
                    let t = ToolUtils.isSafeString(e.desc);
                    Utils.shared().showToast(t, 2);
                }
                else {
                    Utils.shared().showToast(i18nMgr.shared().getValueByKey("bind_mobile.phone_binding_success"), 2);
                }
                PushCenter.shared().pushEvent(GameConfig.MobileBlind_State, User.shared().data.tel_no);
                PushCenter.shared().pushEvent(PushEvent.updateBannerList);
                this.onBindSuccess(this.otp_tf.string, e.data.serialno);
            }
            else if (e.desc && ToolUtils.isSafeString(e.desc).length > 0) {
                let t = ToolUtils.isSafeString(e.desc);
                Utils.shared().showToast(t, 2);
            }
        }
    }
    listenGetCodeCall(e, t, i) {
        if (Utils.shared().hideLoading(), 200 !== i) {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text37"), 2);
        }
        else {
            let e = ToolUtils.parseJson(t);
            if (0 === e.ret) {
                let t = e.data.timeout;
                this.serialno = e.data.serialno;
                User.shared().code_timeout = t;
                Utils.shared().showToast(i18nMgr.shared().getValueByKey("bind_mobile.verification_tips"), 2);
                this.unschedule(this.refreshCodeBtn);
                this.refreshCodeBtn();
                this.schedule(this.refreshCodeBtn, 1);
            }
            else {
                if (e.desc && ToolUtils.isSafeString(e.desc).length > 0) {
                    let t = ToolUtils.isSafeString(e.desc);
                    Utils.shared().showToast(t, 2);
                }
                let t = e.data.timeout;
                t && ToolUtils.isSafeNumber(t) > 0 && (User.shared().code_timeout = t, this.unschedule(this.refreshCodeBtn), this.refreshCodeBtn(), this.schedule(this.refreshCodeBtn, 1));
            }
        }
    }
    refreshCodeBtn() {
        User.shared().code_timeout = User.shared().code_timeout - 1;
        let e = this.code_btnNode.getComponent(Button), t = this.code_btnNode.getChildByName("ico").getComponent(Sprite);
        User.shared().code_timeout <= 0 ? (this.unschedule(this.refreshCodeBtn), e.interactable = true, t.spriteFrame = this.buttonSpriteFrames[0], this.codeLabel.string = "OTP", this.codeLabel.node.getComponent(LabelShadow).color = CommDefine.shadowcolor.green, Utils.updateLabelMaterial(this.codeLabel.node, CommDefine.gradient.btn_green)) : (e.interactable = false, t.spriteFrame = this.buttonSpriteFrames[1], this.codeLabel.string = `(${User.shared().code_timeout}s)`, this.codeLabel.node.getComponent(LabelShadow).color = CommDefine.shadowcolor.gray, Utils.updateLabelMaterial(this.codeLabel.node, CommDefine.gradient.btn_gray));
    }
    resethCodeBtn() {
        let e = this.code_btnNode.getComponent(Button), t = this.code_btnNode.getComponent(Sprite);
        this.unschedule(this.refreshCodeBtn);
        e.interactable = true;
        t.spriteFrame = this.buttonSpriteFrames[0];
        this.codeLabel.string = "OTP";
        this.codeLabel.node.getComponent(LabelShadow).color = CommDefine.shadowcolor.green;
        Utils.updateLabelMaterial(this.codeLabel.node, CommDefine.gradient.btn_green);
    }
    updateMobileClearStatus() {
        ToolUtils.isSafeString(this.phone_tf.string).length > 0 ? this.btn_del_phone.active = true : this.btn_del_phone.active = false;
    }
    updateOtpClearStatus() {
        ToolUtils.isSafeString(this.otp_tf.string).length > 0 ? this.btn_del_otp.active = true : this.btn_del_otp.active = false;
    }
    buttonClick(e, t) {
        if (SoundManager.shared().playFx("click"), "code" === t) {
            if (0 == this.state || 1 == this.state || 3 == this.state) {
                let e = ToolUtils.isSafeString(this.phone_tf.string);
                if (0 == e.length) {
                    return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("bind_mobile.input_number_tips"), 2);
                }
                if (10 != e.length) {
                    return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("bind_mobile.invalid_mobile_number"), 2);
                }
                if (1 == this.state && User.shared().data.tel_no == e) {
                    return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("bind_mobile.same_number"), 2);
                }
                Utils.shared().showLoading(10, true, (() => {
                    Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
                }));
                HttpManager.shared().doGetMobileCode(e, 4, 1, this.listenGetCodeCall.bind(this));
            }
        }
        else if ("submit" === t) {
            if (0 === this.state || 3 === this.state) {
                this.restoreScrollviewTop();
                let e = ToolUtils.isSafeString(this.phone_tf.string), t = ToolUtils.isSafeString(this.otp_tf.string);
                if (0 == e.length) {
                    return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("bind_mobile.input_number_tips"), 2);
                }
                if (e.length < 10) {
                    return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("bind_mobile.invalid_mobile_number"), 2);
                }
                if (0 == t.length) {
                    return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("bind_mobile.enter_code_tips"), 2);
                }
                if (t.length < 6) {
                    return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text63"), 3);
                }
                Utils.shared().showLoading(10, true, (() => {
                    Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
                }));
                HttpManager.shared().doBlindPhoneAccount(e, t, "", this.serialno, this.listenBlindPhoneCall.bind(this));
            }
        }
        else if ("clearMobile" === t) {
            this.phone_tf.string = "";
            this.phone_tf.blur();
            this.updateMobileClearStatus();
        }
        else if ("clearOTP" === t) {
            this.otp_tf.string = "";
            this.otp_tf.blur();
            this.updateOtpClearStatus();
        }
        else if ("close" === t) {
            if (this._closed) {
                return;
            }
            this.onBackView();
        }
    }
    onBindSuccess(e, t) {
        ToolUtils.isObjValid(this.node) && this.node.destroy();
    }
    onBackView() {
        ToolUtils.isObjValid(this.node) && this.node.destroy();
    }
    showScrollivewUp(e) {
        if (ToolUtils.getIsInRoom()) {
            return;
        }
        let t = v3(0, 0);
        this.node.inverseTransformPoint(t, e.getWorldPosition());
        let i = GameConfig.REAL_SCREEN_HEIGHT;
        ToolUtils.getIsInRoom() && (i = GameConfig.REAL_SCREEN_WIDTH);
        let s = i / 2 + t.y - 34 - 80;
        s < this._keyboardHei ? this.rootNode.setPosition(v3(0, this._keyboardHei - s)) : this.rootNode.setPosition(v3(0, 0));
    }
    restoreScrollviewTop() {
        this.rootNode.setPosition(v3(0, 0));
    }
}
