// @ts-nocheck
// Recovered from index.js:279
import { _decorator, sys } from "cc";
import i18nMgr from "./i18nMgr";
import PushCenter from "./PushCenter";
import { ToolUtils } from "./ToolUtils";
import Utils from "./Utils";
import GameConfig from "./GameConfig";
import NetConfig from "./NetConfig";
import PushEvent from "./PushEvent";
import RummyCmd from "./RummyCmd";
import URLConfig from "./URLConfig";
import User from "./User";
import NetHostManager from "./NetHostManager";
import Server from "./Server";
import { MyComponent } from "./MyComponent";
import { LuckyBallgame } from "./LuckyBallgame";
import { LuckyBallGameManager } from "./LuckyBallGameManager";
const { ccclass } = _decorator;
@ccclass("LuckyBallGameHandle")
export class LuckyBallGameHandle extends MyComponent {
    public _TAG: string = "LuckyBallGameHandle";
    public isNetworkDelay: boolean = true;
    public tid_key: string = "";
    public backgroundSatyTime: number = 0;
    public _enterStartTime: number = 0;
    onLoad() {
        LuckyBallGameManager.shared()._tidKey = User.shared().curTid_key;
        this.tid_key = User.shared().curTid_key;
        this._enterStartTime = sys.now();
        Server.shared().regDispatch(NetConfig.HEARTBEAT_CMD, this.handler_server_HEARTBEAT_DELAY_return.bind(this), this);
        Server.shared().regDispatch(NetConfig.SERVER_LOGIN_GATE_RESP, this.handler_server_login_gate_return.bind(this), this);
        Server.shared().regDispatch(NetConfig.SM_LOGIN_RETURN, this.handler_server_login_return.bind(this), this);
        Server.shared().regDispatch(NetConfig.SYSTEM_GATEWAY_CMD, this.handler_server_system_gateway_return.bind(this), this);
        this.initPushCenter();
    }
    initPushCenter() {
        this.addEvent(GameConfig.onEnterForeground, (e => {
            if (ToolUtils.isGameBackground = false, ToolUtils.isObjValid(this.node)) {
                let e = this, t = sys.now();
                this.scheduleOnce((() => {
                    e.isNetworkDelay = true;
                }), 1);
                Utils.shared().checkScreenPortrait();
                t / 1000 - this.backgroundSatyTime / 1000 > 30 || ToolUtils.backgroundWebSocketReconnection ? (ToolUtils.backgroundWebSocketReconnection = false, this.scheduleOnce((() => {
                    Server.shared().disconnectWebSocket();
                })), this.scheduleOnce((() => {
                    this.loginGameServer();
                }), 0.2)) : this.scheduleOnce((() => {
                    this.node.getComponent(LuckyBallgame).sendGameInfoRequest();
                }), 0.2);
            }
        }), this);
        this.addEvent(GameConfig.onEnterBackground, (e => {
            ToolUtils.isGameBackground = true;
            this.backgroundSatyTime = sys.now();
            this.send_request_enterBackGround();
        }), this);
        this.addEvent(PushEvent.BackToLogin, (e => {
        }), this);
        this.addEvent(PushEvent.ExitGameToHall, (e => {
            ToolUtils.isObjValid(this.node) && this.backToHall();
        }), this);
        this.addEvent(PushEvent.Low_Memory_Notice, (e => {
            ToolUtils.isObjValid(this.node);
        }), this);
        this.addEvent(PushEvent.RefreshRoomDesk, (() => {
            ToolUtils.isObjValid(this.node) && LuckyBallGameManager.shared().sendGameInfoRequest();
        }), this);
    }
    handler_server_login_return(e) {
        try {
            sys.isObjectValid(e.session_id) && (User.shared().session_id = e.session_id);
            let t = ToolUtils.isSafeString(e.old_tid_key);
            if (this.tid_key != t) {
                return;
            }
            if (1 == parseInt("" + e.ret) && ToolUtils.isSafeString(e.alertStr).length > 0) {
                return this.backToHall(), Utils.shared().showToast(e.alertStr, 2, 0, ToolUtils.getIsNormalDirection()), void (ToolUtils.deskInfos.size <= 1 && Server.shared().disconnectWebSocket());
            }
            if (0 == parseInt("" + e.ret)) {
                if (sys.isObjectValid(e.session_id) && (User.shared().session_id = e.session_id), 1 == e.isNewTable) {
                    return void LuckyBallGameManager.shared().create_new_table();
                }
                0 == e.isNewTable && sys.isObjectValid(e.table_keys) && Array.isArray(e.table_keys) && e.table_keys.length > 0 ? (User.shared().curTid_key = e.table_keys[0].tid_key, this.tid_key = e.table_keys[0].tid_key, LuckyBallGameManager.shared()._tidKey = this.tid_key, LuckyBallGameManager.shared().sendGameInfoRequest()) : this.backToHall();
            }
            else {
                e.alertStr && "" != e.alertStr && Utils.shared().showCommomDialog(e.alertStr, "", (() => {
                }), false, ToolUtils.getIsNormalDirection(), null, null, null, null, null, this.tid_key);
            }
        }
        catch (e) {
        }
    }
    backToHall() {
        Server.shared().clearEventByTarget(this);
        PushCenter.shared().pushEvent(PushEvent.ExitLuckyBallGame);
        this.node.destroy();
    }
    send_request_enterBackGround() {
        let e = { cmd: RummyCmd.CLIENT_OFFLINE, uid: User.shared().data.uid, version: GameConfig.Server_Api_Ver, tid_key: this.tid_key, skey: User.shared().getSkey() };
        Server.shared().send(e);
    }
    handler_server_system_gateway_return(e) {
        if (null != e.tid_key && null != e.tid_key && "" != e.tid_key) {
            if (this.tid_key === (e.tid_key || "") && -1 === e.res) {
                let e = i18nMgr.shared().getValueByKey("utlis.service_upgrade");
                Utils.shared().showToast(e, 2, 0, ToolUtils.getIsNormalDirection());
                this.backToHall();
            }
        }
        else {
            User.shared().curTid_key === this.tid_key && -1 === e.res && ToolUtils.isSafeString(e.msg).length > 0 && Utils.shared().showToast(e.msg, 2, 0, ToolUtils.getIsNormalDirection());
        }
    }
    handler_server_login_gate_return(e) {
        LuckyBallGameManager.shared().handler_server_login_gate_return(e);
    }
    handler_server_HEARTBEAT_DELAY_return(e) {
        this.isNetworkDelay = true;
        let t = sys.now() - e.ct;
        ToolUtils.gamePing = t;
        t > 999 && (t = 999);
        1 == User.shared().games_delay_open && (User.shared().hasMaintain || 0 == window.InGameScene || this.updateNetSignal(t));
    }
    loginGameServer() {
        Server.shared().setOpenCb((() => {
            User.shared().send_login_gate_request();
        }));
        Server.shared().setReconCb((() => {
            User.shared().send_request_game_tableinfo();
        }));
        let e = URLConfig.orginHttp_tcp, t = NetHostManager.shared().chooseBestTcpIpConn(ToolUtils.curRoomId), s = NetHostManager.shared().chooseBestTcpPortConn(ToolUtils.curRoomId);
        "-1" != t && -1 != s && (e = 443 == s ? "wss://" + t + ":443" : "ws://" + t + ":" + s);
        Server.shared().createSocket(e);
        User.shared().isGameDisconnectServer = false;
    }
    updateNetSignal(e) {
    }
}
