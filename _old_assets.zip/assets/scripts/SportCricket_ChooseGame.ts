// @ts-nocheck
// Recovered from index.js:547
import { _decorator, Button, color, instantiate, Label, Layout, Node, ProgressBar, ScrollView, size, sp, Sprite, SpriteFrame, sys, UITransform, v3, view, Widget } from "cc";
import SoundManager from "./SoundManager";
import PushCenter from "./PushCenter";
import { TLog } from "./TLog";
import Utils from "./Utils";
import User from "./User";
import HttpManager from "./HttpManager";
import i18nMgr from "./i18nMgr";
import BaseLayer from "./BaseLayer";
import { HttpRequest } from "./HttpRequestName";
import GameConfig from "./GameConfig";
import PushEvent from "./PushEvent";
import TweenTool from "./TweenTool";
import SportCricket_Manager from "./SportCricket_Manager";
import { ToolUtils } from "./ToolUtils";
import ScrollVisibility from "./ScrollVisibility";
import BundleNameDefined from "./BundleNameDefined";
import PhpReportDefined from "./PhpReportDefined";
const { ccclass, property } = _decorator;
@ccclass("SportCricket_ChooseGame")
export class SportCricket_ChooseGame extends BaseLayer {
    public TAG: string = "SportCricket_ChooseGame";
    @property(Node)
    public rootNode: Node = null;
    @property(Node)
    public goldNode: Node = null;
    @property(Node)
    public tabNode: Node = null;
    @property(Node)
    public sortNode: Node = null;
    @property(Node)
    public sortMoban: Node = null;
    public sortFilterInfo: any = null;
    @property(Node)
    public bottomNode: Node = null;
    @property(Node)
    public fingerNode: Node = null;
    @property(Node)
    public topNode: Node = null;
    @property(ScrollView)
    public allMatchScrollView: ScrollView = null;
    @property(ScrollView)
    public myMatchScrollView: ScrollView = null;
    @property([SpriteFrame])
    public capBgImgs: SpriteFrame[] = [];
    @property([SpriteFrame])
    public sortBgImgs: SpriteFrame[] = [];
    @property([SpriteFrame])
    public operateImgs: SpriteFrame[] = [];
    @property([SpriteFrame])
    public iconImgs: SpriteFrame[] = [];
    public allMatchTable: any = null;
    public myMatchTable: any = null;
    public all_listData: any[] = [];
    public my_listData: any[] = [];
    @property(Node)
    public my_mobanView: Node = null;
    @property(Node)
    public shortteam_mobanView: Node = null;
    @property(Node)
    public fullteam_mobanView: Node = null;
    public _closed: boolean = false;
    public bShowPushAnim: boolean = true;
    public _lastClick: number = 0;
    public _match_id: number = 0;
    public _source: any = null;
    public _sortItemArr: any[] = [];
    public _sortAes: number = 1;
    public _curSelectSortType: any = -1;
    public _allitemArr: any[] = [];
    public _allItemMap: Map = new Map;
    public _allItemDataMap: Map = new Map;
    public _allTeamViewMap: Map = new Map;
    public _myitemArr: any[] = [];
    public _myItemMap: Map = new Map;
    public _myItemDataMap: Map = new Map;
    public _myTeamViewMap: Map = new Map;
    public all_has_next_page: number = 0;
    public all_cur_page: number = 1;
    public _isSendMsg: boolean = false;
    public my_has_next_page: number = 0;
    public my_cur_page: number = 1;
    public curTab: number = 0;
    public tabWzColor: any[] = [color(147, 11, 11), color(102, 102, 102)];
    public _curTeamNum: number = 0;
    public _match_state: number = 1;
    public _lastNode: any = null;
    public _hasLoadMyMatch: boolean = false;
    public _hasLoadAllMatch: boolean = false;
    public _hasLoadStatCmp: boolean = false;
    public taskAwardIconMap: Map = new Map;
    public sortitem_select_color: any = color(151, 0, 0);
    public sortitem_unselect_color: any = color(10, 10, 10);
    public arrow_unselect_color: any = color(200, 200, 200);
    public filter_select_color: any = color(151, 0, 0);
    public _hasForceSignMatch: number = 0;
    public _forceSessionId: number = 0;
    onLoad() {
        PushCenter.shared().addListener(GameConfig.Update_Money, (e => {
            try {
                ToolUtils.isObjValid(this.node) && this.updateGold(e);
            }
            catch (e) {
                TLog.printError(this.TAG, GameConfig.Update_Money, e);
            }
        }), this);
        PushCenter.shared().addListener(PushEvent.Yes11SignOk, (e => {
            try {
                ToolUtils.isObjValid(this.node) && (this._hasLoadAllMatch = false, this._hasLoadMyMatch = false, this._hasForceSignMatch = 0, this._forceSessionId = 0, 0 == this.curTab ? (this.all_cur_page = 1, this.requestAllMatchList(false, true)) : (this.my_cur_page = 1, this.requestMyMatchList(false, true)));
            }
            catch (e) {
                TLog.printError(this.TAG, PushEvent.Yes11SignOk, e);
            }
        }), this);
        PushCenter.shared().addListener(PushEvent.commentDownloaderImg, (e => {
            try {
                if (sys.isObjectValid(this.node) && this.taskAwardIconMap.size > 0) {
                    for (const [t, i] of this.taskAwardIconMap) {
                        i == e && (sys.isObjectValid(t) ? Utils.shared().updateNetImage(t, e, size(88, 88)) : "team_icon0" != t.name && "team_icon1" != t.name || Utils.shared().updateNetImage(t, e, size(76, 76)));
                    }
                }
            }
            catch (e) {
                TLog.printError(this.TAG, PushEvent.commentDownloaderImg, e);
            }
        }), this);
        PushCenter.shared().addListener(PushEvent.RefreshYesGameTeamNum, (e => {
            try {
                if (ToolUtils.isObjValid(this.node)) {
                    this._curTeamNum = SportCricket_Manager.shared().cricket_curTeamNum;
                    let t = this.bottomNode.getChildByName("my_team_btn");
                    if (sys.isObjectValid(e)) {
                        if (sys.isObjectValid(e.not_in_lineup) && 1 == Number(e.not_in_lineup)) {
                            t.getChildByName("idot").active = true;
                            t.getChildByName("dot").active = false;
                        }
                        else if (sys.isObjectValid(e.not_in_lineup) && 0 == Number(e.not_in_lineup) && (t.getChildByName("idot").active = false, sys.isObjectValid(e.create_num) && Number(e.create_num) >= 1)) {
                            if (t.getChildByName("idot").active) {
                                return;
                            }
                            1 == SportCricket_Manager.shared().cricket_backup_open && (t.getChildByName("dot").active = true);
                        }
                    }
                }
            }
            catch (e) {
                TLog.printError(this.TAG, PushEvent.RefreshYesGameTeamNum, e);
            }
        }), this);
        PushCenter.shared().addListener(PushEvent.HideYes11BackkUpDot, (e => {
            try {
                if (ToolUtils.isObjValid(this.node)) {
                    let t = this.bottomNode.getChildByName("my_team_btn");
                    if (t.getChildByName("idot").active) {
                        return;
                    }
                    1 == SportCricket_Manager.shared().cricket_backup_open && (t.getChildByName("dot").active = 1 == Number(e));
                }
            }
            catch (e) {
                TLog.printError(this.TAG, PushEvent.HideYes11BackkUpDot, e);
            }
        }), this);
        PushCenter.shared().addListener(PushEvent.CricketForceSign_JoinMore, (e => {
            ToolUtils.isObjValid(this.node) && this.onBackView(true);
        }), this);
        PushCenter.shared().addListener(PushEvent.CricketForceSign_PlayRummy, (e => {
            ToolUtils.isObjValid(this.node) && this.onBackView(true);
        }), this);
        PushCenter.shared().addListener(PushEvent.NoticeNotInLineUpInGame, (e => {
            try {
                if (ToolUtils.isObjValid(this.node)) {
                    let t = this.bottomNode.getChildByName("my_team_btn");
                    1 == Number(e) ? (t.getChildByName("idot").active = true, t.getChildByName("dot").active = false) : t.getChildByName("idot").active = false;
                }
            }
            catch (e) {
                TLog.printError(this.TAG, PushEvent.NoticeNotInLineUpInGame, e);
            }
        }), this);
        this.fitLuckyTheme();
    }
    fitLuckyTheme() {
        0 != GameConfig.NATIVE_GAME_APP_TYPE && (this.sortitem_select_color = color(38, 59, 152), this.sortitem_unselect_color = color(102, 102, 102), this.arrow_unselect_color = color(102, 102, 102), this.tabWzColor = [color(221, 3, 3), color(102, 102, 102)], this.filter_select_color = color(38, 59, 152), this.rootNode.getChildByName("top_node").getChildByName("top_bg").getComponent(Sprite).color = color(12, 26, 60, 255), this.goldNode.getChildByName("coin").getComponent(Label).color = color(251, 220, 0, 255), this.tabNode.getChildByName("bg").getComponent(Sprite).color = color(250, 250, 250, 255), this.tabNode.getChildByName("tab0").getChildByName("line").getComponent(Sprite).color = this.tabWzColor[0], this.tabNode.getChildByName("tab1").getChildByName("line").getComponent(Sprite).color = this.tabWzColor[0], this.tabNode.getChildByName("tab2").getChildByName("line").getComponent(Sprite).color = this.tabWzColor[0]);
    }
    releaseData(e) {
        0 == e ? (this.all_listData = null, this._allItemDataMap.clear(), this._allItemMap.clear(), this._allTeamViewMap.clear(), this._allitemArr = null) : (this.my_listData = null, this._myItemDataMap.clear(), this._myItemMap.clear(), this._myTeamViewMap.clear(), this._myitemArr = null);
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().removeListenersByTag(this);
        this.unscheduleAllCallbacks();
        this.releaseData(0);
        this.releaseData(1);
    }
    init(e) {
        sys.isObjectValid(e) && sys.isObjectValid(e.match_id) && (this._match_id = e.match_id, SportCricket_Manager.shared().cricket_curMatchId = this._match_id);
        sys.isObjectValid(e) && sys.isObjectValid(e.source) && (this._source = { ...e.source });
        sys.isObjectValid(e) && sys.isObjectValid(e.lastNode) && (this._lastNode = e.lastNode);
    }
    start() {
        super.start();
        this.initView();
        this.updateGold(User.shared().data.money);
        this.bShowPushAnim ? ToolUtils.showPushAnim(this.node, 0, (() => {
            ToolUtils.isObjValid(this._lastNode) && (this._lastNode.active = false);
            this.refreshView();
        })) : this.refreshView();
    }
    requestAllMatchList(e = false, t = false) {
        let i = { page: this.all_cur_page, match_id: this._match_id, filter: this.dealSortParam(), force: User.shared().forceSignCricket };
        e && Utils.shared().showLoading(10, true, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
        }), ToolUtils.getIsNormalDirection());
        HttpManager.shared().doGetCommonRequest(i, HttpRequest.Yes11_AllContestList, ((e, t, i) => {
            if (Utils.shared().hideLoading(), 200 != i) {
                Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.request_fail"), 2);
                ToolUtils.isObjValid(this.node) && (this._isSendMsg = false, this.all_cur_page > 1 && (this.all_cur_page = this.all_cur_page - 1), (this.all_cur_page = 1) && this.allMatchScrollView.content.removeAllChildren());
            }
            else {
                try {
                    let e = ToolUtils.parseJson(t);
                    0 == e.ret ? sys.isObjectValid(e.data) && ToolUtils.isObjValid(this.node) && (this._isSendMsg = false, this.all_listData = [], sys.isObjectValid(e.data.list) && Array.isArray(e.data.list) && e.data.list.length > 0 && (this.all_listData = e.data.list), this.allMatchScrollView.content.removeAllChildren(), this.allMatchScrollView.scrollToTop(0), this.dealMatchView(this.all_listData, 0), this.allMatchScrollView.getComponent(ScrollVisibility).updateVisibility(), sys.isObjectValid(e.data.page) && (this.all_cur_page = e.data.page), sys.isObjectValid(e.data.has_next_page) && (this.all_has_next_page = e.data.has_next_page), this.all_listData.length > 0 ? this.rootNode.getChildByName("nodata").active = false : this.rootNode.getChildByName("nodata").active = true, sys.isObjectValid(e.data.team_num) && (this._curTeamNum = Number(e.data.team_num), this.bottomNode.getChildByName("my_team_btn").getChildByName("idot").active = false, this.bottomNode.getChildByName("my_team_btn").getChildByName("dot").active = false, this._curTeamNum > 0 && (sys.isObjectValid(e.data.not_in_lineup) && 1 == e.data.not_in_lineup ? this.bottomNode.getChildByName("my_team_btn").getChildByName("idot").active = true : (this.bottomNode.getChildByName("my_team_btn").getChildByName("idot").active = false, sys.isObjectValid(e.data.fill_backup) && 1 == e.data.fill_backup ? 1 == SportCricket_Manager.shared().cricket_backup_open && (this.bottomNode.getChildByName("my_team_btn").getChildByName("dot").active = true) : this.bottomNode.getChildByName("my_team_btn").getChildByName("dot").active = false)))) : ToolUtils.isObjValid(this.node) && (this.all_cur_page = 1) && (this.allMatchScrollView.content.removeAllChildren(), this.allMatchScrollView.scrollToTop(0));
                }
                catch (e) {
                    TLog.printError("requestAllMatchList err:", e.toString());
                }
            }
        }));
    }
    updateTabView() {
        this.tabNode.getChildByName("tab0").getChildByName("di").active = false;
        this.tabNode.getChildByName("tab1").getChildByName("di").active = false;
        this.tabNode.getChildByName("tab2").getChildByName("di").active = false;
        this.tabNode.getChildByName("tab0").getChildByName("line").active = 0 == this.curTab;
        this.tabNode.getChildByName("tab1").getChildByName("line").active = 1 == this.curTab;
        this.tabNode.getChildByName("tab2").getChildByName("line").active = 2 == this.curTab;
        0 == this.curTab ? (this.tabNode.getChildByName("tab0").getChildByName("Label").getComponent(Label).color = this.tabWzColor[0], this.tabNode.getChildByName("tab1").getChildByName("Label").getComponent(Label).color = this.tabWzColor[1], this.tabNode.getChildByName("tab2").getChildByName("Label").getComponent(Label).color = this.tabWzColor[1]) : 1 == this.curTab ? (this.tabNode.getChildByName("tab0").getChildByName("Label").getComponent(Label).color = this.tabWzColor[1], this.tabNode.getChildByName("tab1").getChildByName("Label").getComponent(Label).color = this.tabWzColor[0], this.tabNode.getChildByName("tab2").getChildByName("Label").getComponent(Label).color = this.tabWzColor[1]) : 2 == this.curTab && (this.tabNode.getChildByName("tab0").getChildByName("Label").getComponent(Label).color = this.tabWzColor[1], this.tabNode.getChildByName("tab1").getChildByName("Label").getComponent(Label).color = this.tabWzColor[1], this.tabNode.getChildByName("tab2").getChildByName("Label").getComponent(Label).color = this.tabWzColor[0]);
        i18nMgr.shared().changeLabelFont(this.tabNode.getChildByName("tab0").getChildByName("Label").getComponent(Label), 0 == this.curTab);
        i18nMgr.shared().changeLabelFont(this.tabNode.getChildByName("tab1").getChildByName("Label").getComponent(Label), 1 == this.curTab);
        i18nMgr.shared().changeLabelFont(this.tabNode.getChildByName("tab2").getChildByName("Label").getComponent(Label), 2 == this.curTab);
        let e = [];
        e.push(this.tabNode.getChildByName("tab0").getChildByName("line"));
        e.push(this.tabNode.getChildByName("tab1").getChildByName("line"));
        e.push(this.tabNode.getChildByName("tab2").getChildByName("line"));
        for (let t = 0; t < 3; t++) {
            if (this.curTab == t) {
                e[t].scale = v3(0, 1, 1);
                let i = TweenTool.scaleTo(e[t], 0.16, v3(1.1, 1, 1), null, false), a = TweenTool.scaleTo(e[t], 0.16, v3(1, 1, 1), null, false);
                TweenTool.sequence(e[t], true, null, i, a);
            }
            else {
                e[t].scale = v3(1, 1, 1);
            }
        }
    }
    updateGullakBtnStatus(e, t, i) {
        let a = this.rootNode.getChildByName("top_node").getChildByName("gullak_btn");
        if (ToolUtils.isObjValid(a) && (a.active = 1 == e, 1 == e)) {
            let e = a.getChildByName("anim").getComponent(sp.Skeleton);
            e.clearTracks();
            e.setToSetupPose();
            i ? (e.setAnimation(0, "2", false), e.setCompleteListener((() => {
                e.setCompleteListener(null);
                e.clearTracks();
                e.setToSetupPose();
                0 == t ? e.setAnimation(0, "0", true) : e.setAnimation(0, "1", true);
            }))) : 0 == t ? e.setAnimation(0, "0", true) : e.setAnimation(0, "1", true);
        }
    }
    requestMyMatchList(e = false, t = false) {
        let i = { page: this.my_cur_page, match_id: this._match_id };
        e && Utils.shared().showLoading(10, true, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
        }), ToolUtils.getIsNormalDirection());
        HttpManager.shared().doGetCommonRequest(i, HttpRequest.Yes11_MyContestList, ((e, t, i) => {
            if (Utils.shared().hideLoading(), 200 != i) {
                Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.request_fail"), 2);
                ToolUtils.isObjValid(this.node) && (this._isSendMsg = false, this.my_cur_page > 1 && (this.my_cur_page = this.my_cur_page - 1), (this.my_cur_page = 1) && this.myMatchScrollView.content.removeAllChildren());
            }
            else {
                try {
                    let e = ToolUtils.parseJson(t);
                    0 == e.ret ? sys.isObjectValid(e.data) && ToolUtils.isObjValid(this.node) && (this._isSendMsg = false, this.my_listData = [], sys.isObjectValid(e.data.list) && Array.isArray(e.data.list) && e.data.list.length > 0 && (this.my_listData = e.data.list), this.myMatchScrollView.content.removeAllChildren(), this.myMatchScrollView.scrollToTop(0), this.dealMatchView(this.my_listData, 1), this.myMatchScrollView.getComponent(ScrollVisibility).updateVisibility(), sys.isObjectValid(e.data.page) && (this.my_cur_page = e.data.page), sys.isObjectValid(e.data.has_next_page) && (this.my_has_next_page = e.data.has_next_page), this.my_listData.length > 0 ? this.rootNode.getChildByName("nodata").active = false : this.rootNode.getChildByName("nodata").active = true, sys.isObjectValid(e.data.team_num) && (this._curTeamNum = Number(e.data.team_num), this._curTeamNum > 0 && (sys.isObjectValid(e.data.not_in_lineup) && 1 == e.data.not_in_lineup ? this.bottomNode.getChildByName("my_team_btn").getChildByName("idot").active = true : (this.bottomNode.getChildByName("my_team_btn").getChildByName("idot").active = false, sys.isObjectValid(e.data.fill_backup) && 1 == e.data.fill_backup ? 1 == SportCricket_Manager.shared().cricket_backup_open && (this.bottomNode.getChildByName("my_team_btn").getChildByName("dot").active = true) : this.bottomNode.getChildByName("my_team_btn").getChildByName("dot").active = false)))) : ToolUtils.isObjValid(this.node) && (this.my_cur_page = 1) && (this.myMatchScrollView.content.removeAllChildren(), this.myMatchScrollView.scrollToTop(0));
                }
                catch (e) {
                    TLog.printError("requestMyMatchList err:", e.toString());
                }
            }
        }));
    }
    onArrowViewClick(e, t) {
        1 != this._hasForceSignMatch && (SoundManager.shared().playFx("click"), sys.now() - this._lastClick < 500 || (this._lastClick = sys.now(), 3 != this._match_state ? 4 != this._match_state ? this.dealArrowMatchView(Number(t)) : Utils.shared().showToast(i18nMgr.shared().getValueByKey("yes11.cancel_tip"), 2) : Utils.shared().showToast(i18nMgr.shared().getValueByKey("yes11.live_tip"), 2)));
    }
    dealArrowMatchView(e) {
        let t = null;
        if (0 == this.curTab ? this._allitemArr.length > e && (t = this._allitemArr[e]) : this._myitemArr.length > e && (t = this._myitemArr[e]), ToolUtils.isObjValid(t)) {
            if (t.getChildByName("main_node").getChildByName("sub_node").getChildByName("short_team_layout").active) {
                t.getChildByName("main_node").getChildByName("sub_node").getChildByName("short_team_layout").active = false;
                t.getChildByName("main_node").getChildByName("sub_node").getChildByName("arrow_btn").getChildByName("arrow").setScale(v3(1, -1));
                t.getChildByName("main_node").getChildByName("sub_node").getChildByName("full_team_layout").active = true;
                sys.isObjectValid(t.getChildByName("main_node").getChildByName("sub_node").getChildByName("full_team_layout").children) && 0 !== t.getChildByName("main_node").getChildByName("sub_node").getChildByName("full_team_layout").children.length || (1 == this.curTab ? this.addFullTeamView(t.getChildByName("main_node").getChildByName("sub_node").getChildByName("full_team_layout"), this.my_listData[e].self_sign_team, this.my_listData[e].session_id, e) : this.addFullTeamView(t.getChildByName("main_node").getChildByName("sub_node").getChildByName("full_team_layout"), this.all_listData[e].self_sign_team, this.all_listData[e].session_id, e), t.getChildByName("main_node").getChildByName("sub_node").getChildByName("full_team_layout").getComponent(Layout).updateLayout());
                let i = t.getChildByName("main_node").getChildByName("sub_node").getChildByName("full_team_layout").getComponent(UITransform).contentSize.height;
                t.getChildByName("bg").getComponent(UITransform).contentSize = size(672, 390 + i);
                t.getComponent(UITransform).contentSize = size(672, 390 + i);
                t.getChildByName("main_node").getComponent(UITransform).contentSize = size(672, 390 + i);
            }
            else {
                t.getChildByName("main_node").getChildByName("sub_node").getChildByName("short_team_layout").active = true;
                t.getChildByName("main_node").getChildByName("sub_node").getChildByName("full_team_layout").active = false;
                t.getChildByName("main_node").getChildByName("sub_node").getChildByName("arrow_btn").getChildByName("arrow").setScale(v3(1, 1));
                let e = t.getChildByName("main_node").getChildByName("sub_node").getChildByName("short_team_layout").getComponent(UITransform).contentSize.height;
                t.getChildByName("bg").getComponent(UITransform).contentSize = size(672, 390 + e);
                t.getComponent(UITransform).contentSize = size(672, 390 + e);
                t.getChildByName("main_node").getComponent(UITransform).contentSize = size(672, 390 + e);
            }
        }
    }
    updateFullItemMsgInView(e, t) {
        if (sys.isObjectValid(t.teama_num) && String(t.teama_num).length > 0 && (e.getChildByName("team_num0").getComponent(Label).string = t.teama_num), sys.isObjectValid(t.teamb_num) && String(t.teamb_num).length > 0 && (e.getChildByName("team_num1").getComponent(Label).string = t.teamb_num), sys.isObjectValid(t.members) && Array.isArray(t.members) && t.members.length > 0) {
            for (let i = 0; i < t.members.length; i++) {
                let a = t.members[i];
                1 == Number(a.captain_role) ? (e.getChildByName("cap_node0").getChildByName("wz").getComponent(Label).string = a.short_name, a.out_team_id == t.teama_id ? (e.getChildByName("cap_node0").getChildByName("bg").getComponent(Sprite).spriteFrame = this.capBgImgs[0], e.getChildByName("cap_node0").getChildByName("wz").getComponent(Label).color = color(255, 255, 255), e.getChildByName("cap_node0").getChildByName("flag").getChildByName("wz").getComponent(Label).color = color(255, 255, 255), e.getChildByName("cap_node0").getChildByName("flag").getComponent(Sprite).spriteFrame = this.operateImgs[0]) : (e.getChildByName("cap_node0").getChildByName("bg").getComponent(Sprite).spriteFrame = this.capBgImgs[1], e.getChildByName("cap_node0").getChildByName("wz").getComponent(Label).color = color(51, 51, 51), e.getChildByName("cap_node0").getChildByName("flag").getChildByName("wz").getComponent(Label).color = color(51, 51, 51), e.getChildByName("cap_node0").getChildByName("flag").getComponent(Sprite).spriteFrame = this.operateImgs[1]), sys.isObjectValid(a.thumb_url) && a.thumb_url.length > 0 && (this.taskAwardIconMap.set(e.getChildByName("cap_node0").getChildByName("player_icon"), a.thumb_url), Utils.shared().updateNetImage(e.getChildByName("cap_node0").getChildByName("player_icon"), a.thumb_url, size(88, 88)))) : 2 == Number(a.captain_role) && (e.getChildByName("cap_node1").getChildByName("wz").getComponent(Label).string = a.short_name, a.out_team_id == t.teama_id ? (e.getChildByName("cap_node1").getChildByName("bg").getComponent(Sprite).spriteFrame = this.capBgImgs[0], e.getChildByName("cap_node1").getChildByName("wz").getComponent(Label).color = color(255, 255, 255), e.getChildByName("cap_node1").getChildByName("flag").getChildByName("wz").getComponent(Label).color = color(255, 255, 255), e.getChildByName("cap_node1").getChildByName("flag").getComponent(Sprite).spriteFrame = this.operateImgs[0]) : (e.getChildByName("cap_node1").getChildByName("bg").getComponent(Sprite).spriteFrame = this.capBgImgs[1], e.getChildByName("cap_node1").getChildByName("wz").getComponent(Label).color = color(51, 51, 51), e.getChildByName("cap_node1").getChildByName("flag").getChildByName("wz").getComponent(Label).color = color(51, 51, 51), e.getChildByName("cap_node1").getChildByName("flag").getComponent(Sprite).spriteFrame = this.operateImgs[1]), sys.isObjectValid(a.thumb_url) && a.thumb_url.length > 0 && (this.taskAwardIconMap.set(e.getChildByName("cap_node1").getChildByName("player_icon"), a.thumb_url), Utils.shared().updateNetImage(e.getChildByName("cap_node1").getChildByName("player_icon"), a.thumb_url, size(88, 88))));
            }
        }
    }
    updateFullItemView(e, t) {
        let i = ToolUtils.toJsonString(t);
        if (e.getChildByName("bg").getComponent(Button).clickEvents[0].customEventData = i, e.getChildByName("edit_btn").getComponent(Button).clickEvents[0].customEventData = i, e.getChildByName("switch_btn").getComponent(Button).clickEvents[0].customEventData = i, e.getChildByName("backup_btn").getComponent(Button).clickEvents[0].customEventData = i, e.getChildByName("backup_btn").getChildByName("dot").active = false, e.getChildByName("red_diban").active = false, sys.isObjectValid(t.fill_backup) && 1 == t.fill_backup && (1 == SportCricket_Manager.shared().cricket_backup_open ? (e.getChildByName("backup_btn").getChildByName("dot").active = true, e.getChildByName("backup_btn").active = true) : e.getChildByName("backup_btn").active = false), sys.isObjectValid(t.can_switch) && 1 == t.can_switch ? e.getChildByName("switch_btn").active = true : e.getChildByName("switch_btn").active = false, sys.isObjectValid(t.not_in_lineup_num) && t.not_in_lineup_num > 0) {
            e.getChildByName("red_diban").active = true;
            e.getChildByName("red_diban").getChildByName("edit_arrow").getComponent(Button).clickEvents[0].customEventData = ToolUtils.toJsonString(t);
            e.getComponent(UITransform).contentSize = size(644, 290);
            let i = ToolUtils.format(i18nMgr.shared().getValueByKey("yes11.lineup_tip"), t.not_in_lineup_num);
            e.getChildByName("red_diban").getChildByName("red_wz").getComponent(Label).string = i;
        }
        sys.isObjectValid(t.name) && t.name.length > 0 && (e.getChildByName("name").getComponent(Label).string = t.name);
        sys.isObjectValid(t.teama_short_name) && String(t.teama_short_name).length > 0 && (e.getChildByName("team_name0").getComponent(Label).string = t.teama_short_name);
        sys.isObjectValid(t.teamb_short_name) && String(t.teamb_short_name).length > 0 && (e.getChildByName("team_name1").getComponent(Label).string = t.teamb_short_name);
        this.updateFullItemMsgInView(e, t);
    }
    addFullTeamView(e, t, i, a) {
        if (ToolUtils.isObjValid(e) && sys.isObjectValid(t)) {
            for (let s = 0; s < t.length; s++) {
                let o = instantiate(this.fullteam_mobanView);
                o.active = true;
                e.addChild(o);
                t[s].session_id = i;
                t[s].session_index = a;
                1 == this.curTab ? (t[s].can_switch = this.my_listData[a].can_switch, this._myTeamViewMap.has(String(t[s].team_id)) ? this._myTeamViewMap.get(String(t[s].team_id)).push(o) : this._myTeamViewMap.set(String(t[s].team_id), [o])) : (t[s].can_switch = this.all_listData[a].can_switch, this._allTeamViewMap.has(String(t[s].team_id)) ? this._allTeamViewMap.get(String(t[s].team_id)).push(o) : this._allTeamViewMap.set(String(t[s].team_id), [o]));
                this.updateFullItemView(o, t[s]);
            }
        }
    }
    onPreviewClick(e, t) {
        if (1 == this._hasForceSignMatch) {
            return;
        }
        if (SoundManager.shared().playFx("click"), sys.now() - this._lastClick < 500) {
            return;
        }
        this._lastClick = sys.now();
        let i = ToolUtils.parseJson(t), a = { match_id: this._match_id, team_id: i.team_id };
        SportCricket_Manager.shared().dealShowPreviewTeamLogic(a, this.node);
    }
    onBackUpTeamClick(e, t) {
        if (1 == this._hasForceSignMatch) {
            return;
        }
        if (SoundManager.shared().playFx("click"), sys.now() - this._lastClick < 500) {
            return;
        }
        if (this._lastClick = sys.now(), 3 == this._match_state) {
            return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("yes11.live_tip"), 2);
        }
        if (4 == this._match_state) {
            return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("yes11.cancel_tip"), 2);
        }
        let i = ToolUtils.parseJson(t), a = { match_id: this._match_id, team_id: i.team_id };
        SportCricket_Manager.shared().requestYes11_PreCreateTeamCheck(a, true, (e => {
            let t = { source: this._source, match_id: this._match_id, player_source: e, team_id: i.team_id, fromType: 3, lastNode: this.node, call: e => {
                    this.dealBackUpTeam(e);
                } };
            Utils.shared().showSportCricket_backUpPlayers(t);
        }));
    }
    dealBackUpTeam(e) {
        if (this._myTeamViewMap.has(String(e))) {
            let t = this._myTeamViewMap.get(String(e));
            if (sys.isObjectValid(t) && Array.isArray(t)) {
                for (let e = 0; e < t.length; e++) {
                    let i = t[e];
                    ToolUtils.isObjValid(i) && (i.getChildByName("backup_btn").getChildByName("dot").active = false);
                }
            }
        }
        if (this._allTeamViewMap.has(String(e))) {
            let t = this._allTeamViewMap.get(String(e));
            if (sys.isObjectValid(t) && Array.isArray(t)) {
                for (let e = 0; e < t.length; e++) {
                    let i = t[e];
                    ToolUtils.isObjValid(i) && (i.getChildByName("backup_btn").getChildByName("dot").active = false);
                }
            }
        }
    }
    onSwitchTeamClick(e, t) {
        if (1 == this._hasForceSignMatch) {
            return;
        }
        if (SoundManager.shared().playFx("click"), sys.now() - this._lastClick < 500) {
            return;
        }
        if (this._lastClick = sys.now(), 3 == this._match_state) {
            return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("yes11.live_tip"), 2);
        }
        if (4 == this._match_state) {
            return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("yes11.cancel_tip"), 2);
        }
        let i = ToolUtils.parseJson(t), a = { match_id: this._match_id, team_id: i.team_id, contest_id: i.session_id };
        SportCricket_Manager.shared().requestYes11_JoinList(a, true, (e => {
            let t = { match_id: this._match_id, contest_id: i.session_id, teamlistData: e, curTeam: i, call: e => {
                    this.dealSwitchTeam(e);
                } };
            Utils.shared().showSportCricket_switchList(t);
        }));
    }
    switchTeamLogic(e, t, i) {
        let a = e.getChildByName("main_node").getChildByName("sub_node").getChildByName("short_team_layout"), s = e.getChildByName("main_node").getChildByName("sub_node").getChildByName("full_team_layout"), o = null;
        if (o = 1 == i ? this._myItemDataMap.get(String(t.session_id)) : this._allItemDataMap.get(String(t.session_id)), sys.isObjectValid(o)) {
            for (let e = 0; e < o.self_sign_team.length; e++) {
                if (o.self_sign_team[e].team_id == t.target_team_id && sys.isObjectValid(a.children)) {
                    if (e < a.children.length) {
                        let i = a.children[e];
                        sys.isObjectValid(i) && (i.getChildByName("wz").getComponent(Label).string = t.switch_teamInfo.short_name);
                    }
                    if (e < s.children.length) {
                        let i = s.children[e];
                        sys.isObjectValid(i) && (t.switch_teamInfo.session_id = t.session_id, t.switch_teamInfo.can_switch = o.can_switch, this.updateFullItemView(i, t.switch_teamInfo));
                    }
                }
            }
        }
    }
    dealSwitchTeam(e) {
        if (sys.isObjectValid(e) && sys.isObjectValid(e.session_id)) {
            if (this._myItemMap.has(String(e.session_id))) {
                let t = this._myItemMap.get(String(e.session_id));
                sys.isObjectValid(t) && this.switchTeamLogic(t, e, 1);
            }
            if (this._allItemMap.has(String(e.session_id))) {
                let t = this._allItemMap.get(String(e.session_id));
                sys.isObjectValid(t) && this.switchTeamLogic(t, e, 0);
            }
            if (sys.isObjectValid(e.not_in_lineup)) {
                let t = this.bottomNode.getChildByName("my_team_btn");
                1 == Number(e.not_in_lineup) ? (t.getChildByName("idot").active = true, t.getChildByName("dot").active = false) : (t.getChildByName("idot").active = false, t.getChildByName("dot").active = false, 1 == Number(e.fill_back_up) && (t.getChildByName("dot").active = true));
            }
        }
    }
    onEditTeamClick(e, t) {
        if (1 == this._hasForceSignMatch) {
            return;
        }
        if (SoundManager.shared().playFx("click"), sys.now() - this._lastClick < 500) {
            return;
        }
        if (this._lastClick = sys.now(), 3 == this._match_state) {
            return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("yes11.live_tip"), 2);
        }
        if (4 == this._match_state) {
            return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("yes11.cancel_tip"), 2);
        }
        let i = ToolUtils.parseJson(t), a = i.session_index, s = { match_id: this._match_id, team_id: i.team_id };
        SportCricket_Manager.shared().requestYes11_PreCreateTeamCheck(s, true, (e => {
            let t = { source: this._source, match_id: this._match_id, player_source: e, team_id: i.team_id, fromType: 3, lastNode: this.node, call: e => {
                    sys.isObjectValid(e) && (e.session_index = a);
                    this.dealEditTeam(e);
                } };
            Utils.shared().showSportCricket_createTeam(t);
        }));
    }
    updateEditTeam(e, t, i) {
        if (sys.isObjectValid(t) && Array.isArray(t)) {
            for (let i = 0; i < t.length; i++) {
                let a = t[i];
                if (ToolUtils.isObjValid(a)) {
                    if (11 == e.lineUpNum || -1 == e.lineUpNum) {
                        if (a.getChildByName("red_diban").active) {
                            let e = a.getComponent(UITransform).contentSize;
                            a.getComponent(UITransform).contentSize = size(e.width, e.height - 58);
                        }
                        a.getChildByName("red_diban").active = false;
                    }
                    else {
                        if (!a.getChildByName("red_diban").active) {
                            let e = a.getComponent(UITransform).contentSize;
                            a.getComponent(UITransform).contentSize = size(e.width, e.height + 58);
                        }
                        a.getChildByName("red_diban").active = true;
                        let t = ToolUtils.format(i18nMgr.shared().getValueByKey("yes11.lineup_tip"), 11 - e.lineUpNum);
                        a.getChildByName("red_diban").getChildByName("red_wz").getComponent(Label).string = t;
                    }
                    this.updateFullItemMsgInView(a, e.teamInfo);
                }
            }
        }
    }
    dealEditTeam(e) {
        if (sys.isObjectValid(e) && sys.isObjectValid(e.team_id) && sys.isObjectValid(e.lineUpNum)) {
            if (this._myTeamViewMap.has(String(e.team_id))) {
                let t = this._myTeamViewMap.get(String(e.team_id));
                this.updateEditTeam(e, t, 1);
            }
            if (this._allTeamViewMap.has(String(e.team_id))) {
                let t = this._allTeamViewMap.get(String(e.team_id));
                this.updateEditTeam(e, t, 0);
            }
            for (let t = 0; t < this.my_listData.length; t++) {
                if (sys.isObjectValid(this.my_listData[t].self_sign_team) && Array.isArray(this.my_listData[t].self_sign_team)) {
                    let i = false;
                    for (let a = 0; a < this.my_listData[t].self_sign_team.length; a++) {
                        Number(this.my_listData[t].self_sign_team[a].team_id) == Number(e.team_id) && (this.my_listData[t].self_sign_team[a].teama_num = e.teamInfo.teama_num, this.my_listData[t].self_sign_team[a].teamb_num = e.teamInfo.teamb_num, this.my_listData[t].self_sign_team[a].members = e.teamInfo.members, i = true);
                    }
                    try {
                        i && this.updateSessionViewSize(t, 1);
                    }
                    catch (e) {
                        TLog.printError(this.TAG, "dealEditTeam_1:", e);
                    }
                }
            }
            for (let t = 0; t < this.all_listData.length; t++) {
                if (sys.isObjectValid(this.all_listData[t].self_sign_team) && Array.isArray(this.all_listData[t].self_sign_team)) {
                    let i = false;
                    for (let a = 0; a < this.all_listData[t].self_sign_team.length; a++) {
                        Number(this.all_listData[t].self_sign_team[a].team_id) == Number(e.team_id) && (this.all_listData[t].self_sign_team[a].teama_num = e.teamInfo.teama_num, this.all_listData[t].self_sign_team[a].teamb_num = e.teamInfo.teamb_num, this.all_listData[t].self_sign_team[a].members = e.teamInfo.members, i = true);
                    }
                    try {
                        i && this.updateSessionViewSize(t, 0);
                    }
                    catch (e) {
                        TLog.printError(this.TAG, "dealEditTeam_2:", e);
                    }
                }
            }
        }
    }
    updateSessionViewSize(e, t) {
        let i = null;
        if (1 == t && this._myitemArr.length > e ? i = this._myitemArr[e] : 0 == t && this._allitemArr.length > e && (i = this._allitemArr[e]), ToolUtils.isObjValid(i) && i.getChildByName("main_node").getChildByName("sub_node").getChildByName("full_team_layout").active) {
            i.getChildByName("main_node").getChildByName("sub_node").getChildByName("full_team_layout").getComponent(Layout).updateLayout();
            let e = i.getChildByName("main_node").getChildByName("sub_node").getChildByName("full_team_layout").getComponent(UITransform).contentSize.height;
            i.getChildByName("bg").getComponent(UITransform).contentSize = size(672, 250 + e);
            i.getComponent(UITransform).contentSize = size(672, 250 + e);
        }
    }
    dealMatchView(e, t) {
        1 == t ? (this._myitemArr = [], this._myItemMap.clear(), this._myItemDataMap.clear(), this._hasLoadMyMatch = true, this._myTeamViewMap.clear(), this.myMatchScrollView.content.removeAllChildren()) : (this._allitemArr = [], this._allItemMap.clear(), this._allItemDataMap.clear(), this._hasLoadAllMatch = true, this._allTeamViewMap.clear(), this.allMatchScrollView.content.removeAllChildren());
        this._hasForceSignMatch = 0;
        for (let i = 0; i < e.length; i++) {
            let a = instantiate(this.my_mobanView);
            a.active = true;
            e[i].tabType = t;
            this.initMatchItem(a, e[i], i, t);
            1 == t ? (this._myitemArr.push(a), this._myItemMap.set(String(e[i].session_id), a), this._myItemDataMap.set(String(e[i].session_id), e[i]), this.myMatchScrollView.content.addChild(a)) : (this._allitemArr.push(a), this._allItemMap.set(String(e[i].session_id), a), this._allItemDataMap.set(String(e[i].session_id), e[i]), this.allMatchScrollView.content.addChild(a));
        }
    }
    refreshPos(e) {
        e.getChildByName("main_node").getChildByName("pool2").getComponent(Label).updateRenderData(true);
        e.getChildByName("main_node").getChildByName("prize_desc").getComponent(Label).updateRenderData(true);
        let t = v3(0, 0);
        e.getChildByName("main_node").getChildByName("pool2").getPosition(t);
        let i = e.getChildByName("main_node").getChildByName("pool2").getComponent(UITransform).contentSize.width;
        e.getChildByName("main_node").getChildByName("pool2_arrow").setPosition(v3(t.x + i + 10, -287.772));
        e.getChildByName("main_node").getChildByName("prize_icon").setPosition(v3(t.x + i + 30, -287.511));
        e.getChildByName("main_node").getChildByName("prize_desc").setPosition(v3(t.x + i + 30 + 20, -287.511));
        let a = v3(0, 0);
        e.getChildByName("main_node").getChildByName("prize_desc").getPosition(a);
        i = e.getChildByName("main_node").getChildByName("prize_desc").getComponent(UITransform).contentSize.width;
        e.getChildByName("main_node").getChildByName("prize_arrow").setPosition(v3(a.x + i + 10, -287.772));
        e.getChildByName("main_node").getChildByName("m_icon").setPosition(v3(a.x + i + 30, -287.511));
        e.getChildByName("main_node").getChildByName("m_desc").setPosition(v3(a.x + i + 30 + 20, -287.511));
        e.getChildByName("main_node").getChildByName("pool").getComponent(Label).updateRenderData(true);
        let s = v3(0, 0);
        e.getChildByName("main_node").getChildByName("pool").getPosition(s);
        i = e.getChildByName("main_node").getChildByName("pool").getComponent(UITransform).contentSize.width;
        e.getChildByName("main_node").getChildByName("pool_arrow").setPosition(v3(s.x + i + 10, -106.776));
    }
    initMatchItem(e, t, i, a) {
        if (e.active = true, sys.isObjectValid(t.name) && t.name.length > 0 && (e.getChildByName("main_node").getChildByName("title").getComponent(Label).string = t.name), sys.isObjectValid(t.all_reward) && (sys.isObjectValid(t.is_chip) && 1 == t.is_chip ? (e.getChildByName("main_node").getChildByName("pool").getComponent(Label).string = String(t.all_reward), e.getChildByName("main_node").getChildByName("pool2").getComponent(Label).string = String(t.first_reward), e.getChildByName("main_node").getChildByName("chip").active = true, e.getChildByName("main_node").getChildByName("cashbg").active = false) : (e.getChildByName("main_node").getChildByName("pool").getComponent(Label).string = "₹" + String(t.all_reward), e.getChildByName("main_node").getChildByName("pool2").getComponent(Label).string = "₹" + String(t.first_reward), e.getChildByName("main_node").getChildByName("chip").active = false, e.getChildByName("main_node").getChildByName("cashbg").active = true)), sys.isObjectValid(t.left_sign_num) && sys.isObjectValid(t.sign_num) && (e.getChildByName("main_node").getChildByName("progress").getComponent(ProgressBar).progress = (t.sign_num - t.left_sign_num) / t.sign_num), sys.isObjectValid(t.fee) && (sys.isObjectValid(t.is_chip) && 1 == t.is_chip ? (e.getChildByName("main_node").getChildByName("status_btn").getChildByName("node").getChildByName("wz").getComponent(Label).string = t.fee, e.getChildByName("main_node").getChildByName("status_btn").getChildByName("node").getChildByName("ico").active = true) : (0 == t.fee ? e.getChildByName("main_node").getChildByName("status_btn").getChildByName("node").getChildByName("wz").getComponent(Label).string = "FREE" : e.getChildByName("main_node").getChildByName("status_btn").getChildByName("node").getChildByName("wz").getComponent(Label).string = "₹" + t.fee, e.getChildByName("main_node").getChildByName("status_btn").getChildByName("node").getChildByName("ico").active = false)), e.getChildByName("main_node").getChildByName("jiangchi_node").getComponent(Button).clickEvents[0].customEventData = ToolUtils.toJsonString(t), e.getComponent(Button).clickEvents[0].customEventData = ToolUtils.toJsonString(t), e.getChildByName("main_node").getChildByName("status_btn").getComponent(Button).clickEvents[0].customEventData = ToolUtils.toJsonString(t), sys.isObjectValid(t.type) && 3 == t.type ? (e.getChildByName("main_node").getChildByName("jiangchi_node").getChildByName("amt").getComponent(Label).string = "₹" + ToolUtils.parse_double(t.last_all_reward), e.getChildByName("main_node").getChildByName("jiangchi_node").getComponent(Layout).updateLayout(), t.last_all_reward != t.all_reward ? e.getChildByName("main_node").getChildByName("jiangchi_node").active = true : e.getChildByName("main_node").getChildByName("jiangchi_node").active = false) : e.getChildByName("main_node").getChildByName("jiangchi_node").active = false, sys.isObjectValid(t.left_sign_num) && (e.getChildByName("main_node").getChildByName("left_desc1").getComponent(Label).string = t.left_sign_num + " Left"), sys.isObjectValid(t.sign_num) && (e.getChildByName("main_node").getChildByName("left_desc2").getComponent(Label).string = t.sign_num + " Spots"), sys.isObjectValid(t.reward_rate) && (e.getChildByName("main_node").getChildByName("prize_desc").getComponent(Label).string = t.reward_rate), sys.isObjectValid(t.person_sign_num) && (t.person_sign_num > 1 ? (e.getChildByName("main_node").getChildByName("m_icon").getComponent(Sprite).spriteFrame = this.iconImgs[0], e.getChildByName("main_node").getChildByName("m_desc").getComponent(Label).string = ToolUtils.format(i18nMgr.shared().getValueByKey("yes11.upto"), t.person_sign_num)) : (e.getChildByName("main_node").getChildByName("m_icon").getComponent(Sprite).spriteFrame = this.iconImgs[1], e.getChildByName("main_node").getChildByName("m_desc").getComponent(Label).string = t.m_desc, e.getChildByName("main_node").getChildByName("m_desc").getComponent(Label).string = ToolUtils.format(i18nMgr.shared().getValueByKey("yes11.no_team"), t.person_sign_num))), sys.isObjectValid(t.self_sign_team) && Array.isArray(t.self_sign_team) && t.self_sign_team.length > 0) {
            e.getChildByName("main_node").getChildByName("sub_node").active = true;
            e.getChildByName("main_node").getChildByName("sub_node").getChildByName("short_team_layout").active = true;
            e.getChildByName("main_node").getChildByName("sub_node").getChildByName("full_team_layout").active = true;
            e.getChildByName("main_node").getChildByName("team_num_tip").active = true;
            e.getChildByName("main_node").getChildByName("sub_node").getChildByName("arrow_btn").getComponent(Button).clickEvents[0].customEventData = String(i);
            e.getChildByName("main_node").getChildByName("team_num_tip").getChildByName("wz").getComponent(Label).string = String(t.self_sign_team.length);
            for (let i = 0; i < t.self_sign_team.length; i++) {
                let a = instantiate(this.shortteam_mobanView);
                a.active = true;
                e.getChildByName("main_node").getChildByName("sub_node").getChildByName("short_team_layout").addChild(a);
                a.getChildByName("wz").getComponent(Label).string = t.self_sign_team[i].short_name;
            }
            e.getChildByName("main_node").getChildByName("sub_node").getChildByName("short_team_layout").updateWorldTransform();
            e.getChildByName("main_node").getChildByName("sub_node").getChildByName("join_num").getComponent(Label).string = ToolUtils.format(i18nMgr.shared().getValueByKey("yes11.join_team2"), t.self_sign_team.length);
            let a = Math.ceil(t.self_sign_team.length / 7), s = 40 * a + 5 * (a - 1);
            e.getChildByName("bg").getComponent(UITransform).contentSize = size(672, 390 + s);
            e.getComponent(UITransform).contentSize = size(672, 390 + s);
            e.getChildByName("main_node").getComponent(UITransform).contentSize = size(672, 390 + s);
        }
        else {
            e.getChildByName("main_node").getChildByName("sub_node").active = false;
            e.getChildByName("bg").getComponent(UITransform).contentSize = size(672, 320);
            e.getComponent(UITransform).contentSize = size(672, 320);
            e.getChildByName("main_node").getComponent(UITransform).contentSize = size(672, 320);
        }
        if (this.refreshPos(e), 1 == User.shared().forceSignCricket && sys.isObjectValid(t.force) && 1 == t.force) {
            let i = instantiate(this.fingerNode);
            i.active = true;
            i.parent = e.getChildByName("main_node").getChildByName("status_btn");
            i.setPosition(v3(73, -26));
            let a = i.getComponent(sp.Skeleton);
            a.clearTracks();
            a.setAnimation(0, "click", true);
            this._hasForceSignMatch = 1;
            this._forceSessionId = Number(t.session_id);
        }
    }
    refreshView() {
        this.rootNode.getChildByName("nodata").active = false;
        this.curTab = 0;
        this.updateTabView();
        this.updateTabContent();
        this._hasLoadStatCmp || 1 != SportCricket_Manager.shared().cricket_teamStatsOpen ? this._hasLoadStatCmp || (this._hasLoadStatCmp = true, TweenTool.delayAct(this.node, (() => {
            ToolUtils.preLoadBundlePrefab(BundleNameDefined.Bundle_Yes11, "prefab/cricket_createteam", null);
            ToolUtils.preLoadBundlePrefab(BundleNameDefined.Bundle_Yes11, "prefab/cricket_gamedetails", null);
        }), 2, true)) : (this._hasLoadStatCmp = true, TweenTool.delayAct(this.node, (() => {
            ToolUtils.preLoadBundlePrefab(BundleNameDefined.Bundle_Yes11, "prefab/cricket_teamstatscmp", null);
            ToolUtils.preLoadBundlePrefab(BundleNameDefined.Bundle_Yes11, "prefab/cricket_createteam", null);
            ToolUtils.preLoadBundlePrefab(BundleNameDefined.Bundle_Yes11, "prefab/cricket_gamedetails", null);
        }), 2, true));
        this.updateSortRoot();
        this.updateContestDetails();
    }
    updateContestDetails() {
        let e = this._source.teama, t = this._source.teamb;
        sys.isObjectValid(e.short_name) && e.short_name.length > 0 && (this.topNode.getChildByName("team_short_name0").getComponent(Label).string = e.short_name);
        sys.isObjectValid(t.short_name) && t.short_name.length > 0 && (this.topNode.getChildByName("team_short_name1").getComponent(Label).string = t.short_name);
        sys.isObjectValid(e.logo_url) && e.logo_url.length > 0 && (this.taskAwardIconMap.set(this.topNode.getChildByName("team_icon0"), e.logo_url), Utils.shared().updateNetImage(this.topNode.getChildByName("team_icon0"), e.logo_url, size(76, 76)));
        sys.isObjectValid(t.logo_url) && t.logo_url.length > 0 && (this.taskAwardIconMap.set(this.topNode.getChildByName("team_icon1"), t.logo_url), Utils.shared().updateNetImage(this.topNode.getChildByName("team_icon1"), t.logo_url, size(76, 76)));
        sys.isObjectValid(this._source.location) && this._source.location.length > 0 && (this.topNode.getChildByName("location").getComponent(Label).string = this._source.location);
    }
    updateSortRoot() {
        if (sys.isObjectValid(SportCricket_Manager.shared().sortSourceData) && sys.isObjectValid(SportCricket_Manager.shared().sortSourceData.contest)) {
            let e = SportCricket_Manager.shared().sortSourceData.contest.length, t = this.sortNode.getChildByName("sort_scrollview").getComponent(ScrollView);
            for (let i = 0; i < e; i++) {
                let e = -1, a = SportCricket_Manager.shared().sortSourceData.contest[i];
                if (sys.isObjectValid(a) && sys.isObjectValid(a.show_enter) && (e = a.show_enter), 1 == e || 2 == e) {
                    let e = instantiate(this.sortMoban);
                    e.active = true;
                    e.getChildByName("root").getChildByName("wz").getComponent(Label).string = a.name;
                    e.getChildByName("root").getChildByName("wz").getComponent(Label).updateRenderData(true);
                    e.getChildByName("root").getComponent(Layout).updateLayout(true);
                    let i = e.getChildByName("root").getChildByName("wz").getComponent(UITransform).contentSize.width;
                    e.getComponent(UITransform).contentSize = size(i + 60, 50);
                    e.getChildByName("ico").getComponent(UITransform).contentSize = size(i + 60, 50);
                    t.content.addChild(e);
                    e.getChildByName("root").getChildByName("arrow").active = true;
                    e.getComponent(Button).clickEvents[0].customEventData = a.type;
                    e.ext_info = a.type;
                    this._sortItemArr.push(e);
                    this.updateSortItemStatus(e, 0);
                }
            }
        }
    }
    updateSortItemStatus(e, t) {
        ToolUtils.isObjValid(e) && (1 == t ? (e.getChildByName("ico").getComponent(Sprite).spriteFrame = this.sortBgImgs[1], e.getChildByName("root").getChildByName("wz").getComponent(Label).color = this.sortitem_select_color, e.getChildByName("root").getChildByName("arrow").active = true, 1 == this._sortAes ? (e.getChildByName("root").getChildByName("arrow").getChildByName("ico0").getComponent(Sprite).color = this.arrow_unselect_color, e.getChildByName("root").getChildByName("arrow").getChildByName("ico1").getComponent(Sprite).color = this.sortitem_select_color) : (e.getChildByName("root").getChildByName("arrow").getChildByName("ico1").getComponent(Sprite).color = this.arrow_unselect_color, e.getChildByName("root").getChildByName("arrow").getChildByName("ico0").getComponent(Sprite).color = this.sortitem_select_color)) : (e.getChildByName("ico").getComponent(Sprite).spriteFrame = this.sortBgImgs[0], e.getChildByName("root").getChildByName("wz").getComponent(Label).color = this.sortitem_unselect_color, e.getChildByName("root").getChildByName("arrow").active = true, e.getChildByName("root").getChildByName("arrow").getChildByName("ico1").getComponent(Sprite).color = this.arrow_unselect_color, e.getChildByName("root").getChildByName("arrow").getChildByName("ico0").getComponent(Sprite).color = this.arrow_unselect_color));
    }
    updateFilterBtnStatus() {
        let e = this.sortNode.getChildByName("filter_btn");
        sys.isObjectValid(this.sortFilterInfo) ? (e.getChildByName("wz").getComponent(Label).color = this.filter_select_color, e.getChildByName("ico").getComponent(Sprite).color = this.filter_select_color) : (e.getChildByName("wz").getComponent(Label).color = color(102, 102, 102), e.getChildByName("ico").getComponent(Sprite).color = color(102, 102, 102));
    }
    dealSortParam() {
        if (sys.isObjectValid(this.sortFilterInfo)) {
            let e = [], t = false, i = ToolUtils.parseJson(ToolUtils.toJsonString(this.sortFilterInfo));
            for (let a = 0; a < i.length; a++) {
                let s = i[a];
                s.type == this._curSelectSortType && (s.sort = this._sortAes, t = true);
                e.push(s);
            }
            return t || -1 == this._curSelectSortType || e.push({ type: this._curSelectSortType, sort: this._sortAes }), ToolUtils.toJsonString(e);
        }
        if (-1 == this._curSelectSortType) {
            return "";
        }
        {
            let e = [{ type: this._curSelectSortType, sort: this._sortAes }];
            return ToolUtils.toJsonString(e);
        }
    }
    onShowJiangChiClick(e, t) {
        if (1 == this._hasForceSignMatch) {
            return;
        }
        if (SoundManager.shared().playFx("click"), sys.now() - this._lastClick < 500) {
            return;
        }
        this._lastClick = sys.now();
        let i = ToolUtils.parseJson(t), a = { match_id: this._match_id, contest_id: i.session_id, contest_source: i, source: this._source, lastNode: this.rootNode, fromType: 0 };
        Utils.shared().showSportCricket_plusJiangChi(a);
    }
    onChooseItemCheckClick(e, t) {
        if (1 != this._hasForceSignMatch && (SoundManager.shared().playFx("click"), !(sys.now() - this._lastClick < 500))) {
            if (this._lastClick = sys.now(), Number(t) == this._curSelectSortType) {
                0 == this._sortAes ? this._sortAes = 1 : this._sortAes = 0;
                for (let e = 0; e < this._sortItemArr.length; e++) {
                    let t = this._sortItemArr[e];
                    ToolUtils.isObjValid(t) && sys.isObjectValid(t.ext_info) && (t.ext_info == this._curSelectSortType ? this.updateSortItemStatus(t, 1) : this.updateSortItemStatus(t, 0));
                }
            }
            else {
                this._sortAes = 1;
                this._curSelectSortType = Number(t);
                for (let e = 0; e < this._sortItemArr.length; e++) {
                    let t = this._sortItemArr[e];
                    ToolUtils.isObjValid(t) && sys.isObjectValid(t.ext_info) && (t.ext_info == this._curSelectSortType ? this.updateSortItemStatus(t, 1) : this.updateSortItemStatus(t, 0));
                }
            }
            this._hasLoadAllMatch = false;
            0 == this.curTab && (this.all_cur_page = 1, this.requestAllMatchList(false, true));
        }
    }
    updateGold(e) {
        let t = this.goldNode.getChildByName("coin");
        null != e && t && (t.getComponent(Label).string = ToolUtils.parse_double(e));
    }
    onCloseButtonClick(e, t) {
        if (1 != this._hasForceSignMatch && (SoundManager.shared().playFx("click"), "back_btn" == t)) {
            if (this._closed) {
                return;
            }
            this.onBackView();
        }
    }
    initView() {
        if (this.fitScreen(), 0 == SportCricket_Manager.shared().cricket_teamStatsOpen && (this.tabNode.getChildByName("tab2").active = false, this.tabNode.getChildByName("tab0").getComponent(UITransform).contentSize = size(360, 90), this.tabNode.getChildByName("tab0").getChildByName("di").getComponent(UITransform).contentSize = size(360, 90), this.tabNode.getChildByName("tab0").getChildByName("line").getComponent(UITransform).contentSize = size(160, 4), this.tabNode.getChildByName("tab0").setPosition(v3(-180, -45)), this.tabNode.getChildByName("tab1").getComponent(UITransform).contentSize = size(360, 90), this.tabNode.getChildByName("tab1").getChildByName("di").getComponent(UITransform).contentSize = size(360, 90), this.tabNode.getChildByName("tab1").getChildByName("line").getComponent(UITransform).contentSize = size(160, 4), this.tabNode.getChildByName("tab1").setPosition(v3(180, -45))), sys.isObjectValid(this._source)) {
            this.rootNode.getChildByName("top_node").getChildByName("title").getComponent(Label).string = this._source.teama.short_name + " vs " + this._source.teamb.short_name;
            this.topNode.getChildByName("time_state").active = false;
            let e = this.rootNode.getChildByName("top_node").getChildByName("lefttime");
            sys.isObjectValid(this._source.status) && (this._match_state = this._source.status);
            let t = this.topNode.getChildByName("daybg"), i = this.topNode.getChildByName("hourbg"), a = this.topNode.getChildByName("minbg"), s = Utils.shared().parseTimeCount(this._source.time_left);
            t.getChildByName("time").getComponent(Label).string = s[0] > 9 ? String(s[0]) : "0" + String(s[0]);
            i.getChildByName("time").getComponent(Label).string = s[1] > 9 ? String(s[1]) : "0" + String(s[1]);
            a.getChildByName("time").getComponent(Label).string = s[2] > 9 ? String(s[2]) : "0" + String(s[2]);
            0 == this._source.time_left && 1 == this._source.status ? (e.getComponent(Label).string = this._source.start_day, sys.isObjectValid(this._source.is_current_day) && 1 == Number(this._source.is_current_day) && (this._source.status = 3, e.getComponent(Label).string = "Live", this.topNode.getChildByName("time_state").active = true, this.topNode.getChildByName("time_state").getComponent(Label).string = "Live", t.active = false, i.active = false, a.active = false)) : 1 == this._source.status ? TweenTool.myschedule(e, 1, (() => {
                if (ToolUtils.isObjValid(this.node)) {
                    if (this._source.time_left > 0) {
                        this._source.time_left = this._source.time_left - 1;
                        let e = Utils.shared().parseTimeCount(this._source.time_left);
                        t.getChildByName("time").getComponent(Label).string = e[0] > 9 ? String(e[0]) : "0" + String(e[0]);
                        i.getChildByName("time").getComponent(Label).string = e[1] > 9 ? String(e[1]) : "0" + String(e[1]);
                        a.getChildByName("time").getComponent(Label).string = e[2] > 9 ? String(e[2]) : "0" + String(e[2]);
                    }
                    else {
                        this._source.status = 3;
                        e.getComponent(Label).string = "Live";
                        TweenTool.stopNodeAction(e);
                        this.topNode.getChildByName("time_state").active = true;
                        this.topNode.getChildByName("time_state").getComponent(Label).string = "Live";
                        t.active = false;
                        i.active = false;
                        a.active = false;
                    }
                }
            })) : 3 == this._source.status ? (TweenTool.stopNodeAction(e), e.getComponent(Label).string = "Live", this.topNode.getChildByName("time_state").active = true, this.topNode.getChildByName("time_state").getComponent(Label).string = "Live", t.active = false, i.active = false, a.active = false) : 4 == this._source.status && (TweenTool.stopNodeAction(e), e.getComponent(Label).string = "Cancel", this.topNode.getChildByName("time_state").active = true, this.topNode.getChildByName("time_state").getComponent(Label).string = "Cancel", t.active = false, i.active = false, a.active = false);
            PushCenter.shared().addListener(PushEvent.UpdateYes11CurMatchLeftTime, (s => {
                try {
                    ToolUtils.isObjValid(this.node) && s.match_id == this._match_id && (this._source.time_left = s.time_left, this._source.is_current_day = s.is_current_day, this._match_state = s.status, 3 == s.status ? (TweenTool.stopNodeAction(e), e.getComponent(Label).string = "Live", this.topNode.getChildByName("time_state").active = true, this.topNode.getChildByName("time_state").getComponent(Label).string = "Live", t.active = false, i.active = false, a.active = false) : 4 == s.status && (TweenTool.stopNodeAction(e), e.getComponent(Label).string = "Cancel", this.topNode.getChildByName("time_state").active = true, this.topNode.getChildByName("time_state").getComponent(Label).string = "Cancel", t.active = false, i.active = false, a.active = false));
                }
                catch (e) {
                    TLog.printError(this.TAG, PushEvent.UpdateYes11CurMatchLeftTime, e);
                }
            }), this);
            PushCenter.shared().addListener(PushEvent.RefreshYesGameSignPer, (e => {
                try {
                    ToolUtils.isObjValid(this.node) && this.updateGameSessionPercent(e);
                }
                catch (e) {
                    TLog.printError(this.TAG, PushEvent.RefreshYesGameSignPer, e);
                }
            }), this);
            PushCenter.shared().addListener(PushEvent.Update_Gullak_RewardInGame, (e => {
                ToolUtils.isObjValid(this.node) && this.updateGullakBtnStatus(User.shared().act_68_open, User.shared().act_68_full_status, true);
            }), this);
        }
        this.updateGullakBtnStatus(User.shared().act_68_open, User.shared().act_68_full_status, true);
    }
    updateGameSessionPercent(e) {
        if (sys.isObjectValid(e.contest)) {
            if (0 == this.curTab) {
                let t = -1;
                for (let i = 0; i < this.all_listData.length; i++) {
                    if (this._match_id == Number(e.match_id) && this.all_listData[i].session_id == e.contest.session_id) {
                        t = i;
                        break;
                    }
                }
                if (-1 != t) {
                    let t = this._allItemMap.get(String(e.contest.session_id));
                    if (ToolUtils.isObjValid(t)) {
                        let i = t.getComponent(Button).clickEvents[0].customEventData, a = ToolUtils.parseJson(i), s = a.reward_rate;
                        sys.isObjectValid(a) && (a.left_sign_num = e.contest.left_sign_num, a.sign_num = e.contest.sign_num, sys.isObjectValid(e.contest.reward_rate) && (a.reward_rate = e.contest.reward_rate), sys.isObjectValid(e.contest.all_reward) && (a.all_reward = e.contest.all_reward), sys.isObjectValid(e.contest.first_reward) && (a.first_reward = e.contest.first_reward));
                        t.getChildByName("main_node").getChildByName("jiangchi_node").getComponent(Button).clickEvents[0].customEventData = ToolUtils.toJsonString(a);
                        t.getComponent(Button).clickEvents[0].customEventData = ToolUtils.toJsonString(a);
                        sys.isObjectValid(e.contest.left_sign_num) && sys.isObjectValid(e.contest.sign_num) && (t.getChildByName("main_node").getChildByName("progress").getComponent(ProgressBar).progress = (e.contest.sign_num - e.contest.left_sign_num) / e.contest.sign_num, t.getChildByName("main_node").getChildByName("left_desc1").getComponent(Label).string = e.contest.left_sign_num + " Left", t.getChildByName("main_node").getChildByName("left_desc2").getComponent(Label).string = e.contest.sign_num + " Spots");
                        sys.isObjectValid(e.contest.once_incr_reward) && e.contest.once_incr_reward > 0 && (sys.isObjectValid(a.last_all_reward) && a.last_all_reward > 0 ? (t.getChildByName("main_node").getChildByName("jiangchi_node").getChildByName("amt").getComponent(Label).string = "₹" + ToolUtils.parse_double(a.last_all_reward), t.getChildByName("main_node").getChildByName("jiangchi_node").getComponent(Layout).updateLayout(), a.last_all_reward != a.all_reward ? t.getChildByName("main_node").getChildByName("jiangchi_node").active = true : t.getChildByName("main_node").getChildByName("jiangchi_node").active = false) : t.getChildByName("main_node").getChildByName("jiangchi_node").active = false, t.getChildByName("main_node").getChildByName("pool2_arrow").active = true, t.getChildByName("main_node").getChildByName("pool_arrow").active = true, t.getChildByName("main_node").getChildByName("pool_add").active = true, t.getChildByName("main_node").getChildByName("pool_add").getComponent(Label).string = "+" + e.contest.once_incr_reward, s != a.reward_rate && (t.getChildByName("main_node").getChildByName("prize_arrow").active = true), TweenTool.stopNodeAction(t), TweenTool.delayAct(t, (() => {
                            t.getChildByName("main_node").getChildByName("pool2_arrow").active = false;
                            t.getChildByName("main_node").getChildByName("prize_arrow").active = false;
                            t.getChildByName("main_node").getChildByName("pool_arrow").active = false;
                            t.getChildByName("main_node").getChildByName("pool_add").active = false;
                            sys.isObjectValid(e.contest.all_reward) && (t.getChildByName("main_node").getChildByName("pool").getComponent(Label).string = "₹" + String(e.contest.all_reward));
                            sys.isObjectValid(e.contest.first_reward) && (t.getChildByName("main_node").getChildByName("pool2").getComponent(Label).string = "₹" + String(e.contest.first_reward));
                            sys.isObjectValid(e.contest.reward_rate) && (t.getChildByName("main_node").getChildByName("prize_desc").getComponent(Label).string = e.contest.reward_rate);
                            this.refreshPos(t);
                        }), 2, true));
                    }
                }
            }
            else {
                let t = -1;
                for (let i = 0; i < this.my_listData.length; i++) {
                    if (this._match_id == Number(e.match_id) && this.my_listData[i].session_id == e.contest.session_id) {
                        t = i;
                        break;
                    }
                }
                if (-1 != t) {
                    let t = this._myItemMap.get(String(e.contest.session_id));
                    if (ToolUtils.isObjValid(t)) {
                        let i = t.getComponent(Button).clickEvents[0].customEventData, a = ToolUtils.parseJson(i), s = a.reward_rate;
                        sys.isObjectValid(a) && (a.left_sign_num = e.contest.left_sign_num, a.sign_num = e.contest.sign_num, sys.isObjectValid(e.contest.reward_rate) && (a.reward_rate = e.contest.reward_rate), sys.isObjectValid(e.contest.all_reward) && (a.all_reward = e.contest.all_reward), sys.isObjectValid(e.contest.first_reward) && (a.first_reward = e.contest.first_reward));
                        t.getChildByName("main_node").getChildByName("jiangchi_node").getComponent(Button).clickEvents[0].customEventData = ToolUtils.toJsonString(a);
                        t.getComponent(Button).clickEvents[0].customEventData = ToolUtils.toJsonString(a);
                        sys.isObjectValid(e.contest.left_sign_num) && sys.isObjectValid(e.contest.sign_num) && (t.getChildByName("main_node").getChildByName("progress").getComponent(ProgressBar).progress = (e.contest.sign_num - e.contest.left_sign_num) / e.contest.sign_num, t.getChildByName("main_node").getChildByName("left_desc1").getComponent(Label).string = e.contest.left_sign_num + " Left", t.getChildByName("main_node").getChildByName("left_desc2").getComponent(Label).string = e.contest.sign_num + " Spots");
                        sys.isObjectValid(e.contest.once_incr_reward) && e.contest.once_incr_reward > 0 && (sys.isObjectValid(a.last_all_reward) && a.last_all_reward > 0 ? (t.getChildByName("main_node").getChildByName("jiangchi_node").getChildByName("amt").getComponent(Label).string = "₹" + ToolUtils.parse_double(a.last_all_reward), t.getChildByName("main_node").getChildByName("jiangchi_node").getComponent(Layout).updateLayout(), a.last_all_reward != a.all_reward ? t.getChildByName("main_node").getChildByName("jiangchi_node").active = true : t.getChildByName("main_node").getChildByName("jiangchi_node").active = false) : t.getChildByName("main_node").getChildByName("jiangchi_node").active = false, t.getChildByName("main_node").getChildByName("pool2_arrow").active = true, t.getChildByName("main_node").getChildByName("pool_arrow").active = true, t.getChildByName("main_node").getChildByName("pool_add").active = true, t.getChildByName("main_node").getChildByName("pool_add").getComponent(Label).string = "+" + String(e.contest.once_incr_reward), s != a.reward_rate && (t.getChildByName("main_node").getChildByName("prize_arrow").active = true), TweenTool.stopNodeAction(t), TweenTool.delayAct(t, (() => {
                            t.getChildByName("main_node").getChildByName("pool2_arrow").active = false;
                            t.getChildByName("main_node").getChildByName("pool_arrow").active = false;
                            t.getChildByName("main_node").getChildByName("pool_add").active = false;
                            t.getChildByName("main_node").getChildByName("prize_arrow").active = false;
                            sys.isObjectValid(e.contest.all_reward) && (t.getChildByName("main_node").getChildByName("pool").getComponent(Label).string = "₹" + String(e.contest.all_reward));
                            sys.isObjectValid(e.contest.first_reward) && (t.getChildByName("main_node").getChildByName("pool2").getComponent(Label).string = "₹" + String(e.contest.first_reward));
                            sys.isObjectValid(e.contest.reward_rate) && (t.getChildByName("main_node").getChildByName("prize_desc").getComponent(Label).string = e.contest.reward_rate);
                            this.refreshPos(t);
                        }), 2, true));
                    }
                }
            }
        }
    }
    onItemClick(e, t) {
        if (1 == this._hasForceSignMatch) {
            return;
        }
        if (SoundManager.shared().playFx("click"), sys.now() - this._lastClick < 500) {
            return;
        }
        if (this._lastClick = sys.now(), 3 == this._match_state) {
            return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("yes11.live_tip"), 2);
        }
        if (4 == this._match_state) {
            return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("yes11.cancel_tip"), 2);
        }
        let i = ToolUtils.parseJson(t), a = { match_id: this._match_id, contest_id: i.session_id, contest_source: i, source: this._source, lastNode: this.rootNode };
        Utils.shared().showSportCricket_gameDetails(a);
    }
    onJoinGameClick(e, t) {
        let i = ToolUtils.parseJson(t);
        if (1 == this._hasForceSignMatch) {
            if (Number(i.session_id) != this._forceSessionId) {
                return;
            }
        }
        SoundManager.shared().playFx("click");
        sys.now() - this._lastClick < 500 || (this._lastClick = sys.now(), 3 != this._match_state ? 4 != this._match_state ? this.checkJoinGame(i) : Utils.shared().showToast(i18nMgr.shared().getValueByKey("yes11.cancel_tip"), 2) : Utils.shared().showToast(i18nMgr.shared().getValueByKey("yes11.live_tip"), 2));
    }
    checkJoinGame(e) {
        let t = false;
        1 == User.shared().forceSignCricket && this._forceSessionId > 0 && (t = true);
        let i = { session_id: e.session_id, match_id: this._match_id, force: t ? 1 : 0 };
        Utils.shared().showLoading(10, true, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
        }), ToolUtils.getIsNormalDirection());
        SportCricket_Manager.shared().requestYes11_PreJoinGameCheck(i, true, (t => {
            if (sys.isObjectValid(t) && sys.isObjectValid(t.code)) {
                if (308501 == t.code) {
                    sys.isObjectValid(e.is_chip) && 1 == e.is_chip ? Utils.shared().showQuickRechargeByYes11({ fee: e.fee, is_chip: 1 }) : Utils.shared().showQuickRechargeByYes11({ fee: e.fee });
                    User.shared().updatePayScene(PhpReportDefined.pay_scene.hall_cricket);
                }
                else if (308502 == t.code) {
                    let t = 0;
                    sys.isObjectValid(e.is_chip) && (t = e.is_chip);
                    this.checkCreateTeam(1, e.session_id, t);
                }
                else if (308503 == t.code) {
                    let i = { match_id: this._match_id, contest_id: e.session_id, assureInfo: t };
                    sys.isObjectValid(e) && sys.isObjectValid(e.is_chip) && 1 == e.is_chip && (i.assureInfo.is_chip = 1);
                    Utils.shared().showSportCricket_assureJoin(i);
                }
                else if (308504 == t.code) {
                    let t = { match_id: this._match_id, contest_id: e.session_id };
                    SportCricket_Manager.shared().requestYes11_JoinList(t, true, (t => {
                        let i = { match_id: this._match_id, contest_id: e.session_id, teamlistData: t };
                        sys.isObjectValid(e) && sys.isObjectValid(e.is_chip) && 1 == e.is_chip && (i.teamlistData.is_chip = 1);
                        Utils.shared().showSportCricket_joinList(i);
                    }));
                }
            }
        }));
    }
    onButtonClick(e, t) {
        if (1 != this._hasForceSignMatch && (SoundManager.shared().playFx("click"), !(sys.now() - this._lastClick < 500))) {
            if (this._lastClick = sys.now(), 3 != this._match_state) {
                if (4 != this._match_state) {
                    if ("tab0" == t) {
                        if (0 == this.curTab) {
                            return;
                        }
                        this.curTab = 0;
                        this.updateTabView();
                        this.updateTabContent();
                    }
                    else if ("tab1" == t) {
                        if (1 == this.curTab) {
                            return;
                        }
                        this.curTab = 1;
                        this.updateTabView();
                        this.updateTabContent();
                    }
                    else if ("tab2" == t) {
                        if (2 == this.curTab) {
                            return;
                        }
                        this.curTab = 2;
                        this.updateTabView();
                        this.updateTabContent();
                    }
                    else if ("create_team" == t) {
                        this.checkCreateTeam(0);
                    }
                    else if ("my_teams" == t) {
                        0 == this._curTeamNum ? this.checkCreateTeam(0) : this.dealTeamListLogic();
                    }
                    else if ("filter" == t) {
                        let e = { fromType: 2, source: SportCricket_Manager.shared().sortSourceData, filter: this.sortFilterInfo, chooseCall: e => {
                                sys.isObjectValid(e) && e.length > 0 ? this.sortFilterInfo = e : this.sortFilterInfo = null;
                                this.all_cur_page = 1;
                                this.requestAllMatchList(true, true);
                                this.updateFilterBtnStatus();
                            } };
                        Utils.shared().showSportCricket_gameSortView(e);
                    }
                    else if ("add_chip" == t) {
                        Utils.shared().showStoreView(null, null);
                        User.shared().updatePayScene(PhpReportDefined.pay_scene.hall_cricket);
                    }
                    else if ("gullak" == t) {
                        let e = {};
                        Utils.shared().doJumpLogic(PushEvent.JUMP_TO_Gullak, e, { isNext: false, bWithTip: true, link_id: sys.now(), reportEvtId: 4, reportScene: 2 });
                        User.shared().updatePayScene(PhpReportDefined.pay_scene.hall_cricket);
                    }
                }
                else {
                    Utils.shared().showToast(i18nMgr.shared().getValueByKey("yes11.cancel_tip"), 2);
                }
            }
            else {
                Utils.shared().showToast(i18nMgr.shared().getValueByKey("yes11.live_tip"), 2);
            }
        }
    }
    dealTeamListLogic() {
        let e = { match_id: this._match_id };
        Utils.shared().showLoading(10, true, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
        }), ToolUtils.getIsNormalDirection());
        HttpManager.shared().doGetCommonRequest(e, HttpRequest.Yes11_TeamList, ((t, i, a) => {
            if (Utils.shared().hideLoading(), 200 != a) {
                Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.request_fail"), 2);
            }
            else {
                try {
                    let t = ToolUtils.parseJson(i);
                    if (0 == t.ret) {
                        if (sys.isObjectValid(t.data)) {
                            let i = { match_id: e.match_id, fromType: 0, source: this._source, teamlistData: t.data, lastNode: this.node };
                            Utils.shared().showSportCricket_teamList(i);
                        }
                    }
                    else {
                        sys.isObjectValid(t.desc) && t.desc.length > 0 && Utils.shared().showToast(t.desc, 2);
                    }
                }
                catch (e) {
                    TLog.printError("showSportCricket_teamList err:", e.toString());
                }
            }
        }));
    }
    checkCreateTeam(e = 0, t, i = 0) {
        let a = { match_id: this._match_id, force: User.shared().forceSignCricket };
        SportCricket_Manager.shared().requestYes11_PreCreateTeamCheck(a, true, (a => {
            let s = { source: this._source, match_id: this._match_id, player_source: a, fromType: e, lastNode: this.node };
            sys.isObjectValid(t) && (s.contest_id = t);
            sys.isObjectValid(i) && (s.is_chip = i);
            Utils.shared().showSportCricket_createTeam(s);
        }));
    }
    updateTabContent() {
        if (this.allMatchScrollView.node.active = 0 == this.curTab, this.myMatchScrollView.node.active = 1 == this.curTab, this.bottomNode.active = 2 != this.curTab, this.rootNode.getChildByName("nodata").active = false, this.rootNode.getChildByName("stats_root").active = 2 == this.curTab, this.sortNode.active = 0 == this.curTab, 0 == this.curTab) {
            if (this._hasLoadAllMatch) {
                this.allMatchScrollView.node.active = true;
                0 == this.all_listData.length && (this.rootNode.getChildByName("nodata").active = true);
                this.allMatchScrollView.getComponent(ScrollVisibility).updateVisibility();
            }
            else {
                let e = true;
                this.all_cur_page = 1;
                this.requestAllMatchList(e, true);
            }
        }
        else if (1 == this.curTab) {
            if (this._hasLoadMyMatch) {
                this.myMatchScrollView.node.active = true;
                0 == this.my_listData.length && (this.rootNode.getChildByName("nodata").active = true);
                this.myMatchScrollView.getComponent(ScrollVisibility).updateVisibility();
            }
            else {
                let e = true;
                this.my_cur_page = 1;
                this.requestMyMatchList(e, true);
            }
        }
        else if (2 == this.curTab) {
            this._match_id;
            this._source;
            this.node;
            this.rootNode.getChildByName("stats_root").getComponent(ScrollView).content;
        }
    }
    onBackView(e = true) {
        e && (Utils.shared().hideLoading(), ToolUtils.isObjValid(this.node) && TweenTool.stopNodeAction(this.node), this.bShowPushAnim ? (this._closed = true, ToolUtils.isObjValid(this._lastNode) && (this._lastNode.active = true), ToolUtils.showPushAnim(this.node, 1, (() => {
            ToolUtils.isObjValid(this.node) && this.node.destroy();
        }))) : (ToolUtils.isObjValid(this._lastNode) && (this._lastNode.active = true), ToolUtils.isObjValid(this.node) && (TweenTool.stopNodeAction(this.node), this.node.destroy())));
    }
    fitScreen() {
        ToolUtils.adaptSafeArea(this.rootNode);
        let e = sys.getSafeAreaRect().y, t = view.getVisibleSize();
        if (this.node.getComponent(UITransform).setContentSize(t.width, t.height), 0 != e) {
            let t = this.rootNode.getChildByName("all_ScrollView").getComponent(Widget).bottom;
            this.rootNode.getChildByName("all_ScrollView").getComponent(Widget).bottom = t - e;
            t = this.rootNode.getChildByName("my_ScrollView").getComponent(Widget).bottom;
            this.rootNode.getChildByName("my_ScrollView").getComponent(Widget).bottom = t - e;
            t = this.rootNode.getChildByName("bottom_node").getComponent(Widget).bottom;
            this.rootNode.getChildByName("bottom_node").getComponent(Widget).bottom = t - e;
        }
    }
}
