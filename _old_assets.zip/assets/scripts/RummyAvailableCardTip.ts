// @ts-nocheck
// Recovered from index.js:423
import { _decorator, Component, instantiate, Label, Node, NodePool, Prefab, ScrollView, size, sys, UITransform, v3, Vec3, view } from "cc";
import { TLog } from "./TLog";
import RummyCard from "./RummyCard";
import RummyDataManager from "./RummyDataManager";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("RummyAvailableCardTip")
export class RummyAvailableCardTip extends Component {
    @property(Node)
    public bgViewNode: Node = null;
    @property(Node)
    public arrowNode: Node = null;
    @property(Node)
    public maskNode: Node = null;
    @property(Prefab)
    public cardPrefab: Prefab = null;
    @property(Node)
    public inputCardNode: Node = null;
    public max_bg_x: number = 425;
    public min_bg_x: any = -425;
    public cardNodesVec: any[] = [];
    public tid_key: string = "";
    public card_scale: number = 0.32;
    public cards_positions: any[] = [new Vec3(-9, 0), new Vec3(12, 0)];
    public cardsViewPool: any = null;
    public orign_bg_width: number = 384;
    public cardIndex: any = -1;
    public groupIndex: any = -1;
    public cardValue: any = -1;
    public worldPos: any = undefined;
    start() {
        this.maskNode.getComponent(UITransform).setContentSize(view.getVisibleSize());
        this.cardsViewPool || (this.cardsViewPool = new NodePool("RummyAvailableCardTip"));
    }
    refreshTips(e, t = null) {
        if (!sys.isObjectValid(e)) {
            return;
        }
        let i;
        if (Array.isArray(e) && e.length > this.groupIndex && this.groupIndex > 0) {
            let t = e[this.groupIndex].inputs;
            if (t && Array.isArray(t) && t.length > 0) {
                for (let e = 0; e < t.length; e++) {
                    let s = t[e].index, r = t[e].cards;
                    if (Array.isArray(s) && Array.isArray(r) && 2 == s.length && 2 == r.length) {
                        for (let o = 0; o < r.length; o++) {
                            if (r[o] == this.cardValue && s[o] == this.cardIndex) {
                                i = t[e];
                                break;
                            }
                        }
                    }
                }
            }
        }
        sys.isObjectValid(i) ? this.refreshUI(i) : t && t();
    }
    showTips(e) {
        sys.isObjectValid(e) && (sys.isObjectValid(e.cardIndex) && (this.cardIndex = e.cardIndex), sys.isObjectValid(e.groupIndex) && (this.groupIndex = e.groupIndex), sys.isObjectValid(e.cardValue) && (this.cardValue = e.cardValue), this.cardsViewPool || (this.cardsViewPool = new NodePool("RummyAvailableCardTip")), sys.isObjectValid(e.worldPos) && (this.worldPos = e.worldPos), sys.isObjectValid(e.tid_key) && (this.tid_key = e.tid_key), this.refreshUI(e.data));
    }
    refreshUI(e) {
        let t, i = this.bgViewNode.getChildByName("cards");
        for (let e = 0, i = this.cardNodesVec.length; e < i; e++) {
            t = this.cardNodesVec[e];
            ToolUtils.isObjValid(t) && this.putCardNode(t);
        }
        Array(i.children) && i.children.length > 0 && i.removeAllChildren();
        let s = this.bgViewNode.getChildByName("ScrollView"), r = s.getComponent(ScrollView).content;
        Array(r.children) && r.children.length > 0 && r.removeAllChildren();
        this.cardNodesVec = [];
        let o, a = this.orign_bg_width, n = 31.5, h = this.bgViewNode.getChildByName("close"), c = this.bgViewNode.getChildByName("line"), C = 0;
        Array.isArray(e.outs) && e.outs.length > 0 && (C = e.outs.length);
        let y = C;
        y > 4 && (y = 4);
        let _ = this.bgViewNode.getChildByName("num");
        y <= 4 && (a -= 63 * (4 - y), h.setPosition(new Vec3(183 - n * (4 - y), 64)), c.setPosition(new Vec3(n * (4 - y) - 82, 2)), i.setPosition(new Vec3(n * (4 - y) - 132, 14)), _.setPosition(new Vec3(n * (4 - y) - 130, -36)), s.setPosition(new Vec3(n * (4 - y) - 72.5, 0)), this.max_bg_x = 425 + n * (4 - y), this.min_bg_x = -this.max_bg_x, s.getComponent(UITransform).setContentSize(size(255 - 63 * (4 - y), 139)), s.getComponent(ScrollView).view.setContentSize(size(255 - 63 * (4 - y), 139)));
        this.bgViewNode.getComponent(UITransform).setContentSize(size(a, 139));
        let N = new Vec3;
        if (this.node.inverseTransformPoint(N, this.worldPos), this.arrowNode.setPosition(N.x, -62), N.x <= this.max_bg_x && N.x >= this.min_bg_x ? this.bgViewNode.setPosition(N.x, -1) : N.x > this.max_bg_x ? this.bgViewNode.setPosition(this.max_bg_x, -1) : this.bgViewNode.setPosition(this.min_bg_x, -1), sys.isObjectValid(e)) {
            if (_.getComponent(Label).string = "" + e.num, Array.isArray(e.cards) && e.cards.length > 0) {
                let t = e.cards.length > 2 ? 2 : e.cards.length;
                for (let s = 0; s < t; s++) {
                    let t = this.getCardNode();
                    o = t.getComponent("RummyCard");
                    o.init(e.cards[s], false, 0);
                    o.openCard();
                    o.showLaiziFlag(RummyDataManager.shared().isShowLaiziColor(e.cards[s], this.tid_key));
                    o.setMask(false);
                    t.setScale(v3(this.card_scale, this.card_scale));
                    t.setPosition(this.cards_positions[s]);
                    t.active = true;
                    i.addChild(t);
                    this.cardNodesVec.push(t);
                }
            }
            if (Array.isArray(e.outs) && e.outs.length > 0) {
                for (let t = 0; t < C; t++) {
                    let i = instantiate(this.inputCardNode);
                    i.active = true;
                    i.getChildByName("num").getComponent(Label).string = "x" + e.outs[t].n;
                    let s = this.getCardNode();
                    o = s.getComponent("RummyCard");
                    o.init(e.outs[t].c, false, 0);
                    o.openCard();
                    o.showLaiziFlag(RummyDataManager.shared().isShowLaiziColor(e.outs[t].c, this.tid_key));
                    o.setMask(0 == e.outs[t].n);
                    s.setScale(v3(this.card_scale, this.card_scale));
                    s.active = true;
                    i.addChild(s);
                    s.setPosition(new Vec3(0, 14));
                    r.addChild(i);
                    this.cardNodesVec.push(s);
                }
            }
        }
    }
    getCardNode() {
        let e = null;
        e = this.cardsViewPool.size() > 0 ? this.cardsViewPool.get() : instantiate(this.cardPrefab);
        e.active = true;
        try {
            null === e.getComponent("RummyCard") || e.getComponent("RummyCard");
            e.getComponent("RummyCard").resetCards();
        }
        catch (e) {
            TLog.printError("trycatch getCardNode,error:", e);
        }
        return e;
    }
    putCardNode(e) {
        e.getComponent(RummyCard).resetCards();
        e.active = false;
        this.cardsViewPool && this.cardsViewPool.put(e);
    }
    update(e) {
    }
    onDestroy() {
        this.cardsViewPool.clear();
    }
}
