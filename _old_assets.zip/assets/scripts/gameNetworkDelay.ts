// @ts-nocheck
// Recovered from index.js:155
import { _decorator, Component, director, instantiate, v3 } from "cc";
import GameConfig from "./GameConfig";
import PushCenter from "./PushCenter";
import i18nMgr from "./i18nMgr";
import BundleNameDefined from "./BundleNameDefined";
import { ToolUtils } from "./ToolUtils";
import PushEvent from "./PushEvent";
const { ccclass } = _decorator;
@ccclass("gameNetworkDelay")
export default class gameNetworkDelay extends Component {
    static instance = null;
    public isLoadNetNode: boolean = false;
    public networkNode: any = null;
    public network_delay_time: number = 0;
    public isActiveDisconnect: boolean = false;
    public isSuccessfulReconnection: boolean = false;
    public networkDelayPrefab: any = null;
    static shared(): gameNetworkDelay {
        return null == this.instance && (this.instance = new gameNetworkDelay), this.instance;
    }
    loadNode() {
        ToolUtils.loadCommonPrefab(this.networkDelayPrefab, BundleNameDefined.bundle_networkdelay, "prefab/networkdelay", (e => {
            this.networkDelayPrefab = e;
            this.createNetWorkDelayView();
        }));
    }
    createNetWorkDelayView() {
        try {
            if (director.getScene().name == BundleNameDefined.rummy_scence) {
                let e = director.getScene().getChildByName("Canvas");
                ToolUtils.isObjValid(e.getChildByName("networkNode")) && e.getChildByName("networkNode").destroy();
                this.networkNode = instantiate(this.networkDelayPrefab);
                this.networkNode.name = "networkNode";
                e.addChild(this.networkNode);
                1 == ToolUtils.heart_open && (ToolUtils.deskInfos.size > 1 || 1 !== ToolUtils.in_isGuideRoom) ? (this.unschedule(this.updateTipTime), this.schedule(this.updateTipTime, 1)) : this.unschedule(this.updateTipTime);
                this.isShowNetworkDelay(false);
                this.setLandscapeShow();
            }
        }
        catch (e) {
        }
    }
    onLoad() {
    }
    onStartSchedule() {
        this.unschedule(this.updateTipTime);
        this.schedule(this.updateTipTime, 1);
    }
    updateTipTime() {
        if (this.isActiveDisconnect) {
            return this.network_delay_time = 0, void this.isShowNetworkDelay(false);
        }
        if (this.network_delay_time = this.network_delay_time + 1, this.network_delay_time > ToolUtils.heart_time[0] && this.network_delay_time < ToolUtils.heart_time[1]) {
            this.isShowNetworkDelay(true);
            this.network_delay_time == ToolUtils.heart_time[0] + 1 ? (ToolUtils.has_reconnect = true, this.isSuccessfulReconnection && (this.isSuccessfulReconnection = false)) : this.network_delay_time == ToolUtils.heart_time[0] + Math.floor((ToolUtils.heart_time[1] - ToolUtils.heart_time[0]) / 2) + 1 && PushCenter.shared().pushEvent(PushEvent.SwitchGameGateAddr);
        }
        else if (this.network_delay_time >= ToolUtils.heart_time[1]) {
            if (this.network_delay_time == ToolUtils.heart_time[1] && (ToolUtils.has_reconnect = true), !ToolUtils.isObjValid(this.networkNode)) {
                return void (this.network_delay_time = 0);
            }
            this.isActiveDisconnect = true;
            ToolUtils.has_comm_alert = true;
            PushCenter.shared().pushEvent(PushEvent.ShowCommDlg, { strContent: i18nMgr.shared().getValueByKey("utlis.text6"), strTitle: i18nMgr.shared().getValueByKey("utlis.tips"), okfc: e => {
                    ToolUtils.isObjValid(this.networkNode) && (1 == e ? (this.isSuccessfulReconnection = true, PushCenter.shared().pushEvent(GameConfig.NetWorkErrorReconnection), this.isActiveDisconnect = false, ToolUtils.has_comm_alert = false) : (PushCenter.shared().pushEvent(GameConfig.RummyCompleteExit), this.isActiveDisconnect = false, ToolUtils.has_comm_alert = false), this.network_delay_time = 0);
                }, bWithCancel: false, bLandscape: ToolUtils.getIsNormalDirection() });
        }
    }
    updateNetworktime() {
        ToolUtils.isObjValid(this.networkNode) ? (this.isSuccessfulReconnection && (this.isSuccessfulReconnection = false), this.isShowNetworkDelay(false)) : this.unschedule(this.updateTipTime);
        this.isSuccessfulReconnection = false;
        this.network_delay_time = 0;
    }
    getNetworkdelayTime() {
        return this.network_delay_time;
    }
    isShowNetworkDelay(e) {
        ToolUtils.isObjValid(this.networkNode) && (this.networkNode.getChildByName("network_bg").active = e || false);
    }
    setActiveDisconnect(e) {
        this.isActiveDisconnect = e;
    }
    removechild() {
        this.unschedule(this.updateTipTime);
        ToolUtils.isObjValid(this.networkNode) && this.networkNode.destroy();
        this.networkNode = null;
    }
    onDestroy() {
        PushCenter.shared().removeListenersByTag(this);
        this.unschedule(this.updateTipTime);
        ToolUtils.isObjValid(this.networkNode) && this.networkNode.destroy();
    }
    setLandscapeShow() {
        ToolUtils.isObjValid(this.networkNode) && (ToolUtils.getOrientation() || this.networkNode.setRotationFromEuler(v3(0, 0, -90)));
    }
}
