// @ts-nocheck
// Recovered from index.js:221
import { _decorator, Button, EditBox, Label, LabelShadow, Node, size, Sprite, SpriteFrame, sys, UITransform, v3 } from "cc";
import SoundManager from "./SoundManager";
import Utils from "./Utils";
import BaseLayer from "./BaseLayer";
import User from "./User";
import HttpManager from "./HttpManager";
import i18nMgr from "./i18nMgr";
import PushCenter from "./PushCenter";
import PushEvent from "./PushEvent";
import { TransferPlatform } from "./TransferPlatform";
import TweenTool from "./TweenTool";
import ReportConfig from "./ReportConfig";
import GameConfig from "./GameConfig";
import CommDefine, { CheckModule } from "./CommDefine";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("KycUpdate")
export class KycUpdate extends BaseLayer {
    @property(Node)
    public rootNode: Node = null;
    @property(Node)
    public verifyNode: Node = null;
    @property(Node)
    public waitNode: Node = null;
    @property(Node)
    public tipsNode: Node = null;
    @property(Node)
    public secTipsLabel: Node = null;
    @property(Node)
    public cardNumberNode: Node = null;
    @property(Node)
    public panNumberNode: Node = null;
    @property(Node)
    public errTipNode: Node = null;
    @property(Node)
    public verifyBgNode: Node = null;
    @property(Node)
    public verify_btn: Node = null;
    @property(Node)
    public waiting_more_btn: Node = null;
    @property([SpriteFrame])
    public verifyBtnDiImags: SpriteFrame[] = [];
    public cardNumberStr: string = "";
    public panNumberStr: string = "";
    public isNext: boolean = false;
    public from_source: number = 0;
    public _closed: boolean = false;
    public _verifyBtnPos: any = undefined;
    public _bgSize: any = undefined;
    public _frameSize: any = undefined;
    public _mIdTime: number = 0;
    public _identitytimeAction: any = null;
    public _countDownAction: any = null;
    public _keyboardHei: number = 740;
    public _uiType: number = 0;
    public _panNameSize: any = undefined;
    initParaData(e) {
        sys.isObjectValid(e) && (sys.isObjectValid(e.isNext) && (this.isNext = e.isNext), sys.isObjectValid(e.from_source) && (this.from_source = e.from_source), sys.isObjectValid(e.uiType) && (this._uiType = e.uiType));
    }
    onLoad() {
        ToolUtils.showFullScreen(this.node.getChildByName("mask"));
        this._verifyBtnPos = this.verify_btn.getPosition();
        let e = this.verifyBgNode.getComponent(UITransform).contentSize;
        this._bgSize = size(e.width, e.height);
        this.updateCheckStatus();
        this.dealMultipleLanguages();
        e = this.verifyNode.getChildByName("input_frame").getComponent(UITransform).contentSize;
        this._frameSize = size(e.width, e.height);
        this._panNameSize = this.tipsNode.getChildByName("label_pan_name").getComponent(Label).fontSize;
    }
    dealMultipleLanguages() {
        2 == i18nMgr.shared().language && (this.verifyNode.getChildByName("enter_number").getComponent(Label).fontSize = 22, this.verifyNode.getChildByName("enter_pan").getComponent(Label).fontSize = 22, this.verifyNode.getChildByName("sec_tip_wz").getComponent(Label).fontSize = 14, this.waitNode.getChildByName("title").getComponent(Label).fontSize = 24);
    }
    start() {
        if (super.start(), TransferPlatform.shared().setSoftInputMode(1), this.startShowAnim(this.rootNode), PushCenter.shared().addListener(PushEvent.UpdateKycResubmit, (() => {
            ToolUtils.isObjValid(this.node) && (Utils.shared().hideLoading(), this.stopCountDownActin(), this.updateCheckStatus(), this.updateVerifyView(), this.restoreScrollviewTop(), 2 == User.shared().data.resubmit_status || 3 == User.shared().data.resubmit_status ? (this._identitytimeAction && (this.stopIdentityActin(), this.updateCardNumberStatus()), Utils.shared().hideLoading(), 2 == User.shared().data.resubmit_status ? this.onBackView() : this.showVerifyBtnStatus(1)) : this.showVerifyBtnStatus(1), 2 == User.shared().kyc_resubmit_data.status ? HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Hall, event: ReportConfig.hall_evt.resubmit_verify_succ }) : 3 == User.shared().kyc_resubmit_data.status && HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Hall, event: ReportConfig.hall_evt.resubmit_verify_fail }));
        }), this), PushCenter.shared().addListener(PushEvent.changeWebViewHeight, (e => {
            ToolUtils.isObjValid(this.node) && (this._keyboardHei = ToolUtils.isSafeNumber(Number(e)), this.showScrollivewUp(this.cardNumberNode.getChildByName("EditBox")));
        }), this), ToolUtils.isObjValid(this.waiting_more_btn)) {
            this.waiting_more_btn.getChildByName("wz").getComponent(Label).updateRenderData(true);
            let e = this.waiting_more_btn.getChildByName("wz").getComponent(UITransform).contentSize.width, t = this.waiting_more_btn.getChildByName("line").getComponent(UITransform).contentSize;
            this.waiting_more_btn.getChildByName("line").getComponent(UITransform).setContentSize(size(e, t.height));
        }
        1 == this._uiType ? (this.verifyNode.active = false, this.waitNode.active = false, this.tipsNode.active = true, this.updatePanName()) : (this.verifyNode.active = true, this.waitNode.active = false, this.tipsNode.active = false, sys.isObjectValid(User.shared().kyc_resubmit_data) || Utils.shared().showLoading(15, true, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3);
        })), this.updateVerifyView(true), User.shared().doGetKycResubmitInfo((() => {
            Utils.shared().hideLoading();
            ToolUtils.isObjValid(this.node) && this.updateVerifyView();
        })));
        HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Hall, event: ReportConfig.hall_evt.enter_resubmit_verify });
    }
    onDestroy() {
        super.onDestroy();
        TransferPlatform.shared().setSoftInputMode(0);
        TweenTool.stopNodeAction(this.rootNode);
        TweenTool.stopNodeAction(this.node);
        Utils.shared().hideLoading();
        PushCenter.shared().removeListenersByTag(this);
    }
    updateCheckStatus() {
        0 == User.shared().data.resubmit_status || 3 == User.shared().data.resubmit_status ? (this.verifyNode.active = true, this.waitNode.active = false) : 1 == User.shared().data.resubmit_status && (this.waitNode.active = true, this.verifyNode.active = false);
    }
    updateErrTips() {
        if (sys.isObjectValid(User.shared().kyc_resubmit_data.reason) && ToolUtils.isSafeString(User.shared().kyc_resubmit_data.reason).length > 0) {
            this.errTipNode.active = true;
            this.errTipNode.getChildByName("tx").getComponent(Label).string = User.shared().kyc_resubmit_data.reason;
            this.errTipNode.getChildByName("tx").getComponent(Label).updateRenderData(true);
            let e = 0;
            e = this.errTipNode.getChildByName("tx").getComponent(UITransform).contentSize.height > 50 ? 50 : 30;
            this.verify_btn.setPosition(v3(this._verifyBtnPos.x, this._verifyBtnPos.y - e, this._verifyBtnPos.z));
            this.verifyBgNode.getComponent(UITransform).setContentSize(size(this._bgSize.width, this._bgSize.height + e));
            this.verifyBgNode.setPosition(v3(0, -e / 2));
            this.verifyNode.getChildByName("input_frame").getComponent(UITransform).setContentSize(size(this._frameSize.width, this._frameSize.height + e));
        }
        else {
            this.errTipNode.active = false;
            this.errTipNode.getChildByName("tx").getComponent(Label).string = "";
            this.verify_btn.setPosition(this._verifyBtnPos);
            this.verifyBgNode.getComponent(UITransform).setContentSize(this._bgSize);
            this.verifyBgNode.setPosition(v3(0, 0));
            this.verifyNode.getChildByName("input_frame").getComponent(UITransform).setContentSize(this._frameSize);
        }
    }
    updateCardNumberView(e = "", t, i = true) {
        i && (this.cardNumberStr = e, this.cardNumberNode.getChildByName("del_btn").active = false);
        this.cardNumberNode.getChildByName("EditBox").getComponent(EditBox).string = this.cardNumberStr;
        this.cardNumberNode.getChildByName("content").getComponent(Label).string = this.cardNumberStr;
        this.cardNumberNode.getChildByName("EditBox").active = t;
        this.cardNumberNode.getChildByName("content").active = !t;
        this.cardNumberNode.getChildByName("EditBox").getComponent(EditBox).inputMode = EditBox.InputMode.NUMERIC;
        this.cardNumberNode.getChildByName("EditBox").getComponent(EditBox).maxLength = 12;
    }
    updatePanNumberView(e = "", t, i = true) {
        i && (this.panNumberStr = e, this.panNumberNode.getChildByName("del_btn").active = false);
        this.panNumberNode.getChildByName("EditBox").getComponent(EditBox).string = this.panNumberStr;
        this.panNumberNode.getChildByName("content").getComponent(Label).string = this.panNumberStr;
        this.panNumberNode.getChildByName("EditBox").active = t;
        this.panNumberNode.getChildByName("content").active = !t;
        this.panNumberNode.getChildByName("EditBox").getComponent(EditBox).inputMode = EditBox.InputMode.SINGLE_LINE;
        this.panNumberNode.getChildByName("EditBox").getComponent(EditBox).maxLength = 10;
    }
    updateCardNumberStatus() {
        if (this.cardNumberNode) {
            let e = this.cardNumberNode.getChildByName("EditBox");
            this.cardNumberStr = ToolUtils.isSafeString(e.getComponent(EditBox).string);
            this.cardNumberStr.length > 0 && (0 == User.shared().data.resubmit_status || 3 == User.shared().data.resubmit_status) ? this.cardNumberNode.getChildByName("del_btn").active = true : this.cardNumberNode.getChildByName("del_btn").active = false;
            12 == this.cardNumberStr.length && 10 == this.panNumberStr.length ? this.showVerifyBtnStatus(1) : this.showVerifyBtnStatus(0);
        }
    }
    updatePanNumberStatus() {
        if (this.panNumberNode) {
            let e = this.panNumberNode.getChildByName("EditBox");
            this.panNumberStr = ToolUtils.isSafeString(e.getComponent(EditBox).string);
            this.panNumberStr.length > 0 && (0 == User.shared().data.resubmit_status || 3 == User.shared().data.resubmit_status) ? this.panNumberNode.getChildByName("del_btn").active = true : this.panNumberNode.getChildByName("del_btn").active = false;
            12 == this.cardNumberStr.length && 10 == this.panNumberStr.length ? this.showVerifyBtnStatus(1) : this.showVerifyBtnStatus(0);
        }
    }
    onEditDidBegan(e, t) {
    }
    onEditBoxChanged(e, t, i) {
        "card_number" == i ? this.updateCardNumberStatus() : "pan_number" == i && this.updatePanNumberStatus();
    }
    onEditBoxEnded(e, t) {
        "card_number" == t ? this.updateCardNumberStatus() : "pan_number" == t && this.updatePanNumberStatus();
    }
    showScrollivewUp(e) {
        if (ToolUtils.getIsInRoom()) {
            return;
        }
        let t = v3(0, 0);
        this.node.inverseTransformPoint(t, e.getWorldPosition());
        let i = GameConfig.REAL_SCREEN_HEIGHT;
        ToolUtils.getIsInRoom() && (i = GameConfig.REAL_SCREEN_WIDTH);
        let a = i / 2 + t.y - 34 - 80;
        a < this._keyboardHei ? this.rootNode.setPosition(v3(0, this._keyboardHei - a)) : this.rootNode.setPosition(v3(0, 0));
    }
    restoreScrollviewTop() {
        this.rootNode.setPosition(v3(0, 0));
    }
    updateVerifyView(e = false) {
        this._closed || (e && sys.isObjectValid(User.shared().kyc_resubmit_data) && sys.isObjectValid(User.shared().kyc_resubmit_data.loading_second) && i18nMgr.shared().changeLabelLanguage(this.secTipsLabel.getComponent(Label), "kyc.just_5_secs", false, User.shared().kyc_resubmit_data.loading_second), !sys.isObjectValid(User.shared().kyc_resubmit_data) || 0 != User.shared().kyc_resubmit_data.status && 3 != User.shared().kyc_resubmit_data.status ? this.verify_btn.getComponent(Button).interactable = false : (this.updateErrTips(), ToolUtils.isSafeString(User.shared().kyc_resubmit_data.aad_card).length > 0 && (this.updateCardNumberView(User.shared().kyc_resubmit_data.aad_card, true), this.updateCardNumberStatus()), ToolUtils.isSafeString(User.shared().kyc_resubmit_data.pan_card).length > 0 && (this.updatePanNumberView(User.shared().kyc_resubmit_data.pan_card, true), this.updatePanNumberStatus()), this.verify_btn.getComponent(Button).interactable = true, 0 == User.shared().kyc_resubmit_data.status ? i18nMgr.shared().changeLabelLanguage(this.verify_btn.getChildByName("wz").getComponent(Label), "kyc.verify", true) : (Utils.shared().hideLoading(), i18nMgr.shared().changeLabelLanguage(this.verify_btn.getChildByName("wz").getComponent(Label), "kyc.resubmit", true))));
    }
    updatePanName() {
        let e = "";
        if (sys.isObjectValid(User.shared().DepositTransferData) && sys.isObjectValid(User.shared().DepositTransferData.list)) {
            for (let t = 0, i = User.shared().DepositTransferData.list.length; t < i; t++) {
                let i = User.shared().DepositTransferData.list[t];
                2 == i.type && sys.isObjectValid(i.pan_name) && (e = i.pan_name);
            }
        }
        if (sys.isObjectValid(e) && e.length > 0) {
            let t = this.tipsNode.getChildByName("label_pan_name").getComponent(Label);
            e.length > 30 ? t.fontSize = this._panNameSize - 10 : e.length > 28 ? t.fontSize = this._panNameSize - 8 : e.length > 25 ? t.fontSize = this._panNameSize - 6 : e.length > 22 && (t.fontSize = this._panNameSize - 4);
            t.string = e;
        }
    }
    onButtonClick(e, t) {
        if (SoundManager.shared().playFx("click"), "back" == t || "close" == t) {
            this.onCloseLogic();
        }
        else if ("verify" == t) {
            if (!User.shared().checkLocationPermit(CheckModule.KYC, this.from_source)) {
                return;
            }
            let e = ToolUtils.isSafeString(this.cardNumberStr);
            if (12 !== e.length) {
                return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text78"), 2);
            }
            let t = ToolUtils.isSafeString(this.panNumberStr);
            if (10 !== t.length) {
                return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text78"), 2);
            }
            sys.isObjectValid(User.shared().kyc_resubmit_data) && sys.isObjectValid(User.shared().kyc_resubmit_data.reason) && User.shared().kyc_resubmit_data.reason > 0 && (User.shared().kyc_resubmit_data.reason = "", this.updateErrTips());
            this.showVerifyBtnStatus(2);
            this.verify_btn.getChildByName("wz").getComponent(Label).string = i18nMgr.shared().getValueByKey("kyc.verity_pending");
            this.stopCountDownActin();
            this._countDownAction = TweenTool.delayAct(this.node, (() => {
                Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text37"), 3);
                this.revertBtnStatus(1);
            }), 30, true);
            HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Hall, event: ReportConfig.hall_evt.click_resubmit_submit });
            HttpManager.shared().doKycResubmitSava(e, t, this.listenSubmitCall.bind(this));
        }
        else if ("check" == t) {
            this.onCloseLogic();
        }
        else if ("cardnumber_del" == t) {
            let e = this.cardNumberNode.getChildByName("EditBox");
            e.getComponent(EditBox).string = "";
            e.getComponent(EditBox).blur();
            this.updateCardNumberStatus();
        }
        else if ("panNumber_del" == t) {
            let e = this.panNumberNode.getChildByName("EditBox");
            e.getComponent(EditBox).string = "";
            e.getComponent(EditBox).blur();
            this.updatePanNumberStatus();
        }
        else if ("check_more" == t) {
            this.onCloseLogic();
            ToolUtils.getIsInRoom() && (User.shared().BackHallOpenModule = 3, User.shared().isShowPopList = false, PushCenter.shared().pushEvent(GameConfig.BackToHall));
        }
        else if ("feedBack" == t) {
            if (1 == User.shared().temp_pingbi.feedback) {
                return void Utils.shared().showToast("Coming soon", 2);
            }
            Utils.shared().doJumpLogic(PushEvent.JUMP_TO_FEEDBACK);
        }
    }
    revertBtnStatus(e) {
        this.showVerifyBtnStatus(e);
        this.updateVerifyView();
    }
    listenSubmitCall(e, t, i) {
        if (200 !== i) {
            ToolUtils.isObjValid(this.node) && (Utils.shared().hideLoading(), Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text37"), 2), this.stopCountDownActin(), this.revertBtnStatus(1));
        }
        else {
            try {
                let e = ToolUtils.parseJson(t);
                if (0 === e.ret) {
                    HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Hall, event: ReportConfig.hall_evt.kyc_resubmit_succ });
                    let t = e.data.status;
                    sys.isObjectValid(User.shared().kyc_resubmit_data) || (User.shared().kyc_resubmit_data = {});
                    User.shared().kyc_resubmit_data.status = t;
                    User.shared().data.resubmit_status = t;
                    User.shared().data.show_resubmit = 2 == t ? 0 : 1;
                    e.data.aad_card && (User.shared().kyc_resubmit_data.aad_card = e.data.aad_card);
                    e.data.pan_card && (User.shared().kyc_resubmit_data.pan_card = e.data.pan_card);
                    2 == User.shared().kyc_resubmit_data.status ? HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Hall, event: ReportConfig.hall_evt.resubmit_verify_succ }) : 3 == User.shared().kyc_resubmit_data.status && HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Hall, event: ReportConfig.hall_evt.resubmit_verify_fail });
                    2 != t && 1 != t || User.shared().getBannerData();
                    sys.isObjectValid(e.data.loading_seconds) && Number(e.data.loading_seconds) > 0 ? ToolUtils.isObjValid(this.node) && (1 == User.shared().kyc_resubmit_data.status && (this.verify_btn.getComponent(Button).interactable = false, i18nMgr.shared().changeLabelLanguage(this.verify_btn.getChildByName("wz").getComponent(Label), "kyc.verity_pending", true)), this.showVerifyWaitTime(Number(e.data.loading_seconds)), this.stopCountDownActin(), this._countDownAction = TweenTool.delayAct(this.node, (() => {
                        Utils.shared().hideLoading();
                        this.updateCheckStatus();
                        this.updateVerifyView();
                        User.shared().doGetKycVerifyList();
                    }), Number(e.data.loading_seconds), true)) : (2 != t && 1 != t || (User.shared().kyc_resubmit_data.reason = "", ToolUtils.isObjValid(this.node) && (this.stopCountDownActin(), 2 == t ? (Utils.shared().showToast(i18nMgr.shared().getValueByKey("kyc.submit_success"), 2), ToolUtils.isObjValid(this.node) && this.onBackView()) : (this.updateCheckStatus(), this.revertBtnStatus(0)))), PushCenter.shared().pushEvent(GameConfig.Update_Kyc, User.shared().data.kyc_check));
                }
                else {
                    ToolUtils.isObjValid(this.node) && (this.stopCountDownActin(), this.revertBtnStatus(1), e.desc && e.desc.length > 0 && Utils.shared().showToast(e.desc, 2));
                    let t = e.ret + ToolUtils.isSafeString(e.desc);
                    HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Hall, event: ReportConfig.hall_evt.kyc_resubmit_fail, kyc_err: t });
                }
            }
            catch (e) {
                ToolUtils.isObjValid(this.node) && (this.stopCountDownActin(), this.revertBtnStatus(1));
                let t = ToolUtils.isSafeString(e.toString());
                HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Hall, event: ReportConfig.hall_evt.kyc_resubmit_fail, kyc_err: t });
            }
        }
    }
    showVerifyBtnStatus(e) {
        let t = sys.isObjectValid(User.shared().kyc_resubmit_data) ? User.shared().kyc_resubmit_data.status : User.shared().data.resubmit_status, i = this.verify_btn.getChildByName("anim_waiting");
        1 == e ? (this.verify_btn.getComponent(Button).interactable = true, this.verify_btn.getChildByName("di").getComponent(Sprite).spriteFrame = this.verifyBtnDiImags[1], this.verify_btn.getChildByName("di").active = true, 0 == t ? i18nMgr.shared().changeLabelLanguage(this.verify_btn.getChildByName("wz").getComponent(Label), "kyc.verify", true) : i18nMgr.shared().changeLabelLanguage(this.verify_btn.getChildByName("wz").getComponent(Label), "kyc.resubmit", true), i.active = false, this.verify_btn.getChildByName("wz").getComponent(LabelShadow).color = CommDefine.shadowcolor.green, this.verify_btn.getChildByName("wz").getComponent(LabelShadow).enabled = true, Utils.updateLabelMaterial(this.verify_btn.getChildByName("wz"), CommDefine.gradient.btn_green)) : 0 == e ? (this.verify_btn.getComponent(Button).interactable = false, this.verify_btn.getChildByName("di").getComponent(Sprite).spriteFrame = this.verifyBtnDiImags[0], this.verify_btn.getChildByName("di").active = true, 0 == t ? i18nMgr.shared().changeLabelLanguage(this.verify_btn.getChildByName("wz").getComponent(Label), "kyc.verify", true) : i18nMgr.shared().changeLabelLanguage(this.verify_btn.getChildByName("wz").getComponent(Label), "kyc.resubmit", true), i.active = false, this.verify_btn.getChildByName("wz").getComponent(LabelShadow).enabled = true, this.verify_btn.getChildByName("wz").getComponent(LabelShadow).color = CommDefine.shadowcolor.gray, Utils.updateLabelMaterial(this.verify_btn.getChildByName("wz"), CommDefine.gradient.btn_gray)) : 2 == e && (this.verify_btn.getComponent(Button).interactable = false, i.active = true, this.verify_btn.getChildByName("wz").getComponent(LabelShadow).enabled = true, this.verify_btn.getChildByName("wz").getComponent(LabelShadow).color = CommDefine.shadowcolor.gray, this.verify_btn.getChildByName("di").active = true, this.verify_btn.getChildByName("di").getComponent(Sprite).spriteFrame = this.verifyBtnDiImags[0], Utils.updateLabelMaterial(this.verify_btn.getChildByName("wz"), CommDefine.gradient.btn_gray));
    }
    showVerifyWaitTime(e) {
        if (this._identitytimeAction && TweenTool.stopAction(this._identitytimeAction), this._mIdTime = Number(e), e > 0) {
            this.showVerifyBtnStatus(2);
            let t = this.verify_btn.getChildByName("wz");
            t.getComponent(Label).string = ToolUtils.format(i18nMgr.shared().getValueByKey("kyc.pending_count"), String(e));
            this._identitytimeAction = TweenTool.myschedule(this.node, 1, (() => {
                this._mIdTime -= 1;
                this._mIdTime <= 0 ? (this.stopIdentityActin(), this.updateCheckStatus(), this.updateVerifyView(), this.updateCardNumberStatus(), User.shared().doGetKycVerifyList()) : t.getComponent(Label).string = ToolUtils.format(i18nMgr.shared().getValueByKey("kyc.pending_count"), String(this._mIdTime));
            }));
        }
    }
    stopCountDownActin() {
        this._countDownAction && (TweenTool.stopAction(this._countDownAction), this._countDownAction = null);
    }
    stopIdentityActin() {
        this._identitytimeAction && (TweenTool.stopAction(this._identitytimeAction), this._identitytimeAction = null);
    }
    onCloseLogic() {
        PushCenter.shared().pushEvent(PushEvent.onKycGuideRemove);
        this.stopIdentityActin();
        this.stopCountDownActin();
        this.isNext && PushCenter.shared().pushEvent(PushEvent.Update_NextPopActivity);
        this.onRemoveWindow();
    }
    onRemoveWindow() {
        this._closed || ToolUtils.isObjValid(this.node) && (this._closed = true, this.node.destroy());
    }
    onBackView() {
        this.onCloseLogic();
    }
}
