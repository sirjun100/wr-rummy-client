// @ts-nocheck
// Recovered from index.js:537
import { _decorator, instantiate, Label, Node, Sprite, SpriteFrame, sys, v3 } from "cc";
import Parent from "./Parent";
import PushCenter from "./PushCenter";
import SoundManager from "./SoundManager";
import { ToolUtils } from "./ToolUtils";
import { SixPointManager } from "./SixPointManager";
import TweenTool from "./TweenTool";
const { ccclass, property } = _decorator;
@ccclass("SixPointTable")
export default class SixPointTable extends Parent {
    public _TAG: string = "SixPointTable";
    public lastClick: number = 0;
    public gameCallback: any = null;
    @property(Node)
    public dsMoban: Node = null;
    @property([SpriteFrame])
    public ds_bgs: SpriteFrame[] = [];
    @property([Node])
    public trend_root: Node[] = [];
    onLoad() {
    }
    onDestroy() {
        super.onDestroy();
        this.unscheduleAllCallbacks();
        PushCenter.shared().removeListenersByTag(this);
    }
    start() {
        this.initView();
        this.addPushNotify();
    }
    setCallBack(t) {
        this.gameCallback = t;
    }
    getZhuangPoint() {
        let t = this.node.getChildByName("heguan");
        if (ToolUtils.isObjValid(t)) {
            let e = v3(0, 0);
            return t.getWorldPosition(e), e;
        }
        return v3(0, 0);
    }
    refreshSeziHistoryRecode(t) {
        let e = SixPointManager.shared().history_recordVec.length;
        for (let i = 0; i < 6; i++) {
            if (this.trend_root[i].active = true, this.trend_root[i].removeAllChildren(), e > i) {
                let e = SixPointManager.shared().history_recordVec[i].length;
                if (e <= 0) {
                    continue;
                }
                let o = 0;
                e > 12 && (o = e - 12, e = 12 + o);
                for (let s = o; s < e; s++) {
                    let o = SixPointManager.shared().history_recordVec[i][s], n = instantiate(this.dsMoban);
                    if (ToolUtils.isObjValid(n)) {
                        n.active = true;
                        let s = n.getChildByName("num");
                        o <= 1 ? (n.getComponent(Sprite).spriteFrame = this.ds_bgs[0], s.getComponent(Label).string = "X") : (n.getComponent(Sprite).spriteFrame = this.ds_bgs[1], s.getComponent(Label).string = "" + o);
                        n.getChildByName("effect").active = false;
                        this.trend_root[i].addChild(n);
                        i == e - 1 && t && (n.getChildByName("effect").active = true, TweenTool.blink(n.getChildByName("effect"), 5, true, (() => {
                            n.getChildByName("effect").active = false;
                        }), n));
                    }
                }
            }
        }
    }
    addPushNotify() {
    }
    initView() {
    }
    resetInfo() {
        for (let t = 0; t <= 5; t++) {
            this.showMeXzGoldNum(0, t);
            this.showOthersXzGoldNum(0, t);
        }
    }
    showMeXzGoldNum(t, e) {
        let i = `xz_me_gold${e}`, o = this.node.getChildByName(i);
        ToolUtils.isObjValid(o) && (o.getComponent(Label).string = ToolUtils.parse_ChipNum2(t));
    }
    showOthersXzGoldNum(t, e) {
        let i = `xz_other_gold${e}`, o = this.node.getChildByName(i);
        ToolUtils.isObjValid(o) && (o.getComponent(Label).string = ToolUtils.parse_ChipNum2(t));
    }
    touchBtnEvent(t, e) {
        SoundManager.shared().playFx("click");
        sys.now() - this.lastClick < 200 || (this.lastClick = sys.now(), sys.isObjectValid(this.gameCallback) && this.gameCallback(e));
    }
}
