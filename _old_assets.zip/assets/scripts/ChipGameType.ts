// @ts-nocheck
// Recovered from index.js:67
import { _decorator, Label, sys } from "cc";
import i18nMgr from "./i18nMgr";
import SoundManager from "./SoundManager";
import BaseLayer from "./BaseLayer";
import PushCenter from "./PushCenter";
import { ToolUtils } from "./ToolUtils";
const { ccclass } = _decorator;
@ccclass("ChipGameType")
export class ChipGameType extends BaseLayer {
    public rootNode: any = null;
    public _callback: any = null;
    public _infoStr: string = "";
    public _min_entry: number = 0;
    public cur_money: number = 0;
    public _isHelp: boolean = false;
    start() {
        super.start();
        ToolUtils.showFullScreen(this.node.getChildByName("mask"));
        for (let t = 1; t <= 3; t++) {
            this.node.getChildByName("node" + t).active = false;
        }
        if (this._isHelp ? this.rootNode = this.node.getChildByName("node3") : ToolUtils.getOrientation() ? this.rootNode = this.node.getChildByName("node2") : this.rootNode = this.node.getChildByName("node1"), this.rootNode.active = true, ToolUtils.startShowAnim(this.rootNode), ToolUtils.getOrientation()) {
            if (2 == i18nMgr.shared().language && ToolUtils.isObjValid(this.rootNode.getChildByName("btn_start"))) {
                let t = this.rootNode.getChildByName("btn_start").getChildByName("wz");
                ToolUtils.isObjValid(t) && (t.getComponent(Label).fontSize = 24, t.getComponent(Label).lineHeight = 34);
            }
        }
        else if (2 == i18nMgr.shared().language && ToolUtils.isObjValid(this.rootNode.getChildByName("btn_start"))) {
            let t = this.rootNode.getChildByName("btn_start").getChildByName("wz");
            ToolUtils.isObjValid(t) && (t.getComponent(Label).fontSize = 24, t.getComponent(Label).lineHeight = 34);
        }
    }
    initParaData(t, e = null) {
        this._callback = e;
        sys.isObjectValid(t) && (sys.isObjectValid(t.min_entry) && (this._min_entry = t.min_entry), sys.isObjectValid(t.isHelp) && (this._isHelp = t.isHelp));
    }
    onButtonClick(t, e) {
        ("close" == e || "start" == e || "close_di" == e && this._isHelp) && (SoundManager.shared().playFx("click"), this.onBackView());
    }
    onBackView() {
        ToolUtils.isObjValid(this.node) && this.node.destroy();
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().removeListenersByTag(this);
    }
}
