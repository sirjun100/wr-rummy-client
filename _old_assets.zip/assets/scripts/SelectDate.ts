// @ts-nocheck
// Recovered from index.js:505
import { _decorator, Node } from "cc";
import BaseLayer from "./BaseLayer";
import LoopScrollView from "./LoopScrollView";
import SoundManager from "./SoundManager";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("SelectDate")
export class SelectDate extends BaseLayer {
    @property(Node)
    public dayScrollView: Node = null;
    @property(Node)
    public monthScrollView: Node = null;
    @property(Node)
    public yearScrollView: Node = null;
    public dayIndex: number = 0;
    public monthIndex: number = 0;
    public yearIndex: number = 0;
    public strDay: string = "";
    public strMonth: string = "";
    public strYear: string = "";
    public curDay: number = 0;
    public curMonth: number = 0;
    public curYear: number = 0;
    public maxDay: number = 0;
    public _cb: any = null;
    public dayArray: any[] = [];
    public monthArray: any[] = [];
    public yearArray: any[] = [];
    setCallBack(t, e, r, i) {
        this._cb = t;
        var a = new Date;
        this.curYear = a.getFullYear() - 18;
        this.curMonth = a.getMonth() + 1;
        this.curDay = a.getDate();
        this.yearArray = [];
        for (let t = 0; t < 100; t++) {
            this.yearArray.push(String(this.curYear - t));
        }
        this.updateDateArray(e, r, i);
        for (let t = 0, e = this.yearArray.length; t < e; t++) {
            if (i == this.yearArray[t]) {
                this.yearIndex = t;
                break;
            }
        }
        for (let t = 0, e = this.monthArray.length; t < e; t++) {
            if (r == this.monthArray[t]) {
                this.monthIndex = t;
                break;
            }
        }
        for (let t = 0, r = this.dayArray.length; t < r; t++) {
            if (e == this.dayArray[t]) {
                this.dayIndex = t;
                break;
            }
        }
    }
    updateDateArray(t, e, r) {
        let i = 12;
        r == String(this.curYear) && (i = this.curMonth, this.strMonth = String(this.curMonth));
        this.monthIndex > i && (this.monthIndex = i - 1);
        this.monthArray = [];
        for (let t = 0; t < i; t++) {
            let e = ToolUtils.format("0${0}", t + 1).slice(-2);
            this.monthArray.push(e);
        }
        let a = ToolUtils.getMothHaveDay(Number(r), Number(e));
        Number(r) == this.curYear && Number(e) == this.curMonth && (a = this.curDay, this.strDay = String(this.curDay));
        this.dayIndex >= a && (this.dayIndex = a - 1);
        this.dayArray = [];
        for (let t = 0; t < a; t++) {
            let e = ToolUtils.format("0${0}", t + 1).slice(-2);
            this.dayArray.push(e);
        }
    }
    start() {
        super.start();
        this.initView();
    }
    initView() {
        this.dayScrollView.getComponent(LoopScrollView).initData(this.dayArray, this.dayLoopScrollViewCallBack.bind(this), this.dayIndex);
        this.monthScrollView.getComponent(LoopScrollView).initData(this.monthArray, this.monthLoopScrollViewCallBack.bind(this), this.monthIndex);
        this.yearScrollView.getComponent(LoopScrollView).initData(this.yearArray, this.yearLoopScrollViewCallBack.bind(this), this.yearIndex, false);
    }
    dayLoopScrollViewCallBack(t, e) {
        this.dayIndex != t && (this.dayIndex = t, this.strDay = e);
    }
    monthLoopScrollViewCallBack(t, e) {
        if (this.monthIndex != t) {
            this.monthIndex = t;
            this.strMonth = e;
            this.updateDateArray(this.strDay, this.strMonth, this.strYear);
            this.dayScrollView.getComponent(LoopScrollView).updateData(this.dayArray, this.dayIndex);
        }
    }
    yearLoopScrollViewCallBack(t, e) {
        if (this.yearIndex != t) {
            this.yearIndex = t;
            this.strYear = e;
            this.updateDateArray(this.strDay, this.strMonth, this.strYear);
            this.dayScrollView.getComponent(LoopScrollView).updateData(this.dayArray, this.dayIndex);
            this.monthScrollView.getComponent(LoopScrollView).updateData(this.monthArray, this.monthIndex);
        }
    }
    onButtonClick(t, e) {
        SoundManager.shared().playFx("click");
        "ok" == e && (this._cb && this._cb(this.dayArray[this.dayIndex], this.monthArray[this.monthIndex], this.yearArray[this.yearIndex]), ToolUtils.isObjValid(this.node) && this.node.destroy());
    }
}
