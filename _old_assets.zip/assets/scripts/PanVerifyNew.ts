// @ts-nocheck
// Recovered from index.js:333
import { _decorator, assetManager, Button, EditBox, Label, Node, ScrollView, size, Sprite, SpriteFrame, sys, UITransform, v3, Widget } from "cc";
import BaseLayer from "./BaseLayer";
import SoundManager from "./SoundManager";
import { TransferPlatform } from "./TransferPlatform";
import PushCenter from "./PushCenter";
import GameConfig from "./GameConfig";
import { TLog } from "./TLog";
import Utils from "./Utils";
import User from "./User";
import HttpManager from "./HttpManager";
import PushEvent from "./PushEvent";
import i18nMgr from "./i18nMgr";
import TweenTool from "./TweenTool";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("PanVerifyNew")
export class PanVerifyNew extends BaseLayer {
    @property(Node)
    public rootNode: Node = null;
    @property(ScrollView)
    public scrollView: ScrollView = null;
    @property(Node)
    public errTipNode: Node = null;
    @property(Node)
    public panelCenter: Node = null;
    @property(Node)
    public photoNode: Node = null;
    @property(Node)
    public infoNode: Node = null;
    @property(Node)
    public frontErrNode: Node = null;
    @property(Node)
    public uploadBtn: Node = null;
    @property(Button)
    public uploadBtn2: Button = null;
    @property(Node)
    public cardNumberNode: Node = null;
    @property(Node)
    public submit_btn: Node = null;
    @property(Node)
    public tipsNode: Node = null;
    public frontImgPath: any = null;
    public frontImgName: string = "";
    public cardNumberStr: string = "";
    public isLoadingImg: boolean = false;
    public bShowPushAnim: boolean = false;
    public showUICallback: any = null;
    public closeUICallBack: any = null;
    public _closed: boolean = false;
    public _source_type: number = 0;
    public _frontImgDataStr: string = "";
    public _uploadImgSize: any = size(495, 300);
    public _callback: any = null;
    public _bBtnEnable: boolean = true;
    public _bCanUpdate: boolean = false;
    onLoad() {
        if (ToolUtils.isSafeString(User.shared().kyc_bottom_tip).length > 0) {
            this.tipsNode.getComponent(Label).string = User.shared().kyc_bottom_tip;
        }
        else {
            let t = i18nMgr.shared().getValueByKey("kyc.kyc_18tips");
            this.tipsNode.getComponent(Label).string = t;
        }
    }
    init(t, e = null, a = null) {
        this.bShowPushAnim = t;
        this.showUICallback = e;
        this.closeUICallBack = a;
    }
    initData(t = null, e = null) {
        t && (this._source_type = t);
        this._callback = e;
    }
    start() {
        if (super.start(), this.initView(), this.bShowPushAnim && ToolUtils.showPushAnim(this.node, 0, (() => {
            this.showUICallback && this.showUICallback();
        })), PushCenter.shared().addListener(GameConfig.GetLocalImage, (t => {
            if (ToolUtils.isObjValid(this.node)) {
                this.frontImgPath = t.img_path;
                let e = t.img_path;
                try {
                    let t = this;
                    this.isLoadingImg = true;
                    assetManager.loadRemote(e, (function (a, i) {
                        if (null != a) {
                            return void Utils.shared().hideToast();
                        }
                        const n = SpriteFrame.createWithImage(i);
                        let s = null;
                        s = t.photoNode.getChildByName("front_img");
                        s.getComponent(Sprite).spriteFrame = n;
                        s.getComponent(UITransform).setContentSize(t._uploadImgSize);
                        t.isLoadingImg = false;
                        TransferPlatform.shared().image2Text(e, "MainHall", t, "onFrontImgToText");
                        ToolUtils.isObjValid(t.node) && !TransferPlatform.shared().getIsCanOCR() ? t.doUploadImg() : Utils.shared().hideToast();
                    }));
                }
                catch (t) {
                    Utils.shared().hideToast();
                }
            }
        }), this), PushCenter.shared().addListener(PushEvent.Update_PanInfo, (() => {
            ToolUtils.isObjValid(this.node) && this.updateCardVerifyView();
        }), this), PushCenter.shared().addListener(PushEvent.Update_PanResult, (() => {
            ToolUtils.isObjValid(this.node) && 2 == User.shared().pan_check && (Utils.shared().hideLoading(), Utils.shared().showToast(i18nMgr.shared().getValueByKey("kyc.pancard_verify_suc"), 2), 1 == this._source_type && this._callback && this._callback(1), this.onBackView());
        }), this), ToolUtils.isObjValid(this.panelCenter.getChildByName("tips"))) {
            this.panelCenter.getChildByName("tips").getComponent(Label).updateRenderData(true);
            let t = this.panelCenter.getChildByName("tips").getComponent(UITransform).contentSize.height;
            if (t > 55) {
                let e = this.photoNode.getPosition();
                this.photoNode.setPosition(v3(e.x, e.y - (t - 40), e.z));
                e = this.infoNode.getPosition();
                this.infoNode.setPosition(v3(e.x, e.y - (t - 40), e.z));
            }
        }
    }
    dealQrCodeInfo(t) {
    }
    onFrontImgToText(t) {
        this._frontImgDataStr = t;
        let e = sys.isObjectValid(User.shared().pancard_data.photo_clear_level) ? User.shared().pancard_data.photo_clear_level : 1;
        this._bCanUpdate = 3 == e;
        try {
            if (this._frontImgDataStr.length > 10) {
                let t = this._frontImgDataStr.split("###");
                if (t.length >= 4) {
                    let a, i = -1, n = -1, s = -1, r = ["INCOME", "NCOMET", "COMETA", "OMETAX", "METAXD", "ETAXDE", "TAXDEP", "AXDEPA", "XDEPAR", "DEPART", "EPARTM", "PARTME", "ARTMEN", "RTMENT"], o = ["PermanentA", "ermanentAc", "rmanentAcc", "manentAcco", "anentAccou", "nentAccoun", "entAccount", "ntAccountN", "tAccountNu", "AccountNum", "ccountNumb", "countNumbe", "ountNumber", "untNumberC", "ntNumberCa", "tNumberCar", "NumberCard"], d = ["GOVT.O", "OVT.OF", "VT.OFI", "T.OFIN", ".OFIND", "OFINDI", "FINDIA"];
                    for (let e = 0, h = t.length; e < h; e++) {
                        if (a = t[e].repeat(1), a = a.replace(/ /g, ""), -1 == i) {
                            for (let t = 0, n = r.length; t < n; t++) {
                                if (-1 != a.indexOf(r[t])) {
                                    i = e;
                                    break;
                                }
                            }
                            if (i >= 0) {
                                continue;
                            }
                        }
                        if (-1 == s) {
                            for (let t = 0, i = o.length; t < i; t++) {
                                if (-1 != a.indexOf(o[t])) {
                                    s = e;
                                    break;
                                }
                            }
                            if (s >= 0) {
                                continue;
                            }
                        }
                        if (-1 == n) {
                            for (let t = 0, i = d.length; t < i; t++) {
                                if (-1 != a.indexOf(d[t])) {
                                    n = e;
                                    break;
                                }
                            }
                            if (n >= 0) {
                                continue;
                            }
                        }
                    }
                    let h = /[A-Z]/, l = /\d/, c = false;
                    if (s >= 0) {
                        let e = t[s + 1];
                        if (e && 10 == e.length && h.test(e) && l.test(e)) {
                            this.updateCardNumberView2(e);
                            c = true;
                        }
                        else {
                            let e = t[s - 1];
                            e && 10 == e.length && h.test(e) && l.test(e) && (this.updateCardNumberView2(e), c = true);
                        }
                    }
                    if (!c) {
                        let e = "";
                        for (let i = 0, n = t.length; i < n; i++) {
                            if (a = t[i].repeat(1), a = a.replace(/ /g, ""), a && 10 == a.length && h.test(a) && l.test(a)) {
                                e = a;
                                break;
                            }
                        }
                        e.length > 0 && (this.updateCardNumberView2(e), c = true);
                    }
                    1 == e ? i >= 0 && n >= 0 && c ? (this._bCanUpdate = true, this.frontErrNode.active = false, this.updateBtnStatus(2)) : (sys.isObjectValid(User.shared().data.open_signzy) && 1 == Number(User.shared().data.open_signzy) && (this.frontErrNode.active = true, this._bCanUpdate = false), this.updateBtnStatus(1)) : (this._bCanUpdate = true, this.frontErrNode.active = false);
                }
                else {
                    sys.isObjectValid(User.shared().data.open_signzy) && 1 == Number(User.shared().data.open_signzy) && 1 == e && (this.frontErrNode.active = true, this._bCanUpdate = false, this.updateBtnStatus(1));
                }
            }
            else {
                sys.isObjectValid(User.shared().data.open_signzy) && 1 == Number(User.shared().data.open_signzy) && 1 == e && (this.frontErrNode.active = true, this._bCanUpdate = false, this.updateBtnStatus(1));
                TransferPlatform.shared().getIsCanOCR() || (this._bCanUpdate = true, this.frontErrNode.active = false);
            }
        }
        catch (t) {
            TLog.printError("--------- onFrontImgToText err:", t);
        }
    }
    updateBtnStatus(t) {
        try {
            0 == t ? (i18nMgr.shared().changeLabelLanguage(this.uploadBtn.getChildByName("wz").getComponent(Label), "kyc.upload", true), this.uploadBtn.getChildByName("wz").active = true, this.uploadBtn.getChildByName("gou").active = false, this.uploadBtn.getComponent(Button).interactable = true, this.uploadBtn2.interactable = true) : 1 == t ? (i18nMgr.shared().changeLabelLanguage(this.uploadBtn.getChildByName("wz").getComponent(Label), "kyc.reUpload", true), this.uploadBtn.getChildByName("wz").active = true, this.uploadBtn.getChildByName("gou").active = false, this.uploadBtn.getComponent(Button).interactable = true, this.uploadBtn2.interactable = true) : 2 == t && (this.uploadBtn.getChildByName("wz").active = false, this.uploadBtn.getChildByName("gou").active = true, this.uploadBtn.getComponent(Button).interactable = false, this.uploadBtn2.interactable = false);
        }
        catch (t) {
        }
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().removeListenersByTag(this);
        this.unscheduleAllCallbacks();
        this.isLoadingImg && Utils.shared().hideToast();
    }
    initView() {
        this.fitScreen();
        this.updateCardVerifyView();
        sys.isObjectValid(User.shared().pancard_data) || Utils.shared().showLoading(10, true, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3);
        }));
        HttpManager.shared().doGetPanCardInfo2(((t, e, a) => {
            try {
                if (200 != a) {
                    alert("The login timed out, please try again");
                }
                else {
                    let t = ToolUtils.parseJson(e);
                    0 == t.ret && (User.shared().pancard_data = t.data, ToolUtils.isObjValid(this.node) && this.updateCardVerifyView());
                }
            }
            catch (t) {
                TLog.printError("PanVerifyNew listenGetPanCardInfoCallback:", t);
            }
        }));
    }
    updateCardVerifyView(t = true) {
        this.submit_btn.getComponent(Button).interactable = false;
        let e = false;
        0 == User.shared().pan_check || 3 == User.shared().pan_check ? (e = true, this.submit_btn.getComponent(Button).interactable = true, 0 == User.shared().pan_check ? i18nMgr.shared().changeLabelLanguage(this.submit_btn.getChildByName("wz").getComponent(Label), "kyc.submit", true) : (Utils.shared().hideLoading(), i18nMgr.shared().changeLabelLanguage(this.submit_btn.getChildByName("wz").getComponent(Label), "kyc.resubmit", true))) : (e = false, this.submit_btn.getComponent(Button).interactable = false, 1 == User.shared().pan_check ? i18nMgr.shared().changeLabelLanguage(this.submit_btn.getChildByName("wz").getComponent(Label), "kyc.verity_pending", true) : (Utils.shared().hideLoading(), i18nMgr.shared().changeLabelLanguage(this.submit_btn.getChildByName("wz").getComponent(Label), "kyc.verity_verified", true)));
        let a = this.errTipNode.getChildByName("tx");
        ToolUtils.isObjValid(a) && t && this.updateErrTips();
        sys.isObjectValid(User.shared().pancard_data) && (this.updateCardTypeView(User.shared().pancard_data, e, t), this.updateCardNumberView(User.shared().pancard_data, e, t));
    }
    updateErrTips() {
        if (User.shared().pancard_data && ToolUtils.isSafeString(User.shared().pancard_data.reason).length > 0) {
            this.errTipNode.active = true;
            this.errTipNode.getChildByName("tx").getComponent(Label).string = User.shared().pancard_data.reason;
            this.errTipNode.getChildByName("tx").getComponent(Label).updateRenderData(true);
            let t = this.errTipNode.getComponent(UITransform).contentSize, e = this.errTipNode.getChildByName("tx").getComponent(UITransform).contentSize.height + 8;
            this.errTipNode.getComponent(UITransform).setContentSize(size(t.width, e));
            this.panelCenter.setPosition(v3(0, -e, 0));
            t = this.scrollView.content.getComponent(UITransform).contentSize;
            this.scrollView.content.getComponent(UITransform).setContentSize(size(t.width, 1000 + e));
        }
        else {
            this.errTipNode.active = false;
            this.errTipNode.getChildByName("tx").getComponent(Label).string = "";
            this.panelCenter.setPosition(v3(0, 0, 0));
            let t = this.scrollView.content.getComponent(UITransform).contentSize;
            this.scrollView.content.getComponent(UITransform).setContentSize(size(t.width, 1000));
        }
    }
    updateCardTypeView(t, e, a = true) {
        if (ToolUtils.isObjValid(this.photoNode)) {
            this.photoNode.active = true;
            let i = this.photoNode.getChildByName("front_bg"), n = this.photoNode.getChildByName("front_img");
            a && (this.frontImgPath, t.photo_frontend && t.photo_frontend.length > 0 ? (e ? this.updateBtnStatus(1) : this.updateBtnStatus(2), 3 == User.shared().pan_check ? (this.frontImgName = "", n.getComponent(Sprite).spriteFrame = null, i.active = true) : (i.active = false, this.frontImgName = t.photo_frontend, Utils.shared().updateNetImage(n.getComponent(Sprite), User.shared().data.kyc_imgPath + t.photo_frontend, this._uploadImgSize))) : (this.frontImgName = "", n.getComponent(Sprite).spriteFrame = null, i.active = true, this.updateBtnStatus(0)));
        }
    }
    updateCardNumberView(t, e, a = true) {
        a && (this.cardNumberStr = "", t.card && t.card.length > 0 && (this.cardNumberStr = t.card), this.cardNumberNode.getChildByName("del_btn").active = false);
        this.cardNumberNode.getChildByName("EditBox").getComponent(EditBox).string = this.cardNumberStr;
        this.cardNumberNode.getChildByName("content").getComponent(Label).string = this.cardNumberStr;
        this.cardNumberNode.getChildByName("EditBox").active = e;
        this.cardNumberNode.getChildByName("content").active = !e;
    }
    updateCardNumberView2(t) {
        this.cardNumberStr = t;
        this.cardNumberNode.getChildByName("EditBox").getComponent(EditBox).string = this.cardNumberStr;
        this.cardNumberNode.getChildByName("content").getComponent(Label).string = this.cardNumberStr;
        this.cardNumberNode.getChildByName("EditBox").active = true;
        this.cardNumberNode.getChildByName("content").active = false;
        this.cardNumberNode.getChildByName("del_btn").active = ToolUtils.isSafeString(this.cardNumberStr).length > 0;
    }
    onButtonClick(t, e) {
        if (SoundManager.shared().playFx("click"), "close" == e) {
            1 == this._source_type && this._callback && this._callback(1);
            this.onBackView();
        }
        else if ("kefu" == e) {
            if (1 == User.shared().temp_pingbi.feedback) {
                return void Utils.shared().showToast("Coming soon", 2);
            }
            Utils.shared().doJumpLogic(PushEvent.JUMP_TO_FEEDBACK);
        }
        else if ("front" == e) {
            this.isLoadingImg || Utils.shared().showKycPhotoView(this.node, this.photoCallBack.bind(this));
        }
        else if ("cardnumber_del" == e) {
            let t = this.cardNumberNode.getChildByName("EditBox");
            t.getComponent(EditBox).string = "";
            t.getComponent(EditBox).blur();
            this.updateCardNumberStatus();
        }
        else {
            "noEditName" == e && Utils.shared().showToast(i18nMgr.shared().getValueByKey("kyc.no_edit_name_tips"), 2);
        }
    }
    photoCallBack(t) {
        let e = sys.now() + ".jpg";
        "takephoto" == t ? TransferPlatform.shared().openCamera(e, 1, GameConfig.REAL_SCREEN_HEIGHT, GameConfig.REAL_SCREEN_HEIGHT) : TransferPlatform.shared().openPhoto(e, 1, GameConfig.REAL_SCREEN_HEIGHT, GameConfig.REAL_SCREEN_HEIGHT);
    }
    updateCardNumberStatus() {
        if (this.cardNumberNode) {
            let t = this.cardNumberNode.getChildByName("EditBox");
            this.cardNumberStr = ToolUtils.isSafeString(t.getComponent(EditBox).string);
            this.cardNumberStr.length > 0 && (0 == User.shared().pan_check || 3 == User.shared().pan_check) ? this.cardNumberNode.getChildByName("del_btn").active = true : this.cardNumberNode.getChildByName("del_btn").active = false;
        }
    }
    onEditBoxChanged(t, e, a) {
        "card_number" == a && this.updateCardNumberStatus();
    }
    onEditBoxEnded(t, e) {
        "card_number" == e && this.updateCardNumberStatus();
    }
    onSumbitButtonClick(t, e) {
        if (SoundManager.shared().playFx("click"), !this._bBtnEnable) {
            return;
        }
        this._bBtnEnable = false;
        TweenTool.delayAct(this.node, (() => {
            this._bBtnEnable = true;
        }), 2, true);
        sys.isObjectValid(User.shared().pancard_data) && ToolUtils.isSafeString(User.shared().pancard_data.reason).length > 0 && (User.shared().pancard_data.reason = "", User.shared().pancard_data.fast_reason = "", this.updateErrTips());
        let a = sys.isObjectValid(User.shared().pancard_data.photo_clear_level) ? User.shared().pancard_data.photo_clear_level : 1;
        if (a < 3 && "" === this.frontImgName && null === this.frontImgPath) {
            return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text76"), 2);
        }
        if (1 == a && sys.isObjectValid(User.shared().data.open_signzy) && 1 == Number(User.shared().data.open_signzy) && !this._bCanUpdate) {
            return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("kyc.upload_verify_image_fail"), 2);
        }
        let i = ToolUtils.isSafeString(this._frontImgDataStr), n = ToolUtils.isSafeString(this.cardNumberStr);
        10 === n.length ? (Utils.shared().showLoading(20, true, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text37"), 3);
        })), TransferPlatform.shared().getIsCanOCR() ? this.frontImgPath ? HttpManager.shared().doUpdateFile(0, "panimg", this.frontImgPath, ((t, e, a) => {
            if (200 !== a) {
                ;
            }
            else {
                try {
                    let t = ToolUtils.parseJson(e);
                    0 === t.ret ? (this.frontImgName = t.data.imgName, Utils.shared().showLoading(20, true, (() => {
                        Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text37"), 3);
                    }), ToolUtils.getIsNormalDirection(), 1), HttpManager.shared().doPanSaveInfo2(i, n, this.frontImgName, this.listenSubmitCall.bind(this))) : t.desc && t.desc.length > 0 && Utils.shared().showToast(t.desc, 2);
                }
                catch (t) {
                }
            }
        })) : HttpManager.shared().doPanSaveInfo2(i, n, this.frontImgName, this.listenSubmitCall.bind(this)) : this.frontImgPath && 0 == this.frontImgName.length ? this.doUploadImg((() => {
            Utils.shared().showLoading(20, true, (() => {
                Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text37"), 3);
            }), ToolUtils.getIsNormalDirection(), 1);
            HttpManager.shared().doPanSaveInfo2(i, n, this.frontImgName, this.listenSubmitCall.bind(this));
        })) : HttpManager.shared().doPanSaveInfo2(i, n, this.frontImgName, this.listenSubmitCall.bind(this))) : Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text78"), 2);
    }
    doUploadImg(t = null) {
        if (ToolUtils.isSafeString(this.frontImgPath).length > 0) {
            let e = this;
            HttpManager.shared().doUploadNewPanFile(this.frontImgPath, ((a, i, n) => {
                if (Utils.shared().hideToast(), 200 !== n) {
                    Utils.shared().hideLoading();
                }
                else {
                    if (!ToolUtils.isObjValid(e.node)) {
                        return;
                    }
                    try {
                        let a = sys.isObjectValid(User.shared().pancard_data.photo_clear_level) ? User.shared().pancard_data.photo_clear_level : 1, n = ToolUtils.parseJson(i);
                        0 === n.ret ? (e.frontImgName = n.data.img_url, sys.isObjectValid(n.data.img_content) && n.data.img_content.length > 0 ? e._frontImgDataStr = n.data.img_content : e._frontImgDataStr = "", t ? t() : (e._bCanUpdate = true, e.frontErrNode.active = false, e.updateBtnStatus(2), sys.isObjectValid(n.data.card) && n.data.card.length > 0 ? e.updateCardNumberView2(n.data.card) : 1 == a && e.updateCardNumberView2(""))) : (Utils.shared().hideLoading(), n.desc && n.desc.length > 0 && Utils.shared().showToast(n.desc, 2), t || (sys.isObjectValid(User.shared().data.open_signzy) && 1 == Number(User.shared().data.open_signzy) && 1 == a && (e.frontErrNode.active = true, e._bCanUpdate = false), e.updateBtnStatus(1)));
                    }
                    catch (t) {
                        Utils.shared().hideLoading();
                    }
                }
            }));
        }
    }
    listenSubmitCall(t, e, a) {
        if (200 == a) {
            try {
                let t = ToolUtils.parseJson(e);
                0 === t.ret ? (sys.isObjectValid(t.data.pan_check) && (User.shared().pan_check = t.data.pan_check), sys.isObjectValid(t.data.name) && (User.shared().pancard_data.name = t.data.name), sys.isObjectValid(t.data.photo_frontend) && (User.shared().pancard_data.photo_frontend = t.data.photo_frontend), sys.isObjectValid(t.data.card) && (User.shared().pancard_data.card = t.data.card), PushCenter.shared().pushEvent(PushEvent.Update_Pan, User.shared().pan_check), sys.isObjectValid(t.data.loading_seconds) && Number(t.data.loading_seconds) > 0 ? ToolUtils.isObjValid(this.node) && (this.updateCardVerifyView(), Utils.shared().showLoading(Number(t.data.loading_seconds), true, (() => {
                    ToolUtils.isObjValid(this.node) && (1 == this._source_type && this._callback && this._callback(1), this.onBackView());
                    Utils.shared().showToast(i18nMgr.shared().getValueByKey("kyc.submit_success"), 3.5);
                }), ToolUtils.getIsNormalDirection(), 1)) : (Utils.shared().hideLoading(), ToolUtils.isObjValid(this.node) && (1 == this._source_type && this._callback && this._callback(1), 2 == User.shared().pan_check ? sys.isObjectValid(t.data.reward_list) && t.data.reward_list.length > 0 ? Utils.shared().showKycVerifySucTip(t.data.reward_list, i18nMgr.shared().getValueByKey("kyc.PAN_Verify_Suc")) : Utils.shared().showToast(i18nMgr.shared().getValueByKey("kyc.PAN_Verify_Suc"), 3.5) : Utils.shared().showToast(i18nMgr.shared().getValueByKey("kyc.wait_for_verify"), 3.5), this.onBackView()))) : (Utils.shared().hideLoading(), t.desc && t.desc.length > 0 && Utils.shared().showToast(t.desc, 2));
            }
            catch (t) {
                Utils.shared().hideLoading();
            }
        }
        else {
            Utils.shared().hideLoading();
        }
    }
    onBackView(t = true) {
        ToolUtils.isObjValid(this.node) && t && (Utils.shared().hideLoading(), this.closeUICallBack && this.closeUICallBack(), this.bShowPushAnim ? (this._closed = true, ToolUtils.showPushAnim(this.node, 1, (() => {
            ToolUtils.isObjValid(this.node) && this.node.destroy();
        }))) : ToolUtils.isObjValid(this.node) && this.node.destroy());
    }
    fitScreen() {
        ToolUtils.adaptSafeArea(this.rootNode);
        let t = sys.getSafeAreaRect().y;
        this.rootNode.getChildByName("tips").getComponent(Widget).bottom = 120 - t;
        this.submit_btn.getComponent(Widget).bottom = 20 - t;
    }
}
