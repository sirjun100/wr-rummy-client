// @ts-nocheck
// Recovered from index.js:181
import { _decorator, assetManager, director, instantiate, Sprite, sys } from "cc";
import BundleNameDefined from "./BundleNameDefined";
import { TLog } from "./TLog";
import { GameAlreadyJoined } from "./GameAlreadyJoined";
import User from "./User";
import Utils from "./Utils";
import { PersonMsgBind } from "./PersonMsgBind";
import i18nMgr from "./i18nMgr";
import PushCenter from "./PushCenter";
import PushEvent from "./PushEvent";
import HttpManager from "./HttpManager";
import { HttpRequest } from "./HttpRequestName";
import { ActivityCollection } from "./ActivityCollection";
import { ToolUtils } from "./ToolUtils";
import { CommonGameType } from "./CommDefine";
const { ccclass } = _decorator;
@ccclass("HallTopUiLogic")
export default class HallTopUiLogic {
    public mainHall: any = null;
    init(e) {
        this.mainHall = e;
    }
    dealMultipleLanguages() {
    }
    checkIsMatchRoom() {
        let e = false, a = ToolUtils.deskInfos.get(User.shared().curTid_key);
        return a && 4 == a.mode && 3 != a.match_mode && (e = true), e;
    }
    changeRoomBg(e = ToolUtils.curGameType) {
        try {
            let a = this.mainHall.node.getChildByName("room_bg"), i = a.getChildByName("desk");
            if (e == CommonGameType.SixDice) {
                return sys.isObjectValid(this.mainHall.littleGameBgs[0]) && (a.getComponent(Sprite).spriteFrame = this.mainHall.littleGameBgs[0]), void (sys.isObjectValid(this.mainHall.littleGameDesks[0]) && (i.getComponent(Sprite).spriteFrame = this.mainHall.littleGameDesks[0]));
            }
            if (e == CommonGameType.FruitMachine) {
                return sys.isObjectValid(this.mainHall.littleGameBgs[1]) && (a.getComponent(Sprite).spriteFrame = this.mainHall.littleGameBgs[1]), void (sys.isObjectValid(this.mainHall.littleGameDesks[1]) && (i.getComponent(Sprite).spriteFrame = this.mainHall.littleGameDesks[1]));
            }
            if (e == CommonGameType.Crash) {
                return sys.isObjectValid(this.mainHall.littleGameBgs[2]) && (a.getComponent(Sprite).spriteFrame = this.mainHall.littleGameBgs[2]), void (i.active = false);
            }
            if (e == CommonGameType.Ludo) {
                return sys.isObjectValid(this.mainHall.littleGameBgs[3]) && (a.getComponent(Sprite).spriteFrame = this.mainHall.littleGameBgs[3]), void (sys.isObjectValid(this.mainHall.littleGameDesks[3]) && (i.getComponent(Sprite).spriteFrame = this.mainHall.littleGameDesks[3]));
            }
            let r = 4 == User.shared().styles[0] ? 1 : 0;
            5 == User.shared().styles[0] && (r = 2);
            let n, o, l = User.shared().styles[0] - 1;
            ToolUtils.deskInfos.get(User.shared().curTid_key) && 1 == ToolUtils.deskInfos.get(User.shared().curTid_key).special_mode ? 0 == l ? i.getComponent(Sprite).spriteFrame = this.mainHall.fourDesk_bgs[l] : (o = l + 1, n = "rummy_big_four_table_" + o, User.shared().remoteImagesMap.has(n) && sys.isObjectValid(User.shared().remoteImagesMap.get(n)) ? i.getComponent(Sprite).spriteFrame = User.shared().remoteImagesMap.get(n) : (i.getComponent(Sprite).spriteFrame = this.mainHall.desk_bg[0], Utils.shared().loadRemoteDeskImage(i, n))) : this.checkIsMatchRoom() ? (o = 7, n = "rummy_card_table_bg_0" + o, User.shared().remoteImagesMap.has(n) && sys.isObjectValid(User.shared().remoteImagesMap.get(n)) ? i.getComponent(Sprite).spriteFrame = User.shared().remoteImagesMap.get(n) : Utils.shared().loadRemoteDeskImage(i, n)) : 0 == l ? i.getComponent(Sprite).spriteFrame = this.mainHall.desk_bg[l] : (o = l, n = "rummy_card_table_bg_0" + o, User.shared().remoteImagesMap.has(n) && sys.isObjectValid(User.shared().remoteImagesMap.get(n)) ? i.getComponent(Sprite).spriteFrame = User.shared().remoteImagesMap.get(n) : (i.getComponent(Sprite).spriteFrame = this.mainHall.desk_bg[0], Utils.shared().loadRemoteDeskImage(i, n)));
            this.checkIsMatchRoom() ? (o = 6, n = "rummy_game_bg_" + o, User.shared().remoteImagesMap.has(n) && sys.isObjectValid(User.shared().remoteImagesMap.get(n)) ? a.getComponent(Sprite).spriteFrame = User.shared().remoteImagesMap.get(n) : Utils.shared().loadRemoteDeskImage(a, n)) : 0 == r ? a.getComponent(Sprite).spriteFrame = this.mainHall.table_bg[r] : (o = r + 1, n = "rummy_game_bg_" + o, User.shared().remoteImagesMap.has(n) && sys.isObjectValid(User.shared().remoteImagesMap.get(n)) ? a.getComponent(Sprite).spriteFrame = User.shared().remoteImagesMap.get(n) : Utils.shared().loadRemoteDeskImage(a, n));
        }
        catch (e) {
            TLog.printError(" changeRoomBg err:", e);
        }
    }
    preChangeMatchRoomBg() {
        try {
            let e = this.mainHall.node.getChildByName("room_bg"), a = e.getChildByName("desk"), i = "rummy_card_table_bg_07";
            User.shared().remoteImagesMap.has(i) && sys.isObjectValid(User.shared().remoteImagesMap.get(i)) ? a.getComponent(Sprite).spriteFrame = User.shared().remoteImagesMap.get(i) : Utils.shared().loadRemoteDeskImage(a, i);
            i = "rummy_game_bg_6";
            User.shared().remoteImagesMap.has(i) && sys.isObjectValid(User.shared().remoteImagesMap.get(i)) ? e.getComponent(Sprite).spriteFrame = User.shared().remoteImagesMap.get(i) : Utils.shared().loadRemoteDeskImage(e, i);
        }
        catch (e) {
            TLog.printError(" preChangeMatchRoomBg err:", e);
        }
    }
    refreshAddCashFlag() {
    }
    showMyJoinGame() {
        try {
            if (window.InSwitchScene) {
                return void TLog.printError("-------- switchScene stop preload res.");
            }
            ToolUtils.loadCommonPrefab(null, BundleNameDefined.bundle_hall, "prefab/game_already_joined", (e => {
                if (ToolUtils.isObjValid(this.mainHall.node) && !this.mainHall.node.getChildByName("game_already_joined")) {
                    let a = instantiate(e);
                    this.mainHall.node.addChild(a);
                    a.getComponent(GameAlreadyJoined).updateList(this.mainHall._tableInfoMsg);
                    User.shared().send_request_hall_tableinfo();
                }
            }));
        }
        catch (e) {
            TLog.printError(" on_join_game_click show myjoinedGames err:", e);
        }
    }
    showDailyTask(e) {
        window.InSwitchScene ? TLog.printError("-------- switchScene stop preload res.") : Utils.shared().showDailyTask(this.mainHall.node, this.mainHall.lobby_root, e);
    }
    showDailyGuide(e = false, a = null) {
        window.InSwitchScene ? TLog.printError("-------- switchScene stop preload res.") : Utils.shared().showDailyGuide(this.mainHall.node, e, a);
    }
    showCouponAct(e) {
        Utils.shared().showCouponActView(this.mainHall.node, e);
    }
    showFirstRecharge2(e) {
        if (0 !== User.shared().charge_open) {
            if (sys.isObjectValid(e) || (e = {}), !sys.isObjectValid(e.vid) || !sys.isObjectValid(e.ext)) {
                return sys.isObjectValid(User.shared().firstrechargeData) ? (e.ext = User.shared().firstrechargeData, void Utils.shared().showFirstRechargeView(this.mainHall.node, e)) : void HttpManager.shared().doGetCommonRequest(null, HttpRequest.FirstRechargePage, ((a, t, s) => {
                    if (200 != s) {
                        Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.request_fail"), 2);
                    }
                    else {
                        let a = ToolUtils.parseJson(t);
                        0 == a.ret ? (User.shared().firstrechargeData = a.data, ToolUtils.isObjValid(this.mainHall.node) && (e.ext = User.shared().firstrechargeData, Utils.shared().showFirstRechargeView(this.mainHall.node, e))) : ToolUtils.isSafeString(a.desc).length > 0 && (Utils.shared().showToast(ToolUtils.isSafeString(a.desc), 2), User.shared().canFirstPay = 0, PushCenter.shared().pushEvent(PushEvent.PurchasedFirstRecharge), PushCenter.shared().pushEvent(PushEvent.CloseFirstRecharge));
                    }
                }));
            }
            Utils.shared().showFirstRechargeView(this.mainHall.node, e);
        }
    }
    hideFirstPayView() {
        if (ToolUtils.isObjValid(this.mainHall.node)) {
            let e = this.mainHall.node.getChildByName("FirstRecharge");
            if (ToolUtils.isObjValid(e)) {
                return void e.removeFromParent();
            }
        }
        let e = director.getScene().getChildByName("Canvas");
        if (ToolUtils.isObjValid(e)) {
            let a = e.getChildByName("FirstRecharge");
            ToolUtils.isObjValid(a) && a.removeFromParent();
        }
    }
    showTwentyHourRecharge(e) {
        0 !== User.shared().charge_open && (sys.isObjectValid(User.shared().twentyfourrechargeData) ? Utils.shared().showTwentyFourRechargeView(this.mainHall.node, e) : HttpManager.shared().doGetCommonRequest(null, HttpRequest.TwentyFourRechargePage, ((a, t, s) => {
            if (200 != s) {
                Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.request_fail"), 2);
            }
            else {
                let a = ToolUtils.parseJson(t);
                0 == a.ret ? (User.shared().twentyfourrechargeData = a.data, ToolUtils.isObjValid(this.mainHall.node) && Utils.shared().showTwentyFourRechargeView(this.mainHall.node, e)) : ToolUtils.isSafeString(a.desc).length > 0 && (Utils.shared().showToast(ToolUtils.isSafeString(a.desc), 2), User.shared().canTwentyFour = 0, PushCenter.shared().pushEvent(PushEvent.PurchasedFirstRecharge), PushCenter.shared().pushEvent(PushEvent.CloseTwentyHourRecharge));
            }
        })));
    }
    showRebateRecharge(e) {
        if (0 !== User.shared().charge_open) {
            if (sys.isObjectValid(e) || (e = {}), !sys.isObjectValid(e.vid) || !sys.isObjectValid(e.ext)) {
                return sys.isObjectValid(User.shared().rebaterechargeData) ? (e.ext = User.shared().rebaterechargeData, void Utils.shared().showRebateRechargeView(this.mainHall.node, e)) : void HttpManager.shared().doGetCommonRequest(null, HttpRequest.RebateRechargePage, ((a, t, s) => {
                    if (200 != s) {
                        Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.request_fail"), 2);
                    }
                    else {
                        let a = ToolUtils.parseJson(t);
                        0 == a.ret ? (User.shared().rebaterechargeData = a.data, ToolUtils.isObjValid(this.mainHall.node) && (e.ext = User.shared().rebaterechargeData, Utils.shared().showRebateRechargeView(this.mainHall.node, e))) : ToolUtils.isSafeString(a.desc).length > 0 && (Utils.shared().showToast(ToolUtils.isSafeString(a.desc), 2), PushCenter.shared().pushEvent(PushEvent.PurchasedFirstRecharge), PushCenter.shared().pushEvent(PushEvent.CloseRebateRecharge));
                    }
                }));
            }
            Utils.shared().showRebateRechargeView(this.mainHall.node, e);
        }
    }
    showBuyOneGetThree(e) {
        if (0 !== User.shared().charge_open) {
            if (sys.isObjectValid(e) || (e = {}), !sys.isObjectValid(e.vid) || !sys.isObjectValid(e.ext)) {
                return sys.isObjectValid(User.shared().payOneForThreeData) ? (e.ext = User.shared().payOneForThreeData, void Utils.shared().showBuyOneGetThreeView(this.mainHall.node, e)) : void HttpManager.shared().doGetCommonRequest(null, HttpRequest.BuyOneGetThreePage, ((a, t, s) => {
                    if (200 != s) {
                        Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.request_fail"), 2);
                    }
                    else {
                        let a = ToolUtils.parseJson(t);
                        0 == a.ret ? (User.shared().payOneForThreeData = a.data, ToolUtils.isObjValid(this.mainHall.node) && (e.ext = User.shared().payOneForThreeData, e.needReqPage = false, Utils.shared().showBuyOneGetThreeView(this.mainHall.node, e))) : ToolUtils.isSafeString(a.desc).length > 0 && (Utils.shared().showToast(ToolUtils.isSafeString(a.desc), 2), PushCenter.shared().pushEvent(PushEvent.PurchasedFirstRecharge), PushCenter.shared().pushEvent(PushEvent.CloseBuyOneGetThree));
                    }
                }));
            }
            Utils.shared().showBuyOneGetThreeView(this.mainHall.node, e);
        }
    }
    showDailyFireSale(e) {
        if (0 !== User.shared().charge_open) {
            if (sys.isObjectValid(e) || (e = {}), !sys.isObjectValid(e.vid) || !sys.isObjectValid(e.ext)) {
                return sys.isObjectValid(User.shared().dailyFireSaleData) ? (e.ext = User.shared().dailyFireSaleData, e.isRefresh = true, void Utils.shared().showDailyFireSaleView(e)) : void User.shared().requestDailySalePage((() => {
                    ToolUtils.isObjValid(this.mainHall.node) && (e.ext = User.shared().dailyFireSaleData, Utils.shared().showDailyFireSaleView(e));
                }));
            }
            Utils.shared().showDailyFireSaleView(e);
        }
    }
    showConsecutiveGift(e) {
        if (0 !== User.shared().charge_open) {
            if (sys.isObjectValid(e) || (e = {}), !sys.isObjectValid(e.vid) || !sys.isObjectValid(e.ext)) {
                return sys.isObjectValid(User.shared().consecutiveGiftData) ? (e.ext = User.shared().consecutiveGiftData, void Utils.shared().showConsecutiveGiftView(this.mainHall.node, e)) : void HttpManager.shared().doGetCommonRequest(null, HttpRequest.ConsecutiveGiftPage, ((a, t, s) => {
                    if (200 != s) {
                        Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.request_fail"), 2);
                    }
                    else {
                        let a = ToolUtils.parseJson(t);
                        0 == a.ret ? (User.shared().consecutiveGiftData = a.data, ToolUtils.isObjValid(this.mainHall.node) && (e.ext = User.shared().consecutiveGiftData, Utils.shared().showConsecutiveGiftView(this.mainHall.node, e))) : ToolUtils.isSafeString(a.desc).length > 0 && (Utils.shared().showToast(ToolUtils.isSafeString(a.desc), 2), PushCenter.shared().pushEvent(PushEvent.PurchasedFirstRecharge), PushCenter.shared().pushEvent(PushEvent.CloseConsecutiveGift));
                    }
                }));
            }
            Utils.shared().showConsecutiveGiftView(this.mainHall.node, e);
        }
    }
    showCustomSelGift(e) {
        User.shared().custom_sel_gift_open;
    }
    showSessionPackage(e) {
        if (User.shared().sessionResult) {
            e.vid;
        }
    }
    showCreatePassWordView(e = null, a = false) {
        User.shared().data.tel_no && "" !== User.shared().data.tel_no ? Utils.shared().showHallPassWordView(a) : Utils.shared().showCommomDialog(i18nMgr.shared().getValueByKey("settings.verify_mobile"), i18nMgr.shared().getValueByKey("settings.tips"), (t => {
            1 == t && PushCenter.shared().pushEvent(PushEvent.ShowChangeBindMobile, { lastNode: e, nType: 0, callback: (e, t) => {
                    User.shared().bSetpassword = true;
                    Utils.shared().showHallPassWordView(a, e, t);
                    Utils.shared().showToast(i18nMgr.shared().getValueByKey("bind_mobile.phone_binding_success"), 2);
                } });
        }), true, false, i18nMgr.shared().getValueByKey("settings.go"), i18nMgr.shared().getValueByKey("settings.cancel"));
    }
    showChangeBindMobile(e, a, t, s = false) {
        if (window.InSwitchScene) {
            TLog.printError("-------- switchScene stop preload res.");
        }
        else {
            try {
                ToolUtils.loadCommonPrefab(null, BundleNameDefined.Bundle_kyc, "prefab/person_msg_bind", (e => {
                    if (director.getScene().name != BundleNameDefined.hall_scene) {
                        return;
                    }
                    let s = instantiate(e);
                    s.name = "changeBindMobile";
                    let n = s.getComponent(PersonMsgBind);
                    n.setState(a);
                    n.setCloseCallBack(((e, a, s) => {
                        e && t && t(a, s);
                    }));
                    director.getScene().getChildByName("Canvas").addChild(s);
                }));
            }
            catch (e) {
                TLog.printError("Hall showChangeBindMobile err:", e);
            }
        }
    }
    showSafetyVerify(e, a) {
        window.InSwitchScene ? TLog.printError("-------- switchScene stop preload res.") : Utils.shared().showSafetyVerify(e, a);
    }
    showAnnouncementView(e, a = false) {
        window.InSwitchScene ? TLog.printError("-------- switchScene stop preload res.") : Utils.shared().showAnnouncementView(e, a);
    }
    showNovicesTaskView(e = false, a) {
        window.InSwitchScene ? TLog.printError("-------- switchScene stop preload res.") : Utils.shared().showNovicesTaskView(e, a);
    }
    showReliefPackage(e = null) {
        window.InSwitchScene ? TLog.printError("-------- switchScene stop preload res.") : Utils.shared().showReliefPackageView(e);
    }
    showActivityColletion(e) {
        if (window.InSwitchScene) {
            TLog.printError("-------- switchScene stop preload res.");
        }
        else {
            try {
                ToolUtils.loadCommonPrefab(null, BundleNameDefined.bundle_hallTopUI, "prefab/activity_collection", (a => {
                    if (director.getScene().name == BundleNameDefined.hall_scene && ToolUtils.isObjValid(e)) {
                        let t = e.getChildByName("activity_collection");
                        if (ToolUtils.isObjValid(t)) {
                            t.getComponent(ActivityCollection).updateActivityCollection();
                        }
                        else {
                            t = instantiate(a);
                            e.addChild(t);
                        }
                    }
                }));
            }
            catch (e) {
                TLog.printError("Hall showActivityColletion err:", e);
            }
        }
    }
    showLotteryAct(e = null) {
        if (window.InSwitchScene) {
            return void TLog.printError("-------- switchScene stop preload res.");
        }
        let a = director.getScene().getChildByName("Canvas");
        Utils.shared().showLotteryView(a, e);
    }
    showPerformanceView() {
        window.InSwitchScene ? TLog.printError("-------- switchScene stop preload res.") : Utils.shared().showPerformanceView();
    }
    showRecodeDetailsView(e) {
        window.InSwitchScene ? TLog.printError("-------- switchScene stop preload res.") : Utils.shared().showRecodeDetailsView(e);
    }
    showSetting() {
        director.getScene().name == BundleNameDefined.hall_scene && Utils.shared().showHallSettingView();
    }
    releaseRes() {
        let e, a = [{ name: "relief_package", prefab: "prefab/relief_package", strBundle: BundleNameDefined.bundle_firstRecharge }, { name: "newplayer_task", prefab: "prefab/newplayer_task", strBundle: BundleNameDefined.bundle_novicesTask }, { name: "announcement", prefab: "prefab/announcement", strBundle: BundleNameDefined.bundle_hallTopUI }, { name: "changeBindMobile", prefab: "prefab/person_msg_bind", strBundle: BundleNameDefined.bundle_hallTopUI }, { name: "HallSettingsPassword", prefab: "prefab/hall_settings_password", strBundle: BundleNameDefined.Bundle_kyc }, { name: "safetyVerifyNode", prefab: "prefab/safety_verify_node", strBundle: BundleNameDefined.Bundle_kyc }, { name: "FirstRecharge", prefab: "prefab/first_buy", strBundle: BundleNameDefined.bundle_firstRecharge }, { name: "BuyOneGetThree", prefab: "prefab/payoneforthree", strBundle: BundleNameDefined.bundle_payoneforthree }, { name: "weekmonth", prefab: "prefab/weekmonth", strBundle: BundleNameDefined.bundle_weekmonth }, { name: "weekmonthrenew", prefab: "prefab/weekmonthrenew", strBundle: BundleNameDefined.bundle_weekmonth }, { name: "freecash", prefab: "prefab/freecash", strBundle: BundleNameDefined.bundle_freecash }], t = director.getScene().getChildByName("Canvas");
        for (let s = 0, i = a.length; s < i; s++) {
            e = assetManager.getBundle(a[s].strBundle);
            e && t.isValid && (ToolUtils.isObjValid(this.mainHall.node.getChildByName(a[s].name)) || ToolUtils.isObjValid(t.getChildByName(a[s].name)) || e.release(a[s].prefab));
        }
    }
}
