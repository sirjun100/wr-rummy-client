// @ts-nocheck
// Recovered from index.js:325
import { _decorator, Button, instantiate, Label, LabelShadow, Node, ProgressBar, size, Sprite, SpriteAtlas, SpriteFrame, sys, UITransform, v3, Vec3 } from "cc";
import ReportConfig from "./ReportConfig";
import i18nMgr from "./i18nMgr";
import TweenTool from "./TweenTool";
import HttpManager from "./HttpManager";
import PushCenter from "./PushCenter";
import User from "./User";
import PushEvent from "./PushEvent";
import { TransferPlatform } from "./TransferPlatform";
import { HttpRequest } from "./HttpRequestName";
import BaseLayer from "./BaseLayer";
import Utils from "./Utils";
import SoundManager from "./SoundManager";
import CommDefine from "./CommDefine";
import GameConfig from "./GameConfig";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("NewPlayerTask")
export class NewPlayerTask extends BaseLayer {
    @property([SpriteFrame])
    public dailyItemSprites: SpriteFrame[] = [];
    @property([SpriteFrame])
    public taskBtnSprites: SpriteFrame[] = [];
    @property([SpriteFrame])
    public boxSprites: SpriteFrame[] = [];
    @property(Node)
    public rootNode: Node = null;
    @property(Label)
    public timeLabel: Label = null;
    @property([Node])
    public taskItems: Node[] = [];
    @property([Node])
    public boxItems: Node[] = [];
    @property([Node])
    public progressItems: Node[] = [];
    @property(Node)
    public rewardModel: Node = null;
    @property(Node)
    public tipsRewardModel: Node = null;
    @property(Node)
    public ruleNode: Node = null;
    @property(Label)
    public ruleLabel: Label = null;
    @property(Node)
    public tipsBubbleNode: Node = null;
    @property(SpriteAtlas)
    public rewardPlist: SpriteAtlas = null;
    public sceneStr: any = ReportConfig.scece.Hall;
    public vid: number = 0;
    public funcId: any = ReportConfig.func.New_reward;
    public isNext: boolean = false;
    public isRequest: boolean = false;
    public isDouble: boolean = false;
    public collectIndex: number = 0;
    public ruleTips: string = "";
    public _isScrolling: boolean = false;
    public _listData: any = null;
    public _scrollUtil: any = null;
    public _initDelay: number = 0;
    public _linkId: number = 0;
    public _reportScene: number = 1;
    public _bCanSend: boolean = false;
    public _roomScale: any = v3(0.74, 0.74, 0.74);
    public _taskData: any[] = [];
    public _bStartCountDown: boolean = false;
    public _nCountcd: any = -1;
    public _curTipIdx: any = -1;
    public pro_cd: any = null;
    public _isInAnim: boolean = false;
    onLoad() {
        let t = this.rootNode.getChildByName("close_btn");
        ToolUtils.getIsInRoom() ? (this.rootNode.setScale(this._roomScale), this.rootNode.setPosition(v3(0, -10))) : ToolUtils.isObjValid(t) && t.setPosition(v3(309.84, 452.428));
    }
    start() {
        super.start();
        this._linkId = this._linkId > 0 ? this._linkId : sys.now();
        this._reportScene = this._reportScene >= 0 ? this._reportScene : ToolUtils.getIsInRoom() ? 2 : 1;
        this.isRequest = false;
        this.ruleNode.active = false;
        this.initPushEvent();
        this.startShowAnim(this.rootNode, (() => {
        }));
        this._initDelay = 0;
        TweenTool.delayAct(this.node, (() => {
            this.refreshTaskList();
        }), this._initDelay, true);
        this._initDelay += 0.05;
        TweenTool.commonSchedule(this.node, 1, this.scheduleCallBack.bind(this));
    }
    startShowAnim(t, e) {
        t.setScale(v3(0, 0, 0));
        let i = ToolUtils.getIsInRoom() ? this._roomScale : v3(1, 1, 1);
        TweenTool.scaleTo(t, 0.2, i, "backOut", true, (() => {
            t.setScale(i);
            e && e();
        }));
    }
    initTask(t = false, e) {
        let i = sys.isObjectValid(e) && sys.isObjectValid(e.vid) ? e.vid : 0;
        this.vid = i;
        this.isNext = t;
        sys.isObjectValid(e) && sys.isObjectValid(e.reportScene) && (this._reportScene = e.reportScene);
        sys.isObjectValid(e) && sys.isObjectValid(e.link_id) && e.link_id > 0 && (this._linkId = e.link_id);
    }
    onEnable() {
        TransferPlatform.shared().setNormalFrameRate();
    }
    initPushEvent() {
        PushCenter.shared().addListener(PushEvent.RefreshTaskList, (t => {
            ToolUtils.isObjValid(this.node) && this.requestNovicesTaskList();
            0 == ToolUtils.isInGameScene ? User.shared().getHallInfo(this.vid) : User.shared().getRoomRoomInfo(this.vid, PushEvent.JUMP_TO_NEW_NOVICESTASK);
        }), this);
    }
    scheduleCallBack() {
        let t = this._taskData;
        if (sys.isObjectValid(t) && this._bStartCountDown) {
            if (this._nCountcd -= 1, t.data.left_second = this._nCountcd, this._nCountcd < 0) {
                return t.time_left = -1, User.shared().getHallInfo(), void this.onBackView();
            }
            this.timeLabel.string = ToolUtils.format("${0} ${1}", "Time Left: ", Utils.shared().parseCountDown(this._nCountcd));
        }
    }
    startLeftTime(t) {
        let e = "Time Left: ";
        if (Number.isNaN(t) || t <= 0) {
            return User.shared().getHallInfo(), void (this.timeLabel.string = "");
        }
        this._bStartCountDown = true;
        this._nCountcd = t;
        e = ToolUtils.format("${0} ${1}", e, Utils.shared().parseCountDown(this._nCountcd));
        this.timeLabel.string = e;
    }
    refreshTaskList() {
        this.rewardModel && (this.rewardModel.active = false, this._taskData = this.vid > 0 ? User.shared().roomNovicesData : User.shared().novicesTaskData, sys.isObjectValid(this._taskData) && sys.isObjectValid(this._taskData.data) && (this.startLeftTime(Number(this._taskData.data.left_second)), this.updateTaskListContent(this._taskData.data), this.updateBottomProgress(this._taskData.data)), this.requestNovicesTaskList(), 0 == ToolUtils.isInGameScene ? User.shared().getHallInfo(this.vid) : User.shared().getRoomRoomInfo(this.vid, PushEvent.JUMP_TO_NEW_NOVICESTASK));
    }
    updateBottomProgress(t) {
        if (sys.isObjectValid(t) && sys.isObjectValid(t.active_num) && sys.isObjectValid(t.active)) {
            let e = Number(t.active_num), i = t.active;
            if (this.rootNode.getChildByName("ball").getChildByName("num").getComponent(Label).string = t.active_num, sys.isObjectValid(i) && i.length > 0) {
                for (let t = 0, s = i.length; t < s && t < 4; t++) {
                    if (!(e >= i[t].amt)) {
                        this.boxItems[t].getComponent(Sprite).spriteFrame = this.boxSprites[0];
                        this.progressItems[t].getComponent(ProgressBar).progress = t > 0 ? (e - i[t - 1].amt) / Number(i[t].amt - i[t - 1].amt) : e / Number(i[0].amt);
                        break;
                    }
                    this.boxItems[t].getComponent(Sprite).spriteFrame = this.boxSprites[1];
                    this.progressItems[t].getComponent(ProgressBar).progress = 1;
                }
            }
        }
    }
    updateTaskListContent(t, e = -1) {
        if (t && t.task.length > 0) {
            for (let i = 0, s = t.task.length; i < s && i < 3; i++) {
                let s = t.task[i], a = this.taskItems[i], o = ToolUtils.isSafeNumber(s.task_status);
                if (e > 0 && e == i && 2 != o) {
                    let t = instantiate(a), e = a.getPosition();
                    t.setPosition(e);
                    t.parent = a.parent;
                    TweenTool.stopNodeAction(a);
                    let i = a.getComponent(UITransform).contentSize.width;
                    a.setPosition(v3(e.x + i + 10, e.y, e.z));
                    TweenTool.moveTo(a, 0.2, e, "linear", true, (() => {
                        a.setPosition(e);
                    }));
                    TweenTool.moveTo(t, 0.2, v3(e.x - i - 10, e.y, e.z), "linear", true, (() => {
                        t.removeFromParent();
                    }));
                }
                ToolUtils.isSafeNumber(s.type);
                let n = ToolUtils.isSafeNumber(s.sub_type), l = ToolUtils.isSafeString(s.sub_title);
                if (l.length > 0 && (a.getChildByName("name").getComponent(Label).string = l), sys.isObjectValid(s.num) && sys.isObjectValid(s.total)) {
                    s.num > s.total ? a.getChildByName("progress_num").getComponent(Label).string = ToolUtils.format("${0}/${1}", s.total, s.total) : a.getChildByName("progress_num").getComponent(Label).string = ToolUtils.format("${0}/${1}", ToolUtils.parse_double(s.num, -1), s.total);
                    let t = Number(s.num) / Number(s.total);
                    a.getChildByName("ProgressBar").getComponent(ProgressBar).progress = t;
                }
                if (sys.isObjectValid(s.reward) && s.reward.length > 0) {
                    let t = a.getChildByName("rewardList").getChildByName("view").getChildByName("content");
                    t.removeAllChildren();
                    for (let e = 0, i = s.reward.length; e < i; e++) {
                        let i = instantiate(this.rewardModel);
                        this.updateRewardSprite(i.getChildByName("ico"), Number(s.reward[e].type));
                        i.getChildByName("num").getComponent(Label).string = s.reward[e].amt;
                        i.active = true;
                        i.name = "reward" + e;
                        t.addChild(i);
                    }
                }
                let f = a.getChildByName("btn");
                2 == o ? (f.getComponent(Button).interactable = false, f.getComponent(Sprite).spriteFrame = this.taskBtnSprites[2], f.getChildByName("wz").getComponent(Label).string = "COLLECTED", Utils.updateLabelMaterial(f.getChildByName("wz"), CommDefine.gradient.btn_gray), f.getChildByName("wz").getComponent(LabelShadow).color = CommDefine.shadowcolor.gray) : 1 == o ? (f.getComponent(Button).interactable = true, f.getComponent(Sprite).spriteFrame = this.taskBtnSprites[0], f.getChildByName("wz").getComponent(Label).string = "COLLECT", Utils.updateLabelMaterial(f.getChildByName("wz"), CommDefine.gradient.btn_green), f.getChildByName("wz").getComponent(LabelShadow).color = CommDefine.shadowcolor.green) : 1 == n || 2 == n ? (f.getComponent(Button).interactable = true, f.getComponent(Sprite).spriteFrame = this.taskBtnSprites[1], f.getChildByName("wz").getComponent(Label).string = "PLAY NOW", Utils.updateLabelMaterial(f.getChildByName("wz"), CommDefine.gradient.btn_blue), f.getChildByName("wz").getComponent(LabelShadow).color = CommDefine.shadowcolor.blue) : (f.getChildByName("wz").getComponent(Label).string = "ADD CASH", ToolUtils.getIsInRoom() ? (f.getComponent(Button).interactable = false, f.getComponent(Sprite).spriteFrame = this.taskBtnSprites[2], Utils.updateLabelMaterial(f.getChildByName("wz"), CommDefine.gradient.btn_gray), f.getChildByName("wz").getComponent(LabelShadow).color = CommDefine.shadowcolor.gray) : (f.getComponent(Button).interactable = true, f.getComponent(Sprite).spriteFrame = this.taskBtnSprites[1], Utils.updateLabelMaterial(f.getChildByName("wz"), CommDefine.gradient.btn_blue), f.getChildByName("wz").getComponent(LabelShadow).color = CommDefine.shadowcolor.blue));
                f.active = true;
            }
        }
    }
    updateRewardSprite(t, e) {
        ToolUtils.isSafeString(CommDefine.rewardPistName[e]).length > 0 && Utils.shared().setImage(t, CommDefine.rewardPistName[e], this.rewardPlist);
    }
    onCollectBtnClick(t, e) {
        if (SoundManager.shared().playFx("click"), e = Number(e), !(sys.isObjectValid(this._taskData) && sys.isObjectValid(this._taskData.data) && sys.isObjectValid(this._taskData.data.task) && sys.isObjectValid(this._taskData.data.task[e]))) {
            return;
        }
        let i = this._taskData.data.task[e];
        if (1 == i.task_status) {
            if (this.isRequest) {
                return;
            }
            this.isRequest = true;
            let t = this.vid;
            Utils.shared().showLoading(10, false, (() => {
                Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
            }), ToolUtils.getIsNormalDirection());
            let s = { uid: User.shared().data.uid, type: i.type, task_id: i.task_id, sub_task_id: i.sub_task_id, vid: t };
            HttpManager.shared().doGetCommonRequest(s, HttpRequest.NovicesTaskGetTaskReward, ((i, s, a) => {
                if (Utils.shared().hideLoading(), ToolUtils.isObjValid(this.node) && (this.isRequest = false), 200 == a) {
                    let i = ToolUtils.parseJson(s);
                    0 == i.ret ? (t > 0 && User.shared().requestNovicesTaskInfo(), 0 == ToolUtils.isInGameScene ? User.shared().getHallInfo(this.vid) : User.shared().getRoomRoomInfo(this.vid, PushEvent.JUMP_TO_NEW_NOVICESTASK), ToolUtils.isObjValid(this.node) && (this._isInAnim = true, this.showGetRewardAnim(e, i.data.reward_list))) : ToolUtils.isSafeString(i.desc).length > 0 && Utils.shared().showToast(i.desc, 2, 0, ToolUtils.getIsNormalDirection());
                }
            }));
            TweenTool.delayAct(this.node, (() => {
                sys.isObjectValid(this.node) && (this.isRequest = false);
            }), 5, true);
        }
        else if (ToolUtils.getIsInRoom()) {
            this.onBackView();
        }
        else if (1 == i.sub_type || 2 == i.sub_type) {
            let t = sys.isObjectValid(i.jump_info) && sys.isObjectValid(i.jump_info.type) ? i.jump_info.type : PushEvent.JUMP_TO_CASH_ROOM, e = sys.isObjectValid(i.jump_info) && sys.isObjectValid(i.jump_info.exe) ? i.jump_info.exe : { play: 0 };
            Utils.shared().doJumpLogic(t, e);
            ToolUtils.isObjValid(this.node) && this.node.destroy();
        }
        else {
            3 == i.sub_type && Utils.shared().doJumpLogic(PushEvent.JUMP_TO_STORE);
        }
    }
    onBoxClick(t, e) {
        if (SoundManager.shared().playFx("click"), e = Number(e), this._curTipIdx == e) {
            this._curTipIdx = -1;
            this.tipsBubbleNode.active = false;
        }
        else if (sys.isObjectValid(this.boxItems[e])) {
            this._curTipIdx = e;
            let t = this.tipsBubbleNode.getChildByName("layout"), i = this._taskData.data.active[e];
            this.tipsBubbleNode.getChildByName("ball_num").getComponent(Label).string = ToolUtils.format("${0}/${1}", this._taskData.data.active_num, i.amt);
            t.removeAllChildren();
            for (let e = 0, s = i.reward.length; e < s; e++) {
                let s = instantiate(this.tipsRewardModel);
                this.updateRewardSprite(s.getChildByName("ico"), Number(i.reward[e].type));
                s.getChildByName("num").getComponent(Label).string = i.reward[e].amt;
                s.active = true;
                t.addChild(s);
            }
            let s = this.tipsBubbleNode.getChildByName("bg").getComponent(UITransform).contentSize;
            i.reward.length > 2 ? this.tipsBubbleNode.getChildByName("bg").getComponent(UITransform).setContentSize(size(s.width, 120 + 33 * (i.reward.length - 2))) : this.tipsBubbleNode.getChildByName("bg").getComponent(UITransform).setContentSize(size(s.width, 120));
            let a = new Vec3;
            this.tipsBubbleNode.getPosition(a);
            this.tipsBubbleNode.setPosition(v3(this.boxItems[e].position.x, a.y, a.z));
            this.tipsBubbleNode.active = true;
            this.tipsBubbleNode.setScale(v3(0.2, 0.2, 0.2));
            TweenTool.scaleTo(this.tipsBubbleNode, 0.15, v3(1, 1, 1), "backOut", true, (() => {
                this.tipsBubbleNode.setScale(v3(1, 1, 1));
            }));
        }
    }
    onButtonClick(t, e) {
        SoundManager.shared().playFx("click");
        "close" === e ? ToolUtils.isObjValid(this.node) && (this.isNext && PushCenter.shared().pushEvent(PushEvent.Update_NextPopActivity), this.node.destroy()) : "help" === e ? this.ruleTips && "" != this.ruleTips && (this.ruleNode.active = true, this.ruleLabel.string = this.ruleTips, i18nMgr.shared().changeLabelFont(this.ruleLabel)) : "helpClose" === e && (this.ruleNode.active = false);
    }
    requestNovicesTaskList(t = -1) {
        let e = this.vid;
        HttpManager.shared().doGetCommonRequest({ vid: this.vid }, HttpRequest.NovicesTaskList, ((i, s, a) => {
            if (200 != a) {
                ;
            }
            else {
                let i = ToolUtils.parseJson(s);
                0 == i.ret && (e > 0 ? User.shared().roomNovicesData = i : User.shared().novicesTaskData = i, ToolUtils.isObjValid(this.node) && (this._isInAnim || (this._taskData = i, sys.isObjectValid(i) && sys.isObjectValid(i.data) && (this.startLeftTime(Number(i.data.left_second)), this.updateTaskListContent(i.data, t), this.updateBottomProgress(i.data)))));
            }
        }));
    }
    showGetRewardAnim(t, e) {
        if (sys.isObjectValid(this.taskItems[t]) && sys.isObjectValid(this._taskData) && sys.isObjectValid(this._taskData.data) && sys.isObjectValid(this._taskData.data.task)) {
            let i = this.taskItems[t], s = this._taskData.data.task[t];
            if (ToolUtils.isObjValid(i) && sys.isObjectValid(s.reward) && s.reward.length > 0) {
                let a = i.getChildByName("btn");
                a.getComponent(Button).interactable = true;
                a.getComponent(Sprite).spriteFrame = this.taskBtnSprites[2];
                a.getChildByName("wz").getComponent(Label).string = "COLLECTED";
                Utils.updateLabelMaterial(a.getChildByName("wz"), CommDefine.gradient.btn_gray);
                a.getChildByName("wz").getComponent(LabelShadow).color = CommDefine.shadowcolor.gray;
                let o, n = i.getChildByName("rewardList").getChildByName("view").getChildByName("content"), l = null, h = 0, u = ToolUtils.getIsInRoom() ? 0.5 * GameConfig.REAL_SCREEN_WIDTH : 0.5 * GameConfig.REAL_SCREEN_HEIGHT, p = ToolUtils.getIsInRoom() ? 0.5 * GameConfig.REAL_SCREEN_HEIGHT : 0.5 * GameConfig.REAL_SCREEN_WIDTH;
                for (let t = 0, e = s.reward.length; t < e; t++) {
                    if (13 == s.reward[t].type && ToolUtils.isObjValid(n.getChildByName("reward" + t))) {
                        let e = n.getChildByName("reward" + t);
                        o = instantiate(e.getChildByName("ico"));
                        l = e.getChildByName("ico").getWorldPosition();
                        o.setPosition(v3(l.x - p, l.y - u));
                        o.parent = this.node;
                        o.active = true;
                        h = Number(s.reward[t].amt);
                        break;
                    }
                }
                if (ToolUtils.isObjValid(o)) {
                    let i = this.rootNode.getChildByName("ball").getWorldPosition(), s = v3(i.x - p, i.y - u);
                    return void TweenTool.moveTo(o, 0.5, s, "cubicInOut", true, (() => {
                        o.removeFromParent();
                        ToolUtils.isObjValid(this.node) && this.showProgressAnim(h, t, e);
                    }));
                }
            }
        }
        this.showRewardDlg(t, e);
    }
    showProgressAnim(t, e, i) {
        let s = sys.isObjectValid(this._taskData) ? this._taskData.data : null;
        if (t > 0 && sys.isObjectValid(s) && sys.isObjectValid(s.active_num) && sys.isObjectValid(s.active)) {
            let a, o = Number(s.active_num), n = s.active, l = [], d = [], c = o + t, p = Number(s.active_num) + t;
            if (this.rootNode.getChildByName("ball").getChildByName("num").getComponent(Label).string = ToolUtils.parse_double("" + p, -2), sys.isObjectValid(n) && n.length > 0) {
                for (let t = 0, e = n.length; t < e && t < 4; t++) {
                    if (o <= n[t].amt) {
                        if (l.push(t), a = o / Number(n[t].amt), c >= n[t].amt) {
                            d.push(1);
                            for (let i = t + 1; i < e && i < 4; i++) {
                                if (!(c >= n[i].amt)) {
                                    l.push(i);
                                    d.push((c - n[i - 1].amt) / Number(n[i].amt - n[i - 1].amt));
                                    break;
                                }
                                l.push(i);
                                d.push(1);
                            }
                        }
                        else {
                            t > 0 ? d.push((c - n[t - 1].amt) / Number(n[t].amt - n[t - 1].amt)) : d.push(c / Number(n[t].amt));
                        }
                        break;
                    }
                }
                if (l.length > 0) {
                    TweenTool.stopAction(this.pro_cd);
                    let t = 0, s = a;
                    return void (this.pro_cd = TweenTool.commonSchedule(this.node, 0.03, (() => {
                        if (s += 0.05, s >= d[t]) {
                            if (sys.isObjectValid(l[t + 1])) {
                                ToolUtils.isObjValid(this.boxItems[t]) && (this.boxItems[t].getComponent(Sprite).spriteFrame = this.boxSprites[1]);
                                t += 1;
                                s = 0;
                            }
                            else {
                                let s = l[t];
                                ToolUtils.isObjValid(this.progressItems[s]) && (this.progressItems[s].getComponent(ProgressBar).progress = d[t]);
                                TweenTool.stopAction(this.pro_cd);
                                this.showRewardDlg(e, i);
                            }
                        }
                        else {
                            let e = l[t];
                            ToolUtils.isObjValid(this.progressItems[e]) && (this.progressItems[e].getComponent(ProgressBar).progress = s);
                        }
                    })));
                }
            }
        }
        this.showRewardDlg(e, i);
    }
    showRewardDlg(t, e) {
        let i = [];
        if (e && e.length > 0) {
            for (let t = 0, s = e.length; t < s; t++) {
                13 != e[t].type && i.push(e[t]);
            }
        }
        i && i.length > 0 ? User.shared().showChargeReward(i, (e => {
            sys.isObjectValid(this.node) && (this._isInAnim = false, this.requestNovicesTaskList(t));
        })) : this._isInAnim = false;
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().removeListenersByTag(this);
    }
    setLandscapeShow() {
        this.node.getChildByName("root") && ToolUtils.showFullScreen(this.node.getChildByName("root"));
    }
    onBackView() {
        ToolUtils.isObjValid(this.node) && (this.isNext && PushCenter.shared().pushEvent(PushEvent.Update_NextPopActivity), this.node.destroy());
    }
}
