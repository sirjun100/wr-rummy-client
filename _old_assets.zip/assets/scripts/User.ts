// @ts-nocheck
// Recovered from index.js:655
import { _decorator, director, sys } from "cc";
import NetHostManager from "./NetHostManager";
import AppInfo from "./AppInfo";
import MD5 from "./MD5";
import PushCenter from "./PushCenter";
import { TLog } from "./TLog";
import { ToolUtils } from "./ToolUtils";
import { TransferPlatform } from "./TransferPlatform";
import TweenTool from "./TweenTool";
import Utils from "./Utils";
import i18nMgr from "./i18nMgr";
import BundleNameDefined from "./BundleNameDefined";
import CommDefine, { BagItemType, CheckModule, CUSTOM_REWARD_ENUM, HELPER_ENUM, PointsType } from "./CommDefine";
import GameConfig from "./GameConfig";
import HowToPlayDefined from "./HowToPlayDefined";
import { HttpRequest } from "./HttpRequestName";
import NetConfig from "./NetConfig";
import PhpReportDefined from "./PhpReportDefined";
import PushEvent from "./PushEvent";
import ReportConfig from "./ReportConfig";
import RummyCmd from "./RummyCmd";
import URLConfig from "./URLConfig";
import SportCricket_Manager from "./SportCricket_Manager";
import gameNetworkDelay from "./gameNetworkDelay";
import RummyDataManager from "./RummyDataManager";
import HttpManager from "./HttpManager";
import LabaServer from "./LabaServer";
import Server from "./Server";
import { DeskInfo } from "./DeskInfo";
const { ccclass } = _decorator;
@ccclass("User")
export default class User {
    static _instance = null;
    public data: any = {};
    public roomTable: any[] = [];
    public crashModel: number = 0;
    public zjh_bonus_num: number = 0;
    public zjh_bonus_amount: number = 0;
    public min_money: number = 0;
    public ruleFlag: string = "";
    public laba_broadcast_op: number = 0;
    public laba_broadcast_url: string = "";
    public min_charge: number = 0;
    public max_charge: number = 0;
    public has_charged: number = 0;
    public withdraw_alert: number = 0;
    public isAutoGame: boolean = false;
    public canAutoLogin: number = 1;
    public isLoginHall: boolean = false;
    public rewardList: any = null;
    public teenPattiType: number = 0;
    public soreTb: any = {};
    public _shop_open: number = 0;
    public _withdraw_open: number = 0;
    public _nBackToHallGameId: any = -1;
    public get_gmoney: number = 0;
    public get_bonus: number = 0;
    public isPop_chest: boolean = false;
    public isFirstRegist: boolean = false;
    public real_money: number = 0;
    public in_vid: any = -1;
    public in_gameType: any = -1;
    public in_isPractice: number = 0;
    public _bHasRequestRoomList: boolean = false;
    public vecGameResInit: any[] = [];
    public code_timeout: number = 0;
    public rummyType: number = 0;
    public loginType: string = "";
    public access_token: string = "";
    public clubUserInfo: any = null;
    public shareMainInfo: any = null;
    public bc_gold: number = 0;
    public club_withdraw: number = 0;
    public isSwitchGame: boolean = false;
    public magicexpressioncost: number = 0;
    public histroyCardGameCd: number = 0;
    public curDeskIndex: number = 0;
    public curTid_key: string = "";
    public gameRummyType: number = 0;
    public ReliefResult: any = null;
    public sessionResult: any = null;
    public room_paydef: any[] = [];
    public bBackToLogin: boolean = false;
    public bNeedUpdateMoney: boolean = false;
    public shop_guide: number = 0;
    public b_storeLevel: boolean = false;
    public alertTip: string = "";
    public club_data: any = null;
    public club_grade: Map = new Map([[0, 0], [1, 1], [2, 2], [3, 3], [4, 4], [5, 5], [6, 6], [7, 7], [8, 8], [9, 9], [10, 1], [15, 2], [18, 3], [20, 4], [25, 5], [30, 6], [40, 7], [50, 8], [60, 9]]);
    public rps_data: any = null;
    public clubUpgradeMsg: any = null;
    public actList: any[] = [];
    public walletData_bonus: any = null;
    public walletData_history: any = null;
    public clubData_history: any = null;
    public StoreData_His_rec: any = null;
    public StoreData_His_with: any = null;
    public m_strMyRefererId: string = "";
    public hasShowLoadTable: boolean = false;
    public isGameDisconnectServer: boolean = false;
    public prop: any = null;
    public auto_sort: number = 1;
    public openGameTab: any[] = [];
    public bSetpassword: boolean = false;
    public httpLogWrite: string = "";
    public phplog_write_open: number = 0;
    public games_delay_open: number = 0;
    public isShowMatchEnterTips: boolean = false;
    public isShowGuideRewardTips: boolean = false;
    public isGuideEnterGame: number = 0;
    public raceRoomDate: any = null;
    public reportId: number = 0;
    public getIpCount: number = 0;
    public novicesTaskData: any = null;
    public flopCashTaskData: any = null;
    public flopCashTaskRecordData: any = null;
    public roomNovicesData: any = null;
    public new_user_task: number = 0;
    public new_user_task_open: number = 0;
    public new_user_flopcash_open: number = 0;
    public firstrechargeData: any = null;
    public twentyfourrechargeData: any = null;
    public rebaterechargeData: any = null;
    public payOneForThreeData: any = null;
    public consecutiveGiftData: any = null;
    public customSelGiftData: any = null;
    public treasuredrawData: any = null;
    public chipfirstrechargeData: any = null;
    public reliefPackageData: any = null;
    public dailyFireSaleData: any = null;
    public canFirstPay: number = 0;
    public canTwentyFour: number = 0;
    public canRebate: number = 0;
    public daily_task: number = 0;
    public dailydata: any = null;
    public roomDailyTaskListData: any = null;
    public canReliefPay: number = 0;
    public newDailydata: any = null;
    public backCardTaskdata: any = null;
    public newDailyListData: any = null;
    public dailyLoginActData: any = null;
    public rechargeRewardsData: any = null;
    public newDailyRules: string = "";
    public showNewDailyTask: number = 0;
    public showBackTask: number = 0;
    public showBackCardTask: number = 0;
    public pingRequestTime: any = undefined;
    public pingRequestTime2: any = undefined;
    public isFirstOpenApp: boolean = true;
    public BackHallOpenModule: any = -1;
    public invite_bonus: number = 0;
    public poplist: any[] = [];
    public hasLogin: boolean = false;
    public styles: any[] = [];
    public practice_guide_jump: boolean = false;
    public hasMaintain: boolean = false;
    public maintainMsg: any = null;
    public delayPayMsg: any[] = [];
    public delayPayIndex: number = 0;
    public has_referral: number = 0;
    public charge_open: number = 1;
    public game_raceid: any[] = [];
    public jump_type: any = null;
    public jump_ext: any = null;
    public bLoginGetJumpType: boolean = false;
    public inner_rank_open: boolean = false;
    public ispingbi: number = 1;
    public is04pingbi: number = 0;
    public sigal_delay_show: boolean = false;
    public g_delay: boolean = false;
    public easy_mode_show: boolean = false;
    public multiple_rummy_open: number = 0;
    public multiple_2_open: number = 0;
    public bump_rummy_open: number = 0;
    public auto_sort_tips: boolean = false;
    public private_share_open: boolean = false;
    public mall_gift: boolean = false;
    public mall_lottery: boolean = false;
    public act_54_report: boolean = true;
    public act_68_report: boolean = true;
    public act_65_report: boolean = true;
    public act_66_report: boolean = true;
    public act_83_report: boolean = true;
    public adjust_reg_event: string = "";
    public show_sgame: number = 0;
    public act_68_open: number = 0;
    public act_68_full_status: number = 0;
    public small_game: any[] = [];
    public forceSignCricket: number = 0;
    public first_recharge_type: number = 1;
    public temp_pingbi: any = { email: 0, me: 0, cardsetting: 0, recommend: this.ispingbi, tickets: 1, match_ticket: 1, dailytask: this.is04pingbi, xstask: this.is04pingbi, activity: this.is04pingbi, referearn: this.is04pingbi, userinfo: this.is04pingbi, loginLanguage: this.ispingbi, performance: this.ispingbi, performance_playback: this.ispingbi, fblogin: this.ispingbi, add_cash_limits: this.is04pingbi, feedback: this.is04pingbi, me_add_cash: this.is04pingbi, guess_card: this.is04pingbi, sclb: this.is04pingbi, twentyhour: this.is04pingbi, cclb: this.is04pingbi, store: this.is04pingbi, club: this.is04pingbi, withdraw: this.is04pingbi, matchgame: this.is04pingbi, buddygame: this.is04pingbi, guestlogin: this.is04pingbi, register: this.is04pingbi, matchshow: this.is04pingbi, tds: this.is04pingbi, redeemcode: this.is04pingbi, tds_me: this.is04pingbi, tds_bubble: this.is04pingbi, gst_me: this.is04pingbi, wallet_me: this.is04pingbi };
    public can_update_nick_name: number = 0;
    public fromGame: number = 0;
    public is_check_location: number = 0;
    public hasJumpToSet: boolean = false;
    public jumpFromHall: boolean = false;
    public check_list: any = null;
    public practice_tips_info: any = null;
    public hall_bundleMap: Map = new Map;
    public popNode: any[] = [];
    public walletResult: any = null;
    public hasPreload: boolean = false;
    public inviteEarnings: any = null;
    public couponData: any[] = [];
    public rechargeLimitData: any = null;
    public withdrawData: any = null;
    public hallLeaderBoardMainData: any = {};
    public DepositTransferData: any = null;
    public withdrawAccountData: any = null;
    public walletDetailsData: Map = new Map;
    public emailData: any = null;
    public tdsList: any = null;
    public contactInfoList: any = null;
    public LotteryData: any = null;
    public promotions_red: number = 0;
    public dailyTask_red: any = {};
    public novicesTask_red: any = {};
    public with_tip: string = "";
    public sysRecommend: any = null;
    public canRefreshWallet: boolean = true;
    public bHasGetSwitchInfo: boolean = false;
    public bHasStartPint: boolean = false;
    public bHasStartGooglePint: boolean = false;
    public pan_open: number = 0;
    public pan_check: number = 0;
    public pancard_data: any = null;
    public novice_guide_type: number = 0;
    public outTradeNo: any = null;
    public adjustSchedule: any = null;
    public isShowPopList: boolean = true;
    public newKycData: any = { form_list: [], kyc_list: {} };
    public me_del_account: number = 0;
    public profile_del_account: number = 0;
    public bind_type: number = 0;
    public hasFirstLocation: boolean = false;
    public isInPerformanceRoom: number = 0;
    public game_id: number = 0;
    public help_setting: any = { open_deck_pick: 0, discard: 0, finish_card_number: 0, finish_conditions: 0, quick_finish: 0, card_rating: 0, sort_mode: 0, card_reading: 0, enter_anim: 0, play_effect: 0, available_cards: 0, open_deck_pick_def: 0, discard_def: 0, finish_card_number_def: 0, finish_conditions_def: 0, quick_finish_def: 0, card_rating_def: 0, sort_mode_def: 2, card_reading_def: 0, enter_anim_def: 0, play_effect_def: 0, multiple_card_rating: 0, available_cards_def: 0 };
    public play_back_round: number = 1;
    public first_click_play_time: any = -1;
    public enter_game_loadRes_time: any = -1;
    public send_gate_log_time: any = -1;
    public send_game_log_time: any = -1;
    public send_game_create_tab_time: any = -1;
    public performanceData: any = null;
    public performanceSiftStatus: any[] = [];
    public detalisData: any = null;
    public detalisIndex: number = 0;
    public walletPayDetailsData: any = null;
    public nAutoLoginType: any = -1;
    public abtest_closevid: any[] = [];
    public kyc_guide_data: any = {};
    public kyc_bottom_tip: string = "";
    public gullak_data: any = null;
    public freecashData: any = null;
    public happyHoliData: any = null;
    public weekmonthData: any = null;
    public receiptData: any = null;
    public receiptHistorList: any[] = [];
    public mall_exp_data: any = null;
    public bonusForestData: any = null;
    public treasureMainData: any = null;
    public treasureBoomPopData: any = null;
    public _bNewPlayerGuideskip: boolean = false;
    public remoteImagesMap: Map = new Map;
    public remoteAnimMap: Map = new Map;
    public hallGamesTabInfo: any = null;
    public points_easy_cfg: any = { tips_times: 1, show_game_introduce: 0, show_new_tag: 0 };
    public points_multiple_cfg: any = { tips_times: 1, show_game_introduce: 0, show_new_tag: 0, initial_drop_points: 0, middle_drop_points: 0, max_lose: 0 };
    public points_bump_cfg: any = { tips_times: 1, show_game_introduce: 0, show_new_tag: 0 };
    public points_double_cfg: any = { tips_times: 1, show_game_introduce: 0, show_new_tag: 0 };
    public lucky_box: number = 0;
    public act_73: number = 0;
    public act_73_report: number = 0;
    public vedioMap: Map = new Map;
    public mall_label: number = 0;
    public commonRewardMsgs: any[] = [];
    public rewardIndex: number = 0;
    public act_74_report: number = 0;
    public _reqHallGetTime: number = 0;
    public _php_msg_status: Map = new Map;
    public is_new_login: number = 1;
    public lastWinGameInfo: any = { nVid: -1, nScore: 0 };
    public bShowAppReview: boolean = false;
    public superVipPageData: any = null;
    public superVipUpMsg: any = null;
    public adventrueData: any = null;
    public show_ask: number = 0;
    public hall_box_active: boolean = false;
    public hall_box_click: boolean = false;
    public act_76_show: number = 0;
    public hall_rank_data: any = null;
    public act_76_recommend_list: any[] = [];
    public roomActRankDataMap: Map = new Map;
    public store_retain_expire_seconds: number = 0;
    public retention_pop_info: any = null;
    public act_79: number = 0;
    public has_go_charge: boolean = false;
    public charge_sucess: boolean = false;
    public has_req_lobbyPop: boolean = false;
    public hall_select_tab: number = 2;
    public show_exclusive_skin: number = 0;
    public s_whatsapp: number = 0;
    public s_uirp_1: number = 0;
    public s_uirp_2: number = 0;
    public s_uirp_3: number = 0;
    public s_uirp_4: number = 0;
    public choose_game_type: number = 0;
    public matchInfoList: any = null;
    public bonus_out_time: boolean = false;
    public session_id: string = "";
    public gameDisplayPageData: any = null;
    public avatar_frame_id: number = 0;
    public act_90_open: number = 0;
    public act_101_open: number = 0;
    public act_90_recommend_list: any[] = [];
    public act_116_not_recommend_list: any[] = [];
    public act_116_not_recommend_show: number = 0;
    public treasureHuntMainData: any = null;
    public act_97_open: number = 0;
    public act_97_recommend_list: any[] = [];
    public chip_treasureHuntMainData: any = null;
    public free_match_raceid: any = null;
    public kyc_resubmit_data: any = null;
    public match_ticket_no: any = null;
    public match_tid_key: any = null;
    public match_vid: any = null;
    public match_isDetail: number = 0;
    public has_invite_reward: number = 0;
    public exe_cfg: any = { introduce_times: 1 };
    public exe_data: any = null;
    public chip_hall_give: number = 0;
    public honorteam_role: any = -1;
    public act_96_recommend_list: any = null;
    public act_96_unrecommend_list: any = null;
    public honorteam_mainData: any = null;
    public honorteam_ruleData: any = null;
    public chip_bump_rummy_open: number = 0;
    public chip_multiple_rummy_open: number = 0;
    public chip_multiple_2_open: number = 0;
    public bump_6_open: number = 0;
    public bump_2_open: number = 0;
    public chip_bump_6_open: number = 0;
    public chip_bump_2_open: number = 0;
    public double_6_open: number = 0;
    public chip_double_6_open: number = 0;
    public sw_reportLoginTime: boolean = false;
    public sw_reportGameTime: boolean = false;
    public tawk_open: number = 0;
    public tawk_url: string = "";
    public isFirstOpenApp2: boolean = true;
    public chip_local_has: boolean = false;
    public act_98_times: number = 0;
    public act_98_touch_chip: number = 0;
    public act_98_give_chip: number = 0;
    public _preload_act_list: any[] = [];
    public superVipHelpData: any = null;
    public marketInviteData: any = null;
    public choosegame: any = null;
    public bHasPreGetActInfo: boolean = false;
    public enterRoomMoneyExe: number = 0;
    public enterRoomMoney: number = 0;
    public gameShareConfig: any = null;
    public exitRoomGameType: number = 0;
    public exitRoomRummyType: number = 0;
    public exitRoomGameVid: number = 0;
    public _checkExitRoomVid: boolean = true;
    public withdraw_noCharge_open: number = 1;
    public points_classic_gesture: number = 0;
    public points_classic_base_money: number = 0;
    public game_lock_data: any = null;
    public table_red_dot: number = 0;
    public ratingTradeNo: any = null;
    public gp_rating_open: number = 0;
    public gp_rating_lock_hour: number = 0;
    public last_rating_time: number = 0;
    public gp_raing_finish_seconds: number = 0;
    public gp_raing_hasSkip: boolean = false;
    public gp_raing_skip_time: number = 0;
    public playingMethod_entry_switch: any[] = [];
    public crazyCashbackData: any = null;
    public crazyCashbackRule: any = null;
    public showCrazyCashback: number = 0;
    public showCrazyCashbackDot: number = 0;
    public feedback_sw: number = 0;
    public golden_link_data: any = null;
    public tawk_url_1: string = "";
    public tawk_url_2: string = "";
    public tawk_url_3: string = "";
    public tawk_url_4: string = "";
    public tawk_url_5: string = "";
    public tawk_url_6: string = "";
    public tawk_url_7: string = "";
    public tawk_url_8: string = "";
    public tawk_url_9: string = "";
    public tawk_url_10: string = "";
    public tawk_url_11: string = "";
    public backpack: number = 0;
    public history_data_open: number = 0;
    public restartGift_pagedata: any = null;
    public backPackData: any = null;
    public hisGameRecord: Map = new Map;
    public faqMainData: any = null;
    public faqDetailsData: Map = new Map;
    public cricket_open: number = 0;
    public custom_sel_gift_open: number = 0;
    public treasuredraw_open: number = 0;
    public popActState: number = 0;
    public forcePopAct: boolean = false;
    public cricGameStyle: number = 2;
    public payment_cnt: any = { upi_1_min: 0, upi_1_max: 0, upi_2_min: 0, upi_2_max: 0, upi_2_add: 0, selectpay_shop: 0, selectpay_gift: 0, pmode: 0, upi2_select_amount: [] };
    public share_rank_data: any = { rank_list: [], total_bouns: 0, total_cash: 0, user_share_data: {}, page: -1, hasNextPage: 0 };
    public payment_scene: any = { scene: -1, vid: 0 };
    public popact_anim_count: number = 3;
    constructor() {
        PushCenter.shared().addListener(PushEvent.LoginLabaSocket, (a => {
            let t = { cmd: NetConfig.Laba_Login_req, uid: User.shared().data.uid, vid: 101, name: User.shared().data.name, skey: User.shared().getSkey(), version: GameConfig.Server_Api_Ver, is_new_login: User.shared().getIsNewLogin() };
            LabaServer.shared().send(t);
        }), this);
        PushCenter.shared().addListener(PushEvent.SwitchGameGateAddr, (a => {
            User.shared().switchGameGateReconAddr();
        }), this);
        PushCenter.shared().addListener(PushEvent.ShowLoginScene, (a => {
            User.shared().showLogin();
        }), this);
        PushCenter.shared().addListener(PushEvent.ReqAdReward, (a => {
            if (!sys.isObjectValid(a)) {
                return;
            }
            let t = a.report_scene, i = a.report_link_id;
            User.shared().requestActAdVideoReceivReward(t, i);
        }), this);
        PushCenter.shared().addListener(PushEvent.ShowWebWithdrawAdd, (a => {
            User.shared().showWebWithdrawAddView();
        }), this);
        PushCenter.shared().addListener(PushEvent.ShowWebPanVerify, (a => {
            let t = ToolUtils.isObjValid(a) ? a : null;
            User.shared().showWebPanVerify(t);
        }), this);
        PushCenter.shared().addListener(PushEvent.GetLocationStatus, (a => {
            User.shared().requestGetLocationStatus();
        }), this);
    }
    static shared() : User {
        return null == this._instance && (this._instance = new User, this._instance.init()), this._instance;
    }
    init() {
        AppInfo.shared().getChannelId();
        this.resetUserData(GameConfig.CHANNEL_ID);
        ToolUtils.isInGameScene = 0;
        this._nBackToHallGameId = -1;
        this.pingRequestTime = sys.now();
        this.pingRequestTime2 = sys.now();
        this.popNode = [];
        this.startCleanPhpMsgCatsh();
    }
    resetUserData(e) {
        this.data.uid = 0;
        ToolUtils.uid = 0;
        this.data.skey = "0";
        ToolUtils.skey = "0";
        this.data.channel = e;
        this.data.money = 0;
        this.data.sex = 2;
        this.data.user = "";
        this.data.name = "";
        this.data.avatar = "head_1.png";
        this.data.password = "";
        this.get_gmoney = 0;
        this.get_bonus = 0;
        this.real_money = 0;
        this.isPop_chest = false;
        this.isAutoGame = false;
        this.in_vid = -1;
        this.in_gameType = -1;
        this.in_isPractice = 0;
        ToolUtils.in_isGuideRoom = 0;
        this._bHasRequestRoomList = false;
        this.roomTable = [];
        this.openGameTab = [];
        this.data.money_exe = 0;
        this.isShowGuideRewardTips = false;
        this.data.kyc_data = {};
        this.data.kyc_check = 0;
        this.data.real_name = "";
        this.data.location_status = 0;
        this.data.kyc_open = 0;
        this.data.card_check_type = 0;
        this.inviteEarnings = null;
        this.couponData = [];
        this.rechargeLimitData = null;
        this.withdrawData = null;
        this.DepositTransferData = null;
        this.withdrawAccountData = null;
        this.emailData = null;
        this.walletDetailsData.clear();
        this.tdsList = null;
        this.contactInfoList = null;
        this.isShowPopList = true;
        this.newKycData = { form_list: [], kyc_list: {} };
        this.gullak_data = null;
        this.private_share_open = false;
        this.freecashData = null;
        this._php_msg_status.clear();
        this.weekmonthData = null;
        this.receiptData = null;
        this.bonusForestData = null;
        this.treasureMainData = null;
        this.act_90_open = 0;
        this.act_101_open = 0;
        this.act_90_recommend_list = [];
        this.act_116_not_recommend_list = [];
        this.treasureHuntMainData = null;
        this.act_97_open = 0;
        this.act_97_recommend_list = [];
        this.chip_treasureHuntMainData = null;
        this.act_96_recommend_list = null;
        this.act_96_unrecommend_list = null;
        this.honorteam_role = -1;
        this.honorteam_mainData = null;
        this.feedback_sw = 0;
        this.faqMainData = null;
        this.faqDetailsData.clear();
        this.hisGameRecord.clear();
        this.cricket_open = 0;
        this.custom_sel_gift_open = 0;
        this.treasuredraw_open = 0;
        this.hallLeaderBoardMainData = {};
        SportCricket_Manager.shared().cricket_completeInfo = [];
        SportCricket_Manager.shared().cricket_notInLineUpMap.clear();
        SportCricket_Manager.shared().cricket_playerInfoMap.clear();
        this.payment_cnt = { upi_1_min: 0, upi_1_max: 0, upi_2_min: 0, upi_2_max: 0, upi_2_add: 0, selectpay_shop: 0, selectpay_gift: 0, pmode: 0, upi2_select_amount: [] };
        this.forceSignCricket = 0;
        this.share_rank_data = { rank_list: [], total_bouns: 0, total_cash: 0, user_share_data: {}, page: -1, hasNextPage: 0 };
        this.payment_scene = { scene: -1, vid: 0 };
    }
    cleanTmpData() {
        this.data.uid = 0;
        ToolUtils.uid = 0;
        this.data.skey = "0";
        ToolUtils.skey = "0";
        this.club_data = null;
        this.walletData_bonus = null;
        this.walletData_history = null;
        this.clubData_history = null;
        this.StoreData_His_rec = null;
        this.StoreData_His_with = null;
        this.actList = [];
        this.promotions_red = 0;
        this.dailyTask_red = {};
        this.novicesTask_red = {};
        this.with_tip = "";
        this.new_user_task = 0;
        this.new_user_task_open = 0;
        this.new_user_flopcash_open = 0;
        this.firstrechargeData = null;
        this.twentyfourrechargeData = null;
        this.rebaterechargeData = null;
        this.payOneForThreeData = null;
        this.consecutiveGiftData = null;
        this.customSelGiftData = null;
        this.treasuredrawData = null;
        this.chipfirstrechargeData = null;
        this.reliefPackageData = null;
        this.dailyFireSaleData = null;
        this.canFirstPay = 0;
        this.canTwentyFour = 0;
        this.canRebate = 0;
        this.daily_task = 0;
        this.canReliefPay = 0;
        this.novicesTaskData = null;
        this.flopCashTaskData = null;
        this.flopCashTaskRecordData = null;
        this.inviteEarnings = null;
        this.couponData = [];
        this.rechargeLimitData = null;
        this.withdrawData = null;
        this.DepositTransferData = null;
        this.withdrawAccountData = null;
        this.emailData = null;
        this.walletDetailsData.clear();
        this.tdsList = null;
        this.sysRecommend = null;
        this.contactInfoList = null;
        this.isShowPopList = true;
        this.abtest_closevid = [];
        this.kyc_guide_data = {};
        this.kyc_bottom_tip = "";
        this._php_msg_status.clear();
        this.is_new_login = 1;
        this.weekmonthData = null;
        this.freecashData = null;
        this.receiptData = null;
        this.bonusForestData = null;
        this.has_req_lobbyPop = false;
        this.adventrueData = null;
        this.hall_rank_data = null;
        this.gullak_data = null;
        this.backCardTaskdata = null;
        this.treasureMainData = null;
        this.dailyLoginActData = null;
        this.crazyCashbackData = null;
        ToolUtils._bNeedReportToken = true;
        this.bHasPreGetActInfo = false;
        this.exitRoomGameVid = 0;
        this.exitRoomGameType = 0;
        this.exitRoomRummyType = 0;
        this.points_classic_gesture = 0;
        this.points_classic_base_money = 0;
        this.game_lock_data = null;
        this._checkExitRoomVid = true;
        this.feedback_sw = 0;
        this.showCrazyCashback = 0;
        this.showCrazyCashbackDot = 0;
        this.golden_link_data = null;
        this.faqMainData = null;
        this.faqDetailsData.clear();
        this.hisGameRecord.clear();
        this.cricket_open = 0;
        this.custom_sel_gift_open = 0;
        this.treasuredraw_open = 0;
        this.last_rating_time = 0;
        this.ratingTradeNo = null;
        this.hallLeaderBoardMainData = {};
        SportCricket_Manager.shared().cricket_completeInfo = [];
        SportCricket_Manager.shared().cricket_notInLineUpMap.clear();
        SportCricket_Manager.shared().cricket_playerInfoMap.clear();
        this.payment_cnt = { upi_1_min: 0, upi_1_max: 0, upi_2_min: 0, upi_2_max: 0, upi_2_add: 0, selectpay_shop: 0, selectpay_gift: 0, pmode: 0, upi2_select_amount: [] };
        this.forceSignCricket = 0;
        this.share_rank_data = { rank_list: [], total_bouns: 0, total_cash: 0, user_share_data: {}, page: -1, hasNextPage: 0 };
        this.payment_scene = { scene: -1, vid: 0 };
    }
    resetUserDataInHall() {
        ToolUtils.resetUserDataInHall();
        let e = sys.localStorage.getItem("auto_sort");
        null != e && null != e && (this.auto_sort = Number(e));
        this.practice_guide_jump = false;
        this.hasMaintain = false;
        this.isSwitchGame = false;
        this.curTid_key = "";
        this.isShowMatchEnterTips = false;
        this.isAutoGame = false;
        this.crashModel = 0;
        this.first_click_play_time = -1;
        this.enter_game_loadRes_time = -1;
        this.match_isDetail = 0;
    }
    setUserDataByResponse() {
        if (this.isFirstRegist = null != this.data.isregister && 1 == this.data.isregister, this.real_money = this.data.money, sys.isObjectValid(this.data.shop_open) && (this._shop_open = this.data.shop_open), sys.isObjectValid(this.data.gbonus) && (this.get_bonus = this.data.gbonus), sys.isObjectValid(this.data.gmoney) && (this.get_gmoney = this.data.gmoney), sys.isObjectValid(this.data.isregister) && (ToolUtils.isregister = this.data.isregister), sys.isObjectValid(this.data.client_ip) && (ToolUtils.client_ip = this.data.client_ip), sys.isObjectValid(this.data.games_delay_open) && (this.games_delay_open = this.data.games_delay_open), sys.isObjectValid(this.data.heart_open) && (ToolUtils.heart_open = this.data.heart_open), sys.isObjectValid(this.data.heartbeat_time) && (ToolUtils.heartbeat_time = this.data.heartbeat_time), sys.isObjectValid(this.data.phplog_write_open) && (this.phplog_write_open = this.data.phplog_write_open), sys.isObjectValid(this.data.heart_time) && (ToolUtils.heart_time = this.data.heart_time), sys.isObjectValid(this.data.invite_bonus) && (this.invite_bonus = this.data.invite_bonus), sys.isObjectValid(this.data.can_update_nick_name) && (this.can_update_nick_name = this.data.can_update_nick_name), sys.isObjectValid(this.data.check_list) && (this.check_list = this.data.check_list, TLog.printMsg("check_list:", this.check_list)), sys.isObjectValid(this.data.netime) && ToolUtils.isSafeNumber(this.data.netime) > 0 && (ToolUtils.firstLoginTime = 1000 * this.data.netime), sys.isObjectValid(this.data.pan_open) && (this.pan_open = this.data.pan_open), sys.isObjectValid(this.data.pan_check) && (this.pan_check = this.data.pan_check), sys.isObjectValid(this.data.act_63_ui) && (this.showNewDailyTask = this.data.act_63_ui), sys.isObjectValid(this.data.act_63_back_ui) && (this.showBackTask = this.data.act_63_back_ui), sys.isObjectValid(this.data.act_63_backcard_ui) && (this.showBackCardTask = this.data.act_63_backcard_ui), sys.isObjectValid(this.data.act_90_open) && (this.act_90_open = this.data.act_90_open), sys.isObjectValid(this.data.act_101_open) && (this.act_101_open = this.data.act_101_open), sys.isObjectValid(this.data.style) && (this.cricGameStyle = this.data.style), sys.isObjectValid(this.data.act_97_open) && (this.act_97_open = this.data.act_97_open), sys.isObjectValid(this.data.tawk_url) && (this.tawk_url = this.data.tawk_url), AppInfo.shared().getIsNewKyc() && sys.isObjectValid(this.data.new_kyc_check) && (this.data.kyc_check = this.data.new_kyc_check), sys.isObjectValid(this.data.table_red_dot) && (this.table_red_dot = this.data.table_red_dot), sys.isObjectValid(this.data.feedback_url_type) && (ToolUtils.feedback_url_type = this.data.feedback_url_type), sys.isObjectValid(this.data.gateway_heart) && (ToolUtils.gateHeartBeatSwitch = 1 == ToolUtils.isSafeNumber(this.data.gateway_heart)), this.abtest_closevid = [], sys.isObjectValid(this.data.abtest_closevid) && Array.isArray(this.data.abtest_closevid)) {
            for (let e, a = 0, t = this.data.abtest_closevid.length; a < t; a++) {
                e = Number(this.data.abtest_closevid[a]);
                this.abtest_closevid[e] = true;
            }
        }
        if (sys.isObjectValid(this.data.lobby_play)) {
            for (let e = 0, a = this.data.lobby_play.length; e < a; e++) {
                const a = Number(this.data.lobby_play[e]);
                this.openGameTab[a] = true;
            }
        }
    }
    getSkey() {
        return HttpManager.shared().getSkey();
    }
    checkVidOpen(e) {
        return !this.abtest_closevid[e];
    }
    loadLocalRoomTable() {
        try {
            let e = localStorage.getItem("commRoomData");
            sys.isObjectValid(e) && "" != e && (this.roomTable = ToolUtils.parseJson(e));
        }
        catch (e) {
            TLog.printError("----------- loadLocalRoomTable error:", e);
        }
    }
    cleanLocalRoomTable(e = false) {
        this._bHasRequestRoomList = false;
        this.roomTable.pointsrummy_v = -1;
        this.roomTable.poolrummy_v = -1;
        this.roomTable.dealsrummy_v = -1;
        this.roomTable.multiplerummy_v = -1;
        this.roomTable.lobby_list_v = -1;
        e && ToolUtils.saveData("commRoomData", "");
    }
    requestRoomList(e = false) {
        sys.isObjectValid(this.roomTable.pointsrummy) && -1 != this.roomTable.pointsrummy_v || (this._bHasRequestRoomList = false, this.checkGameRoomList(e));
    }
    checkGameRoomList(e = false, a = false) {
        return sys.isObjectValid(this.roomTable.pointsrummy) && -1 != this.roomTable.pointsrummy_v ? (this._bHasRequestRoomList = true, true) : (this._bHasRequestRoomList ? PushCenter.shared().pushEvent(GameConfig.Delay_Ask_RoomList) : (this._bHasRequestRoomList = true, e && Utils.shared().showLoading(10, false), this.doReqCommRoomList((() => {
            PushCenter.shared().pushEvent(PushEvent.GetRoomListCallBack);
        }), a)), false);
    }
    doReqCommRoomList(a = null, t = false) {
        HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Login, event: ReportConfig.login_evt.getRoomInfo });
        TransferPlatform.shared().logEvent_firebase(ReportConfig.login_evt.getRoomInfo);
        let i = sys.now(), r = { channel_id: TransferPlatform.shared().getChannelId(), phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: i, rver: GameConfig.NEW_APP_VERSION };
        sys.isObjectValid(this.roomTable.pointsrummy) || this.loadLocalRoomTable();
        t || (sys.isObjectValid(this.roomTable.pointsrummy_v) && (r.pointsrummy_v = this.roomTable.pointsrummy_v), sys.isObjectValid(this.roomTable.poolrummy_v) && (r.poolrummy_v = this.roomTable.poolrummy_v), sys.isObjectValid(this.roomTable.dealsrummy_v) && (r.dealsrummy_v = this.roomTable.dealsrummy_v), sys.isObjectValid(this.roomTable.multiplerummy_v) && (r.multiplerummy_v = this.roomTable.multiplerummy_v), sys.isObjectValid(this.roomTable.lobby_list_v) && (r.lobby_list_v = this.roomTable.lobby_list_v));
        HttpManager.shared().doGetCommRoomList(r, ((i, r, d) => {
            if (a && a(), 0 == r.length) {
                return void TransferPlatform.shared().logEvent_firebase(ReportConfig.login_evt.req_room_info_fail);
            }
            1 == GameConfig.HTTP_MSG_DEBUG && TLog.printMsg(r);
            let h = ToolUtils.parseJson(r);
            if (!sys.isObjectValid(h.ret) || 0 != h.ret) {
                return TransferPlatform.shared().logEvent_firebase(ReportConfig.login_evt.req_room_info_fail), void (1 == GameConfig.HTTP_MSG_DEBUG && TLog.printMsg(h.desc));
            }
            TransferPlatform.shared().logEvent_firebase(ReportConfig.login_evt.req_room_info_succ);
            let l = false;
            t ? (this.roomTable = [], this.roomTable = h.data, l = true) : sys.isObjectValid(this.roomTable.pointsrummy) ? (sys.isObjectValid(h.data.lobby_list_v) ? sys.isObjectValid(this.roomTable.lobby_list_v) && this.roomTable.lobby_list_v == h.data.lobby_list_v || (this.roomTable.lobby_list_v = h.data.lobby_list_v, this.roomTable.lobby_list = h.data.lobby_list, l = true) : sys.isObjectValid(h.data.lobby_list) && (this.roomTable.lobby_list = h.data.lobby_list, l = true), sys.isObjectValid(h.data.pointsrummy_v) && this.roomTable.pointsrummy_v == h.data.pointsrummy_v ? sys.isObjectValid(h.data.pointsrummy) && h.data.pointsrummy.length > 0 && (this.roomTable.pointsrummy = h.data.pointsrummy, l = true) : (this.roomTable.pointsrummy_v = h.data.pointsrummy_v, this.roomTable.pointsrummy = h.data.pointsrummy, l = true), sys.isObjectValid(h.data.poolrummy_v) && this.roomTable.poolrummy_v == h.data.poolrummy_v ? sys.isObjectValid(h.data.poolrummy) && h.data.poolrummy.length > 0 && (this.roomTable.poolrummy = h.data.poolrummy, l = true) : (this.roomTable.poolrummy_v = h.data.poolrummy_v, this.roomTable.poolrummy = h.data.poolrummy, l = true), sys.isObjectValid(h.data.dealsrummy_v) && this.roomTable.dealsrummy_v == h.data.dealsrummy_v ? sys.isObjectValid(h.data.dealsrummy) && h.data.dealsrummy.length > 0 && (this.roomTable.dealsrummy = h.data.dealsrummy, l = true) : (this.roomTable.dealsrummy_v = h.data.dealsrummy_v, this.roomTable.dealsrummy = h.data.dealsrummy, l = true), sys.isObjectValid(h.data.multiplerummy_v) && this.roomTable.multiplerummy_v == h.data.multiplerummy_v ? sys.isObjectValid(h.data.multiplerummy) && h.data.multiplerummy.length > 0 && (this.roomTable.multiplerummy = h.data.multiplerummy, l = true) : (this.roomTable.multiplerummy_v = h.data.multiplerummy_v, this.roomTable.multiplerummy = h.data.multiplerummy, l = true)) : (this.roomTable = [], this.roomTable = h.data, l = true);
            this.checkRecommendRoom();
            l && ToolUtils.saveData("commRoomData", ToolUtils.toJsonString(User.shared().roomTable));
            sys.isObjectValid(h.data.refresh_room_ver) && ToolUtils.saveData("refresh_room_ver", h.data.refresh_room_ver);
        }));
    }
    checkFastBuy() {
        return true;
    }
    requestStoreList(e = null, a = 1) {
        HttpManager.shared().doGetSoreList2(e, a, ((a, t, i) => {
            if (200 != i) {
                PushCenter.shared().pushEvent(GameConfig.Get_StoreList_Err);
            }
            else {
                let a = ToolUtils.parseJson(t);
                0 == a.ret && (this.store_retain_expire_seconds = 0, this.soreTb = a.data, sys.isObjectValid(a.data.retention_pop_info) ? this.retention_pop_info = a.data.retention_pop_info : this.retention_pop_info = null);
                PushCenter.shared().pushEvent(GameConfig.Update_Store, e);
                PushCenter.shared().pushEvent(GameConfig.Update_Wallet);
            }
        }));
    }
    requestMallExeShopList(e = null) {
        HttpManager.shared().doGetExeStoreList(e, ((a, t, s) => {
            if (200 != s) {
                PushCenter.shared().pushEvent(GameConfig.Get_ExeStoreList_Err);
            }
            else {
                let a = ToolUtils.parseJson(t);
                0 == a.ret && (this.mall_exp_data = a.data);
                PushCenter.shared().pushEvent(GameConfig.Update_ExeStore, e);
            }
        }));
    }
    getShopStatus() {
        return 0 != this._shop_open || (Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text28"), 2, 0, ToolUtils.getIsNormalDirection()), false);
    }
    showFastShop(e = false, a, t = 0, s = 0) {
        let i = this;
        if (e) {
            Utils.shared().showCommomDialog(i18nMgr.shared().getValueByKey("utlis.text1"), i18nMgr.shared().getValueByKey("choose_game.add_cash"), (e => {
                if (1 == e) {
                    if (i.soreTb && "object" == typeof i.soreTb && 0 == i.soreTb.length) {
                        return void HttpManager.shared().doGetSoreList2((() => {
                            PushCenter.shared().pushEvent(GameConfig.Show_FullScreen_Shop, a);
                        }));
                    }
                    PushCenter.shared().pushEvent(GameConfig.Show_FullScreen_Shop, a);
                }
            }), false, ToolUtils.getIsNormalDirection());
        }
        else {
            let e = { vid: a, match_vid: t, min_entry: s };
            PushCenter.shared().pushEvent(GameConfig.Show_Shop, ToolUtils.toJsonString(e));
        }
    }
    showBlindAlert(e, a) {
        let t = i18nMgr.shared().getValueByKey("utlis.text2"), s = i18nMgr.shared().getValueByKey("utlis.text3");
        Utils.shared().showCommomDialog(s, t, (e => {
            1 == e && Utils.shared().showVerifyPhoneDlg();
        }), true);
    }
    doBindInvite() {
        let a = "";
        a = AppInfo.shared().getAPKComment();
        null != a && null != a && String(a).length > 0 && HttpManager.shared().doGetMemberShipBind(a, ((a, t, s) => {
            if (Utils.shared().hideLoading(), 200 != s) {
                Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text29"), 2, 0, ToolUtils.getIsNormalDirection());
            }
            else {
                let a = ToolUtils.parseJson(t);
                if (0 == a.ret) {
                    if (null != a.data && null != a.data && null != a.data.uid) {
                        let t = ToolUtils.format(i18nMgr.shared().getValueByKey("utlis.text30"), String(a.data.uid));
                        Utils.shared().showToast(t, 2, 0, ToolUtils.getIsNormalDirection());
                        this.m_strMyRefererId = String(a.data.uid);
                        User.shared().clubUserInfo && User.shared().clubUserInfo.data && (User.shared().clubUserInfo.data.my_referrer = a.data.uid);
                        PushCenter.shared().pushEvent(GameConfig.Update_invite_ReferrerID, 0);
                    }
                }
                else {
                    null != a.desc && null != a.desc && Utils.shared().showToast(a.desc, 2, 0, ToolUtils.getIsNormalDirection());
                }
            }
        }));
    }
    getLoginParam() {
        let e, a;
        -1 != GameConfig.CHIPS_CHANNELS.indexOf(GameConfig.CHANNEL_ID) && 1 == GameConfig.CHIPS_MODLE ? (e = ToolUtils.isSafeString(sys.localStorage.getItem("LoginProxy_password" + AppInfo.shared().getChannelId() + GameConfig.CHIPS_MODLE)), a = ToolUtils.isSafeString(sys.localStorage.getItem("LoginProxy_user" + AppInfo.shared().getChannelId() + GameConfig.CHIPS_MODLE))) : (e = ToolUtils.isSafeString(sys.localStorage.getItem("LoginProxy_password" + AppInfo.shared().getChannelId())), a = ToolUtils.isSafeString(sys.localStorage.getItem("LoginProxy_user" + AppInfo.shared().getChannelId())));
        let t = { user: a, password: e, ts: sys.now(), mtoken: AppInfo.shared().getOpenUDID(), token: "", access_token: this.access_token, logintype: this.loginType, channel_id: AppInfo.shared().getChannelId(), os: AppInfo.shared().getOS(), uuid: AppInfo.shared().getPhoneUUID(), phonenos: AppInfo.shared().getPhoneOS(), phonename: AppInfo.shared().getPhoneName(), m_brand: AppInfo.shared().getPhoneBrand(), device: AppInfo.shared().getDeviceType(), rver: GameConfig.NEW_APP_VERSION, cver: AppInfo.shared().getAppVersionCode(), phoneimei: AppInfo.shared().getPhoneIMEI(), phoneimsi: AppInfo.shared().getPhoneIMEI(), m_model: AppInfo.shared().getDeviceVersion(), gaid: AppInfo.shared().getGaid(), latitude: AppInfo.shared().getLatitude(), longitude: AppInfo.shared().getLongitude() };
        return 1 == GameConfig.CHIPS_MODLE && (t.ui_a = 1), t;
    }
    updateMoney_exe(e) {
        this.data.money_exe != e && (e < 0 && (e = 0), this.data.money_exe = e, PushCenter.shared().pushEvent(PushEvent.UpdatePractiseGold, this.data.money_exe));
    }
    updateMoney(e) {
        (this.bNeedUpdateMoney || this.data.money != e || this.real_money != e) && (this.bNeedUpdateMoney = false, e < 0 && (e = 0), this.data.money = e, this.real_money = e, PushCenter.shared().pushEvent(GameConfig.Update_Money, this.data.money));
    }
    updateRoomCoin(e) {
        e < 0 && (e = 0);
        PushCenter.shared().pushEvent(PushEvent.UpdatePractiseGold_Room, e);
    }
    updateBonus(e) {
        this.data.bonus != e && (e < 0 && (e = 0), this.data.bonus = e, PushCenter.shared().pushEvent(GameConfig.Update_Bonus, this.data.bonus));
    }
    getGameRoomTable(e) {
        if (sys.isObjectValid(this.roomTable.lobby_list) && Array.isArray(this.roomTable.lobby_list) && this.roomTable.lobby_list.length > 0) {
            for (let a = 0; a < this.roomTable.lobby_list.length; a++) {
                if (this.roomTable.lobby_list[a].type == e) {
                    return sys.isObjectValid(this.roomTable.lobby_list[a].list) && Array.isArray(this.roomTable.lobby_list[a].list) ? { open: 1, list: this.roomTable.lobby_list[a].list, modes: this.roomTable.lobby_list[a].modes } : sys.isObjectValid(this.roomTable.lobby_list[a].info) ? { open: 1, info: this.roomTable.lobby_list[a].info } : { open: 1 };
                }
            }
        }
        return { open: 0 };
    }
    updateDeposit(e) {
        this.data.deposit != e && (e < 0 && (e = 0), this.data.deposit = e, PushCenter.shared().pushEvent(GameConfig.Update_Deposit, this.data.deposit));
    }
    updateWithdraw(e) {
        this.data.withdraw != e && (e < 0 && (e = 0), this.data.withdraw = e, PushCenter.shared().pushEvent(GameConfig.Update_withdraw, this.data.withdraw));
    }
    updateWallet(e) {
        this.data.wallet != e && (e < 0 && (e = 0), this.data.wallet = e, PushCenter.shared().pushEvent(PushEvent.UpdateInviteWallet, this.data.wallet));
    }
    updateGetMoney(e) {
        this.get_gmoney != e && (e < 0 && (e = 0), this.data.gmoney = e, this.get_gmoney = e, PushCenter.shared().pushEvent(GameConfig.Update_GetMoney, e));
    }
    updateGetBonus(e) {
        this.get_bonus != e && (e < 0 && (e = 0), this.data.gbonus = e, this.get_bonus = e, PushCenter.shared().pushEvent(GameConfig.Update_GetBonus, e));
    }
    updateMemberShipRp(e) {
        this.data.club.rp != e && (e < 0 && (e = 0), this.data.club.rp = e, PushCenter.shared().pushEvent(GameConfig.Update_MemberShipRp, e));
    }
    getIsNewLogin() {
        let e = this.is_new_login;
        return this.is_new_login = 0, e;
    }
    startLabaTcp() {
        let a = NetHostManager.shared().chooseBestTcpIpConn(1000), t = NetHostManager.shared().chooseBestTcpPortConn(1000), s = URLConfig.WS_LABA;
        "-1" != a && -1 != t && (s = 443 == t ? "wss://" + a + ":443" : "ws://" + a + ":" + t);
        LabaServer.shared().setOpenCb((() => {
            User.shared().send_request_hall_tableinfo();
        }));
        LabaServer.shared().createSocket(s);
        this.regLabaEvent();
    }
    regLabaEvent() {
        Server.shared().setForcedOfflineHandler(this.handler_laba_server_force_offline.bind(this));
        LabaServer.shared().regDispatch(NetConfig.Laba_CONNENCT_SUCC, this.handler_laba_connect_succ_return.bind(this), this);
        LabaServer.shared().regDispatch(NetConfig.Laba_UpDate_User, this.handler_laba_update_user_return.bind(this), this);
        LabaServer.shared().regDispatch(NetConfig.SERVER_NOTIFY_TABLE_DISBAND, this.handler_server_notify_table_disband.bind(this), this);
        LabaServer.shared().regDispatch(NetConfig.Laba_OutGame, this.handler_laba_outgame.bind(this), this);
        LabaServer.shared().regDispatch(NetConfig.Laba_SERVER_SYSTEM_MESSAGE, this.handler_laba_server_system_message.bind(this), this);
        LabaServer.shared().regDispatch(NetConfig.SERVER_FORCED_OFFLINE, this.handler_laba_server_force_offline.bind(this), this);
        LabaServer.shared().regDispatch(NetConfig.Laba_Server_BroadCast, this.handler_laba_server_broadcast.bind(this), this);
        LabaServer.shared().regDispatch(NetConfig.SERVER_TABLE_INFO_CHANGE, this.handler_server_table_info_change.bind(this), this);
        LabaServer.shared().regDispatch(NetConfig.SERVER_NOTIFY_REFLUSH_GAMEHOST, this.handler_server_notify_refluse_gamehost.bind(this), this);
        LabaServer.shared().regDispatch(NetConfig.SERVER_NOTIFY_GAME_MODE_INFO, this.handler_server_notify_game_mode_info.bind(this), this);
        LabaServer.shared().regDispatch(NetConfig.CLINET_NOTICE_KYC_CHANGE, this.handler_clinet_notify_kyc_change.bind(this), this);
        LabaServer.shared().regDispatch(NetConfig.SERVER_RESP_HALL_TABLE_INFO, this.handler_server_resp_hall_tableinfo.bind(this), this);
        LabaServer.shared().regDispatch(NetConfig.SERVER_NOTIFY_RACE_WILL_START, this.handler_server_notify_race_will_start.bind(this), this);
        LabaServer.shared().regDispatch(NetConfig.SERVER_NOTIFY_DISUSE_RACE_USER, this.handler_server_notify_disuse_race_user.bind(this), this);
        LabaServer.shared().regDispatch(NetConfig.SERVER_RACE_REWARD_INFO_RESPOND, this.handler_server_race_reward_info_respond.bind(this), this);
        LabaServer.shared().regDispatch(NetConfig.SERVER_CAN_JOIN_RACE_RESPOND, this.handler_server_can_join_race_respond.bind(this), this);
        LabaServer.shared().regDispatch(NetConfig.SERVER_NOTIFY_RACE_START, this.handler_server_notify_race_start.bind(this), this);
        LabaServer.shared().regDispatch(NetConfig.SERVER_RSYNC_SMALL_TABLE_INFO, this.handler_server_resp_game_tableinfo.bind(this), this);
        LabaServer.shared().regDispatch(NetConfig.CLIENT_NOTIFY_NEWER_REWARD_POP, this.handler_laba_notify_newer_reward_pop.bind(this), this);
        LabaServer.shared().regDispatch(NetConfig.Laba_Server_MaintenanceNotice, this.handler_laba_notify_maintenance_notice.bind(this), this);
        LabaServer.shared().regDispatch(NetConfig.SERVER_SYSTEM_MESSAGE_NEW, this.handler_laba_server_system_message_new.bind(this), this);
    }
    handler_laba_notify_maintenance_notice(a) {
        this.hasMaintain = true;
        this.maintainMsg = a;
        ToolUtils.judgeIfInScene(BundleNameDefined.hall_scene) && (LabaServer.shared().reset(), Server.shared().reset(), User.shared().bBackToLogin = true, director.loadScene("login"));
    }
    send_laba_notify_update_user_info() {
        let e = {};
        e.cmd = NetConfig.CLINET_NOTICE_USER_CHANGE;
        e.uid = this.data.uid;
        e.name = this.data.name;
        e.skey = this.getSkey();
        e.ver = GameConfig.Server_Api_Ver;
        LabaServer.shared().send(e);
    }
    send_laba_notify_newer_reward_pop_laba() {
        let e = {};
        e.cmd = NetConfig.CLIENT_NOTIFY_NEWER_REWARD_POP;
        e.uid = this.data.uid;
        e.name = this.data.name;
        e.skey = this.getSkey();
        e.ver = GameConfig.Server_Api_Ver;
        LabaServer.shared().send(e);
    }
    handler_laba_notify_newer_reward_pop(a) {
        2 == a.type && ToolUtils.judgeIfInScene(BundleNameDefined.rummy_scence) || User.shared().isShowGuideRewardTips && ToolUtils.getOrientation() && (User.shared().isShowGuideRewardTips = false, HttpManager.shared().doGetNewPlayerGuideFinish(1, ((a, t, s) => {
            if (200 == s) {
                try {
                    let a = ToolUtils.parseJson(t);
                    0 == a.ret && (ToolUtils.in_isGuideRoom = 0, User.shared().data.beginner_guide.practice_status = 1, User.shared().data.beginner_guide.cash_status = 1, null != a.data && null != a.data && null != a.data.money && (User.shared().data.money = a.data.money), this.showJumpToCashGameTips(), this.isGuideEnterGame = 1);
                }
                catch (e) {
                    TLog.printError("doGetNewPlayerGuideFinish err:", e.toString());
                }
            }
        })));
    }
    showJumpToCashGameTips(a = null, t = 0) {
        if (ToolUtils.getIsInRoom() && !this.isCanPlayCashGame()) {
            return;
        }
        let i = {};
        if (sys.isObjectValid(a)) {
            i = a;
        }
        else if (i.list = [], i.msg = i18nMgr.shared().getValueByKey("reward_tips.welcom_tip"), sys.isObjectValid(User.shared().data.beginner_guide.reward) && User.shared().data.beginner_guide.reward.length > 0) {
            if (sys.isObjectValid(User.shared().data.cdkey_reward) && User.shared().data.cdkey_reward.length > 0) {
                let a = 0, t = "";
                for (let s = 0, r = User.shared().data.beginner_guide.reward.length; s < r; s++) {
                    a = 0;
                    for (let i = User.shared().data.cdkey_reward.length; i >= 0; i--) {
                        if (Number(User.shared().data.cdkey_reward[i].type) == Number(User.shared().data.beginner_guide.reward[s].type)) {
                            a = Number(User.shared().data.cdkey_reward[i].amount);
                            t.length > 0 && (t += "+");
                            t += a + Utils.shared().getIconNameByType(User.shared().data.cdkey_reward[i].type);
                            User.shared().data.cdkey_reward.splice(i, 1);
                            break;
                        }
                    }
                    let r = [];
                    r.num = Number(User.shared().data.beginner_guide.reward[s].amt) + a;
                    r.type = Number(User.shared().data.beginner_guide.reward[s].type);
                    r.name = Utils.shared().getIconNameByType(r.type);
                    r.php_data = User.shared().data.beginner_guide.reward[s];
                    i.list.push(r);
                    0 == User.shared().data.beginner_guide.reward[s].type && 0 == User.shared().data.money && (User.shared().data.money = User.shared().data.beginner_guide.reward[s].amt + a, PushCenter.shared().pushEvent(GameConfig.Update_Money, User.shared().data.money));
                }
                for (let s = 0; s < User.shared().data.cdkey_reward.length; s++) {
                    let r = [];
                    r.num = Number(User.shared().data.cdkey_reward[s].amount);
                    r.type = Number(User.shared().data.cdkey_reward[s].type);
                    r.name = Utils.shared().getIconNameByType(r.type);
                    r.php_data = User.shared().data.cdkey_reward[s];
                    i.list.push(r);
                    0 == User.shared().data.cdkey_reward[s].type && 0 == User.shared().data.money && (User.shared().data.money = User.shared().data.cdkey_reward[s].amount, PushCenter.shared().pushEvent(GameConfig.Update_Money, User.shared().data.money));
                    t.length > 0 && (t += "+");
                    t += a + Utils.shared().getIconNameByType(User.shared().data.cdkey_reward[s].type);
                }
                User.shared().data.cdkey_reward = [];
                i.msg += "\n" + ToolUtils.format(i18nMgr.shared().getValueByKey("reward_tips.cdkey_tip"), t);
                i.hasCdkeyReward = true;
            }
            else {
                for (let a = 0, t = User.shared().data.beginner_guide.reward.length; a < t; a++) {
                    let t = [];
                    t.num = Number(User.shared().data.beginner_guide.reward[a].amt);
                    t.type = Number(User.shared().data.beginner_guide.reward[a].type);
                    t.name = Utils.shared().getIconNameByType(t.type);
                    t.php_data = User.shared().data.beginner_guide.reward[a];
                    i.list.push(t);
                }
            }
        }
        else {
            let a = [];
            a.num = User.shared().data.beginner_guide.cash_reward;
            a.type = 0;
            a.name = Utils.shared().getIconNameByType(0);
            i.list.push(a);
        }
        sys.isObjectValid(this.data.abtest_vid) && (i.vid = Number(this.data.abtest_vid));
        let r = "reward_tips.play_now";
        sys.isObjectValid(i.vid) && 0 == i.vid && (r = "reward_tips.okey");
        let d = User.shared().data.cricket_guide;
        sys.isObjectValid(d) && 1 == GameConfig.GAME_HALL_THEME && sys.isObjectValid(d.cricket_get_btn) && (1 == d.cricket_get_btn ? r = "reward_tips.okey" : (2 == d.cricket_get_btn || 3 == d.cricket_get_btn) && (r = "reward_tips.play_now"));
        Utils.shared().showRewardTips(i, (a => {
            if (1 == a) {
                let a = ReportConfig.scece.Hall, i = ReportConfig.func.NewPlayer, r = ReportConfig.newPlayerGuide.RewardDlg_playNow;
                if (4 == t ? (i = ReportConfig.func.Hall, r = ReportConfig.hall_evt.get10cash_playnow) : ToolUtils.getOrientation() && (a = ReportConfig.scece.Practice), r != ReportConfig.newPlayerGuide.RewardDlg_playNow && HttpManager.shared().doSdkApiReport({ scene: a, func: i, event: r }), !this.checkCanPlayCashGame(CheckModule.NEW_USER, true)) {
                    return void PushCenter.shared().pushEvent(PushEvent.updateLobbyBubble);
                }
                let h = 0;
                this.data.abtest_vid && (h = ToolUtils.isSafeNumber(this.data.abtest_vid));
                h > 0 ? (User.shared().first_click_play_time = Math.floor(sys.now() / 1000), PushCenter.shared().pushEvent(PushEvent.UpdateGameTableInfoNum), Utils.shared().showLoading(5, true, (() => {
                    Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
                }), ToolUtils.getIsNormalDirection()), User.shared().practice_guide_jump = true, ToolUtils.curRoomId = h, Utils.shared().showLoadTable(h, HowToPlayDefined.RUMMY_POINTS, null, null, null, null, null, 1)) : 0 == h && 1 == GameConfig.GAME_HALL_THEME && sys.isObjectValid(d) && sys.isObjectValid(d.force) && 1 == d.force && (this.forceSignCricket = 1, PushCenter.shared().pushEvent(PushEvent.RefreshYes11GameList));
            }
            else {
                let e = ReportConfig.scece.Hall;
                ToolUtils.getOrientation() && (e = ReportConfig.scece.Practice);
                PushCenter.shared().pushEvent(PushEvent.updateLobbyBubble);
                PushCenter.shared().pushEvent(PushEvent.Update_NextPopActivity);
                Utils.shared().preLoadBundleAsset(true);
                let a = 0;
                this.data.abtest_vid && (a = ToolUtils.isSafeNumber(this.data.abtest_vid));
                0 == a && 1 == GameConfig.GAME_HALL_THEME && sys.isObjectValid(d) && sys.isObjectValid(d.force) && 1 == d.force && (this.forceSignCricket = 1, PushCenter.shared().pushEvent(PushEvent.RefreshYes11GameList));
            }
        }), t, r);
    }
    handler_laba_connect_succ_return(e) {
        this.send_request_hall_tableinfo();
    }
    handler_laba_update_user_return(e) {
        if (sys.isObjectValid(e.money_exe) && this.updateMoney_exe(e.money_exe), sys.isObjectValid(e.t_m) && this.updateMoney(e.t_m), sys.isObjectValid(e.withdraw) && this.updateWithdraw(e.withdraw), sys.isObjectValid(e.wallet) && this.updateWallet(e.wallet), sys.isObjectValid(e.pay_total) && (this.data.pay_total = e.pay_total, this.has_charged = e.pay_total, this.updatePayTotalMoney(e.pay_total)), sys.isObjectValid(e.p_n) && (this.data.total_board = e.p_n), sys.isObjectValid(e.deposit) && this.updateDeposit(e.deposit), sys.isObjectValid(e.bonus) && this.updateBonus(e.bonus), sys.isObjectValid(e.gmoney) && this.updateGetMoney(e.gmoney), sys.isObjectValid(e.gbonus) && this.updateGetBonus(e.gbonus), sys.isObjectValid(e.prop_info) && e.prop_info.length > 0) {
            for (let a = 0, t = e.prop_info.length; a < t; a++) {
                let t = e.prop_info[a];
                this.setPropNumById(t.pid, t.value);
            }
        }
        sys.isObjectValid(e.p_s) && 1 == e.p_s && (sys.isObjectValid(e.tbl_n) && 1 == e.tbl_n && PushCenter.shared().pushEvent(PushEvent.NoticeUpdateHallTab), PushCenter.shared().pushEvent(PushEvent.CloseFirstRecharge), Utils.shared().uploadGtagEvent(PhpReportDefined.GA_RechargeSuc), Utils.shared().uploadFBEvent(PhpReportDefined.FB_RechargeSuc), Utils.shared().uploadGtagEvent(PhpReportDefined.GA_RechargeAmount + "_" + e.p_a), Utils.shared().uploadFBEvent(PhpReportDefined.FB_RechargeAmount + "_" + e.p_a), this.requestStoreList({ clear: true }, 2), PushCenter.shared().pushEvent(GameConfig.Recharge, 0), this.charge_sucess = true, setTimeout((() => {
            this.charge_sucess = false;
        }), 2000));
    }
    handler_server_notify_table_disband(e) {
        let a = e;
        PushCenter.shared().pushEvent(GameConfig.Update_NoTifyRoom, a);
    }
    handler_server_table_info_change(e) {
        let a = e;
        PushCenter.shared().pushEvent(GameConfig.Update_PrivateRoom, a);
    }
    handler_laba_outgame(a) {
        HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Login, event: ReportConfig.login_evt.skeyReport, skey: this.getSkey() });
        LabaServer.shared().reset();
        Server.shared().reset();
        Utils.shared().showCommomDialog(a.alertStr, "", (() => {
            User.shared().showLogin();
        }));
    }
    handler_laba_server_system_message(e) {
        ToolUtils.LabaTable.push(e.msg);
        ToolUtils.LabaCount = ToolUtils.LabaCount + 1;
    }
    handler_laba_server_system_message_new(e) {
        sys.isObjectValid(e.data) && (0 == i18nMgr.shared().language && sys.isObjectValid(e.data[0]) ? (ToolUtils.LabaTable.push(e.data[0]), ToolUtils.LabaCount = ToolUtils.LabaCount + 1) : 1 == i18nMgr.shared().language && sys.isObjectValid(e.data[1]) ? (ToolUtils.LabaTable.push(e.data[1]), ToolUtils.LabaCount = ToolUtils.LabaCount + 1) : 2 == i18nMgr.shared().language && sys.isObjectValid(e.data[2]) ? (ToolUtils.LabaTable.push(e.data[2]), ToolUtils.LabaCount = ToolUtils.LabaCount + 1) : 3 == i18nMgr.shared().language && sys.isObjectValid(e.data[3]) ? (ToolUtils.LabaTable.push(e.data[3]), ToolUtils.LabaCount = ToolUtils.LabaCount + 1) : sys.isObjectValid(e.data[0]) && (ToolUtils.LabaTable.push(e.data[0]), ToolUtils.LabaCount = ToolUtils.LabaCount + 1));
    }
    handler_laba_server_force_offline(a) {
        if (ToolUtils.has_offline) {
            return;
        }
        LabaServer.shared().reset();
        Server.shared().reset();
        localStorage.setItem("logintype", "-1");
        this.loginType = "-1";
        ToolUtils.has_offline = true;
        ToolUtils.offlineMsg = a.msg;
        this.cleanLocalRoomTable();
        ToolUtils.judgeIfInScene(BundleNameDefined.rummy_scence) ? PushCenter.shared().pushEvent(PushEvent.BackToLogin) : (TransferPlatform.shared().setHighFrameRate(), AppInfo.shared().orientationToPortrait(), User.shared().bBackToLogin = true, director.loadScene("login"));
    }
    handler_laba_server_broadcast(e) {
        let a = e.op;
        this.laba_broadcast_op = a;
        1 == a && (this.laba_broadcast_url = e.url);
        let t = e.msg;
        Utils.shared().showCommomDialog("" + t, "", (e => {
        }));
    }
    handler_server_notify_refluse_gamehost(e) {
        NetHostManager.shared().doGainNewHost();
    }
    handler_server_notify_game_mode_info(e) {
        null != e.shop_open && (this._shop_open = e.shop_open);
    }
    startCleanPhpMsgCatsh() {
        setTimeout((() => {
            let a = [], t = sys.now();
            for (let [e, s] of this._php_msg_status) {
                t - Number(s) >= 180000 && a.push(e);
            }
            for (let e = 0; e < a.length; e++) {
                this._php_msg_status.delete(a[e]);
            }
            User.shared().startCleanPhpMsgCatsh();
        }), 60000);
    }
    handler_clinet_notify_kyc_change(a) {
        if (null != a.data && null != a.data.type) {
            let t = a.data.type, r = a.data.uuid;
            if (sys.isObjectValid(r)) {
                if (this.send_php_msg_ack_laba(r), this._php_msg_status.has(r)) {
                    return void TLog.printError("---------- has deal 9008 msg! uuid:", r);
                }
                this._php_msg_status.set(r, sys.now());
            }
            switch (Number(t)) {
                case 1:
                    undefined !== a.data.kyc_check && (this.data.kyc_check = a.data.kyc_check), undefined !== a.data.card_check && (this.data.card_check = a.data.card_check), null != a.data.kyc_update_status && (this.data.kyc_update_status = a.data.kyc_update_status), sys.isObjectValid(this.newKycData.kyc_list) && (this.newKycData.kyc_list = {}), ToolUtils.isSafeString(a.data.card).length > 0 && (this.newKycData.kyc_list.card = a.data.card), sys.isObjectValid(a.data.reason) && (this.data.kyc_data.reason = a.data.reason, this.newKycData.kyc_list.reason = a.data.reason), sys.isObjectValid(a.data.fast_reason) && (this.newKycData.kyc_list.fast_reason = a.data.fast_reason), sys.isObjectValid(a.data.trigger_age_pop) && (this.newKycData.kyc_list.trigger_age_pop = a.data.trigger_age_pop), sys.isObjectValid(a.data.kyc_otp_check) && (this.data.kyc_otp_check = a.data.kyc_otp_check), 2 == a.data.card_check ? (HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Hall, event: ReportConfig.hall_evt.kyc_verify_succ }), this.newKycData.kyc_list.reason = "", this.newKycData.kyc_list.fast_reason = "", this.newKycData.kyc_list.trigger_age_pop = 0, sys.isObjectValid(a.data.card_check_type) && (this.data.card_check_type = a.data.card_check_type), AppInfo.shared().getIsNewKyc() && this.doGetKycAccount(), PushCenter.shared().pushEvent(PushEvent.Close_FastOtpView), PushCenter.shared().pushEvent(PushEvent.CloseAgeVerifySelect), PushCenter.shared().pushEvent(PushEvent.CloseWebView), sys.isObjectValid(a.data.reward_list) && a.data.reward_list.length > 0 && Utils.shared().showKycVerifySucTip(a.data.reward_list, i18nMgr.shared().getValueByKey("kyc.KYC_Verify_Suc")), this.checkUpdateActivity(PushEvent.JUMP_TO_KYC_VERIFY_SUC), PushCenter.shared().pushEvent(PushEvent.RefreshHallLeaderBoardsPage)) : 3 == a.data.card_check ? (HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Hall, event: ReportConfig.hall_evt.kyc_verify_fail }), sys.isObjectValid(a.data.card_check_type) && (this.data.card_check_type = a.data.card_check_type), AppInfo.shared().getIsNewKyc() && this.doGetKycAccount()) : 0 == a.data.card_check && 1 == a.data.has_next_step && PushCenter.shared().pushEvent(PushEvent.UpdateKycStep, { has_next_step: a.data.has_next_step, name: a.data.name, birthday: a.data.birthday, card: a.data.card }), this.setUserRealName(), PushCenter.shared().pushEvent(GameConfig.Update_Kyc, this.data.kyc_check);
                    break;
                case 151:
                    if (sys.isObjectValid(a.data)) {
                        if (sys.isObjectValid(a.data.player_club_info) && (User.shared().data.player_club = a.data.player_club_info), sys.isObjectValid(a.data.upgrade)) {
                            if (this.clubUpgradeMsg = a.data.upgrade, ToolUtils.judgeIfInHall()) {
                                if (2 == User.shared().popActState) {
                                    let e = { exe: {} };
                                    e.type = PushEvent.Custom_TO_MemberShipUpgrade;
                                    e.exe.ext = this.clubUpgradeMsg;
                                    Utils.shared().doJumpLogic(PushEvent.Custom_TO_MemberShipUpgrade, e);
                                }
                                else {
                                    1 == User.shared().popActState && User.shared().pushActivityToPopList();
                                }
                            }
                            else {
                                let e = { exe: {} };
                                e.type = PushEvent.Custom_TO_MemberShipUpgrade;
                                e.exe.ext = this.clubUpgradeMsg;
                                Utils.shared().doJumpLogic(PushEvent.Custom_TO_MemberShipUpgrade, e);
                            }
                        }
                        PushCenter.shared().pushEvent(GameConfig.Hall_MemberShip_info, this.data.player_club);
                    }
                    break;
                case 34:
                    this.canFirstPay = 0;
                    let r = a.data.list;
                    r && r.length > 0 && this.showChargeReward(r, (e => {
                        PushCenter.shared().pushEvent(PushEvent.Update_NextPopActivity);
                    })), PushCenter.shared().pushEvent(PushEvent.PurchasedFirstRecharge);
                    break;
                case 35:
                    PushCenter.shared().pushEvent(PushEvent.SessionPackageLimit);
                    break;
                case 36:
                    let h = ToolUtils.judgeIfInScene(BundleNameDefined.rummy_scence) ? 1 : 0;
                    this.requestGetCbTimeout(h);
                    break;
                case 37:
                    this.has_referral = 1;
                    break;
                case 51:
                    PushCenter.shared().pushEvent(PushEvent.WithdrawFail, a.data);
                    break;
                case 54:
                    this.requestStoreList();
                    break;
                case 56:
                    undefined !== a.data.can_fst_pay && (this.canFirstPay = a.data.can_fst_pay), PushCenter.shared().pushEvent(PushEvent.PurchasedFirstRecharge), PushCenter.shared().pushEvent(PushEvent.HallGet), this.checkUpdateActivity(PushEvent.JUMP_TO_SCLB);
                    break;
                case 57:
                    this.getHallInfo();
                    break;
                case 58:
                    undefined !== a.data.tid_key && PushCenter.shared().pushEvent(PushEvent.SwitchTabEvent, a.data);
                    break;
                case 59:
                    let _ = ToolUtils.curVId;
                    null != a.data.vid && (_ = a.data.vid), null != a.data.complete && 1 == a.data.complete ? PushCenter.shared().pushEvent(PushEvent.RoomShowTaskGouAnim, _) : null != a.data.act_id && User.shared().getRoomRoomInfo(_, a.data.act_id);
                    break;
                case 60:
                    User.shared().doGetModuleSwitchInfo(), PushCenter.shared().pushEvent(PushEvent.UpdateActivity);
                    break;
                case 61:
                    User.shared().pan_check = a.data.pan_check, 2 == User.shared().pan_check && (sys.isObjectValid(a.data.name) && (User.shared().pancard_data.name = a.data.name, this.setUserRealName()), sys.isObjectValid(a.data.reward_list) && a.data.reward_list.length > 0 && Utils.shared().showKycVerifySucTip(a.data.reward_list, i18nMgr.shared().getValueByKey("kyc.PAN_Verify_Suc")), this.checkUpdateActivity(PushEvent.JUMP_TO_KYC_VERIFY_SUC)), 3 == User.shared().pan_check && (sys.isObjectValid(a.data.reason) && (User.shared().pancard_data.reason = a.data.reason), sys.isObjectValid(a.data.fast_reason) && (User.shared().pancard_data.fast_reason = a.data.fast_reason)), sys.isObjectValid(a.data.can_update_name) && (User.shared().pancard_data.can_update_name = a.data.can_update_name), PushCenter.shared().pushEvent(PushEvent.Update_Pan), PushCenter.shared().pushEvent(PushEvent.Update_PanInfo), PushCenter.shared().pushEvent(PushEvent.Update_PanResult);
                    break;
                case 62:
                    User.shared().pan_open = a.data.pan_open, PushCenter.shared().pushEvent(PushEvent.Update_Pan);
                    break;
                case 63:
                    a.data.list && a.data.list.length > 0 && this.showChargeReward(a.data.list, (e => {
                        PushCenter.shared().pushEvent(PushEvent.Update_NextPopActivity);
                    }), ToolUtils.format(i18nMgr.shared().getValueByKey("relief_package.relief_tips"), a.data.cash), 5);
                    break;
                case 64:
                    this.handler_laba_server_force_offline(a);
                    break;
                case 65:
                    undefined !== a.data.show && (this.canReliefPay = a.data.show), this.getHallInfo(), PushCenter.shared().pushEvent(PushEvent.PurchasedFirstRecharge), this.checkUpdateActivity(PushEvent.JUMP_TO_SCLB);
                    break;
                case 66:
                    {
                        let t = ToolUtils.curVId;
                        if (null != a.data.vid && (t = a.data.vid), null != a.data.complete && 1 == a.data.complete ? PushCenter.shared().pushEvent(PushEvent.RoomShowDailyTaskGouAnim, t) : null != a.data.act_id && User.shared().getRoomRoomInfo(t, a.data.act_id), null != a.data.pop && 1 == a.data.pop) {
                            let e = {};
                            e.vid = t;
                            e.complete = ToolUtils.isSafeNumber(a.data.complete);
                            PushCenter.shared().pushEvent(PushEvent.RoomShowDailyTaskListBubble, e);
                        }
                    }
                    break;
                case 67:
                    PushCenter.shared().pushEvent(PushEvent.UpdateLotteryAct), sys.isObjectValid(a.data.msg) && Utils.shared().showToast(a.data.msg, 2, 0, ToolUtils.getIsNormalDirection()), this.checkUpdateActivity(PushEvent.JUMP_TO_LOTTERYACT);
                    break;
                case 68:
                    director.getScene().name == BundleNameDefined.hall_scene && (this.getHallInfo(), PushCenter.shared().pushEvent(PushEvent.UpdateActivity));
                    break;
                case 106:
                    if (PushCenter.shared().pushEvent(PushEvent.updataWeekMonth), a.data.reward_list && a.data.reward_list.length > 0) {
                        let e = 10;
                        this.showChargeReward(a.data.reward_list, null, a.data.msg, e, a.data.price_tips, a.data.recharge_id);
                    }
                    this.checkUpdateActivity(PushEvent.JUMP_TO_WEEK_MONTH);
                    break;
                case 94:
                    if (PushCenter.shared().pushEvent(PushEvent.updataWeekMonth), a.data.reward && a.data.reward.length > 0) {
                        let e = { list: [] };
                        for (let t = 0, s = a.data.reward.length; t < s; t++) {
                            let s = a.data.reward[t], i = [];
                            i.num = s.amt;
                            i.type = s.type;
                            i.php_data = s;
                            i.name = Utils.shared().getIconNameByType(s.type, s.desc || "");
                            e.list[t] = i;
                        }
                        e.card_content = a.data.card_content;
                        e.card_title = a.data.card_title;
                        sys.isObjectValid(a.data.msg) && (e.msg = a.data.msg);
                        sys.isObjectValid(a.data.price_tips) && a.data.price_tips.length > 0 && (e.priceTips = a.data.price_tips);
                        sys.isObjectValid(a.data.recharge_id) && a.data.recharge_id.length > 0 && (e.rechargeId = a.data.recharge_id);
                        Utils.shared().showRewardTips(e, null, 6, "reward_tips.okey");
                    }
                    break;
                case 72:
                    if (sys.isObjectValid(a.data.full_status) && (User.shared().act_68_full_status = a.data.full_status), sys.isObjectValid(a.data.act_68_open) && (User.shared().act_68_open = a.data.act_68_open, 0 == User.shared().act_68_open && PushCenter.shared().pushEvent(PushEvent.Update_Gullak_State)), a.data.reward && a.data.reward.length > 0) {
                        if (director.getScene().name == BundleNameDefined.hall_scene) {
                            let e = director.getScene().getChildByName("Canvas").getChildByName("gullak");
                            if (ToolUtils.isObjValid(e)) {
                                let t = e.getComponent("PiggyBank");
                                t && t.isValid && t.showChargeReward(a.data);
                            }
                        }
                        else {
                            director.getScene().name != BundleNameDefined.switch_scence && (PushCenter.shared().pushEvent(PushEvent.Update_Gullak_RewardInGame, a.data), director.getScene().name != BundleNameDefined.fruitmachine_scene && PushCenter.shared().pushEvent(PushEvent.Update_Gullak_State));
                        }
                    }
                    this.checkUpdateActivity(PushEvent.JUMP_TO_Gullak);
                    break;
                case 73: break;
                case 74:
                    sys.isObjectValid(a.data.show_game_introduce) && (this.points_easy_cfg.show_game_introduce = a.data.show_game_introduce, PushCenter.shared().pushEvent(PushEvent.EasyGameIntroduce));
                    break;
                case 75:
                    sys.isObjectValid(a.data.show_new_tag) && (this.points_easy_cfg.show_new_tag = a.data.show_new_tag, PushCenter.shared().pushEvent(PushEvent.EasyGameShowNewFlag));
                    break;
                case 76:
                case 135:
                    if (135 == Number(t) && PushCenter.shared().pushEvent(PushEvent.GetLeafUpdateTreasure), a.data.reward_list && a.data.reward_list.length > 0) {
                        let t = { list: [] };
                        sys.isObjectValid(a.data.msg) && (t.msg = a.data.msg);
                        for (let e = 0, s = a.data.reward_list.length; e < s; e++) {
                            let s = a.data.reward_list[e], i = [];
                            i.num = s.amt;
                            i.type = s.type;
                            i.php_data = s;
                            i.name = Utils.shared().getIconNameByType(s.type, s.desc || "");
                            t.list[e] = i;
                        }
                        sys.isObjectValid(a.data.msg) && (t.msg = a.data.msg);
                        sys.isObjectValid(a.data.price_tips) && a.data.price_tips.length > 0 && (t.priceTips = a.data.price_tips);
                        sys.isObjectValid(a.data.recharge_id) && a.data.recharge_id.length > 0 && (t.rechargeId = a.data.recharge_id);
                        director.getScene().name == BundleNameDefined.hall_scene ? (Utils.shared().showRewardTips(t, (t => {
                            if (sys.isObjectValid(a.data.act_id) && a.data.act_id == PushEvent.JUMP_TO_Adventrue) {
                                let a = director.getScene().getChildByName("Canvas").getChildByName("advancedGift");
                                if (ToolUtils.isObjValid(a)) {
                                    let t = a.getComponent("AdvancedGift");
                                    t && t.isValid && User.shared().requestActAdvancedPackPage((e => {
                                        director.getScene().name == BundleNameDefined.hall_scene && t && t.isValid && (sys.isObjectValid(e) && (e.ui_type = 1), t.refreshUI(e));
                                    }));
                                }
                            }
                        }), 10, "reward_tips.okey"), PushCenter.shared().pushEvent(PushEvent.RefreshWallet)) : this.commonRewardMsgs.push(t);
                    }
                    break;
                case 77:
                    PushCenter.shared().pushEvent(PushEvent.BackHallShowAppReview);
                    break;
                case 78:
                    let n = this.getSuperVipUpgradeMsg(a.data);
                    sys.isObjectValid(a.data.vip_info) && (User.shared().data.vip_info = a.data.vip_info, PushCenter.shared().pushEvent(PushEvent.RefreshSuperVipInfo)), PushCenter.shared().pushEvent(PushEvent.RefreshSuperVipHome);
                    let c = director.getScene().getChildByName("Canvas").getChildByName("Store");
                    this.superVipUpMsg = n;
                    let g = director.getScene().getChildByName("Canvas").getChildByName("superVip");
                    ToolUtils.isObjValid(g) || this.requestSuperVipHomePageData(), n.list = [], sys.isObjectValid(a.data.msg) && (n.msg = a.data.msg);
                    for (let e = 0, t = a.data.reward_list.length; e < t; e++) {
                        let t = a.data.reward_list[e], s = [];
                        s.num = t.amt;
                        s.type = t.type;
                        s.name = Utils.shared().getIconNameByType(t.type, t.desc || "");
                        s.php_data = t;
                        n.list[e] = s;
                    }
                    let y = false, f = [];
                    f.type = CUSTOM_REWARD_ENUM.VIP_LEVEL, f.num = n.new_show_level || 0;
                    for (let e = 0; e < n.list.length; e++) {
                        n.list[e].type == f.type && (y = true);
                    }
                    y || n.list.unshift(f), director.getScene().name == BundleNameDefined.hall_scene && ToolUtils.isObjValid(Utils.shared().hall_rootNode) && Utils.shared().hall_rootNode.active && !ToolUtils.isObjValid(c) && Utils.shared().showRewardTips(n, null, 1, "reward_tips.okey", "", (() => {
                        User.shared().superVipUpMsg = null;
                        User.shared().requestSuperVipConfirmUpgradePop();
                    }));
                    break;
                case 79:
                    sys.isObjectValid(a.data.vip_info) && (User.shared().data.vip_info = a.data.vip_info, PushCenter.shared().pushEvent(PushEvent.RefreshSuperVipInfo), PushCenter.shared().pushEvent(PushEvent.RefreshSuperVipHome));
                    break;
                case 80:
                    PushCenter.shared().pushEvent(PushEvent.RefreshSuperVipHome);
                    break;
                case 81:
                    PushCenter.shared().pushEvent(PushEvent.RefreshHappyRewards);
                    break;
                case 82:
                    if (User.shared().mall_lottery && 1 == User.shared().soreTb.lottery_show) {
                        let e = a.data.msg_0;
                        1 == i18nMgr.shared().language ? e = a.data.msg_1 : 2 == i18nMgr.shared().language ? e = a.data.msg_2 : 3 == i18nMgr.shared().language && (e = a.data.msg_3);
                        ToolUtils.LabaTable.push(e);
                        ToolUtils.LabaCount = ToolUtils.LabaCount + 1;
                    }
                    PushCenter.shared().pushEvent(PushEvent.RefreshReceipt);
                    break;
                case 83:
                    this.requestStoreList(), PushCenter.shared().pushEvent(PushEvent.RefreshReceipt);
                    break;
                case 84:
                    PushCenter.shared().pushEvent(PushEvent.RefreshRoomActRank), sys.isObjectValid(a.data.progress_list) && Array.isArray(a.data.progress_list) && a.data.progress_list.length > 0 && PushCenter.shared().pushEvent(PushEvent.RefreshRoomActRankProgress, a.data.progress_list);
                    break;
                case 85:
                    this.act_76_show = 2, PushCenter.shared().pushEvent(PushEvent.RefreshLeaderBoardsSwitch);
                    break;
                case 86:
                    sys.isObjectValid(a.data.act_76_recommend_list) && Array.isArray(a.data.act_76_recommend_list) && (this.act_76_recommend_list = a.data.act_76_recommend_list, PushCenter.shared().pushEvent(PushEvent.RefreshHallChooseGameRankStar), PushCenter.shared().pushEvent(PushEvent.RefreshHallLeaderBoardsPage));
                    break;
                case 87: break;
                case 88:
                    sys.isObjectValid(a.data.show_new_tag) && (this.points_multiple_cfg.show_new_tag = a.data.show_new_tag, PushCenter.shared().pushEvent(PushEvent.MultipleGameShowNewFlag));
                    break;
                case 89:
                    sys.isObjectValid(a.data.show_game_introduce) && (this.points_multiple_cfg.show_game_introduce = a.data.show_game_introduce, PushCenter.shared().pushEvent(PushEvent.MultipleGameIntroduce)), sys.isObjectValid(a.data.initial_drop_points) && (this.points_multiple_cfg.initial_drop_points = a.data.initial_drop_points), sys.isObjectValid(a.data.middle_drop_points) && (this.points_multiple_cfg.middle_drop_points = a.data.middle_drop_points), sys.isObjectValid(a.data.max_lose) && (this.points_multiple_cfg.max_lose = a.data.max_lose);
                    break;
                case 92:
                    PushCenter.shared().pushEvent(PushEvent.ReceiveTreaHuntMarquee, a.data);
                    break;
                case 93:
                    a.data.status && (this.data.show_resubmit = a.data.status), a.data.status && (this.data.resubmit_status = a.data.status, this.kyc_resubmit_data.status = a.data.status), a.data.aad_card && (this.kyc_resubmit_data.aad_card = a.data.aad_card), a.data.pan_card && (this.kyc_resubmit_data.pan_card = a.data.pan_card), PushCenter.shared().pushEvent(PushEvent.UpdateKycResubmit), PushCenter.shared().pushEvent(PushEvent.RefreshKycList), this.doGetKycVerifyList(), 2 == a.data.status && this.getBannerData();
                    break;
                case 95:
                    PushCenter.shared().pushEvent(PushEvent.UpdateBankCardVerify, a.data), sys.isObjectValid(a.data.match_error_pop) && a.data.match_error_pop;
                    break;
                case 96:
                    sys.isObjectValid(a.data.show_game_introduce) && (this.points_bump_cfg.show_game_introduce = a.data.show_game_introduce, PushCenter.shared().pushEvent(PushEvent.MultipleGameIntroduce));
                    break;
                case 97:
                    sys.isObjectValid(a.data.show_new_tag) && (this.points_bump_cfg.show_new_tag = a.data.show_new_tag, PushCenter.shared().pushEvent(PushEvent.MultipleGameShowNewFlag));
                    break;
                case 98:
                    sys.isObjectValid(a.status) && sys.isObjectValid(a.reason) && a.reason.length > 0 && Utils.shared().showToast(a.reason, 3);
                    break;
                case 101:
                    this.has_invite_reward = 1, PushCenter.shared().pushEvent(PushEvent.ShowInviteRedBag);
                    break;
                case 100:
                    if (sys.isObjectValid(a.data.prop_type) && sys.isObjectValid(a.data.prop)) {
                        let t = Number(a.data.prop_type);
                        1 == t ? (User.shared().data.avatar = "head_" + a.data.prop + ".png", PushCenter.shared().pushEvent(GameConfig.Change_Head)) : 2 == t && (User.shared().avatar_frame_id = Number(a.data.prop), PushCenter.shared().pushEvent(GameConfig.Hall_MemberShip_info));
                        PushCenter.shared().pushEvent(PushEvent.RefreshGameDisplayPage);
                        ToolUtils.judgeIfInRummy() && PushCenter.shared().pushEvent(PushEvent.NotifyGameDisplayModify);
                    }
                    break;
                case 102:
                    sys.isObjectValid(a.data.amount) && (PushCenter.shared().pushEvent(GameConfig.Update_ExeStore), PushCenter.shared().pushEvent(PushEvent.CloseChipsFirstRecharge), User.shared().getHallInfo());
                    break;
                case 104:
                case 105:
                    PushCenter.shared().pushEvent(PushEvent.ReceiveTreaHuntMarquee, a.data);
                    break;
                case 107:
                    PushCenter.shared().pushEvent(PushEvent.ShowGameOverNovicesBanner, a.data), PushCenter.shared().pushEvent(PushEvent.RefreshTaskList);
                    break;
                case 108:
                    PushCenter.shared().pushEvent(PushEvent.RefreshTaskList);
                    break;
                case 109:
                    PushCenter.shared().pushEvent(PushEvent.UpdateRoomTaskProgess, a.data), PushCenter.shared().pushEvent(PushEvent.RefreshTaskList);
                    break;
                case 110:
                    sys.isObjectValid(a.data.collect_list) && Array.isArray(a.data.collect_list) ? User.shared().newKycData.collect_list = a.data.collect_list : User.shared().newKycData.collect_list = [], sys.isObjectValid(a.data.me_card_check) && (User.shared().newKycData.me_card_check = ToolUtils.isSafeNumber(a.data.me_card_check)), sys.isObjectValid(a.data.kyc_otp_check) && (this.data.kyc_otp_check = a.data.kyc_otp_check), sys.isObjectValid(a.data.kyc_digilocker_check) && (this.data.kyc_digilocker_check = a.data.kyc_digilocker_check), PushCenter.shared().pushEvent(GameConfig.Update_Kyc);
                    break;
                case 120:
                    undefined !== a.data.can_twenty_pay && (this.canTwentyFour = a.data.can_twenty_pay), PushCenter.shared().pushEvent(PushEvent.PurchasedFirstRecharge), PushCenter.shared().pushEvent(PushEvent.HallGet), this.checkUpdateActivity(PushEvent.JUMP_TO_TwentyFourRecharge);
                    break;
                case 121:
                    if (!sys.isObjectValid(a.data.game_lock) || !a.data.game_lock || Array.isArray(a.data.game_lock)) {
                        return;
                    }
                    User.shared().game_lock_data = a.data.game_lock || null, PushCenter.shared().pushEvent(PushEvent.UpdateRummyUnlockData);
                    break;
                case 122:
                    PushCenter.shared().pushEvent(PushEvent.RefreshRechargeRewardList);
                    break;
                case 123:
                    if (sys.isObjectValid(a.data.kp_verify_type)) {
                        if (3 == a.data.kp_verify_type) {
                            PushCenter.shared().pushEvent(PushEvent.Close_PanView);
                            PushCenter.shared().pushEvent(PushEvent.Close_FastOtpView);
                            PushCenter.shared().pushEvent(PushEvent.Update_PanResult);
                            let e = i18nMgr.shared().getValueByKey("deposit.kyc_name_null");
                            sys.isObjectValid(a.data.kp_verify_reason) && a.data.kp_verify_reason.length > 0 && (e = a.data.kp_verify_reason);
                            let t = { bLandscape: ToolUtils.getIsNormalDirection(), bWithCancel: true, strContent: e, strTitle: i18nMgr.shared().getValueByKey("email.tips"), sureKey: "deposit.verify_kyc", dialogType: 0 };
                            Utils.shared().showCommonAlert(t, (e => {
                                if (1 == e) {
                                    let e = { isRefine: 1 };
                                    Utils.shared().showOtpKyc(e);
                                }
                            }), false);
                            PushCenter.shared().pushEvent(PushEvent.Update_PanResult);
                        }
                        else if (4 == a.data.kp_verify_type) {
                            PushCenter.shared().pushEvent(PushEvent.Close_PanView);
                            PushCenter.shared().pushEvent(PushEvent.Close_FastOtpView);
                            PushCenter.shared().pushEvent(PushEvent.Update_PanResult);
                            let e = i18nMgr.shared().getValueByKey("deposit.kyc_name_null");
                            sys.isObjectValid(a.data.kp_verify_reason) && a.data.kp_verify_reason.length > 0 && (e = a.data.kp_verify_reason);
                            let t = { bLandscape: ToolUtils.getIsNormalDirection(), bWithCancel: true, strContent: e, strTitle: i18nMgr.shared().getValueByKey("email.tips"), sureKey: "deposit.btn_revise_kyc2", cancelKey: "deposit.btn_revise_pan2", dialogType: 0 };
                            PushCenter.shared().pushEvent(PushEvent.Update_PanResult);
                            Utils.shared().showCommonAlert(t, (e => {
                                if (1 == e) {
                                    let e = { is_refine: 1 };
                                    Utils.shared().showOtpKyc(e);
                                }
                            }), false);
                        }
                        else {
                            7 == a.data.kp_verify_type && PushCenter.shared().pushEvent(PushEvent.Update_PanResult);
                        }
                    }
                    break;
                case 124:
                    sys.isObjectValid(a.data.c_type) && (1 == a.data.c_type ? PushCenter.shared().pushEvent(PushEvent.RefreshOtpKycReason, a.data.c_reason) : 2 == a.data.c_type && PushCenter.shared().pushEvent(PushEvent.RefreshPanReason, a.data.c_reason));
                    break;
                case 125:
                    PushCenter.shared().pushEvent(PushEvent.RefreshHappyFlop);
                    break;
                case 126:
                    PushCenter.shared().pushEvent(PushEvent.RefreshCouponRecharge);
                    break;
                case 127:
                    sys.isObjectValid(a.data.act_id) && (PushCenter.shared().pushEvent(PushEvent.HallGet), a.data.act_id == PushEvent.JUMP_TO_TwentyFourRecharge ? (this.canTwentyFour = a.data.act_status, this.checkUpdateActivity(PushEvent.JUMP_TO_TwentyFourRecharge), 1 != this.canTwentyFour && PushCenter.shared().pushEvent(PushEvent.CloseTwentyHourRecharge)) : a.data.act_id == PushEvent.JUMP_TO_RebateRecharge ? (this.canRebate = a.data.act_status, this.checkUpdateActivity(PushEvent.JUMP_TO_RebateRecharge), 1 != this.canRebate && (PushCenter.shared().pushEvent(PushEvent.PurchasedFirstRecharge), PushCenter.shared().pushEvent(PushEvent.CloseRebateRecharge))) : a.data.act_id == PushEvent.JUMP_TO_BuyOneGetThree ? sys.isObjectValid(a.data.ext) && a.data.ext && (User.shared().payOneForThreeData = a.data.ext, PushCenter.shared().pushEvent(PushEvent.UpdateBuyOneGetThree, User.shared().payOneForThreeData)) : a.data.act_id == PushEvent.JUMP_TO_RestartGift ? sys.isObjectValid(a.data.ext) && (this.restartGift_pagedata = a.data.ext, PushCenter.shared().pushEvent(PushEvent.RefreshRestartGift, a.data.ext)) : a.data.act_id == PushEvent.JUMP_TO_DailyFireSale ? sys.isObjectValid(a.data.ext) && (this.dailyFireSaleData = a.data.ext, PushCenter.shared().pushEvent(PushEvent.RefreshDailyFireSale, a.data.ext)) : a.data.act_id == PushEvent.JUMP_TO_ConsecutiveGift ? sys.isObjectValid(a.data.ext) && (this.consecutiveGiftData = a.data.ext, PushCenter.shared().pushEvent(PushEvent.UpdateConsecutiveGift, a.data.ext)) : a.data.act_id == PushEvent.JUMP_TO_TreasureDraw && sys.isObjectValid(a.data.ext) && (this.treasuredrawData = a.data.ext, PushCenter.shared().pushEvent(PushEvent.UpdateTreasureDraw, a.data.ext)));
                    break;
                case 128:
                    PushCenter.shared().pushEvent(PushEvent.UpdateRoomFlopCrashTaskProgess, a.data.task_data);
                    break;
                case 129:
                    User.shared().requestBagPackPage();
                    break;
                case 130:
                    sys.isObjectValid(a.data.kyc_otp_check) && (this.data.kyc_otp_check = a.data.kyc_otp_check), sys.isObjectValid(a.data.kyc_digilocker_check) && (this.data.kyc_digilocker_check = a.data.kyc_digilocker_check);
                    break;
                case 131:
                    sys.isObjectValid(a.data.act_131_dot_ids) && Array.isArray(a.data.act_131_dot_ids) ? SportCricket_Manager.shared().updateMatchLineUpMap(a.data.act_131_dot_ids) : SportCricket_Manager.shared().updateMatchLineUpMap([]), PushCenter.shared().pushEvent(PushEvent.NoticePlayerNotInLineUp);
                    break;
                case 132:
                    ToolUtils.vip_reward_dot = 1, PushCenter.shared().pushEvent(PushEvent.RefreshSuperVipInfo);
                    break;
                case 136:
                    PushCenter.shared().pushEvent(PushEvent.CloseWebView), sys.isObjectValid(a.data.status) && sys.isObjectValid(a.data.reason) && a.data.reason.length > 0 && Utils.shared().showToast(a.data.reason, 3);
                    break;
                case 141:
                    sys.isObjectValid(a.data.full_status) && (User.shared().act_68_full_status = a.data.full_status), sys.isObjectValid(a.data.act_68_open) && (User.shared().act_68_open = a.data.act_68_open), PushCenter.shared().pushEvent(PushEvent.Update_Gullak_State);
                    break;
                case 180:
                    PushCenter.shared().pushEvent(PushEvent.RefreshYesGameSignPer, a.data);
                    break;
                case 181:
                    sys.isObjectValid(a.data.tg_name) && (User.shared().data.tg_name = a.data.tg_name, PushCenter.shared().pushEvent(PushEvent.Telegram_Robot_Update), PushCenter.shared().pushEvent(PushEvent.CloseWebView)), sys.isObjectValid(a.data.tg_auth_url) && a.data.tg_auth_url.length > 0 && (User.shared().data.tg_auth_url = a.data.tg_auth_url);
                    break;
                case 182:
                    sys.isObjectValid(a.data.is_new_rank) && (User.shared().data.is_new_rank = a.data.is_new_rank);
                    break;
                case 183:
                    sys.isObjectValid(a.data.info) && this.handler_laba_update_user_return(a.data.info), this.send_refresh_laba();
                    break;
                case 184:
                case 185:
                case 186:
                case 187:
                case 188:
                case 189:
                case 190: if (184 == Number(t) ? (User.shared().getBannerData(), User.shared().getHallInfo(), PushCenter.shared().pushEvent(PushEvent.CloseFirstRecharge)) : 185 == Number(t) ? sys.isObjectValid(a.data.act_status) && (this.canTwentyFour = a.data.act_status, this.checkUpdateActivity(PushEvent.JUMP_TO_TwentyFourRecharge), 1 != this.canTwentyFour && PushCenter.shared().pushEvent(PushEvent.CloseTwentyHourRecharge)) : 187 == Number(t) ? sys.isObjectValid(a.data.ext) && a.data.ext && (User.shared().payOneForThreeData = a.data.ext, PushCenter.shared().pushEvent(PushEvent.UpdateBuyOneGetThree, User.shared().payOneForThreeData)) : 188 == Number(t) ? sys.isObjectValid(a.data.ext) && (this.restartGift_pagedata = a.data.ext, PushCenter.shared().pushEvent(PushEvent.RefreshRestartGift, a.data.ext)) : 189 == Number(t) && sys.isObjectValid(a.data.ext) && (this.consecutiveGiftData = a.data.ext, PushCenter.shared().pushEvent(PushEvent.UpdateConsecutiveGift, a.data.ext)), a.data.reward_list && a.data.reward_list.length > 0) {
                    let e = 10;
                    this.showChargeReward(a.data.reward_list, (e => {
                    }), a.data.msg, e, a.data.price_tips, a.data.recharge_id);
                }
            }
        }
    }
    checkUpdateActivity(a) {
        if (User.shared().actList.length > 0) {
            for (let t = 0, i = User.shared().actList.length; t < i; t++) {
                if (sys.isObjectValid(User.shared().actList[t].jump_info) && User.shared().actList[t].jump_info.type == a) {
                    PushCenter.shared().pushEvent(PushEvent.UpdateActivity);
                    break;
                }
            }
        }
    }
    showChargeReward(e, a = null, t = null, i = 1, r = "", d = "") {
        if (Array.isArray(e) && e.length > 0) {
            let h = { list: [] };
            for (let a = 0, t = e.length; a < t; a++) {
                let t = e[a], i = [];
                sys.isObjectValid(t.amt) ? i.num = t.amt : sys.isObjectValid(t.amount) ? i.num = t.amount : sys.isObjectValid(t.num) && (i.num = t.num);
                i.type = t.type;
                i.php_data = t;
                i.name = Utils.shared().getIconNameByType(t.type, t.desc || "");
                h.list[a] = i;
            }
            sys.isObjectValid(t) && (h.msg = t);
            sys.isObjectValid(r) && r.length > 0 && (h.priceTips = r);
            sys.isObjectValid(d) && d.length > 0 && (h.rechargeId = d);
            Utils.shared().showRewardTips(h, a, i, "reward_tips.okey");
        }
    }
    initLoginMsg(a) {
        try {
            let t = {};
            if (t.time = sys.now(), sys.isObjectValid(a.t1) && (t.t1 = a.t1), sys.isObjectValid(a.t2) && (t.t2 = a.t2), sys.isObjectValid(a.t3) && (t.t3 = a.t3), ToolUtils.report_time_param.loginSuccess = t, GameConfig.HTTP_MSG_DEBUG, AppInfo.shared().setFirebaseUserProperty("name", a.data.name + ""), AppInfo.shared().setFirebaseUserProperty("ID", a.data.uid + ""), HttpManager.shared().setUidAndKey(a.data.uid, a.data.skey), this.retention_pop_info = null, sys.isObjectValid(a.data.chips_model) && (GameConfig.CHIPS_MODLE = 1 == ToolUtils.isSafeNumber(a.data.chips_model) ? 1 : 0), -1 != GameConfig.CHIPS_CHANNELS.indexOf(GameConfig.CHANNEL_ID) && -1 != ToolUtils.LAST_CHIPS_MODLE && GameConfig.CHIPS_MODLE != ToolUtils.LAST_CHIPS_MODLE && ToolUtils.saveData("logintype", "-1"), ToolUtils.saveData("LastChipsModel", GameConfig.CHIPS_MODLE), this.data = a.data, ToolUtils.uid = this.data.uid, ToolUtils.skey = this.data.skey, ToolUtils.game_model = this.data.game_model, ToolUtils.saveData("logintype", this.loginType), ToolUtils.saveData("lastLoginUid", "" + this.data.uid), 0 === this.data.logintype) {
                -1 != GameConfig.CHIPS_CHANNELS.indexOf(GameConfig.CHANNEL_ID) && 1 == GameConfig.CHIPS_MODLE ? (this.data.user && ToolUtils.saveData("LoginProxy_user" + GameConfig.CHANNEL_ID + GameConfig.CHIPS_MODLE, ToolUtils.isSafeString(this.data.user)), this.data.password && ToolUtils.saveData("LoginProxy_password" + GameConfig.CHANNEL_ID + GameConfig.CHIPS_MODLE, ToolUtils.isSafeString(this.data.password)), 0 !== GameConfig.HTTP_MSG_DEBUG && TLog.printMsg("____________________LoginProxy_user:", sys.localStorage.getItem("LoginProxy_user" + GameConfig.CHANNEL_ID + GameConfig.CHIPS_MODLE)), 0 !== GameConfig.HTTP_MSG_DEBUG && TLog.printMsg("____________________LoginProxy_password:", sys.localStorage.getItem("LoginProxy_password" + GameConfig.CHANNEL_ID + GameConfig.CHIPS_MODLE))) : (this.data.user && ToolUtils.saveData("LoginProxy_user" + GameConfig.CHANNEL_ID, ToolUtils.isSafeString(this.data.user)), this.data.password && ToolUtils.saveData("LoginProxy_password" + GameConfig.CHANNEL_ID, ToolUtils.isSafeString(this.data.password)), 0 !== GameConfig.HTTP_MSG_DEBUG && TLog.printMsg("____________________LoginProxy_user:", sys.localStorage.getItem("LoginProxy_user" + GameConfig.CHANNEL_ID)), 0 !== GameConfig.HTTP_MSG_DEBUG && TLog.printMsg("____________________LoginProxy_password:", sys.localStorage.getItem("LoginProxy_password" + GameConfig.CHANNEL_ID)));
            }
            else if (3 === this.data.logintype) {
                if (a.data.tel_no && a.data.tel_no.length > 0) {
                    if (1 == a.data.isregister) {
                        HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Login, event: ReportConfig.login_evt.phoneRegisterSuc });
                        AppInfo.shared().logEvent_firebase(ReportConfig.login_evt.phoneRegisterSuc);
                    }
                    else {
                        let a = ReportConfig.login_evt.phoneLoginSuc;
                        2 == User.shared().nAutoLoginType ? a = ReportConfig.login_evt.phoneAutoLoginSucc : 3 == User.shared().nAutoLoginType && (a = ReportConfig.login_evt.codeAutoLoginSucc);
                        HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Login, event: a });
                        AppInfo.shared().logEvent_firebase(ReportConfig.login_evt.phoneLoginSuc);
                    }
                }
                this.data.tel_no && (ToolUtils.saveData("code_phoneno", this.data.tel_no + ""), ToolUtils.saveData(this.data.tel_no + "", "1"));
                this.data.pwdtoken && ToolUtils.saveData("code_pwdno", this.data.pwdtoken + "");
                0 !== GameConfig.HTTP_MSG_DEBUG && TLog.printMsg("____________________code_phoneno:", sys.localStorage.getItem("code_phoneno"));
                0 !== GameConfig.HTTP_MSG_DEBUG && TLog.printMsg("____________________code_pwdno:", sys.localStorage.getItem("code_pwdno"));
            }
            else {
                6 === this.data.logintype && (this.data.account && (ToolUtils.saveData("save_phoneno", this.data.account + ""), ToolUtils.saveData(this.data.account + "", "1")), this.data.password && ToolUtils.saveData("save_pwdno", this.data.password + ""), 0 !== GameConfig.HTTP_MSG_DEBUG && TLog.printMsg("____________________save_phoneno:", sys.localStorage.getItem("save_phoneno")), 0 !== GameConfig.HTTP_MSG_DEBUG && TLog.printMsg("____________________save_pwdno:", sys.localStorage.getItem("save_pwdno")));
            }
            if (sys.isObjectValid(this.data.beginner_guide) ? sys.isObjectValid(this.data.beginner_guide.practice_status) || (this.data.beginner_guide.practice_status = 1) : (this.data.beginner_guide = {}, this.data.beginner_guide.practice_status = 1), sys.isObjectValid(a.data.kyc_img_url) && (URLConfig.kyc_img_url = a.data.kyc_img_url), sys.isObjectValid(a.data.forbidden_province) && (CommDefine.forbidden_province = a.data.forbidden_province), sys.isObjectValid(a.data.poplist) && (1 == GameConfig.CHIPS_MODLE ? this.poplist = [] : (this.poplist = a.data.poplist, this.preloadPopListBundle(false))), 0 == GameConfig.CHIPS_MODLE && sys.isObjectValid(a.data.banner) ? this.data.bannerlist = a.data.banner : this.data.bannerlist = [], this.small_game = [], sys.isObjectValid(a.data.small_game) && (this.small_game = a.data.small_game), sys.isObjectValid(a.data.act_68_open) && (this.act_68_open = a.data.act_68_open), sys.isObjectValid(a.data.act_68_full_status) && (this.act_68_full_status = a.data.act_68_full_status), ToolUtils.saveData(CommDefine.FirstLogin, "1"), ToolUtils.saveData(CommDefine.LoginTime, "" + sys.now()), sys.isObjectValid(a.data.cdkey_open) && (User.shared().temp_pingbi.redeemcode = 1 == a.data.cdkey_open ? 0 : 1), sys.isObjectValid(a.data.points_easy_cfg)) {
                let e = a.data.points_easy_cfg;
                sys.isObjectValid(e.tips_times) && (this.points_easy_cfg.tips_times = e.tips_times);
                sys.isObjectValid(e.show_game_introduce) && (this.points_easy_cfg.show_game_introduce = e.show_game_introduce);
                sys.isObjectValid(e.show_new_tag) && (this.points_easy_cfg.show_new_tag = e.show_new_tag);
            }
            if (sys.isObjectValid(a.data.multiple_cfg)) {
                let e = a.data.multiple_cfg;
                sys.isObjectValid(e.tips_times) && (this.points_multiple_cfg.tips_times = e.tips_times);
                sys.isObjectValid(e.show_game_introduce) && (this.points_multiple_cfg.show_game_introduce = e.show_game_introduce);
                sys.isObjectValid(e.show_new_tag) && (this.points_multiple_cfg.show_new_tag = e.show_new_tag);
                sys.isObjectValid(e.initial_drop_points) && (this.points_multiple_cfg.initial_drop_points = e.initial_drop_points);
                sys.isObjectValid(e.middle_drop_points) && (this.points_multiple_cfg.middle_drop_points = e.middle_drop_points);
                sys.isObjectValid(e.max_lose) && (this.points_multiple_cfg.max_lose = e.max_lose);
            }
            if (sys.isObjectValid(a.data.points_bump_cfg)) {
                let e = a.data.points_bump_cfg;
                sys.isObjectValid(e.tips_times) && (this.points_bump_cfg.tips_times = e.tips_times);
                sys.isObjectValid(e.show_game_introduce) && (this.points_bump_cfg.show_game_introduce = e.show_game_introduce);
                sys.isObjectValid(e.show_new_tag) && (this.points_bump_cfg.show_new_tag = e.show_new_tag);
            }
            if (sys.isObjectValid(a.data.points_double_cfg)) {
                let e = a.data.points_double_cfg;
                sys.isObjectValid(e.tips_times) && (this.points_double_cfg.tips_times = e.tips_times);
                sys.isObjectValid(e.show_game_introduce) && (this.points_double_cfg.show_game_introduce = e.show_game_introduce);
                sys.isObjectValid(e.show_new_tag) && (this.points_double_cfg.show_new_tag = e.show_new_tag);
            }
            if (sys.isObjectValid(a.data.first_pop_page) && sys.isObjectValid(a.data.first_pop_page.data)) {
                switch (Number(a.data.first_pop_page.act_id)) {
                    case PushEvent.JUMP_TO_WEEK_MONTH:
                        this.weekmonthData = a.data.first_pop_page.data, ToolUtils.saveData("weekmonth_data" + String(User.shared().data.uid), ToolUtils.toJsonString(this.weekmonthData));
                        break;
                    case PushEvent.JUMP_TO_Gullak:
                        this.gullak_data = a.data.first_pop_page.data;
                        break;
                    case PushEvent.JUMP_TO_SCLB:
                        this.firstrechargeData = a.data.first_pop_page.data;
                        break;
                    case PushEvent.JUMP_TO_TwentyFourRecharge:
                        this.twentyfourrechargeData = a.data.first_pop_page.data;
                        break;
                    case PushEvent.JUMP_TO_RebateRecharge:
                        this.rebaterechargeData = a.data.first_pop_page.data;
                        break;
                    case PushEvent.JUMP_TO_BuyOneGetThree:
                        this.payOneForThreeData = a.data.first_pop_page.data;
                        break;
                    case PushEvent.JUMP_TO_ConsecutiveGift:
                        this.consecutiveGiftData = a.data.first_pop_page.data;
                        break;
                    case PushEvent.JUMP_TO_CustomSelGift:
                        this.customSelGiftData = a.data.first_pop_page.data;
                        break;
                    case PushEvent.JUMP_TO_TreasureDraw:
                        this.treasuredrawData = a.data.first_pop_page.data;
                        break;
                    case PushEvent.JUMP_TO_Adventrue:
                        this.adventrueData = a.data.first_pop_page.data;
                        break;
                    case PushEvent.JUMP_TO_LeaderBoards: this.hall_rank_data = a.data.first_pop_page.data;
                }
            }
            if (this.delayPayMsg = [], this.delayPayIndex = 0, this.commonRewardMsgs = [], this.rewardIndex = 0, this.setUserDataByResponse(), this.is_new_login = 1, this.startLabaTcp(), this.act_76_show = 0, sys.isObjectValid(a.data.act_76_show) && (this.act_76_show = a.data.act_76_show), ToolUtils.has_offline = false, this.fromGame = 0, this.requestGetLocationStatus(), this.walletResult = null, this.clubUserInfo = null, this.shareMainInfo = null, this.checkLocalPracticeRecomendRoom(), this.checkRecommendRoom(), this.getNativeAdjustId(), ToolUtils._bNeedReportToken = false, AppInfo.shared().getFireBaseToken(true), this.superVipPageData = null, this.superVipUpMsg = null, sys.isObjectValid(a.data.vip_pop_info) && (this.superVipUpMsg = this.getSuperVipUpgradeMsg(a.data.vip_pop_info)), this.checkPreGetActInfo(false), this._preload_act_list = [], sys.isObjectValid(a.data) && Array.isArray(a.data.prep_act_list)) {
                for (let e, t = 0, s = a.data.prep_act_list.length; t < s; t++) {
                    e = a.data.prep_act_list[t];
                    this._preload_act_list[Number(e.act_id)] = e;
                }
            }
            this.hall_box_active = false;
            this.hall_box_click = false;
            this.act_76_recommend_list = [];
            sys.isObjectValid(a.data.act_76_recommend_list) && Array.isArray(a.data.act_76_recommend_list) && (this.act_76_recommend_list = a.data.act_76_recommend_list);
            sys.isObjectValid(a.data.has_invite_reward) && (this.has_invite_reward = Number(a.data.has_invite_reward));
            this.act_90_recommend_list = [];
            sys.isObjectValid(a.data.act_90_recommend_list) && Array.isArray(a.data.act_90_recommend_list) && (this.act_90_recommend_list = a.data.act_90_recommend_list);
            this.act_116_not_recommend_list = [];
            sys.isObjectValid(a.data.act_116_not_recommend_list) && Array.isArray(a.data.act_116_not_recommend_list) && (this.act_116_not_recommend_list = a.data.act_116_not_recommend_list);
            this.act_116_not_recommend_show = 0;
            sys.isObjectValid(a.data.act_116_not_recommend_show) && (this.act_116_not_recommend_show = a.data.act_116_not_recommend_show);
            this.act_97_recommend_list = [];
            sys.isObjectValid(a.data.act_97_recommend_list) && Array.isArray(a.data.act_97_recommend_list) && (this.act_97_recommend_list = a.data.act_97_recommend_list);
            this.act_96_unrecommend_list = [];
            sys.isObjectValid(a.data.act_96_unrecommend_list) && Array.isArray(a.data.act_96_unrecommend_list) && (this.act_96_unrecommend_list = a.data.act_96_unrecommend_list);
            this.act_96_recommend_list = [];
            sys.isObjectValid(a.data.act_96_recommend_list) && Array.isArray(a.data.act_96_recommend_list) && (this.act_96_recommend_list = a.data.act_96_recommend_list);
            this.has_go_charge = false;
            this.charge_sucess = false;
            this.matchInfoList = null;
            this.gameDisplayPageData = null;
            sys.isObjectValid(this.data.avatar_frame_id) && (this.avatar_frame_id = Number(this.data.avatar_frame_id));
            this.refreshTableStyles(a.data);
            sys.isObjectValid(this.data.exe_cfg) && sys.isObjectValid(this.data.exe_cfg.introduce_times) && (this.exe_cfg.introduce_times = this.data.exe_cfg.introduce_times);
            this.exe_data = this.data.exe_data;
            this.act_98_times = 0;
            sys.isObjectValid(this.data.act_98_times) && (this.act_98_times = ToolUtils.isSafeNumber(this.data.act_98_times));
            this.act_98_touch_chip = 0;
            sys.isObjectValid(this.data.act_98_touch_chip) && (this.act_98_touch_chip = ToolUtils.isSafeNumber(this.data.act_98_touch_chip));
            this.act_98_give_chip = 0;
            sys.isObjectValid(this.data.act_98_give_chip) && (this.act_98_give_chip = ToolUtils.isSafeNumber(this.data.act_98_give_chip));
            sys.isObjectValid(this.adjust_reg_event) && this.adjust_reg_event.length > 0 && sys.isObjectValid(this.data.isregister) && 1 == Number(this.data.isregister) && this.reportAdjustRegEvent();
            sys.isObjectValid(this.data.pay_total) && (this.data.pay_total = this.data.pay_total, this.has_charged = this.data.pay_total, this.updatePayTotalMoney(this.data.pay_total));
            this.withdraw_noCharge_open = 1;
            sys.isObjectValid(this.data.pay_withdraw) && (this.withdraw_noCharge_open = ToolUtils.isSafeNumber(this.data.pay_withdraw));
            sys.isObjectValid(this.data.game_lock) && this.data.game_lock && !Array.isArray(this.data.game_lock) && (this.game_lock_data = this.data.game_lock || null);
            sys.isObjectValid(this.data.gp_rating_open) && (this.gp_rating_open = ToolUtils.isSafeNumber(this.data.gp_rating_open));
            sys.isObjectValid(this.data.gp_rating_lock_hour) && (this.gp_rating_lock_hour = ToolUtils.isSafeNumber(this.data.gp_rating_lock_hour));
            sys.isObjectValid(this.data.play_record_times) && (this.histroyCardGameCd = ToolUtils.isSafeNumber(this.data.play_record_times));
            sys.isObjectValid(this.data.show_sgame) && (this.show_sgame = ToolUtils.isSafeNumber(this.data.show_sgame));
            sys.isObjectValid(this.data.act131_search) && (SportCricket_Manager.shared().sortSourceData = this.data.act131_search);
            sys.isObjectValid(this.data.feedback_data) && (ToolUtils.feedback_data = this.data.feedback_data);
            sys.isObjectValid(this.data.first_recharge_type) && (this.first_recharge_type = ToolUtils.isSafeNumber(this.data.first_recharge_type));
        }
        catch (e) {
            TLog.printError("--------------- initLoginMsg err:", e.toString());
        }
    }
    checkPreGetActInfo(a = true) {
        this.bHasPreGetActInfo || sys.isObjectValid(User.shared().data.prep_act) && 1 == User.shared().data.prep_act && HttpManager.shared().doPreGetActivityInfo(((t, i, r) => {
            if (200 != r) {
                a && User.shared().checkPreRequestActData();
            }
            else {
                try {
                    let t = ToolUtils.parseJson(i);
                    0 == t.ret && sys.isObjectValid(t.data) ? (User.shared().bHasPreGetActInfo = true, sys.isObjectValid(t.data[54]) && (User.shared().firstrechargeData = t.data[54]), sys.isObjectValid(t.data[104]) && (User.shared().weekmonthData = t.data[104], ToolUtils.saveData("weekmonth_data" + String(User.shared().data.uid), ToolUtils.toJsonString(this.weekmonthData))), sys.isObjectValid(t.data[68]) && (User.shared().gullak_data = t.data[68]), sys.isObjectValid(t.data[74]) && (User.shared().adventrueData = t.data[74]), sys.isObjectValid(t.data[107]) && (User.shared().dailyLoginActData = t.data[107], ToolUtils.saveData("dailycheckin_data" + String(User.shared().data.uid), ToolUtils.toJsonString(User.shared().dailyLoginActData)), PushCenter.shared().pushEvent(PushEvent.UpdateDailyLoginAct)), sys.isObjectValid(t.data[119]) && (User.shared().twentyfourrechargeData = t.data[119]), sys.isObjectValid(t.data[118]) && (User.shared().rebaterechargeData = t.data[118]), sys.isObjectValid(t.data[125]) && (User.shared().payOneForThreeData = t.data[125]), sys.isObjectValid(t.data[130]) && (User.shared().consecutiveGiftData = t.data[130]), sys.isObjectValid(t.data[115]) && (User.shared().rechargeRewardsData = t.data[115]), sys.isObjectValid(t.data[121]) && (User.shared().crazyCashbackData = t.data[121]), sys.isObjectValid(t.data[122]) && (User.shared().golden_link_data = t.data[122]), sys.isObjectValid(t.data[135]) && (User.shared().customSelGiftData = t.data[135])) : a && User.shared().checkPreRequestActData();
                }
                catch (t) {
                    TLog.printError("listenPreGetActivityInfoAfterLogin err:", t);
                    a && User.shared().checkPreRequestActData();
                }
            }
        }));
    }
    checkTargetRequestActData(e) {
        e == PushEvent.JUMP_TO_WEEK_MONTH ? sys.isObjectValid(this.weekmonthData) || !this.checkInPopList(PushEvent.JUMP_TO_WEEK_MONTH) && !this.checkInActCollectList(PushEvent.JUMP_TO_WEEK_MONTH) || this.requestWeekMonthActData() : e == PushEvent.JUMP_TO_SCLB ? sys.isObjectValid(this.firstrechargeData) || !this.checkInPopList(PushEvent.JUMP_TO_SCLB) && !this.checkInActCollectList(PushEvent.JUMP_TO_SCLB) || this.requestFirstRechargePageData() : e == PushEvent.JUMP_TO_TwentyFourRecharge ? sys.isObjectValid(this.twentyfourrechargeData) || !this.checkInPopList(PushEvent.JUMP_TO_TwentyFourRecharge) && !this.checkInActCollectList(PushEvent.JUMP_TO_TwentyFourRecharge) || this.requestTwentyFourRechargePageData() : e == PushEvent.JUMP_TO_RebateRecharge ? sys.isObjectValid(this.rebaterechargeData) || !this.checkInPopList(PushEvent.JUMP_TO_RebateRecharge) && !this.checkInActCollectList(PushEvent.JUMP_TO_RebateRecharge) || this.requestRebateRechargePageData() : e == PushEvent.JUMP_TO_BuyOneGetThree ? sys.isObjectValid(this.payOneForThreeData) || !this.checkInPopList(PushEvent.JUMP_TO_BuyOneGetThree) && !this.checkInActCollectList(PushEvent.JUMP_TO_BuyOneGetThree) || this.requestBuyOneGetThreePageData() : e == PushEvent.JUMP_TO_Adventrue ? sys.isObjectValid(this.adventrueData) || !this.checkInPopList(PushEvent.JUMP_TO_Adventrue) && !this.checkInActCollectList(PushEvent.JUMP_TO_Adventrue) || this.requestActAdvancedPackPage() : e == PushEvent.JUMP_TO_Gullak ? sys.isObjectValid(this.gullak_data) || !this.checkInPopList(PushEvent.JUMP_TO_Gullak) && !this.checkInActCollectList(PushEvent.JUMP_TO_Gullak) || this.requestActGullakPage() : e == PushEvent.JUMP_TO_DAILYLOGIN ? !sys.isObjectValid(this.dailyLoginActData) && sys.isObjectValid(this.data.act105_open) && 1 == this.data.act105_open && (this.checkInPopList(PushEvent.JUMP_TO_DAILYLOGIN) || this.checkInActCollectList(PushEvent.JUMP_TO_DAILYLOGIN)) && this.requestDailyLoginActData(true) : e == PushEvent.JUMP_TO_TreasureDraw && (sys.isObjectValid(this.treasuredrawData) || !this.checkInPopList(PushEvent.JUMP_TO_TreasureDraw) && !this.checkInActCollectList(PushEvent.JUMP_TO_TreasureDraw) || this.requestTreasureDrawPageData());
    }
    checkPreRequestActData() {
        User.shared().bHasPreGetActInfo = true;
        sys.isObjectValid(this.weekmonthData) || !this.checkInPopList(PushEvent.JUMP_TO_WEEK_MONTH) && !this.checkInActCollectList(PushEvent.JUMP_TO_WEEK_MONTH) || this.requestWeekMonthActData();
        sys.isObjectValid(this.firstrechargeData) || !this.checkInPopList(PushEvent.JUMP_TO_SCLB) && !this.checkInActCollectList(PushEvent.JUMP_TO_SCLB) || this.requestFirstRechargePageData();
        sys.isObjectValid(this.twentyfourrechargeData) || !this.checkInPopList(PushEvent.JUMP_TO_TwentyFourRecharge) && !this.checkInActCollectList(PushEvent.JUMP_TO_TwentyFourRecharge) || this.requestTwentyFourRechargePageData();
        sys.isObjectValid(this.rebaterechargeData) || !this.checkInPopList(PushEvent.JUMP_TO_RebateRecharge) && !this.checkInActCollectList(PushEvent.JUMP_TO_RebateRecharge) || this.requestRebateRechargePageData();
        sys.isObjectValid(this.payOneForThreeData) || !this.checkInPopList(PushEvent.JUMP_TO_BuyOneGetThree) && !this.checkInActCollectList(PushEvent.JUMP_TO_BuyOneGetThree) || this.requestBuyOneGetThreePageData();
        sys.isObjectValid(this.adventrueData) || !this.checkInPopList(PushEvent.JUMP_TO_Adventrue) && !this.checkInActCollectList(PushEvent.JUMP_TO_Adventrue) || this.requestActAdvancedPackPage();
        sys.isObjectValid(this.gullak_data) || !this.checkInPopList(PushEvent.JUMP_TO_Gullak) && !this.checkInActCollectList(PushEvent.JUMP_TO_Gullak) || this.requestActGullakPage();
        !sys.isObjectValid(this.dailyLoginActData) && sys.isObjectValid(this.data.act105_open) && 1 == this.data.act105_open && (this.checkInPopList(PushEvent.JUMP_TO_DAILYLOGIN) || this.checkInActCollectList(PushEvent.JUMP_TO_DAILYLOGIN)) && this.requestDailyLoginActData(true);
        sys.isObjectValid(this.treasuredrawData) || !this.checkInPopList(PushEvent.JUMP_TO_TreasureDraw) && !this.checkInActCollectList(PushEvent.JUMP_TO_TreasureDraw) || this.requestTreasureDrawPageData();
    }
    checkInPopList(e) {
        if (this.poplist && this.poplist.length > 0) {
            for (let a = 0, t = this.poplist.length; a < t; a++) {
                if (e == this.poplist[a].type) {
                    return true;
                }
            }
        }
        return false;
    }
    checkInActCollectList(e) {
        if (this.data.act_collect_open && this.data.act_collect_open.list && this.data.act_collect_open.list.length > 0) {
            for (let a = 0, t = this.data.act_collect_open.list.length; a < t; a++) {
                if (e == this.data.act_collect_open.list[a].act_id) {
                    return true;
                }
            }
        }
        return false;
    }
    reportAdjustRegEvent() {
        let e = {};
        e.token = this.adjust_reg_event;
        e.cbParams = {};
        e.cbParams.uid = String(this.data.uid);
        e.cbParams.serverid = String(this.data.uid);
        e.cbParams.playerid = String(this.data.uid);
        e.cbParams.channelid = AppInfo.shared().getChannelId();
        e.partnerParams = {};
        e.partnerParams.uid = String(this.data.uid);
        e.partnerParams.serverid = String(this.data.uid);
        e.partnerParams.playerid = String(this.data.uid);
        e.partnerParams.channelid = AppInfo.shared().getChannelId();
        AppInfo.shared().trackEventByAdjust(ToolUtils.toJsonString(e));
    }
    requestDailyLoginActData(a = false) {
        (null == User.shared().dailyLoginActData || a) && HttpManager.shared().doGetCommonRequest(null, HttpRequest.GetDailyLogin, ((a, t, s) => {
            try {
                if (200 != s) {
                    alert("The login timed out, please try again");
                }
                else {
                    let a = ToolUtils.parseJson(t);
                    0 == a.ret && (User.shared().dailyLoginActData = a.data, ToolUtils.saveData("dailycheckin_data" + String(User.shared().data.uid), ToolUtils.toJsonString(User.shared().dailyLoginActData)), PushCenter.shared().pushEvent(PushEvent.UpdateDailyLoginAct));
                }
            }
            catch (e) {
            }
        }));
    }
    requestCheckFlopCashReward(e = "") {
        HttpManager.shared().doGetCommonRequest({ vid: e }, HttpRequest.FlopCashAutoCheckReward, ((e, a, t) => {
            try {
                if (200 != t) {
                    alert("The login timed out, please try again");
                }
                else {
                    ToolUtils.parseJson(a);
                }
            }
            catch (e) {
            }
        }));
    }
    checkLocalPracticeRecomendRoom() {
        let a = false;
        if (User.shared().isFirstOpenApp2) {
            let t = sys.localStorage.getItem(User.shared().data.uid + "recommendRoomNew");
            if (sys.isObjectValid(t)) {
                let i = ToolUtils.getRecommendRoom(ToolUtils.parseJson(t));
                sys.isObjectValid(i) && sys.isObjectValid(i.gameType) && 3 == i.gameType && (a = true, sys.localStorage.removeItem(User.shared().data.uid + "recommendRoomNew"));
            }
        }
        User.shared().isFirstOpenApp2 = false;
        this.chip_local_has = a;
    }
    refreshTableStyles(a) {
        let t = false;
        if (sys.isObjectValid(a.table_id)) {
            let e = Number(a.table_id);
            this.styles[0] != e && (t = true, e >= 1 && e <= 5 && (this.styles[0] = e));
        }
        if (sys.isObjectValid(a.table_face_id)) {
            let e = Number(a.table_face_id);
            this.styles[1] != e && (t = true, e >= 1 && e <= 3 && (this.styles[1] = e));
        }
        if (sys.isObjectValid(a.table_back_id)) {
            let e = Number(a.table_back_id);
            this.styles[2] != e && (t = true, e >= 1 && e <= 5 && (this.styles[2] = e));
        }
        t && (ToolUtils.saveData("display_styles", ToolUtils.toJsonString(User.shared().styles)), PushCenter.shared().pushEvent(PushEvent.UpdateRaceCSS), PushCenter.shared().pushEvent(PushEvent.RefreshGameDisplayPage), 5 == this.styles[0] && 3 == this.styles[1] && 5 == this.styles[2] && PushCenter.shared().pushEvent(PushEvent.ShowSwitchGameSkinTips));
    }
    getSuperVipUpgradeMsg(e) {
        let a = { list: [] };
        if (sys.isObjectValid(e.msg) && (a.msg = e.msg), sys.isObjectValid(e.reward_list)) {
            for (let t = 0, i = e.reward_list.length; t < i; t++) {
                let i = e.reward_list[t], r = [];
                sys.isObjectValid(i.amt) && (r.num = i.amt);
                sys.isObjectValid(i.amount) && (r.num = i.amount);
                r.type = i.type;
                r.name = Utils.shared().getIconNameByType(i.type, i.desc || "");
                a.list[t] = r;
            }
        }
        return a.old_show_level = e.old_show_level, a.new_show_level = e.new_show_level, a.isSuperUpLevel = true, a;
    }
    checkGetSysRecommedRoom() {
        let e = this.roomTable.recommend;
        return this.data.recommend && (e = this.data.recommend), this.data.last_cash && (e = this.data.last_cash), e;
    }
    checkFirstChipClick() {
        let a = sys.localStorage.getItem(User.shared().data.uid + "firstchip");
        return (!sys.isObjectValid(a) || "1" != a) && (sys.localStorage.setItem(User.shared().data.uid + "firstchip", "1"), true);
    }
    checkRecommendRoom() {
        try {
            if (!sys.isObjectValid(User.shared().data.uid) || 0 == User.shared().data.uid) {
                return;
            }
            if (1 == GameConfig.CHIPS_MODLE) {
                return void (this.sysRecommend = null);
            }
            let a = this.roomTable.recommend;
            this.data.recommend && (a = this.data.recommend);
            this.data.last_cash && (a = this.data.last_cash);
            let t = sys.localStorage.getItem(User.shared().data.uid + "saveRecommendRoom");
            if (sys.isObjectValid(t)) {
                if (sys.isObjectValid(this.data.daily_login_cnt) && 1 == this.data.daily_login_cnt) {
                    sys.isObjectValid(a) && (ToolUtils.saveData(User.shared().data.uid + "saveRecommendRoom", ToolUtils.toJsonString(a)), this.sysRecommend = a, sys.localStorage.removeItem(User.shared().data.uid + "recommendRoom"), sys.localStorage.removeItem(User.shared().data.uid + "recommendRoomNew"), sys.localStorage.removeItem(User.shared().data.uid + "addRecommendRoomNew"));
                }
                else {
                    let i = sys.localStorage.getItem(User.shared().data.uid + "recommendRoomNew");
                    sys.isObjectValid(i) ? this.sysRecommend = ToolUtils.parseJson(i) : sys.isObjectValid(a) ? (ToolUtils.saveData(User.shared().data.uid + "saveRecommendRoom", ToolUtils.toJsonString(a)), this.sysRecommend = a) : sys.isObjectValid(t) && (this.sysRecommend = ToolUtils.parseJson(t));
                }
            }
            else {
                sys.isObjectValid(a) && (ToolUtils.saveData(User.shared().data.uid + "saveRecommendRoom", ToolUtils.toJsonString(a)), this.sysRecommend = a);
            }
        }
        catch (e) {
            TLog.printError("-------- user checkRecommendRoom err:", e);
        }
    }
    getFirebaseJumpType(e = false) {
        !e && this.jump_type && this.jump_type.length > 0 ? this.dealPushJumpLogic() : (this.bLoginGetJumpType = e, AppInfo.shared().getFirebaseJumpType("User", this, "onGetFireBaseJumpType"));
    }
    onGetFireBaseJumpType(e) {
        e && String(e).length > 0 && (this.jump_type = String(e), AppInfo.shared().getFirebaseExt("User", this, "onGetFireBaseExt"));
    }
    onGetFireBaseExt(e) {
        this.jump_ext = null;
        e && String(e).length > 0 && (this.jump_ext = "object" == typeof e ? e : ToolUtils.parseJson(e));
        HttpManager.shared().doReportPushData(this.jump_type, this.jump_ext);
        this.bLoginGetJumpType || this.dealPushJumpLogic();
    }
    dealPushJumpLogic() {
        let e = null;
        if (Number(this.jump_type) == PushEvent.JUMP_TO_COUPON_ACT && (e = {}, e.needReqPage = true), Utils.shared().doJumpLogic(this.jump_type, this.jump_ext, e), this.poplist && this.poplist.length > 0) {
            for (let e = 0, a = this.poplist.length; e < a; e++) {
                this.jump_type == this.poplist[e].type && this.poplist.splice(e, 1);
            }
        }
        this.jump_type = this.jump_ext = null;
    }
    requestDailytaskList() {
        HttpManager.shared().doGetDailyTaskList(((a, t, s) => {
            try {
                if (200 != s) {
                    alert("The login timed out, please try again");
                }
                else {
                    let a = ToolUtils.parseJson(t);
                    0 == a.ret && (User.shared().dailydata = a.data);
                }
            }
            catch (e) {
                TLog.printError("listenEmailCallback:", e);
            }
        }));
    }
    doMemberShipData() {
        HttpManager.shared().doGetMemberShipPageData(((a, t, i) => {
            try {
                if (200 != i) {
                    alert("The login timed out, please try again");
                }
                else {
                    let a = ToolUtils.parseJson(t);
                    0 == a.ret && (this.club_data = a.data, sys.isObjectValid(a.data.player_club_info) && (User.shared().data.player_club = a.data.player_club_info));
                }
            }
            catch (e) {
                TLog.printError("doMemberShipData:", e);
            }
        }));
    }
    getActivityData() {
        HttpManager.shared().doGetActivityList(((a, t, s) => {
            try {
                if (200 != s) {
                    alert("The login timed out, please try again");
                }
                else {
                    let a = ToolUtils.parseJson(t);
                    if (0 == a.ret && (User.shared().actList = a.data.actlist, Array.isArray(User.shared().actList))) {
                        for (let a = 0, t = User.shared().actList.length; a < t; a++) {
                            Utils.shared().downNetImage(User.shared().actList[a].imgurl);
                        }
                    }
                }
            }
            catch (e) {
                TLog.printError("getActivityData:", e);
            }
        }));
    }
    checkPayment(a) {
        return !!sys.isObjectValid(User.shared().payment_cnt) && (a >= User.shared().payment_cnt.upi_1_min && a <= User.shared().payment_cnt.upi_1_max && (a >= User.shared().payment_cnt.upi_2_min && a <= User.shared().payment_cnt.upi_2_max));
    }
    startPay(a, t = 0, i = null) {
        a.scene = this.payment_scene.scene;
        a.vid = this.payment_scene.vid;
        0 == t && 1 == User.shared().payment_cnt.selectpay_gift && sys.isObjectValid(a.price) && this.checkPayment(Number(a.price)) ? Utils.shared().showPaymentGuide(null, a, (e => {
            a.pmode = e;
            this.startOrder(HttpRequest.CommPay, a, t);
            sys.isObjectValid(i) && i(1);
        })) : (this.startOrder(HttpRequest.CommPay, a, t), sys.isObjectValid(i) && i(1));
    }
    startOrder(a, t, i = 0) {
        Utils.shared().showLoading(10, true, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
        }), ToolUtils.getIsNormalDirection());
        HttpManager.shared().doPay("comm_pay2", a, t, ((t, r, h) => {
            if (Utils.shared().hideLoading(), 200 != h) {
                Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text29"), 2, 0, ToolUtils.getIsNormalDirection());
            }
            else {
                let t = ToolUtils.parseJson(r);
                if (0 == t.ret) {
                    if (t.data.paytx && 1 === t.data.paytx) {
                        let e = { email: t.data.email, tel_no: t.data.tel_no, name: t.data.name, from_type: 1 };
                        t.data.amount && (this.bc_gold = t.data.amount);
                        Utils.shared().showPersonalInfoVerifyView(e);
                    }
                    else {
                        t.data.out_trade_no && (this.outTradeNo = t.data.out_trade_no, 1 == i && ToolUtils.judgeIfInHall() && (this.ratingTradeNo = t.data.out_trade_no));
                        let e = t.data.ext_info;
                        if (sys.os !== sys.OS.ANDROID && sys.os !== sys.OS.OHOS) {
                            if (e) {
                                let a = ToolUtils.parseJson(e);
                                a.payurl && sys.openURL(a.payurl);
                            }
                        }
                        else {
                            let a = ToolUtils.parseJson(e);
                            9 == a.ptype && sys.isObjectValid(t.data.out_trade_no) ? (a.flow_id = t.data.out_trade_no, AppInfo.shared().requestPay(ToolUtils.toJsonString(a))) : AppInfo.shared().requestPay(e);
                        }
                        1 == this.act_79 && 1 == i && (this.has_go_charge = true);
                    }
                    TweenTool.delayAct(ToolUtils.getPersistGlobalNode(), (() => {
                        a == HttpRequest.CommChipPay ? (User.shared().chipfirstrechargeData && User.shared().getHallInfo(), this.requestMallExeShopList()) : this.requestStoreList();
                    }), 1.5, true);
                    PushCenter.shared().pushEvent(PushEvent.OrderSuccess);
                }
                else {
                    if (101 == t.ret || 102 == t.ret || 103 == t.ret) {
                        let e = ToolUtils.format(i18nMgr.shared().getValueByKey("add_cash_limits.daily_limits_tips"), t.data.left);
                        102 == t.ret ? e = ToolUtils.format(i18nMgr.shared().getValueByKey("add_cash_limits.monthly_limits_tips"), t.data.left) : 103 == t.ret && (e = ToolUtils.format(i18nMgr.shared().getValueByKey("add_cash_limits.weekly_limits_tips"), t.data.left));
                        Utils.shared().showCommomDialog(e, i18nMgr.shared().getValueByKey("settings.tips"), (e => {
                            1 == e && Utils.shared().showRechargeLimitsView();
                        }), true, false, i18nMgr.shared().getValueByKey("store.reset"), i18nMgr.shared().getValueByKey("utlis.later"), false, null, 1);
                    }
                    else {
                        PushCenter.shared().pushEvent(PushEvent.RechargeFailed);
                        ToolUtils.isSafeString(t.desc) && t.desc.length > 0 && Utils.shared().showToast(t.desc, 3);
                    }
                    a == HttpRequest.CommChipPay ? (User.shared().chipfirstrechargeData && User.shared().getHallInfo(), this.requestMallExeShopList()) : this.requestStoreList();
                }
            }
        }));
    }
    showKyc() {
        if (1 === AppInfo.shared().checkLocationPermission()) {
            AppInfo.shared().getLocationInfo();
        }
        else {
            let e = i18nMgr.shared().getValueByKey("rummy_main.notice"), a = i18nMgr.shared().getValueByKey("utlis.text5");
            Utils.shared().showCommomDialog(a, e, (e => {
                1 == e && AppInfo.shared().getLocationInfo();
            }), false);
        }
        return true;
    }
    getHallInfo(a = 0) {
        if (sys.now() - this._reqHallGetTime < 1000) {
            return PushCenter.shared().pushEvent(PushEvent.UpdateTaskRed), PushCenter.shared().pushEvent(PushEvent.RefreshHallAddCashFlag), PushCenter.shared().pushEvent(GameConfig.Update_Email), void PushCenter.shared().pushEvent(PushEvent.RefreshKycGuideTips);
        }
        this._reqHallGetTime = sys.now();
        HttpManager.shared().doGetCommonRequest({ isBackToHall: ToolUtils.isInGameScene, vid: a }, HttpRequest.HallInfoGet, ((t, i, r) => {
            if (200 != r) {
                ;
            }
            else {
                let t = ToolUtils.parseJson(i);
                if (0 == t.ret) {
                    if (sys.isObjectValid(t.data.player_club) && (this.data.player_club = t.data.player_club, PushCenter.shared().pushEvent(GameConfig.Hall_MemberShip_info, this.data.player_club)), sys.isObjectValid(t.data.avatar_frame_id) && (Number(t.data.avatar_frame_id) != this.avatar_frame_id ? (this.avatar_frame_id = Number(t.data.avatar_frame_id), PushCenter.shared().pushEvent(GameConfig.Hall_MemberShip_info, this.data.player_club)) : this.avatar_frame_id = Number(t.data.avatar_frame_id)), sys.isObjectValid(t.data.act_list_open)) {
                        let e = false;
                        if (sys.isObjectValid(t.data.act_list_open.act_106)) {
                            let a = ToolUtils.isSafeNumber(t.data.act_list_open.act_106);
                            a !== this.new_user_task_open && (this.new_user_task_open = a, e = true);
                            1 == a && null == this.novicesTaskData && this.requestNovicesTaskInfo();
                        }
                        if (sys.isObjectValid(t.data.act_list_open.act_123)) {
                            let a = ToolUtils.isSafeNumber(t.data.act_list_open.act_123);
                            a !== this.new_user_flopcash_open && (this.new_user_flopcash_open = a, e = true);
                            1 == a && null == this.flopCashTaskData && this.requestFlopCashTaskInfo();
                        }
                        if (sys.isObjectValid(t.data.act_list_open.act_52)) {
                            let a = ToolUtils.isSafeNumber(t.data.act_list_open.act_52);
                            a !== this.daily_task && (this.daily_task = a, PushCenter.shared().pushEvent(PushEvent.UpdateRoomTaskBtn), e = true);
                            1 == a && (1 == this.showNewDailyTask ? (this.requestNewDailyTaskData(), this.requestNewDailyListData()) : null == this.dailydata && this.requestDailytaskList());
                        }
                        if (sys.isObjectValid(t.data.act_list_open.act_54)) {
                            let a = ToolUtils.isSafeNumber(t.data.act_list_open.act_54);
                            a !== this.canFirstPay && (this.canFirstPay = a, e = true);
                            1 != this.canFirstPay && PushCenter.shared().pushEvent(PushEvent.CloseFirstRecharge);
                        }
                        if (sys.isObjectValid(t.data.act_list_open.act_119)) {
                            let a = ToolUtils.isSafeNumber(t.data.act_list_open.act_119);
                            a !== this.canTwentyFour && (this.canTwentyFour = a, e = true);
                            1 != this.canTwentyFour && PushCenter.shared().pushEvent(PushEvent.CloseTwentyHourRecharge);
                        }
                        if (sys.isObjectValid(t.data.act_list_open.act_118)) {
                            let a = ToolUtils.isSafeNumber(t.data.act_list_open.act_118);
                            a !== this.canRebate && (this.canRebate = a, e = true);
                            1 != this.canRebate && PushCenter.shared().pushEvent(PushEvent.CloseRebateRecharge);
                        }
                        if (sys.isObjectValid(t.data.act_list_open.act_62)) {
                            let a = ToolUtils.isSafeNumber(t.data.act_list_open.act_62);
                            a !== this.canReliefPay && (this.canReliefPay = a, e = true);
                        }
                        if (sys.isObjectValid(t.data.act_list_open.act_135)) {
                            let a = ToolUtils.isSafeNumber(t.data.act_list_open.act_135);
                            a !== this.custom_sel_gift_open && (this.custom_sel_gift_open = a, e = true);
                            1 != this.custom_sel_gift_open && PushCenter.shared().pushEvent(PushEvent.CloseCustomSelGift);
                        }
                        if (sys.isObjectValid(t.data.act_list_open.act_137)) {
                            let a = ToolUtils.isSafeNumber(t.data.act_list_open.act_137);
                            a !== this.treasuredraw_open && (this.treasuredraw_open = a, e = true);
                            1 != this.treasuredraw_open && PushCenter.shared().pushEvent(PushEvent.CloseTreasureDraw);
                        }
                        e && PushCenter.shared().pushEvent(PushEvent.PurchasedFirstRecharge);
                    }
                    let i = false;
                    if (sys.isObjectValid(t.data.hall_red_list) && (t.data.hall_red_list.act_52 && (this.dailyTask_red = t.data.hall_red_list.act_52, i = true), t.data.hall_red_list.act_106 && (this.novicesTask_red = t.data.hall_red_list.act_106, i = true)), sys.isObjectValid(t.data.promotions_red)) {
                        let e = ToolUtils.isSafeNumber(Number(t.data.promotions_red));
                        e != this.promotions_red && (this.promotions_red = e, i = true);
                    }
                    if (i && PushCenter.shared().pushEvent(PushEvent.UpdateTaskRed), (sys.isObjectValid(t.data.row) || sys.isObjectValid(t.data.email_effect)) && (sys.isObjectValid(t.data.row) && (User.shared().data.un_read_email = ToolUtils.isSafeNumber(Number(t.data.row))), sys.isObjectValid(t.data.email_effect) && (User.shared().data.bonus_out_time = 1 == t.data.email_effect), PushCenter.shared().pushEvent(GameConfig.Update_Email)), sys.isObjectValid(t.data.email_bind_red_dot) && (User.shared().data.email_bind_red_dot = t.data.email_bind_red_dot), sys.isObjectValid(t.data.email_bind_reward) && t.data.email_bind_reward && Array.isArray(t.data.email_bind_reward) && (User.shared().data.email_bind_reward = t.data.email_bind_reward), 0 == GameConfig.CHIPS_MODLE && sys.isObjectValid(t.data.banner) ? (this.data.bannerlist = t.data.banner, PushCenter.shared().pushEvent(PushEvent.updateBannerList)) : this.data.bannerlist = [], sys.isObjectValid(t.data.act_collect_open) && (this.data.act_collect_open = t.data.act_collect_open, PushCenter.shared().pushEvent(PushEvent.updateActCollectOpen)), sys.isObjectValid(t.data.exe_act_collect_open) && (this.data.exe_act_collect_open = t.data.exe_act_collect_open, PushCenter.shared().pushEvent(PushEvent.updateActCollectOpenEXE)), sys.isObjectValid(t.data.act_63_back_ui) && (this.showBackTask = t.data.act_63_back_ui), sys.isObjectValid(t.data.act_121_show) && (this.showCrazyCashback = t.data.act_121_show, this.showCrazyCashbackDot = t.data.act_121_dot, PushCenter.shared().pushEvent(PushEvent.UpdateCashbackEnt)), sys.isObjectValid(t.data.act_63_backcard_ui) && (this.showBackCardTask = t.data.act_63_backcard_ui, 1 == this.showBackCardTask && this.requestBackCardTaskData()), this.getHelpSettingData(t.data.sw_cfg), t.data.sw_cfg && t.data.sw_cfg.list && Array.isArray(t.data.sw_cfg.list) && t.data.sw_cfg.list.length > 0 && this.dealSw_cfgListdata(t.data.sw_cfg.list[0], 1), 0 == a && sys.isObjectValid(t.data.check_list) && (this.check_list = t.data.check_list), sys.isObjectValid(t.data.act_67_guide_data) && (this.kyc_guide_data = t.data.act_67_guide_data, PushCenter.shared().pushEvent(PushEvent.RefreshKycGuideTips)), sys.isObjectValid(t.data.bottom_tips) && (this.kyc_bottom_tip = t.data.bottom_tips), sys.isObjectValid(t.data.kyc_check) && (this.data.kyc_check = t.data.kyc_check), sys.isObjectValid(t.data.pan_check) && (User.shared().pan_check = t.data.pan_check), sys.isObjectValid(t.data.mall_label) && (User.shared().mall_label = t.data.mall_label, PushCenter.shared().pushEvent(PushEvent.RefreshHallAddCashFlag)), sys.isObjectValid(t.data.vip_info) && (User.shared().data.vip_info = t.data.vip_info, PushCenter.shared().pushEvent(PushEvent.RefreshSuperVipInfo)), sys.isObjectValid(t.data.act_76_show) && (User.shared().act_76_show = t.data.act_76_show, PushCenter.shared().pushEvent(PushEvent.RefreshLeaderBoardsSwitch)), sys.isObjectValid(t.data.s_whatsapp) && (User.shared().s_whatsapp = t.data.s_whatsapp), sys.isObjectValid(t.data.vio) && (User.shared().data.vio = t.data.vio), sys.isObjectValid(t.data.refresh_room_sw) && 1 == Number(t.data.refresh_room_sw) && sys.isObjectValid(t.data.refresh_room_ver)) {
                        let a = localStorage.getItem("refresh_room_ver");
                        sys.isObjectValid(a) && "" != a ? a != "" + t.data.refresh_room_ver && (ToolUtils.saveData("refresh_room_ver", t.data.refresh_room_ver), User.shared().doReqCommRoomList((() => {
                            PushCenter.shared().pushEvent(PushEvent.GetRoomListCallBack);
                        }), true)) : (ToolUtils.saveData("refresh_room_ver", t.data.refresh_room_ver), User.shared().doReqCommRoomList((() => {
                            PushCenter.shared().pushEvent(PushEvent.GetRoomListCallBack);
                        }), true));
                    }
                    this.refreshTableStyles(t.data);
                    sys.isObjectValid(t.data.act_98_times) && (this.act_98_times = ToolUtils.isSafeNumber(t.data.act_98_times));
                    sys.isObjectValid(t.data.act_98_touch_chip) && (this.act_98_touch_chip = ToolUtils.isSafeNumber(t.data.act_98_touch_chip));
                    sys.isObjectValid(t.data.act_98_give_chip) && (this.act_98_give_chip = ToolUtils.isSafeNumber(t.data.act_98_give_chip));
                    sys.isObjectValid(t.data.gesture) && (sys.isObjectValid(t.data.gesture.points_classic_base_money) && ToolUtils.isSafeNumber(t.data.gesture.points_classic_base_money), sys.isObjectValid(t.data.gesture.points_classic_gesture) && (this.points_classic_gesture = ToolUtils.isSafeNumber(t.data.gesture.points_classic_gesture) || 0), sys.isObjectValid(t.data.gesture.points_classic_base_money) && (this.points_classic_base_money = ToolUtils.isSafeNumber(t.data.gesture.points_classic_base_money) || 0), PushCenter.shared().pushEvent(PushEvent.CheckHandGuide));
                    sys.isObjectValid(t.data.game_lock) && t.data.game_lock && !Array.isArray(t.data.game_lock) && (User.shared().game_lock_data = t.data.game_lock || null);
                    sys.isObjectValid(t.data.table_red_dot) && this.table_red_dot != ToolUtils.isSafeNumber(t.data.table_red_dot) && (this.table_red_dot = t.data.table_red_dot, PushCenter.shared().pushEvent(PushEvent.ChangeTableRedDot, this.table_red_dot));
                    sys.isObjectValid(t.data.act_131_show) && (this.cricket_open = t.data.act_131_show, sys.isObjectValid(t.data.act_131_dot_ids) && Array.isArray(t.data.act_131_dot_ids) ? SportCricket_Manager.shared().updateMatchLineUpMap(t.data.act_131_dot_ids) : SportCricket_Manager.shared().updateMatchLineUpMap([]), sys.isObjectValid(t.data.act_131_backup) && (SportCricket_Manager.shared().cricket_backup_open = Number(t.data.act_131_backup)), PushCenter.shared().pushEvent(PushEvent.RefreshYes11Ent));
                    sys.isObjectValid(t.data.tawk_url_1) && t.data.tawk_url_1.length > 0 && (this.tawk_url_1 = t.data.tawk_url_1);
                    sys.isObjectValid(t.data.tawk_url_2) && t.data.tawk_url_2.length > 0 && (this.tawk_url_2 = t.data.tawk_url_2);
                    sys.isObjectValid(t.data.tawk_url_3) && t.data.tawk_url_3.length > 0 && (this.tawk_url_3 = t.data.tawk_url_3);
                    sys.isObjectValid(t.data.tawk_url_4) && t.data.tawk_url_4.length > 0 && (this.tawk_url_4 = t.data.tawk_url_4);
                    sys.isObjectValid(t.data.tawk_url_5) && t.data.tawk_url_5.length > 0 && (this.tawk_url_5 = t.data.tawk_url_5);
                    sys.isObjectValid(t.data.tawk_url_5) && t.data.tawk_url_5.length > 0 && (this.tawk_url_5 = t.data.tawk_url_5);
                    sys.isObjectValid(t.data.tawk_url_6) && t.data.tawk_url_6.length > 0 && (this.tawk_url_6 = t.data.tawk_url_6);
                    sys.isObjectValid(t.data.tawk_url_7) && t.data.tawk_url_7.length > 0 && (this.tawk_url_7 = t.data.tawk_url_7);
                    sys.isObjectValid(t.data.tawk_url_8) && t.data.tawk_url_8.length > 0 && (this.tawk_url_8 = t.data.tawk_url_8);
                    sys.isObjectValid(t.data.tawk_url_9) && t.data.tawk_url_9.length > 0 && (this.tawk_url_9 = t.data.tawk_url_9);
                    sys.isObjectValid(t.data.tawk_url_10) && t.data.tawk_url_10.length > 0 && (this.tawk_url_10 = t.data.tawk_url_10);
                    sys.isObjectValid(t.data.tawk_url_11) && t.data.tawk_url_11.length > 0 && (this.tawk_url_11 = t.data.tawk_url_11);
                    sys.isObjectValid(t.data.tawk_url_12) && t.data.tawk_url_12.length > 0 && (ToolUtils.tawk_url_12 = t.data.tawk_url_12);
                    sys.isObjectValid(t.data.vip_reward_dot) && (ToolUtils.vip_reward_dot = t.data.vip_reward_dot, PushCenter.shared().pushEvent(PushEvent.RefreshSuperVipInfo));
                    sys.isObjectValid(t.data.play_collect_open) && sys.isObjectValid(t.data.play_collect_open.list) && (this.playingMethod_entry_switch = t.data.play_collect_open.list, this.playingMethod_entry_switch.sort(((e, a) => a.sort - e.sort)), PushCenter.shared().pushEvent(PushEvent.UpdateHallSmallGameSort));
                    sys.isObjectValid(t.data.show_sgame) && (this.show_sgame = ToolUtils.isSafeNumber(t.data.show_sgame), PushCenter.shared().pushEvent(PushEvent.UpdateHallSmallGame));
                    sys.isObjectValid(t.data.act_68_open) && (this.act_68_open = t.data.act_68_open);
                    sys.isObjectValid(t.data.act_68_full_status) && (this.act_68_full_status = t.data.act_68_full_status);
                    sys.isObjectValid(t.data.is_new_rank) && (this.data.is_new_rank = t.data.is_new_rank);
                    sys.isObjectValid(t.data.upi_1_min) && sys.isObjectValid(t.data.upi_1_max) && (this.payment_cnt.upi_1_min = Number(t.data.upi_1_min), this.payment_cnt.upi_1_max = Number(t.data.upi_1_max));
                    sys.isObjectValid(t.data.upi_2_max) && sys.isObjectValid(t.data.upi_2_max) && (this.payment_cnt.upi_2_min = Number(t.data.upi_2_min), this.payment_cnt.upi_2_max = Number(t.data.upi_2_max));
                    sys.isObjectValid(t.data.upi_2_add) && (this.payment_cnt.upi_2_add = Number(t.data.upi_2_add));
                    sys.isObjectValid(t.data.pmode) && (this.payment_cnt.pmode = Number(t.data.pmode));
                    sys.isObjectValid(t.data.selectpay_shop) && (this.payment_cnt.selectpay_shop = Number(t.data.selectpay_shop));
                    sys.isObjectValid(t.data.selectpay_gift) && (this.payment_cnt.selectpay_gift = Number(t.data.selectpay_gift));
                    sys.isObjectValid(t.data.upi2_select_amount) && Array.isArray(t.data.upi2_select_amount) && (this.payment_cnt.upi2_select_amount = t.data.upi2_select_amount);
                    sys.isObjectValid(t.data.popact_anim_count) && (this.popact_anim_count = Number(t.data.popact_anim_count));
                }
            }
        }));
    }
    getBannerData(e = 0) {
        HttpManager.shared().doGetCommonRequest({ isBackToHall: ToolUtils.isInGameScene, vid: e }, HttpRequest.HallBannerGet, ((e, a, t) => {
            if (200 != t) {
                ;
            }
            else {
                let e = ToolUtils.parseJson(a);
                0 == e.ret && (0 == GameConfig.CHIPS_MODLE && sys.isObjectValid(e.data.banner) ? (this.data.bannerlist = e.data.banner, PushCenter.shared().pushEvent(PushEvent.updateBannerList)) : (this.data.bannerlist = [], PushCenter.shared().pushEvent(PushEvent.updateBannerList)));
            }
        }));
    }
    getRoomRoomInfo(e = 0, a) {
        HttpManager.shared().doGetCommonRequest({ vid: e, act_id: a }, HttpRequest.RoomInfoGet, ((e, a, t) => {
            if (200 != t) {
                ;
            }
            else {
                let e = ToolUtils.parseJson(a), t = false;
                0 == e.ret && (e.data.red_list.act_106 && (this.novicesTask_red = e.data.red_list.act_106, t = true), e.data.red_list.act_52 && (this.dailyTask_red = e.data.red_list.act_52, t = true), t && PushCenter.shared().pushEvent(PushEvent.UpdateTaskRed));
            }
        }));
    }
    getRoomDailyTaskTips(e = 0) {
        HttpManager.shared().doGetCommonRequest({ vid: e }, HttpRequest.DailyTaskGetTips, ((a, t, s) => {
            if (200 != s) {
                ;
            }
            else {
                let a = ToolUtils.parseJson(t);
                if (0 == a.ret && a.data.act_52_task) {
                    let t = {};
                    t.vid = e;
                    t.taskData = a.data.act_52_task;
                    PushCenter.shared().pushEvent(PushEvent.RoomShowSingleDailyTaskBubble, t);
                }
            }
        }));
    }
    preloadPopListBundle(e) {
        if (sys.isObjectValid(this.poplist) && Array.isArray(this.poplist) && this.poplist.length > 0) {
            let a = this.poplist[0].type;
            e ? setTimeout((() => {
                Array.isArray(this.poplist) && this.poplist.length > 0 && (a = this.poplist[0].type, Utils.shared().preLoadActBundlePrefab(a, this.poplist[0].exe));
            }), 800) : Utils.shared().preLoadActBundlePrefab(a, this.poplist[0].exe);
        }
    }
    getHallPopList(a = true) {
        this.has_req_lobbyPop = true;
        this._checkExitRoomVid = true;
        User.shared().popActState = 0;
        let t = 0;
        User.shared().lastWinGameInfo.nVid > 0 && (t = User.shared().lastWinGameInfo.nScore);
        HttpManager.shared().doGetCommonRequest({ is_guide: this.isGuideEnterGame, join_room_money: User.shared().enterRoomMoney || 0, join_room_chip: User.shared().enterRoomMoneyExe || 0, last_vid: ToolUtils.curVId, last_win_score: t, exit_vid: User.shared().exitRoomGameVid }, HttpRequest.HallGetLobbyPop, ((t, i, r) => {
            if (User.shared().lastWinGameInfo = { nVid: -1, nScore: 0 }, 200 != r) {
                User.shared().has_req_lobbyPop = false;
            }
            else {
                let t = ToolUtils.parseJson(i);
                if (0 == t.ret && sys.isObjectValid(t.data.poplist)) {
                    if (User.shared().popActState = 1, User.shared().poplist = [], 1 == GameConfig.CHIPS_MODLE) {
                        return;
                    }
                    for (let a = 0, s = t.data.poplist.length; a < s; a++) {
                        User.shared().poplist.push(t.data.poplist[a]);
                    }
                    User.shared().checkLobbyPopList();
                    User.shared().pushActivityToPopList();
                    1 == GameConfig.HTTP_MSG_DEBUG && User.shared().poplist.forEach((e => {
                    }));
                    User.shared().preloadPopListBundle(false);
                    (a || User.shared().forcePopAct) && PushCenter.shared().pushEvent(PushEvent.Update_NextPopActivity);
                }
            }
        }));
        User.shared().enterRoomMoneyExe = 0;
        User.shared().enterRoomMoney = 0;
    }
    getDeskInfo(e, a = true) {
        let t = false, i = ToolUtils.deskInfos.size;
        if (ToolUtils.deskInfos.size > 0) {
            for (let a of ToolUtils.deskInfos.keys()) {
                a === ToolUtils.isSafeString(e.tid_key) && (t = true);
            }
        }
        if (!t && i < 3) {
            let a = new DeskInfo;
            a.tid_key = ToolUtils.isSafeString(e.tid_key);
            a.vid = e.vid;
            a.venuetype = e.venuetype;
            undefined !== e.game_type && (a.game_type = e.game_type);
            undefined !== e.pnum && (a.pnum = e.pnum);
            undefined !== e.base_money && (a.base_money = e.base_money);
            undefined !== e.round && (a.round = e.round);
            undefined !== e.currentRound && (a.currentRound = e.currentRound);
            undefined !== e.mode && (a.mode = e.mode);
            undefined !== e.special_mode && (a.special_mode = e.special_mode);
            sys.isObjectValid(e.match_mode) && (a.match_mode = e.match_mode);
            sys.isObjectValid(e.is_double) && (a.is_double = e.is_double);
            ToolUtils.deskInfos.set(ToolUtils.isSafeString(e.tid_key), a);
        }
        let r = ToolUtils.deskInfos.size;
        a && r >= 1 && r > i && PushCenter.shared().pushEvent(GameConfig.CreateDesk, e);
    }
    doPayDefRequest() {
        HttpManager.shared().doGetPayDefList(((e, a, t) => {
            if (200 != t) {
                ;
            }
            else {
                let e = ToolUtils.parseJson(a);
                0 == e.ret && (this.room_paydef = e.data, this.changeChargeValue(0, 0));
            }
        }));
    }
    doGetPropList() {
    }
    getPropNumById(a) {
        let t = 0;
        if (this.prop && this.prop.length > 0) {
            for (let s = 0, i = this.prop.length; s < i; s++) {
                User.shared().prop[s].pid == a && (t = this.prop[s].num);
            }
        }
        return t;
    }
    setPropNumById(a, t) {
        if (this.prop && this.prop.length > 0) {
            for (let s = 0, i = this.prop.length; s < i; s++) {
                User.shared().prop[s].pid == a && (this.prop[s].num = t);
            }
            PushCenter.shared().pushEvent(GameConfig.Update_Prop);
        }
    }
    changeChargeValue(e, a) {
        let t = this.room_paydef;
        for (let s = 0, i = t.length; s < i; s++) {
            for (let i in t[s]) {
                if (e == parseInt("" + i)) {
                    return void (t[s][i] = a);
                }
            }
        }
        let s = [];
        s[e] = a;
        this.room_paydef.push(s);
    }
    findChargeValue() {
        let e = this.room_paydef;
        for (let a = 0, t = e.length; a < t; a++) {
            for (let t in e[a]) {
                if (ToolUtils.curRoomId == parseInt("" + t)) {
                    return e[a];
                }
            }
        }
        return [];
    }
    send_request_hall_tableinfo() {
        if (1 == this.isInPerformanceRoom) {
            return;
        }
        let e = {};
        e.cmd = NetConfig.CLIENT_RSYNC_SMALL_TABLE_INFO;
        e.uid = this.data.uid;
        e.vid = 101;
        e.name = this.data.name;
        e.skey = this.getSkey();
        e.ver = GameConfig.Server_Api_Ver;
        e.in_room = 0;
        ToolUtils.getIsInRoom() && (e.in_room = 1);
        LabaServer.shared().send(e);
    }
    send_request_update_yesgame_state(e) {
        let a = {};
        a.cmd = NetConfig.CLIENT_SYNC_CRIC_STATUS;
        a.uid = this.data.uid;
        a.skey = this.getSkey();
        a.ver = GameConfig.Server_Api_Ver;
        a.in_cric = e;
        LabaServer.shared().send(a);
    }
    send_request_game_tableinfo() {
        if (1 == this.isInPerformanceRoom) {
            return;
        }
        let e = {};
        e.cmd = NetConfig.CLIENT_RSYNC_SMALL_TABLE_INFO;
        e.uid = this.data.uid;
        e.vid = 101;
        e.name = this.data.name;
        e.skey = this.getSkey();
        e.ver = GameConfig.Server_Api_Ver;
        e.in_room = 1;
        LabaServer.shared().send(e);
    }
    handler_server_resp_hall_tableinfo(e) {
        1 != this.isInPerformanceRoom && PushCenter.shared().pushEvent(PushEvent.UpdateGameTableInfoNum, e);
    }
    handler_server_resp_game_tableinfo(e) {
        1 != this.isInPerformanceRoom && (this.hallGamesTabInfo = e, PushCenter.shared().pushEvent(PushEvent.UpdateGameTableInfoNum, e));
    }
    handler_server_notify_race_will_start(e) {
        let a = e.raceid, t = e.vid;
        this.clearUserMatchTarget();
        let r = e.mode;
        if (director.getScene().name == BundleNameDefined.rummy_scence) {
            if (0 == r || 3 == r) {
                let s = e.tid_key;
                1 == e.isNewTable ? Utils.shared().showLoadTable(t, HowToPlayDefined.gameId_RaceRummy, null, null, null, s, a, 1) : this.send_request_game_tableinfo();
                PushCenter.shared().pushEvent(GameConfig.Close_Rummy_addGame);
            }
            else {
                this.send_can_join_race_info_laba();
            }
        }
        else {
            let d = false;
            3 == r && sys.isObjectValid(e.enter) && 1 == e.enter && (d = true);
            let h = e.tid_key;
            if (0 == r || d) {
                Utils.shared().showLoadTable(t, HowToPlayDefined.gameId_RaceRummy, null, null, null, h, a, 1);
            }
            else if (!this.isShowMatchEnterTips) {
                this.raceRoomDate = [];
                this.raceRoomDate.vid = t;
                this.raceRoomDate.raceid = a;
                this.raceRoomDate.tid_key = h;
                let s = { parentNode: director.getScene().getChildByName("Canvas"), strContent: e.race_name, callfun: this.onEnterRaceGame.bind(this), bRejoin: 1 == Number(e.is_rejoin), isLateJoin: 1 == Number(e.is_late_join) };
                Utils.shared().showMatchAlertView(0, s);
            }
        }
    }
    onEnterRaceGame(e) {
        "enter" == e ? Utils.shared().showLoadTable(this.raceRoomDate.vid, HowToPlayDefined.gameId_RaceRummy, null, null, null, this.raceRoomDate.tid_key, this.raceRoomDate.raceid, 1) : this.send_match_cancel_enter(this.raceRoomDate.raceid);
        this.isShowMatchEnterTips = false;
    }
    handler_server_notify_disuse_race_user(e) {
        e.msg && (Utils.shared().hideCommomDialog(), Utils.shared().showCommomDialog(e.msg, i18nMgr.shared().getValueByKey("rummy_main.notice"), null, false, ToolUtils.getIsNormalDirection()));
    }
    send_php_msg_ack_laba(e) {
        let a = {};
        a.cmd = NetConfig.CLIENT_PHP_MSG_TRANSFER_ACK;
        a.uid = this.data.uid;
        a.name = this.data.name;
        a.skey = this.getSkey();
        a.ver = GameConfig.Server_Api_Ver;
        a.uuid = e;
        LabaServer.shared().send(a);
    }
    send_refresh_laba() {
        let e = {};
        e.cmd = NetConfig.CLINET_NOTICE_USER_CHANGE;
        e.uid = this.data.uid;
        e.name = this.data.name;
        e.skey = this.getSkey();
        e.ver = GameConfig.Server_Api_Ver;
        LabaServer.shared().send(e);
    }
    send_race_reward_info_laba() {
        let e = {};
        e.cmd = NetConfig.CLIENT_RACE_REWARD_INFO_REQUEST;
        e.uid = this.data.uid;
        e.name = this.data.name;
        e.skey = this.getSkey();
        e.ver = GameConfig.Server_Api_Ver;
        LabaServer.shared().send(e);
    }
    send_race_receive_reward_laba(e) {
        let a = {};
        a.cmd = NetConfig.CLIENT_NOTIFY_RECIVE_REWARD_MSG;
        a.uid = this.data.uid;
        a.name = this.data.name;
        a.skey = this.getSkey();
        a.ver = GameConfig.Server_Api_Ver;
        a.raceid = e;
        LabaServer.shared().send(a);
    }
    handler_server_race_reward_info_respond(e) {
        null != e.raceid && PushCenter.shared().pushEvent(GameConfig.ShowMatchOverInfo, ToolUtils.toJsonString(e));
    }
    send_can_join_race_info_laba() {
        let e = {};
        e.cmd = NetConfig.CLIENT_CAN_JOIN_RACE_INFO_REQUEST;
        e.uid = this.data.uid;
        e.name = this.data.name;
        e.skey = this.getSkey();
        e.ver = GameConfig.Server_Api_Ver;
        LabaServer.shared().send(e);
    }
    handler_server_can_join_race_respond(e) {
        let a = e.table_info, t = "";
        if (null != a && a.length > 0) {
            for (let e = 0, s = a.length; e < s; e++) {
                if (1 == a[e].state) {
                    let t = a[e].vid, s = a[e].raceid;
                    Utils.shared().showLoadTable(t, HowToPlayDefined.gameId_RaceRummy, null, null, null, null, s, 1);
                }
                else {
                    "" == t ? t += a[e].race_name : t = t + ", " + a[e].race_name;
                }
            }
            t && t.length > 0 && PushCenter.shared().pushEvent(GameConfig.ShowMatchJoinTips, t);
        }
    }
    handler_server_notify_race_start(e) {
        PushCenter.shared().pushEvent(GameConfig.NotifyRaceStart, e);
    }
    send_client_consume_table_record_laba(e) {
        let a = {};
        a.cmd = NetConfig.CLIENT_CONSUME_TABLE_RECORD;
        a.uid = this.data.uid;
        a.tid_key = e;
        a.skey = this.getSkey();
        a.ver = GameConfig.Server_Api_Ver;
        LabaServer.shared().send(a);
    }
    updatePayTotalMoney(e) {
        this.has_charged != e && (e < 0 && (e = 0), this.has_charged = e, PushCenter.shared().pushEvent(GameConfig.Update_PayTotal, this.has_charged));
    }
    judgePushBagItemUpdateEvent() {
        if (sys.isObjectValid(this.backPackData) && sys.isObjectValid(this.backPackData.list) && Array.isArray(this.backPackData.list)) {
            let e = [];
            for (let a = 0; a < this.backPackData.list.length; a++) {
                let t = this.backPackData.list[a];
                if (sys.isObjectValid(t.reward_type)) {
                    switch (Number(t.reward_type)) {
                        case BagItemType.BonusAdd:
                        case BagItemType.LuckyLeaf:
                        case BagItemType.TreasureKey: e.includes(t.reward_type) || e.push(t.reward_type);
                    }
                }
            }
            e && Array.isArray(e) && e.length > 0 && PushCenter.shared().pushEvent(PushEvent.UpdateBagItem, e);
        }
    }
    getBackPackItemCount(e) {
        let a = 0;
        if (sys.isObjectValid(this.backPackData) && this.backPackData && sys.isObjectValid(this.backPackData.list) && Array.isArray(this.backPackData.list)) {
            for (let t = 0; t < this.backPackData.list.length; t++) {
                let i = this.backPackData.list[t];
                if (sys.isObjectValid(i.reward_type) && sys.isObjectValid(i.num) && i.reward_type == e) {
                    a = ToolUtils.isSafeNumber(i.num);
                    break;
                }
            }
        }
        return a;
    }
    getIPAddress() {
        "MOBILE_BROWSER" != sys.platform && "DESKTOP_BROWSER" != sys.platform && 0 != GameConfig.USR_REPORT_SWITCH && (sys.isObjectValid(ToolUtils.ipAddress) && ToolUtils.ipAddress.length > 0 || this.getIpCount > 3 || HttpManager.shared().doGetIPAddress(((e, a, t) => {
            if (this.getIpCount = this.getIpCount + 1, 200 != t) {
                ;
            }
            else {
                try {
                    let e = new RegExp(/\d+.\d+.\d+.\d+/g), t = a.match(e);
                    Array.isArray(t) && t.length > 0 && (ToolUtils.ipAddress = t[0]);
                    sys.isObjectValid(ToolUtils.ipAddress) || (ToolUtils.ipAddress = "");
                }
                catch (e) {
                }
            }
        })));
    }
    getNetDelayMs() {
        0 != GameConfig.USR_REPORT_SWITCH && (User.shared().bHasStartPint || (User.shared().bHasStartPint = true, this.pingRequestTime = sys.now(), HttpManager.shared().doGetNewWorkDelay(((a, t, i) => {
            200 != i ? ToolUtils.nNetDelayTimeOut = ToolUtils.nNetDelayTimeOut + 1 : (ToolUtils.netDelay = sys.now() - User.shared().pingRequestTime, ToolUtils.nNetDelayTimeOut = -1);
        })), setTimeout((() => {
            User.shared().bHasStartPint = false;
            User.shared().getNetDelayMs();
        }), 5000)));
    }
    getNetDelayMs2() {
        0 != GameConfig.USR_REPORT_SWITCH && (User.shared().bHasStartGooglePint || (User.shared().bHasStartGooglePint = true, this.pingRequestTime2 = sys.now(), HttpManager.shared().doGetNewWorkDelay2(((a, t, i) => {
            200 != i || (ToolUtils.netDelay2 = sys.now() - User.shared().pingRequestTime2);
        })), setTimeout((() => {
            User.shared().bHasStartGooglePint = false;
            User.shared().getNetDelayMs2();
        }), 5000)));
    }
    requestFlopCashTaskInfo() {
        HttpManager.shared().doGetCommonRequest(null, HttpRequest.FlopCashTaskList, ((e, a, t) => {
            if (200 != t) {
                ;
            }
            else {
                let e = ToolUtils.parseJson(a);
                0 == e.ret && (this.flopCashTaskData = e.data, PushCenter.shared().pushEvent(PushEvent.RefreshFlopCashTask));
            }
        }));
    }
    requestNovicesTaskInfo() {
        HttpManager.shared().doGetCommonRequest(null, HttpRequest.NovicesTaskList, ((e, a, t) => {
            if (200 != t) {
                ;
            }
            else {
                let e = ToolUtils.parseJson(a);
                0 == e.ret && (this.novicesTaskData = e);
            }
        }));
    }
    requestRoomDailyTaskList(e) {
        HttpManager.shared().doGetDailyTaskList(((e, a, t) => {
            if (200 != t) {
                ;
            }
            else {
                let e = ToolUtils.parseJson(a);
                0 == e.ret && (this.roomDailyTaskListData = e);
            }
        }));
    }
    requestCrazyCashbackMain() {
        HttpManager.shared().doGetCommonRequest(null, HttpRequest.CrazyCashBackMain, ((e, a, t) => {
            if (200 != t) {
                ;
            }
            else {
                let e = ToolUtils.parseJson(a);
                0 == e.ret && (this.crazyCashbackData = e.data, PushCenter.shared().pushEvent(PushEvent.RefreshCrazyCashBack));
            }
        }));
    }
    requestGetCbTimeout(e = 0) {
        HttpManager.shared().doGetCommonRequest({ vid: e }, HttpRequest.HallGetCbTimeout, ((e, a, t) => {
            if (200 != t) {
                ;
            }
            else {
                let e = ToolUtils.parseJson(a);
                if (0 == e.ret && e.data.list && "object" == typeof e.data.list) {
                    for (let a = 0, t = e.data.list.length; a < t; a++) {
                        const t = e.data.list[a];
                        this.delayPayMsg.push(t);
                    }
                    this.popNextRewardTips();
                }
            }
        }));
    }
    popNextRewardTips() {
        if (!Utils.shared().isRewardTipsShow()) {
            if (this.delayPayMsg.length > this.delayPayIndex) {
                let e = this.delayPayMsg[this.delayPayIndex], a = e.msg, t = 2;
                sys.isObjectValid(e.low) && 1 == e.low && (t = 1);
                this.showChargeReward(e.reward_list, (e => {
                    this.delayPayIndex = this.delayPayIndex + 1;
                    PushCenter.shared().pushEvent(PushEvent.PopNextRewardTip);
                }), a, t);
            }
            else {
                this.delayPayMsg = [];
                this.delayPayIndex = 0;
            }
        }
    }
    showNextCommonRewardTips() {
        if (this.commonRewardMsgs.length > this.rewardIndex) {
            let e = this.commonRewardMsgs[this.rewardIndex];
            Utils.shared().showRewardTips(e, (e => {
                this.rewardIndex = this.rewardIndex + 1;
                PushCenter.shared().pushEvent(PushEvent.ShowNextCommonRewardTip);
            }), 1, "reward_tips.okey");
        }
        else {
            this.commonRewardMsgs = [];
            this.rewardIndex = 0;
        }
    }
    requestGetMemberShipBlind() {
        let e = AppInfo.shared().getAppInstallData();
        if (e.hasInstall && e.channelId.length > 0) {
            let a = e.channelId, t = ToolUtils.isSafeString(localStorage.getItem("dp_datafrom"));
            HttpManager.shared().doGetCommonRequest({ invite_code: a, bind_source: t, isregister: ToolUtils.isregister }, HttpRequest.MemberShipBlind, ((e, a, t) => {
                if (200 != t) {
                    ;
                }
                else {
                    ToolUtils.parseJson(a);
                }
            }));
        }
        AppInfo.shared().getInstallRefer(false);
        let a = AppInfo.shared().getInstallRefer();
        if (a.length > 0) {
            let e = ToolUtils.isSafeString(localStorage.getItem("gp_datafrom"));
            HttpManager.shared().doGetCommonRequest({ invite_code: a, bind_source: e, isregister: ToolUtils.isregister }, HttpRequest.MemberShipBlind, ((e, a, t) => {
                if (200 != t) {
                    ;
                }
                else {
                    ToolUtils.parseJson(a);
                }
            }));
        }
    }
    shareImageAndTextToThirdApp(e, a, t, s, i) {
        if (1 == e) {
            1 === AppInfo.shared().checkPackageInstalled("com.whatsapp") ? AppInfo.shared().shareToWhatsapp2("User", this, "doShareCallBack2", t, a, MD5.Instance.hex_md5(a) + ".png") : Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text48"), 2);
        }
        else if (2 == e) {
            Utils.shared().showLoading(10, true, (() => {
                Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
            }), ToolUtils.getIsNormalDirection());
            Utils.shared().updateNetImage(null, a, null, ((e, s) => {
                Utils.shared().hideLoading();
                AppInfo.shared().shareToFacebook2("User", this, "doShareCallBack2", t, s, MD5.Instance.hex_md5(a) + ".png");
            }));
            AppInfo.shared().copyContent(t);
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text33"), 2);
        }
        else if (3 == e) {
            Utils.shared().showLoading(10, true, (() => {
                Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
            }), ToolUtils.getIsNormalDirection());
            Utils.shared().updateNetImage(null, a, null, ((e, s) => {
                Utils.shared().hideLoading();
                AppInfo.shared().shareToTwitter2("User", this, "doShareCallBack2", t, s, MD5.Instance.hex_md5(a) + ".png");
            }));
            AppInfo.shared().copyContent(t);
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text33"), 2);
        }
        else if (4 == e) {
            if (1 !== AppInfo.shared().checkPackageInstalled("org.telegram.messenger") && 1 !== AppInfo.shared().checkPackageInstalled("org.telegram.messenger.web")) {
                return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text90"), 2);
            }
            AppInfo.shared().copyContent(t);
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text33"), 2);
            let e = "";
            1 === AppInfo.shared().checkPackageInstalled("org.telegram.messenger") ? AppInfo.shared().shareToTelegram2("User", this, "doShareCallBack2", t, a, e, MD5.Instance.hex_md5(a) + ".png", "org.telegram.messenger") : 1 === AppInfo.shared().checkPackageInstalled("org.telegram.messenger.web") && AppInfo.shared().shareToTelegram2("User", this, "doShareCallBack2", t, a, e, MD5.Instance.hex_md5(a) + ".png", "org.telegram.messenger.web");
        }
    }
    doShareCallBack2(e) {
        PushCenter.shared().pushEvent(PushEvent.ShareSuccess);
    }
    setGameRaceid(e, a = true, t) {
        if (this.game_raceid && e) {
            for (let t = 0, s = this.game_raceid.length; t < s; t++) {
                if (this.game_raceid[t] == e) {
                    if (a) {
                        return;
                    }
                    this.game_raceid.splice(t, 1);
                    break;
                }
            }
            a && this.game_raceid.push(e);
        }
        t && (this.game_raceid = []);
    }
    requestGetLocationStatus() {
        if (0 === this.data.uid) {
            return;
        }
        let e = { latitude: AppInfo.shared().getLatitude(), longitude: AppInfo.shared().getLongitude() };
        HttpManager.shared().doGetCommonRequest(e, HttpRequest.GetLocationStatus, ((e, a, t) => {
            if (200 != t) {
                ;
            }
            else {
                let e = ToolUtils.parseJson(a);
                0 == e.ret && (this.data.location_status = e.data.location_status, sys.isObjectValid(e.data.chip_location_status) && (this.data.chip_location_status = e.data.chip_location_status), sys.isObjectValid(e.data.kyc_otp_pop) && (this.data.kyc_otp_pop = e.data.kyc_otp_pop));
            }
        }));
    }
    checkIsPermitArea(e) {
        return 1 === (e == CheckModule.CHIPS_PLAY ? this.data.chip_location_status : this.data.location_status);
    }
    checkLocationPermit(e = 0, a = 0, t = true) {
        if (0 == this.is_check_location) {
            return true;
        }
        let r = e == CheckModule.CHIPS_PLAY ? this.data.chip_location_status : this.data.location_status;
        if (1 != r) {
            let s = "moudule_" + e;
            if (undefined !== this.check_list[s] && 1 === this.check_list[s].location_status && Utils.shared().showLocationTipsAlert(e, null, a, t)) {
                return false;
            }
        }
        if (this.checkIsPermitArea(e)) {
            return true;
        }
        if (Utils.shared().showLocationTipsAlert(e, null, a, t)) {
            return false;
        }
        {
            let a = true, h = "moudule_" + e;
            if (undefined !== this.check_list[h]) {
                if (1 === this.check_list[h].location_status || 3 === this.check_list[h].location_status) {
                    return true;
                }
                let e = CommDefine.LocationForbidTime + h;
                if (2 === r) {
                    if (1 === this.check_list[h].forbidden_pop_limit) {
                        a = false;
                        ToolUtils.saveData(e, "" + sys.now());
                    }
                    else if (2 === this.check_list[h].forbidden_pop_limit) {
                        let t = ToolUtils.isSafeString(sys.localStorage.getItem(e));
                        "" !== t && ToolUtils.isToday(Number(t)) ? a = true : (a = false, ToolUtils.saveData(e, "" + sys.now()));
                    }
                    else if (3 === this.check_list[h].forbidden_pop_limit) {
                        "" !== ToolUtils.isSafeString(sys.localStorage.getItem(e)) ? a = true : (a = false, ToolUtils.saveData(e, "" + sys.now()));
                    }
                    else {
                        4 === this.check_list[h].forbidden_pop_limit && (a = true);
                    }
                }
            }
            if (!a) {
                let a = director.getScene().getChildByName("Canvas");
                if (director.getScene().name == BundleNameDefined.hall_scene) {
                    let e = director.getScene().getChildByName("Canvas");
                    (e.getChildByName("reward_tips_10Cash") || e.getChildByName("node_guide") && e.getChildByName("node_guide").active) && e.getChildByName("tips_node") && (a = e.getChildByName("tips_node"));
                }
                if (e != CheckModule.LOGIN) {
                    CheckModule.RECHARGE;
                    t && Utils.shared().showCustomLocationGuide(a, 2, e);
                }
                else {
                    let e = { bLandscape: ToolUtils.getIsNormalDirection(), bWithCancel: false, strContent: i18nMgr.shared().getValueByKey("utlis.area_tip"), strTitle: i18nMgr.shared().getValueByKey("cash_help.tips"), sureKey: "store.confirm", kefu: true };
                    e.parent_node = a;
                    Utils.shared().showCommonAlert(e, (e => {
                        1 == e && AppInfo.shared().getLocationInfo();
                    }));
                }
            }
            return a;
        }
    }
    checkHasLocationPermit(e = 0) {
        if (0 == this.is_check_location) {
            return true;
        }
        let a = "moudule_" + e;
        if (undefined !== this.check_list[a] && 1 === this.check_list[a].location_status) {
            return true;
        }
        if (this.checkIsPermitArea(e)) {
            return true;
        }
        if (Utils.shared().checkCanShowLocationAlert(e)) {
            return false;
        }
        {
            let a = true, t = "moudule_" + e;
            if (undefined !== this.check_list[t]) {
                if (1 === this.check_list[t].location_status || 3 === this.check_list[t].location_status) {
                    return true;
                }
                let i = CommDefine.LocationForbidTime + t;
                if (2 === (e == CheckModule.CHIPS_PLAY ? this.data.chip_location_status : this.data.location_status)) {
                    if (1 === this.check_list[t].forbidden_pop_limit) {
                        a = false;
                    }
                    else if (2 === this.check_list[t].forbidden_pop_limit) {
                        let e = ToolUtils.isSafeString(sys.localStorage.getItem(i));
                        a = !("" === e || !ToolUtils.isToday(Number(e)));
                    }
                    else if (3 === this.check_list[t].forbidden_pop_limit) {
                        a = "" !== ToolUtils.isSafeString(sys.localStorage.getItem(i));
                    }
                    else {
                        4 === this.check_list[t].forbidden_pop_limit && (a = true);
                    }
                }
            }
            return a;
        }
    }
    checkKyc(e = 0, a) {
        return true;
    }
    checkHasKyc(e = 0) {
        if (sys.isNative || (this.data.kyc_open = 0), 0 === this.data.kyc_open) {
            return true;
        }
        if (2 !== this.data.kyc_check) {
            let a = true, t = "moudule_" + e, i = CommDefine.KycGuideTime + t;
            if (undefined !== this.check_list[t]) {
                let e = this.check_list[t].kyc_pop_limit;
                if (1 === e) {
                    a = false;
                }
                else if (2 === e) {
                    let e = ToolUtils.isSafeString(sys.localStorage.getItem(i));
                    a = !("" === e || !ToolUtils.isToday(Number(e)));
                }
                else if (3 === e) {
                    "" === ToolUtils.isSafeString(sys.localStorage.getItem(i)) && (a = false);
                }
                else {
                    4 === e && (a = true);
                }
            }
            return a;
        }
        return 1 !== this.data.kyc_otp_pop || e != CheckModule.RECHARGE && e != CheckModule.CASH_PLAY && e != CheckModule.CHIPS_PLAY || 2 === this.data.kyc_otp_check;
    }
    checkCanPlayCashGame(e = 0, a) {
        this.checkLocationPermit(e);
        return true;
    }
    checkRoomCanPlayCashGame(e = 0, a = true) {
        return 2;
    }
    isCanPlayCashGame() {
        let e = this.checkHasLocationPermit(CheckModule.CASH_PLAY), a = this.checkHasKyc(CheckModule.CASH_PLAY);
        return !(!e || !a);
    }
    checkOnlyKyc() {
        return true;
    }
    doGetKycVerifyList() {
        AppInfo.shared().getIsNewKyc() ? HttpManager.shared().doGetKycVerifyList2(((a, t, i) => {
            try {
                if (200 != i) {
                    alert("The login timed out, please try again");
                }
                else {
                    let a = ToolUtils.parseJson(t);
                    0 == a.ret && (this.data.kyc_check = a.data.kyc_check, this.data.kyc_imgPath = a.data.kyc_img_url, this.data.card_check = a.data.card_check, this.data.card_check_type = a.data.card_check_type, this.data.kyc_update_status = a.data.kyc_update_status, this.data.kyc_list = a.data.list, this.data.show_resubmit = a.data.show_resubmit, this.data.resubmit_tips = a.data.resubmit_tips, this.data.resubmit_status = a.data.resubmit_status, sys.isObjectValid(a.data.kyc_otp_check) && (this.data.kyc_otp_check = a.data.kyc_otp_check), PushCenter.shared().pushEvent(GameConfig.Update_Kyc, User.shared().data.kyc_check));
                }
            }
            catch (e) {
                TLog.printError("listenGetKycVerifyListCallback:", e);
            }
        })) : HttpManager.shared().doGetKycVerifyList(((e, a, t) => {
            try {
                if (200 != t) {
                    alert("The login timed out, please try again");
                }
                else {
                    let e = ToolUtils.parseJson(a);
                    0 == e.ret && (this.data.kyc_check = e.data.kyc_check, this.data.kyc_imgPath = e.data.kyc_img_url, this.data.card_check = e.data.card_check, this.data.kyc_update_status = e.data.kyc_update_status, this.data.kyc_list = e.data.list);
                }
            }
            catch (e) {
                TLog.printError("listenGetKycVerifyListCallback2:", e);
            }
        }));
    }
    doGetKycAccount() {
        AppInfo.shared().getIsNewKyc() ? HttpManager.shared().doGetKycAccount2(((e, a, t) => {
            try {
                if (200 != t) {
                    alert("The login timed out, please try again");
                }
                else {
                    let e = ToolUtils.parseJson(a);
                    0 == e.ret && (this.newKycData = e.data, PushCenter.shared().pushEvent(PushEvent.RefreshKycList));
                }
            }
            catch (e) {
                TLog.printError("listen doGetKycAccount2 Callback err:", e);
            }
        })) : HttpManager.shared().doGetKycAccount(((e, a, t) => {
            try {
                if (200 != t) {
                    alert("The login timed out, please try again");
                }
                else {
                    let e = ToolUtils.parseJson(a);
                    0 == e.ret && (this.data.kyc_data = e.data, this.setUserRealName());
                }
            }
            catch (e) {
                TLog.printError("listen doGetKycAccount Callback err:", e);
            }
        }));
    }
    doGetPanCardInfo() {
        AppInfo.shared().getIsNewKyc() ? HttpManager.shared().doGetPanCardInfo2(((a, t, s) => {
            try {
                if (200 != s) {
                    alert("The login timed out, please try again");
                }
                else {
                    let a = ToolUtils.parseJson(t);
                    0 == a.ret && (User.shared().pancard_data = a.data, PushCenter.shared().pushEvent(PushEvent.Update_PanInfo));
                }
            }
            catch (e) {
                TLog.printError("listenGetPanCardInfoCallback:", e);
            }
        })) : HttpManager.shared().doGetPanCardInfo(((e, a, t) => {
            try {
                if (200 != t) {
                    alert("The login timed out, please try again");
                }
                else {
                    let e = ToolUtils.parseJson(a);
                    0 == e.ret && (this.pancard_data = e.data, this.setUserRealName(), PushCenter.shared().pushEvent(PushEvent.Update_PanInfo));
                }
            }
            catch (e) {
                TLog.printError("listenGetPanCardInfoCallback:", e);
            }
        }));
    }
    doGetKycPanInfo() {
        HttpManager.shared().doGetKycFormItem(((a, t, i) => {
            try {
                if (200 != i) {
                    alert("The login timed out, please try again");
                }
                else {
                    let a = ToolUtils.parseJson(t);
                    if (0 == a.ret) {
                        let t = a.data.kyc_item;
                        sys.isObjectValid(a.data.cash_left_x) && (this.data.cash_left_x = Number(a.data.cash_left_x));
                        sys.isObjectValid(a.data.submit_left_seconds) && (this.data.submit_left_hour = Number(a.data.submit_left_seconds));
                        sys.isObjectValid(t) && (this.data.kyc_check = t.kyc_check, this.data.kyc_imgPath = t.kyc_img_url, this.data.card_check = t.card_check, this.data.card_check_type = t.card_check_type, this.data.kyc_update_status = t.kyc_update_status, this.data.kyc_list = t.list, this.data.show_resubmit = t.show_resubmit, this.data.resubmit_tips = t.resubmit_tips, this.data.resubmit_status = t.resubmit_status, sys.isObjectValid(t.kyc_otp_check) && (this.data.kyc_otp_check = t.kyc_otp_check), PushCenter.shared().pushEvent(GameConfig.Update_Kyc, User.shared().data.kyc_check));
                        sys.isObjectValid(a.data.kyc_form) && (this.newKycData = a.data.kyc_form, PushCenter.shared().pushEvent(PushEvent.RefreshKycList));
                        sys.isObjectValid(a.data.pan_submit_left_hour) && (this.data.pan_submit_left_hour = Number(a.data.pan_submit_left_hour));
                        sys.isObjectValid(a.data.pan) && (User.shared().pancard_data = a.data.pan, PushCenter.shared().pushEvent(PushEvent.Update_PanInfo));
                    }
                }
            }
            catch (e) {
                TLog.printError("listenGetKycPanInfoCallback:", e);
            }
        }));
    }
    doGetKycResubmitInfo(e = null) {
        HttpManager.shared().doGetCommonRequest(null, "ResubmitKyc.page", ((a, t, s) => {
            if (200 == s) {
                let e = ToolUtils.parseJson(t);
                0 == e.ret && (this.kyc_resubmit_data = e.data, PushCenter.shared().pushEvent(PushEvent.UpdateKycResubmit));
            }
            e && e(t, s);
        }));
    }
    doGetActGoldenLinksInfo(e = null) {
        HttpManager.shared().doGetCommonRequest(null, "Activity.Act_122.page", ((a, t, s) => {
            if (200 == s) {
                let e = ToolUtils.parseJson(t);
                0 == e.ret && (this.golden_link_data = e.data);
            }
            e && e(t, s);
        }));
    }
    doGetActMarketInviteInfo(e = null) {
        HttpManager.shared().doGetCommonRequest(null, "Activity.Act_100.page", ((a, t, s) => {
            if (200 == s) {
                let e = ToolUtils.parseJson(t);
                0 == e.ret && (this.marketInviteData = e.data, ToolUtils.isSafeString(this.marketInviteData.img).length > 0 && Utils.shared().downNetImage(this.marketInviteData.img));
            }
            e && e(t, s);
        }));
    }
    doGetModuleSwitchInfo() {
        HttpManager.shared().doGetModuleSwitch(((e, a, t) => {
            try {
                if (200 != t) {
                    alert("The login timed out, please try again");
                }
                else {
                    let e = ToolUtils.parseJson(a);
                    0 == e.ret && this.dealAppStartSwitchInfo(e.data);
                }
            }
            catch (e) {
                TLog.printError("listenGetModuleSwitchInfoListCallback:", e);
            }
        }));
    }
    dealAppStartSwitchInfo(a) {
        if (User.shared().bHasGetSwitchInfo = true, sys.isObjectValid(a.list) && sys.isObjectValid(a.list[0])) {
            let e = a.list[0];
            this.dealSw_cfgListdata(e);
        }
        this.getHelpSettingData(a);
    }
    dealSw_cfgListdata(a, t = 0) {
        sys.isObjectValid(a.performance) && (User.shared().temp_pingbi.performance = 1 == a.performance ? 0 : 1);
        sys.isObjectValid(a.performance_playback) && (User.shared().temp_pingbi.performance_playback = 1 == a.performance_playback ? 0 : 1);
        sys.isObjectValid(a.recommend) && (User.shared().temp_pingbi.recommend = 1 == a.recommend ? 0 : 1);
        sys.isObjectValid(a.tickets) && (User.shared().temp_pingbi.tickets = 1 == a.tickets ? 0 : 1);
        sys.isObjectValid(a.match_ticket) && (User.shared().temp_pingbi.match_ticket = 1 == a.match_ticket ? 0 : 1);
        sys.isObjectValid(a.me_add_cash) && (User.shared().temp_pingbi.me_add_cash = 1 == a.me_add_cash ? 0 : 1);
        sys.isObjectValid(a.lang) && (User.shared().temp_pingbi.loginLanguage = 1 == a.lang ? 0 : 1);
        sys.isObjectValid(a.daily) && (User.shared().temp_pingbi.dailytask = 1 == a.daily ? 0 : 1);
        sys.isObjectValid(a.new_player) && (User.shared().temp_pingbi.xstask = 1 == a.new_player ? 0 : 1);
        sys.isObjectValid(a.activity) && (User.shared().temp_pingbi.activity = 1 == a.activity ? 0 : 1);
        sys.isObjectValid(a.refer_earn) && (User.shared().temp_pingbi.referearn = 1 == a.refer_earn ? 0 : 1);
        sys.isObjectValid(a.user_info) && (User.shared().temp_pingbi.userinfo = 1 == a.user_info ? 0 : 1);
        sys.isObjectValid(a.guess_card) && (User.shared().temp_pingbi.guess_card = 1 == a.guess_card ? 0 : 1);
        sys.isObjectValid(a.sclb) && (User.shared().temp_pingbi.sclb = 1 == a.sclb ? 0 : 1);
        sys.isObjectValid(a.act_108) && (User.shared().temp_pingbi.twentyhour = 1 == a.act_108 ? 0 : 1);
        sys.isObjectValid(a.cclb) && (User.shared().temp_pingbi.cclb = 1 == a.cclb ? 0 : 1);
        sys.isObjectValid(a.store) && (User.shared().temp_pingbi.store = 1 == a.store ? 0 : 1);
        sys.isObjectValid(a.club) && (User.shared().temp_pingbi.club = 1 == a.club ? 0 : 1);
        sys.isObjectValid(a.withdraw) && (User.shared().temp_pingbi.withdraw = 1 == a.withdraw ? 0 : 1);
        sys.isObjectValid(a.guest) && (User.shared().temp_pingbi.guestlogin = 1 == a.guest ? 0 : 1);
        sys.isObjectValid(a.fblogin) && (User.shared().temp_pingbi.fblogin = 1 == a.fblogin ? 0 : 1, PushCenter.shared().pushEvent(PushEvent.Update_FBLogin));
        sys.isObjectValid(a.register) && (User.shared().temp_pingbi.register = 1 == a.register ? 0 : 1);
        sys.isObjectValid(a.match) && (User.shared().temp_pingbi.matchgame = 1 == a.match ? 0 : 1);
        sys.isObjectValid(a.buddy) && (User.shared().temp_pingbi.buddygame = 1 == a.buddy ? 0 : 1);
        sys.isObjectValid(a.feedback) && (User.shared().temp_pingbi.feedback = 1 == a.feedback ? 0 : 1);
        sys.isObjectValid(a.add_cash_limits) && (User.shared().temp_pingbi.add_cash_limits = 1 == a.add_cash_limits ? 0 : 1);
        sys.isObjectValid(a.match_show) && (User.shared().temp_pingbi.matchshow = 1 == a.match_show ? 0 : 1);
        sys.isObjectValid(a.tds) && (User.shared().temp_pingbi.tds = 1 == a.tds ? 0 : 1);
        sys.isObjectValid(a.tds_me) && (User.shared().temp_pingbi.tds_me = 1 == a.tds_me ? 0 : 1);
        sys.isObjectValid(a.rank) && (User.shared().inner_rank_open = 1 == a.rank);
        sys.isObjectValid(a.delay) && (User.shared().sigal_delay_show = 1 == a.delay);
        sys.isObjectValid(a.points_mode) && (User.shared().easy_mode_show = 1 == a.points_mode);
        sys.isObjectValid(a.googlelogin) && (User.shared().temp_pingbi.googlelogin = 1 == a.googlelogin ? 0 : 1);
        sys.isObjectValid(a.me_del_account) && (User.shared().me_del_account = a.me_del_account);
        sys.isObjectValid(a.profile_del_account) && (User.shared().profile_del_account = a.profile_del_account);
        sys.isObjectValid(a.private_share_open) && (User.shared().private_share_open = 1 == a.private_share_open);
        sys.isObjectValid(a.mall_gift) && (User.shared().mall_gift = 1 == a.mall_gift);
        sys.isObjectValid(a.mall_lottery) && (User.shared().mall_lottery = 1 == a.mall_lottery);
        sys.isObjectValid(a.act_54_report) && (User.shared().act_54_report = 1 == a.act_54_report);
        sys.isObjectValid(a.act_68_report) && (User.shared().act_68_report = 1 == a.act_68_report);
        sys.isObjectValid(a.act_65_report) && (User.shared().act_65_report = 1 == a.act_65_report);
        sys.isObjectValid(a.act_66_report) && (User.shared().act_66_report = 1 == a.act_66_report);
        sys.isObjectValid(a.act_83_report) && (User.shared().act_83_report = 1 == a.act_83_report);
        sys.isObjectValid(a.act_73) && (User.shared().act_73 = a.act_73);
        sys.isObjectValid(a.act_73_report) && (User.shared().act_73_report = a.act_73_report);
        sys.isObjectValid(a.act_74_report) && (User.shared().act_74_report = a.act_74_report);
        sys.isObjectValid(a.act_79) && (User.shared().act_79 = a.act_79);
        sys.isObjectValid(a.multiple_rummy_open) && (User.shared().multiple_rummy_open = a.multiple_rummy_open);
        sys.isObjectValid(a.multiple_2_open) && (User.shared().multiple_2_open = a.multiple_2_open);
        sys.isObjectValid(a.bump_rummy_open) && (User.shared().bump_rummy_open = a.bump_rummy_open);
        sys.isObjectValid(a.lucky_box) && (User.shared().lucky_box = a.lucky_box);
        sys.isObjectValid(a.me_gst) && (User.shared().temp_pingbi.gst_me = 1 == a.me_gst ? 0 : 1);
        sys.isObjectValid(a.tds_bubble) && (User.shared().temp_pingbi.tds_bubble = 1 == a.tds_bubble ? 0 : 1);
        sys.isObjectValid(a.chip_hall_give) && (User.shared().chip_hall_give = a.chip_hall_give);
        sys.isObjectValid(a.chip_bump_rummy_open) && (User.shared().chip_bump_rummy_open = a.chip_bump_rummy_open);
        sys.isObjectValid(a.chip_bump_2_open) && (User.shared().chip_bump_2_open = a.chip_bump_2_open);
        sys.isObjectValid(a.chip_bump_6_open) && (User.shared().chip_bump_6_open = a.chip_bump_6_open);
        sys.isObjectValid(a.chip_multiple_rummy_open) && (User.shared().chip_multiple_rummy_open = a.chip_multiple_rummy_open);
        sys.isObjectValid(a.chip_multiple_2_open) && (User.shared().chip_multiple_2_open = a.chip_multiple_2_open);
        sys.isObjectValid(a.bump_2_open) && (User.shared().bump_2_open = a.bump_2_open);
        sys.isObjectValid(a.bump_6_open) && (User.shared().bump_6_open = a.bump_6_open);
        sys.isObjectValid(a.tawk_open) && (User.shared().tawk_open = a.tawk_open);
        sys.isObjectValid(a.feedback_sw) && (User.shared().feedback_sw = a.feedback_sw);
        sys.isObjectValid(a.backpack) && (User.shared().backpack = a.backpack);
        sys.isObjectValid(a.history_data_open) && (User.shared().history_data_open = a.history_data_open);
        sys.isObjectValid(a.act_135) && (User.shared().custom_sel_gift_open = a.act_135);
        sys.isObjectValid(a.act_137) && (User.shared().treasuredraw_open = a.act_137);
        sys.isObjectValid(a.double_6_open) && (User.shared().double_6_open = a.double_6_open);
        sys.isObjectValid(a.chip_double_6_open) && (User.shared().chip_double_6_open = a.chip_double_6_open);
        sys.isObjectValid(a.me_wallet) && (User.shared().temp_pingbi.me_wallet = 1 == a.me_wallet ? 0 : 1);
        sys.isObjectValid(a.g_delay) && (User.shared().g_delay = 1 == a.g_delay, User.shared().g_delay && 0 == t && User.shared().getNetDelayMs2());
        PushCenter.shared().pushEvent(GameConfig.update_Module_Switch);
    }
    getHelpSettingData(a) {
        if (sys.isObjectValid(a.help_setting)) {
            let t = a.help_setting;
            if (sys.isObjectValid(t.auto_sort_pop)) {
                let a = sys.localStorage.getItem("autoSortCount");
                (null == a || Number(a) > t.auto_sort_pop.cnt) && ToolUtils.saveData("autoSortCount", t.auto_sort_pop.cnt);
                User.shared().auto_sort_tips = 1 == t.auto_sort_pop.sw;
            }
            if (sys.isObjectValid(t.open_deck_pick) && (sys.isObjectValid(t.open_deck_pick.sw) && (User.shared().help_setting.open_deck_pick = t.open_deck_pick.sw), sys.isObjectValid(t.open_deck_pick.def) && (User.shared().help_setting.open_deck_pick_def = t.open_deck_pick.def), sys.isObjectValid(t.open_deck_pick.refresh_ver) && t.open_deck_pick.refresh_ver > 0)) {
                let e = sys.localStorage.getItem("open_deck_pick_ver");
                (null == e || Number(ToolUtils.isSafeString(e)) < t.open_deck_pick.refresh_ver) && sys.localStorage.removeItem("open_deck_pick_def");
                ToolUtils.saveData("open_deck_pick_ver", t.open_deck_pick.refresh_ver + "");
            }
            if (0 == User.shared().help_setting.open_deck_pick && sys.localStorage.removeItem("open_deck_pick_def"), sys.isObjectValid(t.discard) && (sys.isObjectValid(t.discard.sw) && (User.shared().help_setting.discard = t.discard.sw), sys.isObjectValid(t.discard.def) && (User.shared().help_setting.discard_def = t.discard.def), sys.isObjectValid(t.discard.refresh_ver) && t.discard.refresh_ver > 0)) {
                let e = sys.localStorage.getItem("discard_ver");
                (null == e || Number(ToolUtils.isSafeString(e)) < t.discard.refresh_ver) && sys.localStorage.removeItem("discard_def");
                ToolUtils.saveData("discard_ver", t.discard.refresh_ver + "");
            }
            if (0 == User.shared().help_setting.discard && sys.localStorage.removeItem("discard_def"), sys.isObjectValid(t.finish_card_number) && (sys.isObjectValid(t.finish_card_number.sw) && (User.shared().help_setting.finish_card_number = t.finish_card_number.sw), sys.isObjectValid(t.finish_card_number.def) && (User.shared().help_setting.finish_card_number_def = t.finish_card_number.def), sys.isObjectValid(t.finish_card_number.refresh_ver) && t.finish_card_number.refresh_ver > 0)) {
                let e = sys.localStorage.getItem("finish_card_number_ver");
                (null == e || Number(ToolUtils.isSafeString(e)) < t.finish_card_number.refresh_ver) && sys.localStorage.removeItem("finish_card_number_def");
                ToolUtils.saveData("finish_card_number_ver", t.finish_card_number.refresh_ver + "");
            }
            if (0 == User.shared().help_setting.finish_card_number && sys.localStorage.removeItem("finish_card_number_def"), sys.isObjectValid(t.finish_conditions) && (sys.isObjectValid(t.finish_conditions.sw) && (User.shared().help_setting.finish_conditions = t.finish_conditions.sw), sys.isObjectValid(t.finish_conditions.def) && (User.shared().help_setting.finish_conditions_def = t.finish_conditions.def), sys.isObjectValid(t.finish_conditions.refresh_ver) && t.finish_conditions.refresh_ver > 0)) {
                let e = sys.localStorage.getItem("finish_conditions_ver");
                (null == e || Number(ToolUtils.isSafeString(e)) < t.finish_conditions.refresh_ver) && sys.localStorage.removeItem("finish_conditions_def");
                ToolUtils.saveData("finish_conditions_ver", t.finish_conditions.refresh_ver + "");
            }
            if (0 == User.shared().help_setting.finish_conditions && sys.localStorage.removeItem("finish_conditions_def"), sys.isObjectValid(t.quick_finish) && (sys.isObjectValid(t.quick_finish.sw) && (User.shared().help_setting.quick_finish = t.quick_finish.sw), sys.isObjectValid(t.quick_finish.def) && (User.shared().help_setting.quick_finish_def = t.quick_finish.def), sys.isObjectValid(t.quick_finish.refresh_ver) && t.quick_finish.refresh_ver > 0)) {
                let e = sys.localStorage.getItem("quick_finish_ver");
                (null == e || Number(ToolUtils.isSafeString(e)) < t.quick_finish.refresh_ver) && sys.localStorage.removeItem("quick_finish_def");
                ToolUtils.saveData("quick_finish_ver", t.quick_finish.refresh_ver + "");
            }
            if (0 == User.shared().help_setting.quick_finish && sys.localStorage.removeItem("quick_finish_def"), sys.isObjectValid(t.card_rating) && (sys.isObjectValid(t.card_rating.sw) && (User.shared().help_setting.card_rating = t.card_rating.sw), sys.isObjectValid(t.card_rating.def) && (User.shared().help_setting.card_rating_def = t.card_rating.def), sys.isObjectValid(t.card_rating.refresh_ver) && t.card_rating.refresh_ver > 0)) {
                let e = sys.localStorage.getItem("card_rating_ver");
                (null == e || Number(ToolUtils.isSafeString(e)) < t.card_rating.refresh_ver) && sys.localStorage.removeItem("card_rating_def");
                ToolUtils.saveData("card_rating_ver", t.card_rating.refresh_ver + "");
            }
            if (0 == User.shared().help_setting.card_rating && sys.localStorage.removeItem("card_rating_def"), sys.isObjectValid(t.multiple_card_rating) && (User.shared().help_setting.multiple_card_rating = t.multiple_card_rating), sys.isObjectValid(t.card_reading) && (sys.isObjectValid(t.card_reading.sw) && (User.shared().help_setting.card_reading = t.card_reading.sw), sys.isObjectValid(t.card_reading.def) && (User.shared().help_setting.card_reading_def = t.card_reading.def), sys.isObjectValid(t.card_reading.refresh_ver) && t.card_reading.refresh_ver > 0)) {
                let e = sys.localStorage.getItem("card_reading_ver");
                (null == e || Number(ToolUtils.isSafeString(e)) < t.card_reading.refresh_ver) && sys.localStorage.removeItem("card_reading_def");
                ToolUtils.saveData("card_reading_ver", t.card_reading.refresh_ver + "");
            }
            if (0 == User.shared().help_setting.card_reading && sys.localStorage.removeItem("card_reading_def"), sys.isObjectValid(t.sort_mode)) {
                if (sys.isObjectValid(t.sort_mode.sw) && (User.shared().help_setting.sort_mode = t.sort_mode.sw), sys.isObjectValid(t.sort_mode.def) && (User.shared().help_setting.sort_mode_def = t.sort_mode.def), sys.isObjectValid(t.sort_mode.refresh_ver) && t.sort_mode.refresh_ver > 0) {
                    let e = sys.localStorage.getItem("sort_mode_ver");
                    (null == e || Number(ToolUtils.isSafeString(e)) < t.sort_mode.refresh_ver) && sys.localStorage.removeItem("sort_mode_def");
                }
                ToolUtils.saveData("sort_mode_ver", t.sort_mode.refresh_ver + "");
            }
            if (0 == User.shared().help_setting.sort_mode && sys.localStorage.removeItem("sort_mode_def"), sys.isObjectValid(t.enter_anim)) {
                if (sys.isObjectValid(t.enter_anim.sw) && (User.shared().help_setting.enter_anim = t.enter_anim.sw), sys.isObjectValid(t.enter_anim.def) && (User.shared().help_setting.enter_anim_def = t.enter_anim.def), sys.isObjectValid(t.enter_anim.refresh_ver) && t.enter_anim.refresh_ver > 0) {
                    let e = sys.localStorage.getItem("enter_anim_ver");
                    (null == e || Number(ToolUtils.isSafeString(e)) < t.enter_anim.refresh_ver) && sys.localStorage.removeItem("enter_anim_def");
                }
                ToolUtils.saveData("enter_anim_ver", t.enter_anim.refresh_ver + "");
            }
            if (0 == User.shared().help_setting.enter_anim && sys.localStorage.removeItem("enter_anim_def"), sys.isObjectValid(t.play_effect)) {
                if (sys.isObjectValid(t.play_effect.sw) && (User.shared().help_setting.play_effect = t.play_effect.sw), sys.isObjectValid(t.play_effect.def) && (User.shared().help_setting.play_effect_def = t.play_effect.def), sys.isObjectValid(t.play_effect.refresh_ver) && t.play_effect.refresh_ver > 0) {
                    let e = sys.localStorage.getItem("play_effect_ver");
                    (null == e || Number(ToolUtils.isSafeString(e)) < t.play_effect.refresh_ver) && sys.localStorage.removeItem("play_effect_def");
                }
                ToolUtils.saveData("play_effect_ver", t.play_effect.refresh_ver + "");
            }
            if (0 == User.shared().help_setting.play_effect && sys.localStorage.removeItem("play_effect_def"), sys.isObjectValid(t.available_cards) && (sys.isObjectValid(t.available_cards.sw) && (User.shared().help_setting.available_cards = t.available_cards.sw), sys.isObjectValid(t.available_cards.def) && (User.shared().help_setting.available_cards_def = t.available_cards.def), sys.isObjectValid(t.available_cards.refresh_ver) && t.available_cards.refresh_ver > 0)) {
                let e = sys.localStorage.getItem("available_cards_ver");
                (null == e || Number(ToolUtils.isSafeString(e)) < t.available_cards.refresh_ver) && sys.localStorage.removeItem("available_cards_def");
                ToolUtils.saveData("available_cards_ver", t.available_cards.refresh_ver + "");
            }
            0 == User.shared().help_setting.available_cards && sys.localStorage.removeItem("available_cards_def");
        }
        sys.isObjectValid(a.uirp_1) && (User.shared().s_uirp_1 = a.uirp_1);
        sys.isObjectValid(a.uirp_2) && (User.shared().s_uirp_2 = a.uirp_2);
        sys.isObjectValid(a.uirp_3) && (User.shared().s_uirp_3 = a.uirp_3);
        sys.isObjectValid(a.uirp_4) && (User.shared().s_uirp_4 = a.uirp_4);
    }
    updateKycAccount(a) {
        if (null !== a && User.shared().data.kyc_data && User.shared().data.kyc_data.form_list && User.shared().data.kyc_data.form_list.length > 0) {
            for (let t = 0, s = User.shared().data.kyc_data.form_list.length; t < s; t++) {
                "card_type" == User.shared().data.kyc_data.form_list[t].form_name && (User.shared().data.kyc_data.form_list[t].val = a.card_type, User.shared().data.kyc_data.form_list[t].photo_frontend = a.photo_frontend, User.shared().data.kyc_data.form_list[t].photo_backend = a.photo_backend);
                "name" == User.shared().data.kyc_data.form_list[t].form_name && (User.shared().data.kyc_data.form_list[t].val = a.name);
                "sex" == User.shared().data.kyc_data.form_list[t].form_name && (User.shared().data.kyc_data.form_list[t].val = a.sex);
                "card" == User.shared().data.kyc_data.form_list[t].form_name && (User.shared().data.kyc_data.form_list[t].val = a.card);
                "birthday" == User.shared().data.kyc_data.form_list[t].form_name && (User.shared().data.kyc_data.form_list[t].val = a.birthday);
                "zip_code" == User.shared().data.kyc_data.form_list[t].form_name && (User.shared().data.kyc_data.form_list[t].val = a.zip_code);
                "province" == User.shared().data.kyc_data.form_list[t].form_name && (User.shared().data.kyc_data.form_list[t].val = a.province);
                "city" == User.shared().data.kyc_data.form_list[t].form_name && (User.shared().data.kyc_data.form_list[t].val = a.city);
                "address" == User.shared().data.kyc_data.form_list[t].form_name && (User.shared().data.kyc_data.form_list[t].val = a.address);
            }
        }
    }
    updateKycAccount2(a) {
        sys.isObjectValid(a) && (sys.isObjectValid(User.shared().newKycData.kyc_list) || (User.shared().newKycData.kyc_list = {}), ToolUtils.isSafeString(a.name).length > 0 && (User.shared().newKycData.kyc_list.name = a.name), ToolUtils.isSafeString(a.card).length > 0 && (User.shared().newKycData.kyc_list.card = a.card), ToolUtils.isSafeString(a.birthday).length > 0 && (User.shared().newKycData.kyc_list.birthday = a.birthday), ToolUtils.isSafeString(a.photo_frontend).length > 0 && (User.shared().newKycData.kyc_list.photo_frontend = a.photo_frontend), ToolUtils.isSafeString(a.photo_back).length > 0 && (User.shared().newKycData.kyc_list.photo_back = a.photo_back), ToolUtils.isSafeString(a.card_type).length > 0 && (User.shared().newKycData.kyc_list.card_type = a.card_type));
    }
    updatePayScene(e, a = 0) {
        this.payment_scene.scene = e;
        this.payment_scene.vid = a;
    }
    setUserRealName() {
        if (2 == User.shared().data.card_check && User.shared().data.kyc_data && User.shared().data.kyc_data.form_list && User.shared().data.kyc_data.form_list.length > 0) {
            for (let a = 0, t = User.shared().data.kyc_data.form_list.length; a < t; a++) {
                if ("name" == User.shared().data.kyc_data.form_list[a].form_name) {
                    return void (this.data.real_name = User.shared().data.kyc_data.form_list[a].val);
                }
            }
        }
        2 == User.shared().pan_check && sys.isObjectValid(User.shared().pancard_data) && sys.isObjectValid(User.shared().pancard_data.name) && (this.data.real_name = User.shared().pancard_data.name);
    }
    reSetHallBundleLoadState() {
        let e = [BundleNameDefined.gameMode_prefab, BundleNameDefined.menu_prefab, BundleNameDefined.invite_prefab, BundleNameDefined.leaderboard_prefab, BundleNameDefined.email_prefab];
        1 == GameConfig.GAME_HALL_THEME && (e = [BundleNameDefined.cricket_prefab, BundleNameDefined.gameMode_prefab]);
        for (let a = 0, t = e.length; a < t; a++) {
            this.hall_bundleMap.set(e[a], false);
        }
        this.hasPreload = false;
    }
    checkIfHasLoadHallBundle() {
        let e = [BundleNameDefined.gameMode_prefab, BundleNameDefined.menu_prefab, BundleNameDefined.invite_prefab, BundleNameDefined.leaderboard_prefab];
        1 == GameConfig.GAME_HALL_THEME && (e = [BundleNameDefined.cricket_prefab, BundleNameDefined.gameMode_prefab]);
        let a = 0;
        for (let t = 0, s = e.length; t < s; t++) {
            const s = e[t];
            this.hall_bundleMap.has(s) && this.hall_bundleMap.get(s) && a++;
        }
        return a === e.length;
    }
    requestLeaderBoarderMainFramePage() {
        HttpManager.shared().doGetCommonRequest({}, HttpRequest.HallRankMain, ((a, t, s) => {
            if (Utils.shared().hideLoading(), 200 != s) {
                ;
            }
            else {
                let a = ToolUtils.parseJson(t);
                0 == a.ret && (User.shared().hallLeaderBoardMainData = a.data, PushCenter.shared().pushEvent(PushEvent.RefreshHallLeaderBoardMain));
            }
        }));
    }
    dealLeadboardLogic_OptIn(a, t) {
        User.shared().requestRankActEntry(1, (t => {
            sys.isObjectValid(t) && sys.isObjectValid(t.status) && (User.shared().hallLeaderBoardMainData.entry_status = t.status, a && a(t.status));
        }));
    }
    dealLeadboardLogic_OptOut(a) {
        User.shared().requestRankActEntry(0, (t => {
            sys.isObjectValid(t) && sys.isObjectValid(t.status) && (User.shared().hallLeaderBoardMainData.entry_status = t.status, a && a(t.status));
        }));
    }
    requestUpdateRankAutoEntry(e, a) {
        HttpManager.shared().doGetCommonRequest({ status: e }, HttpRequest.HallLeaderBoardsPage_AutoEntry, ((t, i, r) => {
            if (Utils.shared().hideLoading(), 200 != r) {
                ;
            }
            else {
                0 == ToolUtils.parseJson(i).ret && (sys.isObjectValid(this.hallLeaderBoardMainData) && (this.hallLeaderBoardMainData.auto_entry_status = e), a && a(e));
            }
        }));
    }
    requestWallet() {
        let e = new Date, a = 0, t = 0, s = 0;
        a = e.getFullYear();
        t = e.getMonth() + 1;
        s = e.getDate();
        let i = a.toString() + String("0" + t).slice(-2) + String("0" + s).slice(-2), r = e.getTime();
        r -= 518400000;
        e.setTime(r);
        a = e.getFullYear();
        t = e.getMonth() + 1;
        s = e.getDate();
        let d = a.toString() + String("0" + t).slice(-2) + String("0" + s).slice(-2);
        HttpManager.shared().doReportWalletGetList("0", this.listenWalletCallback.bind(this), d, i);
    }
    listenWalletCallback(a, t, s) {
        if (0 != t.length) {
            if (200 != s) {
                ;
            }
            else {
                let a = ToolUtils.parseJson(t);
                0 == a.ret && (User.shared().walletResult = a);
            }
        }
    }
    requestSharePageData() {
        HttpManager.shared().doSharePage(this.listenGetSharePageCall.bind(this));
    }
    listenGetSharePageCall(a, t, s) {
        if (200 != s) {
            ;
        }
        else {
            let a = ToolUtils.parseJson(t);
            0 == a.ret && (User.shared().shareMainInfo = a.data);
        }
    }
    getGPUInfo() {
        director.root.device.renderer;
        director.root.device.vendor;
        director.root.device.memoryStatus;
        director.root.device.capabilities;
    }
    resetLabaSocket() {
        LabaServer.shared().reset();
    }
    popLabaSocket() {
        LabaServer.shared().pop_response();
    }
    popGmSocket() {
        Server.shared().pop_response();
    }
    onNativeEnterForceGround(a) {
        User.shared().popLabaSocket();
        User.shared().popGmSocket();
        User.shared().getFirebaseJumpType(true);
        let t = false;
        setTimeout((() => {
            a > 30 ? (User.shared().resetLabaSocket(), User.shared().startLabaTcp(), t = true, ToolUtils.judgeIfInHall() && (Server.shared().reset(), User.shared().preLinkGameGate())) : (User.shared().send_request_hall_tableinfo(), User.shared().requestEnterForeGround());
        }), 500);
        setTimeout((() => {
            PushCenter.shared().pushEvent(GameConfig.onEnterForeground);
            AppInfo.shared().checkDeepLinkMatchId();
            t && User.shared().requestEnterForeGround();
        }), 600);
        setTimeout((() => {
            User.shared().outTradeNo && (User.shared().outTradeNo = null);
            (ToolUtils.judgeIfInHall() || director.getScene().name == BundleNameDefined.rummy_scence) && User.shared().dealDeepLinkInfo();
        }), 800);
    }
    requestEnterBackGround() {
        let a = User.shared().data.uid;
        if (sys.isObjectValid(a) && 0 != a && LabaServer.shared().isEnable()) {
            let e = {};
            e.cmd = NetConfig.CLIENT_NOTIFY_CHANGE_AROUND;
            e.uid = this.data.uid;
            e.name = this.data.name;
            e.skey = this.getSkey();
            e.ver = GameConfig.Server_Api_Ver;
            e.online = 0;
            LabaServer.shared().send(e);
        }
    }
    requestEnterForeGround() {
        let a = User.shared().data.uid;
        if (sys.isObjectValid(a) && 0 != a && LabaServer.shared().isEnable()) {
            let e = {};
            e.cmd = NetConfig.CLIENT_NOTIFY_CHANGE_AROUND;
            e.uid = this.data.uid;
            e.name = this.data.name;
            e.skey = this.getSkey();
            e.ver = GameConfig.Server_Api_Ver;
            e.online = 1;
            LabaServer.shared().send(e);
        }
    }
    requestWithDrawPage(a) {
        HttpManager.shared().doGetCommonRequest({ mtype: a }, HttpRequest.WithdrawPage, ((a, t, s) => {
            if (Utils.shared().hideLoading(), 200 != s) {
                ;
            }
            else {
                let a = ToolUtils.parseJson(t);
                0 == a.ret && (User.shared().withdrawData = a.data, PushCenter.shared().pushEvent(PushEvent.RefreshWithdrawData));
            }
        }));
    }
    requestDepositTransferPage() {
        HttpManager.shared().doGetCommonRequest(null, HttpRequest.DepositTransferPage, ((a, t, s) => {
            if (200 != s) {
                ;
            }
            else {
                let a = ToolUtils.parseJson(t);
                0 == a.ret && (User.shared().DepositTransferData = a.data, PushCenter.shared().pushEvent(PushEvent.RefreshWithdrawData));
            }
        }));
    }
    getNativeAdjustId() {
        if (!sys.isNative || sys.os !== sys.OS.ANDROID && sys.os !== sys.OS.OHOS) {
            return;
        }
        if (1 == ToolUtils.isSafeNumber(this.data.is_report_adid)) {
            return;
        }
        if (!AppInfo.shared()._bInitAdjust) {
            return;
        }
        if ("" != ToolUtils.isSafeString(AppInfo.shared().getAdjust_Adid())) {
            return void this.reportRequestAdjust();
        }
        this.adjustSchedule && (TweenTool.stopAction(this.adjustSchedule), this.adjustSchedule = null);
        let e = 0;
        this.adjustSchedule = TweenTool.myschedule(ToolUtils.getPersistGlobalNode(), 1, (() => {
            e += 1;
            e % 5 == 1 && (1 == ToolUtils.isSafeNumber(this.data.is_report_adid) ? this.adjustSchedule && (TweenTool.stopAction(this.adjustSchedule), this.adjustSchedule = null) : "" != ToolUtils.isSafeString(AppInfo.shared().getAdjust_Adid()) && (this.adjustSchedule && (TweenTool.stopAction(this.adjustSchedule), this.adjustSchedule = null), this.reportRequestAdjust()));
            e > 300 && this.adjustSchedule && (TweenTool.stopAction(this.adjustSchedule), this.adjustSchedule = null);
        }));
    }
    reportRequestAdjust() {
        "" != ToolUtils.isSafeString(AppInfo.shared().getAdjust_Adid()) && HttpManager.shared().doGetCommonRequest({ adjust_id: AppInfo.shared().getAdjust_Adid(), gaid: AppInfo.shared().getGaid() }, HttpRequest.ReportAdjustId, ((a, t, s) => {
            if (200 != s) {
                User.shared().getNativeAdjustId();
            }
            else {
                0 == ToolUtils.parseJson(t).ret && (User.shared().data.is_report_adid = 1, User.shared().adjustSchedule && (TweenTool.stopAction(User.shared().adjustSchedule), User.shared().adjustSchedule = null));
            }
        }));
    }
    doBindFacebook() {
        HttpManager.shared().doBlindFBAccount(User.shared().access_token, ((a, t, s) => {
            if (200 != s) {
                ;
            }
            else {
                let a = ToolUtils.parseJson(t);
                0 == a.ret && (User.shared().data.hasBlindFb = 1, ToolUtils.isSafeString(a.data.name).length > 0 && (User.shared().data.name = a.data.name), a.data.avatar_url && (User.shared().data.avatar_url = a.data.avatar_url), a.data.avatar && (User.shared().data.avatar = a.data.avatar), User.shared().data.hasBlindFb = 1, PushCenter.shared().pushEvent(GameConfig.Update_Name), PushCenter.shared().pushEvent(GameConfig.Change_Head), PushCenter.shared().pushEvent(PushEvent.LoginBindFacebook));
            }
        }));
    }
    doBindApple() {
        HttpManager.shared().doGetCommonRequest({ token: User.shared().access_token }, HttpRequest.BlindIOSAccount, ((a, t, s) => {
            if (Utils.shared().hideLoading(), 200 != s) {
                Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 1.5, 0, ToolUtils.getIsNormalDirection());
            }
            else {
                try {
                    let a = ToolUtils.parseJson(t);
                    0 == a.ret && (localStorage.setItem(CommDefine.AppleTokenKey, User.shared().access_token), ToolUtils.isSafeString(a.data.name).length > 0 && (User.shared().data.name = a.data.name), ToolUtils.isSafeString(a.data.avatar_url).length > 0 && (User.shared().data.avatar_url = a.data.avatar_url), ToolUtils.isSafeString(a.data.avatar).length > 0 && (User.shared().data.avatar = a.data.avatar), User.shared().data.bindIOS = 1, PushCenter.shared().pushEvent(GameConfig.Update_Name), PushCenter.shared().pushEvent(GameConfig.Change_Head), PushCenter.shared().pushEvent(PushEvent.LoginBindApple));
                }
                catch (e) {
                }
            }
        }));
    }
    requestTreaHuntMainData(a = false, t = 0, s = 6, i, r) {
        let d = 0;
        d = ToolUtils.judgeIfInHall() ? 0 : 1;
        r && 1 == r ? (null == User.shared().chip_treasureHuntMainData || a) && HttpManager.shared().doGetCommonRequest({ vid: t, inRoom: d, player: s }, HttpRequest.GetTreaHuntPage_CHIP, ((a, t, s) => {
            try {
                if (200 != s) {
                    alert("The login timed out, please try again");
                }
                else {
                    let a = ToolUtils.parseJson(t);
                    0 == a.ret && (User.shared().chip_treasureHuntMainData = a.data, this.preloadTreasureHuntRewardIcon(1), PushCenter.shared().pushEvent(PushEvent.UpdateChipTreaHuntMain), 1 == d && i && i(a.data));
                }
            }
            catch (e) {
            }
        })) : (null == User.shared().treasureHuntMainData || a) && HttpManager.shared().doGetCommonRequest({ vid: t, inRoom: d, player: s }, HttpRequest.GetTreaHuntPage, ((a, t, s) => {
            try {
                if (200 != s) {
                    alert("The login timed out, please try again");
                }
                else {
                    let a = ToolUtils.parseJson(t);
                    0 == a.ret && (User.shared().treasureHuntMainData = a.data, this.preloadTreasureHuntRewardIcon(0), PushCenter.shared().pushEvent(PushEvent.UpdateTreaHuntMain), 1 == d && i && i(a.data));
                }
            }
            catch (e) {
            }
        }));
    }
    preloadTreasureHuntRewardIcon(e) {
        if (sys.isObjectValid(e) && 1 == e) {
            if (sys.isObjectValid(this.chip_treasureHuntMainData) && sys.isObjectValid(this.chip_treasureHuntMainData.ctask) && sys.isObjectValid(this.chip_treasureHuntMainData.ctask.list) && this.chip_treasureHuntMainData.ctask.list.length > 0) {
                let e = this.chip_treasureHuntMainData.ctask.list;
                for (let a = 0; a < e.length; a++) {
                    if (sys.isObjectValid(e[a].icon) && e[a].icon.length > 0 && Utils.shared().updateNetImage(null, e[a].icon), sys.isObjectValid(e[a].reward) && e[a].reward.length > 0) {
                        for (let t = 0; t < e[a].reward.length; t++) {
                            sys.isObjectValid(e[a].reward[t].icon) && Utils.shared().updateNetImage(null, e[a].reward[t].icon);
                        }
                    }
                }
            }
        }
        else if (sys.isObjectValid(this.treasureHuntMainData) && sys.isObjectValid(this.treasureHuntMainData.ctask) && sys.isObjectValid(this.treasureHuntMainData.ctask.list) && this.treasureHuntMainData.ctask.list.length > 0) {
            let e = this.treasureHuntMainData.ctask.list;
            for (let a = 0; a < e.length; a++) {
                if (sys.isObjectValid(e[a].icon) && e[a].icon.length > 0 && Utils.shared().updateNetImage(null, e[a].icon), sys.isObjectValid(e[a].reward) && e[a].reward.length > 0) {
                    for (let t = 0; t < e[a].reward.length; t++) {
                        sys.isObjectValid(e[a].reward[t].icon) && Utils.shared().updateNetImage(null, e[a].reward[t].icon);
                    }
                }
            }
        }
    }
    requestBackCardTaskData(a = false) {
        (null == User.shared().backCardTaskdata || a) && HttpManager.shared().doGetCommonRequest(null, HttpRequest.GetBackCardTask, ((a, t, s) => {
            try {
                if (200 != s) {
                    alert("The login timed out, please try again");
                }
                else {
                    let a = ToolUtils.parseJson(t);
                    0 == a.ret && (User.shared().backCardTaskdata = a.data, PushCenter.shared().pushEvent(PushEvent.UpdateBackCardTask));
                }
            }
            catch (e) {
            }
        }));
    }
    requestGstDownUrl(e, a) {
        HttpManager.shared().doGetCommonRequest({ gst_id: e }, HttpRequest.GstGstDownUrl, ((e, t, s) => {
            try {
                if (Utils.shared().hideToast(), 200 != s) {
                    alert("The login timed out, please try again");
                }
                else {
                    let e = ToolUtils.parseJson(t);
                    if (0 == e.ret) {
                        let t = e.data.url;
                        a && a(t);
                    }
                }
            }
            catch (e) {
            }
        }));
    }
    requestNewDailyTaskData(a = false) {
        (null == User.shared().newDailydata || a) && HttpManager.shared().doGetCommonRequest(null, HttpRequest.GetDailyTaskLottery, ((a, t, s) => {
            try {
                if (200 != s) {
                    alert("The login timed out, please try again");
                }
                else {
                    let a = ToolUtils.parseJson(t);
                    0 == a.ret && (User.shared().newDailydata = a.data, PushCenter.shared().pushEvent(PushEvent.UpdateNewDailyTask));
                }
            }
            catch (e) {
            }
        }));
    }
    requestNewDailyListData(a = false) {
        (null == User.shared().newDailyListData || a) && HttpManager.shared().doGetNewDailyTaskList(((a, t, s) => {
            try {
                if (200 != s) {
                    alert("The login timed out, please try again");
                }
                else {
                    let a = ToolUtils.parseJson(t);
                    0 == a.ret && (User.shared().newDailyListData = a.data);
                }
            }
            catch (e) {
            }
        }));
    }
    send_help_all_switcher(a, t) {
        let s = User.shared().getHelper_all_switcher(), i = { cmd: NetConfig.GM_HELP_ALL_SWITCHER, uid: User.shared().data.uid, version: GameConfig.Server_Api_Ver, skey: User.shared().getSkey(), ch_id: GameConfig.CHANNEL_ID, helper_all_switcher: s, tid_key: a, user_click: 0 };
        t && (i.user_click = t);
        Server.shared().send(i);
    }
    getHelper_all_switcher() {
        let a = 0;
        if (1 == User.shared().help_setting.open_deck_pick) {
            let t = sys.localStorage.getItem("open_deck_pick_def");
            null == t && (t = User.shared().help_setting.open_deck_pick_def);
            1 == Number(t) && (a |= HELPER_ENUM.HELPER_PICK);
        }
        if (1 == User.shared().help_setting.discard) {
            let t = sys.localStorage.getItem("discard_def");
            null == t && (t = User.shared().help_setting.discard_def);
            1 == Number(t) && (a |= HELPER_ENUM.HELPER_DISCARD);
        }
        if (1 == User.shared().help_setting.finish_card_number) {
            let t = sys.localStorage.getItem("finish_card_number_def");
            null == t && (t = User.shared().help_setting.finish_card_number_def);
            1 == Number(t) && (a |= HELPER_ENUM.HELPER_HU_NUM);
        }
        if (1 == User.shared().help_setting.finish_conditions) {
            let t = sys.localStorage.getItem("finish_conditions_def");
            null == t && (t = User.shared().help_setting.finish_conditions_def);
            1 == Number(t) && (a |= HELPER_ENUM.HELPER_HU_CONDITION);
        }
        if (1 == User.shared().help_setting.quick_finish) {
            let t = sys.localStorage.getItem("quick_finish_def");
            null == t && (t = User.shared().help_setting.quick_finish_def);
            1 == Number(t) && (a |= HELPER_ENUM.HELPER_QUICK_HU);
        }
        if (1 == User.shared().help_setting.card_rating) {
            let t = sys.localStorage.getItem("card_rating_def");
            null == t && (t = User.shared().help_setting.card_rating_def);
            1 == Number(t) && (a |= HELPER_ENUM.HELPER_PAILI_SCORE);
        }
        if (1 == User.shared().help_setting.sort_mode) {
            let t = sys.localStorage.getItem("sort_mode_def");
            null == t && (t = User.shared().help_setting.sort_mode_def);
            0 == Number(t) ? a |= HELPER_ENUM.HELPER_SORT_NEVER : 1 == Number(t) ? a |= HELPER_ENUM.HELPER_SORT_FIRSTSORT : 2 == Number(t) && (a |= HELPER_ENUM.HELPER_SORT_AUTOSORT);
        }
        else {
            a |= HELPER_ENUM.HELPER_SORT_FIRSTSORT;
        }
        return a;
    }
    send_match_login_gate_request() {
        let a = { cmd: NetConfig.CLIENT_LOGIN_GATE_REQ, uid: User.shared().data.uid, skey: User.shared().getSkey(), version: GameConfig.Server_Api_Ver };
        Server.shared().send(a);
    }
    send_match_login_request() {
        let a = { cmd: NetConfig.GM_LOGIN_REQUEST, uid: User.shared().data.uid, skey: User.shared().getSkey(), version: GameConfig.Server_Api_Ver, vid: CommDefine.MatchVid, auto_sort: User.shared().auto_sort, ch_id: GameConfig.CHANNEL_ID };
        Server.shared().send(a);
    }
    send_match_cancel_enter(a) {
        let t = { cmd: RummyCmd.GM_CANCEL_ENTER_ROOM, uid: User.shared().data.uid, skey: User.shared().getSkey(), version: GameConfig.Server_Api_Ver, vid: CommDefine.MatchVid, raceid: a, session_id: User.shared().session_id, in_hall: ToolUtils.judgeIfInRummy() ? 0 : 1 };
        Server.shared().send(t);
    }
    doSendMatchOnlineStatus(a) {
        let t = { cmd: RummyCmd.CLIENT_NOTIFY_USER_ONLINE_STATUS, uid: User.shared().data.uid, skey: User.shared().getSkey(), version: GameConfig.Server_Api_Ver, status: a, session_id: User.shared().session_id };
        Server.shared().send(t);
    }
    doSendCommGameServerMsg(e) {
        sys.isObjectValid(e) && Server.shared().send(e);
    }
    preLinkGameGate() {
        if (Server.shared().isEnable()) {
            return Server.shared().setOpenCb((() => {
                this.send_login_gate_request();
            })), void (ToolUtils.bSendGateHeatBeat = true);
        }
        Server.shared().reset();
        Server.shared().setOpenCb((() => {
            this.send_login_gate_request();
            ToolUtils.bSendGateHeatBeat = true;
        }));
        Server.shared().setReconCb((() => {
        }));
        let e = URLConfig.orginHttp_tcp, a = this.getSmallPointRoomVid(), t = NetHostManager.shared().chooseBestTcpIpConn(a), s = NetHostManager.shared().chooseBestTcpPortConn(a);
        "-1" != t && -1 != s && (e = 443 == s ? "wss://" + t + ":443" : "ws://" + t + ":" + s);
        Server.shared().createSocket(e);
        gameNetworkDelay.shared().onStartSchedule();
    }
    getSmallPointRoomVid() {
        let a = 0;
        if (sys.isObjectValid(User.shared().roomTable.pointsrummy && sys.isObjectValid(User.shared().roomTable.pointsrummy.crashlist))) {
            let t = User.shared().roomTable.pointsrummy.crashlist;
            if (null != t && t.length > 0) {
                let e = -1;
                for (let a = 0, i = t.length; a < i; a++) {
                    sys.isObjectValid(t[a].mode) && (2 !== t[a].player && 6 !== t[a].player || 1 != t[a].mode || !this.checkVidOpen(Number(t[a].vid)) || (e < 0 || t[a].point < t[e].point) && (e = a));
                }
                e >= 0 && (a = t[e].vid);
            }
        }
        return a;
    }
    send_login_gate_request() {
        this.send_gate_log_time = sys.now();
        let a = { cmd: NetConfig.CLIENT_LOGIN_GATE_REQ, uid: User.shared().data.uid, skey: User.shared().getSkey(), version: GameConfig.Server_Api_Ver, ch_id: GameConfig.CHANNEL_ID };
        Server.shared().send(a);
    }
    send_game_heart_beat_request() {
        let e = { cmd: NetConfig.HEARTBEAT_CMD };
        Server.shared().send(e);
        ToolUtils.lastSendHeartBeatTime = ToolUtils.getOsTime();
    }
    switchGameGateReconAddr() {
        let e = NetHostManager.shared().getGameGateReconAddr();
        e && e.length > 0 && Server.shared().changeWebHost(e);
    }
    uploadLocationInfo() {
        let a = ReportConfig.func.Login;
        director.getScene().name == BundleNameDefined.hall_scene && (a = ReportConfig.func.Hall);
        AppInfo.shared().checkIfOpenLocation() ? ToolUtils.hasGetLocation ? HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: a, event: ReportConfig.login_evt.location_upload, location_type: 1, latitude: AppInfo.shared().getLatitude(), longtitude: AppInfo.shared().getLongitude() }) : (HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: a, event: ReportConfig.login_evt.location_upload, location_type: 4 }), User.shared().requestGetLocationStatus()) : ToolUtils.location_forbid ? HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: a, event: ReportConfig.login_evt.location_upload, location_type: 2 }) : HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: a, event: ReportConfig.login_evt.location_upload, location_type: 3 });
    }
    requestActHappyFlopPage(e, a) {
        let t = 0;
        sys.isObjectValid(e) && sys.isObjectValid(e.vid) && (t = e.vid);
        HttpManager.shared().doGetCommonRequest({ vid: t }, HttpRequest.HappyFlipActPage, ((t, s, i) => {
            if (200 != i) {
                ;
            }
            else {
                let t = ToolUtils.parseJson(s);
                if (0 == t.ret) {
                    let s = { isSucess: true };
                    s.page = t.data;
                    s.data = e;
                    a && a(s);
                }
            }
        }));
    }
    checkCanRecharge(e) {
        return !!this.checkKyc(CheckModule.RECHARGE, e) && !!this.checkLocationPermit(CheckModule.RECHARGE);
    }
    requestActGullakPage(a = null) {
        HttpManager.shared().doGetCommonRequest(null, HttpRequest.GullakPage, ((t, s, i) => {
            if (200 != i) {
                ;
            }
            else {
                let t = ToolUtils.parseJson(s);
                0 == t.ret && (User.shared().gullak_data = t.data, a && a());
            }
        }));
    }
    requestRechargeRewards(a = null) {
        HttpManager.shared().doGetCommonRequest(null, "Activity.Act_115.page", ((t, s, i) => {
            if (200 != i) {
                ;
            }
            else {
                let t = ToolUtils.parseJson(s);
                0 == t.ret && (User.shared().rechargeRewardsData = t.data, a && a());
            }
        }));
    }
    dealDeepLinkInfo() {
        let a = AppInfo.shared().getDeepLinkInfo();
        if (String(a).length > 0) {
            let t = a.split("&");
            if (Array.isArray(t) && t.length > 0) {
                let a = {};
                t.forEach((e => {
                    let [t, s] = e.split("=");
                    a[t] = s;
                }));
                let i = a.t, r = a.e;
                if (sys.isObjectValid(i) && 1 == Number(i)) {
                    if (!User.shared().checkCanPlayCashGame(CheckModule.CASH_PLAY)) {
                        return;
                    }
                    Utils.shared().joinPrivateRoomByRoomId(r);
                }
                else {
                    sys.isObjectValid(i) && 2 == Number(i) ? this.requestDoExchange(r, 2) : sys.isObjectValid(i) && 3 == Number(i) && PushCenter.shared().pushEvent(PushEvent.GetShareDeepLinkYesGame, r);
                }
            }
            AppInfo.shared().setDeepLinkInfo("");
        }
    }
    requestFreeCashPage(e, a = false, t = 0, i = 0) {
        HttpManager.shared().doGetCommonRequest({ trigger_source: e, free_cash_scene: i }, HttpRequest.FreeCash, ((e, r, d) => {
            if (200 != d) {
                ;
            }
            else {
                let e = ToolUtils.parseJson(r);
                0 == e.ret && (this.freecashData = e.data, sys.isObjectValid(this.freecashData.list) && this.freecashData.list.length > 0 && Utils.shared().doJumpLogic(PushEvent.JUMP_TO_FREECASH, { pop_souce: t, from_source: i }, { isNext: a }));
            }
        }));
    }
    requestDoExchange(e, a = 1, t = null) {
        HttpManager.shared().doGetCommonRequest({ cdkey: e, source: a }, "Act_69.doExchange", ((e, a, r) => {
            if (Utils.shared().hideLoading(), director.getScene().name != BundleNameDefined.rummy_scence) {
                if (200 != r) {
                    -1 == r && Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
                }
                else {
                    try {
                        let e = ToolUtils.parseJson(a);
                        0 == e.ret ? (t && t(), sys.isObjectValid(e.data.reward_list) && this.showChargeReward(e.data.reward_list, null, i18nMgr.shared().getValueByKey("reward_tips.fans_gift"))) : sys.isObjectValid(e.desc) && t && t(e.desc);
                    }
                    catch (e) {
                        TLog.printError("------- requestDoExchange err", e);
                    }
                }
            }
        }));
    }
    requestActAdVideoPage(e = null) {
        HttpManager.shared().doGetCommonRequest(null, HttpRequest.AdVideo, ((a, t, s) => {
            if (200 != s) {
                Utils.shared().hideLoading();
                Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3);
            }
            else {
                let a = ToolUtils.parseJson(t);
                0 == a.ret && e && e(a.data);
            }
        }));
    }
    requestActAdVideoReceivReward(a, t) {
        let i = { scene: a, client_time: sys.now(), link_id: t };
        HttpManager.shared().doGetCommonRequest(i, HttpRequest.AdVideoReward, ((a, t, i) => {
            if (200 != i) {
                ;
            }
            else {
                let a = ToolUtils.parseJson(t);
                if (0 == a.ret && sys.isObjectValid(a.data)) {
                    if (sys.isObjectValid(a.data.reward_list)) {
                        let e = null;
                        sys.isObjectValid(a.data.tips) && ToolUtils.isSafeString(a.data.tips).length > 0 && (e = ToolUtils.isSafeString(a.data.tips));
                        this.showChargeReward(a.data.reward_list, null, e);
                    }
                    sys.isObjectValid(a.data.is_hide) && (User.shared().act_73 = 1 == a.data.is_hide ? 0 : 1, PushCenter.shared().pushEvent(PushEvent.RefreshAdVideoSwitch));
                }
            }
        }));
    }
    requestActAdVideoReport(e) {
        0 != this.act_73_report && HttpManager.shared().doGetCommonRequest(e, HttpRequest.AdVideoReport, ((e, a, t) => {
        }));
    }
    requestActAdvancedPackPage(e = null) {
        HttpManager.shared().doGetCommonRequest(null, HttpRequest.AdvancedPackPage, ((a, t, s) => {
            if (200 != s) {
                ;
            }
            else {
                let a = ToolUtils.parseJson(t);
                0 == a.ret && (this.adventrueData = a.data, e && e(a.data));
            }
        }));
    }
    requestSuperVipConfirmUpgradePop() {
        HttpManager.shared().doGetCommonRequest(null, HttpRequest.SuperVipUpgradePopConfirm, ((e, a, t) => {
        }));
    }
    requestSuperVipHomePageData(a = null) {
        HttpManager.shared().doGetCommonRequest(null, HttpRequest.SuperVipPage, ((t, s, i) => {
            if (200 != i) {
                ;
            }
            else {
                let t = ToolUtils.parseJson(s);
                0 == t.ret && (User.shared().superVipPageData = t.data, a && a());
            }
        }));
    }
    requestWeekMonthActData() {
        HttpManager.shared().doGetCommonRequest({ open_act: 0 }, "Activity.Act_104.page", ((a, t, s) => {
            if (200 != s) {
                ;
            }
            else {
                try {
                    let a = ToolUtils.parseJson(t);
                    0 == a.ret && (this.weekmonthData = a.data, ToolUtils.saveData("weekmonth_data" + String(User.shared().data.uid), ToolUtils.toJsonString(this.weekmonthData)));
                }
                catch (e) {
                    TLog.printError("requestWeekMonthActData err:", e.toString());
                }
            }
        }));
    }
    requestFirstRechargePageData(a = null) {
        HttpManager.shared().doGetCommonRequest(null, HttpRequest.FirstRechargePage, ((t, s, i) => {
            if (200 != i) {
                Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.request_fail"), 2);
            }
            else {
                try {
                    let t = ToolUtils.parseJson(s);
                    0 == t.ret && (User.shared().firstrechargeData = t.data, a && a(User.shared().firstrechargeData));
                }
                catch (e) {
                    TLog.printError("requestFirstRechargePageData err:", e.toString());
                }
            }
        }));
    }
    requestTwentyFourRechargePageData(a = null) {
        HttpManager.shared().doGetCommonRequest(null, HttpRequest.TwentyFourRechargePage, ((t, s, i) => {
            if (200 != i) {
                Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.request_fail"), 2);
            }
            else {
                try {
                    let t = ToolUtils.parseJson(s);
                    0 == t.ret && (User.shared().twentyfourrechargeData = t.data, a && a());
                }
                catch (e) {
                    TLog.printError("requestTwentyFourRechargePageData err:", e.toString());
                }
            }
        }));
    }
    requestRebateRechargePageData(a = null) {
        HttpManager.shared().doGetCommonRequest(null, HttpRequest.RebateRechargePage, ((t, s, i) => {
            if (200 != i) {
                Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.request_fail"), 2);
            }
            else {
                try {
                    let t = ToolUtils.parseJson(s);
                    0 == t.ret && (User.shared().rebaterechargeData = t.data, a && a(User.shared().rebaterechargeData));
                }
                catch (e) {
                    TLog.printError("requestRebateRechargePageData err:", e.toString());
                }
            }
        }));
    }
    requestBuyOneGetThreePageData(a = null) {
        HttpManager.shared().doGetCommonRequest(null, HttpRequest.BuyOneGetThreePage, ((t, s, i) => {
            if (200 != i) {
                Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.request_fail"), 2);
            }
            else {
                try {
                    let t = ToolUtils.parseJson(s);
                    0 == t.ret && (User.shared().payOneForThreeData = t.data, a && a(User.shared().payOneForThreeData));
                }
                catch (e) {
                    TLog.printError("requestBuyOneGetThreePageData err:", e.toString());
                }
            }
        }));
    }
    requestConsecutiveGiftPageData(a = null) {
        HttpManager.shared().doGetCommonRequest(null, HttpRequest.ConsecutiveGiftPage, ((t, s, i) => {
            if (200 != i) {
                Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.request_fail"), 2);
            }
            else {
                try {
                    let t = ToolUtils.parseJson(s);
                    0 == t.ret && (User.shared().consecutiveGiftData = t.data, a && a(User.shared().consecutiveGiftData));
                }
                catch (e) {
                    TLog.printError("requestConsecutiveGiftPageData err:", e.toString());
                }
            }
        }));
    }
    requestCustomSelGiftPageData(a = null) {
        HttpManager.shared().doGetCommonRequest(null, HttpRequest.CustomSelGiftPage, ((t, s, i) => {
            if (200 != i) {
                Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.request_fail"), 2);
            }
            else {
                try {
                    let t = ToolUtils.parseJson(s);
                    0 == t.ret && (User.shared().customSelGiftData = t.data, a && a(User.shared().customSelGiftData));
                }
                catch (e) {
                    TLog.printError("requestCustomSelGiftPageData err:", e.toString());
                }
            }
        }));
    }
    requestTreasureDrawPageData(a = null) {
        HttpManager.shared().doGetCommonRequest(null, HttpRequest.TreasureDrawPage, ((t, s, i) => {
            if (200 != i) {
                Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.request_fail"), 2);
            }
            else {
                try {
                    let t = ToolUtils.parseJson(s);
                    0 == t.ret && (User.shared().treasuredrawData = t.data, a && a(User.shared().treasuredrawData));
                }
                catch (e) {
                    TLog.printError("requestTreasureDrawPageData err:", e.toString());
                }
            }
        }));
    }
    requestTreasureDrawExchangeProp(e, a = null) {
        HttpManager.shared().doGetCommonRequest(e, HttpRequest.TreasureDrawExchangeProp, ((e, t, s) => {
            if (200 != s) {
                Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.request_fail"), 2);
            }
            else {
                try {
                    let e = ToolUtils.parseJson(t);
                    0 == e.ret && a && a(e.data);
                }
                catch (e) {
                    TLog.printError("requestTreasureDrawExchangeProp err:", e.toString());
                }
            }
        }));
    }
    requestTreasureDrawReward(e = null) {
        HttpManager.shared().doGetCommonRequest(null, HttpRequest.TreasureDrawReward, ((a, t, s) => {
            if (200 != s) {
                Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.request_fail"), 2);
                PushCenter.shared().pushEvent(PushEvent.UpdateTreasureDrawRewarding, 0);
            }
            else {
                try {
                    let a = ToolUtils.parseJson(t);
                    0 == a.ret ? e && e(a.data) : PushCenter.shared().pushEvent(PushEvent.UpdateTreasureDrawRewarding, 0);
                }
                catch (e) {
                    TLog.printError("requestTreasureDrawReward err:", e.toString());
                    PushCenter.shared().pushEvent(PushEvent.UpdateTreasureDrawRewarding, 0);
                }
            }
        }));
    }
    requestClaimBuyOneGetThreeRward(a = null) {
        HttpManager.shared().doGetCommonRequest(null, HttpRequest.ClaimBuyOneGetThreeReward, ((t, i, r) => {
            if (200 != r) {
                Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.request_fail"), 2);
            }
            else {
                try {
                    let t = ToolUtils.parseJson(i);
                    if (0 == t.ret) {
                        if (!sys.isObjectValid(t.data) || !t.data) {
                            return;
                        }
                        sys.isObjectValid(t.data.reward_list) && t.data.reward_list && Array.isArray(t.data.reward_list) && t.data.reward_list.length && User.shared().showChargeReward(t.data.reward_list);
                        sys.isObjectValid(t.data.ext) && t.data.ext && (User.shared().payOneForThreeData = t.data.ext, a && a(User.shared().payOneForThreeData));
                    }
                }
                catch (e) {
                    TLog.printError("requestClaimBuyOneGetThreeRward err:", e.toString());
                }
            }
        }));
    }
    requestHallLeaderBoardsPage(e = null) {
        HttpManager.shared().doGetCommonRequest(null, HttpRequest.HallLeaderBoardsPage, ((a, t, s) => {
            if (200 != s) {
                e && (Utils.shared().hideLoading(), Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.request_fail"), 2));
            }
            else {
                try {
                    e && Utils.shared().hideLoading();
                    let a = ToolUtils.parseJson(t);
                    0 == a.ret && (this.hall_rank_data = a.data, e && e());
                }
                catch (e) {
                    TLog.printError("requestHallLeaderBoardsPage err:", e.toString());
                }
            }
        }));
    }
    requestGetRecommendRoomList() {
        HttpManager.shared().doGetCommonRequest(null, HttpRequest.HallGetRecommendRoomList, ((e, a, t) => {
            if (200 != t) {
                ;
            }
            else {
                try {
                    let e = ToolUtils.parseJson(a);
                    0 == e.ret && sys.isObjectValid(e.data) && sys.isObjectValid(e.data.act_76_recommend_list) && Array.isArray(e.data.act_76_recommend_list) && (this.act_76_recommend_list = e.data.act_76_recommend_list, PushCenter.shared().pushEvent(PushEvent.RefreshHallChooseGameRankStar));
                }
                catch (e) {
                    TLog.printError("requestHallLeaderBoardsPage err:", e.toString());
                }
            }
        }));
    }
    requestActRankGetRoomProgressData(e) {
        HttpManager.shared().doGetCommonRequest({ vid: e }, HttpRequest.RoomRankActGetRoomProgressData, ((e, a, t) => {
            if (200 != t) {
                ;
            }
            else {
                try {
                    let e = ToolUtils.parseJson(a);
                    0 == e.ret && sys.isObjectValid(e.data) && sys.isObjectValid(e.data.list) && Array.isArray(e.data.list) && e.data.list.length > 0 && PushCenter.shared().pushEvent(PushEvent.RefreshRoomActRankProgress, e.data.list);
                }
                catch (e) {
                    TLog.printError("requestActRankGetRoomProgressData err:", e.toString());
                }
            }
        }));
    }
    requestActRankGetRoomPage(e, a = null) {
        let t = HttpRequest.RoomRankActGetRoomPage;
        1 == this.data.is_new_rank && (t = HttpRequest.RoomRankNewPlayerActGetRoomPage);
        HttpManager.shared().doGetCommonRequest(e, t, ((t, i, r) => {
            if (200 != r) {
                ;
            }
            else {
                try {
                    let t = ToolUtils.parseJson(i);
                    if (0 == t.ret && sys.isObjectValid(t.data)) {
                        let i = false;
                        if (sys.isObjectValid(e) && sys.isObjectValid(e.vid)) {
                            let a = e.vid;
                            if (this.roomActRankDataMap.has(a) && this.roomActRankDataMap.get(a)) {
                                let e = this.roomActRankDataMap.get(a);
                                i = ToolUtils.jsonToMd5(e) != ToolUtils.jsonToMd5(t.data);
                            }
                            this.roomActRankDataMap.set(a, t.data);
                        }
                        a && a(i);
                    }
                }
                catch (e) {
                    TLog.printError("requestActRankGetRoomPage err:", e.toString());
                }
            }
        }));
    }
    requestRankActEntry(e, a = null) {
        HttpManager.shared().doGetCommonRequest({ status: e }, HttpRequest.RankBoardEntry, ((e, t, i) => {
            if (200 != i) {
                ;
            }
            else {
                try {
                    let e = ToolUtils.parseJson(t);
                    0 == e.ret && sys.isObjectValid(e.data) && a && a(e.data);
                }
                catch (e) {
                    TLog.printError("requestActRankGetRoomPage err:", e.toString());
                }
            }
        }));
    }
    requestGetFlopReward(e) {
        HttpManager.shared().doGetCommonRequest(e, HttpRequest.FlopCashTaskGetReward, ((a, t, i) => {
            if (200 != i) {
                0 == sys.getNetworkType() ? Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text91"), 3, 0, ToolUtils.getIsNormalDirection()) : Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
            }
            else {
                try {
                    let a = ToolUtils.parseJson(t);
                    if (0 == a.ret) {
                        try {
                            sys.isObjectValid(RummyDataManager.shared().rummyInfos.get(e.tid_key)) && sys.isObjectValid(RummyDataManager.shared().rummyInfos.get(e.tid_key).flopCashTaskLaba) && (RummyDataManager.shared().rummyInfos.get(e.tid_key).flopCashTaskLaba = null, RummyDataManager.shared().rummyInfos.get(e.tid_key).flopTempTaskInfo = null);
                            sys.isObjectValid(a.data.task_data) && PushCenter.shared().pushEvent(PushEvent.UpdateRoomFlopCrashTaskProgess, a.data.task_data);
                        }
                        catch (e) {
                            TLog.printError(e);
                        }
                    }
                }
                catch (e) {
                    TLog.printError("User", "_dealGetRewardLogic  error:", e);
                }
            }
        }));
    }
    pushActivityToPopList() {
        if (sys.isObjectValid(this.poplist) && sys.isObjectValid(this.clubUpgradeMsg)) {
            let e = { exe: {} };
            e.type = PushEvent.Custom_TO_MemberShipUpgrade;
            e.exe.ext = this.clubUpgradeMsg;
            this.poplist.splice(0, 0, e);
        }
    }
    checkLobbyPopList() {
        if (this._checkExitRoomVid && sys.isObjectValid(this.choosegame) && (this._checkExitRoomVid = false, sys.isObjectValid(this.poplist) && this.poplist.length > 0)) {
            let e = 0;
            do {
                if (this.poplist[e].type == PushEvent.JUMP_TO_Act_BestHighScore || this.poplist[e].type == PushEvent.JUMP_TO_Act_Wild || this.poplist[e].type == PushEvent.JUMP_TO_Act_Multiple || this.poplist[e].type == PushEvent.JUMP_TO_Act_Double) {
                    let a = this.getBestRoomInfoByActId(this.poplist[e].type);
                    if (!sys.isObjectValid(a) || !sys.isObjectValid(a.targetRoom)) {
                        this.poplist.splice(e, 1);
                        continue;
                    }
                    {
                        let t = null;
                        if (a.rummyType == HowToPlayDefined.RUMMY_POINTS ? t = Utils.shared().judgeCashPointRoomUnlock(a.targetRoom.player, a.targetRoom.mode, a.targetRoom.entry) : a.rummyType == HowToPlayDefined.RUMMY_POOL ? t = Utils.shared().judgeCashPoolRoomUnlock(a.targetRoom.player, a.targetRoom.mode, a.targetRoom.entry) : a.rummyType == HowToPlayDefined.RUMMY_DEALS && (t = Utils.shared().judgeCashDealsRoomUnlock(a.targetRoom.player, a.targetRoom.mode, a.targetRoom.entry)), !t || !t.openBol) {
                            this.poplist.splice(e, 1);
                            continue;
                        }
                        if (this.exitRoomGameVid > 0 && a.cRummyType == this.exitRoomRummyType) {
                            if (this.poplist[e].type == PushEvent.JUMP_TO_Act_Wild || this.poplist[e].type == PushEvent.JUMP_TO_Act_Multiple) {
                                this.poplist.splice(e, 1);
                                continue;
                            }
                            if (a.targetRoom.vid == this.exitRoomGameVid) {
                                this.poplist.splice(e, 1);
                                continue;
                            }
                            {
                                let t = this.getRoomInfoByVid(a.targetRoom.rummyType, a.targetRoom.vid), i = this.getRoomInfoByVid(this.exitRoomRummyType, this.exitRoomGameVid);
                                if (sys.isObjectValid(t) && sys.isObjectValid(i) && i.boot >= t.boot) {
                                    this.poplist.splice(e, 1);
                                    continue;
                                }
                            }
                        }
                    }
                }
                else if (!(this.poplist[e].type != PushEvent.JUMP_TO_Act_RechangeCoupon || sys.isObjectValid(this.poplist[e].exe) && Array.isArray(this.poplist[e].exe.rewardList))) {
                    this.poplist.splice(e, 1);
                    continue;
                }
                e++;
            } while (e < this.poplist.length);
        }
    }
    getBestRoomInfoByActId(a) {
        let t = "Points - Classic - ", i = 1, r = HowToPlayDefined.RUMMY_POINTS, d = HowToPlayDefined.RUMMY_POINTS, h = 201, l = 3, _ = 6;
        if (a == PushEvent.JUMP_TO_Act_BestHighScore) {
            if (1 == User.shared().exitRoomGameType) {
                return null;
            }
            let a = this.getRoomInfoByVid(this.exitRoomRummyType, this.exitRoomGameVid, this.exitRoomGameType);
            this.exitRoomRummyType == HowToPlayDefined.RUMMY_POOL ? (t = "Pool - ", r = HowToPlayDefined.RUMMY_POOL, d = HowToPlayDefined.RUMMY_POOL, sys.isObjectValid(a) && (h = a.pool_game, _ = a.player)) : this.exitRoomRummyType == HowToPlayDefined.RUMMY_DEALS ? (t = "Deals - ", r = HowToPlayDefined.RUMMY_DEALS, d = HowToPlayDefined.RUMMY_DEALS, sys.isObjectValid(a) && (l = a.deals, _ = a.player)) : this.exitRoomRummyType == HowToPlayDefined.RUMMY_MULTIPLE ? (i = 3, t = "Points - Multiple - ", d = HowToPlayDefined.RUMMY_MULTIPLE) : this.exitRoomRummyType == HowToPlayDefined.RUMMY_BUMP ? (i = 4, t = "Points - Wild - ", d = HowToPlayDefined.RUMMY_BUMP, sys.isObjectValid(a) && (_ = a.player)) : this.exitRoomRummyType == HowToPlayDefined.RUMMY_POINTS && sys.isObjectValid(a) && (_ = a.player);
        }
        else {
            a == PushEvent.JUMP_TO_Act_Wild ? (i = 4, t = "Points - Wild - ", d = HowToPlayDefined.RUMMY_BUMP) : a == PushEvent.JUMP_TO_Act_Multiple && (i = 3, t = "Points - Multiple - ", d = HowToPlayDefined.RUMMY_MULTIPLE);
        }
        return this.processFindBestRoom(0, r, { tplayer: _, finalMode: i, nType: a, strTips: t, cRummyType: d, pools: h, deals: l });
    }
    processFindBestRoom(e, a, t = {}) {
        let i = 6, r = 1, d = -1, h = "", l = 0, _ = 201, n = 3;
        sys.isObjectValid(t.tplayer) && (i = t.tplayer);
        sys.isObjectValid(t.finalMode) && (r = t.finalMode);
        sys.isObjectValid(t.nType) && (d = t.nType);
        sys.isObjectValid(t.strTips) && (h = t.strTips);
        sys.isObjectValid(t.cRummyType) && (l = t.cRummyType);
        sys.isObjectValid(t.pools) && (_ = t.pools);
        sys.isObjectValid(t.deals) && (n = t.deals);
        let c = null, u = Utils.shared().getCurRoomList(e, a);
        if (null != u && sys.isObjectValid(u.length) && u.length > 0) {
            let t = Number(i), m = [];
            for (let e = 0, i = u.length; e < i; e++) {
                a == HowToPlayDefined.RUMMY_POOL ? Number(u[e].player) == t && Number(u[e].pool_game) == _ && m.push(u[e]) : a == HowToPlayDefined.RUMMY_DEALS ? Number(u[e].player) == t && Number(u[e].deals) == n && m.push(u[e]) : sys.isObjectValid(u[e].mode) && Number(u[e].mode) == r && Number(u[e].player) == t && m.push(u[e]);
            }
            let g = 0, b = 0, y = Utils.shared().getEnterMoneyApi(r, false, 0, a, t), f = Utils.shared().getRecommendRoomIndex(m, y, e);
            if (f.length > 0) {
                g = f[1];
                b = f[2];
                let t = null;
                t = d == PushEvent.JUMP_TO_Act_BestHighScore && sys.isObjectValid(m[g]) ? m[g] : g >= 1 ? m[g - 1] : m[g];
                sys.isObjectValid(t) && (d == PushEvent.JUMP_TO_Act_BestHighScore ? this.exitRoomRummyType == HowToPlayDefined.RUMMY_POOL ? h += ToolUtils.format("${0}PTS - ${1}Players - ₹${2}", t.pool_game, t.player, t.boot) : this.exitRoomRummyType == HowToPlayDefined.RUMMY_DEALS ? h += ToolUtils.format("${0}Games - ${1}Players - ₹${2}", t.deals, t.player, t.boot) : h += ToolUtils.format("${0}Players - ₹${1}", t.player, t.boot) : h += ToolUtils.format("${0}Players - ₹${1}", t.player, t.boot), c = { gameType: e, rummyType: a, cRummyType: l, strTip: h, targetRoom: t, bestRoom: sys.isObjectValid(m[g - 1]) ? m[g - 1] : m[g], bestIndex: g >= 1 ? g - 1 : g, lastIndex: b >= 1 ? b - 1 : b, vRoomlist: m, findIndex: g >= 1 ? g : -1 });
            }
        }
        return c;
    }
    getRoomInfoByVid(e, a, t = 0) {
        let s = Utils.shared().getCurRoomList(t, e);
        if (s && s.length > 0) {
            for (let e = 0, t = s.length; e < t; e++) {
                if (s[e].vid == a) {
                    return s[e];
                }
            }
        }
        return null;
    }
    enterGame(a) {
        let t = a.roomInfo, i = a.gameType, r = a.rummyType, d = sys.isObjectValid(a.is_sub_loading) ? a.is_sub_loading : 0;
        if (t && t.vid) {
            let a = t.vid;
            User.shared().min_money = t.entry;
            ToolUtils.curRoomId = a;
            let s = {};
            s.lobby = i;
            s.game = r;
            s.data = t;
            ToolUtils.saveData(User.shared().data.uid + "recommendRoom" + i + r, ToolUtils.toJsonString(s));
            ToolUtils.saveData(User.shared().data.uid + "recommendRoomNew", ToolUtils.toJsonString(s));
            ToolUtils.curRoomId = a;
            Utils.shared().showCommEnterRoom({ vid: a, game_type: r, isNewTable: 1, is_sub_loading: d });
        }
    }
    getGradeByMemberShipLevel(a) {
        let t = Number.isNaN(a) ? 0 : Number(a);
        return t = User.shared().club_grade.has(t) ? User.shared().club_grade.get(t) : User.shared().club_grade.get(0), t;
    }
    checkHasSuperVip() {
        let a = false;
        return sys.isObjectValid(User.shared().data.vip_info) && sys.isObjectValid(User.shared().data.vip_info.current_show_level) && (a = true), a;
    }
    send_race_rejoin_request(a, t, i = null, r = null, d = null) {
        let h = { cmd: NetConfig.GM_RACE_REJOIN_REQUEST, uid: User.shared().data.uid, skey: User.shared().getSkey(), version: GameConfig.Server_Api_Ver, raceid: Number(a), pay_type: t, isNewTable: 1, from: 1, session_id: User.shared().session_id, in_hall: ToolUtils.judgeIfInRummy() ? 0 : 1 };
        sys.isObjectValid(i) && (h.tk_no = i);
        sys.isObjectValid(r) && (h.tid_key = r);
        sys.isObjectValid(d) && (h.match_vid = d);
        Server.shared().send(h);
    }
    sendJoinMatch(a) {
        let t = null, i = null, d = null, h = null, l = 0;
        sys.isObjectValid(a) && (sys.isObjectValid(a.raceid) && (t = a.raceid), sys.isObjectValid(a.ticket_no) && (i = a.ticket_no), sys.isObjectValid(a.tid_key) && (d = a.tid_key), sys.isObjectValid(a.match_vid) && (h = a.match_vid), sys.isObjectValid(a.is_detail) && (l = a.is_detail));
        this.free_match_raceid = t;
        this.match_ticket_no = i;
        this.match_tid_key = d;
        this.match_vid = h;
        this.match_isDetail = l;
        let _ = Server.shared().isEnable();
        if (_ || Server.shared().reset(), this.clearUserMatchTarget(), this.regRoomMatchEventinit(), Server.shared().setOpenCb((() => {
            User.shared().send_match_login_gate_request();
            User.shared().send_match_login_request();
        })), Server.shared().setReconCb((() => {
        })), _) {
            Server.shared().pop_response();
            User.shared().send_match_login_request();
        }
        else {
            let e = URLConfig.orginHttp_tcp, a = this.getSmallPointRoomVid(), t = NetHostManager.shared().chooseBestTcpIpConn(a), s = NetHostManager.shared().chooseBestTcpPortConn(a);
            "-1" != t && -1 != s && (e = 443 == s ? "wss://" + t + ":443" : "ws://" + t + ":" + s);
            Server.shared().createSocket(e);
        }
    }
    clearUserMatchTarget() {
        Server.shared().clearEventByTarget(this);
    }
    handler_server_match_join_return(a) {
        if (this.clearUserMatchTarget(), 0 == a.ret) {
            if (1 == a.mode ? a.tips && a.tips.length > 0 && Utils.shared().showToast(a.tips, 3) : sys.isObjectValid(a.tips) && ToolUtils.isSafeString(a.tips).length > 0 && Utils.shared().showToast(a.tips, 2), User.shared().updateMoney(a.money), null != a.prop_info && a.prop_info.length > 0) {
                for (let t = 0, s = a.prop_info.length; t < s; t++) {
                    User.shared().setPropNumById(a.prop_info[t].pid, a.prop_info[t].value);
                }
            }
            null != a.money && null != a.money && User.shared().updateMoney(a.money);
            let t = { lobby: 1, game: 0, data: null };
            sys.localStorage.setItem(User.shared().data.uid + "recommendRoomNew", ToolUtils.toJsonString(t));
            sys.localStorage.removeItem(User.shared().data.uid + "addRecommendRoomNew");
            User.shared().doSendMatchOnlineStatus(0);
            PushCenter.shared().pushEvent(PushEvent.FreeMatchPushJoinSuccess);
        }
        else if (0 == a.code) {
            let t = ToolUtils.isSafeNumber(a.min_enter);
            Utils.shared().showQuickRecharge(431, null, true, this.match_tid_key, 0, t);
            User.shared().updatePayScene(PhpReportDefined.pay_scene.hall_less_money, 431);
        }
        else {
            a.msg && Utils.shared().showToast(a.msg, 2);
        }
    }
    handler_server_login_Rummy_return(a) {
        0 == parseInt("" + a.ret) && sys.isObjectValid(a.session_id) && (User.shared().session_id = a.session_id, User.shared().doSendMatchOnlineStatus(1), 1 == this.match_isDetail ? this.send_get_race_detaild_request(this.free_match_raceid) : this.send_try_join_race_by_ticket(this.free_match_raceid, this.match_ticket_no));
    }
    send_get_race_detaild_request(a) {
        let t = { cmd: NetConfig.GM_GET_RACE_DETAILD_REQUEST, uid: User.shared().data.uid, skey: User.shared().getSkey(), version: GameConfig.Server_Api_Ver, raceid: a, session_id: User.shared().session_id, in_hall: 1 };
        Server.shared().send(t);
    }
    handler_server_get_race_detaild_return(a) {
        Utils.shared().hideLoading();
        0 == a.ret ? (a.from_source = 1, Utils.shared().showMatchInfoView(a, (a => {
            if (!User.shared().checkCanPlayCashGame(CheckModule.CASH_PLAY)) {
                return;
            }
            if (1 == Utils.shared().showFastKyc()) {
                return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("kyc.kyc_match"), 2);
            }
            let t = this.free_match_raceid;
            sys.isObjectValid(a) && sys.isObjectValid(a.raceid) && (t = a.raceid);
            this.send_try_join_race_by_ticket(t);
        }))) : sys.isObjectValid(this.match_isDetail) && 1 == this.match_isDetail ? Utils.shared().doJumpLogic(PushEvent.JUMP_TO_MATCH_ROOM) : Utils.shared().showToast(a.msg, 2);
    }
    handler_server_race_points_rewardlist_return(e) {
        PushCenter.shared().pushEvent(PushEvent.RefreshRacePointsRewardList, e);
    }
    regRoomMatchEventinit() {
        Server.shared().regDispatch(NetConfig.SM_JOIN_RETRUN, this.handler_server_match_join_return.bind(this), this);
        Server.shared().regDispatch(NetConfig.SM_LOGIN_RETURN, this.handler_server_login_Rummy_return.bind(this), this);
        Server.shared().regDispatch(NetConfig.SM_TRY_JOIN_RACE_BY_TICKET, this.handler_server_try_join_race_by_ticket_return.bind(this), this);
        Server.shared().regDispatch(NetConfig.SM_GET_RACE_DETAILD_RESPOND, this.handler_server_get_race_detaild_return.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_RANK_INFO_RESPOND, this.handler_server_race_points_rewardlist_return.bind(this), this);
    }
    requestGameDisplayPage(e = null) {
        HttpManager.shared().doGetCommonRequest(null, HttpRequest.GameDisPlayPage, ((a, t, i) => {
            if (200 != i) {
                ;
            }
            else {
                try {
                    let a = ToolUtils.parseJson(t);
                    0 == a.ret && sys.isObjectValid(a.data) && (this.gameDisplayPageData = a.data, sys.isObjectValid(a.data.list) && e && e());
                }
                catch (e) {
                    TLog.printError("requestGameDisplayPage err:", e.toString());
                }
            }
        }));
    }
    send_try_join_race_by_ticket(a = 0, t = null) {
        let i = { cmd: NetConfig.GM_TRY_JOIN_RACE_BY_TICKET, uid: User.shared().data.uid, skey: User.shared().getSkey(), version: GameConfig.Server_Api_Ver, session_id: User.shared().session_id };
        0 != a && (i.raceid = a);
        sys.isObjectValid(t) && (i.tk_no = t);
        Server.shared().send(i);
        window.InHallScene && PushCenter.shared().pushEvent(PushEvent.PreChangeMatchRoomBg);
    }
    handler_server_try_join_race_by_ticket_return(a) {
        let t = a.ret;
        if (0 == t) {
            sys.isObjectValid(a) || (a = {});
            sys.isObjectValid(this.match_tid_key) && (a.match_tid_key = this.match_tid_key);
            sys.isObjectValid(this.match_vid) && (a.match_vid = this.match_vid);
            ToolUtils.judgeIfInHall() ? Utils.shared().showTicketSelectView({ data: a, parent_node: director.getScene().getChildByName("Canvas") }) : ToolUtils.judgeIfInRummy() && Utils.shared().showRoomTicketSelectView({ data: a, parent_node: director.getScene().getChildByName("Canvas") });
        }
        else if (1 == t) {
            if (sys.isObjectValid(a.err_code) && 1 == a.err_code) {
                let t = ToolUtils.isSafeNumber(a.entry_fee);
                Utils.shared().showQuickRecharge(431, null, true, "", 0, t);
                User.shared().updatePayScene(PhpReportDefined.pay_scene.hall_less_money, 431);
            }
            else {
                sys.isObjectValid(a.raceid) && this.send_race_rejoin_request(a.raceid, null, null, this.match_tid_key, this.match_vid);
            }
        }
    }
    requestSwitchExclusiveSkin() {
        HttpManager.shared().doGetCommonRequest(null, HttpRequest.SwitchExclusiveSkin, ((e, a, t) => {
            if (Utils.shared().hideLoading(), 200 != t) {
                ;
            }
            else {
                try {
                    let e = ToolUtils.parseJson(a);
                    0 == e.ret && this.refreshTableStyles(e.data);
                }
                catch (e) {
                    TLog.printError("requestSwitchExclusiveSkin err:", e.toString());
                }
            }
        }));
    }
    requestExeShopExchangeChip(a) {
        HttpManager.shared().doGetCommonRequest(a, HttpRequest.ExeShopExchangeChip, ((a, t, s) => {
            if (Utils.shared().hideLoading(), 200 != s) {
                ;
            }
            else {
                try {
                    let a = ToolUtils.parseJson(t);
                    0 == a.ret && (a.data.tm && User.shared().updateMoney(a.data.tm), PushCenter.shared().pushEvent(GameConfig.Update_ExeStore), Utils.shared().showToast(ToolUtils.format(i18nMgr.shared().getValueByKey("store.pay_succ_exchange_chip"), a.data.nums), 2, 0, ToolUtils.getIsNormalDirection()));
                }
                catch (e) {
                    TLog.printError("requestExeShopExchangeChip err:", e.toString());
                }
            }
        }));
    }
    requestCheckCashGameUpPop(e = null, a = null) {
        HttpManager.shared().doGetCommonRequest(e, HttpRequest.CheckCAshGameUp, ((e, t, s) => {
            if (Utils.shared().hideLoading(), 200 != s) {
                a && a(null);
            }
            else {
                try {
                    let e = ToolUtils.parseJson(t);
                    0 == e.ret ? a && a(e.data.pop) : a && a(null);
                }
                catch (e) {
                    TLog.printError("requestCheckCashGameUpPop err:", e.toString());
                    a && a(null);
                }
            }
        }));
    }
    showCashGameUpAlert(e, a = null, t = -1) {
        let s = ToolUtils.format(i18nMgr.shared().getValueByKey("choose_game.cash_up_tips3"), e), i = { bLandscape: ToolUtils.getIsNormalDirection(), bWithCancel: false, strContent: s, closeType: 3, sureKey: "choose_game.play_now", strTitle: i18nMgr.shared().getValueByKey("utlis.congratulations"), name: "CashGameUpAlert", sceneType: t };
        Utils.shared().showCommonAlert(i, (e => {
            a && a(e);
        }), false);
    }
    requestShareGetGameShare(e = null) {
        HttpManager.shared().doGetCommonRequest(e, HttpRequest.ShareGetGameShare, ((e, a, t) => {
            if (Utils.shared().hideLoading(), 200 != t) {
                ;
            }
            else {
                try {
                    let e = ToolUtils.parseJson(a);
                    0 == e.ret && (this.gameShareConfig = e.data);
                }
                catch (e) {
                    TLog.printError("requestShareGetGameShare err:", e.toString());
                }
            }
        }));
    }
    checkCanShowGameRating() {
        if (1 == this.gp_rating_open) {
            if (sys.now() / 1000 - this.last_rating_time >= 3600 * this.gp_rating_lock_hour && sys.isObjectValid(this.ratingTradeNo)) {
                return true;
            }
        }
        return false;
    }
    requestGameRatingPage(a = null) {
        HttpManager.shared().doGetCommonRequest(a, HttpRequest.GameRatingPage, ((a, t, i) => {
            if (Utils.shared().hideLoading(), 200 != i) {
                ;
            }
            else {
                try {
                    User.shared().ratingTradeNo = null;
                    let a = ToolUtils.parseJson(t);
                    0 == a.ret ? Utils.shared().doJumpLogic(PushEvent.JUMP_TO_GameRatingAlert, a.data) : 1 == a.ret && sys.isObjectValid(a.desc) && ToolUtils.isSafeString(a.desc).length > 0 && Utils.shared().showToast(a.desc, 2);
                }
                catch (e) {
                    TLog.printError("requestGameRatingPage err:", e.toString());
                }
            }
        }));
    }
    requestGameRatingSubmitData(e = null, a = null) {
        HttpManager.shared().doGetCommonRequest(e, HttpRequest.GameRatingSubmitData, ((e, t, i) => {
            if (Utils.shared().hideLoading(), 200 != i) {
                ;
            }
            else {
                try {
                    let e = ToolUtils.parseJson(t), i = i18nMgr.shared().getValueByKey("suggestion.toast1");
                    sys.isObjectValid(e.desc) && ToolUtils.isSafeString(e.desc).length > 0 && (i = e.desc);
                    0 == e.ret && a && (Utils.shared().showToast(i, 2), a());
                }
                catch (e) {
                    TLog.printError("requestGameRatingSubmitData err:", e.toString());
                }
            }
        }));
    }
    requestGameRatingFinishRating(e = null) {
        HttpManager.shared().doGetCommonRequest(e, HttpRequest.GameRatingFinishRating, ((e, a, t) => {
            if (Utils.shared().hideLoading(), 200 != t) {
                ;
            }
            else {
                try {
                    let e = ToolUtils.parseJson(a);
                    0 == e.ret && sys.isObjectValid(e.data) && sys.isObjectValid(e.data.gp_rating_open) && (this.gp_rating_open = e.data.gp_rating_open);
                }
                catch (e) {
                    TLog.printError("requestGameRatingFinishRating err:", e.toString());
                }
            }
        }));
    }
    requestRestartGiftPage(e = null, a = null) {
        HttpManager.shared().doGetCommonRequest(e, HttpRequest.RestartGiftPage, ((e, t, s) => {
            if (Utils.shared().hideLoading(), 200 != s) {
                ;
            }
            else {
                try {
                    let e = ToolUtils.parseJson(t);
                    0 == e.ret && a && a(e.data);
                }
                catch (e) {
                    TLog.printError("requestRestartGiftPage err:", e.toString());
                }
            }
        }));
    }
    requestBagPackPage(e = null) {
        HttpManager.shared().doGetCommonRequest(null, HttpRequest.BackPackPage, ((a, t, i) => {
            if (Utils.shared().hideLoading(), 200 != i) {
                ;
            }
            else {
                try {
                    let a = ToolUtils.parseJson(t);
                    0 == a.ret && sys.isObjectValid(a.data) && (e ? e(a.data) : this.backPackData = a.data, this.judgePushBagItemUpdateEvent());
                }
                catch (e) {
                    TLog.printError("User requestBagPackPage err:", e.toString());
                }
            }
        }));
    }
    requestFaqMain(e) {
        e && Utils.shared().showLoading(10, true, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
        }), ToolUtils.getIsNormalDirection());
        HttpManager.shared().doGetCommonRequest(null, HttpRequest.FaqMainPage, ((e, a, t) => {
            if (Utils.shared().hideLoading(), 200 != t) {
                ;
            }
            else {
                try {
                    let e = ToolUtils.parseJson(a);
                    0 == e.ret && sys.isObjectValid(e.data) && (this.faqMainData = e.data, PushCenter.shared().pushEvent(PushEvent.RefreshFaqMain));
                }
                catch (e) {
                    TLog.printError("User requestBagPackPage err:", e.toString());
                }
            }
        }));
    }
    requestDailySalePage(a = null) {
        HttpManager.shared().doGetCommonRequest(null, HttpRequest.DailyFireSalePage, ((t, s, i) => {
            if (200 != i) {
                Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.request_fail"), 2);
            }
            else {
                let t = ToolUtils.parseJson(s);
                0 == t.ret ? (User.shared().dailyFireSaleData = t.data, a && a(t.data)) : ToolUtils.isSafeString(t.desc).length > 0 && (Utils.shared().showToast(ToolUtils.isSafeString(t.desc), 2), PushCenter.shared().pushEvent(PushEvent.PurchasedFirstRecharge), PushCenter.shared().pushEvent(PushEvent.CloseDailyFireSale));
            }
        }));
    }
    requestHisGameRecord(e) {
        HttpManager.shared().doGetCommonRequest({ s_uid: e }, HttpRequest.GetHistoryData, ((a, t, i) => {
            if (200 != i) {
                Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.request_fail"), 2);
            }
            else {
                try {
                    let a = ToolUtils.parseJson(t);
                    if (0 == a.ret) {
                        if (!e || !sys.isObjectValid(a.data)) {
                            return;
                        }
                        let t = sys.now() / 1000;
                        this.hisGameRecord.set(e, { req_time: t, record_arr: a.data });
                        PushCenter.shared().pushEvent(PushEvent.UpdateMagicHisView, { id: e, arr: a.data });
                    }
                    else {
                        sys.isObjectValid(a.desc) && a.desc.length > 0 && Utils.shared().showToast(a.desc, 2);
                    }
                }
                catch (e) {
                    TLog.printError("requestHisGameRecord err:", e.toString());
                }
            }
        }));
    }
    requestConfirmKycOtpVerify(e = null) {
        HttpManager.shared().doGetCommonRequest(null, HttpRequest.KycConfirmOtpVerify, ((a, t, i) => {
            if (200 != i) {
                ;
            }
            else {
                let e = ToolUtils.parseJson(t);
                0 == e.ret && sys.isObjectValid(e.data) && sys.isObjectValid(e.data.kyc_otp_check) && (this.data.kyc_otp_check = e.data.kyc_otp_check);
            }
            e && e();
        }));
    }
    showLogin(e = false) {
        LabaServer.shared().reset();
        Server.shared().reset();
        localStorage.setItem("logintype", "-1");
        this.loginType = "-1";
        this.bBackToLogin = true;
        this.cleanLocalRoomTable();
        TransferPlatform.shared().setHighFrameRate();
        AppInfo.shared().orientationToPortrait();
        window.InHallScene = false;
        director.loadScene("login");
    }
    showWebWithdrawAddView() {
        sys.isObjectValid(User.shared().withdrawData) || (User.shared().requestWithDrawPage(0), this.requestDepositTransferPage());
        Utils.shared().showWithdrawAddView(null, (e => {
            1 == e && Utils.shared().openLastCloseWebView();
        }), 1);
    }
    showWebPanVerify(e) {
    }
    fastBuy(e) {
        let a = { parent_node: director.getScene().getChildByName("Canvas"), bShowNetTip: true, in_room: 1, is_pop: 1 };
        sys.isObjectValid(e) && Object.keys(e).sort().forEach((function (t) {
            a[t] = e[t];
        }));
        Utils.shared().showQuickRecharge(a);
    }
    getCurModeVec(e) {
        let a = [PointsType.Classic];
        return 0 == e ? 1 == this.double_6_open && (a = [PointsType.Classic, PointsType.Double]) : 3 == e && 1 == this.chip_double_6_open && (a = [PointsType.Classic, PointsType.Double]), a;
    }
}
