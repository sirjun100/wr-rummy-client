// @ts-nocheck
// Recovered from index.js:235
import { _decorator, Component, Label, Node, sp, SpriteAtlas, v3 } from "cc";
import TweenTool from "./TweenTool";
import { ToolUtils } from "./ToolUtils";
import GameConfig from "./GameConfig";
const { ccclass, property } = _decorator;
@ccclass("loading")
export default class LoadingNode extends Component {
    @property(Label)
    public label: Label = null;
    @property(Node)
    public touchLayer: Node = null;
    @property(SpriteAtlas)
    public animAtlas: SpriteAtlas = null;
    @property(Node)
    public LoadingAnim: Node = null;
    public time: number = 10;
    public _cb: any = null;
    onLoad() {
        this.node.active = false;
    }
    onDestroy() {
        TweenTool.stopNodeAction(this.node);
        this.unscheduleAllCallbacks();
    }
    onClickClose(t, i) {
        ToolUtils.isObjValid(this.node) && this.node.destroy();
    }
    showLoading(t, i, e, n, o, s = 0.5) {
        let l = this.LoadingAnim.getComponent(sp.Skeleton), a = "ani_Rummy_loading";
        1 == GameConfig.CHIPS_MODLE && (a = "ani_Rummy_loading2");
        l.setAnimation(0, a, true);
        this.time = t;
        i = 1 == i;
        this.touchLayer.active = i;
        TweenTool.delayAct(this.node, (() => {
            this.node.active = true;
        }), s, true);
        n || this.node.setRotationFromEuler(v3(0, 0, 90));
        this.unscheduleAllCallbacks();
        this.schedule(this.stopShowTime.bind(this), 1);
        e && (this._cb = e);
    }
    stopShowTime() {
        this.time--;
        this.time <= 0 && (this._cb && this._cb(), ToolUtils.isObjValid(this.node) && this.node.destroy());
    }
    hideLoading() {
        ToolUtils.isObjValid(this.node) && this.node.destroy();
    }
    setTip(t, i) {
        this.label.string = t;
        this.time = i;
    }
}
