// @ts-nocheck
// Recovered from index.js:463
import { _decorator, Label, RichText, sys } from "cc";
import i18nMgr from "./i18nMgr";
import TweenTool from "./TweenTool";
import SoundManager from "./SoundManager";
import BaseLayer from "./BaseLayer";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("RummyMatchRebuy")
export class RummyMatchRebuy extends BaseLayer {
    @property(RichText)
    public contentlabel: RichText = null;
    @property(Label)
    public leftTimelabel: Label = null;
    public action_node: any = null;
    public time_action: any = null;
    public money: number = 0;
    public reload: number = 0;
    public leftTime: number = 0;
    public callfunc: any = null;
    public lastClick: number = 0;
    setParaData(t, e, i, s, l) {
        this.action_node = t;
        this.money = e;
        this.reload = i;
        this.leftTime = s;
        this.callfunc = l;
    }
    updateMatchRebuy(t, e) {
        this.money = t;
        this.reload = e;
        this.reInitView();
    }
    onLoad() {
        this.bIsInGame = true;
    }
    start() {
        super.start();
        this.initView();
        ToolUtils.startShowAnim(this.node.getChildByName("rootNode"));
    }
    initView() {
        let t = ToolUtils.format(i18nMgr.shared().getValueByKey("match_game_rebuy.insufficient_pts"), this.money, this.reload);
        this.contentlabel.string = t;
        i18nMgr.shared().changeLabelFont(this.contentlabel);
        this.leftTime > 0 ? (this.leftTimelabel.string = ToolUtils.format(i18nMgr.shared().getValueByKey("match_game_rebuy.second"), this.leftTime), i18nMgr.shared().changeLabelFont(this.leftTimelabel), this.leftTimelabel.node.active = true) : this.leftTimelabel.node.active = false;
        this.time_action = TweenTool.myschedule(this.action_node, 1, this.updateTime.bind(this));
    }
    reInitView() {
        let t = ToolUtils.format(i18nMgr.shared().getValueByKey("match_game_rebuy.insufficient_pts"), this.money, this.reload);
        this.contentlabel.string = t;
        i18nMgr.shared().changeLabelFont(this.contentlabel);
    }
    updateTime() {
        ToolUtils.isObjValid(this.node) && (this.leftTime = this.leftTime - 1, this.leftTime > 0 ? (this.leftTimelabel.string = ToolUtils.format(i18nMgr.shared().getValueByKey("match_game_rebuy.second"), this.leftTime), i18nMgr.shared().changeLabelFont(this.leftTimelabel)) : ToolUtils.isObjValid(this.node) && (this.callfunc("close"), this.node.destroy()));
    }
    onButtonClick(t, e) {
        if (SoundManager.shared().playFx("click"), "ok" == e) {
            if (sys.now() - this.lastClick < 1000) {
                return;
            }
            this.lastClick = sys.now();
            this.callfunc && this.callfunc(this.money);
        }
        else {
            this.callfunc && this.callfunc("close");
            ToolUtils.isObjValid(this.node) && this.node.destroy();
        }
    }
    stopAction() {
        this.time_action && (TweenTool.stopAction(this.time_action), this.time_action = null);
    }
    onDestroy() {
        super.onDestroy();
        this.stopAction();
    }
    setTidKey(t) {
        this.tid_key = t;
    }
    onBackView() {
    }
}
