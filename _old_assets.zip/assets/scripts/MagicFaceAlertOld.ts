// @ts-nocheck
// Recovered from index.js:285
import { _decorator, Button, instantiate, Label, Node, ScrollView, size, Sprite, SpriteAtlas, SpriteFrame, sys, UITransform, v3, Vec3 } from "cc";
import SoundManager from "./SoundManager";
import Utils from "./Utils";
import TweenTool from "./TweenTool";
import { AdapDirection } from "./Parent";
import GameConfig from "./GameConfig";
import PushCenter from "./PushCenter";
import BaseLayer from "./BaseLayer";
import User from "./User";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("MagicFaceAlertOld")
export default class MagicFaceAlertOld extends BaseLayer {
    @property(SpriteAtlas)
    public myAtlas: SpriteAtlas = null;
    @property([SpriteFrame])
    public face_imgs: SpriteFrame[] = [];
    @property(Node)
    public bgNode: Node = null;
    @property(Node)
    public faceList: Node = null;
    @property(Node)
    public faceModelNode: Node = null;
    @property(Node)
    public rootNode: Node = null;
    @property(Label)
    public nameLable: Label = null;
    @property(Label)
    public moneyLable: Label = null;
    @property(Sprite)
    public headSp: Sprite = null;
    @property(Node)
    public clubKuang: Node = null;
    @property([Vec3])
    public vecMoneyPos: Vec3[] = [];
    @property(Label)
    public rankLable: Label = null;
    @property(Node)
    public balanceTitleNode: Node = null;
    @property(SpriteAtlas)
    public clubKuangAtlas: SpriteAtlas = null;
    public cb_face: any = null;
    public cb_text: any = null;
    public target_seatid: number = 0;
    public _showPos: any = v3(0, 0, 0);
    public _chatFaceCount: number = 13;
    public magicexpressioncost: number = 0;
    public bIsInPrivateRoom: boolean = false;
    public bIsPracticeRoom: boolean = false;
    public bIsMatchRoom: boolean = false;
    public bIsSend: boolean = false;
    public cur_uid: any = null;
    onLoad() {
        this.bIsSend = false;
        this.fitScreen();
        this.bIsInGame = true;
        this._chatFaceCount = this.face_imgs.length;
        PushCenter.shared().addListener(GameConfig.Close_Magic_View, (e => {
            ToolUtils.isObjValid(this.node) && Number(e) >= 0 && e === this.target_seatid && ToolUtils.isObjValid(this.node) && this.node.destroy();
        }), this);
        PushCenter.shared().addListener(GameConfig.Update_Bonus, (e => {
            if (ToolUtils.isObjValid(this.node) && this.cur_uid == User.shared().data.uid && !this.bIsPracticeRoom) {
                let e = this.rootNode.getChildByName("bonus"), t = User.shared().data.bonus, i = "₹" + ToolUtils.parse_double(t + "");
                e.getComponent(Label).string = i;
            }
        }), this);
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().removeListenersByTag(this);
        this.unscheduleAllCallbacks();
    }
    fitScreen() {
        if (ToolUtils.showFullScreen(this.node.getChildByName("pingbi")), ToolUtils.showFullScreen(this.node.getChildByName("bg").getChildByName("bg1")), GameConfig.REAL_SCREEN_WIDTH <= GameConfig.CONFIG_SCREEN_WIDTH && this.resetUiPos(this.rootNode, AdapDirection.Right, true, 1, true, true), ToolUtils.isPadPlatform()) {
            let e = (GameConfig.REAL_SCREEN_WIDTH - 720) / 4;
            this.rootNode.setPosition(v3(this.rootNode.position.x, this.rootNode.position.y + e / 2, this.rootNode.position.z));
            let t = this.bgNode.getComponent(UITransform).contentSize;
            this.bgNode.getComponent(UITransform).setContentSize(size(t.width, t.height + e));
            t = this.faceList.getComponent(UITransform).contentSize;
            this.faceList.getComponent(UITransform).setContentSize(size(t.width, t.height + e));
        }
    }
    start() {
        super.start();
        this.initCostView();
    }
    initCostView() {
        let e = this.faceList.getComponent(ScrollView).content;
        e.destroyAllChildren();
        for (let t = 0, i = this._chatFaceCount; t < i; t++) {
            let i = instantiate(this.faceModelNode);
            i.getChildByName("magic").getComponent(Sprite).spriteFrame = this.face_imgs[t];
            i.getChildByName("cashAmtNode").active = !this.bIsPracticeRoom;
            i.getChildByName("chipAmtNode").active = this.bIsPracticeRoom;
            this.bIsPracticeRoom ? i.getChildByName("chipAmtNode").getChildByName("chipAmt").getComponent(Label).string = "" + this.magicexpressioncost || "" : i.getChildByName("cashAmtNode").getComponent(Label).string = "₹" + this.magicexpressioncost || "";
            i.getComponent(Button).clickEvents[0].customEventData = String(t);
            i.active = true;
            e.addChild(i);
        }
    }
    startShowAnim() {
        this.node.position = v3(100, 0, 0);
        let e = v3(0, 0, 0);
        TweenTool.moveTo(this.node, 0.15, e, "fade", true, (() => {
        }));
    }
    setIsInPrivateRoom(e) {
        this.bIsInPrivateRoom = e;
    }
    setIsPracticeRoom(e) {
        this.bIsPracticeRoom = e;
        e && (this.rootNode.getChildByName("balance").active = true, this.rootNode.getChildByName("money").active = true, this.rootNode.getChildByName("chip_title").active = true, this.rootNode.getChildByName("chip").active = true, this.rootNode.getChildByName("money").setPosition(this.vecMoneyPos[0]));
    }
    setIsMatchRoom(e) {
    }
    updatePlayerInfo(e) {
        let t = e.pmodel, i = e.money, o = t.avatar, s = t.avatar_url, n = (t.club_level, this.rootNode.getChildByName("chip")), a = ToolUtils.isSafeNumber(t.avatar_frame_id), r = t.uid, c = t.name;
        i <= 0 && (i = 0);
        let u = ToolUtils.parse_double(i + "");
        if (this.bIsPracticeRoom ? n.getComponent(Label).string = "" + ToolUtils.parse_ChipNum2(i) : this.moneyLable.string = "₹" + u, this.nameLable.string = ToolUtils.GetShortName2(c, 12, true), o && o.length > 0 && Utils.shared().updateHeadImg(this.headSp.node, o, s, size(84, 84)), sys.isObjectValid(User.shared().data.club) && 1 == User.shared().data.club.show_room_avatar_frame) {
            let e = a;
            this.clubKuang.active = e > 0;
            e > 0 && e <= 9 && Utils.shared().setImage(this.clubKuang, ToolUtils.format("club_headkuang${0}", e), this.clubKuangAtlas);
        }
        let m = this.rootNode.getChildByName("icon"), g = this.rootNode.getChildByName("bonus_title"), p = this.rootNode.getChildByName("bonus"), y = this.rootNode.getChildByName("chip_title");
        if (this.cur_uid = r, r != User.shared().data.uid || this.bIsPracticeRoom) {
            if (g.active = false, p.active = false, this.vecMoneyPos[0].y = 274, this.bIsPracticeRoom) {
                if (this.vecMoneyPos[0].y = 285, r != User.shared().data.uid) {
                    this.balanceTitleNode.active = false;
                    this.moneyLable.node.active = false;
                    this.nameLable.node.setPosition(new Vec3(453, 312));
                    y.setPosition(new Vec3(453, 283));
                    n.setPosition(new Vec3(533, 283));
                }
                else {
                    let e = User.shared().data.money;
                    u = "₹" + ToolUtils.parse_double(e + "");
                    this.moneyLable.string = u;
                    this.nameLable.node.setPosition(new Vec3(453, 322));
                    this.balanceTitleNode.setPosition(v3(453, 293));
                    this.moneyLable.node.setPosition(v3(533, 293));
                    y.setPosition(new Vec3(453, 271));
                    n.setPosition(new Vec3(532.702, 271));
                }
            }
            else {
                this.nameLable.node.setPosition(new Vec3(453, 312));
                this.balanceTitleNode.setPosition(new Vec3(453, 283));
                this.moneyLable.node.setPosition(new Vec3(533, 283));
            }
            m.setPosition(new Vec3(461, 274));
            m.active = false;
        }
        else {
            g.active = true;
            p.active = true;
            let e = User.shared().data.bonus;
            u = "₹" + ToolUtils.parse_double(e + "");
            p.getComponent(Label).string = u;
            g.setPosition(new Vec3(453, 271));
            p.setPosition(new Vec3(533, 271));
            this.nameLable.node.setPosition(new Vec3(453, 322));
            this.balanceTitleNode.setPosition(new Vec3(453, 293));
            this.moneyLable.node.setPosition(new Vec3(533, 293));
            m.setPosition(new Vec3(460, 309));
            this.vecMoneyPos[0].y = 283;
        }
    }
    setFaceCallback(e) {
        this.cb_face = e;
    }
    setTargetClientId(e) {
        this.target_seatid = e;
    }
    onClickByFace(e, t) {
        this.bIsSend || (this.bIsSend = true, SoundManager.shared().playFx("click"), this.cb_face(t, this.target_seatid), this.bIsInPrivateRoom ? this.scheduleOnce((() => {
            this.bIsSend = false;
        }), 0.7) : ToolUtils.isObjValid(this.node) && this.node.destroy());
    }
    onClickClose(e, t) {
        SoundManager.shared().playFx("click");
        let i = new Vec3;
        this.node.getPosition(i);
        let o = v3(i.x, i.y - 350, 0);
        ToolUtils.getOrientation() && (o = v3(i.x + 350, i.y, 0));
        TweenTool.moveTo(this.node, 0.15, o, "fade", true, (() => {
            ToolUtils.isObjValid(this.node) && this.node.destroy();
        }));
    }
    setLandscapeShow() {
        ToolUtils.getOrientation() || this.node.setRotationFromEuler(v3(0, 0, -90));
    }
    setTidKey(e) {
        this.tid_key = e;
    }
}
