// @ts-nocheck
// Recovered from index.js:571
import { _decorator, director, instantiate, isValid, sys } from "cc";
import Utils from "./Utils";
import i18nMgr from "./i18nMgr";
import HttpManager from "./HttpManager";
import { HttpRequest } from "./HttpRequestName";
import { TLog } from "./TLog";
import { ToolUtils } from "./ToolUtils";
import { SportCricket_TeamStatsCmp } from "./SportCricket_TeamStatsCmp";
import User from "./User";
import PushEvent from "./PushEvent";
import BundleNameDefined from "./BundleNameDefined";
const { ccclass } = _decorator;
@ccclass("SportCricket_Manager")
export default class SportCricket_Manager {
    static _instance = null;
    public _TAG: string = "SportCricket_Manager";
    public _initLoad: boolean = false;
    public cricket_curMatchId: number = 0;
    public cricket_curTeamNum: number = 0;
    public cricket_completeInfo: any[] = [];
    public cricket_backup_open: number = 1;
    public cricket_notInLineUpMap: Map = new Map;
    public cricket_playerInfoMap: Map = new Map;
    public cricket_playerDetailsMap: Map = new Map;
    public cricket_matchBestTeamMap: Map = new Map;
    public cricket_matchStatTeamMap: Map = new Map;
    public cricket_recentMatchTeamMap: Map = new Map;
    public cricket_venueMatchMap: Map = new Map;
    public cricket_teamPkMatchMap: Map = new Map;
    public cricket_teamLeaderBoardMap: Map = new Map;
    public cricket_teamCompareMap: Map = new Map;
    public cricket_teamStatsOpen: number = 0;
    public checkDeepLink: number = 0;
    public deepLinkData: any = null;
    public sortSourceData: any = null;
    static shared() : SportCricket_Manager {
        return null == this._instance && (this._instance = new SportCricket_Manager), this._instance;
    }
    init() {
    }
    updateMatchLineUpMap(e) {
        if (this.cricket_notInLineUpMap.clear(), e.length > 0) {
            for (let t = 0; t < e.length; t++) {
                this.cricket_notInLineUpMap.set(Number(e[t]), 1);
            }
        }
    }
    dealShareYesGameLogic(t) {
        try {
            if (0 == User.shared().cricket_open) {
                return;
            }
            if (sys.isObjectValid(t)) {
                let a = ToolUtils.parseJson(t);
                if (sys.isObjectValid(a) && (TLog.printError(this._TAG, "dealShareYesGameLogic:_data:", a), sys.isObjectValid(a.o_uid))) {
                    if (a.o_uid == User.shared().data.uid) {
                        return;
                    }
                    if (SportCricket_Manager.shared().checkYes11MainShown()) {
                        return;
                    }
                    SportCricket_Manager.shared().checkDeepLink = 1;
                    SportCricket_Manager.shared().deepLinkData = a;
                    let t = { lastNode: Utils.shared().hall_rootNode };
                    Utils.shared().doJumpLogic(PushEvent.JUMP_TO_Yes11, t);
                }
            }
        }
        catch (e) {
            TLog.printError("MainHall", "dealShareYesGameLogic:", e);
        }
    }
    requestYes11_PreCreateTeamCheck(e, t, a) {
        t && Utils.shared().showLoading(10, true, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
        }), ToolUtils.getIsNormalDirection());
        HttpManager.shared().doGetCommonRequest(e, HttpRequest.Yes11_CreateTeamCheck, ((e, t, i) => {
            if (Utils.shared().hideLoading(), 200 != i) {
                ;
            }
            else {
                try {
                    let e = ToolUtils.parseJson(t);
                    0 == e.ret ? sys.isObjectValid(e.data) && a && a(e.data) : sys.isObjectValid(e.desc) && e.desc.length > 0 && Utils.shared().showToast(e.desc, 2);
                }
                catch (e) {
                    TLog.printError("User requestYes11_PreCreateTeamCheck err:", e.toString());
                }
            }
        }));
    }
    requestYes11_CheckJoinTeamList(e, t, a) {
        t && Utils.shared().showLoading(10, true, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
        }), ToolUtils.getIsNormalDirection());
        HttpManager.shared().doGetCommonRequest(e, HttpRequest.Yes11_CheckJoinTeamList, ((e, t, i) => {
            if (Utils.shared().hideLoading(), 200 != i) {
                ;
            }
            else {
                try {
                    let e = ToolUtils.parseJson(t);
                    0 == e.ret ? sys.isObjectValid(e.data) && a && a(e.data) : sys.isObjectValid(e.desc) && e.desc.length > 0 && Utils.shared().showToast(e.desc, 2);
                }
                catch (e) {
                    TLog.printError("User requestYes11_CheckJoinTeamList err:", e.toString());
                }
            }
        }));
    }
    requestYes11_PreJoinGameCheck(e, t, a) {
        t && Utils.shared().showLoading(10, true, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
        }), ToolUtils.getIsNormalDirection());
        HttpManager.shared().doGetCommonRequest(e, HttpRequest.Yes11_PreJoinGameCheck, ((e, t, i) => {
            if (Utils.shared().hideLoading(), 200 != i) {
                ;
            }
            else {
                try {
                    let e = ToolUtils.parseJson(t);
                    0 == e.ret ? sys.isObjectValid(e.data) && a && a(e.data) : 408500 == e.ret ? this.showSportCricket_addCashTip() : sys.isObjectValid(e.desc) && e.desc.length > 0 && Utils.shared().showToast(e.desc, 2);
                }
                catch (e) {
                    TLog.printError("User requestYes11_PreJoinGameCheck err:", e.toString());
                }
            }
        }));
    }
    requestYes11_JoinList(e, t, a) {
        t && Utils.shared().showLoading(10, true, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
        }), ToolUtils.getIsNormalDirection());
        HttpManager.shared().doGetCommonRequest(e, HttpRequest.Yes11_JoinTeamList, ((e, t, i) => {
            if (Utils.shared().hideLoading(), 200 != i) {
                ;
            }
            else {
                try {
                    let e = ToolUtils.parseJson(t);
                    0 == e.ret ? sys.isObjectValid(e.data) && a && a(e.data) : sys.isObjectValid(e.desc) && e.desc.length > 0 && Utils.shared().showToast(e.desc, 2);
                }
                catch (e) {
                    TLog.printError("User requestBagPackPage err:", e.toString());
                }
            }
        }));
    }
    requestYes11_SwitchList(e, t, a) {
        t && Utils.shared().showLoading(10, true, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
        }), ToolUtils.getIsNormalDirection());
        HttpManager.shared().doGetCommonRequest(e, HttpRequest.Yes11_SwitchTeamList, ((e, t, i) => {
            if (Utils.shared().hideLoading(), 200 != i) {
                ;
            }
            else {
                try {
                    let e = ToolUtils.parseJson(t);
                    0 == e.ret ? sys.isObjectValid(e.data) && a && a(e.data) : sys.isObjectValid(e.desc) && e.desc.length > 0 && Utils.shared().showToast(e.desc, 2);
                }
                catch (e) {
                    TLog.printError("User requestYes11_SwitchList err:", e.toString());
                }
            }
        }));
    }
    requestYes11_SwitchTeam(e, t, a) {
        t && Utils.shared().showLoading(10, true, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
        }), ToolUtils.getIsNormalDirection());
        HttpManager.shared().doGetCommonRequest(e, HttpRequest.Yes11_SwitchTeam, ((e, t, i) => {
            if (Utils.shared().hideLoading(), 200 != i) {
                ;
            }
            else {
                try {
                    let e = ToolUtils.parseJson(t);
                    0 == e.ret ? sys.isObjectValid(e.data) && a && a(e.data) : sys.isObjectValid(e.desc) && e.desc.length > 0 && Utils.shared().showToast(e.desc, 2);
                }
                catch (e) {
                    TLog.printError("User requestYes11_SwitchTeam err:", e.toString());
                }
            }
        }));
    }
    requestYes11_PlayerInfo(e, t) {
        let a = null;
        if (sys.isObjectValid(e.player_id) && this.cricket_playerInfoMap.has(e.player_id) && (a = this.cricket_playerInfoMap.get(e.player_id)), sys.isObjectValid(a)) {
            return sys.isObjectValid(e.role) && (a.role = e.role), sys.isObjectValid(e.join_team) && Array.isArray(e.join_team) && (a.join_team = e.join_team), e.player_source = a, void Utils.shared().showSportCricket_playerMain(e);
        }
        t && Utils.shared().showLoading(10, true, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
        }), ToolUtils.getIsNormalDirection());
        let i = { match_id: e.match_id, player_id: e.player_id };
        HttpManager.shared().doGetCommonRequest(i, HttpRequest.Yes11_PlayerInfo, ((t, i, r) => {
            if (Utils.shared().hideLoading(), 200 != r) {
                ;
            }
            else {
                try {
                    let t = ToolUtils.parseJson(i);
                    0 == t.ret ? sys.isObjectValid(t.data) && (a = t.data, sys.isObjectValid(e.role) && (a.role = e.role), sys.isObjectValid(e.join_team) && Array.isArray(e.join_team) && (a.join_team = e.join_team), e.player_source = a, this.cricket_playerInfoMap.set(e.player_id, a), Utils.shared().showSportCricket_playerMain(e)) : sys.isObjectValid(t.desc) && t.desc.length > 0 && Utils.shared().showToast(t.desc, 2);
                }
                catch (e) {
                    TLog.printError("User requestYes11_PlayerInfo err:", e.toString());
                }
            }
        }));
    }
    requestYes11_PlayerDetailList(e, t, a = false, i = null) {
        let r = { match_id: e, player_id: t };
        a && Utils.shared().showLoading(10, true, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
        }), ToolUtils.getIsNormalDirection());
        HttpManager.shared().doGetCommonRequest(r, HttpRequest.Yes11_EndPlayerDetail, ((r, d, l) => {
            if (Utils.shared().hideLoading(), 200 != l) {
                a && Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.request_fail"), 2);
            }
            else {
                try {
                    let r = ToolUtils.parseJson(d);
                    0 == r.ret ? sys.isObjectValid(r.data) && (this.cricket_playerDetailsMap.set(e + "_" + t, r.data), i && i(r.data)) : a && ToolUtils.isSafeString(r.desc).length > 0 && Utils.shared().showToast(r.desc, 3);
                }
                catch (e) {
                    TLog.printError("requestDetailList err:", e.toString());
                }
            }
        }));
    }
    requestYes11_showLeaderTeam(e, t, a, i = false, r) {
        let d = { match_id: e, team_id: t, session_id: a };
        this.cricket_teamLeaderBoardMap.has(e + "_" + t) ? this.dealCominePreviewLogic(this.cricket_teamLeaderBoardMap.get(e + "_" + t), r, null, 2, a) : (i && Utils.shared().showLoading(10, true, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
        }), ToolUtils.getIsNormalDirection()), HttpManager.shared().doGetCommonRequest(d, HttpRequest.Yes11_GetLeaderboardTeam, ((d, l, h) => {
            if (Utils.shared().hideLoading(), 200 != h) {
                i && Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.request_fail"), 2);
            }
            else {
                try {
                    let d = ToolUtils.parseJson(l);
                    0 == d.ret ? sys.isObjectValid(d.data) && (d.data.match_id = e, this.cricket_teamLeaderBoardMap.set(e + "_" + t, d.data), this.dealCominePreviewLogic(d.data, r, null, 2, a)) : i && ToolUtils.isSafeString(d.desc).length > 0 && Utils.shared().showToast(d.desc, 3);
                }
                catch (e) {
                    TLog.printError("requestDetailList err:", e.toString());
                }
            }
        })));
    }
    requestYes11_showBestTeam(e, t, a = false, i) {
        let r = { match_id: e };
        0 != t && (r.session_id = t);
        this.cricket_matchBestTeamMap.has(e) ? this.dealCominePreviewLogic(this.cricket_matchBestTeamMap.get(e), i, null, 1, t) : (a && Utils.shared().showLoading(10, true, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
        }), ToolUtils.getIsNormalDirection()), HttpManager.shared().doGetCommonRequest(r, HttpRequest.Yes11_GetBestTeam, ((r, d, l) => {
            if (Utils.shared().hideLoading(), 200 != l) {
                a && Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.request_fail"), 2);
            }
            else {
                try {
                    let r = ToolUtils.parseJson(d);
                    0 == r.ret ? sys.isObjectValid(r.data) && (r.data.match_id = e, this.cricket_matchBestTeamMap.set(e, r.data), this.dealCominePreviewLogic(r.data, i, null, 1, t)) : a && ToolUtils.isSafeString(r.desc).length > 0 && Utils.shared().showToast(r.desc, 3);
                }
                catch (e) {
                    TLog.printError("requestDetailList err:", e.toString());
                }
            }
        })));
    }
    searchCompareTeamData(e, t, a, i, r = false, d) {
        let _ = String(e) + "_" + String(t) + "_" + String(a);
        i > 0 && (_ = String(e) + "_" + String(t) + "_" + String(a) + "_" + String(i));
        this.cricket_teamCompareMap.has(_) && d && d(this.cricket_teamCompareMap.get(_));
        r && Utils.shared().showLoading(10, true, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
        }), ToolUtils.getIsNormalDirection());
        let p = { match_id: e, compare_team_id: t, other_team_id: a };
        i > 0 && (p.session_id = i);
        HttpManager.shared().doGetCommonRequest(p, HttpRequest.Yes11_CompareTeam, ((e, t, a) => {
            if (Utils.shared().hideLoading(), 200 != a) {
                r && Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.request_fail"), 2);
            }
            else {
                try {
                    let e = ToolUtils.parseJson(t);
                    0 == e.ret ? sys.isObjectValid(e.data) && (this.cricket_teamCompareMap.set(_, e.data), d && d(e.data)) : r && ToolUtils.isSafeString(e.desc).length > 0 && Utils.shared().showToast(e.desc, 3);
                }
                catch (e) {
                    TLog.printError("requestYes11_showCompareTeam err:", e.toString());
                }
            }
        }));
    }
    requestYes11_showCompareTeam(e, t, a, i, r = false, d = false, _) {
        let p = { match_id: e, compare_team_id: t, other_team_id: a }, u = String(e) + "_" + String(t) + "_" + String(a);
        if (i > 0 && (p.session_id = i, u = String(e) + "_" + String(t) + "_" + String(a) + "_" + String(i)), this.cricket_teamCompareMap.has(u)) {
            let s = { source: this.cricket_teamCompareMap.get(u), match_id: e, my_teamId: t, vs_teamId: a, session_id: i, is_best: d, lastNode: _ };
            Utils.shared().showSportCricket_playerTeamCompareView(s);
        }
        else {
            r && Utils.shared().showLoading(10, true, (() => {
                Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
            }), ToolUtils.getIsNormalDirection());
            HttpManager.shared().doGetCommonRequest(p, HttpRequest.Yes11_CompareTeam, ((l, h, p) => {
                if (Utils.shared().hideLoading(), 200 != p) {
                    r && Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.request_fail"), 2);
                }
                else {
                    try {
                        let c = ToolUtils.parseJson(h);
                        if (0 == c.ret) {
                            if (sys.isObjectValid(c.data)) {
                                this.cricket_teamCompareMap.set(u, c.data);
                                let s = { source: this.cricket_teamCompareMap.get(u), match_id: e, my_teamId: t, vs_teamId: a, session_id: i, is_best: d, lastNode: _ };
                                Utils.shared().showSportCricket_playerTeamCompareView(s);
                            }
                        }
                        else {
                            r && ToolUtils.isSafeString(c.desc).length > 0 && Utils.shared().showToast(c.desc, 3);
                        }
                    }
                    catch (e) {
                        TLog.printError("requestYes11_showCompareTeam err:", e.toString());
                    }
                }
            }));
        }
    }
    dealStatTeamView(e, t) {
        if (sys.isObjectValid(e) && sys.isObjectValid(e.fromType)) {
            if (e.team_source = t, 0 == e.fromType) {
                if (ToolUtils.isObjValid(e.contentNode)) {
                    let t = e.contentNode.getChildByName("cricket_teamstatscmp");
                    ToolUtils.isObjValid(t) ? (t.getComponent(SportCricket_TeamStatsCmp).init(e), t.getComponent(SportCricket_TeamStatsCmp).refreshView()) : Utils.shared().showSportCricket_loadTeamStatViewCmp((t => {
                        if (isValid(t, true)) {
                            let a = instantiate(t);
                            a.parent = e.contentNode;
                            let s = a.getComponent("SportCricket_TeamStatsCmp");
                            s.init(e);
                            s.refreshView();
                        }
                    }));
                }
            }
            else {
                Utils.shared().showSportCricket_fullTeamStatView(e);
            }
        }
    }
    showSportCricket_addCashTip(e = null) {
        let t = ToolUtils.judgeIfInHall();
        if (t) {
            let a = "prefab/cricket_gametip", s = BundleNameDefined.Bundle_Yes11;
            ToolUtils.loadCommonPrefab(null, s, a, (a => {
                try {
                    if (t = ToolUtils.judgeIfInHall(), !t) {
                        return;
                    }
                    let s = director.getScene().getChildByName("Canvas"), i = s.getChildByName("cricket_gametip");
                    if (ToolUtils.isObjValid(i)) {
                        i.active = true;
                    }
                    else {
                        i = instantiate(a);
                        i.parent = s;
                        i.getComponent("SportCricket_GameTip").initParaData(e);
                    }
                }
                catch (e) {
                    TLog.printError("showSportCricket_addCashTip error:" + e);
                }
            }));
        }
    }
    dealShowTeamRecentMatch(e, t) {
        e.matchData = t;
        Utils.shared().showSportCricket_teamRecentMatchView(e);
    }
    requestYes11_getTeamRecentMatchInfo(e, t = false) {
        e.match_id;
        Utils.shared().showSportCricket_teamRecentMatchView(e);
    }
    requestYes11_getVenueMatchInfo(e, t = false) {
        e.venue_id;
        Utils.shared().showSportCricket_venueMatchView(e);
    }
    getPitchPicIndex(e) {
        return "Batting" == e ? 1 : "Bowling" == e ? 2 : "Balanced" == e ? 6 : 1;
    }
    getWeatherPicIndex(e) {
        return "Clear" == e ? 0 : "Clunds" == e ? 10 : "Drizzle" == e || "Rain" == e ? 9 : "Thunderstorm" == e ? 7 : "Fog" == e || "Mist" == e ? 6 : "Haze" == e || "Smoke" == e || "Dust" == e || "Sand" == e ? 5 : "Ash" == e ? 1 : "Snow" == e ? 4 : "Squall" == e ? 3 : "Tornado" == e ? 2 : 11;
    }
    requestYes11_getTeamPkInfo(e, t = false) {
        e.match_id;
        Utils.shared().showSportCricket_teamPkMsgView(e);
    }
    requestYes11_statTeamInfo(e, t = false) {
        let a = { match_id: e.match_id };
        this.cricket_matchStatTeamMap.has(e.match_id) ? this.dealStatTeamView(e, this.cricket_matchStatTeamMap.get(e.match_id)) : (t && Utils.shared().showLoading(10, true, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
        }), ToolUtils.getIsNormalDirection()), HttpManager.shared().doGetCommonRequest(a, HttpRequest.Yes11_GetStatTeam, ((a, i, r) => {
            if (Utils.shared().hideLoading(), 200 != r) {
                t && Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.request_fail"), 2);
            }
            else {
                try {
                    let a = ToolUtils.parseJson(i);
                    0 == a.ret ? sys.isObjectValid(a.data) && (this.cricket_matchStatTeamMap.set(e.match_id, a.data), this.dealStatTeamView(e, this.cricket_matchStatTeamMap.get(e.match_id))) : t && ToolUtils.isSafeString(a.desc).length > 0 && Utils.shared().showToast(a.desc, 3);
                }
                catch (e) {
                    TLog.printError("requestDetailList err:", e.toString());
                }
            }
        })));
    }
    dealShowPreviewTeamLogic(e, t) {
        this.requestYes11_PreCreateTeamCheck(e, true, (e => {
            this.dealCominePreviewLogic(e, t);
        }));
    }
    checkHasLineUp(e) {
        let t = 0;
        if (sys.isObjectValid(e.wk) && Array.isArray(e.wk)) {
            for (let a = 0; a < e.wk.length; a++) {
                1 == e.wk[a].playing11 && (t = 1);
            }
        }
        if (sys.isObjectValid(e.bat) && Array.isArray(e.bat)) {
            for (let a = 0; a < e.bat.length; a++) {
                1 == e.bat[a].playing11 && (t = 1);
            }
        }
        if (sys.isObjectValid(e.ar) && Array.isArray(e.ar)) {
            for (let a = 0; a < e.ar.length; a++) {
                1 == e.ar[a].playing11 && (t = 1);
            }
        }
        if (sys.isObjectValid(e.bowl) && Array.isArray(e.bowl)) {
            for (let a = 0; a < e.bowl.length; a++) {
                1 == e.bowl[a].playing11 && (t = 1);
            }
        }
        return t;
    }
    dealCominePreviewLogic(e, t, a, i, r) {
        let d = [], c = [], l = [], h = [], n = [], m = 0, _ = 0, p = e.credits, u = 0, g = 0;
        if (sys.isObjectValid(i) && 2 == i && sys.isObjectValid(e.left_credit) && (p = e.left_credit), sys.isObjectValid(e.team_id) && (u = e.team_id), sys.isObjectValid(e.wk) && Array.isArray(e.wk)) {
            for (let t = 0; t < e.wk.length; t++) {
                let a = e.wk[t];
                !sys.isObjectValid(i) || 1 != i && 2 != i ? (1 == a.playing11 && (g = 1), sys.isObjectValid(a) && 1 == a.select_status && (a.role = "WK", d.push(a), a.team_id == e.teama.tid ? m += 1 : a.team_id == e.teamb.tid && (_ += 1), p -= a.credits), sys.isObjectValid(a) && a.backup > 0 && (a.role = "WK", n.push(a))) : (a.role = "WK", d.push(a), a.team_id == e.teama.tid ? m += 1 : a.team_id == e.teamb.tid && (_ += 1), 1 == a.playing11 && 2 == i && (g = 1));
            }
        }
        if (sys.isObjectValid(e.bat) && Array.isArray(e.bat)) {
            for (let t = 0; t < e.bat.length; t++) {
                let a = e.bat[t];
                !sys.isObjectValid(i) || 1 != i && 2 != i ? (1 == a.playing11 && (g = 1), sys.isObjectValid(a) && 1 == a.select_status && (a.role = "BAT", c.push(a), a.team_id == e.teama.tid ? m += 1 : a.team_id == e.teamb.tid && (_ += 1), p -= a.credits), sys.isObjectValid(a) && a.backup > 0 && (a.role = "BAT", n.push(a))) : (a.role = "BAT", c.push(a), a.team_id == e.teama.tid ? m += 1 : a.team_id == e.teamb.tid && (_ += 1), 1 == a.playing11 && 2 == i && (g = 1));
            }
        }
        if (sys.isObjectValid(e.ar) && Array.isArray(e.ar)) {
            for (let t = 0; t < e.ar.length; t++) {
                let a = e.ar[t];
                !sys.isObjectValid(i) || 1 != i && 2 != i ? (1 == a.playing11 && (g = 1), sys.isObjectValid(a) && 1 == a.select_status && (a.role = "AR", l.push(a), a.team_id == e.teama.tid ? m += 1 : a.team_id == e.teamb.tid && (_ += 1), p -= a.credits), sys.isObjectValid(a) && a.backup > 0 && (a.role = "AR", n.push(a))) : (a.role = "AR", l.push(a), a.team_id == e.teama.tid ? m += 1 : a.team_id == e.teamb.tid && (_ += 1), 1 == a.playing11 && 2 == i && (g = 1));
            }
        }
        if (sys.isObjectValid(e.bowl) && Array.isArray(e.bowl)) {
            for (let t = 0; t < e.bowl.length; t++) {
                let a = e.bowl[t];
                !sys.isObjectValid(i) || 1 != i && 2 != i ? (1 == a.playing11 && (g = 1), sys.isObjectValid(a) && 1 == a.select_status && (a.role = "BOWL", h.push(a), a.team_id == e.teama.tid ? m += 1 : a.team_id == e.teamb.tid && (_ += 1), p -= a.credits), sys.isObjectValid(a) && a.backup > 0 && (a.role = "BOWL", n.push(a))) : (a.role = "BOWL", h.push(a), a.team_id == e.teama.tid ? m += 1 : a.team_id == e.teamb.tid && (_ += 1), 1 == a.playing11 && 2 == i && (g = 1));
            }
        }
        let y = { wk_Players: d, bat_Players: c, ar_Players: l, bowl_Players: h, backkup_Players: n, teama: e.teama, teamb: e.teamb, teamAPnum: m, teamBPnum: _, credits: e.credits, lineup: g, left_credits: p, bestPts: 0 };
        sys.isObjectValid(i) && 1 == i && (y.fromType = 1);
        sys.isObjectValid(i) && 2 == i && (y.fromType = 2);
        sys.isObjectValid(u) && 0 != u && (y.team_id = u);
        sys.isObjectValid(e.compare_team_id) && (y.compare_team_id = e.compare_team_id);
        sys.isObjectValid(e.point) && (y.bestPts = e.point);
        sys.isObjectValid(e.match_id) && (y.match_id = e.match_id);
        sys.isObjectValid(t) && (y.lastNode = t);
        sys.isObjectValid(r) && 0 != r && (y.session_id = r);
        sys.isObjectValid(a) && (y.backkup_Players = a);
        sys.isObjectValid(i) && 2 == i && (y.have_backups = 0, sys.isObjectValid(e.have_backups) && (y.have_backups = e.have_backups, 1 == e.have_backups && (sys.isObjectValid(e.unused_backups) && Array.isArray(e.unused_backups) && e.unused_backups.length > 0 && (y.backkup_Players = e.unused_backups), sys.isObjectValid(e.used_backups) && Array.isArray(e.used_backups) && e.used_backups.length > 0 && (y.used_backups = e.used_backups))), sys.isObjectValid(e.point) && (y.left_credits = e.point));
        Utils.shared().showSportCricket_teamPreview(y);
    }
    checkYes11MainShown() {
        let e;
        e = director.getScene().getChildByName("Canvas");
        let t = e.getChildByName("cricket_main");
        return !!ToolUtils.isObjValid(t);
    }
}
