// @ts-nocheck
// Recovered from index.js:149
import { _decorator, Button, instantiate, Label, Node, Sprite, SpriteFrame, sys, v3 } from "cc";
import SoundManager from "./SoundManager";
import User from "./User";
import i18nMgr from "./i18nMgr";
import PushCenter from "./PushCenter";
import PushEvent from "./PushEvent";
import TweenTool from "./TweenTool";
import HttpManager from "./HttpManager";
import ReportConfig from "./ReportConfig";
import BaseLayer from "./BaseLayer";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("GameAssistance")
export default class GameAssistance extends BaseLayer {
    @property(Node)
    public rootNode: Node = null;
    @property(Node)
    public itemNode: Node = null;
    @property(Node)
    public layoutNode: Node = null;
    @property([SpriteFrame])
    public switchs: SpriteFrame[] = [];
    public auto_sortItemNode: any = null;
    public assitItemSwitchMap: Map = new Map;
    public assitItemNodesMap: Map = new Map;
    public callback: any = null;
    onLoad() {
    }
    showUi() {
        if (this.itemNode.active = false, this.layoutNode.removeAllChildren(), 1 == User.shared().help_setting.enter_anim) {
            let e = instantiate(this.itemNode);
            e.active = true;
            this.layoutNode.addChild(e);
            let t = sys.localStorage.getItem("enter_anim_def");
            null == t && (t = User.shared().help_setting.enter_anim_def);
            e.getChildByName("switch").active = true;
            0 == Number(t) ? e.getChildByName("switch").getComponent(Sprite).spriteFrame = this.switchs[1] : e.getChildByName("switch").getComponent(Sprite).spriteFrame = this.switchs[0];
            let i = e.getChildByName("title");
            i18nMgr.shared().changeLocalizedLabelKey(i, "game_setting.enter_anim");
            e.getChildByName("detail").active = false;
            e.getChildByName("detail_btn").active = false;
            e.getChildByName("line").active = true;
            this.assitItemSwitchMap.set(0, Number(t));
            this.assitItemNodesMap.set(0, e);
            e.getChildByName("switch").getComponent(Button).clickEvents[0].customEventData = String(0);
        }
        if (1 == User.shared().help_setting.play_effect) {
            let e = instantiate(this.itemNode);
            e.active = true;
            this.layoutNode.addChild(e);
            let t = sys.localStorage.getItem("play_effect_def");
            null == t && (t = User.shared().help_setting.play_effect_def);
            e.getChildByName("switch").active = true;
            0 == Number(t) ? e.getChildByName("switch").getComponent(Sprite).spriteFrame = this.switchs[1] : e.getChildByName("switch").getComponent(Sprite).spriteFrame = this.switchs[0];
            let i = e.getChildByName("title");
            i18nMgr.shared().changeLocalizedLabelKey(i, "game_setting.finish_anim");
            e.getChildByName("detail").active = false;
            e.getChildByName("detail_btn").active = false;
            e.getChildByName("line").active = true;
            this.assitItemSwitchMap.set(1, Number(t));
            this.assitItemNodesMap.set(1, e);
            e.getChildByName("switch").getComponent(Button).clickEvents[0].customEventData = String(1);
        }
        if (1 == User.shared().help_setting.open_deck_pick) {
            let e = instantiate(this.itemNode);
            e.active = true;
            this.layoutNode.addChild(e);
            let t = sys.localStorage.getItem("open_deck_pick_def");
            null == t && (t = User.shared().help_setting.open_deck_pick_def);
            e.getChildByName("switch").active = true;
            0 == Number(t) ? e.getChildByName("switch").getComponent(Sprite).spriteFrame = this.switchs[1] : e.getChildByName("switch").getComponent(Sprite).spriteFrame = this.switchs[0];
            let i = e.getChildByName("title");
            i18nMgr.shared().changeLocalizedLabelKey(i, "game_setting.open_deck_reminder");
            e.getChildByName("detail").active = false;
            e.getChildByName("detail_btn").active = false;
            e.getChildByName("line").active = true;
            e.getChildByName("switch").getComponent(Button).clickEvents[0].customEventData = String(2);
            this.assitItemSwitchMap.set(2, Number(t));
            this.assitItemNodesMap.set(2, e);
        }
        if (1 == User.shared().help_setting.quick_finish) {
            let e = instantiate(this.itemNode);
            e.active = true;
            this.layoutNode.addChild(e);
            let t = sys.localStorage.getItem("quick_finish_def");
            null == t && (t = User.shared().help_setting.quick_finish_def);
            0 == Number(t) ? e.getChildByName("switch").getComponent(Sprite).spriteFrame = this.switchs[1] : e.getChildByName("switch").getComponent(Sprite).spriteFrame = this.switchs[0];
            e.getChildByName("switch").active = true;
            let i = e.getChildByName("title");
            i18nMgr.shared().changeLocalizedLabelKey(i, "game_setting.quick_finish");
            e.getChildByName("detail").active = false;
            e.getChildByName("detail_btn").active = false;
            e.getChildByName("line").active = true;
            e.getChildByName("switch").getComponent(Button).clickEvents[0].customEventData = String(3);
            this.assitItemSwitchMap.set(3, Number(t));
            this.assitItemNodesMap.set(3, e);
        }
        if (1 == User.shared().help_setting.card_rating) {
            let e = instantiate(this.itemNode);
            e.active = true;
            this.layoutNode.addChild(e);
            let t = sys.localStorage.getItem("card_rating_def");
            null == t && (t = User.shared().help_setting.card_rating_def);
            e.getChildByName("switch").active = true;
            0 == Number(t) ? e.getChildByName("switch").getComponent(Sprite).spriteFrame = this.switchs[1] : e.getChildByName("switch").getComponent(Sprite).spriteFrame = this.switchs[0];
            e.getChildByName("switch").getComponent(Button).clickEvents[0].customEventData = String(4);
            this.assitItemSwitchMap.set(4, Number(t));
            this.assitItemNodesMap.set(4, e);
            let i = e.getChildByName("title");
            i18nMgr.shared().changeLocalizedLabelKey(i, "game_setting.card_rating");
            e.getChildByName("detail").active = false;
            e.getChildByName("detail_btn").active = false;
            e.getChildByName("line").active = true;
        }
        if (1 == User.shared().help_setting.finish_card_number) {
            let e = instantiate(this.itemNode);
            e.active = true;
            this.layoutNode.addChild(e);
            let t = sys.localStorage.getItem("finish_card_number_def");
            null == t && (t = User.shared().help_setting.finish_card_number_def);
            e.getChildByName("switch").active = true;
            0 == Number(t) ? e.getChildByName("switch").getComponent(Sprite).spriteFrame = this.switchs[1] : e.getChildByName("switch").getComponent(Sprite).spriteFrame = this.switchs[0];
            this.assitItemSwitchMap.set(5, Number(t));
            this.assitItemNodesMap.set(5, e);
            e.getChildByName("switch").getComponent(Button).clickEvents[0].customEventData = String(5);
            let i = e.getChildByName("title");
            i18nMgr.shared().changeLocalizedLabelKey(i, "game_setting.finish_card_reminder");
            e.getChildByName("detail").active = false;
            e.getChildByName("detail_btn").active = false;
            e.getChildByName("line").active = true;
        }
        if (1 == User.shared().help_setting.finish_conditions) {
            let e = instantiate(this.itemNode);
            e.active = true;
            this.layoutNode.addChild(e);
            let t = sys.localStorage.getItem("finish_conditions_def");
            null == t && (t = User.shared().help_setting.finish_conditions_def);
            e.getChildByName("switch").active = true;
            0 == Number(t) ? e.getChildByName("switch").getComponent(Sprite).spriteFrame = this.switchs[1] : e.getChildByName("switch").getComponent(Sprite).spriteFrame = this.switchs[0];
            this.assitItemSwitchMap.set(6, Number(t));
            this.assitItemNodesMap.set(6, e);
            e.getChildByName("switch").getComponent(Button).clickEvents[0].customEventData = String(6);
            let i = e.getChildByName("title");
            i18nMgr.shared().changeLocalizedLabelKey(i, "game_setting.finish_conditions_reminder");
            e.getChildByName("detail").active = false;
            e.getChildByName("detail_btn").active = false;
            e.getChildByName("line").active = true;
        }
        if (1 == User.shared().help_setting.available_cards) {
            let e = instantiate(this.itemNode);
            e.active = true;
            this.layoutNode.addChild(e);
            let t = sys.localStorage.getItem("available_cards_def");
            null == t && (t = User.shared().help_setting.available_cards_def);
            e.getChildByName("switch").active = true;
            0 == Number(t) ? e.getChildByName("switch").getComponent(Sprite).spriteFrame = this.switchs[1] : e.getChildByName("switch").getComponent(Sprite).spriteFrame = this.switchs[0];
            this.assitItemSwitchMap.set(7, Number(t));
            this.assitItemNodesMap.set(7, e);
            e.getChildByName("switch").getComponent(Button).clickEvents[0].customEventData = String(7);
            let i = e.getChildByName("title");
            i18nMgr.shared().changeLocalizedLabelKey(i, "game_setting.available_cards");
            e.getChildByName("detail").active = false;
            e.getChildByName("detail_btn").active = false;
            e.getChildByName("line").active = true;
        }
        if (1 == User.shared().help_setting.sort_mode) {
            let e = sys.localStorage.getItem("sort_mode_def");
            if (null == e && (e = User.shared().help_setting.sort_mode_def), null != e) {
                let t = instantiate(this.itemNode);
                t.active = true;
                this.layoutNode.addChild(t);
                this.auto_sortItemNode = t;
                let i = t.getChildByName("title");
                i18nMgr.shared().changeLocalizedLabelKey(i, "game_setting.sort_mode");
                t.getChildByName("detail").active = true;
                t.getChildByName("detail_btn").active = true;
                t.getChildByName("line").active = true;
                t.getChildByName("switch").active = false;
                this.refreshAutoSettingChoice(Number(e));
            }
        }
        if (this.layoutNode.children.length > 0) {
            this.layoutNode.children[this.layoutNode.children.length - 1].getChildByName("line").active = false;
        }
    }
    refreshAutoSettingChoice(e) {
        let t = this.auto_sortItemNode.getChildByName("detail");
        switch ((i18nMgr.shared().changeLabelFont(t.getComponent(Label)), e)) {
            case 0:
                t.getComponent(Label).string = i18nMgr.shared().getValueByKey("game_setting.never");
                break;
            case 1:
                t.getComponent(Label).string = i18nMgr.shared().getValueByKey("game_setting.first_sort");
                break;
            case 2: t.getComponent(Label).string = i18nMgr.shared().getValueByKey("game_setting.auto");
        }
    }
    onEnable() {
    }
    setCallBack(e) {
        this.callback = e;
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().removeListenersByTag(this);
    }
    fitScreen() {
        ToolUtils.adaptSafeArea(this.rootNode);
    }
    startShowAnim() {
        this.rootNode.setScale(v3(0.2, 0.2, 0.2));
        TweenTool.scaleTo(this.rootNode, 0.2, v3(1, 1, 1), "backOut", true, (() => {
            this.rootNode.setScale(v3(1, 1, 1));
        }));
    }
    start() {
        super.start();
        this.fitScreen();
        this.showUi();
        PushCenter.shared().addListener(PushEvent.ChangeSortMode, (e => {
            ToolUtils.isObjValid(this.node) && sys.isObjectValid(e) && this.refreshAutoSettingChoice(Number(e));
        }), this);
    }
    onclickByClose(e, t) {
        SoundManager.shared().playFx("click");
        this.onBackView();
    }
    onBackView() {
        ToolUtils.isObjValid(this.node) && (this.callback && this.callback(), this.node.destroy());
    }
    onSwitchClickBtn(e, t) {
        SoundManager.shared().playFx("click");
        let i = Number(t), a = ToolUtils.isSafeNumber(this.assitItemSwitchMap.get(i));
        a = 1 == a ? 0 : 1;
        let s = this.assitItemNodesMap.get(i);
        ToolUtils.isObjValid(s) && (s.getChildByName("switch").getComponent(Sprite).spriteFrame = 1 == a ? this.switchs[0] : this.switchs[1], this.assitItemSwitchMap.set(i, a), this.saveAssitItemSwitchs(i));
    }
    saveAssitItemSwitchs(e) {
        switch (e) {
            case 0:
                ToolUtils.saveData("enter_anim_def", this.assitItemSwitchMap.get(e) + ""), 1 == this.assitItemSwitchMap.get(e) ? HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Rummy_Game, func: ReportConfig.func.game_setting, event: ReportConfig.cash_evt.club_enter_anim_on }) : HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Rummy_Game, func: ReportConfig.func.game_setting, event: ReportConfig.cash_evt.club_enter_anim_off });
                break;
            case 1:
                ToolUtils.saveData("play_effect_def", this.assitItemSwitchMap.get(e) + ""), 1 == this.assitItemSwitchMap.get(e) ? HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Rummy_Game, func: ReportConfig.func.game_setting, event: ReportConfig.cash_evt.club_win_anim_on }) : HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Rummy_Game, func: ReportConfig.func.game_setting, event: ReportConfig.cash_evt.club_win_anim_off });
                break;
            case 2:
                ToolUtils.saveData("open_deck_pick_def", this.assitItemSwitchMap.get(e) + "");
                break;
            case 3:
                ToolUtils.saveData("quick_finish_def", this.assitItemSwitchMap.get(e) + "");
                break;
            case 4:
                ToolUtils.saveData("card_rating_def", this.assitItemSwitchMap.get(e) + "");
                break;
            case 5:
                ToolUtils.saveData("finish_card_number_def", this.assitItemSwitchMap.get(e) + "");
                break;
            case 6:
                ToolUtils.saveData("finish_conditions_def", this.assitItemSwitchMap.get(e) + "");
                break;
            case 7: ToolUtils.saveData("available_cards_def", this.assitItemSwitchMap.get(e) + "");
        }
    }
    onDetailClickBtn(e, t) {
        SoundManager.shared().playFx("click");
    }
    setLandscapeShow() {
    }
    setTidKey(e) {
        this.tid_key = e;
    }
}
