// @ts-nocheck
// Recovered from index.js:437
import { _decorator, sys } from "cc";
import GameConfig from "./GameConfig";
import HowToPlayDefined from "./HowToPlayDefined";
import ReportConfig from "./ReportConfig";
import User from "./User";
import HttpManager from "./HttpManager";
import Server from "./Server";
import RummyCmd from "./RummyCmd";
import CommDefine from "./CommDefine";
import TweenTool from "./TweenTool";
import { ToolUtils } from "./ToolUtils";
const { ccclass } = _decorator;
export let RUMMY_CARD_GROUP_TYPE;
export let RUMMY_GAME_TYPE;
export let RUMMY_MATCH_MODE;
export let RUMMY_MATCH_STATE;
export let RUMMY_MATCH_TYPE;
export let RUMMY_PLAYER_STATE_TYPE;
export let RUMMY_TABLE_STATE_TYPE;
export let Rating_Type;
export let RoomRewardType;
(RUMMY_CARD_GROUP_TYPE = undefined, RUMMY_GAME_TYPE = undefined, RUMMY_MATCH_MODE = undefined, RUMMY_MATCH_STATE = undefined, RUMMY_MATCH_TYPE = undefined, RUMMY_PLAYER_STATE_TYPE = undefined, RUMMY_TABLE_STATE_TYPE = undefined, Rating_Type = undefined, RoomRewardType = undefined);
(!function (e) {
    e[e.POINTS = 0] = "POINTS";
    e[e.POOL = 1] = "POOL";
    e[e.DEALS = 2] = "DEALS";
    e[e.PRIVATE = 3] = "PRIVATE";
    e[e.MATCH = 4] = "MATCH";
    e[e.PRI_POOL = 5] = "PRI_POOL";
    e[e.PRI_DEAL = 6] = "PRI_DEAL";
    e[e.PERFORMANCE = 7] = "PERFORMANCE";
    e[e.MULTIPLE = 8] = "MULTIPLE";
}(RUMMY_GAME_TYPE || (RUMMY_GAME_TYPE = RUMMY_GAME_TYPE = {})));
(function (e) {
    e[e.FULLMATCH = 0] = "FULLMATCH";
    e[e.TIMEMATCH = 1] = "TIMEMATCH";
    e[e.MultipleRounds = 2] = "MultipleRounds";
    e[e.PointsMatch = 3] = "PointsMatch";
}(RUMMY_MATCH_MODE || (RUMMY_MATCH_MODE = RUMMY_MATCH_MODE = {})));
(function (e) {
    e[e.FIXEDDURATION = 0] = "FIXEDDURATION";
    e[e.BASEMONEYUP = 1] = "BASEMONEYUP";
}(RUMMY_MATCH_TYPE || (RUMMY_MATCH_TYPE = RUMMY_MATCH_TYPE = {})));
(function (e) {
    e[e.Ready = 0] = "Ready";
    e[e.Wait = 1] = "Wait";
    e[e.WillStart = 2] = "WillStart";
    e[e.Gaming = 3] = "Gaming";
    e[e.Over = 4] = "Over";
}(RUMMY_MATCH_STATE || (RUMMY_MATCH_STATE = RUMMY_MATCH_STATE = {})));
(function (e) {
    e[e.WAITING = -1] = "WAITING";
    e[e.Betting = 0] = "Betting";
    e[e.DROPPED = 1] = "DROPPED";
    e[e.LOST = 2] = "LOST";
    e[e.WRONGSHOW = 3] = "WRONGSHOW";
    e[e.FINISH = 4] = "FINISH";
    e[e.MIDDLEDROP = 5] = "MIDDLEDROP";
    e[e.WIN = 6] = "WIN";
    e[e.READY = 7] = "READY";
    e[e.AWAY = 8] = "AWAY";
    e[e.OUT = 9] = "OUT";
    e[e.Decision = 10] = "Decision";
    e[e.FirstWinner = 11] = "FirstWinner";
}(RUMMY_PLAYER_STATE_TYPE || (RUMMY_PLAYER_STATE_TYPE = RUMMY_PLAYER_STATE_TYPE = {})));
(function (e) {
    e[e.WAIT = 0] = "WAIT";
    e[e.READY = 1] = "READY";
    e[e.BETTING = 2] = "BETTING";
    e[e.END_GAME = 3] = "END_GAME";
    e[e.FINISH_GAME = 4] = "FINISH_GAME";
}(RUMMY_TABLE_STATE_TYPE || (RUMMY_TABLE_STATE_TYPE = RUMMY_TABLE_STATE_TYPE = {})));
(function (e) {
    e[e.eGroup_Invalid = 0] = "eGroup_Invalid";
    e[e.eGroup_PureSeq = 1] = "eGroup_PureSeq";
    e[e.eGroup_Seq = 2] = "eGroup_Seq";
    e[e.eGroup_Set = 3] = "eGroup_Set";
    e[e.eGroup_Mix = 4] = "eGroup_Mix";
    e[e.eGroup_Laizi = 5] = "eGroup_Laizi";
}(RUMMY_CARD_GROUP_TYPE || (RUMMY_CARD_GROUP_TYPE = RUMMY_CARD_GROUP_TYPE = {})));
(function (e) {
    e[e.bad = 0] = "bad";
    e[e.risky = 1] = "risky";
    e[e.good = 2] = "good";
    e[e.pefect = 3] = "pefect";
}(Rating_Type || (Rating_Type = Rating_Type = {})));
(function (e) {
    e[e.CASH = 2] = "CASH";
    e[e.BONUS = 6] = "BONUS";
    e[e.TICKET = 11] = "TICKET";
    e[e.PHYSICAL = 13] = "PHYSICAL";
}(RoomRewardType || (RoomRewardType = RoomRewardType = {})));
@ccclass("RummyDataManager")
export default class RummyDataManager {
    static _instance = null;
    public data: any = {};
    public deskData: any[] = [];
    public sceneNode: any = null;
    public actionNode: any = null;
    public rummyInfos: Map = new Map;
    public chat_Type: number = 0;
    public taskBubblePrefab: any = null;
    public dailyTaskBubblePrefab: any = null;
    public gameOverPrefab: any = null;
    public RummyTotalSettlementPrefab: any = null;
    public pointsMatchOverPrefab: any = null;
    public tableData: any = null;
    public performancePlayer: any = null;
    public bocost_status: number = 0;
    public openCardInfos: Map = new Map;
    public actRankPrefab: any = null;
    public cardPrefab: any = null;
    public enterPracticeCount: number = 0;
    public hasCloseUpToCashTips: boolean = false;
    public history_data_open: number = 0;
    public bCanGoBack: boolean = false;
    static shared() : RummyDataManager {
        return null == this._instance && (this._instance = new RummyDataManager, this._instance.init()), this._instance;
    }
    init() {
        this.data.playerModels = [];
        this.data.total_bet = 0;
        this.data.per_time = 0;
        this.data.cur_seat = -1;
        this.data.cur_bet = 0;
        this.data.config_cur_bet = 0;
        this.data.mround = 0;
        this.data.uplimit = 0;
        this.data.potlimit = 0;
        this.data.roomBaseMoney = 0;
        this.data.history_recordVec = [];
        this.data.all_seatid = 8;
        this.data.speakerminmoney = 0;
        this.data.cardInfoModelVec = [];
        this.data.roomPlayerCounter = 0;
        this.data.clientSeatId = 0;
        this.data.win_money = 0;
        this.data.pnum = 2;
        this.data.isClientToPlay = false;
        this.data.groupIndex = 0;
        this.data.card_index = 0;
        this.data.close_cardnum = 0;
        this.data.laizicard = 0;
        this.data.dc_card = 0;
        this.data.hasChupai = false;
        this.data.playCardValue = 0;
        this.data.selectCardIndex = 0;
        this.data.game_cd = 0;
        this.data.game_state = 0;
        this.data.from_index = 0;
        this.data.to_index = 0;
        this.data.from_card_index = 0;
        this.data.to_card_index = 0;
        this.data.isCanTouchCard = false;
        this.data.isPlayingCard = false;
        this.data.win_pos = 0;
        this.data.mp_refresh = false;
        this.data.direction = 0;
        this.data.myMoney = 0;
        this.data.cardInfoModelVec = [];
        this.data.zhuang_seatid = -1;
        this.data.playerGiveCards = [];
        for (let e = 0; e < 6; e++) {
            this.data.playerGiveCards[e] = [];
            this.data.playerGiveCards[e].cards = [];
        }
        this.data.timeout_cd = 0;
        this.data.isGameOver = false;
        this.data.gameRummyType = 0;
        this.bocost_status = 0;
        this.data.winner_effects_round = 0;
        this.enterPracticeCount = 0;
        this.hasCloseUpToCashTips = false;
    }
    resetData() {
        this.bocost_status = 0;
        this.tableData = null;
        this.performancePlayer = null;
        this.enterPracticeCount = 0;
        this.hasCloseUpToCashTips = false;
        this.bCanGoBack = false;
    }
    reset() {
        this.data.playerGiveCards = [];
    }
    getRummyXtCard(e) {
        let t = [];
        return t.m_face = 0, t.m_suit = 0, t.m_value = e, t.m_face = t.m_value % 16, t.m_suit = Math.floor(t.m_value / 16), t.m_face < 2 ? t.m_face = t.m_face + 13 : t.m_face >= 14 && (t.m_face = t.m_face + 2), t;
    }
    restoreCardAFace(e) {
        for (let t = 0, a = e.length; t < a; t++) {
            1 == e[t].m_face && (e[t].m_face = 14);
        }
    }
    compare(e, t) {
        if (e.m_face > t.m_face) {
            return 1;
        }
        if (e.m_face < t.m_face) {
            return -1;
        }
        if (e.m_face == t.m_face) {
            if (e.m_suit > t.m_suit) {
                return 1;
            }
            if (e.m_suit < t.m_suit) {
                return -1;
            }
        }
        return 0;
    }
    lesserCallback(t, a) {
        return 1 == RummyDataManager.shared().compare(t, a) ? 1 : -1;
    }
    greaterCallback(t, a) {
        return -1 == RummyDataManager.shared().compare(t, a) ? 1 : -1;
    }
    checkPureSeq(e) {
        if (null == e || e.length < 1) {
            return false;
        }
        for (let t = 0, a = e.length; t < a - 1; t++) {
            if (e[t].m_suit != e[t + 1].m_suit) {
                return false;
            }
            if (e[t].m_value == e[t + 1].m_value) {
                return false;
            }
            if (e[t].m_face + 1 != e[t + 1].m_face) {
                return false;
            }
        }
        return true;
    }
    isSequre(e, t) {
        if (e.length < 3) {
            return false;
        }
        let a = [];
        for (let t = 0, s = e.length; t < s; t++) {
            let s = this.getRummyXtCard(e[t]);
            a.push(s);
        }
        a.sort(this.lesserCallback);
        let s = 0, r = [];
        for (let e = 0, n = a.length; e < n; e++) {
            a[e].m_face >= 16 || a[e].m_face == t ? r.push(a[e]) : 13 == a[e].m_face && (s += 1);
        }
        a = this.removeCard(r, a);
        let n = r.length, i = r.length - 1, m = false;
        if (m = 0 == r.length || 1 == r.length || this.checkSequre(a, i, n), m) {
            return true;
        }
        if (s > 0) {
            return false;
        }
        for (let e = 0, t = a.length; e < t; e++) {
            14 == a[e].m_face && (a[e].m_face = 1);
        }
        return a.sort(this.lesserCallback), m = this.checkSequre(a, i, n), this.restoreCardAFace(a), m;
    }
    checkSequre(e, t, a) {
        let s = 0;
        for (let t = 0, a = e.length; t < a - 1; t++) {
            if (e[t].m_suit != e[t + 1].m_suit) {
                return false;
            }
            if (e[t].m_value == e[t + 1].m_value) {
                return false;
            }
            e[t].m_face + 1 != e[t + 1].m_face && (s = s + e[t + 1].m_face - e[t].m_face - 1);
        }
        return s <= 0 || s <= a;
    }
    removeCard(e, t) {
        let a = [];
        for (let s = 0, r = t.length; s < r; s++) {
            let r = true;
            for (let a = 0, n = e.length; a < n; a++) {
                e[a].m_value == t[s].m_value && (r = false);
            }
            r && a.push(t[s]);
        }
        return a;
    }
    isSetLast(e, t) {
        if (e.length < 3) {
            return false;
        }
        let a = [];
        for (let t = 0, s = e.length; t < s; t++) {
            let s = this.getRummyXtCard(e[t]);
            a.push(s);
        }
        a.sort(this.lesserCallback);
        let s = [], r = [];
        for (let e = 0, n = a.length; e < n; e++) {
            a[e].m_face >= 16 ? s.push(a[e]) : a[e].m_face == t && r.push(a[e]);
        }
        if (a = this.removeCard(s, a), a = this.removeCard(r, a), 0 == a.length || 1 == a.length) {
            return true;
        }
        for (let e = 0, t = a.length; e < t - 1; e++) {
            if (a[e].m_suit == a[e + 1].m_suit) {
                return false;
            }
            if (a[e].m_face != a[e + 1].m_face) {
                return false;
            }
        }
        return true;
    }
    isPureSeq(e = []) {
        if (e.length < 3) {
            return false;
        }
        let t = [];
        for (let a = 0, s = e.length; a < s; a++) {
            let s = this.getRummyXtCard(e[a]);
            t.push(s);
        }
        t.sort(this.lesserCallback);
        let a = this.checkPureSeq(t);
        if (a) {
            return a;
        }
        let s = 0, r = 0;
        for (let e = 0, a = t.length; e < a; e++) {
            13 == t[e].m_face ? s += 1 : 14 == t[e].m_face && (r += 1, t[e].m_face = 1);
        }
        return !(r <= 0) && (!(s > 0) && (t.sort(this.lesserCallback), a = this.checkPureSeq(t), this.restoreCardAFace(t), a));
    }
    reportSuccessIntoGameWithClient(t, a) {
        if (a === CommDefine.NewerGuideRoomTidkey) {
            return;
        }
        if (undefined === t.game_type || null === t.game_type) {
            return;
        }
        if (!RummyDataManager.shared().rummyInfos.has(a)) {
            return;
        }
        if (RummyDataManager.shared().rummyInfos.get(a).hasReport) {
            return;
        }
        RummyDataManager.shared().rummyInfos.get(a).hasReport = true;
        let r = null;
        t.game_type == HowToPlayDefined.gameId_RummyGame ? r = { scene: ReportConfig.scece.CashPoint, func: ReportConfig.func.Rummy_Game_Point, event: ReportConfig.cash_evt.points_into_room_client, type: t.mode, cnt: t.pnum, amt: t.base_money } : t.game_type == HowToPlayDefined.gameId_PoolRummy ? r = { scene: ReportConfig.scece.CashPool, func: ReportConfig.func.Rummy_Game_Pool, event: ReportConfig.cash_evt.pool_into_room_client, type: t.mode, cnt: t.pnum, amt: t.base_money, round: t.round, currentRound: t.currentRound } : t.game_type == HowToPlayDefined.gameId_DealsRummy && (r = { scene: ReportConfig.scece.CashDeals, func: ReportConfig.func.Rummy_Game_Deals, event: ReportConfig.cash_evt.deals_into_room_client, type: t.mode, cnt: t.pnum, amt: t.base_money, round: t.round, currentRound: t.currentRound });
        sys.isObjectValid(r) && (User.shared().enter_game_loadRes_time > 0 && (r.load_res_time = Math.floor((sys.now() - User.shared().enter_game_loadRes_time) / 1000)), User.shared().enter_game_loadRes_time = -1, HttpManager.shared().doSdkApiReport(r));
    }
    reportSuccessIntoGameWithServer(t, a) {
        if (!RummyDataManager.shared().rummyInfos.has(a)) {
            return;
        }
        if (RummyDataManager.shared().rummyInfos.get(a).hasServerReport) {
            return;
        }
        RummyDataManager.shared().rummyInfos.get(a).hasServerReport = true;
        let r = null;
        t.game_type == HowToPlayDefined.gameId_RummyGame ? r = { scene: ReportConfig.scece.CashPoint, func: ReportConfig.func.Rummy_Game_Point, event: ReportConfig.cash_evt.points_into_room_server, type: t.mode, cnt: t.pnum, amt: t.base_money } : t.game_type == HowToPlayDefined.gameId_PoolRummy ? r = { scene: ReportConfig.scece.CashPool, func: ReportConfig.func.Rummy_Game_Pool, event: ReportConfig.cash_evt.pool_into_room_server, type: t.mode, cnt: t.pnum, amt: t.base_money, round: t.disuse_score, currentRound: t.cround } : t.game_type == HowToPlayDefined.gameId_DealsRummy && (r = { scene: ReportConfig.scece.CashDeals, func: ReportConfig.func.Rummy_Game_Deals, event: ReportConfig.cash_evt.deals_into_room_server, type: t.mode, cnt: t.pnum, amt: t.base_money, round: t.total_round, currentRound: t.cround });
        sys.isObjectValid(r) && (User.shared().first_click_play_time > 0 && (r.play_time = User.shared().first_click_play_time), User.shared().first_click_play_time = -1, HttpManager.shared().doSdkApiReport(r));
    }
    reportGameStart(e, t) {
        let a = this.rummyInfos.get(e);
        a.game_type == HowToPlayDefined.gameId_RummyGame ? HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.CashPoint, func: ReportConfig.func.Rummy_Game_Point, event: ReportConfig.cash_evt.points_start, type: a.gameRummyType, cnt: a.gamePlayerNum, amt: a.gameBaseMoney }) : a.game_type == HowToPlayDefined.gameId_PoolRummy && 1 === t.cround ? HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.CashPool, func: ReportConfig.func.Rummy_Game_Pool, event: ReportConfig.cash_evt.pool_start, type: a.gameRummyType, cnt: a.gamePlayerNum, amt: a.gameBaseMoney, round: a.gameRound, currentRound: a.xiaojuNum }) : a.game_type == HowToPlayDefined.gameId_DealsRummy && 1 === t.cround && HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.CashDeals, func: ReportConfig.func.Rummy_Game_Deals, event: ReportConfig.cash_evt.deals_start, type: a.gameRummyType, cnt: a.gamePlayerNum, amt: a.gameBaseMoney, round: a.gameRound, currentRound: a.xiaojuNum });
    }
    reportGameStartCountDown(e) {
        let t = this.rummyInfos.get(e);
        t.game_type == HowToPlayDefined.gameId_RummyGame ? HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.CashPoint, func: ReportConfig.func.Rummy_Game_Point, event: ReportConfig.cash_evt.points_start_countdown, type: t.gameRummyType, cnt: t.gamePlayerNum, amt: t.gameBaseMoney }) : t.game_type == HowToPlayDefined.gameId_PoolRummy ? HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.CashPool, func: ReportConfig.func.Rummy_Game_Pool, event: ReportConfig.cash_evt.pool_start_countdown, type: t.gameRummyType, cnt: t.gamePlayerNum, amt: t.gameBaseMoney, round: t.gameRound, currentRound: t.xiaojuNum }) : t.game_type == HowToPlayDefined.gameId_DealsRummy && HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.CashDeals, func: ReportConfig.func.Rummy_Game_Deals, event: ReportConfig.cash_evt.deals_start_countdown, type: t.gameRummyType, cnt: t.gamePlayerNum, amt: t.gameBaseMoney, round: t.gameRound, currentRound: t.xiaojuNum });
    }
    reportGameFinish(e) {
        if (!this.rummyInfos.has(e.tid_key)) {
            return;
        }
        let t = this.rummyInfos.get(e.tid_key);
        if (t.game_type == HowToPlayDefined.gameId_RummyGame) {
            HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.CashPoint, func: ReportConfig.func.Rummy_Game_Point, event: ReportConfig.cash_evt.points_finish, type: t.gameRummyType, cnt: t.gamePlayerNum, amt: t.gameBaseMoney });
        }
        else if (t.game_type == HowToPlayDefined.gameId_PoolRummy) {
            if (t.hasReportFinish) {
                return;
            }
            1 !== e.all_end && e.head_status != RUMMY_PLAYER_STATE_TYPE.OUT || (HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.CashPool, func: ReportConfig.func.Rummy_Game_Pool, event: ReportConfig.cash_evt.pool_finish, type: t.gameRummyType, cnt: t.gamePlayerNum, amt: t.gameBaseMoney, round: t.gameRound, currentRound: t.xiaojuNum }), t.hasReportFinish = true);
        }
        else {
            t.game_type == HowToPlayDefined.gameId_DealsRummy && 1 === e.all_end && HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.CashDeals, func: ReportConfig.func.Rummy_Game_Deals, event: ReportConfig.cash_evt.deals_finish, type: t.gameRummyType, cnt: t.gamePlayerNum, amt: t.gameBaseMoney, round: t.gameRound, currentRound: t.xiaojuNum });
        }
    }
    reportLeaveTable(e) {
        if (!this.rummyInfos.has(e)) {
            return;
        }
        let t = this.rummyInfos.get(e);
        t.game_type == HowToPlayDefined.gameId_RummyGame ? HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.CashPoint, func: ReportConfig.func.Rummy_Game_Point, event: ReportConfig.cash_evt.points_leave, type: t.gameRummyType, cnt: t.gamePlayerNum, amt: t.gameBaseMoney }) : t.game_type == HowToPlayDefined.gameId_PoolRummy ? HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.CashPool, func: ReportConfig.func.Rummy_Game_Pool, event: ReportConfig.cash_evt.pool_leave, type: t.gameRummyType, cnt: t.gamePlayerNum, amt: t.gameBaseMoney, round: t.gameRound, currentRound: t.xiaojuNum }) : t.game_type == HowToPlayDefined.gameId_DealsRummy && HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.CashDeals, func: ReportConfig.func.Rummy_Game_Deals, event: ReportConfig.cash_evt.deals_leave, type: t.gameRummyType, cnt: t.gamePlayerNum, amt: t.gameBaseMoney, round: t.gameRound, currentRound: t.xiaojuNum });
    }
    reportCommClickEvent(e, t, a) {
        if (!this.rummyInfos.has(e)) {
            return;
        }
        let s = this.rummyInfos.get(e);
        s.game_type == HowToPlayDefined.gameId_RummyGame ? HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.CashPoint, func: t, event: a }) : s.game_type == HowToPlayDefined.gameId_PoolRummy ? HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.CashPool, func: t, event: a }) : s.game_type == HowToPlayDefined.gameId_DealsRummy && HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.CashDeals, func: t, event: a });
    }
    reportDeskBtnClick(e, t, a = null) {
        if (!this.rummyInfos.has(e)) {
            return;
        }
        let s = null, r = this.rummyInfos.get(e);
        r.game_type == HowToPlayDefined.gameId_RummyGame ? s = { scene: ReportConfig.scece.CashPoint, func: ReportConfig.func.Rummy_Game_Point, event: t } : r.game_type == HowToPlayDefined.gameId_PoolRummy ? s = { scene: ReportConfig.scece.CashPool, func: ReportConfig.func.Rummy_Game_Pool, event: t } : r.game_type == HowToPlayDefined.gameId_DealsRummy && (s = { scene: ReportConfig.scece.CashDeals, func: ReportConfig.func.Rummy_Game_Deals, event: t });
        s && (null != a && Object.keys(a).forEach((function (e) {
            s[e] = a[e];
        })), HttpManager.shared().doSdkApiReport(s));
    }
    reportClickTaskBtn(e, t) {
        let a = ReportConfig.scece.Hall;
        if (!this.rummyInfos.has(e)) {
            return a;
        }
        let s = this.rummyInfos.get(e), r = ReportConfig.func.New_reward;
        return 1 == t && (r = ReportConfig.func.Daily_reward), s.game_type == HowToPlayDefined.gameId_RummyGame || s.game_type == HowToPlayDefined.gameId_PracticeRummy || s.game_type == HowToPlayDefined.gameId_PrivateRummy ? (a = ReportConfig.scece.CashPoint, s.game_type == HowToPlayDefined.gameId_PracticeRummy ? a = ReportConfig.scece.PracticePoints : s.game_type == HowToPlayDefined.gameId_PrivateRummy && (a = ReportConfig.scece.PointsPri), a == ReportConfig.scece.CashPoint && 1 == t && HttpManager.shared().doSdkApiReport({ scene: a, func: r, event: ReportConfig.newPlayerReward.clickTaskBtn, type: s.gameRummyType, cnt: s.gamePlayerNum, amt: s.gameBaseMoney })) : s.game_type == HowToPlayDefined.gameId_PoolRummy || s.game_type == HowToPlayDefined.gameId_PoolPrivateRummy || s.game_type == HowToPlayDefined.GameType_PoolPractice ? (a = ReportConfig.scece.CashPool, s.game_type == HowToPlayDefined.GameType_PoolPractice ? a = ReportConfig.scece.PracticePool : s.game_type == HowToPlayDefined.gameId_PoolPrivateRummy && (a = ReportConfig.scece.PoolPri), a == ReportConfig.scece.CashPool && 1 == t && HttpManager.shared().doSdkApiReport({ scene: a, func: r, event: ReportConfig.newPlayerReward.clickTaskBtn, type: s.gameRummyType, cnt: s.gamePlayerNum, amt: s.gameBaseMoney, round: s.gameRound, currentRound: s.xiaojuNum })) : s.game_type != HowToPlayDefined.gameId_DealsRummy && s.game_type != HowToPlayDefined.gameId_DealsPrivateRummy && s.game_type != HowToPlayDefined.GameType_DealsPractice || (a = ReportConfig.scece.CashDeals, s.game_type == HowToPlayDefined.GameType_DealsPractice ? a = ReportConfig.scece.PracticeDeals : s.game_type == HowToPlayDefined.gameId_DealsPrivateRummy && (a = ReportConfig.scece.DealsPri), a == ReportConfig.scece.CashDeals && 1 == t && HttpManager.shared().doSdkApiReport({ scene: a, func: r, event: ReportConfig.newPlayerReward.clickTaskBtn, type: s.gameRummyType, cnt: s.gamePlayerNum, amt: s.gameBaseMoney, round: s.gameRound, currentRound: s.xiaojuNum })), a;
    }
    getPosBySeatid(t, a) {
        let s = t - RummyDataManager.shared().rummyInfos.get(a).clientSeatId;
        return s >= 0 ? s : s + RummyDataManager.shared().rummyInfos.get(a).pnum;
    }
    getSeatidByPos(t, a) {
        let s = t + RummyDataManager.shared().rummyInfos.get(a).clientSeatId;
        return s >= RummyDataManager.shared().rummyInfos.get(a).pnum && (s -= RummyDataManager.shared().rummyInfos.get(a).pnum), s;
    }
    reSetTouchCardState(t) {
        if (RummyDataManager.shared().rummyInfos.has(t)) {
            let e = this.rummyInfos.get(t);
            e.isInGameing = 1;
            e.hasChupai = false;
            e.isCanTouchCard = true;
            e.isPlayingCard = false;
        }
    }
    isShowSwitchBtn(t) {
        let a = false;
        return RummyDataManager.shared().rummyInfos.get(t).gameRummyType === RUMMY_GAME_TYPE.POOL && 1 === RummyDataManager.shared().rummyInfos.get(t).isWatching && (a = true), a;
    }
    send_request_close_out_ui(e) {
        let t = { cmd: RummyCmd.GM_REQ_CLOSE_OUT_UI, uid: User.shared().data.uid, version: GameConfig.Server_Api_Ver, skey: User.shared().getSkey(), tid_key: e };
        Server.shared().send(t);
    }
    send_request_close_finish_alert(e) {
        let t = { cmd: RummyCmd.GM_REQ_CLOSE_FINISH_MSG, uid: User.shared().data.uid, version: GameConfig.Server_Api_Ver, skey: User.shared().getSkey(), tid_key: e };
        Server.shared().send(t);
    }
    static formatRaceTime(e) {
        let t = e;
        if (t >= 0) {
            let e = "";
            if (t >= 3600) {
                let a = (t - t % 86400) / 86400;
                t -= 86400 * a;
                e = e + a + " day";
            }
            if (t >= 3600) {
                let a = (t - t % 3600) / 3600;
                t -= 3600 * a;
                e = e + String("0" + a).slice(-2) + ":";
            }
            let a = (t - t % 60) / 60;
            return t -= 60 * a, e = e + String("0" + a).slice(-2) + ":", e += String("0" + t).slice(-2), e;
        }
        return "00:00";
    }
    stopTweenAction(e) {
        sys.isObjectValid(e) && (TweenTool.stopAction(e), e = null);
    }
    stopTweenActionByNode(e, t = false) {
        ToolUtils.isObjValid(e) && (TweenTool.stopNodeAction(e), t && e.destroy());
    }
    sortPlayerGiveCard(e) {
        let t = this.rummyInfos.get(e.tid_key), a = t.playerGiveCards;
        if (!Array.isArray(a) || 0 == a.length) {
            return;
        }
        for (let e = 0, s = a.length; e < s; e++) {
            if (a[e].seatid == t.clientSeatId) {
                a[e].name = "Me";
                break;
            }
        }
        let s = t.playerModels;
        if (a.length > 0) {
            let e = [];
            for (let t = 0; t < a.length; t++) {
                let r = false;
                for (let s = 0, n = e.length; s < n; s++) {
                    if (e[s].seatid == a[t].seatid) {
                        r = true;
                        break;
                    }
                }
                1 != s[a[t].seatid].status && 9 != s[a[t].seatid].status && (r || e.push(a[t]));
            }
            a = e;
        }
        let n = [];
        if (2 == t.pnum) {
            for (let e = 0, s = a.length; e < s; e++) {
                let s = a[e];
                if (s.seatid != t.clientSeatId) {
                    n.push(s);
                    break;
                }
            }
            for (let e = 0, s = a.length; e < s; e++) {
                let s = a[e];
                if (s.seatid == t.clientSeatId) {
                    n.push(s);
                    break;
                }
            }
        }
        else {
            if (a.sort((function (e, t) {
                return e.seatid - t.seatid;
            })), 1 == GameConfig.HTTP_MSG_DEBUG) {
                for (let e = 0, t = a.length; e < t; e++) {
                    ;
                }
            }
            let s = -1, i = -1;
            for (let e = 0, s = a.length; e < s; e++) {
                if (a[e].seatid == t.clientSeatId) {
                    i = e;
                    break;
                }
            }
            let m = a.length;
            i > -1 && (m >= 2 && (0 == i ? (s = a[m - 1].seatid, s != t.clientSeatId && n.push(a[m - 1])) : (s = a[i - 1].seatid, s != t.clientSeatId && n.push(a[i - 1]))), n.push(a[i]), m -= 2);
            let o = [];
            if (m > 0) {
                m = a.length;
                for (let e = 0; e < m; e++) {
                    let r = a[e];
                    r.seatid != t.clientSeatId && r.seatid != s && o.push(r);
                }
                if (o.length > 0) {
                    let t = e;
                    o.sort((function (e, a) {
                        return t.getPosBySeatid(e.seatid) - t.getPosBySeatid(a.seatid);
                    }));
                    for (let e = 0, t = o.length; e < t; e++) {
                        n.push(o[e]);
                    }
                }
            }
        }
        let i = n.length, m = -1;
        for (let e = 0; e < i; e++) {
            if (n[e].seatid == t.clientSeatId) {
                m = e;
                break;
            }
        }
        if (2 == i) {
            t.opencardXiajiaIndex = 0;
            0 == m ? t.opencardXiajiaIndex = 1 : 1 == m && (t.opencardXiajiaIndex = 0);
        }
        else if (i >= 3) {
            if (t.opencardXiajiaIndex = 2, m >= 0 && 1 != m) {
                let e = n[m], t = n[i - 1];
                n.splice(m, 1);
                n.splice(n.length - 1, 1);
                n.splice(0, 0, t);
                n.splice(1, 0, e);
            }
        }
        else {
            1 == i && (t.opencardXiajiaIndex = 0);
        }
        t.playerGiveCards = n;
    }
    resetTabDataByTidkey(e) {
        if (!this.rummyInfos.has(e)) {
            return;
        }
        let t = this.rummyInfos.get(e);
        t.playerGiveCards = null;
        t.playerGiveCards = [];
        t.isGameOver = false;
        t.isClearCards = true;
        t.is_game_all_end = -1;
        t.game_end_state = -1;
        t.game_state = 0;
        t.game_server_state = 0;
        t.isCanTouchCard = true;
        t.auto_drop_type = 0;
        t.isInGameing = 0;
        t.isGameStarting = 0;
        t.isCanExit = true;
        // Currency is a room property; clearing hand state must preserve it.
        t.has_rev_tableInfo = true;
        t.is_reshuffle = 0;
        t.hasShowTotalSettlement = false;
        t.gameTipsTextType = 0;
        t.hasShowScanAlert = false;
        t.is_table_change_status = false;
        t.hasFaPai = false;
        t.isClientToPlay = false;
        t.isPlayingCard = false;
        t.hasChupai = false;
        t.bHandCardSynchronous = true;
        t.end_game_countdown = 0;
        t.ding_zhuang_seat_state = 0;
        t.stayInTable = false;
        t.dropType = 0;
        t._mopai_time = -1;
        t._discard_time = -1;
        t._drop_time = -1;
        t._declare_time = -1;
        t._pre_drop_type = -1;
        t.round_per_game = 0;
        t.ting_round = 0;
        t.novicesGameOverLaba = null;
        t.flopCashTaskLaba = null;
        t.his_card_players = [];
        for (let e = 0; e <= 5; e++) {
            t.playerModels[e] = null;
            t.playerModels[e] = {};
        }
        t.tf_bonus = 0;
        t.multitable_tips = null;
        t.bHasLocalPickUp = false;
        t.is_rapid = false;
        t.manule_rejoin_select = false;
        t.hasSendCloseOut = false;
    }
    onGameStartReset(e) {
        if (!this.rummyInfos.has(e)) {
            return;
        }
        let t = this.rummyInfos.get(e);
        t.is_showhuAnim_status = false;
        t.hasShowScanAlert = false;
        t.ding_zhuang_seat_state = 0;
        t.stayInTable = false;
        t.dropType = 0;
        t.disCardTipsValue = 0;
        t.pool_rummy_all_end_data = null;
        t.auto_drop_type = 0;
        t.hasShowTotalSettlement = false;
        t.isClientToPlay = false;
        t.isCanExit = true;
        t.isGameStarting = 1;
        t.is_waiting = 0;
        t.game_state = 2;
        t.game_server_state = 2;
        t.game_cd = 2;
        t.isGameOver = false;
        t.bIsSwitchRoom = false;
        t.is_declare_status = false;
        t.close_cardnum = 0;
        t.hasFaPai = false;
        t.bHandCardSynchronous = true;
        t.isInGameing = 1;
        t.isPlayingCard = false;
        t.isMatchGameOver = false;
        t.bIsHasHu = false;
        t._mopai_time = -1;
        t._discard_time = -1;
        t._drop_time = -1;
        t._declare_time = -1;
        t._pre_drop_type = -1;
        t.novicesGameOverLaba = null;
        t.flopCashTaskLaba = null;
        t.multitable_tips = null;
        t.his_card_players = [];
        t.bHasLocalPickUp = false;
        t.is_rapid = false;
        t.manule_rejoin_select = false;
        t.hasSendCloseOut = false;
    }
    onFlowBureauReset(e) {
        if (!this.rummyInfos.has(e)) {
            return;
        }
        let t = this.rummyInfos.get(e);
        t.isCanTouchCard = false;
        t.game_state = 0;
        t.game_server_state = 4;
        t.game_cd = 0;
        t.isGameOver = true;
        t.isClearCards = true;
        t.is_declare_status = false;
    }
    onPreStartReset(e, t) {
        if (!this.rummyInfos.has(e)) {
            return;
        }
        let a = this.rummyInfos.get(e);
        a.game_state = 1;
        a.game_server_state = 1;
        a.game_cd = t;
        a.isGameOver = false;
        a.isCanExit = true;
        a.bIsSwitchRoom = false;
        a.stayInTable = false;
        a.dropType = 0;
        a.isClientToPlay = false;
    }
    getCanShowTingPai() {
        let e = false;
        if (1 == User.shared().help_setting.finish_card_number) {
            let t = sys.localStorage.getItem("finish_card_number_def");
            null == t && (t = User.shared().help_setting.finish_card_number_def);
            1 == Number(t) && (e = true);
        }
        return e;
    }
    getCanShowQuickFinish() {
        let e = false;
        if (1 == User.shared().help_setting.quick_finish) {
            let t = sys.localStorage.getItem("quick_finish_def");
            null == t && (t = User.shared().help_setting.quick_finish_def);
            1 == Number(t) && (e = true);
        }
        return e;
    }
    isShowLaiziColor(t, a) {
        if (78 == RummyDataManager.shared().rummyInfos.get(a).laizicard || 79 == RummyDataManager.shared().rummyInfos.get(a).laizicard) {
            if (78 == t || 79 == t || 1 == t || 17 == t || 33 == t || 49 == t) {
                return true;
            }
        }
        else {
            if (78 == t || 79 == t) {
                return true;
            }
            if (RummyDataManager.shared().rummyInfos.get(a).laizicard % 16 == t % 16) {
                return true;
            }
        }
        return false;
    }
    checkSameCards(e, t) {
        let a = 0;
        if (Array.isArray(e) && Array.isArray(t)) {
            if (e.length != t.length) {
                a = 1;
            }
            else {
                let s, r;
                for (let n = 0, i = e.length; n < i; n++) {
                    if (s = e[n], r = t[n], s.length != r.length) {
                        a = 1;
                        break;
                    }
                    for (let e = 0, t = s.cards.length; e < t; e++) {
                        if (s.cards[e] != r.cards[e]) {
                            a = 1;
                            break;
                        }
                    }
                    if (1 == a) {
                        break;
                    }
                }
            }
        }
        return a;
    }
    getHandRatingType(e) {
        let t = 0, a = Math.floor(10 * e) / 10;
        a > 5 && (a = 5);
        let s = ToolUtils.parse_double("" + a, 1), r = Math.floor(s);
        return s - r >= 0.1 && (r += 0.5), r >= 4.5 ? t = Rating_Type.pefect : r >= 3 && r <= 4 ? t = Rating_Type.good : r >= 2 && r <= 2.5 ? t = Rating_Type.risky : r >= 0.5 && r <= 1.5 && (t = Rating_Type.bad), t;
    }
    checkLiveAvatar(t, a) {
        let r = RummyDataManager.shared().rummyInfos.get(t).playerModels[a];
        if (sys.isObjectValid(r)) {
            if ("head_101.png" == r.avatar) {
                return 0;
            }
            if ("head_102.png" == r.avatar) {
                return 1;
            }
        }
        return -1;
    }
    getCanShowAvailableCardTips() {
        let e = false;
        if (1 == User.shared().help_setting.available_cards) {
            let t = sys.localStorage.getItem("available_cards_def");
            null == t && (t = User.shared().help_setting.available_cards_def);
            1 == Number(t) && (e = true);
        }
        return e;
    }
    send_request_touch_drop_up_venue_alert(e, t, a, s) {
        let n = { cmd: RummyCmd.GM_NOTIFY_TOUCH_DROP_UP_VENUE_TIPS, uid: User.shared().data.uid, version: GameConfig.Server_Api_Ver, skey: User.shared().getSkey(), tid_key: e, is_show_up_venue: t, has_first_open: a, drop_tips_count: s };
        Server.shared().send(n);
    }
}
