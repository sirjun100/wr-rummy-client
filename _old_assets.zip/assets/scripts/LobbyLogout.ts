// @ts-nocheck
// Recovered from index.js:245
import { _decorator, Node, sys, UITransform, v3 } from "cc";
import PushCenter from "./PushCenter";
import User from "./User";
import SoundManager from "./SoundManager";
import BaseLayer from "./BaseLayer";
import TweenTool from "./TweenTool";
import HttpManager from "./HttpManager";
import { ToolUtils } from "./ToolUtils";
import ReportConfig from "./ReportConfig";
const { ccclass, property } = _decorator;
@ccclass("LobbyLogout")
export class LobbyLogout extends BaseLayer {
    @property(Node)
    public rootNode: Node = null;
    public click_time: number = 0;
    initParaData(t, e = null) {
    }
    start() {
        super.start();
        ToolUtils.showFullScreen(this.node.getChildByName("bg"));
        this.fitScreen();
        this.startShowAnim();
    }
    fitScreen() {
    }
    startShowAnim() {
        let t = this.node.getChildByName("bg").getComponent(UITransform).contentSize, e = v3(0, -t.height / 2);
        this.rootNode.setPosition(v3(0, -1280, 0));
        TweenTool.moveTo(this.rootNode, 0.15, e, "fade", true, (() => {
            this.rootNode.setPosition(e);
        }));
    }
    onDestroy() {
        PushCenter.shared().removeListenersByTag(this);
        this.unscheduleAllCallbacks();
    }
    onAssureClick(t, e) {
        SoundManager.shared().playFx("click");
        sys.now() - this.click_time <= 1000 || (this.click_time = sys.now(), HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.ME, event: ReportConfig.hall_evt.click_logout }), User.shared().showLogin());
    }
    onCloseClick(t, e) {
        SoundManager.shared().playFx("click");
        this.onBackView();
    }
    onBackView() {
        ToolUtils.isObjValid(this.node) && this.node.destroy();
    }
    update(t) {
    }
}
