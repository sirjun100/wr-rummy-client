// @ts-nocheck
// Recovered from index.js:413
import { _decorator, Button, color, instantiate, isValid, Label, Node, ScrollView, size, Sprite, sys, UITransform, v3, view, Widget } from "cc";
import Utils from "./Utils";
import SoundManager from "./SoundManager";
import HttpManager from "./HttpManager";
import TableViewUtils from "./TableViewUtils";
import i18nMgr from "./i18nMgr";
import PushEvent from "./PushEvent";
import PushCenter from "./PushCenter";
import User from "./User";
import BaseLayer from "./BaseLayer";
import TweenTool from "./TweenTool";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("rpsHistory")
export class rpsHistory extends BaseLayer {
    @property(Node)
    public topRoot: Node = null;
    @property(Node)
    public siftRoot: Node = null;
    @property(Node)
    public HisMoban: Node = null;
    @property(ScrollView)
    public scollview: ScrollView = null;
    @property(Node)
    public nodataIC: Node = null;
    @property(Node)
    public siftBgNode: Node = null;
    @property(Node)
    public siftContentNode: Node = null;
    public StatusColor: any[] = [color(215, 60, 69), color(0, 140, 22)];
    public btnLabelColor: any[] = [color(153, 153, 153, 255), color(0, 140, 22, 255)];
    public timeStatusTextList: any[] = ["store.all", "store.today"];
    public TimeTag: number = 0;
    public TransactionTag: number = 0;
    public sdate: string = "";
    public edate: string = "";
    public rpsHisTabView: any = null;
    public rpsHisData: any[] = [];
    public lastid: number = 0;
    public page: number = 0;
    public callback: any = null;
    public scollToTop: boolean = false;
    public curTimeTag: number = 0;
    public curTransactionTag: any = -1;
    public sendHttpNum: number = 0;
    public TransactionList: any[] = [];
    public menuList: any[] = [];
    public timeBtnList: any[] = [];
    public _startY: number = 0;
    public _closeAct: any = null;
    public _startAct: any = null;
    public siftBgHeight: number = 748;
    onLoad() {
        for (let t = 0; t < 8; t++) {
            let i = "btnTime" + t;
            0 == t && (i = "btnTimeAll");
            this.timeBtnList[t] = this.siftContentNode.getChildByName(i);
        }
        this.fitScreen();
        this.initTime();
        this.reset();
        Utils.shared().hideLoading();
    }
    start() {
        super.start();
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().removeListenersByTag(this);
        this.unscheduleAllCallbacks();
    }
    onBackView() {
        ToolUtils.isObjValid(this.node) && (this.siftRoot.active ? this.siftRoot.active = false : (this.callback && this.callback(), this.node.destroy()));
    }
    reset() {
        this.initTime();
        this.TimeTag = 0;
        this.TransactionTag = 0;
        this.curTimeTag = 0;
        this.curTransactionTag = 0;
        for (let t = 0, i = this.timeBtnList.length; t < i; t++) {
            let i = this.timeBtnList[t], e = this.siftContentNode.getChildByName("timeLabel" + t).getComponent(Label);
            t == this.TimeTag ? e.color = this.btnLabelColor[1] : e.color = this.btnLabelColor[0];
            i.getChildByName("select_di").active = t == this.TimeTag;
            i.getChildByName("di").active = t != this.TimeTag;
        }
        for (let t = 0, i = this.TransactionList.length; t < i; t++) {
            let i = this.TransactionList[t], e = this.TransactionList[t].getChildByName("wz").getComponent(Label), s = this.menuList[t].value;
            s == this.TransactionTag ? e.color = this.btnLabelColor[1] : e.color = this.btnLabelColor[0];
            i.getChildByName("select_di").active = s == this.TransactionTag;
            i.getChildByName("di").active = s != this.TransactionTag;
        }
        this.updateSelectLabel();
    }
    updateSelectLabel() {
        let t = this.TimeTag, i = this.TransactionTag, e = this.topRoot.getChildByName("timeState"), s = this.topRoot.getChildByName("transactionState");
        if (e.active = 0 != t, s.active = 0 != i, 1 == t) {
            i18nMgr.shared().changeLabelLanguage(e.getComponent(Label), this.timeStatusTextList[t]);
            e.getComponent(Label).updateRenderData(true);
            e.getChildByName("delete_btn").getComponent(Widget).updateAlignment();
        }
        else if (0 != t) {
            let i = this.siftContentNode.getChildByName("timeLabel" + t).getComponent(Label).string;
            e.getComponent(Label).string = i;
            e.getComponent(Label).updateRenderData(true);
            e.getChildByName("delete_btn").getComponent(Widget).updateAlignment();
        }
        if (0 != i) {
            let t = "";
            if (sys.isObjectValid(this.menuList)) {
                for (let e = 0, s = this.menuList.length; e < s; e++) {
                    if (i == this.menuList[e].value) {
                        t = this.menuList[e].name;
                        break;
                    }
                }
            }
            s.getComponent(Label).string = t;
            s.getComponent(Label).updateRenderData(true);
            let a = e.getPosition().x;
            e.active && (a = a + e.getComponent(UITransform).contentSize.width + 50);
            s.setPosition(v3(a, -85));
        }
    }
    initTime() {
        let t = new Date, i = 0, e = 0, s = 0;
        i = t.getFullYear();
        e = t.getMonth() + 1;
        s = t.getDate();
        this.edate = i.toString() + String("0" + e).slice(-2) + String("0" + s).slice(-2);
        let a = t.getTime();
        a -= 518400000;
        t.setTime(a);
        i = t.getFullYear();
        e = t.getMonth() + 1;
        s = t.getDate();
        this.sdate = i.toString() + String("0" + e).slice(-2) + String("0" + s).slice(-2);
    }
    initSift(t) {
        let i = this.siftContentNode.getChildByName("btnMoban"), e = t, s = 0;
        Array.isArray(e) && e.length > 0 && (s = e.length);
        let a = 82 * (Math.ceil(s / 3) - 4);
        if (this.siftBgHeight = 748 + a, this.siftBgNode.getComponent(UITransform).setContentSize(size(720, this.siftBgHeight)), this.siftContentNode.setPosition(v3(0, a)), this.TransactionList = [], Array.isArray(e)) {
            for (let t = 0, s = e.length; t < s; t++) {
                let s = this.siftContentNode.getChildByName("typeBtn" + t);
                sys.isObjectValid(s) || (s = instantiate(i));
                s.parent = this.siftContentNode;
                s.active = true;
                let a = s.getChildByName("wz");
                sys.isObjectValid(e[t]) && (a.getComponent(Label).string = e[t].name);
                s.name = "typeBtn" + t;
                s.position = v3(t % 3 * 228 - 228, 420 - 82 * Math.floor(t / 3));
                s.getComponent(Button).clickEvents[0].customEventData = e[t].value + "";
                this.TransactionList[t] = s;
            }
        }
    }
    setTime(t) {
        let i = new Date, e = 0, s = 0, a = 0;
        if (0 == t) {
            this.initTime();
        }
        else {
            let n = [0, 1, 2, 3, 4, 5, 6, 7], o = i.getTime();
            o -= 86400 * (n[t] - 1) * 1000;
            i.setTime(o);
            e = i.getFullYear();
            s = i.getMonth() + 1;
            a = i.getDate();
            this.sdate = e.toString() + String("0" + s).slice(-2) + String("0" + a).slice(-2);
            this.edate = this.sdate;
        }
    }
    requestRpsHistory(t, i, e, s = 0) {
        this.rpsHisTabView.stopAutoScroll();
        this.sendHttpNum = this.sendHttpNum + 1;
        let a = { type: t, sdate: i, edate: e, last_id: s };
        HttpManager.shared().doGetMemberShipRpsDetail(a, this.listenRpsHistoryCallback.bind(this));
    }
    listenRpsHistoryCallback(t, i, e) {
        if (Utils.shared().hideLoading(), 0 != i.length) {
            if (200 != e) {
                alert("The login timed out, please try again");
            }
            else {
                let t = ToolUtils.parseJson(i);
                if (0 == t.ret && (this.sendHttpNum <= 1 && (User.shared().clubData_history = t, sys.isObjectValid(t.data.menu_list) && (this.menuList = t.data.menu_list)), isValid(this))) {
                    if (this.lastid = Number(t.data.last_id), Number.isNaN(this.lastid) && (this.lastid = 0), null == t.data.have_page ? this.page = 0 : this.page = t.data.have_page, sys.isObjectValid(t.data.list)) {
                        if (t.data.list.length < 1 && this.rpsHisData.length < 1) {
                            this.rpsHisData = [];
                            this.nodataIC.active = true;
                        }
                        else {
                            for (let i = 0, e = t.data.list.length; i < e; i++) {
                                this.rpsHisData.push(t.data.list[i]);
                            }
                            this.nodataIC.active = false;
                        }
                    }
                    this.refreshRpsHistory();
                }
            }
        }
    }
    Uishow(t, i = null) {
        if (this.callback = i, this.reset(), isValid(this)) {
            if (this.lastid = Number(t.data.last_id), Number.isNaN(this.lastid) && (this.lastid = 0), null == t.data.have_page ? this.page = 0 : this.page = t.data.have_page, sys.isObjectValid(t.data.list)) {
                if (t.data.list.length < 1 && this.rpsHisData.length < 1) {
                    this.nodataIC.active = true;
                }
                else {
                    for (let i = 0, e = t.data.list.length; i < e; i++) {
                        this.rpsHisData.push(t.data.list[i]);
                    }
                    this.nodataIC.active = false;
                }
            }
            sys.isObjectValid(t.data.menu_list) && (this.menuList = t.data.menu_list);
            this.siftRoot.active = false;
            let i = [this.HisMoban];
            this.rpsHisTabView = this.node.addComponent(TableViewUtils);
            let e = this.HisMoban.getComponent(UITransform).height;
            this.rpsHisTabView.init([], this.scollview.node, i, this.initCurMobanCallBack.bind(this), 0, e, this.scrollRefreshCallBack.bind(this));
            this.refreshRpsHistory();
            this.rpsHisData = [];
            this.requestRpsHistory(0, this.sdate, this.edate, 0);
        }
    }
    button_click(t, i) {
        if (SoundManager.shared().playFx("click"), this.scollToTop = false, "close" == i) {
            this.onBackView();
        }
        else if ("sift" == i) {
            this.siftRoot.active = true;
            this.initSifeTimeLabels();
            this.initSift(this.menuList);
            this.timeButton_click(null, this.curTimeTag, false);
            this.transactionButton_click(null, this.curTransactionTag, false);
            this.updateSifeBtnSp();
            this._startAct || this.showSelectView();
        }
        else if ("reset" == i) {
            this.reset();
        }
        else if ("confirm" == i) {
            this.scollToTop = true;
            this.hideSelectView((() => {
                this.siftRoot.active = false;
            }));
            this.rpsHisData = [];
            this.lastid = 0;
            this.requestRpsHistory(this.TransactionTag, this.sdate, this.edate, this.lastid);
            this.updateSelectLabel();
            this.curTimeTag = this.TimeTag;
            this.curTransactionTag = this.TransactionTag;
            this.updateSifeBtnSp();
        }
        else if ("time_state" == i) {
            this.rpsHisData = [];
            this.scollToTop = true;
            this.lastid = 0;
            this.timeButton_click(null, 0, false);
            this.TimeTag = 0;
            this.curTimeTag = 0;
            this.updateSelectLabel();
            this.updateSifeBtnSp();
            0 == this.TimeTag && 0 == this.TransactionTag ? this.requestRpsHistory(0, this.sdate, this.edate, this.lastid) : this.requestRpsHistory(this.TransactionTag, this.sdate, this.edate, this.lastid);
        }
        else if ("trans_state" == i) {
            this.rpsHisData = [];
            this.scollToTop = true;
            this.lastid = 0;
            this.transactionButton_click(null, 0, false);
            this.TransactionTag = 0;
            this.curTransactionTag = 0;
            this.updateSelectLabel();
            this.updateSifeBtnSp();
            0 == this.TimeTag && 0 == this.TransactionTag ? this.requestRpsHistory(0, this.sdate, this.edate, this.lastid) : this.requestRpsHistory(this.TransactionTag, this.sdate, this.edate, this.lastid);
        }
        else if ("close_sift" == i) {
            this.hideSelectView((() => {
                this.siftRoot.active = false;
            }));
            this.updateSifeBtnSp();
        }
        else if ("kefu" == i) {
            if (1 == User.shared().temp_pingbi.feedback) {
                return void Utils.shared().showToast("Coming soon", 2);
            }
            Utils.shared().doJumpLogic(PushEvent.JUMP_TO_FEEDBACK);
        }
    }
    initSifeTimeLabels() {
        for (let t = 2, i = this.timeBtnList.length; t < i; t++) {
            let i = new Date, e = this.siftContentNode.getChildByName("timeLabel" + t), s = 0, a = 0, n = i.getTime() - 86400 * (t - 1) * 1000;
            i.setTime(n);
            s = i.getMonth() + 1;
            a = i.getDate();
            e.getComponent(Label).string = String("0" + a).slice(-2) + "/" + String("0" + s).slice(-2);
        }
        2 == i18nMgr.shared().language && (this.siftContentNode.getChildByName("timeLabel0").getComponent(Label).fontSize = 24);
    }
    updateSifeBtnSp() {
        let t = this.topRoot.getChildByName("btn_sift").getChildByName("sift"), i = t.getChildByName("Label");
        0 == this.curTimeTag && 0 == this.curTransactionTag ? (t.getComponent(Sprite).color = color(102, 102, 102), i.getComponent(Label).string = i18nMgr.shared().getValueByKey("store.filter"), i.getComponent(Label).color = color(102, 102, 102)) : (t.getComponent(Sprite).color = color(93, 98, 170), i.getComponent(Label).string = i18nMgr.shared().getValueByKey("store.filter"), i.getComponent(Label).color = color(93, 98, 170));
    }
    timeButton_click(t, i, e = true) {
        let s = Number(i);
        this.TimeTag = s;
        e && SoundManager.shared().playFx("click");
        for (let t = 0, i = this.timeBtnList.length; t < i; t++) {
            let i = this.timeBtnList[t], e = this.siftContentNode.getChildByName("timeLabel" + t).getComponent(Label);
            e.color = t == s ? this.btnLabelColor[1] : this.btnLabelColor[0];
            i.getChildByName("select_di").active = t == s;
            i.getChildByName("di").active = t != s;
        }
        this.setTime(s);
    }
    transactionButton_click(t, i, e = true) {
        let s = Number(i);
        e && SoundManager.shared().playFx("click");
        for (let t = 0, i = this.TransactionList.length; t < i; t++) {
            let i = this.TransactionList[t], e = this.TransactionList[t].getChildByName("wz").getComponent(Label), a = this.menuList[t].value;
            e.color = a == s ? this.btnLabelColor[1] : this.btnLabelColor[0];
            i.getChildByName("select_di").active = a == s;
            i.getChildByName("di").active = a != s;
        }
        this.TransactionTag = s;
    }
    initCurMobanCallBack(t, i) {
        if (null == i) {
            return;
        }
        t.active = true;
        let e = t.getChildByName("txt_gold_type").getComponent(Label), s = t.getChildByName("time").getComponent(Label), a = t.getChildByName("before").getComponent(Label), n = t.getChildByName("after").getComponent(Label);
        e.string = i.desc;
        s.string = i.time;
        Number(i.is_add) >= 1 ? (a.string = i.num, a.color = this.StatusColor[1]) : (a.string = i.num, a.color = this.StatusColor[0]);
        n.string = "" + ToolUtils.parse_double(i.total_rps);
    }
    scrollRefreshCallBack() {
        0 != this.page && (this.requestRpsHistory(this.curTransactionTag, this.sdate, this.edate, this.lastid), this.scollToTop = false);
    }
    refreshRpsHistory() {
        this.rpsHisTabView.reloadData(this.rpsHisData, this.scollToTop);
    }
    mobanCallBack(t, i) {
    }
    showSelectView(t = null) {
        let i = -view.getVisibleSize().height / 2, e = this.siftBgHeight;
        this._startY = i - e - 20;
        this.siftBgNode.setPosition(v3(0, this._startY));
        this._startAct = TweenTool.moveTo(this.siftBgNode, 0.2, v3(0, i), "sineIn", true, (() => {
            ToolUtils.isObjValid(this.node) && (this._startAct && TweenTool.stopAction(this._startAct), this._startAct = null, t && t());
        }));
    }
    hideSelectView(t = null) {
        this._startAct && TweenTool.stopAction(this._startAct);
        this._closeAct || (this._closeAct = TweenTool.moveTo(this.siftBgNode, 0.2, v3(0, this._startY), "sineIn", true, (() => {
            ToolUtils.isObjValid(this.node) && (TweenTool.stopAction(this._closeAct), this._closeAct = null, t && t());
        })));
    }
    fitScreen() {
        let t = ToolUtils.adaptSafeArea(this.node.getChildByName("root")), i = sys.getSafeAreaRect().y, e = view.getVisibleSize(), s = this.scollview.getComponent(UITransform).contentSize, a = e.height - (1280 - s.height) - i + t;
        this.scollview.getComponent(UITransform).contentSize = size(s.width, a);
    }
}
