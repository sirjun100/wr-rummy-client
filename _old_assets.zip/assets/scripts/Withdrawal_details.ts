// @ts-nocheck
// Recovered from index.js:685
import { _decorator, Button, color, Label, Layout, Node, size, Sprite, SpriteFrame, sys, UITransform, v3, view } from "cc";
import BaseLayer from "./BaseLayer";
import AppInfo from "./AppInfo";
import i18nMgr from "./i18nMgr";
import PushCenter from "./PushCenter";
import { ToolUtils } from "./ToolUtils";
import { TransferPlatform } from "./TransferPlatform";
import Utils from "./Utils";
import GameConfig from "./GameConfig";
import SoundManager from "./SoundManager";
const { ccclass, property } = _decorator;
@ccclass("Withdrawal_details")
export class Withdrawal_details extends BaseLayer {
    @property(Node)
    public rootNode: Node = null;
    @property(Node)
    public depositNode: Node = null;
    @property(Node)
    public toastBg: Node = null;
    public recordData: any = null;
    @property([SpriteFrame])
    public his_status_img: SpriteFrame[] = [];
    initData(t) {
        this.recordData = t;
    }
    onLoad() {
        this.depositNode.active = true;
        this.adaptScreen();
        this.fitLuckyTheme();
    }
    fitLuckyTheme() {
        0 != GameConfig.NATIVE_GAME_APP_TYPE && (this.rootNode.getChildByName("top_node").getChildByName("top_bg").getComponent(Sprite).color = color(12, 26, 60));
    }
    start() {
        super.start();
        this.refreshView();
    }
    refreshView() {
        sys.isObjectValid(this.recordData) && (sys.isObjectValid(this.recordData.amount) && (this.depositNode.getChildByName("amount").getComponent(Label).string = "₹" + this.recordData.amount), sys.isObjectValid(this.recordData.real_amount) && (this.depositNode.getChildByName("get").getComponent(Label).string = "₹" + this.recordData.real_amount), sys.isObjectValid(this.recordData.withdrawal_id) && (this.depositNode.getChildByName("wid").getComponent(Label).string = this.recordData.withdrawal_id), sys.isObjectValid(this.recordData.mode_text) && (this.depositNode.getChildByName("mode").getComponent(Label).string = this.recordData.mode_text), sys.isObjectValid(this.recordData.detail_date_text) && (this.depositNode.getChildByName("date").getComponent(Label).string = this.recordData.detail_date_text), sys.isObjectValid(this.recordData.status) ? (this.depositNode.getChildByName("status_bg").getComponent(Button).interactable = false, this.depositNode.getChildByName("status_bg").getChildByName("ico").getComponent(Sprite).spriteFrame = this.his_status_img[this.recordData.status], 0 == this.recordData.status ? (this.depositNode.getChildByName("status_bg").getChildByName("wz").getComponent(Label).string = "Pending", this.depositNode.getChildByName("status_bg").getChildByName("wz").getComponent(Label).color = color(255, 180, 0), this.depositNode.getChildByName("status_bg").getComponent(Sprite).color = color(255, 253, 231), sys.isObjectValid(this.recordData.reason) && this.recordData.reason.length > 0 && (this.toastBg.getChildByName("wz").getComponent(Label).string = this.recordData.reason, this.depositNode.getChildByName("status_bg").getComponent(Button).interactable = true, this.toastBg.getComponent(Layout).updateLayout(), this.depositNode.getChildByName("status_bg").getChildByName("wz").getComponent(Label).isUnderline = true)) : 1 == this.recordData.status ? (this.depositNode.getChildByName("status_bg").getChildByName("wz").getComponent(Label).string = "Success", this.depositNode.getChildByName("status_bg").getChildByName("wz").getComponent(Label).color = color(9, 147, 14), this.depositNode.getChildByName("status_bg").getComponent(Sprite).color = color(243, 255, 245)) : 2 == this.recordData.status && (this.depositNode.getChildByName("status_bg").getChildByName("wz").getComponent(Label).string = "Failed", this.depositNode.getChildByName("status_bg").getChildByName("wz").getComponent(Label).color = color(182, 0, 0), this.depositNode.getChildByName("status_bg").getComponent(Sprite).color = color(253, 243, 243), sys.isObjectValid(this.recordData.reason) && this.recordData.reason.length > 0 && (this.toastBg.getChildByName("wz").getComponent(Label).string = this.recordData.reason, this.depositNode.getChildByName("status_bg").getComponent(Button).interactable = true, this.toastBg.getComponent(Layout).updateLayout(), this.depositNode.getChildByName("status_bg").getChildByName("wz").getComponent(Label).isUnderline = true)), this.depositNode.getChildByName("get").getComponent(Label).string = "₹" + this.recordData.real_amount, 2 == this.recordData.status && 1 == this.recordData.ifsc_err ? (this.depositNode.getChildByName("bg").getComponent(UITransform).contentSize = size(696, 844), this.depositNode.getChildByName("account_tip").active = true, this.depositNode.getChildByName("account").active = true, sys.isObjectValid(this.recordData.w_account) && (this.depositNode.getChildByName("account").getComponent(Label).string = this.recordData.w_account), this.depositNode.getChildByName("ifsc_tip").active = true, this.depositNode.getChildByName("ifsc").active = true, sys.isObjectValid(this.recordData.w_ifsc) && (this.depositNode.getChildByName("ifsc").getComponent(Label).string = this.recordData.w_ifsc), this.depositNode.getChildByName("warn_node").active = true, this.depositNode.getChildByName("assure_btn").setPosition(v3(0, -825.524)), sys.isObjectValid(this.recordData.show_edit) && (this.depositNode.getChildByName("warn_node").getChildByName("change_btn").active = 1 == this.recordData.show_edit)) : (this.depositNode.getChildByName("bg").getComponent(UITransform).contentSize = size(696, 664), this.depositNode.getChildByName("account_tip").active = false, this.depositNode.getChildByName("account").active = false, this.depositNode.getChildByName("ifsc_tip").active = false, this.depositNode.getChildByName("ifsc").active = false, this.depositNode.getChildByName("warn_node").active = false, this.depositNode.getChildByName("assure_btn").setPosition(v3(0, -618.662)))) : this.depositNode.getChildByName("status_bg").getComponent(Button).interactable = false);
    }
    adaptScreen() {
        view.getVisibleSize();
        this.node.getChildByName("root");
        this.node.getChildByName("bg");
        ToolUtils.showFullScreen(this.node.getChildByName("bg"));
    }
    onDestroy() {
        super.onDestroy();
        TransferPlatform.shared().setSoftInputMode(0);
        PushCenter.shared().pushEvent(GameConfig.Update_Wallet);
        PushCenter.shared().removeListenersByTag(this);
        this.unscheduleAllCallbacks();
    }
    onButtonClick(t, e) {
        if (SoundManager.shared().playFx("click"), "close" === e) {
            this.onBackView();
        }
        else if ("chatus" === e) {
            Utils.shared().showContactUsView();
        }
        else if ("copy" === e) {
            AppInfo.shared().copyContent(this.recordData.withdrawal_id);
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text33"), 2);
        }
        else if ("change_account" == e) {
            let t = { w_account: this.recordData.w_account, w_ifsc: this.recordData.w_ifsc, record_id: this.recordData.acc_record_id, ifsc_err: 1 };
            Utils.shared().showWithdrawEditView(null, t, (t => {
                sys.isObjectValid(this.recordData.show_edit) && (this.recordData.show_edit = 0, this.depositNode.getChildByName("warn_node").getChildByName("change_btn").active = false);
            }));
        }
        else if ("reason" == e) {
            let t = this.toastBg.active;
            this.toastBg.active = !t;
        }
    }
    onBackView() {
        ToolUtils.isObjValid(this.node) && this.node.destroy();
    }
}
