// @ts-nocheck
// Recovered from index.js:401
import { _decorator, assetManager, AudioSource, director, instantiate, macro, Node, SpriteFrame, sys, Widget } from "cc";
import Parent from "./Parent";
import i18nMgr from "./i18nMgr";
import PushCenter from "./PushCenter";
import { TLog } from "./TLog";
import { ToolUtils } from "./ToolUtils";
import { TransferPlatform } from "./TransferPlatform";
import TweenTool from "./TweenTool";
import Utils from "./Utils";
import BundleNameDefined from "./BundleNameDefined";
import { CommonGameType, HallGameType } from "./CommDefine";
import GameConfig from "./GameConfig";
import NetConfig from "./NetConfig";
import PhpReportDefined from "./PhpReportDefined";
import PushEvent from "./PushEvent";
import RummyCmd from "./RummyCmd";
import User from "./User";
import HttpManager from "./HttpManager";
import LabaServer from "./LabaServer";
import Server from "./Server";
import SoundManager from "./SoundManager";
import gameNetworkDelay from "./gameNetworkDelay";
import RocketGameAction from "./RocketGameAction";
import RocketGameCmd from "./RocketGameCmd";
import { RocketGameManager } from "./RocketGameManager";
import { RocketGameNoSeatList } from "./RocketGameNoSeatList";
import RocketGameTable from "./RocketGameTable";
import RocketGameTrend from "./RocketGameTrend";
const { ccclass, property } = _decorator;
@ccclass("RocketGameMain")
export class RocketGameMain extends Parent {
    public _TAG: string = "RocketGameMain";
    public isNetworkDelay: boolean = true;
    public _gameData: any = {};
    public _enterStartTime: number = 0;
    public backgroundSatyTime: number = 0;
    @property(Node)
    public rootNode: Node = null;
    @property([AudioSource])
    public musicAudioSources: AudioSource[] = [];
    @property(SpriteFrame)
    public helpImg: SpriteFrame = null;
    public roomTable: any = undefined;
    public roomAction: any = undefined;
    public roomTrend: any = undefined;
    public gameSettingPrefab: any = null;
    public gameAutoPlayPrefab: any = null;
    public noSeatPlayerView: any = null;
    public gameNoseatPrefab: any = null;
    public menualertPrefab: any = null;
    public jackPotPrefab: any = null;
    public networkDelay: number = 0;
    public tid_key: string = "";
    public hasReqRandom: boolean = false;
    onDestroy() {
        gameNetworkDelay.shared().removechild();
        Server.shared().onBackGroundLink();
        PushCenter.shared().removeListenersByTag(this);
        this.unscheduleAllCallbacks();
    }
    onLoad() {
        User.shared().fromGame = 1;
        ToolUtils.switchSceneTye = -1;
        ToolUtils.bSwitchToGame = false;
        window.InHallScene = false;
        window.InGameScene = true;
        window.InSwitchScene = false;
        window.IsBackToHallLoad = false;
        macro.ENABLE_MULTI_TOUCH = false;
        RocketGameManager.shared()._tidKey = User.shared().curTid_key;
        this.tid_key = User.shared().curTid_key;
        RocketGameManager.shared()._vid = ToolUtils.curRoomId;
        User.shared().exitRoomGameVid = ToolUtils.curRoomId;
        this.node.getChildByName("root").getComponent(Widget).enabled = true;
    }
    start() {
        RocketGameManager.shared().data.room_ad_act = -1;
        ToolUtils.report_time_param.gameStart = sys.now();
        this._enterStartTime = sys.now();
        gameNetworkDelay.shared().loadNode();
        this.resetGameData();
        let e = new Node;
        this.node.addChild(e);
        RocketGameManager.shared().sceneNode = e;
        this.initView();
        this._gameData.connectCount = 0;
        this.initPushCenter();
        this.regEvent();
        1 == ToolUtils.heart_open && (this.unschedule(this.netWorkDelayUpdate), this.schedule(this.netWorkDelayUpdate, 2));
        TweenTool.delayAct(this.node, (() => {
            this.loadGameSounds();
            ToolUtils.preLoadBundlePrefab(BundleNameDefined.bundle_public, "prefab/menu_alert", null);
        }), 0.5, true);
        let t = {};
        t.htype = HallGameType.LOBBY_GAME_TYPE_CRASH;
        ToolUtils.saveData(User.shared().data.uid + "saveCommRecommendRoom", ToolUtils.toJsonString(t));
    }
    netWorkDelayUpdate() {
        if (this.networkDelay = this.networkDelay + 1, !User.shared().isGameDisconnectServer) {
            if (this.isNetworkDelay) {
                let e = { cmd: NetConfig.HEARTBEAT_CMD };
                Server.shared().send(e);
                ToolUtils.lastSendHeartBeatTime = ToolUtils.getOsTime();
                this.isNetworkDelay = false;
                this.networkDelay = 0;
            }
            if (this.networkDelay > 10) {
                let e = { cmd: NetConfig.HEARTBEAT_CMD };
                Server.shared().send(e);
                ToolUtils.lastSendHeartBeatTime = ToolUtils.getOsTime();
                this.isNetworkDelay = false;
                this.networkDelay = 0;
            }
        }
    }
    initView() {
        RocketGameManager.shared().popNode = this.rootNode.getChildByName("pop_root");
        this.roomTable = this.rootNode.getChildByName("table_layout").getComponent(RocketGameTable);
        this.roomTable.setCallBack(this.roomActionCallback.bind(this));
        this.roomAction = this.rootNode.getChildByName("action_root").getComponent(RocketGameAction);
        this.roomAction.setCallBack(this.roomActionCallback.bind(this));
        this.roomTrend = this.rootNode.getChildByName("trend_layout").getComponent(RocketGameTrend);
        this.roomTrend.updateViewStatus(false);
        Server.shared().pop_response();
        this._gameData.jackPotNum = 0;
        RocketGameManager.shared().sendGameInfoRequest();
        this.roomAction.updateGullakBtnStatus(User.shared().act_68_open, User.shared().act_68_full_status, false);
    }
    roomActionCallback(e) {
        if ("main_close" == e) {
            this.showMenuAlert();
        }
        else if ("jackpot" == e) {
            this.dealJackPotLogic();
        }
        else if ("add_chip" == e) {
            let e = this._gameData.cur_bet[0];
            this._gameData.cur_bet[1] < e && (e = this._gameData.cur_bet[1]);
            let t = { vid: ToolUtils.curVId, min_entry: e, tid_key: this.tid_key };
            Utils.shared().showQuickRecharge(ToolUtils.curVId, RocketGameManager.shared().popNode, true, User.shared().curTid_key, 0, t.min_entry, false, 0, 0, 0, 1);
            User.shared().updatePayScene(PhpReportDefined.pay_scene.game_desktop, ToolUtils.curVId);
        }
        else if ("main_help" == e) {
            this.dealHelpLogic();
        }
        else if ("btn_set" == e) {
            this.dealSetLogic();
        }
        else if ("bet_reduce0" == e) {
            this.dealBetReduceLogic(0);
        }
        else if ("bet_reduce1" == e) {
            this.dealBetReduceLogic(1);
        }
        else if ("bet_add0" == e) {
            this.dealBetAddLogic(0);
        }
        else if ("bet_add1" == e) {
            this.dealBetAddLogic(1);
        }
        else if ("change_bet0" == e) {
            this.dealSelectBetViewLogic(0);
        }
        else if ("change_bet1" == e) {
            this.dealSelectBetViewLogic(1);
        }
        else if (-1 != e.indexOf("selectbet_")) {
            let t = parseInt(e.split("_")[1]);
            this.dealChooseSelectBetLogic(t);
            this.roomAction.updateSelectBetVisbile(false, 0);
        }
        else if ("assure_bet0" == e) {
            this.dealAssureBetLogic(0);
        }
        else if ("assure_bet1" == e) {
            this.dealAssureBetLogic(1);
        }
        else if ("cancel_bet0" == e) {
            this.dealCancelBetLogic(0);
        }
        else if ("cancel_bet1" == e) {
            this.dealCancelBetLogic(1);
        }
        else if ("autobet_btn0" == e) {
            this.dealAutoSwitchLogic(0, false);
        }
        else if ("autobet_btn1" == e) {
            this.dealAutoSwitchLogic(1, false);
        }
        else if ("auto_btn0" == e) {
            this.dealAutoSwitchLogic(0, false);
        }
        else if ("auto_btn1" == e) {
            this.dealAutoSwitchLogic(1, false);
        }
        else if ("fixauto_btn0" == e) {
            this.dealAutoSwitchLogic(0, true);
        }
        else if ("fixauto_btn1" == e) {
            this.dealAutoSwitchLogic(1, true);
        }
        else if ("noseat_list" == e) {
            this.dealNoseatListLogic();
        }
        else if ("trend_record" == e) {
            this.send_history_recode_request();
            this.roomTrend.updateViewStatus(true);
        }
        else if ("cashout_btn0" == e) {
            this.dealCashOutLogic(0);
        }
        else if ("cashout_btn1" == e) {
            this.dealCashOutLogic(1);
        }
        else if ("close_bet" == e) {
            this.roomAction.updateSelectBetVisbile(false, 0);
        }
        else if ("gullak" == e) {
            let e = { vid: ToolUtils.curVId, parent_node: RocketGameManager.shared().popNode };
            Utils.shared().doJumpLogic(PushEvent.JUMP_TO_Gullak, e, { isNext: false, bWithTip: true, link_id: sys.now(), reportEvtId: 4, reportScene: 2 });
            User.shared().updatePayScene(PhpReportDefined.pay_scene.game_desktop, ToolUtils.curVId);
        }
    }
    dealCashOutLogic(e) {
        let t = { cmd: RocketGameCmd.REQ_CASH_OUT, ch_id: 0, uid: User.shared().data.uid, version: GameConfig.Server_Api_Ver, skey: User.shared().getSkey(), vid: ToolUtils.curRoomId, tid_key: this.tid_key, index: e };
        Server.shared().send(t);
    }
    dealNoseatListLogic() {
        this.send_players_info_request(1);
    }
    send_request_cur_fly_state() {
        let e = { cmd: RocketGameCmd.REQ_CURR_FLY_STATE, ch_id: 0, uid: User.shared().data.uid, version: GameConfig.Server_Api_Ver, skey: User.shared().getSkey(), vid: ToolUtils.curRoomId, tid_key: this.tid_key };
        Server.shared().send(e);
    }
    dealJackPotLogic() {
        try {
            ToolUtils.loadCommonPrefab(this.jackPotPrefab, BundleNameDefined.Bundle_GameCrash, "prefab/rocket_game_jp", (e => {
                if (sys.isObjectValid(e) && e.isValid && sys.isObjectValid(this.node)) {
                    this.jackPotPrefab = e;
                    let t = this.node.getChildByName("rocket_game_jp");
                    ToolUtils.isObjValid(t) || (t = instantiate(e), t.parent = this.node);
                }
            }));
        }
        catch (e) {
            TLog.printError("trycatch  set:", e);
        }
    }
    showMenuAlert() {
        try {
            ToolUtils.loadCommonPrefab(this.menualertPrefab, BundleNameDefined.bundle_public, "prefab/menu_alert", (e => {
                if (sys.isObjectValid(e) && e.isValid && sys.isObjectValid(this.node)) {
                    this.menualertPrefab = e;
                    let t = this.node.getChildByName("menu_alert");
                    if (!ToolUtils.isObjValid(t)) {
                        t = instantiate(e);
                        t.parent = this.node;
                        let a = t.getComponent("MenuAlert");
                        this.initMenu(a);
                    }
                }
            }));
        }
        catch (e) {
            TLog.printError("trycatch MainRummy onDealBtnAction set:", e);
        }
    }
    initMenu(e) {
        e.startShowAnim();
        e.setCallback(this.onMenuCallback.bind(this));
        e.setTidKey(User.shared().curTid_key);
        e.setLandscapeShow();
        e.setSevenUpMenuShow();
    }
    onMenuCallback(e) {
        SoundManager.shared().playFx("click");
        try {
            switch (String(e)) {
                case "exit":
                    this.dealCloseLogic();
                    break;
                case "setting":
                    this.dealSetLogic();
                    break;
                case "help":
                    let e = {};
                    e.parent = this.node, e.isLandscape = true, e.target_sp = this.helpImg, e.game_type = CommonGameType.Crash, Utils.shared().showSingleGameRuleHelpView(e);
            }
        }
        catch (e) {
            TLog.printError("trycatch onMenuCallback:", e);
        }
    }
    send_history_recode_request() {
        let e = { cmd: RocketGameCmd.GM_HISTORY_RECORD_REQUSET, ch_id: 0, uid: User.shared().data.uid, version: GameConfig.Server_Api_Ver, skey: User.shared().getSkey(), vid: ToolUtils.curRoomId, tid_key: this.tid_key };
        Server.shared().send(e);
    }
    send_players_info_request(e) {
        let t = { cmd: RocketGameCmd.GM_PLAYERS_INFO_REQUEST, ch_id: 0, uid: User.shared().data.uid, version: GameConfig.Server_Api_Ver, skey: User.shared().getSkey(), vid: ToolUtils.curRoomId, tid_key: this.tid_key, page: e };
        Server.shared().send(t);
    }
    dealAutoSwitchLogic(e, t) {
        let a = this._gameData.auto_play[e], i = { cmd: RocketGameCmd.GM_AUTO_BET_REQUEST, ch_id: 0, uid: User.shared().data.uid, version: GameConfig.Server_Api_Ver, skey: User.shared().getSkey(), vid: ToolUtils.curRoomId, tid_key: this.tid_key, index: e };
        1 != a || t ? ToolUtils.loadCommonPrefab(this.gameAutoPlayPrefab, BundleNameDefined.Bundle_GameCrash, "prefab/rocket_game_autoplay", (t => {
            this.gameAutoPlayPrefab = t;
            this.showAutoPlayView(e);
        })) : (i.enable = 0, Server.shared().send(i));
    }
    showAutoPlayView(e) {
        try {
            let t = director.getScene().getChildByName("Canvas");
            if (!ToolUtils.isObjValid(t.getChildByName("rocket_game_autoplay"))) {
                let a = instantiate(this.gameAutoPlayPrefab);
                a.name = "rocket_game_autoplay";
                a.parent = t;
                let i = a.getComponent("RocketGameAutoPlay"), s = this._gameData.auto_play[e], r = { isFix: 1 == s, cb: t => {
                        let a = { cmd: RocketGameCmd.GM_AUTO_BET_REQUEST, ch_id: 0, uid: User.shared().data.uid, version: GameConfig.Server_Api_Ver, skey: User.shared().getSkey(), vid: ToolUtils.curRoomId, tid_key: this.tid_key, index: e, enable: 1, rounds: t.round, auto_out: t.check_num };
                        Server.shared().send(a);
                    } };
                1 == s && (r.auto_checkout_num = this._gameData.auto_checkbl[e], r.round = this._gameData.auto_turns[e]);
                i.initParaData(r);
            }
        }
        catch (e) {
            TLog.printError(this._TAG, "showAutoPlayView err:", e);
        }
    }
    dealCancelBetLogic(e) {
        let t = { cmd: RocketGameCmd.GM_CANCEL_BET_REQUEST, ch_id: 0, uid: User.shared().data.uid, version: GameConfig.Server_Api_Ver, skey: User.shared().getSkey(), vid: ToolUtils.curRoomId, tid_key: this.tid_key, index: e };
        Server.shared().send(t);
    }
    dealAssureBetLogic(e) {
        let t = this._gameData.cur_bet[e];
        this.send_request_down_bet(t, e);
    }
    send_request_down_bet(e, t) {
        let a = { cmd: RocketGameCmd.GM_BET_REQUEST, ch_id: 0, uid: User.shared().data.uid, version: GameConfig.Server_Api_Ver, skey: User.shared().getSkey(), vid: ToolUtils.curRoomId, tid_key: this.tid_key, bet: e, index: t };
        Server.shared().send(a);
    }
    dealChooseSelectBetLogic(e) {
        if (-1 != this._gameData.select_betview_index) {
            let t = RocketGameManager.shared().bet_configVec[e];
            this._gameData.cur_bet[this._gameData.select_betview_index] = t;
            this.roomAction.updateCurBetNum(this._gameData.cur_bet[this._gameData.select_betview_index], this._gameData.select_betview_index);
            this.send_request_notify_bet_change(this._gameData.cur_bet[this._gameData.select_betview_index], this._gameData.select_betview_index);
            this.roomAction.updateSelectBetVisbile(false, this._gameData.select_betview_index);
            this._gameData.select_betview_index = -1;
        }
    }
    dealSelectBetViewLogic(e) {
        this.roomAction.isSelectBetViewVisible() && this._gameData.select_betview_index == e ? (this._gameData.select_betview_index = -1, this.roomAction.updateSelectBetVisbile(false, e)) : (this.roomAction.updateSelectBetVisbile(true, e), this._gameData.select_betview_index = e);
    }
    checkAddBtnStatus(e) {
        let t = 100, a = 1000, i = e;
        if (sys.isObjectValid(RocketGameManager.shared().bet_configVec) && RocketGameManager.shared().bet_configVec.length > 0 && (a = RocketGameManager.shared().bet_configVec[RocketGameManager.shared().bet_configVec.length - 1]), sys.isObjectValid(RocketGameManager.shared().bet_rate_configVec_add) && RocketGameManager.shared().bet_rate_configVec_add.length > 0) {
            for (let e = 0; e < RocketGameManager.shared().bet_rate_configVec_add.length; e++) {
                let a = RocketGameManager.shared().bet_rate_configVec_add[e];
                if (i >= a.sn) {
                    if (-1 == a.en) {
                        t = a.rate;
                        break;
                    }
                    if (i < a.en) {
                        t = a.rate;
                        break;
                    }
                }
            }
        }
        return i + t > a ? { flag: false, bet_rate: t } : { flag: true, bet_rate: t };
    }
    judgeCoin(e) {
        return User.shared().data.money >= e;
    }
    dealBetAddLogic(e) {
        let t = this._gameData.cur_bet[e], a = this.checkAddBtnStatus(t);
        a.flag ? (this._gameData.cur_bet[e] = t + a.bet_rate, this.roomAction.updateCurBetNum(this._gameData.cur_bet[e], e), this.send_request_notify_bet_change(this._gameData.cur_bet[e], e)) : this.roomAction.updateAddBetBtnStatus(false, e);
    }
    checkReduceBtnStatus(e) {
        let t = 100, a = 1000, i = e;
        if (sys.isObjectValid(RocketGameManager.shared().bet_configVec) && RocketGameManager.shared().bet_configVec.length > 0 && (a = RocketGameManager.shared().bet_configVec[0]), sys.isObjectValid(RocketGameManager.shared().bet_rate_configVec_reduce) && RocketGameManager.shared().bet_rate_configVec_reduce.length > 0) {
            for (let e = 0; e < RocketGameManager.shared().bet_rate_configVec_reduce.length; e++) {
                let a = RocketGameManager.shared().bet_rate_configVec_reduce[e];
                if (i > a.sn) {
                    if (-1 == a.en) {
                        t = a.rate;
                        break;
                    }
                    if (i <= a.en) {
                        t = a.rate;
                        break;
                    }
                }
            }
        }
        return i - t < a ? { flag: false, bet_rate: t } : { flag: true, bet_rate: t };
    }
    dealBetReduceLogic(e) {
        let t = this._gameData.cur_bet[e], a = this.checkReduceBtnStatus(t);
        a.flag ? (this._gameData.cur_bet[e] = t - a.bet_rate, this.roomAction.updateCurBetNum(this._gameData.cur_bet[e], e), this.send_request_notify_bet_change(this._gameData.cur_bet[e], e)) : this.roomAction.updateReduceBetBtnStatus(false, e);
    }
    send_request_notify_bet_change(e, t) {
        let a = { cmd: RocketGameCmd.GM_NOTIFY_BET_CHANGE, ch_id: 0, uid: User.shared().data.uid, version: GameConfig.Server_Api_Ver, skey: User.shared().getSkey(), vid: ToolUtils.curRoomId, tid_key: this.tid_key, cur_bet: e, index: t };
        Server.shared().send(a);
    }
    dealSetLogic() {
        ToolUtils.loadCommonPrefab(this.gameSettingPrefab, BundleNameDefined.bundle_public, "prefab/game_setting", (e => {
            this.gameSettingPrefab = e;
            this.showSettingAlert();
        }));
    }
    showSettingAlert() {
        try {
            let e = director.getScene().getChildByName("Canvas");
            if (!ToolUtils.isObjValid(e.getChildByName("game_setting"))) {
                let t = instantiate(this.gameSettingPrefab);
                t.name = "game_setting";
                t.parent = e;
                let a = t.getComponent("GameSetting");
                a.startShowAnim();
                a.updateInfo(1);
                a.setLandscapeShow();
            }
        }
        catch (e) {
            TLog.printError("show room setting err:", e);
        }
    }
    dealHelpLogic() {
        let e = { isLandscape: true };
        e.target_sp = this.helpImg;
        e.game_type = CommonGameType.Crash;
        Utils.shared().showSingleGameRuleHelpView(e);
    }
    dealCloseLogic() {
        let e = { bLandscape: ToolUtils.getIsNormalDirection(), bWithCancel: false, strContent: "Are you sure you want to leave the table?", bWithNativeAd: true };
        Utils.shared().showCommonAlert(e, (e => {
            1 == e && PushCenter.shared().pushEvent(PushEvent.ExitGameToHall);
        }), false);
    }
    resetGameData() {
        this._gameData.game_state = 0;
        this._gameData.game_cd = 0;
        RocketGameManager.shared().init();
        this._gameData.cur_bet = [0, 0];
        this._gameData.bet = [0, 0];
        this._gameData.auto_play = [0, 0];
        this._gameData.auto_turns = [0, 0];
        this._gameData.auto_checkbl = [0, 0];
        this._gameData.isGameStartEd = false;
        this._gameData.select_betview_index = -1;
    }
    regEvent() {
        Server.shared().regDispatch(NetConfig.HEARTBEAT_CMD, this.handler_server_HEARTBEAT_DELAY_return.bind(this), this);
        Server.shared().regDispatch(NetConfig.SERVER_LOGIN_GATE_RESP, this.handler_server_login_gate_return.bind(this), this);
        Server.shared().regDispatch(NetConfig.SM_LOGIN_RETURN, this.handler_server_login_return.bind(this), this);
        Server.shared().regDispatch(NetConfig.SYSTEM_GATEWAY_CMD, this.handler_server_system_gateway_return.bind(this), this);
        Server.shared().regDispatch(RocketGameCmd.SM_TABLEINFO_RETURN, this.handler_table_info.bind(this), this);
        Server.shared().regDispatch(RocketGameCmd.SM_BET_CHANGE_RETURN, this.handler_server_bet_change_return.bind(this), this);
        Server.shared().regDispatch(RocketGameCmd.SM_BET_RETURN, this.handler_server_xiazhu.bind(this), this);
        Server.shared().regDispatch(RocketGameCmd.SM_CANCEL_BET_RETURN, this.handler_server_cancel_xiazhu.bind(this), this);
        Server.shared().regDispatch(RocketGameCmd.SM_AUTO_BET_REQUEST, this.handler_server_autobet_switch_return.bind(this), this);
        Server.shared().regDispatch(RocketGameCmd.SM_PLAYERS_INFO_RETURN, this.handler_server_players_info_return.bind(this), this);
        Server.shared().regDispatch(RocketGameCmd.SM_HISTORY_RECORD_RETURN, this.handler_server_history_recode_return.bind(this), this);
        Server.shared().regDispatch(RocketGameCmd.SM_NOTIFY_ROLL_RESULT, this.handler_server_game_end.bind(this), this);
        Server.shared().regDispatch(RocketGameCmd.RSP_CASH_OUT, this.handler_server_cashout_return.bind(this), this);
        Server.shared().regDispatch(RocketGameCmd.NOTIFY_SOMEONE_CASH_OUT, this.handler_server_notify_someone_cash_out.bind(this), this);
        Server.shared().regDispatch(RocketGameCmd.SM_NOTIFY_FLY, this.handler_server_notify_fly.bind(this), this);
        Server.shared().regDispatch(RocketGameCmd.SM_NOTIFY_BET, this.handler_server_notify_bet.bind(this), this);
        Server.shared().regDispatch(RocketGameCmd.RSP_CURR_FLY_STATE, this.handler_server_curr_fly_state_return.bind(this), this);
        Server.shared().regDispatch(RocketGameCmd.SM_ONLINE_PLAYERS_COUNT, this.handler_server_online_players_count.bind(this), this);
        Server.shared().regDispatch(RocketGameCmd.SM_UPDATE_BET_TIME, this.handler_server_update_time_bet.bind(this), this);
        Server.shared().regDispatch(NetConfig.SM_CREATE_TABLE_RETURN, this.handler_server_create_tabel_return.bind(this), this);
        Server.shared().regDispatch(NetConfig.SERVER_ALERT_RETURN, this.handler_server_alert_return.bind(this), this);
        Server.shared().regDispatch(RocketGameCmd.NOTIFY_JP_POOL_AMOUNT, this.handler_server_jackpot_pool_amount_return.bind(this), this);
        Server.shared().regDispatch(RocketGameCmd.NOTIFY_SOMEONE_BET, this.handler_server_other_xiazhu.bind(this), this);
    }
    handler_server_jackpot_pool_amount_return(e) {
        this.tid_key == e.tid_key && sys.isObjectValid(e.jackpot_pool) && (this.roomTable.updateJackPotPool(this._gameData.jackPotNum, e.jackpot_pool), this._gameData.jackPotNum = e.jackpot_pool);
    }
    handler_server_alert_return(e) {
        if (this.tid_key != e.tid_key) {
            return;
        }
        let t = 0;
        sys.isObjectValid(e.type) && (t = Number(e.type));
        let a = e.alertStr;
        if (2 == t) {
            this.updateBankruptcyParam(e);
            let t = this._gameData.cur_bet[0];
            this._gameData.cur_bet[1] < t && (t = this._gameData.cur_bet[1]);
            let a = { vid: RocketGameManager.shared()._vid, min_entry: t, tid_key: this.tid_key, is_pop: 0, parent_node: RocketGameManager.shared().popNode };
            sys.isObjectValid(e.diff_coin) && e.diff_coin > 0 && (a.min_entry = e.diff_coin);
            Utils.shared().showQuickRecharge(ToolUtils.curVId, RocketGameManager.shared().popNode, true, User.shared().curTid_key, 0, a.min_entry);
            User.shared().updatePayScene(PhpReportDefined.pay_scene.game_selectroom_less_money, ToolUtils.curVId);
        }
        else {
            11 != t && 0 != t || sys.isObjectValid(a) && String(a).length > 0 && Utils.shared().showToast(a, 2);
        }
    }
    handler_server_create_tabel_return(e) {
        sys.isObjectValid(e) && sys.isObjectValid(e.game_type) && e.game_type == CommonGameType.Crash && 0 == parseInt("" + e.ret) && (sys.isObjectValid(e.session_id) && (User.shared().session_id = e.session_id), sys.isObjectValid(e.old_tid_key) && e.old_tid_key.length > 0 && this.tid_key == e.old_tid_key && sys.isObjectValid(e.tid_key) && e.tid_key.length > 0 && (this.tid_key = e.tid_key, User.shared().curTid_key = e.tid_key, RocketGameManager.shared()._tidKey = e.tid_key, RocketGameManager.shared().sendGameInfoRequest()));
    }
    handler_server_online_players_count(e) {
        this.tid_key == e.tid_key && sys.isObjectValid(e.count) && this.roomAction.updatePlayerNum(e.count);
    }
    handler_server_curr_fly_state_return(e) {
        this.tid_key == e.tid_key && 1 != e.state && (2 == e.state ? this.roomTable.rocketPlayFly(e.times, this._gameData.flyAnimIndex || 1, this.updateGoldOutNumCall.bind(this)) : (this.roomTable.updateGameEndGuiji(e.times), this.showGameEnd(e.win_rate, false)), this.roomTable.setFlyTime(e.times), this.roomTable.updateFlyBeilv(e.win_rate), sys.isObjectValid(e.bt_state) && Array.isArray(e.bt_state) && (this.roomAction.updateButtonState(e.bt_state[0], 0, e.ext), this.roomAction.updateButtonState(e.bt_state[1], 1, e.ext)));
    }
    handler_server_notify_bet(e) {
        this.tid_key == e.tid_key && (SoundManager.shared().playFx("start_xiazhu"), this._gameData.game_state = e.state, this._gameData.game_cd = e.cd, sys.isObjectValid(e.bt_state) && Array.isArray(e.bt_state) && (this.roomAction.updateButtonState(e.bt_state[0], 0, e.ext), this.roomAction.updateButtonState(e.bt_state[1], 1, e.ext)), this.showXiazhuView(e.cd, e.cd), this.roomTable.resetInfo(), this.roomTable.changeXiaZhuRootState(true));
    }
    handler_server_update_time_bet(e) {
        this.tid_key == e.tid_key && this.roomTable.updateTimeAndBet(e);
    }
    handler_server_notify_fly(e) {
        this.tid_key == e.tid_key && (SoundManager.shared().playTargetMusic(this.musicAudioSources[0]), sys.isObjectValid(e.bt_state) && Array.isArray(e.bt_state) && (this.roomAction.updateButtonState(e.bt_state[0], 0, e.ext), this.roomAction.updateButtonState(e.bt_state[1], 1, e.ext)), this.showFlyView(), this.roomTable.changeXiaZhuRootState(false), this.roomTable.rocketPlayFly(0, 1, this.updateGoldOutNumCall.bind(this)));
    }
    updateGoldOutNumCall(e) {
        for (let t = 0; t < 2; t++) {
            let a = this._gameData.bet[t];
            a > 0 && this.roomAction.updateGoldoutNum(Number(e) * a, t);
        }
    }
    showFlyView() {
        this.roomTable.changeWaiteLayoutVisible(false);
        this.roomTable.changeFlyLayoutVisible(true);
        this.roomAction.changeWinNodeVisible(false);
    }
    handler_server_notify_someone_cash_out(e) {
        this.tid_key == e.tid_key && this.roomTable.showCashoutPlayer(e);
    }
    handler_server_cashout_return(e) {
        if (this.tid_key != e.tid_key) {
            return;
        }
        let t = e.index;
        if (this.roomAction.changeWinNodeVisible(true, e.win_rate, e.win_score), sys.isObjectValid(e.bt_state) && this.roomAction.updateButtonState(e.bt_state, t, e.ext), sys.isObjectValid(e.money)) {
            let t = e.money;
            User.shared().updateMoney(t);
            this.roomAction.updateCoin(t);
        }
        sys.isObjectValid(e.color) && this.roomAction.addCheckOutTrend(t, e.win_rate, e.color);
        this._gameData.bet[t] = 0;
    }
    handler_server_game_end(e) {
        if (this.tid_key != e.tid_key) {
            return;
        }
        if (this._gameData.isGameEnded = false, this._gameData.isInGameing = false, this._gameData.endVal = e, this._gameData.game_state = e.state, this._gameData.game_cd = e.cd, sys.isObjectValid(e.money)) {
            let t = e.money;
            User.shared().updateMoney(t);
            this.roomAction.updateCoin(t);
        }
        let t = {};
        if (t.win_rate = Number(e.win_rate).toFixed(2) + "X", t.color = e.color, RocketGameManager.shared().history_recordVec.push(t), RocketGameManager.shared().history_recordVec.length > 0 && (this.roomTable.refreshHistoryRecode(), this.roomTable.showWinLight()), this.showGameEnd(e.win_rate, true), sys.isObjectValid(e.bt_state) && Array.isArray(e.bt_state) && 2 == e.bt_state.length) {
            for (let t = 0; t < 2; t++) {
                this.roomAction.updateButtonState(e.bt_state[t], t, e.ext);
            }
        }
        for (let e = 0; e < 2; e++) {
            this.checkReduceBtnStatus(this._gameData.cur_bet[e]).flag ? this.roomAction.updateReduceBetBtnStatus(true, e) : this.roomAction.updateReduceBetBtnStatus(false, e);
            this.checkAddBtnStatus(this._gameData.cur_bet[e]).flag ? this.roomAction.updateAddBetBtnStatus(true, e) : this.roomAction.updateAddBetBtnStatus(false, e);
        }
        sys.isObjectValid(e.jackpot_pool) && (this.roomTable.updateJackPotPool(this._gameData.jackPotNum, e.jackpot_pool), this._gameData.jackPotNum = e.jackpot_pool);
    }
    handler_server_history_recode_return(e) {
        if (this.tid_key == e.tid_key) {
            if (RocketGameManager.shared().history_recordVec = [], sys.isObjectValid(e.history_record) && Array.isArray(e.history_record) && e.history_record.length > 0) {
                for (let t = 0; t < e.history_record.length; t++) {
                    RocketGameManager.shared().history_recordVec.push(e.history_record[t]);
                }
            }
            this.roomTable.refreshHistoryRecode();
            this.roomTrend.isShow() && this.roomTrend.refreshTabContent();
        }
    }
    handler_server_players_info_return(e) {
        this.tid_key == e.tid_key && (ToolUtils.isObjValid(this.noSeatPlayerView) ? this.noSeatPlayerView.getComponent(RocketGameNoSeatList).refreshUI(e) : ToolUtils.loadCommonPrefab(this.gameNoseatPrefab, BundleNameDefined.Bundle_GameCrash, "prefab/rocket_game_noseat_players", (t => {
            this.gameNoseatPrefab = t;
            this.showNoSeatPlayerList(e);
        })));
    }
    showNoSeatPlayerList(e) {
        try {
            let t = director.getScene().getChildByName("Canvas");
            if (!ToolUtils.isObjValid(t.getChildByName("rocket_game_noseat_players"))) {
                this.noSeatPlayerView = instantiate(this.gameNoseatPrefab);
                this.noSeatPlayerView.name = "rocket_game_noseat_players";
                this.noSeatPlayerView.parent = t;
                let a = this.noSeatPlayerView.getComponent("RocketGameNoSeatList");
                a.initParaData({ cb: e => {
                        -1 == e ? this.noSeatPlayerView = null : this.send_players_info_request(e + 1);
                    } });
                a.refreshUI(e);
            }
        }
        catch (e) {
            TLog.printError("show room setting err:", e);
        }
    }
    handler_server_autobet_switch_return(e) {
        if (this.tid_key != e.tid_key) {
            return;
        }
        if (0 == e.ret) {
            let t = e.index;
            sys.isObjectValid(e.bt_state) && this.roomAction.updateButtonState(e.bt_state, t, e.ext);
            let a = e.enable;
            this._gameData.auto_play[t] = a;
            1 == a && sys.isObjectValid(e.ext) && sys.isObjectValid(e.ext.round) && (this._gameData.auto_turns[t] = e.ext.round, this._gameData.auto_checkbl[t] = e.ext.auto_out, this.roomAction.updateAutoPlaySwitchStatus(t, 1, e.ext.auto_out));
            a || this.roomAction.updateAutoPlaySwitchStatus(t, 0);
        }
        else {
            if (1 == e.pop_addgold) {
                let t = { vid: ToolUtils.curVId };
                sys.isObjectValid(e.cur_bet) && e.cur_bet > 0 && (t.min_entry = e.cur_bet);
                Utils.shared().showQuickRecharge(ToolUtils.curVId, RocketGameManager.shared().popNode, true, User.shared().curTid_key, 0, t.min_entry);
                User.shared().updatePayScene(PhpReportDefined.pay_scene.game_selectroom_less_money, ToolUtils.curVId);
            }
            else {
                let t = e.err_msg;
                sys.isObjectValid(t) && t.length > 0 && Utils.shared().showToast(e.err_msg, 2);
            }
        }
    }
    handler_server_cancel_xiazhu(e) {
        if (this.tid_key != e.tid_key) {
            return;
        }
        if (0 == e.ret) {
            if (sys.isObjectValid(e.money)) {
                let t = e.money;
                User.shared().updateMoney(t);
                this.roomAction.updateCoin(t);
            }
            let t = e.index;
            sys.isObjectValid(e.bet) && (this._gameData.bet[t] = e.bet);
            sys.isObjectValid(e.bt_state) && this.roomAction.updateButtonState(e.bt_state, t, e.ext);
            sys.isObjectValid(e.tip) && e.tip.length > 0 && Utils.shared().showToast(e.tip, 2);
        }
        else {
            let t = e.err_msg;
            sys.isObjectValid(t) && t.length > 0 && Utils.shared().showToast(e.err_msg, 2);
            sys.isObjectValid(e.bt_state) && this.roomAction.updateButtonState(e.bt_state, e.index, e.ext);
        }
    }
    handler_server_other_xiazhu(e) {
        this.tid_key == e.tid_key && sys.isObjectValid(e.name) && e.name.length > 0 && sys.isObjectValid(e.bet) && e.bet > 0 && this.roomTable.addXiaZhuInfo(e.name, e.bet);
    }
    handler_server_xiazhu(e) {
        if (this.tid_key != e.tid_key) {
            return;
        }
        if (0 == e.ret) {
            if (sys.isObjectValid(e.money)) {
                let t = e.money;
                User.shared().updateMoney(t);
                this.roomAction.updateCoin(t);
            }
            let t = e.index, a = e.bet, i = "Bet " + String(a);
            Utils.shared().showToast(i, 2);
            this._gameData.bet[t] = a;
            this._gameData.cur_bet[t] = a;
            this.roomAction.updateCurBetNum(a, t);
            sys.isObjectValid(e.bt_state) && this.roomAction.updateButtonState(e.bt_state, t, e.ext);
        }
        else {
            if (1 == e.pop_addgold) {
                let t = { vid: ToolUtils.curVId };
                sys.isObjectValid(e.cur_bet) && e.cur_bet > 0 && (t.min_entry = e.cur_bet);
                Utils.shared().showQuickRecharge(ToolUtils.curVId, RocketGameManager.shared().popNode, true, User.shared().curTid_key, 0, t.min_entry);
            }
            else {
                let t = e.err_msg;
                sys.isObjectValid(t) && t.length > 0 && Utils.shared().showToast(e.err_msg, 2);
                sys.isObjectValid(e.bt_state) && this.roomAction.updateButtonState(e.bt_state, e.index, e.ext);
            }
        }
    }
    handler_server_bet_change_return(e) {
        if (this.tid_key == e.tid_key && sys.isObjectValid(e.cur_bet) && sys.isObjectValid(e.index)) {
            this._gameData.cur_bet[e.index] = e.cur_bet;
            this.roomAction.updateCurBetNum(e.cur_bet, e.index);
            this.checkReduceBtnStatus(e.cur_bet).flag ? this.roomAction.updateReduceBetBtnStatus(true, e.index) : this.roomAction.updateReduceBetBtnStatus(false, e.index);
            this.checkAddBtnStatus(e.cur_bet).flag ? this.roomAction.updateAddBetBtnStatus(true, e.index) : this.roomAction.updateAddBetBtnStatus(false, e.index);
        }
    }
    handler_server_system_gateway_return(e) {
        if (null != e.tid_key && null != e.tid_key && "" != e.tid_key) {
            if (this.tid_key === (e.tid_key || "") && -1 === e.res) {
                let e = i18nMgr.shared().getValueByKey("utlis.service_upgrade");
                Utils.shared().showToast(e, 2, 0, ToolUtils.getIsNormalDirection());
                this.backToHall();
            }
        }
        else {
            User.shared().curTid_key === this.tid_key && -1 === e.res && ToolUtils.isSafeString(e.msg).length > 0 && Utils.shared().showToast(e.msg, 2, 0, ToolUtils.getIsNormalDirection());
        }
    }
    handler_server_login_return(e) {
        try {
            sys.isObjectValid(e.session_id) && (User.shared().session_id = e.session_id);
            let t = ToolUtils.isSafeString(e.old_tid_key);
            if (this.tid_key != t) {
                return;
            }
            if (1 == parseInt("" + e.ret) && ToolUtils.isSafeString(e.alertStr).length > 0) {
                return this.backToHall(), Utils.shared().showToast(e.alertStr, 2, 0, ToolUtils.getIsNormalDirection()), void (ToolUtils.deskInfos.size <= 1 && Server.shared().disconnectWebSocket());
            }
            if (0 == parseInt("" + e.ret)) {
                if (sys.isObjectValid(e.session_id) && (User.shared().session_id = e.session_id), 1 == e.isNewTable) {
                    return void RocketGameManager.shared().create_new_table();
                }
                0 == e.isNewTable && sys.isObjectValid(e.table_keys) && Array.isArray(e.table_keys) && e.table_keys.length > 0 ? (User.shared().curTid_key = e.table_keys[0].tid_key, this.tid_key = e.table_keys[0].tid_key, RocketGameManager.shared()._tidKey = this.tid_key, RocketGameManager.shared().sendGameInfoRequest()) : this.backToHall();
            }
            else {
                e.alertStr && "" != e.alertStr && Utils.shared().showCommomDialog(e.alertStr, "", (() => {
                }), false, ToolUtils.getIsNormalDirection(), null, null, null, null, null, this.tid_key);
            }
        }
        catch (e) {
        }
    }
    handler_table_info(e) {
        if (this.tid_key != e.tid_key) {
            return;
        }
        ToolUtils.isObjValid(this._gameData.game_endAction) && TweenTool.stopAction(this._gameData.game_endAction);
        RocketGameManager.shared().checkLoadingRefresh = false;
        TweenTool.stopNodeAction(RocketGameManager.shared().sceneNode);
        let t = e.state;
        if (this._gameData.game_state = t, this._gameData.game_cd = e.cd, sys.isObjectValid(e.money)) {
            let t = e.money;
            User.shared().updateMoney(t);
            this.roomAction.updateCoin(t);
        }
        sys.isObjectValid(e.cur_bet) && Array.isArray(e.cur_bet) && (this._gameData.cur_bet = e.cur_bet);
        RocketGameManager.shared().bet_configVec = [];
        sys.isObjectValid(e.bet_config) && Array.isArray(e.bet_config) && (RocketGameManager.shared().bet_configVec = e.bet_config, this.roomAction.updateSelectBetView());
        sys.isObjectValid(e.autoplay) && (RocketGameManager.shared().auto_play_cnt = e.autoplay);
        for (let e = 0; e < 2; e++) {
            this.roomAction.updateCurBetNum(this._gameData.cur_bet[e], e);
            this.checkReduceBtnStatus(this._gameData.cur_bet[e]).flag ? this.roomAction.updateReduceBetBtnStatus(true, e) : this.roomAction.updateReduceBetBtnStatus(false, e);
            this.checkAddBtnStatus(this._gameData.cur_bet[e]).flag ? this.roomAction.updateAddBetBtnStatus(true, e) : this.roomAction.updateAddBetBtnStatus(false, e);
        }
        RocketGameManager.shared().history_recordVec = [];
        sys.isObjectValid(e.history_record) && Array.isArray(e.history_record) && (RocketGameManager.shared().history_recordVec = e.history_record, this.roomTable.refreshHistoryRecode());
        RocketGameManager.shared().bet_rate_configVec_add = [];
        sys.isObjectValid(e.bet_rate_config_add) && Array.isArray(e.bet_rate_config_add) && (RocketGameManager.shared().bet_rate_configVec_add = e.bet_rate_config_add);
        RocketGameManager.shared().bet_rate_configVec_reduce = [];
        sys.isObjectValid(e.bet_rate_config_reduce) && Array.isArray(e.bet_rate_config_reduce) && (RocketGameManager.shared().bet_rate_configVec_reduce = e.bet_rate_config_reduce);
        this._gameData.bet = [0, 0];
        sys.isObjectValid(e.selfbet) && Array.isArray(e.selfbet) && 2 == e.selfbet.length && (this._gameData.bet = e.selfbet);
        let a = 0;
        sys.isObjectValid(e.cd) && (a = e.cd);
        let i = 0;
        if (sys.isObjectValid(e.total_cd) && (i = e.total_cd), sys.isObjectValid(e.max_fly_time) && e.max_fly_time, sys.isObjectValid(e.max_win_rate) && e.max_win_rate, 1 == t) {
            this.showXiazhuView(a, i);
            this.roomTable.changeXiaZhuRootState(true);
        }
        else {
            this.roomTable.changeXiaZhuRootState(false);
            SoundManager.shared().playTargetMusic(this.musicAudioSources[0]);
            let a = 0;
            if (sys.isObjectValid(e.is_golded_out) && Array.isArray(e.is_golded_out)) {
                for (let t = 0; t < e.is_golded_out.length; t++) {
                    1 == e.is_golded_out[t] && a++;
                }
            }
            let i = e.rocket_in_jp + 1;
            a > 0 && sys.isObjectValid(e.last_bet_index) && e.last_bet_index < 2 && sys.isObjectValid(e.golded_out_rate) && Array.isArray(e.golded_out_rate) && 2 == e.golded_out_rate.length && sys.isObjectValid(e.win_score) && Array.isArray(e.win_score) && 2 == e.win_score.length && this.roomAction.changeWinNodeVisible(true, e.golded_out_rate[e.last_bet_index], e.win_score[e.last_bet_index]);
            this.roomTable.changeWaiteLayoutVisible(false);
            this.roomTable.changeFlyLayoutVisible(true);
            this.roomTable.updateFlyBeilv(e.win_rate);
            this._gameData.flyAnimIndex = i;
            2 == t ? this.roomTable.rocketPlayFly(e.fly_time, i, this.updateGoldOutNumCall.bind(this)) : (this.roomTable.updateGameEndGuiji(e.fly_time), this.showGameEnd(e.win_rate, false));
        }
        if (sys.isObjectValid(e.bt_state) && Array.isArray(e.bt_state)) {
            for (let t = 0; t < e.bt_state.length; t++) {
                this.roomAction.updateButtonState(e.bt_state[t], t, e.ext);
            }
        }
        for (let e = 0; e < 2; e++) {
            this._gameData.auto_play[e] = 0;
        }
        if (sys.isObjectValid(e.autoplay_st) && Array.isArray(e.autoplay_st)) {
            for (let t = 0; t < e.autoplay_st.length; t++) {
                this._gameData.auto_play[t] = e.autoplay_st[t];
            }
            if (sys.isObjectValid(e.autoplay_cfg) && Array.isArray(e.autoplay_cfg)) {
                for (let t = 0; t < e.autoplay_cfg.length; t++) {
                    1 == this._gameData.auto_play[t] && (sys.isObjectValid(e.autoplay_cfg[t].round) && (this._gameData.auto_turns[t] = e.autoplay_cfg[t].round), sys.isObjectValid(e.autoplay_cfg[t].auto_out) && (this._gameData.auto_checkbl[t] = e.autoplay_cfg[t].auto_out));
                }
            }
        }
        for (let e = 0; e < 2; e++) {
            this.roomAction.updateAutoPlaySwitchStatus(e, this._gameData.auto_play[e], this._gameData.auto_checkbl[e]);
        }
        if (this.roomAction.clearCheckOutTrend(0), this.roomAction.clearCheckOutTrend(1), sys.isObjectValid(e.self_history_record) && Array.isArray(e.self_history_record) && 2 == e.self_history_record.length) {
            for (let t = 0; t < 2; t++) {
                let a = e.self_history_record[t].length, i = 0;
                a > 4 && (i = a - 4);
                for (let s = i; s < a; s++) {
                    let a = e.self_history_record[t][s];
                    sys.isObjectValid(a.color) && sys.isObjectValid(a.win_rate) && this.roomAction.addCheckOutTrend(t, a.win_rate, a.color);
                }
            }
        }
        this.send_request_cur_fly_state();
        ToolUtils.isObjValid(e.disable_liveup) && 1 == e.disable_liveup && (Utils.shared().checkHasPopView(RocketGameManager.shared().popNode) || this.reportSever());
    }
    showGameEnd(e, t) {
        this.roomTable.playRocketBzAnim(t);
        this.roomTable.updateFlyBeilv(e, true);
    }
    showXiazhuView(e, t, a) {
        SoundManager.shared().playTargetMusic(this.musicAudioSources[1]);
        this.roomTable.changeWaiteLayoutVisible(true, e, t);
        this.roomTable.changeFlyLayoutVisible(false);
        this.roomAction.changeWinNodeVisible(false);
    }
    handler_server_login_gate_return(e) {
        RocketGameManager.shared().handler_server_login_gate_return(e);
    }
    handler_server_HEARTBEAT_DELAY_return(e) {
        this.isNetworkDelay = true;
        let t = ToolUtils.getOsTime() - ToolUtils.lastSendHeartBeatTime;
        ToolUtils.gamePing = t;
        t > 999 && (t = 999);
        1 == User.shared().games_delay_open && (User.shared().hasMaintain || 0 == window.InGameScene || this.updateNetSignal(t));
    }
    updateNetSignal(e) {
    }
    initPushCenter() {
        PushCenter.shared().addListener(GameConfig.onEnterForeground, (e => {
            if (ToolUtils.isGameBackground = false, ToolUtils.isObjValid(this.node)) {
                let e = this, t = sys.now();
                this.scheduleOnce((() => {
                    e.isNetworkDelay = true;
                }), 1);
                Utils.shared().checkScreenLandscape();
                t / 1000 - this.backgroundSatyTime / 1000 > 30 || ToolUtils.backgroundWebSocketReconnection ? (ToolUtils.backgroundWebSocketReconnection = false, this.scheduleOnce((() => {
                    Server.shared().disconnectWebSocket();
                })), this.scheduleOnce((() => {
                    RocketGameManager.shared().loginGameServer();
                }), 0.2)) : this.scheduleOnce((() => {
                    RocketGameManager.shared().sendGameInfoRequest();
                }), 0.2);
            }
        }), this);
        PushCenter.shared().addListener(GameConfig.onEnterBackground, (e => {
            ToolUtils.isGameBackground = true;
            this.backgroundSatyTime = sys.now();
            this.send_request_enterBackGround();
        }), this);
        PushCenter.shared().addListener(PushEvent.ExitGameToHall, (e => {
            ToolUtils.isObjValid(this.node) && this.backToHall();
        }), this);
        PushCenter.shared().addListener(PushEvent.Low_Memory_Notice, (e => {
            ToolUtils.isObjValid(this.node) && this.releaseRes();
        }), this);
        PushCenter.shared().addListener(GameConfig.NetWorkErrorReconnection, (e => {
            this.scheduleOnce((() => {
                this.scheduleOnce((() => {
                    Server.shared().disconnectWebSocket();
                }));
                this.scheduleOnce((() => {
                    RocketGameManager.shared().loginGameServer();
                }), 0.2);
            }));
        }), this);
        PushCenter.shared().addListener(PushEvent.RefreshRoomDesk, (() => {
            ToolUtils.isObjValid(this.node) && RocketGameManager.shared().sendGameInfoRequest();
        }), this);
        PushCenter.shared().addListener(GameConfig.NetWorkDelayShow, (e => {
            this.isNetworkDelay = true;
            this.networkDelay = 0;
        }), this);
        PushCenter.shared().addListener(GameConfig.Update_Money, (e => {
            ToolUtils.isObjValid(this.node) && this.roomAction.updateCoin(User.shared().data.money);
        }), this);
        PushCenter.shared().addListener(GameConfig.RummyCompleteExit, (e => {
            this.backToHall();
        }), this);
        PushCenter.shared().addListener(PushEvent.ShowTwentyFourRecharge, (e => {
            sys.isObjectValid(e) && null != e.tid_key && e.tid_key === this.tid_key && ToolUtils.isObjValid(this.node) && (undefined !== e.parent_node && null !== e.parent_node || (e.parent_node = RocketGameManager.shared().popNode), e.vid = RocketGameManager.shared()._vid, e.in_room = 1, Utils.shared().showTwentyHourRecharge(e));
        }), this);
        PushCenter.shared().addListener(PushEvent.ShowBuyOneGetThree, (e => {
            sys.isObjectValid(e) && null != e.tid_key && e.tid_key === this.tid_key && ToolUtils.isObjValid(this.node) && (undefined !== e.parent_node && null !== e.parent_node || (e.parent_node = RocketGameManager.shared().popNode), e.vid = RocketGameManager.shared()._vid, e.in_room = 1, Utils.shared().showBuyOneGetThree(e));
        }), this);
        PushCenter.shared().addListener(PushEvent.ShowFirstRecharge, (e => {
            sys.isObjectValid(e) && null != e.tid_key && e.tid_key === this.tid_key && ToolUtils.isObjValid(this.node) && (undefined !== e.parent_node && null !== e.parent_node || (e.parent_node = RocketGameManager.shared().popNode), e.vid = RocketGameManager.shared()._vid, e.in_room = 1, Utils.shared().showFirstRecharge_game2(e));
        }), this);
        PushCenter.shared().addListener(PushEvent.ShowCouponAct, (e => {
            ToolUtils.isObjValid(this.node) && Utils.shared().showCouponActView(null, e);
        }), this);
        PushCenter.shared().addListener(PushEvent.ShowRestartGift, (e => {
            sys.isObjectValid(e) && null != e.tid_key && e.tid_key === this.tid_key && (undefined !== e.parent_node && null !== e.parent_node || (e.parent_node = RocketGameManager.shared().popNode), e.vid = RocketGameManager.shared()._vid, e.in_room = 1, Utils.shared().showRestartGift(e));
        }), this);
        PushCenter.shared().addListener(PushEvent.ShowConsecutiveGift, (e => {
            sys.isObjectValid(e) && null != e.tid_key && e.tid_key === this.tid_key && ToolUtils.isObjValid(this.node) && (undefined !== e.parent_node && null !== e.parent_node || (e.parent_node = RocketGameManager.shared().popNode), e.vid = RocketGameManager.shared()._vid, e.in_room = 1, Utils.shared().showConsecutiveGift(e));
        }), this);
        PushCenter.shared().addListener(PushEvent.Update_Gullak_RewardInGame, (e => {
            ToolUtils.isObjValid(this.node) && this.roomAction.updateGullakBtnStatus(User.shared().act_68_open, User.shared().act_68_full_status, true);
        }), this);
    }
    reportSever() {
        let e = { cmd: NetConfig.CLIENT_NOTIFY_GOBACK_GAME, uid: User.shared().data.uid, type: 2, tid_key: User.shared().curTid_key };
        Server.shared().send(e);
    }
    updateBankruptcyParam(e) {
        if (sys.isObjectValid(e.act_124_show) && (RocketGameManager.shared().data.act_124_show = e.act_124_show), sys.isObjectValid(e.act_98_show)) {
            if (RocketGameManager.shared().data.act_98_show = e.act_98_show, 1 == e.act_98_show) {
                let t = this._gameData.cur_bet[0];
                this._gameData.cur_bet[1] < t && (t = this._gameData.cur_bet[1]);
                RocketGameManager.shared().data.act_98_param = { vid: RocketGameManager.shared()._vid, isShowTip: true, bShowNetTip: true, tid_key: this.tid_key, min_entry: t, ext: { times: e.times, reward_value: e.reward_value, ad_multiple: e.ad_multiple, reward_list: [{ type: 7, amt: e.reward_value }] } };
            }
            else {
                RocketGameManager.shared().data.act_98_param = {};
            }
        }
        sys.isObjectValid(e.act_139_show) && (RocketGameManager.shared().data.act_139_show = e.act_139_show);
        sys.isObjectValid(e.show_ad) ? RocketGameManager.shared().data.show_room_ad = e.show_ad : sys.isObjectValid(e.show_room_ad) && (RocketGameManager.shared().data.show_room_ad = e.show_room_ad);
        sys.isObjectValid(e.room_ad_string) && (RocketGameManager.shared().data.room_ad_string = e.room_ad_string);
        RocketGameManager.shared().data.show_ad = RocketGameManager.shared().data.show_room_ad;
    }
    loadGameSounds() {
        try {
            SoundManager.shared().preLoadBundleSounds(BundleNameDefined.bundle_sound, "crash");
        }
        catch (e) {
        }
    }
    exitCallBack(e) {
        if (1 == e) {
            let e = { cmd: NetConfig.GM_LOGINOUT_REQUEST, tid_key: this.tid_key, vid: ToolUtils.curVId, uid: User.shared().data.uid };
            Server.shared().send(e);
        }
    }
    send_request_enterBackGround() {
        let e = { cmd: RummyCmd.CLIENT_OFFLINE, uid: User.shared().data.uid, version: GameConfig.Server_Api_Ver, tid_key: this.tid_key, skey: User.shared().getSkey() };
        Server.shared().send(e);
    }
    backToHall() {
        this.exitCallBack(1);
        let e = sys.now() - this._enterStartTime;
        e = e > 1000 ? 0 : 1000 - e;
        setTimeout((() => {
            User.shared().hasMaintain ? this.backToLogin() : window.InGameScene && (window.InGameScene = false, User.shared().getHallPopList(false), User.shared().isLoginHall = false, HttpManager.shared().doReportUserAct(PhpReportDefined.Click_Game_QuitGame), TransferPlatform.shared().setHighFrameRate(), window.InSwitchScene = true, window.IsBackToHallLoad = true, Utils.shared().preLoadBundleAsset(0 == TransferPlatform.shared().getDeviceLevel()), Utils.shared().showLoading(20), this.enterSwitchScene(2));
        }), e);
    }
    backToLogin() {
        window.InGameScene && (window.InGameScene = false, window.InHallScene = false, HttpManager.shared().doReportUserAct(PhpReportDefined.Click_Game_QuitGame), Utils.shared().hideRummyNode(), LabaServer.shared().reset(), Server.shared().reset(), User.shared().doSendMatchOnlineStatus(0), TransferPlatform.shared().setHighFrameRate(), this.enterSwitchScene(3));
    }
    enterSwitchScene(e) {
        let t = 100;
        sys.isNative ? sys.os !== sys.OS.IOS && sys.os !== sys.OS.OSX || (t = 50, ToolUtils.isPadPlatform() && (t = 30)) : t = 0;
        let a = e, i = this;
        ToolUtils.loadBundleScene(BundleNameDefined.bundle_switch, BundleNameDefined.switch_scence, ((e, s) => {
            null == e ? (ToolUtils.switchSceneTye = a, i.jumpToSwitchScene(t, s)) : ToolUtils.loadBundleScene(BundleNameDefined.bundle_switch, BundleNameDefined.switch_scence, ((e, s) => {
                null == e ? (ToolUtils.switchSceneTye = a, i.jumpToSwitchScene(t, s)) : (Utils.shared().hideLoading(), Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text27"), 2));
            }));
        }));
    }
    jumpToSwitchScene(e, t) {
        if (User.shared().checkIfHasLoadHallBundle()) {
            sys.os === sys.OS.IOS || sys.os === sys.OS.OSX ? (ToolUtils.isPadPlatform() || setTimeout((() => {
            }), e), Utils.shared().hideLoading(), TransferPlatform.shared().orientationToPortrait((() => {
                director.runScene(t);
            }))) : (Utils.shared().hideLoading(), TransferPlatform.shared().orientationToPortrait((() => {
                setTimeout((() => {
                    director.runScene(t);
                }), e);
            })));
        }
        else {
            let a = false, i = 0;
            this.schedule((s => {
                i += s;
                a || (User.shared().checkIfHasLoadHallBundle() || i >= 2) && (a = true, sys.os === sys.OS.IOS || sys.os === sys.OS.OSX ? (ToolUtils.isPadPlatform() || setTimeout((() => {
                }), e), Utils.shared().hideLoading(), TransferPlatform.shared().orientationToPortrait((() => {
                    director.runScene(t);
                }))) : (Utils.shared().hideLoading(), TransferPlatform.shared().orientationToPortrait((() => {
                    setTimeout((() => {
                        director.runScene(t);
                    }), e);
                }))), this.unscheduleAllCallbacks());
            }));
        }
    }
    onSceneLaunched() {
        PushCenter.shared().pushEvent(PushEvent.BackToHall);
        Utils.shared().hideLoading();
    }
    releaseRes() {
        ToolUtils.isObjValid(this.node) && ToolUtils.isObjValid(RocketGameManager.shared().popNode) && (this.releasePrefabRes(BundleNameDefined.bundle_firstRecharge, "first_buy", "FirstRecharge"), this.releasePrefabRes(BundleNameDefined.bundle_payoneforthree, "payoneforthree", "BuyOneGetThree"), this.releasePrefabRes(BundleNameDefined.bundle_public, "comm_magic_face", "comm_magic_face"), this.releasePrefabRes(BundleNameDefined.bundle_public, "chat_alert", "chat_alert"));
    }
    releasePrefabRes(e, t, a) {
        let i = assetManager.getBundle(e);
        if (!i) {
            return void TLog.printError("---------- releaseRes bundle is null:", e);
        }
        let s = director.getScene().getChildByName("Canvas");
        if (!s.isValid) {
            return;
        }
        let r = s.getChildByName(a);
        ToolUtils.isObjValid(r) || RocketGameManager.shared().popNode.getChildByName(a) || this.node.getChildByName(a) || i.release(ToolUtils.format("prefab/${0}", t));
    }
}
