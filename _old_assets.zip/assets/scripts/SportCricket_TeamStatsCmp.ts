// @ts-nocheck
// Recovered from index.js:597
import { _decorator, Component, Label, Node, ProgressBar, size, Sprite, SpriteFrame, sys } from "cc";
import SoundManager from "./SoundManager";
import PushCenter from "./PushCenter";
import { TLog } from "./TLog";
import Utils from "./Utils";
import PushEvent from "./PushEvent";
import { ToolUtils } from "./ToolUtils";
import SportCricket_Manager from "./SportCricket_Manager";
const { ccclass, property } = _decorator;
@ccclass("SportCricket_TeamStatsCmp")
export class SportCricket_TeamStatsCmp extends Component {
    public TAG: string = "SportCricket_TeamStatsCmp";
    @property(Node)
    public recentRootNode: Node = null;
    @property(Node)
    public venuRootNode: Node = null;
    @property(Node)
    public headRootNode: Node = null;
    @property([SpriteFrame])
    public winLoseSpriteFrame: SpriteFrame[] = [];
    @property([SpriteFrame])
    public pitchSpriteFrame: SpriteFrame[] = [];
    @property([SpriteFrame])
    public weatherSpriteFrame: SpriteFrame[] = [];
    public _closed: boolean = false;
    public _lastClick: number = 0;
    public _isSendMsg: boolean = false;
    public _team_source: any = null;
    public _source: any = null;
    public taskAwardIconMap: Map = new Map;
    public _match_id: number = 0;
    public lastClick: number = 0;
    public _fromType: number = 0;
    public _lastNode: any = null;
    public _match_state: number = 1;
    onLoad() {
        PushCenter.shared().addListener(PushEvent.commentDownloaderImg, (e => {
            try {
                if (ToolUtils.isObjValid(this.node) && this.taskAwardIconMap.size > 0) {
                    for (const [t, i] of this.taskAwardIconMap) {
                        i == e && sys.isObjectValid(t) && Utils.shared().updateNetImage(t, e, size(120, 120));
                    }
                }
            }
            catch (e) {
                TLog.printError(this.TAG, PushEvent.commentDownloaderImg, e);
            }
        }), this);
    }
    onDestroy() {
        PushCenter.shared().removeListenersByTag(this);
        this.unscheduleAllCallbacks();
    }
    init(e) {
        sys.isObjectValid(e) && sys.isObjectValid(e.match_id) && (this._match_id = e.match_id);
        sys.isObjectValid(e) && sys.isObjectValid(e.team_source) && (this._team_source = e.team_source);
        sys.isObjectValid(e) && sys.isObjectValid(e.source) && (this._source = e.source);
        sys.isObjectValid(e) && sys.isObjectValid(e.from_type) && (this._fromType = e.from_type);
        sys.isObjectValid(e) && sys.isObjectValid(e.lastNode) && (this._lastNode = e.lastNode);
    }
    refreshView() {
        if (sys.isObjectValid(this._team_source) && sys.isObjectValid(this._team_source.recent_match)) {
            let e = this._team_source.recent_match;
            if (sys.isObjectValid(e.teama) && sys.isObjectValid(e.teama.logo_url) && e.teama.logo_url.length > 0 && (this.taskAwardIconMap.set(this.recentRootNode.getChildByName("teama_icon"), e.teama.logo_url), Utils.shared().updateNetImage(this.recentRootNode.getChildByName("teama_icon"), e.teama.logo_url, size(120, 120))), sys.isObjectValid(e.teama) && sys.isObjectValid(e.teama.short_name) && e.teama.short_name.length > 0 && (this.recentRootNode.getChildByName("teama_name").getComponent(Label).string = e.teama.short_name), sys.isObjectValid(e.teama) && sys.isObjectValid(e.teama.last_five_match) && Array.isArray(e.teama.last_five_match)) {
                for (let t = 0; t < 5; t++) {
                    let i = this.recentRootNode.getChildByName("teama_flag" + t);
                    ToolUtils.isObjValid(i) && (t < e.teama.last_five_match.length ? sys.isObjectValid(e.teama.last_five_match[t].winning_team_id) && e.teama.last_five_match[t].winning_team_id == e.teama.team_id ? i.getComponent(Sprite).spriteFrame = this.winLoseSpriteFrame[0] : i.getComponent(Sprite).spriteFrame = this.winLoseSpriteFrame[1] : i.getComponent(Sprite).spriteFrame = this.winLoseSpriteFrame[2]);
                }
            }
            if (sys.isObjectValid(e.teamb) && sys.isObjectValid(e.teamb.logo_url) && e.teamb.logo_url.length > 0 && (this.taskAwardIconMap.set(this.recentRootNode.getChildByName("teamb_icon"), e.teamb.logo_url), Utils.shared().updateNetImage(this.recentRootNode.getChildByName("teamb_icon"), e.teamb.logo_url, size(120, 120))), sys.isObjectValid(e.teamb) && sys.isObjectValid(e.teamb.short_name) && e.teamb.short_name.length > 0 && (this.recentRootNode.getChildByName("teamb_name").getComponent(Label).string = e.teamb.short_name), sys.isObjectValid(e.teamb) && sys.isObjectValid(e.teamb.last_five_match) && Array.isArray(e.teamb.last_five_match)) {
                for (let t = 0; t < 5; t++) {
                    let i = this.recentRootNode.getChildByName("teamb_flag" + t);
                    ToolUtils.isObjValid(i) && (t < e.teamb.last_five_match.length ? sys.isObjectValid(e.teamb.last_five_match[t].winning_team_id) && e.teamb.last_five_match[t].winning_team_id == e.teamb.team_id ? i.getComponent(Sprite).spriteFrame = this.winLoseSpriteFrame[0] : i.getComponent(Sprite).spriteFrame = this.winLoseSpriteFrame[1] : i.getComponent(Sprite).spriteFrame = this.winLoseSpriteFrame[2]);
                }
            }
        }
        if (sys.isObjectValid(this._team_source) && sys.isObjectValid(this._team_source.venue_stats)) {
            let e = this._team_source.venue_stats;
            if (sys.isObjectValid(e.name) && e.name.length > 0 && (this.venuRootNode.getChildByName("desc").getComponent(Label).string = e.name), sys.isObjectValid(e.pitch) && e.pitch.length > 0) {
                this.venuRootNode.getChildByName("pitch_desc").getComponent(Label).string = e.pitch;
                let t = SportCricket_Manager.shared().getWeatherPicIndex(e.pitch);
                this.venuRootNode.getChildByName("pitch_style").getComponent(Sprite).spriteFrame = this.pitchSpriteFrame[t];
            }
            if (sys.isObjectValid(e.good_for) && e.good_for.length > 0 && (this.venuRootNode.getChildByName("good_desc").getComponent(Label).string = e.good_for, "Pacers" == e.goodfor_name ? this.venuRootNode.getChildByName("good_style").getComponent(Sprite).spriteFrame = this.pitchSpriteFrame[3] : "Spinners" == e.goodfor_name ? this.venuRootNode.getChildByName("good_style").getComponent(Sprite).spriteFrame = this.pitchSpriteFrame[4] : "Average" == e.goodfor_name && (this.venuRootNode.getChildByName("good_style").getComponent(Sprite).spriteFrame = this.pitchSpriteFrame[5])), sys.isObjectValid(e.weather_type) && e.weather_type.length > 0) {
                this.venuRootNode.getChildByName("wea_desc").getComponent(Label).string = e.weather_type;
                let t = SportCricket_Manager.shared().getWeatherPicIndex(e.weather_type);
                this.venuRootNode.getChildByName("wea_style").getComponent(Sprite).spriteFrame = this.weatherSpriteFrame[Number(t)];
            }
            sys.isObjectValid(e.avg_runs) && e.avg_runs.length > 0 && (this.venuRootNode.getChildByName("avg_desc").getComponent(Label).string = String(e.avg_runs));
            sys.isObjectValid(e.total_wickets) && e.total_wickets.length > 0 && (this.venuRootNode.getChildByName("wick_desc").getComponent(Label).string = String(e.total_wickets));
        }
        if (sys.isObjectValid(this._team_source) && sys.isObjectValid(this._team_source.head_to_head)) {
            let e = this._team_source.head_to_head;
            sys.isObjectValid(e.total_matches_played) && (this.venuRootNode.getChildByName("play_num").getComponent(Label).string = e.total_matches_played + "");
            let t = Number(e.total_matches_played);
            this.venuRootNode.getChildByName("awin_title").getComponent(Label).string = this._team_source.recent.teama.short_name + " Won";
            this.venuRootNode.getChildByName("bwin_title").getComponent(Label).string = this._team_source.recent.teamb.short_name + " Won";
            sys.isObjectValid(e.teama_win) && (this.venuRootNode.getChildByName("awin_desc").getComponent(Label).string = String(e.teama_win), this.venuRootNode.getChildByName("awin_progress").getComponent(ProgressBar).progress = Number(e.teama_win) / t);
            sys.isObjectValid(e.teamb_win) && (this.venuRootNode.getChildByName("bwin_desc").getComponent(Label).string = String(e.teamb_win), this.venuRootNode.getChildByName("bwin_progress").getComponent(ProgressBar).progress = Number(e.teamb_win) / t);
            sys.isObjectValid(e.total_match_drawn) && (this.venuRootNode.getChildByName("tie_desc").getComponent(Label).string = String(e.total_match_drawn), this.venuRootNode.getChildByName("tie_progress").getComponent(ProgressBar).progress = Number(e.total_match_drawn) / t);
            sys.isObjectValid(e.total_match_cancelled) && (this.venuRootNode.getChildByName("no_desc").getComponent(Label).string = String(e.total_match_cancelled), this.venuRootNode.getChildByName("no_progress").getComponent(ProgressBar).progress = Number(e.total_match_cancelled) / t);
        }
    }
    onButtonClick(e, t) {
        if (SoundManager.shared().playFx("click"), !(sys.now() - this._lastClick < 500)) {
            if (this._lastClick = sys.now(), "recent_more" == t) {
                let e = { source: this._source, head_source: this._team_source.head_to_head, fromType: this._fromType, lastNode: this._lastNode, match_id: this._match_id, matchData: this._team_source.recent_match };
                SportCricket_Manager.shared().requestYes11_getTeamRecentMatchInfo(e);
            }
            else if ("venu_more" == t) {
                let e = { source: this._source, venue_source: this._team_source.venue_stats, fromType: this._fromType, lastNode: this._lastNode, match_id: this._match_id };
                SportCricket_Manager.shared().requestYes11_getVenueMatchInfo(e);
            }
            else if ("head_more" == t) {
                let e = { source: this._source, head_source: this._team_source.head_to_head, fromType: this._fromType, lastNode: this._lastNode, match_id: this._match_id };
                SportCricket_Manager.shared().requestYes11_getTeamPkInfo(e);
            }
        }
    }
}
