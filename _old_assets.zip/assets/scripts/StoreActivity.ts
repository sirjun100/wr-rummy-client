// @ts-nocheck
// Recovered from index.js:603
import { _decorator, Button, director, instantiate, Label, LabelShadow, Node, ScrollView, size, sp, Sprite, SpriteFrame, sys, UITransform, v3 } from "cc";
import { TransferPlatform } from "./TransferPlatform";
import TweenTool from "./TweenTool";
import Utils from "./Utils";
import PushCenter from "./PushCenter";
import PushEvent from "./PushEvent";
import ReportConfig from "./ReportConfig";
import User from "./User";
import HttpManager from "./HttpManager";
import SoundManager from "./SoundManager";
import Parent from "./Parent";
import BundleNameDefined from "./BundleNameDefined";
import i18nMgr from "./i18nMgr";
import { ScrollviewUtils } from "./ScrollviewUtils";
import CommDefine from "./CommDefine";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("StoreActivity")
export class StoreActivity extends Parent {
    @property(ScrollView)
    public scrollView: ScrollView = null;
    @property(Node)
    public moban: Node = null;
    @property(SpriteFrame)
    public freegift_bg: SpriteFrame = null;
    @property([SpriteFrame])
    public btn_sprite: SpriteFrame[] = [];
    public _items: any[] = [];
    public scheduleList: any[] = [];
    public activityEndAllTimes: any[] = [];
    public isSendHttp: boolean = false;
    public exe: any = null;
    public _scrollUtil: any = null;
    public isUIReport: boolean = false;
    public inmall_list: any[] = [];
    onLoad() {
        this.fitScreen();
        PushCenter.shared().addListener(PushEvent.commentDownloaderImg, (t => {
            if (ToolUtils.isObjValid(this.node)) {
                for (let e = 0, i = User.shared().actList.length; e < i; e++) {
                    let i = this._items[e];
                    if (sys.isObjectValid(i)) {
                        let s = i.getChildByName("img"), a = User.shared().actList[e].imgurl;
                        a == t && Utils.shared().updateNetImage(s, a, size(660, 220), (t => {
                        }));
                    }
                }
            }
        }), this);
        PushCenter.shared().addListener(PushEvent.UpdateActivity, (t => {
            ToolUtils.isObjValid(this.node) && HttpManager.shared().doGetActivityList(this.listenActivityListCallback.bind(this));
        }), this);
        this._scrollUtil = this.node.addComponent(ScrollviewUtils);
        this._scrollUtil.initScrollviewUtils(this.scrollView);
        this._scrollUtil.setSrollCallBack((t => {
            if (1 == User.shared().s_uirp_3 && sys.isObjectValid(this.inmall_list[t]) && sys.isObjectValid(this.inmall_list[t].jump_info)) {
                let e = [];
                e.push(this.inmall_list[t].jump_info);
                HttpManager.shared().doGetBannerShowRequest(ReportConfig.Cmd_UIOfferActReport, e, ((t, e, i) => {
                }));
            }
        }));
    }
    fitScreen() {
        ToolUtils.adaptSafeArea(this.node);
    }
    setParaData(t) {
        this.exe = t;
    }
    start() {
        this.moban.active = false;
        Array.isArray(User.shared().actList) ? this.refreshActivityList() : Utils.shared().showLoading(10, true, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
        }));
        setTimeout((() => {
            HttpManager.shared().doGetActivityList(this.listenActivityListCallback.bind(this));
        }));
        this.isSendHttp = true;
        PushCenter.shared().addListener(PushEvent.PurchasedFirstRecharge, (t => {
            ToolUtils.isObjValid(this.node) && HttpManager.shared().doGetActivityList(this.listenActivityListCallback.bind(this));
        }), this);
    }
    onDestroy() {
        PushCenter.shared().removeListenersByTag(this);
        this.unscheduleAllCallbacks();
        for (let t = 0, e = this.scheduleList.length; t < e; t++) {
            this.scheduleList[t].stop();
        }
    }
    onEnable() {
        TransferPlatform.shared().setNormalFrameRate();
        this.isSendHttp && (this.isUIReport = false, HttpManager.shared().doGetActivityList(this.listenActivityListCallback.bind(this)));
    }
    listenActivityListCallback(t, e, i) {
        if (Utils.shared().hideLoading(), 200 != i) {
            alert("The login timed out, please try again");
        }
        else {
            let t = ToolUtils.parseJson(e);
            if (0 == t.ret) {
                let e = false;
                if (User.shared().actList.length == t.data.actlist.length) {
                    for (let i = 0, s = t.data.actlist.length; i < s; i++) {
                        if (User.shared().actList[i].id != t.data.actlist[i].id || User.shared().actList[i].inmall != t.data.actlist[i].inmall) {
                            e = true;
                            break;
                        }
                    }
                }
                else {
                    e = true;
                }
                User.shared().actList = t.data.actlist;
                ToolUtils.isObjValid(this.node) && this.refreshActivityList(e);
            }
        }
    }
    refreshActivityList(t = true) {
        if (null == User.shared().actList) {
            return;
        }
        let e = [];
        for (let t = 0, i = User.shared().actList.length; t < i; t++) {
            1 == Number(User.shared().actList[t].inmall) && e.push(User.shared().actList[t]);
        }
        let i = this.scrollView.content;
        t && (Array.isArray(i.children) && i.children.length > 0 && i.removeAllChildren(), this._items = [], this.activityEndAllTimes = []);
        let s = -15, a = this.moban.getComponent(UITransform).contentSize.height, l = 0, n = this.scrollView.getComponent(UITransform).contentSize.height, r = n;
        if (e.length > 0) {
            let t = Math.abs(s) + (e.length + 1) * a + 10 * e.length + 50;
            t >= r && (r = t);
        }
        i.getComponent(UITransform).setContentSize(size(720, r));
        for (let n = 0, r = e.length; n < r; n++) {
            if (t) {
                let t = instantiate(this.moban);
                t.active = true;
                let e = t.getChildByName("ani_loading");
                e.getComponent(sp.Skeleton).clearTracks();
                e.getComponent(sp.Skeleton).setAnimation(0, "hdtd", true);
                t.setPosition(v3(0, s));
                i.addChild(t);
                this._items.push(t);
                s += -(a + 10);
            }
            this.updataActivityView(e[n], l);
            l++;
        }
        let p = { action: "getReward", hasReward: 1 == User.shared().soreTb.free };
        if (t || !sys.isObjectValid(this._items[l])) {
            let t = instantiate(this.moban);
            t.getChildByName("ani_loading").active = false;
            let e = t.getChildByName("img").getComponent(Sprite);
            e.spriteFrame != this.freegift_bg && (e.spriteFrame = this.freegift_bg);
            t.setPosition(v3(0, s));
            i.addChild(t);
            t.active = true;
            this._items.push(t);
        }
        else {
            sys.isObjectValid(this._items[l]) && (this._items[l].active = true);
        }
        this.updataActivityView(p, l);
        this.inmall_list = e;
        let f = e.length + 1;
        if (this._scrollUtil.setScollDetails2(0, n, f, true), 1 == User.shared().s_uirp_3 && e.length > 0 && !this.isUIReport) {
            this.isUIReport = true;
            let t = [];
            for (let i = 0, s = e.length; i < s && (sys.isObjectValid(this._items[i]) && this._items[i].active); i++) {
                sys.isObjectValid(e[i]) && sys.isObjectValid(e[i].jump_info) && t.push(e[i].jump_info);
            }
            HttpManager.shared().doGetBannerShowRequest(ReportConfig.Cmd_UIOfferActReport, t, ((t, e, i) => {
            }));
        }
    }
    updataActivityView(t, e) {
        let i = this._items[e];
        if (sys.isObjectValid(t.imgurl)) {
            let s = i.getChildByName("img"), a = i.getChildByName("ani_loading");
            director.getScene().name == BundleNameDefined.rummy_scence ? Utils.shared().updateNetImage(s, t.imgurl, size(330, 110), (t => {
                a.active = false;
            })) : Utils.shared().updateNetImage(s, t.imgurl, size(680, 204), (t => {
                a.active = false;
            }));
            this.activityEndAllTimes[e] = t.rest_time;
            this.activityEndAllTimes[e] < 600 && (sys.isObjectValid(this.scheduleList[e]) ? (this.scheduleList[e].stop(), this.scheduleList[e] = TweenTool.myschedule(this.node, 1, (() => {
                this.activityEndAllTimes[e] = this.activityEndAllTimes[e] - 1;
                this.activityEndAllTimes[e] <= 0 && (this.scheduleList[e].stop(), sys.isObjectValid(this.node) && HttpManager.shared().doGetActivityList(this.listenActivityListCallback.bind(this)));
            }))) : this.scheduleList[e] = TweenTool.myschedule(this.node, 1, (() => {
                this.activityEndAllTimes[e] = this.activityEndAllTimes[e] - 1;
                this.activityEndAllTimes[e] <= 0 && (this.scheduleList[e].stop(), sys.isObjectValid(this.node) && HttpManager.shared().doGetActivityList(this.listenActivityListCallback.bind(this)));
            })));
            i.getComponent(Button).interactable = true;
            i.getChildByName("collect").active = false;
        }
        else {
            sys.isObjectValid(t.hasReward) && (t.hasReward ? (i.getChildByName("collect").getComponent(Sprite).spriteFrame = this.btn_sprite[0], i18nMgr.shared().changeLabelLanguage(i.getChildByName("collect").getChildByName("wz").getComponent(Label), "kyc.collect", true), i.getComponent(Button).interactable = true, i.getChildByName("collect").getChildByName("wz").getComponent(LabelShadow).color = CommDefine.shadowcolor.green, Utils.updateLabelMaterial(i.getChildByName("collect").getChildByName("wz"), CommDefine.gradient.btn_green)) : (i.getChildByName("collect").getComponent(Sprite).spriteFrame = this.btn_sprite[1], i18nMgr.shared().changeLabelLanguage(i.getChildByName("collect").getChildByName("wz").getComponent(Label), "kyc.collected", true), i.getComponent(Button).interactable = false, 2 == i18nMgr.shared().language && (i.getChildByName("collect").getChildByName("wz").getComponent(Label).fontSize = 22), i.getChildByName("collect").getChildByName("wz").getComponent(LabelShadow).color = CommDefine.shadowcolor.gray, Utils.updateLabelMaterial(i.getChildByName("collect").getChildByName("wz"), CommDefine.gradient.btn_gray)), i.getChildByName("collect").active = true);
        }
        t.index = e;
        i.getComponent(Button).clickEvents[0].customEventData = ToolUtils.toJsonString(t);
    }
    onButtonClick(t, e) {
        SoundManager.shared().playFx("click");
        try {
            let t = ToolUtils.parseJson(e);
            if (t) {
                if (this.activityEndAllTimes[t.index] <= 0) {
                    return void Utils.shared().showToast(t.msg, 2);
                }
                if (sys.isObjectValid(t.jump_info)) {
                    if (t.jump_info.type == PushEvent.JUMP_TO_STORE) {
                        return void PushCenter.shared().pushEvent(PushEvent.showStoreRecharge);
                    }
                    if (sys.isObjectValid(this.exe) && sys.isObjectValid(this.exe.act_id) && this.exe.act_id == t.jump_info.type) {
                        let e = 0;
                        return t.jump_info.type == PushEvent.JUMP_TO_PrayBless ? e = 1 : t.jump_info.type == PushEvent.JUMP_TO_SESSIONPACKGE ? e = 7 : t.jump_info.type == PushEvent.JUMP_TO_LOTTERYACT ? e = 12 : t.jump_info.type == PushEvent.JUMP_TO_BonusForest && (e = 13), Utils.shared().doReportActEvt(this.exe.act_id, 4, e), void PushCenter.shared().pushEvent(PushEvent.showStoreRecharge);
                    }
                    t.jump_info.type == PushEvent.JUMP_TO_GONGGAO && (t.jump_info.exe = t.jump_info.notice);
                    t.jump_info.type == PushEvent.JUMP_TO_HAPPYREWARDS && HttpManager.shared().doGettHappyRewardsReportTo(2, t.id, null);
                    let e = t.jump_info.exe;
                    sys.isObjectValid(e) || (e = {});
                    t.jump_info.type == PushEvent.JUMP_TO_Adventrue && (e.from_source = 1);
                    let i = 1;
                    switch (Number(t.jump_info.type)) {
                        case PushEvent.JUMP_TO_SESSIONPACKGE:
                            i = 7;
                            break;
                        case PushEvent.JUMP_TO_LOTTERYACT:
                            i = 12;
                            break;
                        case PushEvent.JUMP_TO_BonusForest: i = 13;
                    }
                    Utils.shared().doJumpLogic(t.jump_info.type, e, { isNext: false, bWithTip: true, reportScene: 4, reportEvtId: i, link_id: sys.now() });
                }
                else {
                    sys.isObjectValid(t.action) && "getReward" == t.action && HttpManager.shared().doGetCommonRequest(null, "Mall.Shop.getFree", ((t, e, i) => {
                        if (ToolUtils.isObjValid(this.node)) {
                            if (200 != i) {
                                0 == sys.getNetworkType() ? Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text91"), 3, 0, ToolUtils.getIsNormalDirection()) : Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
                            }
                            else {
                                let t = ToolUtils.parseJson(e);
                                if (0 == t.ret) {
                                    if (User.shared().soreTb.free = 0, this._items.length > 0) {
                                        let t = { action: "getReward", hasReward: 1 == User.shared().soreTb.free };
                                        this.updataActivityView(t, this._items.length - 1);
                                    }
                                    let e = t.data.reward;
                                    e && e.length > 0 && User.shared().showChargeReward(e, (t => {
                                        User.shared().requestStoreList();
                                    }));
                                }
                                else {
                                    sys.isObjectValid(t.desc) && t.desc.length > 0 && Utils.shared().showToast(t.desc, 2);
                                }
                            }
                        }
                    }));
                }
            }
        }
        catch (t) {
        }
    }
}
