// @ts-nocheck
// Recovered from index.js:607
import { _decorator, Button, color, instantiate, Label, Layout, Node, Sprite, SpriteFrame, sys, Widget } from "cc";
import Parent from "./Parent";
import User from "./User";
import i18nMgr from "./i18nMgr";
import PushCenter from "./PushCenter";
import GameConfig from "./GameConfig";
import SoundManager from "./SoundManager";
import Utils from "./Utils";
import { HttpRequest } from "./HttpRequestName";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("StoreChip")
export class StoreChip extends Parent {
    public TAG: string = "StoreChip";
    @property(Node)
    public chip_moban: Node = null;
    @property(Node)
    public chiplayout: Node = null;
    @property([SpriteFrame])
    public chipIconArr: SpriteFrame[] = [];
    @property([SpriteFrame])
    public payBtnBgArr: SpriteFrame[] = [];
    public _lastClick: number = 0;
    public _linkId: number = 0;
    public exe: any = null;
    public mallExpData_md5: string = "";
    start() {
        this._linkId = this._linkId > 0 ? this._linkId : sys.now();
        this.addNotify();
        this.getMallExpData() && this.refreshMallExeShopView();
        User.shared().requestMallExeShopList();
    }
    initParaData(e) {
        sys.isObjectValid(e) && (this.exe = e, sys.isObjectValid(e.link_id) && e.link_id > 0 && (this._linkId = e.link_id));
    }
    addNotify() {
        PushCenter.shared().addListener(GameConfig.Update_ExeStore, (e => {
            ToolUtils.isObjValid(this.node) && this.refreshMallExeShopView();
        }), this);
        PushCenter.shared().addListener(GameConfig.onEnterForeground, (e => {
            ToolUtils.isObjValid(this.node) && User.shared().requestMallExeShopList();
        }), this);
    }
    refreshMallExeShopView() {
        let e = this.getMallExpData();
        if (this.mallExpData_md5 != ToolUtils.jsonToMd5(e) && (this.mallExpData_md5 = ToolUtils.jsonToMd5(e), this.chip_moban.active = false, e && e.shop_list)) {
            this.chiplayout.destroyAllChildren();
            for (let t = 0, i = e.shop_list.length; t < i; t++) {
                let i = instantiate(this.chip_moban);
                this.initChipMoban(i, e.shop_list[t]);
                i.active = true;
                this.chiplayout.addChild(i);
            }
        }
    }
    setBgSize(e) {
    }
    initChipMoban(e, t) {
        let i = e.getChildByName("icon"), a = e.getChildByName("best"), s = e.getChildByName("popular"), n = e.getChildByName("firstRec"), o = e.getChildByName("rate"), l = e.getChildByName("origin"), g = e.getChildByName("cur"), y = e.getChildByName("pay_btn"), _ = y.getChildByName("rec_num"), C = y.getChildByName("cashNode"), f = C.getChildByName("cash_icon"), b = l.getChildByName("num").getChildByName("originline"), B = t.goods_type;
        a.active = 2 == Number(t.tag) || false;
        s.active = 1 == Number(t.tag) || false;
        n.active = 3 == Number(t.tag) || false;
        i.getComponent(Sprite).spriteFrame = this.chipIconArr[t.icon_id - 1];
        sys.isObjectValid(t.show_num) && Number(t.show_num) > 0 ? (l.active = true, l.getChildByName("num").getComponent(Label).string = ToolUtils.parse_ChipNum(t.show_num) || "", l.getChildByName("num").getComponent(Label).updateRenderData(true), b.getComponent(Widget).updateAlignment()) : l.active = false;
        g.getChildByName("num").getComponent(Label).string = ToolUtils.parse_ChipNum(t.nums) || "";
        g.getChildByName("num").getComponent(Label).color = color(49, 49, 49, 255);
        g.getChildByName("num").getComponent(Label).updateRenderData(true);
        t.rate_text ? (o.active = true, o.getChildByName("tx").getComponent(Label).string = t.rate_text || "") : o.active = false;
        _.active = 0 == B;
        C.active = 1 == B;
        0 == B ? _.getComponent(Label).string = "₹" + t.money || "" : 1 == B && (C.getChildByName("cash_num").active = true, C.getChildByName("cash_num").getComponent(Label).string = t.money || "", C.getChildByName("cash_num").getComponent(Label).updateRenderData(true), f.active = true, C.getComponent(Layout).updateLayout());
        let N = 1 == B ? 1 : 0;
        y.getComponent(Sprite).spriteFrame = this.payBtnBgArr[N];
        y.getComponent(Button).clickEvents[0].customEventData = ToolUtils.toJsonString(t);
    }
    payBtnClick(e, t) {
        if (SoundManager.shared().playFx("click"), !(sys.now() - this._lastClick < 300) && (this._lastClick = sys.now(), User.shared().checkCanRecharge())) {
            try {
                let e = ToolUtils.parseJson(t);
                if (e) {
                    let t = e.goods_type;
                    if (0 == t) {
                        if (User.shared().checkFirstChipClick()) {
                            let t = { bLandscape: ToolUtils.getIsNormalDirection(), bWithCancel: true, strContent: i18nMgr.shared().getValueByKey("store.chip_charge_tip"), strTitle: i18nMgr.shared().getValueByKey("store.chip_charge_title"), sureKey: "store.chip_confirm", cancelKey: "reward_tips.cancel", dialogType: 0, closeType: 1 };
                            Utils.shared().showCommonAlert(t, (t => {
                                if (1 == t) {
                                    let t = { goods_id: e.goods_id, price: e.money, link_id: this._linkId };
                                    sys.isObjectValid(this.exe) && sys.isObjectValid(this.exe.act_id) && (t.act_id = this.exe.act_id, sys.isObjectValid(this.exe.act_type) && (t.act_type = this.exe.act_type));
                                    User.shared().startOrder(HttpRequest.CommChipPay, t);
                                }
                            }), false);
                        }
                        else {
                            let t = { goods_id: e.goods_id, price: e.money, link_id: this._linkId };
                            sys.isObjectValid(this.exe) && sys.isObjectValid(this.exe.act_id) && (t.act_id = this.exe.act_id, sys.isObjectValid(this.exe.act_type) && (t.act_type = this.exe.act_type));
                            User.shared().startOrder(HttpRequest.CommChipPay, t);
                        }
                    }
                    else if (1 == t) {
                        if (User.shared().data.money >= Number(e.money)) {
                            let t = { bLandscape: ToolUtils.getIsNormalDirection(), bWithCancel: false, strContent: ToolUtils.format(i18nMgr.shared().getValueByKey("store.pay_use_cash_exchange"), e.money, "" + ToolUtils.parse_ChipNum2(e.nums)), strTitle: i18nMgr.shared().getValueByKey("settings.tips"), sureKey: "reward_tips.okey", cancelKey: "reward_tips.cancel", dialogType: 0, closeType: 1 };
                            Utils.shared().showCommonAlert(t, (t => {
                                1 == t && User.shared().requestExeShopExchangeChip({ goods_id: e.goods_id });
                            }), false);
                        }
                        else {
                            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text92"), 3, 0, ToolUtils.getIsNormalDirection());
                        }
                    }
                }
            }
            catch (e) {
            }
        }
    }
    getMallExpData() {
        return sys.isObjectValid(User.shared().mall_exp_data) ? User.shared().mall_exp_data : null;
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().removeListenersByTag(this);
        this.unscheduleAllCallbacks();
    }
}
