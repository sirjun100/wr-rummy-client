// @ts-nocheck
// Recovered from index.js:9
import { _decorator, Button, Label, Node, RichText, Sprite, SpriteFrame, sys, tween, Vec3 } from "cc";
import SoundManager from "./SoundManager";
import Utils from "./Utils";
import PushCenter from "./PushCenter";
import PushEvent from "./PushEvent";
import User from "./User";
import BaseLayer from "./BaseLayer";
import i18nMgr from "./i18nMgr";
import TweenTool from "./TweenTool";
import HttpManager from "./HttpManager";
import { HttpRequest } from "./HttpRequestName";
import ReportConfig from "./ReportConfig";
import GameConfig from "./GameConfig";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("AdvancedGift")
export class AdvancedGift extends BaseLayer {
    public TAG: string = "AdvancedGift";
    @property(Node)
    public rootNode: Node = null;
    @property(Node)
    public recordNode: Node = null;
    @property(Node)
    public mainNode: Node = null;
    @property(Label)
    public timeLabel: Label = null;
    @property(RichText)
    public tipsLabel: RichText = null;
    @property([SpriteFrame])
    public btnImags: SpriteFrame[] = [];
    @property([SpriteFrame])
    public itemBgs: SpriteFrame[] = [];
    @property(Node)
    public ruleNode: Node = null;
    public isNext: boolean = false;
    public lastClick: number = 0;
    public _nVid: number = 0;
    public _linkId: number = 0;
    public _bCanSend: boolean = false;
    public _scheduleAct: any = null;
    public _leftTime: number = 0;
    public rule: string = "";
    public buyID: number = 0;
    public version: string = "";
    public list: any[] = [];
    public buyIndex: any = -1;
    public _lastBuyID: any = -1;
    public _hasReqeust: boolean = false;
    public _ui_type: number = 0;
    public _open_boxIndexs: any[] = [];
    public _last_openIndex: any = -1;
    public _scene: number = 1;
    public _hasCharge: boolean = false;
    public _firstShow: boolean = false;
    public _pop_souce: number = 0;
    public _has_close: boolean = false;
    public adventrueData_md5: any = null;
    initParaData(e) {
        sys.isObjectValid(e) && sys.isObjectValid(e.isNext) && (this.isNext = e.isNext);
        this.timeLabel.string = "";
        this.tipsLabel.string = "";
        sys.isObjectValid(e) && (sys.isObjectValid(e.reset) && (this._leftTime = Number(e.reset)), sys.isObjectValid(e.title) && (this.tipsLabel.string = e.title + ""), sys.isObjectValid(e.rule) && (this.rule = e.rule), sys.isObjectValid(e.buyID) && (this.buyID = e.buyID), sys.isObjectValid(e.version) && (this.version = e.version), sys.isObjectValid(e.list) && (this.list = e.list), sys.isObjectValid(e.from_source) ? this._scene = e.from_source : sys.isObjectValid(e.reportScene) && (this._scene = e.reportScene), sys.isObjectValid(e.pop_souce) && (this._pop_souce = e.pop_souce), sys.isObjectValid(e.link_id) && e.link_id > 0 && (this._linkId = e.link_id));
        sys.isObjectValid(User.shared().adventrueData) ? this.refreshLeftTime() : Utils.shared().showLoading(10, true, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
        }));
    }
    refreshUI(e) {
        this._lastBuyID = this.buyID;
        this._last_openIndex = this.buyIndex;
        sys.isObjectValid(e) && (sys.isObjectValid(e.reset) && (this._leftTime = Number(e.reset)), sys.isObjectValid(e.title) && (this.tipsLabel.string = e.title + ""), sys.isObjectValid(e.rule) && (this.rule = e.rule), sys.isObjectValid(e.buyID) && (this.buyID = e.buyID), sys.isObjectValid(e.version) && (this.version = e.version), sys.isObjectValid(e.list) && (this.list = e.list), sys.isObjectValid(e.ui_type) && (this._ui_type = e.ui_type, 1 == this._ui_type && (this._hasCharge = false)));
        this.refreshLeftTime();
        this.initMainUI();
    }
    refreshLeftTime() {
        this.timeLabel.string = ToolUtils.format(i18nMgr.shared().getValueByKey("advancedPack.time"), Utils.shared().parseCountDownToSec(this._leftTime));
        this._leftTime <= 0 && (this.timeLabel.string = ToolUtils.format(i18nMgr.shared().getValueByKey("advancedPack.time"), "0m 0s"));
    }
    scheduleCallBack() {
        this._leftTime -= 1;
        this._leftTime < 0 && (this._leftTime = 0, this._scheduleAct && TweenTool.stopAction(this._scheduleAct), this._hasReqeust || (User.shared().requestActAdvancedPackPage((e => {
            ToolUtils.isObjValid(this.node) && (sys.isObjectValid(e) && (e.ui_type = 0), this.refreshUI(e));
        })), this._hasReqeust = true));
        this.refreshLeftTime();
    }
    showDisCountNodeAction(e) {
        tween(e).to(0.2, { scale: new Vec3(1.1, 1.1) }).to(0.2, { scale: new Vec3(1, 1) }).union().repeat(2).delay(2).union().repeatForever().start();
    }
    start() {
        super.start();
        this._linkId = this._linkId > 0 ? this._linkId : sys.now();
        this.recordNode.active = false;
        ToolUtils.showFullScreen(this.node.getChildByName("mask"));
        ToolUtils.showFullScreen(this.recordNode.getChildByName("mask"));
        this.startShowAnim(this.rootNode, (() => {
        }));
        sys.isObjectValid(User.shared().adventrueData) && (this._bCanSend = true, this._firstShow = true, this.refreshUI(User.shared().adventrueData));
        this._bCanSend && HttpManager.shared().doCommReportRechargeEvent(ReportConfig.Cmd_AdvancePack, this._scene, 2, this._linkId, "", 0);
        User.shared().requestActAdvancedPackPage((e => {
            if (Utils.shared().hideLoading(), ToolUtils.isObjValid(this.node)) {
                this._bCanSend || (this._bCanSend = true, HttpManager.shared().doCommReportRechargeEvent(ReportConfig.Cmd_AdvancePack, this._scene, 2, this._linkId, "", 0));
                sys.isObjectValid(e.reset) && (this._leftTime = Number(e.reset));
                sys.isObjectValid(e.title) && (this.tipsLabel.string = e.title + "");
                sys.isObjectValid(e.rule) && (this.rule = e.rule);
                sys.isObjectValid(e.buyID) && (this.buyID = e.buyID);
                sys.isObjectValid(e.version) && (this.version = e.version);
                sys.isObjectValid(e.list) && (this.list = e.list);
                let t = true;
                if (sys.isObjectValid(this.adventrueData_md5)) {
                    let e = ToolUtils.jsonToMd5(User.shared().adventrueData);
                    this.adventrueData_md5 == e && (t = false);
                }
                t && this.initMainUI();
            }
        }));
        PushCenter.shared().addListener(GameConfig.onEnterForeground, (e => {
            ToolUtils.isObjValid(this.node) && TweenTool.delayAct(this.node, (() => {
                ToolUtils.isObjValid(this.node) && this._hasCharge && (Utils.shared().isRewardTipsShow() || User.shared().requestActAdvancedPackPage((e => {
                    ToolUtils.isObjValid(this.node) && (sys.isObjectValid(e) && (e.ui_type = 1), Utils.shared().isRewardTipsShow() || this.refreshUI(e));
                })), this._hasCharge = false);
            }), 2, true);
        }), this);
        this.dealMultipleLanguages();
        SoundManager.shared().playFx("act_popshow");
    }
    dealMultipleLanguages() {
        2 != i18nMgr.shared().language && 3 != i18nMgr.shared().language || (this.timeLabel.fontSize = 18);
    }
    initMainUI() {
        let e;
        this.adventrueData_md5 = ToolUtils.jsonToMd5(User.shared().adventrueData);
        this.buyIndex = -1;
        let t = [];
        if (Array.isArray(this.list) && this.list.length > 0) {
            for (let e = 0; e < this.list.length; e++) {
                let i = this.list[e].status;
                3 != i && 5 != i || t.push(e);
            }
            if (this._open_boxIndexs = [], 0 == this._ui_type) {
                for (let e = 0; e < t.length; e++) {
                    t.length > e + 1 && t[e + 1] - t[e] == 1 && (this._open_boxIndexs = [t[e], t[e + 1]]);
                }
            }
            else if (1 == this._ui_type) {
                for (let e = 0; e < t.length; e++) {
                    t[e] > this._last_openIndex && this._open_boxIndexs.push(t[e]);
                }
            }
            for (let t = 0; t < this.list.length; t++) {
                e = "gift" + t;
                let i = this.mainNode.getChildByName(e);
                if (i) {
                    i.active = true;
                    let e = i.getChildByName("discount");
                    TweenTool.stopNodeAction(e);
                    this.refreshGift(t);
                }
            }
        }
        this._scheduleAct && TweenTool.stopAction(this._scheduleAct);
        this.refreshLeftTime();
        this._scheduleAct = TweenTool.commonSchedule(this.node, 1, this.scheduleCallBack.bind(this));
        this._firstShow = false;
    }
    refreshGift(e) {
        this.list[e].id == this.buyID && (this.buyIndex = e);
        let t = this.list[e].status, i = Number(this.list[e].money), s = Number(this.list[e].bmoney), a = Number(this.list[e].bonus), r = this.list[e].all, h = this.list[e].jackpot, l = this.mainNode.getChildByName("gift" + e), o = l.getChildByName("discount"), c = Number(this.list[e].add), m = o.getChildByName("extra");
        1 == i18nMgr.shared().language && (m.getComponent(Label).fontSize = 12);
        let p = l.getChildByName("money"), b = l.getChildByName("reward"), _ = b.getChildByName("cash"), f = b.getChildByName("plus"), y = b.getChildByName("bonus"), C = l.getChildByName("Button"), N = o.getChildByName("value"), V = o.getChildByName("mask"), I = C.getChildByName("Label"), k = _.getChildByName("wz"), j = y.getChildByName("wz"), B = l.getChildByName("mask");
        1 == h && (l.getChildByName("bg").getComponent(Sprite).spriteFrame = this.itemBgs[1]);
        N.getComponent(Label).string = String(c);
        p.getComponent(Label).string = "" + r;
        k.getComponent(Label).string = "₹" + ToolUtils.parse_double(String(s), -1);
        j.getComponent(Label).string = "₹" + ToolUtils.parse_double(String(a), -1);
        c > 0 ? (o.active = true, 1 != t && 3 != t && 5 != t || this.showDisCountNodeAction(o)) : o.active = false;
        s > 0 && a <= 0 ? (_.active = true, y.active = false, f.active = false) : s <= 0 && a > 0 ? (_.active = false, y.active = true, f.active = false) : (_.active = true, y.active = true, f.active = true);
        let O = C.getChildByName("lock");
        sys.isObjectValid(O) && (O.active = 1 == t);
        1 == t ? (C.getComponent(Button).interactable = true, C.getComponent(Sprite).spriteFrame = this.btnImags[1], I.getComponent(Label).string = i > 0 ? "₹" + ToolUtils.parse_double(String(i), -1) : i18nMgr.shared().getValueByKey("advancedPack.free"), V.active = false, B.active = false) : 2 == t ? (C.getComponent(Button).interactable = false, C.getComponent(Sprite).spriteFrame = this.btnImags[2], I.getComponent(Label).string = i18nMgr.shared().getValueByKey("advancedPack.purchased"), V.active = true, B.active = true) : 3 == t ? (C.getComponent(Button).interactable = true, C.getComponent(Sprite).spriteFrame = this.btnImags[0], I.getComponent(Label).string = i > 0 ? i18nMgr.shared().getValueByKey("advancedPack.collect") : i18nMgr.shared().getValueByKey("advancedPack.free"), V.active = false, B.active = false) : 4 == t ? (C.getComponent(Button).interactable = false, C.getComponent(Sprite).spriteFrame = this.btnImags[2], I.getComponent(Label).string = i18nMgr.shared().getValueByKey("advancedPack.collected"), V.active = true, B.active = true) : 5 == t && (C.getComponent(Button).interactable = true, C.getComponent(Sprite).spriteFrame = this.btnImags[0], I.getComponent(Label).string = i > 0 ? "₹" + ToolUtils.parse_double(String(i), -1) : i18nMgr.shared().getValueByKey("advancedPack.free"), V.active = false, B.active = false);
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().removeListenersByTag(this);
        this.unscheduleAllCallbacks();
    }
    update(e) {
    }
    giftButtonClick(e, t) {
        if (SoundManager.shared().playFx("click"), sys.now() - this.lastClick < 1000) {
            return;
        }
        this.lastClick = sys.now();
        let i = this.list[Number(t)].status;
        if (5 == i) {
            if (!User.shared().checkCanRecharge()) {
                return void (ToolUtils.isObjValid(this.node) && this.node.destroy());
            }
            let e = this.list[Number(t)].money;
            this._bCanSend && HttpManager.shared().doCommReportRechargeEvent(ReportConfig.Cmd_AdvancePack, this._scene, 5, this._linkId, { money: e }, 0);
            let i = { price: e, act_id: PushEvent.JUMP_TO_Adventrue, link_id: this._linkId };
            this._hasCharge = true;
            User.shared().startPay(i);
        }
        else {
            3 == i ? (Utils.shared().showLoading(10, true, (() => {
                Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
            })), this._bCanSend && HttpManager.shared().doCommReportRechargeEvent(ReportConfig.Cmd_AdvancePack, this._scene, 6, this._linkId, "", 0), HttpManager.shared().doGetCommonRequest(null, HttpRequest.AdvancedPackGetReward, ((e, t, i) => {
                if (Utils.shared().hideLoading(), 200 != i) {
                    ;
                }
                else {
                    let e = ToolUtils.parseJson(t);
                    if (0 == e.ret && sys.isObjectValid(e.data.reward)) {
                        let t = null;
                        sys.isObjectValid(e.data.tips) && (t = e.data.tips + "");
                        User.shared().showChargeReward(e.data.reward, (t => {
                            sys.isObjectValid(e.data.page) && ToolUtils.isObjValid(this.node) && (sys.isObjectValid(e.data.page) && (e.data.page.ui_type = 2), this.refreshUI(e.data.page));
                        }), t);
                    }
                }
            }))) : 1 == i && Utils.shared().showToast(i18nMgr.shared().getValueByKey("advancedPack.unlock_tips"), 2, 0, ToolUtils.getIsNormalDirection());
        }
    }
    onButtonClick(e, t) {
        SoundManager.shared().playFx("click");
        "close" === t ? this.onBackView() : "help" === t && (this._bCanSend, this.showHelpView());
    }
    showHelpView() {
        this.recordNode.active || (this.recordNode.active = true, this.startShowAnim(this.recordNode.getChildByName("bg"), (() => {
            this.updateRecordView();
        })));
    }
    updateRecordView() {
        ToolUtils.isSafeString(this.rule).length > 0 && (this.ruleNode.getComponent(Label).string = this.rule);
    }
    onBackView() {
        if (ToolUtils.isObjValid(this.node)) {
            if (Utils.shared().hideLoading(), ToolUtils.isObjValid(this.recordNode) && this.recordNode.active) {
                this.recordNode.active = false;
            }
            else {
                if (this._has_close) {
                    return;
                }
                this._has_close = true;
                let e = { alert_node: this.node, rootNode: this.rootNode, isNext: this.isNext, pop_type: PushEvent.JUMP_TO_Adventrue, pop_souce: this._pop_souce };
                Utils.shared().closeActivityView(e);
                Utils.shared().hideToast();
                User.shared().getHallInfo();
                this._bCanSend && HttpManager.shared().doCommReportRechargeEvent(ReportConfig.Cmd_AdvancePack, this._scene, 3, this._linkId, "", 0);
            }
        }
    }
}
