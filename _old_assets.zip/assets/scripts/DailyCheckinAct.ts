// @ts-nocheck
// Recovered from index.js:91
import { _decorator, Button, color, Label, Node, Sprite, SpriteFrame, sys } from "cc";
import BaseLayer from "./BaseLayer";
import PushCenter from "./PushCenter";
import PushEvent from "./PushEvent";
import Utils from "./Utils";
import SoundManager from "./SoundManager";
import TweenTool from "./TweenTool";
import { TLog } from "./TLog";
import User from "./User";
import HttpManager from "./HttpManager";
import i18nMgr from "./i18nMgr";
import { HttpRequest } from "./HttpRequestName";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("DailyCheckinAct")
export class DailyCheckinAct extends BaseLayer {
    public TAG: string = "DailyCheckinAct";
    @property(Node)
    public root: Node = null;
    @property([SpriteFrame])
    public reward_imgs: SpriteFrame[] = [];
    @property([SpriteFrame])
    public item_imgs: SpriteFrame[] = [];
    @property([SpriteFrame])
    public collect_img: SpriteFrame[] = [];
    public _cur_day: number = 1;
    public has_reportUI: boolean = false;
    public _lastClick: number = 0;
    public _linkId: number = 0;
    public _reportScene: any = -1;
    public _initDelay: number = 0;
    public _pop_souce: number = 0;
    public _has_close: boolean = false;
    public isNext: boolean = false;
    public canGetReward: boolean = false;
    public _canGetRewardDay: any = -1;
    public _totalRewards: any[] = [0, 0, 0];
    public dailyLoginActData_md5: any = null;
    onLoad() {
    }
    start() {
        super.start();
        this._linkId = this._linkId > 0 ? this._linkId : sys.now();
        this._reportScene = this._reportScene >= 0 ? this._reportScene : ToolUtils.getIsInRoom() ? 2 : 1;
        this.startShowAnim(this.root);
        ToolUtils.showFullScreen(this.node.getChildByName("bg"));
        TweenTool.delayAct(this.node, (() => {
            if (null !== User.shared().dailyLoginActData) {
                this.updateDailyLoginPage();
            }
            else {
                let t = ToolUtils.isSafeString(sys.localStorage.getItem("dailycheckin_data" + String(User.shared().data.uid)));
                sys.isObjectValid(t) && t.length > 0 && (User.shared().dailyLoginActData = ToolUtils.parseJson(t), this.updateDailyLoginPage());
            }
            User.shared().requestDailyLoginActData(true);
        }), this._initDelay, true);
        PushCenter.shared().addListener(PushEvent.UpdateDailyLoginAct, (t => {
            if (sys.isObjectValid(this.node)) {
                let t = true;
                if (sys.isObjectValid(this.dailyLoginActData_md5)) {
                    let e = ToolUtils.jsonToMd5(User.shared().dailyLoginActData);
                    this.dailyLoginActData_md5 == e && (t = false);
                }
                t && this.updateDailyLoginPage();
                this.has_reportUI || (this.has_reportUI = true);
            }
        }), this);
        this.dealMultipleLanguages();
        SoundManager.shared().playFx("act_popshow");
    }
    dealMultipleLanguages() {
    }
    initParaData(t) {
        sys.isObjectValid(t) && sys.isObjectValid(t.isNext) && (this.isNext = t.isNext);
        sys.isObjectValid(t) && sys.isObjectValid(t.reportScene) && (this._reportScene = t.reportScene);
        sys.isObjectValid(t) && sys.isObjectValid(t.link_id) && t.link_id > 0 && (this._linkId = t.link_id);
        sys.isObjectValid(t) && sys.isObjectValid(t.pop_souce) && (this._pop_souce = t.pop_souce);
    }
    onClickItemEvent(t, e) {
        if (ToolUtils.isObjValid(this.node)) {
            if (sys.now() - this._lastClick < 500) {
                return;
            }
            if (this._lastClick = sys.now(), this.canGetReward) {
                if (SoundManager.shared().playFx("click"), 1 == Utils.shared().showFastKyc()) {
                    return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("kyc.kyc_dailylogin"), 2);
                }
                this.dealGetRewardLogic();
            }
        }
    }
    updateDailyLoginPage() {
        let t = User.shared().dailyLoginActData;
        if (this.dailyLoginActData_md5 = ToolUtils.jsonToMd5(t), sys.isObjectValid(t.day) && (this._cur_day = Number(t.day)), this._totalRewards = [0, 0, 0], sys.isObjectValid(t.ctype) && Number(t.ctype), this.canGetReward = false, sys.isObjectValid(t.status) && (this.canGetReward = 0 == Number(t.status)), sys.isObjectValid(t.every_reward) && Array.isArray(t.every_reward) && 7 == t.every_reward.length) {
            for (let e = 0; e < 7; e++) {
                let i = this.root.getChildByName("item" + e);
                sys.isObjectValid(i) && this.updateItemNode(i, t.every_reward[e], e + 1);
            }
        }
        this.updateCollectBtnState();
    }
    updateCollectBtnState() {
        this.canGetReward ? (this.root.getChildByName("collect_btn").getComponent(Sprite).spriteFrame = this.collect_img[1], this.root.getChildByName("collect_btn").getComponent(Button).interactable = true, this.root.getChildByName("collect_btn").getChildByName("wz").getComponent(Label).color = color(255, 255, 255), this.root.getChildByName("collect_btn").getChildByName("wz").getComponent(Label).string = "COLLECT") : (this.root.getChildByName("collect_btn").getComponent(Sprite).spriteFrame = this.collect_img[0], this.root.getChildByName("collect_btn").getComponent(Button).interactable = false, this.root.getChildByName("collect_btn").getChildByName("wz").getComponent(Label).color = color(102, 102, 102), this.root.getChildByName("collect_btn").getChildByName("wz").getComponent(Label).string = "TOMORROW");
    }
    updateItemNode(t, e, i) {
        if (i != this._cur_day ? (t.getChildByName("ico").getComponent(Sprite).spriteFrame = this.item_imgs[0], t.getChildByName("gou").active = i < this._cur_day, t.getComponent(Button).interactable = false) : (t.getChildByName("ico").getComponent(Sprite).spriteFrame = this.item_imgs[1], t.getChildByName("gou").active = !this.canGetReward, t.getComponent(Button).interactable = this.canGetReward), t.getChildByName("reward_root").active = true, t.getChildByName("reward_root").getChildByName("reward0").active = false, t.getChildByName("reward_root").getChildByName("reward1").active = false, sys.isObjectValid(t.getChildByName("reward_root").getChildByName("reward2")) && (t.getChildByName("reward_root").getChildByName("reward2").active = false), sys.isObjectValid(e) && Array.isArray(e.rewards) && e.rewards.length > 0) {
            let a = e.rewards.length;
            a >= 3 && (a = 2);
            for (let r = 0; r < a; r++) {
                let a = Number(e.rewards[r].type);
                7 == a && (a = 2);
                t.getChildByName("reward_root").getChildByName("reward" + r).active = true;
                t.getChildByName("reward_root").getChildByName("reward" + r).getChildByName("ico").getComponent(Sprite).spriteFrame = this.reward_imgs[a];
                t.getChildByName("reward_root").getChildByName("reward" + r).getChildByName("wz").getComponent(Label).string = "X" + String(e.rewards[r].num);
                this._totalRewards[a] = this._totalRewards[a] + Number(e.rewards[r].num);
                i != this._cur_day ? t.getChildByName("reward_root").getChildByName("reward" + r).getChildByName("wz").getComponent(Label).color = color(51, 51, 51) : t.getChildByName("reward_root").getChildByName("reward" + r).getChildByName("wz").getComponent(Label).color = color(154, 70, 28);
            }
        }
    }
    dealGetRewardLogic() {
        Utils.shared().showLoading(10, true, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
        }));
        HttpManager.shared().doGetCommonRequest({ day: this._cur_day }, HttpRequest.GetDailyLoginReward, ((t, e, i) => {
            if (ToolUtils.isObjValid(this.node)) {
                if (Utils.shared().hideLoading(), 200 != i) {
                    0 == sys.getNetworkType() ? Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text91"), 3, 0, ToolUtils.getIsNormalDirection()) : Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
                }
                else {
                    try {
                        let t = ToolUtils.parseJson(e);
                        if (0 == t.ret) {
                            this.canGetReward = false;
                            User.shared().dailyLoginActData.status = 1;
                            let e = 0;
                            this.root.getChildByName("item" + (this._cur_day - 1)).getChildByName("gou").active = true;
                            e += 0.1;
                            TweenTool.delayAct(this.root, (() => {
                                this.showRewards(User.shared().dailyLoginActData.every_reward[this._cur_day - 1].rewards, t.data.tip);
                            }), e, true);
                            e += 1;
                            TweenTool.delayAct(this.root, (() => {
                                this.updateCollectBtnState();
                            }), e, true);
                        }
                    }
                    catch (t) {
                        TLog.printError(this.TAG, "_dealGetRewardLogic  error:", t);
                    }
                }
            }
        }));
    }
    showRewards(t, e = "") {
        let i = t;
        if (i && i.length > 0) {
            let t = null;
            sys.isObjectValid(e) && ToolUtils.isSafeString(e).length > 0 && (t = ToolUtils.isSafeString(e));
            User.shared().showChargeReward(i, null, t);
        }
    }
    onDealButtonEvent(t, e) {
        if (SoundManager.shared().playFx("click"), ToolUtils.isObjValid(this.node)) {
            if (this._has_close) {
                return;
            }
            this._has_close = true;
            this.onBackView();
        }
    }
    onBackView() {
        let t = { alert_node: this.node, rootNode: this.root, isNext: this.isNext, pop_type: PushEvent.JUMP_TO_DAILYLOGIN, pop_souce: this._pop_souce };
        Utils.shared().closeActivityView(t);
    }
    onDestroy() {
        super.onDestroy();
        ToolUtils.judgeIfInHall() && PushCenter.shared().pushEvent(PushEvent.HallGet);
        PushCenter.shared().removeListenersByTag(this);
    }
}
