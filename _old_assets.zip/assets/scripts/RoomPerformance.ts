// @ts-nocheck
// Recovered from index.js:411
import { _decorator, Button, color, instantiate, Label, Node, ProgressBar, ScrollView, size, Slider, Sprite, SpriteFrame, sys, UITransform, v3, Vec3, view } from "cc";
import Parent, { AdapDirection } from "./Parent";
import SoundManager from "./SoundManager";
import { TLog } from "./TLog";
import PushCenter from "./PushCenter";
import PushEvent from "./PushEvent";
import { ScrollviewUtils } from "./ScrollviewUtils";
import Utils from "./Utils";
import i18nMgr from "./i18nMgr";
import RummyDataManager, { RUMMY_GAME_TYPE, RUMMY_MATCH_MODE, RUMMY_PLAYER_STATE_TYPE } from "./RummyDataManager";
import User from "./User";
import HowToPlayDefined from "./HowToPlayDefined";
import RummyCardConstant from "./RummyCardConstant";
import RummyCmd from "./RummyCmd";
import Server from "./Server";
import TweenTool from "./TweenTool";
import RummyGamePoolPop from "./RummyGamePoolPop";
import RummyTotalSettlement from "./RummyTotalSettlement";
import HttpManager from "./HttpManager";
import { TransferPlatform } from "./TransferPlatform";
import CommDefine from "./CommDefine";
import BundleNameDefined from "./BundleNameDefined";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("RoomPerformance")
export class RoomPerformance extends Parent {
    @property(Node)
    public roundMaskNode: Node = null;
    @property(Node)
    public itemNode: Node = null;
    @property(Slider)
    public slider: Slider = null;
    @property(ProgressBar)
    public progressBar: ProgressBar = null;
    @property(ScrollView)
    public scrollview: ScrollView = null;
    @property(Node)
    public moreNode: Node = null;
    @property(Node)
    public preNode: Node = null;
    @property(Node)
    public startNode: Node = null;
    @property(Node)
    public nextNode: Node = null;
    @property(Node)
    public myPlayerNode: Node = null;
    @property([SpriteFrame])
    public moreImags: SpriteFrame[] = [];
    @property([SpriteFrame])
    public preImags: SpriteFrame[] = [];
    @property([SpriteFrame])
    public nextImags: SpriteFrame[] = [];
    @property([SpriteFrame])
    public startImags: SpriteFrame[] = [];
    @property([SpriteFrame])
    public roundDiImags: SpriteFrame[] = [];
    @property(Node)
    public bgNode: Node = null;
    public _hasClick: boolean = false;
    public _toatalSteps: number = 0;
    public _playing: boolean = false;
    public _curStep: number = 0;
    public _roundNum: number = 0;
    public _listData: any = null;
    public _scrollUtil: any = null;
    public _curRoundIndex: number = 0;
    public _showRoundList: boolean = false;
    public _unclickColor: any = color(102, 102, 102, 255);
    public _whiteColor: any = color(255, 255, 255, 255);
    public _items: any[] = [];
    public mainRummy: any = null;
    public _hasTableData: boolean = false;
    public tid_key: string = "";
    public cround: number = 1;
    public total_round: number = 0;
    public _hasAdjustStep: boolean = false;
    public _hasShare: boolean = false;
    public lastTime: any = undefined;
    public game_serial_id: string = "";
    public curVid: string = "";
    public _delayAct: any = null;
    public _lastSliderTime: number = 0;
    public _delayAdjustAct: any = null;
    public _lastStep: number = 0;
    public _delaySlideAct: any = null;
    public sliderMoved: boolean = false;
    start() {
    }
    fitScreen() {
        if (ToolUtils.showFullScreen(this.bgNode), ToolUtils.showFullScreen(this.roundMaskNode), ToolUtils.isPadPlatform()) {
            let e = this.node.getChildByName("top"), t = this.node.getChildByName("bottom"), s = this.roundMaskNode.getChildByName("round_di"), i = this.node.getChildByName("player0");
            return this.resetUiPos(e, AdapDirection.Up, true, 1, false), this.resetUiPos(t, AdapDirection.Down, true, 1, false), this.resetUiPos(s, AdapDirection.Down, true, 1, false), void this.resetUiPos(i, AdapDirection.Down, true, 1, false);
        }
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().removeListenersByTag(this);
        this.unscheduleAllCallbacks();
    }
    onLoad() {
        SoundManager.shared().preLoadBundleSounds(BundleNameDefined.bundle_sound, "select");
        this.fitScreen();
        RummyDataManager.shared().performancePlayer = this.myPlayerNode;
        this.slider.progress = 0;
        this.progressBar.progress = this.slider.progress;
        this._scrollUtil = this.node.addComponent(ScrollviewUtils);
        this._scrollUtil.initScrollviewUtils(this.scrollview);
        this.roundMaskNode.getComponent(UITransform).setContentSize(size(ToolUtils.getRealViewSize().height, ToolUtils.getRealViewSize().width));
        this.initRegEvent();
        this.lastTime = sys.now();
        PushCenter.shared().addListener(PushEvent.RestoreRoomPerformance, (() => {
            if (ToolUtils.isObjValid(this.node)) {
                let e = RummyDataManager.shared().rummyInfos.get(this.tid_key);
                sys.isObjectValid(this.mainRummy._gameOverMsg) && e.pool_rummy_all_end_data ? (this.showTotalSettlementNode(e.pool_rummy_all_end_data), this._curStep = this._toatalSteps, this.showStepDetais(), this.mainRummy._gameOverMsg = null, this.dealPerformanceToEnd()) : ((e.gameRummyType == RUMMY_GAME_TYPE.POOL || e.gameRummyType == RUMMY_GAME_TYPE.DEALS || e.gameRummyType == RUMMY_GAME_TYPE.PRI_POOL || e.gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL) && this._curStep != this._toatalSteps && this.cround == this.total_round ? this._curStep = this._toatalSteps : this._curStep = 0, this.showStepDetais(), this.send_request_change_step());
            }
        }), this);
        this._lastSliderTime = sys.now();
    }
    showSlideProgress() {
        let e = Math.floor(this._toatalSteps * this.slider.progress + 0.5);
        e != this._curStep && SoundManager.shared().playFx("select_time");
        this._curStep = e;
        let t = this._curStep / this._toatalSteps;
        this.slider.progress = t;
        this.progressBar.progress = this.slider.progress;
        this.showStepDetais();
    }
    onTouchEnded(e) {
        this.send_request_change_step();
    }
    onTouchCancel(e) {
        this.send_request_change_step();
    }
    initRegEvent() {
        Server.shared().regDispatch(RummyCmd.RSP_PLAY_STATUS_ADJUST, this.handler_rsp_play_status_adjust.bind(this), this);
        Server.shared().regDispatch(RummyCmd.RSP_CHANGE_STEP, this.handler_rsp_change_step.bind(this), this);
    }
    slideCallback(e, t) {
        this._lastStep = this._curStep;
        this.showSlideProgress();
        this.sliderMoved = true;
        this._delaySlideAct && (TweenTool.stopAction(this._delaySlideAct), this._delaySlideAct = null);
        this._delaySlideAct = TweenTool.delayAct(this.node, (() => {
            this.sliderMoved && this.send_request_change_step();
            this.sliderMoved = false;
        }), 0.5, true);
    }
    onClick(e, t = "") {
        if (SoundManager.shared().playFx("click"), "close" == t) {
            if (!this._hasClick) {
                let e = { cmd: RummyCmd.GM_LOGINOUT_REQUEST, tid_key: this.tid_key, uid: User.shared().data.uid };
                Server.shared().send(e);
                PushCenter.shared().pushEvent(PushEvent.CloseRoomPerformance);
            }
            this._hasClick = true;
        }
        else if ("share" == t) {
            this._hasShare ? this._delayAct || (this._delayAct = TweenTool.delayAct(this.node, (() => {
                ToolUtils.isObjValid(this.node) && (this._hasShare = false, this._delayAct = null);
            }), 10, true)) : (Utils.shared().showLoading(15, false), Utils.shared().captureScreenshot(this.node, view.getVisibleSize(), (e => {
                e ? this.uploadImage(e) : (this._hasShare = false, Utils.shared().hideLoading());
            })));
            this._hasShare = true;
        }
        else if ("more" == t) {
            this._showRoundList = !this._showRoundList;
            this.roundMaskNode.active = this._showRoundList;
            this._showRoundList && this.refreshSelectItem();
        }
        else if ("pre" == t) {
            if (this._curStep <= 0) {
                return;
            }
            this._hasAdjustStep || (this._curStep >= 1 && (this._curStep -= 1), this.showStepDetais(), this.send_request_change_step(), this._delayAdjustAct || (this._delayAdjustAct = TweenTool.delayAct(this.node, (() => {
                ToolUtils.isObjValid(this.node) && (this._hasAdjustStep = false, this._delayAdjustAct = null);
            }), 1, true)));
            this._hasAdjustStep = true;
        }
        else if ("start" == t) {
            if (!this._hasAdjustStep) {
                let e = 0 == this._playing ? 0 : 1;
                this._curStep != this._toatalSteps || this._playing ? this.send_request_player_status_adjust(e) : (this._curStep = 0, this.showStepDetais(), this.send_request_change_step(0));
                this._delayAdjustAct || (this._delayAdjustAct = TweenTool.delayAct(this.node, (() => {
                    ToolUtils.isObjValid(this.node) && (this._hasAdjustStep = false, this._delayAdjustAct = null);
                }), 1, true));
            }
            this._hasAdjustStep = true;
        }
        else if ("next" == t) {
            if (this._curStep >= this._toatalSteps) {
                return;
            }
            this._hasAdjustStep || (this._curStep < this._toatalSteps && (this._curStep += 1), this.showStepDetais(), this.send_request_change_step(), this._delayAdjustAct || (this._delayAdjustAct = TweenTool.delayAct(this.node, (() => {
                ToolUtils.isObjValid(this.node) && (this._hasAdjustStep = false, this._delayAdjustAct = null);
            }), 1, true)));
            this._hasAdjustStep = true;
        }
        else {
            "mask" == t && (this._showRoundList = false, this.roundMaskNode.active = this._showRoundList);
        }
    }
    uploadImage(e) {
        if (e) {
            let t = { vid: this.curVid, game_serial_id: this.game_serial_id };
            HttpManager.shared().doPlayRecodeShareInfo(t, e, ((e, t, s) => {
                if (Utils.shared().hideLoading(), 200 !== s) {
                    ToolUtils.isObjValid(this.node) && (this._hasShare = false);
                }
                else {
                    ToolUtils.isObjValid(this.node) && (this._hasShare = false);
                    try {
                        let e = ToolUtils.parseJson(t);
                        if (0 === e.ret && null != e.data && null != e.data) {
                            let t = sys.now();
                            if (t - this.lastTime < 2000) {
                                return;
                            }
                            this.lastTime = t;
                            let s = ToolUtils.isSafeString(e.data.image_url), i = ToolUtils.isSafeString(e.data.content);
                            (ToolUtils.isSafeString(s).length > 0 || ToolUtils.isSafeString(i).length > 0) && (TransferPlatform.shared().shareWebPage(i), TransferPlatform.shared().copyContent(i));
                        }
                        else {
                            e.desc && e.desc.length > 0 && Utils.shared().showToast(e.desc, 2);
                        }
                    }
                    catch (e) {
                        ToolUtils.isObjValid(this.node) && (this._hasShare = false);
                    }
                }
            }));
        }
    }
    initRummy(e, t) {
        this.mainRummy = e;
        this.tid_key = t;
        this._hasTableData || null == RummyDataManager.shared().tableData || this.handler_server_table_info_uc(RummyDataManager.shared().tableData);
        this._toatalSteps > 0 && this.showStepDetais();
        this._curStep = 0;
        this.cround = User.shared().play_back_round;
        this.send_request_change_step(0);
        this.mainRummy.tipTs.seatPosVec[0] = this.getMyPlayerHeadViewPos();
        this._playing = true;
        RummyDataManager.shared().bocost_status = 0;
        this.refreshPlayingBtnStatus();
    }
    initView(e) {
        this._hasAdjustStep = false;
        this.slider.progress = 0;
        this.progressBar.progress = this.slider.progress;
        Array.isArray(e.round_detail) && (this._roundNum = e.round_detail.length);
        this.moreNode.getComponent(Sprite).spriteFrame = this._roundNum > 0 ? this.moreImags[0] : this.moreImags[1];
        this.moreNode.getComponent(Button).interactable = this._roundNum > 0;
        this.showStepDetais();
        this.scrollview.content.destroyAllChildren();
        this._listData = [];
        this._items = [];
        for (let t = 0; t < this._roundNum; t++) {
            this._listData.push(e.round_detail[t]);
        }
        if (this._listData.length > 0) {
            let e = 230, t = 40, s = t * this._listData.length > e ? t * this._listData.length : e;
            this.scrollview.content.getComponent(UITransform).height = s;
            for (let e = 0, s = this._listData.length; e < s; e++) {
                let s = instantiate(this.itemNode);
                s.active = true;
                s.setPosition(new Vec3(0, -t * e));
                this.initCurMobanCallBack(s, this._listData[e], e);
                this.scrollview.content.addChild(s);
                this._items.push(s);
            }
            this._scrollUtil.setScollDetails(t, e, this._listData, true);
        }
    }
    initCurMobanCallBack(e, t, s) {
        if (null == t) {
            return;
        }
        e.active = true;
        e.getComponent(Button).clickEvents[0].customEventData = s + "";
        let i = e.getChildByName("round").getComponent(Label);
        i18nMgr.shared().changeLabelFont(i);
        i.string = ToolUtils.format(i18nMgr.shared().getValueByKey("roomPerformance.round"), t.round);
        let a = e.getChildByName("score").getComponent(Label), m = "";
        t.win_score > 0 && (m = "+");
        a.string = m + t.win_score;
        let r = e.getChildByName("state").getComponent(Label);
        i18nMgr.shared().changeLabelFont(r);
        let n = "", o = false, l = 24;
        0 == t.end_status ? n = i18nMgr.shared().getValueByKey("roomPerformance.winner") : 1 == t.end_status ? n = i18nMgr.shared().getValueByKey("roomPerformance.lost") : 2 == t.end_status ? (n = i18nMgr.shared().getValueByKey("roomPerformance.dropped"), o = true) : 3 == t.end_status ? (n = i18nMgr.shared().getValueByKey("roomPerformance.middle_drop"), l = 18) : 4 == t.end_status && (n = i18nMgr.shared().getValueByKey("roomPerformance.wrongshow"), l = 18);
        r.string = n;
        r.fontSize = l;
        let h = e.getChildByName("di");
        o ? (i.color = this._unclickColor, a.color = this._unclickColor, r.color = this._unclickColor, h.active = true, h.getComponent(Sprite).spriteFrame = this.roundDiImags[1], e.getComponent(Button).interactable = false) : (i.color = this._whiteColor, a.color = this._whiteColor, r.color = this._whiteColor, this._curRoundIndex == s ? (h.active = true, h.getComponent(Sprite).spriteFrame = this.roundDiImags[0]) : h.active = false, e.getComponent(Button).interactable = true);
    }
    showPreBtnImage() {
        this._curStep > this._toatalSteps && (this._curStep = this._toatalSteps);
        this.preNode.getComponent(Sprite).spriteFrame = this._curStep > 0 ? this.preImags[0] : this.preImags[1];
        let e = this._curStep / this._toatalSteps;
        this.slider.progress = e;
        this.progressBar.progress = this.slider.progress;
    }
    showNextBtnImage() {
        this.nextNode.getComponent(Sprite).spriteFrame = this._curStep < this._toatalSteps ? this.nextImags[0] : this.nextImags[1];
    }
    showStepDetais() {
        this.showPreBtnImage();
        this.showNextBtnImage();
    }
    itemClick(e, t = "") {
        SoundManager.shared().playFx("click");
        Number(t);
        this._curRoundIndex;
        this._curRoundIndex = Number(t);
        this._showRoundList = false;
        this.roundMaskNode.active = this._showRoundList;
        this.refreshSelectItem();
        this.cround = this._curRoundIndex + 1;
        this._curStep = 0;
        this.send_request_change_step(0);
    }
    dealPerformanceToEnd() {
        this._curStep >= this._toatalSteps && (RummyDataManager.shared().bocost_status = 1, this.refreshPlayingBtnStatus());
    }
    refreshSelectItem() {
        for (let e = 0, t = this._items.length; e < t; e++) {
            let t = this._items[e].getChildByName("di");
            this._curRoundIndex == e ? (t.active = true, t.getComponent(Sprite).spriteFrame = this.roundDiImags[0]) : t.active = false;
        }
    }
    send_request_player_status_adjust(e) {
        let t = { cmd: RummyCmd.REQ_PLAY_STATUS_ADJUST, status: e, tid_key: this.tid_key && this.tid_key != CommDefine.PerformanceRoomTidkey ? this.tid_key : "" };
        Server.shared().send(t);
    }
    handler_rsp_play_status_adjust(e) {
        if (this._hasAdjustStep = false, 0 == e.ret) {
            let t = e.status;
            RummyDataManager.shared().bocost_status = t;
            this.refreshPlayingBtnStatus();
            this.showPlayerTimeAction();
        }
        else {
            e.msg && ToolUtils.isSafeString(e.msg).length > 0 && Utils.shared().showToast(e.msg, 2, 0, ToolUtils.getIsNormalDirection());
            this.showPlayerTimeAction();
        }
    }
    refreshPlayingBtnStatus() {
        this._playing = 1 != RummyDataManager.shared().bocost_status;
        this.startNode.getComponent(Sprite).spriteFrame = this._playing ? this.startImags[1] : this.startImags[0];
    }
    getMyPlayerHeadViewPos() {
        let e = this.myPlayerNode;
        if (e) {
            let t = new Vec3;
            return e.getPosition(t), t;
        }
        return v3(0, 0);
    }
    send_request_change_step(e = 1) {
        let t = { cmd: RummyCmd.REQ_CHANGE_STEP, game_id: User.shared().game_id, round: this.cround, step: this._curStep, status: e, tid_key: this.tid_key && this.tid_key != CommDefine.PerformanceRoomTidkey ? this.tid_key : "" };
        Server.shared().send(t);
    }
    handler_rsp_change_step(e) {
        this._hasAdjustStep = false;
        0 == e.ret || e.msg && ToolUtils.isSafeString(e.msg).length > 0 && Utils.shared().showToast(e.msg, 2, 0, ToolUtils.getIsNormalDirection());
    }
    showPlayerTimeAction() {
        this.mainRummy.playerTs.showPlayerRootTimeAction(RummyDataManager.shared().bocost_status);
    }
    handler_server_table_info_uc(e) {
        Utils.shared().hideLoading();
        this._hasTableData = true;
        RummyDataManager.shared().bocost_status = e.bocost_status;
        this.showPlayerTimeAction();
        this.bgNode.active = false;
        e.vid && (this.curVid = e.vid);
        e.game_serial_id && (this.game_serial_id = e.game_serial_id);
        let t = RummyDataManager.shared().rummyInfos.get(this.tid_key);
        t.pool_rummy_all_end_data = null;
        this.mainRummy._gameOverMsg = null;
        this.mainRummy.resetGameByTableInfo();
        this._curStep = e.cur_step;
        this._toatalSteps = e.total_step;
        null != e.game_id && (User.shared().game_id = e.game_id);
        this.mainRummy.node.getChildByName("rootNode").getChildByName("smallGamebg").active = false;
        sys.isObjectValid(e.finish_card) ? t.is_showhuAnim_status = ToolUtils.isSafeNumber(e.finish_card) > 0 : t.is_showhuAnim_status = false;
        sys.isObjectValid(e.able_client_group) && (t.able_client_group = 1 == e.able_client_group);
        t.isWatching = ToolUtils.isSafeNumber(e.isWatching);
        t.gameRummyType = e.mode || 0;
        t.gameMatchMode = e.match_mode || 0;
        sys.isObjectValid(e.special_mode) && (t.gameRummyMode = e.special_mode);
        sys.isObjectValid(e.game_mode) && (t.gameMatchType = e.game_mode);
        User.shared().gameRummyType = e.mode;
        t.gameBaseMoney = e.base_money;
        t.pnum = e.pnum;
        t.gameRummyType == RUMMY_GAME_TYPE.POOL ? t.gameRound = e.disuse_score : t.gameRummyType == RUMMY_GAME_TYPE.DEALS && (t.gameRound = e.total_round);
        undefined !== e.cround && (t.xiaojuNum = e.cround, e.cround <= 1 && (t.hasReportFinish = false));
        t.isCanTouchCard = false;
        this.initView(e);
        this.mainRummy.rummyShowTopUiLogic.show_table_top_info(e);
        this.refreshPlayingBtnStatus();
        this.mainRummy.hideWinTipAlert();
        t.crashModel = 0;
        t.base_money = ToolUtils.isSafeNumber(e.base_money);
        t.entry_fee = ToolUtils.isSafeNumber(e.entry_fee);
        t.dealsRummyCurrentRount = e.cround;
        this.cround = e.cround;
        this.total_round = e.total_round;
        this._curRoundIndex = this.cround - 1;
        User.shared().play_back_round = this.cround;
        let s = e.dealTs, i = e.pnum;
        e.mode === RUMMY_GAME_TYPE.PRIVATE ? t.game_type = HowToPlayDefined.gameId_PrivateRummy : e.mode === RUMMY_GAME_TYPE.PRI_POOL ? t.game_type = HowToPlayDefined.gameId_PoolPrivateRummy : e.mode === RUMMY_GAME_TYPE.PRI_DEAL ? t.game_type = HowToPlayDefined.gameId_DealsPrivateRummy : e.mode === RUMMY_GAME_TYPE.MATCH && (t.gameRummyType = RUMMY_GAME_TYPE.MATCH, t.game_type = HowToPlayDefined.gameId_RummyGame, t.gameMatchMode == RUMMY_MATCH_MODE.FULLMATCH && (t.matchPrizesInfo = e.reward_infos, 0 == e.isStarting ? this.mainRummy.rummyShowTopUiLogic.showMatchWaitView(e.race_name, e.reward_infos, e.signup_cnt, e.total_num) : this.mainRummy.hideMatchWaitView()));
        t.roomNum = String(e.tid);
        t.op_cd = 20;
        t.host_seat = -1;
        t.op_cd = null != e.op_cd ? e.op_cd : 20;
        let a = sys.isObjectValid(e.total_cd) ? e.total_cd : -1;
        t.pnum = i;
        t.laizicard = e.lz_card;
        t.laiziFlopCard = e.flop_lz_card;
        sys.isObjectValid(e.vid) && (t.vid = e.vid);
        t.clientSeatId = e.self_seatid;
        for (let e = 0; e <= 5; e++) {
            0 != e && this.mainRummy.playerTs.hidePlayer(e);
            this.mainRummy.playerTs.changePlayerZhuangState(false, e);
        }
        if (this.mainRummy.playerTs.showEmptySeat(), this.mainRummy.playerTs.refreshPlayerPostion(), 2 == i) {
            this.mainRummy.tipTs.seatPosVec[1] = this.mainRummy.tipTs.seatPosVec[3];
            this.mainRummy.cardsTs.seatPosVec[1] = this.mainRummy.cardsTs.seatPosVec[3];
            this.mainRummy.tipTs.refreshLoseMoneyPostion();
        }
        else if (4 == i) {
            for (let e = 1; e < i; e++) {
                this.mainRummy.tipTs.seatPosVec[e] = RummyCardConstant.fourPlayerPosVec[e];
                this.mainRummy.cardsTs.seatPosVec[e] = RummyCardConstant.fourPlayerPosVec[e];
            }
            this.mainRummy.actionTs.refreshHeadClickPosition();
        }
        t.game_cd = s;
        t.timeout_cd = e.cd - s;
        this.mainRummy.game_cd = s;
        t.cardInfoModelVec = [];
        let m = 0;
        if (e.players && "object" == typeof e.players) {
            let s = e.players.length;
            t.roomPlayerCounter = s;
            t.players = e.players;
            for (let i = 0; i < s; i++) {
                let s = e.players[i].seatid, a = t.playerModels[s];
                a.isShow = true;
                a.ready = 0;
                a.uid = e.players[i].uid;
                a.seatid = e.players[i].seatid;
                a.role = e.players[i].role;
                null != e.players[i].ready ? a.ready = e.players[i].ready : null != e.players[i].zhunbei && (a.ready = e.players[i].zhunbei);
                a.betting = e.players[i].betting;
                a.see = e.players[i].see;
                a.bet = e.players[i].bet;
                a.status = e.players[i].status;
                a.fold_leave = e.players[i].fold_leave;
                a.name = e.players[i].name;
                a.sex = e.players[i].sex;
                a.avatar = e.players[i].avatar;
                a.avatar_url = e.players[i].avatar_url;
                a.money = e.players[i].money;
                a.score = e.players[i].score;
                a.total_board = e.players[i].total_board;
                a.total_win = e.players[i].total_win;
                a.vlevel = e.players[i].vlevel;
                a.dsc = e.players[i].ps;
                a.vip = e.players[i].vip;
                a.club_level = e.players[i].club_level;
                null != e.players[i].rank && (a.rank = e.players[i].rank);
                a.isRejoin = !!sys.isObjectValid(e.players[i].isRejoin) && 1 == e.players[i].isRejoin;
                a.decision = ToolUtils.isSafeNumber(e.players[i].decision);
                let r = this.mainRummy.getPosBySeatid(s);
                Utils.shared().preDownLoadHeadImg(a.avatar, a.avatar_url);
                let n = {};
                n.name = a.name;
                n.uid = a.uid;
                n.headname = a.avatar;
                n.vlevel = 0;
                n.money = a.money;
                n.sex = a.sex;
                n.avatar_url = a.avatar_url;
                n.vip = a.vip;
                n.club_level = a.club_level;
                n.isinit = true;
                n.isLineUp = false;
                n.isHeadCallback = true;
                this.mainRummy.playerTs.showPlayer(r, n);
                this.mainRummy.playerTs.changeAwayStateStatus(r, true, e.players[i].status);
                null != e.players[i].score && (this.mainRummy.playerTs.setPoolScore(r, e.players[i].score), this.mainRummy.updateSeatScore(s, e.players[i].score));
                0 == r && this.mainRummy.playerTs.updateSeatMoneyInfo(0, a.money);
                t.playerModels[s] = a;
                t.gameRummyType != RUMMY_GAME_TYPE.POOL && t.gameRummyType != RUMMY_GAME_TYPE.PRI_POOL && t.gameRummyType != RUMMY_GAME_TYPE.DEALS && t.gameRummyType != RUMMY_GAME_TYPE.PRI_DEAL && t.gameRummyType != RUMMY_GAME_TYPE.MATCH || null != e.players[i].score && this.mainRummy.playerTs.setPoolScoreState(r, true);
                this.mainRummy.playerTs.hidePipeiAnim(r);
                null != e.players[i].all_score && this.mainRummy.playerTs.showLoseScore(r, e.players[i].all_score, true);
                this.mainRummy.isMyPlayer(s) && (t.isCanTouchCard = false, t.isInGameing = 0, t.auto_out = e.players[i].auto_play);
                e.players[i].cardinfos && "object" == typeof e.players[i].cardinfos && (0 == r ? (m = this.mainRummy.refreshMyCardInfos(e.players[i]), this.mainRummy.cardsTs.beginFaPaiWithoutAnim(t.cardInfoModelVec, t.cardInfoModelVec.length)) : this.mainRummy.cardsTs.showRobotPlayerCards(e.players[i].cardinfos, r));
            }
        }
        t.close_cardnum = null != e.close_cardnum && null != e.close_cardnum ? e.close_cardnum : 0;
        t.round_per_game = null != e.round_per_game && null != e.round_per_game ? e.round_per_game : 0;
        let r = [];
        if (e.opencards) {
            for (let t = 0, s = e.opencards.length; t < s; t++) {
                r.push(e.opencards[t]);
            }
            1 == e.is_pre_decare && r.pop();
        }
        let n = parseInt("" + e.opseatid);
        t.curOptSeatid = n;
        this.mainRummy.tipTs.showGameTipsText(0, 0, "");
        this.mainRummy.playerTs.updateCloseNum(t.close_cardnum);
        this.mainRummy.playerTs.updateOpenNum(r.length);
        this.mainRummy.playerTs.updateRoundNum(t.round_per_game);
        let o = false;
        if (m > 0 && (o = true), 1 === ToolUtils.isSafeNumber(e.isWatching) && (o = true), o && (this.mainRummy.playerTs.changeOpenNumVisibile(true), this.mainRummy.playerTs.changePaiduNumVisible(true), this.mainRummy.playerTs.changeRoundNumVisible(true), this.mainRummy.playerTs.setPaiDuiBgShow(true), this.mainRummy.cardsTs.showPaiduiCards(), this.mainRummy.cardsTs.showLaiziCard(false), r.length > 0 && this.mainRummy.cardsTs.showQipaiWithAnim(r), t.hasFaPai = true), null != e.zhuang_seatid && null != e.zhuang_seatid) {
            let s = parseInt("" + e.zhuang_seatid);
            t.zhuang_seatid = s;
            this.mainRummy.playerTs.changePlayerZhuangState(true, this.mainRummy.getPosBySeatid(s));
        }
        if (t.isClientToPlay = false, n == t.clientSeatId) {
            if (13 == m) {
                let s = e.can_mp;
                this.mainRummy.isCanmqp = false;
                0 == t.gameRummyMode && (this.mainRummy.isCanmqp = 0 == s);
                this.mainRummy.cardsTs.showMoPaiTisAnim(true, this.mainRummy.isCanmqp);
            }
            else {
                14 == m && (this.mainRummy.cardsTs.showMoPaiTisAnim(false, true), this.mainRummy.cardsTs.showFinishTisiAnim(true));
            }
        }
        else {
            t.isClientToPlay = false;
        }
        if (-1 != n) {
            if (0 == e.timestate) {
                this.mainRummy.playerTs.startPlayerTimer(this.mainRummy.getPosBySeatid(n), s);
                this.mainRummy.playerTs.showEasyGameLight(this.mainRummy.getPosBySeatid(n));
            }
            else {
                let e = t.timeout_cd;
                a > 0 ? this.mainRummy.playerTs.startPlayerTimer(this.mainRummy.getPosBySeatid(n), e, true, a - s) : this.mainRummy.playerTs.startPlayerTimer(this.mainRummy.getPosBySeatid(n), e, true);
                this.mainRummy.playerTs.showEasyGameLight(this.mainRummy.getPosBySeatid(n));
            }
        }
        this.mainRummy.removeGameOverView();
        this.mainRummy.removeTotalSettlementView();
    }
    handler_server_game_start_bc(e) {
        this.bgNode.active = false;
        this.mainRummy.tipTs.show_wait_declare(false);
        Utils.shared().hideCommomDialog(this.mainRummy.pop_layer4);
        let t = RummyDataManager.shared().rummyInfos.get(this.tid_key);
        t.is_showhuAnim_status = false;
        t.hasShowScanAlert = false;
        t.ding_zhuang_seat_state = 0;
        t.stayInTable = false;
        t.dropType = 0;
        undefined !== e.cround && e.cround <= 1 && (t.hasReportFinish = false);
        this.mainRummy._isPlayWinEffec = false;
        RummyDataManager.shared().reportGameStart(this.tid_key, e);
        let s = ToolUtils.deskInfos.get(User.shared().curTid_key);
        s || (User.shared().curTid_key = this.tid_key, s = ToolUtils.deskInfos.get(User.shared().curTid_key));
        this.mainRummy._gameOverMsg = null;
        RummyDataManager.shared().stopTweenAction(this.mainRummy.start_time_action);
        this.mainRummy.start_time_action = null;
        ToolUtils.isObjValid(this.mainRummy.rummyGameManualSplit) && this.mainRummy.rummyGameManualSplit.destroy();
        ToolUtils.isObjValid(this.mainRummy.gameHistoryView) && this.mainRummy.gameHistoryView.destroy();
        ToolUtils.isObjValid(this.mainRummy.poolScoreboardView) && this.mainRummy.poolScoreboardView.destroy();
        this.mainRummy.removeTotalSettlementView();
        this.mainRummy.removeGameOverView();
        for (let e = 0; e < 6; e++) {
            this.mainRummy.playerTs.changePlayerZhuangState(false, e);
        }
        if (this.mainRummy.deleteGameOverDalay(), this.mainRummy._gameOverMsg = null, this.mainRummy._bIsGameEnd = false, this.mainRummy._bGameOverClosed = false, this.mainRummy._bIsWinnerAnimEnd = true, this.mainRummy._bIsShowReady = false, this.mainRummy.gameStartMsg = null, t.pool_rummy_all_end_data = null, t.auto_drop_type = 0, t.hasShowTotalSettlement = false, t.isClientToPlay = false, t.gameRummyType != RUMMY_GAME_TYPE.POOL && t.gameRummyType != RUMMY_GAME_TYPE.PRI_POOL && t.gameRummyType != RUMMY_GAME_TYPE.DEALS && t.gameRummyType != RUMMY_GAME_TYPE.PRI_DEAL || (t.is_game_all_end = 0, this.mainRummy.cardsTs.showCopyCard(false), null != e.pool_money && (t.pool_money = e.pool_money)), t.game_end_state = -1, null != e.zhuang_seatid) {
            let s = parseInt("" + e.zhuang_seatid);
            t.zhuang_seatid = s;
        }
        this.mainRummy.isUpdateMyMoney = true;
        t.isCanExit = true;
        t.isGameStarting = 1;
        t.is_waiting = 0;
        t.game_state = 2;
        t.game_server_state = 2;
        t.game_cd = 2;
        t.isGameOver = false;
        t.bIsSwitchRoom = false;
        t.is_declare_status = false;
        t.close_cardnum = 0;
        t.hasFaPai = false;
        t.bHandCardSynchronous = true;
        t.gameRummyType == RUMMY_GAME_TYPE.POOL || t.gameRummyType == RUMMY_GAME_TYPE.DEALS || t.gameRummyType == RUMMY_GAME_TYPE.PRI_POOL || t.gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL || t.gameRummyType == RUMMY_GAME_TYPE.MATCH || this.mainRummy.tipTs.resetFamaToReadyModel();
        this.mainRummy.isGameStarting = true;
        this.mainRummy.is_first_round = false;
        this.mainRummy.tipTs.hideWinEffect();
        this.mainRummy.tipTs.showGameTipsText(0, 0, "");
        t.isInGameing = 1;
        t.isPlayingCard = false;
        t.isMatchGameOver = false;
        t.bIsHasHu = false;
        for (let e = 0; e < t.playerGiveCards.length; e++) {
            t.playerGiveCards[e].cards = [];
        }
        if (this.mainRummy.hideOpenCardAlert(), this.mainRummy.hideWinTipAlert(), 1 == e.reassigned_seats) {
            for (let e = 0; e < 6; e++) {
                this.mainRummy.playerTs.changePlayerZhuangState(false, e);
                this.mainRummy.playerTs.stopPipeiAnim1(e);
            }
        }
        else {
            for (let e = 0; e < 6; e++) {
                this.mainRummy.playerTs.stopPipeiAnim1(e);
            }
        }
        this.mainRummy.cardsTs.showDropCardsZheZhao(false);
        this.mainRummy.tipTs.showMatchWaitTip(false);
        this.mainRummy.cardsTs.resetView();
        let i = e.self_old_seatid, a = -1, m = e.self_seatid;
        if (e.players) {
            for (let t = 0, s = e.players.length; t < s; t++) {
                e.players[t].drawing_card > 0 && (a = t);
            }
        }
        if (this.mainRummy.gameStartMsg = e, e.players) {
            for (let s = 0, r = e.players.length; s < r; s++) {
                const r = e.players[s];
                let n = r.seatid, o = r.drawing_card, l = t.playerModels[n];
                l.fold_leave = r.fold_leave;
                l.status = r.status;
                l.betting = r.betting;
                undefined !== r.score && (l.score = r.score);
                l.isRejoin = 0;
                undefined !== r.isRejoin && (l.isRejoin = r.isRejoin);
                t.playerModels[n].money = r.money;
                let h = 0, u = s == a, d = false;
                1 == e.reassigned_seats ? (h = this.mainRummy.getOldPosBySeatid(r.old_seat, i), d = 1 == r.drawing_card_is_max) : (h = this.mainRummy.getPosBySeatid(n), d = 1 == r.drawing_card_is_max);
                t.gameRummyType != RUMMY_GAME_TYPE.POOL && t.gameRummyType != RUMMY_GAME_TYPE.PRI_POOL && t.gameRummyType != RUMMY_GAME_TYPE.DEALS && t.gameRummyType != RUMMY_GAME_TYPE.PRI_DEAL && t.gameRummyType != RUMMY_GAME_TYPE.MATCH || this.mainRummy.playerTs.setPoolScoreState(h, true);
                let y = this.mainRummy.getOldPosBySeatid(n, m);
                t.gameRummyType == RUMMY_GAME_TYPE.DEALS || t.gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL || t.gameRummyType == RUMMY_GAME_TYPE.POOL || t.gameRummyType == RUMMY_GAME_TYPE.PRI_POOL ? o > 0 ? this.mainRummy.cardsTs.drawCard(h, o, 0, d, u, this.mainRummy.showZhaung.bind(this.mainRummy), y) : this.mainRummy.showZhaung() : o > 0 && this.mainRummy.cardsTs.drawCard(h, o, 0, d, u, this.mainRummy.showZhaung.bind(this.mainRummy), y);
            }
        }
        if (1 != e.reassigned_seats) {
            t.playerGiveCards = [];
            for (let e = 0; e < 6; e++) {
                let s = t.playerModels[e];
                if (s && null != s.betting && null != s.betting) {
                    let e = this.mainRummy.getPosBySeatid(s.seatid), i = [];
                    i.seatid = s.seatid;
                    i.name = s.name;
                    i.cards = [];
                    t.playerGiveCards.push(i);
                    s.status > 0 ? 1 == s.status ? this.mainRummy.playerTs.changeAwayStateStatus(e, true, RUMMY_PLAYER_STATE_TYPE.DROPPED) : 5 == s.status ? this.mainRummy.playerTs.changeAwayStateStatus(e, true, RUMMY_PLAYER_STATE_TYPE.MIDDLEDROP) : 3 == s.status && this.mainRummy.playerTs.changeAwayStateStatus(e, true, RUMMY_PLAYER_STATE_TYPE.WRONGSHOW) : null != s.fold_leave && null != s.fold_leave && 1 == s.fold_leave && this.mainRummy.playerTs.changeAwayStateStatus(e, true, RUMMY_PLAYER_STATE_TYPE.AWAY);
                    undefined !== s.score && this.mainRummy.playerTs.setPoolScore(e, s.score);
                }
            }
        }
    }
    handler_server_self_cards_return(e) {
        this.mainRummy.playerTs.restorePlayerImage(this.mainRummy.gameStartMsg);
        this.mainRummy.cardsTs.drawClear();
        this.mainRummy.delayHideExitPlayers();
        this.mainRummy.cardsTs.showMoPaiTisAnim(false, false);
        let t = RummyDataManager.shared().rummyInfos.get(this.tid_key);
        if (t.hasFaPai = false, t.game_cd = -1, t.game_state = 0, t.game_server_state = 2, t.is_declare_status = false, t.close_cardnum = e.close_cardnum, t.laizicard = e.lz_card, t.laiziFlopCard = e.flop_lz_card, t.dc_card = e.dc_card, t.bHandCardSynchronous = true, this.mainRummy.playerTs.setPaiDuiBgShow(false), e.cardinfos && (this.mainRummy.refreshMyCardInfos(e), this.mainRummy.cardsTs.beginFaPaiWithAnim(e, t.cardInfoModelVec), TweenTool.delayAct(this.mainRummy.action_node, (() => {
            this.mainRummy.playerTs.fadeOutPaidui(0.26);
            this.mainRummy.playerTs.showLoseScore(0, e.all_score, true);
        }), 1.4, true), TweenTool.delayAct(this.mainRummy.action_node, (() => {
            if (this.mainRummy.playerTs.changePaiduNumVisible(true), this.mainRummy.playerTs.changeOpenNumVisibile(true), this.mainRummy.playerTs.changeRoundNumVisible(true), RummyDataManager.shared().rummyInfos.get(this.tid_key).hasFaPai = true, e.players) {
                for (let t = 0, s = e.players.length; t < s; t++) {
                    const s = e.players[t];
                    let i = s.seatid, a = this.mainRummy.getPosBySeatid(i);
                    0 !== a && this.mainRummy.cardsTs.showRobotPlayerCards(s.cardinfos, a);
                }
            }
        }), 2.35, true)), t.gameRummyType == RUMMY_GAME_TYPE.PRIVATE || t.gameRummyType == RUMMY_GAME_TYPE.PRI_POOL || t.gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL || t.gameRummyType == RUMMY_GAME_TYPE.POINTS || t.gameRummyType == RUMMY_GAME_TYPE.MATCH || t.gameRummyType == RUMMY_GAME_TYPE.MULTIPLE) {
            for (let s = 1; s < 6; s++) {
                let i = t.playerModels[s];
                if (i.isShow && 1 == i.betting) {
                    let t = this.mainRummy.getPosBySeatid(i.seatid);
                    8 == i.status ? this.mainRummy.playerTs.changeAwayStateStatus(t, true, RUMMY_PLAYER_STATE_TYPE.AWAY) : 9 == e.status ? this.mainRummy.playerTs.changeAwayStateStatus(t, true, RUMMY_PLAYER_STATE_TYPE.OUT) : -1 == e.status ? this.mainRummy.playerTs.changeAwayStateStatus(t, true, RUMMY_PLAYER_STATE_TYPE.WAITING) : 11 == e.status ? this.mainRummy.playerTs.changeAwayStateStatus(t, true, RUMMY_PLAYER_STATE_TYPE.FirstWinner) : this.mainRummy.playerTs.changeAwayStateStatus(t, false);
                }
            }
        }
    }
    handler_server_next_deal_bc_return(e) {
        this.mainRummy.tipTs.hideTipRootTimeTips();
        this.mainRummy.tipTs.show_finish_tip(false);
        this._curStep = e.step;
        this.showStepDetais();
        let t = e.seatid, s = e.dealTs, i = e.can_mp;
        this.mainRummy.game_cd = s;
        let a = e.round_per_game, m = RummyDataManager.shared().rummyInfos.get(this.tid_key);
        m.op_cd = s;
        m.timeout_cd = e.cd - s;
        m.is_table_change_status = false;
        m.is_declare_status = false;
        m.round_per_game = a;
        this.mainRummy.playerTs.updateRoundNum(a);
        this.mainRummy.isCanmqp = false;
        t == m.clientSeatId ? (Utils.shared().hideCommomDialog(this.mainRummy.pop_layer4), m.game_state = 3, m.game_server_state = 2, m.game_cd = 2, m.isClientToPlay = true, 0 == m.gameRummyMode && (this.mainRummy.isCanmqp = 0 == i), this.mainRummy.cardsTs.showMoPaiTisAnim(true, this.mainRummy.isCanmqp), m.isPlayingCard = false, this.mainRummy.rummyShowTopUiLogic.removeRoomTask(), null != e.auto_drop && null != e.auto_drop && 0 != e.auto_drop || (this.mainRummy.autoDropTs.isshowAutoDropBtn(false, this.tid_key), this.mainRummy.autoDropTs.hideAllLayer()), RummyDataManager.shared().reSetTouchCardState(this.tid_key)) : (m.isClientToPlay = false, this.mainRummy.cardsTs.showFinishTisiAnim(false), m.hasChupai = false, m.isPlayingCard = false, this.mainRummy.tipTs.changePickTipsVisible(0, false), this.mainRummy.cardsTs.showMoPaiTisAnim(false, false));
        this.mainRummy.playerTs.startPlayerTimer(this.mainRummy.getPosBySeatid(t), s);
        this.mainRummy.playerTs.showEasyGameLight(this.mainRummy.getPosBySeatid(t));
        m.curOptSeatid = t;
    }
    handler_server_pick_card_bc_return(e) {
        this._curStep = e.step;
        this.showStepDetais();
        let t = e.close_cardnum, s = RummyDataManager.shared().rummyInfos.get(this.tid_key);
        s.close_cardnum = t;
        s.is_reshuffle = ToolUtils.isSafeNumber(e.is_reshuffle);
        1 === e.is_reshuffle && (t = 0, TweenTool.delayAct(this.mainRummy.time_node, (() => {
            this.mainRummy.playerTs.updateCloseNum(RummyDataManager.shared().rummyInfos.get(this.tid_key).close_cardnum);
            this.mainRummy.playerTs.updateOpenNum(0);
        }), 1.5, true));
        this.mainRummy.playerTs.updateCloseNum(t);
        let i = e.type, a = parseInt("" + e.seatid), m = s.dc_card;
        e.card && (m = e.card);
        let r = this.mainRummy.getPosBySeatid(a);
        if (0 != r) {
            this.mainRummy.cardsTs.showMoPaiTisAnim(false, false);
            let t = s.cardInfoModelVec;
            if (!(t && t.length > 0)) {
                let e = s.clientSeatId;
                1 == s.playerModels[e].betting && this.mainRummy.send_request_tableinfo();
                t = [];
            }
            this.mainRummy.cardsTs.getMoPai(r, i, m, t);
            this.mainRummy.cardsTs.showRobotPlayerCards(e.cardinfos, r);
        }
        else {
            this.mainRummy.tipTs.changePickTipsVisible(0, false);
            s.game_cd = -1;
            s.game_state = 0;
            s.game_server_state = 2;
            let t = null, a = null;
            e.cardinfos && this.mainRummy.refreshMyCardInfos(e);
            s.mp_refresh = false;
            s.mp_refresh = false;
            this.mainRummy.cardsTs.getMoPai(0, i, m, s.cardInfoModelVec, t, a);
            this.mainRummy.cardsTs.showMoPaiTisAnim(false, true);
            this.mainRummy.cardsTs.showFinishTisiAnim(true);
            s.hasChupai = false;
            let r = e.all_score;
            this.mainRummy.playerTs.showLoseScore(0, r, true);
            this.mainRummy.tipTs.changePickTipsVisible(0, false);
        }
        if (1 === ToolUtils.isSafeNumber(e.is_reshuffle)) {
            let e = 0 != r ? 0.95 : 0.2;
            TweenTool.delayAct(this.mainRummy.action_node, (() => {
                this.mainRummy.cardsTs.changeXipaiAnimVisibile(true);
            }), e, true);
        }
        1 === e.is_auto ? this.mainRummy.playerTs.changeAwayStateStatus(r, true, RUMMY_PLAYER_STATE_TYPE.AWAY) : this.mainRummy.playerTs.changeAwayStateStatus(r, false);
    }
    handler_server_discard_card_bc_return(e) {
        this._curStep = e.step;
        this.showStepDetais();
        this.mainRummy.tipTs.show_hupai_tip(false);
        let t = parseInt("" + e.seatid), s = e.card, i = e.index, a = e.card_index, m = e.discard_type, r = 0 == m, n = RummyDataManager.shared().rummyInfos.get(this.tid_key);
        n.is_showhuAnim_status = !r;
        n.game_state = 0;
        n.game_server_state = 2;
        this.mainRummy.tipTs.changePickTipsVisible(0, false);
        n.hasChupai = false;
        e.opencards && Array.isArray(e.opencards) && this.mainRummy.playerTs.updateOpenNum(e.opencards.length);
        let o = this.mainRummy.getPosBySeatid(t);
        if (t == n.clientSeatId) {
            this.mainRummy.cardsTs.showFinishTisiAnim(false);
            this.mainRummy.cardsTs.showMoPaiTisAnim(false, false);
            this.mainRummy.tipTs.show_finish_tip(false);
            n.isPlayingCard = false;
            let t = e.all_score;
            this.mainRummy.playerTs.showLoseScore(0, t, true);
            e.cardinfos && this.mainRummy.refreshMyCardInfos(e);
        }
        else {
            e.cardinfos && this.mainRummy.cardsTs.showRobotPlayerCards(e.cardinfos, o);
        }
        if (this.mainRummy.cardsTs.playOutCards(s, o, r, false, e.opencards, i, a), 1 == e.isfarud) {
            let t = n.clientSeatId;
            n.game_server_state = 4;
            this.mainRummy.cardsTs.showDropCardsZheZhao(true);
            n.gameRummyType == RUMMY_GAME_TYPE.MATCH && this.mainRummy.tipTs.showMatchWaitTip(true);
            n.isCanTouchCard = false;
            n.isInGameing = 0;
            let s = this.mainRummy.getPosBySeatid(t);
            null != e.all_score && this.mainRummy.playerTs.showLoseScore(s, e.all_score, true);
            this.mainRummy.playerTs.stopPlayerTimerByPos(s);
            null != e.cur_money && this.mainRummy.playerTs.updatePlayerMoney(s, e.cur_money);
            n.gameRummyType != RUMMY_GAME_TYPE.POOL && n.gameRummyType != RUMMY_GAME_TYPE.PRI_POOL && n.gameRummyType != RUMMY_GAME_TYPE.PRI_DEAL && n.gameRummyType != RUMMY_GAME_TYPE.DEALS || null != e.score && this.mainRummy.playerTs.setPoolScore(s, e.score);
            n.gameRummyType == RUMMY_GAME_TYPE.MATCH && null != e.score && (this.mainRummy.playerTs.setPoolScore(s, e.score), this.mainRummy.updateSeatScore(t, e.score));
        }
        1 == m && (this.mainRummy.playerTs.stopPlayerTimerByPos(o, true), n.bIsHasHu = true, this.mainRummy.tipTs.showWinEffect(o), this.mainRummy.playerTs.hideAllEasyGameLight());
    }
    handler_server_drop_bc_return(e) {
        if (this.tid_key !== (e.tid_key || "")) {
            return;
        }
        this._curStep = e.step;
        this.showStepDetais();
        let t = e.seatid, s = this.mainRummy.getPosBySeatid(t);
        SoundManager.shared().playFx("rummyDrop");
        0 == s && TweenTool.delayAct(this.node, (() => {
            if (User.shared().curTid_key == this.tid_key) {
                let e = RummyDataManager.shared().getSeatidByPos(s, this.tid_key), t = RummyDataManager.shared().rummyInfos.get(this.tid_key).playerModels[e];
                if (t && this.tid_key == User.shared().curTid_key) {
                    let e = 2 == t.sex ? "female" : "male";
                    SoundManager.shared().playSound(ToolUtils.format("disappointed_${0}", e), null, null, 0.2);
                }
            }
        }), 0.2, true);
        null != e.all_score && this.mainRummy.playerTs.showLoseScore(s, e.all_score, true);
        this.mainRummy.playerTs.stopPlayerTimerByPos(s);
        1 == e.drop_type ? this.mainRummy.playerTs.changeAwayStateStatus(s, true, RUMMY_PLAYER_STATE_TYPE.MIDDLEDROP) : 0 == e.drop_type && this.mainRummy.playerTs.changeAwayStateStatus(s, true, RUMMY_PLAYER_STATE_TYPE.DROPPED);
    }
    handler_server_game_end_bc(e) {
        this._curStep = e.step;
        this.showStepDetais();
        this.mainRummy.winTips.active = false;
        this.mainRummy.hideWinTipAlert();
        for (let e = 0; e < 6; e++) {
            this.mainRummy.playerTs.stopPlayerTimerByPos(e);
        }
        this.dealPerformanceToEnd();
        try {
            if (this.mainRummy.gameOverOpenLogic.tid_key = this.tid_key, this.mainRummy.gameOverOpenLogic.show_settle_ui = ToolUtils.isSafeNumber(e.show_settle_ui), this.mainRummy.gameOverOpenLogic.mainRummy = this.mainRummy, this.mainRummy._pQipai_action && (TweenTool.stopAction(this.mainRummy._pQipai_action), this.mainRummy._pQipai_action = null), ToolUtils.isObjValid(this.mainRummy.openFlag_poolScoreboard) && this.mainRummy.openFlag_poolScoreboard.destroy(), ToolUtils.isObjValid(this.mainRummy.openFlag_dealsScoreboard) && this.mainRummy.openFlag_dealsScoreboard.destroy(), RummyDataManager.shared().rummyInfos.get(this.tid_key).close_cardnum = 0, RummyDataManager.shared().rummyInfos.get(this.tid_key).bIsHasHu = true, e.receivedServerTime = sys.now(), this.mainRummy._bIsShowReady = true, this.mainRummy.tipTs.showPoolJackPot(false), this.mainRummy._gameOverMsg = e, this.mainRummy.tipTs.hideWinEffect(), TweenTool.delayAct(this.node, (() => {
                this.bgNode.active = true;
            }), 1, true), ToolUtils.isObjValid(this.mainRummy.gameEndView)) {
                let t = this.mainRummy.gameEndView.getComponent("RummyGameOverAlert");
                t.isShowEndView(true);
                t.updateInfo(0, e, this.mainRummy.onDealBtnAction.bind(this.mainRummy), true);
                t.show_btn();
            }
            else {
                this.mainRummy.gameOverOpenLogic.show_create_end_view(this.tid_key, e, true);
            }
            if (RummyDataManager.shared().rummyInfos.get(this.tid_key).bIsSwitchRoom = false, this.mainRummy.winPos = -1, e.players) {
                for (let t = 0, s = e.players.length; t < s; t++) {
                    const s = e.players[t];
                    let i = parseInt("" + s.seatid), a = (s.iswin, s.winscore, s.gamesocre), m = this.mainRummy.getPosBySeatid(i), r = s.money, n = s.score, o = s.status;
                    null != n && (this.mainRummy.playerTs.setPoolScore(m, n), this.mainRummy.updateSeatScore(i, n));
                    this.mainRummy.playerTs.setPoolRejoinState(m, false);
                    this.mainRummy.playerTs.changeAwayStateStatus(m, true, o);
                    0 == m && (null != r && this.mainRummy.playerTs.updateSeatMoneyInfo(m, r), this.mainRummy.playerTs.showLoseScore(this.mainRummy.getPosBySeatid(i), a, true));
                }
            }
        }
        catch (e) {
            TLog.printError("trycatch handler_server_game_end_bc,error:", e);
        }
    }
    handler_server_pool_all_record_return(e) {
        ToolUtils.isObjValid(this.mainRummy.rummyGamePoolPoP) && this.mainRummy.rummyGamePoolPoP.getComponent(RummyGamePoolPop).gameControllerRemove();
        ToolUtils.isObjValid(this.mainRummy.rummyGameManualSplit) && this.mainRummy.rummyGameManualSplit.destroy();
        let t = RummyDataManager.shared().rummyInfos.get(this.tid_key);
        t.isInGameing = 0;
        for (let e = 0; e < 6; e++) {
            this.mainRummy.playerTs.stopPlayerTimerByPos(e);
        }
        if (Array.isArray(e.settleinfo)) {
            for (let t = 0, s = e.settleinfo.length; t < s; t++) {
                const s = e.settleinfo[t];
                let i = s.seatid, a = s.total_score, m = this.mainRummy.getPosBySeatid(i);
                this.mainRummy.playerTs.setPoolScore(m, a);
                this.mainRummy.updateSeatScore(i, a);
            }
        }
        t.pool_money = 0;
        ToolUtils.isObjValid(this.mainRummy.poolScoreboardView) && this.mainRummy.poolScoreboardView.destroy();
        let s = false;
        null != this.mainRummy._gameOverMsg && 1 != e.end_way || (s = true);
        t.pool_rummy_all_end_data = null;
        t.pool_rummy_all_end_data = e;
        s ? (this.mainRummy.removeGameOverView(), this._curStep = e.step, this.dealPerformanceToEnd(), this.showStepDetais(), this.mainRummy._bIsShowReady = false, this.mainRummy.tipTs.showGameTipsText(0, 0, ""), this.showTotalSettlementNode(e), ToolUtils.isObjValid(this.mainRummy.rummyGamePoolPoP) && this.mainRummy.rummyGamePoolPoP.setSiblingIndex(20)) : this.mainRummy.removeTotalSettlementView();
    }
    showTotalSettlementNode(e) {
        if (this.bgNode.active = false, this.mainRummy.removeGameOverView(), ToolUtils.isObjValid(this.mainRummy.RummyTotalSettlementNode)) {
            this.mainRummy.RummyTotalSettlementNode.getComponent(RummyTotalSettlement).initView(e, this.mainRummy, this.tid_key);
        }
        else {
            try {
                ToolUtils.loadCommonPrefab(RummyDataManager.shared().RummyTotalSettlementPrefab, BundleNameDefined.bundle_rummy, "prefab/GameRummy_TotalSettlement", (t => {
                    if (sys.isObjectValid(t) && t.isValid) {
                        RummyDataManager.shared().RummyTotalSettlementPrefab = t;
                        let s = instantiate(RummyDataManager.shared().RummyTotalSettlementPrefab);
                        s.parent = this.mainRummy.pop_layer4;
                        s.getComponent(RummyTotalSettlement).initView(e, this.mainRummy, this.tid_key);
                        this.mainRummy.RummyTotalSettlementNode = s;
                    }
                }));
            }
            catch (e) {
                TLog.printError("trycatch laodRummyPrefab,error", e);
            }
        }
        this.mainRummy._gameOverMsg = null;
    }
}
