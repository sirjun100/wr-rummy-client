// @ts-nocheck
// Recovered from index.js:159
import { _decorator, color, instantiate, Label, Node, ScrollView, size, sys, UITransform, v3, view } from "cc";
import { TLog } from "./TLog";
import Utils from "./Utils";
import GameConfig from "./GameConfig";
import HttpManager from "./HttpManager";
import SoundManager from "./SoundManager";
import BaseLayer from "./BaseLayer";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("GameRecode")
export class GameRecode extends BaseLayer {
    @property(ScrollView)
    public scrollView: ScrollView = null;
    @property(Node)
    public selectNode: Node = null;
    @property(Node)
    public resultNode: Node = null;
    @property(Node)
    public dateNode: Node = null;
    @property(Node)
    public moban: Node = null;
    @property(Node)
    public pageRoot: Node = null;
    @property(Label)
    public pageLabel: Label = null;
    @property(Node)
    public nodata: Node = null;
    public curPage: number = 1;
    public totalPage: number = 0;
    public nowTime: any[] = [];
    public dateIndex: number = 0;
    public resultIndex: number = 0;
    public recordData: any = null;
    public scrollH: number = 990;
    public scrW: number = 720;
    public scrH: number = 1000;
    public height1: number = 114;
    public height2: number = 284;
    public resultStr: any[] = ["LOST", "ALL", "WIN"];
    start() {
        super.start();
        this.nodata.active = false;
        this.refreshViewInfo();
        this.doGetWalletBonus();
        this.fitScreen();
    }
    doGetWalletBonus() {
        Utils.shared().showLoading(10, false);
        let e = this.nowTime[this.dateIndex].year + this.nowTime[this.dateIndex].month + this.nowTime[this.dateIndex].day;
        HttpManager.shared().doGetWalletFlow(Number(e), this.resultIndex, this.curPage, this.listenRecordCallback.bind(this));
    }
    listenRecordCallback(e, t, i) {
        Utils.shared().hideLoading();
        try {
            if (200 != i) {
                alert("The login timed out, please try again");
            }
            else if (200 === i) {
                let e = ToolUtils.parseJson(t);
                0 === e.ret && ToolUtils.isObjValid(this.node) && (this.recordData = e, this.refreshRecode());
            }
        }
        catch (e) {
            TLog.printError("----- listenDailyDetailCallback error:", e);
        }
    }
    refreshRecode() {
        let e = this.scrollView.content.getComponent(UITransform), t = this.scrollView.content;
        t.destroyAllChildren();
        this.scrollView.scrollToTop();
        let i = this.recordData.data;
        if (i.list && i.list.length < 1) {
            return this.curPage = 0, this.totalPage = 0, this.refreshPage(), void (this.nodata.active = true);
        }
        this.nodata.active = false;
        this.curPage = i.page;
        this.totalPage = i.all;
        this.refreshPage();
        let s = i.list.length, l = this.scrH;
        this.height1 * s > this.scrollH && (l = this.height1 * s + 10 * (s - 1));
        e.setContentSize(size(this.scrW, l));
        let o = -this.height1 / 2;
        for (let e = 0; e < s; e++) {
            let s = instantiate(this.moban);
            s.active = true;
            0 != e && (o = o - this.height1 - 10);
            s.setPosition(v3(0, o));
            t.addChild(s);
            s.name = String(e);
            let l = i.list[e], r = s.getChildByName("title").getComponent(Label), n = s.getChildByName("date").getComponent(Label), h = s.getChildByName("amount").getComponent(Label), u = s.getChildByName("info"), m = u.getChildByName("id").getComponent(Label), f = u.getChildByName("reason").getComponent(Label), p = u.getChildByName("amount").getComponent(Label);
            if (u.active = false, r.string = l.title, n.string = l.cdate, h.string = l.num, m.string = l.id, f.string = l.reason, p.string = l.num, "string" == typeof l.num) {
                let e = l.num.slice(0, 1);
                "+" == e ? h.color = color(244, 49, 81) : "-" == e && (h.color = color(10, 169, 51));
            }
        }
    }
    refreshScrollView() {
        let e = this.scrollView.content.getComponent(UITransform), t = this.scrollView.content, i = this.recordData.data;
        if (i.list && i.list.length < 1) {
            return;
        }
        let s = i.list.length, l = -this.height1 / 2, o = 0;
        for (let e = 0; e < s; e++) {
            let s = t.getChildByName(String(e)), a = i.list[e];
            if (null != a.isShow && 1 == a.isShow ? (s.getChildByName("info").active = true, s.getChildByName("arrow").scale = v3(1, -1, 1), o = o + this.height2 + 10) : (s.getChildByName("info").active = false, s.getChildByName("arrow").scale = v3(1, 1, 1), o = o + this.height1 + 10), 0 != e) {
                let t = i.list[e - 1];
                l = null != t.isShow && 1 == t.isShow ? l - this.height2 - 10 : l - this.height1 - 10;
            }
            s.setPosition(v3(0, l));
        }
        let a = this.scrH;
        o > this.scrollH && (a = o + 10);
        e.setContentSize(size(this.scrW, a));
    }
    refreshPage() {
        let e = this.curPage + "/" + this.totalPage;
        this.pageLabel.string = e;
    }
    refreshNowTime() {
        for (let e = 0; e < 7; e++) {
            null != this.nowTime[e] && (this.nowTime[e] = []);
            let t = 86400000, i = new Date(sys.now() - e * t), s = [];
            s.year = String(i.getFullYear());
            s.month = String("0" + (i.getMonth() + 1)).slice(-2);
            s.day = String("0" + i.getDate()).slice(-2);
            this.nowTime[e] = s;
        }
    }
    refreshViewInfo() {
        this.refreshNowTime();
        this.resultNode.active = false;
        this.dateNode.active = false;
        let e = this.nowTime[this.dateIndex].year + "/" + this.nowTime[this.dateIndex].month + "/" + this.nowTime[this.dateIndex].day;
        this.selectNode.getChildByName("result").getComponent(Label).string = this.resultStr[this.resultIndex + 1];
        this.selectNode.getChildByName("date").getComponent(Label).string = e;
        this.resultNode.getChildByName("select").getComponent(Label).string = this.resultStr[this.resultIndex + 1];
        this.dateNode.getChildByName("select").getComponent(Label).string = e;
        for (let e = 0; e < 7; e++) {
            let t = this.dateNode.getChildByName("date_" + (e + 1));
            if (null != t) {
                let i = this.nowTime[e].year + "/" + this.nowTime[e].month + "/" + this.nowTime[e].day;
                t.getChildByName("Label").getComponent(Label).string = i;
            }
        }
        this.refreshPage();
    }
    onShowInfoClick(e, t) {
        SoundManager.shared().playFx("click");
        let i = e.target, s = Number(i.name);
        null == this.recordData.data.list[s].isShow || 0 == this.recordData.data.list[s].isShow ? this.recordData.data.list[s].isShow = 1 : this.recordData.data.list[s].isShow = 0;
        this.refreshScrollView();
    }
    onButtonClick(e, t) {
        if (SoundManager.shared().playFx("click"), "close" == t) {
            ToolUtils.isObjValid(this.node) && this.node.destroy();
        }
        else if ("prev" == t) {
            if (this.curPage = this.curPage - 1, this.curPage < 1) {
                return void (this.curPage = 1);
            }
            this.doGetWalletBonus();
        }
        else if ("next" == t) {
            if (this.curPage = this.curPage + 1, this.curPage > this.totalPage) {
                return void (this.curPage = this.totalPage);
            }
            this.doGetWalletBonus();
        }
        else {
            "result" == t ? this.resultNode.active = true : "date" == t ? this.dateNode.active = true : "closeSelect" == t && (this.resultNode.active = false, this.dateNode.active = false);
        }
    }
    onResultSelectClick(e, t) {
        SoundManager.shared().playFx("click");
        this.resultIndex = Number(t);
        this.curPage = 1;
        this.refreshViewInfo();
        this.doGetWalletBonus();
    }
    onDateSelectClick(e, t) {
        SoundManager.shared().playFx("click");
        this.dateIndex = Number(t);
        this.curPage = 1;
        this.refreshViewInfo();
        this.doGetWalletBonus();
    }
    fitScreen() {
        let e = sys.getSafeAreaRect().y, t = view.getVisibleSize().height - GameConfig.CONFIG_SCREEN_HEIGHT - e, i = this.scrollView.getComponent(UITransform);
        this.scrollView.getComponent(UITransform).setContentSize(size(i.width, i.height + t));
        this.pageRoot.setPosition(v3(this.pageRoot.getPosition().x, -view.getVisibleSize().height / 2 + 60));
    }
}
