// @ts-nocheck
// Recovered from index.js:193
import { _decorator } from "cc";
import { TLog } from "./TLog";
const { ccclass } = _decorator;
@ccclass("HttpCrypto")
export default class HttpCrypto {
    static _instance = null;
    public _keyStr: string = "5059b898a9420817732621e597de65a7";
    public _ivStr: string = "1102736404060702";
    static shared(): HttpCrypto {
        return null == this._instance && (this._instance = new HttpCrypto), this._instance;
    }
    encrypt(t) {
        let r = "";
        try {
            let e = CryptoJS.enc.Latin1.parse(this._keyStr), c = CryptoJS.enc.Latin1.parse(this._ivStr);
            r = CryptoJS.AES.encrypt(t, e, { iv: c, mode: CryptoJS.mode.CBC }).toString();
        }
        catch (t) {
            TLog.printError("------- HttpCrypto encrypt err:", t);
        }
        return r;
    }
    decrypt(t) {
        let r = "";
        try {
            let e = CryptoJS.enc.Latin1.parse(this._keyStr), c = CryptoJS.enc.Latin1.parse(this._ivStr);
            r = CryptoJS.AES.decrypt(t, e, { iv: c, mode: CryptoJS.mode.CBC }).toString(CryptoJS.enc.Utf8);
        }
        catch (t) {
            TLog.printError("------- HttpCrypto decrypt err:", t);
        }
        return r;
    }
}
