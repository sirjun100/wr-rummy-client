// @ts-nocheck
// Recovered from index.js:409
import { _decorator, instantiate, Node, Sprite, SpriteFrame, sys, v3, Widget } from "cc";
import Parent from "./Parent";
import PushCenter from "./PushCenter";
import SoundManager from "./SoundManager";
import { ToolUtils } from "./ToolUtils";
import { RocketGameManager } from "./RocketGameManager";
const { ccclass, property } = _decorator;
@ccclass("RocketGameTrend")
export default class RocketGameTrend extends Parent {
    public _TAG: string = "RocketGameTrend";
    @property(Node)
    public rootNode: Node = null;
    @property(Node)
    public contentView: Node = null;
    @property(Node)
    public moban: Node = null;
    @property([SpriteFrame])
    public color_imgs: SpriteFrame[] = [];
    public terkini: any[] = [];
    public panles: any[] = [];
    public maxZpX: number = 36;
    public maxZpY: number = 5;
    public emptyIndex: number = 5;
    onLoad() {
        this.node.getComponent(Widget).enabled = true;
        this.node.getComponent(Widget).updateAlignment();
    }
    onDestroy() {
        super.onDestroy();
        this.unscheduleAllCallbacks();
        PushCenter.shared().removeListenersByTag(this);
    }
    start() {
        this.resetAllView();
    }
    resetAllView() {
        let t = "";
        this.panles = [];
        this.contentView.removeAllChildren();
        for (let e = 1; e <= this.maxZpX; e++) {
            let i = instantiate(this.moban);
            i.active = true;
            i.setPosition(v3(26 + 32 * (e - 1), 16));
            this.contentView.addChild(i);
            for (let e = 1; e <= this.maxZpY; e++) {
                t = "Image" + e;
                let n = i.getChildByName(t);
                ToolUtils.isObjValid(n) && (n.tag = -1, n.active = false);
            }
            this.panles.push(i);
        }
    }
    updateViewStatus(t) {
        this.node.active = t;
    }
    refreshTabContent() {
        this.resetAllView();
        this.dealTerkiniData();
        this.initZhuPanContent();
    }
    dealTerkiniData() {
        this.terkini = [];
        for (let t = 0; t < RocketGameManager.shared().history_recordVec.length; t++) {
            let e = RocketGameManager.shared().history_recordVec[t];
            sys.isObjectValid(e.color) && this.terkini.push(e.color);
        }
    }
    checkSeatNum(t, e) {
        let i = false;
        for (let n = 1; n <= this.maxZpY; n++) {
            let s = `Image${n}`, a = this.panles[t].getChildByName(s);
            e >= this.maxZpY && a.tag === this.emptyIndex && (i = true);
        }
        return i;
    }
    initZhuPanContent() {
        let t = [], e = 0, i = -1, n = -1;
        for (let s = 0; s < this.terkini.length; s++) {
            if (e = this.terkini[s], i != e) {
                i = e;
                let s = [];
                -1 == n ? n = 0 : n += 1;
                t.push(s);
            }
            t[n].push(e);
        }
        if (t.length > this.maxZpX) {
            for (; t.length > this.maxZpX;) {
                t.shift();
            }
        }
        if (0 == t.length) {
            return;
        }
        let s = "", a = 0;
        for (let e = 0; e < t.length; e++) {
            let i = t[e], n = 0, r = this.checkSeatNum(e, i.length);
            if (i.length > this.maxZpY || r) {
                for (let t = 0; t < this.maxZpY; t++) {
                    a = i[t];
                    s = `Image${t + 1}`;
                    let r = this.panles[e].getChildByName(s);
                    ToolUtils.isObjValid(r) && r.tag != this.emptyIndex && a > 0 && a >= 1 && a <= 4 && (r.getComponent(Sprite).spriteFrame = this.color_imgs[a - 1], r.tag = a, r.active = true, n = t);
                }
                let t = -1;
                for (let i = this.maxZpY; i > 0; i--) {
                    let n = this.panles[e + 1];
                    if (ToolUtils.isObjValid(n)) {
                        s = `Image${i}`;
                        let e = n.getChildByName(s);
                        if (ToolUtils.isObjValid(e) && -1 == e.tag) {
                            t = i;
                            break;
                        }
                    }
                }
                if (-1 != t) {
                    for (let r = 0; r < i.length - n && !(e + r >= this.maxZpX); r++) {
                        let l = this.panles[e + r];
                        if (ToolUtils.isObjValid(l)) {
                            s = `Image${t}`;
                            let e = l.getChildByName(s);
                            a = i[n + r];
                            a >= 1 && a <= 4 && (e.getComponent(Sprite).spriteFrame = this.color_imgs[a - 1], e.tag = this.emptyIndex, e.active = true);
                        }
                    }
                }
            }
            else {
                for (let t = 0; t < this.maxZpY; t++) {
                    s = `Image${t + 1}`;
                    let n = this.panles[e].getChildByName(s);
                    t < i.length && n.tag != this.emptyIndex ? (a = i[t], a >= 1 && a <= 4 && (n.getComponent(Sprite).spriteFrame = this.color_imgs[a - 1], n.tag = a, n.active = true)) : (n.tag < 0 || n.tag > this.emptyIndex) && (n.tag = 4, n.active = false);
                }
            }
        }
    }
    isShow() {
        return this.node.active;
    }
    touchBtnEvent(t, e) {
        SoundManager.shared().playFx("click");
        this.node.active = false;
    }
}
