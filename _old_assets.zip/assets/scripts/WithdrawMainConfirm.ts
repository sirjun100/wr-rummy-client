// @ts-nocheck
// Recovered from index.js:697
import { _decorator, Label, Node, sys, v3 } from "cc";
import SoundManager from "./SoundManager";
import HttpManager from "./HttpManager";
import Utils from "./Utils";
import PushCenter from "./PushCenter";
import BaseLayer from "./BaseLayer";
import i18nMgr from "./i18nMgr";
import { HttpRequest } from "./HttpRequestName";
import User from "./User";
import PushEvent from "./PushEvent";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("WithdrawMainConfirm")
export class WithdrawMainConfirm extends BaseLayer {
    @property(Node)
    public contentNode: Node = null;
    @property(Node)
    public tdsTipsNode: Node = null;
    public _callabck: any = null;
    public _lastClick: number = 0;
    public _accData: any = null;
    public _tdsInfo: any = null;
    public _withdrawData: any = null;
    public _hasClicked: boolean = false;
    onLoad() {
    }
    start() {
        super.start();
        this.updateAccountVIew();
        this.updateWithdrawView();
        this.updateTdsInfo();
    }
    initData(t, e) {
        sys.isObjectValid(t) && sys.isObjectValid(t.acc) && (this._accData = t.acc);
        sys.isObjectValid(t) && sys.isObjectValid(t.withdraw) && (this._withdrawData = t.withdraw, sys.isObjectValid(this._withdrawData.tdsInfo) && (this._tdsInfo = this._withdrawData.tdsInfo));
        this._callabck = e;
    }
    updateAccountVIew() {
        sys.isObjectValid(this._accData) && (sys.isObjectValid(this._accData.w_account) && this._accData.w_account.length > 0 ? this.contentNode.getChildByName("acc_number").getComponent(Label).string = this._accData.w_account : this.contentNode.getChildByName("acc_number").getComponent(Label).string = "--", sys.isObjectValid(this._accData.w_name) && this._accData.w_name.length > 0 ? this.contentNode.getChildByName("acc_name").getComponent(Label).string = this._accData.w_name : this.contentNode.getChildByName("acc_name").getComponent(Label).string = "--", sys.isObjectValid(this._accData.w_ifsc) && this._accData.w_ifsc.length > 0 ? this.contentNode.getChildByName("ifsc").getComponent(Label).string = this._accData.w_ifsc : this.contentNode.getChildByName("ifsc").getComponent(Label).string = "--", sys.isObjectValid(this._accData.w_email) && this._accData.w_email.length > 0 ? this.contentNode.getChildByName("email").getComponent(Label).string = this._accData.w_email : this.contentNode.getChildByName("email").getComponent(Label).string = "--", sys.isObjectValid(this._accData.w_mobile) && this._accData.w_mobile.length > 0 ? this.contentNode.getChildByName("mobile").getComponent(Label).string = this._accData.w_mobile : this.contentNode.getChildByName("mobile").getComponent(Label).string = "--", sys.isObjectValid(this._accData.w_type) && 1 == this._accData.w_type && (this.contentNode.getChildByName("ifsc").active = false, this.contentNode.getChildByName("ifsc_title").active = false, this.contentNode.getChildByName("email_title").setPosition(v3(-329.43, -387.827)), this.contentNode.getChildByName("email").setPosition(v3(333.465, -387.827)), this.contentNode.getChildByName("mobile_title").setPosition(v3(-329.43, -449.036)), this.contentNode.getChildByName("mobile").setPosition(v3(333.465, -449.036)), this.contentNode.getChildByName("line-001").active = false));
    }
    updateWithdrawView() {
        sys.isObjectValid(this._withdrawData) && (sys.isObjectValid(this._withdrawData.total) ? (this.contentNode.getChildByName("total").getComponent(Label).string = ToolUtils.format("₹${0}", this._withdrawData.total), this.contentNode.getChildByName("withdraw_amount").getComponent(Label).string = ToolUtils.format("₹${0}", this._withdrawData.total), this.contentNode.parent.getChildByName("assure").getChildByName("wz").getComponent(Label).string = ToolUtils.format("WITHDRAW ₹${0}", this._withdrawData.total), this.contentNode.getChildByName("amount").getComponent(Label).string = ToolUtils.format("₹${0}", this._withdrawData.total)) : (this.contentNode.getChildByName("total").getComponent(Label).string = "₹0", this.contentNode.getChildByName("withdraw_amount").getComponent(Label).string = "₹0"), sys.isObjectValid(this._withdrawData.tds) ? this.contentNode.getChildByName("tds").getComponent(Label).string = ToolUtils.format("₹${0}", this._withdrawData.tds) : this.contentNode.getChildByName("tds").getComponent(Label).string = "₹0", sys.isObjectValid(this._withdrawData.processing_fee) ? this.contentNode.getChildByName("fee").getComponent(Label).string = ToolUtils.format("₹${0}", this._withdrawData.processing_fee) : this.contentNode.getChildByName("fee").getComponent(Label).string = "₹0");
    }
    updateTdsInfo() {
        if (0 != User.shared().temp_pingbi.tds) {
            if (sys.isObjectValid(this._tdsInfo)) {
                let t = this.tdsTipsNode.getChildByName("tds_bg"), e = this._tdsInfo.amount < 0 ? "-" : "";
                t.getChildByName("amount").getComponent(Label).string = ToolUtils.format("${0}₹${1}", e, Math.abs(this._tdsInfo.amount));
                e = this._tdsInfo.winnings < 0 ? "-" : "";
                t.getChildByName("winnings").getComponent(Label).string = ToolUtils.format("${0}₹${1}", e, Math.abs(this._tdsInfo.winnings));
                e = this._tdsInfo.tds < 0 ? "-" : "";
                t.getChildByName("tds").getComponent(Label).string = ToolUtils.format("${0}₹${1}", e, Math.abs(this._tdsInfo.tds));
                e = this._tdsInfo.paid < 0 ? "-" : "";
                t.getChildByName("paid").getComponent(Label).string = ToolUtils.format("${0}₹${1}", e, Math.abs(this._tdsInfo.paid));
                e = this._tdsInfo.tax < 0 ? "-" : "";
                t.getChildByName("tax").getComponent(Label).string = ToolUtils.format("${0}₹${1}", e, Math.abs(this._tdsInfo.tax));
            }
        }
        else {
            this.contentNode.getChildByName("tds_btn").active = false;
        }
    }
    button_click(t, e) {
        if (SoundManager.shared().playFx("click"), !(sys.now() - this._lastClick < 500)) {
            if (this._lastClick = sys.now(), "close" === e) {
                ToolUtils.isObjValid(this.node) && this.node.destroy();
            }
            else if ("not_now" == e) {
                ToolUtils.isObjValid(this.node) && this.node.destroy();
            }
            else if ("assure" == e) {
                if (this._hasClicked) {
                    return;
                }
                this._hasClicked = true;
                Utils.shared().showLoading(10, true, (() => {
                    Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 6, 0, ToolUtils.getIsNormalDirection());
                }));
                this.requestWithdrawOrder();
            }
            else if ("tds" == e) {
                let t = this.tdsTipsNode.active;
                this.tdsTipsNode.active = !t;
            }
            else {
                "tds_more" == e && ToolUtils.isSafeString(ToolUtils.tds_policy_url).length > 0 && (Utils.shared().doJumpLogic(PushEvent.JUMP_TO_TDSPolicy), this.tdsTipsNode.active = false);
            }
        }
    }
    requestWithdrawOrder() {
        HttpManager.shared().doGetCommonRequest({ record_id: this._accData.record_id, w_amount: this._withdrawData.amount, mtype: 0 }, HttpRequest.WithdrawOrder, ((t, e, i) => {
            if (Utils.shared().hideLoading(), ToolUtils.isObjValid(this.node) && (this._hasClicked = false), 200 != i) {
                Utils.shared().showToast(i18nMgr.shared().getValueByKey("withdraw.tips3"), 6);
            }
            else {
                let t = ToolUtils.parseJson(e);
                ToolUtils.isSafeString(t.desc).length > 0 && Utils.shared().showToast(t.desc, 6);
                sys.isObjectValid(t) && sys.isObjectValid(t.data) && sys.isObjectValid(t.data.m_order_id) && (User.shared().ratingTradeNo = t.data.m_order_id);
                ToolUtils.isObjValid(this.node) && (this._callabck && this._callabck(1), this.node.destroy());
            }
        }));
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().removeListenersByTag(this);
    }
}
