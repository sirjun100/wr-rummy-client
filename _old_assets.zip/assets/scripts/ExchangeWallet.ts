// @ts-nocheck
// Recovered from index.js:115
import { _decorator, Component, Button, EditBox, Label, Node, v3 } from "cc";
import Utils from "./Utils";
import TweenTool from "./TweenTool";
import SoundManager from "./SoundManager";
import HttpManager from "./HttpManager";
import User from "./User";
import PushCenter from "./PushCenter";
import GameConfig from "./GameConfig";
import PushEvent from "./PushEvent";
import { TLog } from "./TLog";
import i18nMgr from "./i18nMgr";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("ExchangeWallet")
export class ExchangeWallet extends Component {
    @property(EditBox)
    public exchange_edit: EditBox = null;
    @property(Button)
    public exchange_btn: Button = null;
    @property(Label)
    public amount: Label = null;
    @property(Node)
    public PLACEHOLDER_LABEL: Node = null;
    @property(Node)
    public TEXT_LABEL: Node = null;
    public nums: number = 0;
    public hasClicked: boolean = false;
    start() {
        this.updateWithdraw();
        this.PLACEHOLDER_LABEL.setPosition(v3(-208, 34, 0));
        this.TEXT_LABEL.setPosition(v3(-208, 34, 0));
        PushCenter.shared().addListener(PushEvent.UpdateInviteWallet, (t => {
            ToolUtils.isObjValid(this.node) && (this.amount.string = ToolUtils.parse_double("₹" + t), User.shared().club_withdraw = t);
        }), this);
        ToolUtils.startShowAnim(this.node.getChildByName("bgView"));
    }
    onDestroy() {
        PushCenter.shared().removeListenersByTag(this);
        this.unscheduleAllCallbacks();
    }
    setParaData(t) {
        this.nums = Number(t);
    }
    updateWithdraw() {
        let t = "₹" + ToolUtils.parse_double(String(User.shared().club_withdraw));
        this.amount.string = t;
    }
    onButtonClick(t, e) {
        if (SoundManager.shared().playFx("click"), "close" == e) {
            ToolUtils.isObjValid(this.node) && this.node.destroy();
        }
        else if ("exchange" == e) {
            let t = ToolUtils.isSafeNumber(Number(this.exchange_edit.string));
            if (null != t && t <= 0) {
                return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text45"), 2);
            }
            if (t > User.shared().club_withdraw) {
                return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text46"), 2);
            }
            if (this.hasClicked) {
                return;
            }
            this.exchange_btn.interactable = false;
            TweenTool.delayAct(this.exchange_btn, (() => {
                this.exchange_btn.interactable = true;
            }), 0.5, true);
            this.hasClicked = true;
            HttpManager.shared().doGoldExchange(t, this.listenWithdrawCallback.bind(this));
        }
    }
    listenWithdrawCallback(t, e, i) {
        this.hasClicked = false;
        try {
            if (200 != i) {
                alert("The login timed out, please try again");
            }
            else if (200 == i) {
                let t = ToolUtils.parseJson(e);
                0 === t.ret && (null != t.desc && Utils.shared().showToast(t.desc, 1), null != t.data.withdraw && (User.shared().club_withdraw = t.data.withdraw, this.updateWithdraw(), PushCenter.shared().pushEvent(GameConfig.Update_club_withdraw, User.shared().club_withdraw)), null != t.data.deposit && User.shared().updateDeposit(t.data.deposit), ToolUtils.isObjValid(this.node) && this.node.destroy());
            }
        }
        catch {
        }
    }
    editingDidEnded(t, e) {
        try {
            let t = ToolUtils.isSafeNumber(Number(this.exchange_edit.string));
            t = Math.floor(100 * t) / 100;
            this.exchange_edit.string = t + "";
        }
        catch (t) {
            TLog.printError("trycatch ExchangeWallet editingDidEnded,error:", t);
        }
    }
    editingReturn(t, e) {
        try {
            let t = ToolUtils.isSafeNumber(Number(this.exchange_edit.string));
            t = Math.floor(100 * t) / 100;
            this.exchange_edit.string = t + "";
        }
        catch (t) {
            TLog.printError("trycatch ExchangeWallet editingReturn,error:", t);
        }
    }
}
