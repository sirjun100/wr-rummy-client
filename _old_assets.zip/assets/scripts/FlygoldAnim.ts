// @ts-nocheck
// Recovered from index.js:127
import { _decorator, Animation, instantiate, Label, Node, sp, sys, tween, UIOpacity, UITransform, v3, Vec3, view, Widget } from "cc";
import { ToolUtils } from "./ToolUtils";
import GameConfig from "./GameConfig";
import User from "./User";
import SoundManager from "./SoundManager";
import { MyComponent } from "./MyComponent";
const { ccclass, property } = _decorator;
@ccclass("FlygoldAnim")
export class FlygoldAnim extends MyComponent {
    @property(Node)
    public targetNode: Node = null;
    @property(Node)
    public layoutNode: Node = null;
    @property(Node)
    public guangyunNode: Node = null;
    @property(Node)
    public glodAnim: Node = null;
    @property(Label)
    public glodAnimLabel: Label = null;
    public arcHeight: number = 100;
    public misPlayloop: boolean = false;
    public mCallback: any = null;
    public minSpacing: number = 10;
    public playType: number = 1;
    onLoad() {
        super.onLoad();
        let e = sys.getSafeAreaRect().y;
        this.node.getComponent(Widget).top = e;
        this.node.getComponent(Widget).updateAlignment();
        this.node.getChildByName("spanim").getComponent(Widget).updateAlignment();
    }
    start() {
        this.addEvent(GameConfig.Update_Money, (e => {
            1 != this.playType && (this.glodAnimLabel.string = ToolUtils.parse_double(User.shared().data.money + ""));
        }));
    }
    setData(e = 1, t, i, n = 7, o = false, s) {
        this.misPlayloop = o;
        this.mCallback = s;
        this.playType = e;
        1 == e ? (this.node.getChildByName("hui").active = false, this.playAnimType1(t, i, n)) : (this.node.getChildByName("hui").active = true, this.playAnimType2(n));
    }
    playAnimType2(e) {
        this.glodAnimLabel.string = ToolUtils.parse_double(User.shared().data.money + "");
        this.glodAnim.active = true;
        let t = tween(this.node).delay(0.01).call((() => {
            let e = view.getVisibleSize();
            e.width > e.height ? this.glodAnim.getComponent(sp.Skeleton).setAnimation(0, "horizontal", false) : this.glodAnim.getComponent(sp.Skeleton).setAnimation(0, "Vertical", false);
            SoundManager.shared().playFx("luckball_gold");
        })).delay(1).call((() => {
            let e = tween(this.glodAnimLabel.node).sequence(tween(this.glodAnimLabel.node).to(0.05, { scale: v3(1.15, 1.15, 1.15) }), tween(this.glodAnimLabel.node).to(0.05, { scale: v3(1, 1, 1) })).repeat(10).call((() => {
                this.glodAnimLabel.node.scale = v3(1, 1, 1);
                this.deleteTweenAnim(e);
            })).start();
            this.addTweenAnim(e);
        })).delay(1.5).call((() => {
            this.deleteTweenAnim(t);
            this.node.destroy();
        })).start();
        this.addTweenAnim(t);
        this.targetNode.getComponent(Animation).play();
    }
    playAnimType1(e, t, i = 7) {
        let n = this.node.getComponent(UITransform).convertToNodeSpaceAR(e.getWorldPosition());
        this.layoutNode.setPosition(n);
        let o = this.node.getComponent(UITransform).convertToNodeSpaceAR(t.getWorldPosition());
        this.layoutNode.scale = v3(1, 1, 1);
        this.setListView(i, this.layoutNode, ((e, t, n) => {
            this.scheduleOnce((() => {
                t.active = false;
                let e = this.node.getComponent(UITransform).convertToNodeSpaceAR(t.getWorldPosition()), s = instantiate(this.targetNode);
                this.node.addChild(s);
                s.setPosition(e);
                s.scale = v3(1, 1, 1);
                this.moveArcTo(s, e, o, n == i - 1);
            }), 0.15 * n);
        }));
    }
    moveArcTo(e, t, i, n) {
        let o = Vec3.distance(t, i);
        if (o > 500 && (o = 500), this.arcHeight = 50 + 0.9 * o, o < 200 && (this.arcHeight = 100), Vec3.equals(t, i)) {
            return void e.setPosition(i);
        }
        const s = new Vec3;
        Vec3.lerp(s, t, i, 0.5);
        const a = new Vec3;
        Vec3.subtract(a, i, t);
        const l = new Vec3(-a.y, a.x, 0);
        l.normalize();
        const r = new Vec3;
        Vec3.scaleAndAdd(r, s, l, this.arcHeight);
        const h = Vec3.distance(r, t), c = Math.atan2(t.y - r.y, t.x - r.x);
        let p = Math.atan2(i.y - r.y, i.x - r.x), g = p - c;
        g > Math.PI ? g -= 2 * Math.PI : g < -Math.PI && (g += 2 * Math.PI);
        p = c + g;
        let u = tween({ progress: 0 }).to(0.0035 * o, { progress: 1 }, { easing: "sineOut", onUpdate: (o, s) => {
                const a = c + g * o.progress, l = r.x + h * Math.cos(a), d = r.y + h * Math.sin(a);
                e.setPosition(l, d, t.z);
                1 == o.progress && this.misPlayloop && this.playGuangyunNode(i, n);
            } }).delay(0.01).call((() => {
            this.deleteTweenAnim(u);
            this.mCallback && this.mCallback();
            e.destroy();
            this.misPlayloop || n && this.node.destroy();
        })).start();
        this.addTweenAnim(u);
    }
    playGuangyunNode(e, t) {
        let i = instantiate(this.guangyunNode);
        i.setPosition(e);
        i.scale = v3(0, 0, 0);
        this.node.addChild(i);
        let n = 0.5;
        t && (n = 1);
        let o = tween({ progress: 1 }).to(n, { progress: 0 }, { easing: "sineOut", onUpdate: (e, n) => {
                let o = 1;
                o = t ? 2 * (1 - e.progress) : 1.6 * (1 - e.progress);
                e.progress <= 0.4 && (i.getComponent(UIOpacity).opacity = 50 + 2.5 * e.progress * 205);
                i.scale = v3(o, o, o);
            } }).call((() => {
            i.destroy();
            this.deleteTweenAnim(o);
            t && this.node.destroy();
        })).start();
        this.addTweenAnim(o);
    }
}
