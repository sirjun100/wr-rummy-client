import { director, Director, game, Game, input, Input, sys } from 'cc';
import { ToolUtils } from './ToolUtils';

/** Scene/frame context is independent of network/game state machines. */
export default class ClientDiagnostics {
    private static installed = false;
    static start() {
        const api = (globalThis as any).__rummyDiagnostics;
        if (this.installed || !sys.isNative || !api) return;
        this.installed = true;
        let lastBeat = 0;
        let shownAt = 0;
        const frame = () => {
            const now = Date.now();
            if (now - lastBeat < 1000) return;
            lastBeat = now;
            api.heartbeat({ uid: String(ToolUtils.uid || ''), scene: director.getScene()?.name || 'startup',
                mode: String(ToolUtils.curGameType) + '/' + String(ToolUtils.game_model),
                table: String(ToolUtils.curRoomId || '') });
        };
        director.on(Director.EVENT_AFTER_DRAW, () => {
            if (shownAt) {
                api.breadcrumb('foreground first draw ms=' + (Date.now() - shownAt));
                shownAt = 0;
            }
            frame();
        });
        const sceneReady = () => {
            const scene = director.getScene();
            if (!scene) return;
            api.breadcrumb('scene ' + scene?.name);
            lastBeat = 0; frame();
        };
        director.on(Director.EVENT_AFTER_SCENE_LAUNCH, sceneReady);
        // Observe input without creating UI hit targets or consuming events.
        input.on(Input.EventType.TOUCH_START, (event) => {
            const point = event.getUILocation();
            api.breadcrumb('touch ' + Math.round(point.x) + ',' + Math.round(point.y));
        });
        game.on(Game.EVENT_HIDE, () => { shownAt = 0; api.breadcrumb('game hidden'); });
        // EVENT_SHOW alone does not prove that the renderer produced a frame.
        game.on(Game.EVENT_SHOW, () => { api.breadcrumb('game shown'); shownAt = Date.now(); lastBeat = 0; });
        sceneReady();
    }
}
