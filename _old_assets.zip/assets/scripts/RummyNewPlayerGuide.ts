// @ts-nocheck
// Recovered from index.js:473
import { _decorator, Button, EventHandler, game, instantiate, Label, Node, NodePool, Prefab, size, Size, sp, Sprite, SpriteFrame, UITransform, v3, Vec3 } from "cc";
import Utils from "./Utils";
import User from "./User";
import GameConfig from "./GameConfig";
import SoundManager from "./SoundManager";
import PushCenter from "./PushCenter";
import HttpManager from "./HttpManager";
import { TLog } from "./TLog";
import TweenTool from "./TweenTool";
import RummyCard from "./RummyCard";
import RummyCardConstant from "./RummyCardConstant";
import RummyDataManager from "./RummyDataManager";
import { AdapDirection } from "./Parent";
import ReportConfig from "./ReportConfig";
import PushEvent from "./PushEvent";
import i18nMgr from "./i18nMgr";
import BaseLayer from "./BaseLayer";
import CommDefine from "./CommDefine";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("RummyNewPlayerGuide")
export class RummyNewPlayerGuide extends BaseLayer {
    public _nGuideStep: number = 0;
    @property(Node)
    public root_node: Node = null;
    @property(Node)
    public paidui_btn: Node = null;
    @property(Node)
    public qipai_btn: Node = null;
    @property(Node)
    public group_btn: Node = null;
    @property(Node)
    public discard_btn: Node = null;
    @property(Node)
    public finish_btn: Node = null;
    @property(Node)
    public left_menu: Node = null;
    @property(Node)
    public node_taskBg: Node = null;
    @property(Prefab)
    public cardPrefab: Prefab = null;
    @property([Node])
    public arrow_anim_nodes: Node[] = [];
    @property(sp.Skeleton)
    public hc_anim: any = null;
    @property(sp.Skeleton)
    public win_anim: any = null;
    @property([SpriteFrame])
    public card_kuang_anim: SpriteFrame[] = [];
    public seatPosVec: any[] = [];
    public cardViewVec: any[] = [];
    public groupFlags: any[] = [];
    public cardValueVec: any[] = [];
    public paiduiCardVec: any[] = [];
    public hupaiCardVec: any[] = [];
    public qipaiCards: any[] = [];
    public myGroupcardValueVec: any[] = [];
    public cardsPostions: any[] = [];
    public spXpositionDeq: any[] = [];
    public cardClickPositions: any[] = [];
    public delay_node: any = undefined;
    public lzCard: any = undefined;
    public paidui_node: any = undefined;
    public qipai_node: any = undefined;
    public hupai_node: any = undefined;
    public shoupaiLayout: any = undefined;
    public gropFlogModle: any = undefined;
    public card_root: any = undefined;
    public hand_anim: any = undefined;
    public cardWidth: any = undefined;
    public cardHeight: any = undefined;
    public middlePosY: number = 0;
    public touchCardWidth: number = 0;
    public touchCardHight: number = 0;
    public cardStartPosX: number = 0;
    public cardSpaceGroup: number = 0;
    public allPaiNum: number = 0;
    public handAnimStep: number = 0;
    public mopaiPos: any = undefined;
    public mpType: any = undefined;
    public _diffY: any = undefined;
    public qipaiPoint: any = undefined;
    public paiduiPoint: any = undefined;
    public finishPoint: any = undefined;
    public beginPos: any = undefined;
    public laiziPoint: any = undefined;
    public taskPanelPos: Vec3 = new Vec3;
    public cardScale: any = undefined;
    public mpScale: any = undefined;
    public outcardScale: any = undefined;
    public is_fapai_over: boolean = false;
    public qipaiValue: any = undefined;
    public hasQipai: any = undefined;
    public func_cb: any = null;
    public initialCardNodes: any[] = [];
    public cardsViewPool: any = null;
    public nCloseNum: number = 0;
    public nOpenNum: number = 0;
    public nRoundNum: number = 0;
    onLoad() {
        this.delay_node = new Node;
        this.node.addChild(this.delay_node);
        this.cardScale = RummyCardConstant.CardScale;
        this.cardWidth = RummyCardConstant.CardWidth;
        this.cardHeight = RummyCardConstant.CardHeight;
        this.touchCardWidth = this.cardWidth;
        this.touchCardHight = this.cardHeight;
        this.cardStartPosX = RummyCardConstant.CardStartPosX;
        this.cardSpaceGroup = RummyCardConstant.CardSpaceGroup;
        this.mpScale = RummyCardConstant.mpScale;
        this.outcardScale = RummyCardConstant.OutcardScale;
        this.allPaiNum = RummyCardConstant.allPaiNum;
        this.middlePosY = RummyCardConstant.middlePosY;
        this.qipaiPoint = RummyCardConstant.qipaiPoint;
        this.paiduiPoint = RummyCardConstant.paiduiPoint;
        this.finishPoint = RummyCardConstant.finishPoint;
        this.beginPos = RummyCardConstant.beginPos;
        this.laiziPoint = RummyCardConstant.laiziPoint;
        this._diffY = ToolUtils.getFitBottomHeightDiff();
        this.hand_anim = this.root_node.getChildByName("handAnim");
        this.card_root = this.root_node.getChildByName("card_node");
        this.paidui_node = this.card_root.getChildByName("paidui_node");
        this.qipai_node = this.card_root.getChildByName("qipai_node");
        this.hupai_node = this.card_root.getChildByName("hupai_node");
        this.shoupaiLayout = this.card_root.getChildByName("shoupai");
        this.gropFlogModle = this.card_root.getChildByName("grop_flag");
        this.initPushCenter();
        this.cardsViewPool = new NodePool("RummyGuideGameCard");
        let e = this.node.getChildByName("mask");
        ToolUtils.showFullScreen(e);
        e = this.card_root.getChildByName("mask");
        ToolUtils.showFullScreen(e);
        this.dealMultipleLanguages();
    }
    dealMultipleLanguages() {
        if (2 == i18nMgr.shared().language) {
            this.root_node.getChildByName("step2").getChildByName("text").getComponent(Label).fontSize = 24;
            this.root_node.getChildByName("step4").getChildByName("tips").getComponent(Label).fontSize = 24;
            this.root_node.getChildByName("step4").getChildByName("bg").getComponent(UITransform).contentSize = new Size(920, 120);
            this.root_node.getChildByName("step11").getChildByName("tips").getComponent(Label).fontSize = 24;
            this.root_node.getChildByName("step11").getChildByName("bg").getComponent(UITransform).contentSize = new Size(920, 120);
            let e = -80, t = -80;
            for (let i = 1; i <= 5; i++) {
                let a = this.root_node.getChildByName("step4").getChildByName("icon" + i), s = a.getPosition();
                a.setPosition(v3(s.x + e, s.y, s.z));
                let o = this.root_node.getChildByName("step11").getChildByName("icon" + i), d = o.getPosition();
                o.setPosition(v3(d.x + t, d.y, d.z));
            }
        }
        else if (3 == i18nMgr.shared().language) {
            this.root_node.getChildByName("step2").getChildByName("text").getComponent(Label).fontSize = 24;
            this.root_node.getChildByName("step4").getChildByName("tips").getComponent(Label).fontSize = 24;
            this.root_node.getChildByName("step4").getChildByName("bg").getComponent(UITransform).contentSize = new Size(920, 120);
            this.root_node.getChildByName("step11").getChildByName("tips").getComponent(Label).fontSize = 24;
            this.root_node.getChildByName("step11").getChildByName("bg").getComponent(UITransform).contentSize = new Size(920, 120);
            let e = -80, t = -120;
            for (let i = 1; i <= 5; i++) {
                let a = this.root_node.getChildByName("step4").getChildByName("icon" + i), s = a.getPosition();
                a.setPosition(v3(s.x + e, s.y, s.z));
                let o = this.root_node.getChildByName("step11").getChildByName("icon" + i), d = o.getPosition();
                o.setPosition(v3(d.x + t, d.y, d.z));
            }
        }
    }
    start() {
        super.start();
        this.resetUiPos(this.root_node.getChildByName("skip_btn"), AdapDirection.Right, true, 1, true);
        this.setUiEdgeDistance(this.left_menu.getChildByName("icon"), 0, AdapDirection.Right, true);
        this.setUiEdgeDistance(this.node_taskBg, 0, AdapDirection.Right, true);
        this.node_taskBg.getPosition(this.taskPanelPos);
        this.nCloseNum = 78;
        this.nOpenNum = 1;
        this.nRoundNum = 0;
        this.startGuideStep();
        User.shared()._bNewPlayerGuideskip = true;
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().removeListenersByTag(this);
        this.unscheduleAllCallbacks();
        this.cardsViewPool.clear();
    }
    preInintCardPool() {
        try {
            if (this.cardsViewPool) {
                let e = 0, t = RummyCardConstant.preInitCardNum / 2;
                for (let i = this.cardsViewPool.size(); i < t; i++) {
                    TweenTool.delayAct(this.delay_node, (() => {
                        if (this.cardsViewPool.size() < t) {
                            let e = instantiate(this.cardPrefab);
                            e.active = false;
                            null === e.getComponent("RummyCard") || e.getComponent("RummyCard");
                            e.getComponent(RummyCard).resetCards();
                            this.cardsViewPool.put(e);
                        }
                    }), game.frameTime / 1000 * 3 * e, true);
                    e += 1;
                }
            }
        }
        catch (e) {
            TLog.printError("trycatch preInintCardPool,error:", e);
        }
    }
    initPushCenter() {
        PushCenter.shared().addListener(PushEvent.RummyGameShowHC_newPlay, (e => {
            TweenTool.delayAct(this.delay_node, (() => {
                this.hc_anim.node.active = true;
                this.hc_anim.clearTracks();
                this.hc_anim.setToSetupPose();
                this.hc_anim.setAnimation(0, "hp_hc", false);
                TweenTool.delayAct(this.delay_node, (() => {
                    this.hc_anim.node.active = false;
                }), 1.1, true);
                this.huPaiPaiduiAnim();
                this.huPaiQiPaiduiAnim();
            }), e.delTime, true);
        }), this);
    }
    huPaiPaiduiAnim(e = true) {
        let t = this.getCardNode(), i = t.getComponent("RummyCard");
        i.init(8, true);
        t.setScale(this.outcardScale);
        t.setPosition(this.paiduiPoint);
        this.hupai_node.addChild(t);
        this.hupaiCardVec.push(t);
        let a = TweenTool.rotateBy(t, 0.957 - 0.891, new Vec3(0, 0, 8.4), "linear", false), s = TweenTool.moveBy(t, 0.957 - 0.891, new Vec3(-4, 42.25, 0), "linear", false), o = this.outcardScale.x + 0.05 * this.outcardScale.x, d = TweenTool.scaleTo(t, 0.957 - 0.891, new Vec3(o, o, 0), "linear", false), n = TweenTool.parallel(t, false, null, a, s, d), h = TweenTool.rotateBy(t, 0.99 - 0.957, new Vec3(0, 0, -0.6), "linear", false), l = TweenTool.moveBy(t, 0.957 - 0.891, new Vec3(4, -25.08, 0), "linear", false), c = TweenTool.parallel(t, false, null, h, l), u = TweenTool.sequence(t, false, null, n, c), p = this.getCardNode();
        i = p.getComponent("RummyCard");
        i.init(9, true);
        p.setScale(this.outcardScale);
        p.setPosition(this.paiduiPoint);
        this.hupai_node.addChild(p);
        this.hupaiCardVec.push(p);
        a = TweenTool.rotateBy(p, 0.957 - 0.891, new Vec3(0, 0, 8.4), "linear", false);
        s = TweenTool.moveBy(p, 0.957 - 0.891, new Vec3(-18, 33.25, 0), "linear", false);
        o = this.outcardScale.x + 0.08 * this.outcardScale.x;
        d = TweenTool.scaleTo(p, 0.957 - 0.891, new Vec3(o, o, 0), "linear", false);
        n = TweenTool.parallel(p, false, null, a, s, d);
        h = TweenTool.rotateBy(p, 0.99 - 0.957, new Vec3(0, 0, -1.2), "linear", false);
        l = TweenTool.moveBy(p, 0.957 - 0.891, new Vec3(0.6, -9.32, 0), "linear", false);
        c = TweenTool.parallel(p, false, null, h, l);
        let m = TweenTool.sequence(p, false, null, n, c), C = this.getCardNode();
        i = C.getComponent("RummyCard");
        i.init(10, true);
        C.setScale(this.outcardScale);
        C.setPosition(this.paiduiPoint);
        this.hupai_node.addChild(C);
        this.hupaiCardVec.push(C);
        a = TweenTool.rotateBy(C, 0.957 - 0.891, new Vec3(0, 0, -1.2), "linear", false);
        s = TweenTool.moveBy(C, 0.957 - 0.891, new Vec3(6, 21.5, 0), "linear", false);
        o = this.outcardScale.x + 0.1 * this.outcardScale.x;
        d = TweenTool.scaleTo(C, 0.957 - 0.891, new Vec3(o, o, 0), "linear", false);
        n = TweenTool.parallel(C, false, null, a, s, d);
        h = TweenTool.rotateBy(C, 0.99 - 0.957, new Vec3(0, 0, -6), "linear", false);
        l = TweenTool.moveBy(C, 0.957 - 0.891, new Vec3(0.7, -8, 0), "linear", false);
        c = TweenTool.parallel(C, false, null, h, l);
        let g = TweenTool.sequence(C, false, null, n, c);
        a = TweenTool.rotateBy(this.lzCard, 0.957 - 0.891, new Vec3(0, 0, -2.4), "linear", false);
        s = TweenTool.moveBy(this.lzCard, 0.957 - 0.891, new Vec3(-2, 10, 0), "linear", false);
        n = TweenTool.parallel(this.lzCard, false, null, a, s);
        h = TweenTool.rotateBy(this.lzCard, 0.99 - 0.957, new Vec3(0, 0, 2.4), "linear", false);
        l = TweenTool.moveBy(this.lzCard, 0.99 - 0.957, new Vec3(2, -6, 0), "linear", false);
        c = TweenTool.parallel(this.lzCard, false, null, h, l);
        let y = TweenTool.sequence(this.lzCard, false, null, n, c);
        u.start();
        m.start();
        g.start();
        y.start();
    }
    huPaiQiPaiduiAnim(e = true) {
        this.qipaiCards.length;
        let t = this.getCardNode(), i = t.getComponent("RummyCard"), a = this.qipaiCards[this.qipaiCards.length - 2];
        i.init(a, false);
        i.openCard();
        i.showLaiziFlag(this.isShowLaiziColor(a));
        t.setScale(this.outcardScale);
        t.setPosition(this.qipaiPoint);
        t.active = true;
        this.hupai_node.addChild(t);
        this.hupaiCardVec.push(t);
        let s = this.getCardNode();
        i = s.getComponent("RummyCard");
        a = this.qipaiCards[this.qipaiCards.length - 1];
        i.init(a, false);
        i.openCard();
        i.showLaiziFlag(this.isShowLaiziColor(a));
        s.setScale(this.outcardScale);
        s.setPosition(this.qipaiPoint);
        s.active = true;
        this.hupai_node.addChild(s);
        this.hupaiCardVec.push(s);
        let o = TweenTool.rotateTo(s, 0.957 - 0.891, new Vec3(0, 0, 8.4), "linear", false), d = TweenTool.moveBy(s, 0.957 - 0.891, new Vec3(2, 20, 0), "linear", false), n = this.outcardScale.x + 0.05 * this.outcardScale.x, h = TweenTool.scaleTo(s, 0.957 - 0.891, new Vec3(n, n, 0), "linear", false), l = TweenTool.parallel(s, false, null, o, d, h), c = TweenTool.rotateTo(s, 0.99 - 0.957, new Vec3(0, 0, -1.2), "linear", false), u = TweenTool.moveBy(s, 0.957 - 0.891, new Vec3(5.6, -8.87, 0), "linear", false), p = TweenTool.parallel(s, false, null, c, u);
        TweenTool.sequence(s, false, null, l, p).start();
    }
    setCallBack(e) {
        this.func_cb = e;
    }
    startGuideStep() {
        this._nGuideStep = 0;
        this.startNextStep();
    }
    startNextStep() {
        this._nGuideStep += 1;
        for (let e = 1; e <= 12; e++) {
            this.root_node.getChildByName("step" + e).active = false;
        }
        if (this.card_root.active = this._nGuideStep > 1, this.playArrowAnim(RummyCardConstant.arrowAnimType.mopai, false, false), this.playArrowAnim(RummyCardConstant.arrowAnimType.finish, false, false), this.playArrowAnim(RummyCardConstant.arrowAnimType.qipai, false, false), this.hideGuideClickAnim(), this.group_btn.active = false, this.discard_btn.active = false, this.finish_btn.active = false, this._nGuideStep == RummyCardConstant.NewPlayer_Step.EnterRummy) {
            this.root_node.getChildByName("step1").active = true;
            Utils.shared().StartNodeShowAnim(this.root_node.getChildByName("step1"));
        }
        else if (this._nGuideStep == RummyCardConstant.NewPlayer_Step.FaPai) {
            this.node.getChildByName("mask").active = false;
            this.beginFaPaiWithAnim();
            TweenTool.delayAct(this.node, (() => {
                this.func_cb("updateCloseNum", this.nCloseNum);
                this.func_cb("updateOpenNum", this.nOpenNum);
                this.func_cb("updateRoundNum", this.nRoundNum);
            }), 2.35, true);
        }
        else if (this._nGuideStep == RummyCardConstant.NewPlayer_Step.MoPai) {
            this.playArrowAnim(RummyCardConstant.arrowAnimType.mopai, true, true);
            this.playArrowAnim(RummyCardConstant.arrowAnimType.qipai, true, true);
            this.node.getChildByName("mask").active = false;
            this.card_root.getChildByName("mask").active = true;
            this.card_root.getChildByName("mask").setSiblingIndex(100);
            this.card_root.getChildByName("paidui_node").setSiblingIndex(1000);
            this.card_root.getChildByName("qipai_node").setSiblingIndex(1000);
            this.card_root.getChildByName("anim_node").setSiblingIndex(1000);
            this.card_root.getChildByName("hupai_node").setSiblingIndex(1001);
            this.root_node.getChildByName("step3").active = true;
            Utils.shared().StartNodeShowAnim(this.root_node.getChildByName("step3"));
            this.paidui_btn.active = true;
            this.qipai_btn.active = true;
            this.nRoundNum = this.nRoundNum + 1;
            this.func_cb("updateRoundNum", this.nRoundNum);
        }
        else if (this._nGuideStep == RummyCardConstant.NewPlayer_Step.ClickPureSequenceCards) {
            this.setCardMaskShow(this._nGuideStep);
            this.card_root.getChildByName("shoupai").setSiblingIndex(1000);
            this.root_node.getChildByName("step4").active = true;
            Utils.shared().StartNodeShowAnim(this.root_node.getChildByName("step4"));
            for (let e = 1; e < 6; e++) {
                let t = this.root_node.getChildByName("step4").getChildByName("icon" + e);
                0 == i18nMgr.shared().language ? t.setPosition(v3(52 * e - 127, 35)) : 1 == i18nMgr.shared().language && t.setPosition(v3(52 * e - 80, 35));
            }
        }
        else if (this._nGuideStep == RummyCardConstant.NewPlayer_Step.ClickGroupBtn) {
            this.group_btn.active = true;
            this.cardClickPositions = [];
            this.cardClickPositions.push(this.group_btn.getPosition());
            this.handAnimStep = -1;
            this.startGuideClickCardAnim();
        }
        else if (this._nGuideStep == RummyCardConstant.NewPlayer_Step.SelestTask1) {
            this.setTaskPanelShow(true);
        }
        else if (this._nGuideStep == RummyCardConstant.NewPlayer_Step.Discard) {
            this.setCardMaskShow(this._nGuideStep);
            this.root_node.getChildByName("step5").active = true;
            Utils.shared().StartNodeShowAnim(this.root_node.getChildByName("step5"));
            this.discard_btn.active = true;
            this.discard_btn.getComponent(Button).interactable = false;
        }
        else if (this._nGuideStep == RummyCardConstant.NewPlayer_Step.WaitOtherOpate) {
            this.cleanCardMask();
            this.root_node.getChildByName("step6").getChildByName("tips").getComponent(Label).string = i18nMgr.shared().getValueByKey("newPlayer_guide.wait_play");
            this.root_node.getChildByName("step6").active = true;
            this.node.getChildByName("mask").active = false;
            this.card_root.getChildByName("mask").active = false;
            this.card_root.getChildByName("mask").setSiblingIndex(1);
            this.func_cb("wait_moPai");
            TweenTool.delayAct(this.root_node, (() => {
                this.func_cb("stopTimer");
                this.getMoPai(1, 0, 0, []);
            }), 3, true);
        }
        else if (this._nGuideStep == RummyCardConstant.NewPlayer_Step.MoPai_PaiDui) {
            this.cleanCardMask();
            this.root_node.getChildByName("step7").active = true;
            Utils.shared().StartNodeShowAnim(this.root_node.getChildByName("step7"));
            this.playArrowAnim(RummyCardConstant.arrowAnimType.mopai, true, true);
            this.node.getChildByName("mask").active = false;
            this.card_root.getChildByName("mask").active = true;
            this.card_root.getChildByName("mask").setSiblingIndex(100);
            this.card_root.getChildByName("paidui_node").setSiblingIndex(1000);
            this.card_root.getChildByName("qipai_node").setSiblingIndex(1);
            this.card_root.getChildByName("hupai_node").setSiblingIndex(1001);
            this.card_root.getChildByName("anim_node").setSiblingIndex(1000);
            this.paidui_btn.active = true;
            this.nRoundNum = this.nRoundNum + 1;
            this.func_cb("updateRoundNum", this.nRoundNum);
        }
        else if (this._nGuideStep == RummyCardConstant.NewPlayer_Step.ClickSequenceCards) {
            let e;
            this.setCardMaskShow(this._nGuideStep);
            this.root_node.getChildByName("step11").active = true;
            Utils.shared().StartNodeShowAnim(this.root_node.getChildByName("step11"));
            this.discard_btn.active = true;
            this.discard_btn.getComponent(Button).interactable = false;
            for (let t = 1; t < 6; t++) {
                e = this.root_node.getChildByName("step11").getChildByName("icon" + t);
                0 == i18nMgr.shared().language ? e.setPosition(v3(52 * (t - 1) - 47, 35)) : 1 == i18nMgr.shared().language && e.setPosition(v3(52 * (t - 1) - 30, 35));
            }
        }
        else {
            this._nGuideStep == RummyCardConstant.NewPlayer_Step.ClickGroupBtn2 ? (this.group_btn.active = true, this.cardClickPositions = [], this.cardClickPositions.push(this.group_btn.getPosition()), this.handAnimStep = -1, this.startGuideClickCardAnim()) : this._nGuideStep == RummyCardConstant.NewPlayer_Step.SelestTask2 ? this.setTaskPanelShow(true) : this._nGuideStep == RummyCardConstant.NewPlayer_Step.Discard2 ? (this.setCardMaskShow(this._nGuideStep), this.root_node.getChildByName("step10").active = true, Utils.shared().StartNodeShowAnim(this.root_node.getChildByName("step10")), this.discard_btn.active = true, this.discard_btn.getComponent(Button).interactable = false) : this._nGuideStep == RummyCardConstant.NewPlayer_Step.WaitOtherOpate2 ? (this.cleanCardMask(), this.root_node.getChildByName("step6").getChildByName("tips").getComponent(Label).string = i18nMgr.shared().getValueByKey("newPlayer_guide.wait_play"), this.root_node.getChildByName("step6").active = true, this.node.getChildByName("mask").active = false, this.card_root.getChildByName("mask").active = false, this.card_root.getChildByName("mask").setSiblingIndex(1), this.func_cb("wait_moPai"), TweenTool.delayAct(this.root_node, (() => {
                this.func_cb("stopTimer");
                this.getMoPai(1, 0, 0, []);
            }), 3, true)) : this._nGuideStep == RummyCardConstant.NewPlayer_Step.MoPai_QiPai ? (this.cleanCardMask(), this.root_node.getChildByName("step8").active = true, Utils.shared().StartNodeShowAnim(this.root_node.getChildByName("step8")), this.playArrowAnim(RummyCardConstant.arrowAnimType.qipai, true, true), this.node.getChildByName("mask").active = false, this.card_root.getChildByName("mask").active = true, this.card_root.getChildByName("mask").setSiblingIndex(100), this.card_root.getChildByName("paidui_node").setSiblingIndex(1), this.card_root.getChildByName("qipai_node").setSiblingIndex(1000), this.card_root.getChildByName("hupai_node").setSiblingIndex(1001), this.card_root.getChildByName("anim_node").setSiblingIndex(1000), this.qipai_btn.active = true, this.nRoundNum = this.nRoundNum + 1, this.func_cb("updateRoundNum", this.nRoundNum)) : this._nGuideStep == RummyCardConstant.NewPlayer_Step.ClickSetCards ? (this.root_node.getChildByName("step12").active = true, Utils.shared().StartNodeShowAnim(this.root_node.getChildByName("step12")), this.setCardMaskShow(this._nGuideStep)) : this._nGuideStep == RummyCardConstant.NewPlayer_Step.ClickGroupBtn3 ? (this.group_btn.active = true, this.cardClickPositions = [], this.cardClickPositions.push(this.group_btn.getPosition()), this.handAnimStep = -1, this.startGuideClickCardAnim()) : this._nGuideStep == RummyCardConstant.NewPlayer_Step.Declare ? (this.root_node.getChildByName("step9").active = true, Utils.shared().StartNodeShowAnim(this.root_node.getChildByName("step9")), this.setCardMaskShow(this._nGuideStep)) : this._nGuideStep == RummyCardConstant.NewPlayer_Step.SelestTask3 ? this.setTaskPanelShow(true) : this._nGuideStep == RummyCardConstant.NewPlayer_Step.Finish && this.requestComplateGuide();
        }
    }
    requestComplateGuide() {
        User.shared().data.beginner_guide && 1 == User.shared().data.beginner_guide.practice_status ? this.showComplateGuideTips() : (Utils.shared().showLoading(20, false), HttpManager.shared().doGetNewPlayerGuideFinish(2, ((e, t, i) => {
            if (Utils.shared().hideLoading(), 200 == i) {
                try {
                    let e = ToolUtils.parseJson(t);
                    0 == e.ret ? (ToolUtils.in_isGuideRoom = 0, User.shared().data.beginner_guide.practice_status = 1, ToolUtils.isObjValid(this.node) && (User.shared().data.abtest_gotype ? 1 == User.shared().data.abtest_gotype ? this.showJumpToPracticeGameTips() : 2 == User.shared().data.abtest_gotype && this.showJumpToCashGameTips() : this.showJumpToPracticeGameTips())) : this.tipsNetWorkErr(e.desc);
                }
                catch (e) {
                    TLog.printError("doGetNewPlayerGuideFinish err:", e.toString());
                    this.tipsNetWorkErr();
                }
            }
            else {
                this.tipsNetWorkErr();
            }
        })));
    }
    tipsNetWorkErr(e) {
        0 == (e = ToolUtils.isSafeString(e)).length && (e = i18nMgr.shared().getValueByKey("utlis.text24"));
        Utils.shared().showCommomDialog(e, i18nMgr.shared().getValueByKey("gameRummy_notice_Pop.notice"), (e => {
            1 == e && this.requestComplateGuide();
        }), false, ToolUtils.getIsNormalDirection(), i18nMgr.shared().getValueByKey("utlis.retry"), null, true, this.node);
    }
    cleanCardMask() {
        for (let e = 0, t = this.cardViewVec.length; e < t; e++) {
            this.cardViewVec[e].getComponent(RummyCard).setMask(false);
        }
    }
    setCardMaskShow(e) {
        this.node.getChildByName("mask").active = false;
        this.card_root.getChildByName("mask").active = true;
        this.card_root.getChildByName("mask").setSiblingIndex(1);
        for (let e = 0, t = this.cardViewVec.length; e < t; e++) {
            this.cardViewVec[e].getComponent(RummyCard).setMask(true);
        }
        this.cardClickPositions = [];
        var t = 25, i = 60;
        let a = new Vec3;
        if (e == RummyCardConstant.NewPlayer_Step.ClickPureSequenceCards) {
            if (this.cardViewVec[0]) {
                this.cardViewVec[0].getComponent(RummyCard).setMask(false);
                this.cardViewVec[0].getPosition(a);
                this.cardClickPositions.push(new Vec3(a.x - t, a.y + i, a.z));
                let e = this.cardViewVec[0].addComponent(Button), s = new EventHandler;
                s.component = "RummyNewPlayerGuide";
                s.handler = "onButtonClick";
                s.customEventData = "card0";
                s.target = this.node;
                e.clickEvents.push(s);
            }
            if (this.cardViewVec[1]) {
                this.cardViewVec[1].getComponent(RummyCard).setMask(false);
                this.cardViewVec[1].getPosition(a);
                this.cardClickPositions.push(new Vec3(a.x - t, a.y + i, a.z));
                let e = this.cardViewVec[1].addComponent(Button), s = new EventHandler;
                s.component = "RummyNewPlayerGuide";
                s.handler = "onButtonClick";
                s.customEventData = "card1";
                s.target = this.node;
                e.clickEvents.push(s);
            }
            if (this.cardViewVec[2]) {
                this.cardViewVec[2].getComponent(RummyCard).setMask(false);
                this.cardViewVec[2].getPosition(a);
                this.cardClickPositions.push(new Vec3(a.x - t, a.y + i, a.z));
                let e = this.cardViewVec[2].addComponent(Button), s = new EventHandler;
                s.component = "RummyNewPlayerGuide";
                s.handler = "onButtonClick";
                s.customEventData = "card2";
                s.target = this.node;
                e.clickEvents.push(s);
            }
            if (this.cardViewVec[3]) {
                this.cardViewVec[3].getComponent(RummyCard).setMask(false);
                this.cardViewVec[3].getPosition(a);
                this.cardClickPositions.push(new Vec3(a.x - t, a.y + i, a.z));
                let e = this.cardViewVec[3].addComponent(Button), s = new EventHandler;
                s.component = "RummyNewPlayerGuide";
                s.handler = "onButtonClick";
                s.customEventData = "card3";
                s.target = this.node;
                e.clickEvents.push(s);
            }
            if (this.cardViewVec[13]) {
                this.cardViewVec[13].getComponent(RummyCard).setMask(false);
                this.cardViewVec[13].getPosition(a);
                this.cardClickPositions.push(new Vec3(a.x, a.y + i, a.z));
                let e = this.cardViewVec[13].addComponent(Button), t = new EventHandler;
                t.component = "RummyNewPlayerGuide";
                t.handler = "onButtonClick";
                t.customEventData = "card13";
                t.target = this.node;
                e.clickEvents.push(t);
            }
        }
        else if (e == RummyCardConstant.NewPlayer_Step.Discard) {
            if (this.cardViewVec[11]) {
                this.cardViewVec[11].getComponent(RummyCard).setMask(false);
                this.cardViewVec[11].getPosition(a);
                this.cardClickPositions.push(new Vec3(a.x - t, a.y + i, a.z));
                let e = this.cardViewVec[11].addComponent(Button), s = new EventHandler;
                s.component = "RummyNewPlayerGuide";
                s.handler = "onButtonClick";
                s.customEventData = "card11";
                s.target = this.node;
                e.clickEvents.push(s);
            }
        }
        else if (e == RummyCardConstant.NewPlayer_Step.Discard2) {
            if (this.cardViewVec[13]) {
                this.cardViewVec[13].getComponent(RummyCard).setMask(false);
                this.cardViewVec[13].getPosition(a);
                this.cardClickPositions.push(new Vec3(a.x, a.y + i, a.z));
                let e = this.cardViewVec[13].addComponent(Button), t = new EventHandler;
                t.component = "RummyNewPlayerGuide";
                t.handler = "onButtonClick";
                t.customEventData = "card13";
                t.target = this.node;
                e.clickEvents.push(t);
            }
        }
        else if (e == RummyCardConstant.NewPlayer_Step.ClickSequenceCards) {
            if (this.cardViewVec[6]) {
                this.cardViewVec[6].getComponent(RummyCard).setMask(false);
                this.cardViewVec[6].getPosition(a);
                this.cardClickPositions.push(new Vec3(a.x - t, a.y + i, a.z));
                let e = this.cardViewVec[6].addComponent(Button), s = new EventHandler;
                s.component = "RummyNewPlayerGuide";
                s.handler = "onButtonClick";
                s.customEventData = "card6";
                s.target = this.node;
                e.clickEvents.push(s);
            }
            if (this.cardViewVec[7]) {
                this.cardViewVec[7].getComponent(RummyCard).setMask(false);
                this.cardViewVec[7].getPosition(a);
                this.cardClickPositions.push(new Vec3(a.x - t, a.y + i, a.z));
                let e = this.cardViewVec[7].addComponent(Button), s = new EventHandler;
                s.component = "RummyNewPlayerGuide";
                s.handler = "onButtonClick";
                s.customEventData = "card7";
                s.target = this.node;
                e.clickEvents.push(s);
            }
            if (this.cardViewVec[8]) {
                this.cardViewVec[8].getComponent(RummyCard).setMask(false);
                this.cardViewVec[8].getPosition(a);
                this.cardClickPositions.push(new Vec3(a.x - t, a.y + i, a.z));
                let e = this.cardViewVec[8].addComponent(Button), s = new EventHandler;
                s.component = "RummyNewPlayerGuide";
                s.handler = "onButtonClick";
                s.customEventData = "card8";
                s.target = this.node;
                e.clickEvents.push(s);
            }
            if (this.cardViewVec[9]) {
                this.cardViewVec[9].getComponent(RummyCard).setMask(false);
                this.cardViewVec[9].getPosition(a);
                this.cardClickPositions.push(new Vec3(a.x, a.y + i, a.z));
                let e = this.cardViewVec[9].addComponent(Button), t = new EventHandler;
                t.component = "RummyNewPlayerGuide";
                t.handler = "onButtonClick";
                t.customEventData = "card9";
                t.target = this.node;
                e.clickEvents.push(t);
            }
            if (this.cardViewVec[13]) {
                this.cardViewVec[13].getComponent(RummyCard).setMask(false);
                this.cardViewVec[13].getPosition(a);
                this.cardClickPositions.push(new Vec3(a.x, a.y + i, a.z));
                let e = this.cardViewVec[13].addComponent(Button), t = new EventHandler;
                t.component = "RummyNewPlayerGuide";
                t.handler = "onButtonClick";
                t.customEventData = "card13";
                t.target = this.node;
                e.clickEvents.push(t);
            }
        }
        else if (e == RummyCardConstant.NewPlayer_Step.ClickSetCards) {
            if (this.cardViewVec[10]) {
                this.cardViewVec[10].getComponent(RummyCard).setMask(false);
                this.cardViewVec[10].getPosition(a);
                this.cardClickPositions.push(new Vec3(a.x, a.y + i, a.z));
                let e = this.cardViewVec[10].addComponent(Button), t = new EventHandler;
                t.component = "RummyNewPlayerGuide";
                t.handler = "onButtonClick";
                t.customEventData = "card10";
                t.target = this.node;
                e.clickEvents.push(t);
            }
            if (this.cardViewVec[11]) {
                this.cardViewVec[11].getComponent(RummyCard).setMask(false);
                this.cardViewVec[11].getPosition(a);
                this.cardClickPositions.push(new Vec3(a.x - t, a.y + i, a.z));
                let e = this.cardViewVec[11].addComponent(Button), s = new EventHandler;
                s.component = "RummyNewPlayerGuide";
                s.handler = "onButtonClick";
                s.customEventData = "card11";
                s.target = this.node;
                e.clickEvents.push(s);
            }
            if (this.cardViewVec[13]) {
                this.cardViewVec[13].getComponent(RummyCard).setMask(false);
                this.cardViewVec[13].getPosition(a);
                this.cardClickPositions.push(new Vec3(a.x, a.y + i, a.z));
                let e = this.cardViewVec[13].addComponent(Button), t = new EventHandler;
                t.component = "RummyNewPlayerGuide";
                t.handler = "onButtonClick";
                t.customEventData = "card13";
                t.target = this.node;
                e.clickEvents.push(t);
            }
        }
        else if (e == RummyCardConstant.NewPlayer_Step.Declare && this.cardViewVec[13]) {
            this.cardViewVec[13].getComponent(RummyCard).setMask(false);
            this.cardViewVec[13].getPosition(a);
            this.cardClickPositions.push(new Vec3(a.x, a.y + i, a.z));
            let e = this.cardViewVec[13].addComponent(Button), t = new EventHandler;
            t.component = "RummyNewPlayerGuide";
            t.handler = "onButtonClick";
            t.customEventData = "card13";
            t.target = this.node;
            e.clickEvents.push(t);
        }
        this.handAnimStep = -1;
        this.startGuideClickCardAnim();
    }
    startGuideClickCardAnim() {
        0 != this.cardClickPositions.length ? (this.handAnimStep += 1, this.cardClickPositions[this.handAnimStep] || (this.handAnimStep = 0), this.hand_anim.setPosition(this.cardClickPositions[this.handAnimStep]), this.hand_anim.active = true, TweenTool.stopNodeAction(this.node), TweenTool.delayAct(this.node, this.startGuideClickCardAnim.bind(this), 2, true)) : TweenTool.stopNodeAction(this.node);
    }
    hideGuideClickAnim() {
        TweenTool.stopNodeAction(this.node);
        this.hand_anim.active = false;
    }
    playArrowAnim(e, t, i = false) {
        e == RummyCardConstant.arrowAnimType.mopai ? this.arrow_anim_nodes[0].active = false : e == RummyCardConstant.arrowAnimType.finish ? this.arrow_anim_nodes[1].active = false : e == RummyCardConstant.arrowAnimType.qipai && (this.arrow_anim_nodes[2].active = false, this.arrow_anim_nodes[3].active = false);
        t && (e == RummyCardConstant.arrowAnimType.mopai ? this.arrow_anim_nodes[0].active = true : e == RummyCardConstant.arrowAnimType.finish ? this.arrow_anim_nodes[1].active = true : e == RummyCardConstant.arrowAnimType.qipai && (i ? this.arrow_anim_nodes[2].active = true : this.arrow_anim_nodes[3].active = true));
    }
    onFaPaiAnimFinished() {
        this.node.getChildByName("mask").active = false;
        this.card_root.getChildByName("mask").active = true;
        this.card_root.getChildByName("mask").setSiblingIndex(100);
        this.card_root.getChildByName("paidui_node").setSiblingIndex(1000);
        this.root_node.getChildByName("step2").active = true;
        Utils.shared().StartNodeShowAnim(this.root_node.getChildByName("step2"));
    }
    openCardCallback2(e) {
        if (e) {
            let t = e.getComponent("RummyCard").getCardTag();
            this.openCardCallback3(e);
            e.active = true;
            TweenTool.scaleTo(e, 0.02 + (t - 1) / 30, new Vec3(-this.cardScale.x, this.cardScale.y, this.cardScale.z), null, true);
        }
    }
    openCardCallback3(e) {
        if (e) {
            let t = e.getComponent("RummyCard");
            t.openCard();
            t.getCardTag() == this.cardViewVec.length - 1 && this.showGroupCards(this.myGroupcardValueVec, true);
        }
    }
    showGroupCards(e, t) {
        this.myGroupcardValueVec = e;
        let i = e.length, a = this.cardViewVec.length, s = 2 * RummyCardConstant.cebianW, o = (i - 1) * this.cardSpaceGroup, d = i * this.cardWidth, n = (RummyCardConstant.ScreenWidth - s - o - d) / (1 * (a - i)), h = this.middlePosY, l = this.cardStartPosX, c = this.cardWidth + this.cardSpaceGroup - n;
        this.spXpositionDeq = [];
        let u, p, m, C, g = 0;
        for (let t = 0; t < i; t++) {
            p = e[t].cardVec;
            for (let e = 0; e < p.length; e++) {
                u = l + n * g + t * c;
                this.cardsPostions.push(new Vec3(u, h));
                g += 1;
                this.spXpositionDeq.push(u);
            }
        }
        if (this.cardValueVec.length > 0) {
            this.cardValueVec = [];
            for (let t = 0; t < i; t++) {
                p = e[t].cardVec;
                for (let e = 0; e < p.length; e++) {
                    this.cardValueVec.push(p[e]);
                }
            }
        }
        for (let e = 0, t = this.cardViewVec.length; e < t; e++) {
            m = this.cardViewVec[e];
            C = m.getComponent("RummyCard");
            C.setCardTag(e);
            C.changeCardStatus(false);
            TweenTool.moveTo(m, 0.2, new Vec3(this.spXpositionDeq[e], h, 0), null, true, (() => {
                this.refreshGroupInfo(m);
            }));
        }
        this.refreshAllGroupInfo();
        this.func_cb("updateMyScore", RummyCardConstant.NewPlayer_HandScore1);
    }
    refreshAllGroupInfo() {
        let e = this.myGroupcardValueVec.length, t = this.cardViewVec.length, i = 2 * RummyCardConstant.cebianW, a = (e - 1) * this.cardSpaceGroup, s = e * this.cardWidth, o = (RummyCardConstant.ScreenWidth - i - a - s) / (1 * (t - e));
        for (let e = 0, t = this.groupFlags.length; e < t; e++) {
            ToolUtils.isObjValid(this.groupFlags[e]) && this.groupFlags[e].destroy();
        }
        this.groupFlags = [];
        let d, n, h, l, p, m, g, _, V, N, f, k, b, v, B, G = 0;
        for (let t = 0; t < e; t++) {
            d = this.myGroupcardValueVec[t].cardVec;
            n = instantiate(this.gropFlogModle);
            n && (_ = n.getChildByName("grop_flag"), V = n.getChildByName("btn"), V.active = false, B = "Add_Btn" + t, V.getComponent(Button).clickEvents[0].customEventData = B, B = "left_btn" + t, N = n.getChildByName("left_btn"), N.getComponent(Button).clickEvents[0].customEventData = B, m = true, g = true, B = "right_btn" + t, f = n.getChildByName("right_btn"), f.getComponent(Button).clickEvents[0].customEventData = B, 0 == t ? m = false : t == e - 1 && (g = false), k = _.getChildByName("text"), n.active = true, _.active = true, d.length < 2 || e < 2 ? k.active = false : k.active = true, Utils.shared().setStr(k, this.myGroupcardValueVec[t].desc), b = N.getChildByName("Sprite"), v = f.getChildByName("Sprite"), 0 == this.myGroupcardValueVec[t].color ? (_.getChildByName("flag").getComponent(Sprite).spriteFrame = this.card_kuang_anim[0], k.getComponent(Label).color = RummyCardConstant.White_color) : 2 == this.myGroupcardValueVec[t].color ? (_.getChildByName("flag").getComponent(Sprite).spriteFrame = this.card_kuang_anim[1], k.getComponent(Label).color = RummyCardConstant.White_color) : 3 == this.myGroupcardValueVec[t].color && (_.getChildByName("flag").getComponent(Sprite).spriteFrame = this.card_kuang_anim[2], k.getComponent(Label).color = RummyCardConstant.White_color), h = (d.length - 1) * o + this.cardWidth + 15, l = this.spXpositionDeq[G], p = Math.floor(d.length / 2) + G, l = d.length % 2 == 0 ? this.spXpositionDeq[p] - o / 2 : this.spXpositionDeq[p], k.getComponent(Label).fontSize = 24, n.getComponent(UITransform).setContentSize(size(h, RummyCardConstant.GroupFlagHeight)), _.getComponent(UITransform).setContentSize(size(h, RummyCardConstant.GroupFlagHeight)), n.setPosition(new Vec3(l, RummyCardConstant.GroupFlagPosY, 0)), n.setSiblingIndex(30 + t), N.setPosition(new Vec3(-h / 2 + 20, 3, 0)), f.setPosition(new Vec3(h / 2 - 20, 3, 0)), this.shoupaiLayout.addChild(n), this.groupFlags.push(n), V && (V.active = false), 1 === this.myGroupcardValueVec.length && (m = false, g = false), m = false, g = false, b.active = false, v.active = false, N.active = m, f.active = g);
            for (let e = 0, t = d.length; e < t; e++) {
                G += 1;
            }
        }
    }
    refreshGroupInfo(e) {
        if (e) {
            let t = e.getComponent("RummyCard").getCardTag();
            e.x = this.spXpositionDeq[t];
            t == this.spXpositionDeq.length - 1 && this.showFirstCardView();
        }
    }
    showFirstCardView() {
        if (this.paiduiCardVec.length > 0) {
            let e = this.paiduiCardVec[0];
            e.getComponent("RummyCard").setCardValue(RummyCardConstant.NewPlayer_LaiziCard);
            e.active = true;
            let t = TweenTool.moveTo(e, 0.2, this.qipaiPoint), i = TweenTool.scaleTo(e, 0.1, new Vec3(-this.outcardScale.x, this.outcardScale.y)), a = TweenTool.scaleTo(e, 0.1, new Vec3(this.outcardScale.x, this.outcardScale.y)), s = TweenTool.sequence(e, false, null, i, a);
            TweenTool.parallel(e, true, (() => {
                this.qipaiOpenCardCallback2(e);
            }), t, s);
        }
    }
    qipaiOpenCardCallback2(e) {
        if (e) {
            let t = e.getComponent("RummyCard");
            t.openCard();
            e.active = false;
            for (let e = 0, i = this.paiduiCardVec.length; e < i; e++) {
                let i = this.paiduiCardVec[e];
                ToolUtils.isObjValid(i) && (t = i.getComponent("RummyCard"), t.setCardTag(e), i.setPosition(this.finishPoint));
            }
            let i = instantiate(this.cardPrefab);
            t = i.getComponent("RummyCard");
            t.init(RummyCardConstant.NewPlayer_MoPai1, false);
            t.openCard();
            t.showLaiziFlag(this.isShowLaiziColor(RummyCardConstant.NewPlayer_MoPai1));
            i.setScale(this.outcardScale);
            i.setPosition(this.qipaiPoint);
            this.qipai_node.addChild(i);
            this.qipaiCards.push(i);
            this.showLaiziCard();
        }
    }
    showLaiziCard() {
        if (this.playEffectByName("rummyFlip"), this.paiduiCardVec.length > 0) {
            for (let e = 0, t = this.paiduiCardVec.length; e < t; e++) {
                let t = this.paiduiCardVec[e];
                t.active = true;
                TweenTool.moveTo(t, 0.3, this.paiduiPoint, null, true, (() => {
                    this.paiduiMoveCallBack(t);
                }));
            }
        }
    }
    paiduiMoveCallBack(e) {
        if (ToolUtils.isObjValid(e)) {
            e.setPosition(this.paiduiPoint);
            e.getComponent("RummyCard").getCardTag() != this.paiduiCardVec.length - 1 || this.is_fapai_over || (this.is_fapai_over = true, TweenTool.delayAct(this.paidui_node, (() => {
                this.lzCardReset(e);
            }), 0.5, true));
        }
    }
    lzCardReset(e) {
        if (e) {
            let e, t;
            for (let t = 0, i = this.paiduiCardVec.length; t < i; t++) {
                e = this.paiduiCardVec[t];
                ToolUtils.isObjValid(e) && (e.setPosition(this.paiduiPoint), e.active = true);
            }
            if (this.paiduiCardVec.length > 0) {
                ToolUtils.isObjValid(this.lzCard) || (this.lzCard = instantiate(this.cardPrefab), t = this.lzCard.getComponent("RummyCard"), t.init(RummyCardConstant.NewPlayer_LaiziCard, false), t.openCard(), t.showLaiziFlag(this.isShowLaiziColor(RummyCardConstant.NewPlayer_LaiziCard), true), this.lzCard.setScale(this.outcardScale), this.lzCard.setPosition(this.laiziPoint), this.lzCard.angle = 90, this.lzCard.active = true, this.paidui_node.insertChild(this.lzCard, 0));
                for (let e = 0, i = this.paiduiCardVec.length; e < i; e++) {
                    this.paiduiCardVec[e].setSiblingIndex(e + 1);
                    this.paiduiCardVec[e].active = true;
                    t = this.paiduiCardVec[e].getComponent("RummyCard");
                    t.changeCardToBack();
                }
                this.lzCard.setSiblingIndex(0);
                for (let t = 0, i = this.paiduiCardVec.length; t < i; t++) {
                    e = this.paiduiCardVec[t];
                    e.getSiblingIndex();
                    this.lzCard.getSiblingIndex();
                }
            }
            for (let e = 0, i = this.cardViewVec.length; e < i; e++) {
                t = this.cardViewVec[e].getComponent("RummyCard");
                t.openCard();
                t.showLaiziFlag(this.isShowLaiziColor(t.mCardValue));
            }
            this.onFaPaiAnimFinished();
        }
    }
    isShowLaiziColor(e) {
        if (78 == RummyCardConstant.NewPlayer_LaiziCard || 79 == RummyCardConstant.NewPlayer_LaiziCard) {
            if (78 == e || 79 == e || 1 == e || 17 == e || 33 == e || 49 == e) {
                return true;
            }
        }
        else {
            if (78 == e || 79 == e) {
                return true;
            }
            if (RummyCardConstant.NewPlayer_LaiziCard % 16 == e % 16) {
                return true;
            }
        }
        return false;
    }
    getMoPai(e, t, i, a) {
        this.mopaiPos = e;
        this.mpType = t;
        this.playEffectByName("rummyPickDiscard");
        0 == e && (this.myGroupcardValueVec = a);
        let s = null, o = 1;
        if (0 == t) {
            if (0 !== i && (o = i), ToolUtils.isObjValid(this.lzCard) && this.lzCard.setSiblingIndex(0), 0 === this.paiduiCardVec.length) {
                let e = instantiate(this.cardPrefab);
                e.getComponent("RummyCard").init(1, true);
                e.setScale(this.outcardScale);
                e.setPosition(this.paiduiPoint);
                this.paidui_node.addChild(e);
                this.paiduiCardVec.push(e);
                e.setSiblingIndex(this.paiduiCardVec.length + 1);
            }
            s = this.paiduiCardVec[this.paiduiCardVec.length - 1];
            this.paiduiCardVec.length >= 2 && (this.paiduiCardVec[this.paiduiCardVec.length - 2].active = true);
            this.nCloseNum = this.nCloseNum - 1;
            this.func_cb("updateCloseNum", this.nCloseNum);
        }
        else if (1 == t) {
            if (0 == this.qipaiCards.length) {
                let e = instantiate(this.cardPrefab), t = e.getComponent("RummyCard");
                t.init(i, false);
                t.showLaiziFlag(this.isShowLaiziColor(i));
                e.setScale(this.outcardScale);
                e.setPosition(this.qipaiPoint);
                e.setSiblingIndex(0);
                this.qipai_node.addChild(e);
                this.qipaiCards.push(e);
                o = i;
            }
            if (this.qipaiCards.length > 0) {
                s = this.qipaiCards[this.qipaiCards.length - 1];
                let e = s.getComponent("RummyCard");
                e.mCardValue != i && e.setCardValue(i);
                for (let e = 0, t = this.qipaiCards.length; e < t - 1; e++) {
                    this.qipaiCards[e].setSiblingIndex(e);
                }
                o = i;
            }
            this.nOpenNum = this.nOpenNum - 1;
            this.func_cb("updateOpenNum", this.nOpenNum);
        }
        s.setSiblingIndex(2000);
        s.active = true;
        let d = s.getComponent("RummyCard"), n = new Vec3(this.seatPosVec[e].x, this.seatPosVec[e].y + 14), h = this.mpScale, l = 0.2;
        if (0 == e) {
            let e = new Vec3;
            s.getPosition(e);
            s.active = false;
            ToolUtils.isObjValid(s) && s.destroy();
            let t = instantiate(this.cardPrefab);
            d = t.getComponent("RummyCard");
            d.init(o, false);
            d.showLaiziFlag(this.isShowLaiziColor(o));
            d.setMask(false);
            t.setScale(this.outcardScale);
            t.setPosition(e);
            this.shoupaiLayout.insertChild(t, 2000);
            s = t;
            d.openCard();
            d.setCardValue(o);
            d.showLaiziFlag(this.isShowLaiziColor(o));
            let i = RummyCardConstant.ScreenWidth / 2;
            this.spXpositionDeq.length > 0 && (i = this.spXpositionDeq[this.spXpositionDeq.length - 1]);
            let c = a[a.length - 1].cardVec, u = 52, p = -463 - this._diffY + u * c.length;
            p = this.middlePosY;
            n = new Vec3(i, p);
            h = this.cardScale;
            l = 0.3;
        }
        if (s) {
            s.active = true;
            let t = TweenTool.moveTo(s, l, n), i = TweenTool.scaleTo(s, l, h), a = TweenTool.parallel(s, false, null, t, i), o = 0 != e ? 0.75 : 0;
            0 == this.mpType ? this.paiduiCardVec.pop() : 1 == this.mpType && this.qipaiCards.pop();
            let d = TweenTool.delayAct(this.delay_node, (() => {
                this.mopaiCallback(s);
            }), o);
            TweenTool.sequence(s, true, null, a, d);
        }
    }
    mopaiCallback(e) {
        if (ToolUtils.isObjValid(e)) {
            e.active = false;
            TweenTool.stopNodeAction(e);
            e.destroy();
            for (let e = 0, t = this.paiduiCardVec.length; e < t; e++) {
                ToolUtils.isObjValid(this.paiduiCardVec[e]) && this.paiduiCardVec[e].setSiblingIndex(e + 1);
            }
            ToolUtils.isObjValid(this.lzCard) && this.lzCard.setSiblingIndex(0);
            0 == this.mopaiPos ? (this.beginFaPaiWithoutAnim(), this._nGuideStep !== RummyCardConstant.NewPlayer_Step.MoPai && this._nGuideStep !== RummyCardConstant.NewPlayer_Step.MoPai_PaiDui && this._nGuideStep !== RummyCardConstant.NewPlayer_Step.MoPai_QiPai || this.startNextStep()) : (this.func_cb("wait_outCard"), TweenTool.delayAct(this.root_node, (() => {
                this._nGuideStep === RummyCardConstant.NewPlayer_Step.WaitOtherOpate ? this.playOutCards(RummyCardConstant.NewPlayer_OutCard2, 1, true) : this.playOutCards(RummyCardConstant.NewPlayer_OutCard4, 1, true);
            }), 2, true));
        }
    }
    beginFaPaiWithoutAnim() {
        if (this.cardViewVec.length > 0) {
            let e;
            for (let t = 0, i = this.cardViewVec.length; t < i; t++) {
                e = this.cardViewVec[t];
                ToolUtils.isObjValid(e) && e.destroy();
            }
            this.cardViewVec = [];
        }
        this.cardValueVec = [];
        let e, t = this.middlePosY, i = this.cardStartPosX, a = this.myGroupcardValueVec, s = a.length;
        for (let t = 0; t < s; t++) {
            e = a[t].cardVec;
            for (let t = 0, i = e.length; t < i; t++) {
                this.cardValueVec.push(e[t]);
            }
        }
        let o = this.cardValueVec.length, d = 2 * RummyCardConstant.cebianW, n = (s - 1) * this.cardSpaceGroup, h = s * this.cardWidth, l = (RummyCardConstant.ScreenWidth - d - n - h) / (1 * (o - s)), c = this.cardWidth + RummyCardConstant.CardSpaceGroup - l;
        this.spXpositionDeq = [];
        this.cardsPostions = [];
        let u, p, m, g, y = 0, _ = t;
        for (let t = 0; t < s; t++) {
            e = a[t].cardVec;
            for (let a = 0, s = e.length; a < s; a++) {
                u = i + l * y + t * c;
                p = y;
                m = instantiate(this.cardPrefab);
                this.shoupaiLayout.addChild(m);
                g = m.getComponent("RummyCard");
                g.init(e[a], false);
                g.setCardSize(this.cardWidth, this.cardHeight);
                g.setCardTag(y);
                g.cardIndex = a;
                g.groupIndex = t;
                g.unSelectedPosY = _;
                g.selectedPosY = _ + RummyCardConstant.SelectSpaceY;
                g.setCardTouchAreaX(this.touchCardWidth / 2, this.touchCardWidth / 2);
                g.setCardTouchAreaY(this.cardHeight / 2, this.cardHeight / 2);
                g.hasSelected = false;
                g.rowType = 0;
                m.setScale(this.cardScale);
                m.setPosition(new Vec3(u, _));
                m.active = true;
                m.setSiblingIndex(p);
                g.showLaiziFlag(this.isShowLaiziColor(e[a]));
                this.cardViewVec.push(m);
                y += 1;
                this.spXpositionDeq.push(u);
                this.cardsPostions.push(new Vec3(u, _));
            }
        }
        for (let e = 0, t = this.cardViewVec.length; e < t; e++) {
            g = this.cardViewVec[e].getComponent("RummyCard");
            g.openCard();
            g.showLaiziFlag(this.isShowLaiziColor(g.mCardValue));
        }
        this.refreshAllGroupInfo();
    }
    getSelectedCards() {
        let e = [];
        for (let t = 0, i = this.cardViewVec.length; t < i; t++) {
            this.cardViewVec[t].getComponent("RummyCard").hasSelected && e.push(this.cardViewVec[t]);
        }
        return e;
    }
    playOutCards(e, t, i, a) {
        if (0 == t) {
            this.hasQipai = i;
            this.qipaiValue = e;
            let t = this.getSelectedCards();
            if (1 == t.length) {
                if (0 == i) {
                    let e = t[0].getComponent("RummyCard");
                    this.showHucardAnim_newPlay(e.mCardValue, t[0].position, v3(0.8, 0.8, 0.8), t[0]);
                }
                else {
                    let e = this.qipaiPoint;
                    t[0].setSiblingIndex(200);
                    let i = TweenTool.moveTo(t[0], 0.1, e), a = TweenTool.scaleTo(t[0], 0.1, this.outcardScale);
                    TweenTool.parallel(t[0], true, (() => {
                        this.playOutCallBack(t[0]);
                    }), i, a);
                    this.nOpenNum = this.nOpenNum + 1;
                    this.func_cb("updateOpenNum", this.nOpenNum);
                }
            }
            else {
                let t = this.qipaiPoint;
                0 == i && (t = this.finishPoint);
                let a = instantiate(this.cardPrefab), s = a.getComponent("RummyCard");
                s.init(e, false);
                s.openCard();
                s.showLaiziFlag(this.isShowLaiziColor(e));
                a.setScale(this.outcardScale);
                a.active = true;
                a.setPosition(t);
                this.qipai_node.insertChild(a, 9999);
                this.qipaiCards.push(a);
                this.nOpenNum = this.nOpenNum + 1;
                this.func_cb("updateOpenNum", this.nOpenNum);
            }
        }
        else {
            let s = instantiate(this.cardPrefab), o = s.getComponent("RummyCard");
            if (a ? o.init(e, true) : (o.init(e, false), o.openCard(), o.showLaiziFlag(this.isShowLaiziColor(e))), s.setScale(this.mpScale), s.setPosition(new Vec3(this.seatPosVec[t].x, this.seatPosVec[t].y + 14)), this.qipai_node.insertChild(s, 9999), s.setSiblingIndex(99999), i) {
                s.active = true;
                this.qipaiCards.push(s);
                let e = TweenTool.delayAct(s, null, 0.4), t = TweenTool.moveTo(s, 0.1, this.qipaiPoint), i = TweenTool.scaleTo(s, 0.1, this.outcardScale), a = TweenTool.parallel(s, false, null, t, i);
                TweenTool.sequence(s, true, (() => {
                    this.otherPlayCallBack(s);
                }), e, a);
            }
            else {
                this.playEffectByName("rummyFlip");
                let e = TweenTool.moveTo(s, 0.1, this.finishPoint), t = TweenTool.scaleTo(s, 0.1, this.outcardScale);
                TweenTool.parallel(s, true, null, e, t);
                this.qipaiCards.push(s);
            }
            this.nOpenNum = this.nOpenNum + 1;
            this.func_cb("updateOpenNum", this.nOpenNum);
        }
    }
    playOutCallBack(e) {
        if (ToolUtils.isObjValid(e)) {
            e.setSiblingIndex(this.qipaiCards.length);
            e.destroy();
            for (let e = 0, t = this.qipaiCards.length; e < t; e++) {
                this.qipaiCards[e].setSiblingIndex(e);
                this.qipaiCards[e].active = true;
            }
            let t = instantiate(this.cardPrefab), i = t.getComponent("RummyCard");
            i.init(this.qipaiValue, false);
            i.openCard();
            i.showLaiziFlag(this.isShowLaiziColor(this.qipaiValue));
            t.setScale(this.outcardScale);
            t.setPosition(this.qipaiPoint);
            let a = this.qipaiCards.length;
            t.setSiblingIndex(a);
            0 == this.hasQipai && t.setPosition(this.finishPoint);
            t.active = true;
            this.qipai_node.addChild(t);
            this.hasQipai && this.qipaiCards.push(t);
            this._nGuideStep == RummyCardConstant.NewPlayer_Step.Discard ? (this.myGroupcardValueVec = RummyCardConstant.NewPlayer_GroupCards4, this.beginFaPaiWithoutAnim(), this.startNextStep(), this.func_cb("updateMyScore", RummyCardConstant.NewPlayer_HandScore4)) : this._nGuideStep == RummyCardConstant.NewPlayer_Step.Discard2 ? (this.myGroupcardValueVec = RummyCardConstant.NewPlayer_GroupCards7, this.beginFaPaiWithoutAnim(), this.startNextStep(), this.func_cb("updateMyScore", RummyCardConstant.NewPlayer_HandScore7)) : this._nGuideStep == RummyCardConstant.NewPlayer_Step.Declare && (this.myGroupcardValueVec = RummyCardConstant.NewPlayer_GroupCards10, this.beginFaPaiWithoutAnim(), this.startNextStep(), this.func_cb("updateMyScore", RummyCardConstant.NewPlayer_HandScore10));
        }
    }
    showHucardAnim_newPlay(e, t, i, a) {
        let s = e, o = this.getCardNode(), d = o.getComponent("RummyCard");
        d.init(s, true);
        d.openCard();
        d.showLaiziFlag(this.isShowLaiziColor(s));
        let n = this.finishPoint;
        o.active = true;
        d.showHuAcion_newPlay(t, n, i);
        this.hupai_node.addChild(o);
        this.hupaiCardVec.push(o);
        this.arrow_anim_nodes[0].active = false;
        this.arrow_anim_nodes[1].active = false;
        this.arrow_anim_nodes[2].active = false;
        this.arrow_anim_nodes[3].active = false;
        TweenTool.delayAct(this.node, (() => {
            ToolUtils.isObjValid(this.node) && this._nGuideStep == RummyCardConstant.NewPlayer_Step.Declare && (this.myGroupcardValueVec = RummyCardConstant.NewPlayer_GroupCards10, this.beginFaPaiWithoutAnim(), this.func_cb("updateMyScore", RummyCardConstant.NewPlayer_HandScore10));
        }), 0.2, true);
        TweenTool.delayAct(this.node, (() => {
            ToolUtils.isObjValid(this.node) && this.showWinEffect_newPlay();
        }), 1.8, true);
    }
    showWinEffect_newPlay() {
        this.win_anim && this.win_anim.isValid && (this.win_anim.node.setSiblingIndex(1000), this.win_anim.node.active = true, this.win_anim.clearTracks(), this.win_anim.setAnimation(0, "dp_sl3", false), SoundManager.shared().playFx("winA"));
        TweenTool.delayAct(this.node, (() => {
            ToolUtils.isObjValid(this.node) && (this.win_anim && this.win_anim.isValid && (this.win_anim.node.active = false), this.startNextStep());
        }), 1.5, true);
    }
    otherPlayCallBack(e) {
        this.playEffectByName("rummyFlip");
        this.func_cb("stopTimer");
        TweenTool.delayAct(this.root_node, (() => {
            this.startNextStep();
        }), 0.4, true);
    }
    playEffectByName(e) {
        SoundManager.shared().playFx(e);
    }
    showComplateGuideTips() {
        Utils.shared().showCommomDialog(i18nMgr.shared().getValueByKey("practice_guide.guide_cash_tip"), i18nMgr.shared().getValueByKey("utlis.congratulations"), (e => {
            User.shared().BackHallOpenModule = 1 == e ? 2 : 1;
            ToolUtils.in_isGuideRoom = 0;
            ToolUtils.isObjValid(this.node) && this.node.destroy();
            let t = { tid_key: CommDefine.NewerGuideRoomTidkey, switchCash: false };
            PushCenter.shared().pushEvent(GameConfig.DeleteDesk, t);
        }), false, ToolUtils.getIsNormalDirection(), i18nMgr.shared().getValueByKey("gamebonus_node.confirm"), null, null, this.node);
    }
    showJumpToPracticeGameTips() {
        let e = ToolUtils.format(i18nMgr.shared().getValueByKey("utlis.text26"), User.shared().data.beginner_guide.practice_reward);
        Utils.shared().showCommomDialog(e, i18nMgr.shared().getValueByKey("utlis.congratulations"), (e => {
            if (1 == e) {
                Utils.shared().showLoading(20, false);
                let e = User.shared().roomTable.pointsrummy.chiplist;
                if (e) {
                    User.shared().isShowGuideRewardTips = true;
                    User.shared()._bNewPlayerGuideskip = false;
                    let t = e[0].vid;
                    RummyDataManager.shared().rummyInfos.get(User.shared().curTid_key).vid = t;
                    ToolUtils.in_isGuideRoom = 0;
                    User.shared().isGameDisconnectServer = true;
                    RummyDataManager.shared().rummyInfos.get(User.shared().curTid_key).fromBeginnerTutorial = 1;
                    this.func_cb("jumpToPracticeRoom");
                    ToolUtils.isObjValid(this.node) && this.node.destroy();
                }
                else {
                    User.shared().isShowGuideRewardTips = true;
                    ToolUtils.isObjValid(this.node) && this.node.destroy();
                    PushCenter.shared().pushEvent(GameConfig.BackToHall);
                }
            }
            else {
                User.shared().isShowGuideRewardTips = true;
                ToolUtils.isObjValid(this.node) && this.node.destroy();
                PushCenter.shared().pushEvent(GameConfig.BackToHall);
            }
        }), true, ToolUtils.getIsNormalDirection(), i18nMgr.shared().getValueByKey("reward_tips.play_now"), i18nMgr.shared().getValueByKey("reward_tips.cancel"), null, this.node);
    }
    showJumpToCashGameTips() {
        let e = ToolUtils.format(i18nMgr.shared().getValueByKey("practice_guide.guide_cash_tip"));
        Utils.shared().showCommomDialog(e, i18nMgr.shared().getValueByKey("utlis.congratulations"), (e => {
            1 == e || HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Practice, func: ReportConfig.func.NewPlayer, event: ReportConfig.newPlayerGuide.cash_guide_cancle });
            User.shared().isShowGuideRewardTips = true;
            ToolUtils.isObjValid(this.node) && this.node.destroy();
            PushCenter.shared().pushEvent(GameConfig.BackToHall);
        }), false, ToolUtils.getIsNormalDirection(), i18nMgr.shared().getValueByKey("reward_tips.okey"), null, null, this.node);
    }
    showTaskCompleteAnim() {
        if (this._nGuideStep == RummyCardConstant.NewPlayer_Step.SelestTask1) {
            let e = new Vec3;
            this.node_taskBg.getChildByName("select_img1").getPosition(e);
            this.node_taskBg.getChildByName("complete_anim").setPosition(new Vec3(e.x - 2, e.y - 2, e.z));
            this.node_taskBg.getChildByName("complete_anim").active = true;
            TweenTool.delayAct(this.root_node, (() => {
                SoundManager.shared().playFx("da_gou");
            }), 0.3, true);
            TweenTool.delayAct(this.root_node, (() => {
                this.node_taskBg.getChildByName("select_img1").active = true;
                this.node_taskBg.getChildByName("complete_anim").active = false;
            }), 0.7, true);
            TweenTool.delayAct(this.root_node, (() => {
                this.setTaskPanelShow(false);
                this._nGuideStep == RummyCardConstant.NewPlayer_Step.SelestTask1 && this.startNextStep();
            }), 2, true);
        }
        else if (this._nGuideStep > RummyCardConstant.NewPlayer_Step.SelestTask1 && this._nGuideStep < RummyCardConstant.NewPlayer_Step.SelestTask2) {
            this.node_taskBg.getChildByName("select_img1").active = true;
        }
        else if (this._nGuideStep == RummyCardConstant.NewPlayer_Step.SelestTask2) {
            this.node_taskBg.getChildByName("select_img1").active = true;
            let e = new Vec3;
            this.node_taskBg.getChildByName("select_img2").getPosition(e);
            this.node_taskBg.getChildByName("complete_anim").setPosition(new Vec3(e.x - 2, e.y - 2, e.z));
            this.node_taskBg.getChildByName("complete_anim").active = true;
            TweenTool.delayAct(this.root_node, (() => {
                SoundManager.shared().playFx("da_gou");
            }), 0.3, true);
            TweenTool.delayAct(this.root_node, (() => {
                this.node_taskBg.getChildByName("select_img2").active = true;
                this.node_taskBg.getChildByName("complete_anim").active = false;
            }), 0.7, true);
            TweenTool.delayAct(this.root_node, (() => {
                this.setTaskPanelShow(false);
                this._nGuideStep == RummyCardConstant.NewPlayer_Step.SelestTask2 && this.startNextStep();
            }), 2, true);
        }
        else if (this._nGuideStep > RummyCardConstant.NewPlayer_Step.SelestTask2 && this._nGuideStep < RummyCardConstant.NewPlayer_Step.SelestTask3) {
            this.node_taskBg.getChildByName("select_img1").active = true;
            this.node_taskBg.getChildByName("select_img2").active = true;
        }
        else if (this._nGuideStep == RummyCardConstant.NewPlayer_Step.SelestTask3) {
            this.node_taskBg.getChildByName("select_img1").active = true;
            this.node_taskBg.getChildByName("select_img2").active = true;
            let e = new Vec3;
            this.node_taskBg.getChildByName("select_img3").getPosition(e);
            this.node_taskBg.getChildByName("complete_anim").setPosition(new Vec3(e.x - 2, e.y - 2, e.z));
            this.node_taskBg.getChildByName("complete_anim").active = true;
            TweenTool.delayAct(this.root_node, (() => {
                SoundManager.shared().playFx("da_gou");
            }), 0.3, true);
            TweenTool.delayAct(this.root_node, (() => {
                this.node_taskBg.getChildByName("select_img3").active = true;
                this.node_taskBg.getChildByName("complete_anim").active = false;
            }), 0.7, true);
            TweenTool.delayAct(this.root_node, (() => {
                this.setTaskPanelShow(false);
                this._nGuideStep == RummyCardConstant.NewPlayer_Step.SelestTask3 && this.startNextStep();
            }), 2, true);
        }
    }
    setTaskPanelShow(e) {
        this.left_menu.getChildByName("close_btn").active = e;
        e ? (this.left_menu.getChildByName("icon").active = false, this.node_taskBg.active ? this.showTaskCompleteAnim() : (this.node_taskBg.setPosition(new Vec3(this.taskPanelPos.x + 300, this.taskPanelPos.y, this.taskPanelPos.z)), this.node_taskBg.active = true, TweenTool.stopNodeAction(this.node_taskBg), TweenTool.moveTo(this.node_taskBg, 0.2, this.taskPanelPos, "fade", true, (() => {
            this.showTaskCompleteAnim();
        })))) : this.node_taskBg.active && (TweenTool.stopNodeAction(this.node_taskBg), TweenTool.moveTo(this.node_taskBg, 0.2, new Vec3(this.taskPanelPos.x + 300, this.taskPanelPos.y, this.taskPanelPos.z), "fade", true, (() => {
            this.left_menu.getChildByName("icon").active = true;
            this.node_taskBg.getChildByName("complete_anim").active = false;
            this.node_taskBg.active = false;
        })));
    }
    onButtonClick(e, t) {
        if ("task_close" !== t && "card0" !== t && "card1" !== t && "card2" !== t && "card3" !== t && "card13" !== t && "card6" !== t && "card7" !== t && "card8" !== t && "card9" !== t && "card10" !== t && "card11" !== t && SoundManager.shared().playFx("click"), "continue" === t) {
            this.startNextStep();
        }
        else if ("paidui" === t) {
            this.paidui_btn.active = false;
            this.qipai_btn.active = false;
            this._nGuideStep === RummyCardConstant.NewPlayer_Step.MoPai ? (this.getMoPai(0, 0, RummyCardConstant.NewPlayer_MoPai1, RummyCardConstant.NewPlayer_GroupCards2), TweenTool.delayAct(this.root_node, (() => {
                this.func_cb("updateMyScore", RummyCardConstant.NewPlayer_HandScore2);
            }), 0.3, true)) : this._nGuideStep === RummyCardConstant.NewPlayer_Step.MoPai_PaiDui && (this.getMoPai(0, 0, RummyCardConstant.NewPlayer_MoPai2, RummyCardConstant.NewPlayer_GroupCards5), TweenTool.delayAct(this.root_node, (() => {
                this.func_cb("updateMyScore", RummyCardConstant.NewPlayer_HandScore5);
            }), 0.3, true));
        }
        else if ("qipai" === t) {
            this.paidui_btn.active = false;
            this.qipai_btn.active = false;
            this._nGuideStep === RummyCardConstant.NewPlayer_Step.MoPai ? (this.getMoPai(0, 1, RummyCardConstant.NewPlayer_MoPai1, RummyCardConstant.NewPlayer_GroupCards2), TweenTool.delayAct(this.root_node, (() => {
                this.func_cb("updateMyScore", RummyCardConstant.NewPlayer_HandScore2);
            }), 0.3, true)) : this._nGuideStep === RummyCardConstant.NewPlayer_Step.MoPai_QiPai && (this.getMoPai(0, 1, RummyCardConstant.NewPlayer_MoPai3, RummyCardConstant.NewPlayer_GroupCards8), TweenTool.delayAct(this.root_node, (() => {
                this.func_cb("updateMyScore", RummyCardConstant.NewPlayer_HandScore8);
            }), 0.3, true));
        }
        else if (this._nGuideStep == RummyCardConstant.NewPlayer_Step.ClickPureSequenceCards && ("card0" === t || "card1" === t || "card2" === t || "card3" === t || "card13" === t) || this._nGuideStep == RummyCardConstant.NewPlayer_Step.ClickSequenceCards && ("card6" === t || "card7" === t || "card8" === t || "card9" === t || "card13" === t) || this._nGuideStep == RummyCardConstant.NewPlayer_Step.ClickSetCards && ("card10" === t || "card11" === t || "card13" === t)) {
            let e = Number(t.slice(4, t.length));
            if (this.cardViewVec[e]) {
                let t = this.cardViewVec[e].getComponent(RummyCard);
                t.hasSelected || SoundManager.shared().playFx("rummyCardSelect");
                t.changeCardStatus(true);
            }
            let i = -1;
            for (let [t, a] of this.cardClickPositions.entries()) {
                if (Math.abs(a.x - this.cardViewVec[e].getPosition().x) <= 0.001 || Math.abs(a.x - (this.cardViewVec[e].getPosition().x - 25)) <= 0.001) {
                    i = t;
                    break;
                }
            }
            i >= 0 && this.cardClickPositions.splice(i, 1);
            0 == this.cardClickPositions.length ? this.startNextStep() : (this.handAnimStep = -1, this.startGuideClickCardAnim());
        }
        else if (this._nGuideStep == RummyCardConstant.NewPlayer_Step.Declare && "card13" === t) {
            if (SoundManager.shared().playFx("rummyCardSelect"), this.cardViewVec[13]) {
                this.cardViewVec[13].getComponent(RummyCard).changeCardStatus(true);
            }
            this.finish_btn.active = true;
            this.cardClickPositions = [];
            this.cardClickPositions.push(this.finish_btn.getPosition());
            this.handAnimStep = -1;
            this.startGuideClickCardAnim();
        }
        else if ("card10" === t) {
            if (SoundManager.shared().playFx("rummyCardSelect"), this._nGuideStep > RummyCardConstant.NewPlayer_Step.Discard) {
                return;
            }
            if (this.cardViewVec[10]) {
                this.cardViewVec[10].getComponent(RummyCard).changeCardStatus(true);
            }
            this.discard_btn.getComponent(Button).interactable = true;
            this.cardClickPositions = [];
            this.cardClickPositions.push(this.discard_btn.getPosition());
            this.handAnimStep = -1;
            this.startGuideClickCardAnim();
        }
        else if ("card11" === t) {
            if (SoundManager.shared().playFx("rummyCardSelect"), this._nGuideStep !== RummyCardConstant.NewPlayer_Step.Discard) {
                return;
            }
            if (this.cardViewVec[11]) {
                this.cardViewVec[11].getComponent(RummyCard).changeCardStatus(true);
            }
            this.discard_btn.getComponent(Button).interactable = true;
            this.cardClickPositions = [];
            this.cardClickPositions.push(this.discard_btn.getPosition());
            this.handAnimStep = -1;
            this.startGuideClickCardAnim();
        }
        else if ("card13" === t) {
            if (SoundManager.shared().playFx("rummyCardSelect"), this._nGuideStep !== RummyCardConstant.NewPlayer_Step.Discard2) {
                return;
            }
            if (this.cardViewVec[13]) {
                this.cardViewVec[13].getComponent(RummyCard).changeCardStatus(true);
            }
            this.discard_btn.getComponent(Button).interactable = true;
            this.cardClickPositions = [];
            this.cardClickPositions.push(this.discard_btn.getPosition());
            this.handAnimStep = -1;
            this.startGuideClickCardAnim();
        }
        else {
            "group" === t ? (this.hideGuideClickAnim(), this._nGuideStep !== RummyCardConstant.NewPlayer_Step.ClickGroupBtn && this._nGuideStep !== RummyCardConstant.NewPlayer_Step.ClickGroupBtn2 && this._nGuideStep !== RummyCardConstant.NewPlayer_Step.ClickGroupBtn3 || (this.group_btn.active = false, this._nGuideStep === RummyCardConstant.NewPlayer_Step.ClickGroupBtn ? (this.myGroupcardValueVec = RummyCardConstant.NewPlayer_GroupCards3, this.func_cb("updateMyScore", RummyCardConstant.NewPlayer_HandScore3), SoundManager.shared().playFx("rummyPositiveGroup")) : this._nGuideStep === RummyCardConstant.NewPlayer_Step.ClickGroupBtn2 ? (this.myGroupcardValueVec = RummyCardConstant.NewPlayer_GroupCards6, this.func_cb("updateMyScore", RummyCardConstant.NewPlayer_HandScore6), SoundManager.shared().playFx("rummyPositiveGroup")) : (this.myGroupcardValueVec = RummyCardConstant.NewPlayer_GroupCards9, this.func_cb("updateMyScore", RummyCardConstant.NewPlayer_HandScore9), SoundManager.shared().playFx("rummyPositiveGroup")), this.beginFaPaiWithoutAnim(), TweenTool.delayAct(this.root_node, (() => {
                this.startNextStep();
            }), 0.4, true))) : "discard" === t ? (this.hideGuideClickAnim(), this._nGuideStep == RummyCardConstant.NewPlayer_Step.Discard ? (this.discard_btn.active = false, this.root_node.getChildByName("step5").active = false, this.playOutCards(RummyCardConstant.NewPlayer_OutCard1, 0, true, false)) : this._nGuideStep == RummyCardConstant.NewPlayer_Step.Discard2 && (this.discard_btn.active = false, this.root_node.getChildByName("step10").active = false, this.playOutCards(RummyCardConstant.NewPlayer_OutCard3, 0, true, false))) : "finish" === t ? (this.finish_btn.getComponent(Button).enabled = false, this.hideGuideClickAnim(), this.root_node.getChildByName("step9").active = false, this.playOutCards(RummyCardConstant.NewPlayer_OutCard5, 0, false, true)) : "openTaskPanel" === t ? this.setTaskPanelShow(true) : "task_close" === t ? this._nGuideStep != RummyCardConstant.NewPlayer_Step.SelestTask1 && this._nGuideStep != RummyCardConstant.NewPlayer_Step.SelestTask2 && this._nGuideStep != RummyCardConstant.NewPlayer_Step.SelestTask3 && this.setTaskPanelShow(false) : "skip" === t && (this.func_cb("clearDesk", 0, (() => {
                User.shared().send_laba_notify_newer_reward_pop_laba();
                User.shared().data.beginner_guide && 1 == User.shared().data.beginner_guide.practice_status ? ToolUtils.in_isGuideRoom = 0 : User.shared().isShowGuideRewardTips = true;
                ToolUtils.isObjValid(this.node) && this.node.destroy();
                let e = { tid_key: CommDefine.NewerGuideRoomTidkey, switchCash: false };
                PushCenter.shared().pushEvent(GameConfig.DeleteDesk, e);
            })), this.clearNewPlayerGuideUI());
        }
    }
    clearNewPlayerGuideUI() {
        this.setTaskPanelShow(false);
        this.root_node.active = false;
        this.node.getChildByName("mask").active = false;
    }
    getCurSkiptEvent() {
        let e = ReportConfig.newPlayerGuide.skip1;
        return this._nGuideStep <= 1 ? ReportConfig.newPlayerGuide.skip1 : this._nGuideStep > 1 && this._nGuideStep < 4 ? e = ReportConfig.newPlayerGuide.skip2 : this._nGuideStep >= 4 && this._nGuideStep < 6 ? e = ReportConfig.newPlayerGuide.skip3 : this._nGuideStep >= 6 && this._nGuideStep < 8 ? e = ReportConfig.newPlayerGuide.skip4 : 8 == this._nGuideStep ? e = ReportConfig.newPlayerGuide.skip5 : 9 == this._nGuideStep ? e = ReportConfig.newPlayerGuide.skip6 : this._nGuideStep >= 10 && this._nGuideStep < 12 ? e = ReportConfig.newPlayerGuide.skip7 : this._nGuideStep >= 12 && this._nGuideStep < 14 ? e = ReportConfig.newPlayerGuide.skip8 : 14 == this._nGuideStep ? e = ReportConfig.newPlayerGuide.skip9 : 15 == this._nGuideStep ? e = ReportConfig.newPlayerGuide.skip10 : this._nGuideStep >= 16 && this._nGuideStep < 18 ? e = ReportConfig.newPlayerGuide.skip11 : 18 == this._nGuideStep ? e = ReportConfig.newPlayerGuide.skip12 : 19 == this._nGuideStep ? e = ReportConfig.newPlayerGuide.skip13 : this._nGuideStep >= 20 && (e = ReportConfig.newPlayerGuide.skip14), e;
    }
    beginFaPaiWithAnim() {
        let e, t, i = RummyCardConstant.NewPlayer_GroupCards1, a = RummyCardConstant.NewPlayer_InialCards;
        if (this.is_fapai_over = false, this.cardViewVec.length > 0) {
            for (let t = 0, i = this.cardViewVec.length; t < i; t++) {
                e = this.cardViewVec[t];
                ToolUtils.isObjValid(e) && (e.active = false, TweenTool.stopNodeAction(e), e.destroy());
            }
            this.cardViewVec = [];
        }
        if (this.paiduiCardVec.length > 0) {
            for (let t = 0, i = this.paiduiCardVec.length; t < i; t++) {
                e = this.paiduiCardVec[t];
                ToolUtils.isObjValid(e) && (e.active = false, TweenTool.stopNodeAction(e), e.destroy());
            }
            this.paiduiCardVec = [];
        }
        if (this.initialCardNodes.length > 0) {
            for (let t = 0, i = this.initialCardNodes.length; t < i; t++) {
                e = this.initialCardNodes[t];
                ToolUtils.isObjValid(e) && (e.active = false, TweenTool.stopNodeAction(e), e.destroy());
            }
            this.initialCardNodes = [];
        }
        this.cardValueVec = [];
        let s = this.middlePosY;
        this.paiduiCardVec = [];
        let o = 0.3 + 0.15, d = 0.2, n = 0.1, h = 93;
        h = 14;
        for (let i = 0; i <= 13; i++) {
            e = this.getCardNode();
            t = e.getComponent("RummyCard");
            t.init(1, true);
            t.setCardTag(i);
            e.setScale(RummyCardConstant.OutcardScale);
            e.active = 13 === i;
            e.setPosition(RummyCardConstant.centerPos);
            this.paidui_node.addChild(e);
            e.setSiblingIndex(i);
            e.angle = 0;
            TweenTool.moveToByFade(e, 0.15, e.getPosition(), 0, 1, true, (() => {
            }));
            this.paiduiCardVec.push(e);
        }
        let l, c;
        for (let e = 0; e < RummyCardConstant.shouPaiNum; e++) {
            if (this.paiduiCardVec.length > e + 0) {
                l = e + 0;
                let t = this.paiduiCardVec[l];
                t.active = true;
                c = 1;
                let i = new Vec3(this.seatPosVec[1].x, this.seatPosVec[1].y), a = 0.034 * e + o;
                TweenTool.delayAct(this.delay_node, (() => {
                    if (ToolUtils.isObjValid(t)) {
                        t.active = true;
                        let e = TweenTool.rotateTo(t, n, new Vec3(0, 0, 0)), a = TweenTool.rotateTo(t, n, new Vec3(0, 0, 0)), s = TweenTool.moveTo(t, d, i), o = TweenTool.scaleTo(t, d, RummyCardConstant.OtherHeadCardScale), h = TweenTool.sequence(t, false, null, e, a);
                        TweenTool.parallel(t, true, (() => {
                            ToolUtils.isObjValid(t) && t.setPosition(i);
                        }), s, o, h);
                    }
                    TweenTool.delayAct(this.delay_node, (() => {
                        if (null !== i.x && ToolUtils.isObjValid(t)) {
                            t.setPosition(i);
                            let e = TweenTool.moveTo(t, 0.15, new Vec3(i.x, i.y + 6)), a = TweenTool.delayAct(this.delay_node, (() => {
                                t.active = false;
                            }));
                            TweenTool.sequence(t, true, null, e, a);
                        }
                    }), d, true);
                }), a, true);
            }
        }
        this.allPaiNum = RummyCardConstant.NewPlayer_CloseCardNum;
        let u = 0;
        if (a && "object" == typeof a) {
            let e, t;
            for (let i = 0, o = a.length; i < o; i++) {
                e = this.getCardNode();
                this.shoupaiLayout.addChild(e);
                t = e.getComponent("RummyCard");
                t.init(a[i], true);
                t.setCardSize(this.cardWidth, this.cardHeight);
                t.setCardTag(u);
                t.cardIndex = i;
                t.unSelectedPosY = s;
                t.selectedPosY = s + RummyCardConstant.SelectSpaceY;
                t.groupIndex = 0;
                t.setCardTouchAreaX(this.touchCardWidth / 2, this.touchCardWidth / 2);
                t.setCardTouchAreaY(this.touchCardHight / 2, this.touchCardHight / 2);
                t.rowType = 0;
                e.setScale(RummyCardConstant.OutcardScale);
                e.active = !(i < o - 1);
                e.setPosition(RummyCardConstant.centerPos);
                t.totalIndex = u;
                e.setSiblingIndex(u);
                this.initialCardNodes.push(e);
                u += 1;
            }
        }
        this.myGroupcardValueVec = i;
        let p = 0, m = 0.034;
        this.cardsPostions = [];
        let C = -550.4;
        if (i.length > 0) {
            let e;
            this.getshouPaiPositions(i, this.initialCardNodes.length);
            for (let t = 0, i = this.initialCardNodes.length; t < i; t++) {
                let i = this.initialCardNodes[t];
                ToolUtils.isObjValid(i) && (e = i.getComponent("RummyCard"), e.setCardTag(t), i.active = true, p = m * t + o, TweenTool.delayAct(this.delay_node, (() => {
                    if (ToolUtils.isObjValid(i)) {
                        0 === t && this.playEffectByName("rummyDeal");
                        let a = TweenTool.rotateTo(i, n, new Vec3(0, 0, 12)), o = TweenTool.rotateTo(i, n, new Vec3(0, 0, 0)), d = TweenTool.sequence(i, false, (() => {
                        }), a, o), h = C + 90.83333333333333 * t;
                        1 == this.myGroupcardValueVec.length && this.spXpositionDeq.length > t && (h = this.spXpositionDeq[t]);
                        let l = TweenTool.moveTo(i, 0.2, new Vec3(h, s)), c = TweenTool.scaleTo(i, 0.2, this.cardScale), u = TweenTool.delayAct(i, (() => {
                            ToolUtils.isObjValid(i) && (e = i.getComponent("RummyCard"), e.openCard());
                        }), 0), p = TweenTool.delayAct(i, (() => {
                        }), 0.2), g = 90 * t - 540.4;
                        1 == this.myGroupcardValueVec.length && (g = this.spXpositionDeq[t]);
                        let y = TweenTool.moveTo(i, 0.17, new Vec3(g, s)), _ = TweenTool.delayAct(i, (() => {
                        }), m), w = TweenTool.scaleTo(i, 0.06, new Vec3(0, 0.8), null, false, (() => {
                        })), P = TweenTool.scaleTo(i, 0.1, new Vec3(0.8, 0.8), null, false, (() => {
                        })), S = null;
                        S = 1 == this.myGroupcardValueVec.length ? TweenTool.sequence(i, false, null, p, w, u, P) : TweenTool.sequence(i, false, null, p, y, _, w, u, P);
                        TweenTool.parallel(i, true, (() => {
                        }), d, l, c, S);
                    }
                }), p, true));
            }
        }
        TweenTool.delayAct(this.delay_node, (() => {
            this.fanLaizi();
        }), 1.358, true);
        let g = 1.5;
        1 == this.myGroupcardValueVec.length && (g = 1.5);
        i.length > 0 && TweenTool.delayAct(this.delay_node, (() => {
            this.sortShouPai();
        }), g, true);
    }
    fanLaizi() {
        if (this.paiduiCardVec.length > 0) {
            for (let e = 0, t = this.paiduiCardVec.length; e < t; e++) {
                ToolUtils.isObjValid(this.paiduiCardVec[e]) && (this.paiduiCardVec[e].active = false, TweenTool.stopNodeAction(this.paiduiCardVec[e]), this.paiduiCardVec[e].destroy());
            }
        }
        if (this.paiduiCardVec = [], !ToolUtils.isObjValid(this.lzCard)) {
            this.lzCard = this.getCardNode();
            this.lzCard.getComponent("RummyCard").init(RummyCardConstant.NewPlayer_LaiziCard, false);
            this.lzCard.setScale(this.outcardScale);
            this.lzCard.setPosition(this.paiduiPoint);
            this.lzCard.active = false;
            this.paidui_node.insertChild(this.lzCard, 0);
            this.lzCard.setSiblingIndex(0);
        }
        let e, t, i = this.allPaiNum;
        for (let a = 0; a < i; a++) {
            e = this.getCardNode();
            t = e.getComponent("RummyCard");
            t.init(1, true);
            t.setCardTag(a);
            e.setScale(this.outcardScale);
            e.active = !(a < i - 1);
            e.setPosition(RummyCardConstant.centerPos);
            this.paidui_node.addChild(e);
            e.setSiblingIndex(a + 1);
            this.paiduiCardVec.push(e);
        }
        if (this.playEffectByName("rummyFlip"), this.paiduiCardVec.length > 0) {
            let e = 0.26 - 0.02, t = e + 0.06;
            for (let t = 0, i = this.paiduiCardVec.length; t < i; t++) {
                let a = this.paiduiCardVec[t];
                ToolUtils.isObjValid(a) && t === i - 1 && (a.active = true, TweenTool.moveTo(a, e, this.paiduiPoint, null, true, (() => {
                    ToolUtils.isObjValid(a) && a.setPosition(this.paiduiPoint);
                })));
            }
            TweenTool.delayAct(this.delay_node, (() => {
                let e = 0.3 - 0.1;
                if (!this.is_fapai_over) {
                    let t;
                    for (let e = 0, i = this.paiduiCardVec.length; e < i; e++) {
                        t = this.paiduiCardVec[e];
                        ToolUtils.isObjValid(t) && (t.setPosition(this.paiduiPoint), t.active = !(e <= i - 2));
                    }
                    if (this.is_fapai_over = true, ToolUtils.isObjValid(this.lzCard)) {
                        this.lzCard.setSiblingIndex(0);
                        let t = this.lzCard.getComponent("RummyCard");
                        this.lzCard.active = true;
                        t.init(RummyCardConstant.NewPlayer_LaiziCard, false);
                        t.openCard();
                        t.showLaiziFlag(this.isShowLaiziColor(RummyCardConstant.NewPlayer_LaiziCard), true);
                        this.lzCard.setScale(this.outcardScale);
                        let i = TweenTool.moveTo(this.lzCard, 0.17, new Vec3(this.paiduiPoint.x, this.paiduiPoint.y + 36.8)), a = e - 0.17, s = TweenTool.delayAct(this.delay_node, (() => {
                            let e = TweenTool.moveTo(this.lzCard, a, new Vec3(this.laiziPoint.x, this.laiziPoint.y)), t = TweenTool.rotateTo(this.lzCard, a, new Vec3(0, 0, 90));
                            TweenTool.parallel(this.lzCard, true, (() => {
                                ToolUtils.isObjValid(this.lzCard) && (this.lzCard.setPosition(this.laiziPoint), this.lzCard.angle = 90, this.lzCard.active = true);
                            }), e, t);
                        }), 0);
                        TweenTool.sequence(this.lzCard, true, null, i, s);
                    }
                    let i = 0.2, a = 0.2;
                    TweenTool.delayAct(this.delay_node, (() => {
                        let e = this.createQiPaiCard(RummyCardConstant.NewPlayer_MoPai1);
                        ToolUtils.isObjValid(e) && TweenTool.moveTo(e, a, this.qipaiPoint, null, true, (() => {
                            let t = TweenTool.scaleTo(e, 0.1, new Vec3(0, RummyCardConstant.OutcardScale.y), null, false, (() => {
                                if (ToolUtils.isObjValid(e)) {
                                    let t = e.getComponent("RummyCard");
                                    t.openCard();
                                    t.showLaiziFlag(this.isShowLaiziColor(RummyCardConstant.NewPlayer_MoPai1));
                                }
                            })), i = TweenTool.scaleTo(e, 0.16, RummyCardConstant.OutcardScale, null, false, (() => {
                                this.onFaPaiAnimFinished();
                                this.func_cb("fapai_end");
                            }));
                            TweenTool.sequence(e, true, null, t, i);
                        }));
                    }), i, true);
                }
            }), t, true);
        }
    }
    createQiPaiCard(e) {
        let t = this.getCardNode();
        return this.qipaiCards = [], t.getComponent("RummyCard").init(RummyCardConstant.NewPlayer_MoPai1, true), t.setScale(this.outcardScale), t.setPosition(this.paiduiPoint), this.qipaiCards.push(t), this.qipai_node.addChild(t), t;
    }
    getshouPaiPositions(e, t) {
        this.myGroupcardValueVec = e;
        let i = e.length, a = t, s = 2 * RummyCardConstant.cebianW, o = (i - 1) * this.cardSpaceGroup, d = i * this.cardWidth, n = a - i, h = (RummyCardConstant.ScreenWidth - s - o - d) / (1 * n), l = this.cardStartPosX, c = this.cardWidth + this.cardSpaceGroup - h;
        this.spXpositionDeq = [];
        let u, p, m = 0;
        for (let t = 0; t < i; t++) {
            u = e[t].cardVec;
            for (let e = 0, i = u.length; e < i; e++) {
                p = l + h * m + t * c;
                this.cardsPostions.push(new Vec3(p, this.middlePosY));
                m += 1;
                this.spXpositionDeq.push(p);
            }
        }
    }
    getCardNode() {
        let e = null;
        e = this.cardsViewPool.size() > 0 ? this.cardsViewPool.get() : instantiate(this.cardPrefab);
        e.active = true;
        try {
            null === e.getComponent("RummyCard") || e.getComponent("RummyCard");
            e.getComponent("RummyCard").resetCards();
        }
        catch (e) {
            TLog.printError("trycatch getCardNode,error:", e);
        }
        return e;
    }
    sortShouPai() {
        if (1 == this.myGroupcardValueVec.length) {
            this.refreshMyShouPaiValues();
        }
        else {
            let e, t, i, a, s = 4;
            for (let o = 0, d = this.initialCardNodes.length; o < d; o++) {
                if (e = this.initialCardNodes[o], ToolUtils.isObjValid(e)) {
                    t = Math.floor(d / 2);
                    i = 0;
                    a = new Vec3;
                    e.getPosition(a);
                    let n = 0;
                    o < t ? (i = -8, n = -o * s) : o > t && (i = 8, n = (o - t) * s);
                    let h = TweenTool.moveTo(e, 0.1, new Vec3(a.x + i, this.middlePosY)), l = TweenTool.moveTo(e, 0.16, new Vec3(n, this.middlePosY));
                    TweenTool.sequence(e, true, null, h, l);
                }
            }
            TweenTool.delayAct(this.delay_node, (() => {
                this.refreshMyShouPaiValues();
            }), 0.26, true);
        }
    }
    refreshMyShouPaiValues() {
        this.cardValueVec = [];
        this.cardViewVec = [];
        let e, t = this.myGroupcardValueVec.length, i = 0;
        for (let a = 0; a < t; a++) {
            let t = this.myGroupcardValueVec[a].cardVec;
            for (let s = 0, o = t.length; s < o; s++) {
                this.cardValueVec.push(t[s]);
                let d = this.initialCardNodes[i];
                ToolUtils.isObjValid(d) && (e = d.getComponent("RummyCard"), e.init(t[s], false), e.setCardSize(this.cardWidth, this.cardHeight), e.setCardTag(i), e.cardIndex = s, e.unSelectedPosY = this.middlePosY, e.selectedPosY = this.middlePosY + RummyCardConstant.SelectSpaceY, e.groupIndex = a, e.setCardTouchAreaX(this.touchCardWidth / 2, this.touchCardWidth / 2), e.setCardTouchAreaY(this.touchCardHight / 2, this.touchCardHight / 2), e.rowType = 0, d.setScale(this.cardScale), e.groupCardVecLenth = o, e.totalIndex = i, e.groupColor = this.myGroupcardValueVec[a].color, e.groupText = this.myGroupcardValueVec[a].desc, d.setSiblingIndex(i), this.cardViewVec.push(d), i += 1, e.showLaiziFlag(this.isShowLaiziColor(t[s])));
            }
        }
        this.showMyGroupCards(this.myGroupcardValueVec);
    }
    showMyGroupCards(e) {
        this.myGroupcardValueVec = e;
        let t, i = e.length;
        if (this.getshouPaiPositions(e, 13), this.cardValueVec.length > 0) {
            this.cardValueVec = [];
            for (let a = 0; a < i; a++) {
                t = e[a].cardVec;
                for (let e = 0, i = t.length; e < i; e++) {
                    this.cardValueVec.push(t[e]);
                }
            }
        }
        let a, s = 0.18;
        1 == i && (s = 0);
        for (let e = 0, t = this.cardViewVec.length; e < t; e++) {
            let t = this.cardViewVec[e];
            ToolUtils.isObjValid(t) && (a = t.getComponent("RummyCard"), a.setCardTag(e), a.changeCardStatus(false), TweenTool.moveTo(t, s, new Vec3(this.spXpositionDeq[e], this.middlePosY, 0), null, true, (() => {
                ToolUtils.isObjValid(t) && t.getPosition(a.beforeMovingPos);
            })));
        }
        let o = s + 0;
        1 == i && (o = 0);
        TweenTool.delayAct(this.delay_node, (() => {
            this.refreshAllGroupInfo();
        }), o, true);
    }
    onBackView() {
    }
}
