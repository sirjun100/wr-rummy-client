// @ts-nocheck
// Recovered from index.js:203
import { _decorator, Button, EditBox, Label, LabelShadow, Node, ScrollView, size, sys, UITransform, v3, Widget } from "cc";
import BaseLayer from "./BaseLayer";
import SoundManager from "./SoundManager";
import PushCenter from "./PushCenter";
import GameConfig from "./GameConfig";
import { TLog } from "./TLog";
import Utils from "./Utils";
import User from "./User";
import HttpManager from "./HttpManager";
import PushEvent from "./PushEvent";
import CommDefine, { CheckModule } from "./CommDefine";
import i18nMgr from "./i18nMgr";
import TweenTool from "./TweenTool";
import ReportConfig from "./ReportConfig";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("InputVerify")
export class InputVerify extends BaseLayer {
    @property(Node)
    public rootNode: Node = null;
    @property(ScrollView)
    public scrollView: ScrollView = null;
    @property(Node)
    public errTipNode: Node = null;
    @property(Node)
    public panelCenter: Node = null;
    @property(Node)
    public cardNumberNode: Node = null;
    @property(Node)
    public tipsNode: Node = null;
    public cardNumberStr: string = "";
    public scrollItemPosY: number = 0;
    public isLoadingImg: boolean = false;
    public bShowPushAnim: boolean = false;
    public showUICallback: any = null;
    public closeUICallBack: any = null;
    public _closed: boolean = false;
    public _bBtnEnable: boolean = true;
    onLoad() {
        if (ToolUtils.isSafeString(User.shared().kyc_bottom_tip).length > 0) {
            this.tipsNode.getComponent(Label).string = User.shared().kyc_bottom_tip;
        }
        else {
            let e = i18nMgr.shared().getValueByKey("kyc.kyc_18tips");
            this.tipsNode.getComponent(Label).string = e;
        }
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().removeListenersByTag(this);
        this.unscheduleAllCallbacks();
    }
    init(e, t = null, a = null) {
        this.bShowPushAnim = e;
        this.showUICallback = t;
        this.closeUICallBack = a;
    }
    start() {
        super.start();
        this.initView();
        this.bShowPushAnim && ToolUtils.showPushAnim(this.node, 0, (() => {
            this.showUICallback && this.showUICallback();
        }));
        PushCenter.shared().addListener(GameConfig.Update_Kyc, (() => {
            ToolUtils.isObjValid(this.node) && (this.updateCardVerifyView(), 3 == User.shared().data.card_check && ToolUtils.isSafeString(User.shared().newKycData.kyc_list.fast_reason).length > 0 && sys.isObjectValid(User.shared().newKycData.kyc_list) && ToolUtils.isSafeString(User.shared().newKycData.kyc_list.fast_reason).length > 0 && sys.isObjectValid(User.shared().newKycData.kyc_list.trigger_age_pop) && 1 == Number(User.shared().newKycData.kyc_list.trigger_age_pop) && TweenTool.delayAct(this.node, (() => {
                Utils.shared().doJumpLogic(PushEvent.Custom_TO_KycAgeTip);
            }), 1, true));
        }), this);
        HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Hall, event: ReportConfig.hall_evt.enter_kyc_verify });
    }
    onCloseButtonClick(e, t) {
        if (SoundManager.shared().playFx("click"), "back_btn" == t) {
            if (this._closed) {
                return;
            }
            this.onBackView();
        }
    }
    initView() {
        this.fitScreen();
        sys.isObjectValid(User.shared().newKycData.form_list) && User.shared().newKycData.form_list.length > 0 ? this.updateCardVerifyView(true) : (Utils.shared().showLoading(10, true, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3);
        })), HttpManager.shared().doGetKycAccount2(this.listenGetKycAccountCallback.bind(this)));
    }
    listenGetKycAccountCallback(e, t, a) {
        try {
            if (200 != a) {
                alert("The login timed out, please try again");
            }
            else {
                let e = ToolUtils.parseJson(t);
                0 == e.ret && (User.shared().newKycData = e.data, ToolUtils.isObjValid(this.node) && this.updateCardVerifyView());
            }
        }
        catch (e) {
            TLog.printError("listenGetKycVerifyListCallback:", e);
        }
    }
    updateCardVerifyView(e = true) {
        let t = true;
        0 == User.shared().data.card_check || 3 == User.shared().data.card_check ? (t = true, this.rootNode.getChildByName("submit_btn").getComponent(Button).interactable = true, 0 == User.shared().data.card_check ? i18nMgr.shared().changeLabelLanguage(this.rootNode.getChildByName("submit_btn").getChildByName("wz").getComponent(Label), "kyc.submit", true) : (Utils.shared().hideLoading(), i18nMgr.shared().changeLabelLanguage(this.rootNode.getChildByName("submit_btn").getChildByName("wz").getComponent(Label), "kyc.resubmit", true)), Utils.updateLabelMaterial(this.rootNode.getChildByName("submit_btn").getChildByName("wz"), CommDefine.gradient.btn_green), this.rootNode.getChildByName("submit_btn").getChildByName("wz").getComponent(LabelShadow).color = CommDefine.shadowcolor.green) : (t = false, this.rootNode.getChildByName("submit_btn").getComponent(Button).interactable = false, 1 == User.shared().data.card_check ? i18nMgr.shared().changeLabelLanguage(this.rootNode.getChildByName("submit_btn").getChildByName("wz").getComponent(Label), "kyc.verity_pending", true) : (Utils.shared().hideLoading(), i18nMgr.shared().changeLabelLanguage(this.rootNode.getChildByName("submit_btn").getChildByName("wz").getComponent(Label), "kyc.verity_verified", true)), Utils.updateLabelMaterial(this.rootNode.getChildByName("submit_btn").getChildByName("wz"), CommDefine.gradient.btn_gray), this.rootNode.getChildByName("submit_btn").getChildByName("wz").getComponent(LabelShadow).color = CommDefine.shadowcolor.gray);
        e && this.updateErrTips();
        3 == User.shared().data.card_check && sys.isObjectValid(User.shared().newKycData.kyc_list) && ToolUtils.isSafeString(User.shared().newKycData.kyc_list.card).length > 0 && (this.updateCardNumberView(User.shared().newKycData.kyc_list.card, t, e), this.updateCardNumberStatus());
        2 == User.shared().data.card_check && sys.isObjectValid(User.shared().newKycData.kyc_list) && ToolUtils.isSafeString(User.shared().newKycData.kyc_list.card).length > 0 && this.updateCardNumberView(User.shared().newKycData.kyc_list.card, t, e);
    }
    updateErrTips() {
        if (sys.isObjectValid(User.shared().newKycData.kyc_list) && ToolUtils.isSafeString(User.shared().newKycData.kyc_list.fast_reason).length > 0) {
            this.errTipNode.active = true;
            this.errTipNode.getChildByName("tx").getComponent(Label).string = User.shared().newKycData.kyc_list.fast_reason;
            this.errTipNode.getChildByName("tx").getComponent(Label).updateRenderData(true);
            let e = this.errTipNode.getComponent(UITransform).contentSize, t = this.errTipNode.getChildByName("tx").getComponent(UITransform).contentSize.height + 8;
            this.errTipNode.getComponent(UITransform).setContentSize(size(e.width, t));
            this.panelCenter.setPosition(v3(0, -t, 0));
            e = this.scrollView.content.getComponent(UITransform).contentSize;
            this.scrollView.content.getComponent(UITransform).setContentSize(size(e.width, 1000 + t));
        }
        else {
            this.errTipNode.active = false;
            this.errTipNode.getChildByName("tx").getComponent(Label).string = "";
            this.panelCenter.setPosition(v3(0, 0, 0));
            let e = this.scrollView.content.getComponent(UITransform).contentSize;
            this.scrollView.content.getComponent(UITransform).setContentSize(size(e.width, 1000));
        }
    }
    updateCardNumberView(e = "", t, a = true) {
        a && (this.cardNumberStr = e, this.cardNumberNode.getChildByName("del_btn").active = false);
        this.cardNumberNode.getChildByName("EditBox").getComponent(EditBox).string = this.cardNumberStr;
        this.cardNumberNode.getChildByName("content").getComponent(Label).string = this.cardNumberStr;
        this.cardNumberNode.getChildByName("EditBox").active = t;
        this.cardNumberNode.getChildByName("content").active = !t;
        this.cardNumberNode.getChildByName("EditBox").getComponent(EditBox).inputMode = EditBox.InputMode.NUMERIC;
        this.cardNumberNode.getChildByName("EditBox").getComponent(EditBox).maxLength = 12;
        i18nMgr.shared().changeLabelLanguage(this.cardNumberNode.getChildByName("EditBox").getComponent(EditBox).placeholderLabel, "Enter aadhaar No.");
    }
    onButtonClick(e, t) {
        if ("male" != t && "female" != t && SoundManager.shared().playFx("click"), "cardnumber_del" == t) {
            let e = this.cardNumberNode.getChildByName("EditBox");
            e.getComponent(EditBox).string = "";
            e.getComponent(EditBox).blur();
            this.updateCardNumberStatus();
        }
        else if ("kefu" == t) {
            if (1 == User.shared().temp_pingbi.feedback) {
                return void Utils.shared().showToast("Coming soon", 2);
            }
            Utils.shared().doJumpLogic(PushEvent.JUMP_TO_FEEDBACK);
        }
    }
    updateCardNumberStatus() {
        if (this.cardNumberNode) {
            let e = this.cardNumberNode.getChildByName("EditBox");
            this.cardNumberStr = ToolUtils.isSafeString(e.getComponent(EditBox).string);
            this.cardNumberStr.length > 0 && (0 == User.shared().data.card_check || 3 == User.shared().data.card_check) ? this.cardNumberNode.getChildByName("del_btn").active = true : this.cardNumberNode.getChildByName("del_btn").active = false;
        }
    }
    onEditBoxChanged(e, t, a) {
        "card_number" == a && this.updateCardNumberStatus();
    }
    onEditBoxEnded(e, t) {
        "card_number" == t && this.updateCardNumberStatus();
    }
    onSumbitButtonClick(e, t) {
        if (SoundManager.shared().playFx("click"), !this._bBtnEnable) {
            return;
        }
        if (this._bBtnEnable = false, TweenTool.delayAct(this.node, (() => {
            this._bBtnEnable = true;
        }), 1, true), !User.shared().checkLocationPermit(CheckModule.KYC)) {
            return;
        }
        HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Hall, event: ReportConfig.hall_evt.click_kyc_submit });
        sys.isObjectValid(User.shared().newKycData.kyc_list) && sys.isObjectValid(User.shared().newKycData.kyc_list.fast_reason) && User.shared().newKycData.kyc_list.fast_reason > 0 && (User.shared().newKycData.kyc_list.reason = "", User.shared().newKycData.kyc_list.fast_reason = "", this.updateErrTips());
        let a = ToolUtils.isSafeString(this.cardNumberStr);
        12 === a.length ? (Utils.shared().showLoading(30, true, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text37"), 3);
        })), HttpManager.shared().doKycFastSava(a, 5, this.listenSubmitCall.bind(this))) : Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text78"), 2);
    }
    listenSubmitCall(e, t, a) {
        if (200 !== a) {
            ToolUtils.isObjValid(this.node) && (Utils.shared().hideLoading(), Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text37"), 2));
        }
        else {
            try {
                let e = ToolUtils.parseJson(t);
                if (0 === e.ret) {
                    HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Hall, event: ReportConfig.hall_evt.kyc_submit_succ });
                    let t = e.data.card_check;
                    User.shared().data.card_check = t;
                    2 == User.shared().data.card_check ? HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Hall, event: ReportConfig.hall_evt.kyc_verify_succ }) : 3 == User.shared().data.card_check && HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Hall, event: ReportConfig.hall_evt.kyc_verify_fail });
                    sys.isObjectValid(e.data.loading_seconds) && Number(e.data.loading_seconds) > 0 ? ToolUtils.isObjValid(this.node) && (1 == User.shared().data.card_check && (this.rootNode.getChildByName("submit_btn").getComponent(Button).interactable = false, i18nMgr.shared().changeLabelLanguage(this.rootNode.getChildByName("submit_btn").getChildByName("wz").getComponent(Label), "kyc.verity_pending", true), Utils.updateLabelMaterial(this.rootNode.getChildByName("submit_btn").getChildByName("wz"), CommDefine.gradient.btn_gray)), Utils.shared().showLoading(Number(e.data.loading_seconds), true, (() => {
                        Utils.shared().hideLoading();
                        User.shared().doGetKycVerifyList();
                        ToolUtils.isObjValid(this.node) && this.onBackView();
                        Utils.shared().showToast(i18nMgr.shared().getValueByKey("kyc.submit_success"), 3.5);
                    }), ToolUtils.getIsNormalDirection(), 1)) : (ToolUtils.isObjValid(this.node) && Utils.shared().hideLoading(), sys.isObjectValid(e.data.fast_reason) && (User.shared().newKycData.kyc_list.fast_reason = e.data.fast_reason), sys.isObjectValid(e.data.trigger_age_pop) && (User.shared().newKycData.kyc_list.trigger_age_pop = e.data.trigger_age_pop), 2 != t && 1 != t || (User.shared().newKycData.kyc_list.reason = "", User.shared().newKycData.kyc_list.fast_reason = "", User.shared().newKycData.kyc_list.trigger_age_pop = 0, ToolUtils.isObjValid(this.node) && (User.shared().updateKycAccount2(e.data), 2 == t && (sys.isObjectValid(e.data.reward_list) && e.data.reward_list.length > 0 ? Utils.shared().showKycVerifySucTip(e.data.reward_list, i18nMgr.shared().getValueByKey("kyc.KYC_Verify_Suc")) : Utils.shared().showToast(i18nMgr.shared().getValueByKey("kyc.KYC_Verify_Suc"), 3.5)), ToolUtils.isObjValid(this.node) && this.onBackView())), PushCenter.shared().pushEvent(GameConfig.Update_Kyc, User.shared().data.kyc_check));
                }
                else if (4027 === e.ret) {
                    User.shared().data.submit_left_hour = e.data.submit_left_seconds;
                    Utils.shared().doJumpLogic(PushEvent.Custom_TO_KycLimitTip);
                }
                else {
                    ToolUtils.isObjValid(this.node) && (Utils.shared().hideLoading(), e.desc && e.desc.length > 0 && Utils.shared().showToast(e.desc, 2));
                    let t = e.ret + ToolUtils.isSafeString(e.desc);
                    HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Hall, event: ReportConfig.hall_evt.kyc_submit_fail, kyc_err: t });
                }
            }
            catch (e) {
                ToolUtils.isObjValid(this.node) && Utils.shared().hideLoading();
                let t = ToolUtils.isSafeString(e.toString());
                HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Hall, event: ReportConfig.hall_evt.kyc_submit_fail, kyc_err: t });
            }
        }
    }
    onBackView(e = true) {
        e && (Utils.shared().hideLoading(), this.closeUICallBack && this.closeUICallBack(), this.bShowPushAnim ? (this._closed = true, ToolUtils.showPushAnim(this.node, 1, (() => {
            ToolUtils.isObjValid(this.node) && this.node.destroy();
        }))) : ToolUtils.isObjValid(this.node) && this.node.destroy());
    }
    fitScreen() {
        ToolUtils.adaptSafeArea(this.rootNode);
        let e = sys.getSafeAreaRect().y;
        this.rootNode.getChildByName("tips").getComponent(Widget).bottom = 120 - e;
        this.rootNode.getChildByName("submit_btn").getComponent(Widget).bottom = 20 - e;
        2 == i18nMgr.shared().language && (this.rootNode.getChildByName("tips").getComponent(Widget).bottom = 150 - e);
    }
}
