// @ts-nocheck
// Recovered from index.js:207
import { _decorator, Label, ScrollView } from "cc";
import SoundManager from "./SoundManager";
import BaseLayer from "./BaseLayer";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("InviteHelp")
export class InviteHelp extends BaseLayer {
    @property(ScrollView)
    public scrollView: ScrollView = null;
    @property(Label)
    public txt_content: Label = null;
    public txt: any = null;
    start() {
        super.start();
        ToolUtils.startShowAnim(this.node.getChildByName("helpNode"));
        this.txt && this.txt.length > 0 && (this.txt_content.string = this.txt, this.txt_content.updateRenderData(true));
    }
    setParaData(t) {
        this.txt = t;
    }
    button_click(t, e) {
        SoundManager.shared().playFx("click");
        "close" == e && ToolUtils.isObjValid(this.node) && this.node.destroy();
    }
}
