// @ts-nocheck
// Recovered from index.js:559
import { _decorator, Button, color, instantiate, Label, Node, ScrollView, size, Sprite, SpriteFrame, sys, UITransform, v3 } from "cc";
import SoundManager from "./SoundManager";
import PushCenter from "./PushCenter";
import { TLog } from "./TLog";
import Utils from "./Utils";
import User from "./User";
import i18nMgr from "./i18nMgr";
import BaseLayer from "./BaseLayer";
import GameConfig from "./GameConfig";
import PushEvent from "./PushEvent";
import TweenTool from "./TweenTool";
import { ToolUtils } from "./ToolUtils";
import SportCricket_Manager from "./SportCricket_Manager";
import ScrollVisibility from "./ScrollVisibility";
import PhpReportDefined from "./PhpReportDefined";
const { ccclass, property } = _decorator;
@ccclass("SportCricket_FastCreateTeam")
export class SportCricket_FastCreateTeam extends BaseLayer {
    public TAG: string = "SportCricket_FastCreateTeam";
    @property(Node)
    public rootNode: Node = null;
    @property(Node)
    public goldNode: Node = null;
    @property(Node)
    public nextNode: Node = null;
    @property(Node)
    public detailsNode: Node = null;
    @property(Node)
    public bottomNode: Node = null;
    @property(Node)
    public scrollView: Node = null;
    @property(Node)
    public contentNode: Node = null;
    @property([SpriteFrame])
    public btnBgImgs: SpriteFrame[] = [];
    @property([SpriteFrame])
    public progressImgs: SpriteFrame[] = [];
    @property([SpriteFrame])
    public styleImgs: SpriteFrame[] = [];
    @property([SpriteFrame])
    public operateImgs: SpriteFrame[] = [];
    @property([Node])
    public tabNodes: Node[] = [];
    public leader_listData: any[] = [];
    @property(Node)
    public mobanView: Node = null;
    @property(Node)
    public teama_mobanView: Node = null;
    @property(Node)
    public teamb_mobanView: Node = null;
    public _closed: boolean = false;
    public bShowPushAnim: boolean = true;
    public _lastClick: number = 0;
    public _sourceData: any = null;
    public _itemArr: any[] = [];
    public _isSendMsg: boolean = false;
    public tabWzColor: any[] = [color(183, 0, 0), color(84, 89, 155)];
    public taskAwardIconMap: Map = new Map;
    public _match_id: number = 0;
    public _contest_id: number = 0;
    public _contest_source: any = null;
    public _player_source: any = null;
    public _team_id: number = 0;
    public _source: any = null;
    public _lineup: number = 0;
    public _fromType: number = 0;
    public lastClick: number = 0;
    public _creditsLeft: number = 100;
    public _teamAPlayerNum: number = 0;
    public _teamBPlayerNum: number = 0;
    public _selectPlayerNum: number = 0;
    public _teamSortType: number = 1;
    public _pointsSortType: number = 1;
    public _creditsSortType: number = 1;
    public _curSortType: number = 1;
    public _selectPlayerIds: any[] = [];
    public _wkSelectNum: number = 0;
    public _batSelectNum: number = 0;
    public _arSelectNum: number = 0;
    public _bowlSelectNum: number = 0;
    public _allPlayerMsg: Map = new Map;
    public _allPlayerView: any[] = [];
    public _backupPlayers: any[] = [];
    public playerViewMap: Map = new Map;
    public _match_state: number = 1;
    public _lastNode: any = null;
    public _teamAPlayers_lastOrPlay: any[] = [];
    public _teamBPlayers_lastOrPlay: any[] = [];
    public _teamAPlayers_subPlay: any[] = [];
    public _teamBPlayers_subPlay: any[] = [];
    public _teamAPlayers_other: any[] = [];
    public _teamBPlayers_other: any[] = [];
    public _call: any = null;
    public _posY: number = 0;
    public _cntSize: number = 0;
    public _is_chip: number = 0;
    public _curTabIndex: number = 0;
    onLoad() {
        PushCenter.shared().addListener(PushEvent.commentDownloaderImg, (e => {
            try {
                if (ToolUtils.isObjValid(this.node) && this.taskAwardIconMap.size > 0) {
                    for (const [t, s] of this.taskAwardIconMap) {
                        s == e && sys.isObjectValid(t) && ("player_icon" == t.name ? Utils.shared().updateNetImage(t, e, size(66, 66)) : Utils.shared().updateNetImage(t, e, size(76, 76)));
                    }
                }
            }
            catch (e) {
                TLog.printError(this.TAG, PushEvent.commentDownloaderImg, e);
            }
        }), this);
    }
    fitLuckyTheme() {
        0 != GameConfig.NATIVE_GAME_APP_TYPE && (this.tabWzColor = [color(183, 0, 0), color(84, 89, 155)], this.rootNode.getChildByName("top_node").getChildByName("top_bg").getComponent(Sprite).color = color(12, 26, 60, 255), this.goldNode.getChildByName("coin").getComponent(Label).color = color(251, 220, 0, 255), this.rootNode.getChildByName("details").getChildByName("bg").getComponent(Sprite).color = color(12, 26, 60, 255), this.rootNode.getChildByName("details").getChildByName("lefttime_tip").getComponent(Label).color = color(153, 164, 221, 255), this.rootNode.getChildByName("details").getChildByName("title").getComponent(Label).color = color(153, 164, 221, 255));
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().removeListenersByTag(this);
        this.unscheduleAllCallbacks();
    }
    init(e) {
        sys.isObjectValid(e) && sys.isObjectValid(e.match_id) && (this._match_id = e.match_id);
        sys.isObjectValid(e) && sys.isObjectValid(e.player_source) && (this._player_source = e.player_source);
        sys.isObjectValid(e) && sys.isObjectValid(e.source) && (this._source = { ...e.source });
        sys.isObjectValid(e) && sys.isObjectValid(e.fromType) && (this._fromType = e.fromType);
        sys.isObjectValid(e) && sys.isObjectValid(e.contest_id) && (this._contest_id = e.contest_id);
        sys.isObjectValid(e) && sys.isObjectValid(e.team_id) && (this._team_id = e.team_id);
        sys.isObjectValid(e) && sys.isObjectValid(e.lastNode) && (this._lastNode = e.lastNode);
        sys.isObjectValid(e) && sys.isObjectValid(e.lineup) && (this._lineup = e.lineup);
        sys.isObjectValid(e) && sys.isObjectValid(e.fromType) && (this._fromType = e.fromType);
        sys.isObjectValid(e) && sys.isObjectValid(e.backkup_Players) && (this._backupPlayers = e.backkup_Players);
        sys.isObjectValid(e) && sys.isObjectValid(e.call) && (this._call = e.call);
        sys.isObjectValid(e) && sys.isObjectValid(e.is_chip) && (this._is_chip = e.is_chip);
    }
    start() {
        super.start();
    }
    updateTabView() {
        let e = [color(51, 51, 51), color(168, 26, 26)];
        for (let t = 0; t < 2; t++) {
            this.tabNodes[t].getChildByName("ico").active = this._curTabIndex == t;
            t == this._curTabIndex ? this.tabNodes[t].getChildByName("Label").getComponent(Label).color = e[1] : this.tabNodes[t].getChildByName("Label").getComponent(Label).color = e[0];
            i18nMgr.shared().changeLabelFont(this.tabNodes[t].getChildByName("Label").getComponent(Label), t == this._curTabIndex);
        }
    }
    filterSelectPlayer() {
        if (this._selectPlayerIds = [], this._allPlayerMsg.clear(), this._creditsLeft = 100, this._teamAPlayerNum = 0, this._teamBPlayerNum = 0, this._wkSelectNum = 0, this._batSelectNum = 0, this._arSelectNum = 0, this._bowlSelectNum = 0, this._teamAPlayers_lastOrPlay = [], this._teamBPlayers_lastOrPlay = [], this._teamAPlayers_other = [], this._teamBPlayers_other = [], this._teamAPlayers_subPlay = [], this._teamBPlayers_subPlay = [], sys.isObjectValid(this._player_source)) {
            if (sys.isObjectValid(this._player_source.credits) && (this._creditsLeft = this._player_source.credits), sys.isObjectValid(this._player_source.wk) && this._player_source.wk.length > 0) {
                for (let e = 0; e < this._player_source.wk.length; e++) {
                    1 == this._player_source.wk[e].playing11 && (this._lineup = 1);
                    this._player_source.wk[e].role = "WK";
                    this._allPlayerMsg.set(this._player_source.wk[e].player_id, this._player_source.wk[e]);
                    1 == this._player_source.wk[e].select_status && (this._selectPlayerIds.push(this._player_source.wk[e].player_id), this._creditsLeft -= this._player_source.wk[e].credits, this._wkSelectNum += 1, this._player_source.wk[e].team_id == this._player_source.teama.tid ? this._teamAPlayerNum += 1 : this._teamBPlayerNum += 1);
                }
            }
            if (sys.isObjectValid(this._player_source.bat) && this._player_source.bat.length > 0) {
                for (let e = 0; e < this._player_source.bat.length; e++) {
                    1 == this._player_source.bat[e].playing11 && (this._lineup = 1);
                    this._player_source.bat[e].role = "BAT";
                    this._allPlayerMsg.set(this._player_source.bat[e].player_id, this._player_source.bat[e]);
                    1 == this._player_source.bat[e].select_status && (this._selectPlayerIds.push(this._player_source.bat[e].player_id), this._creditsLeft -= this._player_source.bat[e].credits, this._batSelectNum += 1, this._player_source.bat[e].team_id == this._player_source.teama.tid ? this._teamAPlayerNum += 1 : this._teamBPlayerNum += 1);
                }
            }
            if (sys.isObjectValid(this._player_source.ar) && this._player_source.ar.length > 0) {
                for (let e = 0; e < this._player_source.ar.length; e++) {
                    1 == this._player_source.ar[e].playing11 && (this._lineup = 1);
                    this._player_source.ar[e].role = "AR";
                    this._allPlayerMsg.set(this._player_source.ar[e].player_id, this._player_source.ar[e]);
                    1 == this._player_source.ar[e].select_status && (this._arSelectNum += 1, this._selectPlayerIds.push(this._player_source.ar[e].player_id), this._creditsLeft -= this._player_source.ar[e].credits, this._player_source.ar[e].team_id == this._player_source.teama.tid ? this._teamAPlayerNum += 1 : this._teamBPlayerNum += 1);
                }
            }
            if (sys.isObjectValid(this._player_source.bowl) && this._player_source.bowl.length > 0) {
                for (let e = 0; e < this._player_source.bowl.length; e++) {
                    1 == this._player_source.bowl[e].playing11 && (this._lineup = 1);
                    this._player_source.bowl[e].role = "BOWL";
                    this._allPlayerMsg.set(this._player_source.bowl[e].player_id, this._player_source.bowl[e]);
                    1 == this._player_source.bowl[e].select_status && (this._bowlSelectNum += 1, this._selectPlayerIds.push(this._player_source.bowl[e].player_id), this._creditsLeft -= this._player_source.bowl[e].credits, this._player_source.bowl[e].team_id == this._player_source.teama.tid ? this._teamAPlayerNum += 1 : this._teamBPlayerNum += 1);
                }
            }
            this.filterTeamPlayer();
        }
    }
    filterTeamPlayer() {
        if (sys.isObjectValid(this._player_source.wk) && this._player_source.wk.length > 0) {
            for (let e = 0; e < this._player_source.wk.length; e++) {
                1 == this._lineup ? 1 == this._player_source.wk[e].playing11 && this._player_source.wk[e].team_id == this._player_source.teama.tid ? this._teamAPlayers_lastOrPlay.push(this._player_source.wk[e]) : 1 == this._player_source.wk[e].playing11 && this._player_source.wk[e].team_id == this._player_source.teamb.tid ? this._teamBPlayers_lastOrPlay.push(this._player_source.wk[e]) : 1 != this._player_source.wk[e].playing11 && this._player_source.wk[e].team_id == this._player_source.teama.tid ? 1 == this._player_source.wk[e].subplayer ? this._teamAPlayers_subPlay.push(this._player_source.wk[e]) : this._teamAPlayers_other.push(this._player_source.wk[e]) : 1 != this._player_source.wk[e].playing11 && this._player_source.wk[e].team_id == this._player_source.teamb.tid && (1 == this._player_source.wk[e].subplayer ? this._teamBPlayers_subPlay.push(this._player_source.wk[e]) : this._teamBPlayers_other.push(this._player_source.wk[e])) : 1 == this._player_source.wk[e].join_last_match && this._player_source.wk[e].team_id == this._player_source.teama.tid ? this._teamAPlayers_lastOrPlay.push(this._player_source.wk[e]) : 1 == this._player_source.wk[e].join_last_match && this._player_source.wk[e].team_id == this._player_source.teamb.tid ? this._teamBPlayers_lastOrPlay.push(this._player_source.wk[e]) : 1 != this._player_source.wk[e].join_last_match && this._player_source.wk[e].team_id == this._player_source.teama.tid ? this._teamAPlayers_other.push(this._player_source.wk[e]) : 1 != this._player_source.wk[e].join_last_match && this._player_source.wk[e].team_id == this._player_source.teamb.tid && this._teamBPlayers_other.push(this._player_source.wk[e]);
            }
        }
        if (sys.isObjectValid(this._player_source.bat) && this._player_source.bat.length > 0) {
            for (let e = 0; e < this._player_source.bat.length; e++) {
                1 == this._lineup ? 1 == this._player_source.bat[e].playing11 && this._player_source.bat[e].team_id == this._player_source.teama.tid ? this._teamAPlayers_lastOrPlay.push(this._player_source.bat[e]) : 1 == this._player_source.bat[e].playing11 && this._player_source.bat[e].team_id == this._player_source.teamb.tid ? this._teamBPlayers_lastOrPlay.push(this._player_source.bat[e]) : 1 != this._player_source.bat[e].playing11 && this._player_source.bat[e].team_id == this._player_source.teama.tid ? 1 == this._player_source.bat[e].subplayer ? this._teamAPlayers_subPlay.push(this._player_source.bat[e]) : this._teamAPlayers_other.push(this._player_source.bat[e]) : 1 != this._player_source.bat[e].playing11 && this._player_source.bat[e].team_id == this._player_source.teamb.tid && (1 == this._player_source.bat[e].subplayer ? this._teamBPlayers_subPlay.push(this._player_source.bat[e]) : this._teamBPlayers_other.push(this._player_source.bat[e])) : 1 == this._player_source.bat[e].join_last_match && this._player_source.bat[e].team_id == this._player_source.teama.tid ? this._teamAPlayers_lastOrPlay.push(this._player_source.bat[e]) : 1 == this._player_source.bat[e].join_last_match && this._player_source.bat[e].team_id == this._player_source.teamb.tid ? this._teamBPlayers_lastOrPlay.push(this._player_source.bat[e]) : 1 != this._player_source.bat[e].join_last_match && this._player_source.bat[e].team_id == this._player_source.teama.tid ? this._teamAPlayers_other.push(this._player_source.bat[e]) : 1 != this._player_source.bat[e].join_last_match && this._player_source.bat[e].team_id == this._player_source.teamb.tid && this._teamBPlayers_other.push(this._player_source.bat[e]);
            }
        }
        if (sys.isObjectValid(this._player_source.ar) && this._player_source.ar.length > 0) {
            for (let e = 0; e < this._player_source.ar.length; e++) {
                1 == this._lineup ? 1 == this._player_source.ar[e].playing11 && this._player_source.ar[e].team_id == this._player_source.teama.tid ? this._teamAPlayers_lastOrPlay.push(this._player_source.ar[e]) : 1 == this._player_source.ar[e].playing11 && this._player_source.ar[e].team_id == this._player_source.teamb.tid ? this._teamBPlayers_lastOrPlay.push(this._player_source.ar[e]) : 1 != this._player_source.ar[e].playing11 && this._player_source.ar[e].team_id == this._player_source.teama.tid ? 1 == this._player_source.ar[e].subplayer ? this._teamAPlayers_subPlay.push(this._player_source.ar[e]) : this._teamAPlayers_other.push(this._player_source.ar[e]) : 1 != this._player_source.ar[e].playing11 && this._player_source.ar[e].team_id == this._player_source.teamb.tid && (1 == this._player_source.ar[e].subplayer ? this._teamBPlayers_subPlay.push(this._player_source.ar[e]) : this._teamBPlayers_other.push(this._player_source.ar[e])) : 1 == this._player_source.ar[e].join_last_match && this._player_source.ar[e].team_id == this._player_source.teama.tid ? this._teamAPlayers_lastOrPlay.push(this._player_source.ar[e]) : 1 == this._player_source.ar[e].join_last_match && this._player_source.ar[e].team_id == this._player_source.teamb.tid ? this._teamBPlayers_lastOrPlay.push(this._player_source.ar[e]) : 1 != this._player_source.ar[e].join_last_match && this._player_source.ar[e].team_id == this._player_source.teama.tid ? this._teamAPlayers_other.push(this._player_source.ar[e]) : 1 != this._player_source.ar[e].join_last_match && this._player_source.ar[e].team_id == this._player_source.teamb.tid && this._teamBPlayers_other.push(this._player_source.ar[e]);
            }
        }
        if (sys.isObjectValid(this._player_source.bowl) && this._player_source.bowl.length > 0) {
            for (let e = 0; e < this._player_source.bowl.length; e++) {
                1 == this._lineup ? 1 == this._player_source.bowl[e].playing11 && this._player_source.bowl[e].team_id == this._player_source.teama.tid ? this._teamAPlayers_lastOrPlay.push(this._player_source.bowl[e]) : 1 == this._player_source.bowl[e].playing11 && this._player_source.bowl[e].team_id == this._player_source.teamb.tid ? this._teamBPlayers_lastOrPlay.push(this._player_source.bowl[e]) : 1 != this._player_source.bowl[e].playing11 && this._player_source.bowl[e].team_id == this._player_source.teama.tid ? 1 == this._player_source.bowl[e].subplayer ? this._teamAPlayers_subPlay.push(this._player_source.bowl[e]) : this._teamAPlayers_other.push(this._player_source.bowl[e]) : 1 != this._player_source.bowl[e].playing11 && this._player_source.bowl[e].team_id == this._player_source.teamb.tid && (1 == this._player_source.bowl[e].subplayer ? this._teamBPlayers_subPlay.push(this._player_source.bowl[e]) : this._teamBPlayers_other.push(this._player_source.bowl[e])) : 1 == this._player_source.bowl[e].join_last_match && this._player_source.bowl[e].team_id == this._player_source.teama.tid ? this._teamAPlayers_lastOrPlay.push(this._player_source.bowl[e]) : 1 == this._player_source.bowl[e].join_last_match && this._player_source.bowl[e].team_id == this._player_source.teamb.tid ? this._teamBPlayers_lastOrPlay.push(this._player_source.bowl[e]) : 1 != this._player_source.bowl[e].join_last_match && this._player_source.bowl[e].team_id == this._player_source.teama.tid ? this._teamAPlayers_other.push(this._player_source.bowl[e]) : 1 != this._player_source.bowl[e].join_last_match && this._player_source.bowl[e].team_id == this._player_source.teamb.tid && this._teamBPlayers_other.push(this._player_source.bowl[e]);
            }
        }
        this._teamAPlayers_lastOrPlay.sort(((e, t) => 0 == this._curTabIndex ? e.pts !== t.pts ? t.pts - e.pts : t.credits - e.credits : e.member_prob !== t.member_prob ? t.member_prob - e.member_prob : t.credits - e.credits));
        this._teamBPlayers_lastOrPlay.sort(((e, t) => 0 == this._curTabIndex ? e.pts !== t.pts ? t.pts - e.pts : t.credits - e.credits : e.member_prob !== t.member_prob ? t.member_prob - e.member_prob : t.credits - e.credits));
        this._teamAPlayers_other.sort(((e, t) => 0 == this._curTabIndex ? e.pts !== t.pts ? t.pts - e.pts : t.credits - e.credits : e.member_prob !== t.member_prob ? t.member_prob - e.member_prob : t.credits - e.credits));
        this._teamBPlayers_other.sort(((e, t) => 0 == this._curTabIndex ? e.pts !== t.pts ? t.pts - e.pts : t.credits - e.credits : e.member_prob !== t.member_prob ? t.member_prob - e.member_prob : t.credits - e.credits));
        this._teamAPlayers_subPlay.sort(((e, t) => 0 == this._curTabIndex ? e.pts !== t.pts ? t.pts - e.pts : t.credits - e.credits : e.member_prob !== t.member_prob ? t.member_prob - e.member_prob : t.credits - e.credits));
        this._teamBPlayers_subPlay.sort(((e, t) => 0 == this._curTabIndex ? e.pts !== t.pts ? t.pts - e.pts : t.credits - e.credits : e.member_prob !== t.member_prob ? t.member_prob - e.member_prob : t.credits - e.credits));
        1 == this._lineup ? (this.contentNode.getChildByName("playing_node").getChildByName("wz").getComponent(Label).string = i18nMgr.shared().getValueByKey("yes11.fastc_play"), this.contentNode.getChildByName("noplay_node").getChildByName("wz").getComponent(Label).string = i18nMgr.shared().getValueByKey("yes11.fastc_noplay"), this._teamAPlayers_subPlay.length > 0 || this._teamBPlayers_subPlay.length > 0 ? (this.contentNode.getChildByName("sub_node").active = true, this.contentNode.getChildByName("sub_layout").active = true) : (this.contentNode.getChildByName("sub_node").active = false, this.contentNode.getChildByName("sub_layout").active = false), this.contentNode.getChildByName("playing_node").getChildByName("ico").getComponent(Sprite).color = color(33, 193, 41), this.contentNode.getChildByName("noplay_node").getChildByName("ico").getComponent(Sprite).color = color(245, 94, 94)) : (this.contentNode.getChildByName("sub_node").active = false, this.contentNode.getChildByName("sub_layout").active = false, this.contentNode.getChildByName("playing_node").getChildByName("wz").getComponent(Label).string = i18nMgr.shared().getValueByKey("yes11.fastc_plast_match"), this.contentNode.getChildByName("noplay_node").getChildByName("wz").getComponent(Label).string = i18nMgr.shared().getValueByKey("yes11.fastc_other"), this.contentNode.getChildByName("playing_node").getChildByName("ico").getComponent(Sprite).color = color(77, 119, 252), this.contentNode.getChildByName("noplay_node").getChildByName("ico").getComponent(Sprite).color = color(44, 53, 69));
    }
    refreshView() {
        this.updateTabView();
        this.updateTabContent();
        this.updateStatInfo();
    }
    updateStatInfo() {
        sys.isObjectValid(this._player_source) && (sys.isObjectValid(this._player_source.pitch) && (this.detailsNode.getChildByName("stat_node").getChildByName("pitch_desc").getComponent(Label).string = this._player_source.pitch), sys.isObjectValid(this._player_source.goodfor) && (this.detailsNode.getChildByName("stat_node").getChildByName("goodfor_desc").getComponent(Label).string = this._player_source.goodfor), sys.isObjectValid(this._player_source.avg) && (this.detailsNode.getChildByName("stat_node").getChildByName("avg_desc").getComponent(Label).string = this._player_source.avg));
    }
    updateSelectPlayerNum() {
        this.detailsNode.getChildByName("pnum").getComponent(Label).string = String(this._selectPlayerNum) + "/11";
    }
    updateTeamASelectPlayerNum() {
        this.detailsNode.getChildByName("team_num0").getComponent(Label).string = String(this._teamAPlayerNum);
    }
    updateTeamBSelectPlayerNum() {
        this.detailsNode.getChildByName("team_num1").getComponent(Label).string = String(this._teamBPlayerNum);
    }
    updateProgress() {
        for (let e = 0; e < 11; e++) {
            e < this._selectPlayerNum ? this.detailsNode.getChildByName("progress" + e).getComponent(Sprite).spriteFrame = 0 == e ? this.progressImgs[3] : 10 == e ? this.progressImgs[2] : this.progressImgs[0] : this.detailsNode.getChildByName("progress" + e).getComponent(Sprite).spriteFrame = 0 == e ? this.progressImgs[5] : 10 == e ? this.progressImgs[4] : this.progressImgs[1];
        }
        if (this.detailsNode.getChildByName("progress_wz0").getComponent(Label).string = String(this._selectPlayerNum), this.detailsNode.getChildByName("progress_wz0").active = this._selectPlayerNum > 0, this._selectPlayerNum > 0) {
            let e = this.detailsNode.getChildByName("progress" + (this._selectPlayerNum - 1)).getPosition();
            this.detailsNode.getChildByName("progress_wz0").setPosition(e);
        }
        this.detailsNode.getChildByName("progress_wz1").active = 11 != this._selectPlayerNum;
        this.detailsNode.getChildByName("progress_wz1").active = false;
        this.detailsNode.getChildByName("progress_wz0").active = false;
    }
    updateLeftCredits() {
        this.bottomNode.getChildByName("credits_num").getComponent(Label).string = String(this._creditsLeft);
    }
    updateContestDetails() {
        if (0 == this._fromType && (this._teamAPlayerNum = 0, this._teamBPlayerNum = 0, this._selectPlayerNum = 0), !sys.isObjectValid(this._player_source)) {
            return;
        }
        this.filterSelectPlayer();
        this._selectPlayerNum = this._selectPlayerIds.length;
        this.updateSelectPlayerNum();
        this.updateTeamASelectPlayerNum();
        this.updateTeamBSelectPlayerNum();
        this.updateLeftCredits();
        this.updateProgress();
        this.updateNextButtonStatus();
        let e = this._player_source.teama, t = this._player_source.teamb;
        sys.isObjectValid(e.abbr) && e.abbr.length > 0 && (this.detailsNode.getChildByName("team_short_name0").getComponent(Label).string = e.abbr);
        sys.isObjectValid(t.abbr) && t.abbr.length > 0 && (this.detailsNode.getChildByName("team_short_name1").getComponent(Label).string = t.abbr);
        sys.isObjectValid(e.thumb_url) && e.thumb_url.length > 0 && (this.taskAwardIconMap.set(this.detailsNode.getChildByName("team_icon0"), e.thumb_url), Utils.shared().updateNetImage(this.detailsNode.getChildByName("team_icon0"), e.thumb_url, size(76, 76)));
        sys.isObjectValid(t.thumb_url) && t.thumb_url.length > 0 && (this.taskAwardIconMap.set(this.detailsNode.getChildByName("team_icon1"), t.thumb_url), Utils.shared().updateNetImage(this.detailsNode.getChildByName("team_icon1"), t.thumb_url, size(76, 76)));
    }
    reSortPlayerInfo() {
        this.contentNode.getChildByName("playing_node").active = true;
        this.contentNode.getChildByName("noplay_node").active = true;
        this.contentNode.getChildByName("playing_layout").removeAllChildren();
        this.contentNode.getChildByName("notplay_layout").removeAllChildren();
        this.scrollView.getComponent(ScrollView).scrollToTop(0);
        this._allPlayerView = [];
        this.playerViewMap.clear();
        this._cntSize = 0;
        this._posY = 0;
        this.contentNode.getChildByName("playing_node").setPosition(v3(0, this._posY));
        this._cntSize += 38;
        this._posY -= 38;
        this.contentNode.getChildByName("playing_layout").setPosition(v3(0, this._posY));
        this.addItemView(this.contentNode.getChildByName("playing_layout"), 0);
        1 == this._lineup && (this._teamAPlayers_subPlay.length > 0 || this._teamBPlayers_subPlay.length > 0) && (this.contentNode.getChildByName("sub_node").setPosition(v3(0, this._posY)), this._posY -= 58, this._cntSize += 58, this.contentNode.getChildByName("sub_layout").setPosition(v3(0, this._posY)), this.addItemView(this.contentNode.getChildByName("sub_layout"), 1));
        this.contentNode.getChildByName("noplay_node").setPosition(v3(0, this._posY));
        this._posY -= 58;
        this._cntSize += 58;
        this.contentNode.getChildByName("notplay_layout").setPosition(v3(0, this._posY));
        this.addItemView(this.contentNode.getChildByName("notplay_layout"), 2);
        this.scrollView.getComponent(ScrollView).content.getComponent(UITransform).contentSize = size(720, this._cntSize);
        let e = 11 - this._selectPlayerNum, t = 0;
        0 == this._wkSelectNum && (t += 1);
        0 == this._batSelectNum && (t += 1);
        0 == this._arSelectNum && (t += 1);
        0 == this._bowlSelectNum && (t += 1);
        e <= t && (0 != this._wkSelectNum && this.updatePlayerViewMask(1, "WK"), 0 != this._batSelectNum && this.updatePlayerViewMask(1, "BAT"), 0 != this._arSelectNum && this.updatePlayerViewMask(1, "AR"), 0 != this._bowlSelectNum && this.updatePlayerViewMask(1, "BOWL"));
        10 == this._teamAPlayerNum && 0 == this._teamBPlayerNum ? this.updatePlayerViewMask(1, "-", 1) : 10 == this._teamBPlayerNum && 0 == this._teamAPlayerNum && this.updatePlayerViewMask(1, "-", 0);
        this.scrollView.getComponent(ScrollVisibility).updateVisibility();
    }
    addItemView(e, t) {
        let s = 0;
        0 == t ? (s = this._teamAPlayers_lastOrPlay.length, s < this._teamBPlayers_lastOrPlay.length && (s = this._teamBPlayers_lastOrPlay.length)) : 1 == t ? (s = this._teamAPlayers_subPlay.length, s < this._teamBPlayers_subPlay.length && (s = this._teamBPlayers_subPlay.length)) : (s = this._teamAPlayers_other.length, s < this._teamBPlayers_other.length && (s = this._teamBPlayers_other.length));
        e.getComponent(UITransform).contentSize = size(720, 100 * s);
        for (let a = 0; a < s; a++) {
            this._cntSize += 100;
            this._posY -= 100;
            let s = instantiate(this.mobanView);
            s.active = true;
            e.addChild(s);
            s.setPosition(v3(0, -100 * a));
            let i = null, l = null;
            0 == t ? (a < this._teamAPlayers_lastOrPlay.length && (i = this._teamAPlayers_lastOrPlay[a]), a < this._teamBPlayers_lastOrPlay.length && (l = this._teamBPlayers_lastOrPlay[a])) : 1 == t ? (a < this._teamAPlayers_subPlay.length && (i = this._teamAPlayers_subPlay[a]), a < this._teamBPlayers_subPlay.length && (l = this._teamBPlayers_subPlay[a])) : (a < this._teamAPlayers_other.length && (i = this._teamAPlayers_other[a]), a < this._teamBPlayers_other.length && (l = this._teamBPlayers_other[a]));
            sys.isObjectValid(i) && this.addPlayerView(s.getChildByName("node0"), i, t, 0, a);
            sys.isObjectValid(l) && this.addPlayerView(s.getChildByName("node1"), l, t, 1, a);
        }
    }
    addPlayerView(e, t, s, a, i) {
        let l = null;
        l = instantiate(0 == a ? this.teama_mobanView : this.teamb_mobanView);
        l.active = true;
        e.addChild(l);
        this._allPlayerView.push(l);
        let r = ToolUtils.toJsonString(t);
        if (l.getChildByName("op_btn").getComponent(Button).clickEvents[0].customEventData = r, this.playerViewMap.set(t.player_id, l), l.getChildByName("player_icon").getComponent(Button).clickEvents[0].customEventData = r, l.getChildByName("no").active = 0 == s, 0 == s && (l.getChildByName("no").getComponent(Label).string = String(i + 1)), -1 != this._selectPlayerIds.indexOf(t.player_id) ? (l.getChildByName("bg").getComponent(Sprite).color = color(255, 247, 224), l.getChildByName("op_btn").getChildByName("ico").getComponent(Sprite).spriteFrame = this.operateImgs[1]) : (l.getChildByName("bg").getComponent(Sprite).color = color(255, 255, 255), l.getChildByName("op_btn").getChildByName("ico").getComponent(Sprite).spriteFrame = this.operateImgs[0], "WK" == t.role ? l.getChildByName("mask").active = 8 == this._wkSelectNum : "BAT" == t.role ? l.getChildByName("mask").active = 8 == this._batSelectNum : "AR" == t.role ? l.getChildByName("mask").active = 8 == this._arSelectNum : "BOWL" == t.role && (l.getChildByName("mask").active = 8 == this._bowlSelectNum)), sys.isObjectValid(t.thumb_url) && t.thumb_url.length > 0 && (this.taskAwardIconMap.set(l.getChildByName("player_icon"), t.thumb_url), Utils.shared().updateNetImage(l.getChildByName("player_icon"), t.thumb_url, size(66, 66))), 0 == this._curTabIndex ? sys.isObjectValid(t.pts) && (l.getChildByName("pts").getComponent(Label).string = ToolUtils.format(i18nMgr.shared().getValueByKey("yes11.fastc_pts_form"), t.role, t.pts)) : sys.isObjectValid(t.member_prob) && (l.getChildByName("pts").getComponent(Label).string = ToolUtils.format(i18nMgr.shared().getValueByKey("yes11.fastc_rate_form"), t.role, t.member_prob + "%")), sys.isObjectValid(t.short_name) && (l.getChildByName("pname").getComponent(Label).string = ToolUtils.GetShortName2(String(t.short_name), 7, false), l.getChildByName("pname").getComponent(Label).updateRenderData(true)), l.getChildByName("role").active = false, ("AR" == t.role || "BOWL" == t.role) && sys.isObjectValid(t.bowling_style) && Number(t.bowling_style) > 0) {
            1 == Number(t.bowling_style) ? (l.getChildByName("role").getComponent(Sprite).spriteFrame = this.styleImgs[0], l.getChildByName("role").active = true) : 2 == Number(t.bowling_style) && (l.getChildByName("role").getComponent(Sprite).spriteFrame = this.styleImgs[1], l.getChildByName("role").active = true);
            let e = l.getChildByName("pname").getComponent(UITransform).width;
            0 == a ? l.getChildByName("role").setPosition(v3(-56.033 + e + 25, -49.191)) : l.getChildByName("role").setPosition(v3(56.033 - e - 25, -49.191));
        }
    }
    onPlayerInfoClick(e, t) {
        if (SoundManager.shared().playFx("click"), sys.now() - this._lastClick < 500) {
            return;
        }
        if (this._lastClick = sys.now(), 3 == this._match_state) {
            return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("yes11.live_tip"), 2);
        }
        if (4 == this._match_state) {
            return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("yes11.cancel_tip"), 2);
        }
        let s = ToolUtils.parseJson(t), a = { source: this._source, match_id: this._match_id, team_id: this._team_id, player_id: s.player_id, lastNode: this.node, join_team: s.join_team, playerInfo: t, select_status: 0, call: e => {
                this.onPlayerOperateClick(null, e);
            }, fromType: 1 };
        -1 != this._selectPlayerIds.indexOf(s.player_id) && (a.select_status = 1);
        SportCricket_Manager.shared().requestYes11_PlayerInfo(a, true);
    }
    updateGold(e) {
        let t = this.goldNode.getChildByName("coin");
        null != e && t && (t.getComponent(Label).string = ToolUtils.parse_double(e));
    }
    onPlayerOperateClick(e, t) {
        if (SoundManager.shared().playFx("click"), this._lastClick = sys.now(), 3 == this._match_state) {
            return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("yes11.live_tip"), 2);
        }
        if (4 == this._match_state) {
            return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("yes11.cancel_tip"), 2);
        }
        let s = ToolUtils.parseJson(t), a = s.player_id, i = this._selectPlayerIds.indexOf(a);
        if (-1 != i) {
            this._selectPlayerIds.splice(i, 1);
            this._selectPlayerNum -= 1;
            s.team_id == this._player_source.teama.tid ? this._teamAPlayerNum -= 1 : this._teamBPlayerNum -= 1;
            this._creditsLeft += s.credits;
            this.updateTargetPlayerViewStatus(0, a);
            this.updateOperatePlayerNum(0, s);
            this.updatePlayerViewMask();
        }
        else {
            if (11 == this._selectPlayerNum) {
                return;
            }
            if (10 == this._teamAPlayerNum && s.team_id == this._player_source.teama.tid) {
                return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("yes11.cteam_limit"), 3, 0, ToolUtils.getIsNormalDirection());
            }
            if (10 == this._teamBPlayerNum && s.team_id == this._player_source.teamb.tid) {
                return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("yes11.cteam_limit"), 3, 0, ToolUtils.getIsNormalDirection());
            }
            let e = this.playerViewMap.get(a);
            if (sys.isObjectValid(e) && e.getChildByName("mask").active) {
                return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("yes11.ctip1"), 3, 0, ToolUtils.getIsNormalDirection());
            }
            if (this._creditsLeft - s.credits < 0) {
                return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("yes11.credit_tip"), 3, 0, ToolUtils.getIsNormalDirection());
            }
            this._selectPlayerIds.push(a);
            this._selectPlayerNum += 1;
            s.team_id == this._player_source.teama.tid ? this._teamAPlayerNum += 1 : this._teamBPlayerNum += 1;
            this._creditsLeft -= s.credits;
            this.updateTargetPlayerViewStatus(1, a);
            this.updateOperatePlayerNum(1, s);
            let t = 11 - this._selectPlayerNum, i = 0;
            0 == this._wkSelectNum && (i += 1);
            0 == this._batSelectNum && (i += 1);
            0 == this._arSelectNum && (i += 1);
            0 == this._bowlSelectNum && (i += 1);
            t <= i && (0 != this._wkSelectNum && this.updatePlayerViewMask(1, "WK"), 0 != this._batSelectNum && this.updatePlayerViewMask(1, "BAT"), 0 != this._arSelectNum && this.updatePlayerViewMask(1, "AR"), 0 != this._bowlSelectNum && this.updatePlayerViewMask(1, "BOWL"));
            10 == this._teamAPlayerNum && 0 == this._teamBPlayerNum ? this.updatePlayerViewMask(1, "--", 1) : 10 == this._teamBPlayerNum && 0 == this._teamAPlayerNum && this.updatePlayerViewMask(1, "--", 0);
        }
        this.updateNextButtonStatus();
        sys.isObjectValid(this._call) && this._call(s);
    }
    updateNextButtonStatus() {
        11 == this._selectPlayerNum ? (this.nextNode.getComponent(Sprite).spriteFrame = this.btnBgImgs[0], this.nextNode.getComponent(Button).interactable = true) : (this.nextNode.getComponent(Sprite).spriteFrame = this.btnBgImgs[1], this.nextNode.getComponent(Button).interactable = true);
    }
    dealPreviewLogic() {
        let e = [], t = [], s = [], a = [];
        for (let i = 0; i < this._selectPlayerIds.length; i++) {
            this._allPlayerMsg.has(this._selectPlayerIds[i]) && ("WK" == this._allPlayerMsg.get(this._selectPlayerIds[i]).role ? e.push(this._allPlayerMsg.get(this._selectPlayerIds[i])) : "BAT" == this._allPlayerMsg.get(this._selectPlayerIds[i]).role ? t.push(this._allPlayerMsg.get(this._selectPlayerIds[i])) : "AR" == this._allPlayerMsg.get(this._selectPlayerIds[i]).role ? s.push(this._allPlayerMsg.get(this._selectPlayerIds[i])) : "BOWL" == this._allPlayerMsg.get(this._selectPlayerIds[i]).role && a.push(this._allPlayerMsg.get(this._selectPlayerIds[i])));
        }
        let i = { wk_Players: e, bat_Players: t, ar_Players: s, bowl_Players: a, backkup_Players: this._backupPlayers, teama: this._player_source.teama, teamb: this._player_source.teamb, teamAPnum: this._teamAPlayerNum, teamBPnum: this._teamBPlayerNum, credits: this._player_source.credits, left_credits: this._creditsLeft, lastNode: this.node, lineup: this._lineup };
        Utils.shared().showSportCricket_teamPreview(i);
    }
    dealShowCaptainSelectView() {
        let e = [], t = [], s = [], a = [], i = [];
        for (let l = 0; l < this._selectPlayerIds.length; l++) {
            this._allPlayerMsg.has(this._selectPlayerIds[l]) && (e.push(this._allPlayerMsg.get(this._selectPlayerIds[l])), "WK" == this._allPlayerMsg.get(this._selectPlayerIds[l]).role ? t.push(this._allPlayerMsg.get(this._selectPlayerIds[l])) : "BAT" == this._allPlayerMsg.get(this._selectPlayerIds[l]).role ? s.push(this._allPlayerMsg.get(this._selectPlayerIds[l])) : "AR" == this._allPlayerMsg.get(this._selectPlayerIds[l]).role ? a.push(this._allPlayerMsg.get(this._selectPlayerIds[l])) : "BOWL" == this._allPlayerMsg.get(this._selectPlayerIds[l]).role && i.push(this._allPlayerMsg.get(this._selectPlayerIds[l])));
        }
        let l = { source: this._source, player_source: this._player_source, selectPlayers: e, match_id: this._match_id, fromType: this._fromType, contest_id: this._contest_id, team_id: this._team_id, lineup: this._lineup, is_chip: this._is_chip, previewInfo: { wk_Players: t, bat_Players: s, ar_Players: a, bowl_Players: i, teama: this._player_source.teama, teamb: this._player_source.teamb, teamAPnum: this._teamAPlayerNum, teamBPnum: this._teamBPlayerNum, backkup_Players: this._backupPlayers, credits: this._player_source.credits, left_credits: this._creditsLeft, lineup: this._lineup }, lastNode: this.node };
        Utils.shared().showSportCricket_selectCaptain(l);
    }
    updateOperatePlayerNum(e, t) {
        0 == e ? "WK" == t.role ? this._wkSelectNum -= 1 : "BAT" == t.role ? this._batSelectNum -= 1 : "AR" == t.role ? this._arSelectNum -= 1 : "BOWL" == t.role && (this._bowlSelectNum -= 1) : "WK" == t.role ? this._wkSelectNum += 1 : "BAT" == t.role ? this._batSelectNum += 1 : "AR" == t.role ? this._arSelectNum += 1 : "BOWL" == t.role && (this._bowlSelectNum += 1);
        this.updateSelectPlayerNum();
        this.updateTeamASelectPlayerNum();
        this.updateTeamBSelectPlayerNum();
        this.updateLeftCredits();
        this.updateProgress();
    }
    updatePlayerViewMask(e, t, s) {
        for (let a = 0; a < this._allPlayerView.length; a++) {
            let i = this._allPlayerView[a];
            if (ToolUtils.isObjValid(i)) {
                let a = ToolUtils.parseJson(i.getChildByName("op_btn").getComponent(Button).clickEvents[0].customEventData), l = a.player_id;
                -1 == this._selectPlayerIds.indexOf(l) && (sys.isObjectValid(e) && 1 == e ? sys.isObjectValid(t) && "WK" == t && "WK" == a.role ? (i.getChildByName("mask").active = true, i.getChildByName("op_btn").getComponent(Button).interactable = true) : sys.isObjectValid(s) && (1 == s ? a.team_id == this._player_source.teama.tid && (i.getChildByName("mask").active = true, i.getChildByName("op_btn").getComponent(Button).interactable = true) : a.team_id == this._player_source.teamb.tid && (i.getChildByName("mask").active = true, i.getChildByName("op_btn").getComponent(Button).interactable = true)) : "WK" == a.role && (8 == this._wkSelectNum ? (i.getChildByName("mask").active = true, i.getChildByName("op_btn").getComponent(Button).interactable = true) : (i.getChildByName("mask").active = false, i.getChildByName("op_btn").getComponent(Button).interactable = true)), sys.isObjectValid(e) && 1 == e ? sys.isObjectValid(t) && "BAT" == t && "BAT" == a.role ? (i.getChildByName("mask").active = true, i.getChildByName("op_btn").getComponent(Button).interactable = true) : sys.isObjectValid(s) && (1 == s ? a.team_id == this._player_source.teama.tid && (i.getChildByName("mask").active = true, i.getChildByName("op_btn").getComponent(Button).interactable = true) : a.team_id == this._player_source.teamb.tid && (i.getChildByName("mask").active = true, i.getChildByName("op_btn").getComponent(Button).interactable = true)) : "BAT" == a.role && (8 == this._batSelectNum ? (i.getChildByName("mask").active = true, i.getChildByName("op_btn").getComponent(Button).interactable = true) : (i.getChildByName("mask").active = false, i.getChildByName("op_btn").getComponent(Button).interactable = true)), sys.isObjectValid(e) && 1 == e ? sys.isObjectValid(t) && "AR" == t && "AR" == a.role ? (i.getChildByName("mask").active = true, i.getChildByName("op_btn").getComponent(Button).interactable = true) : sys.isObjectValid(s) && (1 == s ? a.team_id == this._player_source.teama.tid && (i.getChildByName("mask").active = true, i.getChildByName("op_btn").getComponent(Button).interactable = true) : a.team_id == this._player_source.teamb.tid && (i.getChildByName("mask").active = true, i.getChildByName("op_btn").getComponent(Button).interactable = true)) : "AR" == a.role && (8 == this._arSelectNum ? (i.getChildByName("mask").active = true, i.getChildByName("op_btn").getComponent(Button).interactable = true) : (i.getChildByName("mask").active = false, i.getChildByName("op_btn").getComponent(Button).interactable = true)), sys.isObjectValid(e) && 1 == e ? sys.isObjectValid(t) && "BOWL" == t && "BOWL" == a.role ? (i.getChildByName("mask").active = true, i.getChildByName("op_btn").getComponent(Button).interactable = true) : sys.isObjectValid(s) && (1 == s ? a.team_id == this._player_source.teama.tid && (i.getChildByName("mask").active = true, i.getChildByName("op_btn").getComponent(Button).interactable = true) : a.team_id == this._player_source.teamb.tid && (i.getChildByName("mask").active = true, i.getChildByName("op_btn").getComponent(Button).interactable = true)) : "BOWL" == a.role && (8 == this._bowlSelectNum ? (i.getChildByName("mask").active = true, i.getChildByName("op_btn").getComponent(Button).interactable = true) : (i.getChildByName("mask").active = false, i.getChildByName("op_btn").getComponent(Button).interactable = true)));
            }
        }
    }
    updateTargetPlayerViewStatus(e, t) {
        if (this.playerViewMap.has(t)) {
            let s = this.playerViewMap.get(t);
            ToolUtils.isObjValid(s) && (0 == e ? (s.getChildByName("bg").getComponent(Sprite).color = color(255, 255, 255), s.getChildByName("op_btn").getChildByName("ico").getComponent(Sprite).spriteFrame = this.operateImgs[0]) : (s.getChildByName("bg").getComponent(Sprite).color = color(255, 247, 224), s.getChildByName("op_btn").getChildByName("ico").getComponent(Sprite).spriteFrame = this.operateImgs[1]));
        }
    }
    onCloseButtonClick(e, t) {
        if (SoundManager.shared().playFx("click"), "back_btn" == t) {
            if (this._closed) {
                return;
            }
            this.onBackView();
        }
    }
    initView() {
        if (this.fitScreen(), sys.isObjectValid(this._source)) {
            this.rootNode.getChildByName("top_node").getChildByName("title").getComponent(Label).string = this._source.teama.short_name + " vs " + this._source.teamb.short_name;
            let e = this.rootNode.getChildByName("details").getChildByName("lefttime");
            e.getComponent(Label).string = Utils.shared().parseCountDown(this._source.time_left);
            sys.isObjectValid(this._source.status) && (this._match_state = this._source.status);
            0 == this._source.time_left && 1 == this._source.status ? (e.getComponent(Label).string = this._source.start_day, sys.isObjectValid(this._source.is_current_day) && 1 == Number(this._source.is_current_day) && (this._source.status = 3, e.getComponent(Label).string = "Live")) : 1 == this._source.status ? TweenTool.myschedule(e, 1, (() => {
                ToolUtils.isObjValid(this.node) && (this._source.time_left > 0 ? e.getComponent(Label).string = Utils.shared().parseCountDown(this._source.time_left) : (this._source.status = 3, e.getComponent(Label).string = "Live", TweenTool.stopNodeAction(e)));
            })) : 3 == this._source.status ? (TweenTool.stopNodeAction(e), e.getComponent(Label).string = "Live") : 4 == this._source.status && (TweenTool.stopNodeAction(e), e.getComponent(Label).string = "Cancel");
            PushCenter.shared().addListener(PushEvent.UpdateYes11CurMatchLeftTime, (t => {
                try {
                    ToolUtils.isObjValid(this.node) && t.match_id == this._match_id && (this._source.time_left = t.time_left, this._source.is_current_day = t.is_current_day, this._match_state = t.status, 3 == t.status ? (TweenTool.stopNodeAction(e), e.getComponent(Label).string = "Live") : 4 == t.status && (TweenTool.stopNodeAction(e), e.getComponent(Label).string = "Cancel"));
                }
                catch (e) {
                    TLog.printError(this.TAG, PushEvent.UpdateYes11CurMatchLeftTime, e);
                }
            }), this);
            this.updateContestDetails();
        }
    }
    onButtonClick(e, t) {
        if (SoundManager.shared().playFx("click"), !(sys.now() - this._lastClick < 500)) {
            if (this._lastClick = sys.now(), 3 != this._match_state) {
                if (4 != this._match_state) {
                    if ("next" == t) {
                        11 == this._selectPlayerNum ? this.dealShowCaptainSelectView() : Utils.shared().showToast(i18nMgr.shared().getValueByKey("yes11.ctip"), 3, 0, ToolUtils.getIsNormalDirection());
                    }
                    else if ("preview" == t) {
                        this.dealPreviewLogic();
                    }
                    else if ("stat" == t) {
                        let e = { match_id: this._match_id, fromType: 1, source: this._source, lastNode: this.node };
                        SportCricket_Manager.shared().requestYes11_statTeamInfo(e, true);
                    }
                    else if ("add_chip" == t) {
                        Utils.shared().showStoreView(null, null);
                        User.shared().updatePayScene(PhpReportDefined.pay_scene.hall_cricket);
                    }
                    else if ("pts_tab" == t) {
                        if (0 == this._curTabIndex) {
                            return;
                        }
                        this._curTabIndex = 0;
                        this.updateTabView();
                        this.updateContestDetails();
                        this.updateTabContent();
                    }
                    else if ("sel_tab" == t) {
                        if (1 == this._curTabIndex) {
                            return;
                        }
                        this._curTabIndex = 1;
                        this.updateTabView();
                        this.updateContestDetails();
                        this.updateTabContent();
                    }
                }
                else {
                    Utils.shared().showToast(i18nMgr.shared().getValueByKey("yes11.cancel_tip"), 2);
                }
            }
            else {
                Utils.shared().showToast(i18nMgr.shared().getValueByKey("yes11.live_tip"), 2);
            }
        }
    }
    updateTabContent() {
        this.reSortPlayerInfo();
    }
    onBackView(e = true) {
        e && (Utils.shared().hideLoading(), this.bShowPushAnim ? (this._closed = true, ToolUtils.isObjValid(this._lastNode) && (this._lastNode.active = true), ToolUtils.showPushAnim(this.node, 1, (() => {
            ToolUtils.isObjValid(this.node) && this.node.destroy();
        }))) : (ToolUtils.isObjValid(this._lastNode) && (this._lastNode.active = true), ToolUtils.isObjValid(this.node) && this.node.destroy()));
    }
    fitScreen() {
    }
}
