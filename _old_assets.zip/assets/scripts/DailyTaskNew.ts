// @ts-nocheck
// Recovered from index.js:97
import { _decorator, Button, color, game, instantiate, Label, Node, RichText, ScrollView, size, sp, Sprite, SpriteFrame, sys, UITransform, v3, Vec3, view, Widget } from "cc";
import BaseLayer from "./BaseLayer";
import { TransferPlatform } from "./TransferPlatform";
import User from "./User";
import SoundManager from "./SoundManager";
import PushCenter from "./PushCenter";
import PushEvent from "./PushEvent";
import HttpManager from "./HttpManager";
import Utils from "./Utils";
import { TLog } from "./TLog";
import i18nMgr from "./i18nMgr";
import TweenTool from "./TweenTool";
import { HttpRequest } from "./HttpRequestName";
import { ScrollviewUtils } from "./ScrollviewUtils";
import BundleNameDefined from "./BundleNameDefined";
import GameConfig from "./GameConfig";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("DailyTaskNew")
export class DailyTaskNew extends BaseLayer {
    @property(Node)
    public rootnode: Node = null;
    @property(Node)
    public titleAnim: Node = null;
    @property(Node)
    public labels: Node = null;
    @property(Node)
    public sprites: Node = null;
    @property(Node)
    public lightImg: Node = null;
    @property(Node)
    public Moban: Node = null;
    @property(ScrollView)
    public scollview: ScrollView = null;
    @property(Node)
    public nodata: Node = null;
    @property(Label)
    public leftTimeLabel: Label = null;
    @property(Label)
    public myActive: Label = null;
    @property(Label)
    public oneSpinNum: Label = null;
    @property(Label)
    public tenSpinNum: Label = null;
    @property(Node)
    public winAnim: Node = null;
    @property(Node)
    public ruleNode: Node = null;
    @property(Label)
    public ruleLabel: Label = null;
    @property([Node])
    public gift_node: Node[] = [];
    @property([Label])
    public num_node: Label[] = [];
    @property([Node])
    public mask_node: Node[] = [];
    @property(Button)
    public all_btn: Button = null;
    @property(Button)
    public spin_one_btn: Button = null;
    @property(Button)
    public spin_ten_btn: Button = null;
    @property([SpriteFrame])
    public award_Sprite: SpriteFrame[] = [];
    @property([SpriteFrame])
    public light_Sprite: SpriteFrame[] = [];
    @property([SpriteFrame])
    public spin_btn_Sprite: SpriteFrame[] = [];
    @property([SpriteFrame])
    public button_Sprite: SpriteFrame[] = [];
    @property([SpriteFrame])
    public reward_Sprite: SpriteFrame[] = [];
    public _scrollUtil: any = null;
    public Data: any[] = [];
    public _itemArr: any[] = [];
    public isallbtn: boolean = false;
    public isbtn: boolean = false;
    public isNext: boolean = false;
    public isBackKey: boolean = true;
    public bardenominator: any[] = [0.046, 0.135, 0.32, 0.5, 0.687, 0.867];
    public _initDelay: number = 0;
    public _bStartCountDown: boolean = false;
    public _nCountcd: any = -1;
    public _bGameRun: boolean = false;
    public _nBtnOneClieckTime: number = 0;
    public _nBtnTenClieckTime: number = 0;
    public _normalIdx: number = 0;
    public _bNormalRun: boolean = false;
    public _normalCd: number = 0;
    public _normalShowArr: any[] = [[0, 3, 6, 9], [1, 4, 7, 10], [2, 5, 8, 11]];
    public _callback: any = null;
    initParaData(t, e) {
        this.isNext = t;
        this._callback = e;
    }
    onLoad() {
        this.fitScreen();
        TransferPlatform.shared().setHighFrameRate();
        this.Moban.active = false;
        this._scrollUtil = this.node.addComponent(ScrollviewUtils);
        this._scrollUtil.initScrollviewUtils(this.scollview);
        this._initDelay = 0;
        this.dealMultipleLanguages();
    }
    dealMultipleLanguages() {
        2 != i18nMgr.shared().language && 3 != i18nMgr.shared().language || (this.labels.getChildByName("tips2").getComponent(Label).fontSize = 22, this.labels.getChildByName("tips1").getComponent(Label).fontSize = 24, this.labels.getChildByName("time_layout").getChildByName("leftTime").setPosition(v3(52.255, 560.782)), this.labels.getChildByName("time_layout").getChildByName("num").setPosition(v3(54.955, 560.782)));
    }
    onDestroy() {
        super.onDestroy();
        TransferPlatform.shared().setNormalFrameRate();
        PushCenter.shared().pushEvent(PushEvent.HallGet);
        PushCenter.shared().removeListenersByTag(this);
        ToolUtils.isObjValid(this.node) && this.isBackKey && this.isNext && PushCenter.shared().pushEvent(PushEvent.Update_NextPopActivity);
    }
    start() {
        super.start();
        PushCenter.shared().addListener(PushEvent.UpdateNewDailyTask, (t => {
            sys.isObjectValid(this.node) && this.onUpdateTaskLottery();
        }), this);
        PushCenter.shared().addListener(PushEvent.DeleteDailyTask, (() => {
            ToolUtils.isObjValid(this.node) && (this.isBackKey = false, this.onBackView());
        }), this);
        this._initDelay += 0.05;
        TweenTool.delayAct(this.node, (() => {
            TweenTool.commonSchedule(this.node, 1, this.scheduleCallBack.bind(this));
            null !== User.shared().newDailydata && this.onUpdateTaskLottery();
            User.shared().requestNewDailyTaskData(true);
        }), this._initDelay, true);
        this._initDelay += 0.05;
        TweenTool.delayAct(this.node, (() => {
            this.titleAnim && (this.titleAnim.getComponent(sp.Skeleton).clearTracks(), this.titleAnim.getComponent(sp.Skeleton).setToSetupPose(), 0 == i18nMgr.shared().language ? this.titleAnim.getComponent(sp.Skeleton).setSkin("English") : 1 == i18nMgr.shared().language ? this.titleAnim.getComponent(sp.Skeleton).setSkin("Hindi") : 2 == i18nMgr.shared().language ? this.titleAnim.getComponent(sp.Skeleton).setSkin("Tamil") : 3 == i18nMgr.shared().language && this.titleAnim.getComponent(sp.Skeleton).setSkin("Urdu"), this.titleAnim.getComponent(sp.Skeleton).setAnimation(0, "rcyj_ct", true));
        }), this._initDelay, true);
        this._initDelay += 0.05;
        TweenTool.delayAct(this.node, (() => {
            this.showNomalRun();
        }), this._initDelay, true);
        null != User.shared().newDailyListData ? (this._initDelay += 0.05, TweenTool.delayAct(this.node, (() => {
            this.initTaskList(User.shared().newDailyListData);
        }), this._initDelay, true), TweenTool.delayAct(this.node, (() => {
            this.requestList();
        }), this._initDelay + 0.05, true)) : this.requestList(true);
        this._initDelay += 0.05;
        TweenTool.delayAct(this.node, (() => {
            SoundManager.shared().preLoadBundleSounds(BundleNameDefined.bundle_sound, "dailyTask");
        }), this._initDelay, true);
        this._initDelay += 0.05;
        TweenTool.delayAct(this.node, (() => {
            this.requestHelpRules();
        }), this._initDelay, true);
    }
    scheduleCallBack() {
        if (this._bNormalRun && (this._normalCd += 1, this._normalCd % 1 == 0 && (this._normalCd = 0, this._normalIdx += 1, this._normalIdx %= 3, this.showMaskLight(this._normalShowArr[this._normalIdx]))), this._bStartCountDown) {
            if (this._nCountcd -= 1, User.shared().newDailydata.leftTime = this._nCountcd, this._nCountcd < 0) {
                return User.shared().newDailydata.leftTime = -1, User.shared().getHallInfo(), void this.onBackView();
            }
            this.leftTimeLabel.string = Utils.shared().parseCountDown(this._nCountcd);
        }
        this.updateTaskLeftTime();
    }
    updateTaskLeftTime() {
        try {
            if (Array.isArray(this.Data) && this.Data.length > 0) {
                for (let t = 0, e = this.Data.length; t < e; t++) {
                    if (this.Data[t].leftTime > 0 && (this.Data[t].leftTime -= 1, this.initCurMobanCallBack(this._itemArr[t], this.Data[t], t), 0 == this.Data[t].leftTime)) {
                        return this.Data = [], void this.requestList();
                    }
                }
            }
        }
        catch (t) {
            TLog.printError("updateTaskLeftTime err:", t);
        }
    }
    showNomalRun() {
        this._normalIdx = 0;
        this.showMaskLight(this._normalShowArr[this._normalIdx]);
        this._bNormalRun = true;
        this._normalCd = 0;
        this._bGameRun = false;
    }
    showMaskLight(t) {
        if (t && t.length > 0) {
            for (let e = 0; e < 12; e++) {
                t[0] == e || t[1] == e || t[2] == e || t[3] == e ? this.mask_node[e].active = false : this.mask_node[e].active = true;
            }
        }
    }
    runGiftRun(t, e) {
        TweenTool.stopNodeAction(this.lightImg);
        let i = TweenTool.delayAct(this.lightImg, (() => {
            this.lightImg.getComponent(Sprite).spriteFrame = this.light_Sprite[0];
        }), 0.5), a = TweenTool.delayAct(this.lightImg, (() => {
            this.lightImg.getComponent(Sprite).spriteFrame = this.light_Sprite[1];
        }), 0.5), s = TweenTool.sequence(this.lightImg, false, null, i, a);
        s.repeatForever();
        s.start();
        this._bNormalRun = false;
        this._normalCd = -1;
        for (let t = 0; t < 12; t++) {
            this.mask_node[t].active = 0 !== t;
        }
        let n = [0, 1, 2, 3, 4, 5], l = [0.2, 0.22, 0.16, 0.11, 0.08, 0.06, 0.05];
        for (let t = 6; t < 12; t++) {
            n.push(t);
            l.push(0.05);
        }
        for (let t = 0; t < 4; t++) {
            n.push(t);
            l.push(0.035);
        }
        for (let t = 4; t < 8; t++) {
            n.push(t);
            l.push(0.02);
        }
        for (let t = 8; t < 12; t++) {
            n.push(t);
            l.push(0.035);
        }
        for (let t = 0; t < 5; t++) {
            n.push(t);
            l.push(0.05);
        }
        let r = [5, 6, 7, 8, 9, 10, 11, 0], o = [0.06, 0.09, 0.12, 0.15, 0.19, 0.24, 0.3, 0.38];
        for (let e = 1; e < t; e++) {
            r.push(e);
            o.splice(0, 0, 0.05);
        }
        for (let t = 0, e = r.length; t < e; t++) {
            n.push(r[t]);
            l.push(o[t]);
        }
        let h = 0;
        for (let t = 0, i = n.length; t < i; t++) {
            h += l[t];
            TweenTool.delayAct(this.node, (() => {
                let i;
                SoundManager.shared().playFx("slots_run");
                t > 0 && (i = n[t - 1], this.mask_node[i].active = true);
                i = n[t];
                this.mask_node[i].active = false;
                t == n.length - 1 && (TweenTool.stopNodeAction(this.lightImg), this.lightImg.getComponent(Sprite).spriteFrame = this.light_Sprite[2], TweenTool.delayAct(this.node, (() => {
                    e && e();
                }), 0.2, true));
            }), h, true);
        }
    }
    showTenLotteryRun(t, e, i) {
        let a = Number(e[t]) - 1;
        if (SoundManager.shared().playFx("slots_winning"), t == e.length - 1) {
            return this.mask_node[a].active = false, void (i && i());
        }
        this.mask_node[a].active = false;
        let s = instantiate(this.winAnim);
        this.winAnim.parent.addChild(s);
        s && (s.setPosition(this.mask_node[a].position), s.active = true, s.getComponent(sp.Skeleton).clearTracks(), s.getComponent(sp.Skeleton).setToSetupPose(), s.getComponent(sp.Skeleton).setAnimation(0, "rcrw_zj", false), TweenTool.delayAct(this.node, (() => {
            s.destroy();
        }), 0.9, true));
        TweenTool.delayAct(this.node, (() => {
            this.showTenLotteryRun(t + 1, e, i);
        }), 0.3, true);
    }
    onUpdateTaskLottery() {
        if (sys.isObjectValid(User.shared().newDailydata.myActive) && (this.myActive.string = "" + User.shared().newDailydata.myActive), sys.isObjectValid(User.shared().newDailydata.spin1) && (this.oneSpinNum.string = "" + User.shared().newDailydata.spin1), sys.isObjectValid(User.shared().newDailydata.spin10) && (this.tenSpinNum.string = "" + User.shared().newDailydata.spin10), sys.isObjectValid(User.shared().newDailydata.reward)) {
            let t, e;
            for (let i = 0; i < 12; i++) {
                User.shared().newDailydata.reward[i] && (t = User.shared().newDailydata.reward[i].type, sys.isObjectValid(t) && this.award_Sprite[t] && (this.gift_node[i].getComponent(Sprite).spriteFrame = this.award_Sprite[t]), e = User.shared().newDailydata.reward[i].amt, sys.isObjectValid(e) && (this.num_node[i].string = "" + e));
            }
        }
        this.startLeftTimeCountDown(User.shared().newDailydata.leftTime);
        this.updateSpinBtnStatus();
    }
    startLeftTimeCountDown(t) {
        if (Number.isNaN(t) || t <= 0) {
            return User.shared().getHallInfo(), void (this.leftTimeLabel.string = "");
        }
        this._bStartCountDown = true;
        this._nCountcd = t;
        this.leftTimeLabel.string = Utils.shared().parseCountDown(this._nCountcd);
    }
    updateSpinBtnStatus() {
        Number(User.shared().newDailydata.myActive) >= Number(User.shared().newDailydata.spin10) ? (this.spin_one_btn.getComponent(Sprite).spriteFrame = this.spin_btn_Sprite[1], this.spin_ten_btn.getComponent(Sprite).spriteFrame = this.spin_btn_Sprite[1]) : Number(User.shared().newDailydata.myActive) >= Number(User.shared().newDailydata.spin1) ? (this.spin_one_btn.getComponent(Sprite).spriteFrame = this.spin_btn_Sprite[1], this.spin_ten_btn.getComponent(Sprite).spriteFrame = this.spin_btn_Sprite[0]) : (this.spin_one_btn.getComponent(Sprite).spriteFrame = this.spin_btn_Sprite[0], this.spin_ten_btn.getComponent(Sprite).spriteFrame = this.spin_btn_Sprite[0]);
    }
    onSpinResult(t) {
        if (this._bGameRun = true, User.shared().newDailydata.myActive = Number(t.myActive), this.updateSpinBtnStatus(), this.myActive.string = "" + t.myActive, Array.isArray(t.id)) {
            let e = Number(t.id[0]);
            this.runGiftRun(e, (() => {
                this.showTenLotteryRun(0, t.id, (() => {
                    e = Number(t.id[t.id.length - 1]);
                    this.showLotteryReward(e, t);
                }));
            }));
        }
    }
    showLotteryReward(t, e) {
        let i = instantiate(this.winAnim);
        this.winAnim.parent.addChild(i);
        i ? (i.setPosition(this.mask_node[t - 1].position), i.active = true, i.getComponent(sp.Skeleton).clearTracks(), i.getComponent(sp.Skeleton).setToSetupPose(), i.getComponent(sp.Skeleton).setAnimation(0, "rcrw_zj", false), TweenTool.delayAct(this.node, (() => {
            this.Poprewards(e.reward);
            TweenTool.delayAct(this.node, (() => {
                this.showNomalRun();
            }), 0.2, true);
            i.destroy();
        }), 0.9, true)) : (this.Poprewards(e.reward), TweenTool.delayAct(this.node, (() => {
            this.showNomalRun();
        }), 0.2, true));
    }
    requestList(t = false) {
        t && Utils.shared().showLoading(10, true, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
        }));
        HttpManager.shared().doGetNewDailyTaskList(this.listengetlistCallback.bind(this));
    }
    listengetlistCallback(t, e, i) {
        if (Utils.shared().hideLoading(), ToolUtils.isObjValid(this.node)) {
            try {
                if (200 != i) {
                    alert("The login timed out, please try again");
                    this.checkShowNodata();
                }
                else {
                    let t = ToolUtils.parseJson(e);
                    0 == t.ret ? (User.shared().newDailyListData = t.data, this.initTaskList(User.shared().newDailyListData)) : Utils.shared().showToast(ToolUtils.isSafeString(t.desc), 3);
                }
            }
            catch (t) {
                this.checkShowNodata();
            }
        }
    }
    requestHelpRules(t = false) {
        t && Utils.shared().showLoading(10, true, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
        }));
        HttpManager.shared().doGetCommonRequest(null, "Act_63.tip", ((e, i, a) => {
            if (sys.isObjectValid(this.node)) {
                t && Utils.shared().hideLoading();
                try {
                    if (200 != a) {
                        alert("The login timed out, please try again");
                    }
                    else {
                        let e = ToolUtils.parseJson(i);
                        0 == e.ret && (User.shared().newDailyRules = e.data.tip, t && this.showRuleDlg());
                    }
                }
                catch (t) {
                }
            }
        }));
    }
    checkShowNodata() {
        let t = false;
        null !== User.shared().newDailyListData && Array.isArray(User.shared().newDailyListData) && User.shared().newDailyListData.length > 0 && (t = true);
        t || (this.Data = []);
        this.checkListInfo(t);
    }
    initTaskList(t) {
        null != t ? (this.Data = t.list, 1 == t.is_reward ? (this.all_btn.node.active = true, i18nMgr.shared().changeLabelLanguage(this.all_btn.node.getChildByName("wz").getComponent(Label), "daily_tasks.collect", true), this.fitTaskNode(1)) : 2 == t.is_reward ? (this.all_btn.node.active = true, i18nMgr.shared().changeLabelLanguage(this.all_btn.node.getChildByName("wz").getComponent(Label), "daily_tasks.all_txt", true), this.fitTaskNode(1)) : (this.all_btn.node.active = false, this.fitTaskNode(0)), Array.isArray(this.Data) && this.Data.length > 0 ? this.checkListInfo(false) : this.checkListInfo(true), this.refreshList()) : this.checkListInfo(true);
    }
    checkListInfo(t) {
        this.nodata.active = t;
    }
    initCurMobanCallBack(t, e, i = 0) {
        t.active = true;
        let a = t.getChildByName("left_time"), s = a.getChildByName("layout").getChildByName("time_txt"), n = t.getChildByName("name"), o = t.getChildByName("Button"), h = o.getChildByName("btn_txt"), d = t.getChildByName("golds"), c = t.getChildByName("test"), p = t.getChildByName("desc"), _ = t.getChildByName("ticket_num"), f = null, w = "", C = e.reward, k = 0;
        if (C && C.length && (k = C.length), e.leftTime > 0) {
            a.active = true;
            let t = Utils.shared().parseCountDown(e.leftTime);
            s.getComponent(Label).string = t;
        }
        else {
            a.active = false;
        }
        f = "<color=#313131>" + e.name + "</color>";
        w = e.name;
        let D = "" + e.desc;
        sys.isObjectValid(e.progress) && ToolUtils.isSafeString(e.progress).length > 0 && (f += "<color=#539C49 > " + e.progress + " < /color>", w += " " + e.progress);
        n.getComponent(RichText).string = f;
        p.getComponent(Label).string = D;
        c.active = true;
        c.getComponent(Label).string = w;
        c.getComponent(Label).updateRenderData(true);
        0 == D.length ? d.setPosition(0, -20) : (d.setPosition(0, -30), c.getComponent(UITransform).height > 60 ? n.setPosition(-220, -28) : n.setPosition(-220, -38));
        c.active = false;
        1 == e.status ? (o.getComponent(Sprite).spriteFrame = this.button_Sprite[1], h.getComponent(Label).string = i18nMgr.shared().getValueByKey("daily_tasks.collect"), h.getComponent(Label).color = color(255, 255, 255), o.getComponent(Button).interactable = true) : 1 == e.end ? (o.getComponent(Sprite).spriteFrame = this.button_Sprite[2], h.getComponent(Label).string = i18nMgr.shared().getValueByKey("daily_tasks.end"), h.getComponent(Label).color = color(153, 153, 153), o.getComponent(Button).interactable = false) : 0 == e.valid ? (o.getComponent(Sprite).spriteFrame = this.button_Sprite[2], h.getComponent(Label).string = i18nMgr.shared().getValueByKey("daily_tasks.upcoming"), h.getComponent(Label).color = color(153, 153, 153), o.getComponent(Button).interactable = false) : 0 == e.status ? (o.getComponent(Sprite).spriteFrame = this.button_Sprite[0], h.getComponent(Label).string = i18nMgr.shared().getValueByKey("daily_tasks.continue"), h.getComponent(Label).color = color(255, 255, 255), o.getComponent(Button).interactable = true) : 2 == e.status && (o.getComponent(Sprite).spriteFrame = this.button_Sprite[2], h.getComponent(Label).string = i18nMgr.shared().getValueByKey("daily_tasks.collected"), h.getComponent(Label).color = color(153, 153, 153), o.getComponent(Button).interactable = false);
        o.getComponent(Button).clickEvents[0].customEventData = e;
        _.getComponent(Label).string = "";
        let T = 0;
        if (k > 0) {
            let t = 100;
            for (let e = 0; e < k; e++) {
                if (2 == C[e].type) {
                    _.getComponent(Label).string = "x" + ToolUtils.parse_double("" + C[e].amt, -1);
                }
                else if (T < 3) {
                    let i = d.children[T];
                    i.active = true;
                    i.getComponent(Sprite).spriteFrame = this.reward_Sprite[C[e].type];
                    i.getChildByName("num").getComponent(Label).string = "x" + ToolUtils.parse_double("" + C[e].amt, -1);
                    0 == e ? i.setPosition(e * t - 204, -84) : i.setPosition(d.children[e - 1].position.x + t, -84);
                    T++;
                }
            }
        }
        for (let t = T; t < 3; t++) {
            d.children[t].active = false;
        }
        TransferPlatform.shared().setNormalFrameRate();
    }
    scrollRefreshCallBack() {
    }
    refreshList() {
        if (this.Data && this.Data.length > 0) {
            if (this._itemArr.length > this.Data.length) {
                for (let t = this._itemArr.length - 1; t >= this.Data.length; t--) {
                    this.scollview.content.removeChild(this._itemArr[t]);
                    this._itemArr.splice(t, 1);
                }
            }
            let t = this.scollview.getComponent(UITransform).contentSize.height, e = this.Moban.getComponent(UITransform).contentSize.height, i = e * this.Data.length > t ? e * this.Data.length : t;
            if (this.scollview.content.getComponent(UITransform).height = i, this._itemArr.length > 0) {
                for (let t = 0, i = this.Data.length; t < i; t++) {
                    if (ToolUtils.isObjValid(this._itemArr[t])) {
                        this.initCurMobanCallBack(this._itemArr[t], this.Data[t], t);
                    }
                    else {
                        let i = instantiate(this.Moban);
                        i.setPosition(new Vec3(0, -e * t));
                        i.active = true;
                        this.initCurMobanCallBack(i, this.Data[t], t);
                        this._itemArr.push(i);
                        this.scollview.content.addChild(i);
                    }
                }
                this._scrollUtil.setScollDetails(e, t, this.Data, true);
            }
            else {
                this._itemArr = [];
                let i = 0;
                for (this.Data.length; i < this.Data.length; i++) {
                    let a = instantiate(this.Moban);
                    a.setPosition(new Vec3(0, -e * i));
                    a.active = e * i <= t;
                    this.initCurMobanCallBack(a, this.Data[i], i);
                    this._itemArr.push(a);
                    this.scollview.content.addChild(a);
                }
                this._scrollUtil.setScollDetails(e, t, this.Data, false);
            }
        }
        else {
            this.scollview.content.destroyAllChildren();
            this._itemArr = [];
        }
    }
    showRuleDlg() {
        this.ruleNode.active = true;
        this.startShowAnim(this.ruleNode.getChildByName("bg"), (() => {
            this.ruleLabel.string = User.shared().newDailyRules;
            i18nMgr.shared().changeLabelFont(this.ruleLabel);
        }));
    }
    onCloseClick(t, e) {
        SoundManager.shared().playFx("click");
        this.onBackView();
    }
    onBtnClick(t, e) {
        if (SoundManager.shared().playFx("click"), "help" == e) {
            "" != User.shared().newDailyRules ? this.showRuleDlg() : this.requestHelpRules(true);
        }
        else if ("helpClose" === e) {
            this.ruleNode.active = false;
        }
        else if ("spin" == e) {
            if (Number(User.shared().newDailydata.myActive) < Number(User.shared().newDailydata.spin1)) {
                return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("daily_tasks.limit_tickets"), 2);
            }
            if (!this._bGameRun) {
                let t = sys.now();
                t - this._nBtnOneClieckTime >= 2000 && (this._nBtnOneClieckTime = t, this.onStartSpinRequest(1));
            }
        }
        else if ("spin10" == e) {
            if (Number(User.shared().newDailydata.myActive) < Number(User.shared().newDailydata.spin10)) {
                return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("daily_tasks.limit_tickets"), 2);
            }
            if (!this._bGameRun) {
                let t = sys.now();
                t - this._nBtnTenClieckTime >= 2000 && (this._nBtnTenClieckTime = t, this.onStartSpinRequest(10));
            }
        }
    }
    onStartSpinRequest(t) {
        Utils.shared().showLoading(10, false, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3);
        }));
        HttpManager.shared().doGetCommonRequest({ spin: t }, HttpRequest.StartDailyTaskSpin, ((t, e, i) => {
            Utils.shared().hideLoading();
            try {
                if (200 != i) {
                    alert("The login timed out, please try again");
                }
                else {
                    let t = ToolUtils.parseJson(e);
                    0 == t.ret && sys.isObjectValid(this.node) && this.onSpinResult(t.data);
                }
            }
            catch (t) {
            }
        }));
    }
    btnCollectClick(t, e) {
        if (SoundManager.shared().playFx("click"), !this.isbtn) {
            if (this.isbtn = true, 0 == e.status) {
                if (Utils.shared().doJumpLogic(e.jump_info.type, e.jump_info.exe), 8 == e.jump_info.type) {
                    return;
                }
                ToolUtils.isObjValid(this.node) && (this.isBackKey = false, this.onBackView());
                this.isbtn = false;
            }
            else {
                1 == e.status && this.getOneTaskReward(e.task_id);
            }
        }
    }
    onAllBtnClick(t, e) {
        SoundManager.shared().playFx("click");
        this.isallbtn || (this.isallbtn = true, Utils.shared().showLoading(10, true, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
        })), HttpManager.shared().doGetNewDailyTaskReward(null, this.listTaskRewardCallback.bind(this)));
    }
    getOneTaskReward(t) {
        Utils.shared().showLoading(10, true, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
        }));
        HttpManager.shared().doGetNewDailyTaskReward(t, this.listTaskRewardCallback.bind(this));
    }
    listTaskRewardCallback(t, e, i) {
        Utils.shared().hideLoading();
        try {
            if (200 != i) {
                alert("The login timed out, please try again");
            }
            else {
                let t = ToolUtils.parseJson(e);
                0 == t.ret ? (sys.isObjectValid(t.data.money) && User.shared().updateMoney(t.data.money), sys.isObjectValid(t.data.bonus) && User.shared().updateBonus(t.data.bonus), sys.isObjectValid(t.data.myActive) && (User.shared().newDailydata.myActive = Number(t.data.myActive)), User.shared().newDailyListData = t.data.page, sys.isObjectValid(this.node) && (this.myActive.string = "" + t.data.myActive, this.updateSpinBtnStatus(), this.initTaskList(User.shared().newDailyListData), this.isbtn = false, this.isallbtn = false, t.data.reward && t.data.reward.length > 0 && TweenTool.delayAct(this.node, (() => {
                    this.Poprewards(t.data.reward);
                }), game.frameTime / 1000 * 2, true))) : ToolUtils.isSafeString(t.desc).length > 0 && Utils.shared().showToast(ToolUtils.isSafeString(t.desc), 3);
            }
        }
        catch (t) {
            TLog.printError("listenTaskRewardCallback:", t);
        }
    }
    Poprewards(t) {
        let e = t;
        e && e.length > 0 && User.shared().showChargeReward(e);
    }
    fitTaskNode(t) {
        let e = sys.getSafeAreaRect().y, i = view.getVisibleSize(), a = 1 == t ? 303 : 435, s = this.scollview.getComponent(UITransform).contentSize, n = i.height - (1280 - a) - e;
        sys.os === sys.OS.IOS && (n += 40);
        this.scollview.getComponent(UITransform).contentSize = size(s.width, n);
    }
    fitScreen() {
        let t = ToolUtils.adaptSafeArea(this.rootnode);
        this.setUiEdgeDistance(this.all_btn.node, 68 + t, 3, false);
        ToolUtils.showFullScreen(this.ruleNode.getChildByName("mask"));
        ToolUtils.isPadPlatform() && (this.rootnode.getChildByName("content").getChildByName("backBtn").getComponent(Widget).left = -(GameConfig.REAL_SCREEN_WIDTH - 720) / 2 - 10, this.rootnode.getChildByName("content").getChildByName("helpBtn").getComponent(Widget).right = -(GameConfig.REAL_SCREEN_WIDTH - 720) / 2 - 5);
    }
    onBackView() {
        ToolUtils.isObjValid(this.node) && (this._callback && this._callback(), this.node.destroy());
    }
}
