// @ts-nocheck
// Recovered from index.js:39
import { _decorator, Component, Button, EditBox, Label, Node, v3 } from "cc";
import Utils from "./Utils";
import TweenTool from "./TweenTool";
import SoundManager from "./SoundManager";
import HttpManager from "./HttpManager";
import User from "./User";
import PushCenter from "./PushCenter";
import { TransferPlatform } from "./TransferPlatform";
import PushEvent from "./PushEvent";
import i18nMgr from "./i18nMgr";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("BindMyReferCode")
export class BindMyReferCode extends Component {
    @property(EditBox)
    public exchange_edit: EditBox = null;
    @property(Button)
    public exchange_btn: Button = null;
    @property(Label)
    public amount: Label = null;
    @property(Node)
    public PLACEHOLDER_LABEL: Node = null;
    @property(Node)
    public TEXT_LABEL: Node = null;
    @property(Node)
    public tip: Node = null;
    public nums: number = 0;
    public hasClicked: boolean = false;
    start() {
        this.PLACEHOLDER_LABEL.setPosition(v3(-208, 34, 0));
        this.TEXT_LABEL.setPosition(v3(-208, 34, 0));
        this.amount.node.active = false;
        this.tip.active = false;
        ToolUtils.startShowAnim(this.node.getChildByName("bgView"));
    }
    onDestroy() {
        PushCenter.shared().removeListenersByTag(this);
        this.unscheduleAllCallbacks();
    }
    onButtonClick(e, t) {
        if (SoundManager.shared().playFx("click"), "close" == t) {
            ToolUtils.isObjValid(this.node) && this.node.destroy();
        }
        else if ("exchange" == t) {
            let e = this.exchange_edit.string;
            if (0 == e.length || e.length < 7 && e.length > 8 || !Number(e)) {
                return this.amount.node.active = true, i18nMgr.shared().changeLabelLanguage(this.amount, "bind_mobile.invalid_verification"), void (this.tip.active = true);
            }
            this.exchange_btn.interactable = false;
            TweenTool.delayAct(this.exchange_btn, (() => {
                this.exchange_btn.interactable = true;
            }), 0.5, true);
            HttpManager.shared().doGetMemberShipBind(e, this.listenBindCallback.bind(this));
        }
        else if ("paste" == t) {
            let e = TransferPlatform.shared().getPasteBoard();
            null != e && (this.exchange_edit.string = e);
        }
    }
    listenBindCallback(e, t, i) {
        if (0 != t.length) {
            if (200 != i) {
                alert("The login timed out, please try again");
            }
            else {
                let e = ToolUtils.parseJson(t);
                0 == e.ret ? (User.shared().clubUserInfo.data.my_referrer = e.data.uid, Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text44"), 2), PushCenter.shared().pushEvent(PushEvent.InviteRefreshBinding), this.node.destroy()) : Utils.shared().showToast(e.desc, 2);
            }
        }
    }
}
