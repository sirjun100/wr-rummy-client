// @ts-nocheck
// Recovered from index.js:191
let HowToPlayDefined;
(HowToPlayDefined = { gameId_RaceRummy: 25, gameId_RummyGame: 3, gameId_PracticeRummy: 26, gameId_PrivateRummy: 27, gameId_PoolRummy: 30, gameId_PoolPrivateRummy: 31, GameType_PoolPractice: 36, gameId_DealsRummy: 28, gameId_DealsPrivateRummy: 32, GameType_DealsPractice: 37, GameType_Multiple: 38, GameType_MultiplePractice: 39, gameId_RedBlack: 29, RUMMY_POINTS: 0, RUMMY_POOL: 1, RUMMY_DEALS: 2, PRI_POINTS: 3, MATCH: 4, PRI_POOL: 5, PRI_DEAL: 6, PERFORMANCE: 7, RUMMY_MULTIPLE: 8, RUMMY_BUMP: 9, gameVid_rummyPoint: 271, gameVid_rummyPool: 300, gameVid_rummyDeal: 600 });
export default HowToPlayDefined;
