// @ts-nocheck
// Recovered from index.js:611
import { _decorator, Button, color, game, instantiate, Label, Layout, Node, ScrollView, size, sp, Sprite, SpriteFrame, sys, UIOpacity, UITransform, v3 } from "cc";
import Utils from "./Utils";
import SoundManager from "./SoundManager";
import BaseLayer from "./BaseLayer";
import User from "./User";
import TweenTool from "./TweenTool";
import HttpManager from "./HttpManager";
import { HttpRequest } from "./HttpRequestName";
import i18nMgr from "./i18nMgr";
import TableViewUtils from "./TableViewUtils";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("StoreReceiptDialog")
export class StoreReceiptDialog extends BaseLayer {
    @property(Node)
    public rootNode: Node = null;
    @property(Node)
    public ruleNode: Node = null;
    @property(Node)
    public winNode: Node = null;
    @property(Node)
    public receiptNode: Node = null;
    @property(Node)
    public histroyNode: Node = null;
    @property([SpriteFrame])
    public rewardIconFrame: SpriteFrame[] = [];
    @property([SpriteFrame])
    public rewardrankFrame: SpriteFrame[] = [];
    public _rewardColors: any[] = [color(212, 38, 15), color(158, 0, 231), color(48, 93, 234), color(0, 145, 102), color(80, 100, 159)];
    public _showType: number = 0;
    public histroyTabView: any = null;
    public receiptTabView: any = null;
    public _lastRound: number = 0;
    public _hasMore: number = 0;
    public _isSendMsg: boolean = false;
    public _itemOpenMap: Map = new Map;
    public _lastClickTime: number = 0;
    setParaData(e) {
        this._showType = e;
    }
    start() {
        super.start();
        this.fitScreen();
        this.startShowAnim(this.rootNode);
        this.ruleNode.active = 0 == this._showType;
        this.winNode.active = 1 == this._showType;
        this.receiptNode.active = 2 == this._showType;
        this.histroyNode.active = 3 == this._showType;
        this.initView();
        this.dealMultipleLanguages();
    }
    dealMultipleLanguages() {
        2 == i18nMgr.shared().language && (this.histroyNode.getChildByName("moban").getChildByName("more").getChildByName("tips").getComponent(Label).fontSize = 20, this.histroyNode.getChildByName("moban").getChildByName("more").getChildByName("tips").getComponent(Label).lineHeight = 24);
    }
    initView() {
        if (0 == this._showType) {
            sys.isObjectValid(User.shared().receiptData.rule) ? this.refreshRuleView() : HttpManager.shared().doGetCommonRequest(null, HttpRequest.LotteryRule, this.listenLotteryRuleCallBack.bind(this));
        }
        else if (1 == this._showType) {
            this.refreshWinView();
        }
        else if (2 == this._showType) {
            let e = this.receiptNode.getChildByName("moban");
            e.active = false;
            let t = [e];
            this.receiptTabView = this.node.addComponent(TableViewUtils);
            let i = e.getComponent(UITransform).height;
            if (this.receiptTabView.init([], this.receiptNode.getChildByName("ScrollView"), t, this.initReceiptCurMobanCallBack.bind(this), 3, i), sys.isObjectValid(User.shared().receiptData.more) && sys.isObjectValid(User.shared().receiptData.more.my)) {
                let e = [];
                for (let t = 0, i = User.shared().receiptData.more.my.length; t < i; t++) {
                    sys.isObjectValid(e[Math.floor(t / 3)]) || (e[Math.floor(t / 3)] = []);
                    e[Math.floor(t / 3)].push(User.shared().receiptData.more.my[t]);
                }
                this.receiptTabView.reloadData(e);
            }
            HttpManager.shared().doGetCommonRequest(null, HttpRequest.LotteryMore, this.listenLotteryMoreCallBack.bind(this));
        }
        else {
            let e = this.histroyNode.getChildByName("moban");
            e.active = false;
            let t = [e];
            this.histroyTabView = this.node.addComponent(TableViewUtils);
            let i = e.getComponent(UITransform).height / 2;
            if (this.histroyTabView.init([], this.histroyNode.getChildByName("ScrollView"), t, this.initHistroyCurMobanCallBack.bind(this), 10, i, this.scrollHistroyRefreshCallBack.bind(this)), this._itemOpenMap.clear(), User.shared().receiptHistorList = [], sys.isObjectValid(User.shared().receiptData.historyList)) {
                for (let e = 0, t = User.shared().receiptData.historyList.length; e < t; e++) {
                    User.shared().receiptHistorList = User.shared().receiptData.historyList[e];
                }
                this.histroyTabView.reloadData(User.shared().receiptHistorList);
            }
            HttpManager.shared().doGetCommonRequest({ round: 0 }, HttpRequest.LotteryHistory, this.listenLotteryHistoryCallBack.bind(this));
        }
    }
    listenLotteryRuleCallBack(e, t, i) {
        if (Utils.shared().hideLoading(), 200 != i) {
            alert("The login timed out, please try again");
        }
        else {
            try {
                let e = ToolUtils.parseJson(t);
                0 == e.ret && (User.shared().receiptData.rule = e.data.rule, ToolUtils.isObjValid(this.node) && this.refreshRuleView());
            }
            catch (e) {
            }
        }
    }
    listenLotteryMoreCallBack(e, t, i) {
        if (Utils.shared().hideLoading(), 200 != i) {
            alert("The login timed out, please try again");
        }
        else {
            try {
                let e = ToolUtils.parseJson(t);
                if (0 == e.ret && (User.shared().receiptData.more = e.data, ToolUtils.isObjValid(this.node) && sys.isObjectValid(User.shared().receiptData.more) && sys.isObjectValid(User.shared().receiptData.more.my))) {
                    let e = [];
                    for (let t = 0, i = User.shared().receiptData.more.my.length; t < i; t++) {
                        sys.isObjectValid(e[Math.floor(t / 3)]) || (e[Math.floor(t / 3)] = []);
                        e[Math.floor(t / 3)].push(User.shared().receiptData.more.my[t]);
                    }
                    this.receiptTabView.reloadData(e);
                }
            }
            catch (e) {
            }
        }
    }
    listenLotteryHistoryCallBack(e, t, i) {
        if (Utils.shared().hideLoading(), ToolUtils.isObjValid(this.node) && (this._isSendMsg = false), 200 != i) {
            alert("The login timed out, please try again");
        }
        else {
            try {
                let e = ToolUtils.parseJson(t);
                if (0 == e.ret) {
                    0 == this._lastRound && (User.shared().receiptHistorList = []);
                    for (let t = 0, i = e.data.list.length; t < i; t++) {
                        User.shared().receiptHistorList.push(e.data.list[t]);
                    }
                    ToolUtils.isObjValid(this.node) && (this._lastRound = e.data.round, this._hasMore = e.data.more, this.histroyTabView.reloadData(User.shared().receiptHistorList));
                }
            }
            catch (e) {
            }
        }
    }
    refreshRuleView() {
        this.ruleNode.getChildByName("ScrollView").getComponent(ScrollView).content.getChildByName("tips").getComponent(Label).string = User.shared().receiptData.rule;
    }
    refreshWinView() {
        let e = User.shared().receiptData.youWin;
        this.node.getChildByName("mask").getComponent(UIOpacity).opacity = 0;
        TweenTool.moveToByFade(this.node.getChildByName("mask"), 0.1, v3(0, 0), 0, 1, true, (() => {
            this.node.getChildByName("mask").getComponent(UIOpacity).opacity = 255;
        }));
        let t = this.winNode.getChildByName("bgAnim");
        t.active = false;
        this.winNode.getChildByName("anim").active = false;
        TweenTool.delayAct(t, (() => {
            t.active = true;
            t.getComponent(sp.Skeleton).clearTracks();
            t.getComponent(sp.Skeleton).setAnimation(0, "zk1", false);
            let i = 0 == i18nMgr.shared().language ? "English" : "Hindi";
            t.getComponent(sp.Skeleton).setSkin(i);
            t.getComponent(sp.Skeleton).setAttachment("ani_hd_xxxp_bj", ToolUtils.format("ani_hd_xxxp_bj${0}", e.rank));
            t.getComponent(sp.Skeleton).setCompleteListener((() => {
                t.getComponent(sp.Skeleton).setAnimation(0, "xh", true);
                t.getComponent(sp.Skeleton).setAttachment("ani_hd_xxxp_bj", ToolUtils.format("ani_hd_xxxp_bj${0}", e.rank));
            }));
            this.winNode.getChildByName("anim").active = true;
            this.winNode.getChildByName("anim").getComponent(sp.Skeleton).clearTracks();
            this.winNode.getChildByName("anim").getComponent(sp.Skeleton).setAnimation(0, "zk2", false);
        }), 0.15, true);
        Utils.shared().updateHeadImg(t.getChildByName("head").getChildByName("mask").getChildByName("img"), e.avatar, e.avatar_url, size(170, 170));
        let i = this.winNode.getChildByName("root");
        i.getChildByName("round").getComponent(Label).string = ToolUtils.format("#${0}", e.round);
        i.getChildByName("code").getComponent(Label).string = e.code;
        i.getChildByName("money").getComponent(Label).string = ToolUtils.format("₹${0}", e.all);
        this._rewardColors[e.rank - 1] && (i.getChildByName("money").getComponent(Label).color = this._rewardColors[e.rank - 1], i.getChildByName("money_bg").getComponent(Sprite).color = this._rewardColors[e.rank - 1], i.getChildByName("name").getComponent(Label).color = this._rewardColors[e.rank - 1]);
        i.getChildByName("name").getComponent(Label).string = ToolUtils.GetShortName2(e.name, 13, false);
        this.rewardrankFrame[e.rank - 1] && (i.getChildByName("rank").getComponent(Sprite).spriteFrame = this.rewardrankFrame[e.rank - 1]);
        i.getChildByName("reward").removeAllChildren();
        let a = i.getChildByName("reward_moban");
        if (a.active = false, sys.isObjectValid(e.reward) && e.reward.length > 0) {
            i.getChildByName("reward").active = true;
            for (let t = 0, o = e.reward.length; t < o; t++) {
                let r = instantiate(a);
                r.active = true;
                r.setPosition(v3(0, 0));
                r.getChildByName("plus").active = t < o - 1;
                r.getChildByName("num").getComponent(Label).string = e.reward[t].amt;
                this.rewardIconFrame[e.reward[t].type] && (r.getChildByName("icon").getComponent(Sprite).spriteFrame = this.rewardIconFrame[e.reward[t].type]);
                i.getChildByName("reward").addChild(r);
                i.getChildByName("reward").getComponent(Layout).updateLayout();
            }
        }
        else {
            i.getChildByName("reward").active = false;
        }
        i.getComponent(UIOpacity).opacity = 0;
        TweenTool.stopNodeAction(i);
        let o = TweenTool.delayAct(i, null, 0.48, false), r = TweenTool.moveToByFade(i, 0.17, v3(0, 72), 0, 1, false);
        TweenTool.sequence(i, true, (() => {
            i.getComponent(UIOpacity).opacity = 255;
        }), o, r);
    }
    initReceiptCurMobanCallBack(e, t, i) {
        e.active = true;
        for (let i = 0; i < 3; i++) {
            let a = e.getChildByName(ToolUtils.format("item${0}", i));
            sys.isObjectValid(t) && t[i] ? (a.active = true, a.getChildByName("round").getComponent(Label).string = ToolUtils.format("#${0}", User.shared().receiptData.more.round), a.getChildByName("code").getComponent(Label).string = t[i].code, i18nMgr.shared().changeLabelLanguage(a.getChildByName("date").getComponent(Label), "store_receipt.get_at", false, t[i].ts)) : a.active = false;
        }
    }
    initHistroyCurMobanCallBack(e, t, i) {
        if (sys.isObjectValid(t)) {
            e.active = true;
            e.getChildByName("date_node").getChildByName("time").getComponent(Label).string = t.time;
            e.getChildByName("date_node").getChildByName("round").getComponent(Label).string = ToolUtils.format("#${0}", t.round);
            for (let i = 1; i <= 5; i++) {
                let a = e.getChildByName("rank" + i), o = t.rank[ToolUtils.format("${0}", i)];
                if (sys.isObjectValid(o)) {
                    if (a.getChildByName("rank_node").getChildByName("reward").getComponent(Label).string = ToolUtils.format("₹${0}", o.cash), a.getChildByName("rank_node").getChildByName("win_bg").active = 1 == o.win, a.getChildByName("rank_node").getChildByName("win").active = 1 == o.win, i <= 3) {
                        a.active = true;
                        a.getChildByName("name").getComponent(Label).string = ToolUtils.GetShortName2(o.name, 13, false);
                        a.getChildByName("code").getComponent(Label).string = o.code;
                        Utils.shared().updateHeadImg(a.getChildByName("head").getChildByName("img"), o.avatar, o.avatar_url, size(72, 72));
                    }
                    else {
                        a.active = false;
                        let t = e.getChildByName("more").getChildByName("rank" + i);
                        ToolUtils.isObjValid(t) && (t.getChildByName("wz").getComponent(Label).string = ToolUtils.format("₹${0}", o.cash));
                        let r = a.getChildByName("num_node");
                        r.removeAllChildren();
                        let n = a.getChildByName("num_moban");
                        n.active = false;
                        for (let e = 0, t = o.codes.length; e < t; e++) {
                            let t = instantiate(n);
                            t.active = true;
                            t.getChildByName("bg").active = 1 == o.codes[e].win;
                            t.getChildByName("code").getComponent(Label).string = o.codes[e].code;
                            let i = 1 == o.codes[e].win ? color(255, 254, 254) : color(102, 102, 102);
                            t.getChildByName("code").getComponent(Label).color = i;
                            r.addChild(t);
                            r.getComponent(Layout).updateLayout();
                        }
                    }
                }
                else {
                    a.active = false;
                }
            }
            if (sys.isObjectValid(t.rank[ToolUtils.format("${0}", 4)]) || sys.isObjectValid(t.rank[ToolUtils.format("${0}", 5)])) {
                e.getChildByName("more").getChildByName("tips").active = true;
                e.getChildByName("more").getChildByName("more_btn").active = true;
                e.getChildByName("more").getChildByName("more_btn").getComponent(Button).clickEvents[0].customEventData = String(this.histroyTabView.getCellIndex(e));
                let i = this._itemOpenMap.get(t.round);
                this.dealMoreInfo(e, t, i);
            }
            else {
                e.getChildByName("more").getChildByName("win").active = false;
                e.getChildByName("more").getChildByName("rank4").active = false;
                e.getChildByName("more").getChildByName("rank5").active = false;
                e.getChildByName("more").getChildByName("tips").active = false;
                e.getChildByName("more").getChildByName("more_btn").active = false;
            }
        }
    }
    scrollHistroyRefreshCallBack() {
        1 != this._hasMore || this._isSendMsg || (this._isSendMsg = true, HttpManager.shared().doGetCommonRequest({ round: this._lastRound }, HttpRequest.LotteryHistory, this.listenLotteryHistoryCallBack.bind(this)));
    }
    dealMoreInfo(e, t, i) {
        if (sys.isObjectValid(t) && ToolUtils.isObjValid(e)) {
            let a = t.rank[ToolUtils.format("${0}", 4)], o = t.rank[ToolUtils.format("${0}", 5)];
            if (sys.isObjectValid(a) && 1 == a.win || sys.isObjectValid(o) && 1 == o.win ? e.getChildByName("more").getChildByName("win").active = !i : e.getChildByName("more").getChildByName("win").active = false, sys.isObjectValid(a) ? (e.getChildByName("rank4").active = i, e.getChildByName("more").getChildByName("rank4").active = !i) : (e.getChildByName("rank4").active = false, e.getChildByName("more").getChildByName("rank4").active = false), sys.isObjectValid(o)) {
                e.getChildByName("rank5").active = i;
                e.getChildByName("more").getChildByName("rank5").active = !i;
                let t = sys.isObjectValid(a) ? v3(70, -21) : v3(-80, -21);
                e.getChildByName("more").getChildByName("rank5").setPosition(t);
            }
            else {
                e.getChildByName("rank5").active = false;
                e.getChildByName("more").getChildByName("rank5").active = false;
            }
            let r = v3(0.7, i ? -0.7 : 0.7, 1);
            this._itemOpenMap.set(t.round, i);
            let n = i ? "store_receipt.close" : "store_receipt.more_results";
            i18nMgr.shared().changeLabelLanguage(e.getChildByName("more").getChildByName("tips").getComponent(Label), n);
            e.getChildByName("more").getChildByName("more_btn").getChildByName("img").scale = r;
        }
    }
    onMoreClick(e, t) {
        if (sys.now() - this._lastClickTime < 500) {
            return;
        }
        this._lastClickTime = sys.now();
        SoundManager.shared().playFx("click");
        let i = Number(t);
        if (sys.isObjectValid(i)) {
            let e = this.histroyTabView.getIndexCell(i), t = e.getComponent(UITransform).contentSize.height;
            if (sys.isObjectValid(User.shared().receiptHistorList) && sys.isObjectValid(User.shared().receiptHistorList[i])) {
                let a = User.shared().receiptHistorList[i], o = this._itemOpenMap.get(a.round);
                this.dealMoreInfo(e, a, !o);
                this.scheduleOnce((() => {
                    if (ToolUtils.isObjValid(this.node)) {
                        e.getComponent(Layout).updateLayout(true);
                        let a = e.getComponent(UITransform).contentSize.height;
                        this.histroyTabView.resetItemSize(i, a - t);
                    }
                }), game.frameTime / 1000);
            }
            else {
                HttpManager.shared().doGetCommonRequest({ round: this._lastRound }, HttpRequest.LotteryHistory, this.listenLotteryHistoryCallBack.bind(this));
            }
        }
    }
    onButtonClick(e, t) {
        SoundManager.shared().playFx("click");
        "close" == t && ToolUtils.isObjValid(this.node) && this.node.destroy();
    }
    fitScreen() {
        ToolUtils.showFullScreen(this.node.getChildByName("mask"));
        let e = this.histroyNode.getChildByName("ScrollView").getComponent(UITransform).contentSize, t = Utils.shared().getOffsetDistance() / 2 + e.height;
        this.histroyNode.getChildByName("ScrollView").getComponent(UITransform).contentSize = size(e.width, t);
        let i = this.receiptNode.getChildByName("ScrollView").getComponent(UITransform).contentSize, a = Utils.shared().getOffsetDistance() / 2 + i.height;
        this.receiptNode.getChildByName("ScrollView").getComponent(UITransform).contentSize = size(i.width, a);
    }
}
