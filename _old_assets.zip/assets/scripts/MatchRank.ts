// @ts-nocheck
// Recovered from index.js:301
import { _decorator, Button, color, Font, instantiate, Label, Node, ScrollView, size, Sprite, SpriteAtlas, SpriteFrame, sys, UITransform, v3, Vec3 } from "cc";
import Utils from "./Utils";
import User from "./User";
import SoundManager from "./SoundManager";
import i18nMgr from "./i18nMgr";
import TableViewUtils from "./TableViewUtils";
import { TLog } from "./TLog";
import BaseLayer from "./BaseLayer";
import TweenTool from "./TweenTool";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("MatchRank")
export class MatchRank extends BaseLayer {
    @property(Node)
    public rankList: Node = null;
    @property(Node)
    public rankMoban: Node = null;
    @property(Node)
    public myRankNode: Node = null;
    @property([SpriteFrame])
    public rankSpriteFrame: SpriteFrame[] = [];
    @property(Font)
    public scoreFont: Font = null;
    @property(Node)
    public rank_root: Node = null;
    @property(Node)
    public reward_root: Node = null;
    @property([Node])
    public tab_nodes: Node[] = [];
    @property([SpriteFrame])
    public ticket_images: SpriteFrame[] = [];
    @property(SpriteAtlas)
    public rewardAtlas: SpriteAtlas = null;
    public rewardNames: any[] = ["reward_watch.png"];
    public rankTableView: any = null;
    public rankData: any = null;
    public rewardInfos: any = null;
    public curTabIndex: number = 0;
    start() {
        super.start();
        let e = this.node.getChildByName("mask");
        ToolUtils.showFullScreen(e);
        this.rankMoban.active = false;
        this.refreshTab(0);
        let t = [this.rankMoban];
        this.rankTableView = this.node.addComponent(TableViewUtils);
        let a = this.rankMoban.getComponent(UITransform).height;
        if (!ToolUtils.getOrientation()) {
            let e = this.node.getChildByName("rootNode").getChildByName("bg");
            e.getComponent(UITransform).setContentSize(size(672, 992));
            e.setPosition(new Vec3(0, -2));
            let t = this.node.getChildByName("rootNode");
            t.getChildByName("title").setPosition(new Vec3(0, 450));
            t.getChildByName("close_btn").setPosition(new Vec3(297, 450));
            t.getChildByName("tab0").active = false;
            t.getChildByName("tab1").active = false;
            this.rankList.getComponent(UITransform).setContentSize(size(660, 769));
            this.rankList.setPosition(new Vec3(0, 350));
            this.rank_root.getChildByName("title_item").setPosition(new Vec3(0, 410));
            this.myRankNode.setPosition(new Vec3(0, -454));
        }
        this.rankTableView.init([], this.rankList, t, this.initRankItem.bind(this), 2, a, null);
        this.rankData && (this.rankTableView.reloadData(this.rankData), this.setMyRankInfo());
        ToolUtils.startShowAnim(this.node.getChildByName("rootNode"));
    }
    initRankItem(e, t, a) {
        e.active = true;
        e.getChildByName("name").getComponent(Label).string = ToolUtils.GetShortName2(t.name, 10, true);
        t.state && 1 == t.state ? (0 == a ? (i18nMgr.shared().changeLabelLanguage(e.getChildByName("score").getComponent(Label), "match_rank.win"), e.getChildByName("score").getComponent(Label).color = color(0, 131, 21)) : (i18nMgr.shared().changeLabelLanguage(e.getChildByName("score").getComponent(Label), "match_rank.out"), e.getChildByName("score").getComponent(Label).color = color(102, 102, 102)), e.getChildByName("score").getComponent(Label).fontSize = 28) : (e.getChildByName("score").getComponent(Label).string = t.score, e.getChildByName("score").getComponent(Label).color = color(0, 131, 21), e.getChildByName("score").getComponent(Label).font = this.scoreFont, e.getChildByName("score").getComponent(Label).fontSize = 28);
        e.getChildByName("rank").getComponent(Label).string = a + 1 + "";
        e.getChildByName("line").active = a != this.rankData.length - 1;
        e.getChildByName("rank").active = true;
        e.getChildByName("rank_icon").active = false;
        a < 3 && (e.getChildByName("rank").active = false, e.getChildByName("rank_icon").active = true, e.getChildByName("rank_icon").getComponent(Sprite).spriteFrame = this.rankSpriteFrame[a]);
    }
    setMyRankInfo() {
        for (let e = 0, t = this.rankData.length; e < t; e++) {
            let t = this.rankData[e];
            t.uid == User.shared().data.uid && (this.myRankNode.getChildByName("name").getComponent(Label).string = ToolUtils.GetShortName2(t.name, 10, true), t.state && 1 == t.state ? 0 == e ? i18nMgr.shared().changeLabelLanguage(this.myRankNode.getChildByName("score").getComponent(Label), "match_rank.win") : i18nMgr.shared().changeLabelLanguage(this.myRankNode.getChildByName("score").getComponent(Label), "match_rank.out") : this.myRankNode.getChildByName("score").getComponent(Label).string = t.score, this.myRankNode.getChildByName("rank").getComponent(Label).string = 0 != t.rank && null != t.rank ? t.rank : "--", this.myRankNode.getChildByName("rank").active = true, this.myRankNode.getChildByName("rank_icon").active = false, t.rank > 0 && t.rank <= 3 && (this.myRankNode.getChildByName("rank").active = false, this.myRankNode.getChildByName("rank_icon").active = true, this.myRankNode.getChildByName("rank_icon").getComponent(Sprite).spriteFrame = this.rankSpriteFrame[t.rank - 1]));
        }
    }
    refreshUI(e, t = null) {
        sys.isObjectValid(e) && (this.rankData = this.sortRankData(e), this.rankTableView && (this.rankTableView.reloadData(e), this.setMyRankInfo()));
        sys.isObjectValid(t) && (this.rewardInfos = t, this.refreshRaceRewardList(t));
    }
    refreshRankList(e) {
        sys.isObjectValid(e) && (this.rankData = this.sortRankData(e), this.rankTableView && (this.rankTableView.reloadData(e), this.setMyRankInfo()));
    }
    sortRankData(e) {
        return e.sort((function (e, t) {
            return e.rank - t.rank;
        })), e;
    }
    refreshRaceRewardList(e) {
        try {
            let t = this.reward_root.getChildByName("item"), a = this.reward_root.getChildByName("tips_root");
            t.active = false;
            let i = this.reward_root.getChildByName("ScrollView").getComponent(ScrollView);
            if (i.content.removeAllChildren(), a.active = false, e && e.length > 0) {
                let a;
                for (let n = 0, r = e.length; n < r; n++) {
                    let r = e[n];
                    a = instantiate(t);
                    i.content.addChild(a);
                    a.active = true;
                    let o = a.getChildByName("rank");
                    a.getChildByName("rank").active = true;
                    a.getChildByName("rank_icon").active = false;
                    n < 3 && (a.getChildByName("rank").active = false, a.getChildByName("rank_icon").active = true, a.getChildByName("rank_icon").getComponent(Sprite).spriteFrame = this.rankSpriteFrame[n]);
                    sys.isObjectValid(r.desc) && (o.getComponent(Label).string = r.desc + "");
                    a.getChildByName("line").active = n != e.length - 1;
                    let s = a.getChildByName("prize_root");
                    if (s && sys.isObjectValid(r.infos2) && Array(r.infos2) && r.infos2.length > 0) {
                        s.active = true;
                        let e = s.getChildByName("layout0"), t = s.getChildByName("layout1"), a = s.getChildByName("layout2"), i = s.getChildByName("layout3"), n = e.getChildByName("gold").getComponent(Label), o = t.getChildByName("bonus").getComponent(Label), l = a.getChildByName("discount").getComponent(Label), h = a.getChildByName("ic").getComponent(Sprite);
                        e.active = false;
                        t.active = false;
                        a.active = false;
                        i.active = false;
                        for (let s = 0; s < r.infos2.length; s++) {
                            const d = r.infos2[s];
                            if (sys.isObjectValid(d)) {
                                if (sys.isObjectValid(d.type) && 2 == d.type) {
                                    e.active = true;
                                    sys.isObjectValid(d.value) && (n.string = "" + ToolUtils.parse_double(String(d.value), -1));
                                }
                                else if (sys.isObjectValid(d.type) && 6 == d.type) {
                                    t.active = true;
                                    sys.isObjectValid(d.value) && (o.string = "" + ToolUtils.parse_double(String(d.value), -1));
                                }
                                else if (sys.isObjectValid(d.type) && 11 == d.type) {
                                    if (a.active = true, sys.isObjectValid(d.discount)) {
                                        let e = Number(d.discount);
                                        h.spriteFrame = 100 == e ? this.ticket_images[1] : this.ticket_images[0];
                                        0 != i18nMgr.shared().language && i18nMgr.shared().changeLabelFont(l);
                                        let t = ToolUtils.format(i18nMgr.shared().getValueByKey("ticket.off"), d.discount);
                                        sys.isObjectValid(d.value) && Number(d.value) >= 2 && (t = t + "*" + d.value);
                                        l.string = t;
                                    }
                                }
                                else if (sys.isObjectValid(d.type) && 13 == d.type) {
                                    i.active = true;
                                    let e = i.getChildByName("ic"), t = i.getChildByName("desc"), a = ToolUtils.isSafeString(d.item_url), n = ToolUtils.getImageUrlPictureName(a);
                                    ToolUtils.isSafeString(n).length > 0 && (n != this.rewardNames[0] ? (Utils.shared().setImage(e, "reward_unload", this.rewardAtlas), Utils.shared().updateNetImage(e, a, size(48.24, 48.24), (() => {
                                    }))) : Utils.shared().setImage(e, "reward_watch", this.rewardAtlas));
                                    sys.isObjectValid(d.item_name) && (i18nMgr.shared().changeLabelFont(t.getComponent(Label)), t.getComponent(Label).string = "" + d.item_name);
                                }
                            }
                        }
                    }
                }
            }
            let n = instantiate(a);
            n.active = true;
            i.content.addChild(n);
        }
        catch (e) {
            TLog.printError("trycatch error refreshRaceRewardList:", e);
        }
    }
    onButtonClick(e, t) {
        SoundManager.shared().playFx("click");
        "close" == t && ToolUtils.isObjValid(this.node) && this.node.destroy();
    }
    onTabClick(e, t) {
        SoundManager.shared().playFx("click");
        let a = Number(t);
        this.refreshTab(a);
    }
    refreshTab(e) {
        0 == e ? (this.rank_root.active = true, this.reward_root.active = false) : (this.rank_root.active = false, this.reward_root.active = true);
        for (let t = 0; t < this.tab_nodes.length; t++) {
            let a = this.tab_nodes[t], i = a.getChildByName("line"), n = a.getChildByName("di"), r = a.getChildByName("Label");
            if (t == e) {
                if (a.getComponent(Button).interactable = false, r.getComponent(Label).color = color(183, 0, 0), i.active = true, n.active = false, this.curTabIndex != e) {
                    i.scale = v3(0, 1, 1);
                    let e = TweenTool.scaleTo(i, 0.16, v3(1.1, 1, 1), null, false), t = TweenTool.scaleTo(i, 0.16, v3(1, 1, 1), null, false);
                    TweenTool.sequence(i, true, null, e, t);
                }
                else {
                    i.scale = v3(1, 1, 1);
                }
            }
            else {
                a.getComponent(Button).interactable = true;
                r.getComponent(Label).color = color(84, 89, 155);
                i.scale = v3(1, 1, 1);
                n.active = true;
                t == this.curTabIndex ? TweenTool.scaleTo(i, 0.1, v3(0.2, 1, 1), null, true, (() => {
                    i.scale = v3(1, 1, 1);
                    i.active = false;
                })) : i.active = false;
            }
        }
        this.curTabIndex = e;
    }
    setLandscapeShow() {
        ToolUtils.getOrientation() || this.node.setRotationFromEuler(v3(0, 0, -90));
    }
    setTidKey(e) {
        this.bIsInGame = true;
        this.tid_key = e;
    }
    scrollRefreshCallBack() {
        ToolUtils.getOrientation();
    }
}
