// @ts-nocheck
// Recovered from index.js:75
import { _decorator, Button, color, Label, LabelShadow, Node, RichText, size, Sprite, SpriteFrame, sys, UITransform, v3, Vec3 } from "cc";
import BaseLayer from "./BaseLayer";
import TweenTool from "./TweenTool";
import Utils from "./Utils";
import i18nMgr from "./i18nMgr";
import PushEvent from "./PushEvent";
import User from "./User";
import SoundManager from "./SoundManager";
import { ToolUtils } from "./ToolUtils";
import CommDefine from "./CommDefine";
import PhpReportDefined from "./PhpReportDefined";
import HttpManager from "./HttpManager";
import RummyDataManager from "./RummyDataManager";
import GameConfig from "./GameConfig";
const { ccclass, property } = _decorator;
@ccclass("CommonDlgAlert")
export default class CommonDlgAlert extends BaseLayer {
    @property(Node)
    public rootNode: Node = null;
    @property(Node)
    public smallBg: Node = null;
    @property(Node)
    public middleBg: Node = null;
    @property(Node)
    public smallBg2: Node = null;
    @property(Label)
    public middleTips: Label = null;
    @property([SpriteFrame])
    public buttonSprites: SpriteFrame[] = [];
    @property([SpriteFrame])
    public chip_imgs_617: SpriteFrame[] = [];
    public alertBg: any = null;
    public alert_type: number = 0;
    public _type: number = 0;
    public _cb: any = null;
    public counttime: any = -1;
    public _sec: number = 0;
    public _scheduleAction: any = null;
    public _touchClose: boolean = false;
    public _bCanBack: boolean = true;
    public _sceneType: any = -1;
    public _closeType: any = -1;
    public _bReport: boolean = false;
    onLoad() {
        this._bReport = ToolUtils.checkIsModuleReport(PhpReportDefined.module.high_entry_game);
    }
    fitChipMode() {
        if (0 == GameConfig.CHIPS_MODLE) {
            return;
        }
        if (ToolUtils.judgeIfInRummy()) {
            return;
        }
        let e = 2000617 == GameConfig.CHANNEL_ID;
        e && e && 0 == GameConfig.GAME_HALL_THEME && (this.smallBg.getChildByName("bg").getComponent(Sprite).spriteFrame = this.chip_imgs_617[0], this.middleBg.getChildByName("bg").getComponent(Sprite).spriteFrame = this.chip_imgs_617[0], this.smallBg2.getChildByName("bg").getComponent(Sprite).spriteFrame = this.chip_imgs_617[0]);
    }
    start() {
        super.start();
        let e = this.node.getChildByName("bg1");
        ToolUtils.showFullScreen(e);
        3 == this._closeType && this._bReport && HttpManager.shared().doReportClick({ module: PhpReportDefined.module.high_entry_game, scene: this._sceneType, event: PhpReportDefined.high_entry_game_event.show });
    }
    showNodeAnim(e = false) {
        ToolUtils.getIsNormalDirection() || this.node.setRotationFromEuler(v3(0, 0, 90));
        this.startShowAnim(this.rootNode);
    }
    onclickByClose(e, t) {
        SoundManager.shared().playFx("click");
        "touch_close" == t ? this._touchClose && ToolUtils.isObjValid(this.node) && this.node.destroy() : (this._cb && this._cb(2), ToolUtils.isObjValid(this.node) && this.node.destroy());
    }
    onClickByBtn(e, t) {
        if (SoundManager.shared().playFx("click"), "ok" == t && (3 == this._closeType && this._bReport && HttpManager.shared().doReportClick({ module: PhpReportDefined.module.high_entry_game, scene: this._sceneType, event: PhpReportDefined.high_entry_game_event.click_play_now }), this._cb && this._cb(1)), "cancel" == t && this._cb && this._cb(3), "kefu" == t) {
            if (1 != User.shared().temp_pingbi.feedback) {
                return void Utils.shared().doJumpLogic(PushEvent.JUMP_TO_FEEDBACK);
            }
            Utils.shared().showToast("Coming soon", 2);
            this._cb && this._cb(3);
        }
        "update" == t && this._cb && this._cb(1);
        "notNow" == t && this._cb && this._cb(3);
        ToolUtils.isObjValid(this.node) && this.node.destroy();
    }
    updateDlgInfo1(e = "", t = "", i = null, s = false, l = 0) {
        e = sys.isObjectValid(e) ? String(e) : "";
        this.middleBg.active = false;
        ToolUtils.getIsInRoom() ? (this.smallBg2.active = true, this.smallBg.active = false, this.alertBg = this.smallBg2) : (this.smallBg2.active = false, this.smallBg.active = true, this.alertBg = this.smallBg);
        this.alert_type = 0;
        this.alertBg.getChildByName("ok").active = true;
        this.alertBg.getChildByName("cancel").active = false;
        this.alertBg.getChildByName("sure").active = false;
        let a = this.alertBg.getChildByName("title"), o = this.alertBg.getChildByName("content"), h = this.alertBg.getChildByName("richcontent"), c = this.alertBg.getChildByName("thanks"), B = this.alertBg.getChildByName("bonus_tip");
        o.active = 1 != this._type;
        h.active = 1 == this._type;
        let u = new Vec3;
        if (o.getPosition(u), this._closeType = l, 1 == l) {
            ToolUtils.isObjValid(c) && (c.active = true);
            ToolUtils.isObjValid(B) && (B.active = false);
            o.getComponent(Label).fontSize = 56;
            o.setPosition(v3(u.x, u.y + 25));
            h.setPosition(v3(h.position.x, h.position.y + 25));
            this.alertBg.getChildByName("ok").setPosition(this.alertBg.getChildByName("ok").position.x, this.alertBg.getChildByName("ok").position.y + 45);
        }
        else if (2 == l) {
            if (ToolUtils.isObjValid(B) && (B.active = true), ToolUtils.isObjValid(c) && (c.active = false), RummyDataManager.shared().rummyInfos.get(this.tid_key).tf_bonus > 0) {
                let e = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_main.bonus_drop_tip"), ToolUtils.parse_double("" + RummyDataManager.shared().rummyInfos.get(this.tid_key).tf_bonus));
                B.getChildByName("tips").getComponent(Label).string = e;
            }
            else {
                B.getChildByName("tips").getComponent(Label).string = i18nMgr.shared().getValueByKey("rummy_main.bonus_less_tip");
            }
            o.getComponent(Label).fontSize = 48;
            o.getComponent(Label).lineHeight = 56;
            o.setPosition(v3(u.y, u.y - 100));
        }
        else if (3 == l) {
            let e = new Vec3;
            this.alertBg.getChildByName("ok").getPosition(e);
            ToolUtils.isObjValid(c) && (c.active = true);
            o.getComponent(Label).lineHeight = 80;
            o.getComponent(Label).fontSize = 64;
            o.setPosition(v3(u.x, u.y + 31));
            this.alertBg.getChildByName("ok").setPosition(e.x, e.y + 54);
        }
        else {
            ToolUtils.isObjValid(B) && (B.active = false);
            ToolUtils.isObjValid(c) && (c.active = false);
        }
        e.length > 0 && (1 == this._type ? h.getComponent(RichText).string = e : o.getComponent(Label).string = e);
        t.length > 0 ? a.getComponent(Label).string = t : a.getComponent(Label).string = i18nMgr.shared().getValueByKey("utlis.notice");
        i18nMgr.shared().changeLabelFont(a.getComponent(Label), true);
        i18nMgr.shared().changeLabelFont(o.getComponent(Label));
        i18nMgr.shared().changeLabelFont(h.getComponent(RichText));
        null != i && (this._cb = i);
        s && (this.alertBg.getChildByName("close").active = false);
    }
    updateDlgInfo2(e = "", t = "", i = null, s = false, l = 0) {
        e = sys.isObjectValid(e) ? String(e) : "";
        this.alert_type = 0;
        ToolUtils.getIsInRoom() ? (this.smallBg2.active = true, this.smallBg.active = false, this.alertBg = this.smallBg2) : (this.smallBg2.active = false, this.smallBg.active = true, this.alertBg = this.smallBg);
        this.alertBg.getChildByName("ok").active = false;
        this.alertBg.getChildByName("cancel").active = true;
        this.alertBg.getChildByName("sure").active = true;
        let a = this.alertBg.getChildByName("thanks"), o = this.alertBg.getChildByName("bonus_tip"), h = this.alertBg.getChildByName("title"), m = this.alertBg.getChildByName("content"), c = this.alertBg.getChildByName("richcontent");
        if (2 == l) {
            if (ToolUtils.isObjValid(o) && (o.active = true), ToolUtils.isObjValid(a) && (a.active = false), RummyDataManager.shared().rummyInfos.get(this.tid_key).tf_bonus > 0) {
                let e = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_main.bonus_drop_tip"), ToolUtils.parse_double("" + RummyDataManager.shared().rummyInfos.get(this.tid_key).tf_bonus));
                o.getChildByName("tips").getComponent(Label).string = e;
            }
            else {
                o.getChildByName("tips").getComponent(Label).string = i18nMgr.shared().getValueByKey("rummy_main.bonus_less_tip");
            }
            m.getComponent(Label).fontSize = 48;
            m.getComponent(Label).lineHeight = 56;
            m.setPosition(v3(m.position.x, m.position.y - 100));
        }
        else {
            ToolUtils.isObjValid(o) && (o.active = false);
            ToolUtils.isObjValid(a) && (a.active = false);
        }
        m.active = 1 != this._type;
        c.active = 1 == this._type;
        e.length > 0 && (1 == this._type ? c.getComponent(RichText).string = e : m.getComponent(Label).string = e);
        t.length > 0 ? h.getComponent(Label).string = t : h.getComponent(Label).string = i18nMgr.shared().getValueByKey("utlis.notice");
        i18nMgr.shared().changeLabelFont(h.getComponent(Label), true);
        null != i && (this._cb = i);
        s && (this.alertBg.getChildByName("close").active = false);
    }
    setDialogType(e) {
        this._type = e || 0;
    }
    updateButtonWzColor(e, t) {
        sys.isObjectValid(e) && (e.interactable ? (Utils.updateLabelMaterial(t, CommDefine.gradient.btn_green), t.getComponent(LabelShadow).color = color(5, 123, 58, 255)) : (Utils.updateLabelMaterial(t, CommDefine.gradient.btn_gray), t.getComponent(LabelShadow).color = color(103, 103, 103, 255)));
    }
    updateMiddleAlertInfo(e, t = "", i = false, s = null, l = 0, a = 0) {
        this.alert_type = l;
        this.middleBg.active = true;
        this.smallBg.active = false;
        this.smallBg2.active = false;
        this.alertBg = this.middleBg;
        this.middleBg.getChildByName("ok").active = !i;
        this.middleBg.getChildByName("cancel").active = i;
        this.middleBg.getChildByName("sure").active = i;
        let o = true, d = this.middleBg.getChildByName("ok").getChildByName("New Label");
        if (1 == l) {
            o = false;
            a > 0 ? (this.middleBg.getChildByName("ok").getComponent(Sprite).spriteFrame = this.buttonSprites[1], this.middleBg.getChildByName("ok").getComponent(Button).interactable = false, this.middleBg.getChildByName("ok").getChildByName("New Label").getComponent(Label).string = a + "s") : (this.middleBg.getChildByName("ok").getComponent(Sprite).spriteFrame = this.buttonSprites[0], this.middleBg.getChildByName("ok").getComponent(Button).interactable = true);
            this.updateButtonWzColor(this.middleBg.getChildByName("ok").getComponent(Button), d);
            this._sec = a;
            this._scheduleAction && (TweenTool.stopAction(this._scheduleAction), this._scheduleAction = null);
            a > 0 && (this._scheduleAction = TweenTool.myschedule(this.node, 1, (() => {
                this._sec = this._sec - 1;
                this._sec <= 0 ? (TweenTool.stopAction(this._scheduleAction), this._scheduleAction = null, this.middleBg.getChildByName("ok").getComponent(Sprite).spriteFrame = this.buttonSprites[0], this.middleBg.getChildByName("ok").getComponent(Button).interactable = true, i18nMgr.shared().changeLabelLanguage(this.middleBg.getChildByName("ok").getChildByName("New Label").getComponent(Label), "match_alert.okay", true)) : (this.middleBg.getChildByName("ok").getComponent(Sprite).spriteFrame = this.buttonSprites[1], this.middleBg.getChildByName("ok").getChildByName("New Label").getComponent(Label).string = this._sec + "s", this.middleBg.getChildByName("ok").getComponent(Button).interactable = false);
                this.updateButtonWzColor(this.middleBg.getChildByName("ok").getComponent(Button), d);
            })));
        }
        else if (2 == l) {
            o = false;
            this.middleBg.getChildByName("ok").active = false;
            this.middleBg.getChildByName("cancel").active = false;
            this.middleBg.getChildByName("sure").active = false;
            this.middleBg.getChildByName("update").active = true;
            this.middleBg.getChildByName("update").setPosition(v3(0, -379));
            this.middleBg.getChildByName("not_now").active = true;
            let e = this.middleBg.getChildByName("ScrollView"), t = e.getComponent(UITransform).contentSize;
            e.getComponent(UITransform).contentSize = size(t.width, t.height - 60);
            e.getChildByName("view").getComponent(UITransform).contentSize = e.getComponent(UITransform).contentSize;
        }
        else {
            3 == l && (o = false, this.middleBg.getChildByName("ok").active = false, this.middleBg.getChildByName("cancel").active = false, this.middleBg.getChildByName("sure").active = false, this.middleBg.getChildByName("update").active = true, this.middleBg.getChildByName("update").setPosition(this.middleBg.getChildByName("ok").getPosition()), this.middleBg.getChildByName("not_now").active = false);
        }
        this.middleBg.getChildByName("close").active = o;
        let m = this.middleBg.getChildByName("title");
        e.length > 0 && (this.middleTips.string = e);
        t.length > 0 ? m.getComponent(Label).string = t : m.getComponent(Label).string = i18nMgr.shared().getValueByKey("utlis.notice");
        i18nMgr.shared().changeLabelFont(m.getComponent(Label), true);
        null != s && (this._cb = s);
    }
    setCancleButtonWz(e) {
        this.alertBg.getChildByName("cancel").getChildByName("New Label").getComponent(Label).string = e;
    }
    setSureButtonWz(e) {
        this.alertBg.getChildByName("sure").getChildByName("New Label").getComponent(Label).string = e;
        this.alertBg.getChildByName("ok").getChildByName("New Label").getComponent(Label).string = e;
    }
    setSureButtonLableKey(e) {
        let t = this.alertBg.getChildByName("sure"), i = this.alertBg.getChildByName("ok");
        i.getChildByName("New Label").getComponent(Label).string = i18nMgr.shared().getValueByKey(e);
        t.getChildByName("New Label").getComponent(Label).string = i18nMgr.shared().getValueByKey(e);
        2 == i18nMgr.shared().language && "playDraw.play_now" == e && (t.getChildByName("New Label").getComponent(Label).fontSize = 40, i.getChildByName("New Label").getComponent(Label).fontSize = 40, t.getChildByName("New Label").getComponent(Label).lineHeight = 48, i.getChildByName("New Label").getComponent(Label).lineHeight = 48);
    }
    setCancleButtonLableKey(e) {
        this.alertBg.getChildByName("cancel").getChildByName("New Label").getComponent(Label).string = i18nMgr.shared().getValueByKey(e);
    }
    setContentHorizonAlign(e) {
        let t = this.alertBg.getChildByName("content").getComponent(Label);
        e && (t.horizontalAlign = e);
    }
    setContentVerticalAlign(e) {
        let t = this.alertBg.getChildByName("content").getComponent(Label);
        e && (t.verticalAlign = e);
    }
    setContentFontSize(e) {
        let t = this.alertBg.getChildByName("content").getComponent(Label);
        e && (t.fontSize = e);
    }
    startCountTime(e) {
        this.counttime = e;
        this.alertBg.getChildByName("cancel");
        this.alertBg.getChildByName("sure");
        this.counttime;
    }
    updateCountTime() {
        this.counttime = this.counttime - 1;
        this.alertBg.getChildByName("cancel");
        this.counttime <= 0 && this._cb && this._cb(3);
    }
    setKefuBtnVisible(e) {
        let t = this.alertBg.getChildByName("kefu");
        t && (t.active = e);
    }
    setTouchClose(e) {
        this._touchClose = e;
    }
    setTidKey(e) {
        this.bIsInGame = true;
        this.tid_key = e;
    }
    setCanback(e) {
        this._bCanBack = e;
    }
    setSceneType(e) {
        this._sceneType = e;
    }
    onBackView() {
        this._bCanBack && ToolUtils.isObjValid(this.node) && this.node.destroy();
    }
}
