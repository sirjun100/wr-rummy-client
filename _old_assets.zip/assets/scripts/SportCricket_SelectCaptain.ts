// @ts-nocheck
// Recovered from index.js:581
import { _decorator, Button, color, instantiate, Label, Node, size, sp, Sprite, SpriteFrame, sys, UIOpacity, UITransform, v3, view, Widget } from "cc";
import SoundManager from "./SoundManager";
import PushCenter from "./PushCenter";
import { TLog } from "./TLog";
import Utils from "./Utils";
import User from "./User";
import HttpManager from "./HttpManager";
import i18nMgr from "./i18nMgr";
import BaseLayer from "./BaseLayer";
import { HttpRequest } from "./HttpRequestName";
import GameConfig from "./GameConfig";
import PushEvent from "./PushEvent";
import CommDefine from "./CommDefine";
import TweenTool from "./TweenTool";
import SportCricket_Manager from "./SportCricket_Manager";
import { ToolUtils } from "./ToolUtils";
import PhpReportDefined from "./PhpReportDefined";
const { ccclass, property } = _decorator;
@ccclass("SportCricket_SelectCaptain")
export class SportCricket_SelectCaptain extends BaseLayer {
    public TAG: string = "SportCricket_SelectCaptain";
    @property(Node)
    public rootNode: Node = null;
    @property(Node)
    public goldNode: Node = null;
    @property(Node)
    public teamTopNode: Node = null;
    @property(Node)
    public topNode: Node = null;
    @property(Node)
    public nextNode: Node = null;
    @property(Node)
    public detailsNode: Node = null;
    @property(Node)
    public contentNode: Node = null;
    @property([SpriteFrame])
    public teamBgImgs: SpriteFrame[] = [];
    @property([SpriteFrame])
    public capBgImgs: SpriteFrame[] = [];
    @property([SpriteFrame])
    public btnBgImgs: SpriteFrame[] = [];
    @property([SpriteFrame])
    public sortArrowImgs: SpriteFrame[] = [];
    @property([SpriteFrame])
    public operateImgs: SpriteFrame[] = [];
    public leader_listData: any[] = [];
    @property(Node)
    public team_mobanView: Node = null;
    public _closed: boolean = false;
    public bShowPushAnim: boolean = true;
    public _lastClick: number = 0;
    public _sourceData: any = null;
    public _itemArr: any[] = [];
    public _isSendMsg: boolean = false;
    public curTab: number = 0;
    public tabWzColor: any[] = [color(183, 0, 0), color(84, 89, 155)];
    public taskAwardIconMap: Map = new Map;
    public _match_id: number = 0;
    public _contest_id: number = 0;
    public _contest_source: any = null;
    public _player_source: any = null;
    public _team_id: number = 0;
    public _source: any = null;
    public _selectPlayers: any = null;
    public lastClick: number = 0;
    public _teamSortType: number = 1;
    public _pointsSortType: number = 1;
    public _curSortType: number = 1;
    public _wkPlayMsgs: any[] = [];
    public _batPlayMsgs: any[] = [];
    public _arPlayMsgs: any[] = [];
    public _bowlPlayMsgs: any[] = [];
    public captainPoints: number = 0;
    public vCaptainPoints: number = 0;
    public captain_playerId: number = 0;
    public vcaptain_playerId: number = 0;
    public _fromType: number = 0;
    public _previewInfo: any = null;
    public _allPlayerMsg: Map = new Map;
    public _allPlayerView: any[] = [];
    public playerViewMap: Map = new Map;
    public _match_state: number = 1;
    public _lineup: number = 0;
    public _is_chip: number = 0;
    public sort_select_color: any = color(183, 0, 0);
    public _hasForceSignMatch: number = 0;
    onLoad() {
        PushCenter.shared().addListener(GameConfig.Update_Money, (e => {
            try {
                ToolUtils.isObjValid(this.node) && this.updateGold(e);
            }
            catch (e) {
                TLog.printError(this.TAG, GameConfig.Update_Money, e);
            }
        }), this);
        PushCenter.shared().addListener(PushEvent.commentDownloaderImg, (e => {
            try {
                if (ToolUtils.isObjValid(this.node) && this.taskAwardIconMap.size > 0) {
                    for (const [t, i] of this.taskAwardIconMap) {
                        i == e && sys.isObjectValid(t) && ("player_icon" == t.name ? Utils.shared().updateNetImage(t, e, size(110, 110)) : Utils.shared().updateNetImage(t, e, size(40, 40)));
                    }
                }
            }
            catch (e) {
                TLog.printError(this.TAG, PushEvent.commentDownloaderImg, e);
            }
        }), this);
        this.fitLuckyTheme();
    }
    fitLuckyTheme() {
        0 != GameConfig.NATIVE_GAME_APP_TYPE && (this.sort_select_color = color(38, 59, 152), this.tabWzColor = [color(38, 59, 152), color(84, 89, 155)], this.rootNode.getChildByName("top_node").getChildByName("top_bg").getComponent(Sprite).color = color(12, 26, 60, 255), this.goldNode.getChildByName("coin").getComponent(Label).color = color(251, 220, 0, 255));
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().removeListenersByTag(this);
        this.unscheduleAllCallbacks();
    }
    init(e) {
        sys.isObjectValid(e) && sys.isObjectValid(e.match_id) && (this._match_id = e.match_id);
        sys.isObjectValid(e) && sys.isObjectValid(e.player_source) && (this._player_source = e.player_source);
        sys.isObjectValid(e) && sys.isObjectValid(e.source) && (this._source = { ...e.source });
        sys.isObjectValid(e) && sys.isObjectValid(e.force) && (this._hasForceSignMatch = e.force);
        sys.isObjectValid(e) && sys.isObjectValid(e.selectPlayers) && (this._selectPlayers = e.selectPlayers);
        sys.isObjectValid(e) && sys.isObjectValid(e.fromType) && (this._fromType = e.fromType);
        sys.isObjectValid(e) && sys.isObjectValid(e.contest_id) && (this._contest_id = e.contest_id);
        sys.isObjectValid(e) && sys.isObjectValid(e.team_id) && (this._team_id = e.team_id);
        sys.isObjectValid(e) && sys.isObjectValid(e.previewInfo) && (this._previewInfo = e.previewInfo);
        sys.isObjectValid(e) && sys.isObjectValid(e.lineup) && (this._lineup = e.lineup);
        sys.isObjectValid(e) && sys.isObjectValid(e.is_chip) && (this._is_chip = e.is_chip);
    }
    start() {
        super.start();
        this.initView();
        this.bShowPushAnim && (ToolUtils.showPushAnim(this.node, 0, (() => {
        })), this.refreshView());
        this.updateGold(User.shared().data.money);
    }
    filterSelectPlayer() {
        if (this._allPlayerMsg.clear(), this._wkPlayMsgs = [], this._batPlayMsgs = [], this._arPlayMsgs = [], this._bowlPlayMsgs = [], sys.isObjectValid(this._player_source)) {
            if (sys.isObjectValid(this._player_source.captain_multi_num) && (this.captainPoints = this._player_source.captain_multi_num), sys.isObjectValid(this._player_source.assistant_captain_multi_num) && (this.vCaptainPoints = this._player_source.assistant_captain_multi_num), 1 == this._hasForceSignMatch) {
                let e = -1, t = 0;
                for (let i = 0; i < this._selectPlayers.length; i++) {
                    sys.isObjectValid(this._selectPlayers[i].captain_prob) && this._selectPlayers[i].captain_prob >= t && (e = i, t = this._selectPlayers[i].captain_prob);
                }
                this._selectPlayers[e].captain_role = 1;
                let i = -1;
                t = 0;
                for (let a = 0; a < this._selectPlayers.length; a++) {
                    sys.isObjectValid(this._selectPlayers[a].captain_prob) && this._selectPlayers[a].vic_captain_prob >= t && a != e && (i = a, t = this._selectPlayers[a].vic_captain_prob);
                }
                this._selectPlayers[i].captain_role = 2;
            }
            for (let e = 0; e < this._selectPlayers.length; e++) {
                "WK" == this._selectPlayers[e].role ? this._wkPlayMsgs.push(this._selectPlayers[e]) : "BAT" == this._selectPlayers[e].role ? this._batPlayMsgs.push(this._selectPlayers[e]) : "AR" == this._selectPlayers[e].role ? this._arPlayMsgs.push(this._selectPlayers[e]) : "BOWL" == this._selectPlayers[e].role && this._bowlPlayMsgs.push(this._selectPlayers[e]);
                1 == this._selectPlayers[e].captain_role ? this.captain_playerId = this._selectPlayers[e].player_id : 2 == this._selectPlayers[e].captain_role && (this.vcaptain_playerId = this._selectPlayers[e].player_id);
            }
            this.detailsNode.getChildByName("c_point").getComponent(Label).string = ToolUtils.format(i18nMgr.shared().getValueByKey("yes11.get_point"), this.captainPoints);
            this.detailsNode.getChildByName("vc_point").getComponent(Label).string = ToolUtils.format(i18nMgr.shared().getValueByKey("yes11.get_point"), this.vCaptainPoints);
            this.updateCaptainOrVcaptainInBoard();
        }
    }
    updateCaptainOrVcaptainInBoard() {
        let e = this.detailsNode.getChildByName("cap_node0");
        if (0 == this.captain_playerId) {
            e.getChildByName("bg").getComponent(Sprite).spriteFrame = this.capBgImgs[1];
            e.getChildByName("wz").getComponent(Label).color = color(51, 51, 51);
            e.getChildByName("wz").getComponent(Label).string = "Captain";
            e.getComponent(UIOpacity).opacity = 128;
        }
        else if (e.getComponent(UIOpacity).opacity = 255, sys.isObjectValid(this._selectPlayers)) {
            for (let t = 0; t < this._selectPlayers.length; t++) {
                if (this.captain_playerId == this._selectPlayers[t].player_id) {
                    this._selectPlayers[t].team_id == this._player_source.teama.tid ? (e.getChildByName("bg").getComponent(Sprite).spriteFrame = this.capBgImgs[0], e.getChildByName("wz").getComponent(Label).color = color(255, 255, 255)) : (e.getChildByName("bg").getComponent(Sprite).spriteFrame = this.capBgImgs[1], e.getChildByName("wz").getComponent(Label).color = color(51, 51, 51));
                    e.getChildByName("wz").getComponent(Label).string = "C: " + this._selectPlayers[t].short_name;
                    break;
                }
            }
        }
        let t = this.detailsNode.getChildByName("cap_node1");
        if (0 == this.vcaptain_playerId) {
            t.getChildByName("bg").getComponent(Sprite).spriteFrame = this.capBgImgs[1];
            t.getChildByName("wz").getComponent(Label).color = color(51, 51, 51);
            t.getChildByName("wz").getComponent(Label).string = "Vice-captain";
            t.getComponent(UIOpacity).opacity = 128;
        }
        else if (t.getComponent(UIOpacity).opacity = 255, sys.isObjectValid(this._selectPlayers)) {
            for (let e = 0; e < this._selectPlayers.length; e++) {
                if (this.vcaptain_playerId == this._selectPlayers[e].player_id) {
                    this._selectPlayers[e].team_id == this._player_source.teama.tid ? (t.getChildByName("bg").getComponent(Sprite).spriteFrame = this.capBgImgs[0], t.getChildByName("wz").getComponent(Label).color = color(255, 255, 255)) : (t.getChildByName("bg").getComponent(Sprite).spriteFrame = this.capBgImgs[1], t.getChildByName("wz").getComponent(Label).color = color(51, 51, 51));
                    t.getChildByName("wz").getComponent(Label).string = "VC: " + this._selectPlayers[e].short_name;
                    break;
                }
            }
        }
    }
    refreshView() {
        if (this.rootNode.getChildByName("nodata").active = false, this.curTab = 0, this.updateContestDetails(), this.reSortPlayerInfo(), 1 == this._hasForceSignMatch && 1 == User.shared().forceSignCricket) {
            this.rootNode.getChildByName("bottom_node").getChildByName("fingerNode").active = true;
            let e = this.rootNode.getChildByName("bottom_node").getChildByName("fingerNode").getComponent(sp.Skeleton);
            e.clearTracks();
            e.setToSetupPose();
            e.setAnimation(0, "click", true);
        }
    }
    updateSortView() {
        try {
            0 == this._curSortType ? (this.teamTopNode.getChildByName("team_sort").getChildByName("wz").getComponent(Label).color = this.sort_select_color, this.teamTopNode.getChildByName("team_sort").getChildByName("arrow").getComponent(Sprite).color = color(255, 255, 255), 1 == this._teamSortType ? this.teamTopNode.getChildByName("team_sort").getChildByName("arrow").getComponent(Sprite).spriteFrame = this.sortArrowImgs[2] : this.teamTopNode.getChildByName("team_sort").getChildByName("arrow").getComponent(Sprite).spriteFrame = this.sortArrowImgs[1], this.teamTopNode.getChildByName("point_sort").getChildByName("wz").getComponent(Label).color = color(102, 102, 102), this.teamTopNode.getChildByName("point_sort").getChildByName("arrow").getComponent(Sprite).color = color(102, 102, 102), this.teamTopNode.getChildByName("point_sort").getChildByName("arrow").getComponent(Sprite).spriteFrame = this.sortArrowImgs[0]) : 1 == this._curSortType && (this.teamTopNode.getChildByName("point_sort").getChildByName("wz").getComponent(Label).color = this.sort_select_color, this.teamTopNode.getChildByName("point_sort").getChildByName("arrow").getComponent(Sprite).color = color(255, 255, 255), 1 == this._pointsSortType ? this.teamTopNode.getChildByName("point_sort").getChildByName("arrow").getComponent(Sprite).spriteFrame = this.sortArrowImgs[2] : this.teamTopNode.getChildByName("point_sort").getChildByName("arrow").getComponent(Sprite).spriteFrame = this.sortArrowImgs[1], this.teamTopNode.getChildByName("team_sort").getChildByName("wz").getComponent(Label).color = color(102, 102, 102), this.teamTopNode.getChildByName("team_sort").getChildByName("arrow").getComponent(Sprite).color = color(102, 102, 102), this.teamTopNode.getChildByName("team_sort").getChildByName("arrow").getComponent(Sprite).spriteFrame = this.sortArrowImgs[0]);
        }
        catch (e) {
            TLog.printError(this.TAG, "updateSortView:", e);
        }
    }
    updateTopContestDetails() {
        if (!sys.isObjectValid(this._source)) {
            return;
        }
        let e = this._source.teama, t = this._source.teamb;
        sys.isObjectValid(e.short_name) && e.short_name.length > 0 && (this.topNode.getChildByName("team_short_name0").getComponent(Label).string = e.short_name);
        sys.isObjectValid(t.short_name) && t.short_name.length > 0 && (this.topNode.getChildByName("team_short_name1").getComponent(Label).string = t.short_name);
        sys.isObjectValid(e.logo_url) && e.logo_url.length > 0 && (this.taskAwardIconMap.set(this.topNode.getChildByName("team_icon0"), e.logo_url), Utils.shared().updateNetImage(this.topNode.getChildByName("team_icon0"), e.logo_url, size(76, 76)));
        sys.isObjectValid(t.logo_url) && t.logo_url.length > 0 && (this.taskAwardIconMap.set(this.topNode.getChildByName("team_icon1"), t.logo_url), Utils.shared().updateNetImage(this.topNode.getChildByName("team_icon1"), t.logo_url, size(76, 76)));
        sys.isObjectValid(this._source.location) && this._source.location.length > 0 && (this.topNode.getChildByName("location").getComponent(Label).string = this._source.location);
    }
    updateContestDetails() {
        sys.isObjectValid(this._player_source) && (this.filterSelectPlayer(), this.updateNextButtonStatus());
    }
    sortPlayerInfoByType() {
        0 == this._curSortType ? 0 == this._teamSortType ? (this._wkPlayMsgs.sort(((e, t) => e.team_id - t.team_id)), this._batPlayMsgs.sort(((e, t) => e.team_id - t.team_id)), this._arPlayMsgs.sort(((e, t) => e.team_id - t.team_id)), this._bowlPlayMsgs.sort(((e, t) => e.team_id - t.team_id))) : (this._wkPlayMsgs.sort(((e, t) => t.team_id - e.team_id)), this._batPlayMsgs.sort(((e, t) => t.team_id - e.team_id)), this._arPlayMsgs.sort(((e, t) => t.team_id - e.team_id)), this._bowlPlayMsgs.sort(((e, t) => t.team_id - e.team_id))) : 1 == this._curSortType && (0 == this._pointsSortType ? (this._wkPlayMsgs.sort(((e, t) => e.pts !== t.pts ? e.pts - t.pts : t.credits - e.credits)), this._batPlayMsgs.sort(((e, t) => e.pts !== t.pts ? e.pts - t.pts : t.credits - e.credits)), this._arPlayMsgs.sort(((e, t) => e.pts !== t.pts ? e.pts - t.pts : t.credits - e.credits)), this._bowlPlayMsgs.sort(((e, t) => e.pts !== t.pts ? e.pts - t.pts : t.credits - e.credits))) : (this._wkPlayMsgs.sort(((e, t) => e.pts !== t.pts ? t.pts - e.pts : t.credits - e.credits)), this._batPlayMsgs.sort(((e, t) => e.pts !== t.pts ? t.pts - e.pts : t.credits - e.credits)), this._arPlayMsgs.sort(((e, t) => e.pts !== t.pts ? t.pts - e.pts : t.credits - e.credits)), this._bowlPlayMsgs.sort(((e, t) => e.pts !== t.pts ? t.pts - e.pts : t.credits - e.credits))));
    }
    reSortPlayerInfo() {
        this.contentNode.getChildByName("wk_layout").removeAllChildren();
        this.contentNode.getChildByName("bat_layout").removeAllChildren();
        this.contentNode.getChildByName("ar_layout").removeAllChildren();
        this.contentNode.getChildByName("bowl_layout").removeAllChildren();
        this._allPlayerView = [];
        this.playerViewMap.clear();
        this.updateSortView();
        this.sortPlayerInfoByType();
        this.addPlayerView(this.contentNode.getChildByName("wk_layout"), this._wkPlayMsgs);
        this.addPlayerView(this.contentNode.getChildByName("bat_layout"), this._batPlayMsgs);
        this.addPlayerView(this.contentNode.getChildByName("ar_layout"), this._arPlayMsgs);
        this.addPlayerView(this.contentNode.getChildByName("bowl_layout"), this._bowlPlayMsgs);
    }
    addPlayerView(e, t) {
        for (let i = 0; i < t.length; i++) {
            let a = instantiate(this.team_mobanView);
            a.active = true;
            e.addChild(a);
            this._allPlayerView.push(a);
            let s = ToolUtils.toJsonString(t[i]);
            a.getChildByName("c_btn").getComponent(Button).clickEvents[0].customEventData = s;
            a.getChildByName("vc_btn").getComponent(Button).clickEvents[0].customEventData = s;
            a.getChildByName("player_btn").getComponent(Button).clickEvents[0].customEventData = s;
            this.playerViewMap.set(t[i].player_id, a);
            let o = false;
            Number(t[i].player_id) == Number(this.captain_playerId) && (a.getChildByName("bg").getComponent(Sprite).color = color(255, 247, 224), a.getChildByName("c_btn").getChildByName("ico").getComponent(Sprite).spriteFrame = this.operateImgs[1], a.getChildByName("c_btn").getChildByName("role").getComponent(Label).string = String(this.captainPoints) + "x", a.getChildByName("c_btn").getChildByName("role").getComponent(Label).color = color(255, 255, 255), o = true);
            t[i].player_id == this.vcaptain_playerId && (a.getChildByName("bg").getComponent(Sprite).color = color(255, 247, 224), a.getChildByName("vc_btn").getChildByName("ico").getComponent(Sprite).spriteFrame = this.operateImgs[1], a.getChildByName("vc_btn").getChildByName("role").getComponent(Label).string = String(this.vCaptainPoints) + "x", a.getChildByName("vc_btn").getChildByName("role").getComponent(Label).color = color(255, 255, 255), o = true);
            o || (a.getChildByName("bg").getComponent(Sprite).color = color(255, 255, 255), a.getChildByName("c_btn").getChildByName("ico").getComponent(Sprite).spriteFrame = this.operateImgs[0], a.getChildByName("c_btn").getChildByName("role").getComponent(Label).string = "C", a.getChildByName("c_btn").getChildByName("role").getComponent(Label).color = color(102, 102, 102), a.getChildByName("bg").getComponent(Sprite).color = color(255, 255, 255), a.getChildByName("vc_btn").getChildByName("ico").getComponent(Sprite).spriteFrame = this.operateImgs[0], a.getChildByName("vc_btn").getChildByName("role").getComponent(Label).string = "VC", a.getChildByName("vc_btn").getChildByName("role").getComponent(Label).color = color(102, 102, 102));
            a.getChildByName("team_bg").getChildByName("wz").getComponent(Label).string = t[i].team_abbr;
            a.getChildByName("team_bg").getChildByName("wz").getComponent(Label).updateRenderData(true);
            let r = a.getChildByName("team_bg").getChildByName("wz").getComponent(UITransform).width;
            r > 25 && (a.getChildByName("team_bg").getComponent(UITransform).contentSize = size(r + 10, 20));
            t[i].team_id == this._player_source.teama.tid ? (a.getChildByName("team_bg").getComponent(Sprite).spriteFrame = this.teamBgImgs[0], a.getChildByName("team_bg").getChildByName("wz").getComponent(Label).color = color(255, 255, 255)) : (a.getChildByName("team_bg").getComponent(Sprite).spriteFrame = this.teamBgImgs[1], a.getChildByName("team_bg").getChildByName("wz").getComponent(Label).color = color(51, 51, 51));
            sys.isObjectValid(t[i].thumb_url) && t[i].thumb_url.length > 0 && (this.taskAwardIconMap.set(a.getChildByName("player_icon"), t[i].thumb_url), Utils.shared().updateNetImage(a.getChildByName("player_icon"), t[i].thumb_url, size(110, 110)));
            sys.isObjectValid(t[i].pts) && (a.getChildByName("pts").getComponent(Label).string = ToolUtils.format(i18nMgr.shared().getValueByKey("yes11.p_pts"), t[i].pts));
            sys.isObjectValid(t[i].role) && (a.getChildByName("role").getComponent(Label).string = t[i].role);
            sys.isObjectValid(t[i].short_name) && (a.getChildByName("pname").getComponent(Label).string = String(t[i].short_name));
            let c = 0;
            0 == this._lineup && (c = -20);
            a.getChildByName("role").setPosition(v3(-190.153 + c, -74.462));
            "WK" == t[i].role || "AR" == t[i].role ? (a.getChildByName("pts").setPosition(v3(-136.677 + c, -74.462)), a.getChildByName("line").setPosition(v3(-148.636 + c, -75.703))) : "BAT" == t[i].role ? (a.getChildByName("pts").setPosition(v3(10 - 136.677 + c, -74.462)), a.getChildByName("line").setPosition(v3(-138.636 + c, -75.703))) : "BOWL" == t[i].role && (a.getChildByName("pts").setPosition(v3(25 - 136.677 + c, -74.462)), a.getChildByName("line").setPosition(v3(-123.636 + c, -75.703)));
            a.getChildByName("dot").active = 1 == this._lineup;
            1 == this._lineup && (1 == t[i].playing11 ? a.getChildByName("dot").getComponent(Label).color = color(0, 140, 22) : sys.isObjectValid(t[i].subplayer) && 1 == t[i].subplayer ? a.getChildByName("dot").getComponent(Label).color = color(56, 95, 223) : a.getChildByName("dot").getComponent(Label).color = color(215, 60, 69));
            sys.isObjectValid(t[i].captain_prob) ? a.getChildByName("rate0").getComponent(Label).string = t[i].captain_prob + "%" : a.getChildByName("rate0").getComponent(Label).string = "0%";
            sys.isObjectValid(t[i].vic_captain_prob) ? a.getChildByName("rate1").getComponent(Label).string = t[i].vic_captain_prob + "%" : a.getChildByName("rate1").getComponent(Label).string = "0%";
        }
    }
    updateGold(e) {
        let t = this.goldNode.getChildByName("coin");
        null != e && t && (t.getComponent(Label).string = ToolUtils.parse_double(e));
    }
    onSelectCaptainClick(e, t) {
        if (SoundManager.shared().playFx("click"), this._lastClick = sys.now(), 3 == this._match_state) {
            return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("yes11.live_tip"), 2);
        }
        if (4 == this._match_state) {
            return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("yes11.cancel_tip"), 2);
        }
        let i = ToolUtils.parseJson(t).player_id;
        this.captain_playerId != i && (this.vcaptain_playerId == i && (this.updateTargetPlayerViewStatus(0, this.vcaptain_playerId), this.vcaptain_playerId = 0), 0 != this.captain_playerId && this.updateTargetPlayerViewStatus(0, this.captain_playerId), this.updateTargetPlayerViewStatus(1, i), this.captain_playerId = i, this.updateCaptainOrVcaptainInBoard(), this.updateNextButtonStatus());
    }
    onSelectVcaptainClick(e, t) {
        if (SoundManager.shared().playFx("click"), sys.now() - this._lastClick < 500) {
            return;
        }
        if (this._lastClick = sys.now(), 3 == this._match_state) {
            return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("yes11.live_tip"), 2);
        }
        if (4 == this._match_state) {
            return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("yes11.cancel_tip"), 2);
        }
        let i = ToolUtils.parseJson(t).player_id;
        this.vcaptain_playerId != i && (this.captain_playerId == i && (this.updateTargetPlayerViewStatus(0, this.captain_playerId), this.captain_playerId = 0), 0 != this.vcaptain_playerId && this.updateTargetPlayerViewStatus(0, this.vcaptain_playerId), this.updateTargetPlayerViewStatus(2, i), this.vcaptain_playerId = i, this.updateCaptainOrVcaptainInBoard(), this.updateNextButtonStatus());
    }
    updateNextButtonStatus() {
        0 != this.captain_playerId && 0 != this.vcaptain_playerId ? (this.nextNode.getComponent(Sprite).spriteFrame = this.btnBgImgs[0], Utils.updateLabelMaterial(this.nextNode.getChildByName("wz"), CommDefine.gradient.btn_blue), this.nextNode.getComponent(Button).interactable = true) : (this.nextNode.getComponent(Sprite).spriteFrame = this.btnBgImgs[1], Utils.updateLabelMaterial(this.nextNode.getChildByName("wz"), CommDefine.gradient.btn_gray), this.nextNode.getComponent(Button).interactable = true);
    }
    dealCreateLogic() {
        let e = [], t = 0, i = [];
        for (let a = 0; a < this._selectPlayers.length; a++) {
            let s = { player_id: this._selectPlayers[a].player_id, tid: this._selectPlayers[a].team_id };
            1 == this._selectPlayers[a].playing11 && (t += 1);
            this._selectPlayers[a].player_id == this.captain_playerId ? (s.captain_role = 1, s.out_team_id = s.team_id, this._selectPlayers[a].captain_role = 1, this._selectPlayers[a].out_team_id = this._selectPlayers[a].team_id, i.push(this._selectPlayers[a])) : this._selectPlayers[a].player_id == this.vcaptain_playerId ? (s.captain_role = 2, s.out_team_id = s.team_id, this._selectPlayers[a].captain_role = 2, this._selectPlayers[a].out_team_id = this._selectPlayers[a].team_id, i.push(this._selectPlayers[a])) : s.captain_role = 0;
            e.push(s);
        }
        0 == this._lineup && (t = -1);
        let a = 0;
        1 == this._hasForceSignMatch && 1 == User.shared().forceSignCricket && (a = 1);
        let s = { match_id: this._match_id, members: ToolUtils.toJsonString(e), force: a }, o = HttpRequest.Yes11_CreateTeam;
        Utils.shared().showLoading(10, true, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
        }), ToolUtils.getIsNormalDirection());
        3 != this._fromType && 2 != this._fromType && 4 != this._fromType || 0 == this._team_id || (s.team_id = this._team_id, o = HttpRequest.Yes11_UpdateTeam, 4 == this._fromType && (s.origin_team_id = this._team_id, s.operate_type = 2, o = HttpRequest.Yes11_CreateTeam));
        HttpManager.shared().doGetCommonRequest(s, o, ((e, a, s) => {
            if (Utils.shared().hideLoading(), 200 != s) {
                Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.request_fail"), 2);
                ToolUtils.isObjValid(this.node) && (this._isSendMsg = false);
            }
            else {
                try {
                    let e = ToolUtils.parseJson(a);
                    if (0 == e.ret) {
                        if (sys.isObjectValid(e.data) && ToolUtils.isObjValid(this.node)) {
                            if (this._isSendMsg = false, 1 == this._fromType ? this.checkJoinGame(e.data.team_id) : 2 == this._fromType || 3 == this._fromType ? Utils.shared().showToast(i18nMgr.shared().getValueByKey("yes11.update_suc"), 2) : Utils.shared().showToast(i18nMgr.shared().getValueByKey("yes11.create_suc"), 2), PushCenter.shared().pushEvent(PushEvent.RefreshYes11TeamList), 3 != this._fromType && 2 != this._fromType || 0 == this._team_id) {
                                PushCenter.shared().pushEvent(PushEvent.CloseYes11CreateTeam);
                            }
                            else {
                                let e = { team_id: this._team_id, lineUpNum: t, teamInfo: { team_id: this._team_id, teama_num: this._previewInfo.teamAPnum, teamb_num: this._previewInfo.teamBPnum, teama_id: this._player_source.teama.tid, teamb_id: this._player_source.teamb.tid, members: i } };
                                PushCenter.shared().pushEvent(PushEvent.CloseYes11CreateTeam, e);
                            }
                            if (sys.isObjectValid(e.data.create_num)) {
                                SportCricket_Manager.shared().cricket_curTeamNum = e.data.create_num;
                                let t = { create_num: e.data.create_num, not_in_lineup: e.data.not_in_lineup };
                                PushCenter.shared().pushEvent(PushEvent.RefreshYesGameTeamNum, t);
                            }
                            ToolUtils.isObjValid(this.node) && this.node.destroy();
                        }
                    }
                    else {
                        sys.isObjectValid(e.desc) && e.desc.length > 0 && Utils.shared().showToast(e.desc, 2);
                    }
                }
                catch (e) {
                }
            }
        }));
    }
    checkJoinGame(e = 0) {
        let t = 0;
        1 == this._hasForceSignMatch && 1 == User.shared().forceSignCricket && (t = 1);
        let i = { session_id: this._contest_id, match_id: this._match_id, team_id: e, force: t };
        Utils.shared().showLoading(10, true, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
        }), ToolUtils.getIsNormalDirection());
        SportCricket_Manager.shared().requestYes11_PreJoinGameCheck(i, true, (e => {
            if (sys.isObjectValid(e) && sys.isObjectValid(e.code)) {
                if (308503 == e.code) {
                    e.team_name;
                    e.team_id;
                    e.fee;
                    let a = { match_id: i.match_id, contest_id: this._contest_id, assureInfo: e, force: t };
                    1 == this._is_chip && (a.assureInfo.is_chip = this._is_chip);
                    Utils.shared().showSportCricket_assureJoin(a);
                }
                else {
                    308501 == e.code && (sys.isObjectValid(this._is_chip) && 1 == this._is_chip ? Utils.shared().showQuickRechargeByYes11({ fee: e.fee, is_chip: 1 }) : Utils.shared().showQuickRechargeByYes11({ fee: e.fee }), User.shared().updatePayScene(PhpReportDefined.pay_scene.hall_cricket));
                }
            }
        }));
    }
    updateTargetPlayerViewStatus(e, t) {
        if (this.playerViewMap.has(t)) {
            let i = this.playerViewMap.get(t);
            sys.isObjectValid(i) && (0 == e ? (i.getChildByName("bg").getComponent(Sprite).color = color(255, 255, 255), i.getChildByName("c_btn").getChildByName("ico").getComponent(Sprite).spriteFrame = this.operateImgs[0], i.getChildByName("c_btn").getChildByName("role").getComponent(Label).string = "C", i.getChildByName("c_btn").getChildByName("role").getComponent(Label).color = color(102, 102, 102), i.getChildByName("vc_btn").getChildByName("ico").getComponent(Sprite).spriteFrame = this.operateImgs[0], i.getChildByName("vc_btn").getChildByName("role").getComponent(Label).string = "VC", i.getChildByName("vc_btn").getChildByName("role").getComponent(Label).color = color(102, 102, 102)) : 1 == e ? (i.getChildByName("bg").getComponent(Sprite).color = color(255, 247, 224), i.getChildByName("c_btn").getChildByName("ico").getComponent(Sprite).spriteFrame = this.operateImgs[1], i.getChildByName("c_btn").getChildByName("role").getComponent(Label).string = String(this.captainPoints) + "x", i.getChildByName("c_btn").getChildByName("role").getComponent(Label).color = color(255, 255, 255), i.getChildByName("vc_btn").getChildByName("ico").getComponent(Sprite).spriteFrame = this.operateImgs[0], i.getChildByName("vc_btn").getChildByName("role").getComponent(Label).string = "VC", i.getChildByName("vc_btn").getChildByName("role").getComponent(Label).color = color(102, 102, 102)) : 2 == e && (i.getChildByName("bg").getComponent(Sprite).color = color(255, 247, 224), i.getChildByName("c_btn").getChildByName("ico").getComponent(Sprite).spriteFrame = this.operateImgs[0], i.getChildByName("c_btn").getChildByName("role").getComponent(Label).string = "C", i.getChildByName("c_btn").getChildByName("role").getComponent(Label).color = color(102, 102, 102), i.getChildByName("vc_btn").getChildByName("ico").getComponent(Sprite).spriteFrame = this.operateImgs[1], i.getChildByName("vc_btn").getChildByName("role").getComponent(Label).string = String(this.vCaptainPoints) + "x", i.getChildByName("vc_btn").getChildByName("role").getComponent(Label).color = color(255, 255, 255)));
        }
    }
    onCloseButtonClick(e, t) {
        if (1 != this._hasForceSignMatch && (SoundManager.shared().playFx("click"), "back_btn" == t)) {
            if (this._closed) {
                return;
            }
            this.onBackView();
        }
    }
    initView() {
        if (this.fitScreen(), this.updateTopContestDetails(), sys.isObjectValid(this._source)) {
            this.rootNode.getChildByName("top_node").getChildByName("title").getComponent(Label).string = this._source.teama.short_name + " vs " + this._source.teamb.short_name;
            this.topNode.getChildByName("time_state").active = false;
            let e = this.rootNode.getChildByName("top_node").getChildByName("lefttime");
            sys.isObjectValid(this._source.status) && (this._match_state = this._source.status);
            let t = this.topNode.getChildByName("daybg"), i = this.topNode.getChildByName("hourbg"), a = this.topNode.getChildByName("minbg"), s = Utils.shared().parseTimeCount(this._source.time_left);
            t.getChildByName("time").getComponent(Label).string = s[0] > 9 ? String(s[0]) : "0" + String(s[0]);
            i.getChildByName("time").getComponent(Label).string = s[1] > 9 ? String(s[1]) : "0" + String(s[1]);
            a.getChildByName("time").getComponent(Label).string = s[2] > 9 ? String(s[2]) : "0" + String(s[2]);
            0 == this._source.time_left && 1 == this._source.status ? (e.getComponent(Label).string = this._source.start_day, sys.isObjectValid(this._source.is_current_day) && 1 == Number(this._source.is_current_day) && (this._source.status = 3, e.getComponent(Label).string = "Live", this.topNode.getChildByName("time_state").active = true, this.topNode.getChildByName("time_state").getComponent(Label).string = "Live", t.active = false, i.active = false, a.active = false)) : 1 == this._source.status ? TweenTool.myschedule(e, 1, (() => {
                if (ToolUtils.isObjValid(this.node)) {
                    if (this._source.time_left > 0) {
                        this._source.time_left = this._source.time_left - 1;
                        let e = Utils.shared().parseTimeCount(this._source.time_left);
                        t.getChildByName("time").getComponent(Label).string = e[0] > 9 ? String(e[0]) : "0" + String(e[0]);
                        i.getChildByName("time").getComponent(Label).string = e[1] > 9 ? String(e[1]) : "0" + String(e[1]);
                        a.getChildByName("time").getComponent(Label).string = e[2] > 9 ? String(e[2]) : "0" + String(e[2]);
                    }
                    else {
                        this._source.status = 3;
                        e.getComponent(Label).string = "Live";
                        TweenTool.stopNodeAction(e);
                        this.topNode.getChildByName("time_state").active = true;
                        this.topNode.getChildByName("time_state").getComponent(Label).string = "Live";
                        t.active = false;
                        i.active = false;
                        a.active = false;
                    }
                }
            })) : 3 == this._source.status ? (TweenTool.stopNodeAction(e), e.getComponent(Label).string = "Live", this.topNode.getChildByName("time_state").active = true, this.topNode.getChildByName("time_state").getComponent(Label).string = "Live", t.active = false, i.active = false, a.active = false) : 4 == this._source.status && (TweenTool.stopNodeAction(e), e.getComponent(Label).string = "Cancel", this.topNode.getChildByName("time_state").active = true, this.topNode.getChildByName("time_state").getComponent(Label).string = "Cancel", t.active = false, i.active = false, a.active = false);
            PushCenter.shared().addListener(PushEvent.UpdateYes11CurMatchLeftTime, (t => {
                try {
                    ToolUtils.isObjValid(this.node) && t.match_id == this._match_id && (this._source.time_left = t.time_left, this._source.is_current_day = t.is_current_day, this._match_state = t.status, 3 == t.status ? (TweenTool.stopNodeAction(e), e.getComponent(Label).string = "Live") : 4 == t.status && (TweenTool.stopNodeAction(e), e.getComponent(Label).string = "Cancel"));
                }
                catch (e) {
                    TLog.printError(this.TAG, PushEvent.UpdateYes11CurMatchLeftTime, e);
                }
            }), this);
        }
    }
    onButtonClick(e, t) {
        SoundManager.shared().playFx("click");
        sys.now() - this._lastClick < 500 || (this._lastClick = sys.now(), 3 != this._match_state ? 4 != this._match_state ? "save" == t ? 0 != this.captain_playerId && 0 != this.vcaptain_playerId ? this.dealCreateLogic() : Utils.shared().showToast(i18nMgr.shared().getValueByKey("yes11.create_tip"), 3, 0, ToolUtils.getIsNormalDirection()) : "team_sort" == t ? (0 != this._curSortType ? this._curSortType = 0 : 0 == this._teamSortType ? this._teamSortType = 1 : this._teamSortType = 0, this.reSortPlayerInfo()) : "pts_sort" == t ? (1 != this._curSortType ? this._curSortType = 1 : 0 == this._pointsSortType ? this._pointsSortType = 1 : this._pointsSortType = 0, this.reSortPlayerInfo()) : "preview" == t ? this.dealPreviewLogic() : "add_chip" == t && (Utils.shared().showStoreView(null, null), User.shared().updatePayScene(PhpReportDefined.pay_scene.hall_cricket)) : Utils.shared().showToast(i18nMgr.shared().getValueByKey("yes11.cancel_tip"), 2) : Utils.shared().showToast(i18nMgr.shared().getValueByKey("yes11.live_tip"), 2));
    }
    onPlayerInfoClick(e, t) {
        if (SoundManager.shared().playFx("click"), sys.now() - this._lastClick < 500) {
            return;
        }
        if (this._lastClick = sys.now(), 3 == this._match_state) {
            return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("yes11.live_tip"), 2);
        }
        if (4 == this._match_state) {
            return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("yes11.cancel_tip"), 2);
        }
        let i = ToolUtils.parseJson(t), a = { source: this._source, match_id: this._match_id, team_id: this._team_id, player_id: i.player_id, lastNode: this.node, select_status: 0, join_team: i.join_team, fromType: 4 };
        SportCricket_Manager.shared().requestYes11_PlayerInfo(a, true);
    }
    dealPreviewLogic() {
        if (sys.isObjectValid(this._previewInfo)) {
            if (this._previewInfo.wk_Players.length > 0) {
                for (let e = 0; e < this._previewInfo.wk_Players.length; e++) {
                    let t = this._previewInfo.wk_Players[e].player_id;
                    t == this.captain_playerId ? this._previewInfo.wk_Players[e].captain_role = 1 : t == this.vcaptain_playerId ? this._previewInfo.wk_Players[e].captain_role = 2 : this._previewInfo.wk_Players[e].captain_role = 0;
                }
            }
            if (this._previewInfo.bat_Players.length > 0) {
                for (let e = 0; e < this._previewInfo.bat_Players.length; e++) {
                    let t = this._previewInfo.bat_Players[e].player_id;
                    t == this.captain_playerId ? this._previewInfo.bat_Players[e].captain_role = 1 : t == this.vcaptain_playerId ? this._previewInfo.bat_Players[e].captain_role = 2 : this._previewInfo.bat_Players[e].captain_role = 0;
                }
            }
            if (this._previewInfo.ar_Players.length > 0) {
                for (let e = 0; e < this._previewInfo.ar_Players.length; e++) {
                    let t = this._previewInfo.ar_Players[e].player_id;
                    t == this.captain_playerId ? this._previewInfo.ar_Players[e].captain_role = 1 : t == this.vcaptain_playerId ? this._previewInfo.ar_Players[e].captain_role = 2 : this._previewInfo.ar_Players[e].captain_role = 0;
                }
            }
            if (this._previewInfo.bowl_Players.length > 0) {
                for (let e = 0; e < this._previewInfo.bowl_Players.length; e++) {
                    let t = this._previewInfo.bowl_Players[e].player_id;
                    t == this.captain_playerId ? this._previewInfo.bowl_Players[e].captain_role = 1 : t == this.vcaptain_playerId ? this._previewInfo.bowl_Players[e].captain_role = 2 : this._previewInfo.bowl_Players[e].captain_role = 0;
                }
            }
            this._previewInfo.lastNode = this.node;
            Utils.shared().showSportCricket_teamPreview(this._previewInfo);
        }
    }
    onBackView(e = true) {
        e && (Utils.shared().hideLoading(), this.bShowPushAnim ? (this._closed = true, ToolUtils.showPushAnim(this.node, 1, (() => {
            ToolUtils.isObjValid(this.node) && this.node.destroy();
        }))) : ToolUtils.isObjValid(this.node) && this.node.destroy());
    }
    fitScreen() {
        ToolUtils.adaptSafeArea(this.rootNode);
        let e = sys.getSafeAreaRect().y, t = view.getVisibleSize();
        if (this.node.getComponent(UITransform).setContentSize(t.width, t.height), 0 != e) {
            let t = this.rootNode.getChildByName("all_ScrollView").getComponent(Widget).bottom;
            this.rootNode.getChildByName("all_ScrollView").getComponent(Widget).bottom = t - e;
            t = this.rootNode.getChildByName("bottom_node").getComponent(Widget).bottom;
            this.rootNode.getChildByName("bottom_node").getComponent(Widget).bottom = t - e;
        }
    }
}
