// @ts-nocheck
// Recovered from index.js:577
import { _decorator, Button, color, instantiate, Label, Node, ScrollView, size, Sprite, SpriteFrame, sys, UITransform, v2, v3, Vec3, view, Widget } from "cc";
import SoundManager from "./SoundManager";
import PushCenter from "./PushCenter";
import { TLog } from "./TLog";
import Utils from "./Utils";
import User from "./User";
import BaseLayer from "./BaseLayer";
import { ToolUtils } from "./ToolUtils";
import SportCricket_Manager from "./SportCricket_Manager";
import PushEvent from "./PushEvent";
import GameConfig from "./GameConfig";
const { ccclass, property } = _decorator;
@ccclass("SportCricket_PlayerTeamCompare")
export class SportCricket_PlayerTeamCompare extends BaseLayer {
    public TAG: string = "SportCricket_PlayerTeamCompare";
    @property(Node)
    public rootNode: Node = null;
    @property(Node)
    public contentRootNode: Node = null;
    @property(Node)
    public boardRootNode: Node = null;
    @property(Node)
    public diffRootNode: Node = null;
    @property(Node)
    public commDiffRootNode: Node = null;
    @property(Node)
    public commRootNode: Node = null;
    @property(Node)
    public fitterRootNode: Node = null;
    @property(Node)
    public fitterMobanNode: Node = null;
    @property(Node)
    public playerMobanNode: Node = null;
    @property([SpriteFrame])
    public capBgImgs: SpriteFrame[] = [];
    @property(SpriteFrame)
    public noTeamListBgSp: SpriteFrame = null;
    public _closed: boolean = false;
    public bShowPushAnim: boolean = true;
    public _lastClick: number = 0;
    public _isSendMsg: boolean = false;
    public taskAwardIconMap: Map = new Map;
    public _match_id: number = 0;
    public _session_id: number = 0;
    public _myTeamId: number = 0;
    public _cmpTeamId: number = 0;
    public _source: any = null;
    public lastClick: number = 0;
    public _is_best: boolean = false;
    public _lastNode: any = null;
    public _hasInitFilter: boolean = false;
    public _call: any = null;
    public _compare_score: number = 0;
    public _other_score: number = 0;
    onLoad() {
        PushCenter.shared().addListener(PushEvent.commentDownloaderImg, (e => {
            try {
                if (ToolUtils.isObjValid(this.node) && this.taskAwardIconMap.size > 0) {
                    for (const [t, a] of this.taskAwardIconMap) {
                        a == e && sys.isObjectValid(t) && ("head_img" == t.name ? Utils.shared().updateNetImage(t, e, size(118, 118)) : Utils.shared().updateNetImage(t, e, size(54, 66)));
                    }
                }
            }
            catch (e) {
                TLog.printError(this.TAG, PushEvent.commentDownloaderImg, e);
            }
        }), this);
        PushCenter.shared().addListener(GameConfig.Update_Money, (e => {
            try {
                ToolUtils.isObjValid(this.node) && this.updateGold(e);
            }
            catch (e) {
                TLog.printError(this.TAG, GameConfig.Update_Money, e);
            }
        }), this);
        this.fitLuckyTheme();
    }
    fitLuckyTheme() {
        0 != GameConfig.NATIVE_GAME_APP_TYPE && (this.rootNode.getChildByName("top_node").getChildByName("top_bg").getComponent(Sprite).color = color(12, 26, 60, 255), this.rootNode.getChildByName("top_node").getChildByName("add_gold").getChildByName("coin").getComponent(Label).color = color(251, 220, 0, 255));
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().removeListenersByTag(this);
        this.unscheduleAllCallbacks();
    }
    init(e) {
        sys.isObjectValid(e) && sys.isObjectValid(e.match_id) && (this._match_id = e.match_id);
        sys.isObjectValid(e) && sys.isObjectValid(e.session_id) && (this._session_id = e.session_id);
        sys.isObjectValid(e) && sys.isObjectValid(e.my_teamId) && (this._myTeamId = e.my_teamId);
        sys.isObjectValid(e) && sys.isObjectValid(e.vs_teamId) && (this._cmpTeamId = e.vs_teamId);
        sys.isObjectValid(e) && sys.isObjectValid(e.is_best) && (this._is_best = e.is_best);
        sys.isObjectValid(e) && sys.isObjectValid(e.source) && (this._source = { ...e.source });
        sys.isObjectValid(e) && sys.isObjectValid(e.call) && (this._call = e.call);
        sys.isObjectValid(e) && sys.isObjectValid(e.lastNode) && (this._lastNode = e.lastNode);
    }
    start() {
        super.start();
        this.initView();
        this.bShowPushAnim && (ToolUtils.showPushAnim(this.node, 0, (() => {
            sys.isObjectValid(this._lastNode) && (this._lastNode.active = false);
            this.refreshView();
        })), this.refreshView_boardRoot());
    }
    updateGold(e) {
        let t = this.rootNode.getChildByName("top_node").getChildByName("add_gold").getChildByName("coin");
        null != e && t && (t.getComponent(Label).string = ToolUtils.parse_double(e));
    }
    onFilterItemBtnClick(e, t) {
        if (SoundManager.shared().playFx("click"), sys.now() - this._lastClick < 500) {
            return;
        }
        this._lastClick = sys.now();
        let a = ToolUtils.parseJson(t);
        this.fitterRootNode.active = false;
        sys.isObjectValid(a) && sys.isObjectValid(a.team_id) && SportCricket_Manager.shared().searchCompareTeamData(this._match_id, Number(a.team_id), this._cmpTeamId, this._session_id, true, (e => {
            this._source = e;
            this.refreshView_boardRoot();
            this.refreshView();
        }));
    }
    refreshView() {
        this.refreshView_diffRoot();
        let e = this.refreshView_commdiffCapRoot(), t = this.refreshView_commRoot();
        this._hasInitFilter = false;
        e || t || (this.diffRootNode.getChildByName("fenge").active = false);
    }
    updatePlayerItemView(e, t, a) {
        0 == a ? (sys.isObjectValid(t.compare_thumb_url) && t.compare_thumb_url.length > 0 && (this.taskAwardIconMap.set(e.getChildByName("player_moban0").getChildByName("player_icon"), t.compare_thumb_url), Utils.shared().updateNetImage(e.getChildByName("player_moban0").getChildByName("player_icon"), t.compare_thumb_url, size(54, 66))), sys.isObjectValid(t.compare_short_name) && t.compare_short_name.length > 0 && (e.getChildByName("player_moban0").getChildByName("pname").getComponent(Label).string = ToolUtils.GetShortName2(String(t.compare_short_name), 13, false)), sys.isObjectValid(t.other_thumb_url) && t.other_thumb_url.length > 0 && (this.taskAwardIconMap.set(e.getChildByName("player_moban1").getChildByName("player_icon"), t.other_thumb_url), Utils.shared().updateNetImage(e.getChildByName("player_moban1").getChildByName("player_icon"), t.other_thumb_url, size(54, 66))), sys.isObjectValid(t.other_short_name) && t.other_short_name.length > 0 && (e.getChildByName("player_moban1").getChildByName("pname").getComponent(Label).string = ToolUtils.GetShortName2(String(t.other_short_name), 13, false)), sys.isObjectValid(t.compare_team_short_name) && sys.isObjectValid(t.compare_role) && (e.getChildByName("player_moban0").getChildByName("desc").getComponent(Label).string = ToolUtils.isSafeString(t.compare_team_short_name) + "-" + ToolUtils.isSafeString(t.compare_role)), sys.isObjectValid(t.other_team_short_name) && sys.isObjectValid(t.other_role) && (e.getChildByName("player_moban1").getChildByName("desc").getComponent(Label).string = ToolUtils.isSafeString(t.other_team_short_name) + "-" + ToolUtils.isSafeString(t.other_role))) : 1 != a && 2 != a || (sys.isObjectValid(t.thumb_url) && t.thumb_url.length > 0 && (this.taskAwardIconMap.set(e.getChildByName("player_moban0").getChildByName("player_icon"), t.thumb_url), Utils.shared().updateNetImage(e.getChildByName("player_moban0").getChildByName("player_icon"), t.thumb_url, size(54, 66)), this.taskAwardIconMap.set(e.getChildByName("player_moban1").getChildByName("player_icon"), t.thumb_url), Utils.shared().updateNetImage(e.getChildByName("player_moban1").getChildByName("player_icon"), t.thumb_url, size(54, 66))), sys.isObjectValid(t.short_name) && t.short_name.length > 0 && (e.getChildByName("player_moban0").getChildByName("pname").getComponent(Label).string = ToolUtils.GetShortName2(String(t.short_name), 13, false), e.getChildByName("player_moban1").getChildByName("pname").getComponent(Label).string = ToolUtils.GetShortName2(String(t.short_name), 13, false)), sys.isObjectValid(t.team_name) && sys.isObjectValid(t.role) && (e.getChildByName("player_moban0").getChildByName("desc").getComponent(Label).string = ToolUtils.isSafeString(t.team_name) + "-" + ToolUtils.isSafeString(t.role), e.getChildByName("player_moban1").getChildByName("desc").getComponent(Label).string = ToolUtils.isSafeString(t.team_name) + "-" + ToolUtils.isSafeString(t.role)));
        0 == a || 1 == a ? (sys.isObjectValid(t.compare_point) && (this._compare_score += Number(t.compare_point), e.getChildByName("player_moban0").getChildByName("pts").getComponent(Label).string = String(t.compare_point)), sys.isObjectValid(t.compare_point_data) && (e.getChildByName("player_moban0").getChildByName("pts_desc").getComponent(Label).string = ToolUtils.isSafeString(t.compare_point_data), e.getChildByName("player_moban0").getChildByName("pts_desc").active = true), sys.isObjectValid(t.other_point) && (this._other_score += Number(t.other_point), e.getChildByName("player_moban1").getChildByName("pts").getComponent(Label).string = String(t.other_point)), sys.isObjectValid(t.other_point_data) && (e.getChildByName("player_moban1").getChildByName("pts_desc").getComponent(Label).string = ToolUtils.isSafeString(t.other_point_data), e.getChildByName("player_moban1").getChildByName("pts_desc").active = true), sys.isObjectValid(t.compare_captain_role) ? 1 == Number(t.compare_captain_role) ? (e.getChildByName("player_moban0").getChildByName("captain_node").active = true, 0 == a && t.compare_team_short_name == this._source.teama_name || 1 == a && t.team_name == this._source.teama_name ? (e.getChildByName("player_moban0").getChildByName("captain_node").getComponent(Sprite).spriteFrame = this.capBgImgs[0], e.getChildByName("player_moban0").getChildByName("captain_node").getChildByName("wz").getComponent(Label).color = color(255, 255, 255)) : (e.getChildByName("player_moban0").getChildByName("captain_node").getComponent(Sprite).spriteFrame = this.capBgImgs[1], e.getChildByName("player_moban0").getChildByName("captain_node").getChildByName("wz").getComponent(Label).color = color(0, 0, 0)), e.getChildByName("player_moban0").getChildByName("captain_node").getChildByName("wz").getComponent(Label).string = "C") : 2 == Number(t.compare_captain_role) && (e.getChildByName("player_moban0").getChildByName("captain_node").active = true, t.compare_team_short_name == this._source.teama_name || 1 == a && t.team_name == this._source.teama_name ? (e.getChildByName("player_moban0").getChildByName("captain_node").getComponent(Sprite).spriteFrame = this.capBgImgs[0], e.getChildByName("player_moban0").getChildByName("captain_node").getChildByName("wz").getComponent(Label).color = color(255, 255, 255)) : (e.getChildByName("player_moban0").getChildByName("captain_node").getComponent(Sprite).spriteFrame = this.capBgImgs[1], e.getChildByName("player_moban0").getChildByName("captain_node").getChildByName("wz").getComponent(Label).color = color(0, 0, 0)), e.getChildByName("player_moban0").getChildByName("captain_node").getChildByName("wz").getComponent(Label).string = "VC") : e.getChildByName("player_moban0").getChildByName("captain_node").active = false, sys.isObjectValid(t.other_captain_role) ? 1 == Number(t.other_captain_role) ? (e.getChildByName("player_moban1").getChildByName("captain_node").active = true, t.other_team_short_name == this._source.teama_name || 1 == a && t.team_name == this._source.teama_name ? (e.getChildByName("player_moban1").getChildByName("captain_node").getComponent(Sprite).spriteFrame = this.capBgImgs[0], e.getChildByName("player_moban1").getChildByName("captain_node").getChildByName("wz").getComponent(Label).color = color(255, 255, 255)) : (e.getChildByName("player_moban1").getChildByName("captain_node").getComponent(Sprite).spriteFrame = this.capBgImgs[1], e.getChildByName("player_moban1").getChildByName("captain_node").getChildByName("wz").getComponent(Label).color = color(0, 0, 0)), e.getChildByName("player_moban1").getChildByName("captain_node").getChildByName("wz").getComponent(Label).string = "C") : 2 == Number(t.other_captain_role) && (e.getChildByName("player_moban1").getChildByName("captain_node").active = true, t.other_team_short_name == this._source.teama_name || 1 == a && t.team_name == this._source.teama_name ? (e.getChildByName("player_moban1").getChildByName("captain_node").getComponent(Sprite).spriteFrame = this.capBgImgs[0], e.getChildByName("player_moban1").getChildByName("captain_node").getChildByName("wz").getComponent(Label).color = color(255, 255, 255)) : (e.getChildByName("player_moban1").getChildByName("captain_node").getComponent(Sprite).spriteFrame = this.capBgImgs[1], e.getChildByName("player_moban1").getChildByName("captain_node").getChildByName("wz").getComponent(Label).color = color(0, 0, 0)), e.getChildByName("player_moban1").getChildByName("captain_node").getChildByName("wz").getComponent(Label).string = "VC") : e.getChildByName("player_moban1").getChildByName("captain_node").active = false) : (sys.isObjectValid(t.point) && (this._compare_score += Number(t.point), e.getChildByName("player_moban0").getChildByName("pts").active = false, e.getChildByName("player_moban1").getChildByName("pts").active = false, e.getChildByName("com_pts").getComponent(Label).string = String(t.point), e.getChildByName("com_pts").active = true), sys.isObjectValid(t.point_data) && (e.getChildByName("com_desc").getComponent(Label).string = ToolUtils.isSafeString(t.point_data), e.getChildByName("com_desc").active = true), sys.isObjectValid(t.captain_role) ? 1 == Number(t.captain_role) ? (e.getChildByName("player_moban1").getChildByName("captain_node").active = true, t.team_name == this._source.teama_name ? (e.getChildByName("player_moban1").getChildByName("captain_node").getComponent(Sprite).spriteFrame = this.capBgImgs[0], e.getChildByName("player_moban1").getChildByName("captain_node").getChildByName("wz").getComponent(Label).color = color(255, 255, 255), e.getChildByName("player_moban0").getChildByName("captain_node").getComponent(Sprite).spriteFrame = this.capBgImgs[0], e.getChildByName("player_moban0").getChildByName("captain_node").getChildByName("wz").getComponent(Label).color = color(255, 255, 255)) : (e.getChildByName("player_moban1").getChildByName("captain_node").getComponent(Sprite).spriteFrame = this.capBgImgs[1], e.getChildByName("player_moban1").getChildByName("captain_node").getChildByName("wz").getComponent(Label).color = color(0, 0, 0), e.getChildByName("player_moban0").getChildByName("captain_node").getComponent(Sprite).spriteFrame = this.capBgImgs[1], e.getChildByName("player_moban0").getChildByName("captain_node").getChildByName("wz").getComponent(Label).color = color(0, 0, 0)), e.getChildByName("player_moban1").getChildByName("captain_node").getChildByName("wz").getComponent(Label).string = "C", e.getChildByName("player_moban0").getChildByName("captain_node").active = true, e.getChildByName("player_moban0").getChildByName("captain_node").getChildByName("wz").getComponent(Label).string = "C") : 2 == Number(t.captain_role) && (e.getChildByName("player_moban1").getChildByName("captain_node").active = true, t.team_name == this._source.teama_name ? (e.getChildByName("player_moban1").getChildByName("captain_node").getComponent(Sprite).spriteFrame = this.capBgImgs[0], e.getChildByName("player_moban1").getChildByName("captain_node").getChildByName("wz").getComponent(Label).color = color(255, 255, 255), e.getChildByName("player_moban0").getChildByName("captain_node").getComponent(Sprite).spriteFrame = this.capBgImgs[0], e.getChildByName("player_moban0").getChildByName("captain_node").getChildByName("wz").getComponent(Label).color = color(255, 255, 255)) : (e.getChildByName("player_moban1").getChildByName("captain_node").getComponent(Sprite).spriteFrame = this.capBgImgs[1], e.getChildByName("player_moban1").getChildByName("captain_node").getChildByName("wz").getComponent(Label).color = color(0, 0, 0), e.getChildByName("player_moban0").getChildByName("captain_node").getComponent(Sprite).spriteFrame = this.capBgImgs[1], e.getChildByName("player_moban0").getChildByName("captain_node").getChildByName("wz").getComponent(Label).color = color(0, 0, 0)), e.getChildByName("player_moban1").getChildByName("captain_node").getChildByName("wz").getComponent(Label).string = "VC", e.getChildByName("player_moban0").getChildByName("captain_node").active = true, e.getChildByName("player_moban0").getChildByName("captain_node").getChildByName("wz").getComponent(Label).string = "VC") : (e.getChildByName("player_moban1").getChildByName("captain_node").active = false, e.getChildByName("player_moban0").getChildByName("captain_node").active = false), e.getChildByName("line").active = false);
    }
    refreshView_diffRoot() {
        if (sys.isObjectValid(this._source) && sys.isObjectValid(this._source.different_players) && this._source.different_players.length > 0) {
            let e = this._source.different_players;
            this.diffRootNode.active = true;
            this.diffRootNode.getChildByName("player_root").removeAllChildren();
            this._compare_score = 0;
            this._other_score = 0;
            for (let t = 0; t < e.length; t++) {
                let a = instantiate(this.playerMobanNode);
                a.active = true;
                this.diffRootNode.getChildByName("player_root").addChild(a);
                this.updatePlayerItemView(a, e[t], 0);
            }
            let t = this.diffRootNode.getChildByName("diff_title_node").getChildByName("title_node");
            return t.getChildByName("pts").active = true, t.getChildByName("wz1").active = true, this._compare_score > this._other_score ? (t.getChildByName("wz0").getComponent(Label).string = "Your players scored", t.getChildByName("pts").getComponent(Label).color = color(0, 140, 22), t.getChildByName("pts").getComponent(Label).string = String(this._compare_score - this._other_score) + " pts") : this._compare_score == this._other_score ? (t.getChildByName("wz0").getComponent(Label).string = String(this._compare_score) + " pts", t.getChildByName("pts").active = false, t.getChildByName("wz1").active = false) : (t.getChildByName("pts").getComponent(Label).color = color(215, 60, 69), this._is_best ? t.getChildByName("wz0").getComponent(Label).string = "Best team's players scored" : t.getChildByName("wz0").getComponent(Label).string = "Your opponent's players scored", t.getChildByName("pts").getComponent(Label).string = String(this._other_score - this._compare_score) + " pts"), true;
        }
        return this.diffRootNode.active = false, false;
    }
    refreshView_commdiffCapRoot() {
        if (sys.isObjectValid(this._source) && sys.isObjectValid(this._source.different_caps) && this._source.different_caps.length > 0) {
            let e = this._source.different_caps;
            this.commDiffRootNode.active = true;
            this.commDiffRootNode.getChildByName("player_root").removeAllChildren();
            this._compare_score = 0;
            this._other_score = 0;
            for (let t = 0; t < e.length; t++) {
                let a = instantiate(this.playerMobanNode);
                a.active = true;
                this.commDiffRootNode.getChildByName("player_root").addChild(a);
                this.updatePlayerItemView(a, e[t], 1);
            }
            let t = this.commDiffRootNode.getChildByName("diff_title_node").getChildByName("title_node");
            return t.getChildByName("pts").active = true, t.getChildByName("wz1").active = true, this._compare_score > this._other_score ? (t.getChildByName("wz0").getComponent(Label).string = "Your players scored", t.getChildByName("pts").getComponent(Label).color = color(0, 140, 22), t.getChildByName("pts").getComponent(Label).string = String(this._compare_score - this._other_score) + " pts") : this._compare_score == this._other_score ? (t.getChildByName("wz0").getComponent(Label).string = String(this._compare_score) + " pts", t.getChildByName("pts").active = false, t.getChildByName("wz1").active = false) : (t.getChildByName("pts").getComponent(Label).color = color(215, 60, 69), this._is_best ? t.getChildByName("wz0").getComponent(Label).string = "Best team's players scored" : t.getChildByName("wz0").getComponent(Label).string = "Your opponent's players scored", t.getChildByName("pts").getComponent(Label).string = String(this._other_score - this._compare_score) + " pts"), true;
        }
        return this.commDiffRootNode.active = false, false;
    }
    refreshView_commRoot() {
        if (sys.isObjectValid(this._source) && sys.isObjectValid(this._source.common_players) && this._source.common_players.length > 0) {
            let e = this._source.common_players;
            this.commRootNode.active = true;
            this.commRootNode.getChildByName("player_root").removeAllChildren();
            this._compare_score = 0;
            this._other_score = 0;
            for (let t = 0; t < e.length; t++) {
                let a = instantiate(this.playerMobanNode);
                a.active = true;
                this.commRootNode.getChildByName("player_root").addChild(a);
                this.updatePlayerItemView(a, e[t], 2);
            }
            return this.commRootNode.getChildByName("diff_title_node").getChildByName("pts").getComponent(Label).string = String(this._compare_score) + " pts", true;
        }
        return this.commRootNode.active = false, false;
    }
    refreshView_boardRoot() {
        if (sys.isObjectValid(this._source) && sys.isObjectValid(this._source.compare_info) && sys.isObjectValid(this._source.other_info)) {
            let e = this._source.compare_info, t = this._source.other_info;
            Utils.shared().updateHeadImg(this.boardRootNode.getChildByName("head_mask0").getChildByName("head_img"), User.shared().data.avatar, User.shared().data.avatar_url, size(118, 118));
            this.boardRootNode.getChildByName("name0").getComponent(Label).string = ToolUtils.GetShortName2(User.shared().data.name, 13, false);
            sys.isObjectValid(e.team_name) && (this.boardRootNode.getChildByName("filterBtn").getChildByName("wz").getComponent(Label).string = e.team_name);
            sys.isObjectValid(this._source.teams) && Array.isArray(this._source.teams) && this._source.teams.length > 1 || (this.boardRootNode.getChildByName("filterBtn").getComponent(Button).interactable = false, this.boardRootNode.getChildByName("filterBtn").getChildByName("wz").getComponent(UITransform).anchorPoint = v2(0.5, 0.5), this.boardRootNode.getChildByName("filterBtn").getChildByName("wz").setPosition(v3(0, 0)), this.boardRootNode.getChildByName("filterBtn").getChildByName("arrow").active = false, this.boardRootNode.getChildByName("filterBtn").getComponent(Sprite).spriteFrame = this.noTeamListBgSp, this.boardRootNode.getChildByName("filterBtn").getComponent(Sprite).color = color(230, 230, 230));
            sys.isObjectValid(e.team_id) && (this._myTeamId = Number(e.team_id));
            sys.isObjectValid(t.team_id) && (this._cmpTeamId = Number(t.team_id));
            let a = 0, i = 0;
            sys.isObjectValid(e.point) && (a = Number(e.point));
            sys.isObjectValid(t.point) && (i = Number(t.point));
            this.boardRootNode.getChildByName("pts_value0").getComponent(Label).string = String(a);
            this.boardRootNode.getChildByName("pts_value1").getComponent(Label).string = String(i);
            this.boardRootNode.getChildByName("title_node").getChildByName("pts").active = true;
            a > i ? (this.boardRootNode.getChildByName("title_node").getChildByName("wz").getComponent(Label).string = "You won by", this.boardRootNode.getChildByName("title_node").getChildByName("pts").getComponent(Label).color = color(0, 140, 22), this.boardRootNode.getChildByName("title_node").getChildByName("pts").getComponent(Label).string = String(a - i) + " pts") : a == i ? (this.boardRootNode.getChildByName("title_node").getChildByName("wz").getComponent(Label).string = "You have the same pts", this.boardRootNode.getChildByName("title_node").getChildByName("pts").active = false) : (this.boardRootNode.getChildByName("title_node").getChildByName("pts").getComponent(Label).color = color(215, 60, 69), this._is_best ? this.boardRootNode.getChildByName("title_node").getChildByName("wz").getComponent(Label).string = "You were behind by" : this.boardRootNode.getChildByName("title_node").getChildByName("wz").getComponent(Label).string = "Your opponent won by", this.boardRootNode.getChildByName("title_node").getChildByName("pts").getComponent(Label).string = String(i - a) + " pts");
            sys.isObjectValid(e.rank) && (this._is_best ? this.boardRootNode.getChildByName("rank_value").getComponent(Label).string = e.rank + " / --" : this.boardRootNode.getChildByName("rank_value").getComponent(Label).string = e.rank + " / " + t.rank);
            this.boardRootNode.getChildByName("head_best").active = this._is_best;
            this._is_best ? (this.boardRootNode.getChildByName("head_kuang1").active = false, this.boardRootNode.getChildByName("head_mask1").active = false, this.boardRootNode.getChildByName("name1").getComponent(Label).string = "Best team", this.boardRootNode.getChildByName("team_name1").active = false) : (this.boardRootNode.getChildByName("team_name1").active = true, sys.isObjectValid(t.avatar) && sys.isObjectValid(t.avatar_url) && Utils.shared().updateHeadImg(this.boardRootNode.getChildByName("head_mask1").getChildByName("head_img"), t.avatar, t.avatar_url, size(118, 118)), sys.isObjectValid(t.name) && (this.boardRootNode.getChildByName("name1").getComponent(Label).string = ToolUtils.GetShortName2(t.name, 13, false)), sys.isObjectValid(t.team_name) && (this.boardRootNode.getChildByName("team_name1").getChildByName("wz").getComponent(Label).string = t.team_name));
        }
    }
    onCloseButtonClick(e, t) {
        if (SoundManager.shared().playFx("click"), "back_btn" == t) {
            if (this._closed) {
                return;
            }
            this.onBackView();
        }
    }
    initView() {
        this.updateGold(User.shared().data.money);
        this.fitScreen();
    }
    onButtonClick(e, t) {
        if (SoundManager.shared().playFx("click"), !(sys.now() - this._lastClick < 500)) {
            if (this._lastClick = sys.now(), "close_filter" == t) {
                this.fitterRootNode.active = false;
            }
            else if ("show_filter" == t) {
                this.fitterRootNode.active = true;
                let e = new Vec3;
                this.boardRootNode.getChildByName("filterBtn").getWorldPosition(e);
                let t = v3();
                this.fitterRootNode.inverseTransformPoint(t, e);
                this.fitterRootNode.getChildByName("filterList").setPosition(v3(t.x, t.y - 20));
                this.fitterRootNode.getChildByName("filterList").getComponent(ScrollView).scrollToTop(0);
                this._hasInitFilter || this.refreshTeamFilterView();
            }
            else {
                "add_chip" == t && Utils.shared().showStoreView(null, null);
            }
        }
    }
    refreshTeamFilterView() {
        if (this._hasInitFilter = true, sys.isObjectValid(this._source.teams)) {
            this.fitterRootNode.getChildByName("filterList").getComponent(ScrollView).content.removeAllChildren();
            for (let e = 0; e < this._source.teams.length; e++) {
                let t = this._source.teams[e];
                if (Number(t.team_id) != this._myTeamId) {
                    let e = instantiate(this.fitterMobanNode);
                    e.active = true;
                    this.fitterRootNode.getChildByName("filterList").getComponent(ScrollView).content.addChild(e);
                    e.getChildByName("wz").getComponent(Label).string = t.name;
                    e.getComponent(Button).clickEvents[0].customEventData = ToolUtils.toJsonString(t);
                }
            }
        }
    }
    onBackView(e = true) {
        e && (Utils.shared().hideLoading(), this.bShowPushAnim ? (this._closed = true, ToolUtils.isObjValid(this._lastNode) && (this._lastNode.active = true), ToolUtils.showPushAnim(this.node, 1, (() => {
            ToolUtils.isObjValid(this.node) && this.node.destroy();
        }))) : (ToolUtils.isObjValid(this._lastNode) && (this._lastNode.active = true), ToolUtils.isObjValid(this.node) && this.node.destroy()));
    }
    fitScreen() {
        ToolUtils.adaptSafeArea(this.rootNode);
        let e = sys.getSafeAreaRect().y, t = view.getVisibleSize();
        if (this.node.getComponent(UITransform).setContentSize(t.width, t.height), 0 != e) {
            let t = this.rootNode.getComponent(Widget).bottom;
            this.rootNode.getComponent(Widget).bottom = t - e;
        }
    }
}
