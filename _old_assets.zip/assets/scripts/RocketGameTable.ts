// @ts-nocheck
// Recovered from index.js:407
import { _decorator, instantiate, Label, Node, size, sp, Sprite, SpriteFrame, sys, tween, UITransform, v3 } from "cc";
import Parent from "./Parent";
import PushCenter from "./PushCenter";
import TweenTool from "./TweenTool";
import SoundManager from "./SoundManager";
import { ToolUtils } from "./ToolUtils";
import { RocketGameManager } from "./RocketGameManager";
import Utils from "./Utils";
const { ccclass, property } = _decorator;
@ccclass("RocketGameTable")
export default class RocketGameTable extends Parent {
    public _TAG: string = "RocketGameTable";
    @property(Node)
    public trend_moban: Node = null;
    @property(Node)
    public waite_layout: Node = null;
    @property(Node)
    public route_layout: Node = null;
    @property(Node)
    public bg_anim_node: Node = null;
    @property(Node)
    public lightView: Node = null;
    @property(Node)
    public rocketWaiteAnim: Node = null;
    @property(Node)
    public xzhouImage: Node = null;
    @property(Node)
    public yzhouImage: Node = null;
    @property(Node)
    public bl_content: Node = null;
    @property(Node)
    public time_content: Node = null;
    @property(Node)
    public trendList: Node = null;
    @property(Node)
    public fly_layout: Node = null;
    @property(Node)
    public cashout_node: Node = null;
    @property(Node)
    public rocket_node: Node = null;
    @property(Node)
    public cashPlayer: Node = null;
    @property(Node)
    public gj_node: Node = null;
    @property(Node)
    public bz_dian: Node = null;
    @property(Sprite)
    public barSprite: Sprite = null;
    @property(Label)
    public waitTimeLabel: Label = null;
    @property(sp.Skeleton)
    public rocketAnim: any = null;
    @property(sp.Skeleton)
    public rocketBzAnim: any = null;
    @property(sp.Skeleton)
    public liuxingAnim: any = null;
    @property(sp.Skeleton)
    public xingqiuAnim: any = null;
    @property(Node)
    public jackpotPool: Node = null;
    @property(Node)
    public xiazhuRoot: Node = null;
    @property(Node)
    public xiazhuMoban: Node = null;
    @property([SpriteFrame])
    public bigBeilvImgs: SpriteFrame[] = [];
    @property([SpriteFrame])
    public smallBeilvImgs: SpriteFrame[] = [];
    public gameCallback: any = null;
    public x_zhou_width: number = 1142;
    public y_zhou_height: number = 384;
    public time_space: number = 201;
    public bl_space: number = 64;
    public gj_MaxWidth: number = 1046;
    public gj_Maxheight: number = 328;
    public x_speed: number = 100.5;
    public fly_interval: number = 0.05;
    public rocket_end_roation: any = -29.277;
    public waite_interval: number = 1;
    public jindu_interval: number = 0.1;
    public rocket_start_pos: any = v3(0, 0);
    public lastClick: number = 0;
    public gameData: any = {};
    public updateBlCall: any = null;
    onLoad() {
        this.gameData = {};
    }
    start() {
        this.initView();
    }
    initView() {
        this.trend_moban.active = false;
        this.initWaiteLayout();
        this.gameData.rocketAnimIndex = 1;
        this.jackpotPool.getChildByName("num").getComponent(Label).string = "0";
        this.initBgAnim();
        this.initRocketWaiteAnim();
        this.initRouteLayout();
        this.initFlyLayout();
        this.addPushNotify();
        this.changeXiaZhuRootState(false);
    }
    updateJackPotPool(t, i) {
        Utils.playNumAnim(this.jackpotPool.getChildByName("num").getComponent(Label), 0.8, t, i);
    }
    changeXiaZhuRootState(t) {
        this.node.getChildByName("xiazhu_root").active = t;
        this.clearXiaZhuRoot();
    }
    clearXiaZhuRoot() {
        this.xiazhuRoot.removeAllChildren();
    }
    addXiaZhuInfo(t, i) {
        let e = `${t = ToolUtils.GetShortName2(t, 12, false)} BET ${ToolUtils.parse_ChipNum2(i)}`, a = instantiate(this.xiazhuMoban);
        a.active = true;
        a.getComponent(Label).string = e;
        this.xiazhuRoot.addChild(a);
    }
    initRouteLayout() {
        this.route_layout.active = true;
    }
    initFlyLayout() {
        this.fly_layout.active = false;
        this.gj_node.getComponent(UITransform).contentSize = size(0, this.gj_Maxheight);
        this.cashPlayer.active = false;
        this.rocketAnim.node.setPosition(this.rocket_start_pos);
        this.changeFlyAnimState(1);
        this.gameData.zb_start_time = this.gj_MaxWidth / this.x_speed;
        this.gameData.bl_rate = 320;
        this.gameData.zb_start_bl = this.gj_Maxheight / this.gameData.bl_rate + 1;
        this.gameData.cashoutItems = [];
        this.gameData.curBeilv = 1;
        this.rocketBzAnim.node.setPosition(this.rocket_start_pos);
        this.rocketBzAnim.node.active = false;
    }
    playRocketBzAnim(t) {
        sys.isObjectValid(this.gameData.bzAction) && TweenTool.stopAction(this.gameData.bzAction);
        this.gameData.update_flytime_flag = 0;
        SoundManager.shared().pauseMusic();
        this.xingqiuAnim.paused = true;
        this.bz_dian.active = true;
        let i = v3(0, 0);
        this.rocket_node.getPosition(i);
        this.bz_dian.setPosition(v3(i.x, i.y));
        t ? (SoundManager.shared().playFx("baoza"), this.rocketBzAnim.node.angle = this.rocketAnim.node.angle, this.rocketBzAnim.node.active = true, this.rocketBzAnim.clearTracks(), this.rocketBzAnim.setToSetupPose(), this.rocketBzAnim.setAnimation(0, "hj_bz", false), this.gameData.bzAction = TweenTool.delayAct(this.node, (() => {
            this.rocketAnim.node.active = false;
            this.stopFlyAction();
        }), 0.2, true)) : this.rocketAnim.node.active = false;
    }
    showCashoutPlayer(t) {
        let i = t.win_rate, e = t.player_name, a = instantiate(this.cashPlayer), s = `${e} @ x${i.toFixed(2)}`, o = t.fly_time;
        a.getComponent(Label).string = s;
        a.active = true;
        this.cashout_node.addChild(a);
        let l = this.getRocketXPostition(o), h = this.getRocketYPostition(o);
        a.setPosition(v3(l, h));
        let r = {};
        r.x = l;
        r.y = h;
        r.time = o;
        r.item = a;
        r.beilv = t.win_rate;
        this.gameData.cashoutItems.push(r);
        TweenTool.delayAct(a, null, 0.5, true);
        this.updateCashPlayPosition();
    }
    updateCashPlayPosition() {
        if (this.gameData.cashoutItems.length > 0) {
            for (let t = 0; t < this.gameData.cashoutItems.length; t++) {
                let i = this.gameData.cashoutItems[t], e = i.x, a = i.y, s = i.item, o = i.time, n = i.beilv;
                if (ToolUtils.isObjValid(s)) {
                    o < 0 && (o = 0);
                    let l = e - this.x_speed * this.fly_interval;
                    l >= this.gj_MaxWidth && (l = this.gj_MaxWidth);
                    let h = a - this.x_speed * this.fly_interval;
                    if (h >= this.gj_Maxheight && (h = this.gj_Maxheight), e >= this.gj_MaxWidth && (h = this.gj_Maxheight), ToolUtils.isObjValid(s) && s.setPosition(v3(l, h)), h < 0) {
                        s.active = false;
                        s.removeFromParent();
                        i.item = null;
                        ToolUtils.isObjValid(s) && this.gameData.cashoutItems.splice(t, 1);
                        t--;
                        continue;
                    }
                    i.time = i.time - this.fly_interval;
                    i.x = l;
                    i.y = h;
                    i.beilv = n;
                }
            }
        }
    }
    getRocketYPostition(t) {
        let i = this.getBeilvByTime(t, this.gameData.curBeilv), e = this.gameData.bl_rate * i - this.gameData.bl_rate;
        return e >= this.gj_Maxheight && (e = this.gj_Maxheight), this.getRocketXPostition(t) >= this.gj_MaxWidth && (e = this.gj_Maxheight), e;
    }
    getRocketXPostition(t) {
        let i = this.x_speed * t;
        return i >= this.gj_MaxWidth && (i = this.gj_MaxWidth), i;
    }
    getBeilvByTime(t, i) {
        let e = 1;
        return t <= this.gameData.zb_start_time ? e = 1.9 * Math.sin((t / 30 + 1.5) * Math.PI) + 2.9 : t > this.gameData.zb_start_time && t <= 20 ? e = i + 0.15 * this.fly_interval : t > 20 && t <= 30 ? e = i + 0.28 * this.fly_interval : t > 30 && t <= 40 ? e = i + 0.42 * this.fly_interval : t > 40 && t <= 50 ? e = i + 0.65 * this.fly_interval : t > 50 && t <= 60 ? e = i + 0.82 * this.fly_interval : t > 60 && (e = i + 1 * this.fly_interval), e;
    }
    getCashOutPositionY(t, i) {
        let e = 1, a = 0;
        if (t <= this.gameData.zb_start_time) {
            e = 1.9 * Math.sin((t / 30 + 1.5) * Math.PI) + 2.9;
            a = i - (e - (1.9 * Math.sin(((t - this.fly_interval) / 30 + 1.5) * Math.PI) + 2.9)) * this.gameData.bl_rate;
        }
        else {
            t > this.gameData.zb_start_time && t <= 20 ? a = i - 0.15 * this.fly_interval * this.gameData.bl_rate : t > 20 && t <= 30 ? a = i - 0.28 * this.fly_interval * this.gameData.bl_rate : t > 30 && t <= 40 ? a = i - 0.42 * this.fly_interval * this.gameData.bl_rate : t > 40 && t <= 50 ? a = i - 0.65 * this.fly_interval * this.gameData.bl_rate : t > 50 && t <= 60 ? a = i - 0.82 * this.fly_interval * this.gameData.bl_rate : t > 60 && (a = i - 1 * this.fly_interval * this.gameData.bl_rate);
        }
        return a;
    }
    setXZhouPosition(t) {
        let i = this.x_speed * t, e = 0;
        i > this.gj_MaxWidth && (e = this.gj_MaxWidth - i);
        this.gj_node.getComponent(UITransform).contentSize = size(i, this.gj_Maxheight);
        let a = v3();
        this.xzhouImage.getPosition(a);
        this.xzhouImage.setPosition(v3(e, a.y));
        this.time_content.getPosition(a);
        this.time_content.setPosition(v3(e, a.y));
    }
    setYZhouPosition(t) {
        let i = this.getBeilvByTime(t, this.gameData.curBeilv), e = this.gameData.bl_rate * i - this.gameData.bl_rate, a = 0;
        e > this.gj_Maxheight && (a = this.gj_Maxheight - e);
        let s = v3();
        this.yzhouImage.getPosition(s);
        this.yzhouImage.setPosition(v3(s.x, a));
        this.bl_content.getPosition(s);
        this.bl_content.setPosition(v3(s.x, a));
    }
    getRocketRotation(t, i, e) {
        let a = 0;
        if (0 == i) {
            a = 0;
        }
        else if (i >= this.gj_MaxWidth) {
            a = this.rocket_end_roation;
        }
        else {
            let t = 180 * -Math.atan2(e - this.gameData.lastRocketY, i - this.gameData.lastRocketX) / Math.PI;
            t <= this.rocket_end_roation && (t = this.rocket_end_roation);
            a = t;
        }
        return a;
    }
    stopFlyAction() {
        this.gameData.update_flytime_flag = 0;
        this.gameData.cashoutItems = [];
        this.cashout_node.removeAllChildren();
        this.updateBlCall = null;
        sys.isObjectValid(this.gameData.bzAction) && TweenTool.stopAction(this.gameData.bzAction);
    }
    changeFlyLayoutVisible(t) {
        this.fly_layout.active = t;
        t && this.stopWaiteAction();
    }
    changeFlyBeilvVisible(t) {
        let i = this.fly_layout.getChildByName("bl_node");
        ToolUtils.isObjValid(i) && (i.active = t);
    }
    updateTimeAndBet(t) {
    }
    updateFlyBeilv(t, i) {
        sys.isObjectValid(i);
        this.gameData.curBeilv = t;
        let e = this.fly_layout.getChildByName("bl_node");
        if (ToolUtils.isObjValid(e)) {
            let i = `${t.toFixed(2)}X`;
            e.getChildByName("wz").getComponent(Label).string = i;
            t >= 1 && t < 2 ? (e.getChildByName("wz").getComponent(Label).color = RocketGameManager.eCrashColorValue.green, e.getComponent(Sprite).spriteFrame = this.bigBeilvImgs[0]) : t >= 2 && t < 10 ? (e.getChildByName("wz").getComponent(Label).color = RocketGameManager.eCrashColorValue.blue, e.getComponent(Sprite).spriteFrame = this.bigBeilvImgs[1]) : t >= 10 && t < 20 ? (e.getChildByName("wz").getComponent(Label).color = RocketGameManager.eCrashColorValue.purple, e.getComponent(Sprite).spriteFrame = this.bigBeilvImgs[2]) : (e.getChildByName("wz").getComponent(Label).color = RocketGameManager.eCrashColorValue.orange, e.getComponent(Sprite).spriteFrame = this.bigBeilvImgs[3]);
        }
    }
    stopWaiteAction() {
        sys.isObjectValid(this.gameData.waite_action) && (this.unschedule(this.updateWaiteTime), this.gameData.waite_action = null);
        sys.isObjectValid(this.gameData.waite_action2) && (this.unschedule(this.updateWaiteJindu), this.gameData.waite_action2 = null);
    }
    changeWaiteLayoutVisible(t, i, e) {
        if (this.waite_layout.active = t, t) {
            if (this.waitTimeLabel.string = String(i) + "s", this.stopWaiteAction(), this.stopFlyAction(), sys.isObjectValid(e) && ToolUtils.isSafeNumber(e) > 0) {
                let t = (e - i) / ToolUtils.isSafeNumber(e);
                this.barSprite.fillRange = 1 - t;
            }
            this.gameData.cur_cd = i;
            this.gameData.totalCd = e;
            this.gameData.jindu_cd = i;
            this.gameData.waite_action = this.schedule(this.updateWaiteTime, this.waite_interval);
            this.gameData.waite_action2 = this.schedule(this.updateWaiteJindu, this.jindu_interval);
        }
        else {
            this.stopWaiteAction();
        }
    }
    updateWaiteTime() {
        if (this.gameData.cur_cd = this.gameData.cur_cd - this.waite_interval, this.gameData.cur_cd > 0) {
            let t = Math.ceil(this.gameData.cur_cd);
            this.waitTimeLabel.string = String(t) + "s";
        }
        else {
            this.stopWaiteAction();
        }
    }
    updateWaiteJindu() {
        if (this.gameData.jindu_cd = this.gameData.jindu_cd - this.jindu_interval, this.gameData.jindu_cd >= 0) {
            let t = (this.gameData.totalCd - this.gameData.jindu_cd) / this.gameData.totalCd;
            this.barSprite.fillRange = 1 - t;
        }
    }
    changeFlyAnimState(t) {
        this.gameData.rocketAnimIndex = t;
        this.rocket_node.active = true;
        this.rocketAnim.node.active = true;
        this.rocketAnim.clearTracks();
        this.rocketAnim.setToSetupPose();
        this.rocketAnim.setAnimation(0, ["hj_fx1", "hj_fx2"][t - 1], true);
        2 == t && SoundManager.shared().playFx("jackpot");
    }
    initRocketWaiteAnim() {
        this.rocketWaiteAnim.getComponent(sp.Skeleton).setAnimation(0, "hj_zs", true);
        this.xzhouImage.getComponent(UITransform).contentSize = size(this.x_zhou_width, 4);
        this.xzhouImage.setPosition(v3(0, 10));
        this.xzhouImage.removeAllChildren();
        this.route_layout.getChildByName("xfg_item").active = false;
        this.route_layout.getChildByName("yfg_item1").active = false;
        this.route_layout.getChildByName("yfg_item2").active = false;
        this.route_layout.getChildByName("time_item").active = false;
        this.route_layout.getChildByName("bl_item").active = false;
        this.yzhouImage.getComponent(UITransform).contentSize = size(4, this.y_zhou_height);
        this.yzhouImage.setPosition(v3(16, 0));
        this.yzhouImage.removeAllChildren();
        this.showAxis(120, 60);
    }
    showAxis(t, i) {
        this.xzhouImage.setPosition(v3(0, 10));
        this.xzhouImage.removeAllChildren();
        let e = Math.ceil(t / 2), a = e * this.time_space;
        a < this.x_zhou_width && (a = this.x_zhou_width);
        this.xzhouImage.getComponent(UITransform).contentSize = size(a, 4);
        this.time_content.removeAllChildren();
        this.time_content.setPosition(v3(0, 0));
        let s = e + 1;
        for (let t = 1; t <= s; t++) {
            let i = instantiate(this.route_layout.getChildByName("xfg_item"));
            i.active = true;
            i.setPosition(v3((t - 1) * this.time_space, -5));
            this.xzhouImage.addChild(i);
            let e = 2 * (t - 1), a = instantiate(this.route_layout.getChildByName("time_item"));
            a.active = true;
            a.getComponent(Label).string = String(e) + "s";
            a.setPosition(v3((t - 1) * this.time_space + 12, 11.5));
            this.time_content.addChild(a);
        }
        this.yzhouImage.removeAllChildren();
        this.yzhouImage.setPosition(v3(16, 0));
        let o = Math.ceil(10 * i / 2), l = o * this.bl_space;
        l < this.y_zhou_height && (l = this.y_zhou_height);
        this.yzhouImage.getComponent(UITransform).contentSize = size(4, l);
        this.bl_content.removeAllChildren();
        this.bl_content.setPosition(v3(0, 0));
        let h = o + 1;
        for (let t = 1; t <= h; t++) {
            let i = instantiate(this.route_layout.getChildByName("yfg_item1"));
            i.active = true;
            i.setPosition(v3(-12, (t - 1) * this.bl_space));
            this.yzhouImage.addChild(i);
            let e = instantiate(this.route_layout.getChildByName("yfg_item2"));
            e.active = true;
            e.setPosition(v3(-6, (t - 1) * this.bl_space + this.bl_space / 2));
            this.yzhouImage.addChild(e);
            let a = 1 + 0.2 * (t - 1), s = instantiate(this.route_layout.getChildByName("bl_item")), o = a.toFixed(1) + "x";
            s.getComponent(Label).string = o;
            s.active = true;
            s.setPosition(v3(-1, (t - 1) * this.bl_space + 8));
            this.bl_content.addChild(s);
        }
    }
    initBgAnim() {
        this.liuxingAnim = this.bg_anim_node.getChildByName("liuxing_anim").getComponent(sp.Skeleton);
        this.liuxingAnim.clearTracks();
        this.liuxingAnim.setToSetupPose();
        this.liuxingAnim.setAnimation(0, "hj_lxdh", true);
        this.xingqiuAnim = this.bg_anim_node.getChildByName("xingqiu_anim").getComponent(sp.Skeleton);
        this.xingqiuAnim.clearTracks();
        this.xingqiuAnim.setToSetupPose();
        this.xingqiuAnim.setAnimation(0, "hj_xq", true);
        this.xingqiuAnim.node.active = false;
    }
    initWaiteLayout() {
        this.barSprite.fillRange = 1;
        this.gameData.cur_cd = 0;
        this.gameData.totalCd = 0;
        this.gameData.jindu_cd = 0;
        this.gameData.cashoutTime = 0;
    }
    rocketPlayFly(t, i, e) {
        this.stopFlyAction();
        sys.isObjectValid(e) && (this.updateBlCall = e);
        this.bz_dian.active = false;
        this.xingqiuAnim.node.active = true;
        this.xingqiuAnim.clearTracks();
        this.xingqiuAnim.setToSetupPose();
        this.xingqiuAnim.setAnimation(0, "hj_xq", true);
        this.changeFlyLayoutVisible(true);
        this.changeFlyAnimState(i);
        this.gameData.lastRocketX = 0;
        this.gameData.lastRocketY = 0;
        this.gameData.curBeilv = 0;
        this.gameData.flytime = t;
        this.gameData.last_uptime = performance.now();
        this.gameData.update_flytime_flag = 1;
        this.updateFlyTime();
    }
    update(t) {
        if (1 == this.gameData.update_flytime_flag) {
            let t = performance.now();
            t - this.gameData.last_uptime >= 50 && (this.fly_interval = (t - this.gameData.last_uptime) / 1000, this.gameData.last_uptime = t, this.updateFlyTime());
        }
    }
    updateFlyTime() {
        let t = this.getRocketXPostition(this.gameData.flytime), i = this.getRocketYPostition(this.gameData.flytime);
        this.rocket_node.setPosition(v3(t, i));
        let e = this.getRocketRotation(this.gameData.flytime, t, i);
        this.rocketAnim.node.angle = -1 * e;
        this.changeFlyBeilvVisible(true);
        let a = this.getBeilvByTime(this.gameData.flytime, this.gameData.curBeilv);
        a < this.gameData.curBeilv && (a = this.gameData.curBeilv);
        this.gameData.curBeilv = a;
        sys.isObjectValid(this.updateBlCall) && this.updateBlCall(a);
        this.updateFlyBeilv(a);
        this.setXZhouPosition(this.gameData.flytime);
        this.setYZhouPosition(this.gameData.flytime);
        this.updateCashPlayPosition();
        this.gameData.lastRocketX = t;
        this.gameData.lastRocketY = i;
        1 == this.gameData.rocketAnimIndex && a >= 20 && this.changeFlyAnimState(2);
        this.gameData.flytime = this.gameData.flytime + this.fly_interval;
    }
    updateGameEndGuiji(t) {
        this.stopFlyAction();
        this.rocket_node.active = false;
        this.changeFlyLayoutVisible(true);
        this.gameData.lastRocketX = 0;
        this.gameData.lastRocketY = 0;
        this.gameData.flytime = t;
        this.updateFlyTime();
    }
    setFlyTime(t) {
        this.gameData.flytime = t;
    }
    refreshHistoryRecode() {
        let t = RocketGameManager.shared().history_recordVec.length, i = 0;
        t > 12 && (i = t - 12);
        this.trendList.removeAllChildren();
        for (let e = i; e < t; e++) {
            let t = RocketGameManager.shared().history_recordVec[e], i = instantiate(this.trend_moban);
            if (ToolUtils.isObjValid(i)) {
                i.active = true;
                let e = i.getChildByName("wz"), a = t.color, s = t.win_rate;
                a == RocketGameManager.eCrashTrendColor.emGreen ? (e.getComponent(Label).color = RocketGameManager.eCrashColorValue.green, i.getComponent(Sprite).spriteFrame = this.smallBeilvImgs[0]) : a == RocketGameManager.eCrashTrendColor.emBlue ? (e.getComponent(Label).color = RocketGameManager.eCrashColorValue.blue, i.getComponent(Sprite).spriteFrame = this.smallBeilvImgs[1]) : a == RocketGameManager.eCrashTrendColor.emPurple ? (e.getComponent(Label).color = RocketGameManager.eCrashColorValue.purple, i.getComponent(Sprite).spriteFrame = this.smallBeilvImgs[2]) : a == RocketGameManager.eCrashTrendColor.emOrange && (e.getComponent(Label).color = RocketGameManager.eCrashColorValue.orange, i.getComponent(Sprite).spriteFrame = this.smallBeilvImgs[3]);
                e.getComponent(Label).string = s;
                this.trendList.addChild(i);
            }
        }
    }
    resetInfo() {
        sys.isObjectValid(this.gameData.winTrendAction) && TweenTool.stopAction(this.gameData.winTrendAction);
        this.lightView.active = false;
        let t = v3(0, 0);
        this.yzhouImage.getPosition(t);
        this.yzhouImage.setPosition(v3(t.x, 0));
        this.bl_content.getPosition(t);
        this.bl_content.setPosition(v3(t.x, 0));
        this.gj_node.getComponent(UITransform).contentSize = size(0, this.gj_Maxheight);
        this.xzhouImage.getPosition(t);
        this.xzhouImage.setPosition(v3(0, t.y));
        this.time_content.getPosition(t);
        this.time_content.setPosition(v3(0, t.y));
        this.stopFlyAction();
        this.bz_dian.active = false;
        this.clearXiaZhuRoot();
        this.changeXiaZhuRootState(false);
    }
    showWinLight() {
        sys.isObjectValid(this.gameData.winTrendAction) && TweenTool.stopAction(this.gameData.winTrendAction);
        this.gameData.winTrendAction = tween(this.lightView).repeat(3, tween().call((() => {
            this.lightView.active = true;
        })).delay(0.5).call((() => {
            this.lightView.active = false;
        })).delay(0.5)).start();
    }
    setCallBack(t) {
        this.gameCallback = t;
    }
    touchBtnEvent(t, i) {
        SoundManager.shared().playFx("click");
        sys.now() - this.lastClick < 500 || (this.lastClick = sys.now(), this.gameCallback && this.gameCallback(i));
    }
    addPushNotify() {
    }
    onDestroy() {
        super.onDestroy();
        this.stopWaiteAction();
        this.unscheduleAllCallbacks();
        PushCenter.shared().removeListenersByTag(this);
    }
}
