// @ts-nocheck
// Recovered from index.js:533
import { _decorator, instantiate, Label, Node, ScrollView, size, sys } from "cc";
import BaseLayer from "./BaseLayer";
import PushCenter from "./PushCenter";
import Utils from "./Utils";
import SoundManager from "./SoundManager";
import { ToolUtils } from "./ToolUtils";
import { PullToRefresh } from "./PullToRefresh";
const { ccclass, property } = _decorator;
@ccclass("SixPointNoSeatList")
export class SixPointNoSeatList extends BaseLayer {
    public TAG: string = "SixPointNoSeatList";
    @property(Node)
    public root: Node = null;
    @property(Node)
    public moban: Node = null;
    @property(Node)
    public scrollView: Node = null;
    public _lastClick: number = 0;
    public _has_close: boolean = false;
    public gameCallback: any = null;
    public curPage: number = 1;
    public totalPage: number = 1;
    public canGetMore: boolean = true;
    onLoad() {
    }
    start() {
        super.start();
        this.startShowAnim(this.root);
        ToolUtils.showFullScreen(this.node.getChildByName("bg"));
        this.initView();
    }
    initParaData(t) {
        sys.isObjectValid(t) && sys.isObjectValid(t.cb) && (this.gameCallback = t.cb);
    }
    initView() {
        let t = this.scrollView.getComponent(PullToRefresh);
        sys.isObjectValid(t) && t.setOnLoadMore(this.getMoreInfo.bind(this));
    }
    getMoreInfo() {
        sys.isObjectValid(this.gameCallback) && this.curPage < this.totalPage && this.canGetMore && (this.gameCallback(this.curPage), this.canGetMore = false);
    }
    refreshUI(t) {
        if (this.curPage = t.page, this.totalPage = t.total, this.canGetMore = true, sys.isObjectValid(t.players) && Array.isArray(t.players) && t.players.length > 0) {
            for (let e = 0; e < t.players.length; e++) {
                let i = instantiate(this.moban);
                i.active = true;
                let a = i.getChildByName("head_kuang").getChildByName("mask").getChildByName("head_img");
                Utils.shared().updateHeadImg(a, t.players[e].avatar, t.players[e].avatar_url, size(75, 75));
                sys.isObjectValid(t.players[e].name) && (i.getChildByName("name").getComponent(Label).string = ToolUtils.GetShortName2(ToolUtils.isSafeString(t.players[e].name), 10, false));
                sys.isObjectValid(t.players[e].money) && (i.getChildByName("chip_num").getComponent(Label).string = ToolUtils.parse_double(t.players[e].money));
                this.scrollView.getComponent(ScrollView).content.addChild(i);
            }
        }
        let e = this.scrollView.getComponent(PullToRefresh);
        sys.isObjectValid(e) && (e.finishLoadMore(), e.finishRefresh());
    }
    touchBtnEvent(t, e) {
        SoundManager.shared().playFx("click");
        sys.now() - this._lastClick < 500 || (this._lastClick = sys.now(), this.onBackView());
    }
    onBackView() {
        ToolUtils.isObjValid(this.node) && (this.gameCallback && this.gameCallback[-1], this.node.destroy());
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().removeListenersByTag(this);
    }
}
