// @ts-nocheck
// Recovered from index.js:633
import { _decorator, Component, assetManager, director, isValid, Node, Prefab, SafeArea, screen, size, sys, UITransform, v3, view, Widget } from "cc";
import BundleNameDefined from "./BundleNameDefined";
import OptionalGameResources from "./OptionalGameResources";
import { CommonGameType, HallGameType, PointsType } from "./CommDefine";
import GameConfig from "./GameConfig";
import i18nMgr from "./i18nMgr";
import MD5 from "./MD5";
import { TLog } from "./TLog";
import TweenTool from "./TweenTool";
const { ccclass } = _decorator;
@ccclass("ToolUtils")
export class ToolUtils extends Component {
    static uid = 0;
    static skey = 0;
    static game_model = 0;
    static isregister = 0;
    static curRoomId = 0;
    static curVId = 0;
    static ipAddress = "";
    static client_ip = "";
    static nNetDelayTimeOut = -1;
    static netDelay = -1;
    static netDelay2 = -1;
    static gamePing = 0;
    static enter_game_ping = -1;
    static firstLoginTime = 0;
    static curGameType = 0;
    static str = "";
    static _orientation_landscape = false;
    static isGameBackground = false;
    static backgroundWebSocketReconnection = false;
    static has_comm_alert = false;
    static has_reconnect = false;
    static has_offline = false;
    static offlineMsg = null;
    static heart_open = 0;
    static heartbeat_time = 0;
    static heart_time = [5, 15];
    static in_isGuideRoom = 0;
    static isInGameScene = 0;
    static flopActInGameData = null;
    static deskInfos = new Map;
    static ad_has_show_toast = 0;
    static ad_complete = 0;
    static ad_bg_enable = false;
    static report_scene = 1;
    static report_link_id = 0;
    static latitude = "";
    static longitude = "";
    static last_web_url = "";
    static last_web_title = "";
    static report_time_param = {};
    static showGuest = 1;
    static showGuestLocal = true;
    static pp_url = "";
    static tos_url = "";
    static loginKeFu_url = "";
    static feedback_url_type = 0;
    static support_enabled = false;
    static contact_url = "";
    static about_url = "";
    static gst_url = "";
    static refund_url = "";
    static responsible_url = "";
    static tds_policy_url = "";
    static feedback_mode = 0;
    static feedback_data = null;
    static play_back_vid = 901;
    static vip_data = null;
    static login_tawk_url = "";
    static tawk_url_12 = "";
    static remoteUrlList = {};
    static _globalNode = null;
    static _globalNode2 = null;
    static permission_forbid = false;
    static _fireBaseToken = "";
    static _bNeedReportToken = true;
    static location_forbid = false;
    static hasGetLocation = false;
    static switchSceneTye = 0;
    static bSwitchToGame = false;
    static hasShowLabaCount = 0;
    static LabaCount = 0;
    static LabaTable = [];
    static vip_reward_dot = 0;
    static enterBackGround = false;
    static cur_game_bundle = "";
    static local_time_diff = 0;
    static subGameInfo = {};
    static loadSubGameArr = [];
    static _loadResStep = [];
    static _gameLoadInfo = [];
    static _downMaxTry = 3;
    static report_sw_click = [];
    static gateHeartBeatSwitch = false;
    static bSendGateHeatBeat = false;
    static lastSendHeartBeatTime = 0;
    static LAST_CHIPS_MODLE = -1;
    start() {
    }
    static getOsTime() {
        return sys.now() + ToolUtils.local_time_diff;
    }
    static resetUserDataInHall() {
        ToolUtils.has_comm_alert = false;
        ToolUtils.has_reconnect = false;
        ToolUtils.deskInfos.clear();
        ToolUtils.isInGameScene = 0;
        ToolUtils.curRoomId = 0;
        ToolUtils.curVId = 0;
        ToolUtils.enter_game_ping = -1;
        ToolUtils.vip_reward_dot = 0;
        ToolUtils.curGameType = 0;
    }
    static checkIsModuleReport(t) {
        return -1 != ToolUtils.report_sw_click.indexOf(t);
    }
    static getGlobalNode() {
        return ToolUtils._globalNode || (ToolUtils._globalNode = new Node, director.addPersistRootNode(ToolUtils._globalNode)), ToolUtils._globalNode;
    }
    static getPersistGlobalNode() {
        return ToolUtils._globalNode2 || (ToolUtils._globalNode2 = new Node, director.addPersistRootNode(ToolUtils._globalNode2)), ToolUtils._globalNode2;
    }
    static setGlobalNode() {
        let t = director.getScene();
        if (ToolUtils.isObjValid(t)) {
            let r = t.getChildByName("Global");
            ToolUtils.isObjValid(r) && director.addPersistRootNode(r);
        }
    }
    static getRemoteSoundUrl() {
        if (sys.isObjectValid(ToolUtils.remoteUrlList.audio) && ToolUtils.remoteUrlList.audio.length > 0 && (ToolUtils.remoteUrlList.audio.startsWith("http://") || ToolUtils.remoteUrlList.audio.startsWith("https://"))) {
            let t = ToolUtils.remoteUrlList.audio;
            return "MOBILE_BROWSER" == sys.platform || "DESKTOP_BROWSER" == sys.platform ? t += "web/" + BundleNameDefined.bundle_sound : t += "native/" + BundleNameDefined.bundle_sound, t;
        }
        return "";
    }
    static getDeskImageUrl() {
        if (sys.isObjectValid(ToolUtils.remoteUrlList.desk) && ToolUtils.remoteUrlList.desk.length > 0 && (ToolUtils.remoteUrlList.desk.startsWith("http://") || ToolUtils.remoteUrlList.desk.startsWith("https://"))) {
            let t = ToolUtils.remoteUrlList.desk;
            return "MOBILE_BROWSER" == sys.platform || "DESKTOP_BROWSER" == sys.platform ? t += "web/" + BundleNameDefined.bundle_desk : t += "native/" + BundleNameDefined.bundle_desk, t;
        }
        return "";
    }
    static getDownLoadBundleUrl(t) {
        const bundleName = ToolUtils.getSubGameBundleName(t)[0];
        // Native remote bundles use the release pinned by the APK, not mutable hall URLs.
        if (bundleName && assetManager.downloader.remoteBundles.indexOf(bundleName) !== -1) {
            return assetManager.downloader.remoteServerAddress + "remote/";
        }
        let r = "", a = ToolUtils.remoteUrlList.audio;
        return t == HallGameType.LOBBY_GAME_TYPE_SHUIGUOJI ? a = ToolUtils.remoteUrlList.fruit_ver : t == HallGameType.LOBBY_GAME_TYPE_CRASH ? a = ToolUtils.remoteUrlList.crash_ver : t == HallGameType.LOBBY_GAME_TYPE_SIXDICE ? a = ToolUtils.remoteUrlList.sixdice_ver : t == HallGameType.LOBBY_GAME_TYPE_YES11 ? a = ToolUtils.remoteUrlList.yes11_ver : t == HallGameType.LOBBY_GAME_TYPE_LuckBall && (a = ToolUtils.remoteUrlList.wingo_ver), sys.isObjectValid(a) && a.length > 0 && (a.startsWith("http://") || a.startsWith("https://")) && ("MOBILE_BROWSER" == sys.platform || "DESKTOP_BROWSER" == sys.platform ? r += a + "web/remote/" : r += a + "native/remote/"), r;
    }
    static getGuessCardUrl() {
        if (sys.isObjectValid(ToolUtils.remoteUrlList.guesscard) && ToolUtils.remoteUrlList.guesscard.length > 0 && (ToolUtils.remoteUrlList.guesscard.startsWith("http://") || ToolUtils.remoteUrlList.guesscard.startsWith("https://"))) {
            let t = ToolUtils.remoteUrlList.guesscard;
            return "MOBILE_BROWSER" == sys.platform || "DESKTOP_BROWSER" == sys.platform ? t += "web/" + BundleNameDefined.bundle_guessCard : t += "native/" + BundleNameDefined.bundle_guessCard, t;
        }
        return "";
    }
    static gm_xorfunc(t, r) {
        if ("string" == typeof t) {
            let a = new ArrayBuffer(ToolUtils.getUtf8StrLen(t)), i = new DataView(a, 0, ToolUtils.getUtf8StrLen(t));
            ToolUtils.write_utf8(i, 0, t);
            for (let e = 0, t = i.byteLength; e < t; e++) {
                i.setUint8(e, i.getUint8(e) ^ r);
            }
            return i.buffer;
        }
        {
            let e = new Uint8Array(t.length);
            for (let a = 0, i = t.length; a < i; a++) {
                e[a] = t[a] ^ r;
            }
            return e;
        }
    }
    static getOrientation() {
        return ToolUtils._orientation_landscape;
    }
    static checkIsRummy(e) {
        return -1 == [CommonGameType.FruitMachine, CommonGameType.TeenPatti, CommonGameType.TpAK47, CommonGameType.TpPotBlind, CommonGameType.Crash, CommonGameType.SevenUp, CommonGameType.SixDice, CommonGameType.AB, CommonGameType.LHD, CommonGameType.ClearMines, CommonGameType.Horse, CommonGameType.BrTp, CommonGameType.CricketSlot, CommonGameType.LuckBall, CommonGameType.Ludo].indexOf(e);
    }
    static judgeIfInScene(e) {
        return director.getScene().name == e;
    }
    static showPushAnim(t, r = 0, a = null, n = null) {
        if (!ToolUtils.isObjValid(t)) {
            return;
        }
        let l = 4 == r || 5 == r ? 1640 : 720, o = 0.27, u = v3(l, 0), d = v3(0, 0);
        1 == r ? (u = v3(0, 0), d = v3(l, 0)) : 5 == r && (u = v3(-l, 0), d = v3(0, 0));
        n && (sys.isObjectValid(n.startPos) && (u = n.startPos), sys.isObjectValid(n.endPos) && (d = n.endPos), sys.isObjectValid(n.moveTime) && (o = n.moveTime));
        TweenTool.stopNodeAction(t);
        t.setPosition(u);
        TweenTool.moveTo(t, o, d, "cubicOut", true, (() => {
            t.setPosition(d);
            a && a();
        }));
    }
    static startShowAnim(e, t, r = 0.2) {
        e.setScale(v3(r, r, r));
        TweenTool.scaleTo(e, 0.2, v3(1, 1, 1), "backOut", true, (() => {
            e.setScale(v3(1, 1, 1));
            t && t();
        }));
    }
    static toPercent(e) {
        if (isNaN(e)) {
            return "0%";
        }
        let t = (100 * e).toFixed(2);
        return t = t.replace(/\.?0+$/, ""), t + "%";
    }
    static parse_ChipNum(e) {
        let t = Number(e).toFixed(0), r = Number(t);
        if (r >= 10000) {
            let e = r.toString(), t = "", a = 0;
            for (let r = e.length - 1; r >= 0; r--) {
                t = e[r] + t;
                a++;
                (3 === a && 0 !== r || 2 === a && 0 !== r && e.length - r > 3) && (t = "," + t, a = 0);
            }
            return t;
        }
        return r.toString();
    }
    static truncateToTwoDecimalPlaces(e) {
        if ("number" != typeof e || isNaN(e)) {
            return "0.00";
        }
        const [t, r = ""] = e.toString().split(".");
        return `${t}.${r.slice(0, 2).padEnd(2, "0")}`;
    }
    static parse_ChipNum2(t, r) {
        let a = Number(t);
        if (isNaN(a)) {
            return t;
        }
        let i = Math.floor(Number(t)), n = Number(i);
        if (a = Math.abs(Number(i)), a >= 10000000) {
            let t = a / 10000000;
            return n < 0 ? "-" + ToolUtils.truncateToTwoDecimalPlaces(t) + "Cr" : ToolUtils.truncateToTwoDecimalPlaces(t) + "Cr";
        }
        if (a >= 100000) {
            let t = a / 100000;
            return n < 0 ? "-" + ToolUtils.truncateToTwoDecimalPlaces(t) + "L" : ToolUtils.truncateToTwoDecimalPlaces(t) + "L";
        }
        return n < 0 ? "-" + a.toFixed(0) : a.toFixed(0);
    }
    static parse_ChipNum3(e, t = 1) {
        let r = Number(e);
        if (isNaN(r)) {
            return e;
        }
        let a = Number(e).toFixed(0), i = Number(a);
        if (r = Math.abs(Number(a)), r >= 10000000) {
            let e = r / 10000000;
            return e % 1 == 0 ? i < 0 ? "-" + e.toFixed(0) + "Cr" : e.toFixed(0) + "Cr" : i < 0 ? "-" + e.toFixed(t) + "Cr" : e.toFixed(t) + "Cr";
        }
        if (r >= 100000) {
            let e = r / 100000;
            return e % 1 == 0 ? i < 0 ? "-" + e.toFixed(0) + "L" : e.toFixed(0) + "L" : i < 0 ? "-" + e.toFixed(t) + "L" : e.toFixed(t) + "L";
        }
        return i < 0 ? "-" + r.toFixed(0) : r.toFixed(0);
    }
    static jsonToMd5(t) {
        try {
            if (!sys.isObjectValid(t)) {
                return null;
            }
            let r = ToolUtils.toJsonString(t);
            return MD5.Instance.hex_md5(r);
        }
        catch (e) {
            TLog.printError("----------- jsonToMd5 err:", e);
        }
        return "";
    }
    static toJsonString(e) {
        let t = "";
        try {
            t = JSON.stringify(e);
        }
        catch (e) {
            TLog.printError("----------- toJsonStr err:", e);
            t = "";
        }
        return t;
    }
    static parseJson(e) {
        let t = {};
        try {
            t = JSON.parse(e);
        }
        catch (e) {
            TLog.printError("----------- parseJsonString err:", e);
            t = {};
        }
        return t;
    }
    static getRecommendRoom(e, t = []) {
        let r = {};
        if (e && (sys.isObjectValid(e.lobby) && (r.gameType = Number(e.lobby)), sys.isObjectValid(e.game) && (r.rummyType = Number(e.game)), sys.isObjectValid(e.data))) {
            if (r.playersIndex = 2 == e.data.player ? 0 : 1, 1 == Number(e.game)) {
                r.poolIndex = 101 == e.data.pool_game ? 0 : 1;
            }
            else if (2 == Number(e.game)) {
                let t = Number(e.data.deals), a = 3 == t ? 1 : 0;
                a = 6 == t ? 2 : a;
                r.dealsIndex = a;
            }
            if (sys.isObjectValid(e.data.entry) && (r.enterMoney = e.data.entry), sys.isObjectValid(e.data.mode)) {
                if (t.length > 0) {
                    let a = 0;
                    for (let r = 0, i = t.length; r < i; r++) {
                        if (t[r] == e.data.mode) {
                            a = r;
                            break;
                        }
                    }
                    r.modeIndex = a;
                }
                else {
                    e.data.mode == PointsType.Easy ? r.modeIndex = 0 : e.data.mode == PointsType.Multiple ? r.modeIndex = 2 : e.data.mode == PointsType.Wild ? r.modeIndex = 3 : e.data.mode == PointsType.Double && (r.modeIndex = 1);
                }
            }
        }
        return r;
    }
    static setItemAsync(e, t) {
        return new Promise(((r, a) => {
            try {
                localStorage.setItem(e, t);
                r();
            }
            catch (e) {
                a(e);
            }
        }));
    }
    static async saveData(t, r) {
        try {
            await ToolUtils.setItemAsync(t, r);
        }
        catch (e) {
            TLog.printError("Failed to save data: ", e);
        }
    }
    static getPhontTimeShow() {
        let e = new Date, t = e.getFullYear() + "", r = e.getMonth() + 1;
        return t = r < 10 ? t + "-0" + r : t + "-" + r, t = e.getDate() < 10 ? t + "-0" + e.getDate() : t + "-" + e.getDate(), t = e.getHours() < 10 ? t + " 0" + e.getHours() : t + " " + e.getHours(), t = e.getMinutes() < 10 ? t + ":0" + e.getMinutes() : t + ":" + e.getMinutes(), t = e.getSeconds() < 10 ? t + ":0" + e.getSeconds() : t + ":" + e.getSeconds(), t;
    }
    static parseDianzanNumber(e) {
        let t = Number(e);
        if (t < 1000) {
            return t.toString();
        }
        if (t <= 10000) {
            return (t / 1000).toFixed(1) + "K";
        }
        return "10K+";
    }
    static format(e, ...t) {
        let r = e;
        if (-1 == r.indexOf("${0}")) {
            if (3 == i18nMgr.shared().language) {
                for (let e = 0, a = t.length; e < a; e++) {
                    r = r.replace("$", t[e]);
                }
            }
        }
        else {
            for (let e = 0, a = t.length; e < a; e++) {
                r = r.replace("${" + e + "}", t[e]);
            }
        }
        return r;
    }
    static getSexByAvatar(t) {
        let r = 0;
        if (!sys.isObjectValid(t)) {
            return r;
        }
        if (-1 != t.indexOf(".png")) {
            let a = t.split(".")[0];
            if (-1 != a.indexOf("_")) {
                let t = a.split("_")[1], i = ToolUtils.isSafeNumber(Number(t));
                r = i >= 1 && i <= 7 ? 0 : i >= 8 && i <= 12 ? 1 : 0;
            }
        }
        return r;
    }
    static getImageUrlPictureName(t) {
        if (ToolUtils.isSafeString(t).length > 0) {
            let e = "";
            try {
                const r = /\/([^\/?#]+\.(?:png|jpg|jpeg|gif|bmp))/i, a = t.match(r);
                a && a[1] && (e = a[1].split("?")[0]);
            }
            catch (e) {
            }
            return e;
        }
        return "";
    }
    static cardTo16(e) {
        if (null == e) {
            return;
        }
        let t = e.toString(16);
        return e < 16 && (t = "0" + t), "4e" == t && (t = "4f"), t;
    }
    static getCardInfo(t) {
        let r = {}, a = 0;
        return t >= 49 ? a = 48 : t >= 33 ? a = 32 : t >= 17 && (a = 16), r.value = t, r.point = t - a, r.cardFen = ToolUtils.getCardFen(r.point), r.color = a, r;
    }
    static getCardFen(e) {
        return 1 == e || 10 == e || 11 == e || 12 == e || 13 == e ? 10 : e;
    }
    static getCardShowValue(e) {
        return 1 == e ? "A" : 11 == e ? "J" : 12 == e ? "Q" : 13 == e ? "K" : "" + e;
    }
    static getRandomInt(e, t) {
        let r = t - e, a = Math.random();
        return e + Math.round(a * r);
    }
    static checkUPIString(e) {
        let t = true;
        if (-1 === e.indexOf("@") && (t = false), t) {
            for (let r = 0, a = e.length; r < a; r++) {
                const a = e[r];
                if (-1 === "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ.@".indexOf(a)) {
                    t = false;
                    break;
                }
            }
        }
        return t;
    }
    static checkIsPureNumber(e) {
        let t = /[\w]/, r = true;
        for (let a = 0, i = e.length; a < i; a++) {
            const i = e[a];
            if (!t.test(i)) {
                r = false;
                break;
            }
        }
        return r;
    }
    static getPureNumberString(e) {
        return ("" + e).replace(/[\D]/g, "");
    }
    static getPureNumberString2(e) {
        return ("" + e).replace(/[^\d.]/g, "");
    }
    static GetShortName2(e, t, r) {
        if (null == e || t <= 0) {
            return "";
        }
        if (e.length < t) {
            return e;
        }
        let a = e.substring(0, t);
        return r || (a += ".."), a.length >= e.length ? e : a;
    }
    static getLimitLengthString(e, t, r) {
        if (null == e || t <= 0) {
            return "";
        }
        if (e.length <= t) {
            return e;
        }
        let a = e.substring(0, t);
        return r || (a += ".."), a;
    }
    static timeStr2(e, t) {
        let r = 3600;
        if (0 == t) {
            if (e >= r) {
                let t = e % r / 60;
                t = parseInt(String(t));
                let a = e % r % 60;
                return a = parseInt(String(a)), String("0" + t).slice(-2) + ":" + String("0" + a).slice(-2);
            }
            if (e >= 60) {
                let t = e / 60;
                t = parseInt(String(t));
                let r = e % 60;
                return r = parseInt(String(r)), String("0" + t).slice(-2) + ":" + String("0" + r).slice(-2);
            }
            return "00:" + String("0" + e).slice(-2);
        }
        if (e >= r) {
            let t = e / r;
            t = parseInt(String(t));
            let a = e % r / 60;
            a = parseInt(String(a));
            let i = e % r % 60;
            return i = parseInt(String(i)), String("0" + t).slice(-2) + ":" + String("0" + a).slice(-2) + ":" + String("0" + i).slice(-2);
        }
        if (e >= 60) {
            let t = e / 60;
            t = parseInt(String(t));
            let r = e % 60;
            return r = parseInt(String(r)), "00:" + String("0" + t).slice(-2) + ":" + String("0" + r).slice(-2);
        }
        return "00:00:" + String("0" + e).slice(-2);
    }
    static parse_double(t, r = 2, a = false, i = false) {
        let n = Number(t), l = r;
        if (isNaN(n)) {
            return t;
        }
        t = Number(t).toFixed(5);
        let s = Number(t);
        n = Math.abs(Number(t));
        a && s < 0 && (s = 0, n = 0);
        let o = i ? " " : "";
        if (n >= 10000000) {
            let e = n / 10000000;
            return s < 0 ? "-" + e.toFixed(2) + o + "Cr" : e.toFixed(2) + o + "Cr";
        }
        if (n >= 100000) {
            let t = n / 100000;
            return s < 0 ? "-" + ToolUtils.parse_double(t.toString(), 2) + o + "L" : this.parse_double(t.toString(), 2) + o + "L";
        }
        {
            let t = ToolUtils.parseNum_double(n + "", l);
            if (s < 0) {
                if (2 == l) {
                    return "-" + t.toFixed(2);
                }
                if (1 == l) {
                    return "-" + t.toFixed(1);
                }
                if (-1 == l) {
                    if (-1 !== t.toString().indexOf(".")) {
                        return "-" + t.toFixed(2);
                    }
                }
                else if (-2 == l && -1 !== t.toString().indexOf(".")) {
                    return "-" + t.toFixed(1);
                }
                return "-" + t.toString();
            }
            if (2 == l) {
                return t.toFixed(2);
            }
            if (1 == l) {
                return t.toFixed(1);
            }
            if (-1 == l) {
                if (-1 !== t.toString().indexOf(".")) {
                    return t.toFixed(2);
                }
            }
            else if (-2 == l && -1 !== t.toString().indexOf(".")) {
                return t.toFixed(1);
            }
            return t.toString();
        }
    }
    static parseNum_double(e, t = 2) {
        let r = Number(e);
        if (isNaN(r)) {
            return 0;
        }
        {
            let r = e.split("."), a = "", i = "";
            return r && r.length > 0 && (r[0] && (a = r[0]), r[1] && (i = r[1].substring(0, 2), 2 === t && 1 === i.length && (i += "0"))), Number(a + "." + i);
        }
    }
    static parse_double2(e, t = 2) {
        let r = Number(e), a = Number(e), i = 2;
        if (i = 1 == t ? 1 : 2, isNaN(a)) {
            return e;
        }
        if (a = Math.abs(Number(e)), a >= 100000) {
            let e = a / 100000;
            return r < 0 ? "-" + this.parse_double2(e.toString()) + "L" : this.parse_double2(e.toString()) + "L";
        }
        if (a >= 10000) {
            let e = a / 1000;
            return r < 0 ? "-" + this.parse_double2(e.toString()) + "K" : this.parse_double2(e.toString()) + "K";
        }
        {
            let e = this.parseNum_double(a + "", i);
            return r < 0 ? "-" + e.toString() : e.toString();
        }
    }
    static getUtf8StrLen(e) {
        let t, r = 0;
        for (let a = 0, i = e.length; a < i; a++) {
            t = e.charCodeAt(a);
            t <= 127 ? r += 1 : 128 <= t && t <= 2047 ? r += 2 : 2048 <= t && t <= 65535 && (r += 3);
        }
        return r;
    }
    static write_utf8(e, t, r) {
        for (var a = t, i = 0, n = r.length; i < n; i++) {
            var l = r.charCodeAt(i);
            l < 128 ? (e.setUint8(a, l), a++) : l < 2048 ? (e.setUint8(a, 192 | l >> 6), a++, e.setUint8(a, 128 | 63 & l), a++) : l < 65536 ? (e.setUint8(a, 224 | l >> 12), a++, e.setUint8(a, 128 | l >> 6 & 63), a++, e.setUint8(a, 128 | 63 & l), a++) : (i++, l = 65536 + ((1023 & l) << 10 | 1023 & r.charCodeAt(i)), e.setUint8(a, 240 | l >> 18), a++, e.setUint8(a, 128 | l >> 12 & 63), a++, e.setUint8(a, 128 | l >> 6 & 63), a++, e.setUint8(a, 128 | 63 & l), a++);
        }
    }
    static getSafeDistance() {
        let t = sys.getSafeAreaRect().y;
        return ToolUtils._orientation_landscape && sys.getSafeAreaRect().x > t && (t = sys.getSafeAreaRect().x), t;
    }
    static judgeIfInHall() {
        let t = false, r = director.getScene();
        return sys.isObjectValid(r) && ToolUtils.isObjValid(r) && r.name == BundleNameDefined.hall_scene && window.InHallScene && (t = true), t;
    }
    static judgeIfInRummy() {
        let t = false, r = director.getScene();
        return sys.isObjectValid(r) && ToolUtils.isObjValid(r) && r.name == BundleNameDefined.rummy_scence && window.InRummyScene && (t = true), t;
    }
    static getIsInRoom() {
        let t = [BundleNameDefined.rummy_scence, BundleNameDefined.fruitmachine_scene, BundleNameDefined.gamecrash_scene, BundleNameDefined.gamecrash_scene, BundleNameDefined.sixdice_scene, BundleNameDefined.ludo_scence], r = director.getScene();
        return !(!ToolUtils.isObjValid(r) || -1 == t.indexOf(r.name));
    }
    static isAndroidPlatform() {
        let e = false;
        return !sys.isNative || sys.os !== sys.OS.ANDROID && sys.os !== sys.OS.OHOS || (e = true), e;
    }
    static isIosPlatform() {
        let e = false;
        return sys.isNative && sys.os === sys.OS.IOS && (e = true), e;
    }
    static isPadPlatform() {
        let e = false;
        return Math.abs(GameConfig.REAL_SCREEN_WIDTH - 720) >= 5 && (e = true), e;
    }
    static isForbidFuc() {
        return sys.os === sys.OS.IOS || sys.os === sys.OS.OSX;
    }
    static isObjValid(e) {
        return sys.isObjectValid(e) && isValid(e, true);
    }
    static isObjValidStrict(e) {
        return sys.isObjectValid(e) && isValid(e, true);
    }
    static adaptSafeArea(t, r = 0) {
        let a = 0;
        if (sys.os === sys.OS.IOS && ToolUtils.isObjValid(t)) {
            if (0 == r && t.getComponent(SafeArea)) {
                t.getComponent(SafeArea).enabled = false;
                ToolUtils.getSafeDistance() > 40 && (a = 40, t.getComponent(Widget).top = ToolUtils.getSafeDistance() - a);
            }
            else if (1 == r && ToolUtils.getSafeDistance() > 40) {
                a = 40;
                let r = 40 - ToolUtils.getSafeDistance();
                t.setPosition(v3(0, r, 0));
            }
        }
        return a;
    }
    static getFitTopHeightDiff() {
        let e = 0, t = screen.windowSize, r = view.getVisibleSize();
        return t.width / t.height < r.width / r.height && (e = (r.height - 40) * (r.width / r.height - t.width / t.height)), e;
    }
    static getFitBottomHeightDiff() {
        let e = 0, t = screen.windowSize, r = view.getVisibleSize();
        return t.width / t.height < r.width / r.height && (e = r.height / 2 * (r.width / r.height - t.width / t.height)), e;
    }
    static getHorizontalSize() {
        let e = view.getVisibleSize(), t = e.width >= e.height ? e.width : e.height, r = GameConfig.REAL_SCREEN_HEIGHT, a = GameConfig.REAL_SCREEN_WIDTH;
        return t > r && (r = t), size(r, a);
    }
    static getIsNormalDirection() {
        if (ToolUtils.getIsInRoom()) {
            let e = director.getScene().getChildByName("Canvas");
            return !e.getChildByName("ShopMain") && (!e.getChildByName("recharge_limits") && !e.getChildByName("PurseHistory"));
        }
        return true;
    }
    static getOffsetDistance() {
        return ToolUtils.getRealViewSize().height - GameConfig.CONFIG_SCREEN_HEIGHT;
    }
    static getRealViewSize() {
        view.getVisibleSize();
        return size(GameConfig.REAL_SCREEN_WIDTH, GameConfig.REAL_SCREEN_HEIGHT);
    }
    static showFullScreen(t) {
        if (ToolUtils.isObjValid(t)) {
            let e = t.getComponent(UITransform), r = GameConfig.REAL_SCREEN_HEIGHT > GameConfig.REAL_SCREEN_WIDTH ? GameConfig.REAL_SCREEN_HEIGHT : GameConfig.REAL_SCREEN_WIDTH, a = view.getVisibleSize(), i = a.width >= a.height ? a.width : a.height;
            i > r && (r = i);
            let n = size(r, r);
            e.setContentSize(n);
        }
    }
    static isToday(e) {
        let t = new Date(sys.now()), r = t.getFullYear(), a = t.getMonth() + 1, n = t.getDate(), l = new Date(e), s = l.getFullYear(), o = l.getMonth() + 1, u = l.getDate(), d = false;
        return r === s && a === o && n === u && (d = true), d;
    }
    static getMothHaveDay(e, t) {
        return 2 == t ? e % 4 == 0 ? 29 : 28 : 1 == t || 3 == t || 5 == t || 7 == t || 8 == t || 10 == t || 12 == t ? 31 : 30;
    }
    static isSafeString(e) {
        return "string" == typeof e ? e : "";
    }
    static isSafeNumber(e) {
        return "number" != typeof e || Number.isNaN(e) ? 0 : e;
    }
    static shouldHideSettlementHand(playerInfo, packetShowcard, allOthersFolded) {
        // Packet showcard=1 conceals every hand; player showcard=1 reveals this hand.
        // Keep concealment for Drop players and restricted history/watch packets.
        if (1 == packetShowcard || 1 == playerInfo.isfold) {
            return true;
        }
        if (playerInfo.showcard === 0 || playerInfo.showcard === "0") {
            return true;
        }
        if (playerInfo.showcard === 1 || playerInfo.showcard === "1") {
            return false;
        }
        // Older packets have no per-player flag; retain their existing behavior.
        return allOthersFolded;
    }
    static isJsonString(e) {
        try {
            const t = JSON.parse(e);
            return "object" == typeof t && null !== t;
        }
        catch (e) {
            return false;
        }
    }
    static EstimateTypeof(e, t) {
        if (1 == t) {
            return !!/^[0-9]*$/.test(e);
        }
        if (2 == t) {
            return !!/^[a-zA-Z]*$/.test(e);
        }
        return true;
    }
    static getPrintJsonStr(t) {
        let r = "";
        try {
            0 !== GameConfig.HTTP_MSG_DEBUG && sys.isObjectValid(t) && (r = ToolUtils.toJsonString(t));
        }
        catch (e) {
        }
        return r;
    }
    static dump(e) {
        if (null == e) {
            return;
        }
        if ("object" != typeof e) {
            return;
        }
        this.str = "";
        this.parseObject(e);
    }
    static parseObject(t) {
        if (null != t) {
            return Object.keys(t).forEach((e => {
                t[e] instanceof Array ? (this.str += "\n{\n" + e, this.parseObject(t[e]), this.str += "\n}\n") : t[e] instanceof Object ? this.parseObject(t[e]) : this.str += " [" + e + ":" + t[e] + "]\n";
            })), this.str;
        }
        ToolUtils.str += "null";
    }
    static preLoadGameBundle(e, t, r = true) {
        let a = assetManager.getBundle(e);
        if (a) {
            try {
                r && a && (a.preloadScene(t), a.preloadDir(BundleNameDefined.texture_path, (function (e, t) {
                })), a.preloadDir(BundleNameDefined.prefab_path, (function (e, t) {
                })), a.preloadDir(BundleNameDefined.sound_path, (function (e, t) {
                })));
            }
            catch (e) {
                TLog.printError("ToolUtils preLoadGameBundle error: ${error}");
            }
        }
        else {
            try {
                assetManager.loadBundle(e, null, ((e, a) => {
                    null == e && r && (a && a.preloadScene(t), a.preloadDir(BundleNameDefined.texture_path, (function (e, t) {
                    })), a.preloadDir(BundleNameDefined.prefab_path, (function (e, t) {
                    })), a.preloadDir(BundleNameDefined.sound_path, (function (e, t) {
                    })));
                }));
            }
            catch (e) {
                TLog.printError("ToolUtils preLoadGameBundle error:", e);
            }
        }
    }
    static loadBundleScene(e, t, r) {
        let a = assetManager.getBundle(e);
        if (a) {
            a.loadScene(t, ((e, t) => {
                null == e ? sys.isObjectValid(t) && t.isValid ? r && r(null, t) : r && r("scene is invalid", null) : r && r(e, null);
            }));
        }
        else {
            try {
                assetManager.loadBundle(e, null, ((e, a) => {
                    null == e ? a.loadScene(t, ((e, t) => {
                        null == e ? sys.isObjectValid(t) && t.isValid ? r && r(null, t) : r && r("scene is invalid", null) : r && r(e, null);
                    })) : r && r(e, null);
                }));
            }
            catch (e) {
            }
        }
    }
    static preLoadBundlePrefab(e, t, r) {
        let a = assetManager.getBundle(e);
        return new Promise(a ? (e, n) => {
            try {
                a.load(t, Prefab, ((t, a) => {
                    null == t ? sys.isObjectValid(a) && a.isValid ? r && r(null, a) : r && r("prefab is invalid", null) : r && r(t, null);
                    e(a);
                }));
            }
            catch (e) {
                r && r(e, null);
                n(e);
            }
        } : (a, n) => {
            try {
                assetManager.loadBundle(e, null, ((e, n) => {
                    null == e ? n.load(t, Prefab, ((e, t) => {
                        sys.isObjectValid(t) && t.isValid ? r && r(null, t) : r && r("prefab is invalid", null);
                    })) : r && r(e, null);
                    a(n);
                }));
            }
            catch (e) {
                r && r(e, null);
                n(e);
            }
        });
    }
    static loadBundlePrefab(e, t, r) {
        let a = assetManager.getBundle(e);
        if (a) {
            a.load(t, Prefab, ((e, t) => {
                null == e ? sys.isObjectValid(t) && t.isValid ? r && r(null, t) : r && r("prefab is invalid", null) : r && r(e, null);
            }));
        }
        else {
            try {
                assetManager.loadBundle(e, null, ((e, a) => {
                    null == e ? a.load(t, Prefab, ((e, t) => {
                        sys.isObjectValid(t) && t.isValid ? r && r(null, t) : r && r("prefab is invalid", null);
                    })) : r && r(e, null);
                }));
            }
            catch (e) {
                r && r(e, null);
            }
        }
    }
    static loadCommonPrefab(t, r, a, n) {
        sys.isObjectValid(t) && t.isValid ? n && n(t) : ToolUtils.loadBundlePrefab(r, a, ((e, t) => {
            if (null == e) {
                n && n(t);
            }
            else {
                let e = assetManager.getBundle(r);
                if (e) {
                    e.load(a, Prefab, ((e, t) => {
                        sys.isObjectValid(t) && isValid(t, true) && n && n(t);
                    }));
                }
                else {
                    try {
                        assetManager.loadBundle(r, null, ((e, t) => {
                            null == e && t.load(a, Prefab, ((e, t) => {
                                sys.isObjectValid(t) && isValid(t, true) && n && n(t);
                            }));
                        }));
                    }
                    catch (e) {
                    }
                }
            }
        }));
    }
    static loadRemoteBundle(e, t, r) {
        try {
            let a = assetManager.getBundle(e);
            a ? r && r(a) : assetManager.loadBundle(e, null, ((e, a) => {
                if (undefined !== e) {
                    r && r(a);
                }
                else {
                    if (t.startsWith("http://") || t.startsWith("https://")) {
                        let e = assetManager.getBundle(t);
                        if (e) {
                            r && r(e);
                        }
                        else {
                            try {
                                assetManager.loadBundle(t, { cacheEnabled: true }, ((e, t) => {
                                    null == e && r && r(t);
                                }));
                            }
                            catch (e) {
                            }
                        }
                    }
                }
            }));
        }
        catch (e) {
        }
    }
    static getSubGameBundleName(e) {
        let t = [];
        switch (e) {
            case HallGameType.LOBBY_GAME_TYPE_CRASH:
                t = [BundleNameDefined.Bundle_GameCrash, BundleNameDefined.gamecrash_scene];
                break;
            case HallGameType.LOBBY_GAME_TYPE_SIXDICE:
                t = [BundleNameDefined.Bundle_SixDice, BundleNameDefined.sixdice_scene];
                break;
            case HallGameType.LOBBY_GAME_TYPE_SHUIGUOJI:
                t = [BundleNameDefined.Bundle_FruitMachine, BundleNameDefined.fruitmachine_scene];
                break;
            case HallGameType.LOBBY_GAME_TYPE_LuckBall:
                t = [BundleNameDefined.Bundle_LuckyBall, ""];
                break;
            case HallGameType.LOBBY_GAME_TYPE_YES11:
                t = [BundleNameDefined.Bundle_Yes11, ""];
                break;
            case HallGameType.LOBBY_GAME_TYPE_Ludo: t = [BundleNameDefined.Bundle_ludo, BundleNameDefined.ludo_scence];
        }
        return t;
    }
    static getHallGameType(e) {
        let t = -1;
        switch (e) {
            case CommonGameType.TpPotBlind:
            case CommonGameType.TeenPatti:
            case CommonGameType.TpAK47:
                t = HallGameType.LOBBY_GAME_TYPE_TEENPATTI;
                break;
            case CommonGameType.FruitMachine:
                t = HallGameType.LOBBY_GAME_TYPE_SHUIGUOJI;
                break;
            case CommonGameType.AB:
                t = HallGameType.LOBBY_GAME_TYPE_AB;
                break;
            case CommonGameType.BrTp:
                t = HallGameType.LOBBY_GAME_TYPE_BRTP;
                break;
            case CommonGameType.ClearMines:
                t = HallGameType.LOBBY_GAME_TYPE_CLEARMINES;
                break;
            case CommonGameType.Crash:
                t = HallGameType.LOBBY_GAME_TYPE_CRASH;
                break;
            case CommonGameType.CricketSlot:
                t = HallGameType.LOBBY_GAME_TYPE_CRICKETSLOT;
                break;
            case CommonGameType.LuckBall:
                t = HallGameType.LOBBY_GAME_TYPE_LuckBall;
                break;
            case CommonGameType.Horse:
                t = HallGameType.LOBBY_GAME_TYPE_HORSE;
                break;
            case CommonGameType.LHD:
                t = HallGameType.LOBBY_GAME_TYPE_LHD;
                break;
            case CommonGameType.SevenUp:
                t = HallGameType.LOBBY_GAME_TYPE_7UP;
                break;
            case CommonGameType.SixDice:
                t = HallGameType.LOBBY_GAME_TYPE_SIXDICE;
                break;
            case CommonGameType.Rummy:
                t = HallGameType.LOBBY_GAME_TYPE_RUMMY;
                break;
            case CommonGameType.Yes11:
                t = HallGameType.LOBBY_GAME_TYPE_YES11;
                break;
            case CommonGameType.Ludo: t = HallGameType.LOBBY_GAME_TYPE_Ludo;
        }
        return t;
    }
    static getSubGameResVersion(e) {
        let t = GameConfig.REMOTE_RES_VER;
        switch (e) {
            case HallGameType.LOBBY_GAME_TYPE_SHUIGUOJI:
                t = GameConfig.REMOTE_FRUIT_VER;
                break;
            case HallGameType.LOBBY_GAME_TYPE_SIXDICE:
                t = GameConfig.REMOTE_SIXDICE_VER;
                break;
            case HallGameType.LOBBY_GAME_TYPE_CRASH:
                t = GameConfig.REMOTE_CRASH_VER;
                break;
            case HallGameType.LOBBY_GAME_TYPE_LuckBall: t = GameConfig.REMOTE_WINGO_VER;
        }
        return t;
    }
    static checkIsGameDownLoad(gameType, restore = false) {
        if (gameType === HallGameType.LOBBY_GAME_TYPE_RUMMY || gameType === HallGameType.LOBBY_GAME_TYPE_Ludo) {
            return true;
        }
        const [bundleName] = ToolUtils.getSubGameBundleName(gameType);
        if (!bundleName) return false;
        // A loaded config or the old global hot-update flag does not mean the
        // scene and its native dependencies exist. Only a completed load qualifies.
        const state = ToolUtils._gameLoadInfo[gameType];
        return !!(state && !state.isLoading && state.percent === 1 &&
            ToolUtils.subGameInfo[gameType] === ToolUtils.getDownLoadBundleUrl(gameType) &&
            assetManager.getBundle(bundleName));
    }
    static async startLoadSubGame(gameType, baseUrl, onProgress) {
        const [bundleName, sceneName] = ToolUtils.getSubGameBundleName(gameType);
        if (!bundleName) return false;
        const state = ToolUtils._gameLoadInfo[gameType] || { isLoading: false, percent: 0 };
        ToolUtils._gameLoadInfo[gameType] = state;
        if (state.promise) return state.promise;
        state.isLoading = true;
        state.percent = 0;
        delete ToolUtils.subGameInfo[gameType];
        const report = (value) => {
            state.percent = value;
            if (onProgress) onProgress(value);
        };
        const run = async () => {
            try {
                await OptionalGameResources.prepare(bundleName, value => report(value * 0.8));
                const remote = assetManager.downloader.remoteBundles.indexOf(bundleName) !== -1;
                const target = remote || !baseUrl ? bundleName : baseUrl + bundleName;
                const bundle = assetManager.getBundle(bundleName) || await new Promise((resolve, reject) => {
                    assetManager.loadBundle(target, { cacheEnabled: true }, (err, value) => err ? reject(err) : resolve(value));
                });
                report(0.82);
                if (sceneName) {
                    await new Promise((resolve, reject) => {
                        bundle.loadScene(sceneName, (done, total) => {
                            if (total) report(0.82 + 0.08 * done / total);
                        }, (err, scene) => err ? reject(err) : resolve(scene));
                    });
                }
                // Include audio, prefabs and resources outside texture/. Cached files
                // are reused on relaunch, but missing dependencies are checked again.
                await new Promise((resolve, reject) => {
                    bundle.loadDir("", (done, total) => {
                        if (total) report(0.9 + 0.09 * done / total);
                    }, (err, assets) => err ? reject(err) : resolve(assets));
                });
                ToolUtils.subGameInfo[gameType] = ToolUtils.getDownLoadBundleUrl(gameType);
                state.isLoading = false;
                report(1);
                return true;
            } catch (error) {
                state.isLoading = false;
                state.percent = 0;
                delete ToolUtils.subGameInfo[gameType];
                TLog.printError("Subgame resource download failed:", bundleName, error);
                if (onProgress) onProgress(-1);
                return false;
            } finally {
                state.promise = null;
            }
        };
        state.promise = run();
        return state.promise;
    }
    static versionCompareHandle(e, t) {
        let r = e.split("."), a = t.split(".");
        for (let e = 0, t = r.length; e < t; ++e) {
            let t = parseInt(r[e]), i = parseInt(a[e] || "0");
            if (t !== i) {
                return t - i;
            }
        }
        return a.length > r.length ? -1 : 0;
    }
}
