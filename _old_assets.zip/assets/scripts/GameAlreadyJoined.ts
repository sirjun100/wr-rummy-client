// @ts-nocheck
// Recovered from index.js:147
import { _decorator, Button, instantiate, Label, Node, size, UITransform, v3 } from "cc";
import PushCenter from "./PushCenter";
import PushEvent from "./PushEvent";
import { TLog } from "./TLog";
import HttpManager from "./HttpManager";
import ReportConfig from "./ReportConfig";
import SoundManager from "./SoundManager";
import Utils from "./Utils";
import HowToPlayDefined from "./HowToPlayDefined";
import GameConfig from "./GameConfig";
import i18nMgr from "./i18nMgr";
import BaseLayer from "./BaseLayer";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("GameAlreadyJoined")
export class GameAlreadyJoined extends BaseLayer {
    @property(Node)
    public moban: Node = null;
    @property(Node)
    public contentNode: Node = null;
    public _tableInfoMsg: any = null;
    start() {
        super.start();
        ToolUtils.in_isGuideRoom = 0;
        this.moban.active = false;
        PushCenter.shared().addListener(PushEvent.UpdateGameTableInfoNum, (e => {
            try {
                ToolUtils.isObjValid(this.node) && this.updateList(e);
            }
            catch (e) {
                TLog.printError("UpdateGameTableInfoNum:", e);
            }
        }), this);
        HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Hall, event: ReportConfig.hall_evt.showMyJoinGameList });
    }
    on_close_click(e, t) {
        SoundManager.shared().playFx("click");
        ToolUtils.isObjValid(this.node) && this.node.destroy();
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().removeListenersByTag(this);
    }
    on_items_click(e, t) {
        SoundManager.shared().playFx("click");
        Utils.shared().showLoading(5, true, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("login.net_tip1"), 3, 0, ToolUtils.getIsNormalDirection());
        }));
        let a = Number(t);
        const n = this._tableInfoMsg.tableInfo[a];
        ToolUtils.curRoomId = n.vid;
        let o = null, i = null;
        n.game_type !== HowToPlayDefined.gameId_PrivateRummy && n.game_type != HowToPlayDefined.gameId_PoolPrivateRummy && n.game_type != HowToPlayDefined.gameId_DealsPrivateRummy || (o = { roomid: n.vid, base_money: n.base_money, seat_max: n.pnum });
        n.game_type === HowToPlayDefined.gameId_RaceRummy && (i = n.raceid);
        let l = n.tid_key, s = "";
        if (n.game_type === HowToPlayDefined.gameId_RaceRummy ? s = ReportConfig.hall_evt.click_tournaments_go : n.game_type === HowToPlayDefined.gameId_RummyGame ? s = ReportConfig.hall_evt.click_points : n.game_type === HowToPlayDefined.gameId_PoolRummy ? s = ReportConfig.hall_evt.click_pool : n.game_type === HowToPlayDefined.gameId_DealsRummy ? s = ReportConfig.hall_evt.click_deals : n.game_type === HowToPlayDefined.gameId_PracticeRummy ? s = ReportConfig.hall_evt.click_practice_points : n.game_type === HowToPlayDefined.gameVid_rummyPoint ? s = ReportConfig.hall_evt.click_buddy_points : n.game_type === HowToPlayDefined.gameVid_rummyPool ? s = ReportConfig.hall_evt.click_buddy_pool : n.game_type === HowToPlayDefined.gameVid_rummyDeal && (s = ReportConfig.hall_evt.click_buddy_deals), s.length > 0 && HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Hall, event: s, type: n.mode, cnt: n.pnum, amt: n.base_money, round: n.round || 1, currentRound: n.currentRound || 1 }), PushCenter.shared().pushEvent(GameConfig.Close_Match_Room), ToolUtils.checkIsRummy(n.game_type)) {
            Utils.shared().showLoadTable(n.vid, n.game_type, null, o, 0, l, i);
        }
        else {
            let e = { vid: n.vid, game_type: n.game_type, tid_key: n.tid_key, isNewTable: 0 };
            Utils.shared().showCommEnterGame(e);
        }
        ToolUtils.isObjValid(this.node) && this.node.destroy();
    }
    updateList(e) {
        if (this.contentNode.destroyAllChildren(), !e || 1 === e.ret || null == e.tableInfo || "object" != typeof e.tableInfo || e.tableInfo.length < 1) {
            return void (ToolUtils.isObjValid(this.node) && this.node.destroy());
        }
        this._tableInfoMsg = e;
        let t = this.contentNode.getComponent(UITransform), a = this._tableInfoMsg.tableInfo.length, n = 174 * a;
        n > t.height && t.setContentSize(size(t.width, n));
        for (let e = 0; e < a; e++) {
            const t = this._tableInfoMsg.tableInfo[e];
            let a = instantiate(this.moban);
            a.active = true;
            this.contentNode.addChild(a);
            let n = a.getChildByName("entry").getComponent(Label), o = a.getChildByName("item1").getComponent(Label);
            i18nMgr.shared().changeLabelFont(o);
            t.mode === HowToPlayDefined.RUMMY_POINTS || t.mode === HowToPlayDefined.PRI_POINTS ? o.string = i18nMgr.shared().getValueByKey("my_joined_games.value") : t.mode !== HowToPlayDefined.RUMMY_POOL && t.mode !== HowToPlayDefined.RUMMY_DEALS && t.mode !== HowToPlayDefined.PRI_POOL && t.mode !== HowToPlayDefined.PRI_DEAL || (o.string = i18nMgr.shared().getValueByKey("my_joined_games.entry_fee"));
            o.updateRenderer();
            let i = o.node.getComponent(UITransform).width - 83.58;
            if (a.getChildByName("game_name").getComponent(Label).string = t.game_name + "", t.game_type === HowToPlayDefined.gameId_PracticeRummy || t.game_type === HowToPlayDefined.GameType_PoolPractice || t.game_type === HowToPlayDefined.GameType_DealsPractice ? n.string = "" + ToolUtils.parse_double(t.base_money) : 0 == t.base_money ? n.string = i18nMgr.shared().getValueByKey("tournament.free") : n.string = "₹" + ToolUtils.parse_double(t.base_money), t.game_type === HowToPlayDefined.gameId_RaceRummy) {
                a.getChildByName("item2").active = false;
                a.getChildByName("players").active = false;
                a.getChildByName("item1").setPosition(v3(-260, -15));
                a.getChildByName("entry").setPosition(v3(-166 + i, -15));
            }
            else {
                a.getChildByName("item2").active = true;
                a.getChildByName("players").active = true;
                a.getChildByName("item1").setPosition(v3(-260, 8));
                a.getChildByName("entry").setPosition(v3(-166 + i, 8));
                a.getChildByName("players").getComponent(Label).string = "" + t.pnum;
            }
            a.getChildByName("take_seat").getComponent(Button).clickEvents[0].customEventData = "" + e;
        }
    }
}
