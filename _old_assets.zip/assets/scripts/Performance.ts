// @ts-nocheck
// Recovered from index.js:341
import { _decorator, Button, color, game, isValid, Label, Node, ScrollView, Sprite, SpriteFrame, sys, UITransform, v3, Widget } from "cc";
import SoundManager from "./SoundManager";
import TableViewUtils from "./TableViewUtils";
import HttpManager from "./HttpManager";
import Utils from "./Utils";
import { HttpRequest } from "./HttpRequestName";
import BaseLayer from "./BaseLayer";
import PushCenter from "./PushCenter";
import PushEvent from "./PushEvent";
import User from "./User";
import i18nMgr from "./i18nMgr";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("Performance")
export class Performance extends BaseLayer {
    @property(ScrollView)
    public scrollview: ScrollView = null;
    @property(Node)
    public moban: Node = null;
    @property([SpriteFrame])
    public gameIconSprite: SpriteFrame[] = [];
    @property(Node)
    public no_dataNode: Node = null;
    @property(Node)
    public siftNode: Node = null;
    @property([Node])
    public siftSelectNodes: Node[] = [];
    @property([Node])
    public siftTypeNodes: Node[] = [];
    @property([Node])
    public siftGameNodes: Node[] = [];
    @property([Node])
    public siftTimeNodes: Node[] = [];
    @property([SpriteFrame])
    public goldIconSprites: SpriteFrame[] = [];
    public historyTabView: any = null;
    public page: number = 0;
    public callback: any = null;
    public last_row_times: number = 0;
    public tab_type: number = 0;
    public tab_game: number = 0;
    public tab_time: number = 0;
    public has_next_page: number = 0;
    public lastClick: number = 0;
    setCallBack(e) {
        this.callback = e;
    }
    start() {
        super.start();
        ToolUtils.adaptSafeArea(this.node.getChildByName("root"));
        this.siftNode.getChildByName("mask").getComponent(Widget).bottom = -ToolUtils.getSafeDistance();
        this.siftNode.active = false;
        this.scrollview.node.getComponent(Widget).bottom = -ToolUtils.getSafeDistance();
        this.moban.active = false;
        let e = [this.moban];
        this.historyTabView = this.node.addComponent(TableViewUtils);
        let t = this.moban.getComponent(UITransform).height;
        this.scrollview.node.getComponent(Widget).updateAlignment();
        this.historyTabView.init([], this.scrollview.node, e, this.initCurMobanCallBack.bind(this), 0, t, this.scrollRefreshCallBack.bind(this));
        sys.isObjectValid(User.shared().performanceData) ? (this.no_dataNode.active = User.shared().performanceData.length < 1, this.tab_type = User.shared().performanceSiftStatus.tab_type ? User.shared().performanceSiftStatus.tab_type : 0, this.tab_game = User.shared().performanceSiftStatus.tab_game ? User.shared().performanceSiftStatus.tab_game : 0, this.tab_time = User.shared().performanceSiftStatus.tab_time ? User.shared().performanceSiftStatus.tab_time : 0, this.updateSiftStatus(), this.updateSelectLabel(), this.refreshRecode()) : (User.shared().performanceData = [], this.scheduleOnce((() => {
            this.requestGameRecodePage();
        }), game.frameTime / 1000 * 3));
    }
    onDestroy() {
        super.onDestroy();
        this.unscheduleAllCallbacks();
        PushCenter.shared().removeListenersByTag(this);
    }
    onBackView() {
        ToolUtils.isObjValid(this.node) && (this.siftNode.active ? this.siftNode.active = false : (User.shared().performanceData = null, User.shared().performanceSiftStatus = [], this.callback && this.callback(), this.node.destroy()));
    }
    requestGameRecodePage() {
        let e = (new Date).getTime(), t = this.tab_time;
        if (this.tab_time > 0) {
            t = e - 86400 * (this.tab_time - 1) * 1000;
        }
        let i = { type: this.tab_type, game: this.tab_game, filter_time: t, last_row_times: this.last_row_times };
        Utils.shared().showLoading(10, false, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3);
        }));
        HttpManager.shared().doGetCommonRequest(i, HttpRequest.GameRecodeData, this.listenGetGameRecodePageback.bind(this));
    }
    listenGetGameRecodePageback(e, t, i) {
        if (Utils.shared().hideLoading(), 0 != t.length) {
            if (200 != i) {
                User.shared().performanceData.length >= 1 ? this.no_dataNode.active = false : this.no_dataNode.active = true;
                alert("The login timed out, please try again");
            }
            else {
                let e = ToolUtils.parseJson(t);
                if (0 == e.ret && isValid(this)) {
                    if (this.last_row_times = ToolUtils.isSafeNumber(e.data.last_row_times), undefined !== e.data.has_next_page && (this.has_next_page = e.data.has_next_page), null == e.data.list && User.shared().performanceData.length < 1) {
                        User.shared().performanceData = [];
                        this.no_dataNode.active = true;
                    }
                    else {
                        if (Array.isArray(e.data.list) && e.data.list.length > 0) {
                            for (let t = 0, i = e.data.list.length; t < i; t++) {
                                User.shared().performanceData.push(e.data.list[t]);
                            }
                        }
                        this.no_dataNode.active = User.shared().performanceData.length < 1;
                    }
                    this.refreshRecode();
                }
            }
        }
        else {
            User.shared().performanceData.length >= 1 ? this.no_dataNode.active = false : this.no_dataNode.active = true;
        }
    }
    refreshRecode() {
        this.historyTabView.reloadData(User.shared().performanceData, false);
    }
    scrollRefreshCallBack() {
        0 !== this.has_next_page && this.requestGameRecodePage();
    }
    initCurMobanCallBack(e, t) {
        if (null == t) {
            return;
        }
        e.active = true;
        e.getComponent(Button).clickEvents[0].customEventData = t;
        e.getChildByName("video_btn").getComponent(Button).clickEvents[0].customEventData = t;
        let i = e.getChildByName("imageNodes"), a = i.getChildByName("icon").getComponent(Sprite), s = e.getChildByName("LabelNodes"), o = s.getChildByName("name").getComponent(Label), n = s.getChildByName("goldnum").getComponent(Label), r = s.getChildByName("playernum").getComponent(Label), l = s.getChildByName("score").getComponent(Label), h = s.getChildByName("time").getComponent(Label), m = i.getChildByName("gold").getComponent(Sprite);
        a.spriteFrame = this.gameIconSprite[t.icon - 1];
        o.string = t.game_name;
        n.string = t.base_money;
        r.string = t.player_count_text;
        l.string = t.winnings;
        h.string = t.date;
        let c = "₹";
        25 == t.gtype && (c = "");
        t.winnings > 0 ? (l.string = "+" + c + ToolUtils.parse_double(t.winnings + ""), l.color = color(0, 131, 21)) : (l.string = "-" + c + ToolUtils.parse_double(Math.abs(Number(t.winnings)) + ""), l.color = color(203, 41, 50));
        1 == User.shared().temp_pingbi.performance_playback && (i.getChildByName("video").active = false, e.getChildByName("video_btn").active = false, s.getChildByName("score").setPosition(v3(320, -42)), s.getChildByName("time").setPosition(v3(320, -84)));
        let y = 0;
        25 == t.gtype && (y = 1);
        sys.isObjectValid(this.goldIconSprites[y]) && (m.spriteFrame = this.goldIconSprites[y]);
    }
    onButtonClick(e, t) {
        if (SoundManager.shared().playFx("click"), "close" === t) {
            User.shared().performanceData = null;
            User.shared().performanceSiftStatus = [];
            this.onBackView();
        }
        else if ("sift" === t) {
            let e = this.siftNode.active;
            this.siftNode.active = !e;
            this.initSifeTimeLabels();
            this.updateSiftStatus();
        }
        else {
            "close_sift" === t ? this.siftNode.active = false : "reset" === t ? (this.tab_type = 0, this.tab_game = 0, this.tab_time = 0, User.shared().performanceSiftStatus.tab_type = 0, User.shared().performanceSiftStatus.tab_game = 0, User.shared().performanceSiftStatus.tab_time = 0, this.updateSiftStatus(), this.updateSelectLabel()) : ("confirm" === t ? (this.siftNode.active = false, this.updateSelectLabel()) : "type_delete" === t ? (this.tab_type = 0, User.shared().performanceSiftStatus.tab_type = 0, this.updateSiftStatus(), this.updateSelectLabel()) : "game_delete" === t ? (this.tab_game = 0, User.shared().performanceSiftStatus.tab_game = 0, this.updateSiftStatus(), this.updateSelectLabel()) : "time_delete" === t && (this.tab_time = 0, User.shared().performanceSiftStatus.tab_time = 0, this.updateSiftStatus(), this.updateSelectLabel()), this.last_row_times = 0, User.shared().performanceData = [], this.requestGameRecodePage());
        }
    }
    initSifeTimeLabels() {
        let e, t, i, a, s, o, n;
        for (let r = 1, l = this.siftTimeNodes.length; r < l; r++) {
            e = new Date;
            t = this.siftTimeNodes[r].getChildByName("wz");
            s = e.getTime();
            o = 86400 * (r - 1) * 1000;
            n = s - o;
            e.setTime(n);
            i = e.getMonth() + 1;
            a = e.getDate();
            t.getComponent(Label).string = String("0" + a).slice(-2) + "/" + String("0" + i).slice(-2);
        }
    }
    updateSelectLabel() {
        let e = -330, t = false, i = "";
        for (let a = 0, s = this.siftSelectNodes.length; a < s; a++) {
            t = false;
            i = "";
            0 == a && 0 != this.tab_type ? (t = true, i = this.siftTypeNodes[this.tab_type].getChildByName("wz").getComponent(Label).string) : 1 == a && 0 != this.tab_game ? (t = true, i = this.siftGameNodes[this.tab_game].getChildByName("wz").getComponent(Label).string) : 2 == a && 0 != this.tab_time && (t = true, i = this.siftTimeNodes[this.tab_time].getChildByName("wz").getComponent(Label).string);
            this.siftSelectNodes[a].active = t;
            t && (this.siftSelectNodes[a].getComponent(Label).string = i, this.siftSelectNodes[a].getComponent(Label).updateRenderData(true), this.siftSelectNodes[a].setPosition(v3(e, -44)), e = e + this.siftSelectNodes[a].getComponent(UITransform).width + 60);
        }
    }
    onSiftTypeClick(e, t) {
        SoundManager.shared().playFx("click");
        this.tab_type = Number(t);
        User.shared().performanceSiftStatus.tab_type = Number(t);
        this.updateSiftStatus();
    }
    onSiftGameClick(e, t) {
        SoundManager.shared().playFx("click");
        this.tab_game = Number(t);
        User.shared().performanceSiftStatus.tab_game = Number(t);
        this.updateSiftStatus();
    }
    onSiftTimeClick(e, t) {
        SoundManager.shared().playFx("click");
        this.tab_time = Number(t);
        User.shared().performanceSiftStatus.tab_time = Number(t);
        this.updateSiftStatus();
    }
    updateSiftStatus() {
        if (this.siftTypeNodes && this.siftTypeNodes.length > 0) {
            for (let e = 0, t = this.siftTypeNodes.length; e < t; e++) {
                this.tab_type == e ? (this.siftTypeNodes[e].getComponent(Button).interactable = false, this.siftTypeNodes[e].getChildByName("wz").getComponent(Label).color = color(72, 113, 231)) : (this.siftTypeNodes[e].getComponent(Button).interactable = true, this.siftTypeNodes[e].getChildByName("wz").getComponent(Label).color = color(49, 49, 49));
            }
        }
        if (this.siftGameNodes && this.siftGameNodes.length > 0) {
            for (let e = 0, t = this.siftGameNodes.length; e < t; e++) {
                this.tab_game == e ? (this.siftGameNodes[e].getComponent(Button).interactable = false, this.siftGameNodes[e].getChildByName("wz").getComponent(Label).color = color(72, 113, 231)) : (this.siftGameNodes[e].getComponent(Button).interactable = true, this.siftGameNodes[e].getChildByName("wz").getComponent(Label).color = color(49, 49, 49));
            }
        }
        if (this.siftTimeNodes && this.siftTimeNodes.length > 0) {
            for (let e = 0, t = this.siftTimeNodes.length; e < t; e++) {
                this.tab_time == e ? (this.siftTimeNodes[e].getComponent(Button).interactable = false, this.siftTimeNodes[e].getChildByName("wz").getComponent(Label).color = color(72, 113, 231)) : (this.siftTimeNodes[e].getComponent(Button).interactable = true, this.siftTimeNodes[e].getChildByName("wz").getComponent(Label).color = color(49, 49, 49));
            }
        }
    }
    onItemClick(e, t) {
        SoundManager.shared().playFx("click");
        let i = { gtype: t.gtype, game_id: t.game_id, game_time: t.game_time };
        Utils.shared().showLoading(10, false, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3);
        }));
        3 == t.gtype || 27 == t.gtype || 38 == t.gtype ? HttpManager.shared().doGetCommonRequest(i, HttpRequest.GameRecodeeDetail, this.listenGetGameRecodeback.bind(this)) : HttpManager.shared().doGetCommonRequest(i, HttpRequest.GameRecodeInfo, this.listenGetGameRecodeback.bind(this));
    }
    listenGetGameRecodeback(e, t, i) {
        if (Utils.shared().hideLoading(), 0 != t.length) {
            if (200 != i) {
                alert("The login timed out, please try again");
            }
            else {
                try {
                    let e = ToolUtils.parseJson(t);
                    0 == e.ret ? ToolUtils.isObjValid(this.node) && (User.shared().detalisData = e.data, PushCenter.shared().pushEvent(PushEvent.showRecodeDetailsView, e.data)) : e.desc && e.desc.length > 0 && Utils.shared().showToast(e.desc, 2);
                }
                catch (e) {
                }
            }
        }
    }
    onItemVideoClick(e, t) {
        if (SoundManager.shared().playFx("click"), !(sys.now() - this.lastClick < 1000)) {
            if (this.lastClick = sys.now(), t.movie_round > 0) {
                if (1 == Utils.shared().showFastKyc()) {
                    return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("kyc.kyc_performance"), 2);
                }
                PushCenter.shared().pushEvent(PushEvent.rummyPlayback, { game_id: t.game_id, round: t.movie_round });
            }
            else {
                Utils.shared().showToast("No replay available for the current game", 2);
            }
        }
    }
}
