// @ts-nocheck
// Recovered from index.js:145
import { _decorator, Button, color, Label, Node, ScrollView, size, Sprite, sys, UITransform, v2, v3, Widget } from "cc";
import SoundManager from "./SoundManager";
import { TLog } from "./TLog";
import BaseLayer from "./BaseLayer";
import Utils from "./Utils";
import PushCenter from "./PushCenter";
import PushEvent from "./PushEvent";
import User from "./User";
import i18nMgr from "./i18nMgr";
import { ToolUtils } from "./ToolUtils";
import TableViewUtils from "./TableViewUtils";
import HttpManager from "./HttpManager";
import { HttpRequest } from "./HttpRequestName";
import TweenTool from "./TweenTool";
import GameConfig from "./GameConfig";
const { ccclass, property } = _decorator;
@ccclass("GameActLeaderBoard")
export class GameActLeaderBoard extends BaseLayer {
    @property(Node)
    public rootNode: Node = null;
    @property(Node)
    public tipsNode: Node = null;
    @property(Node)
    public optInSuccNode: Node = null;
    @property(Node)
    public rankListNode: Node = null;
    @property(Node)
    public selectTabView: Node = null;
    @property(ScrollView)
    public scrollview: ScrollView = null;
    @property(Node)
    public moban: Node = null;
    @property([Node])
    public tabNodes: Node[] = [];
    public rankTable: any = null;
    public _hasFanAnim: boolean = false;
    public _cur_vid: number = 0;
    public _canhasShowPop: boolean = false;
    public pageData: any = null;
    public left_timeArr: any[] = [0, 0, 0];
    public status: number = 0;
    public tid_key: any = null;
    public total_prize: string = "";
    public hasRefresh: boolean = false;
    public rank_type: string = "daily";
    public _tabIndex: number = 0;
    public _isSendMsg: boolean = false;
    public has_next_page: number = 0;
    public cur_page: number = 1;
    public rank_listData: any[] = [];
    public myRankData: any = null;
    public auto_entry_status: number = 0;
    public tabWzColor: any = color(147, 11, 11, 255);
    onLoad() {
        this.fitLuckyTheme();
    }
    start() {
        this.adapptationScreen();
        PushCenter.shared().addListener(PushEvent.CloseRoomRankAct, (() => {
            ToolUtils.isObjValid(this.node) && this.onBackView();
        }), this);
    }
    fitLuckyTheme() {
        0 != GameConfig.NATIVE_GAME_APP_TYPE && (this.tabWzColor = color(221, 3, 3, 255), this.selectTabView.getChildByName("diban").getComponent(Sprite).color = color(250, 250, 250, 255), this.selectTabView.getChildByName("hour_tab").getChildByName("line").getComponent(Sprite).color = color(221, 3, 3, 255), this.selectTabView.getChildByName("hour_tab").getChildByName("line").getComponent(Sprite).color = color(221, 3, 3, 255), this.selectTabView.getChildByName("daily_tab").getChildByName("line").getComponent(Sprite).color = color(221, 3, 3, 255), this.selectTabView.getChildByName("mega_tab").getChildByName("line").getComponent(Sprite).color = color(221, 3, 3, 255));
    }
    refreshTabView(t) {
        for (let e = 0, i = this.tabNodes.length; e < i; e++) {
            let i = this.tabNodes[e], a = i.getChildByName("Label"), s = i.getChildByName("line");
            e == t ? (i.getComponent(Button).interactable = false, a.getComponent(Label).color = this.tabWzColor, s.active = true, i18nMgr.shared().changeLabelFont(a.getComponent(Label), true)) : (i.getComponent(Button).interactable = true, a.getComponent(Label).color = color(102, 102, 102, 255), s.active = false, i18nMgr.shared().changeLabelFont(a.getComponent(Label), false));
        }
        this._tabIndex = t;
        this.refreshTopInfo(this.pageData);
    }
    refreshTopInfo(t) {
        0 != this.status && (sys.isObjectValid(t) && sys.isObjectValid(t.hour_reward) && (this.tabNodes[0].getChildByName("Label").getComponent(Label).string = `Hour ${t.hour_reward}`), sys.isObjectValid(t) && sys.isObjectValid(t.day_reward) && (this.tabNodes[1].getChildByName("Label").getComponent(Label).string = `Day ${t.day_reward}`), sys.isObjectValid(t) && sys.isObjectValid(t.total_reward) && (this.rankListNode.getChildByName("deta").getComponent(Label).string = `${t.total_reward} ${t.cycle_tips}`), sys.isObjectValid(t) && sys.isObjectValid(t.total_reward) && (this.rankListNode.getChildByName("deta").getComponent(Label).string = `${t.total_reward} ${t.cycle_tips}`), 0 == User.shared().data.is_new_rank ? (sys.isObjectValid(t.hour_left_time) && t.hour_left_time > 0 && (this.left_timeArr[0] = t.hour_left_time), sys.isObjectValid(t.daily_left_time) && t.daily_left_time > 0 && (this.left_timeArr[1] = t.daily_left_time), sys.isObjectValid(t.mega_left_time) && t.mega_left_time > 0 && (this.left_timeArr[2] = t.mega_left_time)) : sys.isObjectValid(t.left_time) && t.left_time > 0 && (this.left_timeArr[0] = t.left_time), TweenTool.stopNodeAction(this.rankListNode.getChildByName("end_time")), this.left_timeArr[this._tabIndex] > 0 ? (TweenTool.stopNodeAction(this.rankListNode.getChildByName("end_time")), this.rankListNode.getChildByName("end_time").getComponent(Label).string = Utils.shared().getCountDownString(this.left_timeArr[this._tabIndex]), this.rankListNode.getChildByName("end_time").active = true, TweenTool.myschedule(this.rankListNode.getChildByName("end_time"), 1, (() => {
            ToolUtils.isObjValid(this.node) && (this.left_timeArr[this._tabIndex] > 0 ? (this.rankListNode.getChildByName("end_time").active = true, this.left_timeArr[this._tabIndex] = this.left_timeArr[this._tabIndex] - 1, this.rankListNode.getChildByName("end_time").getComponent(Label).string = Utils.shared().getCountDownString(this.left_timeArr[this._tabIndex])) : (this.rankListNode.getChildByName("end_time").active = false, TweenTool.stopNodeAction(this.rankListNode.getChildByName("end_time"))));
        }))) : this.rankListNode.getChildByName("end_time").active = false);
    }
    requestActRankGetRoomPage() {
        let t = { type: this.rank_type, vid: this._cur_vid, page: this.cur_page, is_click: 1 }, e = HttpRequest.RoomRankActGetRoomPage;
        1 == User.shared().data.is_new_rank && (e = HttpRequest.RoomRankNewPlayerActGetRoomPage);
        HttpManager.shared().doGetCommonRequest(t, e, ((e, i, a) => {
            if (Utils.shared().hideLoading(), 200 != a) {
                Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.request_fail"), 2);
                ToolUtils.isObjValid(this.node) && (this._isSendMsg = false, this.cur_page > 1 && (this.cur_page = this.cur_page - 1), (this.cur_page = 1) && this.rankTable.reloadData([]));
            }
            else {
                try {
                    let e = ToolUtils.parseJson(i);
                    if (0 == e.ret && sys.isObjectValid(e.data) && ToolUtils.isObjValid(this.node)) {
                        if (sys.isObjectValid(t) && sys.isObjectValid(t.vid)) {
                            let i = t.vid;
                            1 == this.cur_page && "hour" == this.rank_type && User.shared().roomActRankDataMap.set(i, e.data);
                        }
                        if (sys.isObjectValid(e.data.page) && (this.cur_page = e.data.page), 1 == this.cur_page && (this.rank_listData = [], sys.isObjectValid(e.data.my_rank_info) && (this.myRankData = e.data.my_rank_info, this.rank_listData.push(this.myRankData))), sys.isObjectValid(e.data.has_next_page) && (this.has_next_page = e.data.has_next_page), sys.isObjectValid(e.data.rank_list) && Array.isArray(e.data.rank_list) && e.data.rank_list.length > 0) {
                            for (let t = 0, i = e.data.rank_list.length; t < i; t++) {
                                this.rank_listData.push(e.data.rank_list[t]);
                            }
                        }
                        this.scrollview.stopAutoScroll();
                        1 == this.cur_page && this.scrollview.scrollToTop(0);
                        this.rankTable.reloadData(this.rank_listData, 1 == this.cur_page);
                        this.refreshTopInfo(e.data);
                        TweenTool.delayAct(this.node, (() => {
                            this._isSendMsg = false;
                        }), 0.5, true);
                    }
                }
                catch (t) {
                    TLog.printError("requestActRankGetRoomPage err:", t.toString());
                }
            }
        }));
    }
    scrollRefreshCallBack() {
        1 != this.has_next_page || this._isSendMsg || (this._isSendMsg = true, this.cur_page = this.cur_page + 1, this.scrollview.stopAutoScroll(), this.requestActRankGetRoomPage());
    }
    initRankItem(t, e, i) {
        if (null == e) {
            return;
        }
        t.active = true;
        let a = t.getChildByName("bg"), s = t.getChildByName("rank").getComponent(Label), n = t.getChildByName("name").getComponent(Label), o = t.getChildByName("score").getComponent(Label), l = t.getChildByName("reward").getComponent(Label), _ = t.getChildByName("rank").getChildByName("up_root");
        if (_.active = false, 0 == i ? (a.getComponent(Sprite).color = color(148, 42, 35), s.color = color(255, 255, 255), n.color = color(255, 255, 255), o.color = color(255, 255, 255), l.color = color(255, 255, 255)) : (a.getComponent(Sprite).color = color(240, 240, 240), s.color = color(51, 51, 51), n.color = color(51, 51, 51), o.color = color(51, 51, 51), l.color = color(51, 51, 51)), o.string = String(e.points), sys.isObjectValid(e.name) && (n.getComponent(Label).string = ToolUtils.GetShortName2(ToolUtils.isSafeString(e.name), 7, true)), sys.isObjectValid(e.bmoney) && (l.getComponent(Label).string = "₹" + e.bmoney), sys.isObjectValid(e.is_me) && 1 == e.is_me && (n.getComponent(Label).string = "Me", 0 != i && (a.getComponent(Sprite).color = color(251, 245, 225))), sys.isObjectValid(e.rank)) {
            let t = Number(e.rank);
            0 == t ? (s.node.active = true, s.string = "-") : (s.node.active = true, s.string = "" + t);
        }
        else {
            s.node.active = true;
            s.string = "-";
        }
        s.updateRenderData(true);
        0 == i && sys.isObjectValid(e.up_rank) && e.up_rank > 0 && (_.active = true, _.getChildByName("name").getComponent(Label).string = "" + e.up_rank, _.getComponent(Widget).updateAlignment());
        Utils.shared().updateHeadImg(t.getChildByName("head_mask").getChildByName("head_img"), e.avatar, e.avatar, size(45, 45));
    }
    refreshUI() {
        if (User.shared().roomActRankDataMap.has(this._cur_vid) && User.shared().roomActRankDataMap.get(this._cur_vid)) {
            let t = User.shared().roomActRankDataMap.get(this._cur_vid);
            if (sys.isObjectValid(t)) {
                this.hasRefresh = true;
                this.pageData = t;
                let e = ToolUtils.isSafeNumber(t.entry_status);
                this.status = e;
                this.refreshStatusBtn();
                1 == this.status && this.refreshRankList(t);
            }
        }
    }
    refreshRankList(t) {
        sys.isObjectValid(t) && sys.isObjectValid(t.rank_list) && (sys.isObjectValid(t.page) && (this.cur_page = t.page), 1 == this.cur_page && (this.rank_listData = [], sys.isObjectValid(t.my_rank_info) && (this.myRankData = t.my_rank_info, this.rank_listData.push(this.myRankData))), Array.isArray(t.rank_list) && t.rank_list.length > 0 && (this.rank_listData = this.rank_listData.concat(t.rank_list)), this.rankTable.reloadData(this.rank_listData), sys.isObjectValid(t.has_next_page) && (this.has_next_page = t.has_next_page));
    }
    refreshStatusBtn() {
        if (0 == this.status) {
            let t = this.tipsNode.active;
            this.tipsNode.active = true;
            this.tipsNode.getChildByName("total_prize").getComponent(Label).string = ToolUtils.format("${0}", this.pageData.total_reward);
            this.tipsNode.getChildByName("tips").getComponent(Label).string = ToolUtils.format("*Fees: ${0} of cash game winnings", this.pageData.ratio);
            this.tipsNode.getChildByName("deta").getComponent(Label).string = ToolUtils.format("${0}", this.pageData.cycle_tips);
            sys.isObjectValid(this.pageData.left_time) && this.pageData.left_time > 0 ? (TweenTool.stopNodeAction(this.tipsNode.getChildByName("end_time")), TweenTool.myschedule(this.tipsNode.getChildByName("end_time"), 1, (() => {
                ToolUtils.isObjValid(this.node) && (this.pageData.left_time > 0 ? (this.pageData.left_time = this.pageData.left_time - 1, this.tipsNode.getChildByName("end_time").getComponent(Label).string = Utils.shared().getCountDownString(this.pageData.left_time)) : TweenTool.stopNodeAction(this.tipsNode.getChildByName("end_time")));
            }))) : this.tipsNode.getChildByName("end_time").getComponent(Label).string = "00:00:00";
            t || ToolUtils.startShowAnim(this.tipsNode);
        }
        else {
            this.tipsNode.active = false;
        }
        this.optInSuccNode.active = false;
        1 == this.status && (this.rankListNode.active = true, this.refreshTabView(this._tabIndex));
    }
    adapptationScreen() {
        ToolUtils.showFullScreen(this.rootNode);
        let t = sys.getSafeAreaRect().x;
        t > 0 && (this.rankListNode.getComponent(Widget).left = 132 + t, this.rankListNode.getComponent(Widget).updateAlignment());
        0 == User.shared().data.is_new_rank ? (this.selectTabView.active = true, this.scrollview.node.setPosition(v3(68.484, 148.391)), this.rankListNode.getChildByName("list_title").setPosition(v3(54.254, 144.925)), this.scrollview.node.getComponent(UITransform).contentSize = size(450, 360), this.scrollview.node.getChildByName("view").getComponent(Widget).updateAlignment()) : (this.selectTabView.active = false, this.rankListNode.getChildByName("list_title").setPosition(v3(54.254, 217.925)), this.scrollview.node.setPosition(v3(68.484, 221.391)), this.scrollview.node.getComponent(UITransform).contentSize = size(450, 433), this.scrollview.node.getChildByName("view").getComponent(Widget).updateAlignment());
    }
    initParaData(t) {
        sys.isObjectValid(t) && (sys.isObjectValid(t.vid) && (this._cur_vid = t.vid), sys.isObjectValid(t.tid_key) && (this.tid_key = t.tid_key));
        let e = [this.moban];
        this.node.getComponent(TableViewUtils) || (this.rankTable = this.node.addComponent(TableViewUtils));
        let i = this.moban.getComponent(UITransform).height;
        this.rankTable.init([], this.scrollview.node, e, this.initRankItem.bind(this), 10, i, this.scrollRefreshCallBack.bind(this));
        this.node.active = true;
        this._tabIndex = 0;
        this.rank_type = "hour";
        this.refreshUI();
        this.refreshTabView(0);
        User.shared().requestActRankGetRoomPage({ vid: this._cur_vid, type: "hour", page: 1 }, (t => {
            ToolUtils.isObjValid(this.node) && (!t && this.hasRefresh || (this.refreshUI(), this.refreshTabView(0)));
        }));
    }
    update(t) {
    }
    onButtonClick(t, e) {
        switch ((SoundManager.shared().playFx("click"), String(e))) {
            case "close":
            case "ok":
            case "continue":
                this.onBackView();
                break;
            case "auto_switch": break;
            case "opt_in_process":
                this.tipsNode.active = false;
                break;
            case "opt_in":
                User.shared().dealLeadboardLogic_OptIn((t => {
                    ToolUtils.isObjValid(this.node) && (this.status = t, 1 == this.status && (this.tipsNode.active = false, this.optInSuccNode.active = true, ToolUtils.startShowAnim(this.optInSuccNode)));
                }));
                break;
            case "add_table":
                PushCenter.shared().pushEvent(PushEvent.ShowAddTableView), this.onBackView();
                break;
            case "end":
                Utils.shared().showToast("The next event is coming soon", 2);
                break;
            case "hour":
                this.refreshTabView(0), this.rank_type = "hour", this.refreshListUI();
                break;
            case "daily":
                this.refreshTabView(1), this.rank_type = "daily", this.refreshListUI();
                break;
            case "mega": this.refreshTabView(2), this.rank_type = "cycle", this.refreshListUI();
        }
    }
    refreshListUI() {
        this.scrollview.scrollToOffset(v2(0, 0));
        this.rank_listData = [];
        this.cur_page = 1;
        this._isSendMsg = false;
        this.requestActRankGetRoomPage();
    }
    onBackView() {
        ToolUtils.isObjValid(this.node) && this.node.destroy();
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().removeListenersByTag(this);
    }
}
