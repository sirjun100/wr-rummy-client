// @ts-nocheck
// Recovered from index.js:25
import { _decorator, Button, instantiate, Label, Node, ScrollView, Sprite, SpriteFrame, sys, Widget } from "cc";
import i18nMgr from "./i18nMgr";
import Utils from "./Utils";
import User from "./User";
import SoundManager from "./SoundManager";
import BaseLayer from "./BaseLayer";
import PushCenter from "./PushCenter";
import PushEvent from "./PushEvent";
import { BagItemType, CheckModule } from "./CommDefine";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("Bag")
export default class Bag extends BaseLayer {
    public TAG: string = "Bag";
    @property(Node)
    public rootNode: Node = null;
    @property(Node)
    public scrollViewNode: Node = null;
    @property(Node)
    public topNode: Node = null;
    @property(Node)
    public prop_item: Node = null;
    @property(Node)
    public infoNode: Node = null;
    @property(Node)
    public no_itemNode: Node = null;
    @property([SpriteFrame])
    public smallPropImages: SpriteFrame[] = [];
    @property([SpriteFrame])
    public bigPropIamges: SpriteFrame[] = [];
    public isNext: boolean = false;
    public prop_infos: any[] = [];
    public propItems: any[] = [];
    public max_num: number = 40;
    public selectIndex: number = 0;
    public roomInfo: any = null;
    onLoad() {
    }
    start() {
        super.start();
        this.initView();
    }
    reqBagPackPage() {
        User.shared().requestBagPackPage((e => {
            if (sys.isObjectValid(e) && ToolUtils.isObjValid(this.node)) {
                let t = true, i = ToolUtils.jsonToMd5(e);
                if (sys.isObjectValid(User.shared().backPackData)) {
                    i == ToolUtils.jsonToMd5(User.shared().backPackData) && (t = false);
                }
                t && (User.shared().backPackData = e, this.refreshPageUI());
            }
        }));
    }
    onBackView() {
        ToolUtils.isObjValid(this.node) && (this.isNext && PushCenter.shared().pushEvent(PushEvent.Update_NextPopActivity), this.node.destroy());
    }
    initData(e) {
    }
    button_click(e, t) {
        if (SoundManager.shared().playFx("click"), "play_now" === t) {
            if (!User.shared().checkCanPlayCashGame(CheckModule.CASH_PLAY)) {
                return;
            }
            let e = 0, t = 0, i = 0;
            if (sys.isObjectValid(this.roomInfo) && (e = ToolUtils.isSafeNumber(this.roomInfo.vid), undefined !== this.roomInfo.entry && (t = this.roomInfo.entry), ToolUtils.isObjValid(this.roomInfo.mode) && (i = this.roomInfo.mode)), User.shared().data.money < t) {
                return void Utils.shared().showQuickRecharge(e, null, true, "", 0, t, true, 0, 1);
            }
            let o = { gameType: 0, rummyType: i, roomInfo: this.roomInfo };
            User.shared().enterGame(o);
        }
    }
    prop_item_click(e, t) {
        SoundManager.shared().playFx("click");
        this.selectIndex = Number(t);
        this.refreshSelectPropItem();
        this.refreshTopBigPropItem();
    }
    refreshSelectPropItem() {
        for (let e = 0; e < this.prop_infos.length; e++) {
            if (this.propItems[e]) {
                this.propItems[e].getChildByName("select").active = e == this.selectIndex;
            }
        }
    }
    refreshTopBigPropItem() {
        let e = this.infoNode.getChildByName("name"), t = this.infoNode.getChildByName("expire_date"), i = this.infoNode.getChildByName("tips"), o = this.infoNode.getChildByName("prop"), s = this.infoNode.getChildByName("play_btn"), r = o.getChildByName("icon"), a = o.getChildByName("top_num");
        if (this.prop_infos.length > this.selectIndex) {
            let o = this.prop_infos[this.selectIndex];
            this.roomInfo = o.room_info;
            let n = o.title + "", c = o.content + "", p = o.expire_text + "", d = o.rate, m = Number(o.reward_type), u = true;
            e.getComponent(Label).string = n;
            t.getComponent(Label).string = p;
            i.getComponent(Label).string = c;
            a.getComponent(Label).string = d + "";
            let f = -1;
            switch (m) {
                case BagItemType.BonusAdd:
                    f = 0;
                    break;
                case BagItemType.LuckyLeaf:
                    u = false, f = 1;
                    break;
                case BagItemType.TreasureKey: u = false, f = 2;
            }
            s.active = u;
            f >= 0 && this.bigPropIamges[f] && (r.getComponent(Sprite).spriteFrame = this.bigPropIamges[f]);
        }
    }
    initView() {
        this.fitScreen();
        User.shared().backPackData ? this.refreshPageUI() : Utils.shared().showLoading(10, false, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
        }));
        this.reqBagPackPage();
    }
    refreshPageUI() {
        let e = User.shared().backPackData;
        if (this.prop_infos = [], sys.isObjectValid(e)) {
            if (sys.isObjectValid(e.list) && Array.isArray(e.list)) {
                for (let t = 0; t < e.list.length; t++) {
                    let i = e.list[t];
                    if (sys.isObjectValid(i.reward_type)) {
                        switch (Number(i.reward_type)) {
                            case BagItemType.BonusAdd:
                            case BagItemType.LuckyLeaf:
                            case BagItemType.TreasureKey: this.prop_infos.push(i);
                        }
                    }
                }
            }
            sys.isObjectValid(e.show_grid) && (this.max_num = e.show_grid);
        }
        let t = this.scrollViewNode.getComponent(ScrollView).content;
        Array.isArray(t.children) && t.children.length > 0 && t.removeAllChildren();
        Array.isArray(this.prop_infos) && this.prop_infos.length > 0 ? (this.infoNode.active = true, this.no_itemNode.active = false) : (this.infoNode.active = false, this.no_itemNode.active = true);
        let i = null;
        for (let e = 0; e < this.max_num; e++) {
            i = ToolUtils.isObjValid(this.propItems[e]) ? this.propItems[e] : instantiate(this.prop_item);
            t.addChild(i);
            i.active = true;
            this.propItems[e] = i;
        }
        for (let e = 0; e < this.prop_infos.length; e++) {
            ToolUtils.isObjValid(this.propItems[e]) && this.initPropItem(this.propItems[e], this.prop_infos[e], e);
        }
        for (let e = this.prop_infos.length; e < this.max_num; e++) {
            ToolUtils.isObjValid(this.propItems[e]) && this.resetPropItem(this.propItems[e]);
        }
        this.refreshSelectPropItem();
        this.refreshTopBigPropItem();
    }
    resetPropItem(e) {
        let t = e.getChildByName("empty_di"), i = e.getChildByName("prop_di"), o = e.getChildByName("icon"), s = e.getChildByName("select"), r = e.getChildByName("top_num"), a = e.getChildByName("num"), n = e.getChildByName("btn");
        t.active = true;
        i.active = false;
        o.active = false;
        r.active = false;
        a.active = false;
        n.active = false;
        s.active = false;
    }
    initPropItem(e, t, i) {
        let o = t.num, s = t.rate, r = (t.is_select, Number(t.reward_type)), a = e.getChildByName("empty_di"), c = e.getChildByName("prop_di"), p = e.getChildByName("icon"), m = (e.getChildByName("select"), e.getChildByName("top_num")), u = e.getChildByName("num"), f = e.getChildByName("btn"), g = -1;
        switch ((a.active = false, c.active = true, p.active = true, m.active = true, u.active = true, f.active = true, m.getComponent(Label).string = s + "", f.getComponent(Button).interactable = true, f.getComponent(Button).clickEvents[0].customEventData = String(i), r)) {
            case BagItemType.BonusAdd:
                g = 0;
                break;
            case BagItemType.LuckyLeaf:
                g = 1;
                break;
            case BagItemType.TreasureKey: g = 2;
        }
        [BagItemType.LuckyLeaf, BagItemType.TreasureKey].includes(r) && sys.isObjectValid(t.max) && t.max ? u.getComponent(Label).string = o <= t.max ? ToolUtils.parse_double(String(o), -1) + "" : "MAX" : u.getComponent(Label).string = ToolUtils.parse_double(String(o), -1) + "";
        g >= 0 && this.smallPropImages[g] && (p.getComponent(Sprite).spriteFrame = this.smallPropImages[g]);
    }
    onCloseClick(e, t) {
        SoundManager.shared().playFx("click");
        ToolUtils.isObjValid(this.node) && this.onBackView();
    }
    fitScreen() {
        let e = sys.getSafeAreaRect().y;
        ToolUtils.isPadPlatform() && (e = 0);
        let t = ToolUtils.adaptSafeArea(this.rootNode);
        this.scrollViewNode.getComponent(Widget).bottom = -e - t;
    }
    onDestroy() {
        super.onDestroy();
        Utils.shared().hideLoading();
    }
}
