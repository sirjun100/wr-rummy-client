// @ts-nocheck
// Recovered from index.js:661
import { _decorator, assetManager, director, game, isValid, native, Node, Prefab, resources, size, Sprite, SpriteAtlas, SpriteFrame, sys, tween, UITransform, v3, Vec3, view, WebView } from "cc";
import AppInfo from "./AppInfo";
import Utils from "./Utils";
import { TLog } from "./TLog";
import BundleNameDefined from "./BundleNameDefined";
import User from "./User";
import TweenTool from "./TweenTool";
import PushCenter from "./PushCenter";
import GameConfig from "./GameConfig";
import i18nMgr from "./i18nMgr";
import CommDefine from "./CommDefine";
import HttpManager from "./HttpManager";
import ReportConfig from "./ReportConfig";
import PushEvent from "./PushEvent";
import MD5 from "./MD5";
import HowToPlayDefined from "./HowToPlayDefined";
import { ToolUtils } from "./ToolUtils";
const { ccclass } = _decorator;
@ccclass("UtilsLogicTool")
export default class UtilsLogicTool {
    constructor() {
        if (this._util = null, this._nHistoryLen = 0, this._bIsPopState = false, this._nShowCallBackDlgTimes = 0, this.nCurLoadIdx = 0, this.vecHallPreloadBundles = [], this._preloadHallStatus = true, this.updateUrl = "", this.manifestUrl = null, this._hasStartUpdated = false, this._updating = false, this._canRetry = false, this._updateFailCount = 0, this._assetsManager = null, this.DOWNLOAD_APK_FOLDER = "files_apk", this._headSpAt = null, this._mapDownHeadStatus = new Map, this._mapDownPushEvent = new Map, this._netSpriteFrame = new Map, this._mapNetAvatarCatch = new Map, this._sysWritablePath = "", "MOBILE_BROWSER" == sys.platform || "DESKTOP_BROWSER" == sys.platform) {
            this._nHistoryLen < window.history.length && (this._nHistoryLen = window.history.length);
            let e = false;
            setTimeout((function () {
                e = true;
            }), 200);
            let t = this;
            window.addEventListener("popstate", (a => {
                if (e) {
                    if (t._bIsPopState) {
                        return void (t._bIsPopState = false);
                    }
                    t._nShowCallBackDlgTimes > 1 ? Utils.shared().replaceHistory() : Utils.shared().pushHistory();
                    ToolUtils.isInGameScene ? PushCenter.shared().pushEvent(GameConfig.BackKey_Clicked) : (t._nShowCallBackDlgTimes += 1, Utils.shared().showCommomDialog(i18nMgr.shared().getValueByKey("utlis.text"), "", (e => {
                        if (1 == e) {
                            t._nShowCallBackDlgTimes = 0;
                            t._bIsPopState = true;
                            let e = -(window.history.length - t._nHistoryLen + 2);
                            window.history.go(e);
                        }
                        else {
                            Utils.shared().cancelGoBack();
                        }
                    }), true));
                }
            }), true);
            let a = false;
            window.addEventListener("pageshow", (e => {
                (e.persisted || a) && window.location.reload();
                a = false;
            }));
            window.addEventListener("pagehide", (e => {
                a = true;
            }));
        }
    }
    init(e) {
        this._util = e;
    }
    getEnterMoneyApi(e, t = false, s = 0, i = 0, r = 0) {
        let l = sys.localStorage.getItem(User.shared().data.uid + "recommendRoom" + s + i), n = null;
        if (l) {
            let s = ToolUtils.parseJson(l);
            if (s && s.data) {
                if (sys.isObjectValid(s.data.mode)) {
                    let a = r;
                    t && 2 == s.data.mode && 2 != a && (a = 4);
                    s.data.player == a && s.data.mode == e && (n = s.data.entry);
                }
                else {
                    s.data.player == r && (n = s.data.entry);
                }
                if (sys.isObjectValid(s.data.mode)) {
                    let t = r;
                    s.data.player == t && s.data.mode == e && (n = s.data.entry);
                }
                else {
                    s.data.player == r && (n = s.data.entry);
                }
            }
        }
        return n;
    }
    getRecommendRoomIndex(e, t, s) {
        let i = 0, r = 0, l = User.shared().data.money;
        if (3 == s && (l = User.shared().data.money_exe), null != e && sys.isObjectValid(e.length) && e.length > 0) {
            let s;
            for (let n = e.length - 1; n >= 0; n--) {
                sys.isObjectValid(t) && (s = e[n].entry, s == t && 0 == r && (r = n + 1));
                e[n].min_money <= l && l < e[n].max_money && 0 == i && (i = n + 1);
            }
            if (sys.isObjectValid(t)) {
                for (let a = e.length - 1; a >= 0; a--) {
                    if (s = e[a].entry, s == t && t <= l) {
                        return [a + 1, i, r];
                    }
                }
            }
            for (let t = e.length - 1; t >= 0; t--) {
                if (e[t].min_money <= l && l < e[t].max_money) {
                    return [t + 1, i, r];
                }
            }
        }
        return [1, i, r];
    }
    releaseAssetSafely(asset) {
        if (sys.isObjectValid(asset) && asset.isValid && "function" == typeof asset.decRef) {
            asset.decRef();
        }
    }
    cleanPublicAssetsReference() {
        this._util.twentyFourRechargePrefab = null;
        this._util.payOneForThreePrefab = null;
        this._util.consecutiveGiftPrefab = null;
        this._util.restartGiftPrefab = null;
        this._util.couponActPrefab = null;
        this._util.firstRechargePrefab = null;
        this._util.rebateRechargePrefab = null;
        this._util.game_rechargePrefab = null;
        this._util.hall_rechargePrefab = null;
        this._util.gullakPrefab = null;
        this._util.gullakPrefab_inGame = null;
        this._util.treasureHuntPrefabInHall = null;
        this._util.treasureHuntPrefabInRoom = null;
    }
    getCurRoomList(e, t) {
        let a = "pointsrummy";
        t == HowToPlayDefined.RUMMY_POOL ? a = "poolrummy" : t == HowToPlayDefined.RUMMY_DEALS && (a = "dealsrummy");
        let s = [];
        0 == e ? User.shared().roomTable && User.shared().roomTable[a] && (s = User.shared().roomTable[a].crashlist) : 2 == e ? User.shared().roomTable && User.shared().roomTable[a] && (s = User.shared().roomTable[a].privatelist) : 3 == e && User.shared().roomTable && User.shared().roomTable[a] && (s = User.shared().roomTable[a].chiplist);
        let i = [];
        if (null != s && Array.isArray(s) && s.length > 0) {
            for (let e = 0, t = s.length; e < t; e++) {
                User.shared().checkVidOpen(Number(s[e].vid)) && i.push(s[e]);
            }
        }
        return i;
    }
    getCurSelectRoomList(e, t, s, i, r, l) {
        let n = Utils.shared().getCurRoomList(e, t), o = [];
        if (null != n && Array.isArray(n) && n.length > 0) {
            for (let h = 0, u = n.length; h < u; h++) {
                t == HowToPlayDefined.RUMMY_POOL ? n[h].player == s && n[h].pool_game == i && o.push(n[h]) : t == HowToPlayDefined.RUMMY_DEALS ? n[h].player == s && n[h].deals == r && o.push(n[h]) : !sys.isObjectValid(n[h].mode) || 0 != e && 3 != e ? n[h].player == s && o.push(n[h]) : (2 == l && 2 != s && (s = 4), n[h].player == s && n[h].mode == l && (4 == l ? (0 == e && 2 == s && 1 == User.shared().bump_2_open || 6 == s && 1 == User.shared().bump_6_open || 3 == e && 2 == s && 1 == User.shared().chip_bump_2_open || 6 == s && 1 == User.shared().chip_bump_6_open) && o.push(n[h]) : 3 == l ? (0 == e && 2 == s && 1 == User.shared().multiple_2_open || 6 == s && 1 == User.shared().multiple_rummy_open || 3 == e && 2 == s && 1 == User.shared().chip_multiple_2_open || 6 == s && 1 == User.shared().chip_multiple_rummy_open) && o.push(n[h]) : 5 == l ? (0 == e && 6 == s && 1 == User.shared().double_6_open || 3 == e && 6 == s && 1 == User.shared().chip_double_6_open) && o.push(n[h]) : o.push(n[h])));
            }
        }
        return o;
    }
    doReportActEvt(e, t, a, s = 0, i = "", r = 0) {
        let l = "";
        switch (Number(e)) {
            case PushEvent.JUMP_TO_SCLB:
                l = ReportConfig.Cmd_FirstRecharge;
                break;
            case PushEvent.JUMP_TO_Gullak:
                l = ReportConfig.Cmd_Gullak;
                break;
            case PushEvent.JUMP_TO_WEEK_MONTH:
                l = ReportConfig.Cmd_WeekMonth;
                break;
            case PushEvent.JUMP_TO_Adventrue:
                l = ReportConfig.Cmd_AdvancePack;
                break;
            case PushEvent.JUMP_TO_SESSIONPACKGE:
                l = ReportConfig.Cmd_SessionPack;
                break;
            case PushEvent.JUMP_TO_HAPPYFLOP:
                l = ReportConfig.Cmd_HappyFlop;
                break;
            case PushEvent.JUMP_TO_LOTTERYACT:
                l = ReportConfig.Cmd_Lottery;
                break;
            case PushEvent.JUMP_TO_PlayDraw:
                l = ReportConfig.Cmd_PlayDraw;
                break;
            case PushEvent.JUMP_TO_DAILYTASK: break;
            case PushEvent.JUMP_TO_Treasure:
                l = ReportConfig.Cmd_Treasure;
                break;
            case PushEvent.JUMP_TO_SuperVip:
                l = ReportConfig.Cmd_SuperVip;
                break;
            case PushEvent.JUMP_TO_BANKRUPTCARD:
                l = ReportConfig.Cmd_BankRuptCard;
                break;
            case PushEvent.JUMP_TO_DAILYLOGIN:
                l = ReportConfig.Cmd_DailyLogin;
                break;
            case PushEvent.JUMP_TO_TREASURE_HUNT:
                l = ReportConfig.Cmd_TreasureHunt;
                break;
            case PushEvent.JUMP_TO_CHIP_TREASURE_HUNT: l = ReportConfig.Cmd_TreasureHunt_Chip;
        }
        l == ReportConfig.Cmd_AdvancePack && 2 == a || l.length > 0 && HttpManager.shared().doCommReportRechargeEvent(l, t, a, s, i, r);
    }
    hideHallNode() {
        let e = director.getScene();
        if (e) {
            let t = e.getChildByName("Canvas");
            if (t) {
                PushCenter.shared().pushEvent(PushEvent.ChangeHallRoomBg);
                let e = t.getChildByName("hall_root"), a = t.getChildByName("bottom"), s = t.getChildByName("join_game"), n = t.getChildByName("hall_bg"), o = t.getChildByName("room_bg");
                if (!ToolUtils.isObjValid(e)) {
                    return;
                }
                let h, u, d = view.getVisibleSize(), _ = size(1560, 720), c = d.width, f = d.height, m = false;
                if (Math.abs(GameConfig.REAL_SCREEN_WIDTH - c) < 10 && Math.abs(GameConfig.REAL_SCREEN_HEIGHT - f) < 10 || (d.width > d.height && (f = d.width, c = d.height), m = true), ToolUtils.isPadPlatform()) {
                    let e = Math.max(GameConfig.REAL_SCREEN_HEIGHT, _.width);
                    if (m && Math.abs(GameConfig.REAL_SCREEN_WIDTH - c) > 10 && Math.abs(GameConfig.REAL_SCREEN_HEIGHT - f) > 10) {
                        let t = GameConfig.REAL_SCREEN_WIDTH / c;
                        h = e / t;
                        u = GameConfig.REAL_SCREEN_WIDTH / t;
                    }
                    else {
                        h = e;
                        u = GameConfig.REAL_SCREEN_WIDTH;
                    }
                }
                else if (m && Math.abs(GameConfig.REAL_SCREEN_WIDTH - c) > 10 && Math.abs(GameConfig.REAL_SCREEN_HEIGHT - f) > 10) {
                    let e = GameConfig.REAL_SCREEN_HEIGHT / f;
                    h = _.width / e;
                    u = _.height / e;
                }
                else {
                    Math.abs(GameConfig.REAL_SCREEN_WIDTH - c) < 10 && Math.abs(GameConfig.REAL_SCREEN_HEIGHT - f) < 10 ? (h = GameConfig.REAL_SCREEN_HEIGHT, h < _.height && (h = _.height)) : h = Math.max(c, GameConfig.REAL_SCREEN_HEIGHT, _.width);
                    u = _.height;
                }
                o.getComponent(UITransform).setContentSize(size(h, u));
                o.getChildByName("desk").getComponent(UITransform).setContentSize(size(h, u));
                e.active = false;
                a.active = false;
                s.active = false;
                n.active = false;
                m ? (o.active = true, o.setSiblingIndex(9999999)) : setTimeout((() => {
                    o.active = true;
                    o.setSiblingIndex(9999999);
                }), 0.05);
            }
        }
    }
    hideRummyNode(e = null) {
        let t = director.getScene();
        if (t) {
            let s = t.getChildByName("Canvas");
            if (ToolUtils.isObjValid(s)) {
                let t = s.getChildByName("bgNode");
                if (ToolUtils.isObjValid(t)) {
                    let o = t.getChildByName("imgNodes"), h = o.getChildByName("room_bg"), u = o.getChildByName("desk"), d = o.getChildByName("hall_bg");
                    if (ToolUtils.isObjValid(h)) {
                        o.getChildByName("bottom_bg").active = false;
                        o.getChildByName("top_bg").active = false;
                        h.active = false;
                        u.active = false;
                        let t, s, _ = view.getVisibleSize(), c = _.width, f = _.height, m = false;
                        if (Math.abs(GameConfig.REAL_SCREEN_WIDTH - c) < 10 && Math.abs(GameConfig.REAL_SCREEN_HEIGHT - f) < 10 || Math.abs(GameConfig.REAL_SCREEN_WIDTH - f) < 10 && Math.abs(GameConfig.REAL_SCREEN_HEIGHT - c) < 10 || (_.width > _.height && (f = _.width, c = _.height), m = true), m && Math.abs(GameConfig.REAL_SCREEN_WIDTH - c) > 10 && Math.abs(GameConfig.REAL_SCREEN_HEIGHT - f) > 10) {
                            let e = GameConfig.REAL_SCREEN_WIDTH / c;
                            t = GameConfig.REAL_SCREEN_WIDTH / e;
                            s = GameConfig.REAL_SCREEN_HEIGHT / e;
                        }
                        else {
                            Math.abs(GameConfig.REAL_SCREEN_WIDTH - f) < 10 && Math.abs(GameConfig.REAL_SCREEN_HEIGHT - c) < 10 ? (t = f > GameConfig.REAL_SCREEN_WIDTH ? f : GameConfig.REAL_SCREEN_WIDTH, s = c > GameConfig.REAL_SCREEN_HEIGHT ? c : GameConfig.REAL_SCREEN_HEIGHT) : (t = c > GameConfig.REAL_SCREEN_WIDTH ? c : GameConfig.REAL_SCREEN_WIDTH, s = f > GameConfig.REAL_SCREEN_HEIGHT ? f : GameConfig.REAL_SCREEN_HEIGHT);
                        }
                        sys.os !== sys.OS.IOS && sys.os !== sys.OS.OSX || !ToolUtils.isPadPlatform() || (d.getChildByName("hall").getChildByName("bg").getComponent(Sprite).spriteFrame = e, d.getChildByName("bottom").active = false, t < 960 && (t = 960), s < 1280 && (s = 1280));
                        d.getComponent(UITransform).setContentSize(size(t, s));
                        d.active = true;
                    }
                    let _ = s.getChildByName("rootNode");
                    ToolUtils.isObjValid(_) && (_.active = false);
                }
            }
        }
    }
    startDownLoadHotUpdate(e, t) {
        if (!sys.isNative) {
            return;
        }
        if (this._hasStartUpdated) {
            return;
        }
        this.updateUrl = e.update_url;
        this.manifestUrl = t;
        let s = native.fileUtils.getStringFromFile(this.manifestUrl.nativeUrl);
        if (!s) {
            return;
        }
        let i = ToolUtils.parseJson(s);
        this.updateUrl && (i.packageUrl = this.updateUrl, i.remoteManifestUrl = this.updateUrl + "project.manifest", i.remoteVersionUrl = this.updateUrl + "version.manifest");
        const r = this.getSysWritablePath() + CommDefine.UpdateTempPath;
        native.fileUtils.isDirectoryExist(r) || native.fileUtils.createDirectory(r);
        native.fileUtils.writeStringToFile(ToolUtils.toJsonString(i), r + "project1.manifest");
        let l = new native.Manifest(ToolUtils.toJsonString(i), r);
        this._assetsManager = new native.AssetsManager("", r, ToolUtils.versionCompareHandle);
        this._assetsManager.loadLocalManifest(l, r);
        this._assetsManager.getLocalManifest() && this._assetsManager.getLocalManifest().isLoaded() && (this._assetsManager.getState() === native.AssetsManager.State.UNINITED && this._assetsManager.loadLocalManifest(this.manifestUrl.nativeUrl), this._assetsManager.getLocalManifest() && this._assetsManager.getLocalManifest().isLoaded() && (this._assetsManager.setVerifyCallback((function (e, t) {
            t.compressed;
            t.md5;
            t.path;
            t.size;
            return true;
        })), sys.os !== sys.OS.ANDROID && sys.os !== sys.OS.OHOS || this._assetsManager.setMaxConcurrentTask(2), this._assetsManager.setEventCallback(this.checkManifestCb.bind(this)), this._updating = true, this._hasStartUpdated = true, this._updateFailCount = 0, this._assetsManager.checkUpdate()));
    }
    checkManifestCb(e) {
        let t = false;
        switch (e.getEventCode()) {
            case native.EventAssetsManager.ERROR_NO_LOCAL_MANIFEST:
                this.retryStartUpdate();
                break;
            case native.EventAssetsManager.ERROR_DOWNLOAD_MANIFEST:
            case native.EventAssetsManager.ERROR_PARSE_MANIFEST:
                this.retryStartUpdate();
                break;
            case native.EventAssetsManager.ALREADY_UP_TO_DATE: break;
            case native.EventAssetsManager.NEW_VERSION_FOUND:
                t = true, this._updating = false, this.hotUpdate();
                break;
            default: return;
        }
        t || this._assetsManager.setEventCallback(null);
        this._updating = false;
    }
    hotUpdate() {
        this._assetsManager && !this._updating && (this._assetsManager.setEventCallback(this.updateCb.bind(this)), this._assetsManager.getState() === native.AssetsManager.State.UNINITED && this._assetsManager.loadLocalManifest(this.manifestUrl.nativeUrl), this._assetsManager.update(), this._updating = true);
    }
    updateCb(e) {
        var t = false, s = false;
        switch (e.getEventCode()) {
            case native.EventAssetsManager.ERROR_NO_LOCAL_MANIFEST:
                this.retryStartUpdate(), s = true;
                break;
            case native.EventAssetsManager.UPDATE_PROGRESSION: break;
            case native.EventAssetsManager.ERROR_DOWNLOAD_MANIFEST:
            case native.EventAssetsManager.ERROR_PARSE_MANIFEST:
                this.retryStartUpdate(), s = true;
                break;
            case native.EventAssetsManager.ALREADY_UP_TO_DATE:
                s = true;
                break;
            case native.EventAssetsManager.UPDATE_FINISHED:
                t = true;
                break;
            case native.EventAssetsManager.UPDATE_FAILED:
                this._updating = false, this._canRetry = true, this.retryStartUpdate(), HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Login, event: ReportConfig.login_evt.updateRetry }), AppInfo.shared().logEvent_firebase(ReportConfig.login_evt.updateRetry);
                break;
            case native.EventAssetsManager.ERROR_UPDATING:
            case native.EventAssetsManager.ERROR_DECOMPRESS:
        }
        if (s && (this.retryStartUpdate(), this._assetsManager.setEventCallback(null), this._updating = false), t) {
            this._assetsManager.setEventCallback(null);
            const e = this.getSysWritablePath() + CommDefine.UpdateTempPath;
            native.fileUtils.isFileExist(e + "project1.manifest") && native.fileUtils.removeFile(e + "project1.manifest");
            sys.isObjectValid(this.manifestUrl) && this.manifestUrl.decRef();
            this._util.renameDirectory(this.getSysWritablePath(), CommDefine.UpdateTempPath, CommDefine.UpdateRenamePath);
        }
    }
    showErrTips(e) {
        Utils.shared().hideCommomDialog();
        Utils.shared().showCommomDialog(e, "", this.retryStartUpdate.bind(this), false, ToolUtils.getIsNormalDirection(), "OKAY", "", true);
    }
    retryStartUpdate() {
        this._updateFailCount++;
        this._updateFailCount > 5 || (this._updating ? this._canRetry && (this._canRetry = false, this._assetsManager.downloadFailedAssets()) : this.hotUpdate());
    }
    closeHallBoxAnim(e) {
        let t = e.alert_node, s = e.rootNode, r = e.isNext, l = e.pop_type;
        let n = view.getVisibleSize(), o = new Vec3(0, 0, 0);
        if (null == this._util.actNodePos) {
            return void (ToolUtils.isObjValid(t) && (r && PushCenter.shared().pushEvent(PushEvent.Update_NextPopActivity), t.destroy()));
        }
        o.x = this._util.actNodePos.x - n.width / 2;
        o.y = -n.height / 2 + this._util.actNodePos.y;
        let d = s.position.clone(), _ = ToolUtils.format("${0}${1}", User.shared().data.uid, l), c = ToolUtils.isSafeString(sys.localStorage.getItem(_));
        if (c.length > 0 && Number(c) >= User.shared().popact_anim_count) {
            if (ToolUtils.isObjValid(t)) {
                return r && PushCenter.shared().pushEvent(PushEvent.Update_NextPopActivity), void t.destroy();
            }
        }
        else {
            let e = 0;
            c.length > 0 && (e = Number(c));
            sys.localStorage.setItem(_, "" + (e + 1));
        }
        let f = new Vec3(d.x, d.y + 100, d.z), m = new Vec3(o.x, o.y + 100, o.z);
        tween(s).to(0.5, {}, { onUpdate(e, t) {
                const a = 1 - t, i = t * t, r = a * a, l = r * a, n = i * t, u = d.clone().multiplyScalar(l).add(f.clone().multiplyScalar(3 * r * t)).add(m.clone().multiplyScalar(3 * a * i)).add(o.clone().multiplyScalar(n));
                s.setPosition(u);
                const _ = 1 - t;
                s.setScale(new Vec3(_, _, _));
            } }).call((() => {
            ToolUtils.isObjValid(t) && (r && PushCenter.shared().pushEvent(PushEvent.Update_NextPopActivity), t.destroy());
        })).start();
    }
    closeActivityView(e) {
        let t = e.alert_node, s = e.isNext, i = e.pop_type, r = e.pop_souce;
        if (1 == GameConfig.GAME_HALL_THEME && ToolUtils.isObjValid(t)) {
            return s && PushCenter.shared().pushEvent(PushEvent.Update_NextPopActivity), void t.destroy();
        }
        if (Utils.shared().hasShowChooseGame() && 1 == r) {
            if (sys.isObjectValid(User.shared().data.act_collect_open) && sys.isObjectValid(User.shared().data.act_collect_open.list) && Array.isArray(User.shared().data.act_collect_open.list)) {
                let e = User.shared().data.act_collect_open.list.length, r = false;
                for (let t = 0; t < e; t++) {
                    const e = User.shared().data.act_collect_open.list[t];
                    if (sys.isObjectValid(e) && sys.isObjectValid(e.act_id) && e.act_id == i) {
                        r = true;
                        break;
                    }
                }
                if (2 != User.shared().hall_select_tab && (r = false), !r && ToolUtils.isObjValid(t)) {
                    return s && PushCenter.shared().pushEvent(PushEvent.Update_NextPopActivity), void t.destroy();
                }
            }
            this.closeHallBoxAnim(e);
        }
        else {
            ToolUtils.isObjValid(t) && (s && PushCenter.shared().pushEvent(PushEvent.Update_NextPopActivity), t.destroy());
        }
    }
    mackCallBackStatus() {
        this._nShowCallBackDlgTimes += 1;
    }
    cancelGoBack() {
        1 == this._nShowCallBackDlgTimes ? (this._nShowCallBackDlgTimes = 0, window.history && history.forward && window.history.forward()) : (this._nShowCallBackDlgTimes = 0, window.history && history.back && window.history.back());
    }
    replaceHistory() {
        if (window.history && history.replaceState) {
            let e = { title: "title", url: "#" };
            window.history.replaceState(e, "title", "#");
            this._bIsPopState = true;
            window.history.forward();
        }
    }
    pushHistory() {
        if (window.history && history.pushState) {
            let e = { title: "title", url: "#" };
            window.history.pushState(e, "title", "#");
        }
    }
    preLoadWebview(e) {
        let t = ToolUtils.getGlobalNode().getChildByName("preWebNode");
        if (null == t || null == t) {
            t = new Node;
            t.name = "preWebNode";
            ToolUtils.getGlobalNode().addChild(t);
            let e = view.getVisibleSize();
            t.setPosition(v3(-e.width / 2, -e.height / 2));
        }
        let a = t.getComponent(WebView);
        null != a && null != a || (a = t.addComponent(WebView));
        a.url = e;
        t.active = false;
    }
    preLoadBundleAsset(e = false, t = false) {
        this.vecHallPreloadBundles = [];
        let s = [[BundleNameDefined.bundle_hall, null, BundleNameDefined.gameMode_prefab], [BundleNameDefined.Bundle_leaderBoards, null, BundleNameDefined.leaderboard_prefab], [BundleNameDefined.bundle_hallTopUI, null, BundleNameDefined.email_prefab], [BundleNameDefined.bundle_menu, null, BundleNameDefined.menu_prefab], [BundleNameDefined.bundle_invite, null, BundleNameDefined.invite_prefab]];
        1 == GameConfig.GAME_HALL_THEME && (s = [[BundleNameDefined.bundle_hall, null, BundleNameDefined.gameMode_prefab], [BundleNameDefined.Bundle_Yes11, null, BundleNameDefined.cricket_prefab], [BundleNameDefined.bundle_hallTopUI, null, BundleNameDefined.email_prefab], [BundleNameDefined.bundle_menu, null, BundleNameDefined.menu_prefab], [BundleNameDefined.bundle_invite, null, BundleNameDefined.invite_prefab]]);
        for (let e = 0, t = s.length; e < t; e++) {
            let t = s[e][2];
            User.shared().hall_bundleMap.has(t) && User.shared().hall_bundleMap.get(t) || this.vecHallPreloadBundles.push(s[e]);
        }
        let i = 5;
        if ((!sys.isNative || AppInfo.shared().getDeviceLevel() > 0) && (i = 3, AppInfo.shared().getDeviceLevel() > 1 && (User.shared().hall_bundleMap.has(BundleNameDefined.store_prefab) && User.shared().hall_bundleMap.get(BundleNameDefined.store_prefab) || this.vecHallPreloadBundles.push([BundleNameDefined.bundle_wallet, null, BundleNameDefined.store_prefab]), User.shared().hall_bundleMap.has(BundleNameDefined.withdraw_prefab) && User.shared().hall_bundleMap.get(BundleNameDefined.withdraw_prefab) || this.vecHallPreloadBundles.push([BundleNameDefined.bundle_wallet, null, BundleNameDefined.withdraw_prefab]), i = 2), t && (User.shared().hall_bundleMap.has(BundleNameDefined.reward_prefab) && User.shared().hall_bundleMap.get(BundleNameDefined.reward_prefab) || this.vecHallPreloadBundles.push([BundleNameDefined.bundle_public, null, BundleNameDefined.reward_prefab]))), sys.os !== sys.OS.IOS && sys.os !== sys.OS.OSX || this.vecHallPreloadBundles.push([BundleNameDefined.bundle_public, null, BundleNameDefined.dialog_prefab]), this._preloadHallStatus = this.vecHallPreloadBundles.length > 0, this.nCurLoadIdx = -1, e) {
            this.preLoadNextRes();
        }
        else {
            User.shared().hasPreload = true;
            for (let t = 0, a = this.vecHallPreloadBundles.length; t < a; t++) {
                const s = this.vecHallPreloadBundles[t];
                let r = s[0], l = s[1], n = s[2];
                TweenTool.delayAct(ToolUtils.getGlobalNode(), (() => {
                    window.InSwitchScene && !window.IsBackToHallLoad || this.loadBundleAsset(r, l, n, e, t == a - 1);
                }), game.frameTime / 1000 * t * i, true);
            }
        }
    }
    preLoadNextRes() {
        if (!window.InSwitchScene || window.IsBackToHallLoad) {
            if (this.nCurLoadIdx = this.nCurLoadIdx + 1, sys.isObjectValid(this.vecHallPreloadBundles) && this.vecHallPreloadBundles[this.nCurLoadIdx]) {
                let e = this.vecHallPreloadBundles[this.nCurLoadIdx][0], t = this.vecHallPreloadBundles[this.nCurLoadIdx][1], a = this.vecHallPreloadBundles[this.nCurLoadIdx][2];
                this.loadBundleAsset(e, t, a, true);
            }
            else {
                this._preloadHallStatus = false;
                User.shared().hasPreload = true;
            }
        }
        else {
            TLog.printError("-------- preLoadNextRes switchScene stop preload res.");
        }
    }
    loadBundleAsset(e, t, a, s = false, i = false) {
        if (window.InSwitchScene && !window.IsBackToHallLoad) {
            return void TLog.printError("-------- loadBundleAsset switchScene stop preload res.");
        }
        let r = assetManager.getBundle(e);
        if (r) {
            try {
                a ? r && this.loadHallBundlesPrefab(r, a, s, i) : t && r && r.preloadDir(t, ((e, t) => {
                }));
            }
            catch (e) {
                TLog.printError("Utils loadBundleAsset error:", e);
            }
        }
        else {
            try {
                assetManager.loadBundle(e, null, ((e, r) => {
                    null == e && (a ? r && this.loadHallBundlesPrefab(r, a, s, i) : t && r && r.preloadDir(t, ((e, t) => {
                    })));
                }));
            }
            catch (e) {
                TLog.printError("Utils loadBundleAsset error:", e);
            }
        }
    }
    loadHallBundlesPrefab(e, t, a = false, s = false) {
        if (!window.InSwitchScene || window.IsBackToHallLoad) {
            try {
                a ? e.preload(t, Prefab, ((e, t) => {
                    this.preLoadNextRes();
                })) : e.load(t, Prefab, ((e, a) => {
                    t === BundleNameDefined.email_prefab ? this._util.mailViewPrefab = a : t === BundleNameDefined.menu_prefab ? this._util.menuViewPrefab = a : t === BundleNameDefined.wallet_prefab ? this._util.walletPrefab = a : t === BundleNameDefined.invite_prefab ? this._util.invitePrefab = a : t === BundleNameDefined.leaderboard_prefab ? this._util.leaderBoardsHallMainPrefab = a : t === BundleNameDefined.activity_prefab ? this._util.activityPrefab = a : t === BundleNameDefined.cricket_prefab && (this._util.cricket_mainPrefab = a);
                    User.shared().hall_bundleMap.set(t, true);
                    s && (this._preloadHallStatus = false);
                }));
            }
            catch (e) {
                TLog.printError("----------- loadHallBundlesPrefab err:", e);
            }
        }
        else {
            TLog.printError("-------- loadHallBundlesPrefab switchScene stop preload res.");
        }
    }
    releaseYes11Prefab() {
        try {
            this.releaseAssetSafely(this._util.cricket_mainPrefab);
            this._util.cricket_mainPrefab = null;
            this.releaseAssetSafely(this._util.cricket_chooseGamePrefab);
            this._util.cricket_chooseGamePrefab = null;
            this.releaseAssetSafely(this._util.cricket_gameDetailsPrefab);
            this._util.cricket_gameDetailsPrefab = null;
            this.releaseAssetSafely(this._util.cricket_createTeamPrefab);
            this._util.cricket_createTeamPrefab = null;
            this.releaseAssetSafely(this._util.cricket_selectCaptainPrefab);
            this._util.cricket_selectCaptainPrefab = null;
            this.releaseAssetSafely(this._util.cricket_teamListPrefab);
            this._util.cricket_teamListPrefab = null;
            this.releaseAssetSafely(this._util.cricket_joinListPrefab);
            this._util.cricket_joinListPrefab = null;
            this.releaseAssetSafely(this._util.cricket_backUpPrefab);
            this._util.cricket_backUpPrefab = null;
            this.releaseAssetSafely(this._util.cricket_notLineUpPrefab);
            this._util.cricket_notLineUpPrefab = null;
            this.releaseAssetSafely(this._util.cricket_teamPreviewPrefab);
            this._util.cricket_teamPreviewPrefab = null;
            this.releaseAssetSafely(this._util.cricket_assureJoinPrefab);
            this._util.cricket_assureJoinPrefab = null;
            this.releaseAssetSafely(this._util.cricket_end);
            this._util.cricket_end = null;
            this.releaseAssetSafely(this._util.cricket_endReward);
            this._util.cricket_endReward = null;
            this.releaseAssetSafely(this._util.cricket_endPlayerDetail);
            this._util.cricket_endPlayerDetail = null;
            this.releaseAssetSafely(this._util.cricket_fastCreateTeamPrefab);
            this._util.cricket_fastCreateTeamPrefab = null;
            this.releaseAssetSafely(this._util.cricket_playerMainPrefab);
            this._util.cricket_playerMainPrefab = null;
            this.releaseAssetSafely(this._util.cricket_switchListPrefab);
            this._util.cricket_switchListPrefab = null;
        }
        catch (e) {
            TLog.printError("---------- releaseYes11Prefab err:", e);
        }
    }
    releaseHallBundleAssets(e = false, t = false) {
        this.releaseInvitePrefab();
        this.releaseMemberShipPrefab();
        this.releaseMenuPrefab();
        this.releaseYes11Prefab();
        let a = [BundleNameDefined.bundle_menu, BundleNameDefined.bundle_invite];
        for (let e = 0, t = a.length; e < t; e++) {
            let t = assetManager.getBundle(a[e]);
            t && (t.releaseUnusedAssets(), assetManager.removeBundle(t));
        }
        if (e) {
            if (!User.shared().b_storeLevel) {
                this.releaseWalletPrefab();
                let e = assetManager.getBundle(BundleNameDefined.bundle_wallet);
                e && (e.releaseUnusedAssets(), assetManager.removeBundle(e));
            }
            this.releaseHallPrefab();
            let e = assetManager.getBundle(BundleNameDefined.bundle_hallTopUI);
            e && (e.releaseUnusedAssets(), assetManager.removeBundle(e));
            e = assetManager.getBundle(BundleNameDefined.bundle_hall);
            e && (e.releaseUnusedAssets(), assetManager.removeBundle(e));
        }
        User.shared().reSetHallBundleLoadState();
    }
    releaseGameBundleAssets() {
        let e = assetManager.getBundle(BundleNameDefined.bundle_rummyTopUI);
        e && (e.releaseUnusedAssets(), assetManager.removeBundle(e));
        e = assetManager.getBundle(BundleNameDefined.bundle_rummy);
        e && (e.releaseUnusedAssets(), assetManager.removeBundle(e));
    }
    releasePublicUnusedAssets(e = true) {
        if (this._preloadHallStatus) {
            TLog.printError("---------- releasePublicUnusedAssets preloading stop");
        }
        else {
            this.releaseFirstRechargePrefab();
            this.releaseBuyOneGetThreePrefab();
            this.releasePublicPrefab();
            try {
                let t = [BundleNameDefined.bundle_gullak, BundleNameDefined.bundle_firstRecharge, BundleNameDefined.bundle_payoneforthree, BundleNameDefined.bundle_rule, BundleNameDefined.bundle_dailyTask, BundleNameDefined.bundle_location, BundleNameDefined.bundle_weekmonth, BundleNameDefined.Bundle_game_display, BundleNameDefined.Bundle_dailyLogin, BundleNameDefined.Bundle_treasurehunt, BundleNameDefined.Bundle_advancePack];
                e && (this.releaseInvitePrefab(), this.releaseMenuPrefab(), this.releaseMemberShipPrefab(), this.releaseWalletPrefab(), this.releaseKycPrefab(), this.releaseAssetSafely(this._util.easyGameTypePrefab), this._util.easyGameTypePrefab = null, this.releaseAssetSafely(this._util.multipleGameTypePrefab), this._util.multipleGameTypePrefab = null, t.push(BundleNameDefined.Bundle_leaderBoards), t.push(BundleNameDefined.bundle_invite), t.push(BundleNameDefined.bundle_menu), t.push(BundleNameDefined.bundle_wallet), t.push(BundleNameDefined.Bundle_kyc), User.shared().reSetHallBundleLoadState());
                for (let e = 0, a = t.length; e < a; e++) {
                    let a = assetManager.getBundle(t[e]);
                    a && (a.releaseUnusedAssets(), assetManager.removeBundle(a));
                }
            }
            catch (e) {
                TLog.printError("releasePublicUnusedAssets ,error:", e);
            }
        }
    }
    releaseKycPrefab() {
        try {
            this.releaseAssetSafely(this._util.kycPrefab);
            this._util.kycPrefab = null;
            this.releaseAssetSafely(this._util.kycAgeVerifyPrefab);
            this._util.kycAgeVerifyPrefab = null;
            this.releaseAssetSafely(this._util.kycPhotoPrefab);
            this._util.kycPhotoPrefab = null;
            this.releaseAssetSafely(this._util.hallPasswordPrefab);
            this._util.hallPasswordPrefab = null;
            this.releaseAssetSafely(this._util.panGuidePrefab);
            this._util.panGuidePrefab = null;
            this.releaseAssetSafely(this._util.mobileGuidePrefab);
            this._util.mobileGuidePrefab = null;
            this.releaseAssetSafely(this._util.panCardPrefab);
            this._util.panCardPrefab = null;
        }
        catch (e) {
            TLog.printError("---------- releaseKycPrefab err:", e);
        }
    }
    releaseWalletPrefab() {
        try {
            this._util.hidePersonalInfoVerifyView();
            this.releaseAssetSafely(this._util.storePrefab);
            this._util.storePrefab = null;
            this.releaseAssetSafely(this._util.depositTransferPrefab);
            this._util.depositTransferPrefab = null;
            this.releaseAssetSafely(this._util.walletRecordPrefab);
            this._util.walletRecordPrefab = null;
            this.releaseAssetSafely(this._util.keyBoadViewPrefab);
            this._util.keyBoadViewPrefab = null;
            this.releaseAssetSafely(this._util.personalInfoVerifyPrefab);
            this._util.personalInfoVerifyPrefab = null;
            this.releaseAssetSafely(this._util.withdrawHelpPrefab);
            this._util.withdrawHelpPrefab = null;
            this.releaseAssetSafely(this._util.withdrawEditPrefab);
            this._util.withdrawEditPrefab = null;
            this.releaseAssetSafely(this._util.withdrawConfirmPrefab);
            this._util.withdrawConfirmPrefab = null;
            this.releaseAssetSafely(this._util.withdrawManagePrefab);
            this._util.withdrawManagePrefab = null;
            this.releaseAssetSafely(this._util.withdrawDeletePrefab);
            this._util.withdrawDeletePrefab = null;
            this.releaseAssetSafely(this._util.withdrawAddPrefab);
            this._util.withdrawAddPrefab = null;
            this.releaseAssetSafely(this._util.walletPrefab);
            this._util.walletPrefab = null;
            this.releaseAssetSafely(this._util.walletDetailstPrefab);
            this._util.walletDetailstPrefab = null;
            this.releaseAssetSafely(this._util.bonusDetailstPrefab);
            this._util.bonusDetailstPrefab = null;
            this.releaseAssetSafely(this._util.storeReceiptDialogPrefab);
            this._util.storeReceiptDialogPrefab = null;
            this.releaseAssetSafely(this._util.withdrawMainConfirmPrefab);
            this._util.withdrawMainConfirmPrefab = null;
        }
        catch (e) {
            TLog.printError("---------- releaseWalletPrefab err:", e);
        }
    }
    releaseInvitePrefab() {
        try {
            this.releaseAssetSafely(this._util.invitePrefab);
            this._util.invitePrefab = null;
            this.releaseAssetSafely(this._util.inviteEarningsPrefab);
            this._util.inviteEarningsPrefab = null;
            this.releaseAssetSafely(this._util.inviteEarnDetailsPrefab);
            this._util.inviteEarnDetailsPrefab = null;
            this.removeCanvasNodeByName("invite_rewardtask");
            this.releaseAssetSafely(this._util.inviteRewardTaskPrefab);
            this._util.inviteRewardTaskPrefab = null;
            this.releaseAssetSafely(this._util.inviteHelpPrefab);
            this._util.inviteHelpPrefab = null;
            this.releaseAssetSafely(this._util.withdrawalPrefab);
            this._util.withdrawalPrefab = null;
            this.releaseAssetSafely(this._util.exchangeWalletPrefab);
            this._util.exchangeWalletPrefab = null;
            this.releaseAssetSafely(this._util.bindMyReferrerPrefab);
            this._util.bindMyReferrerPrefab = null;
        }
        catch (e) {
            TLog.printError("---------- releaseInvitePrefab err:", e);
        }
    }
    releaseMemberShipPrefab() {
        try {
            this.releaseAssetSafely(this._util.clubViewPrefab);
            this._util.clubViewPrefab = null;
        }
        catch (e) {
            TLog.printError("---------- releaseMemberShipPrefab err:", e);
        }
    }
    releaseMenuPrefab() {
        try {
            this.releaseAssetSafely(this._util.menuViewPrefab);
            this._util.menuViewPrefab = null;
            this.releaseAssetSafely(this._util.hallsettingPrefab);
            this._util.hallsettingPrefab = null;
            this.releaseAssetSafely(this._util.hallLogoutPrefab);
            this._util.hallLogoutPrefab = null;
            this.releaseAssetSafely(this._util.hallPasswordPrefab);
            this._util.hallPasswordPrefab = null;
            this.releaseAssetSafely(this._util.rechargeLimitsPrefab);
            this._util.rechargeLimitsPrefab = null;
        }
        catch (e) {
            TLog.printError("---------- releaseMenuPrefab err:", e);
        }
    }
    releaseHallPrefab() {
        try {
            this.releaseAssetSafely(this._util.hallUserInfoPrefab);
            this._util.hallUserInfoPrefab = null;
            this.releaseAssetSafely(this._util.mailViewPrefab);
            this._util.mailViewPrefab = null;
            this.releaseAssetSafely(this._util.activityPrefab);
            this._util.activityPrefab = null;
        }
        catch (e) {
            TLog.printError("---------- releaseHallPrefab err:", e);
        }
    }
    releaseFirstRechargePrefab() {
        try {
            this.removeCanvasNodeByName("FirstRecharge");
            this.releaseAssetSafely(this._util.firstRechargePrefab);
            this._util.firstRechargePrefab = null;
            this.removeCanvasNodeByName("TwentyFourRecharge");
            this.releaseAssetSafely(this._util.twentyFourRechargePrefab);
            this._util.twentyFourRechargePrefab = null;
            this.removeCanvasNodeByName("RebateRecharge");
            this.releaseAssetSafely(this._util.rebateRechargePrefab);
            this._util.rebateRechargePrefab = null;
            this.removeCanvasNodeByName("restart_gift");
            this.releaseAssetSafely(this._util.restartGiftPrefab);
            this._util.restartGiftPrefab = null;
            this.removeCanvasNodeByName("coupon_package");
            this.releaseAssetSafely(this._util.couponActPrefab);
            this._util.couponActPrefab = null;
            this.removeCanvasNodeByName("ConsecutiveGift");
            this.releaseAssetSafely(this._util.consecutiveGiftPrefab);
            this._util.consecutiveGiftPrefab = null;
        }
        catch (e) {
            TLog.printError("---------- releaseFirstRechargePrefab err:", e);
        }
    }
    releaseBuyOneGetThreePrefab() {
        try {
            this.removeCanvasNodeByName("BuyOneGetThree");
            this.releaseAssetSafely(this._util.payOneForThreePrefab);
            this._util.payOneForThreePrefab = null;
        }
        catch (e) {
            TLog.printError("---------- releaseBuyOneGetThreePrefab err:", e);
        }
    }
    releaseDailyFireSalePrefab() {
        try {
            this.removeCanvasNodeByName("daily_fire_sale");
            this.releaseAssetSafely(this._util.dailyFireSalePrefab);
            this._util.dailyFireSalePrefab = null;
        }
        catch (e) {
            TLog.printError("---------- releaseDailyFireSalePrefab err:", e);
        }
    }
    releaseTreasureDrawPrefab() {
        try {
            this.removeCanvasNodeByName("TreasureDraw");
            this.releaseAssetSafely(this._util.treasuredrawPrefab);
            this._util.treasuredrawPrefab = null;
        }
        catch (e) {
            TLog.printError("---------- releaseTreasureDrawPrefab err:", e);
        }
    }
    releaseTreasureDrawShopPre() {
        try {
            this.removeCanvasNodeByName("treasuredraw_shop");
            this.releaseAssetSafely(this._util.treasuredrawShopPre);
            this._util.treasuredrawShopPre = null;
        }
        catch (e) {
            TLog.printError("---------- releaseTreasureDrawShopPre err:", e);
        }
    }
    releaseLotteryPrefab() {
        try {
            this.removeCanvasNodeByName("Lottery");
            this.releaseAssetSafely(this._util.lotteryPrefab);
            this._util.lotteryPrefab = null;
            this.releaseAssetSafely(this._util.lotteryGamePrefab);
            this._util.lotteryGamePrefab = null;
        }
        catch (e) {
            TLog.printError("---------- releaseLotteryPrefab err:", e);
        }
    }
    releasePublicPrefab() {
        try {
            this.releaseAssetSafely(this._util.webViewPrefab);
            this._util.webViewPrefab = null;
            this.releaseAssetSafely(this._util.rePassWordPrefab);
            this._util.rePassWordPrefab = null;
            this.releaseAssetSafely(this._util.bonusDetailstPrefab);
            this._util.bonusDetailstPrefab = null;
            this.releaseAssetSafely(this._util.ruleHelpViewPrefab);
            this._util.ruleHelpViewPrefab = null;
            this.removeCanvasNodeByName("reward_tips");
            this.releaseAssetSafely(this._util.rewardTipsPrefab);
            this._util.rewardTipsPrefab = null;
            this.releaseAssetSafely(this._util.broadCastPrefab);
            this._util.broadCastPrefab = null;
            this.releaseAssetSafely(this._util.selectAreaPrefab);
            this._util.selectAreaPrefab = null;
            this.releaseAssetSafely(this._util.selectDatePrefab);
            this._util.selectDatePrefab = null;
            this.releaseAssetSafely(this._util.buddyJoinPrefab);
            this._util.buddyJoinPrefab = null;
            this.releaseAssetSafely(this._util.matchAlertPrefab);
            this._util.matchAlertPrefab = null;
            this.releaseAssetSafely(this._util.matchRankPrefab);
            this._util.matchRankPrefab = null;
            this.releaseAssetSafely(this._util.matchPrizesRankPrefab);
            this._util.matchPrizesRankPrefab = null;
            this.releaseAssetSafely(this._util.ageVerifyPrefab);
            this._util.ageVerifyPrefab = null;
            this.releaseAssetSafely(this._util.rankPrefab);
            this._util.rankPrefab = null;
            this.releaseAssetSafely(this._util.contactUsPrefab);
            this._util.contactUsPrefab = null;
            this.releaseAssetSafely(this._util.loginVerificationPrefab);
            this._util.loginVerificationPrefab = null;
            this.releaseAssetSafely(this._util.locationGuidePrefab);
            this._util.locationGuidePrefab = null;
            this.removeCanvasNodeByName("happyHoli");
            this.releaseAssetSafely(this._util.happyHoliPrefab);
            this._util.happyHoliPrefab = null;
            this.removeCanvasNodeByName("redemption_code");
            this.releaseAssetSafely(this._util.redeemCodePrefab);
            this._util.redeemCodePrefab = null;
            this.removeCanvasNodeByName("weeklymonthcard_new");
            this.releaseAssetSafely(this._util.weekmonthPrefab);
            this._util.weekmonthPrefab = null;
            this.removeCanvasNodeByName("commondialog_node");
            this.removeCanvasNodeByName("dailyTask1");
            this.removeCanvasNodeByName("dailyTask2");
            this.removeCanvasNodeByName("dailyTask3");
            this.removeCanvasNodeByName("HappyFlop");
            this.removeCanvasNodeByName("newplayer_task");
            this.removeCanvasNodeByName("practice_tips");
            this.removeCanvasNodeByName("gullak");
            this.releaseAssetSafely(this._util.gullakPrefab);
            this._util.gullakPrefab = null;
            this.releaseAssetSafely(this._util.gullakPrefab_inGame);
            this._util.gullakPrefab_inGame = null;
            this.removeCanvasNodeByName("AdReward");
            this.releaseAssetSafely(this._util.adRewardPrefab);
            this._util.adRewardPrefab = null;
            this.removeCanvasNodeByName("adView");
            this.releaseAssetSafely(this._util.adPrefab);
            this._util.adPrefab = null;
            this.removeCanvasNodeByName("advancedGift");
            this.releaseAssetSafely(this._util.AdvancedGiftPrefab);
            this._util.AdvancedGiftPrefab = null;
            this.removeCanvasNodeByName("superVip");
            this.releaseAssetSafely(this._util.superVipPrefab);
            this._util.superVipPrefab = null;
            this.removeCanvasNodeByName("bonusForest");
            this.releaseAssetSafely(this._util.bonusForestPrefab);
            this._util.bonusForestPrefab = null;
            this.removeCanvasNodeByName("treasure");
            this.releaseAssetSafely(this._util.treasurePrefab);
            this._util.treasurePrefab = null;
            this.removeCanvasNodeByName("treasure_recharge");
            this.releaseAssetSafely(this._util.treasureRechargePrefab);
            this._util.treasureRechargePrefab = null;
            this.removeCanvasNodeByName("dailycheckin");
            this.releaseAssetSafely(this._util.dailyLoginActPrefab);
            this._util.dailyLoginActPrefab = null;
            this.removeCanvasNodeByName("rechargeRewards");
            this.releaseAssetSafely(this._util.rechargeRewardsPrefab);
            this._util.rechargeRewardsPrefab = null;
            this.removeCanvasNodeByName("feedback_node");
            this.releaseAssetSafely(this._util.tawkFeedbackPrefab);
            this._util.tawkFeedbackPrefab = null;
            this.removeCanvasNodeByName("bag");
            this.releaseAssetSafely(this._util.bagPrefab);
            this._util.bagPrefab = null;
            this.removeCanvasNodeByName("earthquakes");
            this.releaseAssetSafely(this._util.treasureHuntPrefabInHall);
            this._util.treasureHuntPrefabInHall = null;
            this.releaseAssetSafely(this._util.treasureHuntPrefabInRoom);
            this._util.treasureHuntPrefabInRoom = null;
            this.removeCanvasNodeByName("WelcomeBackWork");
        }
        catch (e) {
            TLog.printError("---------- releasePublicPrefab err:", e);
        }
    }
    removeCanvasNodeByName(e) {
        let t = director.getScene().getChildByName("Canvas").getChildByName(e);
        ToolUtils.isObjValid(t) && t.destroy();
    }
    writeHttpLog() {
        if (1 == User.shared().phplog_write_open && (sys.os === sys.OS.ANDROID || sys.os === sys.OS.IOS)) {
            if (!sys.isNative) {
                return;
            }
            let e = sys.localStorage.getItem("httpLogWriteNum"), t = 0;
            null != e && null != e && (t = Number(e));
            t += 1;
            t > 100 && (t = 0);
            ToolUtils.saveData("httpLogWriteNum", String(t));
            try {
                let e = this.getSysWritablePath() + "httplog";
                native.fileUtils.isDirectoryExist(e) ? console.log("httplog is exist!!!") : native.fileUtils.createDirectory(e);
                let a = native.fileUtils.getStringFromFile(e + "/httplog_str_write.txt");
                0 == t ? a = User.shared().httpLogWrite : a += User.shared().httpLogWrite;
                native.fileUtils.writeStringToFile(a, e + "/httplog_str_write.txt");
            }
            catch (e) {
                TLog.printError("writeHttpLog,error:", e);
            }
            User.shared().httpLogWrite = "";
        }
    }
    downLoadApk(e, t) {
        let a = native.fileUtils.getWritablePath() + this.DOWNLOAD_APK_FOLDER + "/" + MD5.Instance.hex_md5(e) + ".apk";
        if (TLog.printError("downLoadApk fullFilesName:", a), native.fileUtils.isFileExist(a)) {
            AppInfo.shared().initApk(a, t);
        }
        else {
            let s = a;
            const i = { countOfMaxProcessingTasks: 6, timeoutInSeconds: 10, tempFileNameSuffix: ".tmp" };
            let r = new native.Downloader(i);
            r.createDownloadTask(e, s, "downLoadApk");
            r.onSuccess = e => {
                AppInfo.shared().initApk(a, t);
            };
            r.onError = (e, t, a, s) => {
                TLog.printError("--------- downloader apk TaskError errorCode, errorCodeInternal, errorStr:", t, a, s);
            };
            r.onProgress = (e, t, a, s) => {
                PushCenter.shared().pushEvent(PushEvent.UpdateDownApkProgress, a / s);
            };
        }
    }
    resetDownLoadHeadFlag() {
        this._mapDownHeadStatus.clear();
        this._mapDownPushEvent.clear();
    }
    clearImagUrlPushEvent(e) {
        ToolUtils.isSafeString(e).length > 0 && this._mapDownPushEvent.set(e, false);
    }
    downLoadImage(e, t, s, i, r = null) {
        let l = new XMLHttpRequest;
        l.onreadystatechange = function () {
            if (4 === l.readyState && 200 === l.status && l.response && sys.isNative) {
                e._mapDownHeadStatus.set(i, 0);
                try {
                    let e = new Uint8Array(l.response);
                    native.fileUtils.writeDataToFile(e, i);
                }
                catch (e) {
                    TLog.printError("Utils downLoadImage sucess1:", e);
                }
                r && r();
            }
        }.bind(this);
        l.onerror = function () {
            e._mapDownHeadStatus.set(i, 0);
        };
        l.ontimeout = function () {
            s > 3 ? e._mapDownHeadStatus.set(i, 0) : (s += 1, e.downLoadImage(e, t, s, i, r));
        };
        l.timeout = 10000;
        l.responseType = "arraybuffer";
        l.open("GET", t, true);
        l.send();
    }
    downNetFile(e, t, s) {
        if (sys.isObjectValid(e) && e.length > 0) {
            if ("MOBILE_BROWSER" == sys.platform || "DESKTOP_BROWSER" == sys.platform) {
                window.open(e, "_blank");
            }
            else if (sys.os === sys.OS.ANDROID || sys.os === sys.OS.OHOS || sys.os === sys.OS.IOS || sys.os === sys.OS.OSX) {
                try {
                    let a = this.getSysWritablePath() + this._util.NET_FILE_CATCH_FOLDER;
                    native.fileUtils.isDirectoryExist(a) || native.fileUtils.createDirectory(a);
                    let i = a + "/" + MD5.Instance.hex_md5(t) + "." + s;
                    if (native.fileUtils.isFileExist(i)) {
                        ;
                    }
                    else {
                        if (undefined !== this._mapDownHeadStatus.get(i) && 1 === this._mapDownHeadStatus.get(i)) {
                            return;
                        }
                        this._mapDownHeadStatus.set(i, 1);
                        let t = this, a = i, s = 0;
                        this.downLoadImage(t, e, s, a, (() => {
                            PushCenter.shared().pushEvent(PushEvent.commentDownloaderFile, i);
                        }));
                    }
                }
                catch (e) {
                    TLog.printError("downNetFile,error:", e);
                }
            }
        }
    }
    getWebNetAvatarCatch(e) {
        for (let [t, a] of this._mapNetAvatarCatch.entries()) {
            if (t === e) {
                return a;
            }
        }
        return null;
    }
    getSysWritablePath() {
        let e = "";
        try {
            null != this._sysWritablePath && this._sysWritablePath.length > 0 ? e = this._sysWritablePath : (e = native.fileUtils.getWritablePath(), this._sysWritablePath = e);
            null == e && (e = "");
        }
        catch (e) {
        }
        return e;
    }
    downNetImage(e) {
        if (sys.isObjectValid(e) && e.length > 0) {
            let t = e;
            if ("MOBILE_BROWSER" == sys.platform || "DESKTOP_BROWSER" == sys.platform) {
                if (this.getWebNetAvatarCatch(t)) {
                    PushCenter.shared().pushEvent(PushEvent.commentDownloaderImg, t);
                }
                else {
                    if (undefined !== this._mapDownHeadStatus.get(t) && 1 === this._mapDownHeadStatus.get(t)) {
                        return;
                    }
                    this._mapDownHeadStatus.set(t, 1);
                    let e = this;
                    assetManager.loadRemote(t, ((a, s) => {
                        if (e._mapDownHeadStatus.set(t, 0), null == a) {
                            try {
                                e._mapNetAvatarCatch.set(t, s);
                                PushCenter.shared().pushEvent(PushEvent.commentDownloaderImg, t);
                            }
                            catch (e) {
                                TLog.printError("------ on browser load img err:", e);
                            }
                        }
                    }));
                }
            }
            else if (sys.os === sys.OS.ANDROID || sys.os === sys.OS.OHOS || sys.os === sys.OS.IOS || sys.os === sys.OS.OSX) {
                let e = this.getSysWritablePath() + this._util.NET_IMAGE_CATCH_FOLDER;
                native.fileUtils.isDirectoryExist(e) || native.fileUtils.createDirectory(e);
                let a = this.getImageFormat(t), s = e + "/" + MD5.Instance.hex_md5(t) + "." + a;
                if (native.fileUtils.isFileExist(s)) {
                    PushCenter.shared().pushEvent(PushEvent.commentDownloaderImg, t);
                }
                else {
                    if (undefined !== this._mapDownHeadStatus.get(s) && 1 === this._mapDownHeadStatus.get(s)) {
                        return;
                    }
                    this._mapDownHeadStatus.set(s, 1);
                    let e = this, a = s, i = 0;
                    this.downLoadImage(e, t, i, a, (() => {
                        PushCenter.shared().pushEvent(PushEvent.commentDownloaderImg, t);
                    }));
                }
            }
        }
    }
    getImageFormat(e) {
        const t = e.match(/\.(png|jpe?g|webp)(\?.*)?$/i);
        return t ? t[1].toLowerCase() : "png";
    }
    updateNetImage(e, t, s, i, r) {
        if (t && sys.isObjectValid(t) && t.length > 0) {
            let h = t;
            if ("MOBILE_BROWSER" == sys.platform || "DESKTOP_BROWSER" == sys.platform) {
                if (ToolUtils.isObjValid(e)) {
                    if (this._netSpriteFrame.has(h)) {
                        let t = e.getComponent(Sprite);
                        if (t.spriteFrame != this._netSpriteFrame.get(h) && (t.spriteFrame = this._netSpriteFrame.get(h)), s) {
                            e.getComponent(UITransform).setContentSize(s);
                        }
                        return void (i && i());
                    }
                    let t = this.getWebNetAvatarCatch(h);
                    if (t) {
                        let o = e.getComponent(Sprite), u = SpriteFrame.createWithImage(t);
                        if (this._netSpriteFrame.set(h, u), sys.isObjectValid(r) && (u.insetTop = r.insetTop, u.insetBottom = r.insetBottom, u.insetLeft = r.insetLeft, u.insetRight = r.insetRight, u.rect = r.rect), o.spriteFrame != u && (o.spriteFrame = u), s) {
                            e.getComponent(UITransform).setContentSize(s);
                        }
                        i && i();
                    }
                    else {
                        if (undefined !== this._mapDownHeadStatus.get(h) && 1 === this._mapDownHeadStatus.get(h)) {
                            return;
                        }
                        this._mapDownHeadStatus.set(h, 1);
                        let t = this, o = e;
                        assetManager.loadRemote(h, ((e, u) => {
                            if (t._mapDownHeadStatus.set(h, 0), null == e) {
                                try {
                                    t._mapNetAvatarCatch.set(h, u);
                                    let e = SpriteFrame.createWithImage(u);
                                    if (sys.isObjectValid(r) && (e.insetTop = r.insetTop, e.insetBottom = r.insetBottom, e.insetLeft = r.insetLeft, e.insetRight = r.insetRight, e.rect = r.rect), t._netSpriteFrame.set(h, e), "object" == typeof o && ToolUtils.isObjValid(o)) {
                                        let t = o.getComponent(Sprite);
                                        if (t.spriteFrame != e && (t.spriteFrame = e), s) {
                                            o.getComponent(UITransform).setContentSize(s);
                                        }
                                        i && i();
                                        PushCenter.shared().pushEvent(PushEvent.commentDownloaderImg, h);
                                    }
                                    else {
                                        i && i();
                                    }
                                }
                                catch (e) {
                                    TLog.printError("------ on browser load img err:", e);
                                }
                            }
                        }));
                    }
                }
            }
            else if (sys.os === sys.OS.ANDROID || sys.os === sys.OS.OHOS || sys.os === sys.OS.IOS || sys.os === sys.OS.OSX) {
                let t = this.getSysWritablePath() + this._util.NET_IMAGE_CATCH_FOLDER;
                native.fileUtils.isDirectoryExist(t) || native.fileUtils.createDirectory(t);
                let a = this.getImageFormat(h), l = t + "/" + MD5.Instance.hex_md5(h) + "." + a;
                if (native.fileUtils.isFileExist(l)) {
                    this.setCatchImage(e, l, h, s, i, r);
                }
                else {
                    if (undefined !== this._mapDownHeadStatus.get(l) && 1 === this._mapDownHeadStatus.get(l)) {
                        return;
                    }
                    this._mapDownHeadStatus.set(l, 1);
                    let t = this, a = e, n = l, o = 0;
                    this.downLoadImage(t, h, o, n, (() => {
                        t.setCatchImage(a, n, h, s, i, r);
                        PushCenter.shared().pushEvent(PushEvent.commentDownloaderImg, h);
                    }));
                }
            }
        }
    }
    preDownLoadHeadImg(e, t = "") {
        if ((!e || 0 == e.length || !Utils.shared().checkIsSysHeadImg(e)) && t.length > 0) {
            let e = t;
            if ("MOBILE_BROWSER" == sys.platform || "DESKTOP_BROWSER" == sys.platform) {
                if (!this.getWebNetAvatarCatch(e)) {
                    if (undefined !== this._mapDownHeadStatus.get(e) && 1 === this._mapDownHeadStatus.get(e)) {
                        return;
                    }
                    let t = this;
                    assetManager.loadRemote(e, ((a, s) => {
                        if (t._mapDownHeadStatus.set(e, 0), null == a) {
                            try {
                                t._mapNetAvatarCatch.set(e, s);
                                undefined !== t._mapDownPushEvent.get(e) && true === t._mapDownPushEvent.get(e) && t._mapDownPushEvent.set(e, false);
                            }
                            catch (e) {
                                TLog.printError("------ on browser load img err:", e);
                            }
                        }
                        else {
                            TLog.printError("load avatar_url error= " + a);
                        }
                    }));
                }
            }
            else if (sys.os === sys.OS.ANDROID || sys.os === sys.OS.OHOS || sys.os === sys.OS.IOS || sys.os === sys.OS.OSX) {
                let t = this.getSysWritablePath() + this._util.HEAD_CATCH_FOLDER;
                native.fileUtils.isDirectoryExist(t) || native.fileUtils.createDirectory(t);
                let a = this.getImageFormat(e), s = t + "/" + MD5.Instance.hex_md5(e) + "." + a;
                if (!native.fileUtils.isFileExist(s)) {
                    if (undefined !== this._mapDownHeadStatus.get(s) && 1 === this._mapDownHeadStatus.get(s)) {
                        return;
                    }
                    let t = s, a = this, i = 0;
                    this.downLoadImage(a, e, i, t, (() => {
                        undefined !== a._mapDownPushEvent.get(e) && true === a._mapDownPushEvent.get(e) && a._mapDownPushEvent.set(e, false);
                    }));
                }
            }
        }
    }
    setNomalHeadImag(e, t, s = "", i = size(114, 114)) {
        if (t && t.length > 0 && Utils.shared().checkIsSysHeadImg(t)) {
            var n = t.indexOf(".png");
            if (-1 == n) {
                return;
            }
            let s = t.substring(0, n);
            if (sys.isObjectValid(this._headSpAt) && this._headSpAt.isValid) {
                if (ToolUtils.isObjValid(e)) {
                    this.setImage(e, s, this._headSpAt);
                    e.getComponent(UITransform).setContentSize(i);
                }
            }
            else {
                try {
                    let t = this, a = e;
                    resources.load(BundleNameDefined.nomal_head_path, SpriteAtlas, ((e, r) => {
                        if (null == e) {
                            if (t._headSpAt = r, t._headSpAt.addRef(), "object" == typeof a && ToolUtils.isObjValid(a)) {
                                t.setImage(a, s, t._headSpAt);
                                a.getComponent(UITransform).setContentSize(i);
                            }
                        }
                        else {
                            TLog.printError("load head_ui error= " + e);
                        }
                    }));
                }
                catch (e) {
                }
            }
        }
        else {
            ;
        }
    }
    updateHeadImg(e, t, s = "", i = size(114, 114), h, u = false) {
        let d = h;
        if (t && t.length > 0 && Utils.shared().checkIsSysHeadImg(t)) {
            this.setNomalHeadImag(e, t, s, i);
        }
        else if (sys.isObjectValid(s) && s.length > 0) {
            let t = s;
            if ("MOBILE_BROWSER" == sys.platform || "DESKTOP_BROWSER" == sys.platform) {
                if (!ToolUtils.isObjValid(e)) {
                    return;
                }
                if (this._netSpriteFrame.has(t)) {
                    let a = e.getComponent(Sprite);
                    return a.spriteFrame != this._netSpriteFrame.get(t) && (a.spriteFrame = this._netSpriteFrame.get(t)), void e.getComponent(UITransform).setContentSize(i);
                }
                let a = this.getWebNetAvatarCatch(t);
                if (a) {
                    let s = e.getComponent(Sprite), r = SpriteFrame.createWithImage(a);
                    this._netSpriteFrame.set(t, r);
                    s.spriteFrame != r && (s.spriteFrame = r);
                    e.getComponent(UITransform).setContentSize(i);
                }
                else {
                    if (this.setNomalHeadImag(e, d, s, i), this._mapDownPushEvent.set(t, u), undefined !== this._mapDownHeadStatus.get(t) && 1 === this._mapDownHeadStatus.get(t)) {
                        return;
                    }
                    this._mapDownHeadStatus.set(t, 1);
                    let a = this, r = e;
                    assetManager.loadRemote(t, ((e, s) => {
                        if (a._mapDownHeadStatus.set(t, 0), null == e) {
                            try {
                                a._mapNetAvatarCatch.set(t, s);
                                let e = SpriteFrame.createWithImage(s);
                                if (a._netSpriteFrame.set(t, e), undefined !== a._mapDownPushEvent.get(t) && true === a._mapDownPushEvent.get(t)) {
                                    a._mapDownPushEvent.set(t, false);
                                    PushCenter.shared().pushEvent(PushEvent.commentDownloaderImg, t);
                                }
                                else if ("object" == typeof r && ToolUtils.isObjValid(r)) {
                                    let a = r.getComponent(Sprite);
                                    a.spriteFrame != e && (a.spriteFrame = e);
                                    r.getComponent(UITransform).setContentSize(i);
                                    PushCenter.shared().pushEvent(PushEvent.commentDownloaderImg, t);
                                }
                            }
                            catch (e) {
                                TLog.printError("------ on browser load img err:", e);
                            }
                        }
                    }));
                }
            }
            else if (sys.os === sys.OS.ANDROID || sys.os === sys.OS.OHOS || sys.os === sys.OS.IOS || sys.os === sys.OS.OSX) {
                let a = this.getSysWritablePath() + this._util.HEAD_CATCH_FOLDER;
                native.fileUtils.isDirectoryExist(a) || native.fileUtils.createDirectory(a);
                let r = this.getImageFormat(t), l = a + "/" + MD5.Instance.hex_md5(t) + "." + r;
                if (native.fileUtils.isFileExist(l)) {
                    this.setCatchImage(e, l, t, i);
                }
                else {
                    if (this._mapDownPushEvent.set(l, u), undefined !== this._mapDownHeadStatus.get(l) && 1 === this._mapDownHeadStatus.get(l)) {
                        return;
                    }
                    let a = e;
                    this.setNomalHeadImag(e, d, s, i);
                    this._mapDownHeadStatus.set(l, 1);
                    let r = this, n = l, h = 0;
                    this.downLoadImage(r, t, h, n, (() => {
                        undefined !== r._mapDownPushEvent.get(n) && true === r._mapDownPushEvent.get(n) ? native.fileUtils.isFileExist(n) && PushCenter.shared().pushEvent(PushEvent.commentDownloaderImg, s) : "object" == typeof a && ToolUtils.isObjValid(a) && r.setCatchImage(a, n, t, i);
                    }));
                }
            }
        }
        else {
            d.length > 0 && this.setNomalHeadImag(e, d, "", i);
        }
    }
    setCatchImage(e, t, s, i, r, o) {
        if (ToolUtils.isObjValid(e)) {
            let h = e, u = this;
            if (this._netSpriteFrame.has(s)) {
                const e = this._netSpriteFrame.get(s);
                if ("object" == typeof h && ToolUtils.isObjValid(h)) {
                    let s = h.getComponent(Sprite);
                    if (s.spriteFrame != e && sys.isObjectValid(e) && (s.spriteFrame = e, sys.isObjectValid(o) && (e.insetTop = o.insetTop, e.insetBottom = o.insetBottom, e.insetLeft = o.insetLeft, e.insetRight = o.insetRight, e.rect = o.rect)), i) {
                        h.getComponent(UITransform).setContentSize(i);
                    }
                    r && r(true, t);
                }
                else {
                    r && r(true, t);
                }
            }
            else {
                assetManager.loadRemote(t, (function (e, d) {
                    if (!e) {
                        const e = SpriteFrame.createWithImage(d);
                        if (u._netSpriteFrame.set(s, e), ToolUtils.isObjValid(h)) {
                            let s = h.getComponent(Sprite);
                            if (s.spriteFrame != e && sys.isObjectValid(e) && (s.spriteFrame = e, sys.isObjectValid(o) && (e.insetTop = o.insetTop, e.insetBottom = o.insetBottom, e.insetLeft = o.insetLeft, e.insetRight = o.insetRight, e.rect = o.rect)), i) {
                                h.getComponent(UITransform).setContentSize(i);
                            }
                            r && r(true, t);
                        }
                    }
                }));
            }
        }
        else {
            r && r(true, t);
        }
    }
    setImage(e, t, a) {
        isValid(e, true) && null != t && isValid(a, true) && null != a.getSpriteFrame(t) && null != e.getComponent(Sprite) && e.getComponent(Sprite).spriteFrame != a.getSpriteFrame(t) && (e.getComponent(Sprite).spriteFrame = a.getSpriteFrame(t));
    }
}
