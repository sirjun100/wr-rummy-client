// @ts-nocheck
// Recovered from index.js:563
import { _decorator, Button, color, instantiate, Label, Node, ScrollView, size, Sprite, SpriteFrame, sys, UITransform, v3, view } from "cc";
import SoundManager from "./SoundManager";
import PushCenter from "./PushCenter";
import Utils from "./Utils";
import BaseLayer from "./BaseLayer";
import i18nMgr from "./i18nMgr";
import TweenTool from "./TweenTool";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("SportCricket_GameSort")
export class SportCricket_GameSort extends BaseLayer {
    public TAG: string = "SportCricket_GameSort";
    @property(Node)
    public mainRootNode: Node = null;
    @property(Node)
    public cidRootNode: Node = null;
    @property(Node)
    public chooseRootNode: Node = null;
    @property(Node)
    public cidMoban: Node = null;
    @property(Node)
    public chooseMoban: Node = null;
    @property([SpriteFrame])
    public selectBgImgs: SpriteFrame[] = [];
    @property([SpriteFrame])
    public selectBgImgs2: SpriteFrame[] = [];
    public rootNode: any = null;
    public _itemViewArr: any[] = [];
    public _closed: boolean = false;
    public _lastClick: number = 0;
    public _source: any = null;
    public _fromType: number = 0;
    public _startY: number = 0;
    public _closeAct: any = null;
    public _startAct: any = null;
    public _mainSelectId: number = 0;
    public _cidSelects: any[] = [];
    public _entrySelects: any[] = [];
    public _spotSelects: any[] = [];
    public _poolSelects: any[] = [];
    public _contestSelects: any[] = [];
    public _itemViewArr_ent: any[] = [];
    public _itemViewArr_spot: any[] = [];
    public _itemViewArr_pool: any[] = [];
    public _itemViewArr_contest: any[] = [];
    public _filter: any = null;
    public _mainCall: any = null;
    public _cidCall: any = null;
    public _chooseCall: any = null;
    public _entryInfo: any = null;
    public _spotInfo: any = null;
    public _poolInfo: any = null;
    public _contestInfo: any = null;
    public _isReset: boolean = false;
    onLoad() {
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().removeListenersByTag(this);
        this.unscheduleAllCallbacks();
    }
    init(t) {
        sys.isObjectValid(t) && sys.isObjectValid(t.source) && (this._source = { ...t.source });
        sys.isObjectValid(t) && sys.isObjectValid(t.fromType) && (this._fromType = t.fromType);
        sys.isObjectValid(t) && sys.isObjectValid(t.mainCall) && (this._mainCall = t.mainCall);
        sys.isObjectValid(t) && sys.isObjectValid(t.cidCall) && (this._cidCall = t.cidCall);
        sys.isObjectValid(t) && sys.isObjectValid(t.cids) && (this._cidSelects = t.cids);
        sys.isObjectValid(t) && sys.isObjectValid(t.chooseCall) && (this._chooseCall = t.chooseCall);
        sys.isObjectValid(t) && sys.isObjectValid(t.filter) && (this._filter = t.filter);
    }
    start() {
        super.start();
        this.initView();
        this.refreshView();
        this.showSelectView();
    }
    showSelectView() {
        let t = -view.getVisibleSize().height / 2, e = this.rootNode.getComponent(UITransform).height;
        this._startY = t - e - 20;
        this.rootNode.setPosition(v3(0, this._startY));
        this._startAct = TweenTool.moveTo(this.rootNode, 0.2, v3(0, t), "sineIn", true);
    }
    hideSelectView() {
        this._startAct && TweenTool.stopAction(this._startAct);
        this._closeAct || (this._closeAct = TweenTool.moveTo(this.rootNode, 0.2, v3(0, this._startY), "sineIn", true, (() => {
            ToolUtils.isObjValid(this.node) && this.node.destroy();
        })));
    }
    refreshView() {
        this.updateContestDetails();
    }
    updateContestDetails() {
        if (0 == this._fromType) {
            sys.isObjectValid(this._source) && sys.isObjectValid(this._source.mSortType) && (this._mainSelectId = Number(this._source.mSortType));
            this._itemViewArr.push(this.rootNode.getChildByName("item0"));
            this._itemViewArr.push(this.rootNode.getChildByName("item1"));
            for (let t = 0; t < this._itemViewArr.length; t++) {
                t == this._mainSelectId ? this.updateItemCheckStatus(this._itemViewArr[t], 1) : this.updateItemCheckStatus(this._itemViewArr[t], 0);
            }
        }
        else if (1 == this._fromType) {
            if (!sys.isObjectValid(this._source) || !sys.isObjectValid(this._source.match)) {
                return;
            }
            for (let t = 0; t < this._source.match.length; t++) {
                let e = instantiate(this.cidMoban);
                e.active = true;
                this.rootNode.getChildByName("all_ScrollView").getComponent(ScrollView).content.addChild(e);
                sys.isObjectValid(this._source.match[t].title) && (e.getChildByName("title").getComponent(Label).string = this._source.match[t].title);
                sys.isObjectValid(this._source.match[t].date) && (e.getChildByName("desc").getComponent(Label).string = this._source.match[t].date);
                e.getComponent(Button).clickEvents[0].customEventData = "" + t;
                this._itemViewArr.push(e);
                sys.isObjectValid(this._source.match[t].cid) && -1 != this._cidSelects.indexOf(this._source.match[t].cid) ? this.updateItemCheckStatus(e, 1) : this.updateItemCheckStatus(e, 0);
            }
        }
        else if (2 == this._fromType) {
            if (sys.isObjectValid(this._filter) && this._filter.length > 0) {
                for (let t = 0; t < this._filter.length; t++) {
                    1 == Number(this._filter[t].type) ? this._entrySelects = this._filter[t].item_id : 2 == Number(this._filter[t].type) ? this._spotSelects = this._filter[t].item_id : 3 == Number(this._filter[t].type) ? this._poolSelects = this._filter[t].item_id : 5 == Number(this._filter[t].type) && (this._contestSelects = this._filter[t].item_id);
                }
            }
            let t = null, e = null, i = null, s = null;
            for (let o = 0; o < this._source.contest.length; o++) {
                1 == Number(this._source.contest[o].type) ? t = this._source.contest[o] : 2 == Number(this._source.contest[o].type) ? e = this._source.contest[o] : 3 == Number(this._source.contest[o].type) ? i = this._source.contest[o] : 5 == Number(this._source.contest[o].type) && (s = this._source.contest[o]);
            }
            this._entryInfo = t;
            this._spotInfo = e;
            this._poolInfo = i;
            this._contestInfo = s;
            let o = -44, l = [-254, -84, 86, 256], h = o, n = this.rootNode.getChildByName("all_ScrollView").getComponent(ScrollView).content;
            if (sys.isObjectValid(t) && sys.isObjectValid(t.item)) {
                for (let e = 0; e < t.item.length; e++) {
                    let i = instantiate(this.chooseMoban);
                    i.active = true;
                    this.rootNode.getChildByName("all_ScrollView").getComponent(ScrollView).content.addChild(i);
                    sys.isObjectValid(t.item[e].text) && (i.getChildByName("title").getComponent(Label).string = t.item[e].text);
                    i.getComponent(Button).clickEvents[0].customEventData = "ent_" + e;
                    this._itemViewArr_ent.push(i);
                    -1 != this._entrySelects.indexOf(t.item[e].id) ? this.updateItemCheckStatus(i, 1) : this.updateItemCheckStatus(i, 0);
                    let s = e % 4, n = Math.floor(e / 4);
                    i.setPosition(v3(l[s], o - 90 * n));
                    h = o - 90 * n;
                }
            }
            if (sys.isObjectValid(e) && sys.isObjectValid(e.item)) {
                h -= 80;
                n.getChildByName("spots_title").setPosition(v3(-328.519, h));
                h -= 46;
                o = h;
                for (let t = 0; t < e.item.length; t++) {
                    let i = instantiate(this.chooseMoban);
                    i.active = true;
                    this.rootNode.getChildByName("all_ScrollView").getComponent(ScrollView).content.addChild(i);
                    sys.isObjectValid(e.item[t].text) && (i.getChildByName("title").getComponent(Label).string = e.item[t].text);
                    i.getComponent(Button).clickEvents[0].customEventData = "spot_" + t;
                    this._itemViewArr_spot.push(i);
                    -1 != this._spotSelects.indexOf(e.item[t].id) ? this.updateItemCheckStatus(i, 1) : this.updateItemCheckStatus(i, 0);
                    let s = t % 4, n = Math.floor(t / 4);
                    i.setPosition(v3(l[s], o - 90 * n));
                    h = o - 90 * n;
                }
            }
            else {
                n.getChildByName("spots_title").active = false;
            }
            if (sys.isObjectValid(i) && sys.isObjectValid(i.item)) {
                h -= 80;
                n.getChildByName("pool_title").setPosition(v3(-328.519, h));
                h -= 46;
                o = h;
                for (let t = 0; t < i.item.length; t++) {
                    let e = instantiate(this.chooseMoban);
                    e.active = true;
                    this.rootNode.getChildByName("all_ScrollView").getComponent(ScrollView).content.addChild(e);
                    sys.isObjectValid(i.item[t].text) && (e.getChildByName("title").getComponent(Label).string = i.item[t].text);
                    e.getComponent(Button).clickEvents[0].customEventData = "pool_" + t;
                    this._itemViewArr_pool.push(e);
                    -1 != this._poolSelects.indexOf(i.item[t].id) ? this.updateItemCheckStatus(e, 1) : this.updateItemCheckStatus(e, 0);
                    let s = t % 4, n = Math.floor(t / 4);
                    e.setPosition(v3(l[s], o - 90 * n));
                    h = o - 90 * n;
                }
            }
            else {
                n.getChildByName("pool_title").active = false;
            }
            if (sys.isObjectValid(s) && sys.isObjectValid(s.item)) {
                h -= 80;
                n.getChildByName("contest_title").setPosition(v3(-328.519, h));
                h -= 46;
                o = h;
                l = [-230, 0, 230];
                for (let t = 0; t < s.item.length; t++) {
                    let e = instantiate(this.chooseMoban);
                    e.active = true;
                    e.getComponent(UITransform).contentSize = size(210, 60);
                    e.getChildByName("bg").getComponent(UITransform).contentSize = size(210, 60);
                    this.rootNode.getChildByName("all_ScrollView").getComponent(ScrollView).content.addChild(e);
                    sys.isObjectValid(s.item[t].text) && (e.getChildByName("title").getComponent(Label).string = s.item[t].text);
                    e.getComponent(Button).clickEvents[0].customEventData = "contest_" + t;
                    this._itemViewArr_contest.push(e);
                    -1 != this._contestSelects.indexOf(s.item[t].id) ? this.updateItemCheckStatus(e, 1) : this.updateItemCheckStatus(e, 0);
                    let i = t % 3, n = Math.floor(t / 3);
                    e.setPosition(v3(l[i], o - 75 * n));
                    h = o - 75 * n;
                }
            }
            h -= 80;
            this.rootNode.getChildByName("all_ScrollView").getComponent(ScrollView).content.getComponent(UITransform).contentSize = size(702, -1 * h);
        }
    }
    onCloseButtonClick(t, e) {
        SoundManager.shared().playFx("click");
        sys.now() - this._lastClick < 500 || (this._lastClick = sys.now(), this.onBackView());
    }
    initView() {
        this.mainRootNode.active = 0 == this._fromType;
        this.cidRootNode.active = 1 == this._fromType;
        this.chooseRootNode.active = 2 == this._fromType;
        0 == this._fromType ? this.rootNode = this.mainRootNode : 1 == this._fromType ? this.rootNode = this.cidRootNode : this.rootNode = this.chooseRootNode;
        this.fitScreen();
    }
    onChooseItemCheckClick(t, e) {
        if (SoundManager.shared().playFx("click"), sys.now() - this._lastClick < 200) {
            return;
        }
        this._lastClick = sys.now();
        let i = e.split("_"), s = Number(i[1]);
        if ("ent" == i[0]) {
            let t = this._entryInfo.item[s].id;
            -1 == this._entrySelects.indexOf(t) ? (this._entrySelects.push(t), this.updateItemCheckStatus(this._itemViewArr_ent[s], 1)) : (this._entrySelects.splice(this._entrySelects.indexOf(t), 1), this.updateItemCheckStatus(this._itemViewArr_ent[s], 0));
        }
        else if ("spot" == i[0]) {
            let t = this._spotInfo.item[s].id;
            -1 == this._spotSelects.indexOf(t) ? (this._spotSelects.push(t), this.updateItemCheckStatus(this._itemViewArr_spot[s], 1)) : (this._spotSelects.splice(this._spotSelects.indexOf(t), 1), this.updateItemCheckStatus(this._itemViewArr_spot[s], 0));
        }
        else if ("pool" == i[0]) {
            let t = this._poolInfo.item[s].id;
            -1 == this._poolSelects.indexOf(t) ? (this._poolSelects.push(t), this.updateItemCheckStatus(this._itemViewArr_pool[s], 1)) : (this._poolSelects.splice(this._poolSelects.indexOf(t), 1), this.updateItemCheckStatus(this._itemViewArr_pool[s], 0));
        }
        else if ("contest" == i[0]) {
            let t = this._contestInfo.item[s].id;
            -1 == this._contestSelects.indexOf(t) ? (this._contestSelects.push(t), this.updateItemCheckStatus(this._itemViewArr_contest[s], 1)) : (this._contestSelects.splice(this._contestSelects.indexOf(t), 1), this.updateItemCheckStatus(this._itemViewArr_contest[s], 0));
        }
    }
    onCidItemCheckClick(t, e) {
        if (SoundManager.shared().playFx("click"), sys.now() - this._lastClick < 200) {
            return;
        }
        this._lastClick = sys.now();
        let i = Number(e), s = this._source.match[i].cid;
        -1 == this._cidSelects.indexOf(s) ? (this._cidSelects.push(s), this.updateItemCheckStatus(this._itemViewArr[i], 1)) : (this._cidSelects.splice(this._cidSelects.indexOf(s), 1), this.updateItemCheckStatus(this._itemViewArr[i], 0));
    }
    onMainItemCheckClick(t, e) {
        if (SoundManager.shared().playFx("click"), !(sys.now() - this._lastClick < 200)) {
            this._lastClick = sys.now();
            this._mainSelectId = Number(e);
            for (let t = 0; t < this._itemViewArr.length; t++) {
                t == this._mainSelectId ? this.updateItemCheckStatus(this._itemViewArr[t], 1) : this.updateItemCheckStatus(this._itemViewArr[t], 0);
            }
        }
    }
    updateItemCheckStatus(t, e) {
        ToolUtils.isObjValid(t) && (1 == e ? (2 == this._fromType ? t.getChildByName("bg").getComponent(Sprite).spriteFrame = this.selectBgImgs2[0] : t.getChildByName("bg").getComponent(Sprite).spriteFrame = this.selectBgImgs[0], t.getChildByName("title").getComponent(Label).color = color(51, 51, 51), i18nMgr.shared().changeLabelFont(t.getChildByName("title").getComponent(Label), true)) : (2 == this._fromType ? t.getChildByName("bg").getComponent(Sprite).spriteFrame = this.selectBgImgs2[1] : t.getChildByName("bg").getComponent(Sprite).spriteFrame = this.selectBgImgs[1], t.getChildByName("title").getComponent(Label).color = color(102, 102, 102), i18nMgr.shared().changeLabelFont(t.getChildByName("title").getComponent(Label), false)));
    }
    onButtonClick(t, e) {
        if (SoundManager.shared().playFx("click"), !(sys.now() - this._lastClick < 500)) {
            if (this._lastClick = sys.now(), "main_assure" == e) {
                sys.isObjectValid(this._mainCall) && this._mainCall(this._mainSelectId);
                this.onBackView(true);
            }
            else if ("cid_assure" == e) {
                sys.isObjectValid(this._cidCall) && (0 == this._cidSelects.length && this._isReset || this._cidCall(this._cidSelects));
                this.onBackView(true);
            }
            else if ("cid_reset" == e) {
                this._isReset = true;
                this._cidSelects = [];
                for (let t = 0; t < this._itemViewArr.length; t++) {
                    this.updateItemCheckStatus(this._itemViewArr[t], 0);
                }
                sys.isObjectValid(this._cidCall) && this._cidCall(this._cidSelects);
            }
            else if ("choose_assure" == e) {
                let t = [];
                sys.isObjectValid(this._entrySelects) && this._entrySelects.length > 0 && t.push({ type: 1, item_id: this._entrySelects });
                sys.isObjectValid(this._spotSelects) && this._spotSelects.length > 0 && t.push({ type: 2, item_id: this._spotSelects });
                sys.isObjectValid(this._poolSelects) && this._poolSelects.length > 0 && t.push({ type: 3, item_id: this._poolSelects });
                sys.isObjectValid(this._contestSelects) && this._contestSelects.length > 0 && t.push({ type: 5, item_id: this._contestSelects });
                sys.isObjectValid(this._chooseCall) && (0 == t.length && this._isReset || this._chooseCall(t));
                this.onBackView(true);
            }
            else if ("choose_reset" == e) {
                this._isReset = true;
                this._entrySelects = [];
                for (let t = 0; t < this._itemViewArr_ent.length; t++) {
                    this.updateItemCheckStatus(this._itemViewArr_ent[t], 0);
                }
                this._poolSelects = [];
                for (let t = 0; t < this._itemViewArr_pool.length; t++) {
                    this.updateItemCheckStatus(this._itemViewArr_pool[t], 0);
                }
                this._spotSelects = [];
                for (let t = 0; t < this._itemViewArr_spot.length; t++) {
                    this.updateItemCheckStatus(this._itemViewArr_spot[t], 0);
                }
                this._contestSelects = [];
                for (let t = 0; t < this._itemViewArr_contest.length; t++) {
                    this.updateItemCheckStatus(this._itemViewArr_contest[t], 0);
                }
                sys.isObjectValid(this._chooseCall) && this._chooseCall([]);
            }
        }
    }
    onBackView(t = true) {
        t && (Utils.shared().hideLoading(), this.hideSelectView());
    }
    fitScreen() {
        ToolUtils.adaptSafeArea(this.rootNode);
        sys.getSafeAreaRect().y;
    }
}
