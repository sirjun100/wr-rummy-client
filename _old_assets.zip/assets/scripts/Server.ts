// @ts-nocheck
// Recovered from index.js:507
import { _decorator, Component, director, EventTarget, instantiate, Prefab, resources, sys } from "cc";
import Base64 from "./Base64";
import GameConfig from "./GameConfig";
import gameNetworkDelay from "./gameNetworkDelay";
import NetConfig from "./NetConfig";
import PushCenter from "./PushCenter";
import PushEvent from "./PushEvent";
import CompressUtils from "./CompressUtils";
import HttpManager from "./HttpManager";
import BundleNameDefined from "./BundleNameDefined";
import { ToolUtils } from "./ToolUtils";
const { ccclass } = _decorator;
@ccclass("Server")
export default class Server extends Component {
    static instance = null;
    public ws: any = null;
    public _msg_queue: any[] = [];
    public is_lock: boolean = false;
    public _key: number = 13;
    public _open_cb: any = null;
    public _reconnect_cb: any = null;
    public netNode: any = null;
    public isLoadNetNode: boolean = false;
    public eventDisptch: EventTarget = new EventTarget;
    public _eventArr: any[] = [];
    public _webHost: string = "";
    public is_Reconnect: boolean = false;
    public isSocketUsed: boolean = false;
    public lockReconnect: boolean = false;
    private reconnectGeneration: number = 0;
    private connectionStartedAt: number = 0;
    private lastReceivedAt: number = 0;
    private heartbeatPendingAt: number = 0;
    private lastConnectionCheckAt: number = 0;
    private lastNetworkType: number = -1;
    private forcedOfflineHandler: ((message: any) => void) | null = null;
    setForcedOfflineHandler(handler: (message: any) => void) {
        this.forcedOfflineHandler = handler;
    }
    static shared() : Server {
        return null == this.instance && (this.instance = new Server, this.instance.loadNetNode()), this.instance;
    }
    dispatch(e, t) {
        if (Number(e) === NetConfig.SERVER_FORCED_OFFLINE) {
            this.forcedOfflineHandler?.(t);
            return;
        }
        ToolUtils.has_comm_alert && (ToolUtils.has_comm_alert = false, PushCenter.shared().pushEvent(PushEvent.HideCommDlg));
        ToolUtils.has_reconnect && (ToolUtils.has_reconnect = false, PushCenter.shared().pushEvent(PushEvent.RefreshRoomDesk));
        gameNetworkDelay.shared().setActiveDisconnect(false);
        gameNetworkDelay.shared().updateNetworktime();
        this.eventDisptch.emit(e, t);
    }
    regDispatch(e, t, s) {
        let n = { name: e, cb: this.eventDisptch.on(e, t, s), tg: s };
        this._eventArr.push(n);
    }
    clearEventByTarget(e) {
        for (let t = this._eventArr.length - 1; t >= 0; t--) {
            const s = this._eventArr[t];
            s.tg == e && (this.eventDisptch.off(s.name, s.cb, s.tg), this._eventArr.splice(t, 1));
        }
    }
    clearEventByName(e) {
        this.eventDisptch.off(e);
    }
    getWSState() {
        let e = false;
        switch (this.ws.readyState) {
            case WebSocket.CONNECTING:
            case WebSocket.OPEN:
                e = true;
                break;
            case WebSocket.CLOSING:
            case WebSocket.CLOSED: e = false;
        }
        return e;
    }
    isEnable() {
        return null != this.ws && this.ws.readyState === WebSocket.OPEN;
    }
    createSocket(e) {
        if (ToolUtils.isSafeString(e).length < 1 || this.isSocketUsed) return;
        this._webHost = e;
        this.isSocketUsed = true;
        this.closeWS();
        this.connectionStartedAt = Date.now();
        const socket = this.ws = new WebSocket(e);
        socket.binaryType = "arraybuffer";
        // A queued native callback may outlive closeWS's callback unbinding.
        socket.onopen = event => { if (this.ws === socket) this.onOpen(event); };
        socket.onmessage = event => { if (this.ws === socket) this.onMessage(event); };
        socket.onclose = event => { if (this.ws === socket) this.onClose(event); };
        socket.onerror = event => { if (this.ws === socket) this.onError(event); };
    }
    setOpenCb(e) {
        this._open_cb = e;
    }
    setReconCb(e) {
        this._reconnect_cb = e;
    }
    closeWS() {
        this.reconnectGeneration++;
        this.connectionStartedAt = 0;
        this.lastReceivedAt = 0;
        this.heartbeatPendingAt = 0;
        this.pop_response();
        this.lockReconnect = false;
        this.ws && (this.ws.onopen = null, this.ws.onmessage = null, this.ws.onclose = null, this.ws.onerror = null, this.ws.close(), this.ws = null);
    }
    pauseWS() {
        this.isSocketUsed = false;
        this.closeWS();
        PushCenter.shared().pushEvent(PushEvent.HideCommLoading);
    }
    resumeWS() {
        this.isSocketUsed = true;
        this.onClose({});
        director.getScene().name == BundleNameDefined.hall_scene ? PushCenter.shared().pushEvent(PushEvent.ShowCommLoading, { nTime: 15, bUnEnableTouch: false }) : PushCenter.shared().pushEvent(PushEvent.ShowCommLoading, { nTime: 15, bUnEnableTouch: false, nomal_direction: true });
    }
    checkPauseState() {
        return this.isSocketUsed;
    }
    onMessage(e) {
        this.lastReceivedAt = Date.now();
        this.heartbeatPendingAt = 0;
        this.lock();
        this._msg_queue.push(e.data);
        this.unlock();
    }
    lock() {
        this.is_lock = true;
    }
    unlock() {
        this.is_lock = false;
    }
    update(e) {
        if (1 == this.is_lock) {
            return null;
        }
        if (this._msg_queue.length > 0) {
            return this._msg_queue.shift();
        }
        return null;
    }
    pop_response() {
        this.lock();
        this._msg_queue = [];
        this.unlock();
    }
    send(e) {
        if (e && e.cmd !== NetConfig.HEARTBEAT_CMD) {
            (globalThis as any).__rummyDiagnostics?.breadcrumb('socket send cmd=' + String(e.cmd));
        }
        if (!this.isSocketUsed || null == this.ws || this.is_Reconnect) {
            return;
        }
        if (this.ws.readyState !== WebSocket.OPEN) {
            return;
        }
        if (e.cmd === NetConfig.HEARTBEAT_CMD && !this.heartbeatPendingAt) {
            this.heartbeatPendingAt = Date.now();
        }
        let t = ToolUtils.toJsonString(e);
        if (GameConfig.GAME_SOCKET_MSG_DEBUG && (e.cmd, NetConfig.HEARTBEAT_CMD), 1 == GameConfig.SOCKET_COMPRESS_SWITCH) {
            let e = ToolUtils.getUtf8StrLen(t), s = this.arrayBuf2Str(ToolUtils.gm_xorfunc(t, this._key)), n = null;
            n = e > 256 ? CompressUtils.compress(s) : Base64.shared().encode(s);
            this.ws.send(n);
        }
        else {
            let e = Base64.shared().encode(t);
            this.ws.send(ToolUtils.gm_xorfunc(e, this._key));
        }
    }
    reset() {
        this.onBackGroundLink();
        this.unscheduleAllCallbacks();
        this.isSocketUsed = false;
        this.closeWS();
        this._webHost = "";
    }
    disconnectWebSocket() {
        this.unscheduleAllCallbacks();
        this.pop_response();
        this.isSocketUsed = false;
        this._open_cb = null;
        this._reconnect_cb = null;
        this.is_lock = false;
        this.is_Reconnect && PushCenter.shared().pushEvent(PushEvent.HideCommLoading);
        this.is_Reconnect = false;
        this._webHost = "";
        this.closeWS();
    }
    onBackGroundLink() {
        this.pop_response();
        for (let e = this._eventArr.length - 1; e >= 0; e--) {
            const t = this._eventArr[e];
            this.eventDisptch.off(t.name, t.cb, t.tg);
            this._eventArr.splice(e, 1);
        }
        this._eventArr = [];
        this._open_cb = null;
        this._reconnect_cb = null;
        this.is_Reconnect && PushCenter.shared().pushEvent(PushEvent.HideCommLoading);
        this.is_Reconnect = false;
    }
    changeWebHost(e) {
        this.isSocketUsed = false;
        this.lockReconnect = true;
        this.closeWS();
        const generation = this.reconnectGeneration;
        setTimeout((() => {
            if (generation !== this.reconnectGeneration) return;
            this.createSocket(e);
            this.lockReconnect = false;
        }), 100);
    }
    onError(e) {
        (globalThis as any).__rummyDiagnostics?.breadcrumb('socket error; reconnect');
        this.reconnect();
    }
    onClose(e) {
        (globalThis as any).__rummyDiagnostics?.breadcrumb('socket closed code=' + String(e?.code));
        this.reconnect();
    }
    onOpen(e) {
        this.lastReceivedAt = Date.now();
        this.heartbeatPendingAt = 0;
        (globalThis as any).__rummyDiagnostics?.breadcrumb('socket connected');
        this.is_Reconnect && (this.is_Reconnect = false, this._reconnect_cb && this._reconnect_cb());
        this._open_cb && this._open_cb();
    }
    arrayBuf2Str(e) {
        return (new TextDecoder).decode(new Uint8Array(e));
    }
    str2ArrayBuf(e) {
        let t = new ArrayBuffer(e.length), s = new Uint8Array(t);
        for (let t = 0, n = e.length; t < n; t++) {
            s[t] = e.charCodeAt(t);
        }
        return t;
    }
    loadNetNode() {
        1 != this.isLoadNetNode && (this.isLoadNetNode = true, null == this.netNode && resources.load("prefabs/net/netNode", Prefab, ((e, t) => {
            if (null != e) {
                return;
            }
            let s = t;
            this.netNode = instantiate(s);
            director.addPersistRootNode(this.netNode);
        })));
    }
    checkConnection() {
        const now = Date.now();
        if (now - this.lastConnectionCheckAt < 1000) return;
        this.lastConnectionCheckAt = now;
        if (ToolUtils.isGameBackground || ToolUtils.enterBackGround) return;
        if (!this.isSocketUsed || !this._webHost) {
            this.lastNetworkType = -1;
            return;
        }
        const network = sys.getNetworkType();
        const changed = this.lastNetworkType >= 0 && network > 0 && network !== this.lastNetworkType;
        this.lastNetworkType = network;
        if (network === 0) return;
        if (changed) {
            // Wi-Fi/cellular recovery can leave the old TCP connection OPEN.
            // Replace it immediately, using the existing handshake/table resume.
            (globalThis as any).__rummyDiagnostics?.breadcrumb('socket network changed; reconnect');
            const host = this._webHost;
            this.closeWS();
            this.isSocketUsed = false;
            this.createSocket(host);
            return;
        }
        if (this.lockReconnect) return;
        const connectingExpired = this.ws && this.ws.readyState === WebSocket.CONNECTING && now - this.connectionStartedAt >= 8000;
        const heartbeatExpired = this.heartbeatPendingAt > 0 && now - this.heartbeatPendingAt >= 6000;
        if (!this.ws || this.ws.readyState === WebSocket.CLOSED || connectingExpired || heartbeatExpired) {
            (globalThis as any).__rummyDiagnostics?.breadcrumb('socket watchdog; reconnect');
            this.closeWS();
            this.reconnect();
            return;
        }
        // Probe silent rummy connections; do not inject game heartbeats into
        // other games or deliberately paused/closed sockets.
        if (this.isEnable() && window.InRummyScene && ToolUtils.heart_open === 1 &&
            !this.heartbeatPendingAt && now - this.lastReceivedAt >= 5000) {
            this.send({ cmd: NetConfig.HEARTBEAT_CMD });
        }
    }
    reconnect() {
        if (ToolUtils.isGameBackground && (ToolUtils.backgroundWebSocketReconnection = true), null != this.netNode && this._webHost.length > 0) {
            if (this.lockReconnect) {
                return;
            }
            this.lockReconnect = true;
            const generation = this.reconnectGeneration;
            HttpManager.shared().doRequestSdkApiReport({ event: "game server reconnect", reqTime: sys.now() });
            setTimeout((() => {
                if (generation !== this.reconnectGeneration) return;
                this.isSocketUsed = false;
                this.createSocket(this._webHost);
                this.lockReconnect = false;
            }), 2000);
        }
    }
}
