// @ts-nocheck
// Recovered from index.js:387
import { _decorator, Button, color, EditBox, Label, Node, Sprite, SpriteFrame } from "cc";
import i18nMgr from "./i18nMgr";
import Utils from "./Utils";
import ReportConfig from "./ReportConfig";
import HttpManager from "./HttpManager";
import SoundManager from "./SoundManager";
import BaseLayer from "./BaseLayer";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("RetrievePassword")
export class RetrievePassword extends BaseLayer {
    @property(EditBox)
    public inputField: EditBox = null;
    @property(Node)
    public otp_node: Node = null;
    @property(Node)
    public show_node: Node = null;
    @property(Node)
    public bg_node: Node = null;
    @property(Node)
    public pass_node: Node = null;
    @property(EditBox)
    public pass_Edit: EditBox = null;
    @property(EditBox)
    public otp_Edit: EditBox = null;
    @property(Node)
    public close_node: Node = null;
    @property(Label)
    public text_mobile_error: Label = null;
    @property(Node)
    public pass_error: Node = null;
    @property(Node)
    public save_btn: Node = null;
    @property(SpriteFrame)
    public isOpenSpite: SpriteFrame = [];
    @property(SpriteFrame)
    public SavebtnSpite: SpriteFrame = [];
    public show: boolean = true;
    public account: any = null;
    public tel_no: any = null;
    public code: any = null;
    public inputText: string = "";
    public serialno: string = "";
    public _checkColor: any[] = [color(200, 200, 200), color(0, 140, 22)];
    start() {
        super.start();
        this.save_btn.getComponent(Button).interactable = false;
        this.save_btn.getComponent(Sprite).spriteFrame = this.SavebtnSpite[0];
        this.otp_node.active = false;
        this.inputField.node.active = true;
        this.bg_node.active = true;
        this.pass_node.active = false;
        this.show_node.getComponent(Sprite).spriteFrame = this.isOpenSpite[0];
        this.inputField.getComponent(EditBox).inputFlag = 5;
        let t = this.pass_error.getChildByName("length");
        ToolUtils.isObjValid(t) && (t.getChildByName("ic").getComponent(Sprite).color = this._checkColor[0]);
        let e = this.pass_error.getChildByName("letter");
        ToolUtils.isObjValid(e) && (e.getChildByName("ic").getComponent(Sprite).color = this._checkColor[0]);
        ToolUtils.startShowAnim(this.node.getChildByName("bgView"));
    }
    EndedpasswdField(t, e, i) {
        if (t.string.length > 7 && t.string.length < 17) {
            let t = this.pass_error.getChildByName("length");
            ToolUtils.isObjValid(t) && (t.getChildByName("ic").getComponent(Sprite).color = this._checkColor[1]);
        }
        else {
            let t = this.pass_error.getChildByName("length");
            ToolUtils.isObjValid(t) && (t.getChildByName("ic").getComponent(Sprite).color = this._checkColor[0]);
        }
        if (/^(?=.*[0-9])(?=.*[a-zA-Z])([a-zA-Z0-9]{8,16})$/.test(t.string)) {
            let t = this.pass_error.getChildByName("letter");
            ToolUtils.isObjValid(t) && (t.getChildByName("ic").getComponent(Sprite).color = this._checkColor[1]);
            this.save_btn.getComponent(Button).interactable = true;
            this.save_btn.getComponent(Sprite).spriteFrame = this.SavebtnSpite[1];
        }
        else {
            let t = this.pass_error.getChildByName("letter");
            ToolUtils.isObjValid(t) && (t.getChildByName("ic").getComponent(Sprite).color = this._checkColor[0]);
            this.save_btn.getComponent(Button).interactable = false;
            this.save_btn.getComponent(Sprite).spriteFrame = this.SavebtnSpite[0];
        }
    }
    StardotpField(t) {
        null != this.otp_Edit.string && (this.inputText = this.otp_Edit.string);
    }
    EndedotpField(t) {
        this.inputText.length > t.length ? (this.otp_node.getChildByName("" + this.inputText.length).getComponent(Label).string = "", this.inputText = t) : (t.length > 0 && t.length < 7 && (this.otp_node.getChildByName("" + t.length).getComponent(Label).string = t.slice(t.length - 1, t.length)), this.inputText = t);
    }
    clickCallback(t, e) {
        if (SoundManager.shared().playFx("click"), "submit" == e) {
            if (this.account = this.inputField.string, 10 != this.account.length) {
                return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("login.error_number"), 3);
            }
            HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Login, event: ReportConfig.login_evt.getOptNum });
            Utils.shared().showLoading(20, true);
            HttpManager.shared().doGetMobileCode(this.account, 10, 1, this.listenGetCodeCall.bind(this));
        }
        if ("close" == e && ToolUtils.isObjValid(this.node) && this.node.destroy(), "submitotp" == e) {
            let t = this.otp_node.getChildByName("editbox").getComponent(EditBox).string;
            HttpManager.shared().doPlayerRePassword(this.account, t, 10, this.serialno, this.listenGetPasswordCall.bind(this));
        }
        if ("show" == e && (this.show ? (this.show = false, this.show_node.getComponent(Sprite).spriteFrame = this.isOpenSpite[1], this.inputField.getComponent(EditBox).inputFlag = 0, this.pass_Edit.getComponent(EditBox).inputFlag = 0) : (this.show = true, this.show_node.getComponent(Sprite).spriteFrame = this.isOpenSpite[0], this.inputField.getComponent(EditBox).inputFlag = 5, this.pass_Edit.getComponent(EditBox).inputFlag = 5)), "save" == e) {
            let t = this.pass_Edit.string;
            HttpManager.shared().doPlayersetPassword(this.code, this.tel_no, t, this.serialno, this.listenSetPasswordCall.bind(this));
        }
    }
    listenSetPasswordCall(t, e, i) {
        if (Utils.shared().hideLoading(), 200 !== i) {
            Utils.shared().showCommomDialog(i18nMgr.shared().getValueByKey("utlis.text7"), "", (() => {
            }));
        }
        else {
            let t = ToolUtils.parseJson(e);
            0 === t.ret ? (ToolUtils.saveData("save_pwdno", t.data.password + ""), ToolUtils.isObjValid(this.node) && (this.pass_error.active = false, this.node.destroy(), Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text66"), 3))) : (this.pass_error.active = true, Utils.shared().showToast(t.desc, 3));
        }
    }
    listenGetPasswordCall(t, e, i) {
        if (Utils.shared().hideLoading(), 200 !== i) {
            Utils.shared().showCommomDialog(i18nMgr.shared().getValueByKey("utlis.text7"), "", (() => {
            }));
        }
        else if (ToolUtils.isObjValid(this.node)) {
            let t = ToolUtils.parseJson(e);
            0 === t.ret ? (this.code = t.data.code, this.tel_no = t.data.tel_no, this.pass_node.active = true, ToolUtils.startShowAnim(this.pass_node), this.otp_node.active = false) : Utils.shared().showToast(t.desc, 3);
        }
    }
    listenGetCodeCall(t, e, i) {
        if (Utils.shared().hideLoading(), 200 !== i) {
            Utils.shared().showCommomDialog(i18nMgr.shared().getValueByKey("utlis.text7"), "", (() => {
            }));
        }
        else if (ToolUtils.isObjValid(this.node)) {
            let t = ToolUtils.parseJson(e);
            0 === t.ret ? (this.text_mobile_error.node.active = false, this.otp_node.active = true, this.bg_node.active = false, t.data && t.data.serialno && (this.serialno = t.data.serialno)) : t.desc && t.desc.length > 0 && Utils.shared().showToast(t.desc, 3);
        }
    }
}
