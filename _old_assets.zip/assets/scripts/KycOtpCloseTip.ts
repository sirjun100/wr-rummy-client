// @ts-nocheck
// Recovered from index.js:217
import { _decorator, Node } from "cc";
import BaseLayer from "./BaseLayer";
import SoundManager from "./SoundManager";
import PushCenter from "./PushCenter";
import Utils from "./Utils";
import User from "./User";
import PushEvent from "./PushEvent";
import CommDefine from "./CommDefine";
import { TransferPlatform } from "./TransferPlatform";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("KycOtpCloseTip")
export class KycOtpCloseTip extends BaseLayer {
    @property(Node)
    public rootNode: Node = null;
    public _closed: boolean = false;
    onLoad() {
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().removeListenersByTag(this);
        this.unscheduleAllCallbacks();
    }
    init(e = null) {
    }
    start() {
        super.start();
        TransferPlatform.shared().setSoftInputMode(1);
        let e = this.node.getChildByName("mask");
        ToolUtils.showFullScreen(e);
        this.startShowAnim(this.rootNode);
    }
    onCloseButtonClick(e, t) {
        if (SoundManager.shared().playFx("click"), "back_btn" == t) {
            if (this._closed) {
                return;
            }
            this._closed = true;
            this.onBackView();
        }
    }
    onButtonClick(e, t) {
        if (SoundManager.shared().playFx("click"), "no_thanks" == t) {
            this.onBackView();
            PushCenter.shared().pushEvent(PushEvent.CloseAgeVerifySelect);
            PushCenter.shared().pushEvent(PushEvent.Close_FastOtpView);
            PushCenter.shared().pushEvent(PushEvent.Close_Store);
        }
        else if ("kefu" == t) {
            if (1 == User.shared().temp_pingbi.feedback) {
                return void Utils.shared().showToast("Coming soon", 2);
            }
            let e = { sourceType: CommDefine.TawkUser_Feedback_Source.Kyc, groupType: CommDefine.TawkUser_Feedback_Source.Kyc_Group.Verify };
            Utils.shared().doJumpLogic(PushEvent.JUMP_TO_FEEDBACK, e);
        }
    }
    onBackView(e = true) {
        e && (Utils.shared().hideLoading(), ToolUtils.isObjValid(this.node) && this.node.destroy());
    }
}
