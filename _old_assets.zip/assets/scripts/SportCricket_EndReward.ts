// @ts-nocheck
// Recovered from index.js:557
import { _decorator, Button, color, instantiate, Label, Node, ScrollView, size, Sprite, sys, UITransform, v3 } from "cc";
import SoundManager from "./SoundManager";
import PushCenter from "./PushCenter";
import { TLog } from "./TLog";
import Utils from "./Utils";
import User from "./User";
import HttpManager from "./HttpManager";
import i18nMgr from "./i18nMgr";
import BaseLayer from "./BaseLayer";
import { HttpRequest } from "./HttpRequestName";
import GameConfig from "./GameConfig";
import TableViewUtils from "./TableViewUtils";
import PushEvent from "./PushEvent";
import TweenTool from "./TweenTool";
import SportCricket_Manager from "./SportCricket_Manager";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("SportCricket_EndReward")
export class SportCricket_EndReward extends BaseLayer {
    public TAG: string = "SportCricket_EndReward";
    @property(Node)
    public rootNode: Node = null;
    @property(Node)
    public selectNode: Node = null;
    @property(ScrollView)
    public rankList: ScrollView = null;
    @property(ScrollView)
    public winList: ScrollView = null;
    @property(Node)
    public winContent: Node = null;
    @property(Node)
    public rankItem: Node = null;
    @property(Node)
    public winItem: Node = null;
    @property(Node)
    public noData: Node = null;
    public rankTable: any = null;
    public _closed: boolean = false;
    public bShowPushAnim: boolean = true;
    public _lastClick: number = 0;
    public _sourceData: any = null;
    public _itemArr: any[] = [];
    public has_next_page: number = 0;
    public cur_page: number = 1;
    public _isSendMsg: boolean = false;
    public tabWzColor: any[] = [color(147, 11, 11), color(102, 102, 102)];
    public taskAwardIconMap: Map = new Map;
    public lastClick: number = 0;
    public topEndInfo: any = null;
    public leaderBoardData: any[] = [];
    public wingsInfo: any = null;
    public totalBoardDataCount: number = 0;
    public cur_matchId: any = null;
    public cur_session_id: any = null;
    public all_reward: number = 0;
    public winners: number = 0;
    public fee: number = 0;
    public curTab: number = 0;
    public lastNodeName: string = "";
    public _enter_cb: any = null;
    public _exit_cb: any = null;
    public _namePos: any = v3();
    onLoad() {
        this._namePos = this.rankItem.getChildByName("tx_name").getPosition();
        PushCenter.shared().addListener(PushEvent.commentDownloaderImg, (t => {
            try {
                if (ToolUtils.isObjValid(this.node) && this.taskAwardIconMap.size > 0) {
                    for (const [e, i] of this.taskAwardIconMap) {
                        i == t && Utils.shared().updateNetImage(e, t, size(65, 65));
                    }
                }
            }
            catch (t) {
                TLog.printError(this.TAG, PushEvent.commentDownloaderImg, t);
            }
        }), this);
        this.fitLuckyTheme();
    }
    fitLuckyTheme() {
        0 != GameConfig.NATIVE_GAME_APP_TYPE && (this.tabWzColor = [color(221, 3, 3), color(102, 102, 102)], this.selectNode.getChildByName("bg").getComponent(Sprite).color = color(250, 250, 250, 255), this.selectNode.getChildByName("select_text1").getChildByName("line").getComponent(Sprite).color = this.tabWzColor[0], this.selectNode.getChildByName("select_text2").getChildByName("line").getComponent(Sprite).color = this.tabWzColor[0]);
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().removeListenersByTag(this);
        this.unscheduleAllCallbacks();
    }
    init(t, e = null, i = null) {
        sys.isObjectValid(t) && (sys.isObjectValid(t.session_id) && (this.cur_session_id = t.session_id), sys.isObjectValid(t.match_id) && (this.cur_matchId = t.match_id), sys.isObjectValid(t.all_reward) && (this.all_reward = t.all_reward), sys.isObjectValid(t.winners) && (this.winners = t.winners), sys.isObjectValid(t.fee) && (this.fee = t.fee), sys.isObjectValid(t.leaderBoardInfo) && this.dealLeaderBoardInfo(t.leaderBoardInfo), sys.isObjectValid(t.wingsInfo) && (this.wingsInfo = t.wingsInfo), sys.isObjectValid(t.topEndInfo) && (this.topEndInfo = t.topEndInfo));
        e && (this._enter_cb = e);
        i && (this._exit_cb = i);
        this.curTab = 0;
    }
    dealLeaderBoardInfo(t) {
        if (sys.isObjectValid(t) && sys.isObjectValid(t.my_rank) && 0 == this.leaderBoardData.length) {
            for (let e = 0, i = t.my_rank.length; e < i; e++) {
                let i = {}, a = t.my_rank[e];
                Object.keys(a).forEach((t => {
                    i[t] = a[t];
                }));
                i.isMyTeam = true;
                this.leaderBoardData.push(i);
            }
        }
        if (sys.isObjectValid(t) && sys.isObjectValid(t.list)) {
            for (let e = 0, i = t.list.length; e < i; e++) {
                this.leaderBoardData.push(t.list[e]);
            }
        }
        sys.isObjectValid(t) && sys.isObjectValid(t.page) && (this.cur_page = t.page);
        sys.isObjectValid(t) && sys.isObjectValid(t.has_next_page) && (this.has_next_page = t.has_next_page);
        sys.isObjectValid(t) && sys.isObjectValid(t.total) && (this.totalBoardDataCount = t.total);
    }
    start() {
        super.start();
        this.initView();
        let t = [this.rankItem];
        this.rankTable = this.node.addComponent(TableViewUtils);
        let e = this.rankItem.getComponent(UITransform).height;
        this.rankTable.init([], this.rankList.node, t, this.initRankItem.bind(this), 10, e, this.onScrollRankRefreshCallBack.bind(this));
        sys.isObjectValid(this.wingsInfo) || this.requestWingsList(1 == this.curTab);
        this.refreshView();
    }
    onScrollRankRefreshCallBack() {
        1 != this.has_next_page || this._isSendMsg || (this._isSendMsg = true, this.requestLeaderBoardList(this.cur_page + 1, true, (() => {
            this.updateRankList();
        })));
    }
    initRankItem(t, e, i) {
        t.active = true;
        Utils.shared().updateHeadImg(t.getChildByName("head_mask").getChildByName("head_img"), e.avatar, e.avatar_url, size(65, 65));
        e.avatar_url.length > 0 && -1 != e.avatar_url.indexOf("http") && this.taskAwardIconMap.set(t.getChildByName("head_mask").getChildByName("head_img"), e.avatar_url);
        t.getChildByName("head_kuang").getComponent(Button).clickEvents[0].customEventData = ToolUtils.isSafeString(e.team_id);
        sys.isObjectValid(e.can_preview) && 1 == e.can_preview ? t.getChildByName("head_kuang").getComponent(Button).interactable = true : t.getChildByName("head_kuang").getComponent(Button).interactable = false;
        t.getChildByName("tx_name").getComponent(Label).string = ToolUtils.format("${0}-${1}", e.name, e.team_name) || "";
        t.getChildByName("tx_point").getComponent(Label).string = ToolUtils.format("${0}", e.point);
        t.getChildByName("tx_rank").getComponent(Label).string = ToolUtils.format("${0}", e.rank);
        sys.isObjectValid(e.isMyTeam) && e.isMyTeam ? (t.getChildByName("bg").getComponent(Sprite).color = color(229, 255, 241), String(e.reward).length > 0 ? (sys.isObjectValid(e.is_chip) && 1 == e.is_chip ? (t.getChildByName("tx_win").getComponent(Label).string = ToolUtils.format("You won     ${0}", e.reward), t.getChildByName("chip").active = true, t.getChildByName("chip").setPosition(v3(-138.705, -65.906))) : (t.getChildByName("tx_win").getComponent(Label).string = ToolUtils.format("You won ${0}", e.reward), t.getChildByName("chip").active = false), t.getChildByName("tx_name").setPosition(this._namePos)) : (t.getChildByName("tx_win").getComponent(Label).string = "", t.getChildByName("tx_name").setPosition(v3(this._namePos.x, t.getChildByName("tx_point").getPosition().y)))) : (t.getChildByName("bg").getComponent(Sprite).color = color(240, 240, 240), String(e.reward).length > 0 ? (sys.isObjectValid(e.is_chip) && 1 == e.is_chip ? (t.getChildByName("tx_win").getComponent(Label).string = ToolUtils.format("Won       ${0}", e.reward), t.getChildByName("chip").active = true, t.getChildByName("chip").setPosition(v3(-175.408, -65.906))) : (t.getChildByName("tx_win").getComponent(Label).string = ToolUtils.format("Won ${0}", e.reward), t.getChildByName("chip").active = false), t.getChildByName("tx_name").setPosition(this._namePos)) : (t.getChildByName("tx_win").getComponent(Label).string = "", t.getChildByName("tx_name").setPosition(v3(this._namePos.x, t.getChildByName("tx_point").getPosition().y))));
    }
    onGetTeamClick(t, e) {
        if (SoundManager.shared().playFx("click"), sys.now() - this._lastClick < 500) {
            return;
        }
        this._lastClick = sys.now();
        let i = Number(e);
        SportCricket_Manager.shared().requestYes11_showLeaderTeam(this.cur_matchId, i, this.cur_session_id, true, this.node);
    }
    initWinItem(t, e, i) {
        t.active = true;
        t.getChildByName("tx_rank").getComponent(Label).string = ToolUtils.format("${0}", e.rank);
        t.getChildByName("prize_node").getChildByName("tx_prize").getComponent(Label).string = ToolUtils.format("${0}", e.reward);
        sys.isObjectValid(e.is_chip) && 1 == e.is_chip ? t.getChildByName("prize_node").getChildByName("chip").active = true : t.getChildByName("prize_node").getChildByName("chip").active = false;
        t.getChildByName("bg").getComponent(Sprite).color = i % 2 == 0 ? color(255, 255, 255) : color(240, 240, 240);
    }
    updateSelectView() {
        this.selectNode.getChildByName("select_text1").getChildByName("line").active = 0 == this.curTab;
        this.selectNode.getChildByName("select_text2").getChildByName("line").active = 1 == this.curTab;
        0 == this.curTab ? (this.selectNode.getChildByName("select_text1").getChildByName("Label").getComponent(Label).color = this.tabWzColor[0], this.selectNode.getChildByName("select_text2").getChildByName("Label").getComponent(Label).color = this.tabWzColor[1]) : (this.selectNode.getChildByName("select_text1").getChildByName("Label").getComponent(Label).color = this.tabWzColor[1], this.selectNode.getChildByName("select_text2").getChildByName("Label").getComponent(Label).color = this.tabWzColor[0]);
        i18nMgr.shared().changeLabelFont(this.selectNode.getChildByName("select_text1").getChildByName("Label").getComponent(Label), 0 == this.curTab);
        i18nMgr.shared().changeLabelFont(this.selectNode.getChildByName("select_text2").getChildByName("Label").getComponent(Label), 1 == this.curTab);
        let t = [];
        t.push(this.selectNode.getChildByName("select_text1").getChildByName("line"));
        t.push(this.selectNode.getChildByName("select_text2").getChildByName("line"));
        for (let e = 0; e < 2; e++) {
            if (this.curTab == e) {
                t[e].scale = v3(0, 1, 1);
                let i = TweenTool.scaleTo(t[e], 0.16, v3(1.1, 1, 1), null, false), a = TweenTool.scaleTo(t[e], 0.16, v3(1, 1, 1), null, false);
                TweenTool.sequence(t[e], true, null, i, a);
            }
            else {
                t[e].scale = v3(1, 1, 1);
            }
        }
    }
    updateTabContent() {
        0 == this.curTab ? (this.selectNode.getChildByName("rankTitles").active = true, this.selectNode.getChildByName("winTitles").active = false, this.selectNode.getChildByName("rankTitles").getChildByName("title_teams").getComponent(Label).string = ToolUtils.format("Teams(${0})", this.totalBoardDataCount), this.rankList.node.active = true, this.winList.node.active = false, this.updateRankList()) : 1 == this.curTab && (this.selectNode.getChildByName("winTitles").active = true, this.selectNode.getChildByName("rankTitles").active = false, this.winList.node.active = true, this.rankList.node.active = false, this.updateWinList(), sys.isObjectValid(this.wingsInfo) || this.requestWingsList(true, (() => {
            this.updateWinList();
        })));
    }
    updateRankList() {
        this.taskAwardIconMap.clear();
        this.rankTable.reloadData(this.leaderBoardData);
        this.noData.active = 0 == this.leaderBoardData.length;
    }
    updateWinList() {
        let t = sys.isObjectValid(this.wingsInfo) && sys.isObjectValid(this.wingsInfo.list) ? this.wingsInfo.list : [];
        this.winContent.removeAllChildren();
        for (let e = 0, i = t.length; e < i; e++) {
            let i = instantiate(this.winItem);
            this.initWinItem(i, t[e], e);
            i.active = true;
            this.winContent.addChild(i);
        }
    }
    requestLeaderBoardList(t, e = false, i = null) {
        let a = { uid: User.shared().data.uid, match_id: this.cur_matchId, session_id: this.cur_session_id, page: t };
        e && Utils.shared().showLoading(10, true, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
        }), ToolUtils.getIsNormalDirection());
        HttpManager.shared().doGetCommonRequest(a, HttpRequest.Yes11_EndLeaderBoard, ((t, a, s) => {
            if (Utils.shared().hideLoading(), 200 != s) {
                ToolUtils.isObjValid(this.node) && e && Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.request_fail"), 2);
            }
            else {
                try {
                    let t = ToolUtils.parseJson(a);
                    0 == t.ret ? sys.isObjectValid(t.data) && ToolUtils.isObjValid(this.node) && (this.cur_page != t.data.page && this.dealLeaderBoardInfo(t.data), 0 == this.curTab && (this._isSendMsg = false, i && i())) : ToolUtils.isObjValid(this.node) && e && ToolUtils.isSafeString(t.desc).length > 0 && Utils.shared().showToast(t.desc, 3);
                }
                catch (t) {
                    TLog.printError("requestLeaderBoardList err:", t.toString());
                }
            }
        }));
    }
    requestWingsList(t = false, e = null) {
        let i = { uid: User.shared().data.uid, match_id: this.cur_matchId, session_id: this.cur_session_id };
        t && Utils.shared().showLoading(10, true, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
        }), ToolUtils.getIsNormalDirection());
        let a = this.cur_session_id;
        HttpManager.shared().doGetCommonRequest(i, HttpRequest.Yes11_EndWings, ((i, s, n) => {
            if (Utils.shared().hideLoading(), 200 != n) {
                ToolUtils.isObjValid(this.node) && t && Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.request_fail"), 2);
            }
            else {
                try {
                    let i = ToolUtils.parseJson(s);
                    0 == i.ret ? sys.isObjectValid(i.data) && ToolUtils.isObjValid(this.node) && (sys.isObjectValid(this.wingsInfo) || (this.wingsInfo = []), this.wingsInfo[a] = i.data, 1 == this.curTab && e && e()) : ToolUtils.isObjValid(this.node) && t && ToolUtils.isSafeString(i.desc).length > 0 && Utils.shared().showToast(i.desc, 3);
                }
                catch (t) {
                    TLog.printError("requestwingsList err:", t.toString());
                }
            }
        }));
    }
    refreshView() {
        this.noData.active = false;
        this.updateSelectView();
        this.updateTabContent();
    }
    onCloseButtonClick(t, e) {
        if (SoundManager.shared().playFx("click"), "close" == e) {
            if (this._closed) {
                return;
            }
            this.onBackView();
        }
    }
    initView() {
        SportCricket_Manager.shared().cricket_curMatchId = 0;
        ToolUtils.showFullScreen(this.node.getChildByName("mask"));
        this.startShowAnim();
        this.fitScreen();
    }
    startShowAnim() {
        let t = v3(0, 0);
        this.rootNode.getChildByName("root").setPosition(v3(0, -896, 0));
        TweenTool.moveTo(this.rootNode.getChildByName("root"), 0.15, t, "fade", true, (() => {
            this.rootNode.getChildByName("root").setPosition(t);
        }));
    }
    onItemClick(t, e) {
        if (SoundManager.shared().playFx("click"), sys.now() - this._lastClick < 500) {
            return;
        }
        this._lastClick = sys.now();
        ToolUtils.parseJson(e).match_id;
    }
    onButtonClick(t, e) {
        if (SoundManager.shared().playFx("click"), !(sys.now() - this._lastClick < 500)) {
            if (this._lastClick = sys.now(), "leaderBoard" == e) {
                if (0 == this.curTab) {
                    return;
                }
                this.curTab = 0;
                this.updateSelectView();
                this.updateTabContent();
            }
            else if ("wings" == e) {
                if (1 == this.curTab) {
                    return;
                }
                this.curTab = 1;
                this.updateSelectView();
                this.updateTabContent();
            }
            else {
                "best_team" == e && SportCricket_Manager.shared().requestYes11_showBestTeam(this.cur_matchId, this.cur_session_id, true, this.node);
            }
        }
    }
    onBackView(t = true) {
        t && (Utils.shared().hideLoading(), this._exit_cb && this._exit_cb(), ToolUtils.isObjValid(this.node) && this.node.destroy());
    }
    fitScreen() {
    }
}
