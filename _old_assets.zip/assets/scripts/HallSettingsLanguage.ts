// @ts-nocheck
// Recovered from index.js:177
import { _decorator, Node, v3 } from "cc";
import i18nMgr from "./i18nMgr";
import PushCenter from "./PushCenter";
import PushEvent from "./PushEvent";
import SoundManager from "./SoundManager";
import HttpManager from "./HttpManager";
import BaseLayer from "./BaseLayer";
import ReportConfig from "./ReportConfig";
import User from "./User";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("HallSettingsLanguage")
export class HallSettingsLanguage extends BaseLayer {
    @property(Node)
    public info_top: Node = null;
    @property([Node])
    public languages_check: Node[] = [];
    start() {
        super.start();
        ToolUtils.adaptSafeArea(this.node.getChildByName("root"));
        let e = this.info_top.getChildByName("item" + (i18nMgr.shared().language + 1));
        this.info_top.getChildByName("check").setPosition(v3(290, e.getPosition().y));
    }
    ChangeLanguage(e, t) {
        if (SoundManager.shared().playFx("click"), t == i18nMgr.shared().language) {
            return;
        }
        i18nMgr.shared().changLanguage(Number(t));
        let n = this.info_top.getChildByName("item" + (Number(t) + 1));
        this.info_top.getChildByName("check").setPosition(v3(290, n.getPosition().y));
        PushCenter.shared().pushEvent(PushEvent.changeLanguage);
        HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Hall, event: ReportConfig.hall_evt.change_language });
    }
    onclickByClose() {
        SoundManager.shared().playFx("click");
        i18nMgr.shared().initLanguage();
        HttpManager.shared().doChangeLanguage();
        User.shared().getHallInfo();
        ToolUtils.isObjValid(this.node) && this.node.destroy();
    }
}
