// @ts-nocheck
// Recovered from index.js:483
import { _decorator, Label, Node, v3 } from "cc";
import SoundManager from "./SoundManager";
import { RUMMY_GAME_TYPE } from "./RummyDataManager";
import { TLog } from "./TLog";
import BaseLayer from "./BaseLayer";
import i18nMgr from "./i18nMgr";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("RummyRoomInfo")
export default class RummyRoomInfo extends BaseLayer {
    @property(Node)
    public point: Node = null;
    @property(Node)
    public pool: Node = null;
    @property(Node)
    public deal: Node = null;
    public currentNode: any = null;
    public roomtype: number = 0;
    onLoad() {
        this.bIsInGame = true;
        ToolUtils.showFullScreen(this.node.getChildByName("bg1"));
    }
    start() {
        this.startShowAnim(this.node.getChildByName("rootNode"));
    }
    init(t) {
        null == t && (t = 0);
        t == RUMMY_GAME_TYPE.POINTS || t == RUMMY_GAME_TYPE.PRIVATE || t == RUMMY_GAME_TYPE.MULTIPLE ? (this.point.active = true, this.pool.active = false, this.deal.active = false, this.currentNode = this.point, this.roomtype = 0, 2 == i18nMgr.shared().language && t == RUMMY_GAME_TYPE.MULTIPLE && (this.point.getChildByName("title_gamevariant").getComponent(Label).fontSize = 22, this.point.getChildByName("title_dropPoints").getComponent(Label).fontSize = 22, this.point.getChildByName("dropPoints").getComponent(Label).fontSize = 22)) : t == RUMMY_GAME_TYPE.POOL || t == RUMMY_GAME_TYPE.PRI_POOL ? (this.point.active = false, this.pool.active = true, this.deal.active = false, this.roomtype = 1, this.currentNode = this.pool) : t != RUMMY_GAME_TYPE.DEALS && t != RUMMY_GAME_TYPE.PRI_DEAL || (this.point.active = false, this.pool.active = false, this.deal.active = true, this.roomtype = 2, this.currentNode = this.deal);
    }
    refreshUI(t) {
        try {
            this.init(t.mode);
            let e = this.currentNode.getChildByName("gametype"), i = this.currentNode.getChildByName("gameVariant"), o = this.currentNode.getChildByName("pointValue"), n = this.currentNode.getChildByName("num_deck"), r = this.currentNode.getChildByName("turnTime"), a = this.currentNode.getChildByName("bonusTime"), l = this.currentNode.getChildByName("dropPoints"), u = this.currentNode.getChildByName("dealsValue"), h = this.currentNode.getChildByName("num_seat");
            e && t.GameType && (e.getComponent(Label).string = "" + t.GameType);
            i && t.GameVariant && (i.getComponent(Label).string = "" + t.GameVariant);
            o && t.PointValue && (o.getComponent(Label).string = "" + t.PointValue);
            n && t.NumberOfDecks && (n.getComponent(Label).string = "" + t.NumberOfDecks);
            r && t.TurnTime && (r.getComponent(Label).string = "" + t.TurnTime);
            a && t.BonusTime && (a.getComponent(Label).string = "" + t.BonusTime);
            l && t.DropPoints && (l.getComponent(Label).string = "" + t.DropPoints);
            u && t.Deals && (u.getComponent(Label).string = "" + t.Deals);
            h && t.NoOfSeats && (h.getComponent(Label).string = "" + t.NoOfSeats);
        }
        catch (t) {
            TLog.printError("trycatch RummyRoomInfo refreshUI:", t);
        }
    }
    onClickClose(t, e) {
        SoundManager.shared().playFx("click");
        ToolUtils.isObjValid(this.node) && this.node.destroy();
    }
    setLandscapeShow() {
        ToolUtils.getOrientation() || this.node.setRotationFromEuler(v3(0, 0, -90));
    }
    setTidKey(t) {
        this.tid_key = t;
    }
}
