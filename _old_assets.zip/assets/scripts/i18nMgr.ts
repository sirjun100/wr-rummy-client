// @ts-nocheck
// Recovered from index.js:199
import { _decorator, Font, isValid, resources, Sprite, sys } from "cc";
import { init, t, updateSceneRenderers } from "./LanguageData";
const { ccclass } = _decorator;
@ccclass
export default class i18nMgr {
    static _instance = undefined;
    public language: number = 0;
    public _font: Map = new Map;
    public allLanguages: any[] = ["en", "hi", "ta", "ur"];
    static shared(): i18nMgr {
        return null == this._instance && (this._instance = new i18nMgr), this._instance;
    }
    initLanguage() {
        let e = sys.localStorage.getItem("language");
        null != e && null != e && (this.language = Number(e), this.allLanguages[this.language] && (init(this.allLanguages[this.language]), updateSceneRenderers()));
    }
    changLanguage(e) {
        e != this.language && this.allLanguages[e] && (init(this.allLanguages[e]), updateSceneRenderers(), this.language = e, localStorage.setItem("language", String(e)));
    }
    changeLabelLanguage(t, n, i = false, ...o) {
        if (t && isValid(t, true)) {
            let l = this.getValueByKey(n);
            if (l && "" != l) {
                if (-1 == l.indexOf("${0}")) {
                    if (3 == i18nMgr.shared().language) {
                        for (let e = 0, t = o.length; e < t; e++) {
                            l = l.replace("$", o[e]);
                        }
                    }
                }
                else {
                    for (let e = 0, t = o.length; e < t; e++) {
                        l = l.replace("${" + e + "}", o[e]);
                    }
                }
                t.string = l;
            }
            this.changeLabelFont(t, i);
            sys.isObjectValid(t.node) && sys.isObjectValid(t.node.getComponent("LocalizedLabel")) && this.changeLocalizedLabelKey(t.node, n);
        }
    }
    changeLocalizedLabelKey(e, t) {
        if (sys.isObjectValid(e)) {
            let n = e.getComponent("LocalizedLabel");
            sys.isObjectValid(n) && n.key != t && (n.key = t, n.updateLabel());
        }
    }
    changeLabelFontSize(e, t) {
        e && isValid(e, true) && (e.fontSize = t);
    }
    changeLabelFontBold(e, t = false) {
        sys.isObjectValid(e.node) && sys.isObjectValid(e.node.getComponent("LocalizedLabel")) && (e.node.getComponent("LocalizedLabel").bIsBold = t, e.node.getComponent("LocalizedLabel").updateLabel());
    }
    changeLabelFont(e, t = false) {
        let n = null;
        if (n = t ? "font/font_Bold" : "font/font_Regular", null != n) {
            if (this._font && this._font.has(n)) {
                let l = this._font.get(n);
                e.font = l;
                sys.isObjectValid(e.node) && sys.isObjectValid(e.node.getComponent("LocalizedLabel")) && (e.node.getComponent("LocalizedLabel").bIsBold = t);
            }
            else {
                resources.load(n, Font, ((i, o) => {
                    null == i && sys.isObjectValid(o) && (sys.isObjectValid(this._font) || (this._font = new Map), this._font.set(n, o), sys.isObjectValid(e) && isValid(e, true) && (e.font = o, sys.isObjectValid(e.node) && sys.isObjectValid(e.node.getComponent("LocalizedLabel")) && (e.node.getComponent("LocalizedLabel").bIsBold = t)));
                }));
            }
        }
    }
    changeLabelFont2(e, t = false, n = false) {
        let s = null;
        if (s = t ? "font/font_Bold" : "font/font_Regular", n && (s = "font/Bahnschrift_cuti"), null != s) {
            if (this._font && this._font.has(s)) {
                let n = this._font.get(s);
                e.font = n;
                sys.isObjectValid(e.node) && sys.isObjectValid(e.node.getComponent("LocalizedLabel")) && (e.node.getComponent("LocalizedLabel").bIsBold = t);
            }
            else {
                resources.load(s, Font, ((n, i) => {
                    null == n && sys.isObjectValid(i) && (sys.isObjectValid(this._font) || (this._font = new Map), this._font.set(s, i), sys.isObjectValid(e) && isValid(e, true) && (e.font = i, sys.isObjectValid(e.node) && sys.isObjectValid(e.node.getComponent("LocalizedLabel")) && (e.node.getComponent("LocalizedLabel").bIsBold = t)));
                }));
            }
        }
    }
    changeSpriteLanguage(e, t, n) {
        let l = e.getComponent("LocalizedSprite");
        sys.isObjectValid(l) && (l.key == t && l.spriteFrame == n || (e.getComponent(Sprite).spriteFrame = n, l.key = t, l.spriteFrame = n, l.updateSprite()));
    }
    getValueByKey(e) {
        return t(e);
    }
}
