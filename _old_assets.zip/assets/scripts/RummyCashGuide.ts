// @ts-nocheck
// Recovered from index.js:431
import { _decorator, Label, Node } from "cc";
import BaseLayer from "./BaseLayer";
import Utils from "./Utils";
import SoundManager from "./SoundManager";
import User from "./User";
import HowToPlayDefined from "./HowToPlayDefined";
import HttpManager from "./HttpManager";
import i18nMgr from "./i18nMgr";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("RummyCashGuide")
export class RummyCashGuide extends BaseLayer {
    @property(Node)
    public tipsNode: Node = null;
    @property(Node)
    public prizeNode: Node = null;
    public callfun: any = null;
    start() {
        super.start();
        let e = this.node.getChildByName("mask");
        ToolUtils.showFullScreen(e);
        this.initView();
        ToolUtils.startShowAnim(this.node.getChildByName("rootNode"));
        HttpManager.shared().doGetCommonRequest({ type: 1 }, "BeginnerGuide.exerciseGameReport", null);
    }
    initView() {
        1 == i18nMgr.shared().language && (this.tipsNode.getComponent(Label).fontSize = 24);
        this.prizeNode.getChildByName("num").getComponent(Label).string = ToolUtils.parse_double(User.shared().data.beginner_guide.cash_reward, 0);
    }
    setTidKey(e) {
        this.tid_key = e;
    }
    setParaData(e) {
        this.callfun = e;
    }
    getRoomVid() {
        let e = 0, t = User.shared().roomTable.pointsrummy.crashlist, i = [];
        if (null != t && t.length > 0) {
            for (let e = 0, n = t.length; e < n; e++) {
                6 == t[e].player && 1 == t[e].mode && i.push(t[e]);
            }
        }
        if (null != i && i.length > 0) {
            for (let t = 0, n = i.length; t < n; t++) {
                let n = i[t];
                User.shared().data.money >= n.entry && (e = n.vid);
            }
        }
        return e;
    }
    onButtonClick(e, t) {
        if (SoundManager.shared().playFx("click"), "accept" == t) {
            if (User.shared().isCanPlayCashGame()) {
                let e = 0;
                User.shared().data.abtest_vid && (e = ToolUtils.isSafeNumber(User.shared().data.abtest_vid));
                0 == e && (e = this.getRoomVid());
                0 != e && (this.callfun && this.callfun("onSwitchCash"), Utils.shared().showLoadTable(e, HowToPlayDefined.gameId_RummyGame, null, null, null, null, null, 1), this.callfun && this.callfun("practice_exit"), ToolUtils.isObjValid(this.node) && this.node.destroy());
            }
            else {
                this.callfun && this.callfun("onNotInGame");
                this.callfun && this.callfun("practice_exit");
                ToolUtils.isObjValid(this.node) && this.node.destroy();
            }
            HttpManager.shared().doGetCommonRequest({ type: 2 }, "BeginnerGuide.exerciseGameReport", null);
        }
        else {
            this.callfun && this.callfun("guide_cancel");
            HttpManager.shared().doGetCommonRequest({ type: 3 }, "BeginnerGuide.exerciseGameReport", null);
            ToolUtils.isObjValid(this.node) && this.node.destroy();
        }
    }
}
