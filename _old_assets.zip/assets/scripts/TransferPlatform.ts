// @ts-nocheck
// Recovered from index.js:635
import { _decorator, native, sys } from "cc";
import { TLog } from "./TLog";
import PushCenter from "./PushCenter";
import PushEvent from "./PushEvent";
import i18nMgr from "./i18nMgr";
import SoundManager from "./SoundManager";
import URLConfig from "./URLConfig";
import { ToolUtils } from "./ToolUtils";
import AppInfo from "./AppInfo";
const { ccclass } = _decorator;
let O = { JAVACLASSNAME: "com/lucky/rummy/LuckyAppInfo", ImageCrop_CLASSNAME: "com/lucky/rummy/LuckyImageCrop", method_pre: "", method_next: "", ios_platform: "YsryPlatform" };
@ccclass("TransferPlatform")
export class TransferPlatform {
    static _instance = null;
    constructor() {
        window.TransferPlatform = this;
        AppInfo.shared().getIsProductVer() || (O.JAVACLASSNAME = "com/zeoy/rummy/ZeoyAppInfo", O.ImageCrop_CLASSNAME = "com/zeoy/rummy/ZeoyImageCrop");
    }
    static shared() : TransferPlatform {
        return null == this._instance && (this._instance = new TransferPlatform), this._instance;
    }
    showGoogleRewardedAd() {
        let e = 0;
        if (!sys.isNative || sys.os !== sys.OS.ANDROID && sys.os !== sys.OS.OHOS) {
            sys.isNative && (sys.os === sys.OS.IOS || (sys.os, sys.OS.OSX));
        }
        else {
            let t = O.method_pre + "showGoogleRewardedAd" + O.method_next;
            ToolUtils.ad_has_show_toast = 0;
            try {
                let r = native.reflection.callStaticMethod(O.JAVACLASSNAME, t, "()I");
                1 == r ? PushCenter.shared().pushEvent(PushEvent.ShowCommLoading, { nTime: 15, bUnEnableTouch: true, cb: () => {
                        0 == ToolUtils.ad_has_show_toast && PushCenter.shared().pushEvent(PushEvent.ShowCommToast, { str: i18nMgr.shared().getValueByKey("utlis.ad_fail_load"), time: 3 });
                        ToolUtils.ad_has_show_toast = 1;
                    } }) : PushCenter.shared().pushEvent(PushEvent.HideCommLoading);
                e = r;
            }
            catch (e) {
                PushCenter.shared().pushEvent(PushEvent.HideCommLoading);
            }
        }
        return e;
    }
    getRewardedAdNativeCallBack(e) {
        try {
            PushCenter.shared().pushEvent(PushEvent.HideCommLoading);
            "0" == e ? (ToolUtils.ad_bg_enable = SoundManager.shared().bg_enabled, SoundManager.shared().setEnabled(false), ToolUtils.report_link_id = sys.now(), ToolUtils.ad_complete = 0) : "1" == e || ("2" == e ? ToolUtils.ad_complete = 1 : "3" == e && (1 == ToolUtils.ad_complete && (PushCenter.shared().pushEvent(PushEvent.ReqAdReward, { report_scene: ToolUtils.report_scene, report_link_id: ToolUtils.report_link_id }), ToolUtils.ad_complete = 0), ToolUtils.ad_bg_enable != SoundManager.shared().bg_enabled && SoundManager.shared().setEnabled(ToolUtils.ad_bg_enable), PushCenter.shared().pushEvent(PushEvent.ShowSuperLevelUpAlert)));
        }
        catch (e) {
        }
    }
    checkHasPhonePeSdk() {
        let e = 0;
        if (sys.isNative && (sys.os === sys.OS.ANDROID || sys.os === sys.OS.OHOS)) {
            let t = O.method_pre + "hasPhonePeSdk" + O.method_next;
            try {
                e = native.reflection.callStaticMethod(O.JAVACLASSNAME, t, "()I");
            }
            catch (e) {
            }
        }
        return e;
    }
    getIsRunningOnEmulator() {
        if (!sys.isNative || sys.os !== sys.OS.ANDROID && sys.os !== sys.OS.OHOS) {
            return 0;
        }
        {
            let e = O.method_pre + "CheckIsRunningOnEmulator" + O.method_next;
            try {
                let t = native.reflection.callStaticMethod(O.JAVACLASSNAME, e, "()I"), r = Number(t);
                return isNaN(r) ? 0 : r;
            }
            catch (e) {
                return 0;
            }
        }
    }
    getHasLightSensor() {
        if (!sys.isNative || sys.os !== sys.OS.ANDROID && sys.os !== sys.OS.OHOS) {
            return 0;
        }
        {
            let e = O.method_pre + "HasLightSensor" + O.method_next;
            try {
                let t = native.reflection.callStaticMethod(O.JAVACLASSNAME, e, "()I"), r = Number(t);
                return isNaN(r) ? 0 : r;
            }
            catch (e) {
                return 0;
            }
        }
    }
    getIsPhoneCpu() {
        if (!sys.isNative || sys.os !== sys.OS.ANDROID && sys.os !== sys.OS.OHOS) {
            return 0;
        }
        {
            let e = O.method_pre + "CheckIsPhoneCpu" + O.method_next;
            try {
                let t = native.reflection.callStaticMethod(O.JAVACLASSNAME, e, "()I"), r = Number(t);
                return isNaN(r) ? 0 : r;
            }
            catch (e) {
                return 0;
            }
        }
    }
    getIsSupportCameraLedFlash() {
        if (!sys.isNative || sys.os !== sys.OS.ANDROID && sys.os !== sys.OS.OHOS) {
            return 0;
        }
        {
            let e = O.method_pre + "CheckSupportCameraLedFlash" + O.method_next;
            try {
                let t = native.reflection.callStaticMethod(O.JAVACLASSNAME, e, "()I"), r = Number(t);
                return isNaN(r) ? 0 : r;
            }
            catch (e) {
                return 0;
            }
        }
    }
    getHasBluetooth() {
        if (!sys.isNative || sys.os !== sys.OS.ANDROID && sys.os !== sys.OS.OHOS) {
            return 0;
        }
        {
            let e = O.method_pre + "HasBluetoothDevice" + O.method_next;
            try {
                let t = native.reflection.callStaticMethod(O.JAVACLASSNAME, e, "()I"), r = Number(t);
                return isNaN(r) ? 0 : r;
            }
            catch (e) {
                return 0;
            }
        }
    }
    getHasGPS() {
        if (!sys.isNative || sys.os !== sys.OS.ANDROID && sys.os !== sys.OS.OHOS) {
            return 0;
        }
        {
            let e = O.method_pre + "HasGPSDevice" + O.method_next;
            try {
                let t = native.reflection.callStaticMethod(O.JAVACLASSNAME, e, "()I"), r = Number(t);
                return isNaN(r) ? 0 : r;
            }
            catch (e) {
                return 0;
            }
        }
    }
    getBatteryTemperature() {
        if (!sys.isNative || sys.os !== sys.OS.ANDROID && sys.os !== sys.OS.OHOS) {
            return 0;
        }
        {
            let e = O.method_pre + "getBatteryTemperature" + O.method_next;
            try {
                let t = native.reflection.callStaticMethod(O.JAVACLASSNAME, e, "()I"), r = Number(t);
                return isNaN(r) ? 0 : r;
            }
            catch (e) {
                return 0;
            }
        }
    }
    getBatteryChargePlug() {
        if (!sys.isNative || sys.os !== sys.OS.ANDROID && sys.os !== sys.OS.OHOS) {
            return "";
        }
        {
            let e = O.method_pre + "getBatteryChargePlug" + O.method_next;
            try {
                let t = native.reflection.callStaticMethod(O.JAVACLASSNAME, e, "()Ljava/lang/String;");
                return t = ToolUtils.isSafeString(t), t;
            }
            catch (e) {
                return "";
            }
        }
    }
    getBatteryPercent() {
        if (!sys.isNative || sys.os !== sys.OS.ANDROID && sys.os !== sys.OS.OHOS) {
            return "";
        }
        {
            let e = O.method_pre + "getBatteryPercent" + O.method_next;
            try {
                let t = native.reflection.callStaticMethod(O.JAVACLASSNAME, e, "()Ljava/lang/String;");
                return t = ToolUtils.isSafeString(t), t;
            }
            catch (e) {
                return "";
            }
        }
    }
    getBatteryCharging() {
        if (!sys.isNative || sys.os !== sys.OS.ANDROID && sys.os !== sys.OS.OHOS) {
            return 0;
        }
        {
            let e = O.method_pre + "CheckBatteryCharging" + O.method_next;
            try {
                let t = native.reflection.callStaticMethod(O.JAVACLASSNAME, e, "()I"), r = Number(t);
                return isNaN(r) ? 0 : r;
            }
            catch (e) {
                return 0;
            }
        }
    }
    changeStatusBarVisible(e) {
    }
    setNormalFrameRate() {
    }
    setHighFrameRate() {
    }
    exitApp() {
        if (sys.isNative && (sys.os === sys.OS.ANDROID || sys.os === sys.OS.OHOS)) {
            let e = O.method_pre + "LuckyLogout" + O.method_next;
            AppInfo.shared().getIsProductVer() || (e = O.method_pre + "zeoyLogout" + O.method_next);
            try {
                native.reflection.callStaticMethod(O.JAVACLASSNAME, e, "()V") || PushCenter.shared().pushEvent(PushEvent.ShowLoginScene);
            }
            catch (e) {
            }
        }
    }
    getOsDeviceInfo() {
        return AppInfo.shared().getOsDeviceInfo();
    }
    openVibrate() {
        let e = sys.localStorage.getItem("vb_enabled"), t = true;
        if (sys.isObjectValid(e) && (t = "true" === e), t) {
            if (!sys.isNative || sys.os !== sys.OS.ANDROID && sys.os !== sys.OS.OHOS) {
                if (sys.isNative && sys.os === sys.OS.IOS) {
                    try {
                        native.reflection.callStaticMethod(O.ios_platform, "openVibrate:", "");
                    }
                    catch (e) {
                        return TLog.printError("openVibrate:", e), "";
                    }
                }
            }
            else {
                let e = O.method_pre + "openLuckyVibrate" + O.method_next;
                try {
                    native.reflection.callStaticMethod(O.JAVACLASSNAME, e, "()V");
                }
                catch (e) {
                    TLog.printError("openVibrate:", e);
                }
            }
        }
    }
    openVibrateByTime(e) {
        let t = sys.localStorage.getItem("vb_enabled"), r = true;
        if (null != t && null != t && (r = "true" === t), r) {
            if (!sys.isNative || sys.os !== sys.OS.ANDROID && sys.os !== sys.OS.OHOS) {
                if (sys.isNative && sys.os === sys.OS.IOS) {
                    try {
                        native.reflection.callStaticMethod(O.ios_platform, "openVibrate2:", String(e));
                    }
                    catch (e) {
                        return TLog.printError("openVibrateByTime:", e), "";
                    }
                }
            }
            else {
                let t = O.method_pre + "openLuckyVibrateByTime" + O.method_next;
                try {
                    native.reflection.callStaticMethod(O.JAVACLASSNAME, t, "(I)V", e);
                }
                catch (e) {
                    TLog.printError("openVibrateByTime:", e);
                }
            }
        }
    }
    getPasteBoard() {
        if (!sys.isNative || sys.os !== sys.OS.ANDROID && sys.os !== sys.OS.OHOS) {
            if (!sys.isNative || sys.os !== sys.OS.IOS) {
                return "";
            }
            try {
                let e = native.reflection.callStaticMethod(O.ios_platform, "getPasteBoard:", "");
                if (e) {
                    return ToolUtils.isSafeString(e);
                }
            }
            catch (e) {
                return TLog.printError("getPasteBoard:", e), "";
            }
        }
        else {
            let e = O.method_pre + "getLuckyPasteBoard" + O.method_next;
            try {
                let t = native.reflection.callStaticMethod(O.JAVACLASSNAME, e, "()Ljava/lang/String;");
                if (t) {
                    return t;
                }
            }
            catch (e) {
                return TLog.printError("getPasteBoard:", e), "";
            }
        }
    }
    setSoftInputMode(e) {
        if (!sys.isNative || sys.os !== sys.OS.ANDROID && sys.os !== sys.OS.OHOS) {
            sys.os == sys.OS.WINDOWS || (sys.os, sys.OS.OSX);
        }
        else {
            let t = O.method_pre + "setLuckySoftInputMode" + O.method_next;
            try {
                native.reflection.callStaticMethod(O.JAVACLASSNAME, t, "(I)V", e);
            }
            catch (e) {
                TLog.printError("getInstallRefer:", e);
            }
        }
    }
    logEvent_firebase(e, t = 0) {
        AppInfo.shared().logEvent_firebase(e, t);
    }
    setReportHost(e) {
        if (sys.isObjectValid(e) && !(e.length < 7)) {
            if (!sys.isNative || sys.os !== sys.OS.ANDROID && sys.os !== sys.OS.OHOS) {
                sys.isNative && (sys.os === sys.OS.IOS || (sys.os, sys.OS.OSX));
            }
            else {
                let t = O.method_pre + "setConfRepUrl" + O.method_next;
                try {
                    native.reflection.callStaticMethod(O.JAVACLASSNAME, t, "(Ljava/lang/String;)V", e);
                }
                catch (e) {
                }
            }
        }
    }
    openFileByApp(e, t) {
        if (!sys.isNative || sys.os !== sys.OS.ANDROID && sys.os !== sys.OS.OHOS) {
            if (!sys.isNative || sys.os != sys.OS.IOS && sys.os != sys.OS.OSX) {
                window.open(e, "_blank");
            }
            else {
                try {
                    native.bridge.sendToNative("openFileByApp", e);
                }
                catch (e) {
                    TLog.printError("openFileByApp,error:", e);
                }
            }
        }
        else {
            let r = O.method_pre + "openFileByApp" + O.method_next;
            try {
                native.reflection.callStaticMethod(O.JAVACLASSNAME, r, "(Ljava/lang/String;Ljava/lang/String;)V", e, t);
            }
            catch (e) {
            }
        }
    }
    getPhoneIMEI() {
        return AppInfo.shared().getPhoneIMEI();
    }
    getAppVersionCode() {
        return AppInfo.shared().getAppVersionCode();
    }
    getAppVersionName() {
        return AppInfo.shared().getAppVersionName();
    }
    getOS() {
        return sys.platform;
    }
    getPhoneOS() {
        return sys.platform;
    }
    getDeviceVersion() {
        return sys.os + sys.osVersion;
    }
    getFirebasePushId() {
        return AppInfo.shared().getFirebasePushId();
    }
    getAppInstanceId() {
        return AppInfo.shared().getAppInstanceId();
    }
    getGaid() {
        return AppInfo.shared().getGaid();
    }
    getAppsflyer_Adid() {
        return AppInfo.shared().getAppsflyer_Adid();
    }
    getBePowerId() {
        return AppInfo.shared().getBePowerId();
    }
    getInstallRefer(e = true) {
        return AppInfo.shared().getInstallRefer(e);
    }
    getAppInstallData(e = false) {
        return AppInfo.shared().getAppInstallData(e);
    }
    getDeviceCpuName() {
        return AppInfo.shared().getDeviceCpuName();
    }
    getDeviceCpuHz() {
        return AppInfo.shared().getDeviceCpuHz();
    }
    getDeviceMemory() {
        return AppInfo.shared().getDeviceMemory();
    }
    getAvailueMemory() {
        return AppInfo.shared().getAvailueMemory();
    }
    getDeviceLevel() {
        return AppInfo.shared().getDeviceLevel();
    }
    getDeviceType() {
        return AppInfo.shared().getDeviceType();
    }
    getNetworkType() {
        return AppInfo.shared().getNetworkType();
    }
    getPhoneBrand() {
        return AppInfo.shared().getPhoneBrand();
    }
    getMobileRelease() {
        return AppInfo.shared().getMobileRelease();
    }
    getAndroidGpType() {
        return AppInfo.shared().getAndroidGpType();
    }
    checkOpenLocationPermission() {
        return AppInfo.shared().checkOpenLocationPermission();
    }
    getLocationInfo(e = "1") {
        return AppInfo.shared().getLocationInfo(e);
    }
    shareWebPage(e) {
        AppInfo.shared().shareWebPage(e);
    }
    copyContent(e) {
        AppInfo.shared().copyContent(e);
    }
    setAutoAdapt(e = 0) {
        AppInfo.shared().setAutoAdapt(e);
    }
    orientationToPortrait(e = null) {
        AppInfo.shared().orientationToPortrait(e);
    }
    orientationToLandscape(e = null) {
        AppInfo.shared().orientationToLandscape(e);
    }
    getChannelId() {
        return AppInfo.shared().getChannelId();
    }
    checkPackageInstalled(e) {
        return AppInfo.shared().checkPackageInstalled(e);
    }
    openApplicationChat(e, t) {
        if (!sys.isNative || sys.os !== sys.OS.ANDROID && sys.os !== sys.OS.OHOS) {
            if (sys.isNative && (sys.os == sys.OS.IOS || sys.os == sys.OS.OSX)) {
                try {
                    native.reflection.callStaticMethod(O.ios_platform, "openApplicationChat:andUrlLink:", e, t);
                }
                catch (e) {
                    sys.openURL(t);
                }
            }
        }
        else {
            let r = O.method_pre + "openApplicationChat" + O.method_next;
            try {
                native.reflection.callStaticMethod(O.JAVACLASSNAME, r, "(Ljava/lang/String;Ljava/lang/String;)V", e, t);
            }
            catch (e) {
                sys.openURL(t);
            }
        }
    }
    getPackgeVersionCode(e) {
        return AppInfo.shared().getPackgeVersionCode(e);
    }
    getLocalVersionCode() {
        return AppInfo.shared().getLocalVersionCode();
    }
    startUdpReport(e, t, r) {
        return AppInfo.shared().startUdpReport(e, t, r);
    }
    getUrlParam() {
        return AppInfo.shared().getUrlParam();
    }
    sendEmail(e, t, r) {
        return AppInfo.shared().sendEmail(e, t, r);
    }
    getAdjust_Adid() {
        return AppInfo.shared().getAdjust_Adid();
    }
    openPhoto(e, t, r, a) {
        AppInfo.shared().openPhoto(e, t, r, a);
    }
    openCamera(e, t, r, a) {
        AppInfo.shared().openCamera(e, t, r, a);
    }
    getIsNewKyc() {
        return AppInfo.shared().getIsNewKyc();
    }
    getIsCanOCR() {
        return AppInfo.shared().getIsCanOCR();
    }
    image2Text(e, t, r, a) {
        AppInfo.shared().image2Text(e, t, r, r);
    }
    decodeQrCode(e) {
        return AppInfo.shared().decodeQrCode(e);
    }
    getFBOpen() {
        return AppInfo.shared().getFBOpen();
    }
    disconnectAppleAccount() {
        if (sys.isNative && (sys.os === sys.OS.IOS || sys.os === sys.OS.OSX)) {
            try {
                native.bridge.sendToNative("disconnectRsryAppleAccount");
            }
            catch (e) {
                TLog.printError("disconnectAppleAccount,error:", e);
            }
        }
    }
    logoutFacebookAccount() {
        AppInfo.shared().logoutFacebookAccount();
    }
    startFacebookLogin(e, t, r, a) {
        AppInfo.shared().startFacebookLogin(e, t, r, a);
    }
    startAppleLogin(e, t) {
        AppInfo.shared().startAppleLogin(e, t);
    }
    shareTextToApp(e, t) {
        AppInfo.shared().shareTextToApp(e, t);
    }
    getIos_idfa() {
        return "";
    }
    openGooglePlayReview() {
        if (!sys.isNative || sys.os !== sys.OS.ANDROID && sys.os !== sys.OS.OHOS) {
            sys.isNative || sys.openURL(URLConfig.googleplay_url);
        }
        else {
            let e = O.method_pre + "openGooglePlayReview" + O.method_next;
            try {
                native.reflection.callStaticMethod(O.JAVACLASSNAME, e, "()V");
            }
            catch (e) {
            }
        }
    }
    openAppstoreReview() {
        if (sys.isNative && sys.os === sys.OS.IOS) {
            try {
                native.bridge.sendToNative("openAppStoreReviewPage");
            }
            catch (e) {
                TLog.printError("openAppStoreReviewPage,error:", e);
            }
        }
        else {
            sys.isNative || sys.openURL(URLConfig.appstore_url);
        }
    }
    getLatitude() {
        return AppInfo.shared().getLatitude();
    }
    getLongitude() {
        return AppInfo.shared().getLongitude();
    }
    getDeepLinkCdKey() {
        return AppInfo.shared().getDeepLinkCdKey();
    }
    getFireBaseToken(e = false) {
        return AppInfo.shared().getFireBaseToken(e);
    }
}
