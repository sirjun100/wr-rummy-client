// @ts-nocheck
// Recovered from index.js:671
import { _decorator, Button, color, instantiate, Label, Node, Prefab, ScrollView, size, Sprite, sys, UITransform, v3, Vec3, view, Widget } from "cc";
import TableViewUtils from "./TableViewUtils";
import User from "./User";
import HttpManager from "./HttpManager";
import SoundManager from "./SoundManager";
import Utils from "./Utils";
import { TransferPlatform } from "./TransferPlatform";
import PushCenter from "./PushCenter";
import GameConfig from "./GameConfig";
import TweenTool from "./TweenTool";
import i18nMgr from "./i18nMgr";
import PushEvent from "./PushEvent";
import BaseLayer from "./BaseLayer";
import { ScrollviewUtils } from "./ScrollviewUtils";
import CommDefine from "./CommDefine";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("WalletRecode")
export class WalletRecode extends BaseLayer {
    public TAG: string = "WalletRecode";
    @property([Node])
    public select_btn: Node[] = [];
    @property(Label)
    public uid: Label = null;
    @property(Label)
    public topTips: Label = null;
    @property(ScrollView)
    public rechscollview: ScrollView = null;
    @property(Node)
    public rechmoban: Node = null;
    @property(ScrollView)
    public withscrollview: ScrollView = null;
    @property(Node)
    public withmoban: Node = null;
    @property(Node)
    public load_btn: Node = null;
    @property(Node)
    public nodata: Node = null;
    @property(Node)
    public rootNode: Node = null;
    @property(Node)
    public bgNode: Node = null;
    @property(Prefab)
    public cashHelp: Prefab = null;
    @property(Node)
    public topRootNode: Node = null;
    public curType: number = 1;
    public addCash_last_recode_id: number = 0;
    public withDraw_last_recode_id: number = 0;
    public recordData: any = null;
    public total_num: number = 0;
    public recode_table: any[] = [];
    public last_recode_data_md5: any = null;
    public with_table: any[] = [];
    public last_with_data_md5: any = null;
    public moban_data: any = null;
    public recode_id: number = 0;
    public compulsory_load: number = 0;
    public imgPath: any = null;
    public StatusString: any[] = ["store.processing", "store.succeed", "store.failed", "store.roll_back"];
    public StatusColor: any[] = [color(234, 100, 11), color(0, 131, 21), color(203, 41, 50), color(203, 41, 50)];
    public WithdrawStatusColor: any[] = [color(241, 137, 1), color(0, 140, 22), color(215, 60, 60)];
    public WithdrawStatusString: any[] = ["System Review", "Success", "Failed"];
    public recordTabView: any = null;
    public withTabView: any = null;
    public b_reloadTable: boolean = false;
    public _callback: any = null;
    public _topTipStr: any[] = [];
    public resortItemIndexs: any[] = [];
    public lastReSortItemIndexs: any[] = [];
    public _scrollUtil: any = null;
    public _itemNodes: any[] = [];
    onLoad() {
        Utils.shared().hideLoading();
        let t = view.getVisibleSize(), e = this.rootNode.getComponent(UITransform), i = this.bgNode.getComponent(UITransform), a = this.node.getComponent(UITransform);
        ToolUtils.getOrientation() ? (this.node.setRotationFromEuler(new Vec3(0, 0, 90)), e.setContentSize(t.height, t.width), i.setContentSize(t.height, t.width), a.setContentSize(t.height, t.width), this.rootNode.setPosition(v3(0, -sys.getSafeAreaRect().x, 0))) : (e.setContentSize(t.width, t.height), i.setContentSize(t.width, t.height), a.setContentSize(t.width, t.height), this.rootNode.setPosition(v3(0, -sys.getSafeAreaRect().y, 0)));
        this.fitScreen();
    }
    start() {
        super.start();
        this.uid.string = "(ID:" + User.shared().data.uid + ")";
        this.rechmoban.active = false;
        this.withmoban.active = false;
        this.load_btn.active = false;
        this.rechmoban;
        this._scrollUtil = this.node.addComponent(ScrollviewUtils);
        this._scrollUtil.initScrollviewUtils(this.rechscollview);
        1 == User.shared().temp_pingbi.tds && (this.withmoban.getComponent(UITransform).setContentSize(size(720, 300)), this.withmoban.getChildByName("txt_tds").active = false, this.withmoban.getChildByName("tds").active = false, this.withmoban.getChildByName("line1").setPosition(v3(0, -229.202)), this.withmoban.getChildByName("fid_node").setPosition(v3(-330, -267)), this.withmoban.getChildByName("time").setPosition(v3(191, -267)), this.withmoban.getChildByName("help_btn").setPosition(v3(266, -267)));
        let t = [this.withmoban];
        this.withTabView = this.node.addComponent(TableViewUtils);
        let e = this.withmoban.getComponent(UITransform).height;
        this.withTabView.init([], this.withscrollview.node, t, this.withinitCurMobanCallBack.bind(this), 20, e, this.scrollRefreshCallBack.bind(this));
        this.changeTab(this.curType, true);
        PushCenter.shared().addListener(PushEvent.commentDownloaderFile, (t => {
            TransferPlatform.shared().openFileByApp(t, "application/pdf");
        }), this);
        this.dealMultipleLanguages();
    }
    refreshChargeTable() {
        let t = [this.rechmoban];
        this.recordTabView = this.node.getComponent(TableViewUtils);
        sys.isObjectValid(this.recordTabView) && (this.recordTabView.clearAllItem(true), this.recordTabView.destroy());
        this.recordTabView = this.node.addComponent(TableViewUtils);
        let e = this.rechmoban.getComponent(UITransform).height;
        this.rechscollview.content.getComponent(UITransform).height = 1060;
        this.recordTabView.init([], this.rechscollview.node, t, this.reinitCurMobanCallBack.bind(this), 20, e, this.scrollRefreshCallBack.bind(this), false);
        this.recordTabView.setSrollCallBack(this.moveCallback.bind(this));
    }
    dealMultipleLanguages() {
        2 == i18nMgr.shared().language && (this.topTips.getComponent(Label).fontSize = 22);
    }
    onBackView() {
        this._callback && this._callback();
        ToolUtils.isObjValid(this.node) && this.node.destroy();
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().removeListenersByTag(this);
        this.unscheduleAllCallbacks();
    }
    setParaData(t) {
        this.curType = Number(t);
    }
    setCallBack(t = null) {
        this._callback = t;
    }
    setRecode_tabl(t) {
        sys.isObjectValid(t) && (this.recode_table = t);
    }
    requestWalletRecode() {
        let t = 1 == this.curType ? this.addCash_last_recode_id : this.withDraw_last_recode_id;
        HttpManager.shared().doWalletRecode(this.curType, t, this.listenRecordCallback.bind(this));
    }
    listenRecordCallback(t, e, i) {
        if (Utils.shared().hideLoading(), 0 != e.length) {
            if (200 != i) {
                alert("The login timed out, please try again");
            }
            else {
                let t = ToolUtils.parseJson(e);
                0 == t.ret && (User.shared().with_tip = t.data.rule_tips, sys.isObjectValid(this.node) && (this.recordData = t, this.refreshRecode()));
            }
        }
    }
    refreshRecode() {
        if (!sys.isObjectValid(this.recordData) || !sys.isObjectValid(this.recordData.data)) {
            return;
        }
        this.resortItemIndexs = [];
        this.lastReSortItemIndexs = [];
        let t = 1 == this.curType ? this.addCash_last_recode_id : this.withDraw_last_recode_id, e = false;
        if (null != t && 0 != t || (1 == this.recordData.data.type ? (this.recode_table = [], User.shared().StoreData_His_rec = [], this._topTipStr[0] = this.recordData.data.toptips, e = true) : 2 == this.recordData.data.type && (this.with_table = [], User.shared().StoreData_His_with = [], this._topTipStr[1] = this.recordData.data.toptips, e = true)), this.curType != this.recordData.data.type) {
            return void (e && (1 == this.recordData.data.type ? this.rechscollview.content.removeAllChildren() : this.withTabView.clearAllItem()));
        }
        this.topTips.string = this.recordData.data.toptips;
        let i = 0;
        sys.isObjectValid(this.recordData.data.list) && this.recordData.data.list.length > 0 && (i = this.recordData.data.list.length);
        let a = 0;
        if (1 == this.recordData.data.type ? a = i + this.recode_table.length : 2 == this.recordData.data.type && (a = i + this.with_table.length), i += a, 0 === i) {
            return this.nodata.active = true, void (e && (1 == this.recordData.data.type ? this.rechscollview.content.removeAllChildren() : this.withTabView.clearAllItem()));
        }
        if (this.total_num = i, this.recordData.data && this.recordData.data.total && (this.total_num = this.recordData.data.total), this.recordData.data.last_record_id == t && this.recordData.data.list.length > 0) {
            e && (1 == this.recordData.data.type ? this.rechscollview.content.removeAllChildren() : this.withTabView.clearAllItem());
        }
        else {
            if (1 == this.recordData.data.type) {
                if (sys.isObjectValid(this.recordData.data.last_record_id) && (this.addCash_last_recode_id = this.recordData.data.last_record_id), this.recode_table.length < this.total_num) {
                    for (let t = 0, e = this.recordData.data.list.length; t < e; t++) {
                        this.recode_table.push(this.recordData.data.list[t]);
                    }
                }
                User.shared().StoreData_His_rec = this.recode_table;
            }
            else if (2 == this.recordData.data.type) {
                if (sys.isObjectValid(this.recordData.data.last_record_id) && (this.withDraw_last_recode_id = this.recordData.data.last_record_id), this.with_table.length < this.total_num) {
                    for (let t = 0, e = this.recordData.data.list.length; t < e; t++) {
                        this.with_table.push(this.recordData.data.list[t]);
                    }
                }
                User.shared().StoreData_His_with = this.with_table;
            }
            if (this.nodata.active = false, 1 == this.curType) {
                this.rechscollview.node.active = true;
                this.withscrollview.node.active = false;
                let t = true;
                if (sys.isObjectValid(this.last_recode_data_md5)) {
                    let e = ToolUtils.jsonToMd5(this.recode_table);
                    this.last_recode_data_md5 == e && (t = false);
                }
                t && (this.resortItemIndexs = [], this.lastReSortItemIndexs = [], e && (1 == this.recordData.data.type ? this.rechscollview.content.removeAllChildren() : this.withTabView.clearAllItem()), this.refreshRechargeList());
            }
            else {
                this.rechscollview.node.active = false;
                this.withscrollview.node.active = true;
                let t = true;
                if (sys.isObjectValid(this.last_with_data_md5)) {
                    let e = ToolUtils.jsonToMd5(this.with_table);
                    this.last_with_data_md5 == e && (t = false);
                }
                t && (e && (1 == this.recordData.data.type ? this.rechscollview.content.removeAllChildren() : this.withTabView.clearAllItem()), this.withTabView.reloadData(this.with_table, this.b_reloadTable));
            }
            this.b_reloadTable = false;
        }
    }
    getItemNode() {
    }
    refreshRechargeList() {
        Array.isArray(this.rechscollview.content.children) && this.rechscollview.content.children.length > 0 && this.rechscollview.content.removeAllChildren();
        let t, e = 0, i = 0, a = this.recode_table.length;
        for (let i = 0; i < a; i++) {
            let a = this.recode_table[i].gst_id;
            ToolUtils.isObjValid(this._itemNodes[i]) ? (t = this._itemNodes[i], t.active = true) : (t = instantiate(this.rechmoban), t.active = true, this._itemNodes[i] = t);
            this.rechscollview.content.addChild(t);
            t.setPosition(v3(0, e));
            sys.isObjectValid(a) && a.length > 0 ? (t.getComponent(UITransform).setContentSize(size(720, 450)), e -= 470) : (t.getComponent(UITransform).setContentSize(size(720, 351.3)), e -= 371.3);
            this.reinitCurMobanCallBack(t, this.recode_table[i], i);
        }
        let s = this.rechscollview.getComponent(UITransform).contentSize;
        i = -e;
        this.rechscollview.content.getComponent(UITransform).setContentSize(size(s.width, i));
        this._scrollUtil.setScollDetails2(1, s.height, a, true, 60, this.scrollRefreshCallBack.bind(this));
    }
    reinitCurMobanCallBack(t, e, i) {
        if (null == e) {
            return;
        }
        t.active = true;
        let a = t.getChildByName("amount_node"), s = t.getChildByName("fid_node"), r = a.getChildByName("txt_amount").getComponent(Label), l = a.getChildByName("amount").getComponent(Label), h = s.getChildByName("txt_fid").getComponent(Label), n = s.getChildByName("fid").getComponent(Label), d = t.getChildByName("state").getComponent(Label), c = t.getChildByName("method").getComponent(Label), g = t.getChildByName("before").getComponent(Label), p = t.getChildByName("after").getComponent(Label), _ = t.getChildByName("time").getComponent(Label), w = t.getChildByName("help_btn"), C = t.getChildByName("txt_method"), f = t.getChildByName("txt_extra"), y = t.getChildByName("txt_before"), v = t.getChildByName("txt_after");
        l.string = "₹" + e.amount;
        c.string = e.method;
        g.string = ToolUtils.parse_double(e.beforeAmount);
        p.string = ToolUtils.parse_double(e.afterAmount);
        _.string = e.times;
        n.string = e.id;
        d.node.position = v3(331, d.node.position.y);
        let S = t.getChildByName("promotion").getComponent(Label), T = t.getChildByName("extra").getComponent(Label);
        if (5 == e.alter_type ? T.string = ToolUtils.parse_ChipNum(e.extra_amount) || "" : T.string = e.extra_amount || "", S.string = e.promotion, this.StatusString[e.status] && i18nMgr.shared().changeLabelLanguage(d, this.StatusString[e.status]), this.StatusColor[e.status] && (d.color = this.StatusColor[e.status]), w.active = true, i18nMgr.shared().changeLocalizedLabelKey(C, "store.deposit2"), i18nMgr.shared().changeLocalizedLabelKey(y, "store.recharge_before"), i18nMgr.shared().changeLocalizedLabelKey(v, "store.recharge_after"), i18nMgr.shared().changeLabelLanguage(r, "store.amounts"), i18nMgr.shared().changeLabelLanguage(h, "store.recharge_id"), e.amount_str && "string" == typeof e.amount_str && e.amount_str.length > 0 && (r.string = e.amount_str), e.t_title && "string" == typeof e.t_title && e.t_title.length > 0 && (d.string = e.t_title), 2 == e.alter_type ? i18nMgr.shared().changeLocalizedLabelKey(f, "store.extra_amounts") : 5 == e.alter_type && i18nMgr.shared().changeLocalizedLabelKey(f, "store.chip_amounts"), w.getComponent(Button).clickEvents[0].customEventData = String(e.feed_back_url), t.getChildByName("gst").active = false, sys.isObjectValid(e.gst_id) && e.gst_id.length > 0) {
            let i = t.getChildByName("gst");
            i.active = true;
            i.getComponent(Button).clickEvents[0].customEventData = String(e.gst_id);
        }
    }
    withinitCurMobanCallBack(t, e, i) {
        if (null == e) {
            return;
        }
        t.active = true;
        let a = t.getChildByName("amount_node"), s = t.getChildByName("fid_node"), r = a.getChildByName("txt_amount").getComponent(Label), l = a.getChildByName("amount").getComponent(Label), h = s.getChildByName("txt_fid").getComponent(Label), n = s.getChildByName("fid").getComponent(Label), d = t.getChildByName("state").getComponent(Label), c = t.getChildByName("method").getComponent(Label), g = t.getChildByName("before").getComponent(Label), p = t.getChildByName("after").getComponent(Label), _ = t.getChildByName("tds").getComponent(Label), C = t.getChildByName("time").getComponent(Label), f = t.getChildByName("help_btn"), y = t.getChildByName("txt_method"), v = t.getChildByName("txt_before"), S = t.getChildByName("txt_after"), T = t.getChildByName("state_btn"), B = t.getChildByName("arrow");
        sys.isObjectValid(e.process) && Array.isArray(e.process) && e.process.length > 0 ? (B.active = true, T.active = true, d.node.setPosition(v3(315, -41))) : (B.active = false, T.active = false, d.node.setPosition(v3(330, -41)));
        l.string = "₹" + e.amount;
        c.string = e.method;
        g.string = ToolUtils.parse_double(e.beforeAmount);
        p.string = ToolUtils.parse_double(e.afterAmount);
        _.string = ToolUtils.parse_double(e.tax);
        C.string = e.times;
        n.string = e.id;
        this.WithdrawStatusString[e.status] && (d.string = this.WithdrawStatusString[e.status]);
        this.WithdrawStatusColor[e.status] && (d.color = this.WithdrawStatusColor[e.status], B && (B.getComponent(Sprite).color = this.WithdrawStatusColor[e.status]));
        i18nMgr.shared().changeLabelLanguage(h, "store.withdraw_id");
        i18nMgr.shared().changeLocalizedLabelKey(y, "store.deposit3");
        i18nMgr.shared().changeLocalizedLabelKey(v, "store.recharge_after2");
        i18nMgr.shared().changeLocalizedLabelKey(S, "store.recharge_before2");
        3 == e.status ? i18nMgr.shared().changeLabelLanguage(r, "store.roll_back_amount") : i18nMgr.shared().changeLabelLanguage(r, "store.amounts");
        f.active = true;
        e.amount_str && "string" == typeof e.amount_str && e.amount_str.length > 0 && (r.string = e.amount_str);
        e.t_title && "string" == typeof e.t_title && e.t_title.length > 0 && (d.string = e.t_title);
        f.getComponent(Button).clickEvents[0].customEventData = String(e.feed_back_url);
        T.getComponent(Button).clickEvents[0].customEventData = String(i);
    }
    scrollRefreshCallBack() {
        this.recode_table.length != this.total_num && (Utils.shared().showLoading(10, false), this.requestWalletRecode());
    }
    moveCallback() {
        if (1 == this.curType && this.resortItemIndexs.length > this.lastReSortItemIndexs.length) {
            let t = this.resortItemIndexs.filter((t => !this.lastReSortItemIndexs.includes(t)));
            for (let e = 0; e < t.length; e++) {
                this.recordTabView.resetItemSize(t[e], 450 - 351.3);
            }
            this.lastReSortItemIndexs = [];
            this.lastReSortItemIndexs.push.apply(this.lastReSortItemIndexs, this.resortItemIndexs);
        }
    }
    onSwitchBtnClick(t, e) {
        SoundManager.shared().playFx("click");
        this.changeTab(Number(e));
    }
    changeTab(t, e = false) {
        this.updateSwitchBtn(t);
        this.curType = t;
        1 == this.curType ? (sys.isObjectValid(this._topTipStr[0]) && ToolUtils.isSafeString(this._topTipStr[0]).length > 0 ? this.topTips.string = this._topTipStr[0] : this.topTips.string = "", this.rechscollview.node.active = true, this.withscrollview.node.active = false, sys.isObjectValid(User.shared().StoreData_His_rec) ? (this.recode_table = User.shared().StoreData_His_rec, 0 == this.recode_table.length ? e ? (this.nodata.active = false, Utils.shared().showLoading(10, false)) : this.nodata.active = true : this.nodata.active = false) : (this.nodata.active = false, Utils.shared().showLoading(10, false, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3);
        }))), this.resortItemIndexs = [], this.lastReSortItemIndexs = [], this.last_recode_data_md5 = ToolUtils.jsonToMd5(this.recode_table), this.refreshRechargeList()) : (sys.isObjectValid(this._topTipStr[1]) && ToolUtils.isSafeString(this._topTipStr[1]).length > 0 ? this.topTips.string = this._topTipStr[1] : this.topTips.string = "", this.rechscollview.node.active = false, this.withscrollview.node.active = true, sys.isObjectValid(User.shared().StoreData_His_with) ? (this.with_table = User.shared().StoreData_His_with, 0 == this.with_table.length ? e ? (this.nodata.active = false, Utils.shared().showLoading(10, false)) : this.nodata.active = true : this.nodata.active = false) : (this.nodata.active = false, Utils.shared().showLoading(10, false, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3);
        }))), this.last_with_data_md5 = ToolUtils.jsonToMd5(this.with_table), this.withTabView.reloadData(this.with_table, this.b_reloadTable));
        this.requestWalletRecode();
    }
    updateSwitchBtn(t) {
        for (let e = 0; e < 2; e++) {
            let i = this.topRootNode.getChildByName("Label" + (e + 1)).getComponent(Label), a = this.topRootNode.getChildByName("line" + (e + 1)), s = this.topRootNode.getChildByName("tab_di" + (e + 1));
            if (e == t - 1) {
                if (this.select_btn[e].getComponent(Button).interactable = false, i.color = color(183, 0, 0, 255), i18nMgr.shared().changeLabelFontBold(i, true), a.active = true, this.curType != t) {
                    a.scale = v3(0, 1, 1);
                    let t = TweenTool.scaleTo(a, 0.16, v3(1.1, 1, 1), null, false), e = TweenTool.scaleTo(a, 0.16, v3(1, 1, 1), null, false);
                    TweenTool.sequence(a, true, null, t, e);
                }
                else {
                    a.scale = v3(1, 1, 1);
                }
                s.active = false;
            }
            else {
                this.select_btn[e].getComponent(Button).interactable = true;
                i.color = color(84, 89, 155, 255);
                i18nMgr.shared().changeLabelFontBold(i, false);
                a.scale = v3(1, 1, 1);
                e == this.curType ? TweenTool.scaleTo(a, 0.1, v3(0.2, 1, 1), null, true, (() => {
                    a.scale = v3(1, 1, 1);
                    a.active = false;
                })) : a.active = false;
                s.active = true;
            }
        }
    }
    onButtonClick(t, e) {
        SoundManager.shared().playFx("click");
        t.target;
        if ("close" == e) {
            this.onBackView();
        }
        else if ("help" == e) {
            if (null == this.node.getChildByName("CashHelp")) {
                let t = instantiate(this.cashHelp);
                t.name = "CashHelp";
                this.node.addChild(t);
                t.getComponent("CashHelp").setHelpType(6);
            }
        }
        else if ("load" == e) {
            this.requestWalletRecode();
        }
        else if ("kefu" == e) {
            if (1 == User.shared().temp_pingbi.feedback) {
                return void Utils.shared().showToast("Coming soon", 2);
            }
            let t = User.shared().data.feedback_record_pay_url;
            2 == this.curType && (t = User.shared().data.feedback_record_tx_url);
            let e = { type: this.curType, url: t, sourceType: CommDefine.TawkUser_Feedback_Source.Charge, groupType: CommDefine.TawkUser_Feedback_Source.Charge_Group.ChargeRecord };
            2 == this.curType && (e.sourceType = CommDefine.TawkUser_Feedback_Source.Withdraw, e.groupType = CommDefine.TawkUser_Feedback_Source.Withdraw_Group.WithdrawRecord);
            Utils.shared().doJumpLogic(PushEvent.JUMP_TO_FEEDBACK, e);
        }
    }
    onGstButtonClick(t, e) {
        SoundManager.shared().playFx("click");
        let i = Utils.shared().checkDownNetFileExsits(e, "pdf");
        1 == i.ret ? (Utils.shared().showToast(i18nMgr.shared().getValueByKey("store.gst_downloaded"), 2), TweenTool.delayAct(this.rootNode, (() => {
            TransferPlatform.shared().openFileByApp(i.path, "application/pdf");
        }), 2, true)) : (Utils.shared().showToast(i18nMgr.shared().getValueByKey("store.gst_download"), 5), User.shared().requestGstDownUrl(e, (t => {
            Utils.shared().downNetFile(t, e, "pdf");
        })));
    }
    onHelpButtonClick(t, e) {
        if (SoundManager.shared().playFx("click"), 1 == User.shared().temp_pingbi.feedback) {
            return void Utils.shared().showToast("Coming soon", 2);
        }
        let i = { type: 3, url: e };
        Utils.shared().doJumpLogic(PushEvent.JUMP_TO_FEEDBACK, i);
    }
    onWithdrawStateButtonClick(t, e) {
        SoundManager.shared().playFx("click");
        Array.isArray(this.with_table) && this.with_table.length > Number(e) && Utils.shared().showWithdrawalStatusView(this.with_table[Number(e)]);
    }
    getRecodeInfoById(t) {
        if (null != this.recordData.data && this.recordData.data.list && this.recordData.data.list.length > 0) {
            for (let e = 0; e < this.recordData.data.list.length; e++) {
                if (Number(this.recordData.data.list[e].id) == t) {
                    return this.recordData.data.list[e];
                }
            }
        }
        return null;
    }
    fitScreen() {
        let t = ToolUtils.adaptSafeArea(this.rootNode, 1), e = sys.getSafeAreaRect().y, i = view.getVisibleSize(), a = (i.height - GameConfig.CONFIG_SCREEN_HEIGHT) / 2 - e;
        ToolUtils.getOrientation() && (a = (i.width - GameConfig.CONFIG_SCREEN_HEIGHT) / 2);
        let s = this.rechscollview.view, o = this.withscrollview.view;
        0 != e && (sys.os === sys.OS.IOS || sys.os === sys.OS.OSX ? (this.rechscollview.node.getChildByName("view").getComponent(Widget).bottom = 30 - e, this.withscrollview.node.getChildByName("view").getComponent(Widget).bottom = 30 - e) : (this.rechscollview.node.getChildByName("view").getComponent(Widget).bottom = -e, this.withscrollview.node.getChildByName("view").getComponent(Widget).bottom = -e));
        s.setContentSize(size(s.width, s.height + a + t));
        o.setContentSize(size(o.width, o.height + a + t));
        this.rechscollview.getComponent(UITransform).setContentSize(size(s.width, s.height + a + t));
        this.withscrollview.getComponent(UITransform).setContentSize(size(o.width, o.height + a + t));
    }
}
