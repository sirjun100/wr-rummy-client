// @ts-nocheck
// Recovered from index.js:17
import { _decorator, Label } from "cc";
import SoundManager from "./SoundManager";
import BaseLayer from "./BaseLayer";
import PushEvent from "./PushEvent";
import PushCenter from "./PushCenter";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("Announcement")
export class Announcement extends BaseLayer {
    @property(Label)
    public titleLabel: Label = null;
    @property(Label)
    public contentLabel: Label = null;
    public _isNext: boolean = false;
    start() {
        super.start();
        ToolUtils.startShowAnim(this.node.getChildByName("bgView"));
    }
    initAnnoucement(t, e = false) {
        t && (t.title && (this.titleLabel.string = ToolUtils.isSafeString(t.title)), t.content && (this.contentLabel.string = ToolUtils.isSafeString(t.content)));
        this._isNext = e;
    }
    onButtonClick(t, e) {
        SoundManager.shared().playFx("click");
        "close" == e && ToolUtils.isObjValid(this.node) && (this._isNext && PushCenter.shared().pushEvent(PushEvent.Update_NextPopActivity), this.node.destroy());
    }
    onBackView() {
        ToolUtils.isObjValid(this.node) && (this._isNext && PushCenter.shared().pushEvent(PushEvent.Update_NextPopActivity), this.node.destroy());
    }
}
