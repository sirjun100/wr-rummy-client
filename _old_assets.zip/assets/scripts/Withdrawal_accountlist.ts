// @ts-nocheck
// Recovered from index.js:683
import { _decorator, Button, color, instantiate, Label, Node, ScrollView, Sprite, SpriteFrame, sys, UITransform, v3, view } from "cc";
import BaseLayer from "./BaseLayer";
import Utils from "./Utils";
import { TLog } from "./TLog";
import GameConfig from "./GameConfig";
import PushCenter from "./PushCenter";
import SoundManager from "./SoundManager";
import i18nMgr from "./i18nMgr";
import HttpManager from "./HttpManager";
import { TransferPlatform } from "./TransferPlatform";
import { ToolUtils } from "./ToolUtils";
import TweenTool from "./TweenTool";
const { ccclass, property } = _decorator;
@ccclass("Withdrawal_accountlist")
export class Withdrawal_accountlist extends BaseLayer {
    @property(Node)
    public rootNode: Node = null;
    @property(Node)
    public depositNode: Node = null;
    @property(Node)
    public recordMoban: Node = null;
    @property(Node)
    public recordScrollView: Node = null;
    @property(Node)
    public assureNode: Node = null;
    @property([SpriteFrame])
    public assureImags: SpriteFrame[] = [];
    @property([SpriteFrame])
    public select_imgs: SpriteFrame[] = [];
    public itemNodes: any[] = [];
    @property(Node)
    public qiPaoNode: Node = null;
    public _callback: any = null;
    public _curSelectIndex: any = -1;
    public _curQipaoIndex: any = -1;
    public _accountData: any = null;
    initData(t, e = null) {
        sys.isObjectValid(t) && (this._accountData = t);
        this._callback = e;
    }
    onLoad() {
        this.depositNode.active = true;
        this.adaptScreen();
    }
    start() {
        super.start();
        this.addNotify();
        this.refreshView();
        this.startShowAnim();
    }
    startShowAnim() {
        this.node.getChildByName("bg").getComponent(UITransform).contentSize;
        let t = v3(0, 0);
        this.depositNode.setPosition(v3(0, -1035, 0));
        TweenTool.moveTo(this.depositNode, 0.15, t, "fade", true, (() => {
            this.depositNode.setPosition(t);
        }));
    }
    refreshAssureState() {
        -1 == this._curSelectIndex ? this.assureNode.getComponent(Sprite).spriteFrame = this.assureImags[0] : this.assureNode.getComponent(Sprite).spriteFrame = this.assureImags[1];
    }
    refreshView() {
        if (!sys.isObjectValid(this._accountData)) {
            return;
        }
        if (this._curQipaoIndex = -1, this.qiPaoNode.active = false, this._curSelectIndex = -1, this.depositNode.getChildByName("info_node").getChildByName("balance_amt").getComponent(Label).string = "₹" + this._accountData.amount, this.assureNode.getChildByName("wz").getComponent(Label).string = `WITHDRAWAL ₹${this._accountData.amount}`, this.recordScrollView.getComponent(ScrollView).content.removeAllChildren(), this.itemNodes = [], sys.isObjectValid(this._accountData.list) && Array.isArray(this._accountData.list) && this._accountData.list.length > 0) {
            for (let t = 0; t < this._accountData.list.length; t++) {
                let e = this._accountData.list[t], i = instantiate(this.recordMoban);
                i.active = true;
                this.recordScrollView.getComponent(ScrollView).content.addChild(i);
                sys.isObjectValid(e.check) && (i.getChildByName("check_btn").getChildByName("ico").getComponent(Sprite).spriteFrame = this.select_imgs[e.check], 1 == e.check && (this._curSelectIndex = t));
                sys.isObjectValid(e.w_account) && (i.getChildByName("type_wz").getComponent(Label).string = e.w_account);
                sys.isObjectValid(e.status) && 0 == e.status ? (i.getChildByName("verify_bg").getChildByName("wz").getComponent(Label).string = "Invalid Account", sys.isObjectValid(e.status_wz) && e.status_wz.length > 0 && (i.getChildByName("verify_bg").getChildByName("wz").getComponent(Label).string = e.status_wz), i.getChildByName("verify_bg").getComponent(Sprite).color = color(253, 243, 243), i.getChildByName("verify_bg").getChildByName("wz").getComponent(Label).color = color(156, 0, 0), i.getChildByName("check_btn").getChildByName("ico").getComponent(Sprite).spriteFrame = this.select_imgs[2], i.getChildByName("check_btn").getComponent(Button).interactable = false) : (i.getChildByName("verify_bg").getChildByName("wz").getComponent(Label).string = "Verified", i.getChildByName("verify_bg").getComponent(Sprite).color = color(243, 255, 245), i.getChildByName("verify_bg").getChildByName("wz").getComponent(Label).color = color(77, 147, 55));
                i.info = e;
                i.getChildByName("check_btn").getComponent(Button).clickEvents[0].customEventData = "" + t;
                i.getChildByName("operate_btn").getComponent(Button).clickEvents[0].customEventData = "" + t;
                this.itemNodes.push(i);
            }
        }
        if (1 == this._accountData.show_add_btn) {
            let t = instantiate(this.depositNode.getChildByName("add_account_node"));
            t.active = true;
            this.recordScrollView.getComponent(ScrollView).content.addChild(t);
            sys.isObjectValid(this._accountData.account_limit) && (t.getChildByName("limit").getComponent(Label).string = `Up to ${this._accountData.account_limit} accounts`);
            this._accountData.list.length > 0 && (t.getChildByName("ico").active = false);
        }
        this.refreshAssureState();
    }
    adaptScreen() {
        view.getVisibleSize();
        this.node.getChildByName("root");
        this.node.getChildByName("bg");
        ToolUtils.showFullScreen(this.node.getChildByName("bg"));
    }
    addNotify() {
    }
    onDestroy() {
        super.onDestroy();
        TransferPlatform.shared().setSoftInputMode(0);
        PushCenter.shared().pushEvent(GameConfig.Update_Wallet);
        PushCenter.shared().removeListenersByTag(this);
        this.unscheduleAllCallbacks();
    }
    onOperateBankClick(t, e) {
        if (SoundManager.shared().playFx("click"), e.length > 0) {
            let t = parseInt(e);
            if (TweenTool.stopNodeAction(this.node), this._curQipaoIndex == t && this.qiPaoNode.active) {
                return void (this.qiPaoNode.active = false);
            }
            this._curQipaoIndex = t;
            let i = v3(0, 0);
            this.itemNodes[t].getWorldPosition(i);
            let a = v3(0, 0);
            this.depositNode.inverseTransformPoint(a, i);
            this.qiPaoNode.active = true;
            this.qiPaoNode.setPosition(v3(a.x + 260, a.y));
            TweenTool.delayAct(this.node, (() => {
                this.qiPaoNode.active = false;
            }), 3, true);
        }
    }
    refreshItemSelectView() {
        for (let t = 0; t < this.itemNodes.length; t++) {
            let e = this.itemNodes[t];
            this._curSelectIndex == t ? e.getChildByName("check_btn").getChildByName("ico").getComponent(Sprite).spriteFrame = this.select_imgs[1] : e.getChildByName("check_btn").getComponent(Button).interactable && (e.getChildByName("check_btn").getChildByName("ico").getComponent(Sprite).spriteFrame = this.select_imgs[0]);
        }
    }
    onSelectBankClick(t, e) {
        if (SoundManager.shared().playFx("click"), e.length > 0) {
            let t = parseInt(e);
            if (this._curSelectIndex == t) {
                return;
            }
            this._curSelectIndex = t;
            for (let e = 0; e < this._accountData.list.length; e++) {
                e == this._curSelectIndex && (this._accountData.list[e].check = 0);
                e == t && (this._accountData.list[e].check = 1);
            }
            this.refreshItemSelectView();
            this.refreshAssureState();
        }
    }
    dealDeleteBankLogic() {
        let t = this._accountData.list[this._curQipaoIndex];
        if (!sys.isObjectValid(t)) {
            return;
        }
        let e = this._accountData.amount, i = t.record_id;
        Utils.shared().showLoading(10, false, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3);
        }));
        HttpManager.shared().doGetCommonRequest({ record_id: i }, "WithdrawAcc.doDelV3", ((t, i, a) => {
            if (Utils.shared().hideLoading(), 200 != a) {
                ;
            }
            else {
                let t = ToolUtils.parseJson(i);
                if (0 == t.ret) {
                    try {
                        ToolUtils.isObjValid(this.node) && (this._accountData = t.data, this._accountData.amount = e, this.refreshView());
                    }
                    catch (t) {
                        TLog.printError("trycatch requestRecord:error:", t);
                    }
                }
                else {
                    ToolUtils.isSafeString(t.desc).length > 0 && Utils.shared().showToast(t.desc, 2);
                }
            }
        }));
    }
    dealEditBankLogic() {
        let t = this._accountData.list[this._curQipaoIndex];
        sys.isObjectValid(t) && (sys.isObjectValid(t.status) && 0 == t.status && (t.ifsc_err = 1), Utils.shared().showWithdrawEditView(null, t, (t => {
            let e = this._accountData.amount;
            this._accountData = t;
            this._accountData.amount = e;
            this.refreshView();
        })));
    }
    onButtonClick(t, e) {
        SoundManager.shared().playFx("click");
        "close" === e ? this.onBackView() : "delete" == e ? this.dealDeleteBankLogic() : "edit" == e ? this.dealEditBankLogic() : "assure" == e ? this.dealAssureLogic() : "add_bank" == e && Utils.shared().showWithdrawEditView(null, null, (t => {
            let e = this._accountData.amount;
            this._accountData = t;
            this._accountData.amount = e;
            this.refreshView();
        }));
    }
    dealAssureLogic() {
        if (-1 == this._curSelectIndex) {
            return void Utils.shared().showToast("Please select an available bank account.", 3);
        }
        let t = this._accountData.list[this._curSelectIndex];
        sys.isObjectValid(t) && (Utils.shared().showLoading(10, false, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3);
        })), HttpManager.shared().doGetCommonRequest({ account_id: t.record_id, w_amount: this._accountData.amount }, "Withdraw.orderV2", ((t, e, i) => {
            if (Utils.shared().hideLoading(), 200 != i) {
                ;
            }
            else {
                let t = ToolUtils.parseJson(e);
                if (0 == t.ret) {
                    try {
                        ToolUtils.isObjValid(this.node) && (Utils.shared().showToast("The withdrawal request has been submitted", 3), this.onBackView());
                    }
                    catch (t) {
                        TLog.printError("trycatch requestRecord:error:", t);
                    }
                }
                else {
                    ToolUtils.isSafeString(t.desc).length > 0 && Utils.shared().showToast(t.desc, 2);
                }
            }
        })));
    }
    onBackView() {
        ToolUtils.isObjValid(this.node) && (this._callback && this._callback(), this.node.destroy());
    }
}
