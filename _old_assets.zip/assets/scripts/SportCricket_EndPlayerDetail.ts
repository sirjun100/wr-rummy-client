// @ts-nocheck
// Recovered from index.js:555
import { _decorator, instantiate, Label, Node, size, Sprite, SpriteFrame, sys, UITransform, v3 } from "cc";
import SoundManager from "./SoundManager";
import PushCenter from "./PushCenter";
import Utils from "./Utils";
import BaseLayer from "./BaseLayer";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("SportCricket_EndPlayerDetail")
export class SportCricket_EndPlayerDetail extends BaseLayer {
    public TAG: string = "SportCricket_EndPlayerDetail";
    @property(Node)
    public rootNode: Node = null;
    @property(Node)
    public topInfo: Node = null;
    @property(Node)
    public batting: Node = null;
    @property(Node)
    public bowling: Node = null;
    @property(Node)
    public others: Node = null;
    @property(Node)
    public total: Node = null;
    @property(Node)
    public itemMoban: Node = null;
    @property(Node)
    public lineMoban: Node = null;
    @property([SpriteFrame])
    public teamIconArr: SpriteFrame[] = [];
    public detailInfo: any = null;
    public playerInfo: any = null;
    public bShowPushAnim: boolean = true;
    public _startPos: any = v3();
    onLoad() {
        this._startPos = this.rootNode.getPosition();
        this.rootNode.setPosition(v3(this._startPos.x, this._startPos.y - 800, this._startPos.z));
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().removeListenersByTag(this);
        this.unscheduleAllCallbacks();
    }
    init(t) {
        sys.isObjectValid(t) && (sys.isObjectValid(t.detailInfo) && (this.detailInfo = t.detailInfo), sys.isObjectValid(t.playerInfo) && (this.playerInfo = t.playerInfo));
    }
    start() {
        if (super.start(), this.initView(), this.bShowPushAnim) {
            let t = this._startPos, e = { startPos: v3(t.x, t.y - 800, t.z), endPos: t };
            this.rootNode.active = true;
            ToolUtils.showPushAnim(this.rootNode, 2, null, e);
        }
    }
    onCloseButtonClick(t, e) {
        SoundManager.shared().playFx("click");
        this.onBackView();
    }
    initView() {
        if (sys.isObjectValid(this.playerInfo)) {
            if (ToolUtils.isObjValid(this.topInfo)) {
                if ("teama_player_thumb.png" == this.playerInfo.player_thumb_url ? this.topInfo.getChildByName("head_mask").getChildByName("head_img").getComponent(Sprite).spriteFrame = this.teamIconArr[0] : "teamb_player_thumb.png" == this.playerInfo.player_thumb_url ? this.topInfo.getChildByName("head_mask").getChildByName("head_img").getComponent(Sprite).spriteFrame = this.teamIconArr[1] : Utils.shared().updateNetImage(this.topInfo.getChildByName("head_mask").getChildByName("head_img"), this.playerInfo.player_thumb_url, size(65, 65)), sys.isObjectValid(this.playerInfo.player_name) && this.playerInfo.player_name.length > 0 && (this.topInfo.getChildByName("name").getComponent(Label).string = this.playerInfo.player_name || ""), sys.isObjectValid(this.playerInfo.name) && this.playerInfo.name.length > 0 && (this.topInfo.getChildByName("name").getComponent(Label).string = this.playerInfo.name || ""), this.topInfo.getChildByName("name").getComponent(Label).updateRenderData(true), sys.isObjectValid(this.playerInfo.is_best) && 1 == this.playerInfo.is_best) {
                    this.topInfo.getChildByName("logo").active = true;
                    let t = this.topInfo.getChildByName("name").getComponent(UITransform).contentSize.width;
                    this.topInfo.getChildByName("logo").setPosition(v3(-246.251 + t + 10, -32));
                }
                else {
                    this.topInfo.getChildByName("logo").active = false;
                }
                this.topInfo.getChildByName("score").getChildByName("score").getComponent(Label).string = this.playerInfo.format_str || "";
                this.topInfo.getChildByName("score").getChildByName("score2").getComponent(Label).string = this.playerInfo.team_name || "";
            }
            this.total.getChildByName("bg2").getChildByName("tx_total").getComponent(Label).string = this.playerInfo.point || "";
        }
        if (sys.isObjectValid(this.detailInfo)) {
            if (sys.isObjectValid(this.detailInfo.batting)) {
                for (let t = 0, e = this.detailInfo.batting.length; t < e; t++) {
                    let e = instantiate(this.itemMoban);
                    e.getChildByName("title").getComponent(Label).string = this.detailInfo.batting[t].title;
                    e.getChildByName("val").getComponent(Label).string = this.detailInfo.batting[t].point;
                    e.active = true;
                    this.batting.addChild(e);
                }
                let t = instantiate(this.lineMoban);
                t.active = true;
                this.batting.addChild(t);
                this.batting.active = true;
            }
            else {
                this.batting.active = false;
            }
            if (sys.isObjectValid(this.detailInfo.bowling)) {
                for (let t = 0, e = this.detailInfo.bowling.length; t < e; t++) {
                    let e = instantiate(this.itemMoban);
                    e.getChildByName("title").getComponent(Label).string = this.detailInfo.bowling[t].title;
                    e.getChildByName("val").getComponent(Label).string = this.detailInfo.bowling[t].point;
                    e.active = true;
                    this.bowling.addChild(e);
                }
                let t = instantiate(this.lineMoban);
                t.active = true;
                this.bowling.addChild(t);
                this.bowling.active = true;
            }
            else {
                this.bowling.active = false;
            }
            if (sys.isObjectValid(this.detailInfo.others)) {
                for (let t = 0, e = this.detailInfo.others.length; t < e; t++) {
                    let e = instantiate(this.itemMoban);
                    e.getChildByName("title").getComponent(Label).string = this.detailInfo.others[t].title;
                    e.getChildByName("val").getComponent(Label).string = this.detailInfo.others[t].point;
                    e.active = true;
                    this.others.addChild(e);
                }
                this.others.active = true;
            }
            else {
                this.others.active = false;
            }
        }
    }
    onBackView(t = true) {
        if (t) {
            if (Utils.shared().hideLoading(), this.bShowPushAnim) {
                let t = this.rootNode.getPosition(), e = { startPos: t, endPos: v3(t.x, t.y - 800, t.z) };
                this.rootNode.active = true;
                ToolUtils.showPushAnim(this.rootNode, 2, (() => {
                    ToolUtils.isObjValid(this.node) && this.node.destroy();
                }), e);
            }
            else {
                ToolUtils.isObjValid(this.node) && this.node.destroy();
            }
        }
    }
    fitScreen() {
        ToolUtils.adaptSafeArea(this.rootNode);
        sys.getSafeAreaRect().y;
    }
}
