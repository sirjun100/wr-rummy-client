// @ts-nocheck
// Recovered from index.js:523
import { _decorator, Label, size, sys, tween, v3 } from "cc";
import Parent from "./Parent";
import PushCenter from "./PushCenter";
import SoundManager from "./SoundManager";
import { ToolUtils } from "./ToolUtils";
import User from "./User";
import Utils from "./Utils";
import TweenTool from "./TweenTool";
const { ccclass } = _decorator;
@ccclass("SixPointCardPlayer")
export default class SixPointCardPlayer extends Parent {
    public _TAG: string = "SixPointCardPlayer";
    public lastClick: number = 0;
    public gameCallback: any = null;
    public gameData: any = {};
    onLoad() {
    }
    onDestroy() {
        super.onDestroy();
        this.unscheduleAllCallbacks();
        PushCenter.shared().removeListenersByTag(this);
    }
    start() {
        this.initView();
        this.addPushNotify();
    }
    setCallBack(e) {
        this.gameCallback = e;
    }
    addPushNotify() {
    }
    initView() {
        this.gameData.seatFlagVec = [];
        for (let e = 0; e < 6; e++) {
            this.gameData.seatFlagVec.push(0);
        }
        this.gameData.seatPosVec = [];
        this.gameData.hasChangeSelected = false;
        this.gameData.signCoin = 100;
        this.gameData.zhuangFlag = 0;
        this.gameData.isSuozhu = false;
        this.gameData.selectIndex = 0;
        this.gameData.curcoin = User.shared().data.money;
        this.gameData.isSelfBanker = false;
        for (let e = 0; e <= 7; e++) {
            let a = "player" + e, t = this.node.getChildByName(a);
            ToolUtils.isObjValid(t) && this.gameData.seatPosVec.push(t.getPosition());
        }
    }
    resetTuhaoSeat(e) {
        let a = "player" + e, t = this.node.getChildByName(a);
        ToolUtils.isObjValid(t) && (t.active = true, t.getChildByName("head_mask").getChildByName("head_img").removeAllChildren(), t.getChildByName("empty").active = true, t.getChildByName("head_mask").active = false, t.getChildByName("name_bg").active = false, t.getChildByName("head_bg").active = false, t.getChildByName("floatbg").active = false);
    }
    updateSeatCoinInfo(e, a) {
        let i = "player" + e, s = this.node.getChildByName(i);
        if (ToolUtils.isObjValid(s)) {
            let e = s.getChildByName("name_bg").getChildByName("coin");
            ToolUtils.isObjValid(e) && (e.getComponent(Label).string = ToolUtils.parse_double(a));
        }
    }
    updateNoSeatPlayerNum(e) {
        let a = this.node.getChildByName("player7");
        if (ToolUtils.isObjValid(a)) {
            let i = a.getChildByName("numbg");
            if (ToolUtils.isObjValid(i)) {
                if (e > 0) {
                    i.active = true;
                    i.getChildByName("num").getComponent(Label).string = "" + e;
                }
                else {
                    i.active = false;
                }
            }
        }
    }
    showFloatWord(e, a, l) {
        if (a > 6) {
            return;
        }
        let d = "player" + a, h = this.node.getChildByName(d);
        if (ToolUtils.isObjValid(h) && l > 0) {
            let a = h.getChildByName("floatbg");
            a.getChildByName("floatword").getComponent(Label).string = "+" + ToolUtils.parse_double(l);
            let d = tween(a).delay(e), n = TweenTool.moveBy(a, 1, v3(0, 20)), o = tween(a).call((() => {
                a.active = true;
            }));
            a.active = false;
            a.setPosition(v3(0, 61.659));
            TweenTool.sequence(a, true, (() => {
                a.active = false;
            }), d, o, n);
        }
    }
    jumpWhenSendBet(e) {
        if (6 != e) {
            let a = "player" + e, t = this.node.getChildByName(a);
            if (ToolUtils.isObjValid(t)) {
                let e = v3(0, 0);
                t.getPosition(e);
                let a = tween(t).to(0.08, { position: v3(e.x, e.y + 10) }), l = tween(t).to(0.08, { position: e });
                TweenTool.sequence(t, true, (() => {
                    t.setPosition(e);
                }), a, l);
            }
        }
    }
    updateClientPlayerInfo() {
        if (!sys.isObjectValid(this.gameData.lastMoney) || this.gameData.lastMoney != User.shared().data.money) {
            this.gameData.lastMoney = User.shared().data.money;
            let e = "player6", a = this.node.getChildByName(e);
            if (ToolUtils.isObjValid(a)) {
                let e = a.getChildByName("name_bg").getChildByName("coin");
                ToolUtils.isObjValid(e) && (e.getComponent(Label).string = ToolUtils.parse_double(this.gameData.lastMoney));
            }
        }
    }
    reset() {
        this.gameData.isSuozhu = false;
        this.setUserInfo();
        for (let e = 0; e < 7; e++) {
            this.showWinEffect(e, false);
        }
    }
    setUserInfo() {
        this.updateClientInfo();
    }
    updateClientInfo() {
        let e = User.shared().data.uid, a = User.shared().data.money, t = User.shared().data.name, i = User.shared().data.sex, s = User.shared().data.vlevel, l = User.shared().data.avatar;
        this.showPlayer(6, t, e, l, s, a, i, User.shared().data.avatar_url);
    }
    showWinEffect(e, a) {
    }
    showPlayer(e, a, i, s, l, h, n, o) {
        let g = "player" + e, m = this.node.getChildByName(g);
        if (ToolUtils.isObjValid(m)) {
            m.active = true;
            m.getChildByName("head_mask").getChildByName("head_img").removeAllChildren();
            Utils.shared().updateHeadImg(m.getChildByName("head_mask").getChildByName("head_img"), s, o, size(140, 140), "head_17.png", true);
            m.getChildByName("empty").active = false;
            m.getChildByName("head_mask").active = true;
            m.getChildByName("name_bg").active = true;
            m.getChildByName("head_bg").active = true;
            let e = m.getChildByName("name_bg").getChildByName("coin");
            ToolUtils.isObjValid(e) && (e.getComponent(Label).string = ToolUtils.parse_double(h));
        }
    }
    updatePlayerHead(e, a, t) {
        let i = "player" + e, s = this.node.getChildByName(i);
        ToolUtils.isObjValid(s) && Utils.shared().updateHeadImg(s.getChildByName("head_mask").getChildByName("head_img"), a, t, size(140, 140), "head_17.png");
    }
    getPlayerHeadViewPos(e) {
        let a = "player" + e, t = this.node.getChildByName(a);
        if (ToolUtils.isObjValid(t)) {
            let e = v3(0, 0);
            return t.getWorldPosition(e), e;
        }
        return v3(0, 0);
    }
    touchBtnEvent(e, a) {
        SoundManager.shared().playFx("click");
        sys.now() - this.lastClick < 200 || (this.lastClick = sys.now(), sys.isObjectValid(this.gameCallback) && this.gameCallback(a));
    }
}
