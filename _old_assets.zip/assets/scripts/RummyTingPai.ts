// @ts-nocheck
// Recovered from index.js:489
import { _decorator, Component, Button, color, instantiate, Label, Node, Prefab, ScrollView, size, Size, Sprite, SpriteFrame, sys, UITransform, v3, Vec3 } from "cc";
import SoundManager from "./SoundManager";
import i18nMgr from "./i18nMgr";
import RummyCard from "./RummyCard";
import { TLog } from "./TLog";
import RummyDataManager from "./RummyDataManager";
import TweenTool from "./TweenTool";
import RummyCmd from "./RummyCmd";
import User from "./User";
import GameConfig from "./GameConfig";
import Server from "./Server";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("RummyTingPai")
export class RummyTingPai extends Component {
    @property(Node)
    public iconNode: Node = null;
    @property(Node)
    public bubbleNode: Node = null;
    @property(Node)
    public pickBubbleNode: Node = null;
    @property(ScrollView)
    public scrollview: ScrollView = null;
    @property(Node)
    public tcardNode: Node = null;
    @property([SpriteFrame])
    public iconImags: SpriteFrame[] = [];
    @property(Prefab)
    public cardPrefab: Prefab = null;
    @property(Node)
    public cards_rootNode: Node = null;
    @property(Node)
    public left_node: Node = null;
    @property(Node)
    public right_node: Node = null;
    @property(Node)
    public selectBubbleNode: Node = null;
    @property(Node)
    public selectArrowNode: Node = null;
    @property([SpriteFrame])
    public zhegaiImags: SpriteFrame[] = [];
    @property([SpriteFrame])
    public cardColor: SpriteFrame[] = [];
    @property(Label)
    public readyHandsLable: Label = null;
    @property(Label)
    public scoreLeftLabel: Label = null;
    public cardsTs: any = undefined;
    public tid_key: string = "";
    public tingPaiMsg: any = null;
    public cardScale: Vec3 = new Vec3(0.9, 0.9);
    public canShowBubble: boolean = false;
    public hasListenInfo: boolean = false;
    public tips_type: number = 0;
    public cardsViewPool: any = null;
    public _cur_cardValue: number = 0;
    public tingPaiCards: any[] = [];
    public _cardWidth: number = 0;
    public _lastSelectIndex: any = -1;
    public detailCardsMap: Map = new Map;
    public _orgin_bubble_width: number = 453;
    public _orign_bubble_height: number = 179;
    public _oneRowCardsWidth: number = 415;
    public _oneRowCardsHeight: number = 120;
    public _ceBianWidth: number = 38;
    public _tingPaiListenInfo: any = null;
    onLoad() {
    }
    start() {
        this.dealMultipleLanguages();
    }
    dealMultipleLanguages() {
        2 == i18nMgr.shared().language && (this.left_node.getChildByName("Node").getChildByName("Label").getComponent(Label).fontSize = 20, this.right_node.getChildByName("Node").getChildByName("Label1").getComponent(Label).fontSize = 20);
    }
    onDestroy() {
    }
    buttonClick(e, t) {
        if (0 != RummyDataManager.shared().rummyInfos.get(this.tid_key).helper_best_group_after_pick_open && this._tingPaiListenInfo && Array.isArray(this._tingPaiListenInfo) && this._tingPaiListenInfo.length > Number(t)) {
            if (this._tingPaiListenInfo[Number(t)].n > 0) {
                if (SoundManager.shared().playFx("click"), this._lastSelectIndex == Number(t)) {
                    this.hideSelectBubble();
                }
                else {
                    this._lastSelectIndex = Number(t);
                    let e = this.getSeletCardValue(Number(t));
                    this.detailCardsMap.has(e) ? this.showDetailBubble(Number(t), this.detailCardsMap.get(e)) : this.send_request_helper_tingpai_group(Number(t));
                }
            }
            else {
                this.hideSelectBubble();
            }
        }
    }
    send_request_helper_tingpai_group(e) {
        let t = this.getSeletCardValue(e), i = this.cardsTs.getShouPaiCardValues(), s = { cmd: RummyCmd.GM_HELPER_BEST_GROUP_AFTER_PICK, uid: User.shared().data.uid, version: GameConfig.Server_Api_Ver, skey: User.shared().getSkey(), tid_key: this.tid_key, cards: i, laizi_card: RummyDataManager.shared().rummyInfos.get(this.tid_key).laizicard, tingpai_index: e, card: t };
        Server.shared().send(s);
    }
    bubbleClick(e, t) {
        "bubble" === t || ("select_bubble" === t ? this.hideSelectBubble() : "pick_bubble" === t && this.showpickBubbleView(false));
    }
    hideSelectBubble() {
        let e, t = this.tingPaiCards.length;
        for (let i = 0; i < t; i++) {
            const t = this.tingPaiCards[i];
            ToolUtils.isObjValid(t) && (e = t.getComponent("RummyCard"), e && e.isValid && e.changeTingPaiLightSelectVisible(false));
        }
        ToolUtils.isObjValid(this.selectBubbleNode) && (this.selectBubbleNode.active = false);
        ToolUtils.isObjValid(this.selectArrowNode) && (this.selectArrowNode.active = false);
        this._lastSelectIndex = -1;
        this.detailCardsMap.clear();
    }
    showTingPaiInfo(e, t, i = 0) {
        if (this._cur_cardValue = i, this.tingPaiMsg = e, this.tid_key = e.tid_key, this.cardsTs = t, this.tingPaiCards = [], this.scrollview.content.destroyAllChildren(), this.cards_rootNode.destroyAllChildren(), this.canShowBubble = false, this.hasListenInfo = false, this.tips_type = 0, 13 == this.cardsTs.cardViewVec.length) {
            if (this.tingPaiMsg && this.tingPaiMsg.listen_info && Array.isArray(this.tingPaiMsg.listen_info)) {
                let e = null;
                for (let t = 0, i = this.tingPaiMsg.listen_info.length; t < i; t++) {
                    if (this.tingPaiMsg.listen_info[t] && 1 == this.tingPaiMsg.listen_info[t].is_best) {
                        e = this.tingPaiMsg.listen_info[t];
                        break;
                    }
                }
                sys.isObjectValid(e) && this.showTingPaiDetaisInfo(e);
            }
        }
        else if (14 == this.cardsTs.cardViewVec.length) {
            if (1 == this.cardsTs.getSelectedCards().length || i > 0) {
                if (0 == i) {
                    i = this.cardsTs.getSelectedCards()[0].getComponent("RummyCard").mCardValue;
                }
                if (this.tingPaiMsg && this.tingPaiMsg.listen_info && Array.isArray(this.tingPaiMsg.listen_info)) {
                    let e = null;
                    for (let t = 0, s = this.tingPaiMsg.listen_info.length; t < s; t++) {
                        if (this.tingPaiMsg.listen_info[t] && this.tingPaiMsg.listen_info[t].card == i) {
                            e = this.tingPaiMsg.listen_info[t];
                            break;
                        }
                    }
                    sys.isObjectValid(e) && this.showTingPaiDetaisInfo(e);
                }
            }
            else {
                this.showPreBestTingPaiInfo();
            }
        }
        this.canShowBubble ? this.showNofinishTip() : this.changeTingPaiBubbleVisible(false);
    }
    showNofinishTip() {
        if (!this.hasListenInfo) {
            let e = this.bubbleNode.getChildByName("tip");
            e.active = true;
            0 == this.tips_type ? i18nMgr.shared().changeLocalizedLabelKey(e, "game_setting.nonetofinish") : 1 == this.tips_type && i18nMgr.shared().changeLocalizedLabelKey(e, "game_setting.canfinish");
            this.cards_rootNode.active = false;
            this.scrollview.node.active = false;
            this.bubbleNode.getComponent(UITransform).setContentSize(size(this._orgin_bubble_width, this._orign_bubble_height));
            this.refreshBubbleHandsScore(this._orgin_bubble_width, this._orign_bubble_height);
            this.hideSelectBubble();
        }
    }
    showPreBestTingPaiInfo() {
        if (this.tingPaiMsg && this.tingPaiMsg.listen_info && Array.isArray(this.tingPaiMsg.listen_info)) {
            let e = null;
            for (let t = 0, i = this.tingPaiMsg.listen_info.length; t < i; t++) {
                if (this.tingPaiMsg.listen_info[t] && 1 == this.tingPaiMsg.listen_info[t].is_best) {
                    e = this.tingPaiMsg.listen_info[t];
                    break;
                }
            }
            sys.isObjectValid(e) && this.showTingPaiDetaisInfo(e);
        }
    }
    showTingPaiDetaisInfo(e) {
        let t = RummyDataManager.shared().rummyInfos.get(this.tid_key);
        if (0 == t.helper_best_group_after_pick_open) {
            return this.bubbleNode.getComponent(Button).interactable = false, void this.showFirstTingPaiDetails(e);
        }
        this.bubbleNode.getComponent(Button).interactable = true;
        this.tingPaiCards = [];
        this.canShowBubble = true;
        let i = this.bubbleNode.getChildByName("tip");
        if (this.readyHandsLable.string = "" + e.finish_num, sys.isObjectValid(t) && 1 == t.is_multiple) {
            let i, s = t.ting_round;
            i = s >= 0 && sys.isObjectValid(t.multiple_cfg[s]) ? t.multiple_cfg[s] : t.multiple_cfg[t.multiple_cfg.length - 1];
            this.scoreLeftLabel.string = e.lost + "/" + ToolUtils.parse_double("" + e.lost * i, -2);
        }
        else {
            this.scoreLeftLabel.string = e.lost + "";
        }
        this.tcardNode.active = false;
        let s = 14;
        if (0 == e.lost) {
            i.active = true;
            this.tips_type = 1;
            i18nMgr.shared().changeLocalizedLabelKey(i, "game_setting.canfinish");
            this.cards_rootNode.active = false;
            this.scrollview.node.active = false;
            this.bubbleNode.getComponent(UITransform).setContentSize(size(this._orgin_bubble_width, this._orign_bubble_height));
            this.refreshBubbleHandsScore(this._orgin_bubble_width, this._orign_bubble_height);
        }
        else if (0 == e.finish_num) {
            i.active = true;
            i18nMgr.shared().changeLocalizedLabelKey(i, "game_setting.nonetofinish");
            this.tips_type = 0;
            this.bubbleNode.getComponent(UITransform).setContentSize(size(this._orgin_bubble_width, this._orign_bubble_height));
            this.refreshBubbleHandsScore(this._orgin_bubble_width, this._orign_bubble_height);
            this.cards_rootNode.active = false;
            this.scrollview.node.active = false;
        }
        else {
            i.active = false;
            let t = 0;
            if (e.listen && Array.isArray(e.listen) && (t = e.listen.length), t <= 42 ? (this.cards_rootNode.active = true, this.scrollview.node.active = false) : (this.cards_rootNode.active = false, this.scrollview.node.active = true), t > 0) {
                let i, n, o = 0.32, a = this._ceBianWidth, l = this._orign_bubble_height, r = 120, d = this._orgin_bubble_width, b = this._oneRowCardsWidth, f = 0, w = 8, N = 168, y = 100, S = 0, P = 100, v = 0, B = 0, L = 0;
                if (t <= s) {
                    S = t;
                    f = N * o;
                    L = (t - 1) * w + t * f;
                    b = L > b ? L : b;
                    d = a + b;
                    B = b - f;
                    this.bubbleNode.getComponent(UITransform).setContentSize(size(d, l));
                    this.cards_rootNode.getComponent(UITransform).setContentSize(size(b, r));
                }
                else if (t > s && t <= 28) {
                    f = N * o;
                    S = s;
                    b = (S - 1) * w + S * f;
                    B = b - f;
                    d = a + b;
                    l = this._orign_bubble_height + P;
                    this.bubbleNode.getComponent(UITransform).setContentSize(size(d, l));
                    r = this._oneRowCardsHeight + P;
                    this.cards_rootNode.getComponent(UITransform).setContentSize(size(b, r));
                }
                else if (t > 28 && t <= 42) {
                    f = N * o;
                    S = s;
                    b = (S - 1) * w + S * f;
                    B = b - f;
                    d = a + b;
                    l = this._orign_bubble_height + 2 * P;
                    this.bubbleNode.getComponent(UITransform).setContentSize(size(d, l));
                    r = this._oneRowCardsHeight + 2 * P;
                    this.cards_rootNode.getComponent(UITransform).setContentSize(size(b, r));
                }
                else {
                    f = N * o;
                    S = s;
                    b = (S - 1) * w + S * f;
                    B = b - f;
                    d = a + b;
                    l = this._orign_bubble_height + 2 * P;
                    this.bubbleNode.getComponent(UITransform).setContentSize(size(d, l));
                    r = this._oneRowCardsHeight + 2 * P;
                    this.scrollview.vertical = true;
                    this.scrollview.view.getComponent(UITransform).setContentSize(size(b, r));
                    this.scrollview.node.getComponent(UITransform).setContentSize(size(b, r));
                    v = Math.ceil(1 * (t - 42) / S) * P + r;
                    this.scrollview.content.getComponent(UITransform).setContentSize(size(b, v));
                }
                this._cardWidth = f;
                this.refreshBubbleHandsScore(d, l);
                let M = 0, V = 0, k = 0, T = 0;
                this._tingPaiListenInfo = e.listen;
                for (let s = 0; s < t; s++) {
                    let a = e.listen[s], l = instantiate(this.tcardNode);
                    l.active = true;
                    i = l.getChildByName("num");
                    i.getComponent(Label).string = "x" + a.n;
                    0 == a.n ? i.getComponent(Label).color = color(109, 109, 109, 255) : i.getComponent(Label).color = color(255, 255, 255, 255);
                    l.getComponent(UITransform).setContentSize(size(f, y));
                    let d = instantiate(this.cardPrefab);
                    n = d.getComponent("RummyCard");
                    n.init(a.c, false, 0);
                    n.openCard();
                    n.showLaiziFlag(RummyDataManager.shared().isShowLaiziColor(a.c, this.tid_key));
                    n.setMask(0 == a.n);
                    n.changeTingPaiLightSelectVisible(false);
                    d.setScale(v3(o, o));
                    d.setPosition(new Vec3(-f / 2, -37.12));
                    i.setPosition(new Vec3(-f / 2, -75.352));
                    l.addChild(d);
                    l.getComponent(Button).clickEvents[0].customEventData = String(s);
                    this.tingPaiCards.push(d);
                    i.getComponent(Label).fontSize = 20;
                    t <= 42 ? (k = Math.floor(s / S), T = Math.ceil(s % S), M = (f + w) * T - B, V = r - 15 - P * k, l.setPosition(v3(M, V)), this.cards_rootNode.addChild(l)) : (k = Math.floor(s / S), T = Math.ceil(s % S), M = (f + w) * T - B, V = -12 - P * k, l.setPosition(v3(M, V)), this.scrollview.content.addChild(l));
                    this.hasListenInfo = true;
                }
            }
            else {
                this.bubbleNode.getComponent(UITransform).setContentSize(size(this._orgin_bubble_width, this._orign_bubble_height));
                this.refreshBubbleHandsScore(this._orgin_bubble_width, this._orign_bubble_height);
            }
        }
    }
    changeTingPaiBubbleVisible(e) {
        e ? (this.bubbleNode.active = true, this.showNofinishTip()) : this.bubbleNode.active = false;
        this.changeTingpaiIconStatue(e);
        this.hideSelectBubble();
    }
    changeTingpaiIconStatue(e) {
        this.iconNode.getComponent(Sprite).spriteFrame = e ? this.iconImags[1] : this.iconImags[0];
    }
    hideTingPaiUI() {
        this.iconNode.active = false;
        this.changeTingPaiBubbleVisible(false);
    }
    chooseSelectTingPaiCard(e) {
        let t, i = this.tingPaiCards.length, s = 0;
        for (let n = 0; n < i; n++) {
            const i = this.tingPaiCards[n];
            ToolUtils.isObjValid(i) && (t = i.getComponent("RummyCard"), n == e ? (t.changeTingPaiLightSelectVisible(true), s = t.mCardValue) : t.changeTingPaiLightSelectVisible(false));
        }
        return s;
    }
    getSeletCardValue(e) {
        let t, i = 0;
        if (this.tingPaiCards.length > e) {
            const s = this.tingPaiCards[e];
            ToolUtils.isObjValid(s) && (t = s.getComponent("RummyCard"), t && t.isValid && (i = t.mCardValue));
        }
        return i;
    }
    showDetailBubble(e, t) {
        0 == RummyDataManager.shared().rummyInfos.get(this.tid_key).helper_best_group_after_pick_open && this.hideSelectBubble();
        let i = t.cardinfos;
        if (!sys.isObjectValid(i)) {
            return;
        }
        let s, n, o, a, l, h, r, d = 0;
        h = this.tingPaiCards.length;
        let _ = 0, m = -1, N = -1;
        sys.isObjectValid(t.card_groupindex) && (m = t.card_groupindex);
        sys.isObjectValid(t.card_index) && (N = t.card_index);
        for (let i = 0; i < h; i++) {
            const n = this.tingPaiCards[i];
            ToolUtils.isObjValid(n) && (s = n.getComponent("RummyCard"), i == e ? (s.changeTingPaiLightSelectVisible(true), r = n, this.detailCardsMap.set(s.mCardValue, t), _ = s.mCardValue) : s.changeTingPaiLightSelectVisible(false));
        }
        let y = 14;
        this._lastSelectIndex = e;
        l = h < y ? h : y;
        o = Math.floor(e / l);
        a = Math.ceil(e % l);
        this.selectBubbleNode.active = true;
        this.selectArrowNode.active = true;
        let S = this.bubbleNode.getComponent(UITransform).width, P = 508, v = this._ceBianWidth, B = -S / 2 + 254, L = 183, M = v3(0, 0), V = 0.32, T = -467, I = i.length;
        this._cardWidth = 53.76;
        let R = (-41 - T - (6 + this._cardWidth) * (I - 1)) / (14 - I), A = -41 - T + this._cardWidth + 24;
        A > P && (this.selectBubbleNode.getComponent(UITransform).setContentSize(new Size(A, 100)), T -= A - P, B = -S / 2 + A / 2);
        ToolUtils.isObjValid(r) && this.bubbleNode.inverseTransformPoint(M, r.getWorldPosition());
        B = P >= S - v ? -S / 2 + 254 : a <= 7 ? -S + P + v / 2 : -v / 2;
        let H, j, O, F, x = 0, D = 52.5;
        h <= y ? (L = 183, this.selectArrowNode.setScale(new Vec3(-1, -1)), x = L - D) : h > y && h <= 28 ? (0 == o ? L += 100 : 1 == o && (L = 183), x = L - D, this.selectArrowNode.setScale(new Vec3(-1, -1))) : h > 28 && (0 == o ? (L = 183, x = L + D, this.selectArrowNode.setScale(new Vec3(1, 1))) : 1 == o ? (L += 100, x = L - D, this.selectArrowNode.setScale(new Vec3(-1, -1))) : (L = 183, x = L - D, this.selectArrowNode.setScale(new Vec3(-1, -1))));
        this.selectArrowNode.setPosition(new Vec3(M.x, x));
        this.selectBubbleNode.setPosition(new Vec3(B, L));
        this.selectBubbleNode.destroyAllChildren();
        for (let e = 0, t = i.length; e < t; e++) {
            let t = i[e].cards;
            H = instantiate(this.bubbleNode.getChildByName("zhegai"));
            H.active = true;
            this.selectBubbleNode.addChild(H);
            let o = i[e].color;
            F = t.length;
            let a = Math.floor(F / 2);
            O = 0;
            for (let i = 0; i < F; i++) {
                let o = instantiate(this.cardPrefab);
                s = o.getComponent("RummyCard");
                s.init(t[i], false, 0);
                s.openCard();
                s.showLaiziFlag(RummyDataManager.shared().isShowLaiziColor(t[i], this.tid_key));
                -1 != m && -1 != N ? m == e && N == i && s.setMask(s.mCardValue == _) : s.setMask(s.mCardValue == _);
                o.setScale(v3(V, V));
                n = T + R * d + e * (6 + this._cardWidth - R);
                o.setPosition(new Vec3(n, 0));
                this.selectBubbleNode.addChild(o);
                d += 1;
                i == a && (O = n);
            }
            0 == o ? H.getComponent(Sprite).spriteFrame = this.zhegaiImags[0] : 2 == o ? H.getComponent(Sprite).spriteFrame = this.zhegaiImags[1] : 3 == o && (H.getComponent(Sprite).spriteFrame = this.zhegaiImags[2]);
            0 == Math.floor(F % 2) && (O -= R / 2);
            j = (F - 1) * R + this._cardWidth;
            H.getComponent(UITransform).setContentSize(size(j, 12));
            H.setSiblingIndex(100 + e);
            H.setPosition(v3(O, -30));
        }
    }
    getCardNode() {
        let e = null;
        e = this.cardsViewPool.size() > 0 ? this.cardsViewPool.get() : instantiate(this.cardPrefab);
        e.active = true;
        try {
            null === e.getComponent("RummyCard") || e.getComponent("RummyCard");
            e.getComponent("RummyCard").resetCards();
        }
        catch (e) {
            TLog.printError("trycatch getCardNode,error:", e);
        }
        return e;
    }
    putCardNode(e) {
        e.getComponent(RummyCard).resetCards();
        TweenTool.stopNodeAction(e);
        e.active = false;
        this.cardsViewPool && this.cardsViewPool.put(e);
    }
    refreshBubbleHandsScore(e, t) {
        let i = (e - 18) / 2;
        this.left_node.getComponent(UITransform).setContentSize(size(i, 40));
        this.right_node.getComponent(UITransform).setContentSize(size(i, 40));
        this.left_node.setPosition(v3(9 - e, t - 25));
        this.right_node.setPosition(v3(-9, t - 25));
        this.left_node.getChildByName("Node").setPosition(v3(i / 2, 0));
        this.right_node.getChildByName("Node").setPosition(v3(-i / 2, 0));
    }
    showFirstTingPaiDetails(e) {
        this.canShowBubble = true;
        let t = this.bubbleNode.getChildByName("tip");
        this.readyHandsLable.string = "" + e.finish_num;
        this.scoreLeftLabel.string = e.lost + "";
        this.tcardNode.active = false;
        if (0 == e.lost) {
            t.active = true;
            this.tips_type = 1;
            i18nMgr.shared().changeLocalizedLabelKey(t, "game_setting.canfinish");
            this.cards_rootNode.active = false;
            this.scrollview.node.active = false;
            this.bubbleNode.getComponent(UITransform).setContentSize(size(this._orgin_bubble_width, this._orign_bubble_height));
            this.refreshBubbleHandsScore(this._orgin_bubble_width, this._orign_bubble_height);
        }
        else if (0 == e.finish_num) {
            t.active = true;
            i18nMgr.shared().changeLocalizedLabelKey(t, "game_setting.nonetofinish");
            this.tips_type = 0;
            this.bubbleNode.getComponent(UITransform).setContentSize(size(this._orgin_bubble_width, this._orign_bubble_height));
            this.refreshBubbleHandsScore(this._orgin_bubble_width, this._orign_bubble_height);
            this.cards_rootNode.active = false;
            this.scrollview.node.active = false;
        }
        else {
            t.active = false;
            let i = 0;
            if (e.listen && Array.isArray(e.listen) && (i = e.listen.length), i <= 42 ? (this.cards_rootNode.active = true, this.scrollview.node.active = false) : (this.cards_rootNode.active = false, this.scrollview.node.active = true), i > 0) {
                let t, s, n = 0.45, o = this._ceBianWidth, a = this._orign_bubble_height, l = 120, r = this._orgin_bubble_width, d = this._oneRowCardsWidth, b = 0, _ = 8, f = 168, w = 130, N = 0, y = 0, S = 140, P = 0, v = 0, B = 0;
                if (i <= 4) {
                    y = 0;
                    N = i;
                    b = f * n;
                    B = (i - 1) * _ + i * b;
                    d = B > d ? B : d;
                    a = this._orign_bubble_height + 38;
                    r = o + d;
                    v = d - b;
                    l = this._oneRowCardsHeight + 38;
                    this.bubbleNode.getComponent(UITransform).setContentSize(size(r, a));
                    this.cards_rootNode.getComponent(UITransform).setContentSize(size(d, l));
                }
                else if (i > 4 && i <= 20) {
                    y = 1;
                    b = f * n;
                    N = Math.ceil(i / 2);
                    B = (N - 1) * _ + N * b;
                    d = B > d ? B : d;
                    v = d - b;
                    r = o + d;
                    a = this._orign_bubble_height + 38 + S;
                    this.bubbleNode.getComponent(UITransform).setContentSize(size(r, a));
                    l = this._oneRowCardsHeight + 38 + S;
                    this.cards_rootNode.getComponent(UITransform).setContentSize(size(d, l));
                }
                else if (i > 20 && i <= 28) {
                    n = 0.32;
                    y = 2;
                    b = f * n;
                    N = Math.ceil(i / 2);
                    B = (N - 1) * _ + N * b;
                    d = B > d ? B : d;
                    v = d - b;
                    r = o + d;
                    S = 100;
                    a = this._orign_bubble_height + S;
                    this.bubbleNode.getComponent(UITransform).setContentSize(size(r, a));
                    l = this._oneRowCardsHeight + S;
                    w = 100;
                    this.cards_rootNode.getComponent(UITransform).setContentSize(size(d, l));
                }
                else if (i > 28 && i <= 42) {
                    S = 100;
                    w = 100;
                    n = 0.32;
                    y = 3;
                    b = f * n;
                    N = 14;
                    d = (N - 1) * _ + N * b;
                    v = d - b;
                    r = o + d;
                    a = 379;
                    this.bubbleNode.getComponent(UITransform).setContentSize(size(r, a));
                    l = this._oneRowCardsHeight + 2 * S;
                    this.cards_rootNode.getComponent(UITransform).setContentSize(size(d, l));
                }
                else {
                    n = 0.32;
                    y = 4;
                    b = f * n;
                    N = 14;
                    d = (N - 1) * _ + N * b;
                    v = d - b;
                    r = o + d;
                    a = 379;
                    S = 100;
                    w = 100;
                    this.bubbleNode.getComponent(UITransform).setContentSize(size(r, a));
                    l = this._oneRowCardsHeight + 2 * S;
                    this.scrollview.vertical = true;
                    this.scrollview.view.getComponent(UITransform).setContentSize(size(d, l));
                    this.scrollview.node.getComponent(UITransform).setContentSize(size(d, l));
                    P = Math.ceil(1 * (i - 42) / N) * S + l;
                    this.scrollview.content.getComponent(UITransform).setContentSize(size(d, P));
                }
                this.refreshBubbleHandsScore(r, a);
                let L = 0, M = 0, V = 0, k = 0;
                for (let o = 0; o < i; o++) {
                    let a = e.listen[o], r = instantiate(this.tcardNode);
                    r.active = true;
                    t = r.getChildByName("num");
                    t.getComponent(Label).string = "x" + a.n;
                    0 == a.n ? t.getComponent(Label).color = color(109, 109, 109, 255) : t.getComponent(Label).color = color(255, 255, 255, 255);
                    (0.45 == n || 0.32 == n) && r.getComponent(UITransform).setContentSize(size(b, w));
                    let d = instantiate(this.cardPrefab);
                    s = d.getComponent("RummyCard");
                    s.init(a.c, false, 0);
                    s.openCard();
                    s.showLaiziFlag(RummyDataManager.shared().isShowLaiziColor(a.c, this.tid_key));
                    s.setMask(0 == a.n);
                    d.setScale(v3(n, n));
                    0.45 == n ? (d.setPosition(new Vec3(-b / 2, -52)), t.setPosition(new Vec3(-b / 2, -106))) : 0.32 == n && (d.setPosition(new Vec3(-b / 2, -37.12)), t.setPosition(new Vec3(-b / 2, -75.352)));
                    r.addChild(d);
                    i <= 42 ? (0 == y ? (L = (b + _) * o - v, M = l - 12, t.getComponent(Label).fontSize = 28) : 1 == y ? (t.getComponent(Label).fontSize = 28, o + 1 <= N ? (L = (b + _) * o - v, M = l - 12) : (L = (b + _) * (o - N) - v, M = S)) : 2 == y ? (t.getComponent(Label).fontSize = 20, o + 1 <= N ? (L = (b + _) * o - v, M = l - 12) : (L = (b + _) * (o - N) - v, M = l - S - 12)) : 3 == y && (t.getComponent(Label).fontSize = 20, V = Math.floor(o / N), k = Math.ceil(o % N), L = (b + _) * k - v, M = l - S * V - 12), r.setPosition(v3(L, M)), this.cards_rootNode.addChild(r)) : (t.getComponent(Label).fontSize = 20, V = Math.floor(o / N), k = Math.ceil(o % N), L = (b + _) * k - v, M = -S * V - 12, r.setPosition(v3(L, M)), this.scrollview.content.addChild(r));
                    this.hasListenInfo = true;
                }
            }
            else {
                this.bubbleNode.getComponent(UITransform).setContentSize(size(this._orgin_bubble_width, this._orign_bubble_height));
                this.refreshBubbleHandsScore(this._orgin_bubble_width, this._orign_bubble_height);
            }
        }
    }
    showPickCardTips(e, t) {
        ToolUtils.isObjValid(this.iconNode) && (this.iconNode.getChildByName("pick_bg").active = e, this.iconNode.getChildByName("pick_wz").active = e, sys.isObjectValid(t) && (1 == t ? i18nMgr.shared().changeLabelLanguage(this.iconNode.getChildByName("pick_wz").getComponent(Label), "game_setting.draw", true) : 2 == t && i18nMgr.shared().changeLabelLanguage(this.iconNode.getChildByName("pick_wz").getComponent(Label), "game_setting.finish", true)));
    }
    showpickBubbleView(e, t) {
        if (ToolUtils.isObjValid(this.pickBubbleNode) && (this.pickBubbleNode.active = e, e && sys.isObjectValid(t))) {
            let e = Math.floor(t.pick_card / 16), i = Math.floor(t.pick_card % 16);
            this.pickBubbleNode.getChildByName("pick_layout").getChildByName("card_num").getComponent(Label).string = String(i);
            this.cardColor[e] && (this.pickBubbleNode.getChildByName("pick_layout").getChildByName("card_color").getComponent(Sprite).spriteFrame = this.cardColor[e]);
            i18nMgr.shared().changeLabelLanguage(this.pickBubbleNode.getChildByName("finish_card").getComponent(Label), "game_setting.finish_card", false, t.finish_num);
            i18nMgr.shared().changeLabelLanguage(this.pickBubbleNode.getChildByName("score_left").getComponent(Label), "game_setting.score_left", false, t.lost);
            let s = this.pickBubbleNode.getChildByName("cards_root");
            if (ToolUtils.isObjValid(s)) {
                let e, i, n = 0, o = t.helper_pick_opencard_new_groups;
                s.destroyAllChildren();
                let a, l, h, r, d = 6, b = 0.32, _ = -467, m = 14, w = -38, N = o.length, y = 168 * b, S = (w - _ - (d + y) * (N - 1)) / (m - N);
                for (let t = 0, m = o.length; t < m; t++) {
                    let m = o[t].cards;
                    a = instantiate(this.pickBubbleNode.getChildByName("zhegai"));
                    a.active = true;
                    s.addChild(a);
                    let w = o[t].color;
                    r = m.length;
                    let N = Math.floor(r / 2);
                    h = 0;
                    for (let o = 0; o < r; o++) {
                        let a = instantiate(this.cardPrefab);
                        e = a.getComponent("RummyCard");
                        e.init(m[o], false, 0);
                        e.openCard();
                        e.showLaiziFlag(RummyDataManager.shared().isShowLaiziColor(m[o], this.tid_key));
                        e.setMask(0 == m[o]);
                        a.setScale(v3(b, b));
                        i = _ + S * n + t * (d + y - S);
                        a.setPosition(new Vec3(i, 0));
                        s.addChild(a);
                        n += 1;
                        o == N && (h = i);
                    }
                    0 == w ? a.getComponent(Sprite).spriteFrame = this.zhegaiImags[0] : 2 == w ? a.getComponent(Sprite).spriteFrame = this.zhegaiImags[1] : 3 == w && (a.getComponent(Sprite).spriteFrame = this.zhegaiImags[2]);
                    0 == Math.floor(r % 2) && (h -= S / 2);
                    l = (r - 1) * S + y;
                    a.getComponent(UITransform).setContentSize(size(l, 12));
                    a.setSiblingIndex(100 + t);
                    a.setPosition(v3(h, -30));
                }
            }
        }
    }
}
