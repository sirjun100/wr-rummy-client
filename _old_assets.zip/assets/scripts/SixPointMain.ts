// @ts-nocheck
// Recovered from index.js:529
import { _decorator, assetManager, AudioSource, director, instantiate, macro, Node, SpriteFrame, sys, v3, Widget } from "cc";
import Parent from "./Parent";
import i18nMgr from "./i18nMgr";
import LoadMultiResTool from "./LoadMultiResTool";
import PushCenter from "./PushCenter";
import { TLog } from "./TLog";
import { ToolUtils } from "./ToolUtils";
import { TransferPlatform } from "./TransferPlatform";
import TweenTool from "./TweenTool";
import Utils from "./Utils";
import BundleNameDefined from "./BundleNameDefined";
import { CommonGameType, HallGameType } from "./CommDefine";
import GameConfig from "./GameConfig";
import NetConfig from "./NetConfig";
import PhpReportDefined from "./PhpReportDefined";
import PushEvent from "./PushEvent";
import RummyCmd from "./RummyCmd";
import User from "./User";
import HttpManager from "./HttpManager";
import LabaServer from "./LabaServer";
import Server from "./Server";
import SoundManager from "./SoundManager";
import gameNetworkDelay from "./gameNetworkDelay";
import SixPointAction from "./SixPointAction";
import SixPointCardPlayer from "./SixPointCardPlayer";
import SixPointChat from "./SixPointChat";
import SixPointCmd from "./SixPointCmd";
import { SixPointManager } from "./SixPointManager";
import { SixPointNoSeatList } from "./SixPointNoSeatList";
import { SixPointRecode } from "./SixPointRecode";
import SixPointTable from "./SixPointTable";
import SixPointTip from "./SixPointTip";
const { ccclass, property } = _decorator;
@ccclass("SixPointMain")
export class SixPointMain extends Parent {
    public _TAG: string = "SixPointMain";
    public isNetworkDelay: boolean = true;
    public _gameData: any = {};
    public _enterStartTime: number = 0;
    public backgroundSatyTime: number = 0;
    @property(Node)
    public rootNode: Node = null;
    @property([AudioSource])
    public musicAudioSources: AudioSource[] = [];
    @property(SpriteFrame)
    public helpImg: SpriteFrame = null;
    public roomTable: any = undefined;
    public roomAction: any = undefined;
    public roomCardPlayer: any = undefined;
    public roomTip: any = undefined;
    public roomChat: any = undefined;
    public gameSettingPrefab: any = null;
    public gameRecodePrefab: any = null;
    public gameRecodeView: any = null;
    public noSeatPlayerView: any = null;
    public gameNoseatPrefab: any = null;
    public menualertPrefab: any = null;
    public canUpdateLabaCoin: boolean = true;
    public networkDelay: number = 0;
    public tid_key: string = "";
    public hasReqRandom: boolean = false;
    onDestroy() {
        gameNetworkDelay.shared().removechild();
        Server.shared().onBackGroundLink();
        PushCenter.shared().removeListenersByTag(this);
        this.unscheduleAllCallbacks();
    }
    onLoad() {
        User.shared().fromGame = 1;
        ToolUtils.switchSceneTye = -1;
        ToolUtils.bSwitchToGame = false;
        window.InHallScene = false;
        window.InGameScene = true;
        window.InSwitchScene = false;
        window.IsBackToHallLoad = false;
        macro.ENABLE_MULTI_TOUCH = false;
        SixPointManager.shared()._tidKey = User.shared().curTid_key;
        this.tid_key = User.shared().curTid_key;
        SixPointManager.shared()._vid = ToolUtils.curRoomId;
        User.shared().exitRoomGameVid = ToolUtils.curRoomId;
        this.node.getChildByName("root").getComponent(Widget).enabled = true;
    }
    start() {
        SixPointManager.shared().data.room_ad_act = -1;
        ToolUtils.report_time_param.gameStart = sys.now();
        this._enterStartTime = sys.now();
        gameNetworkDelay.shared().loadNode();
        this.resetGameData();
        let e = new Node;
        this.node.addChild(e);
        SixPointManager.shared().sceneNode = e;
        this.initView();
        this._gameData.connectCount = 0;
        this.initPushCenter();
        this.regEvent();
        1 == ToolUtils.heart_open && (this.unschedule(this.netWorkDelayUpdate), this.schedule(this.netWorkDelayUpdate, 2));
        TweenTool.delayAct(this.node, (() => {
            LoadMultiResTool.getInstance().preLoadRes([{ bundleName: BundleNameDefined.bundle_public, path: "prefab/menu_alert" }]);
            this.loadGameSounds();
        }), 0.5, true);
        let t = {};
        t.htype = HallGameType.LOBBY_GAME_TYPE_SIXDICE;
        ToolUtils.saveData(User.shared().data.uid + "saveCommRecommendRoom", ToolUtils.toJsonString(t));
    }
    netWorkDelayUpdate() {
        if (this.networkDelay = this.networkDelay + 1, !User.shared().isGameDisconnectServer) {
            if (this.isNetworkDelay) {
                let e = { cmd: NetConfig.HEARTBEAT_CMD };
                Server.shared().send(e);
                ToolUtils.lastSendHeartBeatTime = ToolUtils.getOsTime();
                this.isNetworkDelay = false;
                this.networkDelay = 0;
            }
            if (this.networkDelay > 10) {
                let e = { cmd: NetConfig.HEARTBEAT_CMD };
                Server.shared().send(e);
                ToolUtils.lastSendHeartBeatTime = ToolUtils.getOsTime();
                this.isNetworkDelay = false;
                this.networkDelay = 0;
            }
        }
    }
    initView() {
        SixPointManager.shared().popNode = this.rootNode.getChildByName("pop_layer");
        SoundManager.shared().playTargetMusic(this.musicAudioSources[0]);
        this.roomTable = this.rootNode.getChildByName("table_layout").getComponent(SixPointTable);
        this.roomTable.setCallBack(this.roomActionCallback.bind(this));
        this.roomAction = this.rootNode.getChildByName("action_root").getComponent(SixPointAction);
        this.roomAction.setCallBack(this.roomActionCallback.bind(this));
        this.roomCardPlayer = this.rootNode.getChildByName("card_player_root").getComponent(SixPointCardPlayer);
        this.roomCardPlayer.setCallBack(this.roomCardPlayerActionCallback.bind(this));
        this.roomTip = this.rootNode.getChildByName("tip_root").getComponent(SixPointTip);
        this.roomTip.setCallBack(this.roomActionCallback.bind(this));
        this.roomChat = this.rootNode.getChildByName("chat_root").getComponent(SixPointChat);
        this.roomChat.setCallBack(this.roomActionCallback.bind(this));
        SixPointManager.shared().seatPosVec = [];
        for (let e = 0; e < 8; e++) {
            let t = v3(), a = this.roomCardPlayer.getPlayerHeadViewPos(e);
            this.roomTip.node.inverseTransformPoint(t, a);
            SixPointManager.shared().seatPosVec.push(t);
        }
        let e = v3(), t = this.roomTable.getZhuangPoint();
        this.roomTip.node.inverseTransformPoint(e, t);
        SixPointManager.shared().zhuangPoint = e;
        SixPointManager.shared().seatPosVec.push(e);
        Server.shared().pop_response();
        SixPointManager.shared().sendGameInfoRequest();
        this.unschedule(this.updateGameState);
        this.schedule(this.updateGameState, 1);
        this.roomAction.updateGullakBtnStatus(User.shared().act_68_open, User.shared().act_68_full_status, true);
    }
    updateGameState() {
        this._gameData.game_cd = this._gameData.game_cd - 1;
        this.roomTip.updateGameState(this._gameData.game_cd, this._gameData.game_state);
        1 == this._gameData.game_state && (2 == this._gameData.game_cd || 1 == this._gameData.game_cd ? SoundManager.shared().playFx("xiazhu_stop1") : 0 == this._gameData.game_cd && SoundManager.shared().playFx("xiazhu_stop2"));
    }
    roomCardPlayerActionCallback(e) {
        if (-1 != e.indexOf("player_")) {
            if (7 != parseInt(e.split("_")[1])) {
                return;
            }
            this.dealNoseatListLogic();
        }
    }
    showMenuAlert() {
        try {
            ToolUtils.loadCommonPrefab(this.menualertPrefab, BundleNameDefined.bundle_public, "prefab/menu_alert", (e => {
                if (sys.isObjectValid(e) && e.isValid && sys.isObjectValid(this.node)) {
                    this.menualertPrefab = e;
                    let t = this.node.getChildByName("menu_alert");
                    if (!ToolUtils.isObjValid(t)) {
                        t = instantiate(e);
                        t.parent = this.node;
                        let a = t.getComponent("MenuAlert");
                        this.initMenu(a);
                    }
                }
            }));
        }
        catch (e) {
            TLog.printError("trycatch MainRummy onDealBtnAction set:", e);
        }
    }
    initMenu(e) {
        e.startShowAnim();
        e.setCallback(this.onMenuCallback.bind(this));
        e.setTidKey(User.shared().curTid_key);
        e.setLandscapeShow();
        e.setSevenUpMenuShow();
    }
    onMenuCallback(e) {
        SoundManager.shared().playFx("click");
        try {
            switch (String(e)) {
                case "exit":
                    this.dealCloseLogic();
                    break;
                case "setting":
                    this.dealSetLogic();
                    break;
                case "help":
                    let e = {};
                    e.parent = this.node, e.isLandscape = true, e.target_sp = this.helpImg, e.game_type = CommonGameType.SixDice, Utils.shared().showSingleGameRuleHelpView(e);
            }
        }
        catch (e) {
            TLog.printError("trycatch onMenuCallback:", e);
        }
    }
    roomActionCallback(e) {
        if ("main_close" == e) {
            this.dealCloseLogic();
        }
        else if ("add_chip" == e) {
            let e = { vid: ToolUtils.curRoomId, min_entry: this._gameData.cur_bet, tid_key: this.tid_key };
            Utils.shared().showQuickRecharge(ToolUtils.curVId, SixPointManager.shared().popNode, true, User.shared().curTid_key, 0, e.min_entry, false, 0, 0, 0, 1);
            User.shared().updatePayScene(PhpReportDefined.pay_scene.game_desktop, ToolUtils.curVId);
        }
        else if ("btn_menu" == e) {
            this.showMenuAlert();
        }
        else if (-1 != e.indexOf("btn_bet_")) {
            let t = parseInt(e.split("btn_bet_")[1]);
            this.dealChooseSelectBetLogic(t);
        }
        else if ("btn_trend" == e) {
            this.send_history_recode_request();
        }
        else if ("btn_repeat" == e) {
            this.dealRepeatLogic();
        }
        else if ("btn_xz_area0" == e) {
            this.send_request_down_bet(this._gameData.cur_bet, 0);
        }
        else if ("btn_xz_area1" == e) {
            this.send_request_down_bet(this._gameData.cur_bet, 1);
        }
        else if ("btn_xz_area2" == e) {
            this.send_request_down_bet(this._gameData.cur_bet, 2);
        }
        else if ("btn_xz_area3" == e) {
            this.send_request_down_bet(this._gameData.cur_bet, 3);
        }
        else if ("btn_xz_area4" == e) {
            this.send_request_down_bet(this._gameData.cur_bet, 4);
        }
        else if ("btn_xz_area5" == e) {
            this.send_request_down_bet(this._gameData.cur_bet, 5);
        }
        else if ("gullak" == e) {
            let e = { vid: ToolUtils.curVId, parent_node: SixPointManager.shared().popNode };
            Utils.shared().doJumpLogic(PushEvent.JUMP_TO_Gullak, e, { isNext: false, bWithTip: true, link_id: sys.now(), reportEvtId: 4, reportScene: 2 });
            User.shared().updatePayScene(PhpReportDefined.pay_scene.game_desktop, ToolUtils.curVId);
        }
    }
    dealRepeatLogic() {
        let e = { cmd: SixPointCmd.GM_REPEAT_BET_REQUEST, ch_id: 0, uid: User.shared().data.uid, version: GameConfig.Server_Api_Ver, skey: User.shared().getSkey(), vid: ToolUtils.curRoomId, tid_key: this.tid_key };
        Server.shared().send(e);
    }
    dealNoseatListLogic() {
        this.send_players_info_request(1);
    }
    send_history_recode_request() {
        let e = { cmd: SixPointCmd.GM_HISTORY_RECORD_REQUSET, ch_id: 0, uid: User.shared().data.uid, version: GameConfig.Server_Api_Ver, skey: User.shared().getSkey(), vid: ToolUtils.curRoomId, tid_key: this.tid_key };
        Server.shared().send(e);
    }
    send_players_info_request(e) {
        let t = { cmd: SixPointCmd.GM_PLAYERS_INFO_REQUEST, ch_id: 0, uid: User.shared().data.uid, version: GameConfig.Server_Api_Ver, skey: User.shared().getSkey(), vid: ToolUtils.curRoomId, tid_key: this.tid_key, page: e };
        Server.shared().send(t);
    }
    send_request_down_bet(e, t) {
        let a = { cmd: SixPointCmd.GM_BET_REQUEST, ch_id: 0, uid: User.shared().data.uid, version: GameConfig.Server_Api_Ver, skey: User.shared().getSkey(), vid: ToolUtils.curRoomId, tid_key: this.tid_key, bet: e, option: t };
        Server.shared().send(a);
    }
    dealChooseSelectBetLogic(e) {
        if (-1 != this._gameData.select_betview_index) {
            let t = SixPointManager.shared().bet_configVec[e];
            this._gameData.cur_bet = t;
            this.roomAction.updateCurBetNum(t);
            this._gameData.select_betview_index = e;
            this.send_request_notify_bet_change(t, this._gameData.select_betview_index);
        }
    }
    judgeCoin(e) {
        return User.shared().data.money >= e;
    }
    send_request_notify_bet_change(e, t) {
        let a = { cmd: SixPointCmd.GM_NOTIFY_BET_CHANGE, ch_id: 0, uid: User.shared().data.uid, version: GameConfig.Server_Api_Ver, skey: User.shared().getSkey(), vid: ToolUtils.curRoomId, tid_key: this.tid_key, cur_bet: e, index: t };
        Server.shared().send(a);
    }
    dealSetLogic() {
        ToolUtils.loadCommonPrefab(this.gameSettingPrefab, BundleNameDefined.bundle_public, "prefab/game_setting", (e => {
            this.gameSettingPrefab = e;
            this.showSettingAlert();
        }));
    }
    showSettingAlert() {
        try {
            let e = director.getScene().getChildByName("Canvas");
            if (!ToolUtils.isObjValid(e.getChildByName("game_setting"))) {
                let t = instantiate(this.gameSettingPrefab);
                t.name = "game_setting";
                t.parent = e;
                let a = t.getComponent("GameSetting");
                a.startShowAnim();
                a.updateInfo(1);
                a.setLandscapeShow();
            }
        }
        catch (e) {
            TLog.printError("show room setting err:", e);
        }
    }
    dealHelpLogic() {
        let e = { isLandscape: true };
        e.target_sp = this.helpImg;
        e.game_type = CommonGameType.SixDice;
        Utils.shared().showSingleGameRuleHelpView(e);
    }
    dealCloseLogic() {
        let e = { bLandscape: ToolUtils.getIsNormalDirection(), bWithCancel: false, strContent: "Are you sure you want to leave the table?", bWithNativeAd: true };
        Utils.shared().showCommonAlert(e, (e => {
            1 == e && PushCenter.shared().pushEvent(PushEvent.ExitGameToHall);
        }), false);
    }
    resetGameData() {
        this._gameData.game_state = 0;
        this._gameData.game_cd = 0;
        SixPointManager.shared().init();
        SixPointManager.shared().resetPlayers();
        this._gameData.game_state = 0;
        this._gameData.game_cd = 0;
        this._gameData.bet_configVec = [];
        this._gameData.cur_bet = 0;
        this._gameData.sit_down_coin = 0;
        this._gameData.allBetMap = [];
        this._gameData.showCardModelVec = [];
        this._gameData.toSeatVec = [];
        this._gameData.curSelectBetIndex = -1;
        SixPointManager.shared().clientSeatId = 8;
        this._gameData.hander_state = 0;
        this._gameData.isGameStartING = false;
        this._gameData.isGameEnded = true;
        this._gameData.mCurDownMoney = 0;
        this._gameData.xiazhuBigOrSmall = 0;
        this._gameData.xiazhuVec = [];
        this._gameData.isInTuHao = false;
        this._gameData.isGameStartEd = false;
        this._gameData.betStatusVec = [];
    }
    regEvent() {
        Server.shared().regDispatch(NetConfig.HEARTBEAT_CMD, this.handler_server_HEARTBEAT_DELAY_return.bind(this), this);
        Server.shared().regDispatch(NetConfig.SERVER_LOGIN_GATE_RESP, this.handler_server_login_gate_return.bind(this), this);
        Server.shared().regDispatch(NetConfig.SM_LOGIN_RETURN, this.handler_server_login_return.bind(this), this);
        Server.shared().regDispatch(NetConfig.SYSTEM_GATEWAY_CMD, this.handler_server_system_gateway_return.bind(this), this);
        Server.shared().regDispatch(SixPointCmd.SM_TABLEINFO_RETURN, this.handler_table_info.bind(this), this);
        Server.shared().regDispatch(SixPointCmd.SM_HISTORY_RECORD_RETURN, this.handler_server_history_recode_return.bind(this), this);
        Server.shared().regDispatch(SixPointCmd.SM_SIT_DOWN_BC, this.handler_server_richaseainfo.bind(this), this);
        Server.shared().regDispatch(SixPointCmd.SM_BET_RETURN, this.handler_server_xiazhu.bind(this), this);
        Server.shared().regDispatch(SixPointCmd.SM_BET_BC, this.handler_server_xiazhu_bc.bind(this), this);
        Server.shared().regDispatch(SixPointCmd.SM_NOTIFY_ROLL_RESULT, this.handler_server_game_end.bind(this), this);
        Server.shared().regDispatch(SixPointCmd.SM_PER_SECOND_BET_INFO, this.handler_server_per_second_bet_info.bind(this), this);
        Server.shared().regDispatch(SixPointCmd.SM_NOTIFY_BET, this.handler_server_notify_bet.bind(this), this);
        Server.shared().regDispatch(SixPointCmd.SM_BET_CHANGE_RETURN, this.handler_server_bet_change_return.bind(this), this);
        Server.shared().regDispatch(SixPointCmd.SM_STAND_UP_BC, this.handler_server_stand_up_bc.bind(this), this);
        Server.shared().regDispatch(SixPointCmd.SM_NOTIFY_COMMING_REST, this.handler_server_notify_commit_rest.bind(this), this);
        Server.shared().regDispatch(SixPointCmd.SM_PLAYERS_INFO_RETURN, this.handler_server_players_info_return.bind(this), this);
        Server.shared().regDispatch(SixPointCmd.SM_ONLINE_PLAYERS_COUNT, this.handler_server_online_players_count.bind(this), this);
        Server.shared().regDispatch(SixPointCmd.SM_REPEAT_BET_RETURN, this.handler_server_repeat_xiazhu_return.bind(this), this);
        Server.shared().regDispatch(SixPointCmd.SERVER_ALERT_RETURN, this.handler_server_alert_return.bind(this), this);
        Server.shared().regDispatch(NetConfig.SM_CREATE_TABLE_RETURN, this.handler_server_create_tabel_return.bind(this), this);
    }
    handler_server_create_tabel_return(e) {
        sys.isObjectValid(e) && sys.isObjectValid(e.game_type) && e.game_type == CommonGameType.SixDice && 0 == parseInt("" + e.ret) && (sys.isObjectValid(e.session_id) && (User.shared().session_id = e.session_id), sys.isObjectValid(e.old_tid_key) && e.old_tid_key.length > 0 && this.tid_key == e.old_tid_key && sys.isObjectValid(e.tid_key) && e.tid_key.length > 0 && (this.tid_key = e.tid_key, User.shared().curTid_key = e.tid_key, SixPointManager.shared()._tidKey = e.tid_key, SixPointManager.shared().sendGameInfoRequest()));
    }
    showRecodelist(e) {
        try {
            let t = director.getScene().getChildByName("Canvas");
            if (!ToolUtils.isObjValid(t.getChildByName("sixpoint_noseat_recode"))) {
                this.gameRecodeView = instantiate(this.gameRecodePrefab);
                this.gameRecodeView.name = "sixpoint_noseat_recode";
                this.gameRecodeView.parent = t;
                let a = this.gameRecodeView.getComponent("SixPointRecode");
                a.initParaData((() => {
                    this.gameRecodeView = null;
                }));
                a.refreshUI(e);
            }
        }
        catch (e) {
            TLog.printError("show room setting err:", e);
        }
    }
    handler_server_notify_commit_rest(e) {
        this.tid_key == e.tid_key && (this.canUpdateLabaCoin = true, this._gameData.game_state = e.state, this._gameData.game_cd = e.cd, 3 == this._gameData.game_state && (this.roomTip.playRolldiceAnim(0, 0), this.roomTip.reset(), this.roomTable.resetInfo(), this.roomCardPlayer.reset()));
    }
    handler_server_stand_up_bc(e) {
        if (this.tid_key != e.tid_key) {
            return;
        }
        let t = e.uid, a = e.seatid;
        SixPointManager.shared().playerModels[a].isShow = false;
        t == User.shared().data.uid && (this._gameData.isInTuHao = false);
        this.roomCardPlayer.resetTuhaoSeat(a);
    }
    handler_server_per_second_bet_info(e) {
        if (this.tid_key == e.tid_key && sys.isObjectValid(e.betAreaInfo)) {
            for (let t = 0; t < e.betAreaInfo.length; t++) {
                let a = e.betAreaInfo[t], i = a.option, s = a.allbet, r = a.selfbet;
                this.roomTable.showOthersXzGoldNum(s, i);
                this.roomTable.showMeXzGoldNum(r, i);
                s - this._gameData.allBetMap[i] > 0 && (this.roomTip.showSendCoinEffect(7, a, true), this.roomCardPlayer.jumpWhenSendBet(7));
                this._gameData.allBetMap[i] = s;
            }
        }
    }
    handler_server_xiazhu_bc(e) {
        if (this.tid_key != e.tid_key) {
            return;
        }
        let t = e.money, a = e.option, i = e.seatid, s = e.uid, r = e.allbet, d = (e.bet, e.betAreaInfo);
        if (this._gameData.allBetMap[a] = r, s == User.shared().data.uid && (User.shared().updateMoney(t), this.updateSeatCoin(6, t)), this.updateSeatCoin(i, t), this.roomTable.showOthersXzGoldNum(r, a), i != SixPointManager.shared().all_seatid) {
            if (sys.isObjectValid(d) && Array.isArray(d)) {
                for (let e = 0; e < d.length; e++) {
                    this.roomTip.showSendCoinEffect(i, d[e], true);
                }
            }
            this.roomCardPlayer.jumpWhenSendBet(i);
        }
        this.roomCardPlayer.updateSeatCoinInfo(i, t);
    }
    handler_server_richaseainfo(e) {
        if (this.tid_key != e.tid_key) {
            return;
        }
        this._gameData.isInTuHao = false;
        let t = e.sex, a = e.seatid, i = e.avatar, s = e.name, r = e.money, d = e.uid, o = "";
        sys.isObjectValid(e.avatar_url) && (o = e.avatar_url);
        d == User.shared().data.uid && (SixPointManager.shared().all_seatid = a, this._gameData.isInTuHao = true, SoundManager.shared().playFx("sit"));
        let n = SixPointManager.shared().playerModels[a];
        n.isShow = true;
        n.uid = d;
        n.coin = r;
        n.name = s;
        n.sex = t;
        n.vlevel = e.vlevel;
        n.avatar = i;
        n.seatid = a;
        n.avatar_url = o;
        n.dsc = "";
        this.roomCardPlayer.showPlayer(a, s, d, i, e.vlevel, r, t, o);
    }
    handler_server_online_players_count(e) {
        this.tid_key == e.tid_key && sys.isObjectValid(e.count) && this.roomCardPlayer.updateNoSeatPlayerNum(e.count);
    }
    handler_server_notify_bet(e) {
        this.tid_key == e.tid_key && (this.canUpdateLabaCoin = true, SoundManager.shared().playFx("start_xiazhu"), this._gameData.game_state = e.state, this._gameData.game_cd = e.cd, this.roomTip.playStartGameAnim());
    }
    handler_server_game_end(e) {
        if (this.tid_key != e.tid_key) {
            return;
        }
        this.canUpdateLabaCoin = false;
        this._gameData.isGameEnded = false;
        this._gameData.isInGameing = false;
        this._gameData.endVal = e;
        this._gameData.game_state = e.state;
        this._gameData.game_cd = e.cd;
        this._gameData.endVal = e;
        let t = e.money, a = false;
        if (this._gameData.showCardModelVec = [], this._gameData.toSeatVec = [], sys.isObjectValid(e.rich_players) && Array.isArray(e.rich_players)) {
            for (let t = 0; t < e.rich_players.length; t++) {
                let i = e.rich_players[t], s = i.seatid, r = i.money, d = i.winscore;
                if (d > 0) {
                    a = true;
                    let e = {};
                    e.seatId = s;
                    e.coin = d;
                    e.selfCoin = r;
                    this._gameData.showCardModelVec.push(e);
                    this._gameData.toSeatVec.push(SixPointManager.shared().seatPosVec[s]);
                }
            }
        }
        let i = e.winscore;
        if (i > 0) {
            a = true;
            let e = { seatId: 6 };
            e.coin = i;
            e.selfCoin = t;
            this._gameData.showCardModelVec.push(e);
            this._gameData.toSeatVec.push(SixPointManager.shared().seatPosVec[6]);
        }
        if (e.other_win > 0) {
            a = true;
            let e = { seatId: 7 };
            e.coin = i;
            e.selfCoin = t;
            this._gameData.showCardModelVec.push(e);
            this._gameData.toSeatVec.push(SixPointManager.shared().seatPosVec[7]);
        }
        e.point;
        let s = e.win_op, r = e.diceinfo, d = e.banker_lose, o = e.betAreaInfo;
        if (d <= 0 && (d = 100), SoundManager.shared().playFx("rolldice"), SixPointManager.shared().win_op = [], sys.isObjectValid(s) && Array.isArray(s) && (SixPointManager.shared().win_op = s), SixPointManager.shared().diceinfo = [], sys.isObjectValid(r) && Array.isArray(r) && (SixPointManager.shared().diceinfo = r, this.roomTip.playRolldiceAnim(1, r)), sys.isObjectValid(e.pointinfo) && Array.isArray(e.pointinfo)) {
            for (let t = 0; t < e.pointinfo.length; t++) {
                SixPointManager.shared().history_recordVec[t].push(e.pointinfo[t]);
            }
        }
        SixPointManager.shared().history_recordVec.length > 0 && TweenTool.delayAct(this.node, (() => {
            this.roomTable.refreshSeziHistoryRecode(true);
        }), 7, true);
        TweenTool.delayAct(this.node, (() => {
            this.delayShowWinAnim();
        }), 6, true);
        let n = 7;
        TweenTool.delayAct(this.node, (() => {
            this.delayFlyGoldToZhuang();
        }), n, true);
        1 == SixPointManager.shared().isgold && (a = true);
        a && (n += 2, TweenTool.delayAct(this.node, (() => {
            this.delayFlyGoldToRewardArea(o);
        }), n, true), n += 1, TweenTool.delayAct(this.node, (() => {
            this.showGoldToSeat();
        }), n, true));
        n += 1;
        TweenTool.delayAct(this.node, (() => {
        }), n, true);
    }
    handler_server_alert_return(e) {
        if (this.tid_key != e.tid_key) {
            return;
        }
        let t = 0;
        sys.isObjectValid(e.type) && (t = Number(e.type));
        let a = e.alertStr;
        if (2 == t) {
            this.updateBankruptcyParam(e);
            let t = { vid: SixPointManager.shared()._vid, min_entry: this._gameData.cur_bet, tid_key: this.tid_key, is_pop: 0, parent_node: SixPointManager.shared().popNode };
            sys.isObjectValid(e.diff_coin) && e.diff_coin > 0 && (t.min_entry = e.diff_coin);
            Utils.shared().showQuickRecharge(ToolUtils.curVId, SixPointManager.shared().popNode, true, User.shared().curTid_key, 0, t.min_entry);
            User.shared().updatePayScene(PhpReportDefined.pay_scene.game_selectroom_less_money, ToolUtils.curVId);
        }
        else {
            11 != t && 0 != t || sys.isObjectValid(a) && String(a).length > 0 && Utils.shared().showToast(a, 2);
        }
    }
    delayShowWinAnim() {
        for (let e = 0; e < SixPointManager.shared().win_op.length; e++) {
            let t = SixPointManager.shared().win_op[e];
            this.roomTip.changeWinKuangStatus(0, t, true, v3(0, 0));
        }
        if (sys.isObjectValid(this._gameData.endVal.win_multiple)) {
            let e = [];
            for (let t = 0; t < this._gameData.endVal.win_multiple.length; t++) {
                e.push(this._gameData.endVal.win_multiple[t]);
            }
            this.roomTip.playWinAnim(e);
        }
    }
    showGoldToSeat() {
        this.canUpdateLabaCoin = true;
        let e = this._gameData.endVal.money;
        if (e > User.shared().data.money && User.shared().updateMoney(e), this.updateSeatCoin(6, e), TweenTool.delayAct(this.node, (() => {
            this.roomCardPlayer.updateSeatCoinInfo(6, User.shared().data.money);
        }), 1, true), sys.isObjectValid(this._gameData.endVal.rich_players)) {
            for (let e = 0; e < this._gameData.endVal.rich_players.length; e++) {
                let t = this._gameData.endVal.rich_players[e], a = t.seatid, i = t.money;
                t.winscore > 0 && (this.updateSeatCoin(a, i), TweenTool.delayAct(this.node, ((e, t) => {
                    this.roomCardPlayer.updateSeatCoinInfo(e, t);
                }), 1, true));
            }
        }
        let t = false;
        for (let e = 0; e < this._gameData.showCardModelVec.length; e++) {
            let a = this._gameData.showCardModelVec[e];
            sys.isObjectValid(a) && (this.roomCardPlayer.showFloatWord(1, a.seatId, a.coin), a.seatId == SixPointManager.shared().all_seatid && (t = true));
        }
        t && SoundManager.shared().playFx("win_me");
        for (let e = 0; e < SixPointManager.shared().win_op.length; e++) {
            let t = SixPointManager.shared().win_op[e];
            this.roomTip.showGoldEffect(this._gameData.toSeatVec, this._gameData.showCardModelVec, t);
        }
    }
    delayFlyGoldToRewardArea(e) {
        if (sys.isObjectValid(e) && Array.isArray(e) && e.length > 0) {
            for (let t = 0; t < e.length; t++) {
                this.roomTip.flyGoldToWinArea(e[t]);
            }
        }
    }
    delayFlyGoldToZhuang() {
        this.roomTip.flyGoldToZhuangJia();
    }
    handler_server_history_recode_return(e) {
        if (this.tid_key != e.tid_key) {
            return;
        }
        if (SixPointManager.shared().history_recordVec = [], sys.isObjectValid(e.history_record) && Array.isArray(e.history_record) && e.history_record.length > 0) {
            for (let t = 0; t < e.history_record.length; t++) {
                SixPointManager.shared().history_recordVec.push(e.history_record[t]);
            }
        }
        this.roomTable.refreshSeziHistoryRecode(false);
        0 == e.reflush && (ToolUtils.isObjValid(this.gameRecodeView) ? this.gameRecodeView.getComponent(SixPointRecode).refreshUI(e) : ToolUtils.loadCommonPrefab(this.gameRecodePrefab, BundleNameDefined.Bundle_SixDice, "prefab/sixpoint_noseat_recode", (t => {
            this.gameRecodePrefab = t;
            this.showRecodelist(e);
        })));
    }
    handler_server_players_info_return(e) {
        this.tid_key == e.tid_key && (ToolUtils.isObjValid(this.noSeatPlayerView) ? this.noSeatPlayerView.getComponent(SixPointNoSeatList).refreshUI(e) : ToolUtils.loadCommonPrefab(this.gameNoseatPrefab, BundleNameDefined.Bundle_SixDice, "prefab/sixpoint_noseat_players", (t => {
            this.gameNoseatPrefab = t;
            this.showNoSeatPlayerList(e);
        })));
    }
    showNoSeatPlayerList(e) {
        try {
            let t = director.getScene().getChildByName("Canvas");
            if (!ToolUtils.isObjValid(t.getChildByName("sixpoint_noseat_players"))) {
                this.noSeatPlayerView = instantiate(this.gameNoseatPrefab);
                this.noSeatPlayerView.name = "sixpoint_noseat_players";
                this.noSeatPlayerView.parent = t;
                let a = this.noSeatPlayerView.getComponent("SixPointNoSeatList");
                a.initParaData({ cb: e => {
                        -1 == e ? this.noSeatPlayerView = null : this.send_players_info_request(e + 1);
                    } });
                a.refreshUI(e);
            }
        }
        catch (e) {
            TLog.printError("show room setting err:", e);
        }
    }
    handler_server_repeat_xiazhu_return(e) {
        if (this.tid_key != e.tid_key) {
            return;
        }
        if (0 == e.ret) {
            if (this._gameData.isInGameing = true, sys.isObjectValid(e.money)) {
                let t = e.money;
                User.shared().updateMoney(t);
            }
            let t = e.money;
            this.updateSeatCoin(6, t);
            let a = e.betAreaInfo;
            if (sys.isObjectValid(a) && Array.isArray(a)) {
                for (let e = 0; e < a.length; e++) {
                    let t = a[e].option, i = a[e].allbet, s = a[e].selfbet;
                    this._gameData.allBetMap[t] = i;
                    this.roomTable.showMeXzGoldNum(s, t);
                    this.roomTable.showOthersXzGoldNum(i, t);
                    this.roomTip.showSendCoinEffect(6, a[e], true);
                }
            }
            this.roomCardPlayer.updateSeatCoinInfo(6, t);
        }
        else {
            if (1 == e.pop_addgold) {
                let t = { vid: ToolUtils.curRoomId, is_pop: 0 };
                sys.isObjectValid(e.cur_bet) && e.cur_bet > 0 && (t.min_entry = e.cur_bet);
                Utils.shared().showQuickRecharge(ToolUtils.curVId, SixPointManager.shared().popNode, true, User.shared().curTid_key, 0, t.min_entry);
                User.shared().updatePayScene(PhpReportDefined.pay_scene.game_selectroom_less_money, ToolUtils.curVId);
            }
            else {
                let t = e.err_msg;
                sys.isObjectValid(t) && t.length > 0 && Utils.shared().showToast(e.err_msg, 2);
            }
        }
    }
    handler_server_xiazhu(e) {
        if (this.tid_key != e.tid_key) {
            return;
        }
        if (0 == e.ret) {
            if (this._gameData.isInGameing = true, sys.isObjectValid(e.money)) {
                let t = e.money;
                User.shared().updateMoney(t);
            }
            let t = e.money, a = e.option, i = e.allbet, s = e.selfbet;
            this._gameData.cut_bet = e.bet;
            this._gameData.allBetMap[a] = i;
            this.updateSeatCoin(6, t);
            this.roomTable.showMeXzGoldNum(s, a);
            this.roomTable.showOthersXzGoldNum(i, a);
            let r = e.betAreaInfo;
            if (sys.isObjectValid(r) && Array.isArray(r)) {
                for (let e = 0; e < r.length; e++) {
                    this.roomTip.showSendCoinEffect(6, r[e], true);
                }
            }
            this.roomCardPlayer.jumpWhenSendBet(6);
            this.roomAction.updateCurBetNum(this._gameData.cur_bet);
            this.roomCardPlayer.updateSeatCoinInfo(6, t);
            6 != SixPointManager.shared().all_seatid && (this.updateSeatCoin(SixPointManager.shared().all_seatid, t), this.roomCardPlayer.updateSeatCoinInfo(SixPointManager.shared().all_seatid, t));
        }
        else {
            if (1 == e.pop_addgold) {
                let t = { vid: ToolUtils.curRoomId, is_pop: 0 };
                sys.isObjectValid(e.cur_bet) && e.cur_bet > 0 && (t.min_entry = e.cur_bet);
                Utils.shared().showQuickRecharge(ToolUtils.curVId, SixPointManager.shared().popNode, true, User.shared().curTid_key, 0, t.min_entry);
                User.shared().updatePayScene(PhpReportDefined.pay_scene.game_selectroom_less_money, ToolUtils.curVId);
            }
            else {
                let t = e.err_msg;
                sys.isObjectValid(t) && t.length > 0 && Utils.shared().showToast(e.err_msg, 2);
            }
        }
    }
    updateSeatCoin(e, t) {
        for (let a = 0; a <= 8; a++) {
            SixPointManager.shared().playerModels[a].seatid == e && (SixPointManager.shared().playerModels[a].coin = t);
        }
    }
    handler_server_bet_change_return(e) {
        this.tid_key == e.tid_key && sys.isObjectValid(e.cur_bet) && (this._gameData.cur_bet = e.cur_bet, this.roomAction.updateCurBetNum(e.cur_bet));
    }
    handler_server_system_gateway_return(e) {
        if (null != e.tid_key && null != e.tid_key && "" != e.tid_key) {
            if (this.tid_key === (e.tid_key || "") && -1 === e.res) {
                let e = i18nMgr.shared().getValueByKey("utlis.service_upgrade");
                Utils.shared().showToast(e, 2, 0, ToolUtils.getIsNormalDirection());
                this.backToHall();
            }
        }
        else {
            User.shared().curTid_key === this.tid_key && -1 === e.res && ToolUtils.isSafeString(e.msg).length > 0 && Utils.shared().showToast(e.msg, 2, 0, ToolUtils.getIsNormalDirection());
        }
    }
    handler_server_login_return(e) {
        try {
            sys.isObjectValid(e.session_id) && (User.shared().session_id = e.session_id);
            let t = ToolUtils.isSafeString(e.old_tid_key);
            if (this.tid_key != t) {
                return;
            }
            if (1 == parseInt("" + e.ret) && ToolUtils.isSafeString(e.alertStr).length > 0) {
                return this.backToHall(), Utils.shared().showToast(e.alertStr, 2, 0, ToolUtils.getIsNormalDirection()), void (ToolUtils.deskInfos.size <= 1 && Server.shared().disconnectWebSocket());
            }
            if (0 == parseInt("" + e.ret)) {
                if (sys.isObjectValid(e.session_id) && (User.shared().session_id = e.session_id), 1 == e.isNewTable) {
                    return void SixPointManager.shared().create_new_table();
                }
                0 == e.isNewTable && sys.isObjectValid(e.table_keys) && Array.isArray(e.table_keys) && e.table_keys.length > 0 ? (User.shared().curTid_key = e.table_keys[0].tid_key, this.tid_key = e.table_keys[0].tid_key, SixPointManager.shared()._tidKey = this.tid_key, SixPointManager.shared().sendGameInfoRequest()) : this.backToHall();
            }
            else {
                e.alertStr && "" != e.alertStr && Utils.shared().showCommomDialog(e.alertStr, "", (() => {
                }), false, ToolUtils.getIsNormalDirection(), null, null, null, null, null, this.tid_key);
            }
        }
        catch (e) {
        }
    }
    handler_table_info(e) {
        if (this.tid_key != e.tid_key) {
            return;
        }
        SixPointManager.shared().checkLoadingRefresh = false;
        TweenTool.stopNodeAction(SixPointManager.shared().sceneNode);
        this.canUpdateLabaCoin = true;
        let t = e.state;
        if (this._gameData.game_state = t, this._gameData.game_cd = e.cd, sys.isObjectValid(e.money) && User.shared().updateMoney(e.money), SixPointManager.shared().bet_configVec = [], sys.isObjectValid(e.bet_config) && Array.isArray(e.bet_config)) {
            for (let t = 0; t < e.bet_config.length; t++) {
                SixPointManager.shared().bet_configVec.push(e.bet_config[t]);
            }
        }
        this.roomAction.resetBetAmtView();
        SixPointManager.shared().all_seatid = e.seatid;
        let a = e.sex, i = e.avatar, s = e.name, r = e.uid;
        this._gameData.cur_bet = e.cur_bet;
        this.roomCardPlayer.reset();
        this.roomAction.updateCurBetNum(this._gameData.cur_bet);
        sys.isObjectValid(e.gold_limit) && (SixPointManager.shared().gold_limit = e.gold_limit);
        User.shared().data.uid = r;
        User.shared().updateMoney(e.money);
        User.shared().data.name = s;
        User.shared().data.sex = a;
        User.shared().data.vlevel = e.vlevel;
        User.shared().data.avatar = i;
        User.shared().data.avatar_url = e.avatar_url;
        this.roomCardPlayer.updateClientInfo();
        this._gameData.allBetMap = [];
        for (let e = 0; e <= 5; e++) {
            this._gameData.allBetMap.push(0);
        }
        this._gameData.sit_down_coin = e.sit_down_money;
        let d = SixPointManager.shared().playerModels[6];
        d.isShow = false;
        d.uid = r;
        d.coin = User.shared().data.money;
        d.name = s;
        d.sex = a;
        d.vlevel = User.shared().data.vlevel;
        d.avatar = i;
        d.seatid = 6;
        d.avatar_url = User.shared().data.avatar_url;
        for (let e = 0; e <= 5; e++) {
            SixPointManager.shared().playerModels[e].isShow = false;
            this.roomCardPlayer.resetTuhaoSeat(e);
        }
        if (sys.isObjectValid(e.rich_players) && Array.isArray(e.rich_players)) {
            for (let t = 0; t < e.rich_players.length; t++) {
                let a = e.rich_players[t], i = a.seatid, s = a.sex, r = a.avatar, d = a.name, o = a.uid, n = a.avatar_url, h = a.money, l = a.vlevel, _ = SixPointManager.shared().playerModels[i];
                _.isShow = true;
                _.uid = o;
                _.coin = h;
                _.name = d;
                _.sex = s;
                _.avatar = r;
                _.seatid = i;
                _.avatar_url = n;
                _.vlevel = l;
                this.roomCardPlayer.showPlayer(i, d, o, r, l, h, s, n);
            }
        }
        if (this.roomTable.resetInfo(), sys.isObjectValid(e.betAreaInfo) && Array.isArray(e.betAreaInfo)) {
            for (let t = 0; t < e.betAreaInfo.length; t++) {
                let a = e.betAreaInfo[t], i = a.option, s = a.allbet, r = a.selfbet;
                a.multiple;
                this.roomTable.showMeXzGoldNum(r, i);
                this.roomTable.showOthersXzGoldNum(s, i);
                this._gameData.allBetMap[i] = s;
            }
        }
        if (sys.isObjectValid(e.history_record) && Array.isArray(e.history_record) && e.history_record.length > 0) {
            SixPointManager.shared().history_recordVec = [];
            for (let t = 0; t < e.history_record.length; t++) {
                SixPointManager.shared().history_recordVec.push(e.history_record[t]);
            }
            this.roomTable.refreshSeziHistoryRecode(false);
        }
        1 == t && this.roomTip.playRolldiceAnim(0);
        SixPointManager.shared().speakermincoin = e.speakerminmoney;
        ToolUtils.isObjValid(e.disable_liveup) && 1 == e.disable_liveup && (Utils.shared().checkHasPopView(SixPointManager.shared().popNode) || this.reportSever());
    }
    handler_server_login_gate_return(e) {
        SixPointManager.shared().handler_server_login_gate_return(e);
    }
    handler_server_HEARTBEAT_DELAY_return(e) {
        this.isNetworkDelay = true;
        let t = sys.now() - e.ct;
        ToolUtils.gamePing = t;
        t > 999 && (t = 999);
        1 == User.shared().games_delay_open && (User.shared().hasMaintain || 0 == window.InGameScene || this.updateNetSignal(t));
    }
    updateNetSignal(e) {
    }
    initPushCenter() {
        PushCenter.shared().addListener(GameConfig.onEnterForeground, (e => {
            if (ToolUtils.isGameBackground = false, ToolUtils.isObjValid(this.node)) {
                let e = this, t = sys.now();
                this.scheduleOnce((() => {
                    e.isNetworkDelay = true;
                }), 1);
                Utils.shared().checkScreenLandscape();
                t / 1000 - this.backgroundSatyTime / 1000 > 30 || ToolUtils.backgroundWebSocketReconnection ? (ToolUtils.backgroundWebSocketReconnection = false, this.scheduleOnce((() => {
                    Server.shared().disconnectWebSocket();
                })), this.scheduleOnce((() => {
                    SixPointManager.shared().loginGameServer();
                }), 0.2)) : this.scheduleOnce((() => {
                    SixPointManager.shared().sendGameInfoRequest();
                }), 0.2);
            }
        }), this);
        PushCenter.shared().addListener(GameConfig.onEnterBackground, (e => {
            ToolUtils.isGameBackground = true;
            this.backgroundSatyTime = sys.now();
            this.send_request_enterBackGround();
        }), this);
        PushCenter.shared().addListener(PushEvent.ExitGameToHall, (e => {
            ToolUtils.isObjValid(this.node) && this.backToHall();
        }), this);
        PushCenter.shared().addListener(GameConfig.NetWorkErrorReconnection, (e => {
            this.scheduleOnce((() => {
                this.scheduleOnce((() => {
                    Server.shared().disconnectWebSocket();
                }));
                this.scheduleOnce((() => {
                    SixPointManager.shared().loginGameServer();
                }), 0.2);
            }));
        }), this);
        PushCenter.shared().addListener(PushEvent.RefreshRoomDesk, (() => {
            ToolUtils.isObjValid(this.node) && SixPointManager.shared().sendGameInfoRequest();
        }), this);
        PushCenter.shared().addListener(GameConfig.NetWorkDelayShow, (e => {
            this.isNetworkDelay = true;
            this.networkDelay = 0;
        }), this);
        PushCenter.shared().addListener(GameConfig.Update_Money, (e => {
            ToolUtils.isObjValid(this.node) && this.canUpdateLabaCoin && this.updateCoin(User.shared().data.money);
        }), this);
        PushCenter.shared().addListener(GameConfig.RummyCompleteExit, (e => {
            this.backToHall();
        }), this);
        PushCenter.shared().addListener(PushEvent.Low_Memory_Notice, (e => {
            ToolUtils.isObjValid(this.node) && this.releaseRes();
        }), this);
        PushCenter.shared().addListener(PushEvent.commentDownloaderImg, (e => {
            if (ToolUtils.isObjValid(this.node)) {
                for (let t = 0; t < 6; t++) {
                    let a = SixPointManager.shared().playerModels[t];
                    a.avatar_url == e && this.roomCardPlayer.updatePlayerHead(a.seatid, a.avatar, a.avatar_url);
                }
            }
        }), this);
        PushCenter.shared().addListener(PushEvent.ShowTwentyFourRecharge, (e => {
            sys.isObjectValid(e) && null != e.tid_key && e.tid_key === this.tid_key && ToolUtils.isObjValid(this.node) && (undefined !== e.parent_node && null !== e.parent_node || (e.parent_node = SixPointManager.shared().popNode), e.vid = SixPointManager.shared()._vid, e.in_room = 1, Utils.shared().showTwentyHourRecharge(e));
        }), this);
        PushCenter.shared().addListener(PushEvent.ShowBuyOneGetThree, (e => {
            sys.isObjectValid(e) && null != e.tid_key && e.tid_key === this.tid_key && ToolUtils.isObjValid(this.node) && (undefined !== e.parent_node && null !== e.parent_node || (e.parent_node = SixPointManager.shared().popNode), e.vid = SixPointManager.shared()._vid, e.in_room = 1, Utils.shared().showBuyOneGetThree(e));
        }), this);
        PushCenter.shared().addListener(PushEvent.ShowFirstRecharge, (e => {
            sys.isObjectValid(e) && null != e.tid_key && e.tid_key === this.tid_key && ToolUtils.isObjValid(this.node) && (undefined !== e.parent_node && null !== e.parent_node || (e.parent_node = SixPointManager.shared().popNode), e.vid = SixPointManager.shared()._vid, e.in_room = 1, Utils.shared().showFirstRecharge_game2(e));
        }), this);
        PushCenter.shared().addListener(PushEvent.ShowCouponAct, (e => {
            ToolUtils.isObjValid(this.node) && Utils.shared().showCouponActView(null, e);
        }), this);
        PushCenter.shared().addListener(PushEvent.ShowRestartGift, (e => {
            sys.isObjectValid(e) && null != e.tid_key && e.tid_key === this.tid_key && ToolUtils.isObjValid(this.node) && (e.parent_node = SixPointManager.shared().popNode, e.vid = SixPointManager.shared()._vid, e.in_room = 1, Utils.shared().showRestartGift(e));
        }), this);
        PushCenter.shared().addListener(PushEvent.ShowConsecutiveGift, (e => {
            sys.isObjectValid(e) && null != e.tid_key && e.tid_key === this.tid_key && ToolUtils.isObjValid(this.node) && (undefined !== e.parent_node && null !== e.parent_node || (e.parent_node = SixPointManager.shared().popNode), e.vid = SixPointManager.shared()._vid, e.in_room = 1, Utils.shared().showConsecutiveGift(e));
        }), this);
        PushCenter.shared().addListener(PushEvent.Update_Gullak_RewardInGame, (e => {
            ToolUtils.isObjValid(this.node) && this.roomAction.updateGullakBtnStatus(User.shared().act_68_open, User.shared().act_68_full_status, true);
        }), this);
    }
    reportSever() {
        let e = { cmd: NetConfig.CLIENT_NOTIFY_GOBACK_GAME, uid: User.shared().data.uid, type: 2, tid_key: User.shared().curTid_key };
        Server.shared().send(e);
    }
    updateBankruptcyParam(e) {
        sys.isObjectValid(e.act_124_show) && (SixPointManager.shared().data.act_124_show = e.act_124_show);
        sys.isObjectValid(e.act_98_show) && (SixPointManager.shared().data.act_98_show = e.act_98_show, 1 == e.act_98_show ? SixPointManager.shared().data.act_98_param = { vid: SixPointManager.shared()._vid, isShowTip: true, bShowNetTip: true, tid_key: this.tid_key, min_entry: this._gameData.cur_bet, ext: { times: e.times, reward_value: e.reward_value, ad_multiple: e.ad_multiple, reward_list: [{ type: 7, amt: e.reward_value }] } } : SixPointManager.shared().data.act_98_param = {});
        sys.isObjectValid(e.act_139_show) && (SixPointManager.shared().data.act_139_show = e.act_139_show);
        sys.isObjectValid(e.show_ad) ? SixPointManager.shared().data.show_room_ad = e.show_ad : sys.isObjectValid(e.show_room_ad) && (SixPointManager.shared().data.show_room_ad = e.show_room_ad);
        sys.isObjectValid(e.room_ad_string) && (SixPointManager.shared().data.room_ad_string = e.room_ad_string);
        SixPointManager.shared().data.show_ad = SixPointManager.shared().data.show_room_ad;
    }
    updateCoin(e) {
        SixPointManager.shared().playerModels[SixPointManager.shared().all_seatid].coin = e;
        this.roomCardPlayer.updateClientPlayerInfo();
    }
    loadGameSounds() {
        try {
            SoundManager.shared().preLoadBundleSounds(BundleNameDefined.bundle_sound, "brgame");
        }
        catch (e) {
        }
    }
    send_request_enterBackGround() {
        let e = { cmd: RummyCmd.CLIENT_OFFLINE, uid: User.shared().data.uid, version: GameConfig.Server_Api_Ver, tid_key: this.tid_key, skey: User.shared().getSkey() };
        Server.shared().send(e);
    }
    exitCallBack(e) {
        if (1 == e) {
            let e = { cmd: NetConfig.GM_LOGINOUT_REQUEST, tid_key: this.tid_key, vid: ToolUtils.curRoomId, uid: User.shared().data.uid };
            Server.shared().send(e);
        }
    }
    backToHall() {
        this.exitCallBack(1);
        let e = sys.now() - this._enterStartTime;
        e = e > 1000 ? 0 : 1000 - e;
        setTimeout((() => {
            User.shared().hasMaintain ? this.backToLogin() : window.InGameScene && (window.InGameScene = false, User.shared().getHallPopList(false), User.shared().isLoginHall = false, HttpManager.shared().doReportUserAct(PhpReportDefined.Click_Game_QuitGame), TransferPlatform.shared().setHighFrameRate(), window.InSwitchScene = true, window.IsBackToHallLoad = true, Utils.shared().preLoadBundleAsset(0 == TransferPlatform.shared().getDeviceLevel()), Utils.shared().showLoading(20), this.enterSwitchScene(2));
        }), e);
    }
    backToLogin() {
        window.InGameScene && (window.InGameScene = false, window.InHallScene = false, HttpManager.shared().doReportUserAct(PhpReportDefined.Click_Game_QuitGame), Utils.shared().hideRummyNode(), LabaServer.shared().reset(), Server.shared().reset(), User.shared().doSendMatchOnlineStatus(0), TransferPlatform.shared().setHighFrameRate(), this.enterSwitchScene(3));
    }
    enterSwitchScene(e) {
        let t = 100;
        sys.isNative ? sys.os !== sys.OS.IOS && sys.os !== sys.OS.OSX || (t = 50, ToolUtils.isPadPlatform() && (t = 30)) : t = 0;
        let a = e, i = this;
        ToolUtils.loadBundleScene(BundleNameDefined.bundle_switch, BundleNameDefined.switch_scence, ((e, s) => {
            null == e ? (ToolUtils.switchSceneTye = a, i.jumpToSwitchScene(t, s)) : ToolUtils.loadBundleScene(BundleNameDefined.bundle_switch, BundleNameDefined.switch_scence, ((e, s) => {
                null == e ? (ToolUtils.switchSceneTye = a, i.jumpToSwitchScene(t, s)) : (Utils.shared().hideLoading(), Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text27"), 2));
            }));
        }));
    }
    jumpToSwitchScene(e, t) {
        if (User.shared().checkIfHasLoadHallBundle()) {
            sys.os === sys.OS.IOS || sys.os === sys.OS.OSX ? (ToolUtils.isPadPlatform() || setTimeout((() => {
            }), e), Utils.shared().hideLoading(), TransferPlatform.shared().orientationToPortrait((() => {
                director.runScene(t);
            }))) : (Utils.shared().hideLoading(), TransferPlatform.shared().orientationToPortrait((() => {
                setTimeout((() => {
                    director.runScene(t);
                }), e);
            })));
        }
        else {
            let a = false, i = 0;
            this.schedule((s => {
                i += s;
                a || (User.shared().checkIfHasLoadHallBundle() || i >= 2) && (a = true, sys.os === sys.OS.IOS || sys.os === sys.OS.OSX ? (ToolUtils.isPadPlatform() || setTimeout((() => {
                }), e), Utils.shared().hideLoading(), TransferPlatform.shared().orientationToPortrait((() => {
                    director.runScene(t);
                }))) : (Utils.shared().hideLoading(), TransferPlatform.shared().orientationToPortrait((() => {
                    setTimeout((() => {
                        director.runScene(t);
                    }), e);
                }))), this.unscheduleAllCallbacks());
            }));
        }
    }
    onSceneLaunched() {
        PushCenter.shared().pushEvent(PushEvent.BackToHall);
        Utils.shared().hideLoading();
    }
    releaseRes() {
        ToolUtils.isObjValid(this.node) && ToolUtils.isObjValid(SixPointManager.shared().popNode) && (this.releasePrefabRes(BundleNameDefined.bundle_firstRecharge, "first_buy", "FirstRecharge"), this.releasePrefabRes(BundleNameDefined.bundle_payoneforthree, "payoneforthree", "BuyOneGetThree"), this.releasePrefabRes(BundleNameDefined.bundle_public, "comm_magic_face", "comm_magic_face"), this.releasePrefabRes(BundleNameDefined.bundle_public, "chat_alert", "chat_alert"));
    }
    releasePrefabRes(e, t, a) {
        let i = assetManager.getBundle(e);
        if (!i) {
            return void TLog.printError("---------- releaseRes bundle is null:", e);
        }
        let s = director.getScene().getChildByName("Canvas");
        if (!s.isValid) {
            return;
        }
        let r = s.getChildByName(a);
        ToolUtils.isObjValid(r) || SixPointManager.shared().popNode.getChildByName(a) || this.node.getChildByName(a) || i.release(ToolUtils.format("prefab/${0}", t));
    }
}
