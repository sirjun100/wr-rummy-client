// @ts-nocheck
// Recovered from index.js:543
import { _decorator, assert, assetManager, AudioClip, AudioSource, clamp01, resources, sys } from "cc";
import { TLog } from "./TLog";
import TweenTool from "./TweenTool";
import { ToolUtils } from "./ToolUtils";
const { ccclass } = _decorator;
@ccclass("SoundManager")
export default class SoundManager {
    static _instance = null;
    static _audioSource = undefined;
    public sounds: any = {};
    public bg_enabled: boolean = false;
    public fx_enabled: boolean = false;
    public _initLoad: boolean = false;
    public soundVolume: number = 1;
    public _callBack: any = null;
    public music: string = "";
    public _hallAudioSource: any = null;
    public _roomAudioSource: any = null;
    public _soundAudioSource: any = null;
    public _nMusicType: any = -1;
    private _h5GameOpen: boolean = false;
    static shared() : SoundManager {
        return null == this._instance && (this._instance = new SoundManager), this._instance;
    }
    initAudioSource(s, i, o) {
        this._hallAudioSource = s;
        this._roomAudioSource = i;
        this._soundAudioSource = o;
        SoundManager._audioSource = s;
        SoundManager._instance.init();
        this._nMusicType = 0;
    }
    init() {
        this._initLoad || (this.preLoadSounds(), this.resetSwitch());
    }
    resetMusic() {
        SoundManager._audioSource = null;
    }
    resetSwitch() {
        let e = sys.localStorage.getItem("bg_enabled");
        null != e && null != e ? this.bg_enabled = "true" == e : (ToolUtils.saveData("bg_enabled", "true"), this.bg_enabled = true);
        this.bg_enabled && this.setMusicVolume(1);
        let s = sys.localStorage.getItem("fx_enabled");
        null != s && null != s ? this.fx_enabled = "true" == s : (ToolUtils.saveData("fx_enabled", "true"), this.fx_enabled = true);
    }
    addSound(e, s) {
        this.sounds[e] = s;
    }
    playFx(e, s, i) {
        s || (s = 1);
        this.fx_enabled && null != e && null != this.sounds[e] && ToolUtils.isObjValid(this.sounds[e]) && (i ? (this._callBack = i, this._soundAudioSource.clip = this.sounds[e], assert(this._soundAudioSource, "SoundManager not inited!"), this._soundAudioSource.loop = false, this._soundAudioSource.play(), this._soundAudioSource.node.on(AudioSource.EventType.ENDED, this.onAudioEnded, this)) : this._soundAudioSource.playOneShot(this.sounds[e], s));
    }
    stopSound() {
        this._soundAudioSource.stop();
    }
    playSound(e, s, i, o) {
        s || (s = 1);
        this.fx_enabled && null != e && null != this.sounds[e] && ToolUtils.isObjValid(this.sounds[e]) && (o ? TweenTool.delayAct(this._soundAudioSource.node, (() => {
            this.soundCallBack(e, s, i);
        }), o, true) : this.soundCallBack(e, s, i));
    }
    soundCallBack(e, s, i) {
        i ? (this._callBack = i, this._soundAudioSource.clip = this.sounds[e], assert(this._soundAudioSource, "SoundManager not inited!"), this._soundAudioSource.loop = false, this._soundAudioSource.play(), this._soundAudioSource.node.on(AudioSource.EventType.ENDED, this.onAudioEnded, this)) : this._soundAudioSource.playOneShot(this.sounds[e], s);
    }
    onAudioEnded() {
        this._callBack && this._callBack();
        this._soundAudioSource.node.off(AudioSource.EventType.ENDED, this.onAudioEnded, this);
    }
    playMusic(s) {
        try {
            const i = SoundManager._audioSource;
            sys.isObjectValid(i) && (i.loop = s, this.bg_enabled && !this._h5GameOpen ? i.playing || i.play() : i.pause());
        }
        catch (e) {
            TLog.printError("SoundManager playMusic err:", e);
        }
    }
    playTargetMusic(s) {
        sys.isObjectValid(SoundManager._audioSource) && SoundManager._audioSource.stop();
        SoundManager._audioSource = s;
        SoundManager._instance.init();
        this._nMusicType = 1;
        this.playMusic(true);
    }
    switchBgMusic(s) {
        s != this._nMusicType && (sys.isObjectValid(SoundManager._audioSource) && SoundManager._audioSource.stop(), 0 == s ? SoundManager._audioSource = this._hallAudioSource : 1 == s && (SoundManager._audioSource = this._roomAudioSource), this.resetSwitch(), SoundManager._instance.init(), this._nMusicType = s);
        this.playMusic(true);
    }
    pauseMusic() {
        sys.isObjectValid(SoundManager._audioSource) && SoundManager._audioSource.stop();
    }
    suspendForH5Game() {
        this._h5GameOpen = true;
        sys.isObjectValid(SoundManager._audioSource) && SoundManager._audioSource.pause();
    }
    resumeFromH5Game() {
        if (!this._h5GameOpen) return;
        this._h5GameOpen = false;
        this.playMusic(true);
    }
    stopMusic() {
        ToolUtils.saveData("bg_enabled", "false");
    }
    stopAllSound() {
        ToolUtils.saveData("fx_enabled", "false");
    }
    setMusicVolume(s) {
        const i = SoundManager._audioSource;
        try {
            sys.isObjectValid(i) && (s = clamp01(s), i.volume = s);
        }
        catch (e) {
            TLog.printError("setMusicVolume fail:", e);
        }
    }
    setFxEnabled(e) {
        e && ToolUtils.saveData("fx_enabled", "true");
        this.fx_enabled = e;
    }
    getFxEnabled() {
        return this.fx_enabled;
    }
    setEnabled(e, s = false) {
        this.bg_enabled = e;
        s || (this.bg_enabled ? ToolUtils.saveData("bg_enabled", "true") : ToolUtils.saveData("bg_enabled", "false"));
        this.playMusic(true);
    }
    getEnable() {
        return this.bg_enabled;
    }
    preLoadSounds() {
        this._initLoad = true;
        resources.loadDir("sound", AudioClip, (function (s, i) {
            for (let s = 0; s < i.length; s++) {
                SoundManager.shared().addSound(i[s].name, i[s]);
                s == i.length - 1 && SoundManager.shared().setEnabled(SoundManager.shared().bg_enabled);
            }
        }));
    }
    preLoadBundleSounds(s, i) {
        ToolUtils.loadRemoteBundle(s, ToolUtils.getRemoteSoundUrl(), (s => {
            s && s.loadDir(i, AudioClip, (function (s, i) {
                if (sys.isObjectValid(i)) {
                    for (let s = 0; s < i.length; s++) {
                        SoundManager.shared().addSound(i[s].name, i[s]);
                        s == i.length - 1 && SoundManager.shared().setEnabled(SoundManager.shared().bg_enabled);
                    }
                }
            }));
        }));
    }
    releaseBundleSounds(e, s) {
        try {
            let i = assetManager.getBundle(e);
            i && i.release(s);
        }
        catch (e) {
        }
    }
}
