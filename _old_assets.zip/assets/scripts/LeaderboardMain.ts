// @ts-nocheck
// Recovered from index.js:231
import { _decorator, Button, color, instantiate, Label, LabelShadow, Layout, Node, ScrollView, size, Sprite, SpriteFrame, sys, UITransform, v3, Widget } from "cc";
import { TransferPlatform } from "./TransferPlatform";
import { TLog } from "./TLog";
import Utils from "./Utils";
import PushCenter from "./PushCenter";
import PushEvent from "./PushEvent";
import User from "./User";
import HttpManager from "./HttpManager";
import SoundManager from "./SoundManager";
import Parent from "./Parent";
import { ToolUtils } from "./ToolUtils";
import { HttpRequest } from "./HttpRequestName";
import { CheckModule } from "./CommDefine";
import TweenTool from "./TweenTool";
const { ccclass, property } = _decorator;
@ccclass("LeaderboardMain")
export class LeaderboardMain extends Parent {
    public TAG: string = "LeaderboardMain";
    @property(Node)
    public boarderRootNode: Node = null;
    @property(ScrollView)
    public topRankScrollView: ScrollView = null;
    @property(Node)
    public optRootNode: Node = null;
    @property(Node)
    public miniSchRootNode: Node = null;
    @property(Node)
    public rankRootNode: Node = null;
    @property(Node)
    public faqRootNode: Node = null;
    @property(Node)
    public starRootNode: Node = null;
    @property(Node)
    public rankMoban: Node = null;
    @property(Node)
    public topRankMoban: Node = null;
    @property([SpriteFrame])
    public daojuImages: SpriteFrame[] = [];
    @property([SpriteFrame])
    public rankIcoImages: SpriteFrame[] = [];
    @property(Node)
    public faqMoban: Node = null;
    @property(Node)
    public toolRootNode: Node = null;
    @property([SpriteFrame])
    public clubKuangFrame: SpriteFrame[] = [];
    @property([SpriteFrame])
    public faq_itemBgImgs: SpriteFrame[] = [];
    @property([SpriteFrame])
    public iconSpriteFrames: SpriteFrame[] = [];
    @property(Node)
    public rootNode: Node = null;
    @property(Node)
    public safeAreaNode: Node = null;
    public taskAwardIconMap: Map = new Map;
    public _rankItems: any[] = [];
    public _faqItems: any[] = [];
    public isSendHttp: boolean = false;
    public _hasInitFaq: boolean = false;
    public curTab: number = 0;
    public cycle_sn: number = 0;
    public miniRankData: any = null;
    public megaRankData: any = null;
    public _lastClick: number = 0;
    public _canClickTab: boolean = true;
    onLoad() {
        this.fitScreen();
        PushCenter.shared().addListener(PushEvent.commentDownloaderImg, (e => {
            if (ToolUtils.isObjValid(this.node) && this.taskAwardIconMap.size > 0) {
                for (const [t, i] of this.taskAwardIconMap) {
                    i == e && sys.isObjectValid(t) && "banner" == t.name && Utils.shared().updateNetImage(t, e, size(720, 1215));
                }
            }
        }), this);
        PushCenter.shared().addListener(PushEvent.RefreshHallLeaderBoardMain, (e => {
            ToolUtils.isObjValid(this.node) && (this.refreshView(), this.requestRankData());
        }), this);
        PushCenter.shared().addListener(PushEvent.RefreshHallLeaderBoardEntry, (e => {
            ToolUtils.isObjValid(this.node) && (User.shared().hallLeaderBoardMainData.entry_status = Number(e), this.updateEntryStatus(Number(e)), this.refreshOptView());
        }), this);
    }
    fitScreen() {
        let e = ToolUtils.getSafeDistance();
        ToolUtils.isPadPlatform() ? this.safeAreaNode.active = false : this.safeAreaNode.active = e > 0;
    }
    start() {
        this.isSendHttp = true;
        sys.isObjectValid(User.shared().hallLeaderBoardMainData) ? (this.refreshView(), this.requestRankData()) : User.shared().requestLeaderBoarderMainFramePage();
    }
    refreshView() {
        sys.isObjectValid(User.shared().hallLeaderBoardMainData.cycle_sn) && (this.cycle_sn = User.shared().hallLeaderBoardMainData.cycle_sn);
        this.refreshBoarderView();
        this.refreshMiniBoardSch();
        this.refreshStarView();
        this.refreshFaqView();
        this.refreshOptView();
    }
    refreshOptView() {
        let e = User.shared().hallLeaderBoardMainData;
        this.optRootNode.active = true;
        this.optRootNode.getChildByName("tip1").active = 1 == e.entry_status;
        this.optRootNode.getChildByName("tip2").active = 1 == e.entry_status;
        this.optRootNode.getChildByName("btn").active = 1 == e.entry_status;
    }
    refreshFaqView() {
        if (this._hasInitFaq) {
            return;
        }
        let e = User.shared().hallLeaderBoardMainData;
        if (sys.isObjectValid(e.faq) && Array.isArray(e.faq)) {
            for (let t = 0; t < e.faq.length; t++) {
                let i = instantiate(this.faqMoban);
                i.active = true;
                this.initFaqItemView(i, e.faq[t], t);
                i.parent = this.faqRootNode;
                this._faqItems.push(i);
            }
        }
    }
    initFaqItemView(e, t, i) {
        sys.isObjectValid(t.title) && t.title.length > 0 && (e.getChildByName("title").getComponent(Label).string = t.title);
        sys.isObjectValid(t.content) && t.content.length > 0 && (e.getChildByName("content").getComponent(Label).string = t.content, e.getChildByName("content").getComponent(Label).updateRenderData(true));
        e.getChildByName("arrow").getComponent(Button).clickEvents[0].customEventData = String(i);
    }
    onFaqItemClick(e, t) {
        if (SoundManager.shared().playFx("click"), sys.now() - this._lastClick < 500) {
            return;
        }
        this._lastClick = sys.now();
        let i = Number(t);
        this.changeFaqItemArrow(i);
    }
    changeFaqItemArrow(e) {
        if (e < this._faqItems.length) {
            for (let t = 0; t < this._faqItems.length; t++) {
                let i = this._faqItems[t];
                if (ToolUtils.isObjValid(i)) {
                    if (t == e) {
                        if (i.getChildByName("content").active) {
                            i.getChildByName("content").active = false;
                            i.getChildByName("arrow").getChildByName("ico").scale = v3(1, 1);
                            i.getChildByName("bg").getComponent(Sprite).spriteFrame = this.faq_itemBgImgs[0];
                            i.getChildByName("bg").getComponent(UITransform).contentSize = size(670, 110);
                            i.getComponent(UITransform).contentSize = size(670, 110);
                        }
                        else {
                            i.getChildByName("content").active = true;
                            i.getChildByName("arrow").getChildByName("ico").scale = v3(-1, 1);
                            i.getChildByName("content").getChildByName("ico").getComponent(Widget).updateAlignment();
                            let e = i.getChildByName("content").getChildByName("ico").getComponent(UITransform).contentSize.height;
                            i.getChildByName("bg").getComponent(Sprite).spriteFrame = this.faq_itemBgImgs[1];
                            i.getChildByName("bg").getComponent(UITransform).contentSize = size(670, e);
                            i.getComponent(UITransform).contentSize = size(670, e);
                        }
                    }
                    else {
                        i.getChildByName("content").active = false;
                        i.getChildByName("arrow").getChildByName("ico").scale = v3(1, 1);
                        i.getChildByName("bg").getComponent(Sprite).spriteFrame = this.faq_itemBgImgs[0];
                        i.getChildByName("bg").getComponent(UITransform).contentSize = size(670, 110);
                        i.getComponent(UITransform).contentSize = size(670, 110);
                    }
                }
            }
            this.faqRootNode.getComponent(Layout).updateLayout();
        }
    }
    refreshStarView() {
        let e = User.shared().hallLeaderBoardMainData;
        if (sys.isObjectValid(e.last_cycle_top_three)) {
            if (sys.isObjectValid(e.last_cycle_top_three.title) && (this.starRootNode.getChildByName("top_tip").getComponent(Label).string = "TOP 3 at #" + e.last_cycle_top_three.title), sys.isObjectValid(e.last_cycle_top_three.list) && Array.isArray(e.last_cycle_top_three.list) && 3 == e.last_cycle_top_three.list.length) {
                for (let t = 0; t < e.last_cycle_top_three.list.length; t++) {
                    let i = e.last_cycle_top_three.list[t], a = this.starRootNode.getChildByName("head_mask" + t).getChildByName("head_img");
                    Utils.shared().updateHeadImg(a, i.avatar, i.avatar_url, size(135, 135));
                    let n = this.starRootNode.getChildByName("club_kuang" + t);
                    if (sys.isObjectValid(i.club)) {
                        n.active = true;
                        let e = User.shared().getGradeByMemberShipLevel(Number(i.club));
                        0 == e ? n.active = false : e > 0 && e <= 9 ? (n.active = true, n.getComponent(Sprite).spriteFrame = this.clubKuangFrame[e]) : n.active = false;
                    }
                    else {
                        n.active = false;
                    }
                    sys.isObjectValid(i.name) && (this.starRootNode.getChildByName("player" + t).getComponent(Label).string = ToolUtils.GetShortName2(ToolUtils.isSafeString(i.name), 10, false));
                }
            }
            if (sys.isObjectValid(e.last_ten_top_one) && Array.isArray(e.last_ten_top_one)) {
                this.starRootNode.getChildByName("rank_list").getComponent(ScrollView).content.removeAllChildren();
                for (let t = 0; t < e.last_ten_top_one.length; t++) {
                    let i = e.last_ten_top_one[t], a = instantiate(this.topRankMoban);
                    a.active = true;
                    sys.isObjectValid(i.name) && (a.getChildByName("player").getComponent(Label).string = ToolUtils.GetShortName2(ToolUtils.isSafeString(i.name), 10, false));
                    let n = a.getChildByName("head_mask").getChildByName("head_img");
                    Utils.shared().updateHeadImg(n, i.avatar, i.avatar_url, size(100, 100));
                    let r = a.getChildByName("club_kuang");
                    if (sys.isObjectValid(i.club)) {
                        r.active = true;
                        let e = User.shared().getGradeByMemberShipLevel(Number(i.club));
                        0 == e ? r.active = false : e > 0 && e <= 9 ? (r.active = true, r.getComponent(Sprite).spriteFrame = this.clubKuangFrame[e]) : r.active = false;
                    }
                    else {
                        r.active = false;
                    }
                    sys.isObjectValid(i.points) && (a.getChildByName("point").getComponent(Label).string = String(i.points) + " pts");
                    sys.isObjectValid(i.reward) && (a.getChildByName("prize").getComponent(Label).string = "₹" + String(i.reward));
                    this.starRootNode.getChildByName("rank_list").getComponent(ScrollView).content.addChild(a);
                }
                e.last_ten_top_one.length < 4 ? this.starRootNode.getChildByName("rank_list").getComponent(ScrollView).enabled = false : this.starRootNode.getChildByName("rank_list").getComponent(ScrollView).enabled = true;
            }
            else {
                this.starRootNode.getChildByName("rank_list").getComponent(ScrollView).content.removeAllChildren();
                this.starRootNode.getChildByName("rank_list").getComponent(ScrollView).enabled = false;
            }
        }
    }
    refreshBoarderView() {
        let e = User.shared().hallLeaderBoardMainData;
        sys.isObjectValid(e.main_pic) && e.main_pic.length > 0 && (this.taskAwardIconMap.set(this.boarderRootNode.getChildByName("banner"), e.main_pic), Utils.shared().updateNetImage(this.boarderRootNode.getChildByName("banner"), e.main_pic, size(720, 1215)));
        sys.isObjectValid(e.entry_status) && this.updateEntryStatus(e.entry_status);
    }
    refreshMiniBoardSch() {
        let e = User.shared().hallLeaderBoardMainData;
        for (let e = 0; e < 4; e++) {
            this.miniSchRootNode.getChildByName("sch" + e).active = false;
            this.miniSchRootNode.getChildByName("time" + e).active = false;
            this.miniSchRootNode.getChildByName("fire_node" + e).active = false;
        }
        if (sys.isObjectValid(e.mini_schedule) && Array.isArray(e.mini_schedule) && e.mini_schedule.length <= 4) {
            for (let t = 0; t < e.mini_schedule.length; t++) {
                if (sys.isObjectValid(e.mini_schedule[t].show_range_time) && (this.miniSchRootNode.getChildByName("sch" + t).active = true, this.miniSchRootNode.getChildByName("sch" + t).getComponent(Label).string = String(e.mini_schedule[t].show_range_time)), sys.isObjectValid(e.mini_schedule[t].time) && (this.miniSchRootNode.getChildByName("time" + t).active = true, this.miniSchRootNode.getChildByName("time" + t).getComponent(Label).string = String(e.mini_schedule[t].time)), sys.isObjectValid(e.mini_schedule[t].hot) && e.mini_schedule[t].hot > 0) {
                    this.miniSchRootNode.getChildByName("fire_node" + t).active = true;
                    this.miniSchRootNode.getChildByName("fire_node" + t).removeAllChildren();
                    for (let i = 0; i < e.mini_schedule[t].hot; i++) {
                        let e = instantiate(this.miniSchRootNode.getChildByName("fire"));
                        e.active = true;
                        this.miniSchRootNode.getChildByName("fire_node" + t).addChild(e);
                        e.setPosition(v3(27 * i, 0));
                    }
                }
            }
        }
    }
    updateEntryStatus(e) {
        User.shared().hallLeaderBoardMainData.entry_status = e;
        this.boarderRootNode.getChildByName("opt_in").active = 0 == e;
        this.boarderRootNode.getChildByName("play_now").active = 1 == e;
        this.boarderRootNode.getChildByName("coming_soon").active = 2 == e;
    }
    onDestroy() {
        PushCenter.shared().removeListenersByTag(this);
        this.unscheduleAllCallbacks();
    }
    onEnable() {
        this._canClickTab = true;
        TransferPlatform.shared().setNormalFrameRate();
        this.isSendHttp && this.requestRankData();
        sys.isObjectValid(User.shared().hallLeaderBoardMainData) && (this.refreshBoarderView(), this.refreshOptView(), this.toolRootNode.active = false);
    }
    changeRankType() {
        let e = null, t = null;
        0 == this.curTab ? (this.rankRootNode.getChildByName("btn_mini").getChildByName("di").active = false, this.rankRootNode.getChildByName("btn_mini").getChildByName("wz").getComponent(Label).color = color(183, 0, 0), this.rankRootNode.getChildByName("btn_mini").getChildByName("wz").getComponent(LabelShadow).color = color(255, 243, 226), this.rankRootNode.getChildByName("btn_mini").getChildByName("line").active = true, this.rankRootNode.getChildByName("btn_mega").getChildByName("di").active = true, this.rankRootNode.getChildByName("btn_mega").getChildByName("wz").getComponent(Label).color = color(84, 89, 155), this.rankRootNode.getChildByName("btn_mega").getChildByName("wz").getComponent(LabelShadow).color = color(196, 209, 243), this.rankRootNode.getChildByName("btn_mega").getChildByName("line").active = false, e = this.rankRootNode.getChildByName("btn_mega"), t = this.rankRootNode.getChildByName("btn_mini")) : (this.rankRootNode.getChildByName("btn_mega").getChildByName("di").active = false, this.rankRootNode.getChildByName("btn_mega").getChildByName("wz").getComponent(Label).color = color(183, 0, 0), this.rankRootNode.getChildByName("btn_mega").getChildByName("wz").getComponent(LabelShadow).color = color(255, 243, 226), this.rankRootNode.getChildByName("btn_mega").getChildByName("line").active = true, this.rankRootNode.getChildByName("btn_mini").getChildByName("di").active = true, this.rankRootNode.getChildByName("btn_mini").getChildByName("wz").getComponent(Label).color = color(84, 89, 155), this.rankRootNode.getChildByName("btn_mini").getChildByName("wz").getComponent(LabelShadow).color = color(196, 209, 243), this.rankRootNode.getChildByName("btn_mini").getChildByName("line").active = false, e = this.rankRootNode.getChildByName("btn_mini"), t = this.rankRootNode.getChildByName("btn_mega"));
        let i = e.getChildByName("line");
        i.active && (TweenTool.stopNodeAction(i), TweenTool.scaleTo(i, 0.1, v3(0.2, 1, 1), null, true, (() => {
            i.scale = v3(1, 1, 1);
            i.active = false;
        })));
        let a = t.getChildByName("line");
        a.active = true;
        TweenTool.stopNodeAction(a);
        a.scale = v3(0, 1, 1);
        let n = TweenTool.scaleTo(a, 0.16, v3(1.1, 1, 1), null, false), o = TweenTool.scaleTo(a, 0.16, v3(1, 1, 1), null, false);
        TweenTool.sequence(a, true, null, n, o);
    }
    refreshRankContentView() {
        let e = null;
        if (e = 0 == this.curTab ? this.miniRankData : this.megaRankData, sys.isObjectValid(e)) {
            if (sys.isObjectValid(e.rank_list) && Array.isArray(e.rank_list) && e.rank_list.length > 0) {
                for (let t = 0; t < e.rank_list.length && !(t >= 10); t++) {
                    if (ToolUtils.isObjValid(this._rankItems[t])) {
                        this._rankItems[t].active = true;
                    }
                    else {
                        let e = instantiate(this.rankMoban);
                        e.active = true;
                        this.rankRootNode.getChildByName("list_node").addChild(e);
                        this._rankItems[t] = e;
                    }
                    this.updateRankItem(this._rankItems[t], t, e.rank_list[t], false);
                }
                if (e.rank_list.length < this._rankItems.length) {
                    for (let t = e.rank_list.length; t < this._rankItems.length; t++) {
                        ToolUtils.isObjValid(this._rankItems[t]) && (this._rankItems[t].active = false);
                    }
                }
            }
            else {
                for (let e = 0; e < this._rankItems.length; e++) {
                    ToolUtils.isObjValid(this._rankItems[e]) && (this._rankItems[e].active = false);
                }
            }
            sys.isObjectValid(e.my_rank_info) && this.updateRankItem(this.rankRootNode.getChildByName("my_item"), -1, e.my_rank_info, true);
        }
    }
    updateRankItem(e, t, i, a) {
        if (sys.isObjectValid(i.rank)) {
            let t = Number(i.rank);
            0 == t ? (e.getChildByName("rank_sp").active = false, e.getChildByName("num").active = true, e.getChildByName("num").getComponent(Label).string = "-") : t <= 3 ? (e.getChildByName("rank_sp").active = true, e.getChildByName("rank_sp").getComponent(Sprite).spriteFrame = this.rankIcoImages[t - 1], e.getChildByName("num").active = false) : (e.getChildByName("rank_sp").active = false, e.getChildByName("num").active = true, e.getChildByName("num").getComponent(Label).string = String(t));
        }
        -1 != t && (e.getChildByName("bg").getComponent(Sprite).color = t % 2 == 0 ? color(255, 252, 251) : color(240, 240, 240));
        sys.isObjectValid(i.name) && (e.getChildByName("name").getComponent(Label).string = ToolUtils.GetShortName2(ToolUtils.isSafeString(i.name), 13, false));
        sys.isObjectValid(i.points) && (e.getChildByName("points").getComponent(Label).string = "" + i.points);
        let n = false;
        sys.isObjectValid(i.bmoney) && i.bmoney > 0 ? (e.getChildByName("prize_node").getChildByName("cash").active = true, e.getChildByName("prize_node").getChildByName("cash").getChildByName("num").getComponent(Label).string = String(i.bmoney), n = true) : e.getChildByName("prize_node").getChildByName("cash").active = false;
        sys.isObjectValid(i.bonus) && i.bonus > 0 ? (e.getChildByName("prize_node").getChildByName("bonus").active = true, e.getChildByName("prize_node").getChildByName("bonus").getChildByName("num").getComponent(Label).string = String(i.bonus), n = true) : e.getChildByName("prize_node").getChildByName("bonus").active = false;
        let o = e.getChildByName("prize_node").getChildByName("box");
        sys.isObjectValid(i.box) && Array.isArray(i.box) && i.box.length > 0 ? (o.active = true, o.getChildByName("btn").getComponent(Button).clickEvents[0].customEventData = "" + t, o.getChildByName("btn").getComponent(Button).interactable = true, 9 == i.box[0].type && i.box[0].sub_type <= this.daojuImages.length && (o.getChildByName("icon").getComponent(Sprite).spriteFrame = this.daojuImages[i.box[0].sub_type - 1]), n = true) : (o.active = false, o.getChildByName("btn").getComponent(Button).interactable = false);
        e.getChildByName("prize_node").getChildByName("wz").active = !n;
    }
    requestRankData() {
        let e = "daily";
        1 == this.curTab && (e = "cycle");
        let t = { type: e, cycle_sn: this.cycle_sn, page: 1, origin: 1 };
        HttpManager.shared().doGetCommonRequest(t, HttpRequest.HallRankBoardList, ((e, t, i) => {
            if (200 != i) {
                this._canClickTab = true;
            }
            else {
                this._canClickTab = true;
                try {
                    let e = ToolUtils.parseJson(t);
                    0 == e.ret && (0 == this.curTab ? this.miniRankData = e.data : this.megaRankData = e.data, this.refreshRankContentView());
                }
                catch (e) {
                    TLog.printError("requestRankData err:", e.toString());
                }
            }
        }));
    }
    onButtonClick(e, t) {
        SoundManager.shared().playFx("click");
        try {
            if (sys.now() - this._lastClick < 500) {
                return;
            }
            if (this._lastClick = sys.now(), "mini_tab" == t) {
                if (!this._canClickTab) {
                    return;
                }
                if (0 == this.curTab) {
                    return;
                }
                this._canClickTab = false;
                this.curTab = 0;
                this.changeRankType();
                sys.isObjectValid(this.miniRankData) ? (this._canClickTab = true, this.refreshRankContentView()) : this.requestRankData();
            }
            else if ("mega_tab" == t) {
                if (!this._canClickTab) {
                    return;
                }
                if (1 == this.curTab) {
                    return;
                }
                this.curTab = 1;
                this.changeRankType();
                sys.isObjectValid(this.megaRankData) ? (this._canClickTab = true, this.refreshRankContentView()) : this.requestRankData();
            }
            else {
                "hide_tool" == t ? this.toolRootNode.active = false : "opt_out" == t ? this.dealOptOutLogic() : "opt_in" == t ? this.dealOptInLogic() : "playnow" == t ? this.dealPlayNowLogic() : "mega_rank" == t ? Utils.shared().doJumpLogic(PushEvent.JUMP_TO_LeaderBoards, { tab: 1, lastNode: this.node }) : "mini_rank" == t ? Utils.shared().doJumpLogic(PushEvent.JUMP_TO_LeaderBoards, { tab: 0, lastNode: this.node }) : "coming_soon" == t && Utils.shared().showToast("The next event is coming soon", 2);
            }
        }
        catch (e) {
        }
    }
    dealOptInLogic() {
        User.shared().dealLeadboardLogic_OptIn((e => {
            ToolUtils.isObjValid(this.node) && (this.updateEntryStatus(e), this.refreshOptView());
        }));
    }
    dealOptOutLogic() {
        User.shared().dealLeadboardLogic_OptOut((e => {
            User.shared().hallLeaderBoardMainData.entry_status = e;
            this.updateEntryStatus(e);
            this.refreshOptView();
        }));
    }
    dealPlayNowLogic() {
        if (!User.shared().checkCanPlayCashGame(CheckModule.CASH_PLAY)) {
            return;
        }
        let e = User.shared().hallLeaderBoardMainData;
        sys.isObjectValid(e.jump_info) && Utils.shared().doJumpLogic(PushEvent.JUMP_TO_CASH_ROOM, e.jump_info);
    }
    refreshBubbleDaoju(e, t) {
        let i = t.length;
        for (let a = 0; a < i; a++) {
            if (9 == t[a].type) {
                t[a].sub_type <= this.daojuImages.length && (e.getChildByName("daoju_item").getChildByName("icon").getComponent(Sprite).spriteFrame = this.daojuImages[t[a].sub_type - 1]);
                Number(t[a].amt) > 1 ? e.getChildByName("daoju_item").getChildByName("num").getComponent(Label).string = "x" + t[a].amt + " Days" : e.getChildByName("daoju_item").getChildByName("num").getComponent(Label).string = "x" + t[a].amt + " Day";
                e.getChildByName("daoju_item").getChildByName("num").getComponent(Label).updateRenderData(true);
                t[a].sub_type - 1 == 0 ? e.getChildByName("name").getComponent(Label).string = "Motorcycle entryance" : t[a].sub_type - 1 == 1 ? e.getChildByName("name").getComponent(Label).string = "Golden bird enterance" : t[a].sub_type - 1 == 2 && (e.getChildByName("name").getComponent(Label).string = "Throne enterance");
                break;
            }
        }
    }
    listBoxClick(e, t) {
        if (SoundManager.shared().playFx("click"), sys.now() - this._lastClick < 500) {
            return;
        }
        this._lastClick = sys.now();
        let i = null;
        if (i = 0 == this.curTab ? this.miniRankData : this.megaRankData, !sys.isObjectValid(i)) {
            return;
        }
        this.rootNode.getChildByName("ScrollView").getComponent(ScrollView).stopAutoScroll();
        this.toolRootNode.active = true;
        let a = Number(t), n = null;
        n = -1 == a ? this.rankRootNode.getChildByName("my_item") : this._rankItems[a];
        let r = n.getChildByName("prize_node").getChildByName("box");
        if (i.rank_list.length > a || -1 == a) {
            this.toolRootNode.getChildByName("bubble").active = true;
            let e = null;
            e = -1 == a ? i.my_rank_info.box : i.rank_list[a].box;
            this.refreshBubbleDaoju(this.toolRootNode.getChildByName("bubble"), e);
            let t = v3();
            r.getWorldPosition(t);
            let n = v3();
            this.toolRootNode.inverseTransformPoint(n, t);
            this.toolRootNode.getChildByName("bubble").setPosition(v3(n.x + 80, n.y + 84));
        }
    }
}
