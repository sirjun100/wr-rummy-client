// @ts-nocheck
// Recovered from index.js:289
import { _decorator, assetManager, Button, color, director, game, Graphics, instantiate, isValid, Label, Layout, Mask, Node, Prefab, ProgressBar, size, sp, Sprite, SpriteAtlas, SpriteFrame, sys, tween, UIOpacity, UITransform, v3, Vec3, view, Widget } from "cc";
import Parent from "./Parent";
import AppInfo from "./AppInfo";
import i18nMgr from "./i18nMgr";
import PushCenter from "./PushCenter";
import { TLog } from "./TLog";
import { ToolUtils } from "./ToolUtils";
import { TransferPlatform } from "./TransferPlatform";
import TweenTool from "./TweenTool";
import Utils from "./Utils";
import BundleNameDefined from "./BundleNameDefined";
import CommDefine, { CheckModule, CommonGameType, CUSTOM_REWARD_ENUM, HallGameType, RemoteGameList } from "./CommDefine";
import GameConfig from "./GameConfig";
import HowToPlayDefined from "./HowToPlayDefined";
import { HttpRequest } from "./HttpRequestName";
import NetConfig from "./NetConfig";
import PhpReportDefined from "./PhpReportDefined";
import PushEvent from "./PushEvent";
import ReportConfig from "./ReportConfig";
import LoadTableCpp from "./LoadTableCpp";
import User from "./User";
import HttpManager from "./HttpManager";
import Server from "./Server";
import SoundManager from "./SoundManager";
import Carte from "./Carte";
import { LobbyAds } from "./LobbyAds";
import LobbyRummySelection from "./LobbyRummySelection";
import { ShareMainPage } from "./ShareMainPage";
import HallTopUiLogic from "./HallTopUiLogic";
import { computeCircularIconSize, computeGameEntryGeometry, GAME_ENTRY_ICON_SIZE, GAME_ENTRY_LABEL_HEIGHT, GAME_ENTRY_LABEL_WIDTH, GAME_ENTRY_PANEL_WIDTH } from "./GameEntryGeometry";
import { downloadH5Package, installedH5Index, localH5LaunchURL, supportsH5Packages } from "./H5GamePackages";
const { ccclass, property } = _decorator;
@ccclass("MainLobby")
export default class MainLobby extends Parent {
    @property(Prefab)
    public BannersPrefab: Prefab = null;
    @property(Prefab)
    public choose_gamePrefab: Prefab = null;
    @property(Node)
    public hall_bg: Node = null;
    @property(Node)
    public lobby_root: Node = null;
    @property(Node)
    public top_info: Node = null;
    @property(Node)
    public gameEntryBtn: Node = null;
    @property(Node)
    public gameEntryPageNode: Node = null;
    @property(Node)
    public bottom_info_right: Node = null;
    @property(Node)
    public cricket_bottom_right: Node = null;
    @property(Label)
    public nick_name: Label = null;
    @property(Label)
    public uid: Label = null;
    @property(Node)
    public activity_root: Node = null;
    @property(Node)
    public wallet_root: Node = null;
    @property(Node)
    public invite_root: Node = null;
    @property(Node)
    public menu_root: Node = null;
    @property(Node)
    public bottom_root: Node = null;
    @property(Node)
    public node_guide: Node = null;
    @property(Node)
    public guide_skip_btn: Node = null;
    @property(Node)
    public guide_practice_btn: Node = null;
    @property(Node)
    public infoNode: Node = null;
    @property(Node)
    public cashInfo: Node = null;
    @property([Node])
    public tabNodeArray: Node[] = [];
    @property([SpriteFrame])
    public isreadiconSp: SpriteFrame[] = [];
    @property([SpriteFrame])
    public table_bg: SpriteFrame[] = [];
    @property([SpriteFrame])
    public desk_bg: SpriteFrame[] = [];
    @property(Node)
    public emailRedNode: Node = null;
    @property(Node)
    public emailBonusTip: Node = null;
    @property(Node)
    public dailytaskRedNode: Node = null;
    @property(Node)
    public dailytaskRewardNode: Node = null;
    @property(Node)
    public novicesRedNode: Node = null;
    @property([Node])
    public guideTips: Node[] = [];
    @property(Node)
    public join_game: Node = null;
    @property([SpriteFrame])
    public tabAct_imgs: SpriteFrame[] = [];
    public hall_tabact_img: Map = new Map;
    @property(Node)
    public tips_node: Node = null;
    @property(Node)
    public pageRoot: Node = null;
    @property([Node])
    public pageNodes: Node[] = [];
    @property([SpriteFrame])
    public fourDesk_bgs: SpriteFrame[] = [];
    @property([SpriteFrame])
    public littleGameBgs: SpriteFrame[] = [];
    @property([SpriteFrame])
    public littleGameDesks: SpriteFrame[] = [];
    @property([SpriteFrame])
    public clubIconFrame: SpriteFrame[] = [];
    @property(SpriteAtlas)
    public clubKuangAtlas: SpriteAtlas = null;
    public choosegame: any = null;
    public my_join_state: number = 0;
    @property([SpriteFrame])
    public chipsIcos: SpriteFrame[] = [];
    @property([SpriteFrame])
    public chipsMasks: SpriteFrame[] = [];
    @property([SpriteFrame])
    public chip_imgs_617: SpriteFrame[] = [];
    public curSelectTab: number = 0;
    public lastNodeName: string = "";
    public _isLoginHall: boolean = false;
    public _isGameHall: boolean = false;
    public _lastSelectTab: number = 0;
    public myJoinAct: any = null;
    public _tableInfoMsg: any = null;
    public activityPrefab: any = null;
    public _page_time: number = 0.27;
    public _lastPageRootX: number = 0;
    public _guideStep: number = 0;
    public _lastClick: number = 0;
    public _bRefreshChooseGame: boolean = false;
    public _bDelayShowLocation: boolean = false;
    public hallTopUiLogic: any = null;
    public _initDelay: number = 0;
    public _reRetHallPopList: boolean = false;
    public _joinGameDiffX: number = 0;
    public _isFromLogin: boolean = false;
    public _treasuredraw_rewarding: boolean = false;
    public _serverCanPreLink: boolean = true;
    public gameBtnArr: any[] = [];
    public menu_select_color: any = color(153, 44, 35);
    public menu_unselect_color: any = color(133, 133, 133);
    public tab_wz_color: any = color(134, 16, 16);
    public has_popAct: any[] = [];
    public h5Games: any[] = [];
    public h5GameNodes: Node[] = [];
    public h5CatalogLoaded: boolean = false;
    public h5Downloading: Set<string> = new Set();
    public h5DownloadProgress: Map<string, number> = new Map();
    public _has_execute_popAct: boolean = false;
    public _gateHeartSchedule: any = null;
    public _tmpGateHeartSwitch: boolean = false;
    public _gateHeartBeatStep: number = 0;
    onDestroy() {
        super.onDestroy();
        User.shared().hallGamesTabInfo = null;
        User.shared().choosegame = null;
        PushCenter.shared().removeListenersByTag(this);
        this._gateHeartSchedule && (TweenTool.stopAction(this._gateHeartSchedule), this._gateHeartSchedule = null);
        TweenTool.stopNodeAction(this.node);
        this.unscheduleAllCallbacks();
        null != this.hallTopUiLogic && (delete this.hallTopUiLogic, this.hallTopUiLogic = null);
        User.shared().has_req_lobbyPop = false;
        User.shared().forcePopAct = false;
    }
    onEnable() {
        sys.isObjectValid(this.infoNode) && (this.infoNode.on(Node.EventType.TOUCH_START, this.onTouchEvent, this), this.infoNode.on(Node.EventType.TOUCH_MOVE, this.onTouchEvent, this), this.infoNode.on(Node.EventType.TOUCH_END, this.onTouchEvent, this), this.infoNode.on(Node.EventType.TOUCH_CANCEL, this.onTouchEvent, this));
    }
    onDisable() {
        sys.isObjectValid(this.infoNode) && (this.infoNode.off(Node.EventType.TOUCH_START, this.onTouchEvent, this), this.infoNode.off(Node.EventType.TOUCH_MOVE, this.onTouchEvent, this), this.infoNode.off(Node.EventType.TOUCH_END, this.onTouchEvent, this), this.infoNode.off(Node.EventType.TOUCH_CANCEL, this.onTouchEvent, this));
    }
    resetTabActImgs() {
        this.hall_tabact_img.set(54, { name: "WELCOME BONUS", img: this.tabAct_imgs[0] });
        this.hall_tabact_img.set(68, { name: "GULLAK", img: this.tabAct_imgs[1] });
        this.hall_tabact_img.set(74, { name: "ADVENTURE BONUS", img: this.tabAct_imgs[2] });
        this.hall_tabact_img.set(104, { name: "GOOD VALUE OFFER", img: this.tabAct_imgs[3] });
        this.hall_tabact_img.set(119, { name: "24H INSANE LOOT", img: this.tabAct_imgs[4] });
        this.hall_tabact_img.set(125, { name: "BUY 1 GET 3", img: this.tabAct_imgs[5] });
        this.hall_tabact_img.set(130, { name: "ENDLESS BENEFITS", img: this.tabAct_imgs[6] });
        this.hall_tabact_img.set(140, { name: "SURPRISE COUPON", img: this.tabAct_imgs[7] });
    }
    onLoad() {
        ToolUtils.bSendGateHeatBeat = false;
        ToolUtils.report_time_param.hallOnLoad = sys.now();
        this.gameBtnArr[HallGameType.LOBBY_GAME_TYPE_SIXDICE] = this.gameEntryPageNode.getChildByName("list").getChildByName("layout").getChildByName("sixdice_btn");
        this.gameBtnArr[HallGameType.LOBBY_GAME_TYPE_SHUIGUOJI] = this.gameEntryPageNode.getChildByName("list").getChildByName("layout").getChildByName("slot_btn");
        this.gameBtnArr[HallGameType.LOBBY_GAME_TYPE_CRASH] = this.gameEntryPageNode.getChildByName("list").getChildByName("layout").getChildByName("crash_btn");
        this.gameBtnArr[HallGameType.LOBBY_GAME_TYPE_LuckBall] = this.gameEntryPageNode.getChildByName("list").getChildByName("layout").getChildByName("wingo_btn");
        this.gameBtnArr[HallGameType.LOBBY_GAME_TYPE_YES11] = this.gameEntryPageNode.getChildByName("list").getChildByName("layout").getChildByName("yes11_btn");
        User.shared().updatePayScene(0);
        this.resetTabActImgs();
        sys.os !== sys.OS.IOS && sys.os !== sys.OS.OSX && TransferPlatform.shared().setAutoAdapt(0);
        this.pageRoot.getComponent(UITransform).setContentSize(size(5 * GameConfig.REAL_SCREEN_WIDTH, GameConfig.REAL_SCREEN_HEIGHT));
        for (let e = 0; e < this.pageNodes.length; e++) {
            const t = this.pageNodes[e];
            ToolUtils.isObjValid(t) && t.getComponent(UITransform).setContentSize(size(GameConfig.REAL_SCREEN_WIDTH, GameConfig.REAL_SCREEN_HEIGHT));
        }
        this._isGameHall = 1 == User.shared().fromGame;
        1 === User.shared().fromGame && User.shared().send_laba_notify_update_user_info();
        null == this.hallTopUiLogic && (this.hallTopUiLogic = new HallTopUiLogic, this.hallTopUiLogic.init(this));
        User.shared().fromGame = 0;
        User.shared().resetUserDataInHall();
        this.showCashInfo(false);
        sys.isObjectValid(User.shared().data.hall_invite_earn) && (this.tabNodeArray[3].getChildByName("flag").getChildByName("wz").getComponent(Label).string = User.shared().data.hall_invite_earn);
        this.join_game.active = false;
        window.InRummyScene = false;
        window.InHallScene = true;
        Utils.shared().hideLoading();
        GameConfig.HasInGameRoom = false;
        Server.shared().onBackGroundLink();
        User.shared().requestRoomList();
        User.shared().setGameRaceid(null, null, true);
        let e = this.node.getChildByName("room_bg"), t = 4 == User.shared().styles[0] ? 1 : 0;
        5 == User.shared().styles[0] && (t = 2);
        e.getComponent(Sprite).spriteFrame = this.table_bg[t];
        e.getChildByName("desk").getComponent(Sprite).spriteFrame = this.desk_bg[User.shared().styles[0] - 1];
        this._isLoginHall = User.shared().isLoginHall;
        this._isFromLogin = User.shared().isLoginHall;
        this.curSelectTab = 2;
        this._treasuredraw_rewarding = false;
        0 == GameConfig.GAME_HALL_THEME ? this.showPageNode(2) : 2 == User.shared().cricGameStyle ? this.showPageNode(1) : (this.curSelectTab = 1, this.showPageNode(2));
        this.initView();
        null != User.shared().data.bannerlist && null != User.shared().data.bannerlist || (User.shared().data.bannerlist = []);
        this.resetDeskBgSize();
        Utils.shared().hall_rootNode = this.node.getChildByName("hall_root");
        ToolUtils.isPadPlatform();
        setTimeout((() => {
            ToolUtils.isObjValid(this.node) && window.InHallScene && this.hallTopUiLogic.changeRoomBg();
        }), 1500);
        this.fitLuckyTheme();
        this.loadH5GameCatalog();
    }
    loadH5GameCatalog() {
        HttpManager.shared().doGetCommonRequest({}, "Games.h5List", ((_, body, status) => {
            if (!ToolUtils.isObjValid(this.node) || status !== 200) return;
            try {
                const reply = ToolUtils.parseJson(body);
                if (!reply || reply.ret !== 0 || !reply.data || !Array.isArray(reply.data.list)) return;
                this.h5Games = reply.data.list.filter((entry) =>
                    entry && typeof entry.game_id === "string" && /^[a-z0-9_-]{1,32}$/.test(entry.game_id) &&
                    typeof entry.name === "string" && entry.name.length > 0 && entry.name.length <= 64);
                this.h5CatalogLoaded = true;
                this.renderH5GameEntries();
                this.refreshSmallGameStatus();
                this.refreshHallGameEntry();
            } catch (_) { /* 无有效目录时不展示 H5 入口 */ }
        }));
    }
    renderH5GameEntries() {
        const layout = this.gameEntryPageNode.getChildByName("list").getChildByName("layout");
        this.h5GameNodes.forEach((node) => node && node.isValid && node.destroy());
        this.h5GameNodes = [];
        const template = layout.getChildByName("slot_btn");
        if (!template) return;
        const fruitLabel = template.getChildByName("wz")?.getComponent(Label);
        if (fruitLabel) fruitLabel.string = "Fruits";
        // The fruit tile is a permanent prefab node; remove only its H5
        // decoration when the catalog is refreshed, never the tile itself.
        for (const name of ["round_icon", "h5_download_badge"]) {
            const child = template.getChildByName(name);
            if (child) { child.removeFromParent(); child.destroy(); }
        }
        template.getComponent(Sprite).enabled = true;
        // Clone from the undecorated tile even when fruit appears first in the
        // catalog, or later H5 tiles would inherit fruit's overlay twice.
        const cloneTemplate = instantiate(template);
        for (const entry of this.h5Games) {
            const isFruit = entry.game_id === "fruit";
            const node = isFruit ? template : instantiate(cloneTemplate);
            if (!isFruit) node.name = "h5_" + entry.game_id + "_btn";
            const label = node.getChildByName("wz")?.getComponent(Label);
            if (label) {
                label.string = entry.name.trim().replace(/\s+/, "\n");
            }
            const button = node.getComponent(Button);
            const sprite = node.getComponent(Sprite);
            const fruitIcon = isFruit ? sprite?.spriteFrame : null;
            node.getComponent(UITransform).setContentSize(size(GAME_ENTRY_ICON_SIZE, GAME_ENTRY_ICON_SIZE));
            if (sprite) {
                if (!isFruit) sprite.spriteFrame = null; // 不把水果机 777 图标误用到其他游戏。
                sprite.enabled = false;
            }
            if (button && !isFruit) {
                button.clickEvents = button.clickEvents.slice(0, 1);
                if (button.clickEvents[0]) button.clickEvents[0].customEventData = "h5:" + entry.game_id;
                // Keep the button's touch area while the image lives inside
                // its own circular stencil, independent of image dimensions.
                button.transition = Button.Transition.NONE;
                button.normalSprite = null;
            }
            const roundIcon = new Node("round_icon");
            roundIcon.addComponent(UITransform).setContentSize(size(GAME_ENTRY_ICON_SIZE, GAME_ENTRY_ICON_SIZE));
            const mask = roundIcon.addComponent(Mask);
            mask.type = Mask.Type.GRAPHICS_ELLIPSE;
            mask.segments = 80;
            const backdrop = new Node("backdrop");
            backdrop.addComponent(UITransform).setContentSize(size(GAME_ENTRY_ICON_SIZE, GAME_ENTRY_ICON_SIZE));
            const fill = backdrop.addComponent(Graphics);
            fill.fillColor = color(32, 38, 62, 255);
            fill.circle(0, 0, GAME_ENTRY_ICON_SIZE / 2);
            fill.fill();
            roundIcon.addChild(backdrop);
            const picture = new Node("picture");
            const pictureSize = picture.addComponent(UITransform);
            pictureSize.setContentSize(size(GAME_ENTRY_ICON_SIZE, GAME_ENTRY_ICON_SIZE));
            const pictureSprite = picture.addComponent(Sprite);
            pictureSprite.sizeMode = Sprite.SizeMode.CUSTOM;
            if (fruitIcon) pictureSprite.spriteFrame = fruitIcon;
            roundIcon.addChild(picture);
            // Match A exactly: keep a dark mask over the icon while it is not
            // installed and show only one central radial progress indicator.
            // The icon becomes fully coloured only after installation.
            const downloadMask = new Node("h5_download_mask");
            downloadMask.addComponent(UITransform).setContentSize(size(GAME_ENTRY_ICON_SIZE, GAME_ENTRY_ICON_SIZE));
            const maskFill = downloadMask.addComponent(Graphics);
            maskFill.fillColor = color(0, 0, 0, 153);
            maskFill.circle(0, 0, GAME_ENTRY_ICON_SIZE / 2);
            maskFill.fill();
            roundIcon.addChild(downloadMask);
            node.addChild(roundIcon);
            // Match A's 56px badge on its 122px game icon.
            roundIcon.setSiblingIndex(0);
            const badgeSize = GAME_ENTRY_ICON_SIZE * 56 / 122;
            const badgeRadius = badgeSize / 2 - 1;
            const downloadBadge = new Node("h5_download_badge");
            downloadBadge.addComponent(UITransform).setContentSize(size(badgeSize, badgeSize));
            const badgeFill = downloadBadge.addComponent(Graphics);
            badgeFill.fillColor = color(0, 0, 0, 153);
            badgeFill.circle(0, 0, badgeRadius);
            badgeFill.fill();
            // The selected download treatment is a clockwise white radial
            // sweep across the whole badge. The dark badge remains visible in
            // the unfinished portion; at 100% the whole disc is white.
            const progressSector = new Node("h5_progress_sector");
            // Keep a 1px inset so the antialiased edge stays inside the base.
            const sectorDiameter = badgeSize - 2;
            progressSector.addComponent(UITransform).setContentSize(size(sectorDiameter, sectorDiameter));
            const sectorPen = progressSector.addComponent(Graphics);
            sectorPen.fillColor = color(255, 255, 255, 242);
            downloadBadge.addChild(progressSector);
            const downloadArrow = new Node("h5_download_arrow");
            downloadArrow.addComponent(UITransform).setContentSize(size(badgeSize, badgeSize));
            const arrow = downloadArrow.addComponent(Graphics);
            arrow.strokeColor = color(255, 255, 255, 255);
            arrow.lineWidth = 4;
            arrow.moveTo(0, 12);
            arrow.lineTo(0, -5);
            arrow.moveTo(-8, 2);
            arrow.lineTo(0, -6);
            arrow.lineTo(8, 2);
            arrow.moveTo(-11, -14);
            arrow.lineTo(11, -14);
            arrow.stroke();
            downloadBadge.addChild(downloadArrow);
            node.addChild(downloadBadge);
            if (!isFruit) {
                layout.addChild(node);
                this.h5GameNodes.push(node);
            }
            this.refreshH5DownloadBadge(entry, node);
            if (!isFruit && typeof entry.icon === "string" && /^https:\/\//i.test(entry.icon)) {
                assetManager.loadRemote(entry.icon, ((error, image) => {
                    if (!error && image && node.isValid && picture.isValid) {
                        const frame = SpriteFrame.createWithImage(image);
                        const fitted = computeCircularIconSize(entry.game_id, image.width, image.height);
                        pictureSize.setContentSize(size(fitted.width, fitted.height));
                        pictureSprite.spriteFrame = frame;
                        pictureSprite.sizeMode = Sprite.SizeMode.CUSTOM;
                        this.refreshH5DownloadBadge(entry, node);
                    }
                }));
            }
        }
        cloneTemplate.destroy();
    }
    refreshH5DownloadBadge(entry: any, node: Node) {
        const inheritedBadge = node.getChildByName("download");
        if (inheritedBadge) inheritedBadge.active = false;
        const badge = node.getChildByName("h5_download_badge");
        if (!badge) return;
        const hasPackage = supportsH5Packages() && typeof entry.asset_zip_url === "string" &&
            /^[a-f0-9]{64}$/.test(entry.asset_zip_sha256 || "");
        const installed = hasPackage && !!installedH5Index(entry.game_id, entry.asset_zip_sha256);
        if (installed) {
            this.h5Downloading.delete(entry.game_id);
            this.h5DownloadProgress.delete(entry.game_id);
        }
        const needsDownload = hasPackage && !installed;
        const downloading = this.h5Downloading.has(entry.game_id);
        const progress = Math.max(0, Math.min(1, this.h5DownloadProgress.get(entry.game_id) || 0));
        const downloadMask = node.getChildByName("round_icon")?.getChildByName("h5_download_mask");
        const showDownloadState = needsDownload || downloading;
        if (downloadMask) downloadMask.active = needsDownload;
        badge.active = showDownloadState;
        const arrow = badge.getChildByName("h5_download_arrow");
        if (arrow) arrow.active = showDownloadState;
        const sector = badge.getChildByName("h5_progress_sector");
        if (sector) {
            sector.active = downloading;
            const pen = sector.getComponent(Graphics);
            pen.clear();
            if (downloading && progress > 0) {
                // Draw the wedge ourselves instead of borrowing the prefab's
                // progress texture: some native builds do not expose that
                // texture at runtime, leaving the progress visually black.
                // Points descend from 12 o'clock, which produces a clockwise
                // sweep on Cocos' y-up coordinate system.
                const radius = sector.getComponent(UITransform).width / 2;
                const segments = Math.max(2, Math.ceil(progress * 64));
                pen.moveTo(0, 0);
                for (let step = 0; step <= segments; step++) {
                    const angle = Math.PI / 2 - Math.PI * 2 * progress * step / segments;
                    pen.lineTo(Math.cos(angle) * radius, Math.sin(angle) * radius);
                }
                pen.close();
                pen.fill();
            }
        }
    }
    openH5Game(gameId: string) {
        if (!/^[a-z0-9_-]{1,32}$/.test(gameId)) return;
        const game = this.h5Games.find((entry) => entry.game_id === gameId);
        if (!game) return;
        // A verified local installation wins over any stale in-memory download
        // flag, even if the Android completion callback was never delivered.
        for (const activeId of Array.from(this.h5Downloading)) {
            const active = this.h5Games.find((entry) => entry.game_id === activeId);
            if (!active || !installedH5Index(activeId, active.asset_zip_sha256)) continue;
            this.h5Downloading.delete(activeId);
            this.h5DownloadProgress.delete(activeId);
            const activeNode = activeId === "fruit"
                ? this.gameEntryPageNode.getChildByName("list")?.getChildByName("layout")?.getChildByName("slot_btn")
                : this.h5GameNodes.find((item) => item && item.isValid && item.name === "h5_" + activeId + "_btn");
            if (activeNode) this.refreshH5DownloadBadge(active, activeNode);
        }
        if (supportsH5Packages() && typeof game.asset_zip_url === "string" && /^[a-f0-9]{64}$/.test(game.asset_zip_sha256 || "")) {
            if (!installedH5Index(gameId, game.asset_zip_sha256)) {
                if (this.h5Downloading.has(gameId)) {
                    Utils.shared().showToast("Downloading game resources, please wait...", 2);
                    return;
                }
                this.h5Downloading.add(gameId);
                this.h5DownloadProgress.set(gameId, 0);
                const refreshEntry = () => {
                    const current = gameId === "fruit"
                        ? this.gameEntryPageNode.getChildByName("list")?.getChildByName("layout")?.getChildByName("slot_btn")
                        : this.h5GameNodes.find((item) => item && item.isValid && item.name === "h5_" + gameId + "_btn");
                    if (current) this.refreshH5DownloadBadge(game, current);
                };
                refreshEntry();
                downloadH5Package(gameId, game.asset_zip_url, game.asset_zip_sha256, (progress) => {
                    // Display only progress reported by the native downloader.
                    // This keeps the sweep proportional to bytes downloaded and
                    // the verification/install stages instead of racing to 90%.
                    const current = this.h5DownloadProgress.get(gameId) || 0;
                    this.h5DownloadProgress.set(gameId, Math.max(current, progress));
                    if (ToolUtils.isObjValid(this.node)) refreshEntry();
                }).then(() => {
                    // Installation is already verified before this promise
                    // resolves. Clear the transient state synchronously so a
                    // disabled/paused component cannot leave a stale badge.
                    this.h5Downloading.delete(gameId);
                    this.h5DownloadProgress.delete(gameId);
                    if (ToolUtils.isObjValid(this.node)) refreshEntry();
                }).catch(() => {
                    this.h5Downloading.delete(gameId);
                    this.h5DownloadProgress.delete(gameId);
                    if (!ToolUtils.isObjValid(this.node)) return;
                    refreshEntry();
                    Utils.shared().showToast("Download failed. Please try again.", 2);
                });
                return;
            }
        }
        this.launchH5Game(gameId);
    }
    launchH5Game(gameId: string) {
        HttpManager.shared().doGetCommonRequest({ game_id: gameId }, "Games.launch", ((_, body, status) => {
            if (!ToolUtils.isObjValid(this.node)) return;
            let data = null;
            if (status === 200) {
                try {
                    const reply = ToolUtils.parseJson(body);
                    if (reply && reply.ret === 0) data = reply.data;
                } catch (_) { /* 请求失败时不打开未登录的展示页 */ }
            }
            if (!data || data.game_id !== gameId || typeof data.launch_url !== "string" ||
                !/^https:\/\/[^/]+/i.test(data.launch_url)) {
                Utils.shared().showToast("Game temporarily unavailable", 2);
                return;
            }
            let launchURL = data.launch_url;
            let localIndex = "";
            const game = this.h5Games.find((entry) => entry.game_id === gameId);
            if (supportsH5Packages() && game && game.asset_zip_sha256) {
                localIndex = installedH5Index(gameId, game.asset_zip_sha256);
                if (!localIndex) { Utils.shared().showToast("Game download required", 2); return; }
                try { launchURL = localH5LaunchURL(data.launch_url, localIndex); }
                catch (_) { Utils.shared().showToast("Game package unavailable", 2); return; }
            }
            // Match A's H5 transition: keep the native animated loader above the
            // lobby while the WebView remains offscreen, then let the game show
            // its own branded loading page as soon as it is ready.
            Utils.shared().showLoading(12, true);
            Utils.shared().openUrl({
                url: launchURL,
                title: gameId === "fruit" ? "Fruits" : typeof data.name === "string" ? data.name : gameId,
                h5GameId: gameId,
                h5PackageIndex: localIndex,
                h5RemoteURL: data.launch_url,
                // Every game currently produced by the shared slots build is a
                // landscape Cocos game. Keep this client-side guard until every
                // deployed h5_game_config row has been migrated from the old
                // portrait default; otherwise the H5 canvas rotates inside a
                // portrait Activity and appears sideways.
                orientation: ["fruit", "blackcat", "luckyspin", "mine", "chicken_road", "elephant", "pigslots", "aviator"].includes(gameId)
                    ? "landscape"
                    : data.orientation === "landscape" ? "landscape" : "portrait",
                // Keep the entry panel over the lobby until the H5 cover has
                // actually been mounted. Hiding it here exposes one lobby frame
                // while the WebView prefab is loaded for the first time.
                h5LaunchCover: this.gameEntryPageNode,
            });
        }));
    }
    fitLuckyTheme() {
        0 != GameConfig.NATIVE_GAME_APP_TYPE && (this.menu_select_color = color(30, 66, 152), this.menu_unselect_color = color(147, 154, 167), this.tab_wz_color = color(30, 66, 152), this.top_info.getChildByName("money").getComponent(Label).color = color(251, 220, 0, 255), this.lobby_root.getChildByName("top_bg").getComponent(Sprite).color = color(12, 26, 60, 255), this.hall_bg.getChildByName("hall").getChildByName("top_bg").getComponent(Sprite).color = color(12, 26, 60, 255), this.bottom_root.getChildByName("select").getComponent(Sprite).color = color(30, 66, 152, 255), 0 == GameConfig.GAME_HALL_THEME && (this.bottom_root.getChildByName("btn_lobby").getChildByName("img").getComponent(Sprite).color = color(30, 66, 152, 255), this.bottom_root.getChildByName("btn_lobby").getChildByName("Label").getComponent(Label).color = color(30, 66, 152, 255), this.bottom_root.getChildByName("btn_menu").getChildByName("img2").getComponent(Sprite).color = color(30, 66, 152, 255)), this.pageNodes[2].getChildByName("bg").getComponent(Sprite).color = color(12, 26, 60, 255));
    }
    fitChipMode() {
        if (0 == GameConfig.CHIPS_MODLE) {
            return;
        }
        let e = 2000617 == GameConfig.CHANNEL_ID;
        e && e && 0 == GameConfig.GAME_HALL_THEME && (this.menu_select_color = color(237, 217, 150), this.menu_unselect_color = color(96, 163, 140), this.tab_wz_color = color(237, 217, 150), this.hall_bg.getChildByName("hall").getChildByName("top_bg").getComponent(Sprite).color = color(9, 69, 68, 255), this.lobby_root.getChildByName("top_bg").getComponent(Sprite).color = color(9, 69, 68, 255), this.pageNodes[2].getChildByName("bg").getComponent(Sprite).color = color(14, 48, 51, 255), this.lobby_root.getChildByName("top").getChildByName("btn_mail").getChildByName("img").getComponent(Sprite).spriteFrame = this.chip_imgs_617[0], 0 == GameConfig.GAME_HALL_THEME && (this.bottom_root.getChildByName("select").getComponent(Sprite).color = color(237, 217, 150), this.bottom_root.getChildByName("bg").getComponent(Sprite).spriteFrame = this.chip_imgs_617[1], this.bottom_root.getChildByName("btn_lobby").getChildByName("img").getComponent(Sprite).color = this.menu_select_color, this.bottom_root.getChildByName("btn_lobby").getChildByName("Label").getComponent(Label).color = this.menu_select_color, this.bottom_root.getChildByName("btn_menu").getChildByName("img2").getComponent(Sprite).color = this.menu_select_color, this.bottom_root.getChildByName("btn_leaderboard").getChildByName("img").getComponent(Sprite).color = this.menu_unselect_color, this.bottom_root.getChildByName("btn_leaderboard").getChildByName("Label").getComponent(Label).color = this.menu_unselect_color, this.bottom_root.getChildByName("btn_invite").getChildByName("img").getComponent(Sprite).color = this.menu_unselect_color, this.bottom_root.getChildByName("btn_invite").getChildByName("Label").getComponent(Label).color = this.menu_unselect_color, this.bottom_root.getChildByName("btn_inbox").getChildByName("img").getComponent(Sprite).color = this.menu_unselect_color, this.bottom_root.getChildByName("btn_inbox").getChildByName("Label").getComponent(Label).color = this.menu_unselect_color, this.bottom_root.getChildByName("btn_menu").getChildByName("img").getComponent(Sprite).color = this.menu_unselect_color, this.bottom_root.getChildByName("btn_menu").getChildByName("Label").getComponent(Label).color = this.menu_unselect_color));
    }
    onTouchEvent(e) {
        if (e.preventSwallow = true, e.getType() == Node.EventType.TOUCH_END) {
            if (sys.now() - this._lastClick < 500) {
                return;
            }
            this._lastClick = sys.now();
            this.showCashInfo(false);
            this.showMemberShipInfo(false);
        }
    }
    showPageNode(e) {
        for (let t = 0, i = this.pageNodes.length; t < i; t++) {
            const i = this.pageNodes[t];
            i.active = t === e;
            i.setPosition(v3(0, 0));
        }
    }
    resetDeskBgSize() {
        let e = GameConfig.REAL_SCREEN_HEIGHT;
        e < 1560 && (e = 1560);
        let t = this.node.getChildByName("room_bg");
        t.getComponent(UITransform).setContentSize(size(e, GameConfig.REAL_SCREEN_WIDTH));
        t.getChildByName("desk").getComponent(UITransform).setContentSize(size(e, GameConfig.REAL_SCREEN_WIDTH));
        let i = this.node_guide.getChildByName("play_guide");
        if (sys.isObjectValid(i) && sys.isObjectValid(i.getChildByName("mask"))) {
            let e = view.getVisibleSize();
            i.getChildByName("mask").getComponent(UITransform).setContentSize(size(e.width, e.height + e.height / 2));
            let t = i.getChildByName("content").getChildByName("widget_node");
            t.getComponent(Widget).updateAlignment();
            let a = t.getComponent(UITransform).height - 2 * sys.getSafeAreaRect().y;
            t.getChildByName("btn_practice").setPosition(v3(0, -(591 + 591 * (a - 836) / 836 / 2)));
            t.getChildByName("anim_hand").setPosition(v3(0, 57 - (591 + 591 * (a - 836) / 836 / 2)));
        }
    }
    popActivity() {
        1 != GameConfig.CHIPS_MODLE && this.scheduleOnce((() => {
            if (ToolUtils.isSafeString(User.shared().data.notify_msg).length > 0) {
                Utils.shared().showCommomDialog(ToolUtils.isSafeString(User.shared().data.notify_msg), i18nMgr.shared().getValueByKey("utlis.notice"), (e => {
                    User.shared().data.notify_msg = "";
                    PushCenter.shared().pushEvent(PushEvent.Update_NextPopActivity);
                }), false, ToolUtils.getIsNormalDirection());
            }
            else if (User.shared()._checkExitRoomVid && User.shared().checkLobbyPopList(), User.shared().poplist.length > 0) {
                if (window.InSwitchScene) {
                    return void TLog.printError("-------- switchScene stop preload res.");
                }
                let e = User.shared().poplist[0];
                if (-1 != this.has_popAct.indexOf(Number(e.type))) {
                    return User.shared().poplist.splice(0, 1), void PushCenter.shared().pushEvent(PushEvent.Update_NextPopActivity);
                }
                this.has_popAct.push(Number(e.type));
                let t = e.exe, i = { isNext: true };
                if (this._isLoginHall && (sys.isObjectValid(t) ? t.pop_souce = 1 : t = { pop_souce: 1 }), Number(e.type) == PushEvent.JUMP_TO_FREECASH) {
                    let e = this._isLoginHall ? 4 : 5;
                    sys.isObjectValid(t) ? t.from_source = e : t = { from_source: e };
                }
                Number(e.type) == PushEvent.JUMP_TO_NewPass && (i.reportEvtId = 5, i.link_id = sys.now(), i.reportScene = 1);
                Number(e.type) == PushEvent.JUMP_TO_Treasure && (sys.isObjectValid(t) ? t.from_source = e.exe.from_source : t = { from_source: e.exe.from_source });
                Number(e.type) != PushEvent.JUMP_TO_INVITE_GETREWARDPOP && Number(e.type) != PushEvent.JUMP_TO_INVITE_REWAARDTASK || (sys.isObjectValid(t) ? t.inShare = 0 : t = { inShare: 0 });
                Utils.shared().doJumpLogic(ToolUtils.isSafeNumber(Number(e.type)), t, i);
                User.shared().poplist.splice(0, 1);
                User.shared().preloadPopListBundle(true);
                TweenTool.delayAct(this.node, (() => {
                    User.shared().poplist.length > 0 && sys.isObjectValid(User.shared().poplist[0]) && User.shared().checkTargetRequestActData(ToolUtils.isSafeNumber(Number(User.shared().poplist[0].type)));
                }), 2, true);
                this._isGameHall ? User.shared().updatePayScene(PhpReportDefined.pay_scene.game_to_hall) : User.shared().updatePayScene(PhpReportDefined.pay_scene.login_to_hall);
            }
            else {
                User.shared().popActState = 2;
            }
        }), game.frameTime / 1000);
    }
    showHallGuide() {
    }
    initPushEvent() {
        PushCenter.shared().addListener(PushEvent.Show_Challenge, (e => {
            ToolUtils.isObjValid(this.node) && window.InHallScene && Utils.shared().showLeaderBoardMainView(this.node);
        }), this);
        PushCenter.shared().addListener(PushEvent.Update_CloseMenu, (e => {
            ToolUtils.isObjValid(this.node) && window.InHallScene && (this.tabNodeArray[4].getChildByName("img").active = true, this.tabNodeArray[4].getChildByName("img2").active = false, 1 == GameConfig.GAME_HALL_THEME && (this.tabNodeArray[4].getComponent(Sprite).color = color(255, 255, 255), this.tabNodeArray[4].getChildByName("img").getComponent(Sprite).color = color(133, 133, 133), this.tabNodeArray[4].getChildByName("img2").getComponent(Sprite).color = color(133, 133, 133)));
            this.scheduleOnce(this.delayRequestRoomList, 2);
        }), this);
        PushCenter.shared().addListener(PushEvent.Close_Invite, (e => {
            ToolUtils.isObjValid(this.node) && window.InHallScene && 1 == GameConfig.GAME_HALL_THEME && (this.tabNodeArray[3].getComponent(Sprite).color = color(255, 255, 255), this.tabNodeArray[3].getChildByName("img").getComponent(Sprite).color = color(133, 133, 133));
            this.scheduleOnce(this.delayRequestRoomList, 2);
        }), this);
        PushCenter.shared().addListener(GameConfig.Delay_Ask_RoomList, (e => {
            this.scheduleOnce(this.delayRequestRoomList, 2);
        }), this);
        PushCenter.shared().addListener(PushEvent.ResetHallGameBg, (e => {
            ToolUtils.isObjValid(this.node) && window.InHallScene && sys.isObjectValid(this.hallTopUiLogic) && this.hallTopUiLogic.changeRoomBg(Number(e));
        }), this);
        PushCenter.shared().addListener(PushEvent.RefreshActCollStatus, (e => {
            ToolUtils.isObjValid(this.node) && this.updateSmallGameStatus(User.shared().show_sgame, e);
        }), this);
        PushCenter.shared().addListener(GameConfig.Update_Money, (e => {
            this._treasuredraw_rewarding || ToolUtils.isObjValid(this.node) && window.InHallScene && (this.updateGold(e), this.choosegame && this.choosegame.getComponent(LobbyRummySelection).updateStartBtnState());
        }), this);
        PushCenter.shared().addListener(PushEvent.UpdateTreasureDrawRewarding, (e => {
            this._treasuredraw_rewarding = 1 == e;
            this._treasuredraw_rewarding || ToolUtils.isObjValid(this.node) && window.InHallScene && this.setUserInfo();
        }), this);
        PushCenter.shared().addListener(GameConfig.Update_Name, (e => {
            ToolUtils.isObjValid(this.node) && window.InHallScene && this.setUserInfo();
        }), this);
        PushCenter.shared().addListener(GameConfig.Change_Head, (e => {
            ToolUtils.isObjValid(this.node) && window.InHallScene && this.setUserInfo();
        }), this);
        PushCenter.shared().addListener(GameConfig.Update_withdraw, (e => {
            ToolUtils.isObjValid(this.node) && window.InHallScene && this.setUserInfo();
        }), this);
        PushCenter.shared().addListener(GameConfig.Update_Deposit, (e => {
            ToolUtils.isObjValid(this.node) && window.InHallScene && this.setUserInfo();
        }), this);
        PushCenter.shared().addListener(GameConfig.Enter_Private_Room, (e => {
            this.enterRummy(e.vid, e.roomType, e.tid, e.privateRoomData, e.is_back);
        }), this);
        PushCenter.shared().addListener(GameConfig.Jump_Hall_Tab_View, (e => {
            this.onSwitchTabClick(null, e, true);
        }), this);
        PushCenter.shared().addListener(PushEvent.CricketForceSign_PlayRummy, (e => {
            ToolUtils.isObjValid(this.node) && this.onSwitchTabClick(null, "2", true);
        }), this);
        PushCenter.shared().addListener(GameConfig.Jump_Hall_Choose_game, (e => {
            this.onSwitchTabClick(null, "2", true);
            e && e.length > 0 && "match" == e[0] && this.onSwitchGameClick(e, true);
        }), this);
        PushCenter.shared().addListener(PushEvent.UpdateGameTableInfoNum, (e => {
            try {
                User.shared().hallGamesTabInfo = null;
                ToolUtils.isObjValid(this.node) && window.InHallScene && this.update_hall_tableinfo(e);
            }
            catch (e) {
                TLog.printError("UpdateGameTableInfoNum:", e);
            }
        }), this);
        PushCenter.shared().addListener(GameConfig.Update_Email, (e => {
            ToolUtils.isObjValid(this.node) && window.InHallScene && this.updateEmailReddot();
        }), this);
        PushCenter.shared().addListener(PushEvent.ShowNovicesTask, (e => {
            ToolUtils.isObjValid(this.node) && window.InHallScene && this.showNoviceTask();
        }), this);
        PushCenter.shared().addListener(PushEvent.updateBannerList, (e => {
            ToolUtils.isObjValid(this.node) && window.InHallScene && this.addBannerNode();
        }), this);
        PushCenter.shared().addListener(PushEvent.Update_NextPopActivity, (e => {
            TweenTool.delayAct(this.node, (() => {
                ToolUtils.isObjValid(this.node) && window.InHallScene && this.popActivity();
            }), game.frameTime / 1000, true);
        }), this);
        PushCenter.shared().addListener(PushEvent.updateLobbyBubble, (e => {
            TweenTool.delayAct(this.node, (() => {
                ToolUtils.isObjValid(this.node) && window.InHallScene && this.showHallGuide();
            }), game.frameTime / 1000, true);
        }), this);
        PushCenter.shared().addListener(GameConfig.onEnterBackground, (e => {
            HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Hall, event: ReportConfig.hall_evt.enterBackGround });
            ToolUtils.isObjValid(this.node) && window.InHallScene && (this._tmpGateHeartSwitch = ToolUtils.bSendGateHeatBeat, ToolUtils.bSendGateHeatBeat = false);
        }), this);
        PushCenter.shared().addListener(GameConfig.onEnterForeground, (e => {
            ToolUtils.isObjValid(this.node) && window.InHallScene && (User.shared().getHallInfo(), ToolUtils.bSendGateHeatBeat = this._tmpGateHeartSwitch);
        }), this);
        PushCenter.shared().addListener(PushEvent.onAppResume, (e => {
            User.shared().getFirebaseJumpType();
        }), this);
        PushCenter.shared().addListener(GameConfig.Jump_Hall_Setting, (e => {
            ToolUtils.isObjValid(this.node) && window.InHallScene && this.hallTopUiLogic.showSetting();
        }), this);
        PushCenter.shared().addListener(PushEvent.UpdateTaskRed, (e => {
            ToolUtils.isObjValid(this.node) && window.InHallScene && this.updateRed();
        }), this);
        PushCenter.shared().addListener(PushEvent.HallGet, (e => {
            ToolUtils.isObjValid(this.node) && window.InHallScene && User.shared().getHallInfo();
        }), this);
        PushCenter.shared().addListener(PushEvent.NoticeUpdateHallTab, (e => {
            ToolUtils.isObjValid(this.node) && window.InHallScene && (!this._tableInfoMsg || !Array.isArray(this._tableInfoMsg.tableInfo) || this._tableInfoMsg.tableInfo.length < 1) && User.shared().send_request_hall_tableinfo();
        }), this);
        PushCenter.shared().addListener(PushEvent.changeLanguage, (e => {
            ToolUtils.isObjValid(this.node) && window.InHallScene && this.hallTopUiLogic && this.hallTopUiLogic.dealMultipleLanguages();
        }), this);
        PushCenter.shared().addListener(GameConfig.BackKey_Clicked, (() => {
            if (User.shared().popNode && User.shared().popNode.length > 0) {
                let e = User.shared().popNode[User.shared().popNode.length - 1];
                if (ToolUtils.isObjValid(e)) {
                    let t = { nodeName: e.name };
                    PushCenter.shared().pushEvent(GameConfig.BackKey_Event, t);
                }
            }
            // At the lobby root, Android Back keeps the player in the lobby.
        }), this);
        PushCenter.shared().addListener(PushEvent.ShowHallDailyTask, (e => {
            ToolUtils.isObjValid(this.node) && window.InHallScene && this.hallTopUiLogic.showDailyTask(e);
        }), this);
        PushCenter.shared().addListener(PushEvent.ShowHallDailyGuide, (e => {
            if (ToolUtils.isObjValid(this.node) && window.InHallScene) {
                let t = !!e.isNext, i = e.exe;
                this.hallTopUiLogic.showDailyGuide(t, i);
            }
        }), this);
        PushCenter.shared().addListener(PushEvent.ShowFirstRecharge, (e => {
            ToolUtils.isObjValid(this.node) && window.InHallScene && this.hallTopUiLogic.showFirstRecharge2(e);
        }), this);
        PushCenter.shared().addListener(PushEvent.ShowCouponAct, (e => {
            ToolUtils.isObjValid(this.node) && window.InHallScene && this.hallTopUiLogic.showCouponAct(e);
        }), this);
        PushCenter.shared().addListener(PushEvent.ShowTwentyFourRecharge, (e => {
            ToolUtils.isObjValid(this.node) && window.InHallScene && this.hallTopUiLogic.showTwentyHourRecharge(e);
        }), this);
        PushCenter.shared().addListener(PushEvent.ShowRebateRecharge, (e => {
            ToolUtils.isObjValid(this.node) && window.InHallScene && this.hallTopUiLogic.showRebateRecharge(e);
        }), this);
        PushCenter.shared().addListener(PushEvent.ShowBuyOneGetThree, (e => {
            ToolUtils.isObjValid(this.node) && window.InHallScene && this.hallTopUiLogic.showBuyOneGetThree(e);
        }), this);
        PushCenter.shared().addListener(PushEvent.ShowConsecutiveGift, (e => {
            ToolUtils.isObjValid(this.node) && window.InHallScene && this.hallTopUiLogic.showConsecutiveGift(e);
        }), this);
        PushCenter.shared().addListener(PushEvent.ShowCustomSelGift, (e => {
            ToolUtils.isObjValid(this.node) && window.InHallScene && this.hallTopUiLogic.showCustomSelGift(e);
        }), this);
        PushCenter.shared().addListener(PushEvent.ShowDailyFireSale, (e => {
            ToolUtils.isObjValid(this.node) && window.InHallScene && this.hallTopUiLogic.showDailyFireSale(e);
        }), this);
        PushCenter.shared().addListener(PushEvent.ShowSessionPackage, (e => {
            if (ToolUtils.isObjValid(this.node) && window.InHallScene) {
                if (undefined === e.parent_node || null === e.parent_node) {
                    let t = director.getScene();
                    e.parent_node = t.getChildByName("Canvas");
                }
                this.hallTopUiLogic.showSessionPackage(e);
            }
        }), this);
        PushCenter.shared().addListener(PushEvent.ShowChangeBindMobile, (e => {
            if (ToolUtils.isObjValid(this.node) && window.InHallScene) {
                let t = e && null != e.lastNode ? e.lastNode : null, i = e && null != e.nType ? e.nType : 0, a = e && null != e.callback ? e.callback : null, s = !(!e || null == e.bShowPushAnim) && e.bShowPushAnim;
                this.hallTopUiLogic.showChangeBindMobile(t, i, a, s);
            }
        }), this);
        PushCenter.shared().addListener(PushEvent.ShowSafetyVerify, (e => {
            if (ToolUtils.isObjValid(this.node) && window.InHallScene) {
                let t = e && null != e.lastNode ? e.lastNode : null, i = e && null != e.jump_info ? e.jump_info : null;
                this.hallTopUiLogic.showSafetyVerify(t, i);
            }
        }), this);
        PushCenter.shared().addListener(PushEvent.JUMP_TO_ANNOUNCEMENT, (e => {
            if (ToolUtils.isObjValid(this.node) && window.InHallScene) {
                let t = e && null != e.exe ? e.exe : null, i = e && null != e.isNext ? e.isNext : null;
                this.hallTopUiLogic.showAnnouncementView(t, i);
            }
        }), this);
        PushCenter.shared().addListener(PushEvent.ShowNovicesTaskView, (e => {
            if (ToolUtils.isObjValid(this.node) && window.InHallScene) {
                let t = !(!e || !e.isNext), i = e && null != e.exe ? e.exe : null;
                this.hallTopUiLogic.showNovicesTaskView(t, i);
            }
        }), this);
        PushCenter.shared().addListener(PushEvent.ShowCreatePassWordView, (e => {
            if (ToolUtils.isObjValid(this.node) && window.InHallScene) {
                let t = e && null != e.lastNode ? e.lastNode : null, i = e && null != e.isNext ? e.isNext : null;
                this.hallTopUiLogic.showCreatePassWordView(t, i);
            }
        }), this);
        PushCenter.shared().addListener(PushEvent.ShowReliefPackage, (e => {
            ToolUtils.isObjValid(this.node) && window.InHallScene && this.hallTopUiLogic.showReliefPackage(e);
        }), this);
        PushCenter.shared().addListener(PushEvent.GetRoomListCallBack, (e => {
            Utils.shared().hideLoading();
            ToolUtils.isObjValid(this.node) && window.InHallScene && (this._bRefreshChooseGame && (this._bRefreshChooseGame = false, this.choosegame ? this.choosegame.getComponent(LobbyRummySelection).initView() : this.setGameModeIcon()), this._serverCanPreLink && User.shared().preLinkGameGate(), this.refreshSmallGameStatus());
        }), this);
        PushCenter.shared().addListener(PushEvent.updateActCollectOpen, (e => {
            ToolUtils.isObjValid(this.node) && window.InHallScene && this.addActCollectNode();
        }), this);
        PushCenter.shared().addListener(PushEvent.updateActCollectOpenEXE, (e => {
            ToolUtils.isObjValid(this.node) && window.InHallScene && this.addActCollectNode();
        }), this);
        PushCenter.shared().addListener(PushEvent.Low_Memory_Notice, (e => {
            ToolUtils.isObjValid(this.node) && window.InHallScene && this.hallTopUiLogic.releaseRes();
        }), this);
        PushCenter.shared().addListener(PushEvent.EnterSwitchScene, (e => {
            ToolUtils.isObjValid(this.node) && (TweenTool.stopNodeAction(this.node), TweenTool.stopNodeAction(ToolUtils.getGlobalNode()));
        }), this);
        PushCenter.shared().addListener(PushEvent.ShowLotteryAct, (e => {
            ToolUtils.isObjValid(this.node) && window.InHallScene && this.hallTopUiLogic.showLotteryAct(e);
        }), this);
        PushCenter.shared().addListener(PushEvent.rummyPlayback, (e => {
            if (ToolUtils.isObjValid(this.node) && window.InHallScene) {
                User.shared().isInPerformanceRoom = 1;
                User.shared().game_id = e.game_id;
                let t = {};
                t.vid = ToolUtils.play_back_vid;
                t.game_id = User.shared().game_id;
                sys.isObjectValid(e.round) && 0 != e.round && (t.round = e.round);
                Utils.shared().showCommEnterRoom(t);
            }
        }), this);
        PushCenter.shared().addListener(PushEvent.showPerformanceView, (e => {
            ToolUtils.isObjValid(this.node) && window.InHallScene && this.hallTopUiLogic.showPerformanceView();
        }), this);
        PushCenter.shared().addListener(PushEvent.showRecodeDetailsView, (e => {
            ToolUtils.isObjValid(this.node) && window.InHallScene && this.hallTopUiLogic.showRecodeDetailsView(e);
        }), this);
        PushCenter.shared().addListener(PushEvent.ChangeHallRoomBg, (e => {
            ToolUtils.isObjValid(this.node) && window.InHallScene && this.hallTopUiLogic && this.hallTopUiLogic.changeRoomBg();
        }), this);
        PushCenter.shared().addListener(PushEvent.PreChangeMatchRoomBg, (e => {
            ToolUtils.isObjValid(this.node) && window.InHallScene && this.hallTopUiLogic && this.hallTopUiLogic.preChangeMatchRoomBg();
        }), this);
        PushCenter.shared().addListener(PushEvent.ShowNextCommonRewardTip, (e => {
            ToolUtils.isObjValid(this.node) && window.InHallScene && setTimeout((() => {
                User.shared().showNextCommonRewardTips();
            }), game.frameTime);
        }), this);
        PushCenter.shared().addListener(PushEvent.ContinueHallPopList, (e => {
            ToolUtils.isObjValid(this.node) && this._reRetHallPopList && User.shared().getHallPopList(true);
        }), this);
        PushCenter.shared().addListener(PushEvent.RefreshSuperVipInfo, (e => {
            ToolUtils.isObjValid(this.node) && window.InHallScene && this.updateMemberShipInfo();
        }), this);
        PushCenter.shared().addListener(PushEvent.UpdateCashbackEnt, (e => {
            ToolUtils.isObjValid(this.node) && window.InHallScene && this.showActCashback();
        }), this);
        PushCenter.shared().addListener(PushEvent.ChooseHallLeaderBoardsGame, (e => {
            this.onSwitchTabClick(null, "2", true);
            ToolUtils.isObjValid(this.choosegame) ? this.choosegame.getComponent(LobbyRummySelection).chooseRoomByOutSide(e) : this.setGameModeIcon();
        }), this);
        PushCenter.shared().addListener(GameConfig.Hall_MemberShip_info, (e => {
            ToolUtils.isObjValid(this.node) && window.InHallScene && this.updateMemberShipInfo();
        }), this);
        PushCenter.shared().addListener(PushEvent.InMatchChooseGameCloseAct, (e => {
            ToolUtils.isObjValid(this.node) && (sys.isObjectValid(this._tableInfoMsg) && 0 === this._tableInfoMsg.ret && sys.isObjectValid(this._tableInfoMsg.tableInfo) && this._tableInfoMsg.tableInfo.length > 0 && (this.join_game.active = true), this.addActCollectNode());
        }), this);
        PushCenter.shared().addListener(PushEvent.ShowInviteRedBag, (e => {
            ToolUtils.isObjValid(this.node) && window.InHallScene && this.checkInviteRedAnim();
        }), this);
        PushCenter.shared().addListener(PushEvent.ChangeTableRedDot, (e => {
            ToolUtils.isObjValid(this.node) && window.InHallScene && this.refreshHeadTableRedDot();
        }), this);
        PushCenter.shared().addListener(PushEvent.ShowGameRatingAlert, (e => {
            ToolUtils.isObjValid(this.node) && window.InHallScene && User.shared().checkCanShowGameRating() && User.shared().requestGameRatingPage({ m_order_id: User.shared().ratingTradeNo });
        }), this);
        PushCenter.shared().addListener(GameConfig.EmailBlind_State, (e => {
            ToolUtils.isObjValid(this.node) && this.refreshHeadTableRedDot();
        }), this);
        PushCenter.shared().addListener(PushEvent.UpdateHallSmallGame, (e => {
            ToolUtils.isObjValid(this.node) && this.updateSmallGameStatus(User.shared().show_sgame);
        }), this);
        PushCenter.shared().addListener(PushEvent.UpdateHallSmallGameSort, (e => {
            ToolUtils.isObjValid(this.node) && this.refreshSmallGameStatus();
        }), this);
        PushCenter.shared().addListener(PushEvent.UpdateGameDownloadProgress, (e => {
            if (ToolUtils.isObjValid(this.node) && window.InHallScene && sys.isObjectValid(e) && sys.isObjectValid(e.game_type) && sys.isObjectValid(e.progress)) {
                let t = Number(e.game_type);
                if (ToolUtils.isObjValid(this.gameBtnArr[t])) {
                    const i = t => {
                        let i = t.getChildByName("download").getChildByName("ico"), a = t.getChildByName("download").getChildByName("ProgressBar");
                        if (1 == e.progress) {
                            return i.active = false, a.active = false, void (t.getComponent(Sprite).color = color(255, 255, 255));
                        }
                        i.active = false;
                        a.active = true;
                        let s = e.progress;
                        a.getComponent(ProgressBar).progress = s;
                    };
                    i(this.gameBtnArr[t]);
                    t == HallGameType.LOBBY_GAME_TYPE_LuckBall && this.cricket_bottom_right && i(this.cricket_bottom_right.getChildByName("wingo_btn"));
                }
            }
        }), this);
        PushCenter.shared().addListener(PushEvent.OnGameDownloadError, (e => {
            if (ToolUtils.isObjValid(this.node) && window.InHallScene && sys.isObjectValid(e) && sys.isObjectValid(e.game_type)) {
                let t = Number(e.game_type);
                if (ToolUtils.isObjValid(this.gameBtnArr[t])) {
                    const e = e => {
                        let t = e.getChildByName("download").getChildByName("ico"), i = e.getChildByName("download").getChildByName("ProgressBar");
                        t.active = true;
                        i.active = false;
                        e.getComponent(Sprite).color = color(120, 120, 120);
                    };
                    e(this.gameBtnArr[t]);
                    t == HallGameType.LOBBY_GAME_TYPE_LuckBall && e(this.bottom_info_right.getChildByName("wingo_btn"));
                    Utils.shared().showToast("Download failed. Please try again.", 2);
                }
            }
        }), this);
        PushCenter.shared().addListener(PushEvent.EnterMatchRigestView, (e => {
            if (ToolUtils.isObjValid(this.node) && window.InHallScene && sys.isObjectValid(e)) {
                // A paginated cache need not contain the reminder's race.
                // Open its detail by ID; the backend validates availability.
                Utils.shared().doJumpLogic(PushEvent.JUMP_TO_MATCH_ROOM, { race_id: e });
            }
        }), this);
        PushCenter.shared().addListener(PushEvent.ExitLuckyBallGame, (e => {
            this.join_game.active = false;
        }), this);
        PushCenter.shared().addListener(PushEvent.CloseFirstRecharge, (e => {
            ToolUtils.isObjValid(this.node) && window.InHallScene && this.hallTopUiLogic.hideFirstPayView();
        }), this);
    }
    updateRed() {
    }
    updateEmailReddot() {
        undefined !== User.shared().data.un_read_email && User.shared().data.un_read_email > 0 ? (User.shared().data.un_read_email > 9 ? (User.shared().data.un_read_email > 99 ? this.emailRedNode.getChildByName("Label").getComponent(Label).string = "99+" : this.emailRedNode.getChildByName("Label").getComponent(Label).string = User.shared().data.un_read_email, this.emailRedNode.getComponent(Sprite).spriteFrame = this.isreadiconSp[1]) : (this.emailRedNode.getComponent(Sprite).spriteFrame = this.isreadiconSp[0], this.emailRedNode.getChildByName("Label").getComponent(Label).string = User.shared().data.un_read_email), this.emailRedNode.active = true) : this.emailRedNode.active = false;
    }
    showNoviceTask() {
        Utils.shared().judgeIfHasNode("newplayer_task") || Utils.shared().doJumpLogic(PushEvent.JUMP_TO_NEW_NOVICESTASK);
    }
    refreshHeadTableRedDot() {
        let e = this.top_info.getChildByName("redpot");
        sys.isObjectValid(User.shared().data.email_bind_red_dot) && 1 == User.shared().data.email_bind_red_dot || User.shared().table_red_dot;
        e.active = false;
    }
    start() {
        window.InSwitchScene = false;
        window.IsBackToHallLoad = false;
        TransferPlatform.shared().logEvent_firebase(ReportConfig.firebase_evt.jump_to_hall);
        ToolUtils.report_time_param.hallStart = sys.now();
        this.fitScreen();
        this.initPushEvent();
        ToolUtils.gamePing = 0;
        let e = this.dealNewPlayerGuideLogic(), t = this.initChooseGameBanner(e);
        if (this.refreshHeadTableRedDot(), AppInfo.shared().checkDeepLinkMatchId(), ToolUtils.switchSceneTye = -1, ToolUtils.bSwitchToGame = false, 1 == GameConfig.GAME_HALL_THEME && 2 == User.shared().cricGameStyle ? User.shared().hall_select_tab = 1 : User.shared().hall_select_tab = 2, User.shared().BackHallOpenModule > 0) {
            let e = User.shared().BackHallOpenModule;
            if (User.shared().BackHallOpenModule = -1, 1 == e) {
                this.dealTabClick(4);
            }
            else if (2 == e) {
                let e = { play: 0 };
                Utils.shared().doJumpLogic(PushEvent.JUMP_TO_CASH_ROOM, e);
            }
        }
        this._isGameHall && TweenTool.delayAct(this.node, (() => {
            User.shared().showNextCommonRewardTips();
        }), game.frameTime / 1000, true);
        let i = User.shared().hasLogin;
        User.shared().hasLogin || (this._initDelay += 0.05, TweenTool.delayAct(this.node, (() => {
            ToolUtils.isObjValid(this.node) && (localStorage.setItem(CommDefine.FirstLocation, "1"), User.shared().hasLogin = true, this._bDelayShowLocation ? TweenTool.delayAct(this.node, (() => {
                User.shared().checkLocationPermit(CheckModule.HALL);
            }), 0.3, true) : User.shared().checkLocationPermit(CheckModule.HALL), User.shared().uploadLocationInfo());
        }), this._initDelay, true), this.checkShowSuperLevelUp());
        User.shared().alertTip && User.shared().alertTip.length > 0 && (Utils.shared().showCommomDialog(User.shared().alertTip, "Tips", (e => {
        }), false, ToolUtils.getIsNormalDirection()), User.shared().alertTip = "");
        User.shared().bHasGetSwitchInfo || User.shared().doGetModuleSwitchInfo();
        this.updateSmallGameStatus(User.shared().show_sgame);
        sys.isObjectValid(User.shared().roomTable) && sys.isObjectValid(User.shared().roomTable.pointsrummy) ? (this._bRefreshChooseGame = false, TweenTool.delayAct(this.node, (() => {
            this._serverCanPreLink && User.shared().preLinkGameGate();
        }), 0.2, true), this.refreshSmallGameStatus()) : (this._bRefreshChooseGame = true, User.shared().requestRoomList(true));
        this._initDelay += 0.1;
        TweenTool.delayAct(this.node, (() => {
            ToolUtils.isObjValid(this.node) && (SoundManager.shared().switchBgMusic(0), User.shared().send_request_hall_tableinfo(), this._isLoginHall || sys.os !== sys.OS.IOS && sys.os !== sys.OS.OSX && Utils.shared().releaseGameBundleAssets());
        }), this._initDelay, true);
        i || (this._initDelay += 0.1, TweenTool.delayAct(this.node, (() => {
            User.shared().dealDeepLinkInfo();
        }), this._initDelay, true));
        this._initDelay += 0.08;
        TweenTool.delayAct(this.node, (() => {
            ToolUtils.isObjValid(this.node) && (User.shared().send_refresh_laba(), this.addBannerNode());
        }), this._initDelay + t, true);
        sys.isObjectValid(User.shared().data.act_collect_open) && sys.isObjectValid(User.shared().data.act_collect_open.list) && User.shared().data.act_collect_open.list.length > 0 ? this._initDelay += 0.2 : this._initDelay += 0.1;
        TweenTool.delayAct(this.node, (() => {
            ToolUtils.isObjValid(this.node) && window.InHallScene && (this.updateRed(), this.addActCollectNode());
        }), this._initDelay, true);
        User.shared().hallGamesTabInfo && User.shared().hallGamesTabInfo.length > 0 && (this._initDelay += 0.05, TweenTool.delayAct(this.node, (() => {
            ToolUtils.isObjValid(this.node) && (this.update_hall_tableinfo(User.shared().hallGamesTabInfo, false), User.shared().hallGamesTabInfo = null);
        }), this._initDelay, true));
        this._initDelay += 0.2;
        TweenTool.delayAct(this.node, (() => {
            ToolUtils.isObjValid(this.node) && (User.shared().send_race_reward_info_laba(), this._isLoginHall ? 0 === User.shared().data.beginner_guide.practice_status && (ToolUtils.preLoadGameBundle(BundleNameDefined.bundle_switch, BundleNameDefined.switch_scence), ToolUtils.preLoadGameBundle(BundleNameDefined.bundle_rummy, BundleNameDefined.rummy_scence, false)) : (User.shared().bNeedUpdateMoney = true, PushCenter.shared().pushEvent(GameConfig.Update_Money, User.shared().data.money), Utils.shared().preLoadBundleAsset()), User.shared().getFirebaseJumpType());
        }), this._initDelay, true);
        this._initDelay += 2;
        TweenTool.delayAct(this.node, (() => {
            ToolUtils.isObjValid(this.node) && (this._isFromLogin = false);
        }), this._initDelay, true);
        setTimeout((() => {
            sys.os !== sys.OS.IOS && sys.os !== sys.OS.OSX || ToolUtils.preLoadGameBundle(BundleNameDefined.bundle_switch, BundleNameDefined.switch_scence);
        }), 500);
        this.showActCashback();
        this.updateMemberShipInfo();
        this.hallTopUiLogic.dealMultipleLanguages();
        !i && User.shared().sw_reportLoginTime ? (User.shared().sw_reportLoginTime = false, setTimeout((() => {
            HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Login, event: ReportConfig.common.report_login_time, reportTime: ToolUtils.report_time_param });
            ToolUtils.report_time_param = {};
        }), 450)) : ToolUtils.report_time_param = {};
        i || this.requestAfterLoginToHall();
        this.nick_name.string = ToolUtils.GetShortName2(User.shared().data.name, 13, false);
        this.uid.string = "" + User.shared().data.uid;
        ToolUtils.gateHeartBeatSwitch && this.startGameHeartBeat();
    }
    startGameHeartBeat() {
        this._gateHeartSchedule && (TweenTool.stopAction(this._gateHeartSchedule), this._gateHeartSchedule = null);
        this._gateHeartBeatStep = 0;
        this._gateHeartSchedule = TweenTool.myschedule(this.node, 1, (() => {
            ToolUtils.bSendGateHeatBeat && (this._gateHeartBeatStep++, this._gateHeartBeatStep >= 30 && (this._gateHeartBeatStep = 0, User.shared().send_game_heart_beat_request()));
        }));
    }
    refreshSmallGameStatus() {
        let e = [];
        this.gameEntryPageNode.getChildByName("list").getChildByName("layout").children.forEach((e => {
            e.active = false;
        }));
        this.cricket_bottom_right && (this.cricket_bottom_right.getChildByName("wingo_btn").active = false);
        User.shared().playingMethod_entry_switch.forEach((t => {
            131 == t.act_id ? 1 != GameConfig.GAME_HALL_THEME && (e.push("yes11_btn"), this.gameEntryPageNode.getChildByName("list").getChildByName("layout").getChildByName("yes11_btn").active = true) : 144 == t.act_id ? (this.gameEntryPageNode.getChildByName("list").getChildByName("layout").getChildByName("crash_btn").active = true, e.push("crash_btn")) : 145 == t.act_id ? (this.gameEntryPageNode.getChildByName("list").getChildByName("layout").getChildByName("wingo_btn") && (this.gameEntryPageNode.getChildByName("list").getChildByName("layout").getChildByName("wingo_btn").active = true), this.cricket_bottom_right && (this.cricket_bottom_right.getChildByName("wingo_btn").active = true), e.push("wingo_btn")) : 146 == t.act_id && (this.gameEntryPageNode.getChildByName("list").getChildByName("layout").getChildByName("sixdice_btn").active = true, e.push("sixdice_btn"));
        }));
        if (this.h5CatalogLoaded && this.h5Games.some((game) => game.game_id === "fruit") && !e.includes("slot_btn")) {
            this.gameEntryPageNode.getChildByName("list").getChildByName("layout").getChildByName("slot_btn").active = true;
            e.push("slot_btn");
        }
        this.h5GameNodes.forEach((node) => { if (node && node.isValid) { node.active = true; e.push(node.name); } });
        this.gameEntryBtn.active = e.length > 0;
        e.forEach(((e, t) => {
            this.gameEntryPageNode.getChildByName("list").getChildByName("layout").getChildByName(e).setSiblingIndex(t);
        }));
        const list = this.gameEntryPageNode.getChildByName("list");
        const layout = list.getChildByName("layout");
        // The prefab grid was designed for 100px icons. Its 80px spacing in
        // lobby2 plus 128px remote images exceeds the 580px dialog. Position
        // tiles explicitly so async image loading cannot reflow the grid.
        layout.getComponent(Layout).enabled = false;
        layout.setPosition(v3(0, 0, 0));
        const { panelHeight, cells } = computeGameEntryGeometry(e.length);
        list.getComponent(UITransform).setContentSize(size(GAME_ENTRY_PANEL_WIDTH, panelHeight));
        const title = list.getChildByName("title");
        title.setPosition(v3(title.position.x, panelHeight / 2 - 65, title.position.z));
        const close = list.getChildByName("close");
        close.setPosition(v3(close.position.x, panelHeight / 2 - 36, close.position.z));
        e.forEach((name, index) => {
            const node = layout.getChildByName(name);
            node.setPosition(v3(cells[index].x, cells[index].y, 0));
            node.getComponent(UITransform).setContentSize(size(GAME_ENTRY_ICON_SIZE, GAME_ENTRY_ICON_SIZE));
            const sprite = node.getComponent(Sprite);
            if (sprite) sprite.sizeMode = Sprite.SizeMode.CUSTOM;
            const labelNode = node.getChildByName("wz");
            const label = labelNode?.getComponent(Label);
            if (label) {
                label.fontSize = 28;
                label.lineHeight = 32;
                label.overflow = Label.Overflow.SHRINK;
                labelNode.getComponent(UITransform).setContentSize(size(GAME_ENTRY_LABEL_WIDTH, GAME_ENTRY_LABEL_HEIGHT));
                labelNode.setPosition(v3(0, -105, 0));
            }
        });
    }
    showGameEntry(e = false, t = false) {
        if (!t) {
            return void (e ? (this.gameEntryPageNode.active = true, this.gameEntryPageNode.getChildByName("list").scale = v3(1, 1, 1), this.gameEntryPageNode.getChildByName("list").setPosition(v3(0, 0, 0))) : this.gameEntryPageNode.active = false);
        }
        this.gameEntryPageNode.active = true;
        let i = v3(0, 0, 0), a = v3(0, 0, 0), s = this.gameEntryPageNode.getComponent(UITransform).convertToNodeSpaceAR(this.gameEntryBtn.getWorldPosition());
        e ? (a = s, this.gameEntryPageNode.getChildByName("list").scale = v3(0, 0, 0)) : (i = s, this.gameEntryPageNode.getChildByName("list").scale = v3(1, 1, 1));
        this.gameEntryPageNode.getChildByName("list").setPosition(a);
        let o = tween({ progress: 0 }).to(0.25, { progress: 1 }, { easing: "sineOut", onUpdate: (t, s) => {
                if (!isValid(this.node)) {
                    return;
                }
                let o = e ? t.progress : 1 - t.progress;
                this.gameEntryPageNode.getChildByName("list").scale = v3(o, o, o);
                let n = a.x + (i.x - a.x) * t.progress, l = a.y + (i.y - a.y) * t.progress;
                this.gameEntryPageNode.getChildByName("list").setPosition(v3(n, l));
                let h = e ? 205 * t.progress : 205 * (1 - t.progress);
                this.gameEntryPageNode.getChildByName("huibg").getComponent(UIOpacity).opacity = h;
            } }).call((() => {
            o.removeSelf();
            this.gameEntryPageNode.getChildByName("list").setPosition(i);
            e || (this.gameEntryPageNode.active = false);
        })).start();
    }
    checkShowSuperLevelUp() {
        sys.isObjectValid(User.shared().superVipUpMsg) && this.scheduleOnce((() => {
            let e = false, t = [];
            if (t.type = CUSTOM_REWARD_ENUM.VIP_LEVEL, t.num = User.shared().superVipUpMsg.new_show_level || 0, User.shared().superVipUpMsg.list) {
                let i = User.shared().superVipUpMsg.list.length;
                for (let a = 0; a < i; a++) {
                    if (User.shared().superVipUpMsg.list[a].type == t.type) {
                        e = true;
                        break;
                    }
                }
            }
            e || User.shared().superVipUpMsg.list.unshift(t);
            Utils.shared().showRewardTips(User.shared().superVipUpMsg, null, 1, "reward_tips.okey", "", (() => {
                User.shared().superVipUpMsg = null;
                User.shared().requestSuperVipConfirmUpgradePop();
            }));
        }), 0);
    }
    initChooseGameBanner(e) {
        let t = 0.2;
        try {
            e ? (this._initDelay += 0.15, this.setGameModeIcon(), TweenTool.delayAct(this.node, (() => {
                ToolUtils.isObjValid(this.node) && this.addBannerNode(false);
            }), this._initDelay, true), TweenTool.delayAct(this.node, (() => {
                ToolUtils.isObjValid(this.node) && this.addBannerNode(false);
            }), this._initDelay + t, true)) : this._isLoginHall ? (this.setGameModeIcon(), TweenTool.delayAct(this.node, (() => {
                ToolUtils.isObjValid(this.node) && this.addBannerNode(false);
            }), this._initDelay + t, true)) : (this.setGameModeIcon(), this.addBannerNode(false), t = 0);
        }
        catch (e) {
            TLog.printError(" initChooseGameBanner err:", e);
        }
        return t;
    }
    requestAfterLoginToHall() {
        TweenTool.delayAct(this.node, (() => {
            0 == GameConfig.GAME_HALL_THEME && User.shared().requestSharePageData();
            User.shared().requestLeaderBoarderMainFramePage();
        }), 1.5, true);
        setTimeout((() => {
            User.shared().requestStoreList();
        }), 1800);
        setTimeout((() => {
            let e = "" != ToolUtils.isSafeString(TransferPlatform.shared().getAdjust_Adid());
            HttpManager.shared().doReportSdkParamAfterLogin(((t, i, a) => {
                if (200 != a) {
                    User.shared().requestGetCbTimeout();
                    AppInfo.shared().reportFireBaseToken();
                }
                else {
                    try {
                        let t = ToolUtils.parseJson(i);
                        if (0 == t.ret) {
                            if (e && (User.shared().data.is_report_adid = 1), sys.isObjectValid(t.data) && sys.isObjectValid(t.data.timeout_list) && "object" == typeof t.data.timeout_list) {
                                for (let e = 0, i = t.data.timeout_list.length; e < i; e++) {
                                    const i = t.data.timeout_list[e];
                                    User.shared().delayPayMsg.push(i);
                                }
                                User.shared().popNextRewardTips();
                            }
                        }
                        else {
                            User.shared().requestGetCbTimeout();
                            AppInfo.shared().reportFireBaseToken();
                        }
                    }
                    catch (e) {
                        TLog.printError("listenReportSdkParamAfterLogin err:", e);
                    }
                }
            }));
            User.shared().requestGetMemberShipBlind();
            sys.isObjectValid(User.shared().data.vip_info) && User.shared().requestSuperVipHomePageData();
        }), 2000);
        setTimeout((() => {
            User.shared().checkPreGetActInfo();
        }), 2800);
        1 == User.shared().act_90_open && User.shared().requestTreaHuntMainData(false, 0, 6, null, 0);
    }
    checkChipTreasureHuntReward() {
        1 == User.shared().act_97_open && HttpManager.shared().doGetCommonRequest(null, HttpRequest.GetTreaHuntRank_CHECKREWARD_CHIP, null);
    }
    showActCashback() {
    }
    checkIsShowAppReview() {
    }
    dealNewPlayerGuideLogic() {
        sys.isObjectValid(User.shared().data.cdkey_err) && User.shared().data.cdkey_err.length > 0 && (Utils.shared().showToast(User.shared().data.cdkey_err, 6), User.shared().data.cdkey_err = "");
        let e = false;
        if (User.shared().isShowGuideRewardTips || 1 === User.shared().data.beginner_guide.practice_status && 0 === User.shared().data.beginner_guide.cash_status) {
            Utils.shared().showLoading(10, true, (() => {
                this.requestNewPlayerGuideFinish();
            }));
            this.requestNewPlayerGuideFinish();
            e = true;
        }
        else if (sys.isObjectValid(User.shared().data.beginner_reward) && User.shared().data.beginner_reward.length > 0) {
            HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Hall, event: ReportConfig.hall_evt.newer_get10cash });
            let t = {};
            if (t.msg = i18nMgr.shared().getValueByKey("reward_tips.welcom_tip"), t.list = [], sys.isObjectValid(User.shared().data.cdkey_reward) && User.shared().data.cdkey_reward.length > 0) {
                let e = "", i = 0;
                for (let a = 0, s = User.shared().data.beginner_reward.length; a < s; a++) {
                    i = 0;
                    for (let t = 0, s = User.shared().data.cdkey_reward.length; t < s; t++) {
                        if (Number(User.shared().data.cdkey_reward[t].type) == Number(User.shared().data.beginner_reward[a].type)) {
                            i = Number(User.shared().data.cdkey_reward[t].amount);
                            e.length > 0 && (e += "+");
                            e += i + Utils.shared().getIconNameByType(User.shared().data.cdkey_reward[t].type);
                            User.shared().data.cdkey_reward.splice(t, 1);
                            break;
                        }
                    }
                    let s = [];
                    s.num = Number(User.shared().data.beginner_reward[a].amt) + i;
                    s.type = Number(User.shared().data.beginner_reward[a].type);
                    s.name = Utils.shared().getIconNameByType(s.type);
                    s.php_data = User.shared().data.beginner_reward[a];
                    t.list.push(s);
                    0 == User.shared().data.beginner_reward[a].type && 0 == User.shared().data.money && (User.shared().data.money = User.shared().data.beginner_reward[a].amt + i, User.shared().real_money = User.shared().data.beginner_reward[a].amt + i, PushCenter.shared().pushEvent(GameConfig.Update_Money, User.shared().data.money));
                }
                for (let a = 0; a < User.shared().data.cdkey_reward.length; a++) {
                    let s = [];
                    s.num = Number(User.shared().data.cdkey_reward[a].amount);
                    s.type = Number(User.shared().data.cdkey_reward[a].type);
                    s.name = Utils.shared().getIconNameByType(s.type);
                    s.php_data = User.shared().data.cdkey_reward[a];
                    t.list.push(s);
                    0 == User.shared().data.cdkey_reward[a].type && 0 == User.shared().data.money && (User.shared().data.money = User.shared().data.cdkey_reward[a].amount, User.shared().real_money = User.shared().data.cdkey_reward[a].amount, PushCenter.shared().pushEvent(GameConfig.Update_Money, User.shared().data.money));
                    e.length > 0 && (e += "+");
                    e += i + Utils.shared().getIconNameByType(User.shared().data.cdkey_reward[a].type);
                }
                User.shared().data.cdkey_reward = [];
                t.msg += "\n" + ToolUtils.format(i18nMgr.shared().getValueByKey("reward_tips.cdkey_tip"), e);
                t.hasCdkeyReward = true;
            }
            else {
                for (let e = 0, i = User.shared().data.beginner_reward.length; e < i; e++) {
                    let i = [];
                    i.num = Number(User.shared().data.beginner_reward[e].amt);
                    i.type = Number(User.shared().data.beginner_reward[e].type);
                    i.name = Utils.shared().getIconNameByType(i.type);
                    i.php_data = User.shared().data.beginner_reward[e];
                    t.list.push(i);
                    0 == User.shared().data.beginner_reward[e].type && 0 == User.shared().data.money && (User.shared().data.money = User.shared().data.beginner_reward[e].amt, User.shared().real_money = User.shared().data.beginner_reward[e].amt, PushCenter.shared().pushEvent(GameConfig.Update_Money, User.shared().data.money));
                }
            }
            t.button_type = 1;
            User.shared().showJumpToCashGameTips(t, 4);
            User.shared().isGuideEnterGame = 1;
            User.shared().data.cash_reward = 0;
            User.shared().data.beginner_reward = [];
            this._bDelayShowLocation = true;
            e = true;
        }
        else if (0 === User.shared().data.beginner_guide.practice_status) {
            this.node_guide.active = true;
            let t = this.node_guide.getChildByName("play_guide");
            t.active = true;
            let i = t.getChildByName("content");
            i.getChildByName("head").active = false;
            i.getChildByName("img_tips").active = false;
            i.getChildByName("widget_node").getChildByName("anim_hand").active = false;
            TweenTool.delayAct(t, (() => {
                i.getChildByName("head").active = true;
                Utils.shared().StartNodeShowAnim(i.getChildByName("head"));
            }), 0.2, true);
            TweenTool.delayAct(t, (() => {
                i.getChildByName("img_tips").active = true;
                Utils.shared().StartNodeShowAnim(i.getChildByName("img_tips"));
            }), 0.5, true);
            TweenTool.delayAct(t, (() => {
                i.getChildByName("widget_node").getChildByName("anim_hand").active = true;
            }), 0.8, true);
            User.shared().isGuideEnterGame = 0;
            e = true;
        }
        else if (this.showHallGuide(), User.shared().hallGamesTabInfo && User.shared().hallGamesTabInfo.length > 0 || (User.shared().isShowPopList && this.showPopList(), User.shared().isShowPopList = true), sys.isObjectValid(User.shared().data.cdkey_reward) && User.shared().data.cdkey_reward.length > 0) {
            let e = { list: [] };
            e.msg = i18nMgr.shared().getValueByKey("reward_tips.fans_gift");
            for (let t = 0; t < User.shared().data.cdkey_reward.length; t++) {
                let i = [];
                i.num = Number(User.shared().data.cdkey_reward[t].amount);
                i.type = Number(User.shared().data.cdkey_reward[t].type);
                i.php_data = User.shared().data.cdkey_reward[t];
                i.name = Utils.shared().getIconNameByType(i.type);
                e.list.push(i);
                0 == User.shared().data.cdkey_reward[t].type && 0 == User.shared().data.money && (User.shared().data.money = User.shared().data.cdkey_reward[t].amount, User.shared().real_money = User.shared().data.cdkey_reward[t].amount, PushCenter.shared().pushEvent(GameConfig.Update_Money, User.shared().data.money));
            }
            Utils.shared().showRewardTips(e, null, 1, "reward_tips.okey");
            User.shared().data.cdkey_reward = [];
        }
        return e;
    }
    requestNewPlayerGuideFinish() {
        HttpManager.shared().doGetNewPlayerGuideFinish(1, ((e, t, i) => {
            if (Utils.shared().hideLoading(), 200 == i) {
                try {
                    let e = ToolUtils.parseJson(t);
                    0 == e.ret && (ToolUtils.in_isGuideRoom = 0, User.shared().isShowGuideRewardTips = false, User.shared().data.beginner_guide.practice_status = 1, User.shared().data.beginner_guide.cash_status = 1, null != e.data && null != e.data && null != e.data.money && (User.shared().data.money = e.data.money, PushCenter.shared().pushEvent(GameConfig.Update_Money, User.shared().data.money)), ToolUtils.isObjValid(this.node) && (User.shared().isGuideEnterGame = 1, User.shared().data.beginner_guide.cash_reward > 0 ? (User.shared().showJumpToCashGameTips(), User.shared()._bNewPlayerGuideskip || (User.shared().isShowPopList && this.showPopList(false), User.shared().isShowPopList = true)) : (User.shared()._bNewPlayerGuideskip ? this.popActivity() : (User.shared().isShowPopList && this.showPopList(), User.shared().isShowPopList = true), Utils.shared().preLoadBundleAsset(true))));
                }
                catch (e) {
                    TLog.printError("doGetNewPlayerGuideFinish err:", e.toString());
                }
            }
        }));
    }
    showPopList(e = true) {
        this._isLoginHall ? sys.isNative ? TweenTool.delayAct(this.node, (() => {
            this.popActivity();
        }), game.frameTime / 1000, true) : this.popActivity() : this.dealShowPopAct(e);
        User.shared().isGuideEnterGame = 0;
    }
    dealShowPopAct(e) {
        this._has_execute_popAct || (this._has_execute_popAct = true, User.shared().has_req_lobbyPop ? 0 != User.shared().popActState ? this.popActivity() : User.shared().forcePopAct = true : User.shared().getHallPopList(e));
    }
    delayRequestRoomList() {
        User.shared().requestRoomList();
    }
    initView() {
        this.refreshGiftLogic();
        this.setUserInfo();
        0 == GameConfig.GAME_HALL_THEME ? (this.onSwitchTabClick(null, "2", true), this.curSelectTab = 2, this._lastSelectTab = this.curSelectTab) : 2 == User.shared().cricGameStyle ? (this._lastSelectTab = 1, this.onSwitchTabClick(null, "1", true), this.curSelectTab = 1) : (this._lastSelectTab = 2, this.onSwitchTabClick(null, "2", true), this.curSelectTab = 2);
        this.checkInviteRedAnim();
        this.refreshHallGameEntry();
        1 == GameConfig.CHIPS_MODLE && (this.top_info.getChildByName("btn_head").active = false, this.top_info.getChildByName("btn_add").active = false, this.top_info.getChildByName("add_cash").active = false, this.top_info.getChildByName("money").active = false, this.top_info.getChildByName("btn_clubInfo").getComponent(Button).interactable = false, 0 == GameConfig.GAME_HALL_THEME && (this.bottom_root.getChildByName("btn_inbox").getChildByName("img").getComponent(Sprite).spriteFrame = this.chipsIcos[0], this.bottom_root.getChildByName("btn_inbox").getChildByName("Label").getComponent(Label).string = "Event", this.bottom_root.getChildByName("btn_invite").getChildByName("img").getComponent(Sprite).spriteFrame = this.chipsIcos[1], this.bottom_root.getChildByName("btn_invite").getChildByName("Label").getComponent(Label).string = "Refer", this.bottom_root.getChildByName("btn_invite").getChildByName("flag").active = false), sys.os !== sys.OS.IOS && sys.os !== sys.OS.OSX || !ToolUtils.isPadPlatform() ? (this.hall_bg.getChildByName("hall").getChildByName("bg").getComponent(Sprite).spriteFrame = this.chipsMasks[0], this.hall_bg.getChildByName("bottom").getComponent(Sprite).spriteFrame = this.chipsMasks[1]) : (this.hall_bg.getChildByName("hall").getChildByName("bg").getComponent(Sprite).spriteFrame = this.chipsMasks[2], this.hall_bg.getChildByName("bottom").active = false));
    }
    refreshGiftLogic() {
        1 == User.shared().new_user_flopcash_open && User.shared().requestCheckFlopCashReward();
    }
    refreshHallGameEntry() {
        for (let e, t = 0, i = RemoteGameList.length; t < i; t++) {
            e = RemoteGameList[t];
            if (e === HallGameType.LOBBY_GAME_TYPE_SHUIGUOJI) {
                const slot = this.gameBtnArr[e];
                slot.getChildByName("download").active = false;
                slot.getComponent(Sprite).color = this.h5Games.some((game) => game.game_id === "fruit") ? color(255, 255, 255) : color(120, 120, 120);
                continue;
            }
            let i = User.shared().getGameRoomTable(e);
            const a = t => {
                if (1 == i.open) {
                    if (ToolUtils.checkIsGameDownLoad(e, true)) {
                        t.getChildByName("download").active = false;
                        t.getComponent(Sprite).color = color(255, 255, 255);
                    }
                    else {
                        let i = t.getChildByName("download").getChildByName("ico"), a = t.getChildByName("download").getChildByName("ProgressBar");
                        if (ToolUtils._gameLoadInfo[e] && ToolUtils._gameLoadInfo[e].isLoading) {
                            if (i.active = false, a.active = true, sys.isObjectValid(ToolUtils._gameLoadInfo[e].percent)) {
                                let t = ToolUtils._gameLoadInfo[e].percent;
                                a.getComponent(ProgressBar).progress = t;
                            }
                            else {
                                a.getComponent(ProgressBar).progress = 0.05;
                            }
                        }
                        else {
                            i.active = true;
                            a.active = false;
                        }
                        t.getChildByName("download").active = true;
                        t.getComponent(Sprite).color = color(120, 120, 120);
                    }
                }
            };
            a(this.gameBtnArr[e]);
            e == HallGameType.LOBBY_GAME_TYPE_LuckBall && this.cricket_bottom_right && a(this.cricket_bottom_right.getChildByName("wingo_btn"));
        }
    }
    checkInviteRedAnim() {
        3 == this.curSelectTab ? this.tabNodeArray[3].getChildByName("anim") && (this.tabNodeArray[3].getChildByName("anim").active = false, this.tabNodeArray[3].getChildByName("img").active = true) : 1 == User.shared().has_invite_reward ? this.tabNodeArray[3].getChildByName("anim") && (this.tabNodeArray[3].getChildByName("anim").active = true, this.tabNodeArray[3].getChildByName("img").active = false, this.tabNodeArray[3].getChildByName("anim").getComponent(sp.Skeleton).clearTracks(), this.tabNodeArray[3].getChildByName("anim").getComponent(sp.Skeleton).setAnimation(0, "share_entrance", true)) : this.tabNodeArray[3].getChildByName("anim") && (this.tabNodeArray[3].getChildByName("anim").active = false, this.tabNodeArray[3].getChildByName("img").active = true);
    }
    fitScreen() {
        let e = ToolUtils.adaptSafeArea(this.lobby_root);
        this.cashInfo.getComponent(Widget).top = this.cashInfo.getComponent(Widget).top + e / 2;
    }
    onClickByBtn(e, t) {
        if (typeof t === "string" && t.startsWith("h5:")) {
            this.openH5Game(t.slice(3));
            return;
        }
        if ("mail" == t) {
            if (HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Hall, event: ReportConfig.hall_evt.click_email }), TransferPlatform.shared().logEvent_firebase(ReportConfig.hall_evt.click_email), 1 === User.shared().temp_pingbi.email) {
                return void Utils.shared().showToast("Coming soon", 2);
            }
        }
        else if ("daily" == t) {
            if (HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Hall, event: ReportConfig.hall_evt.click_weekly_jackpot }), TransferPlatform.shared().logEvent_firebase(ReportConfig.hall_evt.click_weekly_jackpot), 1 === User.shared().temp_pingbi.dailytask) {
                return void Utils.shared().showToast("Coming soon", 2);
            }
        }
        else if ("novices" == t) {
            if (1 == this._guideStep && this.showHallGuide(), 1 === User.shared().temp_pingbi.xstask) {
                return void Utils.shared().showToast("Coming soon", 2);
            }
        }
        else if ("super_vip" == t) {
            TransferPlatform.shared().logEvent_firebase(ReportConfig.firebase_evt.click_supervip);
            let e = { reportEvtId: 3 };
            e.link_id = sys.now();
            e.reportScene = 1;
            Utils.shared().doJumpLogic(PushEvent.JUMP_TO_SuperVip, null, e);
        }
        else if ("act_rank" == t) {
            Utils.shared().doJumpLogic(PushEvent.JUMP_TO_LeaderBoards);
        }
        else if ("treahunt" == t) {
            let e = { reportEvtId: 1 };
            e.link_id = sys.now();
            e.reportScene = 1;
            Utils.shared().doJumpLogic(PushEvent.JUMP_TO_TREASURE_HUNT, null, e);
        }
        else if ("challenger" == t) {
            Utils.shared().showLeaderBoardMainView(this.node);
        }
        else if ("gameentry" == t) {
            this.showGameEntry(true, true);
        }
        else if ("gameentryclose" == t) {
            this.showGameEntry(false, true);
        }
        else if ("act_topgift" == t) {
            let e = User.shared().data.act_collect_open.tab_act;
            if (sys.isObjectValid(e)) {
                let t = e.ext, i = 1;
                sys.isObjectValid(t) || (t = {});
                Utils.shared().doJumpLogic(e.act_id, t, { reportEvtId: i, link_id: sys.now() });
                User.shared().updatePayScene(PhpReportDefined.pay_scene.hall_actviity_topgift);
            }
        }
        SoundManager.shared().playFx("click");
        this.onDealMenu(t);
    }
    onDealMenu(e) {
        if ("roomSelect_AddCash" != e) {
            if (e != this.lastNodeName) {
                switch (String(e)) {
                    case "HallRule":
                    case "Rule":
                        Utils.shared().doJumpLogic(PushEvent.JUMP_TO_HOW_TO_PLAY);
                        break;
                    case "userinfo":
                        Utils.shared().showWalletView2();
                        break;
                    case "mail":
                        User.shared().jumpFromHall = true;
                        let e = { node: Utils.shared().hall_rootNode };
                        Utils.shared().doJumpLogic(PushEvent.JUMP_TO_EMAIL, e);
                        break;
                    case "store":
                        HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Hall, event: ReportConfig.common.try_recharge }), HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Hall, event: ReportConfig.hall_evt.click_to_recharge_mall }), TransferPlatform.shared().logEvent_firebase(ReportConfig.hall_evt.click_to_recharge_mall), User.shared().jumpFromHall = true, TransferPlatform.shared().setHighFrameRate(), Utils.shared().showStoreView({ selAutoBest: true }, Utils.shared().hall_rootNode), User.shared().updatePayScene(PhpReportDefined.pay_scene.hall_shop);
                        break;
                    case "club":
                        this.showMemberShipInfo(false), Utils.shared().doJumpLogic(PushEvent.JUMP_TO_CLUB), HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Hall, event: ReportConfig.hall_evt.click_club }), TransferPlatform.shared().logEvent_firebase(ReportConfig.hall_evt.click_club);
                        break;
                    case "withdraw":
                        if (this.checkWithrawPopKyc()) {
                            return;
                        }
                        HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Hall, event: ReportConfig.hall_evt.click_withdraw }), User.shared().jumpFromHall = true, Utils.shared().doJumpLogic(PushEvent.JUMP_TO_WITHDRAWAL), TransferPlatform.shared().logEvent_firebase(ReportConfig.hall_evt.click_withdraw);
                        break;
                    case "novices":
                        let t = { reportEvtId: 3 };
                        t.link_id = sys.now(), t.reportScene = 1, 1 == User.shared().new_user_flopcash_open && Utils.shared().doJumpLogic(PushEvent.JUMP_TO_Act_FlopCash, null, t), TransferPlatform.shared().logEvent_firebase(ReportConfig.firebase_evt.click_hall_novice);
                        break;
                    case "act_box":
                        let i = director.getScene().getChildByName("Canvas");
                        this.showActivityView(i);
                        break;
                    case "relief":
                        this.hallTopUiLogic.showReliefPackage();
                        break;
                    case "cash_info":
                        if (sys.now() - this._lastClick < 500) {
                            return;
                        }
                        this._lastClick = sys.now(), this.showCashInfo(true);
                        break;
                    case "sixdice":
                        let a = User.shared().getGameRoomTable(HallGameType.LOBBY_GAME_TYPE_SIXDICE);
                        if (0 == a.open) {
                            return void Utils.shared().showToast("Coming soon", 2);
                        }
                        sys.isObjectValid(a.info) && this.enterTargetGame(a.info.vid, CommonGameType.SixDice);
                        break;
                    case "crash":
                        {
                            let e = User.shared().getGameRoomTable(HallGameType.LOBBY_GAME_TYPE_CRASH);
                            if (0 == e.open) {
                                return void Utils.shared().showToast("Coming soon", 2);
                            }
                            sys.isObjectValid(e.info) && this.enterTargetGame(e.info.vid, CommonGameType.Crash);
                        }
                        break;
                    case "yes11":
                        if (0 == User.shared().getGameRoomTable(HallGameType.LOBBY_GAME_TYPE_YES11).open) {
                            return void Utils.shared().showToast("Coming soon", 2);
                        }
                        User.shared().enterRoomMoneyExe = User.shared().data && User.shared().data.money_exe ? User.shared().data.money_exe : 0, User.shared().enterRoomMoney = User.shared().data && User.shared().data.money ? User.shared().data.money : 0, ToolUtils.curVId = 3901, User.shared().exitRoomGameVid = 3901, this.has_popAct = [], this.enterTargetGame(0, CommonGameType.Yes11);
                        break;
                    case "slots": {
                        this.openH5Game("fruit");
                        break;
                    }
                    case "luckBall": {
                        let e = User.shared().getGameRoomTable(HallGameType.LOBBY_GAME_TYPE_LuckBall);
                        if (0 == e.open) {
                            return void Utils.shared().showToast("Coming soon", 2);
                        }
                        sys.isObjectValid(e.info) && (this.has_popAct = [], this.enterTargetGame(e.info.vid, CommonGameType.LuckBall));
                        break;
                    }
                }
            }
        }
        else {
            Utils.shared().showStoreView(null, Utils.shared().hall_rootNode);
        }
    }
    showActivityView(e) {
        ToolUtils.judgeIfInHall() && ToolUtils.loadCommonPrefab(this.activityPrefab, BundleNameDefined.bundle_hallTopUI, "prefab/activity_center", (t => {
            if (this.activityPrefab = t, ToolUtils.isObjValid(e) && null == e.getChildByName("ActivityCenter")) {
                try {
                    let t = instantiate(this.activityPrefab);
                    t.name = "ActivityCenter";
                    e.addChild(t);
                }
                catch (e) {
                    TLog.printError("createActivityView err:", e);
                }
            }
        }));
    }
    enterTargetGame(e, t = CommonGameType.TeenPatti) {
        if (t == CommonGameType.Yes11) {
            return Utils.shared().doJumpLogic(PushEvent.JUMP_TO_Yes11, {}), void this.showGameEntry(false);
        }
        let i = ToolUtils.getHallGameType(t);
        if (!ToolUtils.checkIsGameDownLoad(i)) {
            return void (ToolUtils._gameLoadInfo[i] && ToolUtils._gameLoadInfo[i].isLoading ? Utils.shared().showToast("Downloading game resources, please wait...", 2) : this.startDownLoadGame(i));
        }
        let a = { vid: e, isNewTable: 1, game_type: t };
        this.showGameEntry(false);
        Utils.shared().showCommEnterGame(a);
    }
    startDownLoadGame(e) {
        let t = null;
        if (e == HallGameType.LOBBY_GAME_TYPE_SHUIGUOJI ? t = this.gameEntryPageNode.getChildByName("list").getChildByName("layout").getChildByName("slot_btn") : e == HallGameType.LOBBY_GAME_TYPE_CRASH ? t = this.gameEntryPageNode.getChildByName("list").getChildByName("layout").getChildByName("crash_btn") : e == HallGameType.LOBBY_GAME_TYPE_SIXDICE ? t = this.gameEntryPageNode.getChildByName("list").getChildByName("layout").getChildByName("sixdice_btn") : e == HallGameType.LOBBY_GAME_TYPE_YES11 ? t = this.gameEntryPageNode.getChildByName("list").getChildByName("layout").getChildByName("yes11_btn") : e == HallGameType.LOBBY_GAME_TYPE_LuckBall && (t = this.gameEntryPageNode.getChildByName("list").getChildByName("layout").getChildByName("wingo_btn")), t) {
            const i = e => {
                let i = t.getChildByName("download");
                i.getChildByName("ico").active = false;
                let a = i.getChildByName("ProgressBar");
                a.active = true;
                a.getComponent(ProgressBar).progress = 0.05;
            };
            i();
            e == HallGameType.LOBBY_GAME_TYPE_LuckBall && this.cricket_bottom_right && i(this.cricket_bottom_right.getChildByName("wingo_btn"));
        }
        Utils.shared().startLoadSubGame(e, ToolUtils.getDownLoadBundleUrl(e));
    }
    checkWithrawPopKyc() {
        return false;
    }
    showCashInfo(e) {
        if (ToolUtils.isObjValid(this.infoNode) && (this.infoNode.active != e && (this.infoNode.active = e), ToolUtils.isObjValid(this.cashInfo) && this.cashInfo.active != e)) {
            this.cashInfo.active = e;
            let t = e ? -1 : 1;
            this.top_info.getChildByName("add_cash").getChildByName("arrow").setScale(v3(1, t, 1));
        }
    }
    showMemberShipInfo(e) {
        ToolUtils.isObjValid(this.infoNode) && this.infoNode.active != e && (this.infoNode.active = e);
    }
    setUserInfo() {
        User.shared().data.money != User.shared().real_money && (User.shared().data.money = User.shared().real_money);
        let e = this.top_info.getChildByName("money"), t = this.top_info.getChildByName("head_mask").getChildByName("head_img");
        User.shared().data.avatar && User.shared().data.avatar.length > 0 && Utils.shared().updateHeadImg(t, User.shared().data.avatar, User.shared().data.avatar_url, size(75, 75));
        this.nick_name.string = ToolUtils.GetShortName2(User.shared().data.name, 13, false);
        this.cashInfo.getChildByName("deposit").getComponent(Label).string = "₹ " + ToolUtils.parse_double(String(User.shared().data.deposit), 2, true);
        this.cashInfo.getChildByName("withdrawable").getComponent(Label).string = "₹ " + ToolUtils.parse_double(String(User.shared().data.withdraw), 2, true);
        this._treasuredraw_rewarding || (e.getComponent(Label).string = ToolUtils.parse_double(String(User.shared().data.money)));
    }
    updateMemberShipInfo() {
        this.top_info.getChildByName("btn_clubInfo").active = true;
        let e = 0;
        if (User.shared().data.player_club.club_level && (e = User.shared().getGradeByMemberShipLevel(User.shared().data.player_club.club_level)), sys.isObjectValid(e) && e >= 0) {
            this.clubIconFrame[e] && (this.top_info.getChildByName("btn_clubInfo").getChildByName("icon").getComponent(Sprite).spriteFrame = this.clubIconFrame[e]);
            let t = [color(198, 198, 198), color(205, 137, 92), color(212, 221, 255), color(229, 175, 91), color(95, 185, 255), color(191, 122, 234), color(161, 124, 255), color(255, 116, 188), color(43, 233, 255), color(255, 0, 228)];
            this.top_info.getChildByName("btn_clubInfo").getChildByName("club_name").getComponent(Label).color = t[e];
            this.top_info.getChildByName("btn_clubInfo").getChildByName("club_name").getComponent(Label).string = User.shared().data.player_club.club_name;
        }
    }
    updateGold(e) {
        let t = this.top_info.getChildByName("money");
        null != e && t && (t.getComponent(Label).string = ToolUtils.parse_double(e));
    }
    setGameModeIcon() {
        ToolUtils.isObjValid(this.choosegame) || ToolUtils.isObjValid(this.node) && (this.choosegame = instantiate(this.choose_gamePrefab), this.lobby_root.getChildByName("room").addChild(this.choosegame), User.shared().choosegame = this.choosegame.getComponent(LobbyRummySelection));
    }
    addBannerNode(e = true) {
        let t = this.lobby_root.getChildByName("banner"), i = t.getChildByName("LobbyAd");
        if (ToolUtils.isObjValid(i)) {
            if (e) {
                i.getComponent(LobbyAds).updateBanners();
            }
        }
        else if (i = instantiate(this.BannersPrefab), t.addChild(i), e) {
            i.getComponent(LobbyAds).updateBanners();
        }
    }
    addActCollectNode() {
        if (1 == GameConfig.CHIPS_MODLE) {
            return this.bottom_info_right.getChildByName("btn_box").active = false, void (this.bottom_info_right.getChildByName("btn_tabact").active = false);
        }
        if (this.preDownActImg(), 1 != User.shared().choose_game_type) {
            let e = false;
            if (sys.isObjectValid(User.shared().data.act_collect_open) && sys.isObjectValid(User.shared().data.act_collect_open.tab_act) && (this.bottom_info_right.getChildByName("btn_tabact").active = true, this.updateTopGiftAct(this.bottom_info_right.getChildByName("btn_tabact")), e = true), sys.isObjectValid(User.shared().data.act_collect_open) && sys.isObjectValid(User.shared().data.act_collect_open.list) && User.shared().data.act_collect_open.list.length > 0 && (this.bottom_info_right.getChildByName("btn_box").active = true, e = true), e) {
                return;
            }
        }
        Utils.shared().actNodePos = this.bottom_info_right.getChildByName("btn_box").worldPosition;
        this.bottom_info_right.getChildByName("btn_box").active = false;
        this.bottom_info_right.getChildByName("btn_tabact").active = false;
    }
    updateTopGiftAct(e) {
        if (sys.isObjectValid(User.shared().data.act_collect_open) && sys.isObjectValid(User.shared().data.act_collect_open.tab_act)) {
            let t = User.shared().data.act_collect_open.tab_act.act_id;
            this.hall_tabact_img.has(Number(t)) ? (e.getChildByName("ico").getComponent(Sprite).spriteFrame = this.hall_tabact_img.get(Number(t)).img, e.getChildByName("name").getComponent(Label).string = this.hall_tabact_img.get(Number(t)).name, this.playTabActAnim(e)) : e.active = false;
        }
    }
    playTabActAnim(e) {
        let t = e.getChildByName("mask"), i = e.getChildByName("name");
        i.active = false;
        Array.isArray(t.children) && t.children.length > 0 && t.removeAllChildren();
        TweenTool.stopNodeAction(t);
        i.getComponent(Label).updateRenderData(true);
        let a = i.getComponent(UITransform).width;
        if (a > 90) {
            for (let e = 0; e < 2; e++) {
                let s = instantiate(i);
                s.active = true;
                let o = (a - 90) / 2 + e * (a + 10);
                s.setPosition(v3(o, 5));
                t.addChild(s);
            }
            TweenTool.commonSchedule(t, 0.03, (() => {
                let e = t.children;
                if (sys.isObjectValid(e)) {
                    for (let t = 0, i = e.length; t < i; t++) {
                        let i = new Vec3;
                        e[t].getPosition(i);
                        e[t].setPosition(v3(i.x - 1.2, 5));
                        i.x < -(90 + a) / 2 - 15 && e[t].setPosition(v3((a - 90) / 2 + (a + 10), 5));
                    }
                }
            }));
        }
        else {
            let e = instantiate(i);
            e.active = true;
            e.setPosition(v3(0, 5));
            t.addChild(e);
        }
    }
    preDownActImg() {
        if (sys.isObjectValid(User.shared().data.act_collect_open) && sys.isObjectValid(User.shared().data.act_collect_open.list) && User.shared().data.act_collect_open.list.length > 0) {
            for (let e = 0, t = User.shared().data.act_collect_open.list.length; e < t; e++) {
                Utils.shared().downNetImage(User.shared().data.act_collect_open.list[e].imgurl);
            }
        }
    }
    onGuideBtnClick(e, t) {
        if (SoundManager.shared().playFx("click"), "practice" == t) {
            ToolUtils.in_isGuideRoom = 1;
            Utils.shared().showLoading(20, true, (() => {
                Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3);
                User.shared().send_request_hall_tableinfo();
            }));
            let e = new Node;
            e.addComponent(LoadTableCpp);
            this.node.addChild(e);
            e.name = "loadTableCpp";
            e.getComponent(LoadTableCpp).enterGameScene();
            let t = this.guide_practice_btn.getComponent(Button);
            t.interactable = false;
            TweenTool.delayAct(this.node, (() => {
                t.interactable = true;
            }), 1, true);
        }
        else if ("skip" == t) {
            if (User.shared().send_laba_notify_newer_reward_pop_laba(), 1 === User.shared().data.beginner_guide.cash_status) {
                return;
            }
            Utils.shared().showLoading(10, false, (() => {
                Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3);
            }));
            HttpManager.shared().doGetNewPlayerGuideFinish(1, ((e, t, i) => {
                if (Utils.shared().hideLoading(), 200 == i) {
                    try {
                        let e = ToolUtils.parseJson(t);
                        0 == e.ret && (ToolUtils.in_isGuideRoom = 0, ToolUtils.isObjValid(this.node) && (this.node_guide.active = false, 0 === User.shared().data.beginner_guide.cash_status && (User.shared().data.beginner_guide.cash_reward > 0 ? User.shared().showJumpToCashGameTips() : (this.popActivity(), Utils.shared().preLoadBundleAsset(true)), User.shared().isGuideEnterGame = 1)), User.shared().data.beginner_guide.practice_status = 1, User.shared().data.beginner_guide.cash_status = 1, null != e.data && null != e.data && null != e.data.money && (User.shared().data.money = e.data.money, User.shared().real_money = e.data.money, PushCenter.shared().pushEvent(GameConfig.Update_Money, User.shared().data.money)), PushCenter.shared().pushEvent(PushEvent.CheckHandGuide));
                    }
                    catch (e) {
                        TLog.printError("doGetNewPlayerGuideFinish err:", e.toString());
                    }
                }
            }));
            let e = this.guide_skip_btn.getComponent(Button);
            e.interactable = false;
            TweenTool.delayAct(this.node, (() => {
                e.interactable = true;
            }), 1, true);
        }
    }
    updateSmallGameStatus(e, t) {
        if (1 == GameConfig.CHIPS_MODLE && (e = 0), 1 == e) {
            let e = true;
            sys.isObjectValid(t) && 1 == t && (e = false);
            1 == User.shared().choose_game_type && (e = false);
            this.gameEntryBtn.active = e ? User.shared().playingMethod_entry_switch.length > 0 || this.h5Games.length > 0 : e;
            this.cricket_bottom_right && (this.cricket_bottom_right.getChildByName("wingo_btn").active = e ? User.shared().playingMethod_entry_switch.length > 0 : e);
            1 == GameConfig.GAME_HALL_THEME && (1 == User.shared().choose_game_type ? this.lobby_root.getChildByName("challenger_btn").active = false : this.lobby_root.getChildByName("challenger_btn").active = true);
        }
        else {
            this.gameEntryBtn.active = false;
            this.cricket_bottom_right && (this.cricket_bottom_right.getChildByName("wingo_btn").active = false);
            1 == GameConfig.GAME_HALL_THEME && (1 == User.shared().choose_game_type ? this.lobby_root.getChildByName("challenger_btn").active = false : this.lobby_root.getChildByName("challenger_btn").active = true);
        }
    }
    onSwitchGameClick(e, t) {
        1 != t && SoundManager.shared().playFx("click");
        ToolUtils.isObjValid(this.choosegame) || this.setGameModeIcon();
        "rummy" == e[0] ? this.dealChooseGameLogic(0, e) : "buddy" == e[0] ? this.choosegame.getComponent(LobbyRummySelection).setInitGameType(2, Number(e[1])) : "prictice" == e[0] ? (this.dealChooseGameLogic(3, e), sys.isObjectValid(e[4]) && 1 == Number(e[4]) && this.choosegame.getComponent(LobbyRummySelection).showChipGameAlert()) : "match" == e[0] ? this.choosegame.getComponent(LobbyRummySelection).setInitGameType(1) : "-1" == e && Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text41"), 2);
    }
    dealChooseGameLogic(e, t) {
        if (1 == GameConfig.CHIPS_MODLE && 0 == e && (e = 3), !ToolUtils.isObjValid(this.choosegame)) {
            return;
        }
        let i = Number(t[1]);
        if (Number.isNaN(i)) {
            this.choosegame.getComponent(LobbyRummySelection).initView(true);
        }
        else {
            let a = null, s = sys.localStorage.getItem(User.shared().data.uid + "recommendRoom0" + i);
            if (s) {
                let e = ToolUtils.getRecommendRoom(ToolUtils.parseJson(s));
                sys.isObjectValid(e.playersIndex) && (a = e);
            }
            let o = Number(t[2]);
            if (Number.isNaN(o)) {
                if (a) {
                    this.choosegame.getComponent(LobbyRummySelection).setInitGameType(e, i, a.playersIndex, a.poolIndex, a.dealsIndex, false, a.enterMoney, a.modeIndex);
                }
                else {
                    let t = ToolUtils.getRecommendRoom(User.shared().sysRecommend);
                    sys.isObjectValid(t.playersIndex) && 0 == t.gameType && i == t.rummyType ? this.choosegame.getComponent(LobbyRummySelection).setInitGameType(e, i, t.playersIndex, t.poolIndex, t.dealsIndex, false, t.enterMoney, t.modeIndex) : this.choosegame.getComponent(LobbyRummySelection).setInitGameType(e, i, 1, 0, 1);
                }
            }
            else if (0 == i) {
                if (Number.isNaN(Number(t[3]))) {
                    this.choosegame.getComponent(LobbyRummySelection).setInitGameType(e, 0, o);
                }
                else {
                    let i = User.shared().getCurModeVec(e), a = 0;
                    for (let e = 0, s = i.length; e < s; e++) {
                        if (Number(t[3]) == i[e]) {
                            a = e;
                            break;
                        }
                    }
                    this.choosegame.getComponent(LobbyRummySelection).setInitGameType(e, 0, o, 0, 0, false, null, a);
                    sys.isObjectValid(t[4]) && 1 == Number(t[4]) && this.choosegame.getComponent(LobbyRummySelection).onCheckShowGameAlert();
                }
            }
            else {
                1 == i ? this.choosegame.getComponent(LobbyRummySelection).setInitGameType(e, 1, o, Number(t[3])) : 2 == i && (Number.isNaN(Number(t[3])) ? a && o == a.playersIndex ? this.choosegame.getComponent(LobbyRummySelection).setInitGameType(e, 2, o, 0, a.dealsIndex) : 0 == o ? this.choosegame.getComponent(LobbyRummySelection).setInitGameType(e, 2, 0, 0, 0) : this.choosegame.getComponent(LobbyRummySelection).setInitGameType(e, 2, 1, 0, 1) : this.choosegame.getComponent(LobbyRummySelection).setInitGameType(e, 2, o, 0, Number(t[3])));
            }
        }
    }
    onSwitchTabClick(e, t, i) {
        if (4 == Number(t)) {
            if (this.checkMainMenuHide(Number(t))) {
                return;
            }
        }
        else {
            if (this.checkMainMenuHide(Number(t)), 1 == GameConfig.GAME_HALL_THEME) {
                if (3 == Number(t)) {
                    if (this.checkMainInvteHide(Number(t))) {
                        return;
                    }
                }
                else {
                    this.checkMainInvteHide(Number(t));
                }
            }
            if (this.curSelectTab == Number(t)) {
                return;
            }
        }
        1 != i && SoundManager.shared().playFx("click");
        this.showCashInfo(false);
        this.showMemberShipInfo(false);
        this.dealTabClick(t);
    }
    dealTabClick(e) {
        if (0 == e) {
            if (1 == GameConfig.CHIPS_MODLE) {
                return void Utils.shared().showToast("Coming soon", 2);
            }
            Utils.shared().doJumpLogic(PushEvent.JUMP_TO_STORE);
            User.shared().updatePayScene(PhpReportDefined.pay_scene.hall_shop);
        }
        else if (1 == e) {
            if (TransferPlatform.shared().setHighFrameRate(), 0 == GameConfig.GAME_HALL_THEME) {
                return void (1 == GameConfig.CHIPS_MODLE ? Utils.shared().showToast("Coming soon", 2) : Utils.shared().showLeaderBoardMainView(this.node));
            }
            {
                let e = { parent_node: this.wallet_root };
                Utils.shared().showSportCricket_main(e);
            }
            this.curSelectTab = 1;
            this.updateSelectTab(this.curSelectTab);
        }
        else if (2 == e) {
            this.curSelectTab = 2;
            ToolUtils.isObjValid(this.choosegame) || this.setGameModeIcon();
            this.updateSelectTab(this.curSelectTab);
        }
        else if (3 == e) {
            if (2 == this._guideStep && this.showHallGuide(), 1 === User.shared().temp_pingbi.referearn) {
                return void Utils.shared().showToast("Coming soon", 2);
            }
            if (TransferPlatform.shared().setHighFrameRate(), 0 == GameConfig.GAME_HALL_THEME) {
                this.curSelectTab = 3;
                Utils.shared().showInviteView(this.invite_root);
                this.updateSelectTab(this.curSelectTab);
            }
            else {
                let e = "hall_root";
                if (1 == GameConfig.GAME_HALL_THEME) {
                    let e = director.getScene().getChildByName("Canvas");
                    return void Utils.shared().showInviteView(e);
                }
                Utils.shared().showInviteView(this.node.getChildByName(e));
            }
            HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Hall, event: ReportConfig.hall_evt.click_ReferEarn });
            TransferPlatform.shared().logEvent_firebase(ReportConfig.hall_evt.click_ReferEarn);
        }
        else if (4 == e) {
            if (TransferPlatform.shared().setHighFrameRate(), 1 === User.shared().temp_pingbi.me) {
                this.hallTopUiLogic.showSetting();
            }
            else {
                let e = "hall_root";
                1 == GameConfig.GAME_HALL_THEME && (e = "middle_root");
                director.getScene().getChildByName("Canvas");
                Utils.shared().showMenuView(this.node.getChildByName(e));
                this.tabNodeArray[4].getChildByName("img").active = false;
                this.tabNodeArray[4].getChildByName("img2").active = true;
            }
            HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Hall, event: ReportConfig.hall_evt.click_me });
            TransferPlatform.shared().logEvent_firebase(ReportConfig.hall_evt.click_me);
        }
    }
    checkMainMenuHide(e) {
        let t = "hall_root";
        1 == GameConfig.GAME_HALL_THEME && (t = "middle_root");
        let i = this.node.getChildByName(t).getChildByName("carte_node_v2");
        return ToolUtils.isObjValid(i) ? (i.getComponent(Carte).onBackView(), this.tabNodeArray[4].getChildByName("img").active = true, this.tabNodeArray[4].getChildByName("img2").active = false, 1 == GameConfig.GAME_HALL_THEME && (this.tabNodeArray[4].getChildByName("img").getComponent(Sprite).color = this.menu_unselect_color, this.tabNodeArray[4].getChildByName("img2").getComponent(Sprite).color = this.menu_unselect_color), true) : (1 == GameConfig.GAME_HALL_THEME && (4 == e ? (this.tabNodeArray[4].getChildByName("img").getComponent(Sprite).color = this.menu_select_color, this.tabNodeArray[4].getChildByName("img2").getComponent(Sprite).color = this.menu_select_color) : (this.tabNodeArray[4].getChildByName("img").getComponent(Sprite).color = this.menu_unselect_color, this.tabNodeArray[4].getChildByName("img2").getComponent(Sprite).color = this.menu_unselect_color)), false);
    }
    checkMainInvteHide(e) {
        let t = director.getScene().getChildByName("Canvas").getChildByName("share_main_page");
        return ToolUtils.isObjValid(t) ? (t.getComponent(ShareMainPage).onBackView(), this.tabNodeArray[3].getChildByName("img").active = true, 1 == GameConfig.GAME_HALL_THEME && (this.tabNodeArray[3].getChildByName("img").getComponent(Sprite).color = this.menu_unselect_color), true) : (1 == GameConfig.GAME_HALL_THEME && (this.tabNodeArray[3].getChildByName("img").getComponent(Sprite).color = 3 == e ? color(153, 44, 35) : this.menu_unselect_color), false);
    }
    updateSelectTab(e) {
        let t = this.bottom_root.getChildByName("select");
        TweenTool.stopNodeAction(t);
        for (let i = 0, a = this.tabNodeArray.length; i < a; i++) {
            let a = this.tabNodeArray[i], s = a.getChildByName("img"), o = a.getChildByName("line"), l = a.getChildByName("Label");
            s.active = true;
            TweenTool.stopNodeAction(s);
            this._lastSelectTab === i && i < 4 && ToolUtils.isObjValid(this.pageNodes[i]) && (this.pageNodes[i].active = true);
            this.checkInviteRedAnim();
            e == i ? (i < 4 && ToolUtils.isObjValid(this.pageNodes[i]) && (this.pageNodes[i].active = true), 0 == GameConfig.GAME_HALL_THEME ? (o.getComponent(Sprite).color = color(255, 255, 255, 0), 0 != e && (this.tabNodeArray[i - 1].getChildByName("line").getComponent(Sprite).color = color(255, 255, 255, 0)), TweenTool.moveTo(t, this._page_time, v3(a.getPosition().x, 55), "cubicOut", true, (() => {
            })), l.getComponent(Label).color = this.tab_wz_color, TweenTool.scaleTo(s, 0.1, v3(0.94, 0.94, 0.94), null, true, (() => {
                s.getComponent(Sprite).color = this.tab_wz_color;
                TweenTool.scaleTo(s, 0.1, v3(1, 1, 1), null, true);
            }))) : 1 != e && 2 != e || 1 != i && 2 != i ? (3 == e && 3 != i || 4 == e && 4 != i) && (this.tabNodeArray[i].getComponent(Sprite).color = color(255, 255, 255), s.getComponent(Sprite).color = this.menu_unselect_color) : (s.getComponent(Sprite).color = color(255, 255, 255), l.getComponent(Label).color = color(255, 255, 255), o.active = true)) : (this._lastSelectTab !== i && i < 4 && ToolUtils.isObjValid(this.pageNodes[i]) && (this.pageNodes[i].active = false), 0 == GameConfig.GAME_HALL_THEME ? (o.getComponent(Sprite).color = color(255, 255, 255, 255), o.setPosition(73.153, 54), s.getComponent(Sprite).color = this.menu_unselect_color, l.getComponent(Label).color = this.menu_unselect_color) : (1 != e && 2 != e || (o.active = false), 1 != i && 2 != i ? (3 == e && 3 != i || 4 == e && 4 != i) && (this.tabNodeArray[i].getComponent(Sprite).color = color(255, 255, 255), s.getComponent(Sprite).color = this.menu_unselect_color) : (s.getComponent(Sprite).color = this.menu_unselect_color, l.getComponent(Label).color = this.menu_unselect_color)));
            0 == GameConfig.GAME_HALL_THEME && (o.active = false);
        }
        this.scrollHallPageByIndex(e);
        this._lastSelectTab = e;
    }
    scrollHallPageByIndex(e) {
        User.shared().hall_select_tab = e;
        TweenTool.stopNodeAction(this.pageRoot);
        this.pageRoot.setPosition(v3(this._lastPageRootX, 0));
        let t = 0, i = this.pageNodes[this._lastSelectTab].getPosition().x, a = this.pageNodes[e], s = this.pageRoot.getPosition().x, o = GameConfig.REAL_SCREEN_WIDTH;
        this._lastSelectTab < e ? (t = s - o, a.setPosition(v3(i + o, 0))) : this._lastSelectTab > e && (t = s + o, a.setPosition(v3(i - o, 0)));
        this._lastPageRootX = t;
        TweenTool.moveTo(this.pageRoot, this._page_time, v3(t, 0), "cubicOut", true, (() => {
            this.pageRoot.setPosition(v3(t, 0));
            for (let t = 0, i = this.pageNodes.length; t < i; t++) {
                const i = this.pageNodes[t];
                t === e ? (i.active = true, 1 === e || 2 === e && PushCenter.shared().pushEvent(PushEvent.CheckBannerReport)) : i.active = false;
            }
        }));
        1 == GameConfig.GAME_HALL_THEME && TweenTool.delayAct(this.node, (() => {
            this.node.getChildByName("bottom").getChildByName("xuhua").active = 1 == e;
        }), 0.2, true);
    }
    enterRummy(e, t = 1, i, a, s = 0, o) {
        0 != sys.getNetworkType() ? (Utils.shared().showLoading(5, true, (() => {
            0 == sys.getNetworkType() ? Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text91"), 3, 0, ToolUtils.getIsNormalDirection()) : (Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection()), User.shared().send_request_hall_tableinfo());
        })), ToolUtils.curRoomId = e, Utils.shared().showCommEnterRoom({ vid: e, game_type: t, tid: i, privateRoomData: a, is_back: s, raceid: o, isNewTable: 1 })) : Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text91"), 3, 0, ToolUtils.getIsNormalDirection());
    }
    on_join_game_click(e, t) {
        SoundManager.shared().playFx("click");
        HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Hall, event: ReportConfig.hall_evt.clickMyJoinGame });
        0 === this.my_join_state && (this.my_join_state = 1, TweenTool.moveTo(this.join_game, 0.2, v3(-276 - this._joinGameDiffX, this.join_game.getPosition().y, this.join_game.getPosition().z), null, true), this.myJoinAct = TweenTool.delayAct(this.join_game, (() => {
            TweenTool.moveTo(this.join_game, 0.2, v3(-376 - this._joinGameDiffX, this.join_game.getPosition().y, this.join_game.getPosition().z), null, true, (() => {
                this.my_join_state = 0;
            }));
        }), 6, true));
        this.hallTopUiLogic.showMyJoinGame();
    }
    update_hall_tableinfo(e, t = false) {
        try {
            let i = true;
            if (sys.isObjectValid(e) && 0 === e.ret) {
                if (sys.isObjectValid(e.tableInfo) && e.tableInfo.length > 0) {
                    this.join_game.active = true;
                    let t = e.tableInfo.length;
                    if (this.join_game.getChildByName("num").getComponent(Label).string = "" + t, this._tableInfoMsg = e, this.my_join_state = 1, this.join_game.setPosition(v3(-276 - this._joinGameDiffX, this.join_game.getPosition().y)), TweenTool.delayAct(this.join_game, (() => {
                        TweenTool.moveTo(this.join_game, 0.2, v3(-376 - this._joinGameDiffX, this.join_game.getPosition().y, this.join_game.getPosition().z), null, true, (() => {
                            this.my_join_state = 0;
                        }));
                    }), 6, true), this._isFromLogin && !this._isGameHall) {
                        const e = this._tableInfoMsg.tableInfo[0];
                        if (ToolUtils.curRoomId = e.vid, ToolUtils.checkIsRummy(e.game_type)) {
                            let t = null, a = null;
                            e.game_type !== HowToPlayDefined.gameId_PrivateRummy && e.game_type != HowToPlayDefined.gameId_PoolPrivateRummy && e.game_type != HowToPlayDefined.gameId_DealsPrivateRummy || (t = { roomid: e.vid, base_money: e.base_money, seat_max: e.pnum });
                            e.game_type === HowToPlayDefined.gameId_RaceRummy && (a = e.raceid);
                            let s = e.tid_key;
                            HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Hall, event: ReportConfig.hall_evt.login_enter_room, type: e.mode, cnt: e.pnum, amt: e.base_money, round: e.round || 1, currentRound: e.currentRound || 1 });
                            User.shared().poplist = [];
                            i = false;
                            this._serverCanPreLink = false;
                            Utils.shared().showLoadTable(e.vid, e.game_type, null, t, 0, s, a);
                        }
                        else {
                            User.shared().poplist = [];
                            i = false;
                            let t = { vid: e.vid, game_type: e.game_type, tid_key: e.tid_key, isNewTable: 0 };
                            this._serverCanPreLink = false;
                            Utils.shared().showCommEnterGame(t);
                        }
                    }
                    else {
                        e.cmd == NetConfig.SERVER_RESP_HALL_TABLE_INFO && this.on_join_game_click(null, "joingame");
                    }
                }
                else {
                    this.join_game.active = false;
                    this._tableInfoMsg = null;
                }
            }
            else {
                this.join_game.active = false;
                this._tableInfoMsg = null;
            }
            t && i && (User.shared().isShowPopList && this.showPopList(), User.shared().isShowPopList = true);
        }
        catch (e) {
            TLog.printError("---------- update_hall_tableinfo err:", e);
        }
    }
}
