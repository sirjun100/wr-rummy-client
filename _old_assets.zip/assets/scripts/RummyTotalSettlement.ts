// @ts-nocheck
// Recovered from index.js:493
import { _decorator, Button, color, instantiate, Label, LabelShadow, Node, size, sp, Sprite, SpriteAtlas, SpriteFrame, sys, UITransform, v3 } from "cc";
import SoundManager from "./SoundManager";
import RummyDataManager, { RUMMY_GAME_TYPE } from "./RummyDataManager";
import Utils from "./Utils";
import User from "./User";
import PushCenter from "./PushCenter";
import PushEvent from "./PushEvent";
import TweenTool from "./TweenTool";
import i18nMgr from "./i18nMgr";
import BaseLayer from "./BaseLayer";
import CommDefine from "./CommDefine";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("RummyTotalSettlement")
export default class RummyTotalSettlement extends BaseLayer {
    @property(Node)
    public bgView: Node = null;
    @property(Node)
    public ItemBg: Node = null;
    @property(Node)
    public ItemJiasaiBg: Node = null;
    @property(Node)
    public downTime: Node = null;
    @property(Node)
    public bonusTipsMask: Node = null;
    @property([SpriteFrame])
    public title_show_img: SpriteFrame[] = [];
    @property([SpriteFrame])
    public item_bg_img: SpriteFrame[] = [];
    @property([SpriteFrame])
    public title_win_img: SpriteFrame[] = [];
    @property([SpriteFrame])
    public title_lose_img: SpriteFrame[] = [];
    @property([SpriteFrame])
    public title_result_img: SpriteFrame[] = [];
    @property([SpriteFrame])
    public me_flag_img: SpriteFrame[] = [];
    public scoreBg_colors: any[] = [color(208, 208, 208), color(255, 230, 145)];
    public win_lost_colors: any[] = [color(121, 121, 121), color(0, 140, 22)];
    public break_bg1_colors: any[] = [color(233, 233, 233), color(255, 247, 218)];
    public break_bg2_colors: any[] = [color(208, 208, 208), color(255, 230, 145)];
    @property(SpriteAtlas)
    public clubKuangAtlas: SpriteAtlas = null;
    @property([SpriteFrame])
    public btn_imgs: SpriteFrame[] = [];
    public typeNum: number = 0;
    public data: any = undefined;
    public gameController: any = undefined;
    public hide_start: number = 0;
    public itemViewDate: any[] = [];
    public gameTipsTextTime: number = 0;
    public gameTipsTextTimeAction: any = null;
    public b_isPlayEff: boolean = true;
    public _bIsMyWin: boolean = false;
    public _scheduleStartCardAct: any = null;
    public _leftTime: any = -1;
    public _upvenue_fee: any = -1;
    public _upType: number = 0;
    public hasShowBonusTips: boolean = false;
    public _hideBonusTipsAct: any = null;
    public _hasUpBtn: boolean = false;
    public _lastClick: number = 0;
    public _rankAct: any = null;
    public hasShowRank: boolean = false;
    onLoad() {
        this.bIsInGame = true;
        this.ItemBg.active = false;
        this.ItemJiasaiBg.active = false;
        PushCenter.shared().addListener(PushEvent.RummyGameTotalSettlementTime, (e => {
            this.showTimeCountdown(e);
        }), this);
    }
    start() {
        super.start();
        ToolUtils.showFullScreen(this.node.getChildByName("bg1"));
        PushCenter.shared().addListener(PushEvent.HideGameOverBg, (e => {
            this.node.getChildByName("bg1").active = false;
        }), this);
        PushCenter.shared().addListener(PushEvent.ShowGameOverBg, (e => {
            this.node.getChildByName("bg1").active = true;
        }), this);
        PushCenter.shared().addListener(PushEvent.Update_Gullak_State, (e => {
            if (ToolUtils.isObjValid(this.node)) {
                let e = RummyDataManager.shared().rummyInfos.get(this.tid_key) || null;
                sys.isObjectValid(e) && 0 == e.crashModel && this.updateGullakBtnStatus(User.shared().act_68_open, User.shared().act_68_full_status, true);
            }
        }), this);
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().removeListenersByTag(this);
        let e = RummyDataManager.shared().rummyInfos.get(this.tid_key) || null;
        sys.isObjectValid(e) && (e.pool_rummy_all_end_data = null, e.is_game_all_end = -1, e.hasShowTotalSettlement = false);
        PushCenter.shared().pushEvent(PushEvent.ShowWinShareBtn, false);
    }
    initView(e, t, i) {
        this.data = e;
        this.gameController = t;
        this.tid_key = i;
        let a = RummyDataManager.shared().rummyInfos.get(this.tid_key) || null, s = [[v3(0, 32)], [v3(-100, 32), v3(100, 32)], [v3(-200, 32), v3(0, 32), v3(200, 32)], [v3(-300, 32), v3(-100, 32), v3(100, 32), v3(300, 32)], [v3(-388, 32), v3(-194, 32), v3(0, 32), v3(194, 32), v3(388, 32)], [v3(-485, 32), v3(-291, 32), v3(-97, 32), v3(97, 32), v3(291, 32), v3(485, 32)]], o = e.settleinfo;
        if (!sys.isObjectValid(o)) {
            return void (ToolUtils.isObjValid(this.node) && this.node.destroy());
        }
        let n = o.length, l = [];
        null != e.hide_start && (this.hide_start = e.hide_start);
        1 == e.isWatching && (this.bgView.getChildByName("tltle_img").getComponent(Sprite).spriteFrame = this.title_result_img[0]);
        this._bIsMyWin = false;
        for (let e = 0; e < n; e++) {
            o[e].uid == User.shared().data.uid && (this._bIsMyWin = Number(o[e].prize) > 0, this._bIsMyWin && sys.isObjectValid(o[e].rank_info) && o[e].rank_info, l.unshift(o[e]), o[e].prize > 0 ? (this.bgView.getChildByName("tltle_img").getComponent(Sprite).spriteFrame = this.title_win_img[0], this.b_isPlayEff && (SoundManager.shared().playFx("rummyWin"), this.b_isPlayEff = false), a && 0 == a.crashModel && (User.shared().lastWinGameInfo = { nVid: a.vid, nScore: o[e].prize })) : (this.bgView.getChildByName("tltle_img").getComponent(Sprite).spriteFrame = this.title_lose_img[0], User.shared().lastWinGameInfo = { nVid: -1, nScore: 0 }));
        }
        for (let e = 0; e < n; e++) {
            o[e].uid != User.shared().data.uid && l.push(o[e]);
        }
        this.removeListItem();
        for (let t = 0; t < l.length; t++) {
            let i = l[t].avatar, o = l[t].avatar_url, m = (l[t].club_level, 0);
            sys.isObjectValid(l[t].avatar_frame_id) && (m = l[t].avatar_frame_id);
            let b = null;
            b = 1 == e.isTieBreak ? instantiate(this.ItemJiasaiBg) : instantiate(this.ItemBg);
            b.active = true;
            b.setPosition(s[n - 1][t]);
            this.bgView.addChild(b);
            let p = { item: b, seatid: l[t].seatid, players: l[t] };
            if (this.itemViewDate[t] = p, b.getChildByName("name").getComponent(Label).string = ToolUtils.GetShortName2(l[t].name, 9, false), Utils.shared().updateHeadImg(b.getChildByName("head_mask").getChildByName("head"), i, o, size(100, 100)), sys.isObjectValid(User.shared().data.club) && 1 == User.shared().data.club.show_room_avatar_frame) {
                let e = m;
                b.getChildByName("club_kuang").active = e > 0;
                e > 0 && e <= 9 && Utils.shared().setImage(b.getChildByName("club_kuang"), ToolUtils.format("club_headkuang${0}", e), this.clubKuangAtlas);
            }
            b.getChildByName("score_text").getComponent(Label).string = i18nMgr.shared().getValueByKey("rummy_main.pts") + l[t].total_score;
            i18nMgr.shared().changeLabelFont(b.getChildByName("score_text").getComponent(Label));
            1 == l[t].isTieBreak ? (b.getChildByName("win_or_lose").getComponent(Label).fontSize = 24, i18nMgr.shared().changeLabelLanguage(b.getChildByName("win_or_lose").getComponent(Label), "gameRummy_TotalSettlement.tie_breaker", true), b.getChildByName("win_or_lose").getComponent(Label).color = color(102, 102, 102)) : (0 == l[t].disuse && 1 != e.all_end) || (-1 == l[t].prize ? (b.getChildByName("win_or_lose").getComponent(Label).fontSize = 30, i18nMgr.shared().changeLabelLanguage(b.getChildByName("win_or_lose").getComponent(Label), "gameRummy_TotalSettlement.playing", true), b.getChildByName("win_or_lose").getComponent(Label).color = color(102, 102, 102)) : l[t].prize > 0 ? (b.getChildByName("win_or_lose").getComponent(Label).fontSize = 36, a && 1 == a.crashModel ? b.getChildByName("win_or_lose").getComponent(Label).string = "+" + ToolUtils.parse_ChipNum2(l[t].prize) : b.getChildByName("win_or_lose").getComponent(Label).string = "+₹" + ToolUtils.parse_double(l[t].prize), b.getChildByName("win_or_lose").getComponent(Label).color = color(0, 141, 21)) : (b.getChildByName("win_or_lose").getComponent(Label).fontSize = 30, i18nMgr.shared().changeLabelLanguage(b.getChildByName("win_or_lose").getComponent(Label), "gameRummy_TotalSettlement.lost", true), b.getChildByName("win_or_lose").getComponent(Label).color = color(102, 102, 102)));
            1 == e.isTieBreak && ToolUtils.isObjValid(b.getChildByName("tie_breask2")) && (null != l[t].tie_break_score && null != l[t].tie_break_score[0] ? (b.getChildByName("tie_breask2").getComponent(Label).string = "" + l[t].tie_break_score[0], b.getChildByName("tie_breask3").active = false) : (b.getChildByName("tie_breask3").active = true, b.getChildByName("tie_breask1").active = false, b.getChildByName("tie_breask2").active = false), null != l[t].tie_break_score && null != l[t].tie_break_score[1] ? (b.getChildByName("tie_breask5").getComponent(Label).string = "" + l[t].tie_break_score[1], b.getChildByName("tie_breask6").active = false) : (b.getChildByName("tie_breask6").active = true, b.getChildByName("tie_breask4").active = false, b.getChildByName("tie_breask5").active = false));
            let y = b.getChildByName("auto_split"), C = false;
            sys.isObjectValid(y) && (sys.isObjectValid(l[t].auto_split) && (C = 1 == l[t].auto_split), y.active = C);
            let B = false;
            if (l[t].uid == User.shared().data.uid) {
                if (b.getChildByName("ME").active = true, b.getChildByName("ME").getComponent(Sprite).spriteFrame = this.me_flag_img[0], 0 == a.crashModel && l[t].prize <= 0 && sys.isObjectValid(l[t].tf_bonus) && l[t].tf_bonus > 0) {
                    let e = "bonus_tips_" + t;
                    if (b.getChildByName("bonus_btn").getComponent(Button).clickEvents[0].customEventData = e, sys.isObjectValid(l[t].bonus_incr_rate) && l[t].bonus_incr_rate > 0) {
                        B = true;
                        let e = 100 * Number(ToolUtils.parse_double(l[t].bonus_incr_rate));
                        b.getChildByName("bonus_btn").getChildByName("Label").getComponent(Label).string = `+${e}%`;
                    }
                }
            }
            else {
                b.getChildByName("ME").active = false;
            }
            if (b.getChildByName("bonus_btn").active = B, a && (a.gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL || a.gameRummyType == RUMMY_GAME_TYPE.PRI_POOL)) {
                1 == a.playerModels[l[t].seatid].ready && (l[t].uid == User.shared().data.uid && 1 == e.isWatching ? b.getChildByName("head_mask").getChildByName("head").getChildByName("ready").active = false : b.getChildByName("head_mask").getChildByName("head").getChildByName("ready").active = true);
            }
            this.updateItemStyle(1 == e.isTieBreak, l[t].prize, b);
        }
        this.bonusTipsMask.setSiblingIndex(10000);
        1 == e.end_type ? this.bgView.getChildByName("explanation").active = true : this.bgView.getChildByName("explanation").active = false;
        let b = this.bgView.getChildByName("start_btn");
        0 !== this.hide_start && (b.active = false, this.bgView.getChildByName("exit_btn").setPosition(v3(0, -190.826, 0)));
        sys.isObjectValid(e.force_up_venue_tips_end) && 1 == ToolUtils.isSafeNumber(e.force_up_venue_tips_end.show) && (a.force_up_venue_tips_end = e.force_up_venue_tips_end, b.getComponent(Button).clickEvents[0].customEventData = "continue");
        this._hasUpBtn = false;
        sys.isObjectValid(e.up_venue) ? 1 == a.crashModel ? this.show_up_btn(e.up_venue, 1) : this.show_up_btn(e.up_venue, 0) : 1 == a.crashModel && sys.isObjectValid(e.tf_venue) ? this.show_up_btn(e.tf_venue, 2) : 0 != a.crashModel || a.gameRummyType !== RUMMY_GAME_TYPE.DEALS && a.gameRummyType !== RUMMY_GAME_TYPE.POOL || (b.setPosition(v3(0, -190.826, 0)), this.bgView.getChildByName("exit_btn").active = false, this.bgView.getChildByName("exit_btn2").active = true);
        a && a.gameRummyType === RUMMY_GAME_TYPE.DEALS && (this.bgView.getChildByName("close_btn").active = 1 === ToolUtils.isSafeNumber(e.show_close_btn));
        a && (a.hasShowTotalSettlement = true);
        1 == User.shared().isInPerformanceRoom ? (this.bgView.getChildByName("start_btn").active = false, this.bgView.getChildByName("exit_btn").active = false, this.bgView.getChildByName("start_btn").setPosition(v3(0, -190.826)), this.bgView.getChildByName("close_btn").active = false) : a && (0 != a.crashModel || a.gameRummyType !== RUMMY_GAME_TYPE.DEALS && a.gameRummyType !== RUMMY_GAME_TYPE.POOL ? (this.bgView.getChildByName("exit_btn").active = true, this.bgView.getChildByName("exit_btn2").active = false) : (this.bgView.getChildByName("exit_btn").active = false, this.bgView.getChildByName("exit_btn2").active = true));
        this.checkShowShareBtn();
        PushCenter.shared().pushEvent(PushEvent.GameOverShowFreeMatchPush);
        0 == a.crashModel && a.gameRummyType != RUMMY_GAME_TYPE.MATCH && 0 == a.crashModel && this.updateGullakBtnStatus(User.shared().act_68_open, User.shared().act_68_full_status, false);
        PushCenter.shared().pushEvent(PushEvent.Update_CheckFlopTaskGame, this.tid_key);
    }
    updateGullakBtnStatus(e, t, i) {
        let a = this.bgView.getChildByName("gullak_btn");
        if (ToolUtils.isObjValid(a) && (a.active = 1 == e, 1 == e)) {
            let e = a.getChildByName("anim").getComponent(sp.Skeleton);
            e.clearTracks();
            e.setToSetupPose();
            i ? (e.setAnimation(0, "2", false), e.setCompleteListener((() => {
                e.setCompleteListener(null);
                e.clearTracks();
                e.setToSetupPose();
                0 == t ? e.setAnimation(0, "0", true) : e.setAnimation(0, "1", true);
            }))) : 0 == t ? e.setAnimation(0, "0", true) : e.setAnimation(0, "1", true);
        }
    }
    refreshRoomActAnim() {
    }
    showRoomActAnim(e) {
        this.bgView.getChildByName("rank_act").active = false;
    }
    updateItemStyle(e, t, i) {
        t > 0 ? (i.getComponent(Sprite).spriteFrame = this.item_bg_img[1], sys.isObjectValid(i.getChildByName("scorebg")) && (i.getChildByName("scorebg").getComponent(Sprite).color = this.scoreBg_colors[1]), i.getChildByName("win_or_lose").getComponent(Label).color = this.win_lost_colors[1], e && (sys.isObjectValid(i.getChildByName("break_bg1")) && (i.getChildByName("break_bg1").getComponent(Sprite).color = this.break_bg1_colors[1]), sys.isObjectValid(i.getChildByName("break_bg2")) && (i.getChildByName("break_bg2").getComponent(Sprite).color = this.break_bg1_colors[1]))) : (i.getComponent(Sprite).spriteFrame = this.item_bg_img[0], sys.isObjectValid(i.getChildByName("scorebg")) && (i.getChildByName("scorebg").getComponent(Sprite).color = this.scoreBg_colors[0]), i.getChildByName("win_or_lose").getComponent(Label).color = this.win_lost_colors[0], e && (sys.isObjectValid(i.getChildByName("break_bg1")) && (i.getChildByName("break_bg1").getComponent(Sprite).color = this.break_bg1_colors[0]), sys.isObjectValid(i.getChildByName("break_bg2")) && (i.getChildByName("break_bg2").getComponent(Sprite).color = this.break_bg1_colors[0])));
    }
    show_up_btn(e, t) {
        let i = this.bgView.getChildByName("up_btn");
        if (i) {
            if (i.active = true, this._upType = t, this._upvenue_fee = -1, sys.isObjectValid(e.entry_fee) && (this._upvenue_fee = Number(e.entry_fee)), sys.isObjectValid(e.base_money) && (i.getChildByName("root").getChildByName("num").getComponent(Label).string = 1 == t ? ToolUtils.parse_double(String(e.base_money), -1) : "₹" + ToolUtils.parse_double(String(e.base_money), -1)), 0 == t) {
                let e = this.bgView.getChildByName("start_btn");
                e.setPosition(v3(-120, -190.826));
                1 == i18nMgr.shared().language && (i.getChildByName("root").getChildByName("wz").active = false, i.getChildByName("root").getChildByName("wz1").active = true);
                ToolUtils.isObjValid(this.bgView.getChildByName("up_tocash")) && (this.bgView.getChildByName("up_tocash").active = false);
                ToolUtils.isObjValid(this.bgView.getChildByName("up_tip_practice")) && (this.bgView.getChildByName("up_tip_practice").active = false);
                this.bgView.getChildByName("up_tip") && (this.bgView.getChildByName("up_tip").active = true, this.bgView.getChildByName("up_tip").setSiblingIndex(100), this.bgView.getChildByName("up_tip").setPosition(v3(122, -264.682)));
                e.getComponent(Sprite).spriteFrame = this.btn_imgs[2];
                Utils.updateLabelMaterial(e.getChildByName("wz"), CommDefine.gradient.btn_blue);
                e.getChildByName("wz").getComponent(LabelShadow).color = CommDefine.shadowcolor.blue;
                i.getComponent(Sprite).spriteFrame = this.btn_imgs[0];
                i.setPosition(v3(120, -190.826));
                Utils.updateLabelMaterial(i.getChildByName("root").getChildByName("wz"), CommDefine.gradient.btn_green);
                Utils.updateLabelMaterial(i.getChildByName("root").getChildByName("num"), CommDefine.gradient.btn_green);
                Utils.updateLabelMaterial(i.getChildByName("root").getChildByName("wz1"), CommDefine.gradient.btn_green);
                i.getChildByName("root").getChildByName("wz").getComponent(LabelShadow).color = CommDefine.shadowcolor.green;
                i.getChildByName("root").getChildByName("num").getComponent(LabelShadow).color = CommDefine.shadowcolor.green;
                i.getChildByName("root").getChildByName("wz1").getComponent(LabelShadow).color = CommDefine.shadowcolor.green;
                this._hasUpBtn = true;
            }
            else if (1 == i18nMgr.shared().language && (i.getChildByName("root").getChildByName("wz").active = false, i.getChildByName("root").getChildByName("wz1").active = true), ToolUtils.isObjValid(this.bgView.getChildByName("up_tip")) && (this.bgView.getChildByName("up_tip").active = false), 2 == t) {
                if (ToolUtils.isObjValid(this.bgView.getChildByName("up_tip_practice")) && (this.bgView.getChildByName("up_tip_practice").active = false), ToolUtils.isObjValid(this.bgView.getChildByName("up_tocash"))) {
                    if (RummyDataManager.shared().hasCloseUpToCashTips) {
                        this.bgView.getChildByName("up_tocash").active = false;
                    }
                    else if (RummyDataManager.shared().enterPracticeCount + 1 <= RummyDataManager.shared().rummyInfos.get(this.tid_key).tf_entry_tips_times) {
                        let e = sys.localStorage.getItem("tf_show_tips_count_" + User.shared().data.uid);
                        null == e || Number.isNaN(Number(e)) ? e = 1 : (e = Number(e), e += 1);
                        e <= RummyDataManager.shared().rummyInfos.get(this.tid_key).tf_max_tips_times ? (RummyDataManager.shared().enterPracticeCount += 1, ToolUtils.saveData("tf_show_tips_count_" + User.shared().data.uid, "" + e), this.bgView.getChildByName("up_tocash").active = true, this.bgView.getChildByName("up_tocash").setSiblingIndex(100)) : this.bgView.getChildByName("up_tocash").active = false;
                    }
                    else {
                        this.bgView.getChildByName("up_tocash").active = false;
                    }
                }
                this.bgView.getChildByName("start_btn").setPosition(v3(-1.017, -190.826));
                i18nMgr.shared().changeLocalizedLabelKey(this.bgView.getChildByName("start_btn").getChildByName("wz"), "deposit.continue");
                this.bgView.getChildByName("start_btn").getChildByName("wz").getComponent(Label).string = i18nMgr.shared().getValueByKey("deposit.continue");
                this.bgView.getChildByName("exit_btn").setPosition(v3(-240.631, -190.826));
                i.getComponent(Sprite).spriteFrame = this.btn_imgs[1];
                i.setPosition(v3(238.949, -190.826));
                this.bgView.getChildByName("up_tocash").setPosition(v3(238.949, -264.902));
                Utils.updateLabelMaterial(i.getChildByName("root").getChildByName("wz"), CommDefine.gradient.btn_orange);
                Utils.updateLabelMaterial(i.getChildByName("root").getChildByName("num"), CommDefine.gradient.btn_orange);
                Utils.updateLabelMaterial(i.getChildByName("root").getChildByName("wz1"), CommDefine.gradient.btn_orange);
                i.getChildByName("root").getChildByName("wz").getComponent(LabelShadow).color = CommDefine.shadowcolor.orange;
                i.getChildByName("root").getChildByName("num").getComponent(LabelShadow).color = CommDefine.shadowcolor.orange;
                i.getChildByName("root").getChildByName("wz1").getComponent(LabelShadow).color = CommDefine.shadowcolor.orange;
            }
            else {
                1 == t && (ToolUtils.isObjValid(this.bgView.getChildByName("up_tocash")) && (this.bgView.getChildByName("up_tocash").active = false), ToolUtils.isObjValid(this.bgView.getChildByName("up_tip_practice")) && (this.bgView.getChildByName("up_tip_practice").active = true, this.bgView.getChildByName("up_tip_practice").setSiblingIndex(100)), this.bgView.getChildByName("start_btn").active = false, this.bgView.getChildByName("exit_btn").setPosition(v3(-119, -190.826)), i.getComponent(Sprite).spriteFrame = this.btn_imgs[0], i.setPosition(v3(120, -190.826)), this.bgView.getChildByName("up_tip_practice").setPosition(v3(120, -264.98)), Utils.updateLabelMaterial(i.getChildByName("root").getChildByName("wz"), CommDefine.gradient.btn_green), Utils.updateLabelMaterial(i.getChildByName("root").getChildByName("num"), CommDefine.gradient.btn_green), Utils.updateLabelMaterial(i.getChildByName("root").getChildByName("wz1"), CommDefine.gradient.btn_green), i.getChildByName("root").getChildByName("wz").getComponent(LabelShadow).color = CommDefine.shadowcolor.green, i.getChildByName("root").getChildByName("num").getComponent(LabelShadow).color = CommDefine.shadowcolor.green, i.getChildByName("root").getChildByName("wz1").getComponent(LabelShadow).color = CommDefine.shadowcolor.green);
            }
        }
    }
    isAlreadyShow() {
        return this.bgView.active;
    }
    checkShowShareBtn() {
        RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType != RUMMY_GAME_TYPE.PRI_DEAL && RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType != RUMMY_GAME_TYPE.PRI_POOL || this._bIsMyWin && PushCenter.shared().pushEvent(PushEvent.ShowWinShareBtn, true);
    }
    removeListItem() {
        for (let e = 0, t = this.itemViewDate.length; e < t; e++) {
            if (sys.isObjectValid(this.itemViewDate[e])) {
                let t = this.itemViewDate[e].item;
                ToolUtils.isObjValid(t) && t.destroy();
            }
        }
        this.itemViewDate = [];
    }
    touchBtnEvent(e, t) {
        if (SoundManager.shared().playFx("click"), !(sys.now() - this._lastClick < 1000)) {
            if (this._lastClick = sys.now(), "exit" == t) {
                RummyDataManager.shared().rummyInfos.get(this.tid_key).isInGameing = 0;
                this.gameController.exitCallBack(1);
                ToolUtils.isObjValid(this.node) && this.node.destroy();
            }
            else if ("up" == t) {
                0 == this._upType || 1 == this._upType ? (User.shared().send_client_consume_table_record_laba(this.tid_key), this.gameController.upvenue_entry_fee = this._upvenue_fee, this.gameController.onDealBtnAction("up")) : this.gameController.onDealBtnAction("practice_to_cash");
            }
            else if ("start" == t) {
                User.shared().send_client_consume_table_record_laba(this.tid_key);
                this.gameController.onDealBtnAction("start");
                RummyDataManager.shared().rummyInfos.has(this.tid_key) && (1 == RummyDataManager.shared().rummyInfos.get(this.tid_key).crashModel ? User.shared().data.money_exe >= RummyDataManager.shared().rummyInfos.get(this.tid_key).entry_fee && ToolUtils.isObjValid(this.node) && this.node.destroy() : User.shared().data.money >= RummyDataManager.shared().rummyInfos.get(this.tid_key).entry_fee && (RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType !== RUMMY_GAME_TYPE.PRI_DEAL && RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType !== RUMMY_GAME_TYPE.PRI_POOL || PushCenter.shared().pushEvent(PushEvent.ShowPrivateInviteBtn, this.tid_key), ToolUtils.isObjValid(this.node) && this.node.destroy()));
            }
            else if ("score" == t) {
                this.gameController.showTotalSettlementInfo();
            }
            else if ("close" == t) {
                1 == this.typeNum && this.gameController.exitCallBack(1);
            }
            else if ("settle_close" == t) {
                RummyDataManager.shared().send_request_close_out_ui(this.tid_key);
                ToolUtils.isObjValid(this.node) && this.node.destroy();
            }
            else if ("up_tip_close" == t) {
                this.bgView.getChildByName("up_tip").active = false;
            }
            else if ("up_tocash_close" == t) {
                RummyDataManager.shared().hasCloseUpToCashTips = true;
                this.bgView.getChildByName("up_tocash").active = false;
            }
            else if ("up_tip_practice_close" == t) {
                this.bgView.getChildByName("up_tip_practice").active = false;
            }
            else if (-1 != t.indexOf("bonus_tips")) {
                if (this.bonusTipsMask.active) {
                    return void this.onCloseItemHelpTips(null);
                }
                let e = parseInt(t.substring("bonus_tips_".length));
                for (let t = 0, i = this.itemViewDate.length; t < i; t++) {
                    if (t == e) {
                        if (ToolUtils.isObjValid(this.itemViewDate[t].item)) {
                            this.bonusTipsMask.active = true;
                            let e = this.itemViewDate[t].item, i = e.children.length + 1;
                            e.getChildByName("bonus_btn").setSiblingIndex(i);
                            let a = e.getPosition();
                            if (sys.isObjectValid(this.itemViewDate[t].players.bonus_incr_rate)) {
                                let e = 100 * Number(ToolUtils.parse_double(this.itemViewDate[t].players.bonus_incr_rate));
                                this.bonusTipsMask.getChildByName("Label").getComponent(Label).string = ToolUtils.format("BONUS transtion extra ${0}%", e);
                            }
                            this.bonusTipsMask.getComponent(UITransform).contentSize = size(270, 35);
                            this.bonusTipsMask.setPosition(v3(a.x, -123.015));
                            this.bonusTipsMask.setSiblingIndex(10000);
                        }
                        break;
                    }
                }
            }
            else {
                "close_bonus_tips" == t ? this.onCloseItemHelpTips(null) : "continue" == t ? this.gameController.onDealBtnAction("continue") : "gullak_gameover" == t && this.gameController.onDealBtnAction("gullak_gameover");
            }
        }
    }
    onCloseItemHelpTips(e, t = "") {
        ToolUtils.isObjValid(this.bonusTipsMask) && this.bonusTipsMask.active && (this.bonusTipsMask.active = false);
        this._hideBonusTipsAct && (TweenTool.stopAction(this._hideBonusTipsAct), this._hideBonusTipsAct = null);
    }
    showReadyView(e, t) {
        if (RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL || RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType == RUMMY_GAME_TYPE.PRI_POOL) {
            for (let i = 0, a = this.itemViewDate.length; i < a; i++) {
                this.itemViewDate[i].seatid == e && (this.itemViewDate[i].getChildByName("head_mask").getChildByName("head").getChildByName("ready").active = t);
            }
        }
    }
    showTimeCountdown(e) {
        1 != User.shared().isInPerformanceRoom && (this.gameTipsTextTimeAction && (TweenTool.stopAction(this.gameTipsTextTimeAction), this.gameTipsTextTimeAction = null), null != e && e > 0 && (this.downTime.active = true, this.downTime.getComponent(Label).string = "(" + e + "s)", this.gameTipsTextTime = e, this.gameTipsTextTimeAction = TweenTool.myschedule(this.node, 1, this.updateTipsTimeText.bind(this))));
    }
    updateTipsTimeText() {
        this.gameTipsTextTime = this.gameTipsTextTime - 1;
        this.gameTipsTextTime < 0 ? this.gameTipsTextTimeAction && (TweenTool.stopAction(this.gameTipsTextTimeAction), this.gameTipsTextTimeAction = null, ToolUtils.isObjValid(this.node) && this.node.destroy()) : (this.downTime.active = true, this.downTime.getComponent(Label).string = "(" + this.gameTipsTextTime + "s)");
    }
    onBackView() {
    }
}
