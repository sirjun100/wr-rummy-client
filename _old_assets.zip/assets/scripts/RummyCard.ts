// @ts-nocheck
// Recovered from index.js:427
import { _decorator, Component, color, Label, Node, size, sp, Sprite, SpriteAtlas, SpriteFrame, sys, UIOpacity, UITransform, v3, Vec3 } from "cc";
import PushCenter from "./PushCenter";
import { ToolUtils } from "./ToolUtils";
import TweenTool from "./TweenTool";
import Utils from "./Utils";
import PushEvent from "./PushEvent";
import User from "./User";
import SoundManager from "./SoundManager";
import RummyDataManager from "./RummyDataManager";
const { ccclass, property } = _decorator;
@ccclass("RummyCard")
export default class RummyCard extends Component {
    @property(Node)
    public frontView: Node = null;
    @property(Node)
    public backView: Node = null;
    @property([SpriteAtlas])
    public cardbgs: SpriteAtlas[] = [];
    @property([SpriteAtlas])
    public card: SpriteAtlas[] = [];
    @property(Node)
    public valueSp: Node = null;
    @property(Node)
    public laiziDiSp: Node = null;
    @property(Node)
    public laizi_img: Node = null;
    @property(Node)
    public maskSp: Node = null;
    @property(SpriteAtlas)
    public myAtlas: SpriteAtlas = null;
    @property(Node)
    public newSp: Node = null;
    @property(Node)
    public glowSp: Node = null;
    @property(Node)
    public discardTipsSp: Node = null;
    @property(Node)
    public flashAnim: Node = null;
    @property([SpriteAtlas])
    public smallCardAtlas: SpriteAtlas[] = [];
    @property(SpriteAtlas)
    public smallCardbg: SpriteAtlas = null;
    @property(SpriteAtlas)
    public robotCardAtlas: SpriteAtlas = null;
    @property(SpriteFrame)
    public bumpBigLaizi: SpriteFrame = null;
    @property(SpriteFrame)
    public bumpSmallLaizi: SpriteFrame = null;
    @property(SpriteFrame)
    public clubBigLaizi: SpriteFrame = null;
    @property(SpriteFrame)
    public clubSmallLaizi: SpriteFrame = null;
    @property(Node)
    public tingpaiTipsNode: Node = null;
    @property(Node)
    public tingpaiTips2Node: Node = null;
    public mCardValue: any = undefined;
    public hasShowBg: any = undefined;
    public hasSelected: boolean = false;
    public hasSelecting: boolean = false;
    public _touchBeginX: any = undefined;
    public _touchEndX: any = undefined;
    public _touchBeginY: any = undefined;
    public _touchEndY: any = undefined;
    public _cardWidth: any = undefined;
    public _cardHeight: any = undefined;
    public _nTag: number = 0;
    public hasSelectNew: any = undefined;
    public selectedPosY: any = -150;
    public unSelectedPosY: any = -180;
    public cardIndex: any = undefined;
    public groupIndex: any = undefined;
    public fromToCardIndex: any = undefined;
    public fromToGroupIndex: any = undefined;
    public beforeMovingPos: Vec3 = new Vec3;
    public AfterMovingPos: Vec3 = new Vec3;
    public rowType: any = undefined;
    public lastCardIndex: any = undefined;
    public isZhuang: boolean = false;
    public isNewCard: boolean = false;
    public groupCardVecLenth: number = 0;
    public totalIndex: any = -1;
    public groupColor: any = -1;
    public groupText: string = "";
    public _callback: any = null;
    public _mFinish_num: number = 0;
    public tingpai_type: number = 0;
    public groupType: number = 0;
    public _type: number = 0;
    resetCards() {
        this.mCardValue = 0;
        this.hasShowBg = false;
        this.hasSelected = false;
        this.hasSelecting = false;
        this._touchBeginX = null;
        this._touchEndX = null;
        this._touchBeginY = null;
        this._touchEndY = null;
        this._cardWidth = null;
        this._cardHeight = null;
        this._nTag = 0;
        this.hasSelectNew = null;
        this.selectedPosY = -150;
        this.unSelectedPosY = -180;
        this.cardIndex = null;
        this.groupIndex = null;
        this.fromToCardIndex = null;
        this.fromToGroupIndex = null;
        this.beforeMovingPos = new Vec3;
        this.AfterMovingPos = new Vec3;
        this.rowType = null;
        this.lastCardIndex = null;
        this.isZhuang = false;
        this.groupCardVecLenth = 0;
        this.totalIndex = -1;
        this.groupColor = -1;
        this.groupText = "";
        this.maskSp.active = false;
        this.newSp.active = false;
        this.glowSp.active = false;
        this.discardTipsSp && (this.discardTipsSp.active = false);
        this.laiziDiSp.active = this.laizi_img.active = true;
        this.node.angle = 0;
        this.backView.active = true;
        this.isNewCard = false;
        TweenTool.stopNodeAction(this.node);
        this.initChangeOpacity(255);
        this.tingpaiTipsNode && (this.tingpaiTipsNode.active = false);
        this.tingpaiTips2Node && (this.tingpaiTips2Node.active = false);
        this._callback = null;
        this.tingpai_type = 0;
        this.changeTingPaiLightSelectVisible(false);
        ToolUtils.isObjValid(this.flashAnim) && (this.flashAnim.active = false);
    }
    onLoad() {
    }
    onDestroy() {
        this.unscheduleAllCallbacks();
    }
    init(i, t = false, e = 0) {
        if (this.mCardValue = i, this.hasShowBg = t, this._nTag = i, this._type = e, this.lastCardIndex = -1, this.laizi_img.setScale(v3(1, 1, 1)), 1 == this._type) {
            let i = "s_card_front", t = "s_rm_kingcard_mask", e = "s_rm_img_laizi", a = 0;
            Utils.shared().setImage(this.frontView, i, this.smallCardAtlas[a]);
            Utils.shared().setImage(this.backView, "rummy_small_card_bg_0" + User.shared().styles[2], this.smallCardbg);
            Utils.shared().setImage(this.laiziDiSp, t, this.smallCardAtlas[a]);
            Utils.shared().setImage(this.laizi_img, e, this.smallCardAtlas[a]);
        }
        else if (2 == this._type) {
            this.laiziDiSp.active = this.laizi_img.active = false;
            Utils.shared().setImage(this.frontView, "rb_card_front", this.robotCardAtlas);
        }
        else if (4 == this._type) {
            let i = "s_card_front", t = "s_rm_kingcard_mask", e = 0;
            sys.isObjectValid(this.bumpSmallLaizi) && (this.laizi_img.getComponent(Sprite).spriteFrame = this.bumpSmallLaizi);
            Utils.shared().setImage(this.frontView, i, this.smallCardAtlas[e]);
            Utils.shared().setImage(this.backView, "rummy_small_card_bg_0" + User.shared().styles[2], this.smallCardbg);
            Utils.shared().setImage(this.laiziDiSp, t, this.smallCardAtlas[e]);
        }
        else {
            Utils.shared().setImage(this.frontView, "card_front", this.card[0]);
            Utils.shared().setImage(this.backView, "rummy_card_bg_0" + User.shared().styles[2], this.cardbgs[0]);
        }
        const a = this.backView.getComponent(UIOpacity), s = this.frontView.getComponent(UIOpacity);
        t ? (a.opacity = 255, this.backView.active = true, s.opacity = 0, this.frontView.active = false) : (this.backView.active = false, this.frontView.active = true, s.opacity = 255, a.opacity = 0);
        const l = this.laiziDiSp.getComponent(UIOpacity), n = this.laizi_img.getComponent(UIOpacity);
        if (l.opacity = n.opacity = 0, this.mCardValue > 0 || this.mCardValue < 80) {
            let i = "rm_scard_" + ToolUtils.cardTo16(this.mCardValue);
            1 == this._type || 4 == this._type ? (i = "s_rm_scard_" + ToolUtils.cardTo16(this.mCardValue), Utils.shared().setImage(this.valueSp, i, this.smallCardAtlas[0])) : 2 == this._type ? (i = "rb_scard_" + ToolUtils.cardTo16(this.mCardValue), Utils.shared().setImage(this.valueSp, i, this.robotCardAtlas)) : (User.shared().styles[1] - 1 == 2 && (i = "club_rm_scard_" + ToolUtils.cardTo16(this.mCardValue)), Utils.shared().setImage(this.valueSp, i, this.card[0]));
            const e = this.valueSp.getComponent(UIOpacity);
            t ? (e.opacity = 0, this.valueSp.active = false) : (e.opacity = 255, this.valueSp.active = true);
        }
        this.hasSelected = false;
        this.hasSelecting = false;
    }
    refreshcardbg(i) {
        Utils.shared().setImage(this.backView, i, this.cardbgs[0]);
    }
    refreshcard(i, t) {
        sys.isObjectValid(this.card[t]) && Utils.shared().setImage(this.valueSp, i, this.card[t]);
    }
    refreshlazi(i, t) {
        sys.isObjectValid(this.card[t]) && Utils.shared().setImage(this.laiziDiSp, i, this.card[t]);
        let e = "rm_img_laizi";
        User.shared().styles[1] - 1 == 2 && (e = "club_rm_img_laizi");
        Utils.shared().setImage(this.laizi_img, e, this.card[0]);
    }
    setCardTag(i) {
        "number" != typeof (i = parseInt("" + i)) || i < 0 || (this._nTag = i);
    }
    getCardTag() {
        return this._nTag;
    }
    setCardTouchAreaX(i, t) {
        this._touchBeginX = i;
        this._touchEndX = t;
    }
    setCardTouchAreaY(i, t) {
        this._touchBeginY = i;
        this._touchEndY = t;
    }
    setCardSize(i, t) {
        this._cardWidth = i;
        this._cardHeight = t;
    }
    isContainPos(i, t) {
        let e = this.selectedPosY - this.unSelectedPosY, a = (this.node.getWorldPosition(), new Vec3);
        this.node.getPosition(a);
        let s = i.x, l = i.y;
        if (s >= a.x - this._touchBeginX && s <= a.x + this._touchEndX) {
            if (this.hasSelected) {
                if (l >= a.y - this._touchBeginY - e && l <= a.y + this._touchEndY) {
                    return true;
                }
            }
            else if (l >= a.y - this._touchBeginY && l <= a.y + this._touchEndY) {
                return true;
            }
        }
        return false;
    }
    changeCardSelectedStatus(i) {
        this.hasSelecting = i;
        this.hasSelectNew = i;
    }
    changeCardColor(i) {
        let t = color(255, 255, 255), e = color(130, 130, 130), a = t;
        a = i ? e : t;
        this.valueSp.getComponent(Sprite).color = a;
        this.frontView.getComponent(Sprite).color = a;
        this.laiziDiSp.getComponent(Sprite).color = a;
    }
    changeOpacity(i) {
        const t = this.valueSp.getComponent(UIOpacity), e = this.frontView.getComponent(UIOpacity), a = this.laiziDiSp.getComponent(UIOpacity), s = this.laizi_img.getComponent(UIOpacity);
        t.opacity = i;
        e.opacity = i;
        a.opacity = s.opacity = i;
    }
    initChangeOpacity(i) {
        const t = this.valueSp.getComponent(UIOpacity), e = this.frontView.getComponent(UIOpacity), a = this.laiziDiSp.getComponent(UIOpacity), s = this.laizi_img.getComponent(UIOpacity), l = this.backView.getComponent(UIOpacity);
        t.opacity = i;
        e.opacity = i;
        a.opacity = s.opacity = i;
        l.opacity = i;
        this.node.getComponent(UIOpacity).opacity = i;
    }
    changeCardStatus(i) {
        this.hasSelected = i;
        this.hasSelecting = false;
        let t = new Vec3;
        this.node.getPosition(t);
        this.hasSelected ? this.node.setPosition(v3(t.x, this.selectedPosY, t.y)) : this.node.setPosition(v3(t.x, this.unSelectedPosY, t.y));
    }
    openCard() {
        this.backView.active = false;
        this.frontView.active = true;
        this.valueSp.active = true;
        this.hasShowBg = false;
        const i = this.backView.getComponent(UIOpacity), t = this.frontView.getComponent(UIOpacity), e = this.valueSp.getComponent(UIOpacity);
        i.opacity = 0;
        t.opacity = 255;
        e.opacity = 255;
    }
    changeCardToBack() {
        this.backView.active = true;
        this.frontView.active = false;
        this.hasShowBg = true;
        const i = this.backView.getComponent(UIOpacity), t = this.frontView.getComponent(UIOpacity), e = this.valueSp.getComponent(UIOpacity);
        i.opacity = 255;
        t.opacity = 0;
        e.opacity = 0;
    }
    showLaiziFlag(i, t, e) {
        if (i) {
            let i = true;
            if (78 == this.mCardValue || 79 == this.mCardValue ? (Utils.shared().setImage(this.laiziDiSp, "rm_kingcard_mask", this.myAtlas), i = false) : (Utils.shared().setImage(this.laiziDiSp, "rm_kingcard_mask", this.myAtlas), i = true), e) {
                User.shared().styles[1] - 1 == 2 ? sys.isObjectValid(this.clubBigLaizi) && (this.laizi_img.getComponent(Sprite).spriteFrame = this.clubBigLaizi) : sys.isObjectValid(this.bumpBigLaizi) && (this.laizi_img.getComponent(Sprite).spriteFrame = this.bumpBigLaizi);
            }
            else {
                this.laizi_img.setScale(v3(1, 1, 1));
                let i = "rm_img_laizi";
                User.shared().styles[1] - 1 == 2 && (i = "club_rm_img_laizi");
                Utils.shared().setImage(this.laizi_img, i, this.card[0]);
            }
            t ? (this.laizi_img.angle = -90, this.laizi_img.setPosition(v3(52, 80, 0))) : (this.laizi_img.setPosition(v3(-52, -40.587, 0)), this.laizi_img.angle = 0);
            const a = this.laiziDiSp.getComponent(UIOpacity), s = this.laizi_img.getComponent(UIOpacity);
            a.opacity = s.opacity = 255;
            this.laiziDiSp.active = true;
            this.laizi_img.active = i;
        }
        else {
            const i = this.laiziDiSp.getComponent(UIOpacity), t = this.laizi_img.getComponent(UIOpacity);
            i.opacity = t.opacity = 0;
            this.laiziDiSp.active = this.laizi_img.active = false;
        }
    }
    showJsLaiziFlag(i, t) {
        if (i) {
            let i = true;
            78 == this.mCardValue || 79 == this.mCardValue ? (Utils.shared().setImage(this.laiziDiSp, "s_rm_kingcard_mask", this.smallCardAtlas[0]), i = false) : (Utils.shared().setImage(this.laiziDiSp, "s_rm_kingcard_mask", this.smallCardAtlas[0]), i = true, this.laizi_img.setPosition(v3(0, 0, 0)));
            t && (User.shared().styles[1] - 1 == 2 ? sys.isObjectValid(this.clubSmallLaizi) && (this.laizi_img.getComponent(Sprite).spriteFrame = this.clubSmallLaizi) : sys.isObjectValid(this.bumpSmallLaizi) && (this.laizi_img.getComponent(Sprite).spriteFrame = this.bumpSmallLaizi));
            const e = this.laiziDiSp.getComponent(UIOpacity), a = this.laizi_img.getComponent(UIOpacity);
            e.opacity = a.opacity = 255;
            this.laiziDiSp.active = true;
            this.laizi_img.active = i;
        }
        else {
            const i = this.laiziDiSp.getComponent(UIOpacity), t = this.laizi_img.getComponent(UIOpacity);
            i.opacity = t.opacity = 0;
            this.laiziDiSp.active = this.laizi_img.active = false;
        }
    }
    showRobotLaiziFlag(i) {
        if (i) {
            78 == this.mCardValue || this.mCardValue;
            Utils.shared().setImage(this.laiziDiSp, "rb_kingcard_mask", this.robotCardAtlas);
            this.laizi_img.active = false;
            const i = this.laiziDiSp.getComponent(UIOpacity), t = this.laizi_img.getComponent(UIOpacity);
            i.opacity = t.opacity = 255;
            this.laiziDiSp.active = true;
        }
        else {
            const i = this.laiziDiSp.getComponent(UIOpacity), t = this.laizi_img.getComponent(UIOpacity);
            i.opacity = t.opacity = 0;
            this.laiziDiSp.active = this.laizi_img.active = false;
        }
    }
    showBumpLaiziTipAnim() {
        if (ToolUtils.isObjValid(this.flashAnim)) {
            this.flashAnim.active = true;
            const i = this.flashAnim.getComponent(sp.Skeleton);
            i.clearTracks();
            i.setToSetupPose();
            i.setAnimation(0, "animation", false);
            i.setCompleteListener((() => {
                i.clearTracks();
                i.setToSetupPose();
                i.setAnimation(0, "animation", false);
                i.setCompleteListener(null);
            }));
        }
    }
    hideBumpLaiziTipAnim() {
        if (ToolUtils.isObjValid(this.flashAnim)) {
            this.flashAnim.active = false;
            const i = this.flashAnim.getComponent(sp.Skeleton);
            i.clearTracks();
            i.setCompleteListener(null);
        }
    }
    showHuAcion(i, t, e, a, s) {
        this.node.setScale(a);
        let l = this.node;
        l.position = t;
        TweenTool.stopNodeAction(l);
        const n = this.backView.getComponent(UIOpacity);
        0 != i && (this.backView.active = true, n.opacity = 255);
        let o = TweenTool.moveTo(l, 0.364, new Vec3(31, 71, 0), "linear", false), h = TweenTool.rotateTo(l, 0.364, new Vec3(0, 0, -6), "linear", false), c = TweenTool.scaleTo(l, 0.066, new Vec3(0.8, 0.8), "linear", false), u = TweenTool.scaleTo(l, 0.066, new Vec3(0, 0.88), "linear", false, (() => {
            this.backView.active = true;
            n.opacity = 255;
        })), d = TweenTool.scaleTo(l, 0.066, new Vec3(0.96, 0.96), "linear", false), g = TweenTool.scaleTo(l, 0.066, new Vec3(0, 1.03), "linear", false, (() => {
            this.backView.active = false;
            n.opacity = 0;
        })), _ = TweenTool.scaleTo(l, 0.066, new Vec3(1.07, 1.11), "linear", false), b = TweenTool.rotateTo(l, 0.495, new Vec3(0, 0, 0), "linear", false), f = TweenTool.scaleTo(l, 0.495, new Vec3(1.3, 1.3), "linear", false), w = TweenTool.moveTo(l, 0.495, new Vec3(40, 72, 0), "linear", false, (() => {
        })), T = TweenTool.parallel(l, false, null, b, f, w), k = TweenTool.scaleTo(l, 0.859 - 0.759, new Vec3(0.5, 0.5), "quadInOut", false), I = TweenTool.moveTo(l, 0.859 - 0.759, e, "quadInOut", false, (() => {
        })), A = TweenTool.parallel(l, false, null, k, I), P = TweenTool.scaleTo(l, 0.891 - 0.859, new Vec3(0.6, 0.6), "quadInOut", false), B = TweenTool.scaleTo(l, 1 - 0.891, new Vec3(0.56, 0.56), "quadInOut", false, (() => {
        })), N = TweenTool.sequence(l, false, null, T, A, P, B), L = TweenTool.sequence(l, false, null, c, u, d, g, _, N), D = TweenTool.parallel(l, false, null, o, h, L), F = RummyDataManager.shared().getSeatidByPos(i, s), O = RummyDataManager.shared().rummyInfos.get(s).playerModels[F], x = sys.localStorage.getItem("play_effect_def");
        null == x && (x = User.shared().help_setting.play_effect_def);
        let E = D, j = 1.2;
        if (0 == i) {
            if (1 == RummyDataManager.shared().rummyInfos.get(s).hasChupai) {
                E = D;
                j = 0.959;
                sys.isObjectValid(x) && 1 == Number(x) && O.club_effect_v2 > 0 && O.club_effect_v2 <= 3 ? this.playEffectByName(s, ToolUtils.format("rummy_hupaidonghua${0}", O.club_effect_v2)) : this.playEffectByName(s, "rummy_hupaidonghua");
            }
            else {
                j = 1.2;
                let i = TweenTool.moveTo(l, 0.2, new Vec3(t.x, t.y + 30, t.z), "linear", true, (() => {
                    sys.isObjectValid(x) && 1 == Number(x) && O.club_effect_v2 > 0 && O.club_effect_v2 <= 3 ? this.playEffectByName(s, ToolUtils.format("rummy_hupaidonghua${0}", O.club_effect_v2)) : this.playEffectByName(s, "rummy_hupaidonghua");
                }));
                E = TweenTool.sequence(l, false, null, i, D);
            }
        }
        else {
            let i = TweenTool.moveToByFade(l, 0.2, new Vec3(t.x, t.y + 40, t.z), 0, 1, false), e = TweenTool.scaleTo(l, 0.4, new Vec3(0.5, 0.5), "linear", true, (() => {
                sys.isObjectValid(x) && 1 == Number(x) && O.club_effect_v2 > 0 && O.club_effect_v2 <= 3 ? this.playEffectByName(s, ToolUtils.format("rummy_hupaidonghua${0}", O.club_effect_v2)) : this.playEffectByName(s, "rummy_hupaidonghua");
            })), a = TweenTool.parallel(l, false, null, e, i);
            E = TweenTool.sequence(l, false, null, a, D);
            j = 1.4;
        }
        E.start();
        let Y = { tid_key: s, delTime: j, pos: i };
        PushCenter.shared().pushEvent(PushEvent.RummyGameShowHC, Y);
    }
    showHuAcion_newPlay(i, t, e) {
        this.node.setScale(e);
        let a = this.node;
        a.position = i;
        TweenTool.stopNodeAction(a);
        const s = this.backView.getComponent(UIOpacity);
        let l = TweenTool.moveTo(a, 0.364, new Vec3(31, 71, 0), "linear", false), n = TweenTool.rotateTo(a, 0.364, new Vec3(0, 0, -6), "linear", false), o = TweenTool.scaleTo(a, 0.066, new Vec3(0.8, 0.8), "linear", false), h = TweenTool.scaleTo(a, 0.066, new Vec3(0, 0.88), "linear", false, (() => {
            this.backView.active = true;
            s.opacity = 255;
        })), c = TweenTool.scaleTo(a, 0.066, new Vec3(0.96, 0.96), "linear", false), p = TweenTool.scaleTo(a, 0.066, new Vec3(0, 1.03), "linear", false, (() => {
            this.backView.active = false;
            s.opacity = 0;
        })), u = TweenTool.scaleTo(a, 0.066, new Vec3(1.07, 1.11), "linear", false), d = TweenTool.rotateTo(a, 0.495, new Vec3(0, 0, 0), "linear", false), g = TweenTool.scaleTo(a, 0.495, new Vec3(1.3, 1.3), "linear", false), _ = TweenTool.moveTo(a, 0.495, new Vec3(40, 72, 0), "linear", false, (() => {
        })), b = TweenTool.parallel(a, false, null, d, g, _), f = TweenTool.scaleTo(a, 0.859 - 0.759, new Vec3(0.5, 0.5), "quadInOut", false), C = TweenTool.moveTo(a, 0.859 - 0.759, t, "quadInOut", false, (() => {
        })), w = TweenTool.parallel(a, false, null, f, C), z = TweenTool.scaleTo(a, 0.891 - 0.859, new Vec3(0.6, 0.6), "quadInOut", false), V = TweenTool.scaleTo(a, 1 - 0.891, new Vec3(0.56, 0.56), "quadInOut", false, (() => {
        })), k = TweenTool.sequence(a, false, null, b, w, z, V), I = TweenTool.sequence(a, false, null, o, h, c, p, u, k), A = TweenTool.parallel(a, false, null, l, n, I), P = A, B = TweenTool.moveTo(a, 0.2, new Vec3(i.x, i.y + 30, i.z), "linear", true, (() => {
            SoundManager.shared().playFx("rummy_hupaidonghua");
        }));
        P = TweenTool.sequence(a, false, null, B, A);
        P.start();
        let N = { delTime: 1.2 };
        PushCenter.shared().pushEvent(PushEvent.RummyGameShowHC_newPlay, N);
    }
    playEffectByName(i, t) {
        i === User.shared().curTid_key && SoundManager.shared().playFx(t);
    }
    setCardValue(i) {
        if (this.mCardValue = i, this.mCardValue > 0 || this.mCardValue < 80) {
            let i = "rm_scard_" + ToolUtils.cardTo16(this.mCardValue);
            User.shared().styles[1] - 1 == 2 && (i = "club_rm_scard_" + ToolUtils.cardTo16(this.mCardValue));
            Utils.shared().setImage(this.valueSp, i, this.card[0]);
            this.valueSp.active = 3 != this._type;
            this.valueSp.getComponent(UIOpacity).opacity = 255;
        }
    }
    getCardValue() {
        return this.mCardValue;
    }
    setJsCardValue(i) {
        if (this.mCardValue = i, this.mCardValue > 0 || this.mCardValue < 80) {
            let i = "s_rm_scard_" + ToolUtils.cardTo16(this.mCardValue);
            Utils.shared().setImage(this.valueSp, i, this.smallCardAtlas[0]);
            this.valueSp.active = true;
            this.valueSp.getComponent(UIOpacity).opacity = 255;
        }
    }
    setMask(i, t = false) {
        if (t && i && ToolUtils.isObjValid(this.frontView) && ToolUtils.isObjValid(this.maskSp)) {
            let i = this.frontView.getComponent(UITransform).contentSize;
            this.maskSp.getComponent(UITransform).setContentSize(size(i.width, i.height + 2));
        }
        this.maskSp.active = !!i;
    }
    setMaskFade(i) {
        this.maskSp.active = true;
        TweenTool.moveToByFade(this.maskSp, i, this.maskSp.getPosition(), 0.2, 1, true, (() => {
        }));
    }
    showNewFlag(i) {
        this.newSp.active = !!i;
    }
    showGlowFlag(i) {
        this.glowSp.active = !!i;
    }
    showDiscardTipsFlag(i) {
        this.discardTipsSp.active = !!i;
        i && (this.newSp.active ? this.discardTipsSp.setPosition(v3(-52, 155)) : this.discardTipsSp.setPosition(v3(-52, 140)));
    }
    showTingPaiTipsFlag(i, t = 0, e = null) {
        if (this.tingpaiTipsNode.active = !!i, i) {
            this.tingpai_type = 1;
            this._mFinish_num = t;
            this.tingpaiTipsNode.setPosition(v3(-52, 152));
            this.discardTipsSp.active = false;
            this.tingpaiTips2Node.active = false;
            let i = this.tingpaiTipsNode.getChildByName("Label");
            ToolUtils.isObjValid(i) && (i.getComponent(Label).string = String(t), i.getComponent(Label).fontSize = t >= 100 ? 52 : 60);
            this._callback = e;
        }
    }
    showLightTingPaiTipsFlag(i, t = false, e = 0, a = null) {
        if (this.tingpaiTips2Node.active = !!i, i) {
            this.tingpai_type = 2;
            this._mFinish_num = e;
            this.tingpaiTips2Node.setPosition(v3(-52, 152));
            this.discardTipsSp.active = false;
            this.tingpaiTipsNode.active = false;
            let i = this.tingpaiTips2Node.getChildByName("Label");
            ToolUtils.isObjValid(i) && (i.getComponent(Label).string = e < 0 ? "" : String(e), i.getComponent(Label).fontSize = e >= 100 ? 52 : 60);
            this._callback = a;
        }
    }
    changTingPaiTipsStatus(i) {
        i ? this.showLightTingPaiTipsFlag(true, false, this._mFinish_num, this._callback) : this.showTingPaiTipsFlag(true, this._mFinish_num, this._callback);
    }
    changeMaskSizeSameToFornt() {
        if (this.valueSp && this.maskSp) {
            let i = this.valueSp.getComponent(UITransform).contentSize;
            this.maskSp.getComponent(UITransform).setContentSize(i);
        }
    }
    buttonClick(i, t) {
        SoundManager.shared().playFx("click");
        "tingpai" == t && this._callback && this._callback(this);
    }
    changeTingPaiLightSelectVisible(i) {
        let t = this.node.getChildByName("select");
        ToolUtils.isObjValid(t) && (t.active = i);
    }
}
