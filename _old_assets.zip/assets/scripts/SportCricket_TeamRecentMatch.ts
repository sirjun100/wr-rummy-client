// @ts-nocheck
// Recovered from index.js:593
import { _decorator, color, instantiate, Label, Node, ProgressBar, size, Sprite, SpriteFrame, sys, UITransform, view, Widget } from "cc";
import SoundManager from "./SoundManager";
import PushCenter from "./PushCenter";
import { TLog } from "./TLog";
import Utils from "./Utils";
import User from "./User";
import BaseLayer from "./BaseLayer";
import GameConfig from "./GameConfig";
import PushEvent from "./PushEvent";
import TweenTool from "./TweenTool";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("SportCricket_TeamRecentMatch")
export class SportCricket_TeamRecentMatch extends BaseLayer {
    public TAG: string = "SportCricket_TeamRecentMatch";
    @property(Node)
    public rootNode: Node = null;
    @property(Node)
    public goldNode: Node = null;
    @property(Node)
    public statRoot: Node = null;
    @property(Node)
    public contentRoot: Node = null;
    @property(Node)
    public matchMoban: Node = null;
    @property([SpriteFrame])
    public winLoseSpriteFrame: SpriteFrame[] = [];
    public _closed: boolean = false;
    public bShowPushAnim: boolean = true;
    public _lastClick: number = 0;
    public _isSendMsg: boolean = false;
    public taskAwardIconMap: Map = new Map;
    public _match_id: number = 0;
    public _source: any = null;
    public lastClick: number = 0;
    public _fromType: number = 0;
    public _match_state: number = 1;
    public _head_source: any = null;
    public _matchData: any = null;
    public _lastNode: any = null;
    public _call: any = null;
    public _hasInitAMatch: boolean = false;
    public _hasInitBMatch: boolean = false;
    onLoad() {
        PushCenter.shared().addListener(GameConfig.Update_Money, (t => {
            try {
                ToolUtils.isObjValid(this.node) && this.updateGold(t);
            }
            catch (t) {
                TLog.printError(this.TAG, GameConfig.Update_Money, t);
            }
        }), this);
        PushCenter.shared().addListener(PushEvent.commentDownloaderImg, (t => {
            try {
                if (ToolUtils.isObjValid(this.node) && this.taskAwardIconMap.size > 0) {
                    for (const [e, a] of this.taskAwardIconMap) {
                        a == t && sys.isObjectValid(e) && Utils.shared().updateNetImage(e, t, size(60, 60));
                    }
                }
            }
            catch (t) {
                TLog.printError(this.TAG, PushEvent.commentDownloaderImg, t);
            }
        }), this);
        this.fitLuckyTheme();
    }
    fitLuckyTheme() {
        0 != GameConfig.NATIVE_GAME_APP_TYPE && (this.rootNode.getChildByName("top_node").getChildByName("top_bg").getComponent(Sprite).color = color(12, 26, 60, 255), this.goldNode.getChildByName("coin").getComponent(Label).color = color(251, 220, 0, 255));
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().removeListenersByTag(this);
        this.unscheduleAllCallbacks();
    }
    init(t) {
        sys.isObjectValid(t) && sys.isObjectValid(t.match_id) && (this._match_id = t.match_id);
        sys.isObjectValid(t) && sys.isObjectValid(t.source) && (this._source = { ...t.source });
        sys.isObjectValid(t) && sys.isObjectValid(t.matchData) && (this._matchData = t.matchData);
        sys.isObjectValid(t) && sys.isObjectValid(t.head_source) && (this._head_source = t.head_source);
        sys.isObjectValid(t) && sys.isObjectValid(t.fromType) && (this._fromType = t.fromType);
        sys.isObjectValid(t) && sys.isObjectValid(t.call) && (this._call = t.call);
        sys.isObjectValid(t) && sys.isObjectValid(t.lastNode) && (this._lastNode = t.lastNode);
    }
    start() {
        super.start();
        this.initView();
        this.bShowPushAnim && ToolUtils.showPushAnim(this.node, 0, (() => {
            this.refreshView();
            sys.isObjectValid(this._lastNode) && (this._lastNode.active = false);
        }));
        this.updateGold(User.shared().data.money);
    }
    updateGold(t) {
        let e = this.goldNode.getChildByName("coin");
        null != t && e && (e.getComponent(Label).string = ToolUtils.parse_double(t));
    }
    refreshView() {
        if (sys.isObjectValid(this._matchData)) {
            let t = this.contentRoot.getChildByName("teama_root");
            if (sys.isObjectValid(this._matchData.teama) && sys.isObjectValid(this._matchData.teama.logo_url) && this._matchData.teama.logo_url.length > 0 && (this.taskAwardIconMap.set(t.getChildByName("team_icon"), this._matchData.teama.logo_url), Utils.shared().updateNetImage(t.getChildByName("team_icon"), this._matchData.teama.logo_url, size(60, 60))), sys.isObjectValid(this._matchData.teama) && sys.isObjectValid(this._matchData.teama.short_name) && this._matchData.teama.short_name.length > 0 && (t.getChildByName("team_name").getComponent(Label).string = this._matchData.teama.short_name), sys.isObjectValid(this._matchData.teama) && sys.isObjectValid(this._matchData.teama.last_five_match) && Array.isArray(this._matchData.teama.last_five_match)) {
                for (let e = 0; e < 5; e++) {
                    let a = t.getChildByName("team_flag" + e);
                    ToolUtils.isObjValid(a) && (e < this._matchData.teama.last_five_match.length ? sys.isObjectValid(this._matchData.teama.last_five_match[e].winning_team_id) && this._matchData.teama.last_five_match[e].winning_team_id == this._matchData.teama.team_id ? a.getComponent(Sprite).spriteFrame = this.winLoseSpriteFrame[0] : a.getComponent(Sprite).spriteFrame = this.winLoseSpriteFrame[1] : a.getComponent(Sprite).spriteFrame = this.winLoseSpriteFrame[2]);
                }
            }
            let e = this.contentRoot.getChildByName("teamb_root");
            if (sys.isObjectValid(this._matchData.teamb) && sys.isObjectValid(this._matchData.teamb.logo_url) && this._matchData.teamb.logo_url.length > 0 && (this.taskAwardIconMap.set(e.getChildByName("team_icon"), this._matchData.teamb.logo_url), Utils.shared().updateNetImage(e.getChildByName("team_icon"), this._matchData.teamb.logo_url, size(60, 60))), sys.isObjectValid(this._matchData.teamb) && sys.isObjectValid(this._matchData.teamb.short_name) && this._matchData.teamb.short_name.length > 0 && (e.getChildByName("team_name").getComponent(Label).string = this._matchData.teamb.short_name), sys.isObjectValid(this._matchData.teamb) && sys.isObjectValid(this._matchData.teamb.last_five_match) && Array.isArray(this._matchData.teamb.last_five_match)) {
                for (let t = 0; t < 5; t++) {
                    let a = e.getChildByName("team_flag" + t);
                    ToolUtils.isObjValid(a) && (t < this._matchData.teamb.last_five_match.length ? sys.isObjectValid(this._matchData.teamb.last_five_match[t].winning_team_id) && this._matchData.teamb.last_five_match[t].winning_team_id == this._matchData.teamb.team_id ? a.getComponent(Sprite).spriteFrame = this.winLoseSpriteFrame[0] : a.getComponent(Sprite).spriteFrame = this.winLoseSpriteFrame[1] : a.getComponent(Sprite).spriteFrame = this.winLoseSpriteFrame[2]);
                }
            }
        }
        if (sys.isObjectValid(this._head_source)) {
            let t = this.contentRoot.getChildByName("head_root");
            sys.isObjectValid(this._head_source.total_matches_played) && (t.getChildByName("play_num").getComponent(Label).string = this._head_source.total_matches_played + "");
            let e = Number(this._head_source.total_matches_played);
            t.getChildByName("awin_title").getComponent(Label).string = this._source.recent.teama.short_name + " Won";
            t.getChildByName("bwin_title").getComponent(Label).string = this._source.recent.teamb.short_name + " Won";
            sys.isObjectValid(this._head_source.teama_win) && (t.getChildByName("awin_desc").getComponent(Label).string = String(this._head_source.teama_win), t.getChildByName("awin_progress").getComponent(ProgressBar).progress = Number(this._head_source.teama_win) / e);
            sys.isObjectValid(this._head_source.teamb_win) && (t.getChildByName("bwin_desc").getComponent(Label).string = String(this._head_source.teamb_win), t.getChildByName("bwin_progress").getComponent(ProgressBar).progress = Number(this._head_source.teamb_win) / e);
            sys.isObjectValid(this._head_source.total_match_drawn) && (t.getChildByName("tie_desc").getComponent(Label).string = String(this._head_source.total_match_drawn), t.getChildByName("tie_progress").getComponent(ProgressBar).progress = Number(this._head_source.total_match_drawn) / e);
            sys.isObjectValid(this._head_source.total_match_cancelled) && (t.getChildByName("no_desc").getComponent(Label).string = String(this._head_source.total_match_cancelled), t.getChildByName("no_progress").getComponent(ProgressBar).progress = Number(this._head_source.total_match_cancelled) / e);
        }
    }
    onCloseButtonClick(t, e) {
        if (SoundManager.shared().playFx("click"), "back_btn" == e) {
            if (this._closed) {
                return;
            }
            this.onBackView();
        }
    }
    initView() {
        if (this.fitScreen(), sys.isObjectValid(this._source)) {
            let t = this.rootNode.getChildByName("top_node").getChildByName("lefttime");
            t.getComponent(Label).string = Utils.shared().parseCountDown(this._source.time_left);
            sys.isObjectValid(this._source.status) && (this._match_state = this._source.status);
            0 == this._source.time_left && 1 == this._source.status ? (t.getComponent(Label).string = this._source.start_day, sys.isObjectValid(this._source.is_current_day) && 1 == Number(this._source.is_current_day) && (this._source.status = 3, t.getComponent(Label).string = "Live")) : 1 == this._source.status ? TweenTool.myschedule(t, 1, (() => {
                ToolUtils.isObjValid(this.node) && (this._source.time_left > 0 ? t.getComponent(Label).string = Utils.shared().parseCountDown(this._source.time_left) : (this._source.status = 3, t.getComponent(Label).string = "Live", TweenTool.stopNodeAction(t)));
            })) : 3 == this._source.status ? (TweenTool.stopNodeAction(t), t.getComponent(Label).string = "Live") : 4 == this._source.status && (TweenTool.stopNodeAction(t), t.getComponent(Label).string = "Cancel");
            PushCenter.shared().addListener(PushEvent.UpdateYes11CurMatchLeftTime, (e => {
                try {
                    ToolUtils.isObjValid(this.node) && e.match_id == this._match_id && (this._source.time_left = e.time_left, this._source.is_current_day = e.is_current_day, this._match_state = e.status, 3 == e.status ? (TweenTool.stopNodeAction(t), t.getComponent(Label).string = "Live") : 4 == e.status && (TweenTool.stopNodeAction(t), t.getComponent(Label).string = "Cancel"));
                }
                catch (t) {
                    TLog.printError(this.TAG, PushEvent.UpdateYes11CurMatchLeftTime, t);
                }
            }), this);
        }
    }
    onButtonClick(t, e) {
        SoundManager.shared().playFx("click");
        sys.now() - this._lastClick < 500 || (this._lastClick = sys.now(), "aArrow" == e ? this.contentRoot.getChildByName("teama_match").active ? (this.contentRoot.getChildByName("teama_match").active = false, this.contentRoot.getChildByName("teama_root").getChildByName("arrow").angle = -90) : (this.contentRoot.getChildByName("teama_match").active = true, this.contentRoot.getChildByName("teama_root").getChildByName("arrow").angle = 90, this._hasInitAMatch || (this._hasInitAMatch = true, this.addMatchView(this.contentRoot.getChildByName("teama_root"), this._matchData.teama.last_five_match, true))) : "bArrow" == e ? this.contentRoot.getChildByName("teamb_match").active ? (this.contentRoot.getChildByName("teamb_match").active = false, this.contentRoot.getChildByName("teamb_root").getChildByName("arrow").angle = -90) : (this.contentRoot.getChildByName("teamb_match").active = true, this.contentRoot.getChildByName("teamb_root").getChildByName("arrow").angle = 90, this._hasInitBMatch || (this._hasInitBMatch = true, this.addMatchView(this.contentRoot.getChildByName("teamb_root"), this._matchData.teamb.last_five_match, false))) : "add_chip" == e && Utils.shared().showStoreView(null, null));
    }
    addMatchView(t, e, a) {
        for (let a = 0; a < e.length; a++) {
            let i = instantiate(this.matchMoban);
            i.active = true;
            t.addChild(i);
            sys.isObjectValid(e[a].teama) && sys.isObjectValid(e[a].teama.logo_url) && (this.taskAwardIconMap.set(i.getChildByName("teama_icon"), e[a].teama.logo_url), Utils.shared().updateNetImage(i.getChildByName("teama_icon"), e[a].teama.logo_url, size(60, 60)));
            sys.isObjectValid(e[a].teamb) && sys.isObjectValid(e[a].teamb.logo_url) && (this.taskAwardIconMap.set(i.getChildByName("teamb_icon"), e[a].teamb.logo_url), Utils.shared().updateNetImage(i.getChildByName("teamb_icon"), e[a].teamb.logo_url, size(60, 60)));
            sys.isObjectValid(e[a].result) && e[a].result.length > 0 && (i.getChildByName("team_result").getComponent(Label).string = e[a].result);
            let s = -1;
            sys.isObjectValid(e[a].winning_team_id) ? (e[a].winning_team_id == e[a].teama.team_id ? s = 1 : e[a].winning_team_id == e[a].teamb.team_id && (s = 2), 1 == s ? i.getChildByName("dot").getComponent(Sprite).color = color(77, 183, 92) : 2 == s ? i.getChildByName("dot").getComponent(Sprite).color = color(227, 64, 64) : i.getChildByName("dot").active = false) : i.getChildByName("dot").active = false;
            sys.isObjectValid(e[a].teama) && sys.isObjectValid(e[a].teama.short_name) && (i.getChildByName("teama_name").getComponent(Label).string = e[a].teama.short_name);
            sys.isObjectValid(e[a].teamb) && sys.isObjectValid(e[a].teamb.short_name) && (i.getChildByName("teamb_name").getComponent(Label).string = e[a].teamb.short_name);
            sys.isObjectValid(e[a].teama) && sys.isObjectValid(e[a].teama.scores) && (i.getChildByName("teama_score").getComponent(Label).string = e[a].teama.scores);
            sys.isObjectValid(e[a].teamb) && sys.isObjectValid(e[a].teamb.scores) && (i.getChildByName("teamb_score").getComponent(Label).string = e[a].teamb.scores);
            sys.isObjectValid(e[a].start_time) && (i.getChildByName("match_date").getComponent(Label).string = e[a].start_time);
            sys.isObjectValid(e[a].venue) && sys.isObjectValid(e[a].venue.name) && (i.getChildByName("venue").getComponent(Label).string = e[a].venue.name);
        }
    }
    onBackView(t = true) {
        t && (Utils.shared().hideLoading(), this.bShowPushAnim ? (this._closed = true, ToolUtils.isObjValid(this._lastNode) && (this._lastNode.active = true), ToolUtils.showPushAnim(this.node, 1, (() => {
            ToolUtils.isObjValid(this.node) && this.node.destroy();
        }))) : (ToolUtils.isObjValid(this._lastNode) && (this._lastNode.active = true), ToolUtils.isObjValid(this.node) && this.node.destroy()));
    }
    fitScreen() {
        ToolUtils.adaptSafeArea(this.rootNode);
        let t = sys.getSafeAreaRect().y, e = view.getVisibleSize();
        if (this.node.getComponent(UITransform).setContentSize(e.width, e.height), 0 != t) {
            let e = this.statRoot.getComponent(Widget).bottom;
            this.statRoot.getComponent(Widget).bottom = e - t;
        }
    }
}
