// @ts-nocheck
// Recovered from index.js:219
import { _decorator, Node, sys, UITransform, v3 } from "cc";
import SoundManager from "./SoundManager";
import BaseLayer from "./BaseLayer";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("KycPhoto")
export class KycPhoto extends BaseLayer {
    @property(Node)
    public rootNode: Node = null;
    public cb: any = null;
    public posRoot: any = undefined;
    onLoad() {
        this.posRoot = this.rootNode.getPosition();
        this.rootNode.active = false;
    }
    start() {
        super.start();
        this.scheduleOnce((() => {
            this.fitScreen();
            let t = this.rootNode.getPosition(), o = { startPos: v3(t.x, t.y - 300, t.z), endPos: t };
            this.rootNode.active = true;
            ToolUtils.showPushAnim(this.rootNode, 2, null, o);
        }));
    }
    setCallBack(t) {
        this.cb = t;
    }
    button_click(t, o) {
        SoundManager.shared().playFx("click");
        "takephoto" === o ? this.cb && this.cb(o) : "selectphoto" === o && this.cb && this.cb(o);
        this.onBackView();
    }
    onBackView(t = true) {
        if (t) {
            let t = this.rootNode.getPosition(), o = { startPos: t, endPos: v3(t.x, t.y - 300, t.z) };
            this.rootNode.active = true;
            ToolUtils.showPushAnim(this.rootNode, 2, (() => {
                ToolUtils.isObjValid(this.node) && this.node.destroy();
            }), o);
        }
    }
    fitScreen() {
        let t = sys.getSafeAreaRect().y, o = this.node.getChildByName("bg").getComponent(UITransform).contentSize.height - 1280 - t;
        o > 0 && this.rootNode.setPosition(v3(this.posRoot.x, this.posRoot.y - o / 2));
    }
}
