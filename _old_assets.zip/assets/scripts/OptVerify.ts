// @ts-nocheck
// Recovered from index.js:329
import { _decorator, Button, EditBox, Label, LabelShadow, Node, ScrollView, size, Sprite, SpriteFrame, sys, UITransform, v3, Widget } from "cc";
import BaseLayer from "./BaseLayer";
import SoundManager from "./SoundManager";
import PushCenter from "./PushCenter";
import GameConfig from "./GameConfig";
import { TLog } from "./TLog";
import Utils from "./Utils";
import User from "./User";
import HttpManager from "./HttpManager";
import PushEvent from "./PushEvent";
import CommDefine, { CheckModule } from "./CommDefine";
import i18nMgr from "./i18nMgr";
import TweenTool from "./TweenTool";
import ReportConfig from "./ReportConfig";
import { HttpRequest } from "./HttpRequestName";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("OptVerify")
export class OptVerify extends BaseLayer {
    @property(Node)
    public rootNode: Node = null;
    @property(ScrollView)
    public scrollView: ScrollView = null;
    @property(Node)
    public errTipNode: Node = null;
    @property(Node)
    public panelCenter: Node = null;
    @property(Node)
    public cardNumberNode: Node = null;
    @property(Node)
    public captNumberNode: Node = null;
    @property(Node)
    public otpNumberNode: Node = null;
    @property(Node)
    public code_btnNode: Node = null;
    @property([SpriteFrame])
    public btnImgs: SpriteFrame[] = [];
    @property(Node)
    public tipsNode: Node = null;
    @property(SpriteFrame)
    public blackImg: SpriteFrame = null;
    public cardNumberStr: string = "";
    public captNumberStr: string = "";
    public otpNumberStr: string = "";
    public scrollItemPosY: number = 0;
    public isLoadingImg: boolean = false;
    public session_id: string = "";
    public captcha_url: string = "";
    public _lastClick: number = 0;
    public bShowPushAnim: boolean = false;
    public showUICallback: any = null;
    public closeUICallBack: any = null;
    public _closed: boolean = false;
    public _bBtnEnable: boolean = true;
    public cur_page: number = 0;
    onLoad() {
        if (ToolUtils.isSafeString(User.shared().kyc_bottom_tip).length > 0) {
            this.tipsNode.getComponent(Label).string = User.shared().kyc_bottom_tip;
        }
        else {
            let e = i18nMgr.shared().getValueByKey("kyc.kyc_18tips");
            this.tipsNode.getComponent(Label).string = e;
        }
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().removeListenersByTag(this);
        this.unscheduleAllCallbacks();
    }
    init(e, t = null, i = null) {
        this.bShowPushAnim = e;
        this.showUICallback = t;
        this.closeUICallBack = i;
    }
    start() {
        super.start();
        this.initView();
        this.bShowPushAnim && ToolUtils.showPushAnim(this.node, 0, (() => {
            this.showUICallback && this.showUICallback();
        }));
        PushCenter.shared().addListener(GameConfig.Update_Kyc, (() => {
            if (ToolUtils.isObjValid(this.node) && (this.updateCardVerifyView(true), 2 == User.shared().data.card_check)) {
                let e = false;
                if (sys.isObjectValid(User.shared().newKycData.collect_list) && Array.isArray(User.shared().newKycData.collect_list)) {
                    for (let t = 0; t < User.shared().newKycData.collect_list.length; t++) {
                        if (1 == User.shared().newKycData.collect_list[t].type) {
                            e = true;
                            this.updateErrTips();
                            break;
                        }
                    }
                }
                e || this.onBackView();
            }
        }), this);
        PushCenter.shared().addListener(PushEvent.commentDownloaderImg, (e => {
            sys.isObjectValid(this.node) && e == this.captcha_url && Utils.shared().updateNetImage(this.captNumberNode.getChildByName("capt_img"), this.captcha_url, size(140, 67));
        }), this);
    }
    onCloseButtonClick(e, t) {
        if (SoundManager.shared().playFx("click"), "back_btn" == t) {
            if (this._closed) {
                return;
            }
            this._closed = true;
            this.onBackView();
        }
    }
    initView() {
        this.fitScreen();
        this.cur_page = 0;
        sys.isObjectValid(User.shared().newKycData.collect_list) && User.shared().newKycData.collect_list.length > 0 ? this.updateCardVerifyView(true) : (Utils.shared().showLoading(10, true, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3);
        })), HttpManager.shared().doGetKycAccount2(this.listenGetKycAccountCallback.bind(this)));
        this.refreshCodeBtn();
        User.shared().code_timeout > 0 && this.schedule(this.refreshCodeBtn, 1);
    }
    refreshCodeBtn() {
        User.shared().code_timeout = User.shared().code_timeout - 1;
        let e = this.code_btnNode.getComponent(Button), t = this.code_btnNode.getComponent(Sprite);
        User.shared().code_timeout <= 0 ? (this.unschedule(this.refreshCodeBtn), e.interactable = true, t.spriteFrame = this.btnImgs[1], this.code_btnNode.getChildByName("wz").getComponent(Label).string = "OTP", this.code_btnNode.getChildByName("wz").getComponent(LabelShadow).color = CommDefine.shadowcolor.green, Utils.updateLabelMaterial(this.code_btnNode.getChildByName("wz"), CommDefine.gradient.btn_green), this.updateCardEditStatus(true)) : (e.interactable = false, t.spriteFrame = this.btnImgs[0], this.code_btnNode.getChildByName("wz").getComponent(Label).string = `(${User.shared().code_timeout}s)`, this.code_btnNode.getChildByName("wz").getComponent(LabelShadow).color = CommDefine.shadowcolor.gray, Utils.updateLabelMaterial(this.code_btnNode.getChildByName("wz"), CommDefine.gradient.btn_gray), this.updateCardEditStatus(false), this.cardNumberNode.getChildByName("del_btn").active = false);
    }
    listenGetKycAccountCallback(e, t, i) {
        try {
            if (200 != i) {
                alert("The login timed out, please try again");
            }
            else {
                let e = ToolUtils.parseJson(t);
                0 == e.ret && (User.shared().newKycData = e.data, ToolUtils.isObjValid(this.node) && this.updateCardVerifyView());
            }
        }
        catch (e) {
            TLog.printError("listenGetKycVerifyListCallback:", e);
        }
    }
    updateCardVerifyView(e = true) {
        let t = true;
        0 == User.shared().data.card_check || 3 == User.shared().data.card_check ? (t = true, i18nMgr.shared().changeLabelLanguage(this.rootNode.getChildByName("next_btn").getChildByName("wz").getComponent(Label), "bind_mobile.next", true), this.rootNode.getChildByName("submit_btn").active = true, this.rootNode.getChildByName("submit_btn").getComponent(Button).interactable = true, this.rootNode.getChildByName("submit_btn").getChildByName("wz").getComponent(LabelShadow).color = CommDefine.shadowcolor.green, this.rootNode.getChildByName("submit_btn").getChildByName("wz").getComponent(LabelShadow).enabled = true, Utils.updateLabelMaterial(this.rootNode.getChildByName("submit_btn").getChildByName("wz"), CommDefine.gradient.btn_green), i18nMgr.shared().changeLabelLanguage(this.rootNode.getChildByName("submit_btn").getChildByName("wz").getComponent(Label), "kyc.submit", true)) : (t = false, 2 == User.shared().data.card_check && sys.isObjectValid(User.shared().newKycData.collect_list) && User.shared().newKycData.collect_list.length > 0 && (t = true), this.rootNode.getChildByName("submit_btn").getComponent(Button).interactable = t, this.rootNode.getChildByName("submit_btn").active = true, t ? (this.rootNode.getChildByName("submit_btn").getChildByName("wz").getComponent(LabelShadow).color = CommDefine.shadowcolor.green, this.rootNode.getChildByName("submit_btn").getChildByName("wz").getComponent(LabelShadow).enabled = true, Utils.updateLabelMaterial(this.rootNode.getChildByName("submit_btn").getChildByName("wz"), CommDefine.gradient.btn_green)) : (this.rootNode.getChildByName("submit_btn").getChildByName("wz").getComponent(LabelShadow).color = CommDefine.shadowcolor.gray, this.rootNode.getChildByName("submit_btn").getChildByName("wz").getComponent(LabelShadow).enabled = true, Utils.updateLabelMaterial(this.rootNode.getChildByName("submit_btn").getChildByName("wz"), CommDefine.gradient.btn_gray)), 1 == User.shared().data.card_check ? i18nMgr.shared().changeLabelLanguage(this.rootNode.getChildByName("submit_btn").getChildByName("wz").getComponent(Label), "kyc.verity_pending", true) : (Utils.shared().hideLoading(), i18nMgr.shared().changeLabelLanguage(this.rootNode.getChildByName("submit_btn").getChildByName("wz").getComponent(Label), "kyc.verity_verified", true), t && i18nMgr.shared().changeLabelLanguage(this.rootNode.getChildByName("submit_btn").getChildByName("wz").getComponent(Label), "kyc.revise", true)));
        e && this.updateErrTips();
        3 == User.shared().data.card_check && sys.isObjectValid(User.shared().newKycData.kyc_list) && ToolUtils.isSafeString(User.shared().newKycData.kyc_list.card).length > 0 && (this.updateCardNumberView(User.shared().newKycData.kyc_list.card, t, e), this.updateCardNumberStatus());
        2 == User.shared().data.card_check && sys.isObjectValid(User.shared().newKycData.kyc_list) && ToolUtils.isSafeString(User.shared().newKycData.kyc_list.card).length > 0 && (sys.isObjectValid(User.shared().newKycData.collect_list) && User.shared().newKycData.collect_list.length > 0 ? this.updateCardNumberView(User.shared().newKycData.kyc_list.card, false, e) : this.updateCardNumberView(User.shared().newKycData.kyc_list.card, t, e));
    }
    updateErrTips() {
        if (sys.isObjectValid(User.shared().newKycData.collect_list) && Array.isArray(User.shared().newKycData.collect_list)) {
            for (let e = 0; e < User.shared().newKycData.collect_list.length; e++) {
                if (1 == User.shared().newKycData.collect_list[e].type) {
                    let t = User.shared().newKycData.collect_list[e].reason;
                    if (sys.isObjectValid(t) && t.length > 0) {
                        this.errTipNode.active = true;
                        this.errTipNode.getChildByName("tx").getComponent(Label).string = t;
                        this.errTipNode.getChildByName("tx").getComponent(Label).updateRenderData(true);
                        let e = this.errTipNode.getComponent(UITransform).contentSize, i = this.errTipNode.getChildByName("tx").getComponent(UITransform).contentSize.height + 8;
                        this.errTipNode.getComponent(UITransform).setContentSize(size(e.width, i));
                        this.panelCenter.setPosition(v3(0, -i, 0));
                        e = this.scrollView.content.getComponent(UITransform).contentSize;
                        this.scrollView.content.getComponent(UITransform).setContentSize(size(e.width, 1000 + i));
                    }
                    else {
                        this.errTipNode.active = false;
                        this.errTipNode.getChildByName("tx").getComponent(Label).string = "";
                        this.panelCenter.setPosition(v3(0, 0, 0));
                        let e = this.scrollView.content.getComponent(UITransform).contentSize;
                        this.scrollView.content.getComponent(UITransform).setContentSize(size(e.width, 1000));
                    }
                    break;
                }
            }
        }
    }
    updateCardNumberView(e = "", t, i = true) {
        i && (this.cardNumberStr = e, this.cardNumberNode.getChildByName("del_btn").active = false);
        this.cardNumberNode.getChildByName("EditBox").getComponent(EditBox).string = this.cardNumberStr;
        this.cardNumberNode.getChildByName("content").getComponent(Label).string = this.cardNumberStr;
        this.cardNumberNode.getChildByName("EditBox").active = t;
        this.cardNumberNode.getChildByName("content").active = !t;
        this.cardNumberNode.getChildByName("EditBox").getComponent(EditBox).inputMode = EditBox.InputMode.NUMERIC;
        this.cardNumberNode.getChildByName("EditBox").getComponent(EditBox).maxLength = 12;
        i18nMgr.shared().changeLabelLanguage(this.cardNumberNode.getChildByName("EditBox").getComponent(EditBox).placeholderLabel, "Enter aadhaar No.");
    }
    onButtonClick(e, t) {
        if (SoundManager.shared().playFx("click"), "cardnumber_del" == t) {
            let e = this.cardNumberNode.getChildByName("EditBox");
            e.getComponent(EditBox).string = "";
            e.getComponent(EditBox).blur();
            this.updateCardNumberStatus();
        }
        else if ("kefu" == t) {
            if (1 == User.shared().temp_pingbi.feedback) {
                return void Utils.shared().showToast("Coming soon", 2);
            }
            let e = { sourceType: CommDefine.TawkUser_Feedback_Source.Kyc, groupType: CommDefine.TawkUser_Feedback_Source.Kyc_Group.Verify };
            Utils.shared().doJumpLogic(PushEvent.JUMP_TO_FEEDBACK, e);
        }
        else if ("clearotp" == t) {
            this.otpNumberNode.getChildByName("otp").getChildByName("edit_otp").getComponent(EditBox).string = "";
            this.otpNumberNode.getChildByName("clear_btn").active = false;
        }
        else if ("otp" == t) {
            if (sys.now() - this._lastClick < 500) {
                return;
            }
            this._lastClick = sys.now();
            this.checkAndSendOtp();
        }
        else if ("get_img" == t) {
            if (sys.now() - this._lastClick < 500) {
                return;
            }
            this._lastClick = sys.now();
        }
        else if ("clearcapt" == t) {
            let e = this.captNumberNode.getChildByName("EditBox");
            e.getComponent(EditBox).string = "";
            e.getComponent(EditBox).blur();
            this.captNumberNode.getChildByName("clear_btn").active = false;
        }
        else if ("code" == t) {
            if (sys.now() - this._lastClick < 500) {
                return;
            }
            this._lastClick = sys.now();
            this.checkAndSendOtp();
        }
    }
    checkAndSendOtp() {
        if (this.cardNumberNode) {
            let e = this.cardNumberNode.getChildByName("EditBox");
            if (this.cardNumberStr = ToolUtils.isSafeString(e.getComponent(EditBox).string), 12 != this.cardNumberStr.length) {
                return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("utils.text78"), 3);
            }
            Utils.shared().showLoading(60, true, (() => {
            }));
            let t = 0;
            2 == User.shared().data.card_check && (t = 1);
            HttpManager.shared().doGetCommonRequest({ is_sub_data: t, aad_card: this.cardNumberStr }, HttpRequest.GetOtpKycOnline, this.listenGetCodeCall.bind(this));
        }
    }
    clearCaptNum() {
        this.captNumberNode.getChildByName("EditBox").getComponent(EditBox).string = "";
        this.updateCaptNumberStatus();
    }
    clearOtpNum() {
        this.otpNumberNode.getChildByName("otp").getChildByName("edit_otp").getComponent(EditBox).string = "";
        this.updateOptNumberStatus();
    }
    listenGetCodeCall(e, t, i) {
        if (Utils.shared().hideLoading(), 200 !== i) {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text37"), 3);
        }
        else {
            let e = ToolUtils.parseJson(t);
            if (0 === e.ret) {
                let t = 60;
                sys.isObjectValid(e.data.timeout) && (t = e.data.timeout);
                sys.isObjectValid(e.data.session_id) && e.data.session_id.length > 0 && (this.session_id = e.data.session_id);
                User.shared().code_timeout = t;
                Utils.shared().showToast(i18nMgr.shared().getValueByKey("bind_mobile.verification_tips"), 2);
                this.unschedule(this.refreshCodeBtn);
                this.refreshCodeBtn();
                this.schedule(this.refreshCodeBtn, 1);
            }
            else {
                4027 === e.ret ? (User.shared().data.submit_left_hour = e.data.submit_left_seconds, Utils.shared().doJumpLogic(PushEvent.Custom_TO_KycLimitTip), TweenTool.delayAct(this.node, (() => {
                    this.onBackView();
                }), 1, true)) : e.desc && e.desc.length > 0 && Utils.shared().showToast(e.desc, 3);
            }
        }
    }
    updateCaptNumberStatus() {
        if (this.captNumberNode) {
            let e = this.captNumberNode.getChildByName("EditBox");
            this.captNumberStr = ToolUtils.isSafeString(e.getComponent(EditBox).string);
            this.captNumberStr.length > 0 && (0 == User.shared().data.card_check || 3 == User.shared().data.card_check) ? this.captNumberNode.getChildByName("clear_btn").active = true : this.captNumberNode.getChildByName("clear_btn").active = false;
        }
    }
    updateCardNumberStatus() {
        if (this.cardNumberNode) {
            let e = this.cardNumberNode.getChildByName("EditBox");
            this.cardNumberStr = ToolUtils.isSafeString(e.getComponent(EditBox).string);
            this.cardNumberStr.length > 0 && (0 == User.shared().data.card_check || 3 == User.shared().data.card_check) ? this.cardNumberNode.getChildByName("del_btn").active = true : this.cardNumberNode.getChildByName("del_btn").active = false;
        }
    }
    updateOptNumberStatus() {
        if (this.otpNumberNode) {
            let e = this.otpNumberNode.getChildByName("otp").getChildByName("edit_otp").getComponent(EditBox);
            if (null == e.string || "" == e.string) {
                return void (this.otpNumberNode.getChildByName("clear_btn").active = false);
            }
            this.otpNumberNode.getChildByName("clear_btn").active = true;
            /^([0-9]{8,16})$/.test(e.string);
        }
    }
    onEditBoxChanged(e, t, i) {
        "card_number" == i ? this.updateCardNumberStatus() : "otp" == i ? this.updateOptNumberStatus() : "capt" == i && this.updateCaptNumberStatus();
    }
    onEditBoxEnded(e, t) {
        "card_number" == t ? this.updateCardNumberStatus() : "otp" == t ? this.updateOptNumberStatus() : "capt" == t && this.updateCaptNumberStatus();
    }
    onNextButtonClick(e, t) {
        if (SoundManager.shared().playFx("click"), !this._bBtnEnable) {
            return;
        }
        if (this._bBtnEnable = false, TweenTool.delayAct(this.node, (() => {
            this._bBtnEnable = true;
        }), 1, true), !User.shared().checkLocationPermit(CheckModule.KYC)) {
            return;
        }
        if (sys.isObjectValid(User.shared().newKycData.kyc_list) && sys.isObjectValid(User.shared().newKycData.kyc_list.reason) && User.shared().newKycData.kyc_list.reason > 0 && (User.shared().newKycData.kyc_list.reason = "", User.shared().newKycData.kyc_list.fast_reason = "", this.updateErrTips()), 12 !== ToolUtils.isSafeString(this.cardNumberStr).length) {
            return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text78"), 2);
        }
        if (0 == ToolUtils.isSafeString(this.captNumberStr).length) {
            return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("kyc.kyc_capt"), 2);
        }
        Utils.shared().showLoading(60, true, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text37"), 3);
        }));
        let i = 0;
        2 == User.shared().data.card_check && (i = 1);
        HttpManager.shared().doGetCommonRequest({ is_sub_data: i, aad_card: this.cardNumberStr, session_id: this.session_id, captcha: this.captNumberStr }, HttpRequest.GetOtpKycOnline, this.listenGetCodeCall.bind(this));
    }
    onSumbitButtonClick(e, t) {
        if (SoundManager.shared().playFx("click"), !this._bBtnEnable) {
            return;
        }
        if (this._bBtnEnable = false, TweenTool.delayAct(this.node, (() => {
            this._bBtnEnable = true;
        }), 1, true), !User.shared().checkLocationPermit(CheckModule.KYC)) {
            return;
        }
        if (sys.isObjectValid(User.shared().newKycData.collect_list) && Array.isArray(User.shared().newKycData.collect_list)) {
            for (let e = 0; e < User.shared().newKycData.collect_list.length; e++) {
                if (1 == User.shared().newKycData.collect_list[e].type) {
                    User.shared().newKycData.collect_list[e].reason = "";
                    this.updateErrTips();
                    break;
                }
            }
        }
        let i = this.otpNumberNode.getChildByName("otp").getChildByName("edit_otp").getComponent(EditBox), a = ToolUtils.isSafeString(i.string);
        if (6 !== a.length) {
            return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text63"), 2);
        }
        Utils.shared().showLoading(60, true, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text37"), 3);
        }));
        let s = 0;
        2 == User.shared().data.card_check && (s = 1);
        HttpManager.shared().doGetCommonRequest({ is_sub_data: s, aad_card: this.cardNumberStr, otp: a, session_id: this.session_id }, HttpRequest.SubmitKycOffline, this.listenSubmitCall.bind(this));
    }
    listenSubmitCall(e, t, i) {
        if (200 !== i) {
            ToolUtils.isObjValid(this.node) && (Utils.shared().hideLoading(), Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text37"), 2));
        }
        else {
            try {
                let e = ToolUtils.parseJson(t);
                if (0 === e.ret) {
                    let t = e.data.card_check;
                    sys.isObjectValid(e.data.collect_list) && Array.isArray(e.data.collect_list) && (User.shared().newKycData.collect_list = e.data.collect_list);
                    sys.isObjectValid(e.data.msg) && e.data.msg.length > 0 && Utils.shared().showToast(e.data.msg, 3);
                    User.shared().code_timeout = 0;
                    this.refreshCodeBtn();
                    sys.isObjectValid(e.data.loading_seconds) && Number(e.data.loading_seconds) > 0 ? ToolUtils.isObjValid(this.node) && (1 == t && (this.rootNode.getChildByName("submit_btn").getComponent(Button).interactable = false, i18nMgr.shared().changeLabelLanguage(this.rootNode.getChildByName("submit_btn").getChildByName("wz").getComponent(Label), "kyc.verity_pending", true)), Utils.shared().showLoading(Number(e.data.loading_seconds), true, (() => {
                        Utils.shared().hideLoading();
                        ToolUtils.isObjValid(this.node) && this.onBackView();
                        Utils.shared().showToast(i18nMgr.shared().getValueByKey("kyc.submit_success"), 3.5);
                    }), ToolUtils.getIsNormalDirection(), 1)) : (ToolUtils.isObjValid(this.node) && Utils.shared().hideLoading(), 2 != t && 1 != t || ToolUtils.isObjValid(this.node) && (2 == t && Utils.shared().showToast(i18nMgr.shared().getValueByKey("kyc.KYC_Verify_Suc"), 3.5), ToolUtils.isObjValid(this.node) && this.onBackView()), PushCenter.shared().pushEvent(GameConfig.Update_Kyc, User.shared().data.kyc_check));
                }
                else if (4027 === e.ret) {
                    User.shared().data.submit_left_hour = e.data.submit_left_seconds;
                    Utils.shared().doJumpLogic(PushEvent.Custom_TO_KycLimitTip);
                    TweenTool.delayAct(this.node, (() => {
                        this.onBackView();
                    }), 1, true);
                }
                else {
                    ToolUtils.isObjValid(this.node) && (Utils.shared().hideLoading(), e.desc && e.desc.length > 0 && Utils.shared().showToast(e.desc, 2));
                    let t = e.ret + ToolUtils.isSafeString(e.desc);
                    HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Hall, event: ReportConfig.hall_evt.kyc_submit_fail, kyc_err: t });
                }
            }
            catch (e) {
                ToolUtils.isObjValid(this.node) && Utils.shared().hideLoading();
                let t = ToolUtils.isSafeString(e.toString());
                HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Hall, event: ReportConfig.hall_evt.kyc_submit_fail, kyc_err: t });
            }
        }
    }
    onBackView(e = true) {
        e && (Utils.shared().hideLoading(), this.closeUICallBack && this.closeUICallBack(), this.bShowPushAnim ? (this._closed = true, ToolUtils.showPushAnim(this.node, 1, (() => {
            ToolUtils.isObjValid(this.node) && this.node.destroy();
        }))) : ToolUtils.isObjValid(this.node) && this.node.destroy());
    }
    updateCardEditStatus(e) {
        this.cardNumberNode.getChildByName("mask").active = !e;
    }
    fitScreen() {
        ToolUtils.adaptSafeArea(this.rootNode);
        let e = sys.getSafeAreaRect().y;
        this.rootNode.getChildByName("tips").getComponent(Widget).bottom = 120 - e;
        this.rootNode.getChildByName("submit_btn").getComponent(Widget).bottom = 20 - e;
        this.rootNode.getChildByName("next_btn").getComponent(Widget).bottom = 20 - e;
        2 == i18nMgr.shared().language && (this.rootNode.getChildByName("tips").getComponent(Widget).bottom = 150 - e);
    }
}
