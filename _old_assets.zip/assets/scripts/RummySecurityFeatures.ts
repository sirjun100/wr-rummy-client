// @ts-nocheck
// Recovered from index.js:485
import { _decorator } from "cc";
import SoundManager from "./SoundManager";
import BaseLayer from "./BaseLayer";
import { ToolUtils } from "./ToolUtils";
const { ccclass } = _decorator;
@ccclass("RummySecurityFeatures")
export class RummySecurityFeatures extends BaseLayer {
    onLoad() {
        this.bIsInGame = true;
    }
    start() {
        super.start();
        let t = this.node.getChildByName("bg");
        ToolUtils.showFullScreen(t);
        this.startShowAnim(this.node.getChildByName("rootNode"));
    }
    onCloseClick(t, e) {
        SoundManager.shared().playFx("click");
        ToolUtils.isObjValid(this.node) && this.node.destroy();
    }
    setTidKey(t) {
        this.tid_key = t;
    }
}
