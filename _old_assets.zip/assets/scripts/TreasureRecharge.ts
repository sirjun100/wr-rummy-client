// @ts-nocheck
// Recovered from index.js:645
import { _decorator, Button, director, instantiate, Label, Node, SpriteAtlas, sys, v3, Vec3 } from "cc";
import BaseLayer from "./BaseLayer";
import { ToolUtils } from "./ToolUtils";
import BundleNameDefined from "./BundleNameDefined";
import TweenTool from "./TweenTool";
import PushCenter from "./PushCenter";
import PushEvent from "./PushEvent";
import CommDefine from "./CommDefine";
import Utils from "./Utils";
import SoundManager from "./SoundManager";
import User from "./User";
const { ccclass, property } = _decorator;
@ccclass("TreasureRecharge")
export class TreasureRecharge extends BaseLayer {
    public TAG: string = "TreasureRecharge";
    @property(Node)
    public rootNode: Node = null;
    @property(Node)
    public maskNode: Node = null;
    @property(Node)
    public goodsScrollContent: Node = null;
    @property(SpriteAtlas)
    public rewardPlist: SpriteAtlas = null;
    @property(Node)
    public giftRewItem: Node = null;
    public rechargeNode: any[] = [];
    public isNext: boolean = false;
    public isquick: boolean = false;
    public _nVid: number = 0;
    public _self_rec: boolean = false;
    public _ext_recharge: any = null;
    public _linkId: number = 0;
    public _reportScene: any = -1;
    public _pop_souce: number = 0;
    public _has_close: boolean = false;
    public checkKyc: number = 0;
    public rechragePos: any[] = [];
    public _finishAnim: boolean = false;
    public _lastClick: number = 0;
    public _goodsList: any[] = [];
    initParaData(e, t = 0) {
        this.isNext = e.isNext;
        sys.isObjectValid(e.vid) ? this._nVid = e.vid : this._nVid = ToolUtils.curRoomId;
        sys.isObjectValid(e) && (sys.isObjectValid(e.isquick) && (this.isquick = e.isquick), sys.isObjectValid(e.checkKyc) && (this.checkKyc = e.checkKyc), sys.isObjectValid(e.pop_souce) && (this._pop_souce = e.pop_souce), sys.isObjectValid(e.reportScene) && (this._reportScene = e.reportScene), sys.isObjectValid(e.link_id) && e.link_id > 0 && (this._linkId = e.link_id), sys.isObjectValid(e.self_rec) && (this._self_rec = e.self_rec), sys.isObjectValid(e.ext_recharge) && (this._ext_recharge = e.ext_recharge), sys.isObjectValid(e.goods_list) && Array.isArray(e.goods_list) && (this._goodsList = e.goods_list || []));
    }
    start() {
        super.start();
        this._linkId = this._linkId > 0 ? this._linkId : sys.now();
        this._reportScene = this._reportScene >= 0 ? this._reportScene : ToolUtils.getIsInRoom() ? 2 : 1;
        this.giftRewItem.active = false;
        for (let e, t = 0; t < 3; t++) {
            if (e = this.goodsScrollContent.getChildByName("goodsItem" + t), ToolUtils.isObjValid(e)) {
                this.rechargeNode[t] = e;
                let i = new Vec3;
                this.rechargeNode[t].getPosition(i);
                this.rechragePos.push(i);
            }
        }
        if (ToolUtils.showFullScreen(this.maskNode), sys.isObjectValid(this._goodsList) && this._goodsList && this.updateGoodsScrollView(), PushCenter.shared().pushEvent(PushEvent.HideGameOverBg), director.getScene().name == BundleNameDefined.hall_scene) {
            for (let e = 0, t = this.rechargeNode.length; e < t; e++) {
                this.rechargeNode[e].active = false;
            }
        }
        this._finishAnim = false;
        this.startShowAnim(this.rootNode, (() => {
            if (director.getScene().name == BundleNameDefined.hall_scene && this._goodsList) {
                for (let e = 0, t = this.rechargeNode.length; e < t; e++) {
                    TweenTool.stopNodeAction(this.rechargeNode[e]);
                    this.rechargeNode[e].setPosition(v3(this.rechragePos[e].x + 660, this.rechragePos[e].y));
                    let t = TweenTool.delayAct(this.rechargeNode[e], (() => {
                        this._finishAnim = true;
                        this._goodsList.length > 0 && this._goodsList[e] && (this.rechargeNode[e].active = true);
                    }), 0.04 * e, false), i = TweenTool.moveToByFade(this.rechargeNode[e], 0.15, v3(this.rechragePos[e].x - 20, this.rechragePos[e].y), 0, 1, false), s = TweenTool.moveTo(this.rechargeNode[e], 0.1, v3(this.rechragePos[e].x + 15, this.rechragePos[e].y), null, false), r = TweenTool.moveTo(this.rechargeNode[e], 0.06, v3(this.rechragePos[e].x, this.rechragePos[e].y), null, false);
                    TweenTool.sequence(this.rechargeNode[e], true, (() => {
                    }), t, i, s, r);
                }
            }
        }));
    }
    updateGoodsScrollView() {
        if (sys.isObjectValid(this._goodsList) && this._goodsList && Array.isArray(this._goodsList)) {
            for (let e = 0, t = this.rechargeNode.length; e < t; e++) {
                if (sys.isObjectValid(this._goodsList) && sys.isObjectValid(this._goodsList[e])) {
                    let t = this._goodsList[e];
                    this.rechargeNode[e].active = !!this._finishAnim;
                    this.initGoodsItemView(this.rechargeNode[e], t, e);
                }
                else {
                    this.rechargeNode[e].active = false;
                }
            }
        }
    }
    initGoodsItemView(e, t, i) {
        if (!(e && t && sys.isObjectValid(t.reward) && sys.isObjectValid(t.id) && t.reward && Array.isArray(t.reward))) {
            return;
        }
        let s = e.getChildByName("name"), r = e.getChildByName("act_node"), a = e.getChildByName("gift_node"), o = r.getChildByName("play_now"), c = r.getChildByName("rewlayout"), n = c.getChildByName("rewleaf"), l = c.getChildByName("play_tips"), u = a.getChildByName("btn_addcash"), _ = a.getChildByName("rewlayout");
        if (s.getComponent(Label).string = "" + t.name, sys.isObjectValid(t.act_id) && t.act_id > 0) {
            r.active = true;
            a.active = false;
            sys.isObjectValid(t.content) && t.content ? (l.active = true, l.getComponent(Label).string = "" + t.content) : l.active = false;
            let e = o.getComponent(Button);
            e && e.clickEvents.length > 0 && (e.clickEvents[0].customEventData = "play_now");
            t.reward[0] ? (n.active = true, this.updateRewardSprite(n.getChildByName("ico"), Number(t.reward[0].type)), n.getChildByName("num").getComponent(Label).string = "") : n.active = false;
        }
        else if (sys.isObjectValid(t.goods_id) && t.goods_id) {
            r.active = false;
            a.active = true;
            let e = u.getComponent(Button);
            e && e.clickEvents.length > 0 && (e.clickEvents[0].customEventData = "" + i);
            let s = u.getChildByName("cur");
            sys.isObjectValid(t.price) ? (s.active = true, s.getComponent(Label).string = "₹" + t.price) : s.active = false;
            let o = a.getChildByName("rate");
            sys.isObjectValid(t.rate) && t.rate ? (o.active = true, o.getChildByName("tx").getComponent(Label).string = t.rate) : o.active = false;
            this.updateGiftRewLayoutUI(_, t.reward);
        }
        else {
            r.active = a.active = false;
        }
    }
    updateGiftRewLayoutUI(e, t) {
        if (e && t && Array.isArray(t)) {
            this.giftRewItem.active = false;
            e.destroyAllChildren();
            for (let i = 0, s = t.length; i < s; i++) {
                let s = instantiate(this.giftRewItem);
                s.active = true;
                e.addChild(s);
                this.updateRewardSprite(s.getChildByName("ico"), Number(t[i].type));
                s.getChildByName("num").getComponent(Label).string = "" + t[i].num;
            }
        }
    }
    updateRewardSprite(e, t) {
        ToolUtils.isSafeString(CommDefine.rewardPistName[t]).length > 0 && Utils.shared().setImage(e, CommDefine.rewardPistName[t], this.rewardPlist);
    }
    onButtonClick(e, t) {
        if (SoundManager.shared().playFx("click"), "close" == t) {
            1 == this.checkKyc && Utils.shared().checkAddCashKyc();
            this.onBackView();
        }
        else if ("play_now" == t) {
            PushCenter.shared().pushEvent(PushEvent.CloseTreasure);
            let e = { play: 0, player: 6 };
            Utils.shared().doJumpLogic(PushEvent.JUMP_TO_CASH_ROOM, e);
            this.onBackView();
        }
    }
    onBtnAddCashClick(e, t) {
        if (sys.now() - this._lastClick < 300) {
            return;
        }
        this._lastClick = sys.now();
        SoundManager.shared().playFx("click");
        let i = Number(t);
        if (i >= 0 && this._goodsList && this._goodsList.length > 0) {
            if (i >= this._goodsList.length) {
                return;
            }
            if (ToolUtils.isObjValid(this.node)) {
                if (!User.shared().checkCanRecharge()) {
                    return void this.onBackView();
                }
                let e = this._goodsList[i];
                if (!(e && e.goods_id && e.price && e.id)) {
                    return;
                }
                let t = { pway: "", price: e.price, goodsId: e.goods_id, link_id: this._linkId, act_id: PushEvent.JUMP_TO_Treasure, act84_shop_id: e.id, act84_shop: this._self_rec ? 1 : 0 };
                sys.isObjectValid(this._ext_recharge) && this._ext_recharge && 2 == this._ext_recharge.source && this._ext_recharge.is_guide && this._ext_recharge.is_cash && (t.is_guide = this._ext_recharge.is_guide, t.is_cash = this._ext_recharge.is_cash);
                User.shared().startPay(t);
            }
        }
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().pushEvent(PushEvent.ShowGameOverBg);
        PushCenter.shared().removeListenersByTag(this);
        TweenTool.stopNodeAction(this.node);
        this.unscheduleAllCallbacks();
    }
    onBackView() {
        if (ToolUtils.isObjValid(this.node)) {
            if (this._has_close) {
                return;
            }
            this._has_close = true;
            this.node.destroy();
        }
    }
}
