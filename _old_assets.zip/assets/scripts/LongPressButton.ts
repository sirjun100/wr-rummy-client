// @ts-nocheck
// Recovered from index.js:257
import { _decorator, Component, EventHandler, Node, tween, Vec3 } from "cc";
const { ccclass, property } = _decorator;
@ccclass("LongPressButton")
export class LongPressButton extends Component {
    @property({ tooltip: "Long press to trigger (in seconds)" })
    public longPressTime: number = 1;
    @property({ tooltip: "Zoom in when pressed" })
    public pressScale: number = 0.9;
    @property({ tooltip: "Scaling animation duration (seconds)" })
    public scaleDuration: number = 0.1;
    @property({ type: [EventHandler], tooltip: "Normal click callback (short press)" })
    public clickEvents: [
        EventHandler
    ] = [];
    @property({ type: [EventHandler], tooltip: "Long press to callback" })
    public longPressEvents: [
        EventHandler
    ] = [];
    public _pressTimer: number = 0;
    public _isPressing: boolean = false;
    public _longPressed: boolean = false;
    public _originalScale: Vec3 = new Vec3;
    public interactable: boolean = true;
    onLoad() {
        this.node.on(Node.EventType.TOUCH_START, this.onTouchStart, this);
        this.node.on(Node.EventType.TOUCH_END, this.onTouchEnd, this);
        this.node.on(Node.EventType.TOUCH_CANCEL, this.onTouchCancel, this);
    }
    start() {
        this._originalScale.set(this.node.scale);
    }
    onDestroy() {
        this.node.off(Node.EventType.TOUCH_START, this.onTouchStart, this);
        this.node.off(Node.EventType.TOUCH_END, this.onTouchEnd, this);
        this.node.off(Node.EventType.TOUCH_CANCEL, this.onTouchCancel, this);
    }
    onTouchStart(t) {
        this.interactable && (this._isPressing = true, this._longPressed = false, this._pressTimer = 0, tween(this.node).to(this.scaleDuration, { scale: this._originalScale.clone().multiplyScalar(this.pressScale) }).start());
    }
    onTouchEnd(t) {
        this.interactable && (this._isPressing = false, tween(this.node).to(this.scaleDuration, { scale: this._originalScale }).start(), this._longPressed || this.triggerClickEvents(t));
    }
    onTouchCancel(t) {
        this.interactable && (this._isPressing = false, tween(this.node).to(this.scaleDuration, { scale: this._originalScale }).start());
    }
    update(t) {
        this.interactable && this._isPressing && !this._longPressed && (this._pressTimer += t, this._pressTimer >= this.longPressTime && (this._longPressed = true, this.triggerLongPressEvents()));
    }
    triggerClickEvents(t) {
        EventHandler.emitEvents(this.clickEvents, this);
    }
    triggerLongPressEvents() {
        EventHandler.emitEvents(this.longPressEvents, this);
    }
}
