// @ts-nocheck
// Recovered from index.js:589
import { _decorator, color, instantiate, Label, Node, ProgressBar, size, Sprite, sys, UITransform, view, Widget } from "cc";
import SoundManager from "./SoundManager";
import PushCenter from "./PushCenter";
import { TLog } from "./TLog";
import Utils from "./Utils";
import User from "./User";
import BaseLayer from "./BaseLayer";
import GameConfig from "./GameConfig";
import PushEvent from "./PushEvent";
import TweenTool from "./TweenTool";
import { ToolUtils } from "./ToolUtils";
import PhpReportDefined from "./PhpReportDefined";
const { ccclass, property } = _decorator;
@ccclass("SportCricket_TeamPkMsg")
export class SportCricket_TeamPkMsg extends BaseLayer {
    public TAG: string = "SportCricket_TeamPkMsg";
    @property(Node)
    public rootNode: Node = null;
    @property(Node)
    public goldNode: Node = null;
    @property(Node)
    public statRoot: Node = null;
    @property(Node)
    public contentRoot: Node = null;
    @property(Node)
    public matchMoban: Node = null;
    public _closed: boolean = false;
    public bShowPushAnim: boolean = true;
    public _lastClick: number = 0;
    public _isSendMsg: boolean = false;
    public taskAwardIconMap: Map = new Map;
    public _match_id: number = 0;
    public _source: any = null;
    public lastClick: number = 0;
    public _fromType: number = 0;
    public _match_state: number = 1;
    public _head_source: any = null;
    public _lastNode: any = null;
    public _call: any = null;
    onLoad() {
        PushCenter.shared().addListener(GameConfig.Update_Money, (t => {
            try {
                ToolUtils.isObjValid(this.node) && this.updateGold(t);
            }
            catch (t) {
                TLog.printError(this.TAG, GameConfig.Update_Money, t);
            }
        }), this);
        PushCenter.shared().addListener(PushEvent.commentDownloaderImg, (t => {
            try {
                if (ToolUtils.isObjValid(this.node) && this.taskAwardIconMap.size > 0) {
                    for (const [e, i] of this.taskAwardIconMap) {
                        i == t && sys.isObjectValid(e) && ("rteama_icon" == e.name || "rteamb_icon" == e.name ? Utils.shared().updateNetImage(e, t, size(80, 80)) : Utils.shared().updateNetImage(e, t, size(60, 60)));
                    }
                }
            }
            catch (t) {
                TLog.printError(this.TAG, PushEvent.commentDownloaderImg, t);
            }
        }), this);
        this.fitLuckyTheme();
    }
    fitLuckyTheme() {
        0 != GameConfig.NATIVE_GAME_APP_TYPE && (this.rootNode.getChildByName("top_node").getChildByName("top_bg").getComponent(Sprite).color = color(12, 26, 60, 255), this.goldNode.getChildByName("coin").getComponent(Label).color = color(251, 220, 0, 255));
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().removeListenersByTag(this);
        this.unscheduleAllCallbacks();
    }
    init(t) {
        sys.isObjectValid(t) && sys.isObjectValid(t.match_id) && (this._match_id = t.match_id);
        sys.isObjectValid(t) && sys.isObjectValid(t.source) && (this._source = { ...t.source });
        sys.isObjectValid(t) && sys.isObjectValid(t.head_source) && (this._head_source = t.head_source);
        sys.isObjectValid(t) && sys.isObjectValid(t.fromType) && (this._fromType = t.fromType);
        sys.isObjectValid(t) && sys.isObjectValid(t.call) && (this._call = t.call);
        sys.isObjectValid(t) && sys.isObjectValid(t.lastNode) && (this._lastNode = t.lastNode);
    }
    start() {
        super.start();
        this.initView();
        this.bShowPushAnim && (ToolUtils.showPushAnim(this.node, 0, (() => {
            sys.isObjectValid(this._lastNode) && (this._lastNode.active = false);
            this.refreshMatchView();
        })), this.refreshView());
        this.updateGold(User.shared().data.money);
    }
    updateGold(t) {
        let e = this.goldNode.getChildByName("coin");
        null != t && e && (e.getComponent(Label).string = ToolUtils.parse_double(t));
    }
    refreshMatchView() {
        sys.isObjectValid(this._head_source) && sys.isObjectValid(this._head_source.recent_match) && this._head_source.recent_match.length > 0 ? (this.contentRoot.getChildByName("nodata").active = false, this.addMatchView(this.contentRoot.getChildByName("recent_match"), this._head_source.recent_match)) : this.contentRoot.getChildByName("nodata").active = true;
    }
    refreshView() {
        if (sys.isObjectValid(this._head_source)) {
            let t = this.contentRoot.getChildByName("head_root");
            sys.isObjectValid(this._head_source.total_matches_played) && (t.getChildByName("play_num").getComponent(Label).string = this._head_source.total_matches_played + "");
            let e = Number(this._head_source.total_matches_played);
            t.getChildByName("awin_title").getComponent(Label).string = this._source.recent.teama.short_name + " Won";
            t.getChildByName("bwin_title").getComponent(Label).string = this._source.recent.teamb.short_name + " Won";
            sys.isObjectValid(this._head_source.teama_win) && (t.getChildByName("awin_desc").getComponent(Label).string = String(this._head_source.teama_win), t.getChildByName("awin_progress").getComponent(ProgressBar).progress = Number(this._head_source.teama_win) / e);
            sys.isObjectValid(this._head_source.teamb_win) && (t.getChildByName("bwin_desc").getComponent(Label).string = String(this._head_source.teamb_win), t.getChildByName("bwin_progress").getComponent(ProgressBar).progress = Number(this._head_source.teamb_win) / e);
            sys.isObjectValid(this._head_source.total_match_drawn) && (t.getChildByName("tie_desc").getComponent(Label).string = String(this._head_source.total_match_drawn), t.getChildByName("tie_progress").getComponent(ProgressBar).progress = Number(this._head_source.total_match_drawn) / e);
            sys.isObjectValid(this._head_source.total_match_cancelled) && (t.getChildByName("no_desc").getComponent(Label).string = String(this._head_source.total_match_cancelled), t.getChildByName("no_progress").getComponent(ProgressBar).progress = Number(this._head_source.total_match_cancelled) / e);
        }
        sys.isObjectValid(this._head_source) && (this.contentRoot.getChildByName("recent_root").getChildByName("teama_name").getComponent(Label).string = this._source.teama.short_name, this.contentRoot.getChildByName("recent_root").getChildByName("teamb_name").getComponent(Label).string = this._source.teamb.short_name, this.taskAwardIconMap.set(this.contentRoot.getChildByName("recent_root").getChildByName("teama_icon"), this._source.teama.logo_url), Utils.shared().updateNetImage(this.contentRoot.getChildByName("recent_root").getChildByName("teama_icon"), this._source.teama.logo_url, size(80, 80)), this.taskAwardIconMap.set(this.contentRoot.getChildByName("recent_root").getChildByName("teamb_icon"), this._source.teamb.logo_url), Utils.shared().updateNetImage(this.contentRoot.getChildByName("recent_root").getChildByName("teamb_icon"), this._source.teamb.logo_url, size(80, 80)), sys.isObjectValid(this._head_source.teama_win) && sys.isObjectValid(this._head_source.teamb_win) && (this.contentRoot.getChildByName("recent_root").getChildByName("result").getComponent(Label).string = this._head_source.teama_win + " : " + this._head_source.teamb_win));
    }
    onCloseButtonClick(t, e) {
        if (SoundManager.shared().playFx("click"), "back_btn" == e) {
            if (this._closed) {
                return;
            }
            this.onBackView();
        }
    }
    initView() {
        if (this.fitScreen(), sys.isObjectValid(this._source)) {
            let t = this.rootNode.getChildByName("top_node").getChildByName("lefttime");
            t.getComponent(Label).string = Utils.shared().parseCountDown(this._source.time_left);
            sys.isObjectValid(this._source.status) && (this._match_state = this._source.status);
            0 == this._source.time_left && 1 == this._source.status ? (t.getComponent(Label).string = this._source.start_day, sys.isObjectValid(this._source.is_current_day) && 1 == Number(this._source.is_current_day) && (this._source.status = 3, t.getComponent(Label).string = "Live")) : 1 == this._source.status ? TweenTool.myschedule(t, 1, (() => {
                ToolUtils.isObjValid(this.node) && (this._source.time_left > 0 ? t.getComponent(Label).string = Utils.shared().parseCountDown(this._source.time_left) : (this._source.status = 3, t.getComponent(Label).string = "Live", TweenTool.stopNodeAction(t)));
            })) : 3 == this._source.status ? (TweenTool.stopNodeAction(t), t.getComponent(Label).string = "Live") : 4 == this._source.status && (TweenTool.stopNodeAction(t), t.getComponent(Label).string = "Cancel");
            PushCenter.shared().addListener(PushEvent.UpdateYes11CurMatchLeftTime, (e => {
                try {
                    ToolUtils.isObjValid(this.node) && e.match_id == this._match_id && (this._source.time_left = e.time_left, this._source.is_current_day = e.is_current_day, this._match_state = e.status, 3 == e.status ? (TweenTool.stopNodeAction(t), t.getComponent(Label).string = "Live") : 4 == e.status && (TweenTool.stopNodeAction(t), t.getComponent(Label).string = "Cancel"));
                }
                catch (t) {
                    TLog.printError(this.TAG, PushEvent.UpdateYes11CurMatchLeftTime, t);
                }
            }), this);
        }
    }
    onButtonClick(t, e) {
        SoundManager.shared().playFx("click");
        sys.now() - this._lastClick < 500 || (this._lastClick = sys.now(), "add_chip" == e && (Utils.shared().showStoreView(null, null), User.shared().updatePayScene(PhpReportDefined.pay_scene.hall_cricket)));
    }
    addMatchView(t, e) {
        for (let i = 0; i < e.length; i++) {
            let s = instantiate(this.matchMoban);
            s.active = true;
            t.addChild(s);
            sys.isObjectValid(e[i].teama) && sys.isObjectValid(e[i].teama.logo_url) && (this.taskAwardIconMap.set(s.getChildByName("teama_icon"), e[i].teama.logo_url), Utils.shared().updateNetImage(s.getChildByName("teama_icon"), e[i].teama.logo_url, size(60, 60)));
            sys.isObjectValid(e[i].teamb) && sys.isObjectValid(e[i].teamb.logo_url) && (this.taskAwardIconMap.set(s.getChildByName("teamb_icon"), e[i].teamb.logo_url), Utils.shared().updateNetImage(s.getChildByName("teamb_icon"), e[i].teamb.logo_url, size(60, 60)));
            sys.isObjectValid(e[i].result) && e[i].result.length > 0 && (s.getChildByName("team_result").getComponent(Label).string = e[i].result);
            let a = -1;
            sys.isObjectValid(e[i].winning_team_id) ? (e[i].winning_team_id == e[i].teama.team_id ? a = 1 : e[i].winning_team_id == e[i].teamb.team_id && (a = 2), 1 == a ? s.getChildByName("dot").getComponent(Sprite).color = color(77, 183, 92) : 2 == a ? s.getChildByName("dot").getComponent(Sprite).color = color(227, 64, 64) : s.getChildByName("dot").active = false) : s.getChildByName("dot").active = false;
            sys.isObjectValid(e[i].teama) && sys.isObjectValid(e[i].teama.short_name) && (s.getChildByName("teama_name").getComponent(Label).string = e[i].teama.short_name);
            sys.isObjectValid(e[i].teamb) && sys.isObjectValid(e[i].teamb.short_name) && (s.getChildByName("teamb_name").getComponent(Label).string = e[i].teamb.short_name);
            sys.isObjectValid(e[i].teama) && sys.isObjectValid(e[i].teama.scores_full) && (s.getChildByName("teama_score").getComponent(Label).string = e[i].teama.scores_full);
            sys.isObjectValid(e[i].teamb) && sys.isObjectValid(e[i].teamb.scores_full) && (s.getChildByName("teamb_score").getComponent(Label).string = e[i].teamb.scores_full);
            sys.isObjectValid(e[i].start_time) && (s.getChildByName("match_date").getComponent(Label).string = e[i].start_time);
            sys.isObjectValid(e[i].venue) && sys.isObjectValid(e[i].venue.name) && (s.getChildByName("venue").getComponent(Label).string = e[i].venue.name);
        }
    }
    onBackView(t = true) {
        t && (Utils.shared().hideLoading(), this.bShowPushAnim ? (this._closed = true, ToolUtils.isObjValid(this._lastNode) && (this._lastNode.active = true), ToolUtils.showPushAnim(this.node, 1, (() => {
            ToolUtils.isObjValid(this.node) && this.node.destroy();
        }))) : (ToolUtils.isObjValid(this._lastNode) && (this._lastNode.active = true), ToolUtils.isObjValid(this.node) && this.node.destroy()));
    }
    fitScreen() {
        ToolUtils.adaptSafeArea(this.rootNode);
        let t = sys.getSafeAreaRect().y, e = view.getVisibleSize();
        if (this.node.getComponent(UITransform).setContentSize(e.width, e.height), 0 != t) {
            let e = this.statRoot.getComponent(Widget).bottom;
            this.statRoot.getComponent(Widget).bottom = e - t;
        }
    }
}
