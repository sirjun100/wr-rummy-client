// @ts-nocheck
// Recovered from index.js:129
import { _decorator, Label, Node, sys, tween, Vec3 } from "cc";
import BaseLayer from "./BaseLayer";
import Utils from "./Utils";
import SoundManager from "./SoundManager";
import TweenTool from "./TweenTool";
import User from "./User";
import i18nMgr from "./i18nMgr";
import PushCenter from "./PushCenter";
import PushEvent from "./PushEvent";
import { CheckModule } from "./CommDefine";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("FreeMatchNotification")
export class FreeMatchNotification extends BaseLayer {
    @property(Node)
    public rootNode: Node = null;
    public _linkId: number = 0;
    public _nVid: number = 0;
    public _curBgView: any = null;
    public _ui_type: number = 0;
    public leftPushTime: number = 0;
    public free_match_action: any = null;
    public _callback: any = null;
    public lastClick: number = 0;
    public msg: any = null;
    public raceId: any = null;
    public isNext: boolean = false;
    onLoad() {
    }
    initParaData(t) {
        let e = this.rootNode.getChildByName("bgView0"), i = this.rootNode.getChildByName("bgView1");
        sys.isObjectValid(t) && (sys.isObjectValid(t) && sys.isObjectValid(t.isNext) && (this.isNext = t.isNext), 1 == t.ui_type ? (this._curBgView = i, e.active = false) : (this._curBgView = e, i.active = false), this._ui_type = t.ui_type, this._curBgView.active = true, this.msg = t.msg, this.refreshUI());
        sys.isObjectValid(t) && sys.isObjectValid(t.callback) && (this._callback = t.callback);
    }
    refreshUI() {
        let t = this._curBgView.getChildByName("entry").getComponent(Label), e = this._curBgView.getChildByName("ddl").getComponent(Label), i = this._curBgView.getChildByName("reward0"), s = this._curBgView.getChildByName("reward1");
        try {
            if (sys.isObjectValid(this.msg)) {
                let h = false;
                if (sys.isObjectValid(this.msg.cash) && Number(this.msg.cash) > 0 ? (i.active = true, h = true, i.getChildByName("num").getComponent(Label).string = "" + ToolUtils.parse_double(String(this.msg.cash), -1)) : i.active = false, sys.isObjectValid(this.msg.bonus) && Number(this.msg.bonus) > 0 ? (s.active = true, s.getChildByName("num").getComponent(Label).string = "" + ToolUtils.parse_double(String(this.msg.bonus), -1)) : s.active = false, h || s.setPosition(i.getPosition()), sys.isObjectValid(this.msg.raceid) && (this.raceId = this.msg.raceid), 1 == this._ui_type) {
                    if (sys.isObjectValid(this.msg.match_name) && (t.string = "" + this.msg.match_name), 0 == ToolUtils.isSafeNumber(this.msg.mode)) {
                        sys.isObjectValid(this.msg.joined) && sys.isObjectValid(this.msg.max_join) && (e.string = this.msg.joined + "/" + this.msg.max_join);
                    }
                    else if (1 == ToolUtils.isSafeNumber(this.msg.mode) || 3 == ToolUtils.isSafeNumber(this.msg.mode)) {
                        this.leftPushTime = ToolUtils.isSafeNumber(this.msg.cd);
                        let t = Utils.shared().getCountDownString(this.leftPushTime);
                        if (e.string = t, this.free_match_action && TweenTool.stopAction(this.free_match_action), 3 == ToolUtils.isSafeNumber(this.msg.mode) && this.leftPushTime <= 0) {
                            e.string = i18nMgr.shared().getValueByKey("freeMatchPush.enter");
                            i18nMgr.shared().changeLabelFontBold(e, true);
                        }
                        else {
                            let t = Utils.shared().getCountDownString(this.leftPushTime);
                            e.string = t;
                            this.free_match_action = TweenTool.myschedule(this.node, 1, this.updateFreeMatchPushTime.bind(this));
                        }
                    }
                }
                else if (sys.isObjectValid(this.msg.name) && (t.string = "" + this.msg.name), 0 == Number(this.msg.mode)) {
                    sys.isObjectValid(this.msg.end) && (e.string = "" + this.msg.end);
                }
                else if (1 == Number(this.msg.mode) || 3 == Number(this.msg.mode)) {
                    this.leftPushTime = Number(this.msg.end);
                    let t = Utils.shared().getCountDownString(this.leftPushTime);
                    if (e.string = t, this.free_match_action && TweenTool.stopAction(this.free_match_action), 3 == Number(this.msg.mode) && this.leftPushTime <= 0) {
                        e.string = i18nMgr.shared().getValueByKey("freeMatchPush.enter");
                        i18nMgr.shared().changeLabelFontBold(e, true);
                    }
                    else {
                        let t = Utils.shared().getCountDownString(this.leftPushTime);
                        e.string = t;
                        this.free_match_action = TweenTool.myschedule(this.node, 1, this.updateFreeMatchPushTime.bind(this));
                    }
                }
            }
        }
        catch (t) {
        }
    }
    updateFreeMatchPushTime() {
        this.leftPushTime = this.leftPushTime - 1;
        let t = this._curBgView.getChildByName("ddl").getComponent(Label);
        if (this.leftPushTime <= 0 && (this.free_match_action && (TweenTool.stopAction(this.free_match_action), this.free_match_action = null), 3 == Number(this.msg.mode))) {
            return t.string = i18nMgr.shared().getValueByKey("freeMatchPush.enter"), void i18nMgr.shared().changeLabelFontBold(t, true);
        }
        let e = Utils.shared().getCountDownString(this.leftPushTime);
        t.string = e;
    }
    start() {
        super.start();
        ToolUtils.showFullScreen(this.node.getChildByName("bg"));
        tween(this.rootNode).to(0.2, { scale: new Vec3(1.05, 1.05, 1.05) }).to(0.133, { scale: new Vec3(0.98, 0.98, 0.98) }).to(0.1, { scale: new Vec3(1, 1, 1) }).union().call((() => {
        })).start();
        this.lastClick = sys.now();
        this._linkId = this.lastClick;
    }
    onButtonClick(t, e) {
        if (SoundManager.shared().playFx("click"), "join" === e) {
            if (!User.shared().checkCanPlayCashGame(CheckModule.CASH_PLAY)) {
                return;
            }
            if (1 == Utils.shared().showFastKyc()) {
                return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("kyc.kyc_match"), 2);
            }
            User.shared().sendJoinMatch({ raceid: this.raceId });
        }
        this.onBackView();
    }
    onBackView() {
        ToolUtils.isObjValid(this.node) && (this.isNext && 0 == this._ui_type && PushCenter.shared().pushEvent(PushEvent.Update_NextPopActivity), 1 == this._ui_type && PushCenter.shared().pushEvent(PushEvent.FreeMatchPushHide), this.node.destroy());
    }
    onDestroy() {
        super.onDestroy();
        this.free_match_action && TweenTool.stopAction(this.free_match_action);
        this.free_match_action = null;
        this.unscheduleAllCallbacks();
    }
    update(t) {
    }
}
