// @ts-nocheck
// Recovered from index.js:59
import { _decorator, Component, Button, color, director, find, instantiate, Label, Node, ScrollView, size, sp, Sprite, SpriteAtlas, SpriteFrame, sys, tween, UITransform, v3, view } from "cc";
import PushCenter from "./PushCenter";
import { TLog } from "./TLog";
import { TransferPlatform } from "./TransferPlatform";
import Utils from "./Utils";
import GameConfig from "./GameConfig";
import PushEvent from "./PushEvent";
import User from "./User";
import SoundManager from "./SoundManager";
import BundleNameDefined from "./BundleNameDefined";
import { ToolUtils } from "./ToolUtils";
import TweenTool from "./TweenTool";
import CommDefine from "./CommDefine";
import LoadTableCpp from "./LoadTableCpp";
import PhpReportDefined from "./PhpReportDefined";
const { ccclass, property } = _decorator;
@ccclass("Carte")
export default class Carte extends Component {
    @property({ type: sp.Skeleton, displayName: "" })
    public head_img: sp.Skeleton = null;
    @property(Sprite)
    public head_club_kuang: Sprite = null;
    @property([SpriteFrame])
    public switch_imgs: SpriteFrame[] = [];
    @property([Node])
    public switchNodes: Node[] = [];
    @property(Label)
    public nameLabel: Label = null;
    @property(Node)
    public balance: Node = null;
    @property(Node)
    public topArrowNode: Node = null;
    @property(Label)
    public balance_numLabel: Label = null;
    @property(Label)
    public chip_numLabel: Label = null;
    @property(Label)
    public appVerLabel: Label = null;
    @property(Label)
    public useridLabel: Label = null;
    @property(ScrollView)
    public scrollview: ScrollView = null;
    @property([Node])
    public groupViews: Node[] = [];
    @property([Node])
    public tabViews: Node[] = [];
    @property([SpriteFrame])
    public club_headkuangs: SpriteFrame[] = [];
    @property(SpriteAtlas)
    public spAtlas617: SpriteAtlas = null;
    @property(SpriteFrame)
    public top617SpFrame: SpriteFrame = null;
    @property(SpriteFrame)
    public case617SpFrame: SpriteFrame = null;
    public cb: any = null;
    public lastTime: number = 0;
    public turningAction: any = null;
    public group_arrow_status: any[] = [1, 0, 0, 0, 0];
    public group_color: any = color(163, 0, 0);
    onLoad() {
        this.fitLuckyTheme();
    }
    fitLuckyTheme() {
        0 != GameConfig.NATIVE_GAME_APP_TYPE && (this.group_color = color(30, 66, 152, 255));
    }
    adaptScreenForMenu() {
        ToolUtils.adaptSafeArea(this.node.getChildByName("root"));
        view.getVisibleSize();
    }
    start() {
        this.adaptScreenForMenu();
        0 == GameConfig.CHIPS_MODLE ? this.balance_numLabel.string = ToolUtils.parse_double(User.shared().data.money, 2, true) : this.balance_numLabel.string = ToolUtils.parse_ChipNum2(User.shared().data.money_exe);
        this.chip_numLabel.string = ToolUtils.parse_double(User.shared().data.money_exe, -1, true);
        this.setUserInfo();
        this.useridLabel.string = "ID:" + User.shared().data.uid;
        this.update_clubInfo();
        for (let e = 0; e < 5; e++) {
            this.updateGroupState(e);
        }
        this.initPushEvent();
        let e = SoundManager.shared().bg_enabled;
        this.updateSwitchStatus(this.switchNodes[0], e);
        let t = SoundManager.shared().fx_enabled;
        this.updateSwitchStatus(this.switchNodes[1], t);
        let i = sys.localStorage.getItem("vb_enabled"), a = true;
        sys.isObjectValid(i) && (a = "true" === i);
        this.updateSwitchStatus(this.switchNodes[3], a);
        let s = sys.localStorage.getItem("cv_enabled"), o = true;
        sys.isObjectValid(s) && (o = "true" === s);
        this.updateSwitchStatus(this.switchNodes[2], o);
        sys.isObjectValid(User.shared().club_data) || User.shared().doMemberShipData();
        this.updateIsChips();
        this.appVerLabel.string = "V" + GameConfig.NEW_APP_VERSION + " (" + TransferPlatform.shared().getAppVersionCode() + ")";
        this.fitGameName();
        this.node.getChildByName("root").setPosition(v3(545, 0));
        tween(this.node.getChildByName("root")).to(0.15, { position: v3(0, 0) }).start();
    }
    fitGameName() {
        let e = 0 == GameConfig.GAME_APP_THEME ? CommDefine.AppName_rummy : CommDefine.AppName_circ, t = this.scrollview.content.getChildByName("dic_root").getChildByName("group").getChildByName("desc").getComponent(Label).string;
        if (-1 != t.indexOf(CommDefine.AppName_rummy) && 1 == GameConfig.GAME_APP_THEME) {
            t = t.replace(new RegExp(CommDefine.AppName_rummy, "g"), e);
            this.scrollview.content.getChildByName("dic_root").getChildByName("group").getChildByName("desc").getComponent(Label).string = t;
        }
        else if (1 == GameConfig.NATIVE_GAME_APP_TYPE) {
            let i = "Master Rummy";
            -1 != t.indexOf(i) && (t = t.replace(new RegExp(i, "g"), e), this.scrollview.content.getChildByName("dic_root").getChildByName("group").getChildByName("desc").getComponent(Label).string = t);
        }
    }
    fitChipMode() {
        1 == GameConfig.CHIPS_MODLE && 2000617 == GameConfig.CHANNEL_ID && 0 == GameConfig.GAME_HALL_THEME && (this.node.getChildByName("root").getChildByName("bg").getComponent(Sprite).spriteAtlas = this.spAtlas617, this.node.getChildByName("root").getChildByName("bg").getComponent(Sprite).spriteFrame = this.top617SpFrame, find("root/info_top/img_nodes/add_cash", this.node).getComponent(Sprite).spriteAtlas = this.spAtlas617, find("root/info_top/img_nodes/add_cash", this.node).getComponent(Sprite).spriteFrame = this.case617SpFrame, find("root/info_top/img_nodes/money_amt", this.node).getComponent(Label).color = color("#ffeaaa"));
    }
    updateIsChips() {
        let e = this.scrollview.content, t = this.chip_numLabel.node.parent, i = t.getChildByName("chip_ico");
        i.active = 1 == GameConfig.CHIPS_MODLE;
        i.setPosition(1 == GameConfig.CHIPS_MODLE ? v3(-10, 170.493) : v3(175.578, 170.493));
        i.scale = 1 == GameConfig.CHIPS_MODLE ? v3(0.4, 0.4) : v3(0.5, 0.5);
        t.getChildByName("add_cash").children[0].active = 1 != GameConfig.CHIPS_MODLE;
        t.getChildByName("add_cash").getComponent(UITransform).setContentSize(1 == GameConfig.CHIPS_MODLE ? 165 : 232, 42);
        t.getChildByName("add_cash").getComponent(Button).enabled = 1 != GameConfig.CHIPS_MODLE;
        e.getChildByName("wallet_root").active = 1 != GameConfig.CHIPS_MODLE;
        let a = e.getChildByName("help_root").getChildByName("tab");
        a.getComponent(UITransform).setContentSize(540, 1 == GameConfig.CHIPS_MODLE ? 145 : 225);
        a.getChildByName("desc1").active = 1 != GameConfig.CHIPS_MODLE;
        a.getChildByName("arrow1").active = 1 != GameConfig.CHIPS_MODLE;
        a.getChildByName("ico1").active = 1 != GameConfig.CHIPS_MODLE;
        a.getChildByName("desc2").active = 1 != GameConfig.CHIPS_MODLE;
        a.getChildByName("arrow2").active = 1 != GameConfig.CHIPS_MODLE;
        a.getChildByName("ico2").active = 1 != GameConfig.CHIPS_MODLE;
        a.getComponent(UITransform).setContentSize(540, 1 == GameConfig.CHIPS_MODLE ? 75 : 225);
        let s = e.getChildByName("dic_root").getChildByName("tab");
        s.getChildByName("desc0").active = 1 != GameConfig.CHIPS_MODLE;
        s.getChildByName("arrow0").active = 1 != GameConfig.CHIPS_MODLE;
        s.getChildByName("ico0").active = 1 != GameConfig.CHIPS_MODLE;
        s.getComponent(UITransform).setContentSize(540, 1 == GameConfig.CHIPS_MODLE ? 75 : 150);
        s.children.forEach((e => {
            e.name.includes("0") ? e.active = 1 != GameConfig.CHIPS_MODLE : e.name.includes("1") ? e.setPosition(v3(e.getPosition().x, 1 == GameConfig.CHIPS_MODLE ? -30 : -100)) : e.name.includes("2") && (e.setPosition(v3(e.getPosition().x, 1 == GameConfig.CHIPS_MODLE ? -100 : -170)), e.active = false);
        }));
    }
    startShowAnim() {
        this.node.getChildByName("root").position = v3(540, 0, 0);
        let e = v3(0, 0, 0);
        TweenTool.moveTo(this.node.getChildByName("root"), 0.15, e, "fade", true, (() => {
            this.node.setPosition(e);
        }));
    }
    hideAnim() {
        try {
            let e = v3(0, 0, 0);
            this.node.getChildByName("root").getPosition(e);
            let t = 540, i = v3(e.x + t, e.y, 0);
            TweenTool.moveTo(this.node.getChildByName("root"), 0.15, i, "fade", true, (() => {
                ToolUtils.isObjValid(this.node) && this.node.destroy();
            }));
            PushCenter.shared().pushEvent(PushEvent.Update_CloseMenu);
        }
        catch (e) {
            TLog.printError("trycatch onClickClose:", e);
        }
    }
    updateGroupState(e) {
        0 == this.group_arrow_status[e] ? (this.groupViews[e].getChildByName("arrow").getChildByName("ico").getComponent(Sprite).color = color(197, 197, 197), this.groupViews[e].getChildByName("arrow").getChildByName("ico").angle = -90, this.tabViews[e].active = false) : (this.groupViews[e].getChildByName("arrow").getChildByName("ico").getComponent(Sprite).color = this.group_color, this.groupViews[e].getChildByName("arrow").getChildByName("ico").angle = 90, this.tabViews[e].active = true);
    }
    updateSwitchStatus(e, t) {
        e.getComponent(Sprite).spriteFrame = t ? this.switch_imgs[1] : this.switch_imgs[0];
    }
    onEnable() {
        TransferPlatform.shared().setNormalFrameRate();
        this.lastTime = 0;
    }
    onDisable() {
    }
    initPushEvent() {
        PushCenter.shared().addListener(GameConfig.Update_Money, (e => {
            0 == GameConfig.CHIPS_MODLE && this.balance_numLabel && (this.balance_numLabel.string = ToolUtils.parse_double(e, 2, true));
        }), this);
        PushCenter.shared().addListener(PushEvent.UpdatePractiseGold, (e => {
            1 == GameConfig.CHIPS_MODLE && this.balance_numLabel && (this.balance_numLabel.string = ToolUtils.parse_ChipNum2(e));
        }), this);
        PushCenter.shared().addListener(GameConfig.Update_Name, (e => {
            this.setUserInfo();
        }), this);
        PushCenter.shared().addListener(GameConfig.Change_Head, (e => {
            this.setUserInfo();
        }), this);
        PushCenter.shared().addListener(GameConfig.Hall_MemberShip_info, (e => {
            ToolUtils.isObjValid(this.node) && this.update_clubInfo();
        }), this);
        PushCenter.shared().addListener(GameConfig.Update_withdraw, (e => {
            ToolUtils.isObjValid(this.node) && window.InHallScene && this.setUserInfo();
        }), this);
        PushCenter.shared().addListener(GameConfig.Update_Deposit, (e => {
            ToolUtils.isObjValid(this.node) && window.InHallScene && this.setUserInfo();
        }), this);
    }
    onDestroy() {
        PushCenter.shared().removeListenersByTag(this);
    }
    setUserInfo() {
        this.nameLabel.string = User.shared().data.name + "";
        User.shared().data.avatar && User.shared().data.avatar.length > 0 && Utils.shared().updateHeadImg(this.head_img, User.shared().data.avatar, User.shared().data.avatar_url, size(130, 130));
    }
    clickCallback(e, t) {
        SoundManager.shared().playFx("click");
        sys.now();
        if ("head" === t) {
            Utils.shared().showWalletView2();
        }
        else if (-1 != t.indexOf("group_arrow")) {
            let e = parseInt(t.split("_arrow")[1]);
            0 == this.group_arrow_status[e] ? this.group_arrow_status[e] = 1 : this.group_arrow_status[e] = 0;
            this.updateGroupState(e);
        }
        else if ("withdrawal_go" === t) {
            Utils.shared().doJumpLogic(PushEvent.JUMP_TO_WITHDRAWAL);
        }
        else if ("wallet_go" === t) {
            Utils.shared().showWalletView2();
        }
        else if ("contact_go" === t) {
            Utils.shared().showContactUsView();
        }
        else if ("how_to_play_go" === t) {
            Utils.shared().showRuleHelpView({ isEasy: User.shared().easy_mode_show, isMultiple: 1 == User.shared().multiple_rummy_open, isBump: 1 == User.shared().bump_rummy_open });
        }
        else if ("transactions_go" === t) {
            director.getScene().getChildByName("Canvas");
            Utils.shared().showWalletDetailstView(User.shared().walletData_history);
        }
        else if ("new_player_guide_go" == t) {
            ToolUtils.in_isGuideRoom = 1;
            Utils.shared().showLoading(20, true);
            let e = new Node;
            e.addComponent(LoadTableCpp);
            this.node.addChild(e);
            e.name = "loadTableCpp";
            e.getComponent(LoadTableCpp).enterGameScene();
        }
        else if ("tc_go" === t) {
            Utils.shared().doCustomJump(PushEvent.Custom_TO_TC);
        }
        else if ("privacy_go" === t) {
            Utils.shared().doJumpLogic(PushEvent.JUMP_TO_PrivacyPolicy);
        }
        else if ("limits" === t) {
            Utils.shared().showRechargeLimitsView();
        }
        else if ("responsible" === t) {
            Utils.shared().doJumpLogic(PushEvent.JUMP_TO_RESPONSIBLY);
        }
        else if ("music_go" === t) {
            let e = SoundManager.shared().bg_enabled;
            e = !e;
            SoundManager.shared().setEnabled(e);
            ToolUtils.saveData("bg_enabled", String(e));
            this.updateSwitchStatus(this.switchNodes[0], e);
        }
        else if ("sound_go" === t) {
            let e = SoundManager.shared().fx_enabled;
            e = !e;
            SoundManager.shared().setFxEnabled(e);
            ToolUtils.saveData("fx_enabled", String(e));
            this.updateSwitchStatus(this.switchNodes[1], e);
        }
        else if ("vibration_go" === t) {
            let e = sys.localStorage.getItem("vb_enabled"), t = true;
            sys.isObjectValid(e) && (t = "true" === e);
            t = !t;
            ToolUtils.saveData("vb_enabled", String(t));
            this.updateSwitchStatus(this.switchNodes[3], t);
        }
        else if ("cardvoice_go" === t) {
            let e = sys.localStorage.getItem("cv_enabled"), t = true;
            sys.isObjectValid(e) && (t = "true" === e);
            t = !t;
            ToolUtils.saveData("cv_enabled", String(t));
            this.updateSwitchStatus(this.switchNodes[2], t);
        }
        else if ("redeem_go" === t) {
            if (1 == User.shared().temp_pingbi.redeemcode) {
                return void Utils.shared().showToast(" comming soon", 2);
            }
            Utils.shared().doJumpLogic(PushEvent.JUMP_TO_REDEEM_CODE);
        }
        else if ("hidemenu" == t) {
            this.hideAnim();
        }
        else if ("logout_go" == t) {
            Utils.shared().showHallLogoutView();
        }
        else if ("faq_go" == t) {
            Utils.shared().showFaqMain();
        }
        else if ("club_go" == t) {
            Utils.shared().doJumpLogic(PushEvent.JUMP_TO_CLUB);
        }
        else if ("store" == t) {
            if (1 == GameConfig.CHIPS_MODLE) {
                return;
            }
            Utils.shared().showStoreView(null, Utils.shared().hall_rootNode);
            User.shared().updatePayScene(PhpReportDefined.pay_scene.hall_shop);
        }
        else if ("challenger_go" == t) {
            let e = director.getScene().getChildByName("Canvas");
            Utils.shared().showLeaderBoardMainView(e);
        }
        this.cb && this.cb(t);
    }
    onBackView() {
        ToolUtils.isObjValid(this.node) && this.hideAnim();
    }
    showPopPrefab(e) {
        ToolUtils.loadCommonPrefab(null, BundleNameDefined.bundle_menu, "prefab/" + e, (t => {
            let i = director.getScene().getChildByName("Canvas"), a = i.getChildByName(e);
            if (ToolUtils.isObjValid(a)) {
                return;
            }
            let s = instantiate(t);
            s.name = e;
            i.addChild(s);
        }));
    }
    setCallback(e) {
        this.cb = e;
    }
    update_clubInfo() {
        if (User.shared().data.club) {
            let e = User.shared().getGradeByMemberShipLevel(User.shared().data.club.club);
            0 == e ? this.head_club_kuang.node.active = false : e > 0 && e <= 9 && (0 == User.shared().avatar_frame_id ? this.head_club_kuang.node.active = false : (this.head_club_kuang.node.active = true, this.head_club_kuang.spriteFrame = this.club_headkuangs[User.shared().avatar_frame_id]));
        }
    }
}
