// @ts-nocheck
// Recovered from index.js:327
import { _decorator, Button, color, EditBox, Label, LabelShadow, Node, size, Sprite, SpriteFrame, sys, UITransform, v3 } from "cc";
import BaseLayer from "./BaseLayer";
import SoundManager from "./SoundManager";
import PushCenter from "./PushCenter";
import GameConfig from "./GameConfig";
import { TLog } from "./TLog";
import Utils from "./Utils";
import User from "./User";
import HttpManager from "./HttpManager";
import PushEvent from "./PushEvent";
import CommDefine, { CheckModule } from "./CommDefine";
import i18nMgr from "./i18nMgr";
import TweenTool from "./TweenTool";
import ReportConfig from "./ReportConfig";
import { HttpRequest } from "./HttpRequestName";
import { TransferPlatform } from "./TransferPlatform";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("OnlineVerify")
export class OnlineVerify extends BaseLayer {
    @property(Node)
    public rootNode: Node = null;
    @property(Node)
    public errTipNode: Node = null;
    @property(EditBox)
    public captEdit: EditBox = null;
    @property(Node)
    public panelCenter: Node = null;
    @property([SpriteFrame])
    public verifyBtnDiImags: SpriteFrame[] = [];
    @property([SpriteFrame])
    public otpBtnDiImags: SpriteFrame[] = [];
    @property(Node)
    public cardNumberNode: Node = null;
    @property(Node)
    public captNumberNode: Node = null;
    @property(Node)
    public otpNumberNode: Node = null;
    @property(SpriteFrame)
    public blackImg: SpriteFrame = null;
    public cardNumberStr: string = "";
    public captNumberStr: string = "";
    public otpNumberStr: string = "";
    public scrollItemPosY: number = 0;
    public isLoadingImg: boolean = false;
    public session_id: string = "";
    public captcha_url: string = "";
    public _lastClick: number = 0;
    public showUICallback: any = null;
    public closeUICallBack: any = null;
    public _closed: boolean = false;
    public _bBtnEnable: boolean = true;
    public cur_page: number = 0;
    public _curOtpTime: number = 60;
    public is_refine: number = 0;
    public in_deposit: number = 0;
    public _scheduleAct: any = null;
    public _keyboardHei: number = 740;
    public input_node: any = null;
    public is_permit: boolean = false;
    public _nCloseCount: number = 0;
    onLoad() {
    }
    onDestroy() {
        super.onDestroy();
        TransferPlatform.shared().setSoftInputMode(0);
        PushCenter.shared().removeListenersByTag(this);
        this.unscheduleAllCallbacks();
    }
    init(e = null) {
        sys.isObjectValid(e) && (sys.isObjectValid(e.is_refine) && (this.is_refine = ToolUtils.isSafeNumber(e.is_refine)), sys.isObjectValid(e.in_deposit) && (this.in_deposit = ToolUtils.isSafeNumber(e.in_deposit)), sys.isObjectValid(e.is_permit) && (this.is_permit = e.is_permit));
    }
    start() {
        super.start();
        TransferPlatform.shared().setSoftInputMode(1);
        let e = this.node.getChildByName("mask");
        ToolUtils.showFullScreen(e);
        this.initView();
        this.startShowAnim(this.rootNode);
        PushCenter.shared().addListener(GameConfig.Update_Kyc, (() => {
            ToolUtils.isObjValid(this.node) && (Utils.shared().hideLoading(), this.updateCardVerifyView(true), this.updateRewardList(), 3 == User.shared().data.card_check && ToolUtils.isSafeString(User.shared().newKycData.kyc_list.fast_reason).length > 0 && sys.isObjectValid(User.shared().newKycData.kyc_list) && ToolUtils.isSafeString(User.shared().newKycData.kyc_list.fast_reason).length);
        }), this);
        PushCenter.shared().addListener(PushEvent.commentDownloaderImg, (e => {
            sys.isObjectValid(this.node) && e == this.captcha_url && Utils.shared().updateNetImage(this.captNumberNode.getChildByName("capt_img"), this.captcha_url, size(140, 67));
        }), this);
        PushCenter.shared().addListener(PushEvent.Close_FastOtpView, (e => {
            sys.isObjectValid(this.node) && this.onBackView();
        }), this);
        PushCenter.shared().addListener(PushEvent.RefreshOtpKycReason, (e => {
            sys.isObjectValid(this.node) && this.updateErrTips(e);
        }), this);
        HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Hall, event: ReportConfig.hall_evt.enter_kyc_verify });
        PushCenter.shared().addListener(PushEvent.changeWebViewHeight, (e => {
            ToolUtils.isObjValid(this.node) && (this._keyboardHei = ToolUtils.isSafeNumber(Number(e)), ToolUtils.judgeIfInHall() && (sys.isObjectValid(this.input_node) ? this.showScrollivewUp(this.input_node) : this.showScrollivewUp(this.captEdit.node)));
        }), this);
    }
    showScrollivewUp(e) {
        if (ToolUtils.getIsInRoom()) {
            return;
        }
        let t = v3(0, 0);
        this.node.inverseTransformPoint(t, e.getWorldPosition());
        let i = GameConfig.REAL_SCREEN_HEIGHT;
        ToolUtils.getIsInRoom() && (i = GameConfig.REAL_SCREEN_WIDTH);
        let a = i / 2 + t.y - 34 - 80;
        a < this._keyboardHei ? this.rootNode.setPosition(v3(0, this._keyboardHei - a)) : this.rootNode.setPosition(v3(0, 0));
    }
    restoreScrollviewTop() {
        this.rootNode.setPosition(v3(0, 0));
    }
    updateNextBtnStatus(e) {
        0 == e ? (this.rootNode.getChildByName("next_btn").getComponent(Button).interactable = false, this.rootNode.getChildByName("next_btn").getComponent(Sprite).spriteFrame = this.verifyBtnDiImags[0], this.rootNode.getChildByName("next_btn").getChildByName("wz").getComponent(Label).color = color(255, 255, 255), this.rootNode.getChildByName("next_btn").getChildByName("wz").getComponent(LabelShadow).enabled = true, this.rootNode.getChildByName("next_btn").getChildByName("wz").getComponent(LabelShadow).color = CommDefine.shadowcolor.gray, Utils.updateLabelMaterial(this.rootNode.getChildByName("next_btn").getChildByName("wz"), CommDefine.gradient.btn_gray)) : (this.rootNode.getChildByName("next_btn").getComponent(Button).interactable = true, this.rootNode.getChildByName("next_btn").getComponent(Sprite).spriteFrame = this.verifyBtnDiImags[1], this.rootNode.getChildByName("next_btn").getChildByName("wz").getComponent(Label).color = color(255, 255, 255), this.rootNode.getChildByName("next_btn").getChildByName("wz").getComponent(LabelShadow).color = CommDefine.shadowcolor.green, this.rootNode.getChildByName("next_btn").getChildByName("wz").getComponent(LabelShadow).enabled = true, Utils.updateLabelMaterial(this.rootNode.getChildByName("next_btn").getChildByName("wz"), CommDefine.gradient.btn_green));
    }
    onCloseButtonClick(e, t) {
        if (SoundManager.shared().playFx("click"), "back_btn" == t) {
            if (this._nCloseCount += 1, this._closed) {
                return;
            }
            this._closed = true;
            this.onBackView();
        }
    }
    initView() {
        this.cur_page = 0;
        this.updateRewardList();
        this.updateNextBtnStatus(0);
        2 == User.shared().data.card_check ? sys.isObjectValid(User.shared().newKycData.collect_list) && User.shared().newKycData.collect_list.length > 0 ? (this.updateCardVerifyView(true), User.shared().code_timeout > 0 ? (this.updateOptBtnStatus(0), this._scheduleAct && TweenTool.stopAction(this._scheduleAct), this.updateOptTime(), this._scheduleAct = TweenTool.commonSchedule(this.node, 1, this.updateOptTime.bind(this))) : this.updateOptBtnStatus(1)) : (Utils.shared().showLoading(10, true, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3);
        })), this.updateOptBtnStatus(1), HttpManager.shared().doGetKycAccount2(this.listenGetKycAccountCallback.bind(this))) : sys.isObjectValid(User.shared().newKycData.form_list) && User.shared().newKycData.form_list.length > 0 ? (this.updateCardVerifyView(true), User.shared().code_timeout > 0 ? (this.updateOptBtnStatus(0), this._scheduleAct && TweenTool.stopAction(this._scheduleAct), this.updateOptTime(), this._scheduleAct = TweenTool.commonSchedule(this.node, 1, this.updateOptTime.bind(this))) : this.updateOptBtnStatus(1)) : (Utils.shared().showLoading(10, true, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3);
        })), HttpManager.shared().doGetKycAccount2(this.listenGetKycAccountCallback.bind(this)));
    }
    listenGetKycAccountCallback(e, t, i) {
        try {
            if (200 != i) {
                alert("The login timed out, please try again");
            }
            else {
                let e = ToolUtils.parseJson(t);
                0 == e.ret && (User.shared().newKycData = e.data, ToolUtils.isObjValid(this.node) && this.updateCardVerifyView());
            }
        }
        catch (e) {
            TLog.printError("listenGetKycVerifyListCallback:", e);
        }
    }
    updateCardVerifyView(e = true) {
        let t = true;
        if (this.is_permit) {
            return Utils.shared().hideLoading(), this.rootNode.getChildByName("bottem_tip").active = false, ToolUtils.judgeIfInHall() && (this.rootNode.getChildByName("bgView").getComponent(UITransform).contentSize = size(620, 814)), void this.updateOptBtnStatus(1);
        }
        if (0 == User.shared().data.card_check || 3 == User.shared().data.card_check) {
            if (t = true, this.rootNode.getChildByName("submit_btn").active = true, this.rootNode.getChildByName("submit_btn").getComponent(Button).interactable = true, this.showVerifyBtnStatus(1), 3 == User.shared().data.card_check) {
                let e = sys.localStorage.getItem(User.shared().data.uid + "otpVerflag");
                sys.isObjectValid(e) && e.length > 0 ? i18nMgr.shared().changeLabelLanguage(this.rootNode.getChildByName("submit_btn").getChildByName("wz").getComponent(Label), "kyc.resubmit", true) : i18nMgr.shared().changeLabelLanguage(this.rootNode.getChildByName("submit_btn").getChildByName("wz").getComponent(Label), "kyc.submit", true);
            }
            else {
                i18nMgr.shared().changeLabelLanguage(this.rootNode.getChildByName("submit_btn").getChildByName("wz").getComponent(Label), "kyc.submit", true);
            }
        }
        else {
            if (2 == User.shared().data.card_check && 0 == this.is_refine && !this.is_permit) {
                return void this.onBackView();
            }
            t = false;
            1 == this.is_refine && (t = true);
            1 == User.shared().data.card_check || Utils.shared().hideLoading();
            i18nMgr.shared().changeLabelLanguage(this.rootNode.getChildByName("submit_btn").getChildByName("wz").getComponent(Label), "kyc.verity_verified", true);
            1 == this.is_refine && (this.rootNode.getChildByName("submit_btn").active = true, this.rootNode.getChildByName("submit_btn").getComponent(Button).interactable = true, this.showVerifyBtnStatus(1), i18nMgr.shared().changeLabelLanguage(this.rootNode.getChildByName("submit_btn").getChildByName("wz").getComponent(Label), "kyc.revise", true));
        }
        if (e && this.updateErrTips(), 3 == User.shared().data.card_check && sys.isObjectValid(User.shared().newKycData.kyc_list) && ToolUtils.isSafeString(User.shared().newKycData.kyc_list.card).length > 0 && (this.updateCardNumberView(User.shared().newKycData.kyc_list.card, t, e), this.updateCardNumberStatus()), 2 == User.shared().data.card_check && sys.isObjectValid(User.shared().newKycData.kyc_list) && ToolUtils.isSafeString(User.shared().newKycData.kyc_list.card).length > 0 && this.updateCardNumberView(User.shared().newKycData.kyc_list.card, t, e), ToolUtils.judgeIfInHall()) {
            if (2 == User.shared().data.card_check) {
                if (sys.isObjectValid(User.shared().newKycData.collect_list) && User.shared().newKycData.collect_list.length > 0) {
                    for (let e = 0; e < User.shared().newKycData.collect_list.length; e++) {
                        if (2 == Number(User.shared().newKycData.collect_list[e].type)) {
                            this.rootNode.getChildByName("bottem_tip").active = true;
                            this.rootNode.getChildByName("bgView").getComponent(UITransform).contentSize = size(620, 864);
                            break;
                        }
                    }
                }
            }
            else if (sys.isObjectValid(User.shared().newKycData.form_list) && User.shared().newKycData.form_list.length > 0) {
                for (let e = 0; e < User.shared().newKycData.form_list.length; e++) {
                    if (2 == Number(User.shared().newKycData.form_list[e].type)) {
                        this.rootNode.getChildByName("bottem_tip").active = true;
                        this.rootNode.getChildByName("bgView").getComponent(UITransform).contentSize = size(620, 864);
                        break;
                    }
                }
            }
        }
    }
    updateCardNumberStatus() {
        if (this.cardNumberNode) {
            let e = this.cardNumberNode.getChildByName("EditBox");
            this.cardNumberStr = ToolUtils.isSafeString(e.getComponent(EditBox).string);
            this.cardNumberStr.length > 0 && (0 == User.shared().data.card_check || 3 == User.shared().data.card_check) ? this.cardNumberNode.getChildByName("del_btn").active = true : this.cardNumberNode.getChildByName("del_btn").active = false;
            1 == this.is_refine && (12 == this.cardNumberStr.length && this.cardNumberStr != User.shared().newKycData.kyc_list.card ? ToolUtils.judgeIfInHall() && sys.isObjectValid(User.shared().newKycData.kyc_list.card) && User.shared().newKycData.kyc_list.card.length > 0 && (this.cardNumberNode.getChildByName("tx").active = true) : ToolUtils.judgeIfInHall() && (this.cardNumberNode.getChildByName("tx").active = false));
        }
    }
    updateRewardList() {
        let e = User.shared().data.kyc_list;
        if (sys.isObjectValid(e) && Array.isArray(e) && e.length > 0) {
            for (let t = 0; t < e.length; t++) {
                if (2 == ToolUtils.isSafeNumber(e[t].type)) {
                    let i = 0, a = 0;
                    if (sys.isObjectValid(e[t].cash) && (i = Number(e[t].cash)), sys.isObjectValid(e[t].bonus) && (a = Number(e[t].bonus)), i > 0 && a > 0) {
                        let e = ToolUtils.format(i18nMgr.shared().getValueByKey("kyc.kyc_top_tip"), "₹" + String(i + a) + "*");
                        this.rootNode.getChildByName("top_tip").getComponent(Label).string = e;
                    }
                    else if (i > 0) {
                        let e = ToolUtils.format(i18nMgr.shared().getValueByKey("kyc.kyc_top_tip"), "CASH ₹" + String(i));
                        this.rootNode.getChildByName("top_tip").getComponent(Label).string = e;
                    }
                    else if (a > 0) {
                        let e = ToolUtils.format(i18nMgr.shared().getValueByKey("kyc.kyc_top_tip"), "BONUS ₹" + String(a));
                        this.rootNode.getChildByName("top_tip").getComponent(Label).string = e;
                    }
                    break;
                }
            }
        }
    }
    updateErrTips(e) {
        if (sys.isObjectValid(e) && e.length > 0) {
            return this.errTipNode.active = true, this.errTipNode.getChildByName("tx").getComponent(Label).string = e, this.errTipNode.getChildByName("tx").getComponent(Label).updateRenderData(true), void (ToolUtils.judgeIfInHall() ? this.rootNode.getChildByName("content").setPosition(v3(0, 434.236)) : this.rootNode.getChildByName("content").setPosition(v3(206.463, 26.871 + 20)));
        }
        sys.isObjectValid(User.shared().newKycData.kyc_list) && ToolUtils.isSafeString(User.shared().newKycData.kyc_list.reason).length > 0 ? (this.errTipNode.active = true, this.errTipNode.getChildByName("tx").getComponent(Label).string = User.shared().newKycData.kyc_list.reason, this.errTipNode.getChildByName("tx").getComponent(Label).updateRenderData(true), ToolUtils.judgeIfInHall() ? this.rootNode.getChildByName("content").setPosition(v3(0, 434.236)) : this.rootNode.getChildByName("content").setPosition(v3(206.463, 26.871 + 20))) : (this.errTipNode.active = false, this.errTipNode.getChildByName("tx").getComponent(Label).string = "", ToolUtils.judgeIfInHall() ? this.rootNode.getChildByName("content").setPosition(v3(0, 414.236)) : this.rootNode.getChildByName("content").setPosition(v3(206.463, 26.871)));
    }
    updateCardNumberView(e = "", t, i = true) {
        i && (this.cardNumberStr = e);
        this.cardNumberNode.getChildByName("EditBox").active = false;
        this.cardNumberNode.getChildByName("EditBox").getComponent(EditBox).string = this.cardNumberStr;
        let a = ToolUtils.format(i18nMgr.shared().getValueByKey("kyc.kyc_verify_aad_tip"), this.cardNumberStr);
        this.cardNumberNode.getChildByName("content").getComponent(Label).string = a;
        this.cardNumberNode.getChildByName("EditBox").active = t;
        this.cardNumberNode.getChildByName("content").active = !t;
        this.cardNumberNode.getChildByName("EditBox").getComponent(EditBox).inputMode = EditBox.InputMode.NUMERIC;
        this.cardNumberNode.getChildByName("EditBox").getComponent(EditBox).maxLength = 12;
        this.cardNumberNode.getChildByName("EditBox").getComponent(EditBox).placeholderLabel.string = "Enter aadhaar No.";
    }
    onButtonClick(e, t) {
        if (SoundManager.shared().playFx("click"), "digilocker" == t) {
            Utils.shared().showLoading(15, true, (() => {
                Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3);
            }));
            let e = 1 == this.in_deposit ? 2 : 1;
            HttpManager.shared().doGetDialockerUrl(e, ((e, t, i) => {
                if (Utils.shared().hideLoading(), 200 == i) {
                    try {
                        let e = ToolUtils.parseJson(t);
                        if (0 == e.ret) {
                            if (ToolUtils.isSafeString(e.data.url).length > 0 && ToolUtils.isObjValid(this.node)) {
                                let t = { url: e.data.url, title: i18nMgr.shared().getValueByKey("kyc.digitalLocker_verify"), key: "kyc.digitalLocker_verify" };
                                Utils.shared().openUrl(t, this.node);
                            }
                        }
                        else {
                            null != e.desc && null != e.desc && Utils.shared().showToast(e.desc, 2, 0, ToolUtils.getIsNormalDirection());
                        }
                    }
                    catch (e) {
                        TLog.printError("listenGetDialockerUrl err:", e);
                    }
                }
            }));
        }
        else if ("cardnumber_del" == t) {
            let e = this.cardNumberNode.getChildByName("EditBox");
            e.getComponent(EditBox).string = "";
            e.getComponent(EditBox).blur();
            this.updateCardNumberStatus();
        }
        else if ("clearotp" == t) {
            this.otpNumberNode.getChildByName("otp").getChildByName("edit_otp").getComponent(EditBox).string = "";
            this.otpNumberNode.getChildByName("clear_btn").active = false;
        }
        else if ("dealOtp" == t) {
            if (sys.now() - this._lastClick < 500) {
                return;
            }
            this._lastClick = sys.now();
            this.checkAndSendOtp();
        }
        else if ("get_img" == t) {
            if (sys.now() - this._lastClick < 500) {
                return;
            }
            this._lastClick = sys.now();
        }
        else if ("clearcapt" == t) {
            let e = this.captNumberNode.getChildByName("EditBox");
            e.getComponent(EditBox).string = "";
            e.getComponent(EditBox).blur();
            this.captNumberNode.getChildByName("clear_btn").active = false;
            this.updateNextBtnStatus(0);
        }
        else if ("kefu" == t) {
            if (1 == User.shared().temp_pingbi.feedback) {
                return void Utils.shared().showToast("Coming soon", 2);
            }
            let e = { sourceType: CommDefine.TawkUser_Feedback_Source.Kyc, groupType: CommDefine.TawkUser_Feedback_Source.Kyc_Group.Verify };
            Utils.shared().doJumpLogic(PushEvent.JUMP_TO_FEEDBACK, e);
        }
    }
    checkAndSendOtp() {
        if (this.cardNumberNode) {
            let e = this.cardNumberNode.getChildByName("EditBox");
            if (this.cardNumberStr = ToolUtils.isSafeString(e.getComponent(EditBox).string), 12 != this.cardNumberStr.length) {
                let e = "Invalid ID number";
                return ToolUtils.isSafeString(i18nMgr.shared().getValueByKey("utils.text78")).length > 0 && (e = i18nMgr.shared().getValueByKey("utils.text78")), void Utils.shared().showToast(e, 3);
            }
            Utils.shared().showLoading(60, true, (() => {
            }));
            let t = 0;
            2 == User.shared().data.card_check && (t = 1);
            let i = HttpRequest.GetOtpKycOnline;
            1 == this.is_refine && (i = HttpRequest.GetOtpKycOnline_withdraw);
            HttpManager.shared().doGetCommonRequest({ is_sub_data: t, aad_card: this.cardNumberStr }, i, this.listenGetCodeCall.bind(this));
        }
    }
    clearCaptNum() {
        this.captNumberNode.getChildByName("EditBox").getComponent(EditBox).string = "";
        this.updateCaptNumberStatus();
    }
    clearOtpNum() {
        this.otpNumberNode.getChildByName("otp").getChildByName("edit_otp").getComponent(EditBox).string = "";
        this.updateOptNumberStatus();
    }
    updateCardEditStatus(e) {
        this.cardNumberNode.getChildByName("mask").active = !e;
    }
    listenGetCodeCall(e, t, i) {
        if (Utils.shared().hideLoading(), 200 !== i) {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text37"), 3);
        }
        else {
            let e = ToolUtils.parseJson(t);
            0 === e.ret ? (this.cur_page = 1, sys.isObjectValid(e.data.otptime) && Number(e.data.otptime) > 0 && (this._curOtpTime = Number(e.data.otptime)), sys.isObjectValid(e.data.session_id) && e.data.session_id.length > 0 && (this.session_id = e.data.session_id), User.shared().code_timeout = this._curOtpTime, this.updateOptBtnStatus(0), this.updateOptTime(), this._scheduleAct && TweenTool.stopAction(this._scheduleAct), this._scheduleAct = TweenTool.commonSchedule(this.node, 1, this.updateOptTime.bind(this)), this.clearOtpNum()) : 4027 === e.ret ? (User.shared().data.submit_left_hour = e.data.submit_left_seconds, Utils.shared().doJumpLogic(PushEvent.Custom_TO_KycLimitTip), TweenTool.delayAct(this.node, (() => {
                this.onBackView();
            }), 1, true)) : e.desc && e.desc.length > 0 && Utils.shared().showToast(e.desc, 3);
        }
    }
    updateOptTime() {
        if (User.shared().code_timeout > 0) {
            User.shared().code_timeout -= 1;
            let e = "(" + String(User.shared().code_timeout) + "s)";
            this.otpNumberNode.getChildByName("otp_btn").getChildByName("wz").getComponent(Label).string = e;
        }
        else {
            this._scheduleAct && TweenTool.stopAction(this._scheduleAct);
            this.updateOptBtnStatus(1);
        }
    }
    updateCaptNumberStatus() {
        if (this.captNumberNode) {
            let e = this.captNumberNode.getChildByName("EditBox");
            this.captNumberStr = ToolUtils.isSafeString(e.getComponent(EditBox).string);
            this.captNumberStr.length > 0 && (0 == User.shared().data.card_check || 3 == User.shared().data.card_check || 2 == User.shared().data.card_check && 1 == this.is_refine) ? (this.captNumberNode.getChildByName("clear_btn").active = true, this.updateNextBtnStatus(1)) : (this.captNumberNode.getChildByName("clear_btn").active = false, this.updateNextBtnStatus(0));
        }
    }
    updateOptNumberStatus() {
        if (this.otpNumberNode) {
            let e = this.otpNumberNode.getChildByName("otp").getChildByName("edit_otp").getComponent(EditBox);
            if (null == e.string || "" == e.string) {
                return void (this.otpNumberNode.getChildByName("clear_btn").active = false);
            }
            this.otpNumberNode.getChildByName("clear_btn").active = true;
            /^([0-9]{8,16})$/.test(e.string);
        }
    }
    onEditBoxBegan(e, t, i) {
        "otp" == i ? this.input_node = this.otpNumberNode.getChildByName("otp").getChildByName("edit_otp").getComponent(EditBox).node : "capt" == i ? this.input_node = this.captNumberNode.getChildByName("EditBox") : "card_number" == i && (this.input_node = this.cardNumberNode.getChildByName("EditBox"));
    }
    onEditBoxChanged(e, t, i) {
        "otp" == i ? this.updateOptNumberStatus() : "capt" == i ? this.updateCaptNumberStatus() : "card_number" == i && this.updateCardNumberStatus();
    }
    onEditBoxEnded(e, t) {
        "otp" == t ? this.updateOptNumberStatus() : "capt" == t ? this.updateCaptNumberStatus() : "card_number" == t && this.updateCardNumberStatus();
    }
    onNextButtonClick(e, t) {
        if (SoundManager.shared().playFx("click"), !this._bBtnEnable) {
            return;
        }
        if (this._bBtnEnable = false, TweenTool.delayAct(this.node, (() => {
            this._bBtnEnable = true;
        }), 1, true), !User.shared().checkLocationPermit(CheckModule.KYC)) {
            return;
        }
        if (sys.isObjectValid(User.shared().newKycData.kyc_list) && sys.isObjectValid(User.shared().newKycData.kyc_list.reason) && User.shared().newKycData.kyc_list.reason > 0 && (User.shared().newKycData.kyc_list.reason = "", User.shared().newKycData.kyc_list.fast_reason = "", this.updateErrTips()), 12 !== ToolUtils.isSafeString(this.cardNumberStr).length) {
            return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text78"), 2);
        }
        if (0 == ToolUtils.isSafeString(this.captNumberStr).length) {
            return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("kyc.kyc_capt"), 2);
        }
        Utils.shared().showLoading(60, true, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text37"), 3);
        }));
        this._curOtpTime = 60;
        let i = 0;
        2 == User.shared().data.card_check && (i = 1);
        let a = HttpRequest.GetOtpKycOnline;
        1 == this.is_refine && (a = HttpRequest.GetOtpKycOnline_withdraw);
        HttpManager.shared().doGetCommonRequest({ is_sub_data: i, aad_card: this.cardNumberStr, session_id: this.session_id, captcha: this.captNumberStr }, a, this.listenGetCodeCall.bind(this));
    }
    onSumbitButtonClick(e, t) {
        if (SoundManager.shared().playFx("click"), !this._bBtnEnable) {
            return;
        }
        if (this._bBtnEnable = false, TweenTool.delayAct(this.node, (() => {
            this._bBtnEnable = true;
        }), 1, true), !User.shared().checkLocationPermit(CheckModule.KYC)) {
            return;
        }
        HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Hall, event: ReportConfig.hall_evt.click_kyc_submit });
        sys.isObjectValid(User.shared().newKycData.kyc_list) && sys.isObjectValid(User.shared().newKycData.kyc_list.reason) && User.shared().newKycData.kyc_list.reason > 0 && (User.shared().newKycData.kyc_list.reason = "", User.shared().newKycData.kyc_list.fast_reason = "", this.updateErrTips());
        let i = this.otpNumberNode.getChildByName("otp").getChildByName("edit_otp").getComponent(EditBox), a = ToolUtils.isSafeString(i.string);
        if (6 !== a.length) {
            return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text63"), 2);
        }
        Utils.shared().showLoading(60, true, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text37"), 3);
        }));
        let s = 0;
        2 == User.shared().data.card_check && (s = 1);
        let o = HttpRequest.SubmitKycOffline;
        1 == this.is_refine && (o = HttpRequest.SubmitKycOffline_withdraw);
        HttpManager.shared().doGetCommonRequest({ is_sub_data: s, aad_card: this.cardNumberStr, otp: a, session_id: this.session_id }, o, this.listenSubmitCall.bind(this));
    }
    updateOptBtnStatus(e) {
        1 == e ? (this.otpNumberNode.getChildByName("otp_btn").getComponent(Button).interactable = true, this.otpNumberNode.getChildByName("otp_btn").getChildByName("ico").getComponent(Sprite).spriteFrame = this.otpBtnDiImags[1], this.otpNumberNode.getChildByName("otp_btn").getChildByName("wz").getComponent(Label).color = color(255, 255, 255), this.otpNumberNode.getChildByName("otp_btn").getChildByName("wz").getComponent(Label).color = color(255, 255, 255), this.otpNumberNode.getChildByName("otp_btn").getChildByName("wz").getComponent(LabelShadow).color = CommDefine.shadowcolor.green, this.otpNumberNode.getChildByName("otp_btn").getChildByName("wz").getComponent(LabelShadow).enabled = true, Utils.updateLabelMaterial(this.otpNumberNode.getChildByName("otp_btn").getChildByName("wz"), CommDefine.gradient.btn_green), this.otpNumberNode.getChildByName("otp_btn").getChildByName("wz").getComponent(Label).string = "OTP", this.updateCardEditStatus(true)) : 0 == e && (this.otpNumberNode.getChildByName("otp_btn").getComponent(Button).interactable = false, this.otpNumberNode.getChildByName("otp_btn").getChildByName("ico").getComponent(Sprite).spriteFrame = this.otpBtnDiImags[0], this.otpNumberNode.getChildByName("otp_btn").getChildByName("wz").getComponent(Label).color = color(255, 255, 255), this.otpNumberNode.getChildByName("otp_btn").getChildByName("wz").getComponent(LabelShadow).enabled = true, this.otpNumberNode.getChildByName("otp_btn").getChildByName("wz").getComponent(LabelShadow).color = CommDefine.shadowcolor.gray, Utils.updateLabelMaterial(this.otpNumberNode.getChildByName("otp_btn").getChildByName("wz"), CommDefine.gradient.btn_gray), this.updateCardEditStatus(false), this.cardNumberNode.getChildByName("del_btn").active = false);
    }
    showVerifyBtnStatus(e) {
        let t = this.rootNode.getChildByName("submit_btn").getChildByName("anim_waiting");
        1 == e ? (this.rootNode.getChildByName("submit_btn").getComponent(Button).interactable = true, this.rootNode.getChildByName("submit_btn").getComponent(Sprite).spriteFrame = this.verifyBtnDiImags[1], t.active = false, this.rootNode.getChildByName("submit_btn").getChildByName("wz").getComponent(Label).color = color(255, 255, 255), this.rootNode.getChildByName("submit_btn").getChildByName("wz").getComponent(LabelShadow).color = CommDefine.shadowcolor.green, this.rootNode.getChildByName("submit_btn").getChildByName("wz").getComponent(LabelShadow).enabled = true, Utils.updateLabelMaterial(this.rootNode.getChildByName("submit_btn").getChildByName("wz"), CommDefine.gradient.btn_green)) : 0 == e ? (this.rootNode.getChildByName("submit_btn").getComponent(Button).interactable = false, this.rootNode.getChildByName("submit_btn").getComponent(Sprite).spriteFrame = this.verifyBtnDiImags[0], t.active = false, this.rootNode.getChildByName("submit_btn").getChildByName("wz").getComponent(Label).color = color(255, 255, 255), this.rootNode.getChildByName("submit_btn").getChildByName("wz").getComponent(LabelShadow).enabled = true, this.rootNode.getChildByName("submit_btn").getChildByName("wz").getComponent(LabelShadow).color = CommDefine.shadowcolor.gray, Utils.updateLabelMaterial(this.rootNode.getChildByName("submit_btn").getChildByName("wz"), CommDefine.gradient.btn_gray)) : 2 == e && (this.rootNode.getChildByName("submit_btn").getComponent(Button).interactable = false, this.rootNode.getChildByName("submit_btn").getComponent(Sprite).spriteFrame = this.verifyBtnDiImags[0], t.active = true, this.rootNode.getChildByName("submit_btn").getChildByName("wz").getComponent(Label).color = color(255, 255, 255), this.rootNode.getChildByName("submit_btn").getChildByName("wz").getComponent(LabelShadow).enabled = true, this.rootNode.getChildByName("submit_btn").getChildByName("wz").getComponent(LabelShadow).color = CommDefine.shadowcolor.gray, Utils.updateLabelMaterial(this.rootNode.getChildByName("submit_btn").getChildByName("wz"), CommDefine.gradient.btn_gray));
    }
    listenSubmitCall(e, t, i) {
        if (200 !== i) {
            ToolUtils.isObjValid(this.node) && (Utils.shared().hideLoading(), Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text37"), 2));
        }
        else {
            try {
                let e = ToolUtils.parseJson(t);
                if (0 === e.ret) {
                    sys.localStorage.setItem(User.shared().data.uid + "otpVerflag", "1");
                    HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Hall, event: ReportConfig.hall_evt.kyc_submit_succ });
                    this.showVerifyBtnStatus(2);
                    sys.isObjectValid(e.data.msg) && e.data.msg.length > 0 && Utils.shared().showToast(e.data.msg, 3);
                    User.shared().code_timeout = 0;
                    this.updateOptTime();
                    i18nMgr.shared().changeLabelLanguage(this.rootNode.getChildByName("submit_btn").getChildByName("wz").getComponent(Label), "kyc.verity_pending", true);
                    let t = e.data.card_check;
                    2 != User.shared().data.card_check && (User.shared().data.card_check = t);
                    sys.isObjectValid(e.data.kyc_otp_check) && (User.shared().data.kyc_otp_check = e.data.kyc_otp_check);
                    2 == User.shared().data.card_check ? HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Hall, event: ReportConfig.hall_evt.kyc_verify_succ }) : 3 == User.shared().data.card_check && HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Hall, event: ReportConfig.hall_evt.kyc_verify_fail });
                    sys.isObjectValid(e.data.loading_seconds) && Number(e.data.loading_seconds) > 0 ? ToolUtils.isObjValid(this.node) && (1 == t && PushCenter.shared().pushEvent(GameConfig.Update_Kyc, User.shared().data.kyc_check), Utils.shared().showLoading(Number(e.data.loading_seconds), true, (() => {
                        Utils.shared().hideLoading();
                        User.shared().doGetKycVerifyList();
                        ToolUtils.isObjValid(this.node) && this.onBackView();
                    }), ToolUtils.getIsNormalDirection(), 1)) : (ToolUtils.isObjValid(this.node) && Utils.shared().hideLoading(), sys.isObjectValid(e.data.fast_reason) && (User.shared().newKycData.kyc_list.fast_reason = e.data.fast_reason), sys.isObjectValid(e.data.trigger_age_pop) && (User.shared().newKycData.kyc_list.trigger_age_pop = e.data.trigger_age_pop), 2 != t && 1 != t || (User.shared().newKycData.kyc_list.reason = "", User.shared().newKycData.kyc_list.fast_reason = "", User.shared().newKycData.kyc_list.trigger_age_pop = 0, ToolUtils.isObjValid(this.node) && (User.shared().updateKycAccount2(e.data), 2 == t && (sys.isObjectValid(e.data.reward_list) && e.data.reward_list.length > 0 ? Utils.shared().showKycVerifySucTip(e.data.reward_list, i18nMgr.shared().getValueByKey("kyc.KYC_Verify_Suc")) : Utils.shared().showToast(i18nMgr.shared().getValueByKey("kyc.KYC_Verify_Suc"), 3.5)), ToolUtils.isObjValid(this.node) && this.onBackView())), PushCenter.shared().pushEvent(GameConfig.Update_Kyc, User.shared().data.kyc_check));
                }
                else if (4027 === e.ret) {
                    User.shared().data.submit_left_hour = e.data.submit_left_seconds;
                    Utils.shared().doJumpLogic(PushEvent.Custom_TO_KycLimitTip);
                    TweenTool.delayAct(this.node, (() => {
                        this.onBackView();
                    }), 1, true);
                }
                else {
                    ToolUtils.isObjValid(this.node) && (Utils.shared().hideLoading(), e.desc && e.desc.length > 0 && Utils.shared().showToast(e.desc, 2));
                    let t = e.ret + ToolUtils.isSafeString(e.desc);
                    HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Hall, event: ReportConfig.hall_evt.kyc_submit_fail, kyc_err: t });
                }
            }
            catch (e) {
                ToolUtils.isObjValid(this.node) && Utils.shared().hideLoading();
                let t = ToolUtils.isSafeString(e.toString());
                HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Hall, event: ReportConfig.hall_evt.kyc_submit_fail, kyc_err: t });
            }
        }
    }
    onBackView(e = true) {
        e && (Utils.shared().hideLoading(), ToolUtils.isObjValid(this.node) && this.node.destroy());
    }
}
