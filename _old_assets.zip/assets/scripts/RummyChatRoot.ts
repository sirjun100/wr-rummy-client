// @ts-nocheck
// Recovered from index.js:433
import { _decorator, color, instantiate, Label, Node, size, sp, Sprite, SpriteAtlas, sys, UITransform, v3, Vec3 } from "cc";
import TweenTool from "./TweenTool";
import RummyDataManager from "./RummyDataManager";
import SoundManager from "./SoundManager";
import User from "./User";
import { TLog } from "./TLog";
import Parent, { AdapDirection } from "./Parent";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("RummyChatRoot")
export default class RummyChatRoot extends Parent {
    @property([Node])
    public vecMagicAnimNode: Node[] = [];
    @property([Node])
    public clubMagicAnimNode: Node[] = [];
    @property(SpriteAtlas)
    public myAtlasFace: SpriteAtlas = null;
    public tid_key: string = "";
    public chatTextTab: any[] = ["Hi all", "Bye all", "Hurry up", "Your turn", "Nice game", "Good job", "Thank you", "Oh no", "Uh...", "Oh my god", "Good luck", "I'm sorry", "let me see", "I'm waiting", "It's my time", "Bless me", "Namaste", "Saubhaagy Ho", "Jaldi", "Shaandaar Hai", "Phir Milenge", "Main Jeeta", "Aanand Le Lo"];
    public chatSoundTab: any[] = ["hi_all", "bye_all", "hurry_up", "your_turn", "nice_game", "good_job", "thank_you", "oh_no", "uh", "oh_my_god", "good_luck", "im_sorry", "let_me_see", "im_waiting", "its_my_time", "bless_me", "namaste", "saubhaagy_ho", "jaldi", "shaandaar_hai", "phir_milenge", "main_jeeta", "aanand_le_lo"];
    public seatPosVec: any[] = [];
    public tmpFaceArr: any = {};
    public mainRummy: any = null;
    onLoad() {
        for (let e = 0; e < 6; e++) {
            this.tmpFaceArr[e] = [];
        }
        let e = this.node.getChildByName("chat_text_node_0");
        ToolUtils.isPadPlatform() && this.resetUiPos(e, AdapDirection.Down, true, 1, false);
    }
    initView(e) {
        this.mainRummy = e;
        this.mainRummy && sys.isObjectValid(this.mainRummy) && this.mainRummy.tipTs && sys.isObjectValid(this.mainRummy.tipTs) && (this.tid_key = this.mainRummy.tid_key, this.seatPosVec = this.mainRummy.tipTs.seatPosVec);
    }
    start() {
    }
    onDestroy() {
        super.onDestroy();
        this.unscheduleAllCallbacks();
    }
    startTalk2(e, t, i) {
        if (this.tid_key = this.mainRummy.tid_key, 2 == RummyDataManager.shared().rummyInfos.get(this.tid_key).pnum && (1 == e ? e = 3 : 3 == e && (e = 1)), e < 0 || e > 5 || null == this.node.getChildByName("chat_text_node_" + e)) {
            return;
        }
        if (sys.isObjectValid(i)) {
            let t = RummyDataManager.shared().getSeatidByPos(e, this.tid_key), a = RummyDataManager.shared().rummyInfos.get(this.tid_key).playerModels[t];
            if (a && this.chatSoundTab[i]) {
                let e = 2 == a.sex ? "female" : "male";
                this.playEffectByName(ToolUtils.format("${0}_${1}", this.chatSoundTab[i], e));
            }
        }
        let a = this.node.getChildByName("chat_text_node_" + e);
        if (ToolUtils.isObjValid(a)) {
            this.hideFaceChat(e);
            let t = !a.active;
            a.active = true;
            t && (TweenTool.stopNodeAction(a), a.setScale(v3(0.2, 0.2, 0.2)), TweenTool.fadeScaleByEasing(a, 0.15, v3(1, 1, 1), 0.5, 1, "quadInOut", true, (() => {
                a.setScale(v3(1, 1, 1));
            })));
            let s = a.getChildByName("text_bg"), o = a.getChildByName("Tx_msg").getComponent(Label);
            o.string = this.chatTextTab[i];
            s.active = false;
            4 == RummyDataManager.shared().rummyInfos.get(this.tid_key).pnum && this.seatPosVec.length > e && e > 0 && a.setPosition(new Vec3(this.seatPosVec[e].x, this.seatPosVec[e].y + 65));
            o.updateRenderData(true);
            let n = a.getChildByName("Tx_msg").getComponent(UITransform).contentSize, l = size(n.width + 60, n.height), u = s.getComponent(UITransform), y = u.contentSize;
            u.setContentSize(size(l.width, y.height));
            s.active = true;
            a.getComponent(UITransform).unscheduleAllCallbacks();
            a.getComponent(UITransform).scheduleOnce((() => {
                a.active = false;
                TweenTool.stopNodeAction(a);
                a.setScale(v3(1, 1, 1));
            }), 3);
        }
    }
    startTalk(e) {
        let t = new Node;
        t.addComponent(Label).string = e;
        t.getComponent(Label).color = color(255, 255, 255);
        let i = ToolUtils.getRandomInt(-350, 350);
        t.setPosition(v3(660, i));
        TweenTool.moveTo(t, 12, v3(-700, i), null, true, (() => {
            ToolUtils.isObjValid(t) && t.destroy();
        }));
        t.parent = this.node;
    }
    hideAllChat() {
        for (let e = 0; e < 6; e++) {
            this.hideTextChat(e);
            this.hideFaceChat(e);
        }
    }
    hideTextChat(e) {
        let t = this.node.getChildByName("chat_text_node_" + e);
        ToolUtils.isObjValid(t) && (t.active = false, TweenTool.stopNodeAction(t), t.setScale(v3(1, 1, 1)));
    }
    hideFaceChat(e) {
        let t = this.node.getChildByName("chat_face_node_" + e);
        ToolUtils.isObjValid(t) && (t.active = false, TweenTool.stopNodeAction(t), t.setScale(v3(1, 1, 1)));
    }
    playEffectByName(e) {
        this.tid_key === User.shared().curTid_key && SoundManager.shared().playFx(e);
    }
    showFace(e, t) {
        if (this.tid_key = this.mainRummy.tid_key, 2 == RummyDataManager.shared().rummyInfos.get(this.tid_key).pnum && (1 == e ? e = 3 : 3 == e && (e = 1)), e < 0 || e > 5 || null == this.node.getChildByName("chat_face_node_" + e)) {
            return;
        }
        let i = this.node.getChildByName("chat_face_node_" + e);
        if (ToolUtils.isObjValid(i)) {
            this.hideTextChat(e);
            let a = !i.active;
            i.active = true;
            a && (TweenTool.stopNodeAction(i), i.setScale(v3(0.2, 0.2, 0.2)), TweenTool.fadeScaleByEasing(i, 0.15, v3(1, 1, 1), 0.5, 1, "quadInOut", true, (() => {
                i.setScale(v3(1, 1, 1));
            })));
            4 == RummyDataManager.shared().rummyInfos.get(this.tid_key).pnum && this.seatPosVec.length > e && e > 0 && i.setPosition(new Vec3(this.seatPosVec[e].x, this.seatPosVec[e].y + 65));
            let s = "face_" + t;
            i.getChildByName("face").getComponent(Sprite).spriteFrame = this.myAtlasFace.getSpriteFrame(s);
            i.getComponent(UITransform).unscheduleAllCallbacks();
            i.getComponent(UITransform).scheduleOnce((() => {
                i.active = false;
                TweenTool.stopNodeAction(i);
                i.setScale(v3(1, 1, 1));
            }), 3);
        }
    }
    showMemberShipFace(e, t) {
    }
    showBigFace(e, t, i, a) {
        this.tid_key = this.mainRummy.tid_key;
        try {
            let a = 0 == e ? this.seatPosVec[e].y - 10 : this.seatPosVec[e].y, s = 0 == t ? this.seatPosVec[t].y - 10 : this.seatPosVec[t].y, o = v3(this.seatPosVec[e].x, a, this.seatPosVec[e].z), n = v3(this.seatPosVec[t].x, s + 10, this.seatPosVec[t].z), c = this.vecMagicAnimNode[i], r = ["xianhua", "wen", "tuoxie", "zhadan", "jidan", "jincha", "xfxz", "nz", "mgtq", "xsq", "fanqie", "lvzi", "yanhua"];
            if (c && r[i]) {
                let t = instantiate(c);
                t.setPosition(o);
                c.parent.addChild(t);
                sys.isObjectValid(this.tmpFaceArr) && sys.isObjectValid(this.tmpFaceArr[e]) && this.tmpFaceArr[e].push(t);
                t.active = true;
                let a = t.getComponent(sp.Skeleton);
                if (a.setToSetupPose(), a.setAnimation(0, r[i], false), a.setCompleteListener((() => {
                    ToolUtils.isObjValid(t) && (this.deleteFaceByItme(e, t), t.destroy());
                })), TweenTool.delayAct(RummyDataManager.shared().sceneNode, (() => {
                    ToolUtils.isObjValid(t) && (this.deleteFaceByItme(e, t), t.destroy());
                }), 4.5, true), ToolUtils.isObjValid(t)) {
                    let e = i < 6;
                    e || this.bigFaceCallBack(i);
                    TweenTool.moveTo(t, 0.4, n, null, true, (() => {
                        e && this.bigFaceCallBack(i);
                    }));
                }
            }
        }
        catch (e) {
            TLog.printError("trycatch RummyTipRoot:showBigFace,error:", e);
        }
    }
    bigFaceCallBack(e) {
        if (this.tid_key === User.shared().curTid_key && null != e && null != e && Number(e) >= 0) {
            let t = ["mf_megui", "mf_kiss", "mf_tuoxie", "mf_zhadan", "mf_jidan", "mf_tea", "mf_coin", "mf_clock", "mf_mgtq", "mf_holi", "mf_tomato", "mf_donkey", "mf_fireworks"], i = Number(e);
            t[i] && SoundManager.shared().playFx(t[i]);
        }
    }
    deleteFaceByItme(e, t) {
        try {
            if (ToolUtils.isObjValid(this.tmpFaceArr[e])) {
                for (let i = 0, a = this.tmpFaceArr[e].length; i < a; i++) {
                    if (this.tmpFaceArr[e][i] == t) {
                        return void this.tmpFaceArr[e].splice(i, 1);
                    }
                }
            }
        }
        catch (e) {
        }
    }
    hideMagicFace(e) {
        if (sys.isObjectValid(this.tmpFaceArr) && ToolUtils.isObjValid(this.tmpFaceArr[e]) && Array.isArray(this.tmpFaceArr[e])) {
            for (let t = 0, i = this.tmpFaceArr[e].length; t < i; t++) {
                let i = this.tmpFaceArr[e][t];
                ToolUtils.isObjValid(i) && (TweenTool.stopNodeAction(i), i.destroy());
            }
        }
    }
}
