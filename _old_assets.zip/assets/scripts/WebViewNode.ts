// @ts-nocheck
// Recovered from index.js:673
import { _decorator, color, Label, Node, SafeArea, screen, size, Sprite, sys, UITransform, v3, Vec3, view, WebView, Widget } from "cc";
import GameConfig from "./GameConfig";
import AppInfo from "./AppInfo";
import SoundManager from "./SoundManager";
import { TransferPlatform } from "./TransferPlatform";
import PushCenter from "./PushCenter";
import PushEvent from "./PushEvent";
import i18nMgr from "./i18nMgr";
import BaseLayer from "./BaseLayer";
import { ToolUtils } from "./ToolUtils";
import { localH5LaunchURL, prepareH5LocalWebView } from "./H5GamePackages";
import HttpManager from "./HttpManager";
const { ccclass, property } = _decorator;
// The Android-safe-area gutter is outside the H5 viewport. Match each
// game's own edge art there instead of painting every game lobby red.
const H5_EDGE_COLORS = {
    fruit: [38, 8, 17],
    blackcat: [9, 29, 46],
    luckyspin: [42, 25, 32],
    mine: [9, 9, 18],
    chicken_road: [51, 53, 79],
    elephant: [37, 40, 71],
    pigslots: [37, 40, 71],
    aviator: [37, 40, 71],
};
@ccclass("WebViewNode")
export default class WebViewNode extends BaseLayer {
    @property(Node)
    public webview: Node = null;
    @property(Label)
    public titleLabel: Label = null;
    public _payOk_cb: any = null;
    public _cancel_cb: any = null;
    public _scheme: string = "payWebView";
    public _callback: any = null;
    public _source: number = 0;
    public webUrls: any[] = [];
    public webTitles: any[] = [];
    public _h5GameId: string = "";
    public _h5Relaunching: boolean = false;
    public _h5Origin: string = "";
    public _h5MessageHandler: any = null;
    public _h5Landscape: boolean = false;
    public _h5PackageIndex: string = "";
    public _h5MusicSuspended: boolean = false;
    private _h5Ready: boolean = false;
    private _h5FallbackScheduled: boolean = false;
    private _h5ReadyCallback: any = null;
    private _h5ReadyTimeout = () => this.revealH5Game();
    private _h5LoadedFallback = () => this.revealH5Game();

    /** Called before this prefab enters the scene, so Android never draws about:blank. */
    prepareH5Launch() {
        const widget = this.webview.getComponent(Widget);
        widget.enabled = false;
        this.webview.setPosition(v3(10000, 10000, 0));
    }
    onLoad() {
        TransferPlatform.shared().setSoftInputMode(1);
        ToolUtils.adaptSafeArea(this.node.getChildByName("root"));
        let e = this.webview.getComponent(WebView);
        this.webview.getComponent(Widget).bottom = -ToolUtils.getSafeDistance();
        let t = "rummy-object", i = this;
        if (sys.isNative) {
            e.setJavascriptInterfaceScheme(t);
            e.setOnJSCallback((function (e, s) {
                let url = typeof s === "string" ? s : typeof e === "string" ? e : "";
                let l = url.replace(/^rummy-object:\/\//i, "").replace(/\/+$/, "");
                if ("add_withdraw_account" == l) {
                    PushCenter.shared().pushEvent(PushEvent.ShowWebWithdrawAdd);
                }
                else if ("pan_verification" == l) {
                    PushCenter.shared().pushEvent(PushEvent.ShowWebPanVerify, this.node);
                }
                else if (-1 != l.indexOf("kefu:")) {
                    i._source += 1;
                    let e = l.replace("kefu:", "");
                    i.openKefuUrl(e);
                }
                else if ("h5_exit" == l && i._h5GameId) {
                    i.closeWebView();
                }
                else if ("h5_relaunch" == l && i._h5GameId) {
                    i.relaunchH5Game();
                }
                else if ("h5_ready" == l && i._h5GameId) {
                    i.revealH5Game();
                }
            }));
        }
        this.changeWebViewHeight(0);
        view.resizeWithBrowserSize(false);
        PushCenter.shared().addListener(PushEvent.changeWebViewHeight, (e => {
            sys.isObjectValid(this) && this.changeWebViewHeight(ToolUtils.isSafeNumber(Number(e)));
        }), this);
        PushCenter.shared().addListener(PushEvent.CloseWebView, (e => {
            sys.isObjectValid(this) && this.closeWebView();
        }), this);
        this.fitLuckyTheme();
    }
    fitLuckyTheme() {
        0 != GameConfig.NATIVE_GAME_APP_TYPE && (this.node.getChildByName("root").getChildByName("top_node").getChildByName("bg").getComponent(Sprite).color = color(12, 26, 60));
    }
    fitChipMode() {
        if (0 == GameConfig.CHIPS_MODLE) {
            return;
        }
        2000617 == GameConfig.CHANNEL_ID && (this.node.getChildByName("root").getChildByName("top_node").getChildByName("bg").getComponent(Sprite).color = color("#094544"));
    }
    openKefuUrl(e) {
        let t = e, i = this.webview.getComponent(WebView);
        this.titleLabel.string = i18nMgr.shared().getValueByKey("utlis.feedback");
        i.url = t;
        this.webTitles.push(i18nMgr.shared().getValueByKey("utlis.feedback"));
        this.webUrls.push(t);
    }
    onDestroy() {
        super.onDestroy();
        this.finishH5Loading();
        this.unschedule(this._h5ReadyTimeout);
        this.unschedule(this._h5LoadedFallback);
        if (this._h5MusicSuspended) {
            this._h5MusicSuspended = false;
            SoundManager.shared().resumeFromH5Game();
            AppInfo.shared().setH5SystemBarsDark(false);
        }
        if (this._h5Landscape) {
            this._h5Landscape = false;
            AppInfo.shared().orientationToPortrait();
        }
        if (this._h5MessageHandler) {
            window.removeEventListener("message", this._h5MessageHandler);
            this._h5MessageHandler = null;
        }
        PushCenter.shared().removeListenersByTag(this);
    }
    start() {
        super.start();
    }
    fitScreen() {
        let e = ToolUtils.getFitTopHeightDiff();
        if (e > 0) {
            let t = this.node.getChildByName("top"), i = new Vec3;
            t.getPosition(i);
            t.setPosition(v3(i.x, i.y + e, i.z));
        }
        if (e = ToolUtils.getFitBottomHeightDiff(), e > 0) {
            let t = this.node.getChildByName("web"), i = screen.windowSize, s = view.getVisibleSize(), l = t.getComponent(UITransform);
            e = s.height * (s.width / s.height - i.width / i.height);
            l.setContentSize(size(l.width, l.height + e));
        }
    }
    changeWebViewHeight(e) {
        // H5 games supply their own exit control. Give every H5 canvas the
        // full viewport; the native title bar clipped bottom game controls.
        const widget = this.webview.getComponent(Widget);
        if (!this._h5GameId) {
            widget.bottom = -ToolUtils.getSafeDistance() + e;
            return;
        }
        widget.top = 0;
        widget.bottom = 0;
        // prepareH5Launch keeps the native view outside the display. Updating
        // alignment here would immediately move its blank frame back onscreen.
        if (!this._h5Ready) return;
        widget.updateAlignment();
    }
    setOnShouldStartLoading(e, t, i) {
        // Older already-downloaded packages do not yet emit h5_ready. Reveal as
        // soon as their document is drawable, matching A's transition into the
        // game's own branded loading page. New packages use the exact bridge.
        if (this._h5GameId && !this._h5Ready && !this._h5FallbackScheduled) {
            this._h5FallbackScheduled = true;
            this.scheduleOnce(this._h5LoadedFallback, 0);
        }
    }
    closeWebView() {
        SoundManager.shared().playFx("click");
        this.finishH5Loading();
        TransferPlatform.shared().setSoftInputMode(0);
        if (this._h5Landscape) {
            this._h5Landscape = false;
            AppInfo.shared().orientationToPortrait();
        }
        view.resizeWithBrowserSize(true);
        this._callback && this._callback();
        this._cancel_cb && (this._cancel_cb(), this._cancel_cb = null);
        let e = this.webview.getComponent(WebView);
        e && e.isValid && e.destroy();
        ToolUtils.isObjValid(this.node) && this.node.destroy();
    }
    onClickClose(e, t) {
        if (this._source >= 1) {
            this.webUrls.length > this._source && this.webUrls.splice(this._source, 1);
            this.webTitles.length > this._source && this.webTitles.splice(this._source, 1);
            this._source -= 1;
            let e = this.webview.getComponent(WebView);
            this.webUrls.length > this._source && (e.url = this.webUrls[this._source]);
            this.webTitles.length > this._source && "" != this.webTitles[this._source] && (this.titleLabel.string = this.webTitles[this._source]);
        }
        else {
            this.closeWebView();
        }
    }
    setWebData(e, t) {
        this._callback = t;
        this._h5GameId = typeof e.h5GameId === "string" ? e.h5GameId : "";
        this._h5PackageIndex = typeof e.h5PackageIndex === "string" ? e.h5PackageIndex : "";
        this._h5Landscape = !!this._h5GameId && e.orientation === "landscape";
        this._h5ReadyCallback = typeof e.h5ReadyCallback === "function" ? e.h5ReadyCallback : null;
        if (this._h5GameId) {
            SoundManager.shared().suspendForH5Game();
            this._h5MusicSuspended = true;
            const edge = H5_EDGE_COLORS[this._h5GameId] || H5_EDGE_COLORS.fruit;
            AppInfo.shared().setH5SystemBarsDark(true, edge[0], edge[1], edge[2]);
            const background = this.node.getChildByName("bg")?.getComponent(Sprite);
            if (background) background.color = color(edge[0], edge[1], edge[2], 255);
            // Never leave the player on a permanent loading cover if an old or
            // third-party package misses both its loaded event and ready bridge.
            this.scheduleOnce(this._h5ReadyTimeout, 12);
        }
        if (this._h5Landscape) AppInfo.shared().orientationToLandscape();
        const root = this.node.getChildByName("root");
        root.getChildByName("top_node").active = !this._h5GameId;
        if (this._h5GameId) {
            // Match the A client: let the game WebView occupy the entire display,
            // including the cutout area. SafeArea otherwise shrinks its parent.
            const safeArea = root.getComponent(SafeArea);
            if (safeArea) safeArea.enabled = false;
            const rootWidget = root.getComponent(Widget);
            rootWidget.left = rootWidget.right = rootWidget.top = rootWidget.bottom = 0;
            rootWidget.updateAlignment();
            this.changeWebViewHeight(0);
        }
        if (this._h5GameId && !sys.isNative) {
            let match = String(e.url).match(/^https?:\/\/[^/]+/i);
            this._h5Origin = match ? match[0] : "";
            this._h5MessageHandler = (msg) => {
                if (msg.origin !== this._h5Origin || !msg.data) return;
                if (msg.data.game_id !== this._h5GameId) return;
                if (msg.data.type === "exit") this.closeWebView();
                if (msg.data.type === "relaunch") this.relaunchH5Game();
                if (msg.data.type === "ready") this.revealH5Game();
            };
            window.addEventListener("message", this._h5MessageHandler);
        }
        let gameURL = e.url;
        if (this._h5PackageIndex && !prepareH5LocalWebView()) {
            // Preserve playability on devices where Cocos has not yet created
            // its native WebView. Never pass a file URL to a blocked view.
            this._h5PackageIndex = "";
            gameURL = e.h5RemoteURL;
        }
        this.webview.getComponent(WebView).url = gameURL;
        e.key ? i18nMgr.shared().changeLocalizedLabelKey(this.titleLabel.node, e.key) : this.titleLabel.string = e.title;
        this.webTitles.push(ToolUtils.isSafeString(e.title));
        this.webUrls.push(gameURL);
        ToolUtils.last_web_url = gameURL;
        ToolUtils.last_web_title = e.title;
    }
    private revealH5Game() {
        if (!this._h5GameId || this._h5Ready || !this.node || !this.node.isValid) return;
        this._h5Ready = true;
        this.unschedule(this._h5ReadyTimeout);
        this.unschedule(this._h5LoadedFallback);
        const widget = this.webview.getComponent(Widget);
        widget.enabled = true;
        widget.top = 0;
        widget.bottom = 0;
        widget.updateAlignment();
        this.finishH5Loading();
    }
    private finishH5Loading() {
        const callback = this._h5ReadyCallback;
        this._h5ReadyCallback = null;
        callback && callback();
    }
    relaunchH5Game() {
        if (this._h5Relaunching || !this._h5GameId) return;
        this._h5Relaunching = true;
        HttpManager.shared().doGetCommonRequest({ game_id: this._h5GameId }, "Games.launch", ((_, body, status) => {
            this._h5Relaunching = false;
            if (!this.node || !this.node.isValid || status !== 200) return;
            try {
                const reply = ToolUtils.parseJson(body);
                const nextUrl = reply && reply.ret === 0 && reply.data && reply.data.game_id === this._h5GameId && reply.data.launch_url;
                if (typeof nextUrl === "string" && nextUrl.startsWith("https://")) {
                    this.webview.getComponent(WebView).url = this._h5PackageIndex ? localH5LaunchURL(nextUrl, this._h5PackageIndex) : nextUrl;
                }
            } catch (_) { /* 失败时保持断线状态，用户可返回大厅 */ }
        }));
    }
    setCallback(e, t) {
        this._payOk_cb = e;
        this._cancel_cb = t;
    }
}
