// @ts-nocheck
// Recovered from index.js:377
import { _decorator, Component, Node, SpriteAtlas } from "cc";
import Utils from "./Utils";
import User from "./User";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("RecodeCard")
export class RecodeCard extends Component {
    @property(Node)
    public frontView: Node = null;
    @property(Node)
    public backView: Node = null;
    @property(Node)
    public valueSp: Node = null;
    @property(Node)
    public laiziDiSp: Node = null;
    @property(Node)
    public laiziIcSp: Node = null;
    @property([SpriteAtlas])
    public smallCardAtlas: SpriteAtlas[] = [];
    @property(SpriteAtlas)
    public smallCardbg: SpriteAtlas = null;
    public mCardValue: any = undefined;
    public laizicard: any = undefined;
    start() {
    }
    init(i, t = false, a) {
        this.laizicard = a;
        this.mCardValue = i;
        let e = "s_card_front", r = "s_rm_kingcard_mask", s = "s_rm_img_laizi";
        if (User.shared().styles[1] - 1 == 1 && (e = "s2_card_front", r = "s2_rm_kingcard_mask", s = "s2_rm_img_laizi"), Utils.shared().setImage(this.frontView, e, this.smallCardAtlas[0]), Utils.shared().setImage(this.backView, "rummy_small_card_bg_0" + User.shared().styles[2], this.smallCardbg), Utils.shared().setImage(this.laiziDiSp, r, this.smallCardAtlas[0]), Utils.shared().setImage(this.laiziDiSp.getChildByName("img") || this.laiziIcSp, s, this.smallCardAtlas[0]), t ? (this.backView.active = true, this.frontView.active = false) : (this.backView.active = false, this.frontView.active = true, this.showJsLaiziFlag(this.isShowLaiziColor(this.mCardValue))), this.mCardValue > 0 || this.mCardValue < 80) {
            let i = "s_rm_scard_" + ToolUtils.cardTo16(this.mCardValue), a = 0;
            Utils.shared().setImage(this.valueSp, i, this.smallCardAtlas[a]);
            this.valueSp.active = !t;
        }
    }
    openCard() {
        this.backView.active = false;
        this.frontView.active = true;
        this.valueSp.active = true;
    }
    changeCardToBack() {
        this.backView.active = true;
        this.frontView.active = false;
    }
    isShowLaiziColor(i) {
        if (78 == this.laizicard || 79 == this.laizicard) {
            if (78 == i || 79 == i || 1 == i || 17 == i || 33 == i || 49 == i) {
                return true;
            }
        }
        else {
            if (78 == i || 79 == i) {
                return true;
            }
            if (this.laizicard % 16 == i % 16) {
                return true;
            }
        }
        return false;
    }
    showJsLaiziFlag(i) {
        this.laiziIcSp.active = !!i && this.mCardValue != 78 && this.mCardValue != 79;
        i ? (78 == this.mCardValue || 79 == this.mCardValue ? (Utils.shared().setImage(this.laiziDiSp, "s_rm_kingcard_mask", this.smallCardAtlas[0]), this.laiziIcSp.active = false) : (Utils.shared().setImage(this.laiziDiSp, "s_rm_kingcard_mask", this.smallCardAtlas[0]), this.laiziIcSp.active = true), this.laiziDiSp.active = true) : this.laiziDiSp.active = false;
    }
}
