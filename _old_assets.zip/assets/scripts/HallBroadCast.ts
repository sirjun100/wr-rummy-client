// @ts-nocheck
// Recovered from index.js:171
import { _decorator, Component, instantiate, Node, RichText, UITransform, v3, Vec3, view } from "cc";
import TweenTool from "./TweenTool";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("HallBroadCast")
export class HallBroadCast extends Component {
    @property(Node)
    public bgNode: Node = null;
    @property(Node)
    public msgNode: Node = null;
    @property(Node)
    public maskNode: Node = null;
    @property(Node)
    public iconNode: Node = null;
    public _laba_width: number = 462;
    public _view_height: number = 1280;
    public directHide: boolean = false;
    public bgShow: boolean = false;
    public moveDistance: number = 0;
    public autoHide: boolean = false;
    public isMoving: boolean = false;
    public curMsgLabel: any = null;
    public safe_hei: number = 0;
    public moveRepeatAct: any = null;
    public labaAct: any = null;
    public _labadi_hei: number = 28;
    start() {
        this._laba_width = view.getVisibleSize().width - 720 + 462;
        this.bgNode.active = true;
        this.msgNode.active = false;
        this.iconNode.active = false;
        this.maskNode.active = true;
        this.setAutoHide(true);
        this.setDirectHide(false);
        this.startLabaAction();
    }
    onDestroy() {
        this.unscheduleAllCallbacks();
    }
    startLabaAction() {
        this.labaAct && (TweenTool.stopAction(this.labaAct), this.labaAct = null);
        this.labaAct = TweenTool.myschedule(this.node, 0.5, this.listenLabaMsg.bind(this));
    }
    setAutoHide(t) {
        this.autoHide = t;
    }
    setDirectHide(t) {
        this.directHide = t;
    }
    listenLabaMsg() {
        ToolUtils.hasShowLabaCount >= ToolUtils.LabaCount ? this.bgShow && (this.bgShow = false, this.iconNode.active = false) : this.createNewMsg();
    }
    createNewMsg() {
        if (this.isMoving) {
            return;
        }
        let t = ToolUtils.LabaTable[ToolUtils.hasShowLabaCount];
        if (t) {
            this.labaAct && (TweenTool.stopAction(this.labaAct), this.labaAct = null);
            let i = instantiate(this.msgNode);
            this.maskNode.addChild(i);
            i.active = true;
            i.setPosition(v3(this._laba_width / 2, 0));
            i.getComponent(RichText).string = t;
            this.curMsgLabel = i;
            this.moveDistance = 0;
            this.isMoving = true;
            this.iconNode.active = true;
            this.bgShow ? (this.iconNode.active = true, this.startMoveAction()) : this.showMarqueeBG();
        }
    }
    showMarqueeBG() {
        this.bgNode.active = true;
        this.bgShow = true;
        this.startMoveAction();
    }
    startMoveAction() {
        this.stopMoveAction();
        this.moveRepeatAct = TweenTool.myschedule(this.node, 0.02, this.updateMove.bind(this));
    }
    stopMoveAction() {
        this.moveRepeatAct && (TweenTool.stopAction(this.moveRepeatAct), this.moveRepeatAct = null);
    }
    updateMove() {
        if (this.curMsgLabel) {
            this.bgShow = true;
            let t = new Vec3;
            this.curMsgLabel.getPosition(t);
            this.curMsgLabel.setPosition(v3(t.x - 3, t.y));
            this.moveDistance = this.moveDistance + 3;
            let i = this.curMsgLabel.getComponent(UITransform).width;
            this.moveDistance >= i + this._laba_width && (this.curMsgLabel.active = false, this.curMsgLabel.destroy(), this.curMsgLabel = null, TweenTool.stopNodeAction(this.bgNode), this.isMoving = false, ToolUtils.hasShowLabaCount = ToolUtils.hasShowLabaCount + 1, this.stopMoveAction(), this.startLabaAction());
        }
    }
}
