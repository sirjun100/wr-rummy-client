// @ts-nocheck
// Recovered from index.js:637
import { _decorator, Component, assetManager, color, director, game, Node, size, Sprite, SpriteFrame, sys, UITransform, v3, view } from "cc";
import i18nMgr from "./i18nMgr";
import PushCenter from "./PushCenter";
import { ToolUtils } from "./ToolUtils";
import { TransferPlatform } from "./TransferPlatform";
import Utils from "./Utils";
import BundleNameDefined from "./BundleNameDefined";
import { CommonGameType } from "./CommDefine";
import GameConfig from "./GameConfig";
import HowToPlayDefined from "./HowToPlayDefined";
import PushEvent from "./PushEvent";
import ReportConfig from "./ReportConfig";
import User from "./User";
const { ccclass, property } = _decorator;
@ccclass("TransitionScene")
export class TransitionScene extends Component {
    static bundle_logic = BundleNameDefined.bundle_rummyTopUI;
    @property(Node)
    public hall_bg: Node = null;
    @property(Node)
    public room_bg: Node = null;
    @property(Node)
    public login_bg: Node = null;
    @property([SpriteFrame])
    public table_bg: SpriteFrame[] = [];
    @property([SpriteFrame])
    public desk_bg: SpriteFrame[] = [];
    @property(SpriteFrame)
    public hall_ipad_bg: SpriteFrame = null;
    @property([SpriteFrame])
    public fourDesk_bgs: SpriteFrame[] = [];
    @property([SpriteFrame])
    public other_table_bg: SpriteFrame[] = [];
    @property([SpriteFrame])
    public other_desk_bg: SpriteFrame[] = [];
    @property([SpriteFrame])
    public chipsMasks: SpriteFrame[] = [];
    public loadTime: number = 0;
    public bRunScene: boolean = false;
    public bundle_name: any = BundleNameDefined.bundle_rummy;
    public bundle_scene: any = BundleNameDefined.rummy_scence;
    onLoad() {
        ToolUtils.report_time_param.switchOnLoad = sys.now();
        sys.os !== sys.OS.IOS && sys.os !== sys.OS.OSX || !ToolUtils.isPadPlatform() ? 1 == GameConfig.CHIPS_MODLE && (this.hall_bg.getChildByName("hall").getChildByName("bg").getComponent(Sprite).spriteFrame = this.chipsMasks[0], this.hall_bg.getChildByName("bottom").getComponent(Sprite).spriteFrame = this.chipsMasks[1]) : (1 == GameConfig.CHIPS_MODLE ? this.hall_bg.getChildByName("hall").getChildByName("bg").getComponent(Sprite).spriteFrame = this.chipsMasks[2] : this.hall_bg.getChildByName("hall").getChildByName("bg").getComponent(Sprite).spriteFrame = this.hall_ipad_bg, this.hall_bg.getChildByName("bottom").active = false);
        let e, t, s = view.getVisibleSize();
        1 == ToolUtils.switchSceneTye ? (e = Math.max(s.height, GameConfig.REAL_SCREEN_WIDTH), t = Math.max(s.width, GameConfig.REAL_SCREEN_HEIGHT)) : (e = Math.max(s.width, GameConfig.REAL_SCREEN_WIDTH), t = Math.max(s.height, GameConfig.REAL_SCREEN_HEIGHT));
        sys.os !== sys.OS.IOS && sys.os !== sys.OS.OSX || !ToolUtils.isPadPlatform() ? e < 720 && (e = 720) : e < 960 && (e = 960);
        t < 1280 && (t = 1280);
        this.hall_bg.getComponent(UITransform).setContentSize(size(e, t));
        this.initBundleLogic();
        let i = size(1560, 720);
        ToolUtils.isPadPlatform() ? (e = Math.max(GameConfig.REAL_SCREEN_HEIGHT, i.width), t = Math.max(GameConfig.REAL_SCREEN_WIDTH, i.height)) : (e = 1 == ToolUtils.switchSceneTye ? Math.max(s.height, GameConfig.REAL_SCREEN_HEIGHT, i.width) : Math.max(s.width, GameConfig.REAL_SCREEN_WIDTH, i.width), t = i.height);
        this.room_bg.getComponent(UITransform).setContentSize(size(e, t));
        this.room_bg.getChildByName("desk").getComponent(UITransform).setContentSize(size(e, t));
        this.login_bg.getComponent(UITransform).setContentSize(size(GameConfig.REAL_SCREEN_WIDTH, e));
        1 == ToolUtils.switchSceneTye && (ToolUtils.checkIsRummy(ToolUtils.curGameType) ? this.refreshRummyRoomBg() : this.refreshGameRoomBg());
        PushCenter.shared().addListener(PushEvent.OnScreenSizeChanged, (e => {
            this.startSwitch();
        }), this);
        this.startSwitch();
        this.fitLuckyTheme();
    }
    fitLuckyTheme() {
        0 != GameConfig.NATIVE_GAME_APP_TYPE && (this.hall_bg.getChildByName("hall").getChildByName("top_test_bg").getComponent(Sprite).color = color(12, 26, 60), this.hall_bg.getChildByName("hall").getChildByName("top_bg").getComponent(Sprite).color = color(12, 26, 60));
    }
    initBundleLogic() {
        this.bundle_name = BundleNameDefined.bundle_rummy;
        this.bundle_scene = BundleNameDefined.rummy_scence;
        ToolUtils.checkIsRummy(ToolUtils.curGameType) ? (this.bundle_name = BundleNameDefined.bundle_rummy, this.bundle_scene = BundleNameDefined.rummy_scence, TransitionScene.bundle_logic = BundleNameDefined.bundle_rummyTopUI) : ToolUtils.curGameType == CommonGameType.SixDice ? (this.bundle_name = BundleNameDefined.Bundle_SixDice, this.bundle_scene = BundleNameDefined.sixdice_scene, TransitionScene.bundle_logic = "") : ToolUtils.curGameType == CommonGameType.FruitMachine ? (this.bundle_name = BundleNameDefined.Bundle_FruitMachine, this.bundle_scene = BundleNameDefined.fruitmachine_scene, TransitionScene.bundle_logic = "") : ToolUtils.curGameType == CommonGameType.Crash ? (this.bundle_name = BundleNameDefined.Bundle_GameCrash, this.bundle_scene = BundleNameDefined.gamecrash_scene, TransitionScene.bundle_logic = "") : ToolUtils.curGameType != CommonGameType.Ludo && ToolUtils.curGameType != CommonGameType.LudoFriend || (this.bundle_name = BundleNameDefined.Bundle_ludo, this.bundle_scene = BundleNameDefined.ludo_scence);
        ToolUtils.cur_game_bundle = this.bundle_name;
    }
    refreshGameRoomBg() {
        ToolUtils.curGameType == CommonGameType.SixDice ? (this.room_bg.getComponent(Sprite).spriteFrame = this.other_table_bg[0], this.room_bg.getChildByName("desk").getComponent(Sprite).spriteFrame = this.other_desk_bg[0], this.room_bg.getChildByName("desk").getComponent(Sprite).sizeMode = 2, this.room_bg.getChildByName("desk").setPosition(v3(0, -11.418))) : ToolUtils.curGameType == CommonGameType.FruitMachine ? (this.room_bg.getComponent(Sprite).spriteFrame = this.other_table_bg[1], this.room_bg.getChildByName("desk").getComponent(Sprite).spriteFrame = this.other_desk_bg[1], this.room_bg.getChildByName("desk").getComponent(Sprite).sizeMode = 2) : ToolUtils.curGameType == CommonGameType.Crash ? (this.room_bg.getComponent(Sprite).spriteFrame = this.other_table_bg[2], this.room_bg.getChildByName("desk").active = false) : ToolUtils.curGameType != CommonGameType.Ludo && ToolUtils.curGameType != CommonGameType.LudoFriend || (sys.isObjectValid(this.other_table_bg[3]) && (this.room_bg.getComponent(Sprite).spriteFrame = this.other_table_bg[3]), sys.isObjectValid(this.other_desk_bg[3]) && (this.room_bg.getChildByName("desk").getComponent(Sprite).spriteFrame = this.other_desk_bg[3], this.room_bg.getChildByName("desk").getComponent(Sprite).sizeMode = 2));
    }
    checkIsMatchRoom() {
        let e = false, t = ToolUtils.deskInfos.get(User.shared().curTid_key);
        return t && 4 == t.mode && 3 != t.match_mode && (e = true), e;
    }
    refreshRummyRoomBg() {
        let e = 4 == User.shared().styles[0] ? 1 : 0;
        5 == User.shared().styles[0] ? e = 2 : 6 == User.shared().styles[0] ? e = 3 : 7 == User.shared().styles[0] && (e = 4);
        let t, s, i = User.shared().styles[0] - 1, a = this.room_bg.getChildByName("desk");
        ToolUtils.deskInfos.get(User.shared().curTid_key) && 1 == ToolUtils.deskInfos.get(User.shared().curTid_key).special_mode ? 0 == i ? a.getComponent(Sprite).spriteFrame = this.fourDesk_bgs[i] : (s = i + 1, t = "rummy_big_four_table_" + s, User.shared().remoteImagesMap.has(t) && sys.isObjectValid(User.shared().remoteImagesMap.get(t)) ? a.getComponent(Sprite).spriteFrame = User.shared().remoteImagesMap.get(t) : (a.getComponent(Sprite).spriteFrame = this.desk_bg[0], Utils.shared().loadRemoteDeskImage(a, t))) : this.checkIsMatchRoom() ? (s = 7, t = "rummy_card_table_bg_0" + s, User.shared().remoteImagesMap.has(t) && sys.isObjectValid(User.shared().remoteImagesMap.get(t)) ? a.getComponent(Sprite).spriteFrame = User.shared().remoteImagesMap.get(t) : Utils.shared().loadRemoteDeskImage(a, t)) : 0 == i ? a.getComponent(Sprite).spriteFrame = this.desk_bg[i] : (s = i, t = "rummy_card_table_bg_0" + s, User.shared().remoteImagesMap.has(t) && sys.isObjectValid(User.shared().remoteImagesMap.get(t)) ? a.getComponent(Sprite).spriteFrame = User.shared().remoteImagesMap.get(t) : (a.getComponent(Sprite).spriteFrame = this.desk_bg[0], Utils.shared().loadRemoteDeskImage(a, t)));
        this.checkIsMatchRoom() ? (s = 6, t = "rummy_game_bg_" + s, User.shared().remoteImagesMap.has(t) && sys.isObjectValid(User.shared().remoteImagesMap.get(t)) ? this.room_bg.getComponent(Sprite).spriteFrame = User.shared().remoteImagesMap.get(t) : Utils.shared().loadRemoteDeskImage(this.room_bg, t)) : 0 == e ? this.room_bg.getComponent(Sprite).spriteFrame = this.table_bg[e] : (s = e + 1, t = "rummy_game_bg_" + s, User.shared().remoteImagesMap.has(t) && sys.isObjectValid(User.shared().remoteImagesMap.get(t)) ? this.room_bg.getComponent(Sprite).spriteFrame = User.shared().remoteImagesMap.get(t) : Utils.shared().loadRemoteDeskImage(this.room_bg, t));
    }
    start() {
        ToolUtils.report_time_param.switchStart = sys.now();
        1 == ToolUtils.switchSceneTye && Utils.shared().releasePublicUnusedAssets(true);
        Utils.shared().cleanPublicAssetsReference();
        TransferPlatform.shared().logEvent_firebase(ReportConfig.firebase_evt.jump_to_switchscene);
    }
    onDestroy() {
        PushCenter.shared().removeListenersByTag(this);
        ToolUtils.switchSceneTye;
        this.unscheduleAllCallbacks();
    }
    startSwitch() {
        1 == ToolUtils.switchSceneTye ? (sys.os !== sys.OS.IOS && sys.os !== sys.OS.OSX && TransferPlatform.shared().setAutoAdapt(1), sys.os === sys.OS.ANDROID || sys.os === sys.OS.OHOS ? (this.room_bg.active = ToolUtils.getOrientation(), this.hall_bg.active = !ToolUtils.getOrientation()) : (this.room_bg.active = true, this.hall_bg.active = false), this.login_bg.active = false, this.bRunScene || (sys.isNative ? ToolUtils.loadBundleScene(this.bundle_name, this.bundle_scene, (() => {
            sys.isObjectValid(this) && this.isValid && this.switchToGame();
        })) : this.switchToGame())) : 2 == ToolUtils.switchSceneTye ? (sys.os !== sys.OS.IOS && sys.os !== sys.OS.OSX && TransferPlatform.shared().setAutoAdapt(0), this.room_bg.active = ToolUtils.getOrientation(), this.hall_bg.active = !ToolUtils.getOrientation(), sys.os === sys.OS.ANDROID || sys.os === sys.OS.OHOS ? (this.room_bg.active = ToolUtils.getOrientation(), this.hall_bg.active = !ToolUtils.getOrientation(), this.room_bg.active) : (this.room_bg.active = false, this.hall_bg.active = true), this.login_bg.active = false, this.bRunScene || this.switchToHall()) : 3 != ToolUtils.switchSceneTye && -1 != ToolUtils.switchSceneTye || (sys.os !== sys.OS.IOS && sys.os !== sys.OS.OSX && TransferPlatform.shared().setAutoAdapt(0), sys.os === sys.OS.ANDROID || sys.os === sys.OS.OHOS ? (this.room_bg.active = ToolUtils.getOrientation(), this.login_bg.active = !ToolUtils.getOrientation()) : (this.room_bg.active = false, this.login_bg.active = true), this.hall_bg.active = false, this.bRunScene || this.switchToLogin());
    }
    switchToGame() {
        ToolUtils.report_time_param.loadGameResStart = sys.now();
        Utils.shared().showLoading(10, true, null, true, 1);
        Utils.shared().releaseHallUnusedAssets(true);
        User.shared().popNode = [];
        this.loadTime = sys.now();
        User.shared().updatePayScene(0);
        let e = this;
        try {
            let t = assetManager.getBundle(this.bundle_name);
            t ? t.loadScene(this.bundle_scene, (function (t, s) {
                if (null == t) {
                    User.shared().vecGameResInit[HowToPlayDefined.gameId_RummyGame] = true;
                    e.bRunScene || (e.bRunScene = true, e.scheduleOnce((() => {
                        sys.os !== sys.OS.IOS && sys.os !== sys.OS.OSX && Utils.shared().releaseHallBundleAssets();
                        Utils.shared().resetDownLoadHeadFlag();
                        Utils.shared().setLoadingPersist(true);
                        director.runScene(s, null, e.onGameSceneLaunched);
                    }), game.frameTime / 1000));
                }
                else {
                    Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text74"), 2);
                    let t = view.getVisibleSize();
                    t.width > t.height && (ToolUtils.switchSceneTye = 2, e.bRunScene = false, TransferPlatform.shared().orientationToPortrait());
                    1 == GameConfig.CHIPS_MODLE ? e.switchToLogin() : e.switchToHall();
                }
            })) : assetManager.loadBundle(this.bundle_name, null, ((t, s) => {
                if (null == t) {
                    s.loadScene(this.bundle_scene, (function (t, s) {
                        if (null == t) {
                            ToolUtils.report_time_param.loadGameResEnd = sys.now();
                            User.shared().vecGameResInit[HowToPlayDefined.gameId_RummyGame] = true;
                            e.bRunScene || (e.bRunScene = true, e.scheduleOnce((() => {
                                sys.os !== sys.OS.IOS && sys.os !== sys.OS.OSX && Utils.shared().releaseHallBundleAssets();
                                Utils.shared().resetDownLoadHeadFlag();
                                Utils.shared().setLoadingPersist(true);
                                director.runScene(s, null, e.onGameSceneLaunched);
                            }), game.frameTime / 1000));
                        }
                        else {
                            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text74"), 2);
                            let t = view.getVisibleSize();
                            t.width > t.height && TransferPlatform.shared().orientationToPortrait();
                            1 == GameConfig.CHIPS_MODLE ? e.switchToLogin() : e.switchToHall();
                        }
                    }));
                }
                else {
                    Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text74"), 2);
                    let t = view.getVisibleSize();
                    t.width > t.height && TransferPlatform.shared().orientationToPortrait();
                    1 == GameConfig.CHIPS_MODLE ? e.switchToLogin() : e.switchToHall();
                }
            }));
        }
        catch (e) {
        }
    }
    onGameSceneLaunched() {
        try {
            ToolUtils.checkIsRummy(ToolUtils.curGameType) || Utils.shared().hideLoading();
            sys.os === sys.OS.IOS || sys.os === sys.OS.OSX ? TransitionScene.bundle_logic.length > 0 && assetManager.loadBundle(TransitionScene.bundle_logic, null, null) : Utils.shared().releaseHallBundleAssets(true);
            ToolUtils.bSendGateHeatBeat = false;
        }
        catch (e) {
        }
    }
    switchToHall() {
        window.InRummyScene = false;
        window.InGameScene = false;
        window.InHallScene = true;
        Utils.shared().showLoading(15, true, null, true, 1);
        Utils.shared().releaseGameUnusedAssets();
        User.shared().popNode = [];
        this.loadTime = sys.now();
        let e = this, t = assetManager.getBundle(BundleNameDefined.bundle_hall);
        if (t) {
            t.loadScene(BundleNameDefined.hall_scene, (function (t, s) {
                null == t ? e.bRunScene || (e.bRunScene = true, e.jumpToHallScene(s)) : (Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text75"), 2), e.switchToLogin());
            }));
        }
        else {
            try {
                assetManager.loadBundle(BundleNameDefined.bundle_hall, null, ((t, s) => {
                    null == t ? s.loadScene(BundleNameDefined.hall_scene, (function (t, s) {
                        null == t ? e.bRunScene || (e.bRunScene = true, e.jumpToHallScene(s)) : (Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text75"), 2), e.switchToLogin());
                    })) : (Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text75"), 2), e.switchToLogin());
                }));
            }
            catch (e) {
            }
        }
    }
    jumpToHallScene(e) {
        this.scheduleOnce((() => {
            Utils.shared().setLoadingPersist(true);
            director.runScene(e, null, this.onHallSceneLaunched);
        }), game.frameTime / 1000);
    }
    onHallSceneLaunched() {
        try {
            Utils.shared().releaseGameUnusedAssets();
        }
        catch (e) {
        }
    }
    switchToLogin() {
        window.InRummyScene = false;
        window.InHallScene = false;
        window.InGameScene = false;
        Utils.shared().releaseGameUnusedAssets();
        let e = this;
        this.bRunScene || (this.bRunScene = true, this.scheduleOnce((() => {
            TransferPlatform.shared().orientationToPortrait();
            director.loadScene("login", e.onLoginSceneLaunched);
        }), game.frameTime / 1000));
    }
    onLoginSceneLaunched() {
        Utils.shared().hideLoading();
        Utils.shared().releaseGameUnusedAssets();
    }
    update(e) {
    }
}
