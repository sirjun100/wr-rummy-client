// @ts-nocheck
// Recovered from index.js:621
import { _decorator, Button, color, instantiate, Label, Node, ScrollView, size, Sprite, SpriteFrame, sys, UITransform, v3, view } from "cc";
import { TLog } from "./TLog";
import Utils from "./Utils";
import SoundManager from "./SoundManager";
import HttpManager from "./HttpManager";
import i18nMgr from "./i18nMgr";
import BaseLayer from "./BaseLayer";
import TweenTool from "./TweenTool";
import GameConfig from "./GameConfig";
import { ScrollviewUtils } from "./ScrollviewUtils";
import { HttpRequest } from "./HttpRequestName";
import User from "./User";
import ReportConfig from "./ReportConfig";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("Tickets")
export class Tickets extends BaseLayer {
    @property(Node)
    public tabNodes: Node = [];
    @property(Node)
    public ticket_item: Node = null;
    @property(Node)
    public nodata: Node = null;
    @property(ScrollView)
    public scollview: ScrollView = null;
    @property(Node)
    public title_item1: Node = null;
    @property(Node)
    public title_item2: Node = null;
    @property([SpriteFrame])
    public ticket_images: SpriteFrame[] = [];
    @property([SpriteFrame])
    public asssureBtnImages: SpriteFrame[] = [];
    @property(Node)
    public asssureBtnNode: Node = null;
    public _scrollUtil: any = null;
    public availableData: any[] = [];
    public unavailableData: any[] = [];
    public outsideRigistrationData: any[] = [];
    public showType: number = 1;
    public _selectColor: any = color(183, 0, 0, 255);
    public _unSelectColor: any = color(84, 89, 155, 255);
    public _callback: any = null;
    public _scrolHei: number = 0;
    public _itemNodes: any[] = [];
    public availablePage: number = 1;
    public unavailablePage: number = 1;
    public availableTotalPage: number = 0;
    public unavailableTotalPage: number = 0;
    public selectIndex: any = -1;
    public click_time: number = 0;
    public link_id: number = 0;
    onLoad() {
        this.fitScreen();
        this._scrollUtil = this.node.addComponent(ScrollviewUtils);
        this._scrollUtil.initScrollviewUtils(this.scollview);
    }
    start() {
        super.start();
        this.showType = 1;
        this.title_item1.active = false;
        this.title_item2.active = false;
        this.ticket_item.active = false;
        this.link_id = sys.now();
        Utils.shared().showLoading(10, true);
        this.requestTicketGetList(1, 1);
        this.updateTabSelect(0);
    }
    requestTicketGetList(t, e) {
        HttpManager.shared().doGetCommonRequest({ available_status: t, page: e }, HttpRequest.TicketGetList, ((t, e, i) => {
            if (Utils.shared().hideLoading(), 200 != i) {
                ToolUtils.isObjValid(this.node) && this.checkIfShowNodata();
            }
            else {
                try {
                    if (ToolUtils.isObjValid(this.node)) {
                        let t = ToolUtils.parseJson(e);
                        if (0 == t.ret && (sys.isObjectValid(t.data) && (1 == t.data.available_status ? (sys.isObjectValid(t.data.page) && (this.availablePage = t.data.page), sys.isObjectValid(t.data.total) && (this.availableTotalPage = t.data.total)) : 0 == t.data.available_status && (sys.isObjectValid(t.data.page) && (this.unavailablePage = t.data.page), sys.isObjectValid(t.data.total) && (this.unavailableTotalPage = t.data.total))), sys.isObjectValid(t.data.list) && Array.isArray(t.data.list))) {
                            for (let e = 0; e < t.data.list.length; e++) {
                                let i = t.data.list[e];
                                1 == t.data.available_status ? 1 == i.status ? this.availableData.push(i) : 4 == i.status && this.outsideRigistrationData.push(i) : 0 == t.data.available_status && this.unavailableData.push(i);
                            }
                            this.refreshListUi();
                        }
                        this.checkIfShowNodata();
                    }
                }
                catch (t) {
                    TLog.printError("requestTicketGetList err:", t.toString());
                }
            }
        }));
    }
    checkIfShowNodata() {
        if (1 == this.showType) {
            let t = this.availableData.length + this.outsideRigistrationData.length;
            this.nodata.active = t < 1;
        }
        else {
            2 == this.showType && (this.nodata.active = this.unavailableData.length < 1);
        }
    }
    initParaData(t = null) {
        this._callback = t;
    }
    updateTabSelect(t) {
        let e = this.showType - 1;
        for (let i = 0, a = this.tabNodes.length; i < a; i++) {
            let a = this.tabNodes[i], s = a, l = a.getChildByName("line"), n = a.getChildByName("di"), o = a.getChildByName("btn");
            if (i == t) {
                if (o.getComponent(Button).interactable = false, s.getComponent(Label).color = this._selectColor, l.active = true, n.active = false, e != t) {
                    l.scale = v3(0, 1, 1);
                    let t = TweenTool.scaleTo(l, 0.16, v3(1.1, 1, 1), null, false), e = TweenTool.scaleTo(l, 0.16, v3(1, 1, 1), null, false);
                    TweenTool.sequence(l, true, null, t, e);
                }
                else {
                    l.scale = v3(1, 1, 1);
                }
            }
            else {
                o.getComponent(Button).interactable = true;
                s.getComponent(Label).color = this._unSelectColor;
                l.scale = v3(1, 1, 1);
                n.active = true;
                i == e ? TweenTool.scaleTo(l, 0.1, v3(0.2, 1, 1), null, true, (() => {
                    l.scale = v3(1, 1, 1);
                    l.active = false;
                })) : l.active = false;
            }
        }
        this.showType = t + 1;
    }
    ticketItem_click(t, e) {
        SoundManager.shared().playFx("click");
        this.selectIndex = Number(e);
        for (let t = 0, i = this._itemNodes.length; t < i; t++) {
            let i = this._itemNodes[t];
            if (ToolUtils.isObjValid(i)) {
                i.getChildByName("select").active = Number(e) == t;
            }
        }
        this.refreshAssureBtn();
        HttpManager.shared().doCommReportRechargeEvent(ReportConfig.Cmd_MatchTicket, 1, 7, this.link_id, null, 0);
    }
    initCurMobanCallBack(t, e, i) {
        if (null == e) {
            return;
        }
        t.active = true;
        let a = e.match_name, s = Number(e.discount), l = e.reward, n = e.ticket_no, o = Number(e.status), h = e.expire_time, u = t.getChildByName("ticket").getComponent(Sprite), m = t.getChildByName("circle"), v = t.getChildByName("select"), b = t.getChildByName("flag_di"), p = t.getChildByName("flag_wz");
        t.getChildByName("name").getComponent(Label).string = a;
        let f = t.getChildByName("money").getComponent(Label), C = ToolUtils.parse_double(String(l), 0);
        sys.isObjectValid(e.mixed) && 1 == e.mixed && (C += "*");
        f.string = "₹" + C;
        let _ = s;
        t.getChildByName("discount").getComponent(Label).string = String(_);
        t.getChildByName("number").getComponent(Label).string = String(n);
        let w = t.getChildByName("date").getComponent(Label);
        0 != i18nMgr.shared().language && i18nMgr.shared().changeLabelFont(w);
        b.active = false;
        p.active = false;
        w.string = ToolUtils.format(i18nMgr.shared().getValueByKey("ticket.expired_date"), h);
        1 == o ? (t.getComponent(Button).interactable = true, t.getComponent(Button).clickEvents[0].customEventData = String(i), Number(_) >= 100 ? u.spriteFrame = this.ticket_images[1] : u.spriteFrame = this.ticket_images[0], m.active = true, -1 == this.selectIndex ? (0 == i && (this.selectIndex = i), v.active = 0 == i) : v.active = this.selectIndex == i, b.active = false, p.active = false) : (t.getComponent(Button).interactable = false, u.spriteFrame = this.ticket_images[2], m.active = false, v.active = false, 3 == o ? (b.active = true, p.active = true, i18nMgr.shared().changeLabelFont(p.getComponent(Label)), p.getComponent(Label).string = i18nMgr.shared().getValueByKey("menu.expired")) : 2 == o && (b.active = true, p.active = true, i18nMgr.shared().changeLabelFont(p.getComponent(Label)), p.getComponent(Label).string = i18nMgr.shared().getValueByKey("menu.used")));
    }
    refreshAssureBtn() {
        -1 != this.selectIndex ? (this.asssureBtnNode.getChildByName("wz").active = false, this.asssureBtnNode.getChildByName("wz2").active = true, this.asssureBtnNode.getComponent(Button).interactable = true, this.asssureBtnNode.getComponent(Sprite).spriteFrame = this.asssureBtnImages[0]) : (this.asssureBtnNode.getComponent(Sprite).spriteFrame = this.asssureBtnImages[1], this.asssureBtnNode.getComponent(Button).interactable = false, this.asssureBtnNode.getChildByName("wz").active = true, this.asssureBtnNode.getChildByName("wz2").active = false);
    }
    refreshListUi() {
        this.scollview.content.removeAllChildren();
        let t = 0, e = 0, i = 0, a = this.title_item1.getComponent(UITransform).height, s = this.ticket_item.getComponent(UITransform).height;
        if (1 == this.showType) {
            let l = this.availableData.length, n = this.outsideRigistrationData.length;
            if (l > 0) {
                let n = instantiate(this.title_item1);
                n.active = true;
                n.setPosition(v3(0, t));
                this.scollview.content.addChild(n);
                t -= a;
                e += a;
                i += 1;
                for (let i = 0; i < l; i++) {
                    if (ToolUtils.isObjValid(this._itemNodes[i])) {
                        this._itemNodes[i].active = true;
                        this._itemNodes[i].setPosition(v3(0, t));
                        this.scollview.content.addChild(this._itemNodes[i]);
                    }
                    else {
                        let e = instantiate(this.ticket_item);
                        e.active = true;
                        e.setPosition(v3(0, t));
                        this.scollview.content.addChild(e);
                        this._itemNodes[i] = e;
                    }
                    t -= s;
                    e += s;
                    this.initCurMobanCallBack(this._itemNodes[i], this.availableData[i], i);
                }
                i += l;
            }
            if (n > 0) {
                let o = instantiate(this.title_item2);
                o.active = true;
                o.setPosition(v3(0, t));
                this.scollview.content.addChild(o);
                a = o.getComponent(UITransform).height;
                e += a;
                t -= a;
                i += 1;
                for (let i = 0; i < n; i++) {
                    let a = i + l;
                    if (ToolUtils.isObjValid(this._itemNodes[a])) {
                        this._itemNodes[a].active = true;
                        this._itemNodes[a].setPosition(v3(0, t));
                        this.scollview.content.addChild(this._itemNodes[a]);
                    }
                    else {
                        let e = instantiate(this.ticket_item);
                        e.active = true;
                        e.setPosition(v3(0, t));
                        this.scollview.content.addChild(e);
                        this._itemNodes[a] = e;
                    }
                    this.initCurMobanCallBack(this._itemNodes[a], this.outsideRigistrationData[i], a);
                    t -= s;
                    e += s;
                }
                i += n;
            }
            let o = this.scollview.getComponent(UITransform).contentSize, h = this._scrolHei;
            0 == l ? (h += 90, e += 90, this.asssureBtnNode.active = false) : this.asssureBtnNode.active = true;
            this.scollview.getComponent(UITransform).setContentSize(size(o.width, h));
            this.scollview.view.getComponent(UITransform).setContentSize(size(o.width, h));
            this.scollview.content.getComponent(UITransform).setContentSize(size(o.width, e));
            this._scrollUtil.setScollDetails2(1, h, i, true, s, this.scrollRefreshCallBack.bind(this));
            this.refreshAssureBtn();
        }
        else if (2 == this.showType) {
            t = -10;
            e += 10;
            let a, s = this.ticket_item.getComponent(UITransform).height;
            for (let i = 0; i < this.unavailableData.length; i++) {
                ToolUtils.isObjValid(this._itemNodes[i]) ? (a = this._itemNodes[i], a.active = true, a.setPosition(v3(0, t)), this.scollview.content.addChild(a)) : (a = instantiate(this.ticket_item), a.active = true, a.setPosition(v3(0, t)), this.scollview.content.addChild(a), this._itemNodes[i] = a);
                t -= s;
                e += s;
                this.initCurMobanCallBack(a, this.unavailableData[i], i);
            }
            i += this.unavailableData.length;
            let l = this.scollview.getComponent(UITransform).contentSize, n = this._scrolHei + 90;
            e += 90;
            this.scollview.getComponent(UITransform).setContentSize(size(l.width, n));
            this.scollview.view.getComponent(UITransform).setContentSize(size(l.width, n));
            this.scollview.content.getComponent(UITransform).setContentSize(size(l.width, e));
            this._scrollUtil.setScollDetails2(1, n, i, true, s, this.scrollRefreshCallBack.bind(this));
        }
        this.checkIfShowNodata();
    }
    scrollRefreshCallBack() {
        if (1 == this.showType) {
            if (this.availablePage++, this.availablePage > this.availableTotalPage) {
                return this.availablePage = this.availableTotalPage, void this.checkIfShowNodata();
            }
            this.requestTicketGetList(1, this.availablePage);
        }
        else if (2 == this.showType) {
            if (this.unavailablePage++, this.unavailablePage > this.unavailableTotalPage) {
                return this.unavailablePage = this.unavailableTotalPage, void this.checkIfShowNodata();
            }
            this.requestTicketGetList(0, this.unavailablePage);
        }
    }
    button_click(t, e) {
        if (SoundManager.shared().playFx("click"), "close" == e) {
            this.onBackView();
        }
        else if ("available" == e) {
            if (1 == this.showType) {
                return;
            }
            HttpManager.shared().doCommReportRechargeEvent(ReportConfig.Cmd_MatchTicket, 1, 2, this.link_id, null, 0);
            this.updateTabSelect(0);
            this.availableData.length + this.outsideRigistrationData.length < 1 ? (this.selectIndex = -1, this.scollview.content.removeAllChildren(), this.availablePage = 1, this.availableData = [], this.outsideRigistrationData = [], this.requestTicketGetList(1, this.availablePage)) : this.refreshListUi();
        }
        else if ("unavailable" == e) {
            if (2 == this.showType) {
                return;
            }
            HttpManager.shared().doCommReportRechargeEvent(ReportConfig.Cmd_MatchTicket, 1, 3, this.link_id, null, 0);
            this.asssureBtnNode.active = false;
            this.updateTabSelect(1);
            this.unavailableData.length < 1 ? (this.scollview.content.removeAllChildren(), this.unavailablePage = 1, this.unavailableData = [], this.requestTicketGetList(0, this.unavailablePage)) : this.refreshListUi();
        }
        else if ("assure" == e && -1 != this.selectIndex && this.availableData.length > this.selectIndex) {
            if (sys.now() - this.click_time <= 1000) {
                return;
            }
            HttpManager.shared().doCommReportRechargeEvent(ReportConfig.Cmd_MatchTicket, 1, 4, this.link_id, null, 0);
            this.click_time = sys.now();
            let t = this.availableData[this.selectIndex].ticket_no;
            User.shared().sendJoinMatch({ ticket_no: t });
        }
    }
    fitScreen() {
        let t = ToolUtils.adaptSafeArea(this.node.getChildByName("root"), 0), e = view.getVisibleSize(), i = ToolUtils.getSafeDistance();
        ToolUtils.isPadPlatform() && (i = 0);
        let a = this.scollview.getComponent(UITransform).contentSize, s = e.height - GameConfig.CONFIG_SCREEN_HEIGHT + a.height - i + t;
        this._scrolHei = s;
        this.scollview.getComponent(UITransform).contentSize = size(a.width, s);
    }
    onBackView() {
        ToolUtils.isObjValid(this.node) && (this._callback && this._callback(), this.node.destroy());
    }
}
