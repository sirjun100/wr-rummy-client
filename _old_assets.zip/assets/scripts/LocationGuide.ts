// @ts-nocheck
// Recovered from index.js:253
import { _decorator, instantiate, Node, PageView, Sprite, SpriteFrame, Vec3 } from "cc";
import Utils from "./Utils";
import TweenTool from "./TweenTool";
import SoundManager from "./SoundManager";
import User from "./User";
import PushEvent from "./PushEvent";
import BaseLayer from "./BaseLayer";
import ReportConfig from "./ReportConfig";
import HttpManager from "./HttpManager";
import { TransferPlatform } from "./TransferPlatform";
import PushCenter from "./PushCenter";
import GameConfig from "./GameConfig";
import { CheckModule } from "./CommDefine";
import i18nMgr from "./i18nMgr";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("LocationGuide")
export class LocationGuide extends BaseLayer {
    @property(Node)
    public rootNode: Node = null;
    @property(Node)
    public maskNode: Node = null;
    @property(PageView)
    public pageView: PageView = null;
    @property(Node)
    public moban: Node = null;
    @property([SpriteFrame])
    public guideImags: SpriteFrame[] = [];
    public turningAction: any = null;
    public _items: any[] = [];
    public _ui_type: number = 1;
    public fromType: any = -1;
    onLoad() {
        ToolUtils.getOrientation() && this.rootNode.setRotationFromEuler(new Vec3(0, 0, 90));
    }
    start() {
        super.start();
        ToolUtils.showFullScreen(this.maskNode);
        this.moban.active = false;
        for (let e = 1, t = 4; e < t; e++) {
            let t = this.rootNode.getChildByName("node" + e);
            t && (this._ui_type == e ? t.active = true : t.active = false);
        }
        if (1 == this._ui_type) {
            this.moban.active = true;
            let e = ReportConfig.func.Hall;
            HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: e, event: ReportConfig.login_evt.location_guide_pop });
        }
        else if (2 == this._ui_type) {
            let e = this.rootNode.getChildByName("node2").getChildByName("tips");
            this.fromType == CheckModule.CHIPS_PLAY && i18nMgr.shared().changeLocalizedLabelKey(e, "location_guide.restrict_chip_tip");
        }
        this.startShowAnim(this.rootNode, (() => {
            1 == this._ui_type && (this.moban.active = false, this.showGuideLocationLunbo());
        }));
        PushCenter.shared().addListener(GameConfig.onEnterForeground, (e => {
            ToolUtils.isObjValid(this.node) && 1 == TransferPlatform.shared().checkOpenLocationPermission() && this.node.destroy();
        }), this);
        PushCenter.shared().addListener(PushEvent.GetLocationSucess, (e => {
            ToolUtils.isObjValid(this.node) && 1 == TransferPlatform.shared().checkOpenLocationPermission() && this.node.destroy();
        }), this);
    }
    initParaData(e, t = -1) {
        this._ui_type = e;
        this.fromType = t;
    }
    onDestroy() {
        super.onDestroy();
        this.stopTurningAnim();
        PushCenter.shared().removeListenersByTag(this);
    }
    onEnable() {
        this.pageView.node.on("scroll-ended", this.onPageTurning, this);
        this.pageView.getPages().length > 0 && (this.stopTurningAnim(), this.playTurningAnim());
    }
    onDisable() {
        this.pageView.node.off("scroll-ended", this.onPageTurning, this);
        this.stopTurningAnim();
    }
    showGuideLocationLunbo() {
        let e = this.guideImags;
        if (e && e.length > 0) {
            if (this.pageView.getPages().length != e.length) {
                if (this.stopTurningAnim(), this.pageView.removeAllPages(), this.pageView.content.removeAllChildren(), this._items = [], 1 == e.length) {
                    let t = instantiate(this.moban);
                    t.active = true;
                    this.initCurMobanCallBack(t, e[0]);
                    this.pageView.addPage(t);
                    this.pageView.elastic = false;
                    this._items.push(t);
                }
                else if (e.length > 1) {
                    for (let t = 0, i = e.length; t < i + 2; t++) {
                        let n = instantiate(this.moban);
                        n.active = true;
                        let s = t - 1;
                        0 == t ? s = i - 1 : t == i + 1 && (s = 0);
                        this.initCurMobanCallBack(n, e[s]);
                        this.pageView.addPage(n);
                        this.pageView.elastic = true;
                        this._items.push(n);
                    }
                    this.pageView.scrollToPage(1, 0);
                    this.playTurningAnim();
                }
            }
            else if (1 == e.length) {
                let t = this._items[0];
                this.initCurMobanCallBack(t, e[0]);
            }
            else if (e.length > 1) {
                for (let t = 0, i = e.length; t < i + 2; t++) {
                    let n = this._items[t], s = t - 1;
                    0 == t ? s = i - 1 : t == i + 1 && (s = 0);
                    this.initCurMobanCallBack(n, e[s]);
                }
            }
        }
        else {
            this.stopTurningAnim();
            this.pageView.removeAllPages();
            this.pageView.content.removeAllChildren();
            let e = instantiate(this.moban);
            e.active = true;
            this.pageView.addPage(e);
            this.pageView.elastic = false;
            this._items.push(e);
        }
    }
    initCurMobanCallBack(e, t) {
        if (ToolUtils.isObjValid(e)) {
            e.getChildByName("img").getComponent(Sprite).spriteFrame = t;
        }
    }
    playTurningAnim() {
        let e = TweenTool.delayAct(this.pageView, this.pageTurning.bind(this), 2, false);
        this.turningAction = TweenTool.sequence(this.pageView, false, null, e, null);
        this.turningAction.repeatForever();
        this.turningAction.start();
    }
    pageTurning() {
        let e = this.pageView.getPages().length, t = this.pageView.getCurrentPageIndex();
        e > 0 && this.pageView.scrollToPage(t + 1, 1);
    }
    stopTurningAnim() {
        this.turningAction && TweenTool.stopAction(this.turningAction);
    }
    onPageTurning(e, t) {
        let i = e.getPages().length, n = this.pageView.getCurrentPageIndex();
        i > 0 && (0 == n ? this.pageView.scrollToPage(i - 2, 0) : n == i - 1 && this.pageView.scrollToPage(1, 0), this.stopTurningAnim(), this.playTurningAnim());
    }
    onButtonClick(e, t) {
        if (SoundManager.shared().playFx("click"), "close" == t) {
            1 == this._ui_type && (HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Hall, event: ReportConfig.login_evt.location_guide_close }), User.shared().requestGetLocationStatus());
            ToolUtils.isObjValid(this.node) && this.node.destroy();
        }
        else if ("kefu" == t) {
            if (1 != User.shared().temp_pingbi.feedback) {
                return void Utils.shared().doJumpLogic(PushEvent.JUMP_TO_FEEDBACK);
            }
            Utils.shared().showToast("Coming soon", 2);
        }
        else {
            "allow" == t ? (User.shared().requestGetLocationStatus(), HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Hall, event: ReportConfig.login_evt.location_guide_allow }), Utils.shared().openLocation(), ToolUtils.isObjValid(this.node) && 1 == TransferPlatform.shared().checkOpenLocationPermission() && this.node.destroy()) : "goit" == t ? (TransferPlatform.shared().getLocationInfo(), ToolUtils.isObjValid(this.node) && this.node.destroy()) : "enble" == t && (Utils.shared().openLocation(), ToolUtils.isObjValid(this.node) && this.node.destroy());
        }
    }
}
