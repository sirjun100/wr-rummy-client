// @ts-nocheck
// Recovered from index.js:69
import { _decorator, Color, Label } from "cc";
const { ccclass, property } = _decorator;
@ccclass("ColorLabel")
export class ColorLabel extends Label {
  private _colors: [Color] = [];
  @property({ type: [Color] })
  public colors: Color[] = [];
  get colors() {
    return this._colors;
  }
  set colors(o) {
    this._colors = o;
  }
  _updateColor() {
    super._updateColor();
    const o = this.renderData,
      r = o.chunk.vb;
    let t = 5;
    for (let e = 0; e < 4; e++, t += o.floatStride) {
      let o = this.colors[e];
      const l = o.r / 255,
        s = o.g / 255,
        c = o.b / 255,
        i = o.a / 255;
      r[t] = l;
      r[t + 1] = s;
      r[t + 2] = c;
      r[t + 3] = i;
    }
  }
}
