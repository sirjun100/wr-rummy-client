// @ts-nocheck
// Recovered from index.js:227
let LanguageConfig;
(LanguageConfig = { Game_no_open: "utlis.text50", Input_name: "utlis.text51", Input_phone: "utlis.text52", Input_email: "utlis.text53", Input_UTR: "utlis.text54", Upload_Screenshot: "utlis.text55", Withdraw_min_tip: "utlis.text56", Withdraw_max_tip: "utlis.text57", Withdraw_succeed: "utlis.text58", Verification_send: "utlis.text59", Email_binding: "utlis.text60", Phone_binding: "utlis.text61", Enter_correct_phone: "utlis.text62", Enter_verify_code: "utlis.text63", Enter_correct_email: "utlis.text64", Enter_correct_code: "utlis.text65" });
export default LanguageConfig;
