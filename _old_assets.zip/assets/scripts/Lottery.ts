// @ts-nocheck
// Recovered from index.js:261
import { _decorator, Button, Label, Node, sp, Sprite, SpriteFrame, sys, UIOpacity, UITransform, v3 } from "cc";
import SoundManager from "./SoundManager";
import BaseLayer from "./BaseLayer";
import PushCenter from "./PushCenter";
import PushEvent from "./PushEvent";
import Utils from "./Utils";
import i18nMgr from "./i18nMgr";
import { TLog } from "./TLog";
import TweenTool from "./TweenTool";
import HttpManager from "./HttpManager";
import User from "./User";
import TableViewUtils from "./TableViewUtils";
import BundleNameDefined from "./BundleNameDefined";
import ReportConfig from "./ReportConfig";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("Lottery")
export class Lottery extends BaseLayer {
    @property(Node)
    public rootNode: Node = null;
    @property(Node)
    public turntable: Node = null;
    @property(Node)
    public lightNode: Node = null;
    @property(Node)
    public spinNode: Node = null;
    @property(Node)
    public addCashNode: Node = null;
    @property(Node)
    public recordNode: Node = null;
    @property(Node)
    public recordMoabn: Node = null;
    @property(Node)
    public recordScrollView: Node = null;
    @property(Node)
    public ruleNode: Node = null;
    @property(Label)
    public ruleLabel: Label = null;
    @property(sp.Skeleton)
    public pointerAnim: any = null;
    @property(sp.Skeleton)
    public winAnim: any = null;
    @property([SpriteFrame])
    public lightSpFrame: SpriteFrame[] = [];
    @property([SpriteFrame])
    public rewardIconSpFrame: SpriteFrame[] = [];
    public isSpinning: boolean = false;
    public isNext: boolean = false;
    public recodeData: any = null;
    public ruleData: any = null;
    public recordTabView: any = null;
    public lastClick: number = 0;
    public isEnterStore: boolean = false;
    public isquick: boolean = false;
    public _pop_souce: number = 0;
    public _has_close: boolean = false;
    public _scene: number = 1;
    public _linkId: number = 0;
    public _bCanSend: boolean = false;
    public checkKyc: number = 0;
    initParaData(e) {
        sys.isObjectValid(e) && (this.isNext = e.isNext, sys.isObjectValid(e.isquick) && (this.isquick = e.isquick), sys.isObjectValid(e.pop_souce) && (this._pop_souce = e.pop_souce), sys.isObjectValid(e.checkKyc) && (this.checkKyc = e.checkKyc), sys.isObjectValid(e.reportScene) && (this._scene = e.reportScene), sys.isObjectValid(e.link_id) && e.link_id > 0 && (this._linkId = e.link_id));
    }
    start() {
        super.start();
        this._linkId = this._linkId > 0 ? this._linkId : sys.now();
        SoundManager.shared().preLoadBundleSounds(BundleNameDefined.bundle_sound, "lottery");
        let e = 0 == i18nMgr.shared().language ? "English" : "Hindi";
        0 == i18nMgr.shared().language ? e = "English" : 1 == i18nMgr.shared().language ? e = "Hindi" : 2 == i18nMgr.shared().language ? e = "Tamil" : 3 == i18nMgr.shared().language && (e = "Urdu");
        this.spinNode.getChildByName("anim").getComponent(sp.Skeleton).setSkin(e);
        this.spinNode.getChildByName("anim").getComponent(sp.Skeleton).setAnimation(0, "zj_anniu2", true);
        this.winAnim.node.active = false;
        this.recordNode.active = false;
        this.pointerAnim.addAnimation(0, "zj_zhizhen2", true);
        let t = [this.recordMoabn];
        this.recodeData = [];
        this.recordMoabn.active = false;
        this.recordTabView = this.node.addComponent(TableViewUtils);
        let i = this.recordMoabn.getComponent(UITransform).height;
        this.recordTabView.init([], this.recordScrollView, t, this.initCurMobanCallBack.bind(this), 0, i);
        this.playLightAnim(0);
        this.startShowAnim(this.rootNode);
        sys.isObjectValid(User.shared().LotteryData) && (this._bCanSend = true, HttpManager.shared().doCommReportRechargeEvent(ReportConfig.Cmd_Lottery, this._scene, 2, this._linkId, { type: User.shared().LotteryData.type }, 0), this.updateLotteryInfo());
        this.doGetLotteryInfoRequest();
        ToolUtils.showFullScreen(this.node.getChildByName("mask"));
        ToolUtils.showFullScreen(this.recordNode.getChildByName("mask"));
        ToolUtils.showFullScreen(this.ruleNode.getChildByName("mask"));
        PushCenter.shared().addListener(PushEvent.UpdateLotteryAct, (e => {
            ToolUtils.isObjValid(this.node) && this.doGetLotteryInfoRequest();
        }), this);
        PushCenter.shared().addListener(PushEvent.RechargeFailed, (e => {
            ToolUtils.isObjValid(this.node) && this.doGetLotteryInfoRequest();
        }), this);
        this.dealMultipleLanguages();
    }
    dealMultipleLanguages() {
        2 == i18nMgr.shared().language && (this.recordNode.getChildByName("bg").getChildByName("rewards_title").getComponent(Label).fontSize = 20);
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().removeListenersByTag(this);
    }
    doGetLotteryInfoRequest() {
        HttpManager.shared().doGetCommonRequest(null, "Act_64.page", this.listengetLotteryInfoCallBack.bind(this));
    }
    listengetLotteryInfoCallBack(e, t, i) {
        if (200 != i) {
            alert("The login timed out, please try again");
        }
        else {
            try {
                let e = ToolUtils.parseJson(t);
                0 == e.ret && (User.shared().LotteryData = e.data, ToolUtils.isObjValid(this.node) && (this._bCanSend || (this._bCanSend = true, HttpManager.shared().doCommReportRechargeEvent(ReportConfig.Cmd_Lottery, this._scene, 2, this._linkId, { type: User.shared().LotteryData.type }, 0)), this.updateLotteryInfo()));
            }
            catch (e) {
                TLog.printError("listengetLotteryInfoCallBack:", e.toString());
            }
        }
    }
    updateLotteryInfo() {
        if (sys.isObjectValid(User.shared().LotteryData)) {
            if (sys.isObjectValid(User.shared().LotteryData.reward)) {
                for (let e = 0; e < 10; e++) {
                    let t = User.shared().LotteryData.reward[e], i = this.turntable.getChildByName(ToolUtils.format("item${0}", e));
                    ToolUtils.isObjValid(i) && sys.isObjectValid(t) && (sys.isObjectValid(this.rewardIconSpFrame[t.type]) && (i.getChildByName("icon").getComponent(Sprite).spriteFrame = this.rewardIconSpFrame[t.type]), i.getChildByName("num").getComponent(Label).string = t.amt);
                }
            }
            let e = ToolUtils.format(i18nMgr.shared().getValueByKey("lottery.tips"), User.shared().LotteryData.pay, User.shared().LotteryData.up);
            this.rootNode.getChildByName("tips").getComponent(Label).string = e;
            let t = this.rootNode.getChildByName("time");
            ToolUtils.isObjValid(t) && (TweenTool.stopNodeAction(t), i18nMgr.shared().changeLabelLanguage(t.getChildByName("wz").getComponent(Label), "lottery.time_left", false, Utils.shared().parseCountDown(User.shared().LotteryData.leftTime)), TweenTool.myschedule(t, 1, (() => {
                ToolUtils.isObjValid(this.node) && (User.shared().LotteryData.leftTime > 0 ? (User.shared().LotteryData.leftTime = User.shared().LotteryData.leftTime - 1, i18nMgr.shared().changeLabelLanguage(t.getChildByName("wz").getComponent(Label), "lottery.time_left", false, Utils.shared().parseCountDown(User.shared().LotteryData.leftTime))) : TweenTool.stopNodeAction(t));
            })));
            this.updateAddCashNodeStatus();
            this.updateSpainNodeStatus();
        }
    }
    updateAddCashNodeStatus() {
        if (sys.isObjectValid(User.shared().LotteryData.myspin)) {
            if (this.rootNode.getChildByName("spins").getComponent(Label).string = "x" + User.shared().LotteryData.myspin, User.shared().LotteryData.myspin > 0) {
                let e = User.shared().LotteryData.myspin >= 10 ? 10 : 1;
                this.addCashNode.getChildByName("wz").getComponent(Label).fontSize = 38;
                this.addCashNode.getChildByName("wz").getComponent(Label).string = ToolUtils.format("${0} x${1}", i18nMgr.shared().getValueByKey("lottery.spin"), e);
                i18nMgr.shared().changeLabelFont(this.addCashNode.getChildByName("wz").getComponent(Label), true);
                this.addCashNode.getComponent(Button).clickEvents[0].customEventData = "lottery_spin";
            }
            else {
                this.addCashNode.getChildByName("wz").getComponent(Label).fontSize = 48;
                this.addCashNode.getChildByName("wz").getComponent(Label).string = ToolUtils.format("₹${0}", User.shared().LotteryData.money);
                i18nMgr.shared().changeLabelFont(this.addCashNode.getChildByName("wz").getComponent(Label), true);
                this.addCashNode.getComponent(Button).clickEvents[0].customEventData = "lottery_buy";
            }
        }
    }
    updateSpainNodeStatus() {
        this.isSpinning ? (this.spinNode.getComponent(Button).interactable = false, this.spinNode.getChildByName("anim").getComponent(sp.Skeleton).setAnimation(0, "zj_anniu2", true)) : (this.spinNode.getComponent(Button).interactable = true, sys.isObjectValid(User.shared().LotteryData.myspin) && User.shared().LotteryData.myspin > 0 ? this.spinNode.getChildByName("anim").getComponent(sp.Skeleton).setAnimation(0, "zj_anniu1", true) : this.spinNode.getChildByName("anim").getComponent(sp.Skeleton).setAnimation(0, "zj_anniu2", true));
    }
    onButtonClick(e, t) {
        if (SoundManager.shared().playFx("click"), "close" == t) {
            1 == this.checkKyc && Utils.shared().checkAddCashKyc();
            this.onBackView();
        }
        else if ("add_cash" == t) {
            if (sys.now() - this.lastClick < 1000) {
                return;
            }
            let e = ToolUtils.getIsInRoom() ? 7 : 6, t = sys.now();
            if (this._bCanSend && HttpManager.shared().doCommReportRechargeEvent(ReportConfig.Cmd_Lottery, this._scene, e, this._linkId, { type: User.shared().LotteryData.type }, 0, t), HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Hall, event: ReportConfig.common.try_recharge }), this.lastClick = sys.now(), !this.isSpinning) {
                if (User.shared().b_storeLevel) {
                    if (PushCenter.shared().pushEvent(PushEvent.showStoreRecharge), !this.isEnterStore && this.isquick) {
                        let e = ToolUtils.judgeIfInHall() ? 1 : 9;
                        User.shared().requestFreeCashPage(1, false, 0, e);
                    }
                    this.onBackView();
                }
                else {
                    this.isEnterStore = true;
                    let i = { act_id: PushEvent.JUMP_TO_LOTTERYACT };
                    this._bCanSend && (i.link_id = this._linkId, i.act_type = User.shared().LotteryData.type, i.event = e, i.client_time = t);
                    Utils.shared().showStoreView(i, this.node);
                }
            }
        }
        else if ("spin" == t) {
            if (sys.now() - this.lastClick < 1000) {
                return;
            }
            if (this.lastClick = sys.now(), this._bCanSend && HttpManager.shared().doCommReportRechargeEvent(ReportConfig.Cmd_Lottery, this._scene, 9, this._linkId, { type: User.shared().LotteryData.type }, 0), !this.isSpinning) {
                if (sys.isObjectValid(User.shared().LotteryData.myspin) && User.shared().LotteryData.myspin > 0) {
                    HttpManager.shared().doGetCommonRequest({ mode: User.shared().LotteryData.mode, spin: 1 }, "Act_64.spin", this.listengetLotterySpinCallBack.bind(this));
                }
                else {
                    let e = ToolUtils.format(i18nMgr.shared().getValueByKey("lottery.recharge_tips"), User.shared().LotteryData.money);
                    Utils.shared().showToast(e, 2);
                }
            }
        }
        else if ("lottery_spin" == t) {
            if (sys.now() - this.lastClick < 1000) {
                return;
            }
            if (this.lastClick = sys.now(), !this.isSpinning) {
                if (sys.isObjectValid(User.shared().LotteryData.myspin) && User.shared().LotteryData.myspin > 0) {
                    let e = User.shared().LotteryData.myspin >= 10 ? 10 : 1;
                    if (this._bCanSend) {
                        let t = 10 == e ? 10 : 9;
                        HttpManager.shared().doCommReportRechargeEvent(ReportConfig.Cmd_Lottery, this._scene, t, this._linkId, { type: User.shared().LotteryData.type }, 0);
                    }
                    HttpManager.shared().doGetCommonRequest({ mode: User.shared().LotteryData.mode, spin: e }, "Act_64.spin", this.listengetLotterySpinCallBack.bind(this));
                }
                else {
                    let e = ToolUtils.format(i18nMgr.shared().getValueByKey("lottery.recharge_tips"), User.shared().LotteryData.money);
                    Utils.shared().showToast(e, 2);
                }
            }
        }
        else if ("lottery_buy" == t) {
            if (!User.shared().checkCanRecharge()) {
                return void (ToolUtils.isObjValid(this.node) && this.node.destroy());
            }
            if (sys.now() - this.lastClick < 500) {
                return;
            }
            if (this.lastClick = sys.now(), !this.isSpinning && sys.isObjectValid(t)) {
                let e = ToolUtils.getIsInRoom() ? 5 : 4, t = sys.now();
                this._bCanSend && HttpManager.shared().doCommReportRechargeEvent(ReportConfig.Cmd_Lottery, this._scene, e, this._linkId, { price: Number(User.shared().LotteryData.money), type: User.shared().LotteryData.type }, 0, t);
                let i = { pway: User.shared().LotteryData.pways + "", price: Number(User.shared().LotteryData.money), act_id: PushEvent.JUMP_TO_LOTTERYACT };
                this._bCanSend && (i.link_id = this._linkId, i.act_type = User.shared().LotteryData.type, i.event = e, i.client_time = t);
                User.shared().startPay(i);
            }
        }
        else {
            "record" == t ? (sys.isObjectValid(this.recodeData) && this.recodeData.length > 0 && this.showRecordView(), HttpManager.shared().doGetCommonRequest(null, "Act_64.getSpin", this.listengetLotteryRecordCallBack.bind(this))) : "rule" == t && (this._bCanSend, sys.isObjectValid(this.ruleData) ? this.showRuleView() : HttpManager.shared().doGetCommonRequest(null, "Act_64.tips", this.listengetLotteryRuleCallBack.bind(this)));
        }
    }
    listengetLotterySpinCallBack(e, t, i) {
        if (200 != i) {
            alert("The login timed out, please try again");
        }
        else {
            try {
                let e = ToolUtils.parseJson(t);
                if (0 == e.ret && (User.shared().LotteryData.myspin = e.data.myspin, ToolUtils.isObjValid(this.node))) {
                    this.updateAddCashNodeStatus();
                    this.updateSpainNodeStatus();
                    let t = this.getLotteryIndexById(e.data.id);
                    sys.isObjectValid(t) && this.startRunTurntable(t, (() => {
                        ToolUtils.isObjValid(this.node) && this.endLotterySpinCallBack(t, e.data.reward);
                    }));
                }
            }
            catch (e) {
                TLog.printError("listengetLotterySpinCallBack:", e.toString());
            }
        }
    }
    getLotteryIndexById(e) {
        if (sys.isObjectValid(User.shared().LotteryData) && sys.isObjectValid(User.shared().LotteryData.reward)) {
            for (let t = 0, i = User.shared().LotteryData.reward.length; t < i; t++) {
                if (User.shared().LotteryData.reward[t].id == e) {
                    return t;
                }
            }
        }
        return null;
    }
    startRunTurntable(e, t) {
        if (!this.isSpinning) {
            this.isSpinning = true;
            this.playLightAnim(1);
            this.updateSpainNodeStatus();
            SoundManager.shared().playFx("lottery_spin");
            let i = this.turntable.eulerAngles.z % 360, a = 1800 - 36 * e;
            this.turntable.setRotationFromEuler(v3(0, 0, i));
            TweenTool.rotateTo(this.turntable, 4, v3(0, 0, -a), "cubicInOut", true, t);
            this.pointerAnim.clearTracks();
            this.pointerAnim.setToSetupPose();
            this.pointerAnim.setAnimation(0, "zj_zhizhen1", false);
            this.pointerAnim.addAnimation(0, "zj_zhizhen2", true);
            let s = this.turntable.getChildByName("blur");
            if (s) {
                s.active = true;
                s.getComponent(UIOpacity).opacity = 0;
                let e = TweenTool.delayAct(s, null, 1, false), t = TweenTool.moveToByFade(s, 0.48, null, 0, 1, false), i = TweenTool.moveToByFade(s, 0.95, null, 1, 0.7, false), a = TweenTool.moveToByFade(s, 0.54, null, 0.7, 0, false);
                TweenTool.sequence(s, true, (() => {
                    s.active = false;
                }), e, t, i, a);
            }
        }
    }
    endLotterySpinCallBack(e, t) {
        this.playLightAnim(0);
        this.turntable.setRotationFromEuler(v3(0, 0, 36 * e - 360));
        SoundManager.shared().playFx("lottery_win");
        this.winAnim.node.active = true;
        this.winAnim.setAnimation(0, "zj_kj", false);
        this.winAnim.setCompleteListener((() => {
            ToolUtils.isObjValid(this.node) && (this.isSpinning = false, this.winAnim.node.active = false, this.updateSpainNodeStatus(), this.Poprewards(t));
        }));
    }
    Poprewards(e) {
        sys.isObjectValid(e) && e.length > 0 && User.shared().showChargeReward(e);
    }
    playLightAnim(e) {
        if (ToolUtils.isObjValid(this.lightNode)) {
            let t = 0 == e ? 0.5 : 0.2;
            TweenTool.stopNodeAction(this.lightNode);
            this.lightNode.getComponent(Sprite).spriteFrame = this.lightSpFrame[0];
            let i = TweenTool.delayAct(this.lightNode, (() => {
                ToolUtils.isObjValid(this.lightNode) && (this.lightNode.getComponent(Sprite).spriteFrame = this.lightSpFrame[1]);
            }), t, false), a = TweenTool.delayAct(this.lightNode, (() => {
                ToolUtils.isObjValid(this.lightNode) && (this.lightNode.getComponent(Sprite).spriteFrame = this.lightSpFrame[0]);
            }), t, false), s = TweenTool.sequence(this.lightNode, false, null, i, a);
            s.repeatForever();
            s.start();
        }
    }
    listengetLotteryRecordCallBack(e, t, i) {
        if (200 != i) {
            alert("The login timed out, please try again");
        }
        else {
            try {
                let e = ToolUtils.parseJson(t);
                0 == e.ret && ToolUtils.isObjValid(this.node) && (this.recodeData = e.data, this.showRecordView());
            }
            catch (e) {
                TLog.printError("listengetLotteryRecordCallBack:", e.toString());
            }
        }
    }
    showRecordView() {
        this.recordNode.active ? this.updateRecordView() : (this.recordNode.active = true, this.startShowAnim(this.recordNode.getChildByName("bg"), (() => {
            this.updateRecordView();
        })));
    }
    updateRecordView() {
        sys.isObjectValid(this.recodeData) && this.recodeData.length > 0 ? (this.recordTabView.reloadData(this.recodeData, false), this.recordNode.getChildByName("bg").getChildByName("nodata").active = false) : (this.recordTabView.reloadData([], false), this.recordNode.getChildByName("bg").getChildByName("nodata").active = true);
    }
    initCurMobanCallBack(e, t) {
        sys.isObjectValid(t) && (e.active = true, e.getChildByName("date").getComponent(Label).string = t.ctime, e.getChildByName("spins").getComponent(Label).string = ToolUtils.format("x${0}", t.spin), e.getChildByName("rewards").getComponent(Label).string = t.reward);
    }
    listengetLotteryRuleCallBack(e, t, i) {
        if (200 != i) {
            alert("The login timed out, please try again");
        }
        else {
            try {
                let e = ToolUtils.parseJson(t);
                0 == e.ret && (this.ruleData = e.data, ToolUtils.isObjValid(this.node) && this.showRuleView());
            }
            catch (e) {
                TLog.printError("listengetLotteryRuleCallBack:", e.toString());
            }
        }
    }
    showRuleView() {
        ToolUtils.isObjValid(this.recordNode) && (this.recordNode.active ? (this.ruleLabel.string = this.ruleData.tips, i18nMgr.shared().changeLabelFont(this.ruleLabel)) : (this.ruleNode.active = true, this.startShowAnim(this.ruleNode.getChildByName("bg"), (() => {
            this.ruleLabel.string = this.ruleData.tips;
            i18nMgr.shared().changeLabelFont(this.ruleLabel);
        }))));
    }
    onBackView() {
        if (ToolUtils.isObjValid(this.node)) {
            if (ToolUtils.isObjValid(this.recordNode) && this.recordNode.active) {
                this.recordNode.active = false;
            }
            else if (ToolUtils.isObjValid(this.ruleNode) && this.ruleNode.active) {
                this.ruleNode.active = false;
            }
            else {
                if (this._has_close) {
                    return;
                }
                this._bCanSend;
                let e = { alert_node: this.node, rootNode: this.rootNode, isNext: this.isNext, pop_type: PushEvent.JUMP_TO_LOTTERYACT, pop_souce: this._pop_souce };
                Utils.shared().closeActivityView(e);
                this._has_close = true;
                User.shared().getHallInfo();
            }
        }
    }
}
