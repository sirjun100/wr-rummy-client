// @ts-nocheck
// Recovered from index.js:503
import { _decorator, Node } from "cc";
import BaseLayer from "./BaseLayer";
import SoundManager from "./SoundManager";
import LoopScrollView from "./LoopScrollView";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("SelectArea")
export class SelectArea extends BaseLayer {
    @property(Node)
    public scrollView: Node = null;
    public _cb: any = null;
    public curIndex: number = 0;
    public idProofArray: any = null;
    setCallBack(t, e, i) {
        this._cb = t;
        this.curIndex = e;
        this.idProofArray = i;
    }
    start() {
        super.start();
        this.initView();
    }
    initView() {
        this.scrollView.getComponent(LoopScrollView).initData(this.idProofArray, this.loopScrollViewCallBack.bind(this), this.curIndex, false);
    }
    loopScrollViewCallBack(t, e) {
        this.curIndex != t && (this.curIndex = t);
    }
    onButtonClick(t, e) {
        SoundManager.shared().playFx("click");
        "ok" == e && (this._cb && this._cb(this.curIndex), ToolUtils.isObjValid(this.node) && this.node.destroy());
    }
}
