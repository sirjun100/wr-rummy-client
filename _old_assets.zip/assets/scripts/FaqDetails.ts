// @ts-nocheck
// Recovered from index.js:117
import { _decorator, Button, director, instantiate, Label, Layout, Node, RichText, ScrollView, size, Sprite, SpriteFrame, sys, UITransform, v3, Widget } from "cc";
import SoundManager from "./SoundManager";
import PushCenter from "./PushCenter";
import { TLog } from "./TLog";
import Utils from "./Utils";
import User from "./User";
import HttpManager from "./HttpManager";
import PushEvent from "./PushEvent";
import i18nMgr from "./i18nMgr";
import BaseLayer from "./BaseLayer";
import { HttpRequest } from "./HttpRequestName";
import BundleNameDefined from "./BundleNameDefined";
import { TransferPlatform } from "./TransferPlatform";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("FaqDetails")
export class FaqDetails extends BaseLayer {
    public TAG: string = "FaqDetails";
    @property(Node)
    public rootNode: Node = null;
    @property(ScrollView)
    public scrollView: ScrollView = null;
    @property(Node)
    public menuNode: Node = null;
    @property(ScrollView)
    public menuScrollView: ScrollView = null;
    @property([SpriteFrame])
    public itemBgImgs: SpriteFrame[] = [];
    @property([SpriteFrame])
    public statusImgs: SpriteFrame[] = [];
    @property(Node)
    public mobanView: Node = null;
    @property(Node)
    public typeMobanView: Node = null;
    public _closed: boolean = false;
    public bShowPushAnim: boolean = true;
    public _lastClick: number = 0;
    public _sourceData: any = null;
    public _itemArr: any[] = [];
    public _typeMenuInit: boolean = false;
    public JumpType: any = { Chat_Us: "c_01", MemberShip: "c_02", Withdraw_Records: "c_03", Charge_Records: "c_04", TDS: "c_05", STORE: "c_06", KYC: "c_07", WALLET: "c_08", Terms_Service: "c_09", Invite: "c_10", CashLimit: "c_11", RNG: "c_12", Telegram: "c_13", GST: "c_14", Telegram_Channel: "c_15", RESPONSIBLY: "c_16" };
    onLoad() {
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().removeListenersByTag(this);
        this.unscheduleAllCallbacks();
    }
    init(e) {
        sys.isObjectValid(e) && sys.isObjectValid(e.source) && (this._sourceData = e.source);
    }
    start() {
        super.start();
        this.initView();
        this.bShowPushAnim && ToolUtils.showPushAnim(this.node, 0, (() => {
        }));
        this.refreshView();
        PushCenter.shared().addListener(PushEvent.RichTextClick, (e => {
            ToolUtils.isObjValid(this.node) && this.onButtonClick(null, e);
        }), this);
    }
    refreshView() {
        if (sys.isObjectValid(this._sourceData)) {
            this.scrollView.content.removeAllChildren();
            this._itemArr = [];
            sys.isObjectValid(this._sourceData.title) && this._sourceData.title.length > 0 && (this.rootNode.getChildByName("top_node").getChildByName("type_title").getComponent(Label).string = this._sourceData.title.replace(/(\r\n|\r|\n|\u2028|\u2029)/g, ""));
            for (let e = 0; e < this._sourceData.list.length; e++) {
                let t = instantiate(this.mobanView);
                t.active = true;
                this.initItemView(t, this._sourceData.list[e], e);
                t.parent = this.scrollView.content;
                this._itemArr.push(t);
            }
        }
    }
    initItemView(e, t, i) {
        sys.isObjectValid(t.title) && t.title.length > 0 && (e.getChildByName("title").getComponent(Label).string = t.title);
        sys.isObjectValid(t.content) && t.content.length > 0 && (e.getChildByName("content").getComponent(RichText).string = t.content);
        e.getChildByName("arrow").getComponent(Button).clickEvents[0].customEventData = String(i);
        sys.isObjectValid(t.status) && (0 == t.status ? (e.getChildByName("tip_node").getChildByName("status_node").getChildByName("item0").active = true, e.getChildByName("tip_node").getChildByName("status_node").getChildByName("item1").active = true, e.getChildByName("tip_node").getChildByName("status_node").getChildByName("item0").getComponent(Button).clickEvents[0].customEventData = String(i), e.getChildByName("tip_node").getChildByName("status_node").getChildByName("item1").getComponent(Button).clickEvents[0].customEventData = String(i), e.getChildByName("tip_node").getChildByName("status_node").getChildByName("item0").getComponent(Button).interactable = true, e.getChildByName("tip_node").getChildByName("status_node").getChildByName("item1").getComponent(Button).interactable = true, e.getChildByName("tip_node").getChildByName("status_node").getChildByName("item0").getChildByName("ico").getComponent(Sprite).spriteFrame = this.statusImgs[0], e.getChildByName("tip_node").getChildByName("status_node").getChildByName("item1").getChildByName("ico").getComponent(Sprite).spriteFrame = this.statusImgs[0]) : 1 == t.status ? (e.getChildByName("tip_node").getChildByName("status_node").getChildByName("item0").active = true, e.getChildByName("tip_node").getChildByName("status_node").getChildByName("item1").active = false, e.getChildByName("tip_node").getChildByName("status_node").getChildByName("item0").getComponent(Button).interactable = false, e.getChildByName("tip_node").getChildByName("status_node").getChildByName("item0").getChildByName("ico").getComponent(Sprite).spriteFrame = this.statusImgs[1]) : 2 == t.status && (e.getChildByName("tip_node").getChildByName("status_node").getChildByName("item0").active = false, e.getChildByName("tip_node").getChildByName("status_node").getChildByName("item1").active = true, e.getChildByName("tip_node").getChildByName("status_node").getChildByName("item1").getComponent(Button).interactable = false, e.getChildByName("tip_node").getChildByName("status_node").getChildByName("item1").getChildByName("ico").getComponent(Sprite).spriteFrame = this.statusImgs[1]));
    }
    onCloseButtonClick(e, t) {
        if (SoundManager.shared().playFx("click"), "back_btn" == t) {
            if (this._closed) {
                return;
            }
            this.onBackView();
        }
    }
    initView() {
        this.fitScreen();
    }
    onGoodClick(e, t) {
        if (SoundManager.shared().playFx("click"), sys.now() - this._lastClick < 500) {
            return;
        }
        this._lastClick = sys.now();
        let i = Number(t);
        this.dealSubmitLogic(1, i);
    }
    onBadClick(e, t) {
        if (SoundManager.shared().playFx("click"), sys.now() - this._lastClick < 500) {
            return;
        }
        this._lastClick = sys.now();
        let i = Number(t);
        this.dealSubmitLogic(2, i);
    }
    updateItemStatus(e, t) {
        if (t < this._itemArr.length) {
            let i = this._itemArr[t];
            if (!sys.isObjectValid(i)) {
                return;
            }
            1 == e ? (i.getChildByName("tip_node").getChildByName("status_node").getChildByName("item0").active = true, i.getChildByName("tip_node").getChildByName("status_node").getChildByName("item1").active = false, i.getChildByName("tip_node").getChildByName("status_node").getChildByName("item0").getComponent(Button).interactable = false, i.getChildByName("tip_node").getChildByName("status_node").getChildByName("item0").getChildByName("ico").getComponent(Sprite).spriteFrame = this.statusImgs[1]) : 2 == e && (i.getChildByName("tip_node").getChildByName("status_node").getChildByName("item0").active = false, i.getChildByName("tip_node").getChildByName("status_node").getChildByName("item1").active = true, i.getChildByName("tip_node").getChildByName("status_node").getChildByName("item1").getComponent(Button).interactable = false, i.getChildByName("tip_node").getChildByName("status_node").getChildByName("item1").getChildByName("ico").getComponent(Sprite).spriteFrame = this.statusImgs[1]);
            this._sourceData.list[t].status = e;
            sys.isObjectValid(this._sourceData.m_type) && User.shared().faqDetailsData.has(Number(this._sourceData.m_type)) && (User.shared().faqDetailsData.get(Number(this._sourceData.m_type)).status = e);
        }
    }
    dealSubmitLogic(e, t) {
        let i = 0, a = this._sourceData.m_type;
        t < this._sourceData.list.length && sys.isObjectValid(this._sourceData.list[t]) && sys.isObjectValid(this._sourceData.list[t].s_type) && (i = this._sourceData.list[t].s_type);
        Utils.shared().showLoading(10, true, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
        }), ToolUtils.getIsNormalDirection());
        HttpManager.shared().doGetCommonRequest({ m_type: a, s_type: i, op: e }, HttpRequest.FaqDetailsSubmitPage, ((i, a, s) => {
            if (Utils.shared().hideLoading(), 200 != s) {
                ;
            }
            else {
                try {
                    0 == ToolUtils.parseJson(a).ret && this.updateItemStatus(e, t);
                }
                catch (e) {
                    TLog.printError(this.TAG, "dealSubmitLogic err:", e.toString());
                }
            }
        }));
    }
    changeItemArrow(e) {
        if (e < this._itemArr.length) {
            let t = this._itemArr[e];
            if (!sys.isObjectValid(t)) {
                return;
            }
            if (t.getChildByName("content").active) {
                t.getChildByName("content").active = false;
                t.getChildByName("tip_node").active = false;
                t.getChildByName("arrow").getChildByName("ico").scale = v3(1, 1);
                t.getChildByName("bg").getComponent(Sprite).spriteFrame = this.itemBgImgs[0];
                t.getChildByName("bg").getComponent(UITransform).contentSize = size(682, 110);
                t.getComponent(UITransform).contentSize = size(682, 110);
                this.scrollView.content.getComponent(Layout).updateLayout();
            }
            else {
                t.getChildByName("content").active = true;
                t.getChildByName("tip_node").active = true;
                t.getChildByName("arrow").getChildByName("ico").scale = v3(-1, 1);
                t.getChildByName("content").getChildByName("ico").getComponent(Widget).updateAlignment();
                let e = t.getChildByName("content").getChildByName("ico").getComponent(UITransform).contentSize.height;
                t.getChildByName("bg").getComponent(Sprite).spriteFrame = this.itemBgImgs[1];
                t.getChildByName("bg").getComponent(UITransform).contentSize = size(682, e);
                t.getComponent(UITransform).contentSize = size(682, e);
                t.getChildByName("tip_node").getComponent(Widget).updateAlignment();
                this.scrollView.content.getComponent(Layout).updateLayout();
            }
        }
    }
    onItemClick(e, t) {
        if (SoundManager.shared().playFx("click"), sys.now() - this._lastClick < 500) {
            return;
        }
        this._lastClick = sys.now();
        let i = Number(t);
        this.changeItemArrow(i);
    }
    onTypeItemClick(e, t) {
        if (SoundManager.shared().playFx("click"), sys.now() - this._lastClick < 500) {
            return;
        }
        this._lastClick = sys.now();
        let i = Number(t);
        User.shared().faqDetailsData.has(Number(i)) ? (this._sourceData = User.shared().faqDetailsData.get(Number(i)), this.menuNode.active = false, this.refreshView()) : (Utils.shared().showLoading(10, true, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
        }), ToolUtils.getIsNormalDirection()), HttpManager.shared().doGetCommonRequest({ m_type: i }, HttpRequest.FaqDetailsPage, ((e, t, a) => {
            if (Utils.shared().hideLoading(), 200 != a) {
                ;
            }
            else {
                try {
                    let e = ToolUtils.parseJson(t);
                    0 == e.ret && sys.isObjectValid(e.data) && (User.shared().faqDetailsData.set(i, e.data), this._sourceData = e.data, this.menuNode.active = false, this.refreshView());
                }
                catch (e) {
                    TLog.printError("User requestBagPackPage err:", e.toString());
                }
            }
        })));
    }
    onButtonClick(e, t) {
        SoundManager.shared().playFx("click");
        sys.now() - this._lastClick < 500 || (this._lastClick = sys.now(), "chat_us" == t || t == this.JumpType.Chat_Us ? Utils.shared().showContactUsView() : t == this.JumpType.MemberShip ? Utils.shared().doJumpLogic(PushEvent.JUMP_TO_CLUB) : t == this.JumpType.Withdraw_Records ? Utils.shared().showWalletRecordView(2, this.node) : t == this.JumpType.Charge_Records ? Utils.shared().showWalletRecordView(1, this.node) : t == this.JumpType.TDS ? this.showPopPrefab("tds") : t == this.JumpType.STORE ? Utils.shared().doJumpLogic(PushEvent.JUMP_TO_STORE) : t == this.JumpType.KYC ? Utils.shared().showFastKyc() : t == this.JumpType.WALLET ? Utils.shared().doJumpLogic(PushEvent.JUMP_TO_WALLET) : t == this.JumpType.Terms_Service ? Utils.shared().doCustomJump(PushEvent.Custom_TO_TC) : t == this.JumpType.Invite ? Utils.shared().doJumpLogic(PushEvent.JUMP_TO_INVITE) : t == this.JumpType.CashLimit ? Utils.shared().showRechargeLimitsView() : t == this.JumpType.RNG ? Utils.shared().doJumpLogic(PushEvent.Custom_TO_RESPONSIBLY) : t == this.JumpType.GST ? Utils.shared().doJumpLogic(PushEvent.Custom_TO_GSTRULE) : t == this.JumpType.Telegram ? 1 === TransferPlatform.shared().checkPackageInstalled("org.telegram.messenger") ? TransferPlatform.shared().openApplicationChat("org.telegram.messenger", ToolUtils.feedback_data.tgurl) : 1 === TransferPlatform.shared().checkPackageInstalled("org.telegram.messenger.web") ? TransferPlatform.shared().openApplicationChat("org.telegram.messenger.web", ToolUtils.feedback_data.tgurl) : (TransferPlatform.shared().copyContent(ToolUtils.feedback_data.tg), Utils.shared().showToast(i18nMgr.shared().getValueByKey("contact_us.copy_successfully"), 2)) : t == this.JumpType.Telegram_Channel ? 1 === TransferPlatform.shared().checkPackageInstalled("org.telegram.messenger") ? TransferPlatform.shared().openApplicationChat("org.telegram.messenger", ToolUtils.feedback_data.tg_official_url) : 1 === TransferPlatform.shared().checkPackageInstalled("org.telegram.messenger.web") ? TransferPlatform.shared().openApplicationChat("org.telegram.messenger.web", ToolUtils.feedback_data.tg_official_url) : sys.openURL(ToolUtils.feedback_data.tg_official_url) : t == this.JumpType.RESPONSIBLY ? Utils.shared().doJumpLogic(PushEvent.JUMP_TO_RESPONSIBLY) : "type_menu" == t ? this.menuNode.active ? this.menuNode.active = false : (this._typeMenuInit || this.initTypeMenuView(), this.menuNode.active = true) : "menu_close" == t && (this.menuNode.active = false));
    }
    initTypeMenuView() {
        this._typeMenuInit = true;
        this.menuScrollView.content.destroyAllChildren();
        let e = User.shared().faqMainData;
        for (let t = 0; t < e.list.length; t++) {
            let i = instantiate(this.typeMobanView);
            i.active = true;
            sys.isObjectValid(e.list[t].title) && e.list[t].title.length > 0 && (i.getChildByName("title").getComponent(Label).string = e.list[t].title.replace(/(\r\n|\r|\n|\u2028|\u2029)/g, ""));
            sys.isObjectValid(e.list[t].content) && e.list[t].content.length > 0 && (i.getChildByName("desc").getComponent(Label).string = e.list[t].content.replace(/(\r\n|\r|\n|\u2028|\u2029)/g, ""));
            i.parent = this.menuScrollView.content;
            i.getComponent(Button).clickEvents[0].customEventData = e.list[t].m_type;
        }
    }
    showPopPrefab(e) {
        ToolUtils.loadCommonPrefab(null, BundleNameDefined.bundle_menu, "prefab/" + e, (t => {
            let i = director.getScene().getChildByName("Canvas"), a = i.getChildByName(e);
            if (ToolUtils.isObjValid(a)) {
                return;
            }
            let s = instantiate(t);
            s.name = e;
            i.addChild(s);
        }));
    }
    onBackView(e = true) {
        e && (Utils.shared().hideLoading(), this.bShowPushAnim ? (this._closed = true, ToolUtils.showPushAnim(this.node, 1, (() => {
            ToolUtils.isObjValid(this.node) && this.node.destroy();
        }))) : ToolUtils.isObjValid(this.node) && this.node.destroy());
    }
    fitScreen() {
        ToolUtils.adaptSafeArea(this.rootNode);
        let e = sys.getSafeAreaRect().y;
        if (0 != e) {
            let t = this.rootNode.getChildByName("submit_btn").getComponent(Widget).bottom;
            this.rootNode.getChildByName("submit_btn").getComponent(Widget).bottom = t - e;
        }
    }
}
