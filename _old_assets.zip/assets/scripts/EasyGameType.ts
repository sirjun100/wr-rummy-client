// @ts-nocheck
// Recovered from index.js:107
import { _decorator, Label, sys, v3, Vec3 } from "cc";
import i18nMgr from "./i18nMgr";
import User from "./User";
import SoundManager from "./SoundManager";
import BaseLayer from "./BaseLayer";
import PushCenter from "./PushCenter";
import GameConfig from "./GameConfig";
import { ToolUtils } from "./ToolUtils";
const { ccclass } = _decorator;
@ccclass("EasyGameType")
export class EasyGameType extends BaseLayer {
    public rootNode: any = null;
    public _callback: any = null;
    public _infoStr: string = "";
    public _min_entry: number = 0;
    public cur_money: number = 0;
    public _isHelp: boolean = false;
    start() {
        super.start();
        ToolUtils.showFullScreen(this.node.getChildByName("mask"));
        for (let t = 1; t <= 3; t++) {
            this.node.getChildByName("node" + t).active = false;
        }
        if (this._isHelp ? this.rootNode = this.node.getChildByName("node3") : ToolUtils.getOrientation() ? this.rootNode = this.node.getChildByName("node2") : this.rootNode = this.node.getChildByName("node1"), ToolUtils.getOrientation()) {
            if (2 == i18nMgr.shared().language) {
                this.rootNode.getChildByName("desc1").getComponent(Label).lineHeight = 22;
                let t = new Vec3;
                if (this.rootNode.getChildByName("desc1").getPosition(t), this.rootNode.getChildByName("desc1").setPosition(v3(t.x, t.y + 10)), this.rootNode.getChildByName("item2").getComponent(Label).fontSize = 18, ToolUtils.isObjValid(this.rootNode.getChildByName("btn_start"))) {
                    let t = this.rootNode.getChildByName("btn_start").getChildByName("wz");
                    ToolUtils.isObjValid(t) && (t.getComponent(Label).fontSize = 24, t.getComponent(Label).lineHeight = 34);
                }
            }
        }
        else if (2 == i18nMgr.shared().language) {
            this.rootNode.getChildByName("desc1").getComponent(Label).lineHeight = 26;
            let t = new Vec3;
            if (this.rootNode.getChildByName("desc1").getPosition(t), this.rootNode.getChildByName("desc1").setPosition(v3(t.x, t.y - 10)), this.rootNode.getChildByName("item1").getPosition(t), this.rootNode.getChildByName("item1").getComponent(Label).fontSize = 24, this.rootNode.getChildByName("item1").setPosition(v3(t.x, t.y + 10)), this.rootNode.getChildByName("item2").getComponent(Label).fontSize = 24, this.rootNode.getChildByName("item3").getComponent(Label).fontSize = 24, ToolUtils.isObjValid(this.rootNode.getChildByName("btn_start"))) {
                let t = this.rootNode.getChildByName("btn_start").getChildByName("wz");
                ToolUtils.isObjValid(t) && (t.getComponent(Label).fontSize = 24, t.getComponent(Label).lineHeight = 34);
            }
        }
        else {
            3 == i18nMgr.shared().language && (this.rootNode.getChildByName("item2").getComponent(Label).fontSize = 32);
        }
        this.rootNode.active = true;
        ToolUtils.startShowAnim(this.rootNode);
        this.rootNode.getChildByName("info") && (this.rootNode.getChildByName("info").getComponent(Label).string = this._infoStr, this.updateStartBtnState(), this.cur_money = User.shared().data.money, PushCenter.shared().addListener(GameConfig.Update_Money, (t => {
            ToolUtils.isObjValid(this.node) && this.cur_money != User.shared().data.money && (this.cur_money = User.shared().data.money, this.updateStartBtnState());
        }), this));
    }
    updateStartBtnState() {
        let t = this.rootNode.getChildByName("btn_start"), e = this.rootNode.getChildByName("btn_addcash"), i = false;
        User.shared().data.money >= this._min_entry && (i = true);
        t.active = i;
        e.active = !i;
    }
    initParaData(t, e) {
        this._callback = e;
        sys.isObjectValid(t) && (sys.isObjectValid(t.info) && (this._infoStr = t.info), sys.isObjectValid(t.min_entry) && (this._min_entry = t.min_entry), sys.isObjectValid(t.isHelp) && (this._isHelp = t.isHelp));
    }
    onButtonClick(t, e) {
        "close" == e ? (SoundManager.shared().playFx("click"), this.onBackView()) : "start" == e ? (this._callback && this._callback(e), this.onBackView()) : "addcash" == e ? this._callback && this._callback(e) : "close_di" == e && this._isHelp && (SoundManager.shared().playFx("click"), this.onBackView());
    }
    onBackView() {
        ToolUtils.isObjValid(this.node) && this.node.destroy();
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().removeListenersByTag(this);
    }
}
