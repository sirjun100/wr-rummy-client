// @ts-nocheck
// Recovered from index.js:23
import { _decorator, instantiate, Label, Node, Sprite, SpriteFrame, sys, v3, Vec3 } from "cc";
import BaseLayer from "./BaseLayer";
import { TransferPlatform } from "./TransferPlatform";
import User from "./User";
import SoundManager from "./SoundManager";
import PushCenter from "./PushCenter";
import PushEvent from "./PushEvent";
import Utils from "./Utils";
import i18nMgr from "./i18nMgr";
import TweenTool from "./TweenTool";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("BackTaskGuide")
export class BackTaskGuide extends BaseLayer {
    @property(Node)
    public rootnode: Node = null;
    @property(Node)
    public bg: Node = null;
    @property(Node)
    public title: Node = null;
    @property(Node)
    public closeBtn: Node = null;
    @property(Node)
    public lightImg: Node = null;
    @property(Node)
    public leftTimeNode: Node = null;
    @property(Label)
    public leftTimeLabel: Label = null;
    @property(Node)
    public okBtn: Node = null;
    @property(Node)
    public gameMask: Node = null;
    @property(Node)
    public noPlayNode: Node = null;
    @property(Node)
    public spinNode: Node = null;
    @property(Node)
    public collectNode: Node = null;
    @property(Node)
    public Moban: Node = null;
    @property([Node])
    public giftNodes: Node[] = [];
    @property([SpriteFrame])
    public bgSprites: SpriteFrame[] = [];
    @property([SpriteFrame])
    public light_Sprite: SpriteFrame[] = [];
    @property([SpriteFrame])
    public reward_Sprite: SpriteFrame[] = [];
    public isNext: boolean = false;
    public param: any = null;
    public isBackKey: boolean = true;
    public _initDelay: number = 0;
    public _bStartCountDown: boolean = false;
    public _nCountcd: any = -1;
    public _animPosX: any[] = [-350, -224, -98, 28, 154, 280, 406];
    public _animNode: any[] = [];
    initParaData(t, e = null) {
        this.isNext = t;
        this.param = e;
    }
    onLoad() {
        TransferPlatform.shared().setHighFrameRate();
        this._initDelay = 0;
        User.shared().requestNewDailyTaskData(true);
        ToolUtils.showFullScreen(this.node.getChildByName("mask_bg"));
        this.dealMultipleLanguages();
    }
    dealMultipleLanguages() {
        2 == i18nMgr.shared().language && (this.leftTimeLabel.fontSize = 18);
    }
    onDestroy() {
        super.onDestroy();
        TransferPlatform.shared().setNormalFrameRate();
        PushCenter.shared().pushEvent(PushEvent.HallGet);
        PushCenter.shared().removeListenersByTag(this);
        ToolUtils.isObjValid(this.node) && this.isBackKey && this.isNext && PushCenter.shared().pushEvent(PushEvent.Update_NextPopActivity);
    }
    start() {
        super.start();
        Utils.shared().StartNodeShowAnim(this.rootnode);
        this.param && (sys.isObjectValid(this.param.is_reward) && 1 == Number(this.param.is_reward) ? (this.bg.getComponent(Sprite).spriteFrame = this.bgSprites[1], this.collectNode.active = true, this.noPlayNode.active = false, this.spinNode.active = false, this.gameMask.active = false, this.title.setPosition(v3(0, 268, 0)), this.lightImg.setPosition(v3(0, 286, 0)), this.leftTimeNode.setPosition(v3(15, 336, 0)), this.okBtn.setPosition(v3(0, -154, 0)), i18nMgr.shared().changeLabelLanguage(this.okBtn.getChildByName("wz").getComponent(Label), "daily_tasks.collect", true)) : sys.isObjectValid(this.param.spin) && 1 == Number(this.param.spin) ? (this.bg.getComponent(Sprite).spriteFrame = this.bgSprites[0], this.spinNode.active = true, this.gameMask.active = true, this.collectNode.active = false, this.noPlayNode.active = false, this.title.setPosition(v3(0, 284, 0)), this.lightImg.setPosition(v3(0, 301, 0)), this.leftTimeNode.setPosition(v3(15, 351, 0)), this.okBtn.setPosition(v3(0, -170, 0)), sys.isObjectValid(this.param.amount) && (this.spinNode.getChildByName("cash").getComponent(Label).string = ToolUtils.format("₹${0}*", this.param.amount)), i18nMgr.shared().changeLabelLanguage(this.okBtn.getChildByName("wz").getComponent(Label), "daily_tasks.spin_now", true)) : (this.bg.getComponent(Sprite).spriteFrame = this.bgSprites[0], this.gameMask.active = true, this.noPlayNode.active = true, this.spinNode.active = false, this.collectNode.active = false, this.title.setPosition(v3(0, 284, 0)), this.lightImg.setPosition(v3(0, 301, 0)), this.leftTimeNode.setPosition(v3(15, 351, 0)), this.okBtn.setPosition(v3(0, -170, 0)), sys.isObjectValid(this.param.amount) && (this.noPlayNode.getChildByName("cash").getComponent(Label).string = ToolUtils.format("₹${0}*", this.param.amount)), i18nMgr.shared().changeLabelLanguage(this.okBtn.getChildByName("wz").getComponent(Label), "daily_tasks.check", true)));
        TweenTool.commonSchedule(this.node, 1, this.scheduleCallBack.bind(this));
        this.lightImg.active && (this._initDelay += 0.05, TweenTool.delayAct(this.node, (() => {
            TweenTool.stopNodeAction(this.lightImg);
            let t = TweenTool.delayAct(this.lightImg, (() => {
                this.lightImg.getComponent(Sprite).spriteFrame = this.light_Sprite[0];
            }), 0.5), e = TweenTool.delayAct(this.lightImg, (() => {
                this.lightImg.getComponent(Sprite).spriteFrame = this.light_Sprite[1];
            }), 0.5), i = TweenTool.sequence(this.lightImg, false, null, t, e);
            i.repeatForever();
            i.start();
        }), this._initDelay, true), this._initDelay += 0.05, TweenTool.delayAct(this.node, (() => {
            this.startGameRun();
        }), this._initDelay, true));
        this.spinNode.active && (this._initDelay += 0.05, TweenTool.delayAct(this.node, (() => {
            let t = this.spinNode.getChildByName("prizeBg");
            TweenTool.stopNodeAction(t);
            let e = TweenTool.rotateBy(t, 1.5, new Vec3(0, 0, -90), null, false), i = TweenTool.rotateBy(t, 1.5, new Vec3(0, 0, -90), null, false), s = TweenTool.rotateBy(t, 1.5, new Vec3(0, 0, -90), null, false), a = TweenTool.rotateBy(t, 1.5, new Vec3(0, 0, -90), null, false), n = TweenTool.sequence(t, false, null, e, i, s, a);
            n.repeatForever();
            n.start();
        }), this._initDelay, true));
        this.collectNode.active && (this._initDelay += 0.05, TweenTool.delayAct(this.node, (() => {
            this.showReward();
        }), this._initDelay, true));
        this._initDelay += 0.05;
        TweenTool.delayAct(this.node, (() => {
            PushCenter.shared().addListener(PushEvent.UpdateNewDailyTask, (t => {
                sys.isObjectValid(this.node) && this.startLeftTimeCountDown(User.shared().newDailydata.leftTime);
            }), this);
            null !== User.shared().newDailydata && this.startLeftTimeCountDown(User.shared().newDailydata.leftTime);
        }), this._initDelay, true);
    }
    startGameRun() {
        for (let t = 0, e = this.giftNodes.length; t < e; t++) {
            TweenTool.stopNodeAction(this.giftNodes[t]);
        }
        this._animNode = [];
        for (let t = 0; t < 6; t++) {
            this.giftNodes[t].setPosition(v3(this._animPosX[t + 1], 0));
            this._animNode.push(this.giftNodes[t]);
        }
        this.beganMove();
    }
    beganMove() {
        for (let t = 0; t < 6; t++) {
            TweenTool.moveTo(this._animNode[t], 1.5, v3(this._animPosX[t], 0), null, true, (() => {
                if (0 == t) {
                    let t = this._animNode[0];
                    t.setPosition(v3(this._animPosX[6], 0));
                    this._animNode.splice(0, 1);
                    this._animNode.push(t);
                }
                5 == t && this.beganMove();
            }));
        }
    }
    showReward() {
        if (sys.isObjectValid(this.param.reward)) {
            let t = this.param.reward.length;
            for (let e = 0; e < t; e++) {
                if (this.reward_Sprite[this.param.reward[e].type]) {
                    let i = this.addRewardItem(this.param.reward[e]);
                    i.setPosition(v3(160 * (e - (t - 1) / 2), this.Moban.getPosition().y));
                    this.collectNode.addChild(i);
                    i.active = true;
                }
            }
        }
    }
    addRewardItem(t) {
        let e = instantiate(this.Moban);
        e.active = true;
        let i = e.getChildByName("num").getComponent(Label), s = Number(t.type);
        i.string = ToolUtils.parse_double(t.amt);
        let a = e.getChildByName("name").getComponent(Label);
        a.string = Utils.shared().getIconNameByType(s);
        2 == i18nMgr.shared().language && (a.fontSize = 22);
        let o = e.getChildByName("icon").getComponent(Sprite);
        return s >= 0 && (o.spriteFrame = this.reward_Sprite[s]), e;
    }
    scheduleCallBack() {
        if (this._bStartCountDown) {
            if (this._nCountcd -= 1, User.shared().newDailydata.leftTime = this._nCountcd, this._nCountcd < 0) {
                return User.shared().newDailydata.leftTime = -1, User.shared().getHallInfo(), void this.onBackView();
            }
            this.leftTimeLabel.string = Utils.shared().parseCountDown(this._nCountcd);
        }
    }
    startLeftTimeCountDown(t) {
        if (Number.isNaN(t) || t <= 0) {
            return User.shared().getHallInfo(), void (this.leftTimeLabel.string = "");
        }
        this.leftTimeNode.active = true;
        this._bStartCountDown = true;
        this._nCountcd = t;
        this.leftTimeLabel.string = Utils.shared().parseCountDown(this._nCountcd);
    }
    onCloseClick(t, e) {
        SoundManager.shared().playFx("click");
        this.onBackView();
    }
    onBtnClick(t, e) {
        SoundManager.shared().playFx("click");
        "ok" == e && (PushCenter.shared().pushEvent(PushEvent.ShowHallDailyTask, { exe: this.param, isNext: this.isNext }), ToolUtils.isObjValid(this.node) && this.node.destroy());
    }
    onBackView() {
        ToolUtils.isObjValid(this.node) && (this.isBackKey && this.isNext && PushCenter.shared().pushEvent(PushEvent.Update_NextPopActivity), this.node.destroy());
    }
}
