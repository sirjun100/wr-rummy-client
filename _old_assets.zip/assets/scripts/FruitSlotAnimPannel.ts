// @ts-nocheck
// Recovered from index.js:131
import { _decorator, Label, Node, sp, v3 } from "cc";
import Parent from "./Parent";
import PushCenter from "./PushCenter";
import { FruitSlotGameManager } from "./FruitSlotGameManager";
import TweenTool from "./TweenTool";
import User from "./User";
import SoundManager from "./SoundManager";
import { ToolUtils } from "./ToolUtils";
import PushEvent from "./PushEvent";
const { ccclass, property } = _decorator;
@ccclass("FruitSlotAnimPannel")
export default class FruitSlotAnimPannel extends Parent {
    public _TAG: string = "FruitSlotAnimPannel";
    @property(Node)
    public jiesuan_anim: Node = null;
    @property(Node)
    public mask: Node = null;
    @property(Node)
    public textWinNode: Node = null;
    @property(Node)
    public winFontNode: Node = null;
    @property(Node)
    public xyc_xiaojiesuan: Node = null;
    @property(Node)
    public xyc_dajiesuan: Node = null;
    @property([sp.SkeletonData])
    public skeletonData: sp.SkeletonData[] = [];
    onLoad() {
    }
    start() {
        this.initView();
    }
    initView() {
        this.winFontNode.active = false;
        this.xyc_xiaojiesuan.active = false;
        this.xyc_dajiesuan.active = false;
        this.mask.active = false;
        this.resetUi();
        this.addPushNotify();
    }
    resetUi() {
        FruitSlotGameManager.shared()._isBet = true;
        this.textWinNode.active = false;
    }
    showGameEnd() {
        let e = FruitSlotGameManager.shared()._winscore;
        if (FruitSlotGameManager.shared()._jackpot_win <= 0 && e <= 0 && FruitSlotGameManager.shared()._free_game_num != FruitSlotGameManager.shared()._freegamecount && !FruitSlotGameManager.shared()._is_xyc_complete) {
            return this.resetUi(), FruitSlotGameManager.shared().isAnimPlaying = false, User.shared().updateRoomCoin(FruitSlotGameManager.shared()._coin), void PushCenter.shared().pushEvent(PushEvent.Update_FlopGame, 0);
        }
        TweenTool.delayAct(this.node, (() => {
            this.resetUi();
        }), 0, true);
        FruitSlotGameManager.shared()._jackpot_type > 0 ? this.jackpot_jiesuan() : this.show_jiesuan_anim();
    }
    show_jiesuan_anim() {
        2 == FruitSlotGameManager.shared()._winshow_anim ? (this.jiesuan1(3), TweenTool.delayAct(this.node, (() => {
            FruitSlotGameManager.shared().isAnimPlaying = false;
            User.shared().updateRoomCoin(FruitSlotGameManager.shared()._coin);
        }), 1, true)) : 3 == FruitSlotGameManager.shared()._winshow_anim ? (this.jiesuan1(2), TweenTool.delayAct(this.node, (() => {
            FruitSlotGameManager.shared().isAnimPlaying = false;
            User.shared().updateRoomCoin(FruitSlotGameManager.shared()._coin);
        }), 1, true)) : 4 == FruitSlotGameManager.shared()._winshow_anim ? (this.jiesuan1(1), TweenTool.delayAct(this.node, (() => {
            FruitSlotGameManager.shared().isAnimPlaying = false;
            User.shared().updateRoomCoin(FruitSlotGameManager.shared()._coin);
        }), 1, true)) : 1 == FruitSlotGameManager.shared()._winshow_anim ? (SoundManager.shared().playFx("zhongxiaojiang"), FruitSlotGameManager.shared()._free_game_num == FruitSlotGameManager.shared()._freegamecount ? (this.xinyuncao_xiaojiesuan(), TweenTool.delayAct(this.node, (() => {
            FruitSlotGameManager.shared().isAnimPlaying = false;
            User.shared().updateRoomCoin(FruitSlotGameManager.shared()._coin);
        }), 1, true)) : FruitSlotGameManager.shared()._is_xyc_complete ? (this.xinyuncao_dajiesuan(), TweenTool.delayAct(this.node, (() => {
            FruitSlotGameManager.shared().isAnimPlaying = false;
            User.shared().updateRoomCoin(FruitSlotGameManager.shared()._coin);
        }), 1, true)) : TweenTool.delayAct(this.node, (() => {
            FruitSlotGameManager.shared().isAnimPlaying = false;
            User.shared().updateRoomCoin(FruitSlotGameManager.shared()._coin);
            PushCenter.shared().pushEvent(PushEvent.Update_FlopGame, 0);
        }), 0.2, true)) : FruitSlotGameManager.shared()._free_game_num == FruitSlotGameManager.shared()._freegamecount ? (this.xinyuncao_xiaojiesuan(), TweenTool.delayAct(this.node, (() => {
            FruitSlotGameManager.shared().isAnimPlaying = false;
            User.shared().updateRoomCoin(FruitSlotGameManager.shared()._coin);
        }), 1, true)) : FruitSlotGameManager.shared()._is_xyc_complete ? (this.xinyuncao_dajiesuan(), TweenTool.delayAct(this.node, (() => {
            FruitSlotGameManager.shared().isAnimPlaying = false;
            User.shared().updateRoomCoin(FruitSlotGameManager.shared()._coin);
        }), 1, true)) : TweenTool.delayAct(this.node, (() => {
            FruitSlotGameManager.shared().isAnimPlaying = false;
            User.shared().updateRoomCoin(FruitSlotGameManager.shared()._coin);
        }), 0.2, true);
    }
    startLightAni() {
    }
    createLightAni(e, i) {
    }
    startRockerAni() {
    }
    scrollNumAnim(e) {
    }
    jiesuan1(e) {
        let i = this.jiesuan_anim.getChildByName("anim").getComponent(sp.Skeleton);
        2 == e ? this.skeletonData[1] && (i.skeletonData = this.skeletonData[1], i.clearTracks(), i.setToSetupPose(), SoundManager.shared().playFx("mega_win"), i.setAnimation(0, "js2", false)) : 3 == e ? this.skeletonData[2] && (i.skeletonData = this.skeletonData[2], i.clearTracks(), i.setToSetupPose(), SoundManager.shared().playFx("big_win"), i.setAnimation(0, "bigwin", false)) : this.skeletonData[0] && (i.skeletonData = this.skeletonData[0], i.clearTracks(), i.setToSetupPose(), SoundManager.shared().playFx("huge_win"), i.setAnimation(0, "js1", false));
        this.mask.active = true;
        this.winFontNode.active = false;
        PushCenter.shared().pushEvent("slot_good_ani_finish", 3);
        this.xinyuncao_lizixiaoguo();
        i.setCompleteListener(null);
        i.node.active = true;
        TweenTool.delayAct(this.node, (() => {
            ToolUtils.isObjValid(this.node) && (this.winFontNode.active = false, this.mask.active = false, i.node.active = false, FruitSlotGameManager.shared()._free_game_num == FruitSlotGameManager.shared()._freegamecount ? this.xinyuncao_xiaojiesuan() : FruitSlotGameManager.shared()._is_xyc_complete ? this.xinyuncao_dajiesuan() : PushCenter.shared().pushEvent(PushEvent.Update_FlopGame, 0));
        }), 4, true);
        this.winFontNode.active = false;
        this.winFontNode.setPosition(v3(0, -145));
        TweenTool.delayAct(this.node, (() => {
            this.number_beat_Anim(this.winFontNode);
        }), 0.2, true);
    }
    xinyuncao_xiaojiesuan() {
        this.mask.active = true;
        this.jiesuan_anim.getChildByName("anim").active = false;
        this.winFontNode.active = false;
        let e = this.jiesuan_anim.getChildByName("anim").getComponent(sp.Skeleton);
        this.skeletonData[3] && SoundManager.shared().playFx("huge_win");
        PushCenter.shared().pushEvent("is_xyc_state_period", 2);
        PushCenter.shared().pushEvent("game_fruit_button_close_state", 2);
        this.jiesuan_anim.getChildByName("xyc").active = true;
        TweenTool.fadeInOrOut(this.jiesuan_anim.getChildByName("xyc"), 0.3, 0, 1, true);
        TweenTool.delayAct(this.node, (() => {
            ToolUtils.isObjValid(e.node) && (this.winFontNode.active = false, TweenTool.fadeInOrOut(this.xyc_xiaojiesuan, 0.3, 1, 0, true), TweenTool.fadeInOrOut(this.jiesuan_anim.getChildByName("xyc"), 0.3, 1, 0, true), TweenTool.delayAct(this.node, (() => {
                this.mask.active = false;
                this.xyc_xiaojiesuan.active = false;
                this.remove_jiesuan_anim();
                PushCenter.shared().pushEvent("show_xyc_free_spins");
                PushCenter.shared().pushEvent(PushEvent.Update_FlopGame, 0);
            }), 0.5, true));
        }), 2, true);
        this.xyc_xiaojiesuan.active = true;
        this.xyc_xiaojiesuan.getChildByName("text_font").getComponent(Label).string = String(FruitSlotGameManager.shared()._freegamecount);
        TweenTool.fadeInOrOut(this.xyc_xiaojiesuan, 0.3, 0, 1, true);
    }
    xinyuncao_dajiesuan() {
        this.mask.active = true;
        this.jiesuan_anim.getChildByName("anim").active = false;
        this.winFontNode.active = false;
        FruitSlotGameManager.shared()._is_xyc_complete = true;
        let e = this.jiesuan_anim.getChildByName("anim").getComponent(sp.Skeleton);
        this.skeletonData[5] && (e.node.active = true, e.skeletonData = this.skeletonData[5], e.clearTracks(), e.setToSetupPose(), SoundManager.shared().playFx("xingyuncaodajiesuan"), e.setAnimation(0, "xyc_js", false), e.setCompleteListener(null), TweenTool.delayAct(this.node, (() => {
            ToolUtils.isObjValid(this.node) && (PushCenter.shared().pushEvent("is_xyc_state_period", 1), PushCenter.shared().pushEvent("game_fruit_button_close_state", 1), this.remove_jiesuan_anim(), PushCenter.shared().pushEvent(PushEvent.Update_FlopGame, 0));
        }), 4, true));
        this.xyc_dajiesuan.active = true;
        let i = "IN " + FruitSlotGameManager.shared()._freegamecount + " FREE SPINS";
        this.xyc_dajiesuan.getComponent(Label).string = i;
        this.winFontNode.active = false;
        this.winFontNode.setPosition(v3(0, -19.218));
        TweenTool.delayAct(this.node, (() => {
            this.number_beat_Anim(this.winFontNode, FruitSlotGameManager.shared()._cur_freegame_win_socre);
        }), 0.2, true);
    }
    jackpot_jiesuan() {
        this.mask.active = true;
        this.jiesuan_anim.getChildByName("anim").active = false;
        this.winFontNode.active = false;
        SoundManager.shared().playFx("jackpot_mixdown");
        let e = this.jiesuan_anim.getChildByName("anim").getComponent(sp.Skeleton);
        this.skeletonData[6] && (e.node.active = true, e.skeletonData = this.skeletonData[6], e.clearTracks(), e.setToSetupPose(), SoundManager.shared().playFx("xingyuncaodajiesuan"), e.setAnimation(0, "animation", false), e.setCompleteListener((() => {
            if (ToolUtils.isObjValid(this.node)) {
                this.mask.active = false;
                e.node.active = false;
                this.winFontNode.active = false;
                FruitSlotGameManager.shared()._winscore <= 0 && FruitSlotGameManager.shared()._free_game_num != FruitSlotGameManager.shared()._freegamecount && !FruitSlotGameManager.shared()._is_xyc_complete && (this.resetUi(), FruitSlotGameManager.shared().isAnimPlaying = false, User.shared().updateRoomCoin(FruitSlotGameManager.shared()._coin));
                this.show_jiesuan_anim();
            }
        })));
        this.winFontNode.active = false;
        this.winFontNode.setPosition(v3(0, -103));
        TweenTool.delayAct(this.node, (() => {
            this.number_beat_Anim(this.winFontNode, FruitSlotGameManager.shared()._jackpot_win);
        }), 0.2, true);
        TweenTool.delayAct(this.winFontNode, (() => {
            this.winFontNode.active = false;
        }), 3.2, true);
    }
    addPushNotify() {
        PushCenter.shared().addListener("slot_good_ani_finish", (e => {
            ToolUtils.isObjValid(this.node) && 3 != e && this.showGameEnd();
        }), this);
    }
    remove_jiesuan_anim() {
        this.mask.active = false;
        this.jiesuan_anim.getChildByName("anim").active = false;
        this.jiesuan_anim.getChildByName("xyc").active = false;
        this.winFontNode.active = false;
        this.xyc_xiaojiesuan.active = false;
        this.xyc_dajiesuan.active = false;
    }
    number_beat_Anim(e, i) {
        let t = i ?? FruitSlotGameManager.shared()._winscore, a = 0;
        if (t < 52) {
            return e.active = true, void (e.getComponent(Label).string = ToolUtils.parse_double(t));
        }
        a = t > 51 && t < 100 ? 50 : 80;
        a += 1;
        let n = Math.floor(t / a), s = 0;
        for (let i = 0; i < a; i++) {
            s += 0.03;
            TweenTool.delayAct(this.node, (() => {
                if (ToolUtils.isObjValid(e)) {
                    if (i == a - 1) {
                        e.getComponent(Label).string = ToolUtils.parse_double(t);
                    }
                    else {
                        let t = i * n, a = (i + 1) * n, s = ToolUtils.getRandomInt(t, a);
                        e.active = true;
                        e.getComponent(Label).string = ToolUtils.parse_double(s + "");
                        SoundManager.shared().playFx("jinbitiaodong");
                    }
                }
            }), s, true);
        }
    }
    xinyuncao_lizixiaoguo() {
        this.mask.active = true;
        this.jiesuan_anim.getChildByName("anim").active = false;
        this.winFontNode.active = false;
    }
    onDestroy() {
        super.onDestroy();
        this.unscheduleAllCallbacks();
        PushCenter.shared().removeListenersByTag(this);
    }
}
