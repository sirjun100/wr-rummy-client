// @ts-nocheck
// Recovered from index.js:135
import { _decorator, assetManager, AudioSource, director, macro, Node, sp, Sprite, SpriteFrame, sys, v3, Widget } from "cc";
import Parent from "./Parent";
import i18nMgr from "./i18nMgr";
import PushCenter from "./PushCenter";
import { TLog } from "./TLog";
import { ToolUtils } from "./ToolUtils";
import { TransferPlatform } from "./TransferPlatform";
import TweenTool from "./TweenTool";
import Utils from "./Utils";
import BundleNameDefined from "./BundleNameDefined";
import { CommonGameType, HallGameType } from "./CommDefine";
import GameConfig from "./GameConfig";
import { HttpRequest } from "./HttpRequestName";
import NetConfig from "./NetConfig";
import PhpReportDefined from "./PhpReportDefined";
import PushEvent from "./PushEvent";
import RummyCmd from "./RummyCmd";
import User from "./User";
import HttpManager from "./HttpManager";
import LabaServer from "./LabaServer";
import Server from "./Server";
import SoundManager from "./SoundManager";
import gameNetworkDelay from "./gameNetworkDelay";
import FruitSlotAnimPannel from "./FruitSlotAnimPannel";
import FruitSlotBtnPannel from "./FruitSlotBtnPannel";
import FruitSlotGameCmd from "./FruitSlotGameCmd";
import { FruitSlotGameManager } from "./FruitSlotGameManager";
import FruitSlotGoodsPannel from "./FruitSlotGoodsPannel";
const { ccclass, property } = _decorator;
@ccclass("FruitSlotGame")
export class FruitSlotGame extends Parent {
    public _TAG: string = "FruitSlotGame";
    public isNetworkDelay: boolean = true;
    public _gameData: any = {};
    public _enterStartTime: number = 0;
    public backgroundSatyTime: number = 0;
    @property(Node)
    public rootNode: Node = null;
    @property(Sprite)
    public center_bg: Sprite = null;
    @property([SpriteFrame])
    public center_bg_frames: SpriteFrame[] = [];
    @property(Node)
    public center_bg_anim: Node = null;
    public aniView: any = undefined;
    public goodsView: any = undefined;
    public btnView: any = undefined;
    @property([AudioSource])
    public musicAudioSources: AudioSource[] = [];
    public networkDelay: number = 0;
    public tid_key: string = "";
    public roomFreeChipsPrefab: any = null;
    public hasReqRandom: boolean = false;
    public waitPlayGullakAnim: boolean = false;
    public showFlopGamePara: any = null;
    public showFlopGame: boolean = false;
    onDestroy() {
        gameNetworkDelay.shared().removechild();
        Server.shared().onBackGroundLink();
        PushCenter.shared().removeListenersByTag(this);
        this.unscheduleAllCallbacks();
    }
    onLoad() {
        User.shared().fromGame = 1;
        ToolUtils.switchSceneTye = -1;
        ToolUtils.bSwitchToGame = false;
        window.InHallScene = false;
        window.InGameScene = true;
        window.InSwitchScene = false;
        window.IsBackToHallLoad = false;
        macro.ENABLE_MULTI_TOUCH = false;
        FruitSlotGameManager.shared()._tidKey = User.shared().curTid_key;
        this.tid_key = User.shared().curTid_key;
        FruitSlotGameManager.shared()._vid = ToolUtils.curRoomId;
        SoundManager.shared().playTargetMusic(this.musicAudioSources[0]);
        this.node.getChildByName("bg").getComponent(Widget).enabled = true;
    }
    start() {
        FruitSlotGameManager.shared().data.room_ad_act = -1;
        ToolUtils.report_time_param.gameStart = sys.now();
        gameNetworkDelay.shared().loadNode();
        this._enterStartTime = sys.now();
        this.resetGameData();
        let e = new Node;
        this.node.addChild(e);
        FruitSlotGameManager.shared().sceneNode = e;
        this.initView();
        this._gameData.connectCount = 0;
        this.initPushCenter();
        this.regEvent();
        1 == ToolUtils.heart_open && (this.unschedule(this.netWorkDelayUpdate), this.schedule(this.netWorkDelayUpdate, 2));
        TweenTool.delayAct(this.node, (() => {
            this.loadFruitMachSounds();
        }), 0.5, true);
        let t = {};
        t.htype = HallGameType.LOBBY_GAME_TYPE_SHUIGUOJI;
        t.vid = ToolUtils.curRoomId;
        ToolUtils.saveData(User.shared().data.uid + "saveCommRecommendRoom", ToolUtils.toJsonString(t));
    }
    netWorkDelayUpdate() {
        if (this.networkDelay = this.networkDelay + 1, !User.shared().isGameDisconnectServer) {
            if (this.isNetworkDelay) {
                let e = { cmd: NetConfig.HEARTBEAT_CMD };
                Server.shared().send(e);
                ToolUtils.lastSendHeartBeatTime = ToolUtils.getOsTime();
                this.isNetworkDelay = false;
                this.networkDelay = 0;
            }
            if (this.networkDelay > 10) {
                let e = { cmd: NetConfig.HEARTBEAT_CMD };
                Server.shared().send(e);
                ToolUtils.lastSendHeartBeatTime = ToolUtils.getOsTime();
                this.isNetworkDelay = false;
                this.networkDelay = 0;
            }
        }
    }
    initView() {
        FruitSlotGameManager.shared()._game_state_type = 1;
        SoundManager.shared().playTargetMusic(this.musicAudioSources[0]);
        FruitSlotGameManager.shared().popNode = this.rootNode.getChildByName("pop_layer");
        this.aniView = this.rootNode.getChildByName("panel_ani").getComponent(FruitSlotAnimPannel);
        let e = this.center_bg_anim.getComponent(sp.Skeleton);
        e.clearTracks();
        e.setToSetupPose();
        e.setAnimation(0, "frame", true);
        this.center_bg_anim.active = false;
        this.center_bg_anim.setPosition(v3(0, 18.641));
        this.goodsView = this.rootNode.getChildByName("panel_goods").getComponent(FruitSlotGoodsPannel);
        this.btnView = this.rootNode.getChildByName("panel_btn").getComponent(FruitSlotBtnPannel);
        this._gameData.jackPotNum = 0;
        Server.shared().pop_response();
        FruitSlotGameManager.shared().sendGameInfoRequest();
        User.shared().exitRoomGameVid = ToolUtils.curRoomId;
        this.btnView.updateGullakBtnStatus(User.shared().act_68_open, User.shared().act_68_full_status, false);
    }
    resetGameData() {
        this._gameData.game_state = 0;
        this._gameData.game_cd = 0;
        this._gameData.bet_configVec = [];
        this._gameData.cur_bet = 0;
        this._gameData.sit_down_money = 0;
        this._gameData.allBetMap = new Map;
        this._gameData.showCardModelVec = [];
        this._gameData.toSeatVec = [];
        this._gameData.lastReceiHeartAllKillPacketTime = 0;
        this._gameData.isSelfShangZhuang = false;
        this._gameData.curSelectBetIndex = -1;
        this._gameData.hander_state = 0;
        this._gameData.isGameStartING = false;
        this._gameData.isGameEnded = true;
        this._gameData.tcpConnTryTime = 0;
        this._gameData.isShowNoWifiAlert = true;
        this._gameData.mCurDownMoney = 0;
        this._gameData.xiazhuBigOrSmall = 0;
        this._gameData.lastReceiveTime = 0;
        this._gameData.xiazhuVec = [];
        this._gameData.isInTuHao = false;
        this._gameData.isGameStartEd = false;
        this._gameData.betStatusVec = [];
        for (let e = 0; e <= 3; e++) {
            this._gameData.betStatusVec.push(e);
        }
        this._gameData.isNoWifi = false;
        this._gameData.lastReceiHeartAllKillPacketTime = 0;
        this._gameData.isGameStartING = false;
    }
    regEvent() {
        Server.shared().regDispatch(NetConfig.HEARTBEAT_CMD, this.handler_server_HEARTBEAT_DELAY_return.bind(this), this);
        Server.shared().regDispatch(NetConfig.SERVER_LOGIN_GATE_RESP, this.handler_server_login_gate_return.bind(this), this);
        Server.shared().regDispatch(NetConfig.SM_LOGIN_RETURN, this.handler_server_login_return.bind(this), this);
        Server.shared().regDispatch(NetConfig.SYSTEM_GATEWAY_CMD, this.handler_server_system_gateway_return.bind(this), this);
        Server.shared().regDispatch(FruitSlotGameCmd.SM_TABLE_INFO_BC_RETURN, this.handler_table_info.bind(this), this);
        Server.shared().regDispatch(FruitSlotGameCmd.SM_BET_RETURN, this.handler_bet.bind(this), this);
        Server.shared().regDispatch(FruitSlotGameCmd.SM_BET_CHANGE_RETURN, this.handler_linesChange.bind(this), this);
        Server.shared().regDispatch(FruitSlotGameCmd.SM_AUTO_BET_RETURN, this.handler_auto_bet.bind(this), this);
        Server.shared().regDispatch(FruitSlotGameCmd.SM_NOTIFY_NEW_MESSAGE, this.handler_game_red.bind(this), this);
        Server.shared().regDispatch(FruitSlotGameCmd.SM_SPEED_RETURN, this.handler_speed_return.bind(this), this);
        Server.shared().regDispatch(FruitSlotGameCmd.NOTIFY_JACKPOT_POOL_STATE, this.handler_jackpot_pool_state.bind(this), this);
        Server.shared().regDispatch(NetConfig.SERVER_ALERT_RETURN, this.handler_server_alert_return.bind(this), this);
        Server.shared().regDispatch(NetConfig.SM_CREATE_TABLE_RETURN, this.handler_server_create_tabel_return.bind(this), this);
        Server.shared().regDispatch(FruitSlotGameCmd.NOTIFY_JACKPOT_POOL, this.handler_server_jackpot_pool_amount_return.bind(this), this);
    }
    handler_server_jackpot_pool_amount_return(e) {
        this.tid_key == e.tid_key && sys.isObjectValid(e.jackpot_pool) && (0 == this._gameData.jackPotNum && (this._gameData.jackPotNum = e.jackpot_pool), this.btnView.updateJackPotPool(this._gameData.jackPotNum, e.jackpot_pool), this._gameData.jackPotNum = e.jackpot_pool);
    }
    handler_server_create_tabel_return(e) {
        sys.isObjectValid(e) && sys.isObjectValid(e.game_type) && e.game_type == CommonGameType.FruitMachine && 0 == parseInt("" + e.ret) && (sys.isObjectValid(e.session_id) && (User.shared().session_id = e.session_id), sys.isObjectValid(e.old_tid_key) && e.old_tid_key.length > 0 && this.tid_key == e.old_tid_key && sys.isObjectValid(e.tid_key) && e.tid_key.length > 0 && (this.tid_key = e.tid_key, FruitSlotGameManager.shared()._tidKey = e.tid_key, User.shared().curTid_key = e.tid_key, FruitSlotGameManager.shared().sendGameInfoRequest()));
    }
    handler_server_alert_return(e) {
        if (this.tid_key != e.tid_key) {
            return;
        }
        let t = 0;
        sys.isObjectValid(e.type) && (t = Number(e.type));
        let a = e.alertStr;
        if (2 == t) {
            this.updateBankruptcyParam(e);
            let t = { vid: FruitSlotGameManager.shared()._vid, min_entry: FruitSlotGameManager.shared()._raisBetlist[FruitSlotGameManager.shared()._betIndex], tid_key: this.tid_key, is_pop: 0, parent_node: FruitSlotGameManager.shared().popNode };
            Utils.shared().showQuickRecharge(ToolUtils.curVId, FruitSlotGameManager.shared().popNode, true, User.shared().curTid_key, 0, t.min_entry);
            User.shared().updatePayScene(PhpReportDefined.pay_scene.game_selectroom_less_money, FruitSlotGameManager.shared()._vid);
        }
        else {
            11 != t && 0 != t || sys.isObjectValid(a) && String(a).length > 0 && Utils.shared().showToast(a, 2);
        }
    }
    handler_server_system_gateway_return(e) {
        if (null != e.tid_key && null != e.tid_key && "" != e.tid_key) {
            if (this.tid_key === (e.tid_key || "") && -1 === e.res) {
                let e = i18nMgr.shared().getValueByKey("utlis.service_upgrade");
                Utils.shared().showToast(e, 2, 0, ToolUtils.getIsNormalDirection());
                this.backToHall();
            }
        }
        else {
            User.shared().curTid_key === this.tid_key && -1 === e.res && ToolUtils.isSafeString(e.msg).length > 0 && Utils.shared().showToast(e.msg, 2, 0, ToolUtils.getIsNormalDirection());
        }
    }
    handler_server_login_return(e) {
        try {
            sys.isObjectValid(e.session_id) && (User.shared().session_id = e.session_id);
            let t = ToolUtils.isSafeString(e.old_tid_key);
            if (this.tid_key != t) {
                return;
            }
            if (1 == parseInt("" + e.ret) && ToolUtils.isSafeString(e.alertStr).length > 0) {
                return this.backToHall(), Utils.shared().showToast(e.alertStr, 2, 0, ToolUtils.getIsNormalDirection()), void (ToolUtils.deskInfos.size <= 1 && Server.shared().disconnectWebSocket());
            }
            if (0 == parseInt("" + e.ret)) {
                if (sys.isObjectValid(e.session_id) && (User.shared().session_id = e.session_id), 1 == e.isNewTable) {
                    return void FruitSlotGameManager.shared().create_new_table();
                }
                0 == e.isNewTable && sys.isObjectValid(e.table_keys) && Array.isArray(e.table_keys) && e.table_keys.length > 0 ? (User.shared().curTid_key = e.table_keys[0].tid_key, this.tid_key = e.table_keys[0].tid_key, FruitSlotGameManager.shared()._tidKey = this.tid_key, FruitSlotGameManager.shared().sendGameInfoRequest()) : this.backToHall();
            }
            else {
                e.alertStr && "" != e.alertStr && Utils.shared().showCommomDialog(e.alertStr, "", (() => {
                }), false, ToolUtils.getIsNormalDirection(), null, null, null, null, null, this.tid_key);
            }
        }
        catch (e) {
        }
    }
    handler_jackpot_pool_state(e) {
        this.tid_key == e.tid_key && this.goodsView.updateJackPotState(e.state_major, e.state_minor, e.state_mini);
    }
    handler_speed_return(e) {
        this.tid_key == e.tid_key && (FruitSlotGameManager.shared()._isfast = e.type, this.btnView.fast_return());
    }
    handler_game_red(e) {
        this.tid_key == e.tid_key && (FruitSlotGameManager.shared()._hasRedPoint = 1);
    }
    handler_auto_bet(e) {
        this.tid_key == e.tid_key && (FruitSlotGameManager.shared()._isAuto = e.type, FruitSlotGameManager.shared()._autoNum = e.count, this.btnView.updateAutoBtnState(), sys.isObjectValid(e.pop_addgold) && 1 == e.pop_addgold || this.btnView.button_state(0));
    }
    handler_linesChange(e) {
        if (this.tid_key != e.tid_key) {
            return;
        }
        if (0 == e.ret) {
            for (let t = 0; t < FruitSlotGameManager.shared()._raisBetlist.length; t++) {
                if (FruitSlotGameManager.shared()._raisBetlist[t] == e.cur_bet) {
                    FruitSlotGameManager.shared()._betIndex = t;
                    break;
                }
            }
            this.btnView.updateTextBetAmount();
        }
        else {
            sys.isObjectValid(e.err_msg) && e.err_msg.length > 0 && Utils.shared().showToast(e.err_msg, 2);
        }
    }
    handler_bet(e) {
        if (this.tid_key != e.tid_key) {
            return;
        }
        FruitSlotGameManager.shared()._win_data = [];
        FruitSlotGameManager.shared()._winscore = 0;
        FruitSlotGameManager.shared()._is_xyc_complete = false;
        0 == e.ret ? (FruitSlotGameManager.shared().isAnimPlaying = true, this.aniView.remove_jiesuan_anim(), this.goodsView.initPanel(), this.goodsView.remove_action_clone(), User.shared().updateRoomCoin(e.start_money), FruitSlotGameManager.shared()._coin = e.money, User.shared().data.money = e.money, FruitSlotGameManager.shared()._isBet = false, FruitSlotGameManager.shared()._winshow_anim = e.winshow, FruitSlotGameManager.shared()._free_game_num = e.freegame, FruitSlotGameManager.shared()._jackpot_type = e.jackpot_type ?? 0, FruitSlotGameManager.shared()._near_win_cols = e.near_win_cols ?? [], FruitSlotGameManager.shared()._jackpot_win = e.jackpot_win ?? 0, sys.isObjectValid(e.wininfo) && this.win_data_show(e.wininfo), sys.isObjectValid(e.freegamecount) && (FruitSlotGameManager.shared()._is_xyc_complete = true), sys.isObjectValid(e.cur_freegame_win_socre) && (FruitSlotGameManager.shared()._cur_freegame_win_socre = e.cur_freegame_win_socre), 0 != FruitSlotGameManager.shared()._free_game_num || sys.isObjectValid(e.freegamecount) ? FruitSlotGameManager.shared()._free_game_num > 0 && FruitSlotGameManager.shared()._free_game_num != FruitSlotGameManager.shared()._freegamecount && this.update_game_state_type(2) : this.update_game_state_type(1), FruitSlotGameManager.shared()._free_game_num == FruitSlotGameManager.shared()._freegamecount || (FruitSlotGameManager.shared()._free_game_num > 0 && FruitSlotGameManager.shared()._free_game_num != FruitSlotGameManager.shared()._freegamecount ? PushCenter.shared().pushEvent("game_fruit_button_close_state", 2) : 0 == FruitSlotGameManager.shared()._free_game_num && sys.isObjectValid(e.freegamecount) || 0 == FruitSlotGameManager.shared()._free_game_num && PushCenter.shared().pushEvent("game_fruit_button_close_state", 1)), FruitSlotGameManager.shared()._winscore = e.winscore, this.goodsView.startRollingAni(e.result), FruitSlotGameManager.shared()._result = e.result, FruitSlotGameManager.shared()._free_game_num != FruitSlotGameManager.shared()._freegamecount && (this.btnView.show_free_game(e.freegame), FruitSlotGameManager.shared()._free_game_total_win = 0), this.btnView.button_state(1), FruitSlotGameManager.shared()._autoNum = e.auto_count, this.btnView.updateAutoBtnState(), FruitSlotGameManager.shared()._free_game_num > 0 && FruitSlotGameManager.shared()._free_game_num != FruitSlotGameManager.shared()._freegamecount ? sys.isObjectValid(e.free_game_total_win) ? FruitSlotGameManager.shared()._free_game_total_win = e.free_game_total_win : (FruitSlotGameManager.shared()._free_game_total_win = 0, this.btnView.hide_win_num()) : sys.isObjectValid(e.freegamecount) ? sys.isObjectValid(e.free_game_total_win) ? FruitSlotGameManager.shared()._free_game_total_win = e.free_game_total_win : FruitSlotGameManager.shared()._free_game_total_win = 0 : (FruitSlotGameManager.shared()._free_game_total_win = 0, this.btnView.hide_win_num()), this._gameData.jackPotNum_tmp = 0, sys.isObjectValid(e.jackpot_pool) && (this._gameData.jackPotNum_tmp = this._gameData.jackPotNum, this._gameData.jackPotNum = e.jackpot_pool)) : (FruitSlotGameManager.shared().isAnimPlaying = false, sys.isObjectValid(e.pop_addgold) && 1 == e.pop_addgold || sys.isObjectValid(e.err_msg) && e.err_msg.length > 0 && Utils.shared().showToast(e.err_msg, 2));
    }
    win_data_show(e) {
        FruitSlotGameManager.shared()._win_data = [];
        let t = { win_index: [] };
        if (1 == e.length) {
            FruitSlotGameManager.shared()._win_data = e;
        }
        else {
            for (let a = 0; a < e.length; a++) {
                if (sys.isObjectValid(e[a].win_index) && Array.isArray(e[a].win_index) && e[a].win_index.length > 0) {
                    for (let i = 0; i < e[a].win_index.length; i++) {
                        t.win_index.push(e[a].win_index[i]);
                    }
                }
            }
            t.win_index = FruitSlotGameManager.arrayUnique(t.win_index);
            FruitSlotGameManager.shared()._win_data.push(t);
            for (let t = 0; t < e.length; t++) {
                FruitSlotGameManager.shared()._win_data.push(e[t]);
            }
        }
    }
    handler_table_info(e) {
        if (this.tid_key == e.tid_key) {
            if (FruitSlotGameManager.shared().checkLoadingRefresh = false, TweenTool.stopNodeAction(FruitSlotGameManager.shared().sceneNode), FruitSlotGameManager.shared().isAnimPlaying = false, this.aniView.remove_jiesuan_anim(), this.goodsView.initPanel(), this.goodsView.stop_music_jingbiguandong(), FruitSlotGameManager.shared()._isBet = true, FruitSlotGameManager.shared()._gameState = e.state, FruitSlotGameManager.shared()._raisBetlist = e.bet_config, FruitSlotGameManager.shared()._isAuto = e.isAuto, FruitSlotGameManager.shared()._result = e.result, FruitSlotGameManager.shared()._multiple = [], FruitSlotGameManager.shared()._coin = User.shared().data.money, FruitSlotGameManager.shared()._freegamecount = e.freegamecount, FruitSlotGameManager.shared()._free_game_num = e.freegame, FruitSlotGameManager.shared()._isfast = e.isFast, this.btnView.fast_return(), sys.isObjectValid(e.winscore) && (FruitSlotGameManager.shared()._winscore = e.winscore), this.btnView.show_free_game(e.freegame), FruitSlotGameManager.shared()._free_game_num > 0 ? (this.update_game_state_type(2), PushCenter.shared().pushEvent("game_fruit_button_close_state", 2)) : (this.update_game_state_type(1), PushCenter.shared().pushEvent("game_fruit_button_close_state", 1)), this.btnView.button_state(0), sys.isObjectValid(e.bet_config) && Array.isArray(e.bet_config) && e.bet_config.length > 0) {
                for (let t = 0; t < e.bet_config.length; t++) {
                    if (e.cur_bet == e.bet_config[t]) {
                        FruitSlotGameManager.shared()._betIndex = t;
                        break;
                    }
                }
            }
            sys.isObjectValid(e.jackpot_pool) && (this._gameData.jackPotNum = e.jackpot_pool, this.btnView.updateJackPotPool(this._gameData.jackPotNum, e.jackpot_pool));
            sys.isObjectValid(e.auto_count) && (FruitSlotGameManager.shared()._autoNum = e.auto_count);
            User.shared().updateMoney(e.money);
            this.aniView.resetUi();
            this.btnView.updateTextBetAmount();
            this.btnView.updateAutoBtnState();
            this.btnView.updateMultiple();
            this.goodsView.showBetStatePanel();
            sys.isObjectValid(e.free_game_total_win) && e.free_game_total_win > 0 ? (FruitSlotGameManager.shared()._free_game_total_win = e.free_game_total_win, this.btnView.show_win_num(true, e.free_game_total_win)) : (FruitSlotGameManager.shared()._free_game_total_win = 0, this.btnView.show_win_num(true, FruitSlotGameManager.shared()._winscore));
            ToolUtils.isObjValid(e.disable_liveup) && 1 == e.disable_liveup && (Utils.shared().checkHasPopView(FruitSlotGameManager.shared().popNode) || this.reportSever());
            this.checkFlopGoldTask();
        }
    }
    checkFlopGoldTask() {
        if (1 != User.shared().new_user_flopcash_open) {
            return;
        }
        let e = FruitSlotGameManager.shared()._vid;
        HttpManager.shared().doGetCommonRequest({ vid: e }, HttpRequest.FlopCashTaskList, ((t, a, i) => {
            if (200 != i) {
                ;
            }
            else {
                let t = ToolUtils.parseJson(a);
                0 == t.ret && (e > 0 ? sys.isObjectValid(t.data.show) && 1 == t.data.show && (FruitSlotGameManager.shared().data.flopGoldTaskLaba = t.data, this.btnView.updateFlopGoldStatus(true, t.data)) : this.btnView.updateFlopGoldStatus(false, t.data));
            }
        }));
    }
    handler_server_login_gate_return(e) {
        FruitSlotGameManager.shared().handler_server_login_gate_return(e);
    }
    handler_server_HEARTBEAT_DELAY_return(e) {
        this.isNetworkDelay = true;
        let t = ToolUtils.getOsTime() - ToolUtils.lastSendHeartBeatTime;
        ToolUtils.gamePing = t;
        t > 999 && (t = 999);
        1 == User.shared().games_delay_open && (User.shared().hasMaintain || 0 == window.InGameScene || this.updateNetSignal(t));
    }
    updateNetSignal(e) {
    }
    initPushCenter() {
        PushCenter.shared().addListener(GameConfig.onEnterForeground, (e => {
            if (ToolUtils.isGameBackground = false, ToolUtils.isObjValid(this.node)) {
                let e = this, t = sys.now();
                this.scheduleOnce((() => {
                    e.isNetworkDelay = true;
                }), 1);
                Utils.shared().checkScreenLandscape();
                t / 1000 - this.backgroundSatyTime / 1000 > 30 || ToolUtils.backgroundWebSocketReconnection ? (ToolUtils.backgroundWebSocketReconnection = false, this.scheduleOnce((() => {
                    Server.shared().disconnectWebSocket();
                })), this.scheduleOnce((() => {
                    FruitSlotGameManager.shared().loginGameServer();
                }), 0.2)) : this.scheduleOnce((() => {
                    FruitSlotGameManager.shared().sendGameInfoRequest();
                }), 0.2);
            }
        }), this);
        PushCenter.shared().addListener(GameConfig.onEnterBackground, (e => {
            ToolUtils.isGameBackground = true;
            this.backgroundSatyTime = sys.now();
            this.send_request_enterBackGround();
        }), this);
        PushCenter.shared().addListener(PushEvent.BackToLogin, (e => {
            this.backToLogin();
        }), this);
        PushCenter.shared().addListener(PushEvent.ExitGameToHall, (e => {
            ToolUtils.isObjValid(this.node) && this.backToHall();
        }), this);
        PushCenter.shared().addListener(PushEvent.Low_Memory_Notice, (e => {
            ToolUtils.isObjValid(this.node) && this.releaseRes();
        }), this);
        PushCenter.shared().addListener(PushEvent.FruitMach_is_xyc_state_period, (e => {
            ToolUtils.isObjValid(this.node) && this.update_game_state_type(e);
        }), this);
        PushCenter.shared().addListener(PushEvent.RefreshRoomDesk, (() => {
            ToolUtils.isObjValid(this.node) && FruitSlotGameManager.shared().sendGameInfoRequest();
        }), this);
        PushCenter.shared().addListener("game_fruit_background_music", (e => {
            ToolUtils.isObjValid(this.node) && (FruitSlotGameManager.shared()._free_game_num > 0 ? SoundManager.shared().playTargetMusic(this.musicAudioSources[1]) : SoundManager.shared().playTargetMusic(this.musicAudioSources[0]));
        }), this);
        PushCenter.shared().addListener(GameConfig.NetWorkErrorReconnection, (e => {
            this.scheduleOnce((() => {
                this.scheduleOnce((() => {
                    Server.shared().disconnectWebSocket();
                }));
                this.scheduleOnce((() => {
                    FruitSlotGameManager.shared().loginGameServer();
                }), 0.2);
            }));
        }), this);
        PushCenter.shared().addListener(GameConfig.RummyCompleteExit, (e => {
            this.backToHall();
        }), this);
        PushCenter.shared().addListener(GameConfig.NetWorkDelayShow, (e => {
            this.isNetworkDelay = true;
            this.networkDelay = 0;
        }), this);
        PushCenter.shared().addListener(GameConfig.Update_Money, (e => {
            ToolUtils.isObjValid(this.node) && (FruitSlotGameManager.shared().isAnimPlaying || this.btnView.updateCoin(User.shared().data.money));
        }), this);
        PushCenter.shared().addListener("slot_good_ani_finish", (e => {
            ToolUtils.isObjValid(this.node) && TweenTool.delayAct(this.node, (() => {
                sys.isObjectValid(this._gameData.jackPotNum_tmp) && this._gameData.jackPotNum_tmp > 0 && this.btnView.updateJackPotPool(this._gameData.jackPotNum_tmp, this._gameData.jackPotNum);
            }), 0.5, true);
        }), this);
        PushCenter.shared().addListener(PushEvent.NoticeFinishFlop, (e => {
            ToolUtils.isObjValid(this.node) && sys.isObjectValid(e) && this.reportSever();
        }), this);
        PushCenter.shared().addListener(PushEvent.ShowTwentyFourRecharge, (e => {
            sys.isObjectValid(e) && null != e.tid_key && e.tid_key === this.tid_key && ToolUtils.isObjValid(this.node) && (undefined !== e.parent_node && null !== e.parent_node || (e.parent_node = FruitSlotGameManager.shared().popNode), e.vid = FruitSlotGameManager.shared()._vid, e.in_room = 1, Utils.shared().showTwentyHourRecharge(e));
        }), this);
        PushCenter.shared().addListener(PushEvent.ShowBuyOneGetThree, (e => {
            sys.isObjectValid(e) && null != e.tid_key && e.tid_key === this.tid_key && ToolUtils.isObjValid(this.node) && (undefined !== e.parent_node && null !== e.parent_node || (e.parent_node = FruitSlotGameManager.shared().popNode), e.vid = FruitSlotGameManager.shared()._vid, e.in_room = 1, Utils.shared().showBuyOneGetThree(e));
        }), this);
        PushCenter.shared().addListener(PushEvent.ShowFirstRecharge, (e => {
            sys.isObjectValid(e) && null != e.tid_key && e.tid_key === this.tid_key && ToolUtils.isObjValid(this.node) && (undefined !== e.parent_node && null !== e.parent_node || (e.parent_node = FruitSlotGameManager.shared().popNode), e.vid = FruitSlotGameManager.shared()._vid, e.in_room = 1, Utils.shared().showFirstRecharge_game2(e));
        }), this);
        PushCenter.shared().addListener(PushEvent.ShowCouponAct, (e => {
            ToolUtils.isObjValid(this.node) && Utils.shared().showCouponActView(null, e);
        }), this);
        PushCenter.shared().addListener("slot_good_ani_finish", (e => {
            ToolUtils.isObjValid(this.node) && (TweenTool.delayAct(this.node, (() => {
                sys.isObjectValid(this._gameData.jackPotNum_tmp) && this._gameData.jackPotNum_tmp > 0 && this.btnView.updateJackPotPool(this._gameData.jackPotNum_tmp, this._gameData.jackPotNum);
            }), 0.5, true), this.waitPlayGullakAnim && (this.waitPlayGullakAnim = false, this.btnView.updateGullakBtnStatus(User.shared().act_68_open, User.shared().act_68_full_status, true)));
        }), this);
        PushCenter.shared().addListener(PushEvent.Update_Gullak_State, (e => {
            ToolUtils.isObjValid(this.node) && (this.waitPlayGullakAnim = true);
        }), this);
        PushCenter.shared().addListener(PushEvent.Update_Gullak_RewardInGame, (e => {
            ToolUtils.isObjValid(this.node) && this.btnView.updateGullakBtnStatus(User.shared().act_68_open, User.shared().act_68_full_status, true);
        }), this);
        PushCenter.shared().addListener(PushEvent.ShowRestartGift, (e => {
            sys.isObjectValid(e) && null != e.tid_key && e.tid_key === this.tid_key && (undefined !== e.parent_node && null !== e.parent_node || (e.parent_node = FruitSlotGameManager.shared().popNode), e.vid = FruitSlotGameManager.shared()._vid, e.in_room = 1, Utils.shared().showRestartGift(e));
        }), this);
        PushCenter.shared().addListener(PushEvent.ShowConsecutiveGift, (e => {
            sys.isObjectValid(e) && null != e.tid_key && e.tid_key === this.tid_key && ToolUtils.isObjValid(this.node) && (undefined !== e.parent_node && null !== e.parent_node || (e.parent_node = FruitSlotGameManager.shared().popNode), e.vid = FruitSlotGameManager.shared()._vid, e.in_room = 1, Utils.shared().showConsecutiveGift(e));
        }), this);
        PushCenter.shared().addListener(PushEvent.UpdateRoomFlopCrashTaskProgess, (e => {
            ToolUtils.isObjValid(this.node) && sys.isObjectValid(e) && sys.isObjectValid(e) && e.vid == FruitSlotGameManager.shared()._vid && (this.btnView.updateFlopGoldStatus(true, e), FruitSlotGameManager.shared().data.delayShowFlopGoldAct ? FruitSlotGameManager.shared().data.flopGoldTaskInfo = e : (FruitSlotGameManager.shared().data.flopGoldTaskInfo = null, this.updateFlopGoldTask(e)));
        }), this);
        PushCenter.shared().addListener(PushEvent.NoticeFinishFlop, (e => {
            ToolUtils.isObjValid(this.node) && sys.isObjectValid(e) && this.reportSever();
        }), this);
        PushCenter.shared().addListener(PushEvent.Update_FlopGame, (e => {
            ToolUtils.isObjValid(this.node) && this.checkFlopGameShow(e);
        }), this);
    }
    checkFlopGameShow(e) {
        !sys.isObjectValid(e) || 0 != e && 3 != e && 4 != e || this.showFlopGame && sys.isObjectValid(this.showFlopGamePara) && (Utils.shared().showFlopCashActInGame(this.showFlopGamePara), this.showFlopGame = false, ToolUtils.flopActInGameData = null);
    }
    updateFlopGoldTask(e) {
        if (sys.isObjectValid(e) && sys.isObjectValid(e.tid_key) && sys.isObjectValid(e.current_task_status) && 2 == e.current_task_status && this.tid_key == e.tid_key && this.node.active) {
            let t = { source: e, vid: FruitSlotGameManager.shared()._vid, tid_key: e.tid_key };
            this.showFlopGamePara = t;
            this.showFlopGame = true;
            this.send_pause_auto_next_round();
        }
    }
    updateBankruptcyParam(e) {
        sys.isObjectValid(e.act_124_show) && (FruitSlotGameManager.shared().data.act_124_show = e.act_124_show);
        sys.isObjectValid(e.act_98_show) && (FruitSlotGameManager.shared().data.act_98_show = e.act_98_show, 1 == e.act_98_show ? FruitSlotGameManager.shared().data.act_98_param = { vid: FruitSlotGameManager.shared()._vid, isShowTip: true, bShowNetTip: true, tid_key: this.tid_key, min_entry: FruitSlotGameManager.shared()._raisBetlist[FruitSlotGameManager.shared()._betIndex], ext: { times: e.times, reward_value: e.reward_value, ad_multiple: e.ad_multiple, reward_list: [{ type: 7, amt: e.reward_value }] } } : FruitSlotGameManager.shared().data.act_98_param = {});
        sys.isObjectValid(e.act_139_show) && (FruitSlotGameManager.shared().data.act_139_show = e.act_139_show);
        sys.isObjectValid(e.show_ad) ? FruitSlotGameManager.shared().data.show_room_ad = e.show_ad : sys.isObjectValid(e.show_room_ad) && (FruitSlotGameManager.shared().data.show_room_ad = e.show_room_ad);
        sys.isObjectValid(e.room_ad_string) && (FruitSlotGameManager.shared().data.room_ad_string = e.room_ad_string);
        FruitSlotGameManager.shared().data.show_ad = FruitSlotGameManager.shared().data.show_room_ad;
    }
    send_pause_auto_next_round() {
        let e = { cmd: FruitSlotGameCmd.GM_PAUSE_AUTO_NEXT_ROUND, uid: User.shared().data.uid, version: GameConfig.Server_Api_Ver, skey: User.shared().getSkey(), tid_key: User.shared().curTid_key };
        Server.shared().send(e);
    }
    reportSever() {
        let e = { cmd: NetConfig.CLIENT_NOTIFY_GOBACK_GAME, uid: User.shared().data.uid, type: 2, tid_key: User.shared().curTid_key };
        Server.shared().send(e);
    }
    update_game_state_type(e) {
        FruitSlotGameManager.shared()._game_state_type != e && (1 == e ? (FruitSlotGameManager.shared()._game_state_type = 1, SoundManager.shared().playTargetMusic(this.musicAudioSources[0]), this.center_bg.spriteFrame = this.center_bg_frames[1], this.center_bg_anim.active = false) : (FruitSlotGameManager.shared()._game_state_type = 2, SoundManager.shared().playTargetMusic(this.musicAudioSources[1]), this.center_bg.spriteFrame = this.center_bg_frames[0], this.center_bg_anim.active = true));
    }
    loadFruitMachSounds() {
        try {
            SoundManager.shared().preLoadBundleSounds(BundleNameDefined.bundle_sound, "fruitmachine");
        }
        catch (e) {
        }
    }
    exitCallBack(e) {
        if (1 == e) {
            let e = { cmd: NetConfig.GM_LOGINOUT_REQUEST, tid_key: this.tid_key, vid: ToolUtils.curRoomId, uid: User.shared().data.uid };
            Server.shared().send(e);
        }
    }
    send_request_enterBackGround() {
        let e = { cmd: RummyCmd.CLIENT_OFFLINE, uid: User.shared().data.uid, version: GameConfig.Server_Api_Ver, tid_key: this.tid_key, skey: User.shared().getSkey() };
        Server.shared().send(e);
    }
    backToHall() {
        this.exitCallBack(1);
        let e = sys.now() - this._enterStartTime;
        e = e > 1000 ? 0 : 1000 - e;
        setTimeout((() => {
            User.shared().hasMaintain ? this.backToLogin() : window.InGameScene && (window.InGameScene = false, User.shared().getHallPopList(false), User.shared().isLoginHall = false, HttpManager.shared().doReportUserAct(PhpReportDefined.Click_Game_QuitGame), TransferPlatform.shared().setHighFrameRate(), window.InSwitchScene = true, window.IsBackToHallLoad = true, Utils.shared().preLoadBundleAsset(0 == TransferPlatform.shared().getDeviceLevel()), Utils.shared().showLoading(20), this.enterSwitchScene(2));
        }), e);
    }
    backToLogin() {
        window.InGameScene && (window.InGameScene = false, window.InHallScene = false, HttpManager.shared().doReportUserAct(PhpReportDefined.Click_Game_QuitGame), Utils.shared().hideRummyNode(), LabaServer.shared().reset(), Server.shared().reset(), User.shared().doSendMatchOnlineStatus(0), TransferPlatform.shared().setHighFrameRate(), this.enterSwitchScene(3));
    }
    enterSwitchScene(e) {
        let t = 100;
        sys.isNative ? sys.os !== sys.OS.IOS && sys.os !== sys.OS.OSX || (t = 50, ToolUtils.isPadPlatform() && (t = 30)) : t = 0;
        let a = e, i = this;
        ToolUtils.loadBundleScene(BundleNameDefined.bundle_switch, BundleNameDefined.switch_scence, ((e, s) => {
            null == e ? (ToolUtils.switchSceneTye = a, i.jumpToSwitchScene(t, s)) : ToolUtils.loadBundleScene(BundleNameDefined.bundle_switch, BundleNameDefined.switch_scence, ((e, s) => {
                null == e ? (ToolUtils.switchSceneTye = a, i.jumpToSwitchScene(t, s)) : (Utils.shared().hideLoading(), Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text27"), 2));
            }));
        }));
    }
    jumpToSwitchScene(e, t) {
        if (User.shared().checkIfHasLoadHallBundle()) {
            sys.os === sys.OS.IOS || sys.os === sys.OS.OSX ? (ToolUtils.isPadPlatform() || setTimeout((() => {
            }), e), Utils.shared().hideLoading(), TransferPlatform.shared().orientationToPortrait((() => {
                director.runScene(t);
            }))) : (Utils.shared().hideLoading(), TransferPlatform.shared().orientationToPortrait((() => {
                setTimeout((() => {
                    director.runScene(t);
                }), e);
            })));
        }
        else {
            let a = false, i = 0;
            this.schedule((s => {
                i += s;
                a || (User.shared().checkIfHasLoadHallBundle() || i >= 2) && (a = true, sys.os === sys.OS.IOS || sys.os === sys.OS.OSX ? (ToolUtils.isPadPlatform() || setTimeout((() => {
                }), e), Utils.shared().hideLoading(), TransferPlatform.shared().orientationToPortrait((() => {
                    director.runScene(t);
                }))) : (Utils.shared().hideLoading(), TransferPlatform.shared().orientationToPortrait((() => {
                    setTimeout((() => {
                        director.runScene(t);
                    }), e);
                }))), this.unscheduleAllCallbacks());
            }));
        }
    }
    onSceneLaunched() {
        PushCenter.shared().pushEvent(PushEvent.BackToHall);
        Utils.shared().hideLoading();
    }
    releaseRes() {
        ToolUtils.isObjValid(this.node) && ToolUtils.isObjValid(FruitSlotGameManager.shared().popNode) && (this.releasePrefabRes(BundleNameDefined.bundle_firstRecharge, "first_buy", "FirstRecharge"), this.releasePrefabRes(BundleNameDefined.bundle_payoneforthree, "payoneforthree", "BuyOneGetThree"), this.releasePrefabRes(BundleNameDefined.bundle_public, "comm_magic_face", "comm_magic_face"), this.releasePrefabRes(BundleNameDefined.bundle_public, "chat_alert", "chat_alert"));
    }
    releasePrefabRes(e, t, a) {
        let i = assetManager.getBundle(e);
        if (!i) {
            return void TLog.printError("---------- releaseRes bundle is null:", e);
        }
        let s = director.getScene().getChildByName("Canvas");
        if (!s.isValid) {
            return;
        }
        let r = s.getChildByName(a);
        ToolUtils.isObjValid(r) || FruitSlotGameManager.shared().popNode.getChildByName(a) || this.node.getChildByName(a) || i.release(ToolUtils.format("prefab/${0}", t));
    }
}
