// @ts-nocheck
// Recovered from index.js:447
import { _decorator, instantiate, sys } from "cc";
import { TransferPlatform } from "./TransferPlatform";
import i18nMgr from "./i18nMgr";
import PushCenter from "./PushCenter";
import { TLog } from "./TLog";
import TweenTool from "./TweenTool";
import Utils from "./Utils";
import GameConfig from "./GameConfig";
import User from "./User";
import RummyCardConstant from "./RummyCardConstant";
import RummyDataManager, { RUMMY_GAME_TYPE, RUMMY_PLAYER_STATE_TYPE } from "./RummyDataManager";
import RummyGamePoolPop from "./RummyGamePoolPop";
import RummyTotalSettlement from "./RummyTotalSettlement";
import PushEvent from "./PushEvent";
import SoundManager from "./SoundManager";
import { ToolUtils } from "./ToolUtils";
import BundleNameDefined from "./BundleNameDefined";
const { ccclass } = _decorator;
@ccclass("RummyGameOverOpenLogic")
export default class RummyGameOverOpenLogic {
    public tid_key: string = "";
    public mainRummy: any = null;
    public show_settle_ui: number = 0;
    public _gameEndMsg: any = null;
    init(e) {
        this.mainRummy = e;
    }
    ceshiceshi() {
    }
    handler_server_declare_card_bc_return(e, m) {
        this.tid_key = e;
        let a = RummyDataManager.shared().rummyInfos.get(this.tid_key);
        if (this.mainRummy.hideOpenCardAlert(), this.mainRummy.actionTs.changeOpenCardStatus(false, this.mainRummy), null != m.play_animation && 1 == m.play_animation) {
            let e = parseInt("" + m.win_seatid);
            this.mainRummy.playerTs.stopPlayerTimerByPos(this.mainRummy.getPosBySeatid(e), true);
            a.bIsHasHu = true;
            this.mainRummy.cardsTs.deleteClickCountDown();
            this.mainRummy.tipTs.showWinEffect(this.mainRummy.getPosBySeatid(e), m.finish_multiple);
            this.mainRummy.playerTs.hideAllEasyGameLight();
            this.mainRummy.tingPaiTs.hideTingPaiUI();
            this.mainRummy.tingPaiTs.tingPaiMsg = null;
            this.mainRummy.autoDropTs.isshowAutoDropBtn(false, this.tid_key);
            this.mainRummy.autoDropTs.hideAllLayer();
            this.mainRummy.actionTs.changeAutoGroupBtnStatus(false);
            let i = a.clientSeatId, t = RummyDataManager.shared().checkLiveAvatar(this.tid_key, i), s = e == i ? 5 : 2;
            return this.mainRummy.rummyLogicProcessing.showPlayerHeadAnim(0, s, t), void (User.shared().curTid_key != this.tid_key && i != e || SoundManager.shared().playFx("winA"));
        }
        a.isClientToPlay = false;
        Utils.shared().hideCommomDialog(this.mainRummy.pop_layer4);
        a.gameTipsTextType = 0;
        let t = m.uid, h = m.seatid, c = m.alertStr, T = m.alertStr2, g = m.cd, S = m.dec_cd, f = 0;
        a.autoDeclareStatus = m.declare_status;
        let O = a.clientSeatId, I = a.playerModels[O];
        I && (f = I.betting);
        let A = true;
        if (1 != m.isfaurd && (this.mainRummy.isZhahuHupai = false, A = a.is_showhuAnim_status), this.mainRummy.cardsTs.playerHupaiReturn(m.card, m.isfaurd, m.opencards, m.isReissue), this.mainRummy.isMyPlayer(h) && (this.mainRummy.autoDropTs.hideAllLayer(), this.mainRummy.tipTs.show_hupai_tip(false)), 1 == m.isfaurd) {
            if (this.mainRummy.isMyPlayer(h)) {
                this.mainRummy.actionTs.setMopaiBtnInteractable(false);
                this.mainRummy.my_drop_card_state_show(a);
                this.mainRummy.cardsTs.showDropCardsZheZhao(true);
                a.gameRummyType == RUMMY_GAME_TYPE.MATCH && this.mainRummy.tipTs.showMatchWaitTip(true);
                a.isCanExit = true;
                a.isCanTouchCard = false;
                a.isInGameing = 0;
                null != m.all_score && this.mainRummy.playerTs.showLoseScore(0, m.all_score, true);
                this.mainRummy.playerTs.stopPlayerTimerByPos(0);
                null != m.cur_money && this.mainRummy.playerTs.updatePlayerMoney(0, m.cur_money);
                a.gameRummyType != RUMMY_GAME_TYPE.POOL && a.gameRummyType != RUMMY_GAME_TYPE.PRI_POOL && a.gameRummyType != RUMMY_GAME_TYPE.DEALS && a.gameRummyType != RUMMY_GAME_TYPE.PRI_DEAL || null != m.score && (this.mainRummy.playerTs.setPoolScore(0, m.score), this.mainRummy.updateSeatScore(h, m.score));
                a.gameRummyType == RUMMY_GAME_TYPE.MATCH && null != m.score && (this.mainRummy.playerTs.setPoolScore(0, m.score), this.mainRummy.updateSeatScore(h, m.score));
            }
            else {
                let e = this.mainRummy.getPosBySeatid(h);
                null != m.all_score && this.mainRummy.playerTs.showLoseScore(e, m.all_score, true);
                this.mainRummy.playerTs.stopPlayerTimerByPos(e);
                null != m.cur_money && this.mainRummy.playerTs.updatePlayerMoney(e, m.cur_money);
                a.gameRummyType != RUMMY_GAME_TYPE.POOL && a.gameRummyType != RUMMY_GAME_TYPE.PRI_POOL && a.gameRummyType != RUMMY_GAME_TYPE.DEALS && a.gameRummyType != RUMMY_GAME_TYPE.PRI_DEAL || null != m.score && (this.mainRummy.playerTs.setPoolScore(e, m.score), this.mainRummy.updateSeatScore(h, m.score));
                a.gameRummyType == RUMMY_GAME_TYPE.MATCH && null != m.score && (this.mainRummy.playerTs.setPoolScore(e, m.score), this.mainRummy.updateSeatScore(h, m.score));
            }
        }
        if (0 == m.isover) {
            return;
        }
        ToolUtils.isObjValid(this.mainRummy.openFlag_poolScoreboard) && this.mainRummy.openFlag_poolScoreboard.destroy();
        a.bIsHasHu = true;
        a.isClearCards = false;
        this.mainRummy.playerTs.setMultipleFireAnimShow(false, 0);
        this.mainRummy.playerTs.setMultipleFireAnimShow(false, 1);
        this.mainRummy.actionTs.changeSwitchJokerStatus(false, this.mainRummy);
        this.mainRummy.actionTs.changeBestJokerStatus(false, this.mainRummy);
        this.mainRummy.cardsTs.hideBestLaiziBubble();
        this.mainRummy.hideWinTipAlert();
        ToolUtils.isObjValid(this.mainRummy.switchJokerNode) && (this.mainRummy.switchJokerNode.active = false);
        a.game_state = 4;
        a.game_server_state = 4;
        a.game_cd = g;
        a.is_declare_status = false;
        this.mainRummy.hasDeclare = true;
        sys.isObjectValid(m.lz_card) && 1 == a.is_bump && (a.laizicard = m.lz_card, a.winLaizicard = m.lz_card, a.best_lz = 0, this.mainRummy.cardsTs.updateRealLaiziCard(m), sys.isObjectValid(m.cardinfos) ? this.mainRummy.refreshMyShouPai(m) : t == User.shared().data.uid && this.mainRummy.cardsTs.beginFaPaiWithoutAnim(a.cardInfoModelVec, a.cardInfoModelVec.length));
        let b = a.playerModels[a.clientSeatId];
        if (t != User.shared().data.uid) {
            if (b && 0 == b.status && 1 == b.betting && this.mainRummy.actionTs.changeAutoGroupBtnStatus(true), a.gameRummyType != RUMMY_GAME_TYPE.PRIVATE && a.gameRummyType != RUMMY_GAME_TYPE.PRI_POOL && a.gameRummyType != RUMMY_GAME_TYPE.PRI_DEAL && a.gameRummyType != RUMMY_GAME_TYPE.POINTS && a.gameRummyType != RUMMY_GAME_TYPE.MATCH && a.gameRummyType != RUMMY_GAME_TYPE.MULTIPLE && a.gameRummyType != RUMMY_GAME_TYPE.DEALS || 0 != this.mainRummy.cardsTs.cardViewVec.length) {
                1 == a.isInGameing && (a.gameRummyType == RUMMY_GAME_TYPE.PRIVATE || a.gameRummyType == RUMMY_GAME_TYPE.PRI_POOL || a.gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL || a.gameRummyType == RUMMY_GAME_TYPE.POINTS || a.gameRummyType == RUMMY_GAME_TYPE.MATCH || a.gameRummyType == RUMMY_GAME_TYPE.MULTIPLE ? b && 4 != b.status && 1 !== m.isfaurd && 1 === f && (SoundManager.shared().playFx("rummySelfTurn"), TransferPlatform.shared().openVibrate(), null != m.isReissue && 1 == m.isReissue ? this.mainRummy.tipTs.showConfimTips(c, T, true, S) : 0 == A ? TweenTool.delayAct(this.mainRummy.action_node, (() => {
                    this.mainRummy.tipTs.showConfimTips(c, T, true, S);
                }), RummyCardConstant.gameOverDelay2, true) : TweenTool.delayAct(this.mainRummy.action_node, (() => {
                    this.mainRummy.tipTs.showConfimTips(c, T, true, S);
                }), RummyCardConstant.gameOverDelay1, true)) : 1 !== m.isfaurd && 1 === f && (SoundManager.shared().playFx("rummySelfTurn"), TransferPlatform.shared().openVibrate(), null != m.isReissue && 1 == m.isReissue ? this.mainRummy.tipTs.showConfimTips(c, T, true, S) : 0 == A ? TweenTool.delayAct(this.mainRummy.action_node, (() => {
                    this.mainRummy.tipTs.showConfimTips(c, T, true, S);
                }), RummyCardConstant.gameOverDelay2, true) : TweenTool.delayAct(this.mainRummy.action_node, (() => {
                    this.mainRummy.tipTs.showConfimTips(c, T, true, S);
                }), RummyCardConstant.gameOverDelay1, true)));
            }
            else if (a.isCanTouchCard = false, b && 0 == b.betting && 1 !== m.isfaurd) {
                let e = i18nMgr.shared().getValueByKey("rummy_main.gameTipstext14");
                this.mainRummy.tipTs.updateTableTipsInfo(true, e, a.game_state);
            }
        }
        else {
            a.game_state = 4;
            this.mainRummy.actionTs.changeAutoGroupBtnStatus(false);
            0 == A ? TweenTool.delayAct(this.mainRummy.action_node, (() => {
                1 != RummyDataManager.shared().rummyInfos.get(this.tid_key).is_waiting && 1 != RummyDataManager.shared().rummyInfos.get(this.tid_key).isGameStarting && this.mainRummy._bIsShowWaitDeclare && this.mainRummy.tipTs.show_wait_declare(true);
            }), 4, true) : TweenTool.delayAct(this.mainRummy.action_node, (() => {
                1 != RummyDataManager.shared().rummyInfos.get(this.tid_key).is_waiting && 1 != RummyDataManager.shared().rummyInfos.get(this.tid_key).isGameStarting && this.mainRummy._bIsShowWaitDeclare && this.mainRummy.tipTs.show_wait_declare(true);
            }), 2, true);
        }
        a.is_declare_status = true;
        a.gameRummyType != RUMMY_GAME_TYPE.POOL && a.gameRummyType != RUMMY_GAME_TYPE.PRI_POOL && a.gameRummyType != RUMMY_GAME_TYPE.DEALS && a.gameRummyType != RUMMY_GAME_TYPE.PRI_DEAL || (PushCenter.shared().pushEvent(GameConfig.Update_Private_Exit_Status, { tid_key: this.tid_key, bEnable: false }), PushCenter.shared().pushEvent(GameConfig.Update_Menu_Switch_Status, { tid_key: this.tid_key, bEnable: false }));
        this.mainRummy.cardsTs.showMoPaiTisAnim(false, false);
        this.mainRummy.cardsTs.showFinishTisiAnim(false);
        this.mainRummy.actionTs.changeDropBtnStatus(false);
        this.mainRummy.actionTs.changeDiscardBtnStatus(false);
        this.mainRummy.actionTs.changeFinishBtnStatus(false);
        this.mainRummy.autoDropTs.isshowAutoDropBtn(false, this.tid_key);
        this.mainRummy.autoDropTs.hideAllLayer();
        for (let e = 0; e < 6; e++) {
            let i = a.playerModels[e];
            if (1 == i.betting) {
                if (e != h) {
                    let t = true;
                    0 == this.mainRummy.getPosBySeatid(e) && 0 == a.isInGameing && (t = false);
                    t && 2 != i.status && 9 != i.status && g > 0 && (a.op_cd = g, 1 == m.isReissue ? this.mainRummy.playerTs.startPlayerTimer2(this.mainRummy.getPosBySeatid(e), g, this.mainRummy.recon_total_cd) : 0 == A ? TweenTool.delayAct(this.mainRummy.action_node, (() => {
                        this.mainRummy.playerTs.startPlayerTimer2(this.mainRummy.getPosBySeatid(e), g, this.mainRummy.recon_total_cd);
                    }), RummyCardConstant.gameOverDelay2, true) : TweenTool.delayAct(this.mainRummy.action_node, (() => {
                        this.mainRummy.playerTs.startPlayerTimer2(this.mainRummy.getPosBySeatid(e), g, this.mainRummy.recon_total_cd);
                    }), RummyCardConstant.gameOverDelay1, true));
                }
                else {
                    this.mainRummy.playerTs.stopPlayerTimerByPos(this.mainRummy.getPosBySeatid(e), true);
                    a.gameRummyType != RUMMY_GAME_TYPE.PRIVATE && a.gameRummyType != RUMMY_GAME_TYPE.MULTIPLE && a.gameRummyType != RUMMY_GAME_TYPE.PRI_DEAL && a.gameRummyType != RUMMY_GAME_TYPE.POINTS && a.gameRummyType != RUMMY_GAME_TYPE.MATCH || b.status !== RUMMY_PLAYER_STATE_TYPE.FirstWinner && (b.status = 4);
                }
            }
        }
        if (undefined !== m.win_seatid) {
            if (Number(m.win_seatid) === a.clientSeatId ? (a.gameRummyType != RUMMY_GAME_TYPE.POINTS && a.gameRummyType != RUMMY_GAME_TYPE.MULTIPLE || (a.isInGameing = 0), 0 == a.crashModel && (User.shared().lastWinGameInfo = { nVid: a.vid, nScore: 0 })) : User.shared().lastWinGameInfo = { nVid: -1, nScore: 0 }, 0 == A) {
                this.mainRummy._bIsWinnerAnimEnd = true;
                this.mainRummy.isZhahuHupai = true;
                TweenTool.delayAct(this.mainRummy.action_node, (() => {
                    let e = parseInt("" + m.win_seatid);
                    this.mainRummy.playerTs.stopPlayerTimerByPos(this.mainRummy.getPosBySeatid(e), true);
                    this.mainRummy.tipTs.showWinEffect(this.mainRummy.getPosBySeatid(e), m.finish_multiple);
                    let i = a.clientSeatId, t = RummyDataManager.shared().checkLiveAvatar(this.tid_key, i), s = e == i ? 5 : 2;
                    if (this.mainRummy.rummyLogicProcessing.showPlayerHeadAnim(0, s, t), this.mainRummy.playerTs.hideAllEasyGameLight(), this.mainRummy.tingPaiTs.hideTingPaiUI(), this.mainRummy.autoDropTs.isshowAutoDropBtn(false, this.tid_key), this.mainRummy.autoDropTs.hideAllLayer(), 0 == this.mainRummy._isPlayWinEffec) {
                        let m = RummyDataManager.shared().rummyInfos.get(this.tid_key).clientSeatId;
                        User.shared().curTid_key != this.tid_key && m != e || SoundManager.shared().playFx("winA");
                        this.mainRummy._isPlayWinEffec = true;
                    }
                    let n = true;
                    if (RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType == RUMMY_GAME_TYPE.PRI_POOL || RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL) {
                        let e = RummyDataManager.shared().rummyInfos.get(this.tid_key).clientSeatId, m = RummyDataManager.shared().rummyInfos.get(this.tid_key).playerModels[e];
                        !m || 0 != m.betting && -1 != m.status || (n = false);
                    }
                    n && this.startShowGameOverDelay(this.tid_key, RummyCardConstant.gameOverDelay2);
                }), 2, true);
            }
            else {
                let e = parseInt("" + m.win_seatid);
                this.mainRummy._bIsWinnerAnimEnd = true;
                this.mainRummy.isZhahuHupai = false;
                this.mainRummy.playerTs.stopPlayerTimerByPos(this.mainRummy.getPosBySeatid(e), true);
                a.bIsHasHu = true;
                this.mainRummy.cardsTs.deleteClickCountDown();
                this.mainRummy.tipTs.showWinEffect(this.mainRummy.getPosBySeatid(e), m.finish_multiple);
                let i = a.clientSeatId, t = RummyDataManager.shared().checkLiveAvatar(this.tid_key, i), s = e == i ? 5 : 2;
                if (this.mainRummy.rummyLogicProcessing.showPlayerHeadAnim(0, s, t), this.mainRummy.playerTs.hideAllEasyGameLight(), this.mainRummy.tingPaiTs.hideTingPaiUI(), this.mainRummy.tingPaiTs.tingPaiMsg = null, this.mainRummy.autoDropTs.isshowAutoDropBtn(false, this.tid_key), this.mainRummy.autoDropTs.hideAllLayer(), 0 == this.mainRummy._isPlayWinEffec) {
                    let m = a.clientSeatId;
                    User.shared().curTid_key != this.tid_key && m != e || SoundManager.shared().playFx("winA");
                    this.mainRummy._isPlayWinEffec = true;
                }
                let n = true;
                if (a.gameRummyType == RUMMY_GAME_TYPE.PRI_POOL || a.gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL) {
                    let e = a.clientSeatId, m = a.playerModels[e];
                    !m || 0 != m.betting && -1 != m.status || (n = false);
                }
                n && this.startShowGameOverDelay(this.tid_key);
            }
        }
    }
    handler_server_finish_status_bc(e, m) {
        this.tid_key = e;
        let i = RummyDataManager.shared().rummyInfos.get(this.tid_key);
        i.bIsHasHu = true;
        ToolUtils.isObjValid(this.mainRummy.openFlag_poolScoreboard) && this.mainRummy.openFlag_poolScoreboard.destroy();
        undefined !== m.all_finish && null !== m.all_finish && 1 === m.all_finish && (this.mainRummy._bIsShowWaitDeclare = false, i.close_cardnum = 0, i.gameRummyType == RUMMY_GAME_TYPE.POOL || i.gameRummyType == RUMMY_GAME_TYPE.PRI_POOL || i.gameRummyType == RUMMY_GAME_TYPE.DEALS || i.gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL || i.gameRummyType == RUMMY_GAME_TYPE.POINTS || i.gameRummyType == RUMMY_GAME_TYPE.PRIVATE || i.gameRummyType == RUMMY_GAME_TYPE.MULTIPLE || (this.resetGameOverState(), this.resetGameOverUI()));
        let a = m.players.length;
        i.gameRummyType == RUMMY_GAME_TYPE.POOL || i.gameRummyType == RUMMY_GAME_TYPE.DEALS || i.gameRummyType == RUMMY_GAME_TYPE.PRI_POOL || i.gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL || i.gameRummyType == RUMMY_GAME_TYPE.MATCH || this.mainRummy.tipTs.changeTuoguanVisible(false);
        this.mainRummy.autoDropTs.hideAllLayer();
        for (let e = 0; e < a; e++) {
            let a = i.playerModels[m.players[e].seatid];
            null != m.players[e].ready ? a.ready = m.players[e].ready : null != m.players[e].zhunbei && (a.ready = m.players[e].zhunbei);
            let t = m.players[e].seatid, s = m.players[e].score, n = this.mainRummy.getPosBySeatid(t);
            if (1 == m.players[e].isfinish && this.mainRummy.playerTs.stopPlayerTimer2(n), this.mainRummy.isMyPlayer(m.players[e].seatid) && 1 == m.players[e].isfinish) {
                if (Utils.shared().hideCommomDialog(), i.isCanTouchCard = false, this.mainRummy._bIsGameEnd = false, this.mainRummy._gameOverMsg = m, ToolUtils.isObjValid(this.mainRummy.gameEndView)) {
                    if (i.gameRummyType === RUMMY_GAME_TYPE.MATCH) {
                        let e = this.mainRummy.gameEndView.getComponent("RummyPointsMatchOverAlert");
                        e.updateInfo(0, m, this.mainRummy.onDealBtnAction.bind(this.mainRummy));
                        e.show_btn();
                        e.show_switch_btn(false);
                    }
                    else {
                        let e = this.mainRummy.gameEndView.getComponent("RummyGameOverAlert");
                        e.updateInfo(0, m, this.mainRummy.onDealBtnAction.bind(this.mainRummy));
                        e.show_btn();
                        e.show_switch_btn(false);
                    }
                }
                else {
                    i.bIsSwitchRoom || ToolUtils.isObjValid(this.mainRummy.gameEndView) && this.mainRummy.gameEndView.active || (this.mainRummy.isZhahuHupai ? this.startShowGameOverDelay(this.tid_key, RummyCardConstant.gameOverDelay2) : this.startShowGameOverDelay(this.tid_key));
                }
                1 !== ToolUtils.isSafeNumber(m.all_finish) && (this.mainRummy._bIsShowWaitDeclare = true);
                this.mainRummy.tipTs.show_finish_tip(false);
                this.mainRummy.tipTs.show_hupai_tip(false);
            }
            null != s && (this.mainRummy.playerTs.setPoolScore(n, s), this.mainRummy.updateSeatScore(t, s));
        }
    }
    handler_server_game_end_bc(e, m) {
        try {
            this.tid_key = e;
            this.show_settle_ui = ToolUtils.isSafeNumber(m.show_settle_ui);
            let a = RummyDataManager.shared().rummyInfos.get(this.tid_key);
            if (a.hasShowWinAnim = false, this.mainRummy._pQipai_action && (TweenTool.stopAction(this.mainRummy._pQipai_action), this.mainRummy._pQipai_action = null), RummyDataManager.shared().reportGameFinish(m), ToolUtils.isObjValid(this.mainRummy.openFlag_poolScoreboard) && this.mainRummy.openFlag_poolScoreboard.destroy(), ToolUtils.isObjValid(this.mainRummy.openFlag_dealsScoreboard) && this.mainRummy.openFlag_dealsScoreboard.destroy(), a.close_cardnum = 0, a.bIsHasHu = true, this.mainRummy.actionTs.changeAutoGroupBtnStatus(false), m.receivedServerTime = sys.now(), this.mainRummy._bIsShowReady = true, this.mainRummy.tipTs.showPoolJackPot(false), a.gameRummyType == RUMMY_GAME_TYPE.PRIVATE || a.gameRummyType == RUMMY_GAME_TYPE.MATCH) {
                this.mainRummy.isGameStarting = false;
            }
            else if (a.gameRummyType == RUMMY_GAME_TYPE.POOL || a.gameRummyType == RUMMY_GAME_TYPE.DEALS) {
                for (let e = 0, i = m.players.length; e < i; e++) {
                    m.players[e].isfinish = 1;
                }
            }
            else if (a.gameRummyType == RUMMY_GAME_TYPE.PRI_POOL || a.gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL) {
                this.mainRummy.isGameStarting = false;
                for (let e = 0, i = m.players.length; e < i; e++) {
                    m.players[e].isfinish = 1;
                }
                this.mainRummy._bIsShowReady = false;
                this.mainRummy._bIsShowReady || this.mainRummy.actionTs.hideReadyBtn();
            }
            this.mainRummy.rummyEndJpacket = m;
            let t = ToolUtils.isSafeNumber(m.check_settle_cd);
            if (a.gameRummyType == RUMMY_GAME_TYPE.POOL || a.gameRummyType == RUMMY_GAME_TYPE.PRI_POOL || a.gameRummyType == RUMMY_GAME_TYPE.DEALS || a.gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL || a.gameRummyType == RUMMY_GAME_TYPE.PRIVATE) {
                1 !== m.all && this.mainRummy.tipTs.show_wait_declare(true, 1, t);
                for (let e = 0; e < 6; e++) {
                    this.mainRummy.playerTs.setPoolRejoinState(e, false);
                }
            }
            this.mainRummy._gameOverMsg = m;
            this.mainRummy._lastGameOverMsg = m;
            let s = !!m.end_way && 1 == m.end_way;
            this.resetGameOverState();
            a.gameRummyType === RUMMY_GAME_TYPE.POINTS || a.gameRummyType == RUMMY_GAME_TYPE.MULTIPLE || this.mainRummy.checkIsPointsMatch() ? this.mainRummy.actionTs.changeSwitchBtnStatus(false) : (TweenTool.delayAct(this.mainRummy.action_node, (() => {
                RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType === RUMMY_GAME_TYPE.POOL || RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType === RUMMY_GAME_TYPE.PRI_POOL ? this.resetGameOverUI(false) : this.resetGameOverUI();
                t > 0 && this.mainRummy.tipTs.hideWinEffect();
                RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType === RUMMY_GAME_TYPE.PRIVATE && PushCenter.shared().pushEvent(PushEvent.ShowPrivateInviteBtn, this.tid_key);
            }), t, true), 0 === t && TweenTool.delayAct(this.mainRummy.action_node, (() => {
                this.mainRummy.tipTs.hideWinEffect();
            }), 2, true));
            s && this.mainRummy.tipTs.updateTableTipsInfo(false);
            let n = false;
            if (a.bIsSwitchRoom) {
                this._gameEndMsg = m;
            }
            else if (n = !this.mainRummy._bGameOverClosed, n) {
                if (s) {
                    this.mainRummy._bIsGameEnd = true;
                    a.gameRummyType == RUMMY_GAME_TYPE.POOL || a.gameRummyType == RUMMY_GAME_TYPE.PRI_POOL || a.gameRummyType == RUMMY_GAME_TYPE.DEALS || a.gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL ? 1 === this.show_settle_ui && this.startShowGameOverDelay(this.tid_key) : this.startShowGameOverDelay(this.tid_key);
                }
                else if (this.mainRummy.deleteGameOverDalay(), a.gameRummyType == RUMMY_GAME_TYPE.POOL || a.gameRummyType == RUMMY_GAME_TYPE.PRI_POOL || a.gameRummyType == RUMMY_GAME_TYPE.DEALS || a.gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL) {
                    if (1 === this.show_settle_ui) {
                        if (ToolUtils.isObjValid(this.mainRummy.gameEndView)) {
                            let e = this.mainRummy.gameEndView.getComponent("RummyGameOverAlert");
                            e.isShowEndView(true);
                            e.updateInfo(0, m, this.mainRummy.onDealBtnAction.bind(this.mainRummy), true);
                            e.show_btn();
                        }
                        else {
                            this.show_create_end_view(this.tid_key, m, true);
                        }
                    }
                }
                else if (ToolUtils.isObjValid(this.mainRummy.gameEndView)) {
                    if (a.gameRummyType === RUMMY_GAME_TYPE.MATCH) {
                        let e = this.mainRummy.gameEndView.getComponent("RummyPointsMatchOverAlert");
                        e.isShowEndView(true);
                        e.updateInfo(0, m, this.mainRummy.onDealBtnAction.bind(this.mainRummy), true);
                        e.show_btn();
                    }
                    else {
                        let e = this.mainRummy.gameEndView.getComponent("RummyGameOverAlert");
                        e.isShowEndView(true);
                        e.updateInfo(0, m, this.mainRummy.onDealBtnAction.bind(this.mainRummy), true);
                        e.show_btn();
                    }
                }
                else {
                    this.show_create_end_view(this.tid_key, m, true);
                }
            }
            else {
                a.gameRummyType == RUMMY_GAME_TYPE.POOL || a.gameRummyType == RUMMY_GAME_TYPE.PRI_POOL || a.gameRummyType == RUMMY_GAME_TYPE.DEALS || a.gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL ? 1 === this.show_settle_ui && this.showGameOverAlertView(m) : this.showGameOverAlertView(m);
                a.gameRummyType !== RUMMY_GAME_TYPE.PRIVATE && this.mainRummy.checkReadyBtn();
                this.clearCards();
                this.dealGameEnd(this.tid_key);
            }
            if (a.bIsSwitchRoom = false, a.gameRummyType == RUMMY_GAME_TYPE.POOL || a.gameRummyType == RUMMY_GAME_TYPE.DEALS || a.gameRummyType == RUMMY_GAME_TYPE.PRI_POOL || a.gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL || a.gameRummyType == RUMMY_GAME_TYPE.MATCH) {
                a.game_state = 4;
                a.is_game_all_end = m.all_end;
                null != m.pool_money && (a.pool_money = m.pool_money);
                1 == m.all_end ? a.game_end_state = 5 : a.game_end_state = m.WaitState;
                for (let e = 0, i = m.players.length; e < i; e++) {
                    let i = m.players[e], a = parseInt("" + i.seatid), t = this.mainRummy.getPosBySeatid(a);
                    null != i.score && (this.mainRummy.playerTs.setPoolScore(t, i.score), this.mainRummy.updateSeatScore(a, i.score));
                    this.mainRummy.playerTs.setPoolRejoinState(t, false);
                }
                PushCenter.shared().pushEvent(GameConfig.Update_Private_Exit_Status, { tid_key: this.tid_key, bEnable: true });
                a.gameRummyType != RUMMY_GAME_TYPE.DEALS && a.gameRummyType != RUMMY_GAME_TYPE.PRI_DEAL || PushCenter.shared().pushEvent(GameConfig.Update_Menu_Switch_Status, { tid_key: this.tid_key, bEnable: true });
            }
            else {
                this.mainRummy.tipTs.changeTuoguanVisible(false);
            }
            if (this.mainRummy.winPos = -1, a.gameRummyType != RUMMY_GAME_TYPE.PRIVATE && a.gameRummyType != RUMMY_GAME_TYPE.PRI_POOL && a.gameRummyType != RUMMY_GAME_TYPE.PRI_DEAL && a.gameRummyType != RUMMY_GAME_TYPE.MATCH || (this.mainRummy.actionTs.changeSwitchBtnStatus(false), PushCenter.shared().pushEvent(GameConfig.Update_Menu_Switch_Status, { tid_key: this.tid_key, bEnable: false })), m.players) {
                for (let e = 0, t = m.players.length; e < t; e++) {
                    const t = m.players[e];
                    let s = parseInt("" + t.seatid), n = t.iswin, h = t.winscore, u = this.mainRummy.getPosBySeatid(s), o = t.money, d = t.uid, R = t.score;
                    if (a.gameRummyType == RUMMY_GAME_TYPE.PRIVATE || a.gameRummyType == RUMMY_GAME_TYPE.PRI_POOL || a.gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL) {
                        let i = a.playerModels[s];
                        null != m.players[e].ready ? i.ready = m.players[e].ready : null != m.players[e].zhunbei && (i.ready = m.players[e].zhunbei);
                        d == User.shared().data.uid && i.ready;
                    }
                    if (null != R && (this.mainRummy.playerTs.setPoolScore(u, R), this.mainRummy.updateSeatScore(s, R)), d == User.shared().data.uid) {
                        0 == a.crashModel && (sys.isObjectValid(m.isReissue) && 1 == m.isReissue || (User.shared().data.money = o, User.shared().real_money = o, PushCenter.shared().pushEvent(GameConfig.Update_Money, o)));
                        let e = null != t.ishavegamelog ? t.ishavegamelog : 0;
                        this.mainRummy.actionTs.changeRecodeBtnStatus(1 == e);
                        1 == n ? (this.mainRummy.playerTs.showLoseScore(this.mainRummy.getPosBySeatid(s), 0, false), this.mainRummy.winPos = u, a.win_pos = u, a.win_money = h, a.gameRummyType != RUMMY_GAME_TYPE.POINTS && a.gameRummyType != RUMMY_GAME_TYPE.PRIVATE && a.gameRummyType != RUMMY_GAME_TYPE.MULTIPLE || (User.shared().lastWinGameInfo = { nVid: a.vid, nScore: h })) : User.shared().lastWinGameInfo = { nVid: -1, nScore: 0 };
                        sys.isObjectValid(m.isReissue) && 1 == m.isReissue || this.mainRummy.delayUpdatePlayerMoney(s);
                    }
                }
                sys.isObjectValid(m.isReissue) && 1 == m.isReissue || this.mainRummy.delayToUpdatePlayerMoney();
                n || this.dealGameEnd(this.tid_key);
                a.gameRummyType != RUMMY_GAME_TYPE.PRIVATE && a.gameRummyType != RUMMY_GAME_TYPE.PRI_POOL && a.gameRummyType != RUMMY_GAME_TYPE.PRI_DEAL || PushCenter.shared().pushEvent(GameConfig.Update_Private_Exit_Status, { tid_key: this.tid_key, bEnable: true });
                n && s && !ToolUtils.isObjValid(this.mainRummy.gameEndView) ? TweenTool.delayAct(this.mainRummy.time_node, (() => {
                    this.mainRummy.onGameEndViewClosed();
                }), RummyCardConstant.gameOverDelay1, true) : this.mainRummy.onGameEndViewClosed();
            }
        }
        catch (e) {
            TLog.printError("trycatch handler_server_game_end_bc,error:", e);
        }
    }
    showGameOverAlertView(e) {
        let m = ToolUtils.isSafeNumber(e.show_ui), i = RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType;
        if (ToolUtils.isObjValid(this.mainRummy.gameEndView)) {
            if (i == RUMMY_GAME_TYPE.MATCH) {
                let m = this.mainRummy.gameEndView.getComponent("RummyPointsMatchOverAlert");
                m.isShowEndView(true);
                m.updateInfo(0, e, this.mainRummy.onDealBtnAction.bind(this.mainRummy), true);
                m.show_btn();
            }
            else {
                let i = this.mainRummy.gameEndView.getComponent("RummyGameOverAlert"), a = RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType;
                a == RUMMY_GAME_TYPE.PRIVATE || a == RUMMY_GAME_TYPE.PRI_POOL || a == RUMMY_GAME_TYPE.PRI_DEAL ? a == RUMMY_GAME_TYPE.PRI_POOL && 1 === m && i.isShowEndView(true) : i.isShowEndView(true);
                i.updateInfo(0, e, this.mainRummy.onDealBtnAction.bind(this.mainRummy), true);
                i.show_btn();
            }
        }
        else {
            1 === m && this.show_create_end_view(this.tid_key, e, true);
        }
    }
    show_create_end_view(e, m, t) {
        try {
            this.tid_key = e;
            let s = this.mainRummy.pop_layer4.getChildByName("match_game_over"), n = this.mainRummy.pop_layer4.getChildByName("comm_magic_face"), y = RummyDataManager.shared().rummyInfos.get(this.tid_key);
            if (!ToolUtils.isObjValid(s)) {
                if (y.gameRummyType == RUMMY_GAME_TYPE.MATCH) {
                    if (ToolUtils.isObjValid(this.mainRummy.gameEndView)) {
                        let e = this.mainRummy.gameEndView.getComponent("RummyPointsMatchOverAlert");
                        e.tid_key = this.tid_key;
                        e.updateInfo(0, m, this.mainRummy.onDealBtnAction.bind(this.mainRummy), t);
                        e.isShowEndView(true);
                        e.setLandscapeShow();
                        e.show_btn();
                        e.show_switch_btn(false);
                    }
                    else {
                        try {
                            ToolUtils.loadCommonPrefab(RummyDataManager.shared().pointsMatchOverPrefab, BundleNameDefined.bundle_rummy, "prefab/match_points_over", (e => {
                                if (sys.isObjectValid(e) && e.isValid) {
                                    RummyDataManager.shared().pointsMatchOverPrefab = e;
                                    let i = instantiate(RummyDataManager.shared().pointsMatchOverPrefab);
                                    i.parent = this.mainRummy.pop_layer3;
                                    this.mainRummy.gameEndView = i;
                                    let s = i.getComponent("RummyPointsMatchOverAlert");
                                    s.tid_key = this.tid_key;
                                    s.updateInfo(0, m, this.mainRummy.onDealBtnAction.bind(this.mainRummy), t);
                                    s.startShowAnim();
                                    s.setLandscapeShow();
                                    s.show_btn();
                                    s.show_switch_btn(false);
                                }
                            }));
                        }
                        catch (e) {
                            TLog.printError("trycatch laodRummyPrefab,error", e);
                        }
                    }
                }
                else {
                    try {
                        ToolUtils.loadCommonPrefab(RummyDataManager.shared().gameOverPrefab, BundleNameDefined.bundle_rummy, "prefab/rummy_gameover", (e => {
                            if (sys.isObjectValid(e) && e.isValid) {
                                RummyDataManager.shared().gameOverPrefab = e;
                                let i = instantiate(RummyDataManager.shared().gameOverPrefab);
                                i.parent = this.mainRummy.pop_layer3;
                                this.mainRummy.gameEndView = i;
                                let s = i.getComponent("RummyGameOverAlert");
                                s.tid_key = this.tid_key;
                                s.updateInfo(0, m, this.mainRummy.onDealBtnAction.bind(this.mainRummy), t);
                                s.startShowAnim();
                                s.setLandscapeShow();
                                s.show_btn();
                                s.show_switch_btn(false);
                            }
                        }));
                    }
                    catch (e) {
                        TLog.printError("trycatch laodRummyPrefab,error", e);
                    }
                }
                ToolUtils.isObjValid(this.mainRummy.rummyGamePoolPoP) && this.mainRummy.rummyGamePoolPoP.setSiblingIndex(9999);
                ToolUtils.isObjValid(this.mainRummy.rummyGameManualSplit) && this.mainRummy.rummyGameManualSplit.setSiblingIndex(9998);
            }
            ToolUtils.isObjValid(n) && n && (n.destroy(), n = null);
        }
        catch (e) {
            TLog.printError("trycatch show_create_end_view,error:", e);
        }
    }
    resetGameOverState() {
        let e = RummyDataManager.shared().rummyInfos.get(this.tid_key);
        e.isInGameing = 0;
        e.isGameStarting = 0;
        e.isCanTouchCard = false;
        e.game_state = 0;
        e.game_server_state = 4;
        e.game_cd = 0;
        e.isGameOver = true;
        e.is_declare_status = false;
        e.close_cardnum = 0;
        e.hasFaPai = false;
        this.mainRummy._bIsShowWaitDeclare = false;
        this.mainRummy.isOpenQipai = false;
        this.mainRummy.finishType = -1;
        this.mainRummy.hasDeclare = false;
        this.mainRummy.isUpdateMyMoney = false;
    }
    resetGameOverUI(e = true) {
        this.mainRummy.cardsTs.resetView();
        this.hideHeadStatus();
        this.mainRummy.playerTs.showLoseScore(0, 0, true);
        let m = RummyDataManager.shared().rummyInfos.get(this.tid_key);
        (m.gameRummyType === RUMMY_GAME_TYPE.POINTS || m.gameRummyType == RUMMY_GAME_TYPE.MULTIPLE || this.mainRummy.checkIsPointsMatch()) && this.mainRummy.tipTs.hideWinEffect();
        Utils.shared().hideCommomDialog();
        Utils.shared().hideCommomDialog(this.mainRummy.pop_layer4);
        this.mainRummy.autoDropTs.hideAllLayer();
        this.mainRummy.tipTs.show_wait_declare(false);
        this.mainRummy.actionTs.changeOperateBgState(false);
        e && this.mainRummy.playerTs.stopPlayerTimer();
        this.mainRummy.playerTs.hidePaiNum();
        this.mainRummy.playerTs.setPaiDuiBgShow(false, true);
        this.mainRummy.changeQiPaiTableStatus(false);
        for (let e = 0; e < 6; e++) {
            this.mainRummy.playerTs.changePlayerZhuangState(false, e);
            this.mainRummy.playerTs.showDoubleState(e, 0, false);
        }
        this.mainRummy.actionTs.changeOpenCardStatus(false, this.mainRummy);
        this.mainRummy.actionTs.changeSwitchJokerStatus(false, this.mainRummy);
        ToolUtils.isObjValid(this.mainRummy.openCardNode) && (this.mainRummy.openCardNode.active = false);
        this.mainRummy.hideWinTipAlert();
        this.mainRummy.actionTs.changeDirectionBtnStatus(false);
        this.mainRummy.tipTs.showConfimTips("", "", false);
        this.mainRummy.tipTs.changePickTipsVisible(0, false);
        m.isClearCards = true;
    }
    startShowGameOverDelay(e, m) {
        if (this.tid_key = e, this.mainRummy.delayShowGameOver_action) {
            return;
        }
        let i = 1.5;
        null != m && m > 0 && (i = m);
        let a = RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType;
        return (a == RUMMY_GAME_TYPE.POINTS || a == RUMMY_GAME_TYPE.MULTIPLE || a == RUMMY_GAME_TYPE.PRIVATE || this.mainRummy.checkIsPointsMatch()) && this.mainRummy._gameOverMsg && (i = 0), a != RUMMY_GAME_TYPE.POOL && a != RUMMY_GAME_TYPE.PRI_POOL && a != RUMMY_GAME_TYPE.DEALS && a != RUMMY_GAME_TYPE.PRI_DEAL || this.mainRummy._gameOverMsg && 1 === ToolUtils.isSafeNumber(this.mainRummy._gameOverMsg.end_way) && (i = 0), this.mainRummy._bGameOverClosed ? (this.mainRummy.deleteGameOverDalay(), void (this.mainRummy._bIsShowWaitDeclare && this.mainRummy.tipTs.show_wait_declare(true))) : this.mainRummy._bIsWinnerAnimEnd ? (this.mainRummy.deleteGameOverDalay(), this.mainRummy._bIsWinnerAnimEnd = false, void (this.mainRummy.delayShowGameOver_action = TweenTool.delayAct(this.mainRummy.time_node, (() => {
            this.mainRummy._bIsWinnerAnimEnd = true;
            this.mainRummy.deleteGameOverDalay();
            RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType == RUMMY_GAME_TYPE.PRIVATE && RummyDataManager.shared().rummyInfos.get(this.tid_key).hasShowScanAlert || this.showEndView(this.tid_key);
        }), i, true))) : (this.mainRummy.deleteGameOverDalay(), void this.showEndView(this.tid_key));
    }
    showEndView(e) {
        if (this.tid_key = e, !this.mainRummy._gameOverMsg) {
            return;
        }
        let m = RummyDataManager.shared().rummyInfos.get(this.tid_key);
        if (ToolUtils.isObjValid(this.mainRummy.gameEndView)) {
            if (m.gameRummyType == RUMMY_GAME_TYPE.MATCH) {
                let e = this.mainRummy.gameEndView.getComponent("RummyPointsMatchOverAlert");
                this.mainRummy._bIsGameEnd ? (e.isShowEndView(true), e.show_btn()) : e.updateInfo(0, this.mainRummy._gameOverMsg, this.mainRummy.onDealBtnAction.bind(this.mainRummy));
            }
            else {
                let e = this.mainRummy.gameEndView.getComponent("RummyGameOverAlert");
                this.mainRummy._bIsGameEnd ? (e.isShowEndView(true), e.show_btn()) : e.updateInfo(0, this.mainRummy._gameOverMsg, this.mainRummy.onDealBtnAction.bind(this.mainRummy));
            }
        }
        else {
            this.mainRummy._bIsGameEnd ? this.show_create_end_view(this.tid_key, this.mainRummy._gameOverMsg, true) : this.show_create_end_view(this.tid_key, this.mainRummy._gameOverMsg);
        }
        if ((m.gameRummyType === RUMMY_GAME_TYPE.POINTS || m.gameRummyType == RUMMY_GAME_TYPE.MULTIPLE) && ToolUtils.isObjValid(this.mainRummy.gameEndView)) {
            this.mainRummy.gameEndView.getComponent("RummyGameOverAlert").checkEndFlag() && this.mainRummy.tipTs.hideWinEffect();
        }
    }
    reShowEndView(e) {
        if (this.tid_key = e, !this._gameEndMsg) {
            return;
        }
        let m = RummyDataManager.shared().rummyInfos.get(this.tid_key);
        if (ToolUtils.isObjValid(this.mainRummy.gameEndView)) {
            if (m.gameRummyType == RUMMY_GAME_TYPE.MATCH) {
                let e = this.mainRummy.gameEndView.getComponent("RummyPointsMatchOverAlert");
                this.mainRummy._bIsGameEnd ? (e.isShowEndView(true), e.show_btn()) : e.updateInfo(0, this._gameEndMsg, this.mainRummy.onDealBtnAction.bind(this.mainRummy));
            }
            else {
                let e = this.mainRummy.gameEndView.getComponent("RummyGameOverAlert");
                this.mainRummy._bIsGameEnd ? (e.isShowEndView(true), e.show_btn()) : e.updateInfo(0, this._gameEndMsg, this.mainRummy.onDealBtnAction.bind(this.mainRummy));
            }
        }
        else {
            this.mainRummy._bIsGameEnd ? this.show_create_end_view(this.tid_key, this._gameEndMsg, true) : this.show_create_end_view(this.tid_key, this._gameEndMsg);
        }
        if ((m.gameRummyType === RUMMY_GAME_TYPE.POINTS || m.gameRummyType == RUMMY_GAME_TYPE.MULTIPLE) && ToolUtils.isObjValid(this.mainRummy.gameEndView)) {
            this.mainRummy.gameEndView.getComponent("RummyGameOverAlert").checkEndFlag() && this.mainRummy.tipTs.hideWinEffect();
        }
    }
    dealGameEnd(e) {
        this.tid_key = e;
        this.mainRummy.isUpdateMyMoney = true;
        this.mainRummy.tipTs.changePickTipsVisible(0, false);
        this.mainRummy.tipTs.showMatchWaitTip(false);
        this.mainRummy.cardsTs.showMoPaiTisAnim(false, false);
        this.mainRummy.playerTs.showLoseScore(0, 0, true);
        this.mainRummy.playerTs.hideAllEasyGameLight();
        let m = RummyDataManager.shared().rummyInfos.get(this.tid_key);
        for (let e = 0; e < 6; e++) {
            this.mainRummy.playerTs.showLoseScore(e, 0, false);
            m.gameRummyType == RUMMY_GAME_TYPE.POOL || this.mainRummy.playerTs.stopPlayerTimerByPos(e);
            let i = this.mainRummy.getPosBySeatid(e);
            if (m.gameRummyType == RUMMY_GAME_TYPE.POOL || m.gameRummyType == RUMMY_GAME_TYPE.PRI_POOL || m.gameRummyType == RUMMY_GAME_TYPE.DEALS || m.gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL || m.gameRummyType == RUMMY_GAME_TYPE.PRIVATE) {
                let i = m.playerModels[e];
                9 != i.status && 11 != i.status && (m.gameRummyType == RUMMY_GAME_TYPE.POOL || (m.gameRummyType, RUMMY_GAME_TYPE.PRI_POOL));
            }
            else {
                this.mainRummy.playerTs.changeAwayStateStatus(i, false);
            }
            let a = m.playerModels[e];
            a && a.isShow && a.uid > 0 && (m.gameRummyType != RUMMY_GAME_TYPE.PRIVATE && m.gameRummyType != RUMMY_GAME_TYPE.PRI_POOL && m.gameRummyType != RUMMY_GAME_TYPE.PRI_DEAL && m.gameRummyType != RUMMY_GAME_TYPE.MATCH || (8 == a.status ? this.mainRummy.playerTs.changeAwayStateStatus(i, true, RUMMY_PLAYER_STATE_TYPE.AWAY) : 7 == a.status && this.mainRummy.playerTs.changeAwayStateStatus(i, true, RUMMY_PLAYER_STATE_TYPE.READY)));
        }
        this.mainRummy.dealPrivateTableTips();
    }
    show_deals_rummy_pop(e, m, i, a) {
    }
    clean_up_the_desk(e, m) {
        this.tid_key = e;
        let i = RummyDataManager.shared().rummyInfos.get(this.tid_key);
        i.end_game_countdown = 0;
        m || (ToolUtils.isObjValid(this.mainRummy.rummyGamePoolPoP) && this.mainRummy.rummyGamePoolPoP.destroy(), ToolUtils.isObjValid(this.mainRummy.poolScoreboardView) && this.mainRummy.poolScoreboardView.destroy(), this.mainRummy.removeTotalSettlementView());
        this.mainRummy.removeGameOverView();
        this.mainRummy.playerTs.resetAllCard();
        this.mainRummy.tipTs.resetFamaToReadyModel();
        this.mainRummy.tipTs.changeTuoguanVisible(false);
        this.mainRummy.autoDropTs.isshowAutoDropBtn(false, this.tid_key);
        this.mainRummy.autoDropTs.hideAllLayer();
        this.clearCards();
        this.mainRummy.tipTs.show_wait_declare(false);
        this.mainRummy._bIsShowWaitDeclare = false;
        this.mainRummy.isOpenQipai = false;
        this.mainRummy.finishType = -1;
        this.mainRummy.hasDeclare = false;
        this.mainRummy.isUpdateMyMoney = false;
        this.mainRummy.actionTs.changeOperateBgState(false);
        this.mainRummy.playerTs.stopPlayerTimer();
        this.mainRummy.playerTs.hidePaiNum();
        this.mainRummy.tipTs.showConfimTips("", "", false);
        this.mainRummy.actionTs.changeOpenCardStatus(false, this.mainRummy);
        this.mainRummy.actionTs.changeSwitchJokerStatus(false, this.mainRummy);
        ToolUtils.isObjValid(this.mainRummy.openCardNode) && (this.mainRummy.openCardNode.active = false);
        this.mainRummy.hideWinTipAlert();
        this.mainRummy.actionTs.changeDirectionBtnStatus(false);
        i.isInGameing = 0;
        i.isCanTouchCard = false;
        i.game_state = 0;
        i.game_server_state = 4;
        i.game_cd = 0;
        i.isGameOver = true;
        i.racing_time = 0;
        i.bIsHasHu = false;
        this.mainRummy.tipTs.changePickTipsVisible(0, false);
        this.mainRummy.cardsTs.playArrowAnim(RummyCardConstant.arrowAnimType.mopai, false);
        this.mainRummy.cardsTs.playArrowAnim(RummyCardConstant.arrowAnimType.finish, false);
        this.mainRummy.cardsTs.playArrowAnim(RummyCardConstant.arrowAnimType.qipai, false);
        this.mainRummy.winPos = -1;
        this.mainRummy.isUpdateMyMoney = true;
        this.mainRummy.tipTs.changePickTipsVisible(0, false);
        this.mainRummy.cardsTs.showMoPaiTisAnim(false, false);
        this.mainRummy.playerTs.showLoseScore(0, 0, true);
        this.mainRummy.cardsTs.showDropCardsZheZhao(false);
        this.mainRummy.tipTs.showMatchWaitTip(false);
    }
    clearCards() {
        let e = RummyDataManager.shared().rummyInfos.get(this.tid_key);
        null != e && (e.gameRummyType == RUMMY_GAME_TYPE.POOL || e.gameRummyType == RUMMY_GAME_TYPE.PRI_POOL || e.gameRummyType == RUMMY_GAME_TYPE.DEALS || e.gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL || e.gameRummyType == RUMMY_GAME_TYPE.PRIVATE || this.mainRummy.cardsTs.resetView());
    }
    gameEendreset(e) {
        this.tid_key = e;
        this.clearCards();
        this.mainRummy.tipTs.show_wait_declare(false);
        this.mainRummy._bIsShowWaitDeclare = false;
        this.mainRummy.isOpenQipai = false;
        this.mainRummy.finishType = -1;
        this.mainRummy.hasDeclare = false;
        this.mainRummy.isUpdateMyMoney = false;
        this.mainRummy.actionTs.changeOperateBgState(false);
        this.mainRummy.actionTs.changeCenterFinishBtnStatus(false);
        this.mainRummy.playerTs.stopPlayerTimer();
        this.mainRummy.playerTs.hidePaiNum();
        this.mainRummy.tipTs.showConfimTips("", "", false);
        this.mainRummy.actionTs.changeOpenCardStatus(false, this.mainRummy);
        this.mainRummy.actionTs.changeSwitchJokerStatus(false, this.mainRummy);
        ToolUtils.isObjValid(this.mainRummy.openCardNode) && (this.mainRummy.openCardNode.active = false);
        this.mainRummy.hideWinTipAlert();
        this.mainRummy.actionTs.changeDirectionBtnStatus(false);
        let m = RummyDataManager.shared().rummyInfos.get(this.tid_key);
        m.isInGameing = 0;
        m.isCanTouchCard = false;
        m.game_state = 0;
        m.game_server_state = 4;
        m.game_cd = 0;
        m.isGameOver = true;
        m.is_declare_status = false;
        this.mainRummy.tipTs.changePickTipsVisible(0, false);
        this.mainRummy.cardsTs.playArrowAnim(RummyCardConstant.arrowAnimType.mopai, false);
        this.mainRummy.cardsTs.playArrowAnim(RummyCardConstant.arrowAnimType.finish, false);
        this.mainRummy.cardsTs.playArrowAnim(RummyCardConstant.arrowAnimType.qipai, false);
        this.mainRummy.winPos = -1;
        this.mainRummy.isUpdateMyMoney = true;
        RummyDataManager.shared().rummyInfos.get(this.tid_key).isInGameing = 0;
        this.mainRummy.tipTs.changePickTipsVisible(0, false);
        this.mainRummy.tipTs.showMatchWaitTip(false);
        this.mainRummy.cardsTs.showMoPaiTisAnim(false, false);
        this.mainRummy.playerTs.showLoseScore(0, 0, true);
        this.mainRummy.tipTs.changeTuoguanVisible(false);
    }
    handler_server_pool_all_record_return(e, m) {
        if (this.tid_key = e, this.tid_key !== (m.tid_key || "")) {
            return;
        }
        ToolUtils.isObjValid(this.mainRummy.rummyGamePoolPoP) && this.mainRummy.rummyGamePoolPoP.getComponent(RummyGamePoolPop).gameControllerRemove();
        ToolUtils.isObjValid(this.mainRummy.rummyGameManualSplit) && this.mainRummy.rummyGameManualSplit.destroy();
        RummyDataManager.shared().rummyInfos.get(this.tid_key).isInGameing = 0;
        for (let e = 0; e < 6; e++) {
            this.mainRummy.playerTs.stopPlayerTimerByPos(e);
        }
        if (Array.isArray(m.settleinfo)) {
            let e, i;
            for (let a = 0, t = m.settleinfo.length; a < t; a++) {
                e = m.settleinfo[a].seatid;
                i = m.settleinfo[a].total_score;
                let t = this.mainRummy.getPosBySeatid(e);
                this.mainRummy.playerTs.setPoolScore(t, i);
                this.mainRummy.updateSeatScore(e, i);
            }
        }
        this.mainRummy.gameEendreset();
        RummyDataManager.shared().rummyInfos.get(this.tid_key).pool_money = 0;
        ToolUtils.isObjValid(this.mainRummy.poolScoreboardView) && this.mainRummy.poolScoreboardView.destroy();
        1 == m.end_way ? (this.mainRummy.removeGameOverView(), this.mainRummy.actionTs.hideReadyBtn(), this.mainRummy._bIsShowReady = false, this.mainRummy.tipTs.showGameTipsText(0, 0, ""), ToolUtils.isObjValid(this.mainRummy.RummyTotalSettlementNode) ? this.mainRummy.RummyTotalSettlementNode.getComponent(RummyTotalSettlement).initView(m, this.mainRummy, this.tid_key) : ToolUtils.loadCommonPrefab(RummyDataManager.shared().RummyTotalSettlementPrefab, BundleNameDefined.bundle_rummy, "prefab/GameRummy_TotalSettlement", (e => {
            if (sys.isObjectValid(e) && e.isValid) {
                RummyDataManager.shared().RummyTotalSettlementPrefab = e;
                let i = instantiate(RummyDataManager.shared().RummyTotalSettlementPrefab);
                i.parent = this.mainRummy.pop_layer4;
                i.getComponent(RummyTotalSettlement).initView(m, this.mainRummy, this.tid_key);
                this.mainRummy.RummyTotalSettlementNode = i;
            }
        })), TweenTool.delayAct(this.mainRummy.time_node, (() => {
            RummyDataManager.shared().rummyInfos.get(this.tid_key).pool_rummy_all_end_data = null;
            RummyDataManager.shared().rummyInfos.get(this.tid_key).pool_rummy_all_end_data = m;
        }), 0.01, true), ToolUtils.isObjValid(this.mainRummy.rummyGamePoolPoP) && this.mainRummy.rummyGamePoolPoP.setSiblingIndex(20)) : (this.mainRummy.removeTotalSettlementView(), TweenTool.delayAct(this.mainRummy.time_node, (() => {
            RummyDataManager.shared().rummyInfos.get(this.tid_key).pool_rummy_all_end_data = null;
            RummyDataManager.shared().rummyInfos.get(this.tid_key).pool_rummy_all_end_data = m;
        }), 0.01, true));
        this.mainRummy.actionTs.changeRecodeBtnStatus(false);
    }
    hideHeadStatus() {
        let e = RummyDataManager.shared().rummyInfos.get(this.tid_key);
        for (let m = 0; m <= 5; m++) {
            if (sys.isObjectValid(e.playerModels) && Array.isArray(e.playerModels) && e.playerModels.length > m) {
                let i = e.playerModels[m], a = this.mainRummy.getPosBySeatid(m);
                i && (e.gameRummyType == RUMMY_GAME_TYPE.POOL || e.gameRummyType == RUMMY_GAME_TYPE.PRI_POOL || e.gameRummyType == RUMMY_GAME_TYPE.DEALS || e.gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL || e.gameRummyType == RUMMY_GAME_TYPE.POINTS || e.gameRummyType == RUMMY_GAME_TYPE.PRIVATE || this.mainRummy.checkIsPointsMatch()) && (1 != i.status && 2 != i.status && 3 != i.status && 5 != i.status || 1 !== i.decision && this.mainRummy.playerTs.changeAwayStateStatus(a, false), e.gameRummyType != RUMMY_GAME_TYPE.PRI_DEAL && e.gameRummyType != RUMMY_GAME_TYPE.PRI_POOL || 1 == e.is_game_all_end && (this.mainRummy.playerTs.setPoolScoreState(a, false), this.mainRummy.playerTs.setDecisionStateVisible(a, false), this.mainRummy.playerTs.setPoolManualState(a, false)));
            }
        }
    }
}
