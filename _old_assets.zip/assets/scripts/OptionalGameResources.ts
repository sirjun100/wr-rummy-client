import { assetManager, BufferAsset, native, sys } from 'cc';

/** Download and verify an optional game's release before resolving engine assets.
 * Asset UUIDs can be shared with a loaded local bundle; loadDir alone therefore
 * cannot prove that the optional game's files have reached the persistent cache.
 */
export default class OptionalGameResources {
    static async prepare(bundleName: string, progress: (value: number) => void): Promise<void> {
        if (!sys.isNative || !assetManager.downloader.remoteBundles.includes(bundleName)) return;
        const manifest = JSON.parse(native.fileUtils.getStringFromFile('src/optional-game-resources.json'));
        if (manifest.server !== assetManager.downloader.remoteServerAddress) {
            throw new Error('Optional game release does not match this APK');
        }
        const files = manifest.files.filter((file) => file.path.startsWith(bundleName + '/'));
        if (!files.length) throw new Error('Missing optional game manifest: ' + bundleName);
        const cache = assetManager.cacheManager;
        cache.makeBundleFolder(bundleName);
        const total = files.reduce((sum, file) => sum + file.bytes, 0);
        let completed = 0, next = 0, failure: Error | null = null;
        const verify = async (file, reload: boolean) => {
            const url = manifest.server + 'remote/' + file.path;
            const resource = await new Promise<BufferAsset>((resolve, reject) => {
                // The public load pipeline clears temporary download/parse entries.
                // A direct downloader call would leave binary paths cached under URLs
                // later needed as parsed JSON, and would bypass checksum retries.
                assetManager.loadRemote<BufferAsset>(url, {
                    ext: '.bin', cacheAsset: false, reloadAsset: true,
                    cacheEnabled: true, reload, __cacheBundleRoot__: bundleName,
                }, (error, result) => error ? reject(error) : resolve(result));
            });
            const bytes = new Uint8Array(resource.buffer());
            resource.destroy();
            const words: number[] = [];
            for (let i = 0; i < bytes.length; i++) {
                words[i >>> 2] = (words[i >>> 2] || 0) | (bytes[i] << (24 - (i % 4) * 8));
            }
            const crypto = (globalThis as any).CryptoJS;
            if (!crypto?.SHA256) throw new Error('Resource integrity verifier unavailable');
            const digest = crypto.SHA256(crypto.lib.WordArray.create(words, bytes.length)).toString();
            if (bytes.length !== file.bytes || digest !== file.sha256) {
                cache.removeCache(url);
                throw new Error('Optional resource checksum failed: ' + file.path);
            }
        };
        // Wait for all workers even after failure, so a retry cannot overlap a
        // previous operation that still writes files into the same cache.
        await Promise.all(Array.from({ length: Math.min(4, files.length) }, async () => {
            while (!failure && next < files.length) {
                const file = files[next++];
                try {
                    try { await verify(file, false); }
                    catch (_) { await verify(file, true); }
                    completed += file.bytes;
                    progress(completed / total);
                } catch (error) {
                    failure = error as Error;
                }
            }
        }));
        if (failure) throw failure;
    }
}
