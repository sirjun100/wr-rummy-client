// @ts-nocheck
// Recovered from index.js:575
import { _decorator, Button, color, instantiate, Label, Layout, Node, size, Sprite, SpriteFrame, sys, UITransform, v3, view, Widget } from "cc";
import SoundManager from "./SoundManager";
import PushCenter from "./PushCenter";
import { TLog } from "./TLog";
import Utils from "./Utils";
import User from "./User";
import i18nMgr from "./i18nMgr";
import BaseLayer from "./BaseLayer";
import GameConfig from "./GameConfig";
import PushEvent from "./PushEvent";
import TweenTool from "./TweenTool";
import SportCricket_Manager from "./SportCricket_Manager";
import { ToolUtils } from "./ToolUtils";
import PhpReportDefined from "./PhpReportDefined";
const { ccclass, property } = _decorator;
@ccclass("SportCricket_PlayerMain")
export class SportCricket_PlayerMain extends BaseLayer {
    public TAG: string = "SportCricket_PlayerMain";
    @property(Node)
    public rootNode: Node = null;
    @property(Node)
    public goldNode: Node = null;
    @property(Node)
    public dealBtnNode: Node = null;
    @property(Node)
    public topNode: Node = null;
    @property(Node)
    public detailsNode: Node = null;
    @property(Node)
    public contentNode: Node = null;
    @property(Node)
    public tourRootNode: Node = null;
    @property(Node)
    public tourPointsRootNode: Node = null;
    @property([SpriteFrame])
    public teamBgImgs: SpriteFrame[] = [];
    @property([SpriteFrame])
    public btnBgImgs: SpriteFrame[] = [];
    @property(Node)
    public team_mobanView: Node = null;
    @property(Node)
    public tour_mobanView: Node = null;
    @property([SpriteFrame])
    public progressImgs: SpriteFrame[] = [];
    public _closed: boolean = false;
    public bShowPushAnim: boolean = true;
    public _lastClick: number = 0;
    public _sourceData: any = null;
    public _isSendMsg: boolean = false;
    public taskAwardIconMap: Map = new Map;
    public _match_id: number = 0;
    public _player_source: any = null;
    public _select_player_soucrce: any = null;
    public _team_id: number = 0;
    public _player_id: number = 0;
    public _source: any = null;
    public lastClick: number = 0;
    public _fromType: number = 0;
    public _match_state: number = 1;
    public _hasChooseBackUp: number = 0;
    public _lastNode: any = null;
    public _posY: number = 0;
    public _viewSize: number = 900;
    public _call: any = null;
    public _playerInfo: any = null;
    public _select_status: number = 0;
    public _teamAPlayerNum: number = 0;
    public _teamBPlayerNum: number = 0;
    public _selectPlayerNum: number = 0;
    public _selectPlayerIds: any[] = [];
    onLoad() {
        PushCenter.shared().addListener(GameConfig.Update_Money, (t => {
            try {
                ToolUtils.isObjValid(this.node) && this.updateGold(t);
            }
            catch (t) {
                TLog.printError(this.TAG, GameConfig.Update_Money, t);
            }
        }), this);
        PushCenter.shared().addListener(PushEvent.CloseYes11CreateTeam, (t => {
            try {
                ToolUtils.isObjValid(this.node) && this.node.destroy();
            }
            catch (t) {
                TLog.printError(this.TAG, PushEvent.CloseYes11CreateTeam, t);
            }
        }), this);
        PushCenter.shared().addListener(PushEvent.commentDownloaderImg, (t => {
            try {
                if (ToolUtils.isObjValid(this.node) && this.taskAwardIconMap.size > 0) {
                    for (const [e, i] of this.taskAwardIconMap) {
                        i == t && sys.isObjectValid(e) && ("player_icon" == e.name ? Utils.shared().updateNetImage(e, t, size(132, 132)) : Utils.shared().updateNetImage(e, t, size(40, 40)));
                    }
                }
            }
            catch (t) {
                TLog.printError(this.TAG, PushEvent.commentDownloaderImg, t);
            }
        }), this);
        this.fitLuckyTheme();
    }
    fitLuckyTheme() {
        0 != GameConfig.NATIVE_GAME_APP_TYPE && (this.rootNode.getChildByName("top_node").getChildByName("top_bg").getComponent(Sprite).color = color(12, 26, 60, 255), this.goldNode.getChildByName("coin").getComponent(Label).color = color(251, 220, 0, 255), this.rootNode.getChildByName("top_node").getChildByName("lefttime_tip").getComponent(Label).color = color(153, 164, 221, 255), this.rootNode.getChildByName("top_node").getChildByName("player").getComponent(Label).color = color(153, 164, 221, 255));
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().removeListenersByTag(this);
        this.unscheduleAllCallbacks();
    }
    init(t) {
        sys.isObjectValid(t) && sys.isObjectValid(t.match_id) && (this._match_id = t.match_id);
        sys.isObjectValid(t) && sys.isObjectValid(t.player_source) && (this._player_source = t.player_source);
        sys.isObjectValid(t) && sys.isObjectValid(t.select_player_soucrce) && (this._select_player_soucrce = t.select_player_soucrce);
        sys.isObjectValid(t) && sys.isObjectValid(t.source) && (this._source = { ...t.source });
        sys.isObjectValid(t) && sys.isObjectValid(t.fromType) && (this._fromType = t.fromType);
        sys.isObjectValid(t) && sys.isObjectValid(t.team_id) && (this._team_id = t.team_id);
        sys.isObjectValid(t) && sys.isObjectValid(t.call) && (this._call = t.call);
        sys.isObjectValid(t) && sys.isObjectValid(t.lastNode) && (this._lastNode = t.lastNode);
        sys.isObjectValid(t) && sys.isObjectValid(t.select_status) && (this._select_status = t.select_status);
        sys.isObjectValid(t) && sys.isObjectValid(t.playerInfo) && (this._playerInfo = t.playerInfo);
        sys.isObjectValid(t) && sys.isObjectValid(t.player_id) && (this._player_id = t.player_id);
    }
    start() {
        super.start();
        this.initView();
        this.bShowPushAnim && ToolUtils.showPushAnim(this.node, 0, (() => {
            this.refreshView();
            sys.isObjectValid(this._lastNode) && (this._lastNode.active = false);
        }));
        this.updateGold(User.shared().data.money);
    }
    updateGold(t) {
        let e = this.goldNode.getChildByName("coin");
        null != t && e && (e.getComponent(Label).string = ToolUtils.parse_double(t));
    }
    updateSelectPlayerNum() {
        this.topNode.getChildByName("pnum").getComponent(Label).string = String(this._selectPlayerNum) + "/11";
    }
    updateTeamASelectPlayerNum() {
        this.topNode.getChildByName("team_num0").getComponent(Label).string = String(this._teamAPlayerNum);
    }
    updateTeamBSelectPlayerNum() {
        this.topNode.getChildByName("team_num1").getComponent(Label).string = String(this._teamBPlayerNum);
    }
    updateProgress() {
        for (let t = 0; t < 11; t++) {
            t < this._selectPlayerNum ? this.topNode.getChildByName("progress" + t).getComponent(Sprite).spriteFrame = 0 == t ? this.progressImgs[3] : 10 == t ? this.progressImgs[2] : this.progressImgs[0] : this.topNode.getChildByName("progress" + t).getComponent(Sprite).spriteFrame = 0 == t ? this.progressImgs[5] : 10 == t ? this.progressImgs[4] : this.progressImgs[1];
        }
        if (this.topNode.getChildByName("progress_wz0").getComponent(Label).string = String(this._selectPlayerNum), this.topNode.getChildByName("progress_wz0").active = this._selectPlayerNum > 0, this._selectPlayerNum > 0) {
            let t = this.topNode.getChildByName("progress" + (this._selectPlayerNum - 1)).getPosition();
            this.topNode.getChildByName("progress_wz0").setPosition(t);
        }
        this.topNode.getChildByName("progress_wz1").active = 11 != this._selectPlayerNum;
        this.topNode.getChildByName("progress_wz1").active = false;
        this.topNode.getChildByName("progress_wz0").active = false;
    }
    updateContestDetails() {
        this._teamAPlayerNum = 0;
        this._teamBPlayerNum = 0;
        this._selectPlayerNum = 0;
        this.filterSelectPlayer();
        this._selectPlayerNum = this._selectPlayerIds.length;
        this.updateSelectPlayerNum();
        this.updateTeamASelectPlayerNum();
        this.updateTeamBSelectPlayerNum();
        this.updateProgress();
    }
    filterSelectPlayer() {
        if (this._selectPlayerIds = [], this._teamAPlayerNum = 0, this._teamBPlayerNum = 0, sys.isObjectValid(this._select_player_soucrce)) {
            if (sys.isObjectValid(this._select_player_soucrce.wk) && this._select_player_soucrce.wk.length > 0) {
                for (let t = 0; t < this._select_player_soucrce.wk.length; t++) {
                    this._select_player_soucrce.wk[t].role = "WK";
                    1 == this._select_player_soucrce.wk[t].select_status && (this._selectPlayerIds.push(this._select_player_soucrce.wk[t].player_id), this._select_player_soucrce.wk[t].team_id == this._select_player_soucrce.teama.team_id ? this._teamAPlayerNum += 1 : this._teamBPlayerNum += 1);
                }
            }
            if (sys.isObjectValid(this._select_player_soucrce.bat) && this._select_player_soucrce.bat.length > 0) {
                for (let t = 0; t < this._select_player_soucrce.bat.length; t++) {
                    this._select_player_soucrce.bat[t].role = "BAT";
                    1 == this._select_player_soucrce.bat[t].select_status && (this._selectPlayerIds.push(this._select_player_soucrce.bat[t].player_id), this._select_player_soucrce.bat[t].team_id == this._select_player_soucrce.teama.team_id ? this._teamAPlayerNum += 1 : this._teamBPlayerNum += 1);
                }
            }
            if (sys.isObjectValid(this._select_player_soucrce.ar) && this._select_player_soucrce.ar.length > 0) {
                for (let t = 0; t < this._select_player_soucrce.ar.length; t++) {
                    this._select_player_soucrce.ar[t].role = "AR";
                    1 == this._select_player_soucrce.ar[t].select_status && (this._selectPlayerIds.push(this._select_player_soucrce.ar[t].player_id), this._select_player_soucrce.ar[t].team_id == this._select_player_soucrce.teama.team_id ? this._teamAPlayerNum += 1 : this._teamBPlayerNum += 1);
                }
            }
            if (sys.isObjectValid(this._select_player_soucrce.bowl) && this._select_player_soucrce.bowl.length > 0) {
                for (let t = 0; t < this._select_player_soucrce.bowl.length; t++) {
                    this._select_player_soucrce.bowl[t].role = "BOWL";
                    1 == this._select_player_soucrce.bowl[t].select_status && (this._selectPlayerIds.push(this._select_player_soucrce.bowl[t].player_id), this._select_player_soucrce.bowl[t].team_id == this._select_player_soucrce.teama.team_id ? this._teamAPlayerNum += 1 : this._teamBPlayerNum += 1);
                }
            }
        }
    }
    refreshView() {
        this._viewSize = 404;
        this._posY = -404;
        this.updateInTeamView();
        this.tourPointsRootNode.setPosition(v3(0, this._posY));
        this._viewSize += 134;
        this.updateTourListView();
        this.contentNode.getComponent(UITransform).contentSize = size(720, this._viewSize);
    }
    updateInTeamView() {
        this.tourRootNode.getComponent(UITransform).contentSize = size(720, 404);
        let t = 0;
        if (sys.isObjectValid(this._player_source.join_team) && this._player_source.join_team.length > 0) {
            this.tourRootNode.getChildByName("notip").active = false;
            let e = this.tourRootNode.getChildByName("team_layout"), i = this._player_source.join_team.length;
            for (let t = 0; t < i; t++) {
                let i = instantiate(this.team_mobanView);
                i.active = true;
                i.getChildByName("wz").getComponent(Label).string = this._player_source.join_team[t].name;
                e.addChild(i);
            }
            e.getComponent(Layout).updateLayout();
            t = e.getComponent(UITransform).contentSize.height - 70;
            i <= 3 && (t = 0);
            this.tourRootNode.getComponent(UITransform).contentSize = size(720, 404 + t);
            this.tourRootNode.getChildByName("fenge2").setPosition(v3(0, 10 - (404 + t)));
            this._viewSize += t;
            this._posY = -(404 + t);
        }
        else {
            this.tourRootNode.getChildByName("notip").active = true;
        }
    }
    updateTourListView() {
        let t = -133, e = 0;
        if (sys.isObjectValid(this._player_source.join_match) && Array.isArray(this._player_source.join_match)) {
            e = this._player_source.join_match.length;
            for (let e = 0; e < this._player_source.join_match.length; e++) {
                let i = instantiate(this.tour_mobanView);
                if (i.active = true, i.setPosition(v3(0, t)), t -= 100, this._viewSize += 100, this.tourPointsRootNode.addChild(i), sys.isObjectValid(this._player_source.join_match[e].match_short_title) && (i.getChildByName("vs_wz").getComponent(Label).string = this._player_source.join_match[e].match_short_title), sys.isObjectValid(this._player_source.join_match[e].timestamp_start) && (i.getChildByName("date_wz").getComponent(Label).string = this._player_source.join_match[e].timestamp_start), sys.isObjectValid(this._player_source.join_match[e].base_point) && (i.getChildByName("point_wz").getComponent(Label).string = this._player_source.join_match[e].base_point), i.getChildByName("arrow_btn").getComponent(Button).clickEvents[0].customEventData = ToolUtils.toJsonString(this._player_source.join_match[e]), sys.isObjectValid(this._player_source.join_match[e].is_best) && 1 == this._player_source.join_match[e].is_best) {
                    i.getChildByName("vs_wz").getComponent(Label).updateRenderData(true);
                    let t = i.getChildByName("vs_wz").getComponent(UITransform).contentSize.width;
                    i.getChildByName("logo").active = true;
                    i.getChildByName("logo").setPosition(v3(-323.598 + t + 10, -30));
                }
                else {
                    i.getChildByName("logo").active = false;
                }
            }
        }
        0 == e ? (this.tourPointsRootNode.getChildByName("date_title").active = false, this.tourPointsRootNode.getChildByName("line").active = false, this.tourPointsRootNode.getChildByName("points_title").active = false, this.tourPointsRootNode.getChildByName("notip_wz").active = true, this.tourPointsRootNode.getChildByName("notip_ico").active = true) : (this.tourPointsRootNode.getChildByName("date_title").active = true, this.tourPointsRootNode.getChildByName("line").active = true, this.tourPointsRootNode.getChildByName("points_title").active = true, this.tourPointsRootNode.getChildByName("notip_wz").active = false, this.tourPointsRootNode.getChildByName("notip_ico").active = false);
    }
    updateNextButtonStatus() {
        0 != this._fromType && 1 != this._fromType || (0 == this._select_status ? (this.dealBtnNode.getComponent(Sprite).spriteFrame = this.btnBgImgs[0], this.dealBtnNode.getComponent(Sprite).color = color(255, 255, 255), this.dealBtnNode.getChildByName("wz").getComponent(Label).color = color(255, 255, 255), this.dealBtnNode.getChildByName("wz").getComponent(Label).string = "ADD PLAYER", this.dealBtnNode.getComponent(Button).interactable = true) : 1 == this._select_status ? (this.dealBtnNode.getComponent(Sprite).spriteFrame = this.btnBgImgs[2], this.dealBtnNode.getComponent(Sprite).color = color(58, 115, 209), this.dealBtnNode.getChildByName("wz").getComponent(Label).color = color(58, 115, 209), this.dealBtnNode.getChildByName("wz").getComponent(Label).string = "REMOVE PLAYER", this.dealBtnNode.getComponent(Button).interactable = true) : -1 == this._select_status && (this.dealBtnNode.getComponent(Sprite).spriteFrame = this.btnBgImgs[1], this.dealBtnNode.getComponent(Sprite).color = color(255, 255, 255), this.dealBtnNode.getChildByName("wz").getComponent(Label).color = color(255, 255, 255), this.dealBtnNode.getChildByName("wz").getComponent(Label).string = "ADD PLAYER", this.dealBtnNode.getComponent(Button).interactable = true));
    }
    onCloseButtonClick(t, e) {
        if (SoundManager.shared().playFx("click"), "back_btn" == e) {
            if (this._closed) {
                return;
            }
            this.onBackView();
        }
    }
    initView() {
        if (this.fitScreen(), this.updateContestDetails(), sys.isObjectValid(this._source)) {
            let t = this._source.teama, e = this._source.teamb;
            sys.isObjectValid(t.short_name) && t.short_name.length > 0 && (this.topNode.getChildByName("team_short_name0").getComponent(Label).string = t.short_name);
            sys.isObjectValid(e.short_name) && e.short_name.length > 0 && (this.topNode.getChildByName("team_short_name1").getComponent(Label).string = e.short_name);
            sys.isObjectValid(t.thumb_url) && t.thumb_url.length > 0 && (this.taskAwardIconMap.set(this.topNode.getChildByName("team_icon0"), t.thumb_url), Utils.shared().updateNetImage(this.topNode.getChildByName("team_icon0"), t.thumb_url, size(76, 76)));
            sys.isObjectValid(e.thumb_url) && e.thumb_url.length > 0 && (this.taskAwardIconMap.set(this.topNode.getChildByName("team_icon1"), e.thumb_url), Utils.shared().updateNetImage(this.topNode.getChildByName("team_icon1"), e.thumb_url, size(76, 76)));
            let i = this.topNode.getChildByName("lefttime");
            i.getComponent(Label).string = Utils.shared().parseCountDown(this._source.time_left);
            sys.isObjectValid(this._source.status) && (this._match_state = this._source.status);
            0 == this._source.time_left && 1 == this._source.status ? (i.getComponent(Label).string = this._source.start_day, sys.isObjectValid(this._source.is_current_day) && 1 == Number(this._source.is_current_day) && (this._source.status = 3, i.getComponent(Label).string = "Live")) : 1 == this._source.status ? TweenTool.myschedule(i, 1, (() => {
                ToolUtils.isObjValid(this.node) && (this._source.time_left > 0 ? i.getComponent(Label).string = Utils.shared().parseCountDown(this._source.time_left) : (this._source.status = 3, i.getComponent(Label).string = "Live", TweenTool.stopNodeAction(i)));
            })) : 3 == this._source.status ? (TweenTool.stopNodeAction(i), i.getComponent(Label).string = "Live") : 4 == this._source.status && (TweenTool.stopNodeAction(i), i.getComponent(Label).string = "Cancel");
            PushCenter.shared().addListener(PushEvent.UpdateYes11CurMatchLeftTime, (t => {
                try {
                    ToolUtils.isObjValid(this.node) && t.match_id == this._match_id && (this._source.time_left = t.time_left, this._source.is_current_day = t.is_current_day, this._match_state = t.status, 3 == t.status ? (TweenTool.stopNodeAction(i), i.getComponent(Label).string = "Live") : 4 == t.status && (TweenTool.stopNodeAction(i), i.getComponent(Label).string = "Cancel"));
                }
                catch (t) {
                    TLog.printError(this.TAG, PushEvent.UpdateYes11CurMatchLeftTime, t);
                }
            }), this);
        }
        this.updateStaticView();
        this.updateNextButtonStatus();
    }
    updateStaticView() {
        if (!sys.isObjectValid(this._player_source)) {
            return;
        }
        if (sys.isObjectValid(this._player_source.name) && (this.detailsNode.getChildByName("name").getComponent(Label).string = this._player_source.name), sys.isObjectValid(this._player_source.playing_role) && (this.detailsNode.getChildByName("role").getComponent(Label).string = this._player_source.playing_role, this.detailsNode.getChildByName("role").getComponent(Label).updateRenderData(true)), sys.isObjectValid(this._player_source.style)) {
            this.detailsNode.getChildByName("style_tip").getComponent(Label).string = this._player_source.style;
            let t = this.detailsNode.getChildByName("role").getComponent(UITransform).contentSize.width, e = this.detailsNode.getChildByName("role").position.x;
            this.detailsNode.getChildByName("style_tip").setPosition(v3(e + t + 20, -99.253));
        }
        sys.isObjectValid(this._player_source.thumb_url) && this._player_source.thumb_url.length > 0 && (this.taskAwardIconMap.set(this.detailsNode.getChildByName("player_icon"), this._player_source.thumb_url), Utils.shared().updateNetImage(this.detailsNode.getChildByName("player_icon"), this._player_source.thumb_url, size(132, 132)));
        sys.isObjectValid(this._player_source.born_nation) && (this.detailsNode.getChildByName("feb_style").getComponent(Label).string = this._player_source.born_nation);
        sys.isObjectValid(this._player_source.join_last_match) && (this.detailsNode.getChildByName("state_tip").active = 1 == this._player_source.join_last_match);
        this.detailsNode.getChildByName("team_bg").getChildByName("wz").getComponent(Label).string = this._player_source.team.short_name;
        this.detailsNode.getChildByName("team_bg").getChildByName("wz").getComponent(Label).updateRenderData(true);
        let t = this.detailsNode.getChildByName("team_bg").getChildByName("wz").getComponent(UITransform).width;
        t > 46 && (this.detailsNode.getChildByName("team_bg").getComponent(UITransform).contentSize = size(t + 10, 24));
        this._player_source.team.team_id == this._source.teama.team_id ? (this.detailsNode.getChildByName("team_bg").getComponent(Sprite).spriteFrame = this.teamBgImgs[0], this.detailsNode.getChildByName("team_bg").getChildByName("wz").getComponent(Label).color = color(255, 255, 255)) : (this.detailsNode.getChildByName("team_bg").getComponent(Sprite).spriteFrame = this.teamBgImgs[1], this.detailsNode.getChildByName("team_bg").getChildByName("wz").getComponent(Label).color = color(51, 51, 51));
        sys.isObjectValid(this._player_source.matches_played) && (this.tourRootNode.getChildByName("played_num").getComponent(Label).string = this._player_source.matches_played);
        sys.isObjectValid(this._player_source.avg_points) && (this.tourRootNode.getChildByName("avg_num").getComponent(Label).string = this._player_source.avg_points);
        sys.isObjectValid(this._player_source.credits) && (this.tourRootNode.getChildByName("credits_num").getComponent(Label).string = this._player_source.credits);
    }
    onArrowBtnClick(t, e) {
        if (SoundManager.shared().playFx("click"), sys.now() - this._lastClick < 500) {
            return;
        }
        if (this._lastClick = sys.now(), 3 == this._match_state) {
            return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("yes11.live_tip"), 2);
        }
        if (4 == this._match_state) {
            return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("yes11.cancel_tip"), 2);
        }
        let i = ToolUtils.parseJson(e), s = i.match_id + "_" + this._player_id;
        if (SportCricket_Manager.shared().cricket_playerDetailsMap.has(s)) {
            let t = { player_thumb_url: this._player_source.player_thumb_url, format_str: this._player_source.format_str, team_name: this._player_source.team.short_name, point: i.base_point, name: this._player_source.name };
            Utils.shared().showSportCricket_playerDetail({ playerInfo: t, detailInfo: SportCricket_Manager.shared().cricket_playerDetailsMap.get(s), targer: this });
        }
        else {
            SportCricket_Manager.shared().requestYes11_PlayerDetailList(i.match_id, this._player_id, true, (t => {
                let e = { player_thumb_url: this._player_source.player_thumb_url, format_str: this._player_source.format_str, team_name: this._player_source.team.short_name, point: i.base_point, name: this._player_source.name };
                Utils.shared().showSportCricket_playerDetail({ playerInfo: e, detailInfo: t, targer: this });
            }));
        }
    }
    onButtonClick(t, e) {
        SoundManager.shared().playFx("click");
        sys.now() - this._lastClick < 500 || (this._lastClick = sys.now(), 3 != this._match_state ? 4 != this._match_state ? "add" == e ? this.dealPlayerLogic() : "add_chip" == e && (Utils.shared().showStoreView(null, null), User.shared().updatePayScene(PhpReportDefined.pay_scene.hall_cricket)) : Utils.shared().showToast(i18nMgr.shared().getValueByKey("yes11.cancel_tip"), 2) : Utils.shared().showToast(i18nMgr.shared().getValueByKey("yes11.live_tip"), 2));
    }
    dealPlayerLogic() {
        this._call && sys.isObjectValid(this._playerInfo) && (0 != this._select_status && 1 != this._select_status || (this._call(this._playerInfo), 0 == this._select_status ? this._select_status = 1 : this._select_status = 0, this.updateNextButtonStatus(), ToolUtils.isObjValid(this._lastNode) && (this._lastNode.active = true), ToolUtils.isObjValid(this.node) && this.node.destroy()));
    }
    onBackView(t = true) {
        t && (Utils.shared().hideLoading(), this.bShowPushAnim ? (this._closed = true, ToolUtils.isObjValid(this._lastNode) && (this._lastNode.active = true), ToolUtils.showPushAnim(this.node, 1, (() => {
            ToolUtils.isObjValid(this.node) && this.node.destroy();
        }))) : (ToolUtils.isObjValid(this._lastNode) && (this._lastNode.active = true), ToolUtils.isObjValid(this.node) && this.node.destroy()));
    }
    fitScreen() {
        ToolUtils.adaptSafeArea(this.rootNode);
        let t = sys.getSafeAreaRect().y, e = view.getVisibleSize();
        if (this.node.getComponent(UITransform).setContentSize(e.width, e.height), 0 != this._fromType && 1 != this._fromType && (this.rootNode.getChildByName("bottom_node").active = false, this.rootNode.getChildByName("all_ScrollView").getComponent(Widget).bottom = 10), 0 != t) {
            let e = this.rootNode.getChildByName("all_ScrollView").getComponent(Widget).bottom;
            this.rootNode.getChildByName("all_ScrollView").getComponent(Widget).bottom = e - t;
            e = this.rootNode.getChildByName("bottom_node").getComponent(Widget).bottom;
            this.rootNode.getChildByName("bottom_node").getComponent(Widget).bottom = e - t;
        }
    }
}
