// @ts-nocheck
// Recovered from index.js:569
import { _decorator, Button, color, instantiate, Label, Node, ProgressBar, ScrollView, size, sp, Sprite, SpriteFrame, sys, UITransform, v3, view, Widget } from "cc";
import BaseLayer from "./BaseLayer";
import i18nMgr from "./i18nMgr";
import PushCenter from "./PushCenter";
import { TLog } from "./TLog";
import { ToolUtils } from "./ToolUtils";
import TweenTool from "./TweenTool";
import Utils from "./Utils";
import BundleNameDefined from "./BundleNameDefined";
import { HallGameType } from "./CommDefine";
import GameConfig from "./GameConfig";
import { HttpRequest } from "./HttpRequestName";
import PushEvent from "./PushEvent";
import User from "./User";
import HttpManager from "./HttpManager";
import SoundManager from "./SoundManager";
import SportCricket_Manager from "./SportCricket_Manager";
import PhpReportDefined from "./PhpReportDefined";
const { ccclass, property } = _decorator;
@ccclass("SportCricket_Main")
export class SportCricket_Main extends BaseLayer {
    public TAG: string = "SportCricket_Main";
    @property(Node)
    public rootNode: Node = null;
    @property(Node)
    public goldNode: Node = null;
    @property(Node)
    public sortNode: Node = null;
    @property(Node)
    public viewMoreNode: Node = null;
    @property([SpriteFrame])
    public iconImgs: SpriteFrame[] = [];
    @property(Node)
    public sortMoban: Node = null;
    @property(Node)
    public bannerNode: Node = null;
    @property(Node)
    public tabNode: Node = null;
    @property(Node)
    public topNode: Node = null;
    @property(ScrollView)
    public allMatchScrollView: ScrollView = null;
    @property([SpriteFrame])
    public sortBgImgs: SpriteFrame[] = [];
    @property([SpriteFrame])
    public bannerImgs: SpriteFrame[] = [];
    @property(ScrollView)
    public myMatchScrollView: ScrollView = null;
    public allMatchTable: any = null;
    public myMatchTable: any = null;
    public all_listData: any[] = [];
    public my_listData: any[] = [];
    public _sortItemArr: any[] = [];
    @property(Node)
    public mobanView: Node = null;
    @property(Node)
    public mobanView_contest: Node = null;
    public _closed: boolean = false;
    public bShowPushAnim: boolean = true;
    public _lastClick: number = 0;
    public _sourceData: any = null;
    public _itemArr_all: any[] = [];
    public _itemArr_my: any[] = [];
    public all_has_next_page: number = 0;
    public all_cur_page: number = 1;
    public _isSendMsg: boolean = false;
    public my_has_next_page: number = 0;
    public my_cur_page: number = 1;
    public curTab: number = 0;
    public tabWzColor: any[] = [color(147, 11, 11), color(102, 102, 102)];
    public taskAwardIconMap: Map = new Map;
    public lastClick: number = 0;
    public _lastNode: any = null;
    public _hasLoadChoose: boolean = false;
    public _curSortType: number = 1;
    public _cidSelects: any[] = [];
    public reTryTime: number = 0;
    public curBannerType: number = 0;
    public _scheduleAct: any = null;
    public firstCount: number = 0;
    public filter_select_color: any = color(182, 0, 0);
    public force_match_id: number = 0;
    onLoad() {
        PushCenter.shared().addListener(GameConfig.Update_Money, (t => {
            try {
                ToolUtils.isObjValid(this.node) && this.updateGold(t);
            }
            catch (t) {
                TLog.printError(this.TAG, GameConfig.Update_Money, t);
            }
        }), this);
        PushCenter.shared().addListener(PushEvent.commentDownloaderImg, (t => {
            try {
                if (ToolUtils.isObjValid(this.node) && this.taskAwardIconMap.size > 0) {
                    for (const [e, i] of this.taskAwardIconMap) {
                        i == t && Utils.shared().updateNetImage(e, t, size(56, 56));
                    }
                }
            }
            catch (t) {
                TLog.printError(this.TAG, PushEvent.commentDownloaderImg, t);
            }
        }), this);
        PushCenter.shared().addListener(PushEvent.RefreshYes11GameList, (t => {
            try {
                ToolUtils.isObjValid(this.node) && this.updateTabContent();
            }
            catch (t) {
                TLog.printError(this.TAG, PushEvent.RefreshYes11GameList, t);
            }
        }), this);
        PushCenter.shared().addListener(GameConfig.onEnterForeground, (t => {
            try {
                ToolUtils.isObjValid(this.node) && this.updateTabContent();
            }
            catch (t) {
                TLog.printError(this.TAG, GameConfig.onEnterForeground, t);
            }
        }), this);
        PushCenter.shared().addListener(PushEvent.Yes11SignOk, (t => {
            try {
                ToolUtils.isObjValid(this.node) && this.updateTabContent();
            }
            catch (t) {
                TLog.printError(this.TAG, PushEvent.Yes11SignOk, t);
            }
        }), this);
        PushCenter.shared().addListener(PushEvent.NoticePlayerNotInLineUp, (t => {
            try {
                if (ToolUtils.isObjValid(this.node)) {
                    let t = this.tabNode.getChildByName("my_match_btn").getChildByName("idot");
                    if (ToolUtils.isObjValid(t)) {
                        let e = Array.from(SportCricket_Manager.shared().cricket_notInLineUpMap.values()).includes(1);
                        t.active = e;
                    }
                }
            }
            catch (t) {
                TLog.printError(this.TAG, PushEvent.NoticePlayerNotInLineUp, t);
            }
        }), this);
        PushCenter.shared().addListener(PushEvent.RefreshYesGameSignPer, (t => {
            try {
                ToolUtils.isObjValid(this.node) && this.updateGameSessionPercent(t);
            }
            catch (t) {
                TLog.printError(this.TAG, PushEvent.RefreshYesGameSignPer, t);
            }
        }), this);
        PushCenter.shared().addListener(PushEvent.Update_Gullak_RewardInGame, (t => {
            ToolUtils.isObjValid(this.node) && this.updateGullakBtnStatus(User.shared().act_68_open, User.shared().act_68_full_status, true);
        }), this);
        this.fitLuckyTheme();
    }
    fitLuckyTheme() {
        if (0 == GameConfig.NATIVE_GAME_APP_TYPE) {
            return;
        }
        this.filter_select_color = color(38, 59, 152);
        this.tabWzColor = [color(221, 3, 3), color(102, 102, 102)];
        this.goldNode.getChildByName("coin").getComponent(Label).color = color(251, 220, 0, 255);
        this.tabNode.getChildByName("bg").getComponent(Sprite).color = color(250, 250, 250, 255);
        this.tabNode.getChildByName("all_match_btn").getChildByName("line").getComponent(Sprite).color = this.tabWzColor[0];
        this.tabNode.getChildByName("my_match_btn").getChildByName("line").getComponent(Sprite).color = this.tabWzColor[0];
        let t = this.sortNode.getChildByName("sort_scrollview").getComponent(ScrollView).content.getChildByName("time_sort");
        t.getChildByName("wz").getComponent(Label).color = color(38, 59, 152, 255);
        t.getChildByName("arrow").getComponent(Sprite).color = color(38, 59, 152, 255);
    }
    updateGameSessionPercent(t) {
        if (sys.isObjectValid(t.contest)) {
            if (0 == this.curTab) {
                let e = -1;
                for (let i = 0; i < this.all_listData.length; i++) {
                    if (this.all_listData[i].match_id == Number(t.match_id) && sys.isObjectValid(this.all_listData[i].contest) && this.all_listData[i].contest.session_id == t.contest.session_id) {
                        e = i;
                        break;
                    }
                }
                if (-1 != e && this._itemArr_all.length - 1 >= e && ToolUtils.isObjValid(this._itemArr_all[e]) && ToolUtils.isObjValid(this._itemArr_all[e].getChildByName("main_node"))) {
                    let i = this._itemArr_all[e].getChildByName("main_node");
                    ToolUtils.isObjValid(i) && sys.isObjectValid(t.contest.left_sign_num) && sys.isObjectValid(t.contest.sign_num) && (i.getChildByName("progress").getComponent(ProgressBar).progress = (t.contest.sign_num - t.contest.left_sign_num) / t.contest.sign_num, i.getChildByName("left_desc1").getComponent(Label).string = `${t.contest.sign_num - t.contest.left_sign_num}/${t.contest.sign_num} Spots`);
                }
            }
            else {
                let e = -1;
                for (let i = 0; i < this.my_listData.length; i++) {
                    if (this.my_listData[i].match_id == Number(t.match_id) && sys.isObjectValid(this.my_listData[i].contest) && this.my_listData[i].contest.session_id == t.contest.session_id) {
                        e = i;
                        break;
                    }
                }
                if (-1 != e && this._itemArr_my.length - 1 >= e && ToolUtils.isObjValid(this._itemArr_my[e]) && ToolUtils.isObjValid(this._itemArr_my[e].getChildByName("main_node"))) {
                    let i = this._itemArr_my[e].getChildByName("main_node");
                    ToolUtils.isObjValid(i) && sys.isObjectValid(t.contest.left_sign_num) && sys.isObjectValid(t.contest.sign_num) && (i.getChildByName("progress").getComponent(ProgressBar).progress = (t.contest.sign_num - t.contest.left_sign_num) / t.contest.sign_num, i.getChildByName("left_desc1").getComponent(Label).string = `${t.contest.sign_num - t.contest.left_sign_num}/${t.contest.sign_num} Spots`);
                }
            }
        }
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().removeListenersByTag(this);
        this.unscheduleAllCallbacks();
    }
    init(t) {
        sys.isObjectValid(t) && sys.isObjectValid(t.source) && (this._sourceData = t.source);
        sys.isObjectValid(t) && sys.isObjectValid(t.lastNode) && (this._lastNode = t.lastNode);
    }
    start() {
        super.start();
        this.initView();
        this.updateGold(User.shared().data.money);
        this.mobanView;
        this.mobanView.getComponent(UITransform).height;
        this.refreshView();
        ToolUtils.isObjValid(this._lastNode) && (this._lastNode.active = false);
        1 == SportCricket_Manager.shared().checkDeepLink && sys.isObjectValid(SportCricket_Manager.shared().deepLinkData) && (SportCricket_Manager.shared().checkDeepLink = 0, this.checkDeeplinkData());
        this.updateGullakBtnStatus(User.shared().act_68_open, User.shared().act_68_full_status, true);
        let t = {};
        t.htype = HallGameType.LOBBY_GAME_TYPE_YES11;
        ToolUtils.saveData(User.shared().data.uid + "saveCommRecommendRoom", ToolUtils.toJsonString(t));
        this.updateBanner();
        this._scheduleAct = TweenTool.commonSchedule(this.node, 5, this.updateBanner.bind(this));
    }
    updateBanner() {
        0 == this.curBannerType ? this.curBannerType = 1 : this.curBannerType = 0;
        this.bannerNode.getComponent(Sprite).spriteFrame = this.bannerImgs[this.curBannerType];
    }
    checkDeeplinkData() {
    }
    allmatch_scrollRefreshCallBack() {
        1 != this.all_has_next_page || this._isSendMsg || (this._isSendMsg = true, this.all_cur_page = this.all_cur_page + 1, this.requestAllMatchList(false));
    }
    mymatch_scrollRefreshCallBack() {
        1 != this.my_has_next_page || this._isSendMsg || (this._isSendMsg = true, this.my_cur_page = this.my_cur_page + 1, this.requestMyMatchList(false));
    }
    requestAllMatchList(t = false, e = false) {
        let i = { page: this.all_cur_page, sort_type: this._curSortType + 1, cid: this._cidSelects.join(","), force: User.shared().forceSignCricket };
        t && Utils.shared().showLoading(10, true, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
        }), ToolUtils.getIsNormalDirection());
        HttpManager.shared().doGetCommonRequest(i, HttpRequest.Yes11_AllMatchList, ((t, i, a) => {
            if (Utils.shared().hideLoading(), 200 != a) {
                ToolUtils.isObjValid(this.node) && (this._isSendMsg = false, this.all_cur_page > 1 && (this.all_cur_page = this.all_cur_page - 1), (this.all_cur_page = 1) && (this._itemArr_all = [], this.allMatchScrollView.content.removeAllChildren()), this.rootNode.getChildByName("nosign").active = true, this.rootNode.getChildByName("nodata").active = false);
            }
            else {
                try {
                    this.reTryTime = 0;
                    let t = ToolUtils.parseJson(i);
                    if (0 == t.ret) {
                        if (sys.isObjectValid(t.data) && (this.rootNode.getChildByName("nosign").active = false, ToolUtils.isObjValid(this.node))) {
                            if (this._isSendMsg = false, e && (this.all_listData = [], this.allMatchScrollView.scrollToTop(0)), sys.isObjectValid(t.data.has_next_page) && (this.all_has_next_page = t.data.has_next_page), sys.isObjectValid(t.data.list) && Array.isArray(t.data.list) && t.data.list.length > 0) {
                                e && (this._itemArr_all = [], this.allMatchScrollView.content.removeAllChildren());
                                let i = this.allMatchScrollView.content.getChildByName("view_more");
                                ToolUtils.isObjValid(i) && i.removeFromParent();
                                let a = 0, s = null;
                                for (let e = 0, i = t.data.list.length; e < i; e++) {
                                    this.all_listData.push(t.data.list[e]);
                                    let i = null;
                                    if (i = sys.isObjectValid(t.data.list[e].contest) ? instantiate(this.mobanView_contest) : instantiate(this.mobanView), ToolUtils.isObjValid(i) && (this._itemArr_all.push(i), i.active = true, this.initAllMatchItem(i, t.data.list[e], e), this.allMatchScrollView.content.addChild(i), a += 0.15), 1 == User.shared().forceSignCricket && (sys.isObjectValid(t.data.list[e].force) && 1 == t.data.list[e].force && 0 == this.force_match_id && (this.force_match_id = Number(t.data.list[e].match_id), s = t.data.list[e]), this.force_match_id > 0)) {
                                        let t = { match_id: this.force_match_id, source: s, lastNode: this.rootNode };
                                        Utils.shared().showSportCricket_chooseGame(t);
                                    }
                                }
                                if (1 == this.all_has_next_page) {
                                    let t = instantiate(this.viewMoreNode);
                                    t.active = true;
                                    this.allMatchScrollView.content.addChild(t);
                                }
                            }
                            sys.isObjectValid(t.data.page) && (this.all_cur_page = t.data.page);
                            this.all_listData.length > 0 ? this.rootNode.getChildByName("nodata").active = false : 0 == this.curTab && (this._itemArr_all = [], this.rootNode.getChildByName("nodata").active = true, this.allMatchScrollView.content.removeAllChildren());
                            sys.isObjectValid(t.data.act_131_dot_ids) && Array.isArray(t.data.act_131_dot_ids) ? SportCricket_Manager.shared().updateMatchLineUpMap(t.data.act_131_dot_ids) : SportCricket_Manager.shared().updateMatchLineUpMap([]);
                            let i = Array.from(SportCricket_Manager.shared().cricket_notInLineUpMap.values()).includes(1);
                            this.tabNode.getChildByName("my_match_btn").getChildByName("idot").active = i;
                        }
                    }
                    else {
                        ToolUtils.isObjValid(this.node) && (this.all_cur_page = 1) && (this.all_listData = [], this._itemArr_all = [], this.allMatchScrollView.content.removeAllChildren());
                    }
                }
                catch (t) {
                    TLog.printError("requestAllMatchList err:", t.toString());
                }
            }
        }));
    }
    updateTabView() {
        this.tabNode.getChildByName("all_match_btn").getChildByName("di").active = false;
        this.tabNode.getChildByName("my_match_btn").getChildByName("di").active = false;
        this.tabNode.getChildByName("all_match_btn").getChildByName("line").active = 0 == this.curTab;
        this.tabNode.getChildByName("my_match_btn").getChildByName("line").active = 1 == this.curTab;
        0 == this.curTab ? (this.tabNode.getChildByName("all_match_btn").getChildByName("Label").getComponent(Label).color = this.tabWzColor[0], this.tabNode.getChildByName("my_match_btn").getChildByName("Label").getComponent(Label).color = this.tabWzColor[1]) : (this.tabNode.getChildByName("all_match_btn").getChildByName("Label").getComponent(Label).color = this.tabWzColor[1], this.tabNode.getChildByName("my_match_btn").getChildByName("Label").getComponent(Label).color = this.tabWzColor[0]);
        i18nMgr.shared().changeLabelFont(this.tabNode.getChildByName("all_match_btn").getChildByName("Label").getComponent(Label), 0 == this.curTab);
        i18nMgr.shared().changeLabelFont(this.tabNode.getChildByName("my_match_btn").getChildByName("Label").getComponent(Label), 1 == this.curTab);
        let t = [];
        t.push(this.tabNode.getChildByName("all_match_btn").getChildByName("line"));
        t.push(this.tabNode.getChildByName("my_match_btn").getChildByName("line"));
        for (let e = 0; e < 2; e++) {
            if (this.curTab == e) {
                t[e].scale = v3(0, 1, 1);
                let i = TweenTool.scaleTo(t[e], 0.16, v3(1.1, 1, 1), null, false), a = TweenTool.scaleTo(t[e], 0.16, v3(1, 1, 1), null, false);
                TweenTool.sequence(t[e], true, null, i, a);
            }
            else {
                t[e].scale = v3(1, 1, 1);
            }
        }
    }
    requestMyMatchList(t = false, e = false) {
        let i = { page: this.my_cur_page };
        t && Utils.shared().showLoading(10, true, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
        }), ToolUtils.getIsNormalDirection());
        HttpManager.shared().doGetCommonRequest(i, HttpRequest.Yes11_MyMatchList, ((t, i, a) => {
            if (Utils.shared().hideLoading(), 200 != a) {
                ToolUtils.isObjValid(this.node) && (this._isSendMsg = false, this.my_cur_page > 1 && (this.my_cur_page = this.my_cur_page - 1), (this.my_cur_page = 1) && (this.my_listData = [], this._itemArr_my = [], this.myMatchScrollView.content.removeAllChildren()), this.rootNode.getChildByName("nosign").active = true, this.rootNode.getChildByName("nodata").active = false);
            }
            else {
                try {
                    let t = ToolUtils.parseJson(i);
                    if (0 == t.ret) {
                        if (this.rootNode.getChildByName("nosign").active = false, sys.isObjectValid(t.data) && ToolUtils.isObjValid(this.node)) {
                            if (this._isSendMsg = false, e && (this.my_listData = [], SportCricket_Manager.shared().cricket_notInLineUpMap.clear()), sys.isObjectValid(t.data.has_next_page) && (this.my_has_next_page = t.data.has_next_page), sys.isObjectValid(t.data.list) && Array.isArray(t.data.list) && t.data.list.length > 0) {
                                e && this.myMatchScrollView.content.removeAllChildren();
                                let i = this.myMatchScrollView.content.getChildByName("view_more");
                                ToolUtils.isObjValid(i) && i.removeFromParent();
                                for (let e = 0, i = t.data.list.length; e < i; e++) {
                                    this.my_listData.push(t.data.list[e]);
                                    let i = null;
                                    i = sys.isObjectValid(t.data.list[e].contest) ? instantiate(this.mobanView_contest) : instantiate(this.mobanView);
                                    ToolUtils.isObjValid(i) && (i.active = true, this._itemArr_my.push(i), this.initAllMatchItem(i, t.data.list[e], e), this.myMatchScrollView.content.addChild(i));
                                }
                                if (1 == this.my_has_next_page) {
                                    let t = instantiate(this.viewMoreNode);
                                    t.active = true;
                                    this.myMatchScrollView.content.addChild(t);
                                }
                            }
                            sys.isObjectValid(t.data.page) && (this.my_cur_page = t.data.page);
                            this.my_listData.length > 0 ? this.rootNode.getChildByName("nodata").active = false : 1 == this.curTab && (this.my_listData = [], this._itemArr_my = [], this.rootNode.getChildByName("nodata").active = true, this.myMatchScrollView.content.removeAllChildren());
                        }
                        PushCenter.shared().pushEvent(PushEvent.NoticePlayerNotInLineUp);
                    }
                    else {
                        ToolUtils.isObjValid(this.node) && (this.my_cur_page = 1) && (this.my_listData = [], this._itemArr_my = [], this.myMatchScrollView.content.removeAllChildren());
                    }
                }
                catch (t) {
                    TLog.printError("requestMyMatchList err:", t.toString());
                }
            }
        }));
    }
    initAllMatchItem(t, e, i) {
        t.active = true;
        sys.isObjectValid(e.teama.logo_url) && e.teama.logo_url.length > 0 && (this.taskAwardIconMap.set(t.getChildByName("team_icon0"), e.teama.logo_url), Utils.shared().updateNetImage(t.getChildByName("team_icon0"), e.teama.logo_url, size(56, 56)));
        sys.isObjectValid(e.teamb.logo_url) && e.teamb.logo_url.length > 0 && (this.taskAwardIconMap.set(t.getChildByName("team_icon1"), e.teamb.logo_url), Utils.shared().updateNetImage(t.getChildByName("team_icon1"), e.teamb.logo_url, size(56, 56)));
        let a = "";
        if (sys.isObjectValid(e.format_str) && e.format_str.length > 0 && (t.getChildByName("game_type").getComponent(Label).string = e.format_str + " · ", t.getChildByName("game_type").getComponent(Label).updateRenderData(true), a = e.format_str + " · "), sys.isObjectValid(e.competition.title) && e.competition.title.length > 0) {
            t.getChildByName("title").getComponent(Label).string = e.competition.title;
            t.getChildByName("title").getComponent(Label).updateRenderData(true);
            let i = t.getChildByName("game_type").getComponent(UITransform).contentSize.width;
            t.getChildByName("title").setPosition(v3(-307.327 + i + 7, -30.693));
            a += e.competition.title;
        }
        if (t.getChildByName("ginfo").getComponent(Label).string = a, sys.isObjectValid(e.teama.short_name) && e.teama.short_name.length > 0 && (t.getChildByName("team_short_name0").getComponent(Label).string = e.teama.short_name, t.getChildByName("team_short_name0").getComponent(Label).updateRenderData(true)), sys.isObjectValid(e.teama.name) && e.teama.name.length > 0) {
            let i = e.teama.name;
            t.getChildByName("team_full_name0").getComponent(Label).string = i;
            let a = t.getChildByName("team_short_name0").position, s = t.getChildByName("team_short_name0").scale.x, o = t.getChildByName("team_short_name0").getComponent(UITransform).contentSize.width;
            o *= s;
            t.getChildByName("team_full_name0").getComponent(UITransform).contentSize = size(320 - o - 10, 40);
            t.getChildByName("team_full_name0").setPosition(v3(a.x + o + 10, a.y));
        }
        if (sys.isObjectValid(e.teamb.short_name) && e.teamb.short_name.length > 0 && (t.getChildByName("team_short_name1").getComponent(Label).string = e.teamb.short_name, t.getChildByName("team_short_name1").getComponent(Label).updateRenderData(true)), sys.isObjectValid(e.teamb.name) && e.teamb.name.length > 0) {
            let i = e.teamb.name;
            t.getChildByName("team_full_name1").getComponent(Label).string = i;
            let a = t.getChildByName("team_short_name1").position, s = t.getChildByName("team_short_name1").scale.x, o = t.getChildByName("team_short_name1").getComponent(UITransform).contentSize.width;
            o *= s;
            t.getChildByName("team_full_name1").getComponent(UITransform).contentSize = size(320 - o - 10, 40);
            t.getChildByName("team_full_name1").setPosition(v3(a.x + o + 10, a.y));
        }
        let s = 0;
        t.getChildByName("start_date").active = false;
        t.getChildByName("left_time").active = false;
        t.getChildByName("lineups_btn").active = false;
        t.getChildByName("gou").active = false;
        t.getChildByName("more_btn").active = false;
        t.getChildByName("st_live").active = false;
        t.getChildByName("st_complete").active = false;
        t.getChildByName("mask").active = false;
        let o = t.getChildByName("left_time");
        if (TweenTool.stopNodeAction(o), sys.isObjectValid(e.status)) {
            s = e.status;
            let i = 0;
            if (sys.isObjectValid(e.time_left) && (i = Number(e.time_left), e.match_id == SportCricket_Manager.shared().cricket_curMatchId)) {
                let t = { match_id: e.match_id, time_left: i, status: s, is_current_day: e.is_current_day };
                PushCenter.shared().pushEvent(PushEvent.UpdateYes11CurMatchLeftTime, t);
            }
            SportCricket_Manager.shared().cricket_notInLineUpMap.set(e.match_id, 0);
            1 == s ? (t.getChildByName("start_date").active = true, i <= 0 ? (sys.isObjectValid(e.start_day) && e.start_day.length > 0 && (t.getChildByName("left_time").getComponent(Label).string = e.start_day, t.getChildByName("left_time").getComponent(Label).color = color(51, 51, 51), t.getChildByName("left_time").getComponent(Label).fontSize = 48), sys.isObjectValid(e.is_current_day) && 1 == Number(e.is_current_day) && (e.time_left = 0, e.status = 3, t.getComponent(Button).clickEvents[0].customEventData = ToolUtils.toJsonString(e), t.getChildByName("st_live").active = true, t.getChildByName("mask").active = true, t.getChildByName("start_date").active = false)) : (t.getChildByName("left_time").getComponent(Label).color = color(215, 60, 69), t.getChildByName("left_time").getComponent(Label).fontSize = 48, o.getComponent(Label).string = Utils.shared().parseCountDown(e.time_left), TweenTool.myschedule(o, 1, (() => {
                if (ToolUtils.isObjValid(this.node)) {
                    if (e.time_left > 0) {
                        e.time_left = e.time_left - 1;
                        o.getComponent(Label).string = Utils.shared().parseCountDown(e.time_left);
                        t.getComponent(Button).clickEvents[0].customEventData = ToolUtils.toJsonString(e);
                    }
                    else if (t.getChildByName("st_live").active = true, t.getChildByName("mask").active = true, t.getChildByName("start_date").active = false, t.getChildByName("lineups_btn").active = false, e.status = 3, t.getComponent(Button).clickEvents[0].customEventData = ToolUtils.toJsonString(e), TweenTool.stopNodeAction(o), t.getComponent(Button).interactable = false, e.match_id == SportCricket_Manager.shared().cricket_curMatchId) {
                        let t = { match_id: e.match_id, time_left: 0, status: e.status, is_current_day: e.is_current_day };
                        PushCenter.shared().pushEvent(PushEvent.UpdateYes11CurMatchLeftTime, t);
                    }
                }
            }))), 1 == e.status && (sys.isObjectValid(e.start_time) && e.start_time.length > 0 && (t.getChildByName("start_date").getComponent(Label).string = e.start_time), t.getChildByName("start_date").active = true, t.getChildByName("left_time").active = true, sys.isObjectValid(e.lineup_status) && (t.getChildByName("lineups_btn").active = 1 == e.lineup_status, t.getChildByName("start_date").active = 0 == e.lineup_status, 1 == e.lineup_status && (t.getChildByName("mask").active = false, sys.isObjectValid(e.not_in_lineup) && 1 == this.curTab && (t.getChildByName("lineups_btn").getChildByName("idot").active = 1 == e.not_in_lineup, SportCricket_Manager.shared().cricket_notInLineUpMap.set(e.match_id, e.not_in_lineup)))), sys.isObjectValid(e.can_join) && 0 == e.can_join && (t.getChildByName("mask").active = true))) : 3 == s ? (t.getChildByName("st_live").active = true, t.getChildByName("mask").active = true) : 4 == s ? (t.getChildByName("st_complete").active = true, t.getChildByName("mask").active = true, t.getChildByName("st_complete").getComponent(Label).color = color(102, 102, 102), i18nMgr.shared().changeLocalizedLabelKey(t.getChildByName("st_complete"), "kyc.cancel")) : 2 == s && (t.getChildByName("st_complete").active = true, t.getChildByName("mask").active = false, t.getChildByName("st_complete").getComponent(Label).color = color(10, 159, 24), i18nMgr.shared().changeLocalizedLabelKey(t.getChildByName("st_complete"), "tournament.completed1"));
        }
        if (0 == this.curTab ? t.getComponent(Button).interactable = 1 == s : t.getComponent(Button).interactable = 1 == s || 2 == s, t.getComponent(Button).clickEvents[0].customEventData = ToolUtils.toJsonString(e), sys.isObjectValid(e.contest)) {
            1 == s && (t.getChildByName("more_btn").active = true);
            let i = t.getChildByName("main_node");
            ToolUtils.isObjValid(i) && (sys.isObjectValid(e.contest.all_reward) && (i.getChildByName("pool").getComponent(Label).string = String(e.contest.all_reward)), sys.isObjectValid(e.contest.left_sign_num) && sys.isObjectValid(e.contest.sign_num) && (i.getChildByName("progress").getComponent(ProgressBar).progress = (e.contest.sign_num - e.contest.left_sign_num) / e.contest.sign_num, i.getChildByName("left_desc1").getComponent(Label).string = `${e.contest.left_sign_num}/${e.contest.sign_num} Spots`), sys.isObjectValid(e.contest.reward_rate) && (i.getChildByName("prize_desc").getComponent(Label).string = e.contest.reward_rate), sys.isObjectValid(e.contest.person_sign_num) && (e.contest.person_sign_num > 1 ? (i.getChildByName("m_icon").getComponent(Sprite).spriteFrame = this.iconImgs[0], i.getChildByName("m_desc").getComponent(Label).string = ToolUtils.format(i18nMgr.shared().getValueByKey("yes11.upto"), e.contest.person_sign_num)) : (i.getChildByName("m_icon").getComponent(Sprite).spriteFrame = this.iconImgs[1], i.getChildByName("m_desc").getComponent(Label).string = e.contest.m_desc, i.getChildByName("m_desc").getComponent(Label).string = ToolUtils.format(i18nMgr.shared().getValueByKey("yes11.no_team"), e.contest.person_sign_num))), sys.isObjectValid(e.contest.fee) && (t.getChildByName("main_node").getChildByName("status_btn").getChildByName("node").getChildByName("wz").getComponent(Label).string = "₹" + e.contest.fee, t.getChildByName("main_node").getChildByName("status_btn").getChildByName("node").getChildByName("ico").active = false), t.getChildByName("main_node").getChildByName("status_btn").getComponent(Button).clickEvents[0].customEventData = ToolUtils.toJsonString(e));
        }
    }
    onJoinGameClick(t, e) {
        if (SoundManager.shared().playFx("click"), sys.now() - this._lastClick < 500) {
            return;
        }
        this._lastClick = sys.now();
        let i = ToolUtils.parseJson(e);
        3 != i.status ? 4 != i.status ? this.checkJoinGame(i) : Utils.shared().showToast(i18nMgr.shared().getValueByKey("yes11.cancel_tip"), 2) : Utils.shared().showToast(i18nMgr.shared().getValueByKey("yes11.live_tip"), 2);
    }
    checkJoinGame(t) {
        let e = t.match_id, i = t.contest.session_id, a = { session_id: i, match_id: e };
        Utils.shared().showLoading(10, true, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
        }), ToolUtils.getIsNormalDirection());
        SportCricket_Manager.shared().requestYes11_PreJoinGameCheck(a, true, (a => {
            if (sys.isObjectValid(a) && sys.isObjectValid(a.code)) {
                if (308501 == a.code) {
                    Utils.shared().showQuickRechargeByYes11({ fee: t.contest.fee });
                    User.shared().updatePayScene(PhpReportDefined.pay_scene.hall_cricket);
                }
                else if (308502 == a.code) {
                    this.checkCreateTeam(1, i, e, t);
                }
                else if (308503 == a.code) {
                    let t = { match_id: e, contest_id: i, assureInfo: a };
                    Utils.shared().showSportCricket_assureJoin(t);
                }
                else if (308504 == a.code) {
                    let t = { match_id: e, contest_id: i };
                    SportCricket_Manager.shared().requestYes11_JoinList(t, true, (t => {
                        let a = { match_id: e, contest_id: i, teamlistData: t };
                        Utils.shared().showSportCricket_joinList(a);
                    }));
                }
            }
        }));
    }
    checkCreateTeam(t = 0, e, i = 0, a) {
        let s = { match_id: i };
        SportCricket_Manager.shared().requestYes11_PreCreateTeamCheck(s, true, (s => {
            let o = { source: a, match_id: i, player_source: s, fromType: t, lastNode: this.node };
            sys.isObjectValid(e) && (o.contest_id = e);
            Utils.shared().showSportCricket_createTeam(o);
        }));
    }
    refreshView() {
        this.rootNode.getChildByName("nodata").active = false;
        this.curTab = 0;
        this.updateTabView();
        this.updateTabContent();
        this._hasLoadChoose || (this._hasLoadChoose = true, TweenTool.delayAct(this.node, (() => {
            ToolUtils.preLoadBundlePrefab(BundleNameDefined.Bundle_Yes11, "prefab/cricket_choosegame", null);
            ToolUtils.preLoadBundlePrefab(BundleNameDefined.Bundle_Yes11, "prefab/cricket_gamesort", null);
        }), 2, true));
        this.updateSortRoot();
    }
    updateFilterBtnStatus() {
        let t = this.sortNode.getChildByName("filter_btn");
        this._cidSelects.length > 0 ? (t.getChildByName("wz").getComponent(Label).color = this.filter_select_color, t.getChildByName("ico").getComponent(Sprite).color = this.filter_select_color, i18nMgr.shared().changeLabelFont(t.getChildByName("wz").getComponent(Label), true)) : (t.getChildByName("wz").getComponent(Label).color = color(51, 51, 51), t.getChildByName("ico").getComponent(Sprite).color = color(51, 51, 51), i18nMgr.shared().changeLabelFont(t.getChildByName("wz").getComponent(Label), false));
    }
    updateSortRoot() {
        if (sys.isObjectValid(SportCricket_Manager.shared().sortSourceData) && sys.isObjectValid(SportCricket_Manager.shared().sortSourceData.match)) {
            let t = SportCricket_Manager.shared().sortSourceData.match.length;
            t > 5 && (t = 5);
            let e = this.sortNode.getChildByName("sort_scrollview").getComponent(ScrollView);
            for (let i = 0; i < t; i++) {
                let t = instantiate(this.sortMoban);
                t.active = true;
                t.getChildByName("wz").getComponent(Label).string = SportCricket_Manager.shared().sortSourceData.match[i].abbr;
                t.getChildByName("wz").getComponent(Label).updateRenderData(true);
                let a = t.getChildByName("wz").getComponent(UITransform).contentSize.width, s = t.getChildByName("wz").scale.x;
                t.getComponent(UITransform).contentSize = size(a * s + 30, 60);
                t.getChildByName("ico").getComponent(UITransform).contentSize = size(a * s + 30, 60);
                e.content.addChild(t);
                t.getComponent(Button).clickEvents[0].customEventData = i + "";
                this._sortItemArr.push(t);
            }
        }
        this.updateSortTypeCheck();
    }
    updateSortCidCheck(t) {
        for (let e = 0; e < this._sortItemArr.length; e++) {
            if (ToolUtils.isObjValid(this._sortItemArr[e])) {
                let i = SportCricket_Manager.shared().sortSourceData.match[e].cid;
                -1 == t.indexOf(i) ? this.updateSortItemStatus(this._sortItemArr[e], 0) : this.updateSortItemStatus(this._sortItemArr[e], 1);
            }
        }
        this.all_cur_page = 1;
        this.requestAllMatchList(true, true);
    }
    onMainItemCheckClick(t, e) {
        if (SoundManager.shared().playFx("click"), sys.now() - this._lastClick < 500) {
            return;
        }
        if (this._lastClick = sys.now(), !sys.isObjectValid(SportCricket_Manager.shared().sortSourceData)) {
            return;
        }
        SportCricket_Manager.shared().sortSourceData.mSortType = this._curSortType;
        let i = { fromType: 0, source: SportCricket_Manager.shared().sortSourceData, mainCall: t => {
                this._curSortType = t;
                this.all_cur_page = 1;
                this.updateSortTypeCheck();
                this.requestAllMatchList(true, true);
            } };
        Utils.shared().showSportCricket_gameSortView(i);
    }
    updateSortTypeCheck() {
        let t = this.sortNode.getChildByName("sort_scrollview").getComponent(ScrollView).content.getChildByName("time_sort");
        0 == this._curSortType ? t.getChildByName("wz").getComponent(Label).string = "Starting Soon" : t.getChildByName("wz").getComponent(Label).string = "Popular";
    }
    onCidItemCheckClick(t, e) {
        if (SoundManager.shared().playFx("click"), sys.now() - this._lastClick < 500) {
            return;
        }
        this._lastClick = sys.now();
        let i = Number(e), a = SportCricket_Manager.shared().sortSourceData.match[i].cid;
        -1 == this._cidSelects.indexOf(a) ? (this._cidSelects.push(a), this.updateSortItemStatus(this._sortItemArr[i], 1)) : (this._cidSelects.splice(this._cidSelects.indexOf(a), 1), this.updateSortItemStatus(this._sortItemArr[i], 0));
        this.all_cur_page = 1;
        this.requestAllMatchList(true, true);
        this.updateFilterBtnStatus();
    }
    updateSortItemStatus(t, e) {
        ToolUtils.isObjValid(t) && (1 == e ? (t.getChildByName("ico").getComponent(Sprite).spriteFrame = this.sortBgImgs[1], t.getChildByName("wz").getComponent(Label).color = this.filter_select_color, i18nMgr.shared().changeLabelFont(t.getChildByName("wz").getComponent(Label), true)) : (t.getChildByName("ico").getComponent(Sprite).spriteFrame = this.sortBgImgs[0], t.getChildByName("wz").getComponent(Label).color = color(10, 10, 10), i18nMgr.shared().changeLabelFont(t.getChildByName("wz").getComponent(Label), false)));
    }
    updateGold(t) {
        let e = this.goldNode.getChildByName("coin");
        null != t && e && (e.getComponent(Label).string = ToolUtils.parse_double(t));
    }
    onCloseButtonClick(t, e) {
        if (SoundManager.shared().playFx("click"), "back_btn" == e) {
            if (this._closed) {
                return;
            }
            this.onBackView();
        }
    }
    initView() {
        SportCricket_Manager.shared().cricket_curMatchId = 0;
        this.fitScreen();
        this.topNode.getChildByName("back_btn").active = 0 == GameConfig.GAME_HALL_THEME;
        this.topNode.getChildByName("title").active = 0 == GameConfig.GAME_HALL_THEME;
        this.topNode.getChildByName("add_gold").active = 0 == GameConfig.GAME_HALL_THEME;
    }
    onItemClick(t, e) {
        if (SoundManager.shared().playFx("click"), sys.now() - this._lastClick < 500) {
            return;
        }
        this._lastClick = sys.now();
        let i = ToolUtils.parseJson(e), a = i.match_id;
        if (1 == this.curTab && 2 == i.status) {
            if (SportCricket_Manager.shared().cricket_completeInfo[a] && sys.isObjectValid(SportCricket_Manager.shared().cricket_completeInfo[a].endInfo)) {
                let t = { completeInfo: SportCricket_Manager.shared().cricket_completeInfo[a], match_id: a, target: this.node };
                Utils.shared().showSportCricket_end(t);
            }
            else {
                if (0 == sys.getNetworkType()) {
                    return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text91"), 3, 0, ToolUtils.getIsNormalDirection());
                }
                Utils.shared().showLoading(11, true, (() => {
                    0 == sys.getNetworkType() ? Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text91"), 3, 0, ToolUtils.getIsNormalDirection()) : Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
                }), ToolUtils.getIsNormalDirection());
                let t = { uid: User.shared().data.uid, match_id: a };
                HttpManager.shared().doGetCommonRequest(t, HttpRequest.Yes11_EndTopInfo, ((t, e, i) => {
                    if (Utils.shared().hideLoading(), 200 != i) {
                        alert("The login timed out, please try again");
                        0 == sys.getNetworkType() ? Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text91"), 3, 0, ToolUtils.getIsNormalDirection()) : Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
                    }
                    else {
                        let t = ToolUtils.parseJson(e);
                        if (0 == t.ret) {
                            sys.isObjectValid(SportCricket_Manager.shared().cricket_completeInfo[a]) || (SportCricket_Manager.shared().cricket_completeInfo[a] = {});
                            SportCricket_Manager.shared().cricket_completeInfo[a].endInfo = t.data;
                            let e = { completeInfo: SportCricket_Manager.shared().cricket_completeInfo[a], match_id: a, target: this.node };
                            Utils.shared().showSportCricket_end(e);
                        }
                        else {
                            ToolUtils.isSafeString(t.desc).length > 0 && Utils.shared().showToast(t.desc, 3, 0, ToolUtils.getIsNormalDirection());
                        }
                    }
                }));
            }
        }
        else {
            if (1 == i.status && sys.isObjectValid(i.can_join) && 0 == i.can_join) {
                return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("yes11.canjoin_tip"), 3, 0, ToolUtils.getIsNormalDirection());
            }
            let t = { match_id: a, source: i, lastNode: this.rootNode };
            Utils.shared().showSportCricket_chooseGame(t);
        }
    }
    onEnable() {
        1 == GameConfig.GAME_HALL_THEME && (User.shared().getHallInfo(), 0 != this.firstCount && this.updateTabContent(), this.firstCount++);
        User.shared().send_request_update_yesgame_state(1);
    }
    onDisable() {
        User.shared().send_request_update_yesgame_state(0);
    }
    onButtonClick(t, e) {
        if (SoundManager.shared().playFx("click"), !(sys.now() - this._lastClick < 500)) {
            if (this._lastClick = sys.now(), "tab0" == e) {
                if (0 == this.curTab) {
                    return;
                }
                this.curTab = 0;
                this.updateTabView();
                this.updateTabContent();
            }
            else if ("tab1" == e) {
                if (1 == this.curTab) {
                    return;
                }
                this.curTab = 1;
                this.updateTabView();
                this.updateTabContent();
            }
            else if ("reload" == e) {
                this.updateTabContent();
            }
            else if ("filter" == e) {
                if (!sys.isObjectValid(SportCricket_Manager.shared().sortSourceData)) {
                    return;
                }
                let t = { fromType: 1, source: SportCricket_Manager.shared().sortSourceData, cids: this._cidSelects.slice(), cidCall: t => {
                        this._cidSelects = t;
                        this.updateSortCidCheck(t);
                        this.updateFilterBtnStatus();
                    } };
                Utils.shared().showSportCricket_gameSortView(t);
            }
            else if ("add_chip" == e) {
                Utils.shared().showStoreView(null, null);
                User.shared().updatePayScene(PhpReportDefined.pay_scene.hall_cricket);
            }
            else if ("view_more" == e) {
                0 == this.curTab ? 1 != this.all_has_next_page || this._isSendMsg || (this._isSendMsg = true, this.all_cur_page = this.all_cur_page + 1, this.requestAllMatchList(false)) : 1 != this.my_has_next_page || this._isSendMsg || (this._isSendMsg = true, this.my_cur_page = this.my_cur_page + 1, this.requestMyMatchList(false));
            }
            else if ("gullak" == e) {
                let t = {};
                Utils.shared().doJumpLogic(PushEvent.JUMP_TO_Gullak, t, { isNext: false, bWithTip: true, link_id: sys.now(), reportEvtId: 4, reportScene: 2 });
                User.shared().updatePayScene(PhpReportDefined.pay_scene.hall_cricket);
            }
        }
    }
    updateTabContent() {
        if (this.allMatchScrollView.node.active = 0 == this.curTab, this.myMatchScrollView.node.active = 1 == this.curTab, this.rootNode.getChildByName("sort_node").active = 0 == this.curTab, this.allMatchScrollView.scrollToTop(0), this.myMatchScrollView.scrollToTop(0), this.rootNode.getChildByName("nodata").active = false, this.taskAwardIconMap.clear(), 0 == this.curTab) {
            let t = true;
            sys.isObjectValid(this.all_listData) && this.all_listData.length > 0 && (t = false);
            this.all_cur_page = 1;
            this.requestAllMatchList(t, true);
        }
        else {
            let t = true;
            sys.isObjectValid(this.my_listData) && this.my_listData.length > 0 && (t = false);
            this.my_cur_page = 1;
            this.requestMyMatchList(t, true);
        }
    }
    updateGullakBtnStatus(t, e, i) {
        if (1 == GameConfig.GAME_HALL_THEME) {
            return;
        }
        let a = this.rootNode.getChildByName("top_node").getChildByName("gullak_btn");
        if (ToolUtils.isObjValid(a) && (a.active = 1 == t, 1 == t)) {
            let t = a.getChildByName("anim").getComponent(sp.Skeleton);
            t.clearTracks();
            t.setToSetupPose();
            i ? (t.setAnimation(0, "2", false), t.setCompleteListener((() => {
                t.setCompleteListener(null);
                t.clearTracks();
                t.setToSetupPose();
                0 == e ? t.setAnimation(0, "0", true) : t.setAnimation(0, "1", true);
            }))) : 0 == e ? t.setAnimation(0, "0", true) : t.setAnimation(0, "1", true);
        }
    }
    onBackView(t = true) {
        t && (Utils.shared().hideLoading(), ToolUtils.isObjValid(this.node) && TweenTool.stopNodeAction(this.node), this._scheduleAct && TweenTool.stopAction(this._scheduleAct), this.bShowPushAnim ? (this._closed = true, ToolUtils.isObjValid(this._lastNode) && (this._lastNode.active = true), PushCenter.shared().pushEvent(PushEvent.NoticePlayerNotInLineUp), ToolUtils.showPushAnim(this.node, 1, (() => {
            ToolUtils.isObjValid(this.node) && (this.node.destroy(), 0 == GameConfig.GAME_HALL_THEME && User.shared().getHallPopList(true));
        }))) : (ToolUtils.isObjValid(this._lastNode) && (this._lastNode.active = true), ToolUtils.isObjValid(this.node) && this.node.destroy(), 0 == GameConfig.GAME_HALL_THEME && User.shared().getHallPopList(true)));
    }
    fitScreen() {
        ToolUtils.adaptSafeArea(this.rootNode);
        let t = view.getVisibleSize();
        this.node.getComponent(Widget).enabled = true;
        this.node.getComponent(UITransform).setContentSize(t.width, t.height);
        let e = sys.getSafeAreaRect().y;
        GameConfig.GAME_HALL_THEME;
        this.node.getComponent(Widget).bottom = -e;
        this.node.getComponent(Widget).updateAlignment();
        this.rootNode.getComponent(Widget).updateAlignment();
        this.topNode.getComponent(Widget).updateAlignment();
        this.rootNode.getChildByName("select_diban").getComponent(Widget).updateAlignment();
        this.rootNode.getChildByName("sort_node").getComponent(Widget).updateAlignment();
        this.allMatchScrollView.getComponent(Widget).updateAlignment();
        this.allMatchScrollView.node.getChildByName("view").getComponent(Widget).updateAlignment();
        this.myMatchScrollView.getComponent(Widget).updateAlignment();
        this.myMatchScrollView.node.getChildByName("view").getComponent(Widget).updateAlignment();
    }
}
