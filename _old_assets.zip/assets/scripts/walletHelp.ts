// @ts-nocheck
// Recovered from index.js:667
import { _decorator, Label, Node } from "cc";
import PushCenter from "./PushCenter";
import GameConfig from "./GameConfig";
import SoundManager from "./SoundManager";
import BaseLayer from "./BaseLayer";
import i18nMgr from "./i18nMgr";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("walletHelp")
export class walletHelp extends BaseLayer {
    @property(Node)
    public ruleNode: Node = null;
    @property(Label)
    public ruleLabel: Label = null;
    public _nType: number = 0;
    setParam(e) {
        this._nType = e;
    }
    start() {
        super.start();
        ToolUtils.showFullScreen(this.node.getChildByName("mask"));
        0 == this._nType ? this.ruleLabel.getComponent(Label).string = i18nMgr.shared().getValueByKey("store.help_txt1") : 1 == this._nType && (this.ruleLabel.getComponent(Label).string = i18nMgr.shared().getValueByKey("store.bonus_help"));
        ToolUtils.startShowAnim(this.ruleNode);
    }
    dealMultipleLanguages() {
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().pushEvent(GameConfig.Update_Wallet);
        PushCenter.shared().removeListenersByTag(this);
        this.unscheduleAllCallbacks();
    }
    button_click(e, t) {
        SoundManager.shared().playFx("click");
        "helpClose" == t && ToolUtils.isObjValid(this.node) && this.node.destroy();
    }
}
