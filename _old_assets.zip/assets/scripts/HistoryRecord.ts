// @ts-nocheck
// Recovered from index.js:189
import { _decorator, Component, color, instantiate, Label, Node, Prefab, ScrollView, size, SpriteAtlas, UITransform } from "cc";
import SoundManager from "./SoundManager";
import Utils from "./Utils";
import HttpManager from "./HttpManager";
import User from "./User";
import NetConfig from "./NetConfig";
import "./GameConfig";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("HistoryRecord")
export default class HistoryRecord extends Component {
    @property(Label)
    public label: Label = null;
    @property
    public text: string = "hello";
    @property(Prefab)
    public item: Prefab = null;
    @property(SpriteAtlas)
    public myAtlas: SpriteAtlas = null;
    @property(Node)
    public noData: Node = null;
    public mFlag: number = 1;
    onClickByFlag(t, e) {
        SoundManager.shared().playFx("click");
        this.updateInfo(null, e);
    }
    updateInfo(t, e) {
        this.mFlag = e;
        1 == e ? (Utils.shared().setImage(this.node.getChildByName("withdraw_tab"), "tab_off", this.myAtlas), Utils.shared().setImage(this.node.getChildByName("payment_tab"), "tab_on", this.myAtlas), this.node.getChildByName("payment_tab").getChildByName("value").getComponent(Label).color = color(255, 255, 255), this.node.getChildByName("withdraw_tab").getChildByName("value").getComponent(Label).color = color(151, 149, 158)) : (Utils.shared().setImage(this.node.getChildByName("withdraw_tab"), "tab_on", this.myAtlas), Utils.shared().setImage(this.node.getChildByName("payment_tab"), "tab_off", this.myAtlas), this.node.getChildByName("withdraw_tab").getChildByName("value").getComponent(Label).color = color(255, 255, 255), this.node.getChildByName("payment_tab").getChildByName("value").getComponent(Label).color = color(151, 149, 158));
        e = 1 == e ? 2 : 1;
        let i = { uid: User.shared().data.uid, type: e };
        HttpManager.shared().httpRequest(NetConfig.doWithdrawRecode, "RecordLists", i, this.dealHttpBack.bind(this));
    }
    dealHttpBack(t, e, i) {
        if (0 == e.length) {
            return;
        }
        let a = ToolUtils.parseJson(e);
        if (0 == a.ret) {
            let t = [];
            if (undefined !== a.data && undefined !== a.data.list && (t = a.data.list), t.length > 0) {
                this.noData.active = false;
                let e = this.node.getChildByName("scrollview");
                e.active = true;
                let i = e.getComponent(ScrollView);
                i.content.destroyAllChildren();
                let a = -430;
                for (let e = 0, o = t.length; e < o; e++) {
                    let o = instantiate(this.item);
                    1 == this.mFlag ? Utils.shared().setStr(o.getChildByName("title"), "Add Cash") : Utils.shared().setStr(o.getChildByName("title"), "Withdraw");
                    Utils.shared().setStr(o.getChildByName("flowid"), "Flow ID: " + t[e].id);
                    Utils.shared().setStr(o.getChildByName("date"), "" + t[e].times);
                    Utils.shared().setStr(o.getChildByName("money"), "+ ₹" + t[e].amount);
                    let s = "Processing";
                    1 == t[e].status ? (s = "Success", o.getChildByName("flag").getComponent(Label).color = color(28, 176, 35)) : 2 == t[e].status ? (s = "Fail", o.getChildByName("flag").getComponent(Label).color = color(255, 73, 53)) : 3 == t[e].status && (s = "Roll back");
                    Utils.shared().setStr(o.getChildByName("flag"), s);
                    a = -430 - 160 * e;
                    o.setPosition(-10, a);
                    i.content.addChild(o);
                }
                let o = i.content.getComponent(UITransform);
                a = -a;
                a > o.height && o.setContentSize(size(o.width, a));
                i.scrollToPercentVertical(1);
            }
            else {
                this.node.getChildByName("scrollview").active = false;
                this.noData.active = true;
            }
        }
        else {
            Utils.shared().showToast(a.desc, 2);
        }
    }
    onclickByClose(t, e) {
        SoundManager.shared().playFx("click");
        ToolUtils.isObjValid(this.node) && this.node.destroy();
    }
}
