// @ts-nocheck
// Recovered from index.js:233
import { _decorator, Label, Node, Sprite, SpriteFrame, sys, UITransform, v3, Vec3, view } from "cc";
import SoundManager from "./SoundManager";
import BaseLayer from "./BaseLayer";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("LetterKeyBoard")
export class LetterKeyBoard extends BaseLayer {
    @property(Node)
    public rootNode: Node = null;
    @property(Node)
    public bgNode: Node = null;
    @property([SpriteFrame])
    public shiftFrame: SpriteFrame[] = [];
    public big_keys: any[] = ["Q", "W", "E", "R", "T", "Y", "U", "I", "O", "P", "A", "S", "D", "F", "G", "H", "J", "K", "L", "Z", "X", "C", "V", "B", "N", "M"];
    public small_keys: any[] = ["q", "w", "e", "r", "t", "y", "u", "i", "o", "p", "a", "s", "d", "f", "g", "h", "j", "k", "l", "z", "x", "c", "v", "b", "n", "m"];
    public num_keys: any[] = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9"];
    public big_open: boolean = false;
    public cb: any = null;
    start() {
        super.start();
        this.changeLetterKey();
        let e = view.getVisibleSize(), t = this.rootNode.getComponent(UITransform);
        this.bgNode.getComponent(UITransform);
        ToolUtils.getOrientation() ? (this.node.setRotationFromEuler(new Vec3(0, 0, 90)), t.setContentSize(e.height, e.width), this.bgNode.setPosition(v3(this.bgNode.position.x, -e.width / 2))) : (t.setContentSize(e.width, e.height), this.rootNode.setPosition(v3(0, -sys.getSafeAreaRect().y, 0)));
    }
    setParaData(e) {
        this.cb = e;
    }
    onNumerKeyClick(e, t) {
        SoundManager.shared().playFx("click");
        let i = { type: 1, text: t };
        this.cb && this.cb(i);
    }
    onShiftBtnClick(e, t) {
        SoundManager.shared().playFx("click");
        this.big_open = !this.big_open;
        this.changeLetterKey();
    }
    changeLetterKey() {
        for (let e = 0; e < 26; e++) {
            let t = this.bgNode.getChildByName(ToolUtils.format("key_${0}", e));
            if (t) {
                let i = t.getChildByName("wz");
                this.big_open ? i.getComponent(Label).string = this.big_keys[e] : i.getComponent(Label).string = this.small_keys[e];
            }
        }
        let e = this.bgNode.getChildByName("key_shift");
        if (e) {
            let t = e.getChildByName("icon");
            this.big_open ? t.getComponent(Sprite).spriteFrame = this.shiftFrame[1] : t.getComponent(Sprite).spriteFrame = this.shiftFrame[0];
        }
    }
    onSpaceBtnClick(e, t) {
        SoundManager.shared().playFx("click");
        let i = { type: 1, text: " " };
        this.cb && this.cb(i);
    }
    onDeleteBtnClick(e, t) {
        SoundManager.shared().playFx("click");
        let i = { type: -1 };
        this.cb && this.cb(i);
    }
    onLetterBtnClick(e, t) {
        SoundManager.shared().playFx("click");
        let i = "";
        i = this.big_open ? this.big_keys[Number(t)] : this.small_keys[Number(t)];
        let s = { type: 1, text: i };
        this.cb && this.cb(s);
    }
    onCloseBtnClick(e, t) {
        SoundManager.shared().playFx("click");
        ToolUtils.isObjValid(this.node) && this.node.destroy();
    }
}
