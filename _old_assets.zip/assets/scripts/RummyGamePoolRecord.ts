// @ts-nocheck
// Recovered from index.js:451
import { _decorator, instantiate, Label, Node, ScrollView, sys, UITransform } from "cc";
import SoundManager from "./SoundManager";
import RummyDataManager, { RUMMY_GAME_TYPE } from "./RummyDataManager";
import User from "./User";
import BaseLayer from "./BaseLayer";
import i18nMgr from "./i18nMgr";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("RummyGamePoolRecord")
export default class RummyGamePoolRecord extends BaseLayer {
    @property(Node)
    public bgView: Node = null;
    @property(Node)
    public layer1: Node = null;
    @property(Node)
    public layer2: Node = null;
    public typeNum: number = 0;
    public data: any = undefined;
    public gameController: any = undefined;
    onLoad() {
        this.bIsInGame = true;
    }
    start() {
        super.start();
        ToolUtils.showFullScreen(this.node.getChildByName("bg1"));
        ToolUtils.startShowAnim(this.node.getChildByName("rootNode"));
    }
    onDestroy() {
        super.onDestroy();
    }
    initView(e, t, i, a) {
        this.typeNum = e;
        this.data = t;
        let l = Array.isArray(t.record) ? t.record : [];
        this.gameController = i;
        this.tid_key = a;
        // A response replaces the complete scoreboard, including an empty new match.
        for (const layer of [this.layer1, this.layer2]) {
            const content = layer.getChildByName("ListView1").getChildByName("view").getChildByName("content");
            content.destroyAllChildren();
            content.removeAllChildren();
            for (let column = 2; column < 8; column++) {
                const out = layer.getChildByName("Score_layout").getChildByName("out" + column);
                if (out) out.active = false;
            }
        }
        for (let e = 2; e < 8; e++) {
            let t = "";
            t = "Text" + e;
            this.layer1.getChildByName("title_layout").getChildByName(t).getComponent(Label).string = "";
            this.layer1.getChildByName("item").getChildByName(t).getComponent(Label).string = "";
            this.layer1.getChildByName("Score_layout").getChildByName(t).getComponent(Label).string = "";
            this.layer1.getChildByName("Sum_layout").getChildByName(t).getComponent(Label).string = "";
            this.layer2.getChildByName("title_layout").getChildByName(t).getComponent(Label).string = "";
            this.layer2.getChildByName("item").getChildByName(t).getComponent(Label).string = "";
            this.layer2.getChildByName("Score_layout").getChildByName(t).getComponent(Label).string = "";
            2 == e && (i18nMgr.shared().changeLabelLanguage(this.layer1.getChildByName("title_layout").getChildByName(t).getComponent(Label), "gameRummy_deals_record.me"), i18nMgr.shared().changeLabelLanguage(this.layer2.getChildByName("title_layout").getChildByName(t).getComponent(Label), "gameRummy_deals_record.me"));
        }
        let o = [];
        for (let e = 0, t = l.length; e < t; e++) {
            l[e].uid == User.shared().data.uid ? o.unshift(l[e]) : o.push(l[e]);
        }
        1 == this.typeNum ? this.showlayer1(o) : this.showlayer2(o);
    }
    showlayer1(e) {
        this.layer1.active = true;
        this.layer2.active = false;
        let t = "", i = "", a = e.length, l = this.layer1.getChildByName("title_layout"), o = this.layer1.getChildByName("ListView1").getChildByName("view").getChildByName("content"), m = this.layer1.getChildByName("Score_layout"), g = this.layer1.getChildByName("Sum_layout"), c = this.layer1.getChildByName("item");
        c.active = false;
        let N = 0;
        if (e.length > 0 && null != e[0].detail_score) {
            for (let o = 0; o < a; o++) {
                let a = o + 2;
                if (null != e[o].name) {
                    t = "Text" + a;
                    let i = e[o].name;
                    i = ToolUtils.GetShortName2(i, 8, true);
                    e[o].uid == User.shared().data.uid ? i18nMgr.shared().changeLabelLanguage(l.getChildByName(t).getComponent(Label), "gameRummy_deals_record.me") : l.getChildByName(t).getComponent(Label).string = i + "";
                }
                if (null != e[o].total_score && (t = "Text" + a, m.getChildByName(t).getComponent(Label).string = e[o].total_score + "", sys.isObjectValid(e[o].isDisuse))) {
                    let t = m.getChildByName("out" + a);
                    sys.isObjectValid(t) && (t.active = 1 == e[o].isDisuse);
                }
                1 == e[o].is_win ? (t = "Text" + a, i = 1 == RummyDataManager.shared().rummyInfos.get(this.tid_key).crashModel ? "+" + ToolUtils.parse_ChipNum2(e[o].prize) : "+₹" + ToolUtils.parse_double(e[o].prize), g.getChildByName(t).getComponent(Label).string = i + "") : (t = "Text" + a, g.getChildByName(t).getComponent(Label).string = "--");
                null != e[o].detail_score && e[o].detail_score.length > 0 && N < e[o].detail_score.length && (N = e[o].detail_score.length);
            }
            if (RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType == RUMMY_GAME_TYPE.DEALS) {
                let e = instantiate(c);
                e.active = true;
                i18nMgr.shared().changeLabelLanguage(e.getChildByName("Text1").getComponent(Label), "gameRummy_deals_record.start");
                for (let i = 0; i < a; i++) {
                    t = "Text" + (i + 2);
                    e.getChildByName(t).getComponent(Label).string = this.data.start_score + "";
                }
                o.addChild(e);
            }
            for (let i = 0; i < N; i++) {
                let l = instantiate(c);
                l.active = true;
                let s = i + 1;
                l.getChildByName("Text1").getComponent(Label).string = s + "";
                for (let o = 0; o < a; o++) {
                    if (t = "Text" + (o + 2), null != e[o].detail_score[i]) {
                        let a = e[o].detail_score[i].score;
                        l.getChildByName(t).getComponent(Label).string = a + "";
                        1 == e[o].detail_score[i].isRejoin && (l.getChildByName(t).getChildByName("img").active = true);
                    }
                    else {
                        l.getChildByName(t).getComponent(Label).string = "--";
                    }
                }
                o.addChild(l);
            }
            N > 4 && this.layer1.getChildByName("ListView1").getComponent(ScrollView).scrollToBottom(0);
        }
    }
    showlayer2(e) {
        this.layer2.active = true;
        this.layer1.active = false;
        let t = "", i = e.length, a = this.layer2.getChildByName("title_layout"), l = this.layer2.getChildByName("ListView1").getChildByName("view").getChildByName("content"), o = (l.getComponent(UITransform).contentSize, this.layer2.getChildByName("Score_layout")), g = this.layer2.getChildByName("item");
        g.active = false;
        let c = 0;
        if (e.length > 0 && null != e[0].detail_score) {
            for (let l = 0; l < i; l++) {
                let i = l + 2;
                if (null != e[l].name) {
                    t = "Text" + i;
                    let o = e[l].name;
                    o = ToolUtils.GetShortName2(o, 8, true);
                    e[l].uid == User.shared().data.uid ? i18nMgr.shared().changeLabelLanguage(a.getChildByName(t).getComponent(Label), "gameRummy_deals_record.me") : a.getChildByName(t).getComponent(Label).string = o + "";
                }
                if (null != e[l].total_score && (t = "Text" + i, o.getChildByName(t).getComponent(Label).string = e[l].total_score + "", sys.isObjectValid(e[l].isDisuse))) {
                    let t = o.getChildByName("out" + i);
                    sys.isObjectValid(t) && (t.active = 1 == e[l].isDisuse);
                }
                null != e[l].detail_score && e[l].detail_score.length > 0 && c < e[l].detail_score.length && (c = e[l].detail_score.length);
            }
            if (RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType == RUMMY_GAME_TYPE.DEALS) {
                let e = instantiate(g);
                e.active = true;
                i18nMgr.shared().changeLabelLanguage(e.getChildByName("Text1").getComponent(Label), "gameRummy_deals_record.start");
                2 == i18nMgr.shared().language && (e.getChildByName("Text1").getComponent(Label).fontSize = 20);
                for (let a = 0; a < i; a++) {
                    t = "Text" + (a + 2);
                    e.getChildByName(t).getComponent(Label).string = this.data.start_score + "";
                }
                l.addChild(e);
            }
            for (let a = 0; a < c; a++) {
                let o = instantiate(g);
                o.active = true;
                let s = a + 1;
                o.getChildByName("Text1").getComponent(Label).string = s + "";
                for (let l = 0; l < i; l++) {
                    if (t = "Text" + (l + 2), null != e[l].detail_score && null != e[l].detail_score[a]) {
                        let i = e[l].detail_score[a].score;
                        o.getChildByName(t).getComponent(Label).string = i + "";
                        1 == e[l].detail_score[a].isRejoin && (o.getChildByName(t).getChildByName("img").active = true);
                    }
                    else {
                        o.getChildByName(t).getComponent(Label).string = "--";
                    }
                }
                l.addChild(o);
            }
            c > 4 && this.layer2.getChildByName("ListView1").getComponent(ScrollView).scrollToBottom(0);
        }
    }
    touchBtnEvent(e, t) {
        if (SoundManager.shared().playFx("click"), "exit" == t) {
            RummyDataManager.shared().rummyInfos.get(this.tid_key).isInGameing = 0;
            this.gameController.exitCallBack(1);
        }
        else if ("start" == t && (User.shared().send_client_consume_table_record_laba(this.tid_key), this.gameController.onDealBtnAction("start"), RummyDataManager.shared().rummyInfos.has(this.tid_key) && User.shared().data.money < RummyDataManager.shared().rummyInfos.get(this.tid_key).entry_fee)) {
            return;
        }
        ToolUtils.isObjValid(this.node) && this.node.destroy();
    }
}
