// @ts-nocheck
// Recovered from index.js:639
import { _decorator, Button, color, instantiate, Label, LabelShadow, Layout, Node, RichText, ScrollView, sp, Sprite, SpriteAtlas, SpriteFrame, sys, tween, v3, Vec3 } from "cc";
import BaseLayer from "./BaseLayer";
import SoundManager from "./SoundManager";
import { TLog } from "./TLog";
import Utils from "./Utils";
import PushCenter from "./PushCenter";
import PushEvent from "./PushEvent";
import HttpManager from "./HttpManager";
import User from "./User";
import i18nMgr from "./i18nMgr";
import ReportConfig from "./ReportConfig";
import GameConfig from "./GameConfig";
import { HttpRequest } from "./HttpRequestName";
import TweenTool from "./TweenTool";
import BundleNameDefined from "./BundleNameDefined";
import CommDefine, { BagItemType } from "./CommDefine";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
var ct;
var ut;
(!function (e) {
    e[e.NotTriggered = 1] = "NotTriggered";
    e[e.Challenge = 2] = "Challenge";
    e[e.Finish = 3] = "Finish";
}(ct || (ct = {})));
(function (e) {
    e.Dj = "dh1_dj";
    e.Zs = "dh2_zs";
    e.Jc = "dh3_jc";
    e.Xh = "dh4_xh";
    e.Cc_dj = "dh6_cc_dj";
    e.Cc_wdj = "dh5_cc_wdj";
    e.Jt = "dh7_jt";
    e.Dk = "dh8_dk";
    e.Dkhx = "dh9_dkhx";
}(ut || (ut = {})));
@ccclass("Treasure")
export class Treasure extends BaseLayer {
    @property(Node)
    public btn_close_mask: Node = null;
    @property(Node)
    public rootNode: Node = null;
    @property(Node)
    public boomBalanceNode: Node = null;
    @property(Node)
    public boomThinkNode: Node = null;
    @property(Node)
    public finishNode: Node = null;
    @property(Node)
    public ruleNode: Node = null;
    @property(Node)
    public btn_getReward: Node = null;
    @property(Node)
    public btn_cashspend: Node = null;
    @property(Node)
    public btn_shop: Node = null;
    @property(Label)
    public rewardTitle_root: Label = null;
    @property(Node)
    public choose_root: Node = null;
    @property(Node)
    public rewardNode_root: Node = null;
    @property(Node)
    public mainNode: Node = null;
    @property(Node)
    public guideNode: Node = null;
    @property([Node])
    public rewardMoban_root_arr: Node[] = [];
    @property(Node)
    public bigPrice_main: Node = null;
    @property(Node)
    public level: Node = null;
    @property(ScrollView)
    public levelScrollView: ScrollView = null;
    @property(Node)
    public levelMoban: Node = null;
    @property(Node)
    public level_sel: Node = null;
    @property(Node)
    public box: Node = null;
    @property([Node])
    public boxNodeArr: Node[] = [];
    @property(RichText)
    public recharge: RichText = null;
    @property(RichText)
    public bigPrice_guide: RichText = null;
    @property([Node])
    public challagesAnimGuide: Node[] = [];
    @property(Node)
    public grandPrize: Node = null;
    @property(Node)
    public allAccuReaward: Node = null;
    @property(Node)
    public rewardNode_bal: Node = null;
    @property(Node)
    public rewardMoban_bal: Node = null;
    @property(Node)
    public btn_balance: Node = null;
    @property(RichText)
    public bigPrice_finish: RichText = null;
    @property([Node])
    public challagesAnimFinish: Node[] = [];
    @property(Label)
    public ruleLabel: Label = null;
    @property([SpriteFrame])
    public getRewardBtnSpriteArr: SpriteFrame[] = [];
    @property([SpriteFrame])
    public levelMobanBgArr: SpriteFrame[] = [];
    @property([SpriteFrame])
    public up_reward_Sprite: SpriteFrame[] = [];
    @property(SpriteFrame)
    public spend_item_sprite: SpriteFrame = null;
    @property(SpriteAtlas)
    public rewardPlist: SpriteAtlas = null;
    public TAG: string = "Treasure";
    public _linkId: number = 0;
    public _reportScene: number = 1;
    public _bCanSend: boolean = false;
    public _from_source: number = 0;
    public lastUiState: any = undefined;
    public isNext: boolean = false;
    public _callback: any = null;
    public _lastClick: number = 0;
    public _lastClick_getReward: number = 0;
    public _lastClick_Balance: number = 0;
    public _lastClick_LeaveBal: number = 0;
    public _has_close: boolean = false;
    public _reqTreasurePageing: boolean = false;
    public _reqTreasurePageAct: any = null;
    public _reqTreasurePageActTime: number = 3;
    public storageBoomSkin: string = "boomSkin";
    public isSecondOpen: boolean = false;
    public isOpeningBox: boolean = false;
    public isSwitchLeveling: boolean = false;
    public boxDetailArr: any[] = [];
    public boxAnimCompArr: any[] = [];
    public mainBoxRandomSkinArr: any[] = [];
    public boxChildNodeArr: any[] = [];
    public lastAccuRewardList: any[] = [];
    public boxSkinArr: any[] = ["yellow", "Purple", "blue", "green", "red"];
    public boxPresetMidPosArr: any[] = [new Vec3(-130, 80, 0), new Vec3(130, 80, 0), new Vec3(-130, -152, 0), new Vec3(130, -152, 0)];
    public jlk_chuxian: string = "1_chuxian";
    public jlk_xh: string = "2_xh";
    public jlk_kstx: string = "3_kstx";
    public ani_hd_jl_chacao_1: string = "ani_hd_jl_chacao_1";
    public ani_hd_jl_chacao_2: string = "ani_hd_jl_chacao_2";
    public ani_hd_baoxiangcg_daoju: string = "ani_hd_baoxiangcg_daoju";
    public ani_hd_baoxiangcg_daoju_1: string = "ani_hd_baoxiangcg_daoju_1";
    public ani_hd_baoxiangcg_daoju_2: string = "ani_hd_baoxiangcg_daoju_2";
    public ani_hd_baoxiangcg_daoju_3: string = "ani_hd_baoxiangcg_daoju_3";
    public ani_hd_baoxiangcg_daoju_4: string = "ani_hd_baoxiangcg_daoju_4";
    public guideRandomChallSkinArr: any[] = [];
    public guideRandomSkinPreValues: any[] = [];
    public guideBoxCycleScheduleId: any = null;
    public challAnimGuideCompArr: any[] = [];
    public challAnimGuideBoxIconArr: any[] = [];
    public challAnimGuidePosArr: any[] = [new Vec3(-305, 0, 0), new Vec3(0, 0, 0), new Vec3(305, 0, 0), new Vec3(610, 0, 0), new Vec3(905, 0, 0)];
    public finishRandomChallSkinArr: any[] = [];
    public finishRandomSkinPreValues: any[] = [];
    public finishBoxCycleScheduleId: any = null;
    public challAnimFinishCompArr: any[] = [];
    public challAnimFinishBoxIconArr: any[] = [];
    public challAnimFinishPosArr: any[] = [new Vec3(-305, 0, 0), new Vec3(0, 0, 0), new Vec3(305, 0, 0), new Vec3(610, 0, 0), new Vec3(905, 0, 0)];
    public _noboomTweenDealyArr: any[] = [];
    public _haveboomTweenDealyArr: any[] = [];
    public _timerNode: any = null;
    initParaData(e, t) {
        sys.isObjectValid(e) && sys.isObjectValid(e.isNext) && (this.isNext = e.isNext);
        sys.isObjectValid(e) && sys.isObjectValid(e.reportScene) && (this._reportScene = e.reportScene);
        sys.isObjectValid(e) && sys.isObjectValid(e.link_id) && e.link_id > 0 && (this._linkId = e.link_id);
        sys.isObjectValid(e) && sys.isObjectValid(e.pop_souce) && (this._from_source = e.from_source);
        this._callback = t;
    }
    onLoad() {
        this._timerNode = new Node("TreasureTimerNode");
        this.rootNode.active = false;
        this.boomBalanceNode.active = false;
        this.boomThinkNode.active = false;
        this.guideNode.active = false;
        this.finishNode.active = false;
        this.ruleNode.active = false;
        this.levelMoban.active = false;
        this.rewardMoban_bal.active = false;
        this.btn_close_mask.active = true;
        this.stopGuideBoxCycleSchedule();
        this.stopFinishBoxCycleSchedule();
        ToolUtils.showFullScreen(this.node.getChildByName("mask"));
        ToolUtils.showFullScreen(this.ruleNode.getChildByName("mask"));
        this.getMainData() ? this.initView() : Utils.shared().showLoading(10, true, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
        }));
        let e = this.btn_getReward.getChildByName("free"), t = this.bigPrice_main.getChildByName("bigPriceLabel");
        if (this.btn_balance.getChildByName("Label").active = false, 2 == i18nMgr.shared().language) {
            e.getChildByName("Label").getComponent(Label).fontSize = 17;
            t.getComponent(RichText).fontSize = 20;
            for (let e = 0, t = this.rewardMoban_root_arr.length; e < t; e++) {
                this.rewardMoban_root_arr[e].getChildByName("name").getComponent(Label).fontSize = 24;
            }
            this.rewardMoban_bal.getChildByName("name").getComponent(Label).fontSize = 24;
            this.recharge.getComponent(RichText).fontSize = 24;
            this.rootNode.getChildByName("choose_root").getComponent(Label).fontSize = 34;
            this.boomThinkNode.getChildByName("tips").getComponent(Label).fontSize = 22;
            this.boomThinkNode.getChildByName("btn_think").getChildByName("Label").getComponent(Label).fontSize = 26;
            this.grandPrize.position = new Vec3(0, -340, 0);
        }
        else {
            e.getChildByName("Label").getComponent(Label).fontSize = 20;
            t.getComponent(RichText).fontSize = 28;
            for (let e = 0, t = this.rewardMoban_root_arr.length; e < t; e++) {
                this.rewardMoban_root_arr[e].getChildByName("name").getComponent(Label).fontSize = 28;
            }
            this.rewardMoban_bal.getChildByName("name").getComponent(Label).fontSize = 28;
            this.recharge.getComponent(RichText).fontSize = 36;
            this.rootNode.getChildByName("choose_root").getComponent(Label).fontSize = 40;
            this.boomThinkNode.getChildByName("tips").getComponent(Label).fontSize = 28;
            this.boomThinkNode.getChildByName("btn_think").getChildByName("Label").getComponent(Label).fontSize = 32;
            this.grandPrize.position = new Vec3(0, -344, 0);
        }
    }
    start() {
        super.start();
        this._linkId = this._linkId > 0 ? this._linkId : sys.now();
        this._reportScene = this._reportScene >= 0 ? this._reportScene : ToolUtils.getIsInRoom() ? 2 : 1;
        SoundManager.shared().preLoadBundleSounds(BundleNameDefined.bundle_sound, "treasure");
        this.initBoxAnimCompArr();
        this.initChallAnimGuideCompArr();
        this.initChallAnimFinishCompArr();
        this.initNoBoomTweenDelay();
        this.initHaveBoomTweenDelay();
        this.requestTreasureMain();
        PushCenter.shared().addListener(PushEvent.CloseTreasure, (e => {
            ToolUtils.isObjValid(this.node) && this.onBackView();
        }), this);
        PushCenter.shared().addListener(PushEvent.GetLeafUpdateTreasure, (e => {
            ToolUtils.isObjValid(this.node) && this.requestTreasureMain(false);
        }), this);
        PushCenter.shared().addListener(GameConfig.Recharge, (e => {
            ToolUtils.isObjValid(this.node) && this.requestTreasureMain(false);
        }), this);
        PushCenter.shared().addListener(PushEvent.UpdateBagItem, (e => {
            if (ToolUtils.isObjValid(this.node) && sys.isObjectValid(e) && e && Array.isArray(e) && e.length > 0) {
                if (e.includes(BagItemType.LuckyLeaf)) {
                    if (User.shared().backPackData) {
                        let e = User.shared().getBackPackItemCount(BagItemType.LuckyLeaf) || 0;
                        this.updateShopLeafUI(e);
                    }
                    else {
                        this.requestTreasureMain(false);
                    }
                }
            }
        }), this);
    }
    initNoBoomTweenDelay() {
        this._noboomTweenDealyArr = [];
    }
    initHaveBoomTweenDelay() {
        this._haveboomTweenDealyArr = [];
    }
    stopNoBoomTweenDelay(e) {
        this._noboomTweenDealyArr && this._noboomTweenDealyArr[e] && (TweenTool.stopAction(this._noboomTweenDealyArr[e]), this._noboomTweenDealyArr[e] = null);
    }
    stopHaveBoomTweenDelay(e) {
        this._haveboomTweenDealyArr && this._haveboomTweenDealyArr[e] && (TweenTool.stopAction(this._haveboomTweenDealyArr[e]), this._haveboomTweenDealyArr[e] = null);
    }
    stopAllNoBoomTweenDelay() {
        if (this._noboomTweenDealyArr) {
            for (let e = 0; e < this._noboomTweenDealyArr.length; e++) {
                this._noboomTweenDealyArr[e] && TweenTool.stopAction(this._noboomTweenDealyArr[e]);
            }
        }
    }
    stopAllHaveBoomTweenDelay() {
        if (this._haveboomTweenDealyArr) {
            for (let e = 0; e < this._haveboomTweenDealyArr.length; e++) {
                this._haveboomTweenDealyArr[e] && TweenTool.stopAction(this._haveboomTweenDealyArr[e]);
            }
        }
    }
    initBoxAnimCompArr() {
        this.boxChildNodeArr = [];
        for (let e = 0; e < this.boxNodeArr.length; e++) {
            let t = this.boxNodeArr[e].getChildByName("Node");
            t && this.boxChildNodeArr.push(t);
        }
        this.boxAnimCompArr = [];
        for (let e = 0; e < this.boxChildNodeArr.length; e++) {
            let t = this.boxChildNodeArr[e].getComponent(sp.Skeleton);
            t && this.boxAnimCompArr.push(t);
        }
    }
    initChallAnimGuideCompArr() {
        this.challAnimGuideCompArr = [];
        this.challAnimGuideBoxIconArr = [0, 1, 0, 1, 0];
        for (let e = 0, t = this.challagesAnimGuide.length; e < t; e++) {
            this.challAnimGuideCompArr.push(this.challagesAnimGuide[e].getComponent(sp.Skeleton));
        }
    }
    initChallAnimFinishCompArr() {
        this.challAnimFinishCompArr = [];
        this.challAnimFinishBoxIconArr = [0, 1, 0, 1, 0];
        for (let e = 0, t = this.challagesAnimFinish.length; e < t; e++) {
            this.challAnimFinishCompArr.push(this.challagesAnimFinish[e].getComponent(sp.Skeleton));
        }
    }
    initView(e, t) {
        let i = this.getMainData();
        if (i) {
            Object.values(ct).includes(i.ui) && this.showViewByUiStatus(e, t);
        }
    }
    requestTreasureMain(e = true) {
        this._reqTreasurePageing || (this._reqTreasurePageActTime = 3, this._reqTreasurePageing = true, this.stopReqTreasurePageAct(), this._reqTreasurePageAct = TweenTool.myschedule(this.node, 1, (() => {
            this._reqTreasurePageActTime -= 1;
            this._reqTreasurePageActTime <= 0 && (this._reqTreasurePageing = false, this.stopReqTreasurePageAct());
        })), HttpManager.shared().doGetCommonRequest(null, HttpRequest.TreasurePage, ((t, i, o) => {
            if (Utils.shared().hideLoading(), this._reqTreasurePageing = false, this.stopReqTreasurePageAct(), 200 != o) {
                alert("The login timed out, please try again");
            }
            else {
                try {
                    let t = ToolUtils.parseJson(i);
                    if (0 == t.ret) {
                        if (this.setLastAccuRewardList(false), this.setLastUistate(), User.shared().treasureMainData = t.data, !ToolUtils.isObjValid(this.node)) {
                            return;
                        }
                        let i = this.getMainData();
                        if (!i) {
                            return;
                        }
                        this.updateShopLeafUI();
                        i.ui == ct.Challenge ? this.isSwitchLeveling ? i.boom_box_index >= 1 ? 0 == i.has_paid_bomb_fee ? (this.isSwitchLeveling = false, Utils.shared().showLoading(10, true, (() => {
                            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
                        })), this.requestBoomPopPage()) : 1 == i.has_paid_bomb_fee && (this.isSwitchLeveling = false, this.initView()) : this.playMainBoxEntryAnim((() => {
                            this.isSwitchLeveling && (this.isOpeningBox, this.isSwitchLeveling = false, this.updateBoxDetailArr([]), this.initView());
                        })) : e ? (this.setMainBoxRandomSkinArr(), this.initView()) : this.showGetRewardBtnUI() : (this.stopAllNoBoomTweenDelay(), this.stopAllHaveBoomTweenDelay(), this.updateBoxDetailArr([]), this.setLastAccuRewardList(true), this.isOpeningBox = false, this.isSwitchLeveling = false, this.initView(), i.ui == ct.NotTriggered && 0 == i.is_free && 1 == i.can_start && 1 == i.open_type && 0 == i.is_history_pay && this.requestStartFree(2));
                    }
                    else {
                        sys.isObjectValid(t.desc) && Utils.shared().showToast(t.desc, 2);
                    }
                }
                catch (e) {
                    TLog.printError(this.TAG, "requestTreasureMain error:", e);
                    sys.isObjectValid(e) && Utils.shared().showToast(e, 2);
                }
            }
        })));
    }
    requestBoomPopPage() {
        HttpManager.shared().doGetCommonRequest(null, HttpRequest.TreasureBoomPopPage, ((e, t, i) => {
            if (Utils.shared().hideLoading(), 200 != i) {
                alert("The login timed out, please try again");
            }
            else {
                try {
                    let e = ToolUtils.parseJson(t);
                    0 == e.ret && (User.shared().treasureBoomPopData = e.data, ToolUtils.isObjValid(this.node) && this.showBoomBalanceNodeUI());
                }
                catch (e) {
                    TLog.printError(this.TAG, "requestBoomPopPage error:", e);
                }
            }
        }));
    }
    requestOpenBox(e, t) {
        e <= 0 || ![1, 2, 3, 4].includes(e) || (this.isSecondOpen = t, this.isOpeningBox = true, HttpManager.shared().doGetCommonRequest({ box_index: e }, HttpRequest.TreasureOpenBox, ((e, t, i) => {
            if (Utils.shared().hideLoading(), 200 != i) {
                alert("The login timed out, please try again");
            }
            else {
                try {
                    let e = ToolUtils.parseJson(t);
                    if (0 == e.ret) {
                        let t = e.data.boxes, i = e.data.accu_reward_list, o = e.data.final_reward_list;
                        if (!t || t.length < 4) {
                            return;
                        }
                        if (!this.getMainData()) {
                            return;
                        }
                        let r = false, s = [];
                        for (let i = 0; i < t.length; i++) {
                            s.push({ serialNum: t[i].box_index, isAward: 1 == t[i].winning, type: t[i].type, num: -1 == t[i].type ? 0 : t[i].amt });
                            this._bCanSend && r && t[i].winning && (-1 == t[i].type ? (HttpManager.shared().doCommReportRechargeEvent(ReportConfig.Cmd_Treasure, this._reportScene, 16, this._linkId, "", 0), r = true) : t[i].type > 0 && (HttpManager.shared().doCommReportRechargeEvent(ReportConfig.Cmd_Treasure, this._reportScene, 15, this._linkId, "", 0), r = true));
                            -1 == t[i].type && t[i].box_index == e.data.box_index && (User.shared().treasureMainData.boom_box_index = e.data.box_index);
                        }
                        this.setLastAccuRewardList(false);
                        !s || s.length;
                        this.updateBoxDetailArr(s);
                        User.shared().treasureMainData.accu_reward_list = i;
                        this.isSecondOpen && this.removeBoomSkin(4);
                        ToolUtils.isObjValid(this.node) && this.initView(o, this.isSecondOpen);
                    }
                    else {
                        sys.isObjectValid(e.desc) && Utils.shared().showToast(e.desc, 2);
                    }
                }
                catch (e) {
                    TLog.printError(this.TAG, "requestOpenBox error:", e);
                }
            }
        })));
    }
    requestGetReward() {
        HttpManager.shared().doGetCommonRequest(null, HttpRequest.TreasureGetReward, ((e, t, i) => {
            if (Utils.shared().hideLoading(), 200 != i) {
                alert("The login timed out, please try again");
            }
            else {
                try {
                    let e = ToolUtils.parseJson(t);
                    if (0 == e.ret) {
                        let t = e.data.reward_list;
                        t && t.length && User.shared().showChargeReward(t, (e => {
                            this.requestTreasureMain();
                        }));
                    }
                    else {
                        sys.isObjectValid(e.desc) && Utils.shared().showToast(e.desc, 2);
                    }
                }
                catch (e) {
                    TLog.printError(this.TAG, "requestGetReward error:", e);
                }
            }
        }));
    }
    requestGiveUp() {
        HttpManager.shared().doGetCommonRequest(null, HttpRequest.TreasureGiveUp, ((e, t, i) => {
            if (Utils.shared().hideLoading(), 200 != i) {
                alert("The login timed out, please try again");
            }
            else {
                try {
                    let e = ToolUtils.parseJson(t);
                    0 == e.ret ? ToolUtils.isObjValid(this.node) && this.requestTreasureMain() : sys.isObjectValid(e.desc) && Utils.shared().showToast(e.desc, 2);
                }
                catch (e) {
                    TLog.printError(this.TAG, "requestGiveUp error:", e);
                }
            }
        }));
    }
    requestStartFree(e) {
        if (1 == e) {
            if (1 == Utils.shared().showFastKyc()) {
                return;
            }
        }
        else if (2 == e && !User.shared().checkCanRecharge()) {
            return void this.node.destroy();
        }
        HttpManager.shared().doGetCommonRequest({ router_id: e }, HttpRequest.TreasureStartFree, ((e, t, i) => {
            if (Utils.shared().hideLoading(), 200 != i) {
                alert("The login timed out, please try again");
            }
            else {
                try {
                    let e = ToolUtils.parseJson(t);
                    0 == e.ret ? ToolUtils.isObjValid(this.node) && this.requestTreasureMain() : sys.isObjectValid(e.desc) && Utils.shared().showToast(e.desc, 2);
                }
                catch (e) {
                    TLog.printError(this.TAG, "requestStartFree error:", e);
                }
            }
        }));
    }
    requestSkipBomb() {
        HttpManager.shared().doGetCommonRequest(null, HttpRequest.TreasureSkipBomb, ((e, t, i) => {
            if (Utils.shared().hideLoading(), 200 != i) {
                alert("The login timed out, please try again");
            }
            else {
                try {
                    let e = ToolUtils.parseJson(t);
                    0 == e.ret ? ((this.boomBalanceNode.active || this.boomThinkNode.active) && (this.boomBalanceNode.active = this.boomThinkNode.active = false), ToolUtils.isObjValid(this.node) && this.requestTreasureMain()) : sys.isObjectValid(e.desc) && Utils.shared().showToast(e.desc, 2);
                }
                catch (e) {
                    TLog.printError(this.TAG, "requestSkipBomb error:", e);
                }
            }
        }));
    }
    requestGetRecommendGoodsPage(e, t = false) {
        HttpManager.shared().doGetCommonRequest({ source: e }, HttpRequest.TreasureGetRecommendGoodsPage, ((i, o, r) => {
            if (Utils.shared().hideLoading(), 200 != r) {
                alert("The login timed out, please try again");
            }
            else {
                try {
                    let i = ToolUtils.parseJson(o);
                    if (0 == i.ret) {
                        let o = i.data;
                        if (!ToolUtils.isObjValid(this.node) || !o) {
                            return;
                        }
                        if (!sys.isObjectValid(o.ext_leaf) || !Array.isArray(o.ext_leaf)) {
                            return;
                        }
                        Utils.shared().showTreasureRecharge({ goods_list: o.ext_leaf, self_rec: t, ext_recharge: { source: o.source, is_guide: 2 == e ? o.is_guide : null, is_cash: 2 == e ? o.is_cash : null } });
                    }
                    else {
                        sys.isObjectValid(i.desc) && Utils.shared().showToast(i.desc, 2);
                    }
                }
                catch (e) {
                    TLog.printError(this.TAG, "requestGetRecommendGoodsPage error:", e);
                }
            }
        }));
    }
    showViewByUiStatus(e, t) {
        let i = this.getMainData();
        if (!i) {
            return;
        }
        let o = [new Vec3(0, 317, 0), new Vec3(0, -183, 0), new Vec3(0, 300, 0)], r = this.bigPrice_main.getChildByName("bigPriceLabel"), a = this.bigPrice_main.getChildByName("up"), h = a.getChildByName("up_icon"), l = a.getChildByName("up_num");
        switch ((this.rootNode.active = i.ui != ct.Finish, this.mainNode.active = i.ui == ct.Challenge, this.guideNode.active = i.ui == ct.NotTriggered, this.finishNode.active = i.ui == ct.Finish, this.levelMoban.active = this.rewardMoban_bal.active = false, this.recharge.node.active = 0 == i.is_free && 2 != i.open_type, this.btn_close_mask.active = false, 1 == i.is_free || 0 == i.is_free && 2 == i.open_type ? this.bigPrice_guide.node.position = o[2] : this.bigPrice_guide.node.position = o[1], i.ui != ct.NotTriggered && this.stopGuideBoxCycleSchedule(), i.ui != ct.Finish && this.stopFinishBoxCycleSchedule(), i.ui != ct.Challenge && this.removeBoomSkin(3), this.showGetRewardBtnUI(), i.ui)) {
            case ct.NotTriggered:
                0 == i.is_free ? 7 == this._from_source ? HttpManager.shared().doCommReportRechargeEvent(ReportConfig.Cmd_Treasure, this._reportScene, 4, this._linkId, "", 0) : 8 == this._from_source && HttpManager.shared().doCommReportRechargeEvent(ReportConfig.Cmd_Treasure, this._reportScene, 5, this._linkId, "", 0) : 1 == i.is_free && (7 == this._from_source ? HttpManager.shared().doCommReportRechargeEvent(ReportConfig.Cmd_Treasure, this._reportScene, 8, this._linkId, "", 0) : 8 == this._from_source && HttpManager.shared().doCommReportRechargeEvent(ReportConfig.Cmd_Treasure, this._reportScene, 9, this._linkId, "", 0)), this._bCanSend = true, this.boomBalanceNode.active = this.boomThinkNode.active = false;
                let o = 1 == i.is_free || 2 == i.open_type ? "treasure.bigPrice_guide_cash" : "treasure.bigPrice_guide";
                this.bigPrice_guide.getComponent(RichText).fontSize = 1 == i.is_free || 2 == i.open_type ? 36 : 28, this.bigPrice_guide.getComponent(RichText).lineHeight = 1 == i.is_free || 2 == i.open_type ? 54 : 40, this.bigPrice_guide.getComponent(RichText).string = ToolUtils.format(i18nMgr.shared().getValueByKey(o), i.content_challenges), this.recharge.getComponent(RichText).string = ToolUtils.format(i18nMgr.shared().getValueByKey("treasure.guide_recharge"), i.title_charge_amount, i.title_get_amount), this.rewardTitle_root.getComponent(Label).string = ToolUtils.format(i18nMgr.shared().getValueByKey("treasure.win_up_to")), this.playGuideChallAnim(), this.showRrewardNodeRootUI();
                break;
            case ct.Challenge:
                this.lastUiState == ct.NotTriggered ? (0 == i.is_free ? HttpManager.shared().doCommReportRechargeEvent(ReportConfig.Cmd_Treasure, this._reportScene, 7, this._linkId, "", 0) : 1 == i.is_free && HttpManager.shared().doCommReportRechargeEvent(ReportConfig.Cmd_Treasure, this._reportScene, 11, this._linkId, "", 0), this._bCanSend = true) : this._bCanSend || (0 == i.is_free ? HttpManager.shared().doCommReportRechargeEvent(ReportConfig.Cmd_Treasure, this._reportScene, 7, this._linkId, "", 0) : 1 == i.is_free && HttpManager.shared().doCommReportRechargeEvent(ReportConfig.Cmd_Treasure, this._reportScene, 11, this._linkId, "", 0), this._bCanSend = true), this.bigPrice_main.active = a.active = 1 == i.has_after_star, r.getComponent(RichText).string = ToolUtils.format(i18nMgr.shared().getValueByKey("treasure.main_bigPriceLabel"), i.title_boxes_count), this.updateRewardSprite(h, Number(i.up_to_type)), l.getComponent(Label).string = "x" + ToolUtils.parse_double(i.up_to_amount, -1), this.rewardTitle_root.getComponent(Label).string = ToolUtils.format(i18nMgr.shared().getValueByKey("treasure.accumulated_rewards")), this.showLevelUI(), this.showRrewardNodeRootUI(), this.showBoxUI(e, t);
                break;
            case ct.Finish:
                HttpManager.shared().doCommReportRechargeEvent(ReportConfig.Cmd_Treasure, this._reportScene, 25, this._linkId, "", 0), this._bCanSend = true, this.playFinishChallAnim(), this.showFinishUI(), this.boomBalanceNode.active = this.boomThinkNode.active = false;
                break;
            default: this.btn_close_mask.active = true;
        }
    }
    showGetRewardBtnUI() {
        let e = this.getMainData();
        if (!e) {
            return;
        }
        let t = this.btn_getReward.getChildByName("img"), i = this.btn_getReward.getChildByName("free"), o = this.btn_getReward.getChildByName("leaving"), r = this.btn_getReward.getChildByName("start"), a = this.btn_getReward.getChildByName("spend"), n = this.btn_cashspend.getChildByName("Node").getChildByName("icon"), h = this.btn_cashspend.getChildByName("Node").getChildByName("spendlab");
        switch ((this.btn_cashspend.getChildByName("total").active = false, e.ui)) {
            case ct.NotTriggered:
                this.btn_getReward.active = !(0 == e.is_free && 0 == e.can_start && 2 == e.open_type), t.getComponent(Sprite).spriteFrame = this.getRewardBtnSpriteArr[1], r.active = 1 == e.is_free || 0 == e.is_free && 1 == e.can_start, i.active = 1 == e.is_free, a.active = 0 == e.is_free && 0 == e.can_start && 1 == e.open_type, this.btn_cashspend.active = 0 == e.is_free && 0 == e.can_start && 2 == e.open_type, o.active = false, this.btn_getReward.getComponent(Button).interactable = !(0 == e.is_free && 0 == e.can_start && 2 == e.open_type), t.getComponent(Sprite).grayscale = false, 0 == e.is_free && 0 == e.can_start && (1 == e.open_type ? a.getComponent(Label).string = "₹" + ToolUtils.parse_double(e.goods_price, -1) : 2 == e.open_type && (h.getComponent(Label).string = ToolUtils.parse_double(e.cash_amount, -1), n && this.spend_item_sprite && (n.getComponent(Sprite).spriteFrame = this.spend_item_sprite)));
                break;
            case ct.Challenge:
                if (t.getComponent(Sprite).spriteFrame = this.getRewardBtnSpriteArr[0], i.active = r.active = a.active = this.btn_cashspend.active = o.active = false, this.btn_getReward.active = e.now_id > 1, e.now_id <= 1) {
                    return;
                }
                o.active = true, e.boom_box_index >= 1 ? (this.btn_getReward.getComponent(Button).interactable = 1 != e.has_paid_bomb_fee, this.isOpeningBox && !this.isSecondOpen ? this.scheduleOnce((() => {
                    t.getComponent(Sprite).grayscale = 1 != e.has_paid_bomb_fee;
                    Utils.updateLabelMaterial(o, 1 == e.has_paid_bomb_fee ? CommDefine.gradient.btn_blue : CommDefine.gradient.btn_gray);
                    o.getComponent(LabelShadow).color = 1 == e.has_paid_bomb_fee ? CommDefine.shadowcolor.blue : CommDefine.shadowcolor.gray;
                }), 1.5) : (t.getComponent(Sprite).grayscale = 1 != e.has_paid_bomb_fee, Utils.updateLabelMaterial(o, 1 == e.has_paid_bomb_fee ? CommDefine.gradient.btn_blue : CommDefine.gradient.btn_gray), o.getComponent(LabelShadow).color = 1 == e.has_paid_bomb_fee ? CommDefine.shadowcolor.blue : CommDefine.shadowcolor.gray)) : (this.btn_getReward.getComponent(Button).interactable = true, t.getComponent(Sprite).grayscale = false, Utils.updateLabelMaterial(o, CommDefine.gradient.btn_blue), o.getComponent(LabelShadow).color = CommDefine.shadowcolor.blue);
        }
    }
    getMainData() {
        return sys.isObjectValid(User.shared().treasureMainData) ? User.shared().treasureMainData : null;
    }
    judgeCurLevelIsStar() {
        let e = false, t = this.getMainData();
        if (!t || t.ui != ct.Challenge) {
            return e;
        }
        if (t.list && t.now_id) {
            for (let i = 0; i < t.list.length; i++) {
                if (t.now_id == t.list[i].id && 1 == t.list[i].show_star) {
                    return e = true, e;
                }
            }
        }
        return e;
    }
    removeBoomSkin(e) {
        localStorage.removeItem(this.storageBoomSkin);
    }
    setMainBoxRandomSkinArr() {
        if (this.judgeCurLeveIsStar()) {
            this.mainBoxRandomSkinArr = new Array(4).fill(this.boxSkinArr[0]);
            this.removeBoomSkin(1);
        }
        else {
            let e = localStorage.getItem(this.storageBoomSkin);
            if (e) {
                let t = e.split("_");
                if (t[0] && t[1] && Number(t[0]) && Number(t[1]) && t[2]) {
                    let e = this.getMainData();
                    if (e && e.now_id == t[1]) {
                        let e = this.boxSkinArr.slice(1).filter((e => ![t[2]].includes(e))), i = this.getRandomElements(e, 3);
                        if (i && (i.splice(Number(t[0]) - 1, 0, t[2]), this.mainBoxRandomSkinArr = i, this.mainBoxRandomSkinArr && 4 == this.mainBoxRandomSkinArr.length)) {
                            return;
                        }
                    }
                    else {
                        this.removeBoomSkin(2);
                    }
                }
            }
            this.mainBoxRandomSkinArr = this.getRandomElements(this.boxSkinArr.slice(1), 4);
        }
    }
    judgeCurLeveIsStar() {
        var e;
        const t = this.getMainData();
        return (null == t ? undefined : t.ui) === ct.Challenge && ((null == (e = t.list) ? undefined : e.some((e => e.id === t.now_id && 1 === e.show_star))) ?? false);
    }
    judgeFinalAccuReaward() {
        let e = false, t = this.getMainData();
        return t && this.judgeFinalLevel() && t.boom_box_index >= 1 && 0 == t.has_paid_bomb_fee && (e = true), e;
    }
    showRrewardNodeRootUI() {
        let e = this.getMainData();
        if (!e) {
            return;
        }
        let t = [];
        if (e.ui == ct.NotTriggered ? t = e.reward_list.map((e => ({ type: e.type, amt: e.amt }))) : e.ui == ct.Challenge && (t = e.accu_reward_list.map((e => ({ type: e.type, amt: e.amt })))), !sys.isObjectValid(t) || 0 === t.length) {
            return this.rewardNode_root.active = false, void (this.choose_root.active = true);
        }
        t.length > 3 || (t.sort(((e, t) => e.type - t.type)), this.rewardNode_root.active = true, this.choose_root.active = false, e.ui == ct.NotTriggered ? this.processReward1(t, false) : e.ui == ct.Challenge && (this.isOpeningBox ? 1 == e.now_id ? this.processReward1(t, true) : this.lastAccuRewardList && this.processReward2(t, this.lastAccuRewardList) : this.processReward1(t, false)));
    }
    processReward1(e, t) {
        let i = false, o = false, r = false;
        for (let s = 0; s < e.length; s++) {
            if (e[s].type >= 2) {
                r = true;
                this.rewardMoban_root_arr[2].getComponent(Sprite).color = color(255, 255, 255, t ? 0 : 255);
                t ? (this.lastUiState == ct.NotTriggered && (this.rewardMoban_root_arr[2].active = false), TweenTool.delayAct(this.node, (() => {
                    this.rewardMoban_root_arr[2].active = true;
                    this.initRewardMobanRoot(this.rewardMoban_root_arr[2], e[s], t);
                }), 2.1, true)) : (this.rewardMoban_root_arr[2].active = true, this.initRewardMobanRoot(this.rewardMoban_root_arr[2], e[s], t));
            }
            else if (0 == e[s].type) {
                i = true;
                this.rewardMoban_root_arr[0].getComponent(Sprite).color = color(255, 255, 255, t ? 0 : 255);
                t ? (this.lastUiState == ct.NotTriggered && (this.rewardMoban_root_arr[0].active = false), TweenTool.delayAct(this.node, (() => {
                    this.rewardMoban_root_arr[0].active = true;
                    this.initRewardMobanRoot(this.rewardMoban_root_arr[0], e[s], t);
                }), 2.1, true)) : (this.rewardMoban_root_arr[0].active = true, this.initRewardMobanRoot(this.rewardMoban_root_arr[0], e[s], t));
            }
            else if (1 == e[s].type) {
                o = true;
                this.rewardMoban_root_arr[1].getComponent(Sprite).color = color(255, 255, 255, t ? 0 : 255);
                t ? (this.lastUiState == ct.NotTriggered && (this.rewardMoban_root_arr[1].active = false), TweenTool.delayAct(this.node, (() => {
                    this.rewardMoban_root_arr[1].active = true;
                    this.initRewardMobanRoot(this.rewardMoban_root_arr[1], e[s], t);
                }), 2.1, true)) : (this.rewardMoban_root_arr[1].active = true, this.initRewardMobanRoot(this.rewardMoban_root_arr[1], e[s], t));
            }
            i || (this.rewardMoban_root_arr[0].active = i);
            o || (this.rewardMoban_root_arr[1].active = o);
            r || (this.rewardMoban_root_arr[2].active = r);
        }
    }
    processReward2(e, t) {
        let i, o, r, s, a, n, h = -1, l = -1, d = -1, m = -1, c = -1, u = -1;
        for (let e = 0; e < t.length; e++) {
            t[e].type >= 2 ? (d = e, r = true) : 0 == t[e].type ? (h = e, i = true) : 1 == t[e].type && (l = e, o = true);
        }
        for (let t = 0; t < e.length; t++) {
            e[t].type >= 2 ? (u = t, n = true) : 0 == e[t].type ? (m = t, s = true) : 1 == e[t].type && (c = t, a = true);
        }
        if (s || (this.rewardMoban_root_arr[0].active = s), a || (this.rewardMoban_root_arr[1].active = a), n || (this.rewardMoban_root_arr[2].active = n), s) {
            if (i && s) {
                let i = e[m].amt - t[h].amt || 0;
                this.updateRewardMobanRoot(this.rewardMoban_root_arr[0], e[m].amt, i);
            }
            else {
                TweenTool.delayAct(this.node, (() => {
                    this.rewardMoban_root_arr[0].getComponent(Sprite).color = color(255, 255, 255, 0);
                    this.rewardMoban_root_arr[0].active = s;
                    this.initRewardMobanRoot(this.rewardMoban_root_arr[0], e[m], true);
                }), 2.1, true);
            }
        }
        if (a) {
            if (o && a) {
                let i = e[c].amt - t[l].amt || 0;
                this.updateRewardMobanRoot(this.rewardMoban_root_arr[1], e[c].amt, i);
            }
            else {
                TweenTool.delayAct(this.node, (() => {
                    this.rewardMoban_root_arr[1].getComponent(Sprite).color = color(255, 255, 255, 0);
                    this.rewardMoban_root_arr[1].active = a;
                    this.initRewardMobanRoot(this.rewardMoban_root_arr[1], e[c], true);
                }), 2.1, true);
            }
        }
        if (n) {
            if (r && n) {
                let i = e[u].amt - t[d].amt || 0;
                this.updateRewardMobanRoot(this.rewardMoban_root_arr[2], e[u].amt, i);
            }
            else {
                TweenTool.delayAct(this.node, (() => {
                    this.rewardMoban_root_arr[2].getComponent(Sprite).color = color(255, 255, 255, 0);
                    this.rewardMoban_root_arr[2].active = n;
                    this.initRewardMobanRoot(this.rewardMoban_root_arr[2], e[u], true);
                }), 2.1, true);
            }
        }
    }
    initRewardMobanRoot(e, t, i) {
        let o = e.getChildByName("rewardItemAnim1").getComponent(sp.Skeleton), r = e.getChildByName("rewardItemAnim2"), a = r.getComponent(sp.Skeleton), n = e.getChildByName("num"), h = e.getChildByName("name"), l = e.getComponent(Sprite), d = this.getMainBoxAttSpriteName(t.type);
        if (n.active = h.active = false, a.clearTracks(), r.active = false, n.getComponent(Label).string = ToolUtils.parse_double(t.amt, -1), h.getComponent(Label).string = this.getIconNameByType(t.type, t.desc), o.clearTracks(), o.setAttachment(this.ani_hd_baoxiangcg_daoju, d), i) {
            let e = false;
            l.color = color(255, 255, 255, 255);
            o.setAnimation(0, this.jlk_chuxian, false);
            o.setCompleteListener((() => {
                e || (e = true, n.active = h.active = true, o.addAnimation(0, this.jlk_xh, true));
            }));
        }
        else {
            n.active = h.active = true;
            o.setAnimation(0, this.jlk_xh, true);
        }
    }
    updateRewardMobanRoot(e, t, i) {
        e.getChildByName("rewardItemAnim1").getComponent(sp.Skeleton);
        let o = e.getChildByName("rewardItemAnim2").getComponent(sp.Skeleton), r = e.getChildByName("num");
        r.scale = new Vec3(1, 1, 1);
        e.scale = new Vec3(1, 1, 1);
        this.scheduleOnce((() => {
            if (o.addAnimation(0, this.jlk_kstx, false), i > 0) {
                TweenTool.scaleTo(r, 0.13, new Vec3(1.15, 1.15, 1.15));
                TweenTool.scaleTo(r, 0.1, new Vec3(0.92, 0.92, 0.92));
                TweenTool.scaleTo(r, 0.07, new Vec3(1.05, 1.05, 1.05));
                TweenTool.scaleTo(r, 0.06, new Vec3(1, 1, 1));
                let i = TweenTool.scaleTo(r, 0.1, new Vec3(1.2, 1.2, 1.2)), o = TweenTool.scaleTo(r, 0.13, new Vec3(0.94, 0.94, 0.94)), a = TweenTool.scaleTo(r, 0.06, new Vec3(1, 1, 1));
                r.getComponent(Label).string = ToolUtils.parse_double(t.toString(), -1);
                TweenTool.sequence(e, true, null, i, o, a);
            }
            else {
                r.getComponent(Label).string = ToolUtils.parse_double(t.toString(), -1);
            }
        }), 2);
        o.clearTracks();
    }
    showLevelUI() {
        let e = this.getMainData();
        if (!e) {
            return;
        }
        if (!e.list || !sys.isObjectValid(e.list) || e.list.length <= 0) {
            return void (this.level.active = this.levelMoban.active = false);
        }
        let t = this.getNeedShowLevelList();
        if (!t || !t.levelList || !t.levelList.length) {
            return;
        }
        let i = -1;
        this.level.active = true;
        let o = this.level.getChildByName("ScrollView").getChildByName("view").getChildByName("content");
        o.removeAllChildren();
        o.getComponent(Layout).paddingLeft = t.paddingLeft;
        for (let r = 0; r < t.levelList.length; r++) {
            t.levelList[r].id == e.now_id && (i = r);
            let s = instantiate(this.levelMoban);
            s.active = true;
            this.initLevelMobanRoot(s, r, t.levelList[r], e.now_id);
            o.addChild(s);
        }
        this.scheduleOnce((() => {
            if (i > -1) {
                let e = o.children[i];
                sys.isObjectValid(e) && (this.level_sel.active = true, this.level_sel.worldPosition = e.worldPosition);
            }
        }), 0);
    }
    initLevelMobanRoot(e, t, i, o) {
        let r = e.getChildByName("bg"), a = e.getChildByName("level_num"), n = "#8E0000", h = "#FFE467", l = -1;
        0 == i.show_star ? i.id != o ? l = 0 : (l = 1, n = "#9A2800", h = "#F3E0BC") : 1 == i.show_star && (l = i.id != o ? 2 : 3);
        -1 != l && (r.getComponent(Sprite).spriteFrame = this.levelMobanBgArr[l]);
        a.active = 0 == i.show_star;
        0 == i.show_star && (a.getComponent(Label).string = i.id, a.getComponent(Label).color = color(n), a.getComponent(LabelShadow).color = color(h));
    }
    getNeedShowLevelList() {
        let e = [], t = 10, i = this.getMainData();
        return i ? !i.list || !sys.isObjectValid(i.list) || i.list.length <= 0 ? null : (i.list.length < 8 ? (e = i.list, t = 20) : 8 == i.list.length ? (e = i.list, t = 1 == i.now_id ? 10 : -44) : i.now_id + 8 < i.list.length ? 1 == i.now_id ? e = i.list.slice(i.now_id - 1, i.now_id + 7) : (e = i.list.slice(i.now_id - 2, i.now_id + 8), t = -54) : i.now_id + 8 == i.list.length ? (e = i.list.slice(i.now_id - 1, i.now_id + 7), t = 10) : i.now_id + 8 > i.list.length && (e = i.list.slice(i.list.length - 8, i.list.length), t = i.now_id + 7 > i.list.length ? -40 : 10), { levelList: e, paddingLeft: t }) : null;
    }
    showBoxUI(e, t) {
        let i = this.getMainData();
        if (!i) {
            return;
        }
        if (!this.boxNodeArr || this.boxNodeArr.length < 4 || !this.boxAnimCompArr || this.boxAnimCompArr.length < 4) {
            return;
        }
        this.mainBoxRandomSkinArr && this.mainBoxRandomSkinArr.length || this.setMainBoxRandomSkinArr();
        for (let e = 0; e < 4; e++) {
            const t = this.boxAnimCompArr[e];
            t && t.setSkin(this.mainBoxRandomSkinArr[e]);
        }
        this.boxChildNodeArr.forEach((e => {
            const t = e.getChildByName("num");
            t && (t.active = false);
        }));
        let o = this.getAwardBoxDetail() || null;
        if (this.isExistBoomBox()) {
            if (this.stopAllNoBoomTweenDelay(), this.isOpeningBox) {
                let r = t ? i.boom_box_index : 0;
                this.playMainBoxAnimHaveBoom(i.has_paid_bomb_fee, i.now_id, true, o, e, t, null, r);
            }
            else {
                this.playMainBoxAnimHaveBoom(i.has_paid_bomb_fee, i.now_id, false, o, e, t, i.bomb_pop_info, 0);
            }
        }
        else {
            this.stopAllHaveBoomTweenDelay();
            this.isOpeningBox ? this.playMainBoxAnimNoBoom(true, o, e) : this.playMainBoxAnimNoBoom(false, o, e);
        }
    }
    playMainBoxAnimNoBoom(e, t, i) {
        if (e) {
            if (!this.boxDetailArr || !this.boxDetailArr.length) {
                return;
            }
            for (let e = 0; e < this.boxAnimCompArr.length; e++) {
                this.setMainBoxIcon(e);
            }
            if (t) {
                let e = 500, o = (2490 + e) / 1000;
                this.resetMainBoxGray(t.serialNum);
                let r = t.serialNum - 1;
                switch ((this.boxAnimCompArr[r].setCompleteListener(null), this.boxAnimCompArr[r].setAnimation(0, ut.Dj, false), SoundManager.shared().playFx("treasure_reward_" + (this.judgeCurLevelIsStar() ? "special" : "normal")), this.stopNoBoomTweenDelay(0), this._noboomTweenDealyArr[0] = TweenTool.delayAct(this.node, (() => {
                    this.boxDetailArr && 4 == this.boxDetailArr.length && [0, 1, 2, 3].includes(r) ? (this.boxChildNodeArr[r].getChildByName("num").active = true, this.boxChildNodeArr[r].getChildByName("num").getComponent(Label).string = ToolUtils.parse_double(this.boxDetailArr[r].num.toString(), -1)) : this.stopNoBoomTweenDelay(0);
                }), 1, true), this.boxAnimCompArr[r].setCompleteListener((() => {
                    this.boxChildNodeArr[r].getChildByName("num").active = false;
                    this.boxAnimCompArr[r].setCompleteListener(null);
                    this.stopNoBoomTweenDelay(2);
                    this._noboomTweenDealyArr[2] = TweenTool.delayAct(this.node, (() => {
                        let e = false;
                        this.boxAnimCompArr[r].setAnimation(0, ut.Cc_dj, false);
                        this.boxAnimCompArr[r].setCompleteListener((() => {
                            e || (e = true, this.isOpeningBox = false, this.isSwitchLeveling = true, this.judgeFinalLevel() && i && i.length ? User.shared().showChargeReward(i, (e => {
                                this.requestTreasureMain();
                            }), i18nMgr.shared().getValueByKey("treasure.congra_complet")) : this.requestTreasureMain());
                        }));
                    }), e / 1000, true);
                })), t.serialNum)) {
                    case 1:
                        this.stopNoBoomTweenDelay(3), this._noboomTweenDealyArr[3] = TweenTool.delayAct(this.node, (() => {
                            this.setMainBoxGray(2);
                            this.boxAnimCompArr[1].setAnimation(0, ut.Zs, false);
                            this.setMainBoxGray(3);
                            this.boxAnimCompArr[2].setAnimation(0, ut.Zs, false);
                            this.setMainBoxGray(4);
                            this.boxAnimCompArr[3].setAnimation(0, ut.Zs, false);
                        }), 1, true), this.stopNoBoomTweenDelay(4), this._noboomTweenDealyArr[4] = TweenTool.delayAct(this.node, (() => {
                            this.boxDetailArr && 4 == this.boxDetailArr.length && [0, 1, 2, 3].includes(r) ? (this.boxChildNodeArr[1].getChildByName("num").active = true, this.boxChildNodeArr[1].getChildByName("num").getComponent(Label).string = ToolUtils.parse_double(this.boxDetailArr[1].num.toString(), -1), this.boxChildNodeArr[2].getChildByName("num").active = true, this.boxChildNodeArr[2].getChildByName("num").getComponent(Label).string = ToolUtils.parse_double(this.boxDetailArr[2].num.toString(), -1), this.boxChildNodeArr[3].getChildByName("num").active = true, this.boxChildNodeArr[3].getChildByName("num").getComponent(Label).string = ToolUtils.parse_double(this.boxDetailArr[3].num.toString(), -1)) : this.stopNoBoomTweenDelay(4);
                        }), 1.5, true), this.stopNoBoomTweenDelay(5), this._noboomTweenDealyArr[5] = TweenTool.delayAct(this.node, (() => {
                            this.boxChildNodeArr[1].getChildByName("num").active = false;
                            this.boxAnimCompArr[1].setAnimation(0, ut.Cc_wdj, false);
                            this.boxChildNodeArr[2].getChildByName("num").active = false;
                            this.boxAnimCompArr[2].setAnimation(0, ut.Cc_wdj, false);
                            this.boxChildNodeArr[3].getChildByName("num").active = false;
                            this.boxAnimCompArr[3].setAnimation(0, ut.Cc_wdj, false);
                        }), o, true);
                        break;
                    case 2:
                        this.stopNoBoomTweenDelay(3), this._noboomTweenDealyArr[3] = TweenTool.delayAct(this.node, (() => {
                            this.setMainBoxGray(1);
                            this.boxAnimCompArr[0].setAnimation(0, ut.Zs, false);
                            this.setMainBoxGray(3);
                            this.boxAnimCompArr[2].setAnimation(0, ut.Zs, false);
                            this.setMainBoxGray(4);
                            this.boxAnimCompArr[3].setAnimation(0, ut.Zs, false);
                        }), 1, true), this.stopNoBoomTweenDelay(4), this._noboomTweenDealyArr[4] = TweenTool.delayAct(this.node, (() => {
                            this.boxDetailArr && 4 == this.boxDetailArr.length && [0, 1, 2, 3].includes(r) ? (this.boxChildNodeArr[0].getChildByName("num").active = true, this.boxChildNodeArr[0].getChildByName("num").getComponent(Label).string = ToolUtils.parse_double(this.boxDetailArr[0].num.toString(), -1), this.boxChildNodeArr[2].getChildByName("num").active = true, this.boxChildNodeArr[2].getChildByName("num").getComponent(Label).string = ToolUtils.parse_double(this.boxDetailArr[2].num.toString(), -1), this.boxChildNodeArr[3].getChildByName("num").active = true, this.boxChildNodeArr[3].getChildByName("num").getComponent(Label).string = ToolUtils.parse_double(this.boxDetailArr[3].num.toString(), -1)) : this.stopNoBoomTweenDelay(4);
                        }), 1.5, true), this.stopNoBoomTweenDelay(5), this._noboomTweenDealyArr[5] = TweenTool.delayAct(this.node, (() => {
                            this.boxChildNodeArr[0].getChildByName("num").active = false;
                            this.boxAnimCompArr[0].setAnimation(0, ut.Cc_wdj, false);
                            this.boxChildNodeArr[2].getChildByName("num").active = false;
                            this.boxAnimCompArr[2].setAnimation(0, ut.Cc_wdj, false);
                            this.boxChildNodeArr[3].getChildByName("num").active = false;
                            this.boxAnimCompArr[3].setAnimation(0, ut.Cc_wdj, false);
                        }), o, true);
                        break;
                    case 3:
                        this.stopNoBoomTweenDelay(3), this._noboomTweenDealyArr[3] = TweenTool.delayAct(this.node, (() => {
                            this.setMainBoxGray(1);
                            this.boxAnimCompArr[0].setAnimation(0, ut.Zs, false);
                            this.setMainBoxGray(2);
                            this.boxAnimCompArr[1].setAnimation(0, ut.Zs, false);
                            this.setMainBoxGray(4);
                            this.boxAnimCompArr[3].setAnimation(0, ut.Zs, false);
                        }), 1, true), this.stopNoBoomTweenDelay(4), this._noboomTweenDealyArr[4] = TweenTool.delayAct(this.node, (() => {
                            this.boxDetailArr && 4 == this.boxDetailArr.length && [0, 1, 2, 3].includes(r) ? (this.boxChildNodeArr[0].getChildByName("num").active = true, this.boxChildNodeArr[0].getChildByName("num").getComponent(Label).string = ToolUtils.parse_double(this.boxDetailArr[0].num.toString(), -1), this.boxChildNodeArr[1].getChildByName("num").active = true, this.boxChildNodeArr[1].getChildByName("num").getComponent(Label).string = ToolUtils.parse_double(this.boxDetailArr[1].num.toString(), -1), this.boxChildNodeArr[3].getChildByName("num").active = true, this.boxChildNodeArr[3].getChildByName("num").getComponent(Label).string = ToolUtils.parse_double(this.boxDetailArr[3].num.toString(), -1)) : this.stopNoBoomTweenDelay(4);
                        }), 1.5, true), this.stopNoBoomTweenDelay(5), this._noboomTweenDealyArr[5] = TweenTool.delayAct(this.node, (() => {
                            this.boxChildNodeArr[0].getChildByName("num").active = false;
                            this.boxAnimCompArr[0].setAnimation(0, ut.Cc_wdj, false);
                            this.boxChildNodeArr[1].getChildByName("num").active = false;
                            this.boxAnimCompArr[1].setAnimation(0, ut.Cc_wdj, false);
                            this.boxChildNodeArr[3].getChildByName("num").active = false;
                            this.boxAnimCompArr[3].setAnimation(0, ut.Cc_wdj, false);
                        }), o, true);
                        break;
                    case 4: this.stopNoBoomTweenDelay(3), this._noboomTweenDealyArr[3] = TweenTool.delayAct(this.node, (() => {
                        this.setMainBoxGray(1);
                        this.boxAnimCompArr[0].setAnimation(0, ut.Zs, false);
                        this.setMainBoxGray(2);
                        this.boxAnimCompArr[1].setAnimation(0, ut.Zs, false);
                        this.setMainBoxGray(3);
                        this.boxAnimCompArr[2].setAnimation(0, ut.Zs, false);
                    }), 1, true), this.stopNoBoomTweenDelay(4), this._noboomTweenDealyArr[4] = TweenTool.delayAct(this.node, (() => {
                        this.boxDetailArr && 4 == this.boxDetailArr.length && [0, 1, 2, 3].includes(r) ? (this.boxChildNodeArr[0].getChildByName("num").active = true, this.boxChildNodeArr[0].getChildByName("num").getComponent(Label).string = ToolUtils.parse_double(this.boxDetailArr[0].num.toString(), -1), this.boxChildNodeArr[1].getChildByName("num").active = true, this.boxChildNodeArr[1].getChildByName("num").getComponent(Label).string = ToolUtils.parse_double(this.boxDetailArr[1].num.toString(), -1), this.boxChildNodeArr[2].getChildByName("num").active = true, this.boxChildNodeArr[2].getChildByName("num").getComponent(Label).string = ToolUtils.parse_double(this.boxDetailArr[2].num.toString(), -1)) : this.stopNoBoomTweenDelay(4);
                    }), 1.5, true), this.stopNoBoomTweenDelay(5), this._noboomTweenDealyArr[5] = TweenTool.delayAct(this.node, (() => {
                        this.boxChildNodeArr[0].getChildByName("num").active = false;
                        this.boxAnimCompArr[0].setAnimation(0, ut.Cc_wdj, false);
                        this.boxChildNodeArr[1].getChildByName("num").active = false;
                        this.boxAnimCompArr[1].setAnimation(0, ut.Cc_wdj, false);
                        this.boxChildNodeArr[2].getChildByName("num").active = false;
                        this.boxAnimCompArr[2].setAnimation(0, ut.Cc_wdj, false);
                    }), o, true);
                }
            }
        }
        else {
            for (let e = 0; e < 4; e++) {
                this.resetMainBoxGray(e + 1);
                this.boxAnimCompArr[e].clearTracks();
                this.boxAnimCompArr[e].setAnimation(0, ut.Xh, true);
            }
        }
    }
    playMainBoxAnimHaveBoom(e, t, i, o, r, a, n, h) {
        if (i) {
            if (!this.boxDetailArr || 4 != this.boxDetailArr.length) {
                return;
            }
            let e = [1, 2, 3, 4];
            if (a && !e.includes(h)) {
                return;
            }
            let i = -1 == o.type, n = 500, l = (2490 + n) / 1000;
            for (let e = 0; e < this.boxAnimCompArr.length; e++) {
                a && -1 == this.boxDetailArr[e].type && h ? this.setMainBoxIcon(e, true) : this.setMainBoxIcon(e);
            }
            this.resetMainBoxGray(o.serialNum);
            let d = o.serialNum - 1;
            this.boxAnimCompArr[d].setCompleteListener(null);
            this.boxAnimCompArr[d].setAnimation(0, ut.Dj, false);
            i || SoundManager.shared().playFx("treasure_reward_" + (this.judgeCurLevelIsStar() ? "special" : "normal"));
            this.stopHaveBoomTweenDelay(0);
            this._haveboomTweenDealyArr[0] = TweenTool.delayAct(this.node, (() => {
                this.boxDetailArr && 4 == this.boxDetailArr.length && [0, 1, 2, 3].includes(d) ? (this.boxChildNodeArr[d].getChildByName("num").active = this.boxDetailArr[d].type > -1, this.boxDetailArr[d].type > -1 && (this.boxChildNodeArr[d].getChildByName("num").getComponent(Label).string = ToolUtils.parse_double(this.boxDetailArr[d].num.toString(), -1))) : this.stopHaveBoomTweenDelay(0);
            }), 1, true);
            this.stopHaveBoomTweenDelay(1);
            this._haveboomTweenDealyArr[1] = TweenTool.delayAct(this.node, (() => {
                this.boxChildNodeArr[d].getChildByName("num").active = false;
            }), 2.1, true);
            this.boxAnimCompArr[d].setCompleteListener((() => {
                if (this.boxAnimCompArr[d].setCompleteListener(null), i) {
                    let e = false;
                    if (this.boxAnimCompArr[d].clearTracks(), this.setMainBoxGray(o.serialNum), this.setMainBoxIcon(d, true), this.boxChildNodeArr[d].getChildByName("num").active = false, this.boxAnimCompArr[d].setAnimation(d, ut.Dkhx, false), !e) {
                        if (this.isOpeningBox = false, this.isSwitchLeveling = true, !a && t && this.mainBoxRandomSkinArr && this.mainBoxRandomSkinArr.length) {
                            let e = o.serialNum;
                            localStorage.setItem(this.storageBoomSkin, e + "_" + t + "_" + this.mainBoxRandomSkinArr[e - 1]);
                        }
                        e = true;
                        Utils.shared().showLoading(10, true, (() => {
                            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
                        }));
                        this.requestBoomPopPage();
                    }
                }
                else {
                    this.stopHaveBoomTweenDelay(4);
                    this._haveboomTweenDealyArr[4] = TweenTool.delayAct(this.node, (() => {
                        if (this.boxDetailArr && 4 == this.boxDetailArr.length && [0, 1, 2, 3].includes(d)) {
                            if (this.judgeFinalLevel() && r && r.length) {
                                User.shared().showChargeReward(r, (e => {
                                    this.boxAnimCompArr[d].clearTracks();
                                    this.setMainBoxIcon(d);
                                    this.boxChildNodeArr[d].getChildByName("num").active = true;
                                    this.boxAnimCompArr[d].setAnimation(0, ut.Dkhx, false);
                                    this.isOpeningBox = false;
                                    this.isSwitchLeveling = true;
                                    this.requestTreasureMain();
                                }), i18nMgr.shared().getValueByKey("treasure.congra_complet"));
                            }
                            else {
                                let e = false;
                                this.boxAnimCompArr[d].clearTracks();
                                this.setMainBoxIcon(d);
                                this.boxChildNodeArr[d].getChildByName("num").active = false;
                                this.boxAnimCompArr[d].setAnimation(0, ut.Cc_dj, false);
                                this.boxAnimCompArr[d].setCompleteListener((() => {
                                    this.boxAnimCompArr[d].setCompleteListener(null);
                                    e || (this.isOpeningBox = false, this.isSwitchLeveling = true, e = true, this.requestTreasureMain());
                                }));
                            }
                        }
                        else {
                            this.stopHaveBoomTweenDelay(4);
                        }
                    }), n / 1000, true);
                }
            }));
            for (let e = 5; e < 9; e++) {
                this.stopHaveBoomTweenDelay(e);
            }
            switch (o.serialNum) {
                case 1:
                    i ? (this._haveboomTweenDealyArr[8] = TweenTool.delayAct(this._timerNode, (() => {
                        this.setMainBoxGray(2);
                        this.setMainBoxGray(3);
                        this.setMainBoxGray(4);
                    }), 1, true), this.boxAnimCompArr[1].setAnimation(0, ut.Xh, true), this.boxChildNodeArr[1].getChildByName("num").active = false, this.boxAnimCompArr[2].setAnimation(0, ut.Xh, true), this.boxChildNodeArr[2].getChildByName("num").active = false, this.boxAnimCompArr[3].setAnimation(0, ut.Xh, true), this.boxChildNodeArr[3].getChildByName("num").active = false) : (a && h ? this.secondOpenRewardAnim(o.serialNum, h, r) : (this._haveboomTweenDealyArr[5] = TweenTool.delayAct(this._timerNode, (() => {
                        this.setMainBoxGray(2);
                        this.boxAnimCompArr[1].setAnimation(0, ut.Zs, false);
                        this.setMainBoxGray(3);
                        this.boxAnimCompArr[2].setAnimation(0, ut.Zs, false);
                        this.setMainBoxGray(4);
                        this.boxAnimCompArr[3].setAnimation(0, ut.Zs, false);
                    }), 1, true), this._haveboomTweenDealyArr[6] = TweenTool.delayAct(this._timerNode, (() => {
                        this.boxDetailArr && 4 == this.boxDetailArr.length && [0, 1, 2, 3].includes(d) ? (this.boxChildNodeArr[1].getChildByName("num").active = this.boxDetailArr[1].type > -1, this.boxDetailArr[1].type > -1 && (this.boxChildNodeArr[1].getChildByName("num").getComponent(Label).string = ToolUtils.parse_double(this.boxDetailArr[1].num.toString(), -1)), this.boxChildNodeArr[2].getChildByName("num").active = this.boxDetailArr[2].type > -1, this.boxDetailArr[2].type > -1 && (this.boxChildNodeArr[2].getChildByName("num").getComponent(Label).string = ToolUtils.parse_double(this.boxDetailArr[2].num.toString(), -1)), this.boxChildNodeArr[3].getChildByName("num").active = this.boxDetailArr[3].type > -1, this.boxDetailArr[3].type > -1 && (this.boxChildNodeArr[3].getChildByName("num").getComponent(Label).string = ToolUtils.parse_double(this.boxDetailArr[3].num.toString(), -1))) : this.stopHaveBoomTweenDelay(6);
                    }), 1.5, true)), this._haveboomTweenDealyArr[7] = TweenTool.delayAct(this._timerNode, (() => {
                        this.boxDetailArr && 4 == this.boxDetailArr.length && [0, 1, 2, 3].includes(d) ? (this.boxAnimCompArr[1].clearTracks(), a && h ? this.setMainBoxIcon(1, h - 1 == 1) : this.setMainBoxIcon(1), this.judgeFinalLevel() && r && r.length ? (this.boxChildNodeArr[1].getChildByName("num").active = this.boxDetailArr[1].type > -1, this.boxAnimCompArr[1].setAnimation(0, ut.Dkhx, true)) : (this.boxChildNodeArr[1].getChildByName("num").active = false, this.boxAnimCompArr[1].setAnimation(0, ut.Cc_wdj, false)), this.boxAnimCompArr[2].clearTracks(), a && h ? this.setMainBoxIcon(2, h - 1 == 2) : this.setMainBoxIcon(2), this.judgeFinalLevel() && r && r.length ? (this.boxChildNodeArr[2].getChildByName("num").active = this.boxDetailArr[2].type > -1, this.boxAnimCompArr[2].setAnimation(0, ut.Dkhx, true)) : (this.boxChildNodeArr[2].getChildByName("num").active = false, this.boxAnimCompArr[2].setAnimation(0, ut.Cc_wdj, false)), this.boxAnimCompArr[3].clearTracks(), a && h ? this.setMainBoxIcon(3, h - 1 == 3) : this.setMainBoxIcon(3), this.judgeFinalLevel() && r && r.length ? (this.boxChildNodeArr[3].getChildByName("num").active = this.boxDetailArr[3].type > -1, this.boxAnimCompArr[3].setAnimation(0, ut.Dkhx, true)) : (this.boxChildNodeArr[3].getChildByName("num").active = false, this.boxAnimCompArr[3].setAnimation(0, ut.Cc_wdj, false))) : this.stopHaveBoomTweenDelay(7);
                    }), l, true));
                    break;
                case 2:
                    i ? (this._haveboomTweenDealyArr[8] = TweenTool.delayAct(this._timerNode, (() => {
                        this.setMainBoxGray(1);
                        this.setMainBoxGray(3);
                        this.setMainBoxGray(4);
                    }), 1, true), this.boxAnimCompArr[0].setAnimation(0, ut.Xh, true), this.boxChildNodeArr[0].getChildByName("num").active = false, this.boxAnimCompArr[2].setAnimation(0, ut.Xh, true), this.boxChildNodeArr[2].getChildByName("num").active = false, this.boxAnimCompArr[3].setAnimation(0, ut.Xh, true), this.boxChildNodeArr[3].getChildByName("num").active = false) : (a && h ? this.secondOpenRewardAnim(o.serialNum, h, r) : (this._haveboomTweenDealyArr[5] = TweenTool.delayAct(this._timerNode, (() => {
                        this.setMainBoxGray(1);
                        this.boxAnimCompArr[0].setAnimation(0, ut.Zs, false);
                        this.setMainBoxGray(3);
                        this.boxAnimCompArr[2].setAnimation(0, ut.Zs, false);
                        this.setMainBoxGray(4);
                        this.boxAnimCompArr[3].setAnimation(0, ut.Zs, false);
                    }), 1, true), this._haveboomTweenDealyArr[6] = TweenTool.delayAct(this._timerNode, (() => {
                        this.boxDetailArr && 4 == this.boxDetailArr.length && [0, 1, 2, 3].includes(d) ? (this.boxChildNodeArr[0].getChildByName("num").active = this.boxDetailArr[0].type > -1, this.boxDetailArr[0].type > -1 && (this.boxChildNodeArr[0].getChildByName("num").getComponent(Label).string = ToolUtils.parse_double(this.boxDetailArr[0].num.toString(), -1)), this.boxChildNodeArr[2].getChildByName("num").active = this.boxDetailArr[2].type > -1, this.boxDetailArr[2].type > -1 && (this.boxChildNodeArr[2].getChildByName("num").getComponent(Label).string = ToolUtils.parse_double(this.boxDetailArr[2].num.toString(), -1)), this.boxChildNodeArr[3].getChildByName("num").active = this.boxDetailArr[3].type > -1, this.boxDetailArr[3].type > -1 && (this.boxChildNodeArr[3].getChildByName("num").getComponent(Label).string = ToolUtils.parse_double(this.boxDetailArr[3].num.toString(), -1))) : this.stopHaveBoomTweenDelay(6);
                    }), 1.5, true)), this._haveboomTweenDealyArr[7] = TweenTool.delayAct(this._timerNode, (() => {
                        this.boxDetailArr && 4 == this.boxDetailArr.length && [0, 1, 2, 3].includes(d) ? (this.boxAnimCompArr[0].clearTracks(), a && h ? this.setMainBoxIcon(0, h - 1 == 0) : this.setMainBoxIcon(0), this.judgeFinalLevel() && r && r.length ? (this.boxChildNodeArr[0].getChildByName("num").active = this.boxDetailArr[0].type > -1, this.boxAnimCompArr[0].setAnimation(0, ut.Dkhx, true)) : (this.boxChildNodeArr[0].getChildByName("num").active = false, this.boxAnimCompArr[0].setAnimation(0, ut.Cc_wdj, false)), this.boxAnimCompArr[2].clearTracks(), a && h ? this.setMainBoxIcon(2, h - 1 == 2) : this.setMainBoxIcon(2), this.judgeFinalLevel() && r && r.length ? (this.boxChildNodeArr[2].getChildByName("num").active = this.boxDetailArr[2].type > -1, this.boxAnimCompArr[2].setAnimation(0, ut.Dkhx, true)) : (this.boxChildNodeArr[2].getChildByName("num").active = false, this.boxAnimCompArr[2].setAnimation(0, ut.Cc_wdj, false)), this.boxAnimCompArr[3].clearTracks(), a && h ? this.setMainBoxIcon(3, h - 1 == 3) : this.setMainBoxIcon(3), this.judgeFinalLevel() && r && r.length ? (this.boxChildNodeArr[3].getChildByName("num").active = this.boxDetailArr[3].type > -1, this.boxAnimCompArr[3].setAnimation(0, ut.Dkhx, true)) : (this.boxChildNodeArr[3].getChildByName("num").active = false, this.boxAnimCompArr[3].setAnimation(0, ut.Cc_wdj, false))) : this.stopHaveBoomTweenDelay(7);
                    }), l, true));
                    break;
                case 3:
                    i ? (this._haveboomTweenDealyArr[8] = TweenTool.delayAct(this._timerNode, (() => {
                        this.setMainBoxGray(1);
                        this.setMainBoxGray(2);
                        this.setMainBoxGray(4);
                    }), 1, true), this.boxAnimCompArr[0].setAnimation(0, ut.Xh, true), this.boxChildNodeArr[0].getChildByName("num").active = false, this.boxAnimCompArr[1].setAnimation(0, ut.Xh, true), this.boxChildNodeArr[1].getChildByName("num").active = false, this.boxAnimCompArr[3].setAnimation(0, ut.Xh, true), this.boxChildNodeArr[3].getChildByName("num").active = false) : (a && h ? this.secondOpenRewardAnim(o.serialNum, h, r) : (this._haveboomTweenDealyArr[5] = TweenTool.delayAct(this._timerNode, (() => {
                        this.setMainBoxGray(1);
                        this.boxAnimCompArr[0].setAnimation(0, ut.Zs, false);
                        this.setMainBoxGray(2);
                        this.boxAnimCompArr[1].setAnimation(0, ut.Zs, false);
                        this.setMainBoxGray(4);
                        this.boxAnimCompArr[3].setAnimation(0, ut.Zs, false);
                    }), 1, true), this._haveboomTweenDealyArr[6] = TweenTool.delayAct(this._timerNode, (() => {
                        this.boxDetailArr && 4 == this.boxDetailArr.length && [0, 1, 2, 3].includes(d) ? (this.boxChildNodeArr[1].getChildByName("num").active = this.boxDetailArr[1].type > -1, this.boxDetailArr[1].type > -1 && (this.boxChildNodeArr[1].getChildByName("num").getComponent(Label).string = ToolUtils.parse_double(this.boxDetailArr[1].num.toString(), -1)), this.boxChildNodeArr[0].getChildByName("num").active = this.boxDetailArr[0].type > -1, this.boxDetailArr[0].type > -1 && (this.boxChildNodeArr[0].getChildByName("num").getComponent(Label).string = ToolUtils.parse_double(this.boxDetailArr[0].num.toString(), -1)), this.boxChildNodeArr[3].getChildByName("num").active = this.boxDetailArr[3].type > -1, this.boxDetailArr[3].type > -1 && (this.boxChildNodeArr[3].getChildByName("num").getComponent(Label).string = ToolUtils.parse_double(this.boxDetailArr[3].num.toString(), -1))) : this.stopHaveBoomTweenDelay(6);
                    }), 1.5, true)), this._haveboomTweenDealyArr[7] = TweenTool.delayAct(this._timerNode, (() => {
                        this.boxDetailArr && 4 == this.boxDetailArr.length && [0, 1, 2, 3].includes(d) ? (this.boxAnimCompArr[1].clearTracks(), a && h ? this.setMainBoxIcon(1, h - 1 == 1) : this.setMainBoxIcon(1), this.judgeFinalLevel() && r && r.length ? (this.boxChildNodeArr[1].getChildByName("num").active = this.boxDetailArr[1].type > -1, this.boxAnimCompArr[1].setAnimation(0, ut.Dkhx, true)) : (this.boxChildNodeArr[1].getChildByName("num").active = false, this.boxAnimCompArr[1].setAnimation(0, ut.Cc_wdj, false)), this.boxAnimCompArr[0].clearTracks(), a && h ? this.setMainBoxIcon(0, h - 1 == 0) : this.setMainBoxIcon(0), this.judgeFinalLevel() && r && r.length ? (this.boxChildNodeArr[0].getChildByName("num").active = this.boxDetailArr[0].type > -1, this.boxAnimCompArr[0].setAnimation(0, ut.Dkhx, true)) : (this.boxChildNodeArr[0].getChildByName("num").active = false, this.boxAnimCompArr[0].setAnimation(0, ut.Cc_wdj, false)), this.boxAnimCompArr[3].clearTracks(), a && h ? this.setMainBoxIcon(3, h - 1 == 3) : this.setMainBoxIcon(3), this.judgeFinalLevel() && r && r.length ? (this.boxChildNodeArr[3].getChildByName("num").active = this.boxDetailArr[3].type > -1, this.boxAnimCompArr[3].setAnimation(0, ut.Dkhx, true)) : (this.boxChildNodeArr[3].getChildByName("num").active = false, this.boxAnimCompArr[3].setAnimation(0, ut.Cc_wdj, false))) : this.stopHaveBoomTweenDelay(7);
                    }), l, true));
                    break;
                case 4: i ? (this._haveboomTweenDealyArr[8] = TweenTool.delayAct(this._timerNode, (() => {
                    this.setMainBoxGray(1);
                    this.setMainBoxGray(2);
                    this.setMainBoxGray(3);
                }), 1, true), this.boxAnimCompArr[0].setAnimation(0, ut.Xh, true), this.boxChildNodeArr[0].getChildByName("num").active = false, this.boxAnimCompArr[1].setAnimation(0, ut.Xh, true), this.boxChildNodeArr[1].getChildByName("num").active = false, this.boxAnimCompArr[2].setAnimation(0, ut.Xh, true), this.boxChildNodeArr[2].getChildByName("num").active = false) : (a && h ? this.secondOpenRewardAnim(o.serialNum, h, r) : (this._haveboomTweenDealyArr[5] = TweenTool.delayAct(this._timerNode, (() => {
                    this.setMainBoxGray(1);
                    this.boxAnimCompArr[0].setAnimation(0, ut.Zs, false);
                    this.setMainBoxGray(2);
                    this.boxAnimCompArr[1].setAnimation(0, ut.Zs, false);
                    this.setMainBoxGray(3);
                    this.boxAnimCompArr[2].setAnimation(0, ut.Zs, false);
                }), 1, true), this._haveboomTweenDealyArr[6] = TweenTool.delayAct(this._timerNode, (() => {
                    this.boxDetailArr && 4 == this.boxDetailArr.length && [0, 1, 2, 3].includes(d) ? (this.boxChildNodeArr[0].getChildByName("num").active = this.boxDetailArr[0].type > -1, this.boxDetailArr[0].type > -1 && (this.boxChildNodeArr[0].getChildByName("num").getComponent(Label).string = ToolUtils.parse_double(this.boxDetailArr[0].num.toString(), -1)), this.boxChildNodeArr[1].getChildByName("num").active = this.boxDetailArr[1].type > -1, this.boxDetailArr[1].type > -1 && (this.boxChildNodeArr[1].getChildByName("num").getComponent(Label).string = ToolUtils.parse_double(this.boxDetailArr[1].num.toString(), -1)), this.boxChildNodeArr[2].getChildByName("num").active = this.boxDetailArr[2].type > -1, this.boxDetailArr[2].type > -1 && (this.boxChildNodeArr[2].getChildByName("num").getComponent(Label).string = ToolUtils.parse_double(this.boxDetailArr[2].num.toString(), -1))) : this.stopHaveBoomTweenDelay(6);
                }), 1.5, true)), this._haveboomTweenDealyArr[7] = TweenTool.delayAct(this._timerNode, (() => {
                    this.boxDetailArr && 4 == this.boxDetailArr.length && [0, 1, 2, 3].includes(d) ? (this.boxAnimCompArr[1].clearTracks(), a && h ? this.setMainBoxIcon(1, h - 1 == 1) : this.setMainBoxIcon(1), this.judgeFinalLevel() && r && r.length ? (this.boxChildNodeArr[1].getChildByName("num").active = this.boxDetailArr[1].type > -1, this.boxAnimCompArr[1].setAnimation(0, ut.Dkhx, true)) : (this.boxChildNodeArr[1].getChildByName("num").active = false, this.boxAnimCompArr[1].setAnimation(0, ut.Cc_wdj, false)), this.boxAnimCompArr[2].clearTracks(), a && h ? this.setMainBoxIcon(2, h - 1 == 2) : this.setMainBoxIcon(2), this.judgeFinalLevel() && r && r.length ? (this.boxChildNodeArr[2].getChildByName("num").active = this.boxDetailArr[2].type > -1, this.boxAnimCompArr[2].setAnimation(0, ut.Dkhx, true)) : (this.boxChildNodeArr[2].getChildByName("num").active = false, this.boxAnimCompArr[2].setAnimation(0, ut.Cc_wdj, false)), this.boxAnimCompArr[0].clearTracks(), a && h ? this.setMainBoxIcon(0, h - 1 == 0) : this.setMainBoxIcon(0), this.judgeFinalLevel() && r && r.length ? (this.boxChildNodeArr[0].getChildByName("num").active = this.boxDetailArr[0].type > -1, this.boxAnimCompArr[0].setAnimation(0, ut.Dkhx, true)) : (this.boxChildNodeArr[0].getChildByName("num").active = false, this.boxAnimCompArr[0].setAnimation(0, ut.Cc_wdj, false))) : this.stopHaveBoomTweenDelay(7);
                }), l, true));
            }
        }
        else {
            let t = this.getMainData();
            if (!t) {
                return;
            }
            for (let e = 0; e < this.boxAnimCompArr.length; e++) {
                this.resetMainBoxGray(e + 1);
                this.boxAnimCompArr[e].clearTracks();
                e == t.boom_box_index - 1 ? (this.setMainBoxGray(t.boom_box_index), this.setMainBoxIcon(e, true), this.boxAnimCompArr[e].setAnimation(0, ut.Dkhx, true)) : this.boxAnimCompArr[e].setAnimation(0, ut.Xh, true);
            }
            0 == e && (n ? (User.shared().treasureBoomPopData = n, ToolUtils.isObjValid(this.node) && this.showBoomBalanceNodeUI()) : (Utils.shared().showLoading(10, true, (() => {
                Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
            })), this.requestBoomPopPage()));
        }
    }
    secondOpenRewardAnim(e, t, i) {
        let o = [1, 2, 3, 4].filter((i => ![e, t].includes(i)));
        if (o && o.length && 2 == o.length) {
            for (let e = 0; e < o.length; e++) {
                switch (o[e]) {
                    case 1:
                        this._haveboomTweenDealyArr[5] = TweenTool.delayAct(this.node, (() => {
                            this.setMainBoxGray(1);
                            this.boxAnimCompArr[0].setAnimation(0, ut.Zs, false);
                        }), 1, true), this._haveboomTweenDealyArr[6] = TweenTool.delayAct(this.node, (() => {
                            this.boxDetailArr ? (this.boxChildNodeArr[0].getChildByName("num").active = this.boxDetailArr[0].type > -1, this.boxDetailArr[0].type > -1 && (this.boxChildNodeArr[0].getChildByName("num").getComponent(Label).string = ToolUtils.parse_double(this.boxDetailArr[0].num.toString(), -1))) : this.stopHaveBoomTweenDelay(6);
                        }), 1.5, true);
                        break;
                    case 2:
                        this._haveboomTweenDealyArr[5] = TweenTool.delayAct(this.node, (() => {
                            this.setMainBoxGray(2);
                            this.boxAnimCompArr[1].setAnimation(0, ut.Zs, false);
                        }), 1, true), this._haveboomTweenDealyArr[6] = TweenTool.delayAct(this.node, (() => {
                            this.boxDetailArr ? (this.boxChildNodeArr[1].getChildByName("num").active = this.boxDetailArr[1].type > -1, this.boxDetailArr[1].type > -1 && (this.boxChildNodeArr[1].getChildByName("num").getComponent(Label).string = ToolUtils.parse_double(this.boxDetailArr[1].num.toString(), -1))) : this.stopHaveBoomTweenDelay(6);
                        }), 1.5, true);
                        break;
                    case 3:
                        this._haveboomTweenDealyArr[5] = TweenTool.delayAct(this.node, (() => {
                            this.setMainBoxGray(3);
                            this.boxAnimCompArr[2].setAnimation(0, ut.Zs, false);
                        }), 1, true), this._haveboomTweenDealyArr[6] = TweenTool.delayAct(this.node, (() => {
                            this.boxDetailArr ? (this.boxChildNodeArr[2].getChildByName("num").active = this.boxDetailArr[2].type > -1, this.boxDetailArr[2].type > -1 && (this.boxChildNodeArr[2].getChildByName("num").getComponent(Label).string = ToolUtils.parse_double(this.boxDetailArr[2].num.toString(), -1))) : this.stopHaveBoomTweenDelay(6);
                        }), 1.5, true);
                        break;
                    case 4: this._haveboomTweenDealyArr[5] = TweenTool.delayAct(this.node, (() => {
                        this.setMainBoxGray(4);
                        this.boxAnimCompArr[3].setAnimation(0, ut.Zs, false);
                    }), 1, true), this._haveboomTweenDealyArr[6] = TweenTool.delayAct(this.node, (() => {
                        this.boxDetailArr ? (this.boxChildNodeArr[3].getChildByName("num").active = this.boxDetailArr[3].type > -1, this.boxDetailArr[3].type > -1 && (this.boxChildNodeArr[3].getChildByName("num").getComponent(Label).string = ToolUtils.parse_double(this.boxDetailArr[3].num.toString(), -1))) : this.stopHaveBoomTweenDelay(6);
                    }), 1.5, true);
                }
            }
        }
    }
    resetMainBoxGray(e) {
        var t;
        e < 1 || null == (t = this.boxAnimCompArr) || !t.length || (this.boxAnimCompArr[e - 1].color = color(255, 255, 255, 255));
    }
    setMainBoxGray(e) {
        var t;
        e < 1 || null == (t = this.boxChildNodeArr) || !t.length || (this.boxAnimCompArr[e - 1].color = color(128, 128, 128, 255));
    }
    setMainBoxIcon(e, t) {
        var i;
        if (!(e < 0 || null == (i = this.boxAnimCompArr)) && i.length) {
            if (t) {
                this.boxAnimCompArr[e].setAttachment(this.ani_hd_jl_chacao_1, null);
                this.boxAnimCompArr[e].setAttachment(this.ani_hd_jl_chacao_2, null);
            }
            else {
                if (!this.boxDetailArr || !this.boxDetailArr.length) {
                    return;
                }
                this.boxAnimCompArr[e].setAttachment(this.ani_hd_jl_chacao_1, this.getMainBoxAttSpriteName(this.boxDetailArr[e].type));
                this.boxAnimCompArr[e].setAttachment(this.ani_hd_jl_chacao_2, this.getMainBoxAttSpriteName(this.boxDetailArr[e].type));
            }
        }
    }
    showFinishUI() {
        let e = this.getMainData();
        e && (this.bigPrice_finish.getComponent(RichText).string = ToolUtils.format(i18nMgr.shared().getValueByKey("treasure.bigPrice_finish"), e.content_challenges));
    }
    showBoomBalanceNodeUI() {
        if (!sys.isObjectValid(User.shared().treasureBoomPopData)) {
            return;
        }
        this._bCanSend && HttpManager.shared().doCommReportRechargeEvent(ReportConfig.Cmd_Treasure, this._reportScene, 17, this._linkId, "", 0);
        this.boomBalanceNode.active = true;
        let e = User.shared().treasureBoomPopData, t = this.btn_balance.getChildByName("Node").getChildByName("icon_bal"), i = this.btn_balance.getChildByName("Node").getChildByName("spend_bal"), o = [], r = this.judgeFinalAccuReaward();
        this.allAccuReaward.active = r;
        this.grandPrize.active = !r;
        r || (this.grandPrize.getComponent(RichText).string = ToolUtils.format(i18nMgr.shared().getValueByKey("treasure.balance_grand_prize"), e.content_open_count));
        i.getComponent(Label).string = ToolUtils.parse_double(e.amount, -1);
        t && this.spend_item_sprite && (t.getComponent(Sprite).spriteFrame = this.spend_item_sprite);
        for (let t = 0; t < e.accu_reward_list.length; t++) {
            o.push({ type: e.accu_reward_list[t].type, amt: e.accu_reward_list[t].amt });
        }
        !o || !sys.isObjectValid(o) || o.length <= 0 ? this.rewardNode_bal.active = this.rewardMoban_bal.active = false : this.showRewardNodeBal(o);
    }
    showRewardNodeBal(e) {
        if (!e || !e.length) {
            return;
        }
        let t = this.getMainData();
        if (t && t.ui == ct.Challenge) {
            this.rewardNode_bal.active = true;
            this.rewardNode_bal.removeAllChildren();
            for (let t = 0; t < e.length; t++) {
                let i = instantiate(this.rewardMoban_bal);
                i.active = true;
                i.setPosition(v3(0, 0, 0));
                this.rewardNode_bal.addChild(i);
                this.initRewardMobanBal(i, e[t]);
            }
        }
    }
    initRewardMobanBal(e, t) {
        let i = e.getChildByName("rewardItemAnim").getComponent(sp.Skeleton), o = e.getChildByName("num"), r = e.getChildByName("name"), a = this.getMainBoxAttSpriteName(t.type);
        o.active = r.active = true;
        o.getComponent(Label).string = ToolUtils.parse_double(t.amt, -1);
        r.getComponent(Label).string = this.getIconNameByType(t.type, t.desc);
        i.clearTracks();
        i.setAttachment(this.ani_hd_baoxiangcg_daoju, a);
        i.setAnimation(0, this.jlk_xh, true);
    }
    updateBoxDetailArr(e) {
        this.boxDetailArr = e.map((e => ({ ...e }))) || [];
        this.boxDetailArr.length && this.boxDetailArr.sort(((e, t) => (e.serialNum, t.serialNum, e.serialNum - t.serialNum)));
    }
    updateShopLeafUI(e) {
        let t = e || 0;
        if (!t) {
            let e = this.getMainData();
            t = e && sys.isObjectValid(e.leaf_num) ? ToolUtils.isSafeNumber(e.leaf_num) : 0;
        }
        this.btn_shop.getChildByName("money").getComponent(Label).string = ToolUtils.parse_double(String(t), -1);
    }
    updateRewardSprite(e, t) {
        ToolUtils.isSafeString(CommDefine.rewardPistName[t]).length > 0 && Utils.shared().setImage(e, CommDefine.rewardPistName[t], this.rewardPlist);
    }
    setLastAccuRewardList(e) {
        if (this.lastAccuRewardList = [], e) {
            return;
        }
        let t = this.getMainData();
        if (t && t.accu_reward_list) {
            for (let e = 0; e < t.accu_reward_list.length; e++) {
                this.lastAccuRewardList.push({ type: t.accu_reward_list[e].type, amt: t.accu_reward_list[e].amt });
            }
        }
        this.lastAccuRewardList.sort(((e, t) => e.type - t.type));
    }
    setLastUistate() {
        let e = this.getMainData();
        e && (this.lastUiState = e.ui);
    }
    getAwardBoxDetail() {
        return this.isOpeningBox && this.boxDetailArr.find((e => e.isAward)) || null;
    }
    isExistBoomBox() {
        if (this.boxDetailArr && this.boxDetailArr.length) {
            for (let e = 0; e < this.boxDetailArr.length; e++) {
                if (-1 == this.boxDetailArr[e].type) {
                    return true;
                }
            }
        }
        else {
            let e = this.getMainData();
            if (!e) {
                return false;
            }
            if (e.ui == ct.Challenge && e.boom_box_index >= 1) {
                return true;
            }
        }
        return false;
    }
    judgeFinalLevel() {
        let e = this.getMainData();
        return !(!e || e.ui != ct.Challenge || e.now_id != e.list[e.list.length - 1].id);
    }
    getMainBoxAttSpriteName(e) {
        let t = "";
        if ("number" != typeof e || isNaN(e)) {
            return t;
        }
        switch (e) {
            case -1:
                t = this.ani_hd_baoxiangcg_daoju_4;
                break;
            case 0:
                t = this.ani_hd_baoxiangcg_daoju_1;
                break;
            case 1:
                t = this.ani_hd_baoxiangcg_daoju_2;
                break;
            default: t = this.ani_hd_baoxiangcg_daoju_3;
        }
        return t;
    }
    getIconNameByType(e, t = "") {
        let i = "";
        return 0 == e || 1 == e ? Utils.shared().getIconNameByType(e, t) : (i = i18nMgr.shared().getValueByKey("treasure.coupons"), ToolUtils.isSafeString(i).length > 0 ? i : t);
    }
    playMainBoxEntryAnim(e) {
        if (!(this.boxNodeArr && this.boxPresetMidPosArr && this.boxNodeArr.length === this.boxAnimCompArr.length && this.boxNodeArr.length === this.boxPresetMidPosArr.length)) {
            return;
        }
        if (!this.boxSkinArr || this.boxSkinArr.length < 2) {
            return;
        }
        let t = 0;
        const i = [];
        this.setMainBoxRandomSkinArr();
        for (let e = 0; e < this.boxNodeArr.length; e++) {
            this.boxNodeArr[e].position = new Vec3(this.boxPresetMidPosArr[e].x, this.boxPresetMidPosArr[e].y, this.boxPresetMidPosArr[e].z);
            this.boxAnimCompArr[e].clearTracks();
            this.boxAnimCompArr[e].setSkin(this.mainBoxRandomSkinArr[e]);
            this.boxAnimCompArr[e].color = color(255, 255, 255, 0);
            this.resetMainBoxGray(e + 1);
            this.boxNodeArr[e].active = false;
        }
        for (let o = 0; o < this.boxNodeArr.length; o++) {
            let r = tween(this.boxNodeArr[o]).delay(t).call((() => {
                this.boxNodeArr[o].active = true;
                this.boxAnimCompArr[o].color = color(255, 255, 255, 255);
                SoundManager.shared().playFx("treasure_move");
                this.boxAnimCompArr[o].setAnimation(0, ut.Jc, false);
                this.boxAnimCompArr[o].addAnimation(0, ut.Xh, true);
            })).delay(0.483).call((() => {
                o == this.boxNodeArr.length - 1 && (e && e(), i.forEach((e => e.stop())));
            })).start();
            i.push(r);
            t += 0.1;
        }
    }
    playMainBoxExitAnim(e) {
        if (!(this.boxNodeArr && this.boxPresetMidPosArr && this.boxNodeArr.length === this.boxAnimCompArr.length && this.boxNodeArr.length === this.boxPresetMidPosArr.length)) {
            return;
        }
        let t = 0, i = false;
        if (this.boxDetailArr && !(this.boxDetailArr.length < 4)) {
            for (let e = 0; e < this.boxDetailArr.length; e++) {
                if (this.boxDetailArr[e].type > -1 && !this.boxDetailArr[e].num) {
                    i = false;
                    break;
                }
            }
            if (i) {
                for (let i = 0; i < this.boxNodeArr.length; i++) {
                    tween(this.boxNodeArr[i]).delay(t).to(0.5, { position: new Vec3(this.boxPresetMidPosArr[i].x - 700, this.boxPresetMidPosArr[i].y, this.boxPresetMidPosArr[i].z) }).delay(0.27).call((() => {
                        i == this.boxNodeArr.length - 1 && e && e();
                    })).start();
                    t += 0.15;
                }
            }
        }
    }
    getRandomGuideChallAnimSkin() {
        let e;
        0 === this.guideRandomChallSkinArr.length && this.boxSkinArr.length > 0 && (this.guideRandomChallSkinArr = [...this.boxSkinArr]);
        do {
            let t = Math.floor(Math.random() * this.guideRandomChallSkinArr.length);
            e = this.guideRandomChallSkinArr[t];
        } while (this.guideRandomSkinPreValues.includes(e));
        return this.guideRandomSkinPreValues.length >= 3 && this.guideRandomSkinPreValues.shift(), this.guideRandomSkinPreValues.push(e), this.guideRandomChallSkinArr.splice(this.guideRandomChallSkinArr.indexOf(e), 1), e;
    }
    getRandomFinishChallAnimSkin() {
        let e;
        0 === this.finishRandomChallSkinArr.length && this.boxSkinArr.length > 0 && (this.finishRandomChallSkinArr = [...this.boxSkinArr]);
        do {
            let t = Math.floor(Math.random() * this.finishRandomChallSkinArr.length);
            e = this.finishRandomChallSkinArr[t];
        } while (this.finishRandomSkinPreValues.includes(e));
        return this.finishRandomSkinPreValues.length >= 3 && this.finishRandomSkinPreValues.shift(), this.finishRandomSkinPreValues.push(e), this.finishRandomChallSkinArr.splice(this.finishRandomChallSkinArr.indexOf(e), 1), e;
    }
    playGuideChallAnim() {
        let e = this.challAnimGuideCompArr, t = this.challAnimGuidePosArr;
        if (e && e.length) {
            for (let t = 0, i = e.length; t < i; t++) {
                e[t].clearTracks();
                e[t].setToSetupPose();
            }
            if (this.challagesAnimGuide.length == t.length) {
                for (let i = 0, o = this.challagesAnimGuide.length; i < o; i++) {
                    TweenTool.stopNodeAction(this.challagesAnimGuide[i]);
                    e[i].setSkin(this.getRandomGuideChallAnimSkin());
                    this.challagesAnimGuide[i].position = t[i];
                    this.challagesAnimGuide[i].scale = new Vec3(1, 1, 1);
                    this.challagesAnimGuide[i].position.x == t[1].x ? this.playGuideBoxOpenAnim(i, true, this.startGuideBoxCycleSchedule.bind(this)) : e[i].setAnimation(0, ut.Jt, true);
                }
            }
        }
    }
    playFinishChallAnim() {
        let e = this.challAnimFinishCompArr, t = this.challAnimFinishPosArr;
        e && e.length && (e.forEach((e => {
            e.clearTracks();
            e.setToSetupPose();
        })), this.challagesAnimFinish.length === t.length && this.challagesAnimFinish.forEach(((i, o) => {
            TweenTool.stopNodeAction(i);
            e[o].setSkin(this.getRandomFinishChallAnimSkin());
            i.position = t[o];
            i.scale = new Vec3(1, 1, 1);
            i.position.x === t[1].x ? this.playFinishBoxOpenAnim(o, true, this.startFinishBoxCycleSchedule.bind(this)) : e[o].setAnimation(0, ut.Jt, true);
        })));
    }
    stopGuideBoxCycleSchedule() {
        this.guideRandomChallSkinArr = [];
        this.guideRandomSkinPreValues = [];
        this.guideBoxCycleScheduleId && (TweenTool.stopAction(this.guideBoxCycleScheduleId), this.guideBoxCycleScheduleId = null);
    }
    stopFinishBoxCycleSchedule() {
        this.finishRandomChallSkinArr = [];
        this.finishRandomSkinPreValues = [];
        this.finishBoxCycleScheduleId && (TweenTool.stopAction(this.finishBoxCycleScheduleId), this.finishBoxCycleScheduleId = null);
    }
    guideBoxCycleAnim() {
        let e = this.challAnimGuidePosArr;
        for (let t = 0; t < this.challagesAnimGuide.length; t++) {
            if (this.challagesAnimGuide[t].position.x == e[0].x) {
                this.playGuideBoxFrontMove(t, new Vec3(e[0].x - 305, e[0].y, e[0].z));
            }
            else if (this.challagesAnimGuide[t].position.x == e[1].x) {
                this.playGuideBoxMidToLeft(t);
            }
            else if (this.challagesAnimGuide[t].position.x == e[2].x) {
                this.playGuideBoxMoveToMid(t);
            }
            else {
                let i;
                for (let o = 0; o < e.length; o++) {
                    if (this.challagesAnimGuide[t].position.x == e[o].x) {
                        if (0 == o) {
                            break;
                        }
                        i = e[o - 1];
                    }
                }
                if (!i) {
                    return;
                }
                this.playGuideBoxSimpleMove(t, i);
            }
        }
    }
    finishBoxCycleAnim() {
        let e = this.challAnimFinishPosArr;
        for (let t = 0; t < this.challagesAnimFinish.length; t++) {
            if (this.challagesAnimFinish[t].position.x == e[0].x) {
                this.playFinishBoxFrontMove(t, new Vec3(e[0].x - 305, e[0].y, e[0].z));
            }
            else if (this.challagesAnimFinish[t].position.x == e[1].x) {
                this.playFinishBoxMidToLeft(t);
            }
            else if (this.challagesAnimFinish[t].position.x == e[2].x) {
                this.playFinishBoxMoveToMid(t);
            }
            else {
                let i;
                for (let o = 0; o < e.length; o++) {
                    if (this.challagesAnimFinish[t].position.x == e[o].x) {
                        if (0 == o) {
                            break;
                        }
                        i = e[o - 1];
                    }
                }
                if (!i) {
                    return;
                }
                this.playFinishBoxSimpleMove(t, i);
            }
        }
    }
    startGuideBoxCycleSchedule() {
        this.guideBoxCycleAnim();
        this.guideBoxCycleScheduleId && (TweenTool.stopAction(this.guideBoxCycleScheduleId), this.guideBoxCycleScheduleId = null);
        this.guideBoxCycleScheduleId = tween(this.node).delay(4.3).call((() => {
            this.guideBoxCycleAnim();
        })).union().repeatForever().start();
    }
    startFinishBoxCycleSchedule() {
        this.finishBoxCycleAnim();
        this.finishBoxCycleScheduleId && (TweenTool.stopAction(this.finishBoxCycleScheduleId), this.finishBoxCycleScheduleId = null);
        this.finishBoxCycleScheduleId = tween(this.node).delay(4.3).call((() => {
            this.finishBoxCycleAnim();
        })).union().repeatForever().start();
    }
    playGuideBoxFrontMove(e, t) {
        tween(this.challagesAnimGuide[e]).to(0.7, { position: t }, { easing: "expoOut" }).call((() => {
            this.challagesAnimGuide[e].position = this.challAnimGuidePosArr[this.challAnimGuidePosArr.length - 1];
            this.challAnimGuideCompArr[e].setSkin(this.getRandomGuideChallAnimSkin());
        })).start();
    }
    playFinishBoxFrontMove(e, t) {
        tween(this.challagesAnimFinish[e]).to(0.7, { position: t }, { easing: "expoOut" }).call((() => {
            this.challagesAnimFinish[e].position = this.challAnimFinishPosArr[this.challAnimFinishPosArr.length - 1];
            this.challAnimFinishCompArr[e].setSkin(this.getRandomFinishChallAnimSkin());
        })).start();
    }
    playGuideBoxSimpleMove(e, t) {
        tween(this.challagesAnimGuide[e]).to(0.7, { position: t }, { easing: "expoOut" }).start();
    }
    playFinishBoxSimpleMove(e, t) {
        tween(this.challagesAnimFinish[e]).to(0.7, { position: t }, { easing: "expoOut" }).start();
    }
    playGuideBoxMidToLeft(e) {
        tween(this.challagesAnimGuide[e]).call((() => {
            this.challAnimGuideCompArr[e].setAnimation(0, ut.Jt, true);
        })).to(0.7, { position: this.challAnimGuidePosArr[0], scale: new Vec3(1, 1, 0) }, { easing: "expoOut" }).start();
    }
    playFinishBoxMidToLeft(e) {
        tween(this.challagesAnimFinish[e]).call((() => {
            this.challAnimFinishCompArr[e].setAnimation(0, ut.Jt, true);
        })).to(0.7, { position: this.challAnimFinishPosArr[0], scale: new Vec3(1, 1, 0) }, { easing: "expoOut" }).start();
    }
    playGuideBoxMoveToMid(e) {
        tween(this.challagesAnimGuide[e]).call((() => {
            0 == this.challAnimGuideBoxIconArr[e] ? this.challAnimGuideBoxIconArr[e] = 1 : (this.challAnimGuideBoxIconArr[e], this.challAnimGuideBoxIconArr[e] = 0);
            let t = 0 == this.challAnimGuideBoxIconArr[e] ? "ani_hd_baoxiangcg_daoju_1" : "ani_hd_baoxiangcg_daoju_2";
            this.challAnimGuideCompArr[e].setAttachment("ani_hd_jl_chacao_1", t);
            this.challAnimGuideCompArr[e].setAttachment("ani_hd_jl_chacao_2", t);
            this.challAnimGuideCompArr[e].setAnimation(0, ut.Jt, true);
        })).to(0.7, { position: this.challAnimGuidePosArr[1], scale: new Vec3(1.5, 1.5, 0) }, { easing: "expoOut" }).call((() => {
            this.playGuideBoxOpenAnim(e, false);
        })).start();
    }
    playFinishBoxMoveToMid(e) {
        tween(this.challagesAnimFinish[e]).call((() => {
            0 == this.challAnimFinishBoxIconArr[e] ? this.challAnimFinishBoxIconArr[e] = 1 : (this.challAnimFinishBoxIconArr[e], this.challAnimFinishBoxIconArr[e] = 0);
            let t = 0 == this.challAnimFinishBoxIconArr[e] ? "ani_hd_baoxiangcg_daoju_1" : "ani_hd_baoxiangcg_daoju_2";
            this.challAnimFinishCompArr[e].setAttachment("ani_hd_jl_chacao_1", t);
            this.challAnimFinishCompArr[e].setAttachment("ani_hd_jl_chacao_2", t);
            this.challAnimFinishCompArr[e].setAnimation(0, ut.Jt, true);
        })).to(0.7, { position: this.challAnimFinishPosArr[1], scale: new Vec3(1.5, 1.5, 0) }, { easing: "expoOut" }).call((() => {
            this.playFinishBoxOpenAnim(e, false);
        })).start();
    }
    playGuideBoxOpenAnim(e, t, i) {
        t ? tween(this.challagesAnimGuide[e]).call((() => {
            this.challAnimGuideCompArr[e].setAnimation(0, ut.Dk, false);
        })).to(0.5, { scale: new Vec3(1.5, 1.5, 0) }).delay(2.1).call((() => {
            this.challAnimGuideCompArr[e].setAnimation(0, ut.Jt, true);
        })).delay(1).call((() => {
            null == i || i();
        })).start() : tween(this.challagesAnimGuide[e]).call((() => {
            this.challAnimGuideCompArr[e].setAnimation(0, ut.Dk, false);
        })).delay(2.6).call((() => {
            this.challAnimGuideCompArr[e].setAnimation(0, ut.Jt, true);
        })).delay(1).call((() => {
            null == i || i();
        })).start();
    }
    playFinishBoxOpenAnim(e, t, i) {
        t ? tween(this.challagesAnimFinish[e]).call((() => {
            this.challAnimFinishCompArr[e].setAnimation(0, ut.Dk, false);
        })).to(0.5, { scale: new Vec3(1.5, 1.5, 0) }).delay(2.1).call((() => {
            this.challAnimFinishCompArr[e].setAnimation(0, ut.Jt, true);
        })).delay(1).call((() => {
            null == i || i();
        })).start() : tween(this.challagesAnimFinish[e]).call((() => {
            this.challAnimFinishCompArr[e].setAnimation(0, ut.Dk, false);
        })).delay(2.6).call((() => {
            this.challAnimFinishCompArr[e].setAnimation(0, ut.Jt, true);
        })).delay(1).call((() => {
            null == i || i();
        })).start();
    }
    getRandomElements(e, t) {
        if (t > e.length) {
            return;
        }
        const i = [], o = new Set;
        for (; i.length < t;) {
            const t = Math.floor(Math.random() * e.length);
            o.has(t) || (o.add(t), i.push(e[t]));
        }
        return i;
    }
    onBackView() {
        if (ToolUtils.isObjValid(this.node)) {
            if (this.boomThinkNode.active) {
                this.boomThinkNode.active = false;
            }
            else if (this.ruleNode.active) {
                this.ruleNode.active = false;
            }
            else {
                if (this._has_close) {
                    return;
                }
                this.stopReqTreasurePageAct();
                this.stopGuideBoxCycleSchedule();
                this.stopFinishBoxCycleSchedule();
                let e = { alert_node: this.node, rootNode: this.rootNode, isNext: this.isNext, pop_type: PushEvent.JUMP_TO_Treasure };
                Utils.shared().closeActivityView(e);
                this._has_close = true;
                User.shared().getHallInfo();
                this._callback && this._callback();
            }
        }
    }
    onButtonClick(e, t) {
        if (!(sys.now() - this._lastClick < 300)) {
            switch ((this._lastClick = sys.now(), SoundManager.shared().playFx("click"), t)) {
                case "think":
                    this._bCanSend && HttpManager.shared().doCommReportRechargeEvent(ReportConfig.Cmd_Treasure, this._reportScene, 23, this._linkId, "", 0), this.onBackView();
                    break;
                case "close":
                    this.onBackView();
                    break;
                case "shop":
                    let e = this.getMainData();
                    e && sys.isObjectValid(e.shop_goods_list) && e.shop_goods_list && Array.isArray(e.shop_goods_list) && Utils.shared().doCustomJump(PushEvent.Custom_TO_TREASURE_RECHARGE, { goods_list: e.shop_goods_list, self_rec: true });
                    break;
                case "rule": if (ToolUtils.isObjValid(this.ruleNode)) {
                    let e = this.getMainData();
                    this.ruleNode.active = true;
                    this.startShowAnim(this.ruleNode.getChildByName("bg"));
                    e && (this.ruleLabel.string = e.tips);
                }
            }
        }
    }
    onBtnGetRewardClick() {
        if (sys.now() - this._lastClick_getReward < 1000) {
            return;
        }
        SoundManager.shared().playFx("click");
        this._lastClick_getReward = sys.now();
        let e = this.getMainData();
        if (e) {
            switch (e.ui) {
                case ct.NotTriggered:
                    if (0 == e.is_free) {
                        if (!User.shared().checkCanRecharge()) {
                            return void (ToolUtils.isObjValid(this.node) && this.node.destroy());
                        }
                        if (1 == e.can_start) {
                            1 == e.open_type ? 1 == e.is_history_pay && this.requestStartFree(2) : 2 == e.open_type && 1 == e.is_history_pay && this.requestStartFree(3);
                        }
                        else if (this._bCanSend && HttpManager.shared().doCommReportRechargeEvent(ReportConfig.Cmd_Treasure, this._reportScene, 10, this._linkId, "", 0), 1 == e.open_type) {
                            let t = { price: e.goods_price, act_id: PushEvent.JUMP_TO_Treasure, link_id: this._linkId, is_guide: 1 };
                            User.shared().startPay(t);
                        }
                        else {
                            2 == e.open_type && (0 == e.cash_limit ? this.requestStartFree(3) : 1 == e.cash_limit && this.requestGetRecommendGoodsPage(2));
                        }
                    }
                    else {
                        1 == e.is_free && (this._bCanSend && HttpManager.shared().doCommReportRechargeEvent(ReportConfig.Cmd_Treasure, this._reportScene, 6, this._linkId, "", 0), this.requestStartFree(1));
                    }
                    break;
                case ct.Challenge:
                    if (e.now_id <= 1) {
                        return;
                    }
                    if (e.boom_box_index >= 1) {
                        return;
                    }
                    if (this.isOpeningBox || this.isSwitchLeveling) {
                        return;
                    }
                    this._bCanSend && (0 == e.is_free ? HttpManager.shared().doCommReportRechargeEvent(ReportConfig.Cmd_Treasure, this._reportScene, 13, this._linkId, "", 0) : 1 == e.is_free && HttpManager.shared().doCommReportRechargeEvent(ReportConfig.Cmd_Treasure, this._reportScene, 12, this._linkId, "", 0)), this.requestGetReward();
            }
        }
    }
    onBoxClick(e, t) {
        let i = this.getMainData();
        if (!i) {
            return;
        }
        if (this.isOpeningBox) {
            return;
        }
        if (this.isSwitchLeveling) {
            return;
        }
        let o = "box" + i.boom_box_index;
        i.boom_box_index >= 1 ? 1 == i.has_paid_bomb_fee && o != t && (this._bCanSend && HttpManager.shared().doCommReportRechargeEvent(ReportConfig.Cmd_Treasure, this._reportScene, 14, this._linkId, "", 0), this.requestOpenBox(Number(t.slice(3)), true)) : (this._bCanSend && HttpManager.shared().doCommReportRechargeEvent(ReportConfig.Cmd_Treasure, this._reportScene, 14, this._linkId, "", 0), this.requestOpenBox(Number(t.slice(3)), false));
    }
    onLevelClick() {
    }
    onBtnBalanceClick() {
        if (sys.now() - this._lastClick_Balance < 300) {
            return;
        }
        if (this._lastClick_Balance = sys.now(), SoundManager.shared().playFx("click"), !sys.isObjectValid(User.shared().treasureBoomPopData)) {
            return;
        }
        0 == User.shared().treasureBoomPopData.recommend_goods_id ? (this._bCanSend && HttpManager.shared().doCommReportRechargeEvent(ReportConfig.Cmd_Treasure, this._reportScene, 18, this._linkId, "", 0), this.requestSkipBomb()) : (this._bCanSend && HttpManager.shared().doCommReportRechargeEvent(ReportConfig.Cmd_Treasure, this._reportScene, 19, this._linkId, "", 0), this.requestGetRecommendGoodsPage(1));
    }
    onBtnLeaveBalClick(e, t) {
        sys.now() - this._lastClick_LeaveBal < 300 || (this._lastClick_LeaveBal = sys.now(), SoundManager.shared().playFx("click"), "bal" == t ? (this._bCanSend && HttpManager.shared().doCommReportRechargeEvent(ReportConfig.Cmd_Treasure, this._reportScene, 21, this._linkId, "", 0), this.boomThinkNode.active || (this.boomThinkNode.active = true, this._bCanSend && HttpManager.shared().doCommReportRechargeEvent(ReportConfig.Cmd_Treasure, this._reportScene, 22, this._linkId, "", 0))) : "think" == t && (this._bCanSend && HttpManager.shared().doCommReportRechargeEvent(ReportConfig.Cmd_Treasure, this._reportScene, 24, this._linkId, "", 0), this.requestGiveUp()));
    }
    stopReqTreasurePageAct() {
        this._reqTreasurePageAct && (TweenTool.stopAction(this._reqTreasurePageAct), this._reqTreasurePageAct = null);
    }
    onDestroy() {
        super.destroy();
        PushCenter.shared().removeListenersByTag(this);
        this.unscheduleAllCallbacks();
        this.stopReqTreasurePageAct();
        this.stopGuideBoxCycleSchedule();
        this.stopFinishBoxCycleSchedule();
        this.stopAllNoBoomTweenDelay();
        this.stopAllHaveBoomTweenDelay();
    }
}
