// @ts-nocheck
// Recovered from index.js:681
import { _decorator, Button, color, EditBox, HorizontalTextAlignment, Label, LabelShadow, Node, RichText, Sprite, SpriteFrame, sys, v3, Vec3, Widget } from "cc";
import { TLog } from "./TLog";
import SoundManager from "./SoundManager";
import Utils from "./Utils";
import i18nMgr from "./i18nMgr";
import HttpManager from "./HttpManager";
import { HttpRequest } from "./HttpRequestName";
import User from "./User";
import BaseLayer from "./BaseLayer";
import PushCenter from "./PushCenter";
import PushEvent from "./PushEvent";
import TweenTool from "./TweenTool";
import ReportConfig from "./ReportConfig";
import CommDefine from "./CommDefine";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("WithdrawAdd")
export class WithdrawAdd extends BaseLayer {
    public TAG: string = "WithdrawAdd";
    @property(Node)
    public bankNode: Node = null;
    @property(Node)
    public upiNode: Node = null;
    @property(EditBox)
    public nameEdit: EditBox = null;
    @property(EditBox)
    public numberEdit: EditBox = null;
    @property(EditBox)
    public ifscEdit: EditBox = null;
    @property(EditBox)
    public upiEdit: EditBox = null;
    @property(Node)
    public nameDelBtn: Node = null;
    @property(Node)
    public numberDelBtn: Node = null;
    @property(Node)
    public ifscDelBtn: Node = null;
    @property(Node)
    public upiDelBtn: Node = null;
    @property(Node)
    public tipsNode: Node = null;
    @property(Sprite)
    public checkSprite: Sprite = null;
    @property(Node)
    public panNameNode: Node = null;
    @property(Node)
    public inputNode: Node = null;
    @property(Node)
    public verify_btn: Node = null;
    @property([SpriteFrame])
    public verifyBtnDiImags: SpriteFrame[] = [];
    @property([SpriteFrame])
    public tabImags: SpriteFrame[] = [];
    @property([Node])
    public tabNodes: Node[] = [];
    public callback: any = null;
    public _is_checked: number = 1;
    public _w_type: number = 4;
    public _tabIndex: number = 0;
    public _infodata: any = null;
    public _data: any = null;
    public _source_type: number = 0;
    public _center_widgeY: number = 99.376;
    public _input_offY: any = -90;
    public _mIdTime: number = 0;
    public _identitytimeAction: any = null;
    public _countDownAction: any = null;
    public _closed: boolean = false;
    public _record_id: number = 0;
    public _closeUpdateBankCardVerify: boolean = false;
    initData(t = null, e = null) {
        this.callback = t;
        e && (this._source_type = e);
    }
    start() {
        super.start();
        ToolUtils.adaptSafeArea(this.node.getChildByName("root"));
        this.refreshTabButtons();
        this.refreshView();
        let t = ToolUtils.getLimitLengthString(ToolUtils.isSafeString(User.shared().data.real_name), 50, false);
        this.nameEdit.string = t;
        this.verify_btn.getComponent(Widget).bottom = 21 - sys.getSafeAreaRect().y;
        this.updateCheckImageState();
        this.changeNameDelVisible();
        this.changeNumberDelVisible();
        this.changeIfscDelVisible();
        this.changeUpiDelVisible();
        let e = "";
        if (sys.isObjectValid(User.shared().DepositTransferData) && sys.isObjectValid(User.shared().DepositTransferData.list)) {
            for (let t = 0, i = User.shared().DepositTransferData.list.length; t < i; t++) {
                let i = User.shared().DepositTransferData.list[t];
                2 == i.type && sys.isObjectValid(i.pan_name) && (e = i.pan_name);
            }
        }
        if (sys.isObjectValid(e) && e.length > 0) {
            i18nMgr.shared().changeLabelLanguage(this.panNameNode.getChildByName("pan_name").getComponent(RichText), "kyc.kyc_update_pan", false, e);
            this.panNameNode.active = true;
            let t = new Vec3;
            this.inputNode.getPosition(t);
            this.inputNode.setPosition(v3(t.x, t.y + this._input_offY, t.z));
        }
        else {
            this.panNameNode.active = false;
        }
        PushCenter.shared().addListener(PushEvent.RefreshWithdrawData, (t => {
            sys.isObjectValid(this.node) && (this.refreshTabButtons(), this.refreshView());
        }), this);
        PushCenter.shared().addListener(PushEvent.UpdateBankCardVerify, (t => {
            if (sys.isObjectValid(this.node)) {
                if (this._closeUpdateBankCardVerify) {
                    return;
                }
                sys.isObjectValid(t) && sys.isObjectValid(t.record_id) && t.record_id == this._record_id && (sys.isObjectValid(t.msg) && this.showErrTips(t.msg), Utils.shared().hideLoading(), this.revertBtnStatus(1));
            }
        }), this);
        this.dealMultipleLanguages();
        HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Withdraw, event: ReportConfig.hall_evt.withdraw_add_show });
    }
    dealMultipleLanguages() {
        2 == i18nMgr.shared().language ? ToolUtils.isObjValid(this.panNameNode.getChildByName("title")) && (this.panNameNode.getChildByName("title").getComponent(Label).fontSize = 18) : 3 == i18nMgr.shared().language && ToolUtils.isObjValid(this.tipsNode.getChildByName("tip2")) && (this.tipsNode.getChildByName("tip2").getComponent(Label).horizontalAlign = HorizontalTextAlignment.RIGHT);
    }
    showErrTips(t) {
        let e = this.node.getChildByName("root");
        ToolUtils.isObjValid(e.getChildByName("err_tip")) && (ToolUtils.isSafeString(t).length > 0 ? (e.getChildByName("err_tip").getChildByName("tx").getComponent(Label).string = t, e.getChildByName("err_tip").active = true, e.getChildByName("Node").getComponent(Widget).top = 601.704 + this._center_widgeY) : (e.getChildByName("err_tip").active = false, e.getChildByName("Node").getComponent(Widget).top = 601.704));
    }
    refreshTabButtons() {
        if (sys.isObjectValid(User.shared().DepositTransferData) && sys.isObjectValid(User.shared().DepositTransferData.list)) {
            let t = null;
            for (let e = 0, i = User.shared().DepositTransferData.list.length; e < i; e++) {
                2 == User.shared().DepositTransferData.list[e].type && (t = User.shared().DepositTransferData.list[e].w_type_list);
            }
            if (Array.isArray(t)) {
                let e = false, i = 0;
                for (let s = 0; s < this.tabNodes.length; s++) {
                    if (t.length > s) {
                        const a = t[s];
                        let n = ToolUtils.isSafeNumber(a.status), r = this.tabNodes[s];
                        this._tabIndex === s && (this._w_type = a.w_type);
                        r.getChildByName("Label").getComponent(Label).string = a.w_type_name;
                        1 === n ? (r.active = true, i++) : (r.active = false, 0 === s && (e = true));
                    }
                }
                if (i < 2) {
                    for (let t = 0; t < this.tabNodes.length; t++) {
                        this.tabNodes[t].getComponent(Button).interactable = false;
                    }
                }
                e && this.tabNodes[1].setPosition(v3(-170, 440));
            }
        }
    }
    updateCheckImageState() {
        1 === this._is_checked ? this.checkSprite.color = color(0, 140, 22) : this.checkSprite.color = color(200, 200, 200);
    }
    onTextChanged(t, e, i) {
        if ("name" === i) {
            let e = Utils.shared().removeNonAlphabetic(t);
            this.nameEdit.string = e;
            this.changeNameDelVisible();
        }
        else {
            "number" === i ? (t.length > 0 && "." === t.charAt(t.length - 1) && (this.numberEdit.string = t.substring(0, t.length - 1)), this.changeNumberDelVisible()) : "ifsc" === i ? this.changeIfscDelVisible() : "upi" === i && this.changeUpiDelVisible();
        }
    }
    button_click(t, e) {
        if (SoundManager.shared().playFx("click"), "close" == e) {
            this.onBackView();
        }
        else if ("okay" == e) {
            if (4 === this._w_type) {
                if (ToolUtils.isSafeString(this.numberEdit.string).length < 1) {
                    return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("withdraw.tips5"), 2);
                }
                let t = this.numberEdit.string;
                if (isNaN(Number(t))) {
                    return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("withdraw.tips5"), 2);
                }
                let e = ToolUtils.isSafeString(t).length;
                if (e < 9 || e > 18) {
                    return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("withdraw.tips5"), 2);
                }
                if (ToolUtils.isSafeString(this.ifscEdit.string).length < 1) {
                    return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("withdraw.tips8"), 2);
                }
                if (ToolUtils.isSafeString(this.ifscEdit.string).length < 11) {
                    return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("withdraw.tips6"), 2);
                }
                if ("0" !== this.ifscEdit.string.charAt(4)) {
                    return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("withdraw.tips7"), 2);
                }
            }
            else if (1 === this._w_type) {
                if (ToolUtils.isSafeString(this.upiEdit.string).length < 1) {
                    return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("withdraw.tips4"), 2);
                }
                if (!ToolUtils.checkUPIString(this.upiEdit.string)) {
                    return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("withdraw.tips4"), 2);
                }
            }
            this.verify_btn.getComponent(Button).interactable = false;
            this.showErrTips("");
            this.showVerifyBtnStatus(2);
            this.stopCountDownActin();
            this._countDownAction = TweenTool.delayAct(this.node, (() => {
                Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text37"), 3);
                this.revertBtnStatus(1);
            }), 30, true);
            HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Withdraw, event: ReportConfig.hall_evt.withdraw_modify_submit });
            this.requestAddWithdrawAccount();
        }
        else {
            "check" == e ? (this._is_checked = 1 === this._is_checked ? 0 : 1, this.updateCheckImageState()) : "name_del" == e ? (this.nameEdit.string = "", this.nameEdit.focus(), this.changeNameDelVisible()) : "number_del" == e ? (this.numberEdit.string = "", this.numberEdit.focus(), this.changeNumberDelVisible()) : "ifsc_del" == e ? (this.ifscEdit.string = "", this.ifscEdit.focus(), this.changeIfscDelVisible()) : "upi_del" == e && (this.upiEdit.string = "", this.upiEdit.focus(), this.changeUpiDelVisible());
        }
    }
    tab_click(t, e) {
        SoundManager.shared().playFx("click");
        Number(e) !== this._tabIndex && (this._tabIndex = Number(e), this.refreshView());
    }
    refreshView() {
        for (let t = 0; t < this.tabNodes.length; t++) {
            const e = this.tabNodes[t];
            this._tabIndex === t ? (e.getComponent(Sprite).spriteFrame = this.tabImags[1], e.getChildByName("Label").getComponent(Label).color = color(0, 140, 22, 255)) : (e.getComponent(Sprite).spriteFrame = this.tabImags[0], e.getChildByName("Label").getComponent(Label).color = color(153, 153, 153, 255));
        }
        if (sys.isObjectValid(User.shared().DepositTransferData) && sys.isObjectValid(User.shared().DepositTransferData.list)) {
            let t = null;
            for (let e = 0, i = User.shared().DepositTransferData.list.length; e < i; e++) {
                2 == User.shared().DepositTransferData.list[e].type && (t = User.shared().DepositTransferData.list[e].w_type_list);
            }
            if (Array.isArray(t) && t.length >= this._tabIndex) {
                let e = t[this._tabIndex];
                this._w_type = e.w_type;
            }
        }
        4 === this._w_type ? (this.bankNode.active = true, this.upiNode.active = false, this.tipsNode.setPosition(new Vec3(0, 100, 0)), i18nMgr.shared().changeLocalizedLabelKey(this.panNameNode.getChildByName("title"), "kyc.kyc_update_not_same"), i18nMgr.shared().changeLocalizedLabelKey(this.numberEdit.placeholderLabel, "withdraw.enter_bank")) : (this.bankNode.active = false, this.upiNode.active = true, this.tipsNode.setPosition(new Vec3(0, 240, 0)), i18nMgr.shared().changeLocalizedLabelKey(this.panNameNode.getChildByName("title"), "kyc.kyc_update_not_same_upi"), i18nMgr.shared().changeLocalizedLabelKey(this.numberEdit.placeholderLabel, "withdraw.enter_upi"), i18nMgr.shared().changeLocalizedLabelKey(this.inputNode.getChildByName("item2"), "withdraw.upi_id"));
    }
    changeNameDelVisible() {
        let t = this.nameEdit.string.length > 0;
        this.nameDelBtn.active = t;
    }
    changeNumberDelVisible() {
        let t = this.numberEdit.string.length > 0;
        this.numberDelBtn.active = t;
    }
    changeIfscDelVisible() {
        let t = this.ifscEdit.string.length > 0;
        this.ifscDelBtn.active = t;
    }
    changeUpiDelVisible() {
        let t = this.upiEdit.string.length > 0;
        this.upiDelBtn.active = t;
    }
    showVerifyBtnStatus(t) {
        let e = this.verify_btn.getChildByName("anim_waiting");
        1 == t ? (this.verify_btn.getComponent(Button).interactable = true, this.verify_btn.getChildByName("di").getComponent(Sprite).spriteFrame = this.verifyBtnDiImags[1], this.verify_btn.getChildByName("di").active = true, this.verify_btn.getChildByName("wz").getComponent(LabelShadow).enabled = true, Utils.updateLabelMaterial(this.verify_btn.getChildByName("wz"), CommDefine.gradient.btn_green), this.verify_btn.getChildByName("wz").getComponent(LabelShadow).color = CommDefine.shadowcolor.green, this.verify_btn.getChildByName("wz").getComponent(Label).color = color(255, 255, 255), e.active = false) : 2 == t ? (this.verify_btn.getComponent(Button).interactable = false, this.verify_btn.getChildByName("di").getComponent(Sprite).spriteFrame = this.verifyBtnDiImags[0], this.verify_btn.getChildByName("di").active = true, this.verify_btn.getChildByName("wz").getComponent(LabelShadow).enabled = true, Utils.updateLabelMaterial(this.verify_btn.getChildByName("wz"), CommDefine.gradient.btn_gray), this.verify_btn.getChildByName("wz").getComponent(LabelShadow).color = CommDefine.shadowcolor.gray, this.verify_btn.getChildByName("wz").getComponent(Label).color = color(255, 255, 255), e.active = true) : 0 == t && (this.verify_btn.getComponent(Button).interactable = false, this.verify_btn.getChildByName("di").getComponent(Sprite).spriteFrame = this.verifyBtnDiImags[2], e.active = false, Utils.updateLabelMaterial(this.verify_btn.getChildByName("wz"), null), this.verify_btn.getChildByName("wz").getComponent(LabelShadow).enabled = false, this.verify_btn.getChildByName("wz").getComponent(Label).color = color(153, 153, 153), this.verify_btn.getChildByName("wz").getComponent(Label).setMaterial(null, 0));
    }
    showVerifyWaitTime(t) {
        if (this._identitytimeAction && TweenTool.stopAction(this._identitytimeAction), this._mIdTime = Number(t), t > 0) {
            this.showVerifyBtnStatus(2);
            let e = this.verify_btn.getChildByName("wz");
            e.getComponent(Label).string = ToolUtils.format(i18nMgr.shared().getValueByKey("kyc.pending_count"), String(t));
            this._identitytimeAction = TweenTool.myschedule(this.node, 1, (() => {
                this._mIdTime -= 1;
                this._mIdTime <= 0 ? this.stopIdentityActin() : e.getComponent(Label).string = ToolUtils.format(i18nMgr.shared().getValueByKey("kyc.pending_count"), String(this._mIdTime));
            }));
        }
    }
    stopCountDownActin() {
        this._countDownAction && (TweenTool.stopAction(this._countDownAction), this._countDownAction = null);
    }
    stopIdentityActin() {
        this._identitytimeAction && (TweenTool.stopAction(this._identitytimeAction), this._identitytimeAction = null);
    }
    revertBtnStatus(t) {
        this.showVerifyBtnStatus(t);
        1 == t && (this.stopCountDownActin(), this.stopIdentityActin(), i18nMgr.shared().changeLabelLanguage(this.verify_btn.getChildByName("wz").getComponent(Label), "kyc.resubmit", true));
    }
    requestAddWithdrawAccount() {
        let t = this.numberEdit.string;
        1 === this._w_type && (t = this.upiEdit.string);
        let e = { w_type: this._w_type, w_account: t, w_name: this.nameEdit.string, w_ifsc: this.ifscEdit.string, check: this._is_checked };
        this._record_id > 0 && (e.record_id = this._record_id);
        HttpManager.shared().doGetCommonRequest(e, HttpRequest.WithdrawAccDoSave, ((t, e, i) => {
            if (Utils.shared().hideLoading(), 200 != i) {
                ToolUtils.isObjValid(this.node) && (Utils.shared().showToast(i18nMgr.shared().getValueByKey("withdraw.tips11"), 2), this.revertBtnStatus(1), HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Withdraw, event: ReportConfig.hall_evt.withdraw_submit_fail, err_code: i }));
            }
            else {
                try {
                    let t = ToolUtils.parseJson(e);
                    if (ToolUtils.isObjValid(this.node)) {
                        if (0 === t.ret) {
                            let e = t.data.status;
                            if (sys.isObjectValid(t.data.loading_seconds) && Number(t.data.loading_seconds) > 0) {
                                if (ToolUtils.isObjValid(this.node)) {
                                    let i = false;
                                    1 == e && (this.verify_btn.getComponent(Button).interactable = false, i18nMgr.shared().changeLabelLanguage(this.verify_btn.getChildByName("wz").getComponent(Label), "kyc.verity_pending", true));
                                    2 == e ? (HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Withdraw, event: ReportConfig.hall_evt.withdraw_verify_succ }), i = true) : 3 == e && HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Withdraw, event: ReportConfig.hall_evt.withdraw_verify_fail });
                                    this.stopCountDownActin();
                                    i ? (Utils.shared().hideLoading(), Utils.shared().showToast(i18nMgr.shared().getValueByKey("kyc.submit_success"), 3.5), User.shared().doGetKycVerifyList(), ToolUtils.isObjValid(this.node) && (this._data = null, this.onBackView(), this._closeUpdateBankCardVerify = true, PushCenter.shared().pushEvent(PushEvent.UpdateBankCardVerify))) : (this.showVerifyWaitTime(Number(t.data.loading_seconds)), this._closeUpdateBankCardVerify = true, this._countDownAction = TweenTool.delayAct(this.node, (() => {
                                        Utils.shared().hideLoading();
                                        Utils.shared().showToast(i18nMgr.shared().getValueByKey("kyc.submit_success"), 3.5);
                                        User.shared().doGetKycVerifyList();
                                        ToolUtils.isObjValid(this.node) && (this._data = null, this.onBackView(), PushCenter.shared().pushEvent(PushEvent.UpdateBankCardVerify));
                                    }), Number(t.data.loading_seconds), true));
                                }
                            }
                            else {
                                ToolUtils.isObjValid(this.node) && (Utils.shared().hideLoading(), 2 != e && 1 != e || (2 == e ? this._data = t.data : this.revertBtnStatus(0), this.onBackView()));
                                PushCenter.shared().pushEvent(PushEvent.UpdateBankCardVerify);
                            }
                            this._record_id = t.data.record_id;
                        }
                        else if (Utils.shared().hideLoading(), ToolUtils.isObjValid(this.node)) {
                            this.revertBtnStatus(1);
                            t.desc && ToolUtils.isSafeString(t.desc).length > 0 && (300001 == t.ret ? Utils.shared().showKycUpate({ uiType: 1 }) : Utils.shared().showToast(t.desc, 2), this.showErrTips(t.desc));
                            let e = t.ret + ToolUtils.isSafeString(t.desc);
                            HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Withdraw, event: ReportConfig.hall_evt.withdraw_submit_fail, err_code: e });
                        }
                    }
                }
                catch (t) {
                    if (TLog.printError("trycatch requestAddWithdrawAccount,error:", t), ToolUtils.isObjValid(this.node)) {
                        Utils.shared().hideLoading();
                        this.revertBtnStatus(1);
                        let e = ToolUtils.isSafeString(t.toString());
                        HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Withdraw, event: ReportConfig.hall_evt.withdraw_submit_fail, kyc_err: e });
                    }
                }
            }
        }));
    }
    onCloseLogic() {
        this.stopIdentityActin();
        this.stopCountDownActin();
        this.onRemoveWindow();
    }
    onRemoveWindow() {
        this._closed || ToolUtils.isObjValid(this.node) && (this._closed = true, this.onBackView());
    }
    onBackView() {
        this.onCloseLogic();
        ToolUtils.isObjValid(this.node) && (this.callback && 0 == this._source_type ? this.callback(this._data) : this.callback && 1 == this._source_type && this.callback(1), this.node.destroy());
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().removeListenersByTag(this);
    }
}
