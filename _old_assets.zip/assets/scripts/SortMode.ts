// @ts-nocheck
// Recovered from index.js:541
import { _decorator, Node, sys } from "cc";
import SoundManager from "./SoundManager";
import BaseLayer from "./BaseLayer";
import User from "./User";
import PushCenter from "./PushCenter";
import PushEvent from "./PushEvent";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("SortMode")
export class SortMode extends BaseLayer {
    @property(Node)
    public info_top: Node = null;
    @property([Node])
    public selcet_checks: Node[] = [];
    public callback: any = null;
    public sort_index: number = 2;
    start() {
        super.start();
        ToolUtils.adaptSafeArea(this.node.getChildByName("root"));
        this.refreshUI();
    }
    setCallBack(e) {
        this.callback = e;
    }
    refreshUI() {
        let e = sys.localStorage.getItem("sort_mode_def");
        null == e && (e = User.shared().help_setting.sort_mode_def);
        null != e && (this.sort_index = Number(e), this.refreshAutoSettingChoice(Number(e)));
    }
    refreshAutoSettingChoice(e) {
        for (let t = 0; t < this.selcet_checks.length; t++) {
            this.selcet_checks[t].active = t == e;
        }
    }
    onChangeSelect(e, t) {
        SoundManager.shared().playFx("click");
        this.sort_index != Number(t) && (ToolUtils.saveData("sort_mode_def", String(t)), this.refreshAutoSettingChoice(Number(t)), this.sort_index = Number(t), PushCenter.shared().pushEvent(PushEvent.ChangeSortMode, this.sort_index));
    }
    onclickByClose() {
        SoundManager.shared().playFx("click");
        this.onBackView();
    }
    onBackView() {
        ToolUtils.isObjValid(this.node) && (this.callback && this.callback(), this.node.destroy());
    }
}
