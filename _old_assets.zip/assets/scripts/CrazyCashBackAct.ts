// @ts-nocheck
// Recovered from index.js:89
import { _decorator, Button, instantiate, Label, LabelShadow, Node, ProgressBar, Sprite, SpriteFrame, sys, v3 } from "cc";
import BaseLayer from "./BaseLayer";
import PushCenter from "./PushCenter";
import PushEvent from "./PushEvent";
import Utils from "./Utils";
import TweenTool from "./TweenTool";
import { TLog } from "./TLog";
import User from "./User";
import HttpManager from "./HttpManager";
import i18nMgr from "./i18nMgr";
import { HttpRequest } from "./HttpRequestName";
import GameConfig from "./GameConfig";
import CommDefine from "./CommDefine";
import HowToPlayDefined from "./HowToPlayDefined";
import { ToolUtils } from "./ToolUtils";
import PhpReportDefined from "./PhpReportDefined";
const { ccclass, property } = _decorator;
@ccclass("CrazyCashBackAct")
export class CrazyCashBackAct extends BaseLayer {
    public TAG: string = "CrazyCashBackAct";
    @property(Node)
    public root: Node = null;
    @property(Node)
    public itemRoot: Node = null;
    @property(Node)
    public ruleRoot: Node = null;
    @property(Node)
    public ruleContent: Node = null;
    @property(Node)
    public expireTime: Node = null;
    @property([SpriteFrame])
    public btnImgs: SpriteFrame[] = [];
    @property([SpriteFrame])
    public bgImgs: SpriteFrame[] = [];
    public has_reportUI: boolean = false;
    public _lastClick: number = 0;
    public _linkId: number = 0;
    public _reportScene: any = -1;
    public _initDelay: number = 0;
    public _pop_souce: number = 0;
    public _has_close: boolean = false;
    public checkKyc: number = 0;
    public isNext: boolean = false;
    public targetRoom: any = null;
    public ruleInit: boolean = false;
    onLoad() {
        PushCenter.shared().addListener(GameConfig.Recharge, (e => {
            ToolUtils.isObjValid(this.node) && User.shared().requestCrazyCashbackMain();
        }), this);
        PushCenter.shared().addListener(PushEvent.RefreshCrazyCashBack, (e => {
            ToolUtils.isObjValid(this.node) && this.refreshView();
        }), this);
    }
    start() {
        super.start();
        this._linkId = this._linkId > 0 ? this._linkId : sys.now();
        this._reportScene = this._reportScene >= 0 ? this._reportScene : ToolUtils.getIsInRoom() ? 2 : 1;
        this.startShowAnim(this.root);
        ToolUtils.showFullScreen(this.node.getChildByName("mask"));
        ToolUtils.showFullScreen(this.ruleRoot.getChildByName("mask"));
        TweenTool.delayAct(this.node, (() => {
            null !== User.shared().crazyCashbackData && this.refreshView();
            User.shared().requestCrazyCashbackMain();
        }), this._initDelay, true);
        this.requestRuleInfo(false);
    }
    refreshView() {
        let e = User.shared().crazyCashbackData;
        if (!sys.isObjectValid(e)) {
            return;
        }
        sys.isObjectValid(e.time_left) && (this.expireTime.getComponent(Label).string = e.time_left);
        sys.isObjectValid(e.t_percent) && (this.root.getChildByName("title").getComponent(Label).string = ToolUtils.format(i18nMgr.shared().getValueByKey("ccb_cashback.title"), e.t_percent));
        for (let e = 0; e < 5; e++) {
            this.itemRoot.getChildByName("moban" + e).active = false;
        }
        let t = 0;
        sys.isObjectValid(e.list) && Array.isArray(e.list) && e.list.length > 0 && (t = e.list.length);
        t > 5 && (t = 5);
        for (let i = 0; i < t; i++) {
            let t = this.itemRoot.getChildByName("moban" + i);
            this.initItemView(t, e.list[i]);
        }
        this.refreshPlayRoom();
    }
    refreshPlayRoom() {
        let e = User.shared().processFindBestRoom(0, HowToPlayDefined.RUMMY_POINTS, { tplayer: 6, finalMode: 1 });
        this.targetRoom = null;
        sys.isObjectValid(e) && sys.isObjectValid(e.bestRoom) && (this.targetRoom = e.bestRoom, this.root.getChildByName("play_tip").getComponent(Label).string = i18nMgr.shared().getValueByKey("ccb_cashback.point_6_t0") + "₹" + this.targetRoom.point);
    }
    initItemView(e, t) {
        if (sys.isObjectValid(e) && sys.isObjectValid(t)) {
            let i = 1;
            if (sys.isObjectValid(t.type) && (i = t.type), e.active = true, e.getChildByName("ProgressBar").active = 1 == i, e.getChildByName("percent").active = 1 == i, 1 == i ? (e.getChildByName("bg").getComponent(Sprite).spriteFrame = this.bgImgs[0], e.getChildByName("title").getComponent(Label).string = i18nMgr.shared().getValueByKey("ccb_cashback.tip1"), e.getChildByName("title").setPosition(v3(-192.453, 52.421)), sys.isObjectValid(t.amt) && sys.isObjectValid(t.current_amt) && (e.getChildByName("percent").getComponent(Label).string = t.current_amt + "/" + t.amt, e.getChildByName("ProgressBar").getComponent(ProgressBar).progress = t.current_amt / t.amt), e.getChildByName("btn").setPosition(v3(193.926, -28.275)), e.getChildByName("item0").setPosition(v3(-151.386, -26.777)), e.getChildByName("item1").setPosition(v3(-63.465, -26.777))) : 2 == i && (e.getChildByName("bg").getComponent(Sprite).spriteFrame = this.bgImgs[1], e.getChildByName("title").getComponent(Label).string = i18nMgr.shared().getValueByKey("ccb_cashback.tip2"), e.getChildByName("title").setPosition(v3(-192.453, 45.421)), e.getChildByName("btn").setPosition(v3(193.926, -5)), e.getChildByName("item0").setPosition(v3(-151.386, -16.777)), e.getChildByName("item1").setPosition(v3(-63.465, -16.777))), sys.isObjectValid(t.add_cash) && t.add_cash > 0 ? (e.getChildByName("item0").active = true, e.getChildByName("item0").getChildByName("num").getComponent(Label).string = String(t.add_cash)) : e.getChildByName("item0").active = false, sys.isObjectValid(t.add_bonus) && t.add_bonus > 0 ? (e.getChildByName("item1").active = true, e.getChildByName("item1").getChildByName("num").getComponent(Label).string = String(t.add_bonus), e.getChildByName("item0").active ? e.getChildByName("item1").setPosition(v3(-63.465, 10 * (i - 1) - 26.777)) : e.getChildByName("item1").setPosition(v3(-151.386, 10 * (i - 1) - 26.777))) : e.getChildByName("item1").active = false, sys.isObjectValid(t.add_tag) && t.add_tag.length > 0 ? (e.getChildByName("flag").active = true, e.getChildByName("flag").getChildByName("wz").getComponent(Label).string = t.add_tag) : e.getChildByName("flag").active = false, sys.isObjectValid(t.btn_status)) {
                let a = e.getChildByName("btn");
                a.getChildByName("lock").active = false;
                a.getComponent(Button).interactable = true;
                2 == i ? 1 == t.btn_status ? (this.updateButtonStatus(a, 1), a.getChildByName("wz").getComponent(Label).string = "₹" + t.amt) : 2 == t.btn_status ? (this.updateButtonStatus(a, 3), a.getChildByName("wz").getComponent(Label).string = i18nMgr.shared().getValueByKey("advancedPack.purchased"), a.getComponent(Button).interactable = false) : 3 == t.btn_status && (a.getChildByName("lock").active = true, this.updateButtonStatus(a, 2), a.getChildByName("wz").getComponent(Label).string = "₹" + t.amt) : 1 == i && (1 == t.btn_status ? (this.updateButtonStatus(a, 1), a.getChildByName("wz").getComponent(Label).string = i18nMgr.shared().getValueByKey("contact_us.go")) : 2 == t.btn_status ? (this.updateButtonStatus(a, 3), a.getChildByName("wz").getComponent(Label).string = i18nMgr.shared().getValueByKey("weekmonth.collected"), a.getComponent(Button).interactable = false) : 3 == t.btn_status ? (a.getChildByName("lock").active = true, this.updateButtonStatus(a, 2), a.getChildByName("wz").getComponent(Label).string = i18nMgr.shared().getValueByKey("advancedPack.free")) : 4 == t.btn_status && (this.updateButtonStatus(a, 1), a.getChildByName("wz").getComponent(Label).string = i18nMgr.shared().getValueByKey("advancedPack.collect")));
            }
        }
    }
    updateButtonStatus(e, t) {
        sys.isObjectValid(e) && (1 == t ? (e.getChildByName("ico").getComponent(Sprite).spriteFrame = this.btnImgs[0], Utils.updateLabelMaterial(e.getChildByName("wz"), CommDefine.gradient.btn_green), e.getChildByName("wz").getComponent(LabelShadow).color = CommDefine.shadowcolor.green) : 2 == t ? (e.getChildByName("ico").getComponent(Sprite).spriteFrame = this.btnImgs[1], Utils.updateLabelMaterial(e.getChildByName("wz"), CommDefine.gradient.btn_blue), e.getChildByName("wz").getComponent(LabelShadow).color = CommDefine.shadowcolor.blue) : 3 == t && (e.getChildByName("ico").getComponent(Sprite).spriteFrame = this.btnImgs[2], Utils.updateLabelMaterial(e.getChildByName("wz"), CommDefine.gradient.btn_gray), e.getChildByName("wz").getComponent(LabelShadow).color = CommDefine.shadowcolor.gray));
    }
    initParaData(e) {
        sys.isObjectValid(e) && sys.isObjectValid(e.isNext) && (this.isNext = e.isNext);
        sys.isObjectValid(e) && sys.isObjectValid(e.reportScene) && (this._reportScene = e.reportScene);
        sys.isObjectValid(e) && sys.isObjectValid(e.link_id) && e.link_id > 0 && (this._linkId = e.link_id);
        sys.isObjectValid(e) && sys.isObjectValid(e.pop_souce) && (this._pop_souce = e.pop_souce);
        sys.isObjectValid(e.checkKyc) && (this.checkKyc = e.checkKyc);
    }
    onClickItemEvent(e, t) {
        if (ToolUtils.isObjValid(this.node)) {
            if (sys.now() - this._lastClick < 500) {
                return;
            }
            this._lastClick = sys.now();
            let e = User.shared().crazyCashbackData.list[Number(t)];
            if (sys.isObjectValid(e)) {
                let t = 1;
                if (sys.isObjectValid(e.type) && (t = e.type), 2 == t) {
                    if (1 == e.btn_status) {
                        let t = { act_id: PushEvent.JUMP_TO_CrazyCashBack, goodsId: e.good_id, task_id: e.task_id, link_id: this._linkId };
                        User.shared().startPay(t);
                    }
                    else {
                        3 == e.btn_status && Utils.shared().showToast(i18nMgr.shared().getValueByKey("ccb_cashback.lock_tip"), 2);
                    }
                }
                else {
                    1 == t && (1 == e.btn_status ? this.dealPlayGameLogic() : 4 == e.btn_status ? this.dealGetRewardLogic(e.task_id) : 3 == e.btn_status && Utils.shared().showToast(i18nMgr.shared().getValueByKey("ccb_cashback.lock_tip"), 2));
                }
            }
        }
    }
    onClickBtnEvent(e, t) {
        if (ToolUtils.isObjValid(this.node)) {
            if (sys.now() - this._lastClick < 500) {
                return;
            }
            if (this._lastClick = sys.now(), "close" === t) {
                if (this._has_close) {
                    return;
                }
                this._has_close = true;
                this.onBackView();
            }
            else {
                "help" === t ? this.dealRuleLogic() : "rule_close" === t ? this.ruleRoot.active = false : "play" === t && this.dealPlayGameLogic();
            }
        }
    }
    dealRuleLogic() {
        sys.isObjectValid(User.shared().crazyCashbackRule) ? (this.ruleInit || this.refreshRuleContent(User.shared().crazyCashbackRule), this.ruleRoot.active = true, this.startShowAnim(this.ruleRoot)) : this.requestRuleInfo(true);
    }
    requestRuleInfo(e) {
        e && Utils.shared().showLoading(10, true, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
        }));
        HttpManager.shared().doGetCommonRequest(null, HttpRequest.CrazyCashBackRule, ((t, i, a) => {
            if (ToolUtils.isObjValid(this.node)) {
                if (Utils.shared().hideLoading(), 200 != a) {
                    0 == sys.getNetworkType() ? Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text91"), 3, 0, ToolUtils.getIsNormalDirection()) : Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
                }
                else {
                    try {
                        let t = ToolUtils.parseJson(i);
                        0 == t.ret && (User.shared().crazyCashbackRule = t.data.rule, e && (this.ruleInit || this.refreshRuleContent(User.shared().crazyCashbackRule), this.ruleRoot.active = true, this.startShowAnim(this.ruleRoot)));
                    }
                    catch (e) {
                        TLog.printError(this.TAG, "requestRuleInfo  error:", e);
                    }
                }
            }
        }));
    }
    refreshRuleContent(e) {
        if (this.ruleInit = true, sys.isObjectValid(e.rule_one) && e.rule_one.length > 0 ? (this.ruleContent.getChildByName("tip1").active = true, this.ruleContent.getChildByName("tip1").getComponent(Label).string = e.rule_one) : this.ruleContent.getChildByName("tip1").active = false, sys.isObjectValid(e.rule_two) && Array.isArray(e.rule_two) && e.rule_two.length > 0) {
            this.ruleContent.getChildByName("biaoge").active = true;
            for (let t = 0; t < e.rule_two.length; t++) {
                let i = null;
                0 == t ? i = this.ruleContent.getChildByName("biaoge").getChildByName("moban0") : (i = instantiate(this.ruleContent.getChildByName("biaoge").getChildByName("moban0")), this.ruleContent.getChildByName("biaoge").addChild(i));
                sys.isObjectValid(i) && (sys.isObjectValid(e.rule_two[t].row_one) && (i.getChildByName("wz0").getComponent(Label).string = e.rule_two[t].row_one), sys.isObjectValid(e.rule_two[t].row_two) && (i.getChildByName("wz1").getComponent(Label).string = e.rule_two[t].row_two), sys.isObjectValid(e.rule_two[t].row_three) && (i.getChildByName("wz2").getComponent(Label).string = e.rule_two[t].row_three));
            }
        }
        else {
            this.ruleContent.getChildByName("biaoge").active = false;
        }
        sys.isObjectValid(e.rule_three && e.rule_three.length > 0) ? (this.ruleContent.getChildByName("tip2").active = true, this.ruleContent.getChildByName("tip2").getComponent(Label).string = e.rule_three) : this.ruleContent.getChildByName("tip2").active = false;
    }
    dealPlayGameLogic() {
        if (sys.isObjectValid(this.targetRoom)) {
            if (ToolUtils.isObjValid(this.node) && this.node.destroy(), User.shared().data.money < this.targetRoom.entry) {
                if (!User.shared().checkCanRecharge()) {
                    return void (ToolUtils.isObjValid(this.node) && this.node.destroy());
                }
                Utils.shared().showQuickRecharge(this.targetRoom.vid, null, true, "", 0, this.targetRoom.entry, true, 0, this.checkKyc);
                User.shared().updatePayScene(PhpReportDefined.pay_scene.hall_less_money, Number(this.targetRoom.vid));
            }
            else {
                ToolUtils.curRoomId = Number(this.targetRoom.vid);
                Utils.shared().showCommEnterRoom({ vid: Number(this.targetRoom.vid), isNewTable: 1 });
            }
        }
    }
    dealGetRewardLogic(e) {
        Utils.shared().showLoading(10, true, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
        }));
        HttpManager.shared().doGetCommonRequest({ task_id: e }, HttpRequest.CrazyCashBackGetReward, ((e, t, i) => {
            if (ToolUtils.isObjValid(this.node)) {
                if (Utils.shared().hideLoading(), 200 != i) {
                    0 == sys.getNetworkType() ? Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text91"), 3, 0, ToolUtils.getIsNormalDirection()) : Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
                }
                else {
                    try {
                        let e = ToolUtils.parseJson(t);
                        0 == e.ret && (User.shared().requestCrazyCashbackMain(), this.showRewards(e.data.reward_list, i18nMgr.shared().getValueByKey("reward_tips.fans_gift")));
                    }
                    catch (e) {
                        TLog.printError(this.TAG, "_dealGetRewardLogic  error:", e);
                    }
                }
            }
        }));
    }
    showRewards(e, t = "") {
        let i = e;
        if (i && i.length > 0) {
            let e = null;
            sys.isObjectValid(t) && ToolUtils.isSafeString(t).length > 0 && (e = ToolUtils.isSafeString(t));
            User.shared().showChargeReward(i, null, e);
        }
    }
    onBackView() {
        let e = { alert_node: this.node, rootNode: this.root, isNext: this.isNext, pop_type: PushEvent.JUMP_TO_CrazyCashBack, pop_souce: this._pop_souce };
        Utils.shared().closeActivityView(e);
    }
    onDestroy() {
        super.onDestroy();
        ToolUtils.judgeIfInHall() && PushCenter.shared().pushEvent(PushEvent.HallGet);
        TweenTool.stopNodeAction(this.node);
        this.unscheduleAllCallbacks();
        PushCenter.shared().removeListenersByTag(this);
    }
}
