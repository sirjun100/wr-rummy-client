// @ts-nocheck
// Recovered from index.js:195
import { _decorator, native, sys } from "cc";
import GameConfig from "./GameConfig";
import NetConfig from "./NetConfig";
import i18nMgr from "./i18nMgr";
import MD5 from "./MD5";
import NewFormData from "./NewFormData";
import PushCenter from "./PushCenter";
import { TLog } from "./TLog";
import { ToolUtils } from "./ToolUtils";
import { TransferPlatform } from "./TransferPlatform";
import BundleNameDefined from "./BundleNameDefined";
import { HttpRequest } from "./HttpRequestName";
import PushEvent from "./PushEvent";
import ReportConfig from "./ReportConfig";
import URLConfig from "./URLConfig";
import HttpCrypto from "./HttpCrypto";
import { HallGameType } from "./CommDefine";
const { ccclass } = _decorator;
@ccclass("HttpManager")
export default class HttpManager {
    static _instance = null;
    public hconfig: any = {};
    public sdk_url: any = URLConfig.SDK_URL;
    public new_sdk_url: string = "";
    static shared() : HttpManager {
        return null == this._instance && (this._instance = new HttpManager, this._instance.init()), this._instance;
    }
    init() {
        this.hconfig = {};
        this.hconfig.skey = "0";
        this.hconfig.httpUrl = "";
        this.hconfig.uid = 0;
        this.hconfig.httpSecretKey = "751a276cae97ac29e91819106ebb62f0";
        this.hconfig.ver = GameConfig.NEW_APP_VERSION;
    }
    setUrl(e) {
        this.hconfig.httpUrl = e;
    }
    getUrl() {
        return this.hconfig.httpUrl;
    }
    setSdkUrl(e) {
        this.sdk_url = e;
    }
    setNewSdkUrl(e) {
        this.new_sdk_url = e;
    }
    setUidAndKey(e, t) {
        this.hconfig.uid = e;
        this.hconfig.skey = t;
    }
    getSkey() {
        return ToolUtils.skey;
    }
    doSendGetRequest(t, i, a, n = 0, o = 10000) {
        let h = new XMLHttpRequest;
        h.timeout = o;
        h.onreadystatechange = function () {
            if (4 == h.readyState) {
                var i = HttpManager.shared().getDecryptResponse(h.responseText);
                if (h.status >= 200 && h.status <= 299) {
                    if (null != a) {
                        try {
                            if ("ok" != ToolUtils.isSafeString(i)) {
                                let a = ToolUtils.parseJson(i), s = a.t1 || 0, r = a.t2 || 0, n = a.t3 || 0, o = sys.now(), h = "t1:" + s + ",t2:" + r + ",t3:" + n + ",t4:" + o, g = a.action || "";
                                if (HttpManager.shared().doRequestSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Hall, event: "revSuccess", ret: a.ret || 0, reqId: t, action: g, tTime: h, timeDif: o - s, desc: a.desc || "" }), sys.isObjectValid(a.t1) && (ToolUtils.netDelay = o - s), 906 === a.ret) {
                                    return a.desc && a.desc.length > 0 && (ToolUtils.offlineMsg = a.desc), void (ToolUtils.judgeIfInScene(BundleNameDefined.rummy_scence) ? PushCenter.shared().pushEvent(PushEvent.BackToLogin) : PushCenter.shared().pushEvent(PushEvent.ShowLoginScene));
                                }
                            }
                            try {
                                a(t, i, 200);
                                a = null;
                            }
                            catch (e) {
                                TLog.printError("request ok:", e.toString());
                            }
                        }
                        catch (i) {
                            TLog.printError("request error:", i.toString());
                            HttpManager.shared().doRequestSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Hall, event: "revSucCatchErr", reqId: t, error: i.toString() });
                            null != a && a(t, "", -1);
                        }
                    }
                }
                else if (HttpManager.shared().doRequestSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Hall, event: "requestErr", reqId: t, httpStatus: h.status }), null != a) {
                    try {
                        a(t, "", -1);
                    }
                    catch (e) {
                    }
                }
            }
        };
        h.ontimeout = function () {
            t != NetConfig.GainNewHost && t != NetConfig.RegisterRequest && t != NetConfig.SendLogin && t != NetConfig.LuaPhoneLogin && t != NetConfig.CheckUpdate || ToolUtils.judgeIfInScene(BundleNameDefined.hall_scene) && HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Disconn, event: ReportConfig.hall_evt.requestTimeOut });
            HttpManager.shared().doRequestSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Disconn, event: ReportConfig.hall_evt.requestTimeOut, reqId: t });
            null != a && a(t, "", 0);
        };
        h.onerror = function () {
            HttpManager.shared().doRequestSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Disconn, event: "reqError", reqId: t });
            null != a && a(t, "", -1);
        };
        h.onload = function () {
        };
        h.onloadend = function () {
        };
        h.onprogress = function () {
        };
        let u = i;
        1 == GameConfig.HTTP_CRYPTO_SWITCH && sys.isNative && (u = this.getSendCryptoUrl(i));
        h.open("GET", u, true);
        sys.isNative && h.setRequestHeader("Accept-Encoding", "gzip,deflate");
        h.send();
    }
    doSendPostRequest(t, i, a, s) {
        let r = new XMLHttpRequest;
        r.onreadystatechange = function () {
            if (4 == r.readyState && r.status >= 200 && r.status < 400) {
                var i = r.responseText;
                if (null != s) {
                    try {
                        if ("ok" != ToolUtils.isSafeString(i)) {
                            let a = ToolUtils.parseJson(i), s = a.t1 || 0, r = a.t2 || 0, n = a.t3 || 0, o = sys.now(), h = "t1:" + s + ",t2:" + r + ",t3:" + n + ",t4:" + o, g = a.action || "";
                            if (HttpManager.shared().doRequestSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Hall, event: "postRevSuccess", ret: a.ret || 0, reqId: t, action: g, tTime: h, timeDif: o - s, desc: a.desc || "" }), sys.isObjectValid(a.t1) && (ToolUtils.netDelay = o - s), 906 === a.ret) {
                                return a.desc && a.desc.length > 0 && (ToolUtils.offlineMsg = a.desc), void (ToolUtils.judgeIfInScene(BundleNameDefined.rummy_scence) ? PushCenter.shared().pushEvent(PushEvent.BackToLogin) : PushCenter.shared().pushEvent(PushEvent.ShowLoginScene));
                            }
                        }
                        s(t, i, 200);
                    }
                    catch (i) {
                        TLog.printError("request error:", i.toString());
                        HttpManager.shared().doRequestSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Hall, event: "postRevSucCatchErr", reqId: t, error: i.toString() });
                        null != s && s(t, "", -1);
                    }
                }
            }
            else {
                HttpManager.shared().doRequestSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Hall, event: "postRequesErr", reqId: t, readyState: r.readyState, httpStatus: r.status });
            }
        };
        r.ontimeout = function () {
            HttpManager.shared().doRequestSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Disconn, event: "postRequestTimeOut", reqId: t });
            null != s && s(t, "", 0);
        };
        r.onerror = function () {
            HttpManager.shared().doRequestSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Disconn, event: "postRequestErr", reqId: t });
            null != s && s(t, "", -1);
        };
        r.onload = function () {
        };
        r.onloadend = function () {
        };
        r.onprogress = function () {
        };
        r.open("POST", i, true);
        sys.isNative && r.setRequestHeader("Content-Type", "text/plain;charset=utf-8");
        r.send(a);
    }
    paramToSortStr(e) {
        let t = ToolUtils.parseJson(e), i = "";
        return Object.keys(t).sort().forEach((function (e) {
            i = i + e + "=" + t[e];
        })), i;
    }
    urlEncode(e) {
        return e = encodeURIComponent(e);
    }
    createNewSign(e, t = String(this.getSkey())) {
        let i = e + t + this.hconfig.httpSecretKey;
        return MD5.Instance.hex_md5(i);
    }
    createNewSignByHost(e, t) {
        let i = e + t + this.hconfig.httpSecretKey;
        return MD5.Instance.hex_md5(i);
    }
    getSendCryptoUrl(e) {
        let t = e;
        try {
            let i = "api.php?", d = e.indexOf(i);
            if (-1 != d) {
                t = e.substring(0, d) + "i.php?";
                let a = HttpCrypto.shared().encrypt(e.substring(d + i.length));
                t += this.urlEncode(a);
            }
        }
        catch (t) {
            return TLog.printError("getSendCryptoUrl error:", t), e;
        }
        return t;
    }
    getDecryptResponse(e) {
        let t = e;
        try {
            let i = "aes#", d = e.indexOf(i);
            0 == d && (t = HttpCrypto.shared().decrypt(e.substring(d + i.length)));
        }
        catch (t) {
            return TLog.printError("getDecryptResponse error:", t), e;
        }
        return t;
    }
    doCheckUpdate(e = null, t = 10000) {
        let i = sys.now(), a = { channel_id: TransferPlatform.shared().getChannelId(), ts: i, rver: GameConfig.NEW_APP_VERSION, cver: TransferPlatform.shared().getAppVersionCode(), phonenos: TransferPlatform.shared().getPhoneOS(), phoneimsi: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), os_model: TransferPlatform.shared().getDeviceVersion(), os: TransferPlatform.shared().getOS(), pushid: TransferPlatform.shared().getFirebasePushId(), firebase_id: TransferPlatform.shared().getAppInstanceId() };
        1 === GameConfig.SERVER_DEBUG && (a.server_type = GameConfig.server_type);
        this.httpRequestBeforeLogin(NetConfig.CheckUpdate, "CheckUpdateAddr", a, e, "", i, t);
    }
    doGainNewHost(e = null, t = 10000) {
        let i = sys.now();
        if (ToolUtils.versionCompareHandle(GameConfig.REMOTE_CRASH_VER, GameConfig.REMOTE_RES_VER) < 0) {
            let e = sys.localStorage.getItem("subGameVer" + HallGameType.LOBBY_GAME_TYPE_CRASH);
            null != e && null !== e && "" != e || (GameConfig.REMOTE_CRASH_VER = GameConfig.REMOTE_RES_VER);
        }
        if (ToolUtils.versionCompareHandle(GameConfig.REMOTE_FRUIT_VER, GameConfig.REMOTE_RES_VER) < 0) {
            let e = sys.localStorage.getItem("subGameVer" + HallGameType.LOBBY_GAME_TYPE_SHUIGUOJI);
            null != e && null !== e && "" != e || (GameConfig.REMOTE_FRUIT_VER = GameConfig.REMOTE_RES_VER);
        }
        if (ToolUtils.versionCompareHandle(GameConfig.REMOTE_SIXDICE_VER, GameConfig.REMOTE_RES_VER) < 0) {
            let e = sys.localStorage.getItem("subGameVer" + HallGameType.LOBBY_GAME_TYPE_SIXDICE);
            null != e && null !== e && "" != e || (GameConfig.REMOTE_SIXDICE_VER = GameConfig.REMOTE_RES_VER);
        }
        if (ToolUtils.versionCompareHandle(GameConfig.REMOTE_WINGO_VER, GameConfig.REMOTE_RES_VER) < 0) {
            let e = sys.localStorage.getItem("subGameVer" + HallGameType.LOBBY_GAME_TYPE_LuckBall);
            null != e && null !== e && "" != e || (GameConfig.REMOTE_WINGO_VER = GameConfig.REMOTE_RES_VER);
        }
        let a = { channel_id: TransferPlatform.shared().getChannelId(), ts: i, uid: ToolUtils.uid, rver: GameConfig.NEW_APP_VERSION, phonenos: TransferPlatform.shared().getPhoneOS(), gaid: TransferPlatform.shared().getGaid(), os_model: TransferPlatform.shared().getDeviceVersion(), os: TransferPlatform.shared().getOS(), desk_ver: GameConfig.REMOTE_RES_VER, audio_ver: GameConfig.REMOTE_RES_VER, guess_ver: GameConfig.REMOTE_RES_VER, image_ver: GameConfig.REMOTE_RES_VER, tamil_ver: GameConfig.REMOTE_RES_VER, urdu_ver: GameConfig.REMOTE_RES_VER, yes11_ver: GameConfig.REMOTE_YES11_VER, crash_ver: GameConfig.REMOTE_CRASH_VER, fruit_ver: GameConfig.REMOTE_FRUIT_VER, sixdice_ver: GameConfig.REMOTE_SIXDICE_VER, wingo_ver: GameConfig.REMOTE_WINGO_VER };
        1 === GameConfig.SERVER_DEBUG && (a.server_type = GameConfig.server_type);
        this.httpRequestBeforeLogin(NetConfig.GainNewHost, "StartApp.gainHost", a, e, "", i, t);
    }
    doGetAppStartInit(e = null, t = 10000) {
        let i = sys.now();
        if (ToolUtils.versionCompareHandle(GameConfig.REMOTE_CRASH_VER, GameConfig.REMOTE_RES_VER) < 0) {
            let e = sys.localStorage.getItem("subGameVer" + HallGameType.LOBBY_GAME_TYPE_CRASH);
            null != e && null !== e && "" != e || (GameConfig.REMOTE_CRASH_VER = GameConfig.REMOTE_RES_VER);
        }
        if (ToolUtils.versionCompareHandle(GameConfig.REMOTE_FRUIT_VER, GameConfig.REMOTE_RES_VER) < 0) {
            let e = sys.localStorage.getItem("subGameVer" + HallGameType.LOBBY_GAME_TYPE_SHUIGUOJI);
            null != e && null !== e && "" != e || (GameConfig.REMOTE_FRUIT_VER = GameConfig.REMOTE_RES_VER);
        }
        if (ToolUtils.versionCompareHandle(GameConfig.REMOTE_SIXDICE_VER, GameConfig.REMOTE_RES_VER) < 0) {
            let e = sys.localStorage.getItem("subGameVer" + HallGameType.LOBBY_GAME_TYPE_SIXDICE);
            null != e && null !== e && "" != e || (GameConfig.REMOTE_SIXDICE_VER = GameConfig.REMOTE_RES_VER);
        }
        if (ToolUtils.versionCompareHandle(GameConfig.REMOTE_WINGO_VER, GameConfig.REMOTE_RES_VER) < 0) {
            let e = sys.localStorage.getItem("subGameVer" + HallGameType.LOBBY_GAME_TYPE_LuckBall);
            null != e && null !== e && "" != e || (GameConfig.REMOTE_WINGO_VER = GameConfig.REMOTE_RES_VER);
        }
        let a = { channel_id: TransferPlatform.shared().getChannelId(), ts: i, uid: ToolUtils.uid, rver: GameConfig.NEW_APP_VERSION, cver: TransferPlatform.shared().getAppVersionCode(), phoneimsi: TransferPlatform.shared().getPhoneIMEI(), phonenos: TransferPlatform.shared().getPhoneOS(), gaid: TransferPlatform.shared().getGaid(), os_model: TransferPlatform.shared().getDeviceVersion(), os: TransferPlatform.shared().getOS(), pushid: TransferPlatform.shared().getFirebasePushId(), firebase_id: TransferPlatform.shared().getAppInstanceId(), desk_ver: GameConfig.REMOTE_RES_VER, audio_ver: GameConfig.REMOTE_RES_VER, guess_ver: GameConfig.REMOTE_RES_VER, image_ver: GameConfig.REMOTE_RES_VER, tamil_ver: GameConfig.REMOTE_RES_VER, urdu_ver: GameConfig.REMOTE_RES_VER, yes11_ver: GameConfig.REMOTE_YES11_VER, crash_ver: GameConfig.REMOTE_CRASH_VER, fruit_ver: GameConfig.REMOTE_FRUIT_VER, sixdice_ver: GameConfig.REMOTE_SIXDICE_VER, wingo_ver: GameConfig.REMOTE_WINGO_VER };
        sys.isObjectValid(ToolUtils.uid) && ToolUtils.uid > 0 && (a.uid = ToolUtils.uid);
        let n = sys.localStorage.getItem("rummy_install" + TransferPlatform.shared().getChannelId());
        sys.isObjectValid(n) && 1 == Number(n) || (a.install = 1);
        this.httpRequestBeforeLogin(NetConfig.GainNewHost, "StartApp.doInit", a, e, "", i, t);
    }
    doReportPushData(e, t, i = null) {
        let a = ToolUtils.uid;
        if (0 == a) {
            let e = sys.localStorage.getItem("lastLoginUid");
            null != e && (a = Number(e));
        }
        let r = { push_data: ToolUtils.toJsonString({ jump_type: e || "", jump_ext: t || "", rver: GameConfig.NEW_APP_VERSION, uid: a, channel_id: TransferPlatform.shared().getChannelId(), phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), push_id: TransferPlatform.shared().getFirebasePushId(), firebase_id: TransferPlatform.shared().getAppInstanceId(), cver: TransferPlatform.shared().getAppVersionCode() }), ts: ToolUtils.getOsTime() };
        r.mobile_data = ToolUtils.toJsonString({ emulator: TransferPlatform.shared().getIsRunningOnEmulator(), lightSensor: TransferPlatform.shared().getHasLightSensor(), phoneCpu: TransferPlatform.shared().getIsPhoneCpu(), flash: TransferPlatform.shared().getIsSupportCameraLedFlash(), blueTooth: TransferPlatform.shared().getHasBluetooth(), gps: TransferPlatform.shared().getHasGPS(), screen: GameConfig.REAL_SCREEN_WIDTH + "*" + GameConfig.REAL_SCREEN_HEIGHT, cpu: TransferPlatform.shared().getDeviceCpuName(), cpu_hz: TransferPlatform.shared().getDeviceCpuHz(), mem: TransferPlatform.shared().getDeviceMemory(), level: TransferPlatform.shared().getDeviceLevel(), avi_men: TransferPlatform.shared().getAvailueMemory(), sys_ver: TransferPlatform.shared().getMobileRelease(), phe_type: TransferPlatform.shared().getPhoneBrand() + " " + TransferPlatform.shared().getDeviceType(), platform: sys.os });
        this.httpRequestBeforeLogin("ReportLog.pushLog", "ReportLog.pushLog", r, i);
    }
    doReportClick(e, t = null) {
        if (!(e && e.module && e.scene && e.event)) {
            return void TLog.printError("doReportClick error, module, scene, event is empty:", e);
        }
        let i = ToolUtils.getOsTime(), a = { module: e.module, scene: e.scene, event: e.event, ts: i, uid: ToolUtils.uid, rver: GameConfig.NEW_APP_VERSION, channel_id: TransferPlatform.shared().getChannelId(), cver: TransferPlatform.shared().getAppVersionCode(), phoneimsi: TransferPlatform.shared().getPhoneIMEI(), phonenos: TransferPlatform.shared().getPhoneOS(), gaid: TransferPlatform.shared().getGaid(), os_model: TransferPlatform.shared().getDeviceVersion(), os: TransferPlatform.shared().getOS(), pushid: TransferPlatform.shared().getFirebasePushId(), firebase_id: TransferPlatform.shared().getAppInstanceId() };
        e.entry_fee && sys.isObjectValid(e.entry_fee) && (a.entry_fee = e.entry_fee);
        e.vid && sys.isObjectValid(e.vid) && (a.vid = e.vid);
        e.force_up_venue && sys.isObjectValid(e.force_up_venue) && (a.force_up_venue = ToolUtils.toJsonString(e.force_up_venue));
        e.tf_venue && sys.isObjectValid(e.tf_venue) && (a.tf_venue = ToolUtils.toJsonString(e.tf_venue));
        this.httpRequest("ReportLog.click", "ReportLog.click", a, t);
    }
    doGetMobileCode(e, t, i, a, n = 1) {
        let o = sys.now(), h = { tel_no: e, type: t, gtype: i, channel_id: TransferPlatform.shared().getChannelId(), phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: o, rver: GameConfig.NEW_APP_VERSION, send_cnt: n };
        this.httpRequest(NetConfig.GetCodeRequest, "SignupCode", h, a);
    }
    doGetLoginEmailCode(e, t, i) {
        let a = sys.now(), r = { email: e, tel_no: t, channel_id: TransferPlatform.shared().getChannelId(), phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: a, rver: GameConfig.NEW_APP_VERSION };
        this.httpRequest("EmailSendOtp.send", "EmailSendOtp.send", r, i);
    }
    doGetEmailCode(e, t, i) {
        let a = sys.now(), r = { email: e, type: t, channel_id: TransferPlatform.shared().getChannelId(), phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: a, rver: GameConfig.NEW_APP_VERSION };
        this.httpRequest("EmailOtp", "EmailOtp", r, i);
    }
    doVerifyMobileCode(e, t, i) {
        let a = sys.now(), r = { old_phone: e, code: t, channel_id: TransferPlatform.shared().getChannelId(), phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: a, rver: GameConfig.NEW_APP_VERSION };
        this.httpRequest("UpdatePhone.checkMobileCode", "UpdatePhone.checkMobileCode", r, i);
    }
    doVerifyEmailCode(e, t, i) {
        let a = sys.now(), r = { email: e, code: t, channel_id: TransferPlatform.shared().getChannelId(), phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: a, rver: GameConfig.NEW_APP_VERSION };
        this.httpRequest("UpdatePhone.checkEmailCode", "UpdatePhone.checkEmailCode", r, i);
    }
    doPlayerLogin(e, t, i, a, n, o) {
        ToolUtils.report_time_param.req_Login = sys.now();
        let h = sys.now(), l = { tel_no: e, account: t, password: i, logintype: a, channel_id: TransferPlatform.shared().getChannelId(), phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: h, rver: GameConfig.NEW_APP_VERSION, cver: TransferPlatform.shared().getAppVersionCode(), adjust_id: TransferPlatform.shared().getAdjust_Adid(), appsflyer_id: TransferPlatform.shared().getAppsflyer_Adid(), pushid: TransferPlatform.shared().getFirebasePushId(), firebase_id: TransferPlatform.shared().getAppInstanceId(), latitude: TransferPlatform.shared().getLatitude(), longitude: TransferPlatform.shared().getLongitude(), bdid: TransferPlatform.shared().getBePowerId(), cdkey: TransferPlatform.shared().getDeepLinkCdKey(), utm_referral: TransferPlatform.shared().getInstallRefer(false), req_key: o }, g = TransferPlatform.shared().getAppInstallData();
        g.hasInstall && g.channelId.length > 0 && (l.invite_code = g.channelId);
        l.os_device = TransferPlatform.shared().getOsDeviceInfo();
        l.is_new_kyc = TransferPlatform.shared().getIsNewKyc() ? 1 : 0;
        l.mobile_data = ToolUtils.toJsonString({ emulator: TransferPlatform.shared().getIsRunningOnEmulator(), lightSensor: TransferPlatform.shared().getHasLightSensor(), phoneCpu: TransferPlatform.shared().getIsPhoneCpu(), flash: TransferPlatform.shared().getIsSupportCameraLedFlash(), blueTooth: TransferPlatform.shared().getHasBluetooth(), gps: TransferPlatform.shared().getHasGPS(), screen: GameConfig.REAL_SCREEN_WIDTH + "*" + GameConfig.REAL_SCREEN_HEIGHT, cpu: TransferPlatform.shared().getDeviceCpuName(), cpu_hz: TransferPlatform.shared().getDeviceCpuHz(), mem: TransferPlatform.shared().getDeviceMemory(), level: TransferPlatform.shared().getDeviceLevel(), avi_men: TransferPlatform.shared().getAvailueMemory(), sys_ver: TransferPlatform.shared().getMobileRelease(), phe_type: TransferPlatform.shared().getPhoneBrand() + " " + TransferPlatform.shared().getDeviceType(), platform: sys.os });
        this.httpRequest(NetConfig.LuaPhoneLogin, "Player.LoginProxy.do_login", l, n, "", 0, 8000);
    }
    doPlayerRePassword(e, t, i, a, n) {
        let o = sys.now(), h = { tel_no: e, code: t, type: i, serialno: a, channel_id: TransferPlatform.shared().getChannelId(), phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: o, rver: GameConfig.NEW_APP_VERSION, adjust_id: TransferPlatform.shared().getAdjust_Adid(), appsflyer_id: TransferPlatform.shared().getAppsflyer_Adid(), pushid: TransferPlatform.shared().getFirebasePushId(), firebase_id: TransferPlatform.shared().getAppInstanceId() };
        this.httpRequest(NetConfig.LuaPhoneLogin, "Player.LoginProxy.retrieve_valid", h, n);
    }
    doPlayersetPassword(e, t, i, a, n) {
        let o = sys.now(), h = { code: e, tel_no: t, pwd: i, serialno: a, channel_id: TransferPlatform.shared().getChannelId(), phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: o, rver: GameConfig.NEW_APP_VERSION, cver: TransferPlatform.shared().getAppVersionCode(), adjust_id: TransferPlatform.shared().getAdjust_Adid(), appsflyer_id: TransferPlatform.shared().getAppsflyer_Adid(), pushid: TransferPlatform.shared().getFirebasePushId(), firebase_id: TransferPlatform.shared().getAppInstanceId() };
        this.httpRequest(NetConfig.LuaPhoneLogin, "Player.LoginProxy.set_pwd", h, n);
    }
    doPhoneCodeLogin(e, t, i, a, n, o) {
        ToolUtils.report_time_param.req_Login = sys.now();
        let h = sys.now(), l = { tel_no: e, code: t, pwdtoken: i, logintype: a, channel_id: TransferPlatform.shared().getChannelId(), phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: h, rver: GameConfig.NEW_APP_VERSION, cver: TransferPlatform.shared().getAppVersionCode(), adjust_id: TransferPlatform.shared().getAdjust_Adid(), appsflyer_id: TransferPlatform.shared().getAppsflyer_Adid(), pushid: TransferPlatform.shared().getFirebasePushId(), firebase_id: TransferPlatform.shared().getAppInstanceId(), latitude: TransferPlatform.shared().getLatitude(), longitude: TransferPlatform.shared().getLongitude(), bdid: TransferPlatform.shared().getBePowerId(), cdkey: TransferPlatform.shared().getDeepLinkCdKey(), utm_referral: TransferPlatform.shared().getInstallRefer(false), req_key: o }, g = TransferPlatform.shared().getAppInstallData();
        g.hasInstall && g.channelId.length > 0 && (l.invite_code = g.channelId);
        l.os_device = TransferPlatform.shared().getOsDeviceInfo();
        l.is_new_kyc = TransferPlatform.shared().getIsNewKyc() ? 1 : 0;
        l.mobile_data = ToolUtils.toJsonString({ emulator: TransferPlatform.shared().getIsRunningOnEmulator(), lightSensor: TransferPlatform.shared().getHasLightSensor(), phoneCpu: TransferPlatform.shared().getIsPhoneCpu(), flash: TransferPlatform.shared().getIsSupportCameraLedFlash(), blueTooth: TransferPlatform.shared().getHasBluetooth(), gps: TransferPlatform.shared().getHasGPS(), screen: GameConfig.REAL_SCREEN_WIDTH + "*" + GameConfig.REAL_SCREEN_HEIGHT, cpu: TransferPlatform.shared().getDeviceCpuName(), cpu_hz: TransferPlatform.shared().getDeviceCpuHz(), mem: TransferPlatform.shared().getDeviceMemory(), level: TransferPlatform.shared().getDeviceLevel(), avi_men: TransferPlatform.shared().getAvailueMemory(), sys_ver: TransferPlatform.shared().getMobileRelease(), phe_type: TransferPlatform.shared().getPhoneBrand() + " " + TransferPlatform.shared().getDeviceType(), platform: sys.os });
        this.httpRequest(NetConfig.SendLogin, "Player.LoginProxy.do_login", l, n);
    }
    doEmailCodeLogin(e, t, i, a, n, o, h) {
        ToolUtils.report_time_param.req_Login = sys.now();
        let l = sys.now(), g = { tel_no: e, code: i, email: t, pwdtoken: a, logintype: n, channel_id: TransferPlatform.shared().getChannelId(), phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: l, rver: GameConfig.NEW_APP_VERSION, cver: TransferPlatform.shared().getAppVersionCode(), adjust_id: TransferPlatform.shared().getAdjust_Adid(), appsflyer_id: TransferPlatform.shared().getAppsflyer_Adid(), pushid: TransferPlatform.shared().getFirebasePushId(), firebase_id: TransferPlatform.shared().getAppInstanceId(), latitude: TransferPlatform.shared().getLatitude(), longitude: TransferPlatform.shared().getLongitude(), bdid: TransferPlatform.shared().getBePowerId(), cdkey: TransferPlatform.shared().getDeepLinkCdKey(), utm_referral: TransferPlatform.shared().getInstallRefer(false), req_key: h }, p = TransferPlatform.shared().getAppInstallData();
        p.hasInstall && p.channelId.length > 0 && (g.invite_code = p.channelId);
        g.os_device = TransferPlatform.shared().getOsDeviceInfo();
        g.is_new_kyc = TransferPlatform.shared().getIsNewKyc() ? 1 : 0;
        g.mobile_data = ToolUtils.toJsonString({ emulator: TransferPlatform.shared().getIsRunningOnEmulator(), lightSensor: TransferPlatform.shared().getHasLightSensor(), phoneCpu: TransferPlatform.shared().getIsPhoneCpu(), flash: TransferPlatform.shared().getIsSupportCameraLedFlash(), blueTooth: TransferPlatform.shared().getHasBluetooth(), gps: TransferPlatform.shared().getHasGPS(), screen: GameConfig.REAL_SCREEN_WIDTH + "*" + GameConfig.REAL_SCREEN_HEIGHT, cpu: TransferPlatform.shared().getDeviceCpuName(), cpu_hz: TransferPlatform.shared().getDeviceCpuHz(), mem: TransferPlatform.shared().getDeviceMemory(), level: TransferPlatform.shared().getDeviceLevel(), avi_men: TransferPlatform.shared().getAvailueMemory(), sys_ver: TransferPlatform.shared().getMobileRelease(), phe_type: TransferPlatform.shared().getPhoneBrand() + " " + TransferPlatform.shared().getDeviceType(), platform: sys.os });
        this.httpRequest(NetConfig.SendLogin, "Player.LoginProxy.do_login", g, o);
    }
    doBlindPhoneAccount(e, t, i, a, r) {
        let n = sys.now(), o = { tel_no: e, code: t, passwd: i, serialno: a, channel_id: TransferPlatform.shared().getChannelId(), phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), is_new_kyc: TransferPlatform.shared().getIsNewKyc() ? 1 : 0, ts: n, rver: GameConfig.NEW_APP_VERSION };
        this.httpRequest("BindingPhone", "BindingPhone", o, r);
    }
    doChangePhoneAccount(e, t, i, a) {
        let r = sys.now(), n = { phone: t, code: i, old_phone: e, channel_id: TransferPlatform.shared().getChannelId(), phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: r, rver: GameConfig.NEW_APP_VERSION };
        this.httpRequest("UpdatePhone.update", "UpdatePhone.update", n, a);
    }
    doWithdraw(e, t, i, a) {
        let r = sys.now(), n = { amount: t, mtype: a, channel_id: TransferPlatform.shared().getChannelId(), phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: r, rver: GameConfig.NEW_APP_VERSION };
        this.httpRequest("doWithdraw", "Withdraw", n, i);
    }
    doGetTxInfo(e) {
        let t = sys.now(), i = { channel_id: TransferPlatform.shared().getChannelId(), phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: t, rver: GameConfig.NEW_APP_VERSION };
        this.httpRequest("doGetTxInfo", "Withdraw.getTxInfo", i, e);
    }
    doPaytx(e, t, i, a) {
        let r = sys.now(), n = { name: e, tel_no: t, email: i, channel_id: TransferPlatform.shared().getChannelId(), phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: r, rver: GameConfig.NEW_APP_VERSION };
        this.httpRequest("Paytx", "Paytx", n, a);
    }
    doGetReportTo(e, t) {
        let i = sys.now(), a = { type: e, uid: ToolUtils.uid, channel_id: TransferPlatform.shared().getChannelId(), phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: i, rver: GameConfig.NEW_APP_VERSION };
        this.httpRequest("Report.to", "Report.to", a, t);
    }
    doGetShareReward(e, t) {
        let i = sys.now(), a = { enum: e, uid: ToolUtils.uid, channel_id: TransferPlatform.shared().getChannelId(), phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: i, rver: GameConfig.NEW_APP_VERSION };
        this.httpRequest("Club.share", "Club.share", a, t);
    }
    doBlindFBAccount(e, t) {
        let i = sys.now(), a = { token: e, uid: ToolUtils.uid, channel_id: TransferPlatform.shared().getChannelId(), phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: i, rver: GameConfig.NEW_APP_VERSION };
        this.httpRequest("BlindFBAccount", "BlindFBAccount", a, t);
    }
    doGetWinShareInfo(e, t, i, a, r, n, o, h, l) {
        let g = sys.now(), _ = { room_id: e, image_url: t, type: i, tid: a, vid: r, amount: n, image_source: h, score: o, channel_id: TransferPlatform.shared().getChannelId(), phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: g, rver: GameConfig.NEW_APP_VERSION };
        this.httpRequest("Share.getPlayShareInfo", "Share.getPlayShareInfo", _, l);
    }
    doPlayRecodeShareInfo(e, t, i) {
        let a = sys.now(), r = { vid: e.vid, game_serial_id: e.game_serial_id, channel_id: TransferPlatform.shared().getChannelId(), phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: a, rver: GameConfig.NEW_APP_VERSION };
        this.uploadFile(r, "PlayRecord.getShareInfo", t, i);
    }
    uploadFile(e, t, i, r) {
        if (sys.isNative) {
            if (native.fileUtils.isFileExist(i)) {
                try {
                    let n = new XMLHttpRequest;
                    n.onreadystatechange = function () {
                        if (GameConfig.HTTP_MSG_DEBUG, 4 == n.readyState && n.status >= 200 && n.status < 400) {
                            var e = n.responseText;
                            try {
                                r && r(t, e, 200);
                            }
                            catch (e) {
                                TLog.printError("request error:", e);
                                null != r && r(t, "", -1);
                            }
                        }
                        else {
                            404 == n.status ? r && r(t, "", 0) : 500 == n.status && r && r(t, "", 0);
                        }
                    };
                    let o = this.getEncodeUrl(t, e);
                    n.timeout = 10000;
                    n.open("POST", o, true);
                    sys.isNative && n.setRequestHeader("Accept-Encoding", "gzip,deflate");
                    let l, _ = "-------------" + Math.floor(10000000 * Math.random());
                    n.setRequestHeader("Content-Type", "multipart/form-data; boundary=" + _);
                    sys.os !== sys.OS.ANDROID && sys.os !== sys.OS.OHOS && sys.os !== sys.OS.IOS || (l = native.fileUtils.getDataFromFile(i));
                    let u = new NewFormData(_.toString());
                    u.appendFile("filepath", l, i, "Image/png");
                    n.send(u.getArrayBuffer());
                }
                catch (e) {
                }
            }
        }
        else {
            r && r(t, "", 0);
        }
    }
    getEncodeUrl(e, t) {
        let i = this.hconfig.httpUrl;
        if (0 == i.length) {
            i = (1 == GameConfig.SERVER_DEBUG ? "http://" : "https://") + URLConfig.orginHttp_CurHttpUrl + "/api.php";
        }
        i = i + "?action=" + e;
        i = i + "&ver=" + this.hconfig.ver;
        i = i + "&sid=" + this.getSkey();
        let d = this.paramToSortStr(ToolUtils.toJsonString(t)), a = "";
        return a += e, a += this.getSkey(), a += this.hconfig.ver, a += d, i = i + "&sign=" + this.createNewSign(a), i = i + "&param=" + this.urlEncode(ToolUtils.toJsonString(t)), i;
    }
    httpPostRequest(e, t, i, d, a = "", r = 0) {
        let n = this.hconfig.httpUrl;
        if (0 == n.length) {
            n = (1 == GameConfig.SERVER_DEBUG ? "http://" : "https://") + URLConfig.orginHttp_CurHttpUrl + "/api.php";
        }
        n = n + "?action=" + t;
        n = n + "&ver=" + this.hconfig.ver;
        n = n + "&sid=" + this.getSkey();
        a.length > 0 && (n = n + "&ptag=" + a, n = n + "&payerId=" + ToolUtils.uid);
        let o = this.paramToSortStr(ToolUtils.toJsonString(i)), h = "";
        h += t;
        h += this.getSkey();
        h += this.hconfig.ver;
        h += o;
        n = n + "&sign=" + this.createNewSign(h);
        1 == GameConfig.HTTP_MSG_DEBUG && TLog.printMsg("httpRequest actionUrl:" + n);
        this.doSendPostRequest(e, n, ToolUtils.toJsonString(i), d);
    }
    doBindingEmail(e = 1, t, i, a) {
        let r = sys.now(), n = { type: e, email: t, code: i, channel_id: TransferPlatform.shared().getChannelId(), phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), is_new_kyc: TransferPlatform.shared().getIsNewKyc() ? 1 : 0, ts: r, rver: GameConfig.NEW_APP_VERSION };
        this.httpRequest("BindingEmail", "BindingEmail", n, a);
    }
    doChangeBindingEmail(e, t, i) {
        let a = sys.now(), r = { email: e, code: t, channel_id: TransferPlatform.shared().getChannelId(), phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), is_new_kyc: TransferPlatform.shared().getIsNewKyc() ? 1 : 0, ts: a, rver: GameConfig.NEW_APP_VERSION };
        this.httpRequest("UpdateEmail", "UpdateEmail", r, i);
    }
    LoginProxy(e, t, i) {
        ToolUtils.report_time_param.req_Login = sys.now();
        let a = sys.now();
        1 == GameConfig.HTTP_MSG_DEBUG && TLog.printMsg("LuaLoginProxy Req");
        e.adjust_id = TransferPlatform.shared().getAdjust_Adid();
        e.appsflyer_id = TransferPlatform.shared().getAppsflyer_Adid();
        e.pushid = TransferPlatform.shared().getFirebasePushId();
        e.firebase_id = TransferPlatform.shared().getAppInstanceId();
        e.bdid = TransferPlatform.shared().getBePowerId();
        e.cdkey = TransferPlatform.shared().getDeepLinkCdKey();
        let n = TransferPlatform.shared().getAppInstallData();
        n.hasInstall && n.channelId.length > 0 && (e.invite_code = n.channelId);
        e.req_key = i;
        e.os_device = TransferPlatform.shared().getOsDeviceInfo();
        e.utm_referral = TransferPlatform.shared().getInstallRefer(false);
        e.is_new_kyc = TransferPlatform.shared().getIsNewKyc() ? 1 : 0;
        e.mobile_data = ToolUtils.toJsonString({ emulator: TransferPlatform.shared().getIsRunningOnEmulator(), lightSensor: TransferPlatform.shared().getHasLightSensor(), phoneCpu: TransferPlatform.shared().getIsPhoneCpu(), flash: TransferPlatform.shared().getIsSupportCameraLedFlash(), blueTooth: TransferPlatform.shared().getHasBluetooth(), gps: TransferPlatform.shared().getHasGPS(), screen: GameConfig.REAL_SCREEN_WIDTH + "*" + GameConfig.REAL_SCREEN_HEIGHT, cpu: TransferPlatform.shared().getDeviceCpuName(), cpu_hz: TransferPlatform.shared().getDeviceCpuHz(), mem: TransferPlatform.shared().getDeviceMemory(), level: TransferPlatform.shared().getDeviceLevel(), avi_men: TransferPlatform.shared().getAvailueMemory(), sys_ver: TransferPlatform.shared().getMobileRelease(), phe_type: TransferPlatform.shared().getPhoneBrand() + " " + TransferPlatform.shared().getDeviceType(), platform: sys.os });
        this.httpRequest(NetConfig.RegisterRequest, "Player.LoginProxy.do_login", e, t, "", a);
    }
    doGetCommRoomList(t, i = null) {
        sys.isObjectValid(t) && (HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Login, event: ReportConfig.login_evt.getRoomInfo }), TransferPlatform.shared().logEvent_firebase(ReportConfig.login_evt.getRoomInfo), this.httpRequestBeforeLogin(NetConfig.CommRoomRequest, "CommRoom", t, ((e, t, d) => {
            i && i(e, t, d);
        })));
    }
    doPay(e, t, i, a) {
        let r = sys.now(), n = { payerId: ToolUtils.uid, channel_id: GameConfig.CHANNEL_ID, phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), os: TransferPlatform.shared().getOS(), ts: r, vid: ToolUtils.curRoomId, rver: GameConfig.NEW_APP_VERSION, game_model: ToolUtils.game_model, phonepe: TransferPlatform.shared().checkHasPhonePeSdk(), url_param: TransferPlatform.shared().getUrlParam() };
        Object.keys(i).forEach((e => {
            n[e] = i[e];
        }));
        sys.isObjectValid(i.scene) || (n.scene = ToolUtils.getIsInRoom() ? 2 : 1);
        1 == GameConfig.HTTP_MSG_DEBUG && TLog.printMsg("NPayProxy prams:", ToolUtils.getPrintJsonStr(n));
        this.httpRequest(t, t, n, a, e);
    }
    doTestPay(e, t) {
        let i = sys.now(), a = { payerId: ToolUtils.uid, price: e, channel_id: TransferPlatform.shared().getChannelId(), phoneimei: "", gaid: "", ts: i, os: TransferPlatform.shared().getOS(), rver: GameConfig.NEW_APP_VERSION, game_model: ToolUtils.game_model, url_param: "" };
        this.httpRequest(NetConfig.doTestPay, "TestInnerPay", a, t);
    }
    doGetSoreList(e = null, t = null) {
        let i = sys.now(), a = e ? ToolUtils.toJsonString(e) : "", n = { channel_id: TransferPlatform.shared().getChannelId(), phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: i, os: TransferPlatform.shared().getOS(), rver: GameConfig.NEW_APP_VERSION, exe: a };
        this.httpRequest(NetConfig.doGetSoreList, "NShopList", n, t);
    }
    doGetSoreList2(e = null, t = 1, i = null) {
        let a = sys.now(), n = e ? ToolUtils.toJsonString(e) : "", o = { uid: ToolUtils.uid, channel_id: TransferPlatform.shared().getChannelId(), phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: a, os: TransferPlatform.shared().getOS(), rver: GameConfig.NEW_APP_VERSION, exe: n, open_mall_type: t };
        this.httpRequest(NetConfig.doGetSoreList, "Mall.Shop.getListV2", o, i);
    }
    doGetExeStoreList(e = null, t = null) {
        let i = sys.now(), a = e ? ToolUtils.toJsonString(e) : "", n = { uid: ToolUtils.uid, channel_id: TransferPlatform.shared().getChannelId(), phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: i, os: TransferPlatform.shared().getOS(), rver: GameConfig.NEW_APP_VERSION, exe: a };
        this.httpRequest(NetConfig.doGetSoreList, "Mall.ExeShop.getList", n, t);
    }
    doReportUserAct(e, t = null, i = 0) {
    }
    doReportPlayerGuideAct(e) {
    }
    doCommReportRechargeEvent(e, t, i, d, a, s, r = -1) {
    }
    doGetBonusAndCash(e = null) {
        let t = sys.now(), i = { channel_id: TransferPlatform.shared().getChannelId(), phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: t, install: "h5", os: TransferPlatform.shared().getOS(), rver: GameConfig.NEW_APP_VERSION };
        this.httpRequest(NetConfig.Congratulations, "Hall.getFreeBonus", i, e);
    }
    doChangePhoneRequist(e = null) {
        let t = sys.now(), i = { uid: ToolUtils.uid, channel_id: GameConfig.CHANNEL_ID, phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: t, os: TransferPlatform.shared().getOS(), rver: GameConfig.NEW_APP_VERSION, latitude: TransferPlatform.shared().getLatitude(), longtitude: TransferPlatform.shared().getLongitude() };
        this.httpRequest(NetConfig.CheckDevice, "UpdatePhone.checkDevice", i, e);
    }
    doChangeNameRequist(e, t = null) {
        let i = sys.now(), a = { uid: ToolUtils.uid, channel_id: GameConfig.CHANNEL_ID, phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: i, os: TransferPlatform.shared().getOS(), rver: GameConfig.NEW_APP_VERSION, name: e };
        this.httpRequest(NetConfig.doChangeNameRequist, "ModifyPlayerName", a, t);
    }
    doChangeHeadRequist(e, t = null) {
        let i = sys.now(), a = { uid: ToolUtils.uid, channel_id: GameConfig.CHANNEL_ID, phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: i, os: TransferPlatform.shared().getOS(), rver: GameConfig.NEW_APP_VERSION, avatar: e };
        this.httpRequest(NetConfig.doChangeAvatarRequist, "ModifyPlayerAvatar", a, t);
    }
    doEmailType(e = null) {
        let t = sys.now(), i = { uid: ToolUtils.uid, channel_id: GameConfig.CHANNEL_ID, phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: t, os: TransferPlatform.shared().getOS(), rver: GameConfig.NEW_APP_VERSION };
        this.httpRequest(NetConfig.doGetEmailList, "Email.getNew", i, e);
    }
    doAllReadEmail(e, t = null) {
        let i = sys.now(), a = { etype: e, uid: ToolUtils.uid, channel_id: GameConfig.CHANNEL_ID, phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: i, os: TransferPlatform.shared().getOS(), rver: GameConfig.NEW_APP_VERSION };
        this.httpRequest(NetConfig.doEmailAction, "email.allReceive", a, t);
    }
    doDelEmail(e, t = null) {
        let i = sys.now(), a = { etype: e, uid: ToolUtils.uid, channel_id: GameConfig.CHANNEL_ID, phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: i, os: TransferPlatform.shared().getOS(), rver: GameConfig.NEW_APP_VERSION };
        this.httpRequest(NetConfig.doEmailAction, "email.allDel", a, t);
    }
    doGetEmailList(e, t = null) {
        let i = sys.now(), a = { eids: e, uid: ToolUtils.uid, channel_id: GameConfig.CHANNEL_ID, phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: i, os: TransferPlatform.shared().getOS(), rver: GameConfig.NEW_APP_VERSION };
        this.httpRequest(NetConfig.doGetEmailList, "email.getUserEmail", a, t);
    }
    doActionEmailList(e, t, i) {
        let a = sys.now(), n = { uid: ToolUtils.uid, channel_id: GameConfig.CHANNEL_ID, phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: a, os: TransferPlatform.shared().getOS(), rver: GameConfig.NEW_APP_VERSION, eid: e, acttype: t };
        this.httpRequest(NetConfig.doEmailAction, "email.act", n, i);
    }
    doGetMemberShipDashboard(e) {
        let t = sys.now(), i = { uid: ToolUtils.uid, channel_id: GameConfig.CHANNEL_ID, phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: t, os: TransferPlatform.shared().getOS(), rver: GameConfig.NEW_APP_VERSION };
        this.httpRequest(NetConfig.doClubDashBoard, "Club.dashboard", i, e);
    }
    doGetMemberShipBind(e, t) {
        let i = sys.now(), a = { uid: ToolUtils.uid, channel_id: GameConfig.CHANNEL_ID, phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: i, os: TransferPlatform.shared().getOS(), rver: GameConfig.NEW_APP_VERSION, invite_code: e, isregister: ToolUtils.isregister };
        this.httpRequest(NetConfig.doClubBind, "Share.bind", a, t);
    }
    doGetMemberShipNumber(e, t, i) {
        let a = sys.now(), n = { uid: ToolUtils.uid, channel_id: GameConfig.CHANNEL_ID, phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: a, os: TransferPlatform.shared().getOS(), rver: GameConfig.NEW_APP_VERSION, search: e, page: t };
        this.httpRequest(NetConfig.doClubNumber, "Club.number", n, i);
    }
    doGetMemberShipDailyStat(e, t, i, a, n) {
        let o = sys.now(), h = { uid: ToolUtils.uid, channel_id: GameConfig.CHANNEL_ID, phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: o, os: TransferPlatform.shared().getOS(), rver: GameConfig.NEW_APP_VERSION, page: e, tab: t, custom_start: i, custom_end: a };
        this.httpRequest(NetConfig.doClubDailystat, "Club.dailystat", h, n);
    }
    doGetMemberShipRpsDetail(e, t) {
        let i = sys.now(), a = { uid: ToolUtils.uid, channel_id: GameConfig.CHANNEL_ID, phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: i, os: TransferPlatform.shared().getOS(), rver: GameConfig.NEW_APP_VERSION, type: e.type, last_id: e.last_id, sdate: e.sdate, edate: e.edate };
        this.httpRequest(NetConfig.doGetClubRpsDetails, "Player.Club.rpsList", a, t);
    }
    doWalletRecode(e, t, i) {
        let a = sys.now(), n = { uid: ToolUtils.uid, channel_id: GameConfig.CHANNEL_ID, phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: a, os: TransferPlatform.shared().getOS(), rver: GameConfig.NEW_APP_VERSION, type: e, l_id: t };
        this.httpRequest(NetConfig.doWalletRecode, "Record.getRecordList", n, i);
    }
    doRefreshWalletRecode(e, t) {
        let i = sys.now(), a = { uid: ToolUtils.uid, channel_id: GameConfig.CHANNEL_ID, phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: i, os: TransferPlatform.shared().getOS(), rver: GameConfig.NEW_APP_VERSION, id: e };
        this.httpRequest(NetConfig.doRefreshRecode, "Record.getInfo", a, t);
    }
    doFeedBackUploadImage(e, t, i) {
        let a = sys.now(), r = { pid: e, channel_id: TransferPlatform.shared().getChannelId(), phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: a, rver: GameConfig.NEW_APP_VERSION };
        this.uploadFile(r, "Feedback.upload", t, i);
    }
    doGetFeedback(e, t, i, a) {
        let n = sys.now(), o = { uid: ToolUtils.uid, channel_id: GameConfig.CHANNEL_ID, phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: n, os: TransferPlatform.shared().getOS(), rver: GameConfig.NEW_APP_VERSION, utr: t, pid: e, img: i };
        this.httpRequest(NetConfig.doGetFeedback, "Feedback.pay", o, a);
    }
    doGetConponHelp(e) {
        let t = sys.now(), i = { uid: ToolUtils.uid, channel_id: GameConfig.CHANNEL_ID, phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: t, os: TransferPlatform.shared().getOS(), rver: GameConfig.NEW_APP_VERSION };
        this.httpRequest(NetConfig.doCouponHelp, "Coupon.help", i, e);
    }
    doGetConponList(e, t) {
        let i = sys.now(), a = { uid: ToolUtils.uid, channel_id: GameConfig.CHANNEL_ID, phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: i, os: TransferPlatform.shared().getOS(), rver: GameConfig.NEW_APP_VERSION, tab: e };
        this.httpRequest(NetConfig.doCouponHelp, "Coupon.getList", a, t);
    }
    doGetWalletFlow(e, t, i, a) {
        let n = sys.now(), o = { uid: ToolUtils.uid, channel_id: GameConfig.CHANNEL_ID, phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: n, os: TransferPlatform.shared().getOS(), rver: GameConfig.NEW_APP_VERSION, date: e, alter: t, page: i };
        this.httpRequest(NetConfig.doWalletFlow, "log.flow", o, a);
    }
    doGetMemberShipCallStat(e, t) {
        let i = sys.now(), a = { uid: ToolUtils.uid, channel_id: GameConfig.CHANNEL_ID, phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: i, os: TransferPlatform.shared().getOS(), rver: GameConfig.NEW_APP_VERSION, tel_no: e };
        this.httpRequest(NetConfig.doClubCallStat, "Club.call", a, t);
    }
    doGoldExchange(e, t) {
        let i = sys.now(), a = { uid: ToolUtils.uid, channel_id: GameConfig.CHANNEL_ID, phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: i, os: TransferPlatform.shared().getOS(), rver: GameConfig.NEW_APP_VERSION, amount: e };
        this.httpRequest(NetConfig.doClubGoldExchange, "Club.gold_exchange", a, t);
    }
    doGetMemberShipRewardDetailStat(e, t, i) {
        let a = sys.now(), n = { uid: ToolUtils.uid, channel_id: GameConfig.CHANNEL_ID, phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: a, os: TransferPlatform.shared().getOS(), rver: GameConfig.NEW_APP_VERSION, page: e, type: t };
        this.httpRequest(NetConfig.doClubRewardDetails, "Club.reward_details", n, i);
    }
    doGetMemberShipDailyDetail(e, t, i) {
        let a = sys.now(), n = { uid: ToolUtils.uid, channel_id: GameConfig.CHANNEL_ID, phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: a, os: TransferPlatform.shared().getOS(), rver: GameConfig.NEW_APP_VERSION, date: e, page: t };
        this.httpRequest(NetConfig.doClubDailyDetails, "Club.dailydetail", n, i);
    }
    doGetPayDefList(e) {
        let t = sys.now(), i = { uid: ToolUtils.uid, channel_id: GameConfig.CHANNEL_ID, phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: t, os: TransferPlatform.shared().getOS(), rver: GameConfig.NEW_APP_VERSION };
        this.httpRequest("PayDef.allRoom", "PayDef.allRoom", i, e);
    }
    doGetPayDefLimit(e) {
        let t = sys.now(), i = { uid: ToolUtils.uid, channel_id: GameConfig.CHANNEL_ID, phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: t, os: TransferPlatform.shared().getOS(), rver: GameConfig.NEW_APP_VERSION };
        this.httpRequest("PayDef.getLimit", "PayDef.getLimit", i, e);
    }
    doPayDefSetLimit(e, t, i, a) {
        let r = sys.now(), n = { uid: ToolUtils.uid, channel_id: GameConfig.CHANNEL_ID, phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: r, os: TransferPlatform.shared().getOS(), rver: GameConfig.NEW_APP_VERSION, mlimit: e, dlimit: t, wlimit: i };
        this.httpRequest("PayDef.setLimit", "PayDef.setLimit", n, a);
    }
    doGetRummyMonthMatchRank(e, t) {
        let i = sys.now(), a = { uid: ToolUtils.uid, channel_id: GameConfig.CHANNEL_ID, phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: i, os: TransferPlatform.shared().getOS(), rver: GameConfig.NEW_APP_VERSION, lastweek: e };
        this.httpRequest(NetConfig.doGetMonthMatchRank, "match.week", a, t);
    }
    doGetShareUrl(e, t, i) {
        let d = { game_type: e, tid: t };
        this.httpRequest("Share.getShareUrl", "Share.getShareUrl", d, i);
    }
    doGetMemberShipPageData(e) {
        let t = sys.now(), i = { uid: ToolUtils.uid, channel_id: GameConfig.CHANNEL_ID, phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: t, os: TransferPlatform.shared().getOS(), rver: GameConfig.NEW_APP_VERSION };
        this.httpRequest(NetConfig.doGetClubPageData, "Player.Club.getClubList", i, e);
    }
    doGetMemberShipPage(e) {
        let t = sys.now(), i = { uid: ToolUtils.uid, channel_id: GameConfig.CHANNEL_ID, phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: t, os: TransferPlatform.shared().getOS(), rver: GameConfig.NEW_APP_VERSION };
        this.httpRequest(NetConfig.doGetClubPageData, "Player.club.page", i, e);
    }
    doGetMallRPList(e) {
        let t = sys.now(), i = { uid: ToolUtils.uid, channel_id: GameConfig.CHANNEL_ID, phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: t, os: TransferPlatform.shared().getOS(), rver: GameConfig.NEW_APP_VERSION };
        this.httpRequest(NetConfig.doGetMallRPList, "mall.rp.index", i, e);
    }
    doGetMallRPExchange(e, t) {
        let i = sys.now(), a = { uid: ToolUtils.uid, channel_id: GameConfig.CHANNEL_ID, phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: i, os: TransferPlatform.shared().getOS(), rver: GameConfig.NEW_APP_VERSION, goodsId: e };
        this.httpRequest(NetConfig.doGetMallRPExchange, "mall.rp.doExchange", a, t);
    }
    doGetActivityList(e) {
        let t = sys.now(), i = { uid: ToolUtils.uid, channel_id: GameConfig.CHANNEL_ID, phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: t, os: TransferPlatform.shared().getOS(), rver: GameConfig.NEW_APP_VERSION };
        this.httpRequest(NetConfig.doGetActivityList, "Activities.getlist", i, e);
    }
    doReportWalletGetList(e, t, i = "0", a = "0", n = 0, o = 2, h = 0) {
        let l = sys.now(), g = { uid: ToolUtils.uid, channel_id: GameConfig.CHANNEL_ID, phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: l, os: TransferPlatform.shared().getOS(), rver: GameConfig.NEW_APP_VERSION, menu: e, sdate: i, edate: a, lastid: n, alter_type: o, condition: h };
        this.httpRequest(NetConfig.doReportWalletGetList, "wallet.getList", g, t);
    }
    doReportWalletGetOne(e, t) {
        let i = sys.now(), a = { uid: ToolUtils.uid, channel_id: GameConfig.CHANNEL_ID, phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: i, os: TransferPlatform.shared().getOS(), rver: GameConfig.NEW_APP_VERSION, id: e };
        this.httpRequest(NetConfig.doReportWalletGetOne, "wallet.getOne", a, t);
    }
    doGetPropList(e) {
        let t = sys.now(), i = { uid: ToolUtils.uid, channel_id: GameConfig.CHANNEL_ID, phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: t, os: TransferPlatform.shared().getOS(), rver: GameConfig.NEW_APP_VERSION };
        this.httpRequest(NetConfig.doGetPropList, "Prop.getList", i, e);
    }
    doGetHallMatchUsers(e) {
        let t = sys.now(), i = { uid: ToolUtils.uid, channel_id: GameConfig.CHANNEL_ID, phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: t, os: TransferPlatform.shared().getOS(), rver: GameConfig.NEW_APP_VERSION };
        this.httpRequest(NetConfig.doGetHallMatchUser, "hall.users", i, e);
    }
    doGetNewPlayerGuideFinish(e, t, i = 1) {
        let a = sys.now(), r = { uid: ToolUtils.uid, channel_id: GameConfig.CHANNEL_ID, phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: a, os: TransferPlatform.shared().getOS(), rver: GameConfig.NEW_APP_VERSION, type: e, source: i };
        this.httpRequest("BeginnerGuide.receiveAward", "BeginnerGuide.receiveAward", r, t);
    }
    doGetMatchHistory(e) {
        let t = sys.now(), i = { uid: ToolUtils.uid, channel_id: GameConfig.CHANNEL_ID, phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: t, os: TransferPlatform.shared().getOS(), rver: GameConfig.NEW_APP_VERSION };
        this.httpRequest("match.getHistory", "match.getHistory", i, e);
    }
    doGetMatchHistoryContent(e, t) {
        let i = sys.now(), a = { uid: ToolUtils.uid, channel_id: GameConfig.CHANNEL_ID, phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: i, os: TransferPlatform.shared().getOS(), rver: GameConfig.NEW_APP_VERSION, raceid: e };
        this.httpRequest("match.getHistoryContent", "match.getHistoryContent", a, t);
    }
    doGetLoginAfterAddToken(e, t) {
        let i = sys.now(), a = { uid: ToolUtils.uid, channel_id: GameConfig.CHANNEL_ID, phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: i, os: TransferPlatform.shared().getOS(), rver: GameConfig.NEW_APP_VERSION, cver: TransferPlatform.shared().getAppVersionCode(), pushid: TransferPlatform.shared().getFirebasePushId(), firebase_id: TransferPlatform.shared().getAppInstanceId(), token: e };
        this.httpRequest("LoginAfter.addToken", "LoginAfter.addToken", a, t);
    }
    doGetLoginAfterPush(e) {
        if (0 == ToolUtils.uid) {
            return;
        }
        let t = sys.now(), i = { uid: ToolUtils.uid, channel_id: GameConfig.CHANNEL_ID, phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: t, os: TransferPlatform.shared().getOS(), rver: GameConfig.NEW_APP_VERSION, cver: TransferPlatform.shared().getAppVersionCode(), pushid: TransferPlatform.shared().getFirebasePushId(), firebase_id: TransferPlatform.shared().getAppInstanceId() };
        this.httpRequest("LoginAfter.push", "LoginAfter.push", i, e);
    }
    doReportSdkParamAfterLogin(e) {
        if (0 == ToolUtils.uid) {
            return;
        }
        let t = sys.now(), i = { uid: ToolUtils.uid, channel_id: GameConfig.CHANNEL_ID, phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: t, os: TransferPlatform.shared().getOS(), rver: GameConfig.NEW_APP_VERSION, cver: TransferPlatform.shared().getAppVersionCode(), pushid: TransferPlatform.shared().getFirebasePushId(), firebase_id: TransferPlatform.shared().getAppInstanceId(), adjust_id: TransferPlatform.shared().getAdjust_Adid(), token: TransferPlatform.shared().getFireBaseToken(), vid: 0 };
        this.httpRequest("hall.importSdkData", "hall.importSdkData", i, e);
    }
    doPreGetActivityInfo(e) {
        let t = sys.now(), i = { uid: ToolUtils.uid, channel_id: GameConfig.CHANNEL_ID, phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: t, os: TransferPlatform.shared().getOS(), rver: GameConfig.NEW_APP_VERSION };
        this.httpRequest("Activity.PrepAct.getList", "Activity.PrepAct.getList", i, e);
    }
    doGetHallBannerLists(e) {
        let t = sys.now(), i = { uid: ToolUtils.uid, channel_id: GameConfig.CHANNEL_ID, phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: t, os: TransferPlatform.shared().getOS(), rver: GameConfig.NEW_APP_VERSION };
        this.httpRequest("Hall.getBannerLists", "Hall.getBannerLists", i, e);
    }
    doGetDailyTaskList(e) {
        let t = sys.now(), i = { uid: ToolUtils.uid, channel_id: GameConfig.CHANNEL_ID, phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: t, os: TransferPlatform.shared().getOS(), rver: GameConfig.NEW_APP_VERSION };
        this.httpRequest(NetConfig.doGetDailyTaskList, "Task.getList", i, e);
    }
    doGetDailyOneTaskReward(e, t) {
        let i = sys.now(), a = { uid: ToolUtils.uid, channel_id: GameConfig.CHANNEL_ID, phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: i, os: TransferPlatform.shared().getOS(), rver: GameConfig.NEW_APP_VERSION, task_id: e };
        this.httpRequest(NetConfig.doGetDailyTaskList, "Task.getOneTaskReward", a, t);
    }
    doGetNewDailyTaskReward(e = null, t) {
        let i = sys.now(), a = { uid: ToolUtils.uid, channel_id: GameConfig.CHANNEL_ID, phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: i, os: TransferPlatform.shared().getOS(), rver: GameConfig.NEW_APP_VERSION };
        sys.isObjectValid(e) && (a.task_id = e);
        this.httpRequest(NetConfig.doGetDailyTaskList, "Act_63.getReward", a, t);
    }
    doGetDailyTaskAllReward(e) {
        let t = sys.now(), i = { uid: ToolUtils.uid, channel_id: GameConfig.CHANNEL_ID, phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: t, os: TransferPlatform.shared().getOS(), rver: GameConfig.NEW_APP_VERSION };
        this.httpRequest(NetConfig.doGetDailyTaskList, "Task.getAllReward", i, e);
    }
    doGetDailyOneActiveReward(e, t) {
        let i = sys.now(), a = { uid: ToolUtils.uid, channel_id: GameConfig.CHANNEL_ID, phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: i, os: TransferPlatform.shared().getOS(), rver: GameConfig.NEW_APP_VERSION, node_id: e };
        this.httpRequest(NetConfig.doGetDailyTaskList, "Task.getOneActiveReward", a, t);
    }
    doGetNewDailyTaskList(e, t) {
        let i = sys.now(), a = { uid: ToolUtils.uid, channel_id: GameConfig.CHANNEL_ID, phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: i, os: TransferPlatform.shared().getOS(), rver: GameConfig.NEW_APP_VERSION };
        sys.isObjectValid(t) && (a.vid = t);
        this.httpRequest(HttpRequest.GetNewDailyList, "Act_63.page", a, e);
    }
    doGetBonusRecharge(e, t) {
        let i = sys.now(), a = { uid: ToolUtils.uid, channel_id: GameConfig.CHANNEL_ID, phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: i, os: TransferPlatform.shared().getOS(), rver: GameConfig.NEW_APP_VERSION, new_vid: e.new_vid, inRoom: e.inRoom };
        this.httpRequest(NetConfig.doGetBonusGift, "Activity.Act_101.page", a, t);
    }
    doGetQuickRechargeMoneyLess(e, t) {
        let i = sys.now(), a = { uid: ToolUtils.uid, channel_id: GameConfig.CHANNEL_ID, phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: i, os: TransferPlatform.shared().getOS(), rver: GameConfig.NEW_APP_VERSION, vid: e.cur_vid, score: e.score, new_vid: e.new_vid, inRoom: e.inRoom, flag: e.flag, is_pop: e.is_pop };
        this.httpRequest(NetConfig.doGetMoneyLess, "Pop.MoneyLess.page", a, t);
    }
    doGetHappyRewardsList(e, t, i) {
        let a = sys.now(), n = { uid: ToolUtils.uid, channel_id: GameConfig.CHANNEL_ID, phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: a, os: TransferPlatform.shared().getOS(), rver: GameConfig.NEW_APP_VERSION, vid: e, aid: t };
        this.httpRequest(NetConfig.doGetHappyRewardsList, "Activity.Act_53.page", n, i);
    }
    doGetHappyRewardsExchange(e, t, i) {
        let a = sys.now(), n = { uid: ToolUtils.uid, channel_id: GameConfig.CHANNEL_ID, phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: a, os: TransferPlatform.shared().getOS(), rver: GameConfig.NEW_APP_VERSION, rid: e, aid: t };
        this.httpRequest(NetConfig.doGetHappyRewardsExchange, "Activity.Act_53.redeem_rewards", n, i);
    }
    doGettHappyRewardsReportTo(e, t, i) {
        let a = sys.now(), r = { type: e, aid: t, uid: ToolUtils.uid, channel_id: TransferPlatform.shared().getChannelId(), phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: a, rver: GameConfig.NEW_APP_VERSION };
        this.httpRequest("Report.to", "Activity.Act_53.pvuv", r, i);
    }
    doSharePage(e) {
        let t = sys.now(), i = { uid: ToolUtils.uid, channel_id: GameConfig.CHANNEL_ID, phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: t, os: TransferPlatform.shared().getOS(), rver: GameConfig.NEW_APP_VERSION };
        this.httpRequest("Share.page", "Share.page", i, e);
    }
    doShareGetIncomeList(e) {
        let t = sys.now(), i = { uid: ToolUtils.uid, channel_id: GameConfig.CHANNEL_ID, phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: t, os: TransferPlatform.shared().getOS(), rver: GameConfig.NEW_APP_VERSION };
        this.httpRequest("Share.getIncomeListV2", "Share.getIncomeListV2", i, e);
    }
    doSdkApiReport(e) {
        if (0 === GameConfig.USR_REPORT_SWITCH) {
            return;
        }
        let t = sys.now(), i = {};
        if (!sys.isNative || sys.os !== sys.OS.ANDROID && sys.os !== sys.OS.OHOS || (i = { cpu: TransferPlatform.shared().getDeviceCpuName(), cpu_hz: TransferPlatform.shared().getDeviceCpuHz(), mem: TransferPlatform.shared().getDeviceMemory(), level: TransferPlatform.shared().getDeviceLevel() }), sys.isObjectValid(e.type) && (i.type = e.type), sys.isObjectValid(e.amt) && (i.amt = e.amt), sys.isObjectValid(e.cnt) && (i.cnt = e.cnt), sys.isObjectValid(e.round) && (i.round = e.round), sys.isObjectValid(e.currentRound) && (i.currentRound = e.currentRound), sys.isObjectValid(e.fb_error) && (i.fb_error = e.fb_error), sys.isObjectValid(e.skey) && (i.skey = e.skey), ToolUtils.netDelay2 >= 0 && (i.g_ping = ToolUtils.netDelay2), sys.isObjectValid(e.err_code) && (i.err_code = e.err_code), sys.isObjectValid(e.launch_time) && (i.launch_time = e.launch_time), sys.isObjectValid(e.play_time) && (i.play_time = e.play_time), sys.isObjectValid(e.location_type) && (i.location_type = e.location_type), sys.isObjectValid(e.latitude) && (i.latitude = e.latitude), sys.isObjectValid(e.longtitude) && (i.longtitude = e.longtitude), sys.isObjectValid(e.load_res_time) && (i.load_res_time = e.load_res_time), sys.isObjectValid(e.rev_tab_time) && (i.rev_tab_time = e.rev_tab_time), sys.isObjectValid(e.kyc_err) && (i.kyc_err = e.kyc_err), sys.isObjectValid(e.reportTime) && (i.reportTime = e.reportTime), sys.isObjectValid(e.sdkErr) && (i.sdkErr = e.sdkErr), sys.isObjectValid(e.event) && (e.event == ReportConfig.login_evt.openApp || e.event == ReportConfig.login_evt.getHotUpdate || e.event == ReportConfig.login_evt.showLogin || e.event == ReportConfig.login_evt.getGainNewHost)) {
            let e = sys.localStorage.getItem("logintype");
            sys.isObjectValid(e) ? i.last_login_type = e : i.last_login_type = "null";
        }
        let a = 0;
        t < ToolUtils.firstLoginTime && (a = 1);
        let r = ToolUtils.uid, o = sys.localStorage.getItem("lastLoginUid");
        null != o && (r = Number(o));
        let h = { appid: "1", uid: r, channel_id: GameConfig.CHANNEL_ID, app_ver: GameConfig.NEW_APP_VERSION, language: i18nMgr.shared().language, phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: ToolUtils.getPhontTimeShow(), os: TransferPlatform.shared().getOS(), rver: TransferPlatform.shared().getAppVersionCode(), sys_ver: TransferPlatform.shared().getMobileRelease(), phe_type: TransferPlatform.shared().getPhoneBrand() + " " + TransferPlatform.shared().getDeviceType(), net_type: TransferPlatform.shared().getNetworkType(), scene: e.scene ? e.scene : "", func: e.func ? e.func : "", event: e.event ? e.event : "", act_type: a, req_ip: ToolUtils.client_ip, msg: e.msg ? e.msg : "", ext: i };
        ToolUtils.ipAddress.length > 0 && (h.ipAddress = ToolUtils.ipAddress, h.s_ip = ToolUtils.ipAddress);
        ToolUtils.netDelay > 0 && (h.ping = ToolUtils.netDelay);
        ToolUtils.netDelay2 >= 0 && (h.g_ping = ToolUtils.netDelay2);
        ToolUtils.gamePing > 0 ? (h.game_ping = ToolUtils.gamePing, ToolUtils.enter_game_ping = -1) : ToolUtils.enter_game_ping > 0 && (h.game_ping = ToolUtils.enter_game_ping);
        !sys.isNative || sys.os !== sys.OS.ANDROID && sys.os !== sys.OS.OHOS || (h.gp = TransferPlatform.shared().getAndroidGpType());
        let l = [h], g = ToolUtils.toJsonString(l), p = "";
        p += "batch_behavior.online";
        p += t;
        p += GameConfig.NEW_APP_VERSION;
        p += g;
        let c = { action: "batch_behavior.online" };
        if (c.sid = t, c.ver = GameConfig.NEW_APP_VERSION, c.sign = this.createNewSignByHost(p, t), c.param = g, this.sdk_url.length > 7) {
            let e = "";
            if (Number(TransferPlatform.shared().getLocalVersionCode()) > 1) {
                e = "aes#" + HttpCrypto.shared().encrypt(ToolUtils.toJsonString(c));
            }
            else {
                e = ToolUtils.toJsonString(c);
            }
            let t = ToolUtils.format("${0}?log=${1}", this.sdk_url, this.urlEncode(e));
            this.doSendSimpleGetRequest(t, "doSdkApiReport", null);
        }
    }
    doPhonePeReport(e) {
        if (null != e && sys.isObjectValid(e)) {
            let t = sys.now(), i = { uid: ToolUtils.uid, channel_id: GameConfig.CHANNEL_ID, phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: t, os: TransferPlatform.shared().getOS(), rver: GameConfig.NEW_APP_VERSION };
            if (-1 != e.indexOf("PPSdkErr:")) {
                i.resp_json = e;
                i.pay_time = Math.ceil(t / 1000);
            }
            else {
                let t = ToolUtils.parseJson(e);
                t && (sys.isObjectValid(t.resp_json) && (i.resp_json = t.resp_json), sys.isObjectValid(t.sdk_code) && (i.sdk_code = t.sdk_code), sys.isObjectValid(t.pay_time) && (i.pay_time = t.pay_time), sys.isObjectValid(t.m_order_id) && (i.m_order_id = t.m_order_id), sys.isObjectValid(t.req_json) && (i.req_json = t.req_json), sys.isObjectValid(t.order_id) && (i.order_id = t.order_id), sys.isObjectValid(t.sys_ver) && (i.sys_ver = t.sys_ver), sys.isObjectValid(t.phone_type) && (i.phone_type = t.phone_type));
            }
            this.httpRequest("PhonePe.importSdkLog", "PhonePe.importSdkLog", i, null);
        }
    }
    doNewSdkApiReport(e) {
        if (this.new_sdk_url.length < 7) {
            return;
        }
        let t = sys.now(), i = {};
        if (!sys.isNative || sys.os !== sys.OS.ANDROID && sys.os !== sys.OS.OHOS || (i = { cpu: TransferPlatform.shared().getDeviceCpuName(), cpu_hz: TransferPlatform.shared().getDeviceCpuHz(), mem: TransferPlatform.shared().getDeviceMemory(), level: TransferPlatform.shared().getDeviceLevel() }), sys.isObjectValid(e.type) && (i.type = e.type), sys.isObjectValid(e.amt) && (i.amt = e.amt), sys.isObjectValid(e.cnt) && (i.cnt = e.cnt), sys.isObjectValid(e.round) && (i.round = e.round), sys.isObjectValid(e.currentRound) && (i.currentRound = e.currentRound), sys.isObjectValid(e.fb_error) && (i.fb_error = e.fb_error), sys.isObjectValid(e.skey) && (i.skey = e.skey), ToolUtils.netDelay2 >= 0 && (i.g_ping = ToolUtils.netDelay2), sys.isObjectValid(e.err_code) && (i.err_code = e.err_code), sys.isObjectValid(e.launch_time) && (i.launch_time = e.launch_time), sys.isObjectValid(e.play_time) && (i.play_time = e.play_time), sys.isObjectValid(e.location_type) && (i.location_type = e.location_type), sys.isObjectValid(e.latitude) && (i.latitude = e.latitude), sys.isObjectValid(e.longtitude) && (i.longtitude = e.longtitude), sys.isObjectValid(e.load_res_time) && (i.load_res_time = e.load_res_time), sys.isObjectValid(e.rev_tab_time) && (i.rev_tab_time = e.rev_tab_time), sys.isObjectValid(e.kyc_err) && (i.kyc_err = e.kyc_err), sys.isObjectValid(e.reportTime) && (i.reportTime = e.reportTime), sys.isObjectValid(e.sdkErr) && (i.sdkErr = e.sdkErr), sys.isObjectValid(e.event) && (e.event == ReportConfig.login_evt.openApp || e.event == ReportConfig.login_evt.getHotUpdate || e.event == ReportConfig.login_evt.showLogin || e.event == ReportConfig.login_evt.getGainNewHost)) {
            let e = sys.localStorage.getItem("logintype");
            sys.isObjectValid(e) ? i.last_login_type = e : i.last_login_type = "null";
        }
        let a = 0;
        t < ToolUtils.firstLoginTime && (a = 1);
        let r = ToolUtils.uid, o = sys.localStorage.getItem("lastLoginUid");
        null != o && (r = Number(o));
        let h = { appid: "1", uid: r, channel_id: GameConfig.CHANNEL_ID, app_ver: GameConfig.NEW_APP_VERSION, language: i18nMgr.shared().language, phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: ToolUtils.getPhontTimeShow(), os: TransferPlatform.shared().getOS(), rver: TransferPlatform.shared().getAppVersionCode(), sys_ver: TransferPlatform.shared().getMobileRelease(), phe_type: TransferPlatform.shared().getPhoneBrand() + " " + TransferPlatform.shared().getDeviceType(), net_type: TransferPlatform.shared().getNetworkType(), scene: e.scene ? e.scene : "", func: e.func ? e.func : "", event: e.event ? e.event : "", act_type: a, req_ip: ToolUtils.client_ip, msg: e.msg ? e.msg : "", ext: i };
        ToolUtils.ipAddress.length > 0 && (h.ipAddress = ToolUtils.ipAddress, h.s_ip = ToolUtils.ipAddress);
        ToolUtils.netDelay > 0 && (h.ping = ToolUtils.netDelay);
        ToolUtils.netDelay2 >= 0 && (h.g_ping = ToolUtils.netDelay2);
        ToolUtils.gamePing > 0 ? (h.game_ping = ToolUtils.gamePing, ToolUtils.enter_game_ping = -1) : ToolUtils.enter_game_ping > 0 && (h.game_ping = ToolUtils.enter_game_ping);
        !sys.isNative || sys.os !== sys.OS.ANDROID && sys.os !== sys.OS.OHOS || (h.gp = TransferPlatform.shared().getAndroidGpType());
        let l = [h], g = ToolUtils.toJsonString(l), p = "";
        p += "batch_behavior.online";
        p += t;
        p += GameConfig.NEW_APP_VERSION;
        p += g;
        let c = { action: "batch_behavior.online" };
        c.sid = t;
        c.ver = GameConfig.NEW_APP_VERSION;
        c.sign = this.createNewSignByHost(p, t);
        c.param = g;
        let E = "aes#" + HttpCrypto.shared().encrypt(ToolUtils.toJsonString(c)), R = ToolUtils.format("${0}?log=${1}", this.new_sdk_url, this.urlEncode(E));
        this.doSendSimpleGetRequest(R, "doNewSdkApiReport", null);
    }
    doRequestSdkApiReport(e) {
        if (!sys.isObjectValid(URLConfig.SDK_URL2) || 0 == URLConfig.SDK_URL2.length) {
            return;
        }
        let t = { appid: "1", channel_id: GameConfig.CHANNEL_ID, app_ver: GameConfig.NEW_APP_VERSION, language: i18nMgr.shared().language, phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: ToolUtils.getPhontTimeShow(), os: TransferPlatform.shared().getOS(), rver: TransferPlatform.shared().getAppVersionCode(), sys_ver: TransferPlatform.shared().getMobileRelease(), phe_type: TransferPlatform.shared().getPhoneBrand() + " " + TransferPlatform.shared().getDeviceType(), net_type: TransferPlatform.shared().getNetworkType() };
        !sys.isNative || sys.os !== sys.OS.ANDROID && sys.os !== sys.OS.OHOS || (t.cpu = TransferPlatform.shared().getDeviceCpuName(), t.cpu_hz = TransferPlatform.shared().getDeviceCpuHz(), t.mem = TransferPlatform.shared().getDeviceMemory(), t.level = TransferPlatform.shared().getDeviceLevel());
        ToolUtils.ipAddress.length > 0 && (t.ipAddress = ToolUtils.ipAddress);
        ToolUtils.netDelay > 0 && (t.ping = ToolUtils.netDelay);
        ToolUtils.netDelay2 >= 0 && (t.g_ping = ToolUtils.netDelay2);
        ToolUtils.gamePing > 0 && (t.game_ping = ToolUtils.gamePing);
        let i = ToolUtils.uid, a = sys.localStorage.getItem("lastLoginUid");
        null != a && (i = Number(a));
        !Number.isNaN(i) && i > 0 && (t.uid = i);
        sys.isObjectValid(e) && Object.keys(e).sort().forEach((function (i) {
            t[i] = e[i];
        }));
        let r = ToolUtils.toJsonString(t), o = URLConfig.SDK_URL2.split(":");
        if (2 == o.length) {
            if (Number(TransferPlatform.shared().getLocalVersionCode()) > 1) {
                let e = "aes#" + HttpCrypto.shared().encrypt(ToolUtils.toJsonString(r));
                TransferPlatform.shared().startUdpReport(e, o[0], Number(o[1]));
            }
            else {
                TransferPlatform.shared().startUdpReport(ToolUtils.toJsonString(r), o[0], Number(o[1]));
            }
        }
    }
    doServerMsgResponseReport(e) {
        if (!sys.isObjectValid(URLConfig.CPP_URL) || 0 == URLConfig.CPP_URL.length) {
            return;
        }
        let t = { type: Number(e.type), c_t: Number(e.c_t), o_t: Number(e.o_t), uid: Number(ToolUtils.uid), sid: 20000000, channel_id: Number(GameConfig.CHANNEL_ID), app_ver: String(GameConfig.NEW_APP_VERSION), rver: Number(TransferPlatform.shared().getAppVersionCode()), net_type: String(TransferPlatform.shared().getNetworkType()) }, i = ToolUtils.toJsonString(t), a = URLConfig.CPP_URL.split(":");
        if (2 == a.length) {
            if (Number(TransferPlatform.shared().getLocalVersionCode()) > 1) {
                let e = "aes#" + HttpCrypto.shared().encrypt(i);
                TransferPlatform.shared().startUdpReport(e, a[0], Number(a[1]));
            }
            else {
                TransferPlatform.shared().startUdpReport(i, a[0], Number(a[1]));
            }
        }
    }
    doGetNewWorkDelay(e) {
        let t = this.hconfig.httpUrl;
        if (0 == t.length) {
            t = (1 == GameConfig.SERVER_DEBUG ? "http://" : "https://") + URLConfig.orginHttp_CurHttpUrl + "/api.php";
        }
        t = t.replace(".php", ".html");
        this.doSendSimpleGetRequest(t, HttpRequest.NetWorkDelay, e);
    }
    doGetNewWorkDelay2(e) {
        if (1 == GameConfig.SERVER_DEBUG || !sys.isNative) {
            return;
        }
        this.doSendSimpleGetRequest("https://www.google.com/", HttpRequest.NetWorkDelay, e);
    }
    doGetIPAddress(e) {
        this.doSendSimpleGetRequest("https://txt.go.sohu.com/ip/soip", NetConfig.doGetIPAddress, e);
    }
    doSendSimpleGetRequest(e = null, t, i) {
        let d = new XMLHttpRequest;
        d.onreadystatechange = function () {
            if (4 == d.readyState) {
                var e = d.responseText;
                d.status >= 200 && d.status <= 299 ? null != i && i(t, e, 200) : null != i && i(t, "", -1);
            }
        }.bind(this);
        d.onerror = function () {
            null != i && i(t, "", 0);
        };
        d.ontimeout = function () {
            null != i && i(t, "", -1);
        };
        d.timeout = 10000;
        d.open("GET", e, true);
        d.send();
    }
    doGetCommonRequest(e = null, t, i) {
        let a = sys.now(), r = { uid: ToolUtils.uid, channel_id: GameConfig.CHANNEL_ID, phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: a, os: TransferPlatform.shared().getOS(), rver: GameConfig.NEW_APP_VERSION };
        e && Object.keys(e).sort().forEach((function (t) {
            r[t] = e[t];
        }));
        this.httpRequest(t, t, r, i);
    }
    doGetFirstRechargeRequest(e) {
        let t = sys.now(), i = { uid: ToolUtils.uid, channel_id: GameConfig.CHANNEL_ID, phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: t, os: TransferPlatform.shared().getOS(), rver: GameConfig.NEW_APP_VERSION };
        this.httpRequest("Act_50.page", "Act_50.page", i, e);
    }
    httpRequest(e, t, i, d, a = "", r = 0, o = 10000) {
        let h = this.hconfig.httpUrl;
        if ((t === "Games.h5List" || t === "Games.launch") && GameConfig.SERVER_DEBUG === 1) {
            h = GameConfig.H5_GAME_API_URL;
        }
        if (0 == h.length) {
            h = (1 == GameConfig.SERVER_DEBUG ? "http://" : "https://") + URLConfig.orginHttp_CurHttpUrl + "/api.php";
        }
        h = h + "?action=" + t;
        h = h + "&ver=" + this.hconfig.ver;
        h = h + "&sid=" + this.getSkey();
        h = h + "&language=" + i18nMgr.shared().language;
        h = h + "&cver=" + TransferPlatform.shared().getAppVersionCode();
        a.length > 0 && (h = h + "&ptag=" + a, h = h + "&payerId=" + ToolUtils.uid);
        let l = this.paramToSortStr(ToolUtils.toJsonString(i)), g = "";
        g += t;
        g += this.getSkey();
        g += this.hconfig.ver;
        g += l;
        h = h + "&sign=" + this.createNewSign(g);
        h = h + "&param=" + this.urlEncode(ToolUtils.toJsonString(i));
        this.doSendGetRequest(e, h, d, r, o);
    }
    httpRequestBeforeLogin(e, t, i, d, a = "", r = 0, o = 10000) {
        let h = this.hconfig.httpUrl;
        if (0 == h.length) {
            h = (1 == GameConfig.SERVER_DEBUG ? "http://" : "https://") + URLConfig.orginHttp_CurHttpUrl + "/api.php";
        }
        h = h + "?action=" + t;
        h = h + "&ver=" + this.hconfig.ver;
        h += "&sid=0";
        h = h + "&language=" + i18nMgr.shared().language;
        h = h + "&cver=" + TransferPlatform.shared().getAppVersionCode();
        a.length > 0 && (h = h + "&ptag=" + a, h = h + "&payerId=" + ToolUtils.uid);
        let l = this.paramToSortStr(ToolUtils.toJsonString(i)), g = "";
        g += t;
        g += "0";
        g += this.hconfig.ver;
        g += l;
        h = h + "&sign=" + this.createNewSign(g, "0");
        h = h + "&param=" + this.urlEncode(ToolUtils.toJsonString(i));
        this.doSendGetRequest(e, h, d, r, o);
    }
    doGetInviteWithdaraw(e) {
        let t = sys.now(), i = { uid: ToolUtils.uid, channel_id: GameConfig.CHANNEL_ID, phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: t, os: TransferPlatform.shared().getOS(), rver: GameConfig.NEW_APP_VERSION };
        this.httpRequest(NetConfig.doGetDailyTaskList, "Withdraw.getAgentIndex", i, e);
    }
    doChangeLanguage() {
        let e = sys.now(), t = { uid: ToolUtils.uid, channel_id: GameConfig.CHANNEL_ID, phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: e, os: TransferPlatform.shared().getOS(), rver: GameConfig.NEW_APP_VERSION };
        this.httpRequest(NetConfig.doChangeLanguage, "Hall.language", t, null);
    }
    doGetKycVerifyList(e) {
        let t = sys.now(), i = { uid: ToolUtils.uid, channel_id: GameConfig.CHANNEL_ID, phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: t, os: TransferPlatform.shared().getOS(), rver: GameConfig.NEW_APP_VERSION };
        this.httpRequest(NetConfig.doGetKycVerifyList, "Kyc.getItemList", i, e);
    }
    doGetKycVerifyList2(e) {
        let t = sys.now(), i = { uid: ToolUtils.uid, channel_id: GameConfig.CHANNEL_ID, phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: t, os: TransferPlatform.shared().getOS(), rver: GameConfig.NEW_APP_VERSION };
        this.httpRequest(NetConfig.doGetKycVerifyList, "Kyc.getItemListV8", i, e);
    }
    doGetKycPop(e) {
        let t = sys.now(), i = { uid: ToolUtils.uid, channel_id: GameConfig.CHANNEL_ID, phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: t, os: TransferPlatform.shared().getOS(), rver: GameConfig.NEW_APP_VERSION };
        this.httpRequest(NetConfig.doGetKycVerifyList, "Kyc.getPop", i, e);
    }
    doGetKycReward(e, t) {
        let i = sys.now(), a = { uid: ToolUtils.uid, channel_id: GameConfig.CHANNEL_ID, phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: i, os: TransferPlatform.shared().getOS(), rver: GameConfig.NEW_APP_VERSION, item: e };
        this.httpRequest(NetConfig.doGetKycReward, "Kyc.getReward", a, t);
    }
    doGetKycAllReward(e) {
        let t = sys.now(), i = { uid: ToolUtils.uid, channel_id: GameConfig.CHANNEL_ID, phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: t, os: TransferPlatform.shared().getOS(), rver: GameConfig.NEW_APP_VERSION };
        this.httpRequest(NetConfig.doGetKycAllReward, "Kyc.getAllReward", i, e);
    }
    doGetKycAccount(e) {
        let t = sys.now(), i = { uid: ToolUtils.uid, channel_id: GameConfig.CHANNEL_ID, phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: t, os: TransferPlatform.shared().getOS(), rver: GameConfig.NEW_APP_VERSION };
        this.httpRequest(NetConfig.doGetKycAccount, "Kyc.getFormList", i, e);
    }
    doGetKycAccount2(e) {
        let t = sys.now(), i = { uid: ToolUtils.uid, channel_id: GameConfig.CHANNEL_ID, phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: t, os: TransferPlatform.shared().getOS(), rver: GameConfig.NEW_APP_VERSION };
        this.httpRequest(NetConfig.doGetKycAccount, "Kyc.getFormListV8", i, e);
    }
    doKycSaveAccount(e, t, i, a, n, o, h, l, g, p, c, E) {
        let I = sys.now(), R = { uid: ToolUtils.uid, channel_id: GameConfig.CHANNEL_ID, phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: I, os: TransferPlatform.shared().getOS(), rver: GameConfig.NEW_APP_VERSION, card_type: e, photo_frontend: t, photo_backend: i, name: a, sex: n, card: o, birthday: h, zip_code: l, province: g, city: p, address: c, latitude: TransferPlatform.shared().getLatitude(), longitude: TransferPlatform.shared().getLongitude() };
        this.httpRequest(NetConfig.doKycSaveAccount, "Kyc.Save", R, E);
    }
    doKycSaveAccount2(e, t, i, a, n, o, h, l, g, p, c = 0) {
        let E = sys.now(), I = { uid: ToolUtils.uid, channel_id: GameConfig.CHANNEL_ID, phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: E, os: TransferPlatform.shared().getOS(), rver: GameConfig.NEW_APP_VERSION, photo_frontend: e, photo_backend: t, name: o, card: i, birthday: a, content_frontend: h, content_backend: l, is_sub_data: c, from_source: g, photo_birthday: n, latitude: TransferPlatform.shared().getLatitude(), longitude: TransferPlatform.shared().getLongitude() };
        this.httpRequest(NetConfig.doKycSaveAccount, "Kyc.saveV7", I, p, "", 0, 15000);
    }
    doKycFastSava(e, t, i, a = 0, n = 0) {
        let o = sys.now(), h = { uid: ToolUtils.uid, channel_id: GameConfig.CHANNEL_ID, phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: o, os: TransferPlatform.shared().getOS(), rver: GameConfig.NEW_APP_VERSION, card: e, from_source: t, free_cash_scene: a, free_cash_link_id: n, latitude: TransferPlatform.shared().getLatitude(), longitude: TransferPlatform.shared().getLongitude() };
        this.httpRequest(NetConfig.doKycSaveAccount, "Kyc.fastSaveV8", h, i, "", 0, 15000);
    }
    doKycImgRecognitionSave(e, t, i, a, n, o, h, l) {
        let g = sys.now(), p = { uid: ToolUtils.uid, channel_id: GameConfig.CHANNEL_ID, phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: g, os: TransferPlatform.shared().getOS(), rver: GameConfig.NEW_APP_VERSION, photo_frontend: e, photo_backend: t, content_frontend: i, content_backend: a, name: h, card: n, birthday: o, latitude: TransferPlatform.shared().getLatitude(), longitude: TransferPlatform.shared().getLongitude() };
        this.httpRequest(NetConfig.doKycSaveAccount, "Kyc.asyncImgRecognitionSave", p, l, "", 0, 15000);
    }
    doGetPanCardInfo(e) {
        let t = sys.now(), i = { uid: ToolUtils.uid, channel_id: GameConfig.CHANNEL_ID, phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: t, os: TransferPlatform.shared().getOS(), rver: GameConfig.NEW_APP_VERSION };
        this.httpRequest(NetConfig.doGetPanCardInfo, "Player.Pan.page", i, e);
    }
    doGetPanCardInfo2(e) {
        let t = sys.now(), i = { uid: ToolUtils.uid, channel_id: GameConfig.CHANNEL_ID, phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: t, os: TransferPlatform.shared().getOS(), rver: GameConfig.NEW_APP_VERSION };
        this.httpRequest(NetConfig.doGetPanCardInfo, "Player.Pan.getPageV4", i, e);
    }
    doPanSaveInfo(e, t, i, a, n) {
        let o = sys.now(), h = { uid: ToolUtils.uid, channel_id: GameConfig.CHANNEL_ID, phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: o, os: TransferPlatform.shared().getOS(), rver: GameConfig.NEW_APP_VERSION, name: e, card: t, photo_frontend: i, photo_backend: a };
        this.httpRequest(NetConfig.doPanSaveInfo, "Player.Pan.doSave", h, n);
    }
    doPanSaveInfo2(e, t, i, a) {
        let n = sys.now(), o = { uid: ToolUtils.uid, channel_id: GameConfig.CHANNEL_ID, phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: n, os: TransferPlatform.shared().getOS(), rver: GameConfig.NEW_APP_VERSION, card: t, photo_frontend: i, content_frontend: e, latitude: TransferPlatform.shared().getLatitude(), longitude: TransferPlatform.shared().getLongitude() };
        this.httpRequest(NetConfig.doPanSaveInfo, "Player.Pan.saveV4", o, a, "", 0, 15000);
    }
    doPanFastSave(e, t, i = 0, a = 0) {
        let n = sys.now(), o = { uid: ToolUtils.uid, channel_id: GameConfig.CHANNEL_ID, phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: n, os: TransferPlatform.shared().getOS(), rver: GameConfig.NEW_APP_VERSION, card: e, free_cash_scene: i, free_cash_link_id: a, latitude: TransferPlatform.shared().getLatitude(), longitude: TransferPlatform.shared().getLongitude() };
        this.httpRequest(NetConfig.doPanSaveInfo, "Player.Pan.withdrawSave", o, t, "", 0, 15000);
    }
    doGetDialockerUrl(e, t) {
        let i = sys.now(), a = { source: e, uid: ToolUtils.uid, channel_id: GameConfig.CHANNEL_ID, phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: i, os: TransferPlatform.shared().getOS(), rver: GameConfig.NEW_APP_VERSION, latitude: TransferPlatform.shared().getLatitude(), longitude: TransferPlatform.shared().getLongitude() };
        this.httpRequest("KycDigilocker.getUrl", "KycDigilocker.getUrl", a, t);
    }
    doUploadNewPanFile(e, t) {
        let i = sys.now(), a = { channel_id: TransferPlatform.shared().getChannelId(), phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: i, rver: GameConfig.NEW_APP_VERSION };
        this.uploadFile(a, "Player.Pan.uploadImg", e, t);
    }
    doUploadNewKycFile(e, t) {
        let i = sys.now(), a = { channel_id: TransferPlatform.shared().getChannelId(), phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: i, rver: GameConfig.NEW_APP_VERSION };
        this.uploadFile(a, "Kyc.uploadImg", e, t);
    }
    doUpdateFile(e, t, i, a) {
        let r = sys.now(), n = { uptype: e, module_name: t, channel_id: TransferPlatform.shared().getChannelId(), phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: r, rver: GameConfig.NEW_APP_VERSION };
        this.uploadFile(n, "ImgLoad", i, a);
    }
    doKycResubmitSava(e, t, i, a = 0, n = 0) {
        let o = sys.now(), h = { aad_card: e, pan_card: t, uid: ToolUtils.uid, channel_id: GameConfig.CHANNEL_ID, phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: o, os: TransferPlatform.shared().getOS(), rver: GameConfig.NEW_APP_VERSION, free_cash_scene: a, free_cash_link_id: n, latitude: TransferPlatform.shared().getLatitude(), longitude: TransferPlatform.shared().getLongitude() };
        this.httpRequest(NetConfig.doKycSaveAccount, "ResubmitKyc.doSave", h, i, "", 0, 15000);
    }
    doGetKycFormItem(e) {
        let t = sys.now(), i = { uid: ToolUtils.uid, channel_id: GameConfig.CHANNEL_ID, phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: t, os: TransferPlatform.shared().getOS(), rver: GameConfig.NEW_APP_VERSION };
        this.httpRequest(NetConfig.doGetKycAccount, "Kyc.getFormItem", i, e, "", 0, 15000);
    }
    doGetModuleSwitch(e) {
        let t = sys.now(), i = { channel_id: GameConfig.CHANNEL_ID, phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: t, os: TransferPlatform.shared().getOS(), rver: GameConfig.NEW_APP_VERSION };
        sys.isObjectValid(ToolUtils.uid) && ToolUtils.uid > 0 && (i.uid = ToolUtils.uid);
        this.httpRequestBeforeLogin(NetConfig.doModuleSwitch, "Sw.get", i, e);
    }
    doGetSuperVipHelp(e) {
        let t = sys.now(), i = { uid: ToolUtils.uid, channel_id: GameConfig.CHANNEL_ID, phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: t, os: TransferPlatform.shared().getOS(), rver: GameConfig.NEW_APP_VERSION };
        this.httpRequest("Player.Vip.rule", "Player.Vip.rule", i, e);
    }
    doGetBannerShowRequest(e, t = [], i) {
    }
    addZore(e, t) {
        let i = e.toString().length;
        for (; i < t;) {
            e = "0" + e;
            i++;
        }
        return e;
    }
    doCommonLogin(e, t, i) {
        ToolUtils.report_time_param.req_Login = sys.now();
        let a = sys.now(), r = { channel_id: TransferPlatform.shared().getChannelId(), phoneimei: TransferPlatform.shared().getPhoneIMEI(), gaid: TransferPlatform.shared().getGaid(), ts: a, rver: GameConfig.NEW_APP_VERSION, cver: TransferPlatform.shared().getAppVersionCode(), adjust_id: TransferPlatform.shared().getAdjust_Adid(), appsflyer_id: TransferPlatform.shared().getAppsflyer_Adid(), pushid: TransferPlatform.shared().getFirebasePushId(), firebase_id: TransferPlatform.shared().getAppInstanceId(), latitude: TransferPlatform.shared().getLatitude(), longitude: TransferPlatform.shared().getLongitude(), apkType: TransferPlatform.shared().getAndroidGpType(), bdid: TransferPlatform.shared().getBePowerId(), cdkey: TransferPlatform.shared().getDeepLinkCdKey(), utm_referral: TransferPlatform.shared().getInstallRefer(false), req_key: i };
        null != e.tel_no && (r.tel_no = e.tel_no);
        null != e.code && (r.code = e.code);
        null != e.pwdtoken && (r.pwdtoken = e.pwdtoken);
        null != e.logintype && (r.logintype = e.logintype);
        null != e.account && (r.account = e.account);
        null != e.src && (r.src = e.src);
        null != e.access_token && (r.access_token = e.access_token);
        let n = TransferPlatform.shared().getAppInstallData();
        if (n.hasInstall && n.channelId.length > 0) {
            r.invite_code = n.channelId;
        }
        else {
            let e = TransferPlatform.shared().getInstallRefer();
            e.length > 0 && (r.invite_code = e);
        }
        r.os_device = TransferPlatform.shared().getOsDeviceInfo();
        r.is_new_kyc = TransferPlatform.shared().getIsNewKyc() ? 1 : 0;
        r.mobile_data = ToolUtils.toJsonString({ emulator: TransferPlatform.shared().getIsRunningOnEmulator(), lightSensor: TransferPlatform.shared().getHasLightSensor(), phoneCpu: TransferPlatform.shared().getIsPhoneCpu(), flash: TransferPlatform.shared().getIsSupportCameraLedFlash(), blueTooth: TransferPlatform.shared().getHasBluetooth(), gps: TransferPlatform.shared().getHasGPS(), screen: GameConfig.REAL_SCREEN_WIDTH + "*" + GameConfig.REAL_SCREEN_HEIGHT, cpu: TransferPlatform.shared().getDeviceCpuName(), cpu_hz: TransferPlatform.shared().getDeviceCpuHz(), mem: TransferPlatform.shared().getDeviceMemory(), level: TransferPlatform.shared().getDeviceLevel(), avi_men: TransferPlatform.shared().getAvailueMemory(), sys_ver: TransferPlatform.shared().getMobileRelease(), phe_type: TransferPlatform.shared().getPhoneBrand() + " " + TransferPlatform.shared().getDeviceType(), platform: sys.os });
        this.httpRequest("Player.LoginProxy.do_login", "Player.LoginProxy.do_login", r, t);
    }
}
