// @ts-nocheck
// Recovered from index.js:271
import { _decorator, Label } from "cc";
import PushEvent from "./PushEvent";
import SoundManager from "./SoundManager";
import { MyComponent } from "./MyComponent";
const { ccclass, property } = _decorator;
@ccclass("LuckCountDown")
export class LuckCountDown extends MyComponent {
    @property(Label)
    public timeLabel1: Label = null;
    @property(Label)
    public timeLabel2: Label = null;
    @property(Label)
    public timeLabel3: Label = null;
    @property(Label)
    public timeLabel4: Label = null;
    public residueTime: number = 0;
    public gameState: number = 0;
    public mCallback: any = null;
    public lastMiao: string = "-1";
    start() {
        this.schedule((t => {
            if (this.residueTime -= 1000 * t, this.residueTime < 0) {
                return this.timeLabel1.string = "0", this.timeLabel2.string = "0", this.timeLabel3.string = "0", void (this.timeLabel4.string = "0");
            }
            this.updateTimeLabel();
        }));
    }
    setData(t, e, i) {
        this.residueTime = t;
        1 != e && (this.gameState = e, this.mCallback = i, this.updateTimeLabel());
    }
    updateTimeLabel() {
        if (this.timeLabel1.string = Math.floor(this.residueTime / 600000).toString(), 600000 == this.residueTime) {
            this.timeLabel1.string = "1";
            this.timeLabel2.string = "0";
            this.timeLabel3.string = "0";
            this.timeLabel4.string = "0";
        }
        else if (60000 == this.residueTime) {
            this.timeLabel1.string = "0";
            this.timeLabel2.string = "1";
            this.timeLabel3.string = "0";
            this.timeLabel4.string = "0";
        }
        else if (10000 == this.residueTime) {
            this.timeLabel1.string = "0";
            this.timeLabel2.string = "0";
            this.timeLabel3.string = "1";
            this.timeLabel4.string = "0";
        }
        else {
            let t = this.residueTime % 600000;
            this.timeLabel2.string = t > 60000 ? Math.floor(t / 60000).toString() : "0";
            let e = t % 60000;
            this.timeLabel3.string = e > 10000 ? Math.floor(e / 10000).toString() : "0";
            this.timeLabel4.string = Math.floor(e % 10000 / 1000).toString();
        }
        0 == this.gameState && Number(this.timeLabel4.string) <= 5 && this.residueTime <= 6000 && Number(this.timeLabel4.string) > -1 && (this.mCallback && this.mCallback(Number(this.timeLabel4.string)), this.emitEvent(PushEvent.LuckBallCountDownEvent), this.timeLabel4.string != this.lastMiao && (this.lastMiao = this.timeLabel4.string, "0" == this.timeLabel4.string ? SoundManager.shared().playFx("luckball_0") : SoundManager.shared().playFx("luckball_countdown")));
    }
}
