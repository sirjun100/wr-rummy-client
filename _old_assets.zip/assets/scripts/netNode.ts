// @ts-nocheck
// Recovered from index.js:321
import { _decorator, Component, director } from "cc";
import Server from "./Server";
import Base64 from "./Base64";
import GameConfig from "./GameConfig";
import { TLog } from "./TLog";
import NetConfig from "./NetConfig";
import CompressUtils from "./CompressUtils";
import { ToolUtils } from "./ToolUtils";
const { ccclass } = _decorator;
@ccclass("NetNode")
export default class netNode extends Component {
    start() {
        this.schedule(this.onUpdate.bind(this), 0.025);
    }
    onDestroy() {
        director.getScheduler().unschedule(this.onUpdate.bind(this), this);
    }
    onUpdate(e) {
        Server.shared().checkConnection();
        const deadline = Date.now() + 4;
        for (let count = 0; count < 32; count++) {
            const message = Server.shared().update(e);
            if (message == null) break;
            this.processMessage(message);
            if (!this.isValid || Date.now() >= deadline) break;
        }
    }
    processMessage(t) {
        if (null != t) {
            try {
                let e = null;
                if (1 == GameConfig.SOCKET_COMPRESS_SWITCH) {
                    let r = null;
                    "string" == typeof t ? (r = Base64.shared().decode(t), e = Server.shared().arrayBuf2Str(ToolUtils.gm_xorfunc(r, Server.shared()._key))) : (r = CompressUtils.uncompress(new Uint8Array(t)), e = Server.shared().arrayBuf2Str(ToolUtils.gm_xorfunc(r, Server.shared()._key)));
                }
                else {
                    let r = Server.shared().arrayBuf2Str(ToolUtils.gm_xorfunc(t, Server.shared()._key));
                    e = Base64.shared().decode(r);
                }
                if (e) {
                    let t = ToolUtils.parseJson(e);
                    if (-1 != t.cmd) {
                        if (GameConfig.GAME_SOCKET_MSG_DEBUG && GameConfig.HTTP_MSG_DEBUG && t.cmd != NetConfig.SERVER_GAME_HEARTBEAT_BC && t.cmd != NetConfig.HEARTBEAT_CMD) {
                            try {
                                JSON.stringify(t, null, 2);
                            }
                            catch (e) {
                                TLog.printError("receive game dispatch game cmd err");
                            }
                        }
                        Server.shared().dispatch(t.cmd, t);
                    }
                    else {
                        GameConfig.GAME_SOCKET_MSG_DEBUG;
                    }
                }
            }
            catch (e) {
                TLog.printError("trycatch NetNode,error:", e);
            }
        }
    }
}
