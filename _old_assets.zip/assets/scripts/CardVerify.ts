// @ts-nocheck
// Recovered from index.js:57
import { _decorator, assetManager, Button, color, EditBox, HorizontalTextAlignment, Label, Node, ScrollView, size, Sprite, SpriteFrame, sys, UITransform, v3, Vec3, Widget } from "cc";
import BaseLayer from "./BaseLayer";
import SoundManager from "./SoundManager";
import { TransferPlatform } from "./TransferPlatform";
import PushCenter from "./PushCenter";
import GameConfig from "./GameConfig";
import { TLog } from "./TLog";
import Utils from "./Utils";
import User from "./User";
import HttpManager from "./HttpManager";
import PushEvent from "./PushEvent";
import CommDefine, { CheckModule } from "./CommDefine";
import i18nMgr from "./i18nMgr";
import TweenTool from "./TweenTool";
import ReportConfig from "./ReportConfig";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("CardVerify")
export class CardVerify extends BaseLayer {
    @property(Node)
    public rootNode: Node = null;
    @property(Node)
    public titleNode: Node = null;
    @property(ScrollView)
    public scrollView: ScrollView = null;
    @property(Node)
    public errTipNode: Node = null;
    @property(Node)
    public panelCenter: Node = null;
    @property(Node)
    public frontBtn: Node = null;
    @property(Button)
    public frontBtn2: Button = null;
    @property(Node)
    public backBtn: Node = null;
    @property(Button)
    public backBtn2: Button = null;
    @property(Node)
    public frontErrNode: Node = null;
    @property(Node)
    public nameNode: Node = null;
    @property(Node)
    public nameEditBg_btn: Node = null;
    @property(Node)
    public cardNumberNode: Node = null;
    @property(Node)
    public dateBirthNode: Node = null;
    @property(Node)
    public tipsNode: Node = null;
    @property([SpriteFrame])
    public btnSpriteFrame: SpriteFrame[] = [];
    public cardTypeIndex: number = 0;
    public typeArray: any[] = [];
    public frontImgPath: any = null;
    public backImgPath: any = null;
    public imgType: number = 0;
    public frontImgName: string = "";
    public backImgName: string = "";
    public nameStr: string = "";
    public gender: number = 1;
    public cardNumberStr: string = "";
    public strDay: string = "";
    public strMonth: string = "";
    public strYear: string = "";
    public scrollItemPosY: number = 0;
    public isLoadingImg: boolean = false;
    public bShowPushAnim: boolean = false;
    public showUICallback: any = null;
    public closeUICallBack: any = null;
    public _closed: boolean = false;
    public _step: number = 0;
    public _frontImgDataStr: string = "";
    public _backImgDataStr: string = "";
    public _bFrontCanUpdate: boolean = false;
    public _bBackCanUpdate: boolean = false;
    public _uploadImgSize: any = size(320, 194);
    public _bBtnEnable: boolean = true;
    public _phont_birthday: string = "";
    onLoad() {
        if (ToolUtils.isSafeString(User.shared().kyc_bottom_tip).length > 0) {
            this.tipsNode.getComponent(Label).string = User.shared().kyc_bottom_tip;
        }
        else {
            let e = i18nMgr.shared().getValueByKey("kyc.kyc_18tips");
            this.tipsNode.getComponent(Label).string = e;
        }
    }
    dealMultipleLanguages() {
        if (2 == i18nMgr.shared().language || 3 == i18nMgr.shared().language) {
            this.panelCenter.getChildByName("tips2").getComponent(Label).fontSize = 18;
            this.panelCenter.getChildByName("tips2").getComponent(Label).lineHeight = 22;
            this.panelCenter.getChildByName("tips2").getComponent(Label).horizontalAlign = HorizontalTextAlignment.LEFT;
            let e = new Vec3;
            this.panelCenter.getChildByName("tips1").getPosition(e);
            this.panelCenter.getChildByName("tips1").setPosition(v3(e.x, e.y + 10));
            3 == i18nMgr.shared().language && (this.panelCenter.getChildByName("name_title").getComponent(Label).horizontalAlign = HorizontalTextAlignment.LEFT, this.panelCenter.getChildByName("card_title").getComponent(Label).horizontalAlign = HorizontalTextAlignment.LEFT, this.panelCenter.getChildByName("date_title").getComponent(Label).horizontalAlign = HorizontalTextAlignment.LEFT);
        }
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().removeListenersByTag(this);
        this.unscheduleAllCallbacks();
        this.isLoadingImg && Utils.shared().hideToast();
    }
    init(e, t = null, a = null) {
        this.bShowPushAnim = e;
        this.showUICallback = t;
        this.closeUICallBack = a;
    }
    start() {
        super.start();
        this.initView();
        this.bShowPushAnim && ToolUtils.showPushAnim(this.node, 0, (() => {
            this.showUICallback && this.showUICallback();
        }));
        PushCenter.shared().addListener(GameConfig.GetLocalImage, (e => {
            if (ToolUtils.isObjValid(this.node)) {
                0 == this.imgType ? this.frontImgPath = e.img_path : this.backImgPath = e.img_path;
                let t = e.img_path;
                try {
                    let e = this;
                    this.isLoadingImg = true;
                    assetManager.loadRemote(t, (function (a, i) {
                        if (null != a) {
                            return void Utils.shared().hideToast();
                        }
                        const s = SpriteFrame.createWithImage(i);
                        let r;
                        r = 0 == e.imgType ? e.panelCenter.getChildByName("front_img") : e.panelCenter.getChildByName("back_img");
                        r.getComponent(Sprite).spriteFrame = s;
                        r.getComponent(UITransform).setContentSize(e._uploadImgSize);
                        e.isLoadingImg = false;
                        0 == e.imgType ? (TransferPlatform.shared().image2Text(t, "MainHall", e, "onFrontImgToText"), ToolUtils.isObjValid(e.node) && !TransferPlatform.shared().getIsCanOCR() ? e.doUploadFrontImg() : Utils.shared().hideToast()) : (Utils.shared().hideToast(), TransferPlatform.shared().image2Text(t, "MainHall", e, "onBackImgToText"));
                    }));
                }
                catch (e) {
                    TLog.printError("Card verify cardImage.spriteFrame:", e);
                    Utils.shared().hideToast();
                }
            }
        }), this);
        PushCenter.shared().addListener(GameConfig.Update_Kyc, (() => {
            if (ToolUtils.isObjValid(this.node) && (this.updateCardVerifyView(), 2 == User.shared().data.card_check)) {
                let e = false;
                if (sys.isObjectValid(User.shared().newKycData.collect_list) && Array.isArray(User.shared().newKycData.collect_list)) {
                    for (let t = 0; t < User.shared().newKycData.collect_list.length; t++) {
                        if (2 == User.shared().newKycData.collect_list[t].type) {
                            e = true;
                            this.updateErrTips();
                            break;
                        }
                    }
                }
                e || (this.bShowPushAnim = false, this.onBackView());
            }
        }), this);
        HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Hall, event: ReportConfig.hall_evt.enter_kyc_verify });
        this.dealMultipleLanguages();
    }
    onFrontImgToText(e) {
        this._frontImgDataStr = e;
        try {
            this.autoDealFrontImgText();
        }
        catch (e) {
            TLog.printError("------- onFrontImgToText err", e);
        }
    }
    autoDealFrontImgText() {
        let e = sys.isObjectValid(User.shared().newKycData.photo_clear_level) ? User.shared().newKycData.photo_clear_level : 1;
        if (this._bFrontCanUpdate = 3 == e, this._frontImgDataStr.length > 10) {
            this.strYear = "";
            this.strMonth = "";
            this.strDay = "";
            this.updateDateBirthView2();
            this.updateNameView2("");
            this.updateCardNumberView2("");
            let t = this._frontImgDataStr.split("###");
            if (t.length >= 4) {
                let a, i = -1, s = -1, r = -1, n = -1, h = false, o = "", d = ["governme", "overnmen", "vernment", "ernmento", "rnmentof", "nmentofi", "mentofin", "entofind", "ntofindi", "tofindia"], l = ["Yearo", "earof", "arofB", "rofBi", "ofBir", "fBirt", "Birth", "irth:"], c = ["Father:", "ather:"];
                for (let e = 0; e < t.length; e++) {
                    if (a = t[e].repeat(1), a = a.replace(/ /g, ""), -1 == i) {
                        let t = a.toLowerCase();
                        for (let a = 0; a < d.length; a++) {
                            if (-1 != t.indexOf(d[a])) {
                                i = e;
                                break;
                            }
                        }
                        if (i >= 0) {
                            continue;
                        }
                    }
                    if (-1 == s) {
                        let t = a.toLowerCase();
                        if ((-1 != t.indexOf("male") || -1 != t.indexOf("female")) && (s = e), s >= 0) {
                            continue;
                        }
                    }
                    if (-1 == r) {
                        if (-1 != a.indexOf("DOB")) {
                            r = e;
                        }
                        else if (-1 != a.indexOf("DoB")) {
                            r = e;
                        }
                        else if (-1 != a.indexOf("YoB")) {
                            r = e;
                            h = true;
                        }
                        else {
                            for (let t = 0; t < l.length; t++) {
                                if (-1 != a.indexOf(l[t])) {
                                    r = e;
                                    h = true;
                                    break;
                                }
                            }
                            -1 == r && -1 != a.indexOf("Brith") && (r = e, h = true);
                        }
                        if (r >= 0) {
                            continue;
                        }
                    }
                    if (-1 == n) {
                        const t = /^[0-9]+$/;
                        12 == a.length && t.test(a) && (n = e, o = a);
                    }
                }
                if (i >= 0 && r >= 0 && i < r) {
                    let e = "";
                    for (let a = i + 1; a < r && (-1 === t[a].indexOf(c[0]) || -1 === t[a].indexOf(c[1])); a++) {
                        e += t[a];
                    }
                    e.length > 0 && this.updateNameView2(e);
                }
                if (12 == o.length && this.updateCardNumberView2(o), r >= 0) {
                    let e = t[r].repeat(1);
                    e = e.replace(/ /g, "");
                    e = e.replace(/[a-zA-Z]+/g, "");
                    let a = e.split(":");
                    a.length > 1 && (e = a[1]);
                    let i = e.split("/");
                    if (3 == i.length) {
                        const e = /\d+/g, t = i[0].match(e);
                        if (t) {
                            let e = t.map(Number);
                            if (1 == e.length) {
                                let t = Math.floor(Number(e[0]));
                                t >= 1 && t <= 31 && (1 == String(t).length ? this.strDay = ToolUtils.format("0${0}", "" + t) : this.strDay = ToolUtils.format("${0}", "" + t));
                            }
                        }
                        let a = Math.floor(Number(i[1]));
                        a >= 1 && a <= 12 && (1 == String(a).length ? this.strMonth = ToolUtils.format("0${0}", "" + a) : this.strMonth = ToolUtils.format("${0}", "" + a));
                        this.strYear = i[2];
                    }
                    else {
                        h && (this.strYear = "", this.strMonth = "", this.strDay = "");
                    }
                    this.strYear.length > 0 && this.strMonth.length > 0 && this.strDay.length > 0 && this.updateDateBirthView2();
                }
                1 == e ? i >= 0 && s >= 0 && r >= 0 && n >= 0 ? (this._bFrontCanUpdate = true, this.frontErrNode.active = false, this.updateBtnStatus(1, 2)) : (sys.isObjectValid(User.shared().data.open_signzy) && 1 == Number(User.shared().data.open_signzy) && (this.frontErrNode.active = true), this.updateBtnStatus(1, 1)) : (this._bFrontCanUpdate = true, this.frontErrNode.active = false);
            }
            else {
                sys.isObjectValid(User.shared().data.open_signzy) && 1 == Number(User.shared().data.open_signzy) && 1 == e && (this.frontErrNode.active = true, this.updateBtnStatus(1, 1));
            }
        }
        else {
            sys.isObjectValid(User.shared().data.open_signzy) && 1 == Number(User.shared().data.open_signzy) && 1 == e && (this.frontErrNode.active = true, this.updateBtnStatus(1, 1));
            TransferPlatform.shared().getIsCanOCR() || (this._bFrontCanUpdate = true, this.frontErrNode.active = false);
        }
    }
    onBackImgToText(e) {
        this._backImgDataStr = e;
        try {
            this.autoDealBackImgText();
        }
        catch (e) {
            TLog.printError("------- onBackImgToText err", e);
        }
        this._bBackCanUpdate = true;
    }
    autoDealBackImgText() {
        let e = sys.isObjectValid(User.shared().newKycData.photo_clear_level) ? User.shared().newKycData.photo_clear_level : 1;
        this._bBackCanUpdate = 3 == e;
        this._backImgDataStr.length > 10 ? (this._bBackCanUpdate = true, 1 == e && this.updateBtnStatus(2, 2)) : TransferPlatform.shared().getIsCanOCR() ? 1 == e && this.updateBtnStatus(2, 1) : (this._bBackCanUpdate = true, 1 == e && this.updateBtnStatus(2, 2));
    }
    updateBtnStatus(e, t) {
        try {
            let a = 1 == e ? this.frontBtn : this.backBtn, i = 1 == e ? this.frontBtn2 : this.backBtn2;
            0 == t ? (a.getChildByName("img").getComponent(Sprite).spriteFrame = this.btnSpriteFrame[0], 1 == e ? i18nMgr.shared().changeLabelLanguage(a.getChildByName("wz").getComponent(Label), "kyc.upload_front", true) : i18nMgr.shared().changeLabelLanguage(a.getChildByName("wz").getComponent(Label), "kyc.upload_back", true), a.getChildByName("wz").active = true, a.getChildByName("gou").active = false, a.getComponent(Button).interactable = true, i.interactable = true) : 1 == t ? (a.getChildByName("img").getComponent(Sprite).spriteFrame = this.btnSpriteFrame[0], i18nMgr.shared().changeLabelLanguage(a.getChildByName("wz").getComponent(Label), "kyc.reUpload", true), a.getChildByName("wz").active = true, a.getChildByName("gou").active = false, a.getComponent(Button).interactable = true, i.interactable = true) : 2 == t && (a.getChildByName("img").getComponent(Sprite).spriteFrame = this.btnSpriteFrame[1], a.getChildByName("wz").active = false, a.getChildByName("gou").active = true, a.getComponent(Button).interactable = false, i.interactable = false);
        }
        catch (e) {
        }
    }
    onCloseButtonClick(e, t) {
        if (SoundManager.shared().playFx("click"), "back_btn" == t) {
            if (this._closed) {
                return;
            }
            this.onBackView();
        }
    }
    initView() {
        this.fitScreen();
        2 == User.shared().data.card_check ? sys.isObjectValid(User.shared().newKycData.collect_list) && User.shared().newKycData.collect_list.length > 0 ? this.updateCardVerifyView(true) : (Utils.shared().showLoading(10, true, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3);
        })), HttpManager.shared().doGetKycAccount2(this.listenGetKycAccountCallback.bind(this))) : sys.isObjectValid(User.shared().newKycData.form_list) && User.shared().newKycData.form_list.length > 0 ? this.updateCardVerifyView(true) : (Utils.shared().showLoading(10, true, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3);
        })), HttpManager.shared().doGetKycAccount2(this.listenGetKycAccountCallback.bind(this)));
    }
    listenGetKycAccountCallback(e, t, a) {
        try {
            if (200 != a) {
                alert("The login timed out, please try again");
            }
            else {
                let e = ToolUtils.parseJson(t);
                0 == e.ret && (User.shared().newKycData = e.data, ToolUtils.isObjValid(this.node) && this.updateCardVerifyView());
            }
        }
        catch (e) {
            TLog.printError("listenGetKycVerifyListCallback:", e);
        }
    }
    updateCardVerifyView(e = true) {
        let t = true;
        if (0 == User.shared().data.card_check || 3 == User.shared().data.card_check ? (t = true, this.rootNode.getChildByName("submit_btn").getComponent(Button).interactable = true, 0 == User.shared().data.card_check ? i18nMgr.shared().changeLabelLanguage(this.rootNode.getChildByName("submit_btn").getChildByName("wz").getComponent(Label), "kyc.submit", true) : (Utils.shared().hideLoading(), i18nMgr.shared().changeLabelLanguage(this.rootNode.getChildByName("submit_btn").getChildByName("wz").getComponent(Label), "kyc.resubmit", true))) : (t = false, this.rootNode.getChildByName("submit_btn").getComponent(Button).interactable = false, 1 == User.shared().data.card_check ? i18nMgr.shared().changeLabelLanguage(this.rootNode.getChildByName("submit_btn").getChildByName("wz").getComponent(Label), "kyc.verity_pending", true) : (Utils.shared().hideLoading(), i18nMgr.shared().changeLabelLanguage(this.rootNode.getChildByName("submit_btn").getChildByName("wz").getComponent(Label), "kyc.verity_verified", true))), e && this.updateErrTips(), 3 == User.shared().data.card_check && sys.isObjectValid(User.shared().newKycData.kyc_list) && (ToolUtils.isSafeString(User.shared().newKycData.kyc_list.name).length > 0 && this.updateNameView(User.shared().newKycData.kyc_list.name, t, e), ToolUtils.isSafeString(User.shared().newKycData.kyc_list.card).length > 0 && this.updateCardNumberView(User.shared().newKycData.kyc_list.card, t, e), ToolUtils.isSafeString(User.shared().newKycData.kyc_list.birthday).length > 0 && this.updateDateBirthView(User.shared().newKycData.kyc_list.birthday, t, e)), 2 == User.shared().data.card_check && sys.isObjectValid(User.shared().newKycData.kyc_list)) {
            let t = false;
            sys.isObjectValid(User.shared().newKycData.collect_list) && User.shared().newKycData.collect_list.length > 0 && (t = true);
            ToolUtils.isSafeString(User.shared().newKycData.kyc_list.photo_frontend).length > 0 && this.updateCardTypeView(User.shared().newKycData.kyc_list, t, e);
            ToolUtils.isSafeString(User.shared().newKycData.kyc_list.name).length > 0 && this.updateNameView(User.shared().newKycData.kyc_list.name, t, e);
            ToolUtils.isSafeString(User.shared().newKycData.kyc_list.card).length > 0 && this.updateCardNumberView(User.shared().newKycData.kyc_list.card, t, e);
            ToolUtils.isSafeString(User.shared().newKycData.kyc_list.birthday).length > 0 && this.updateDateBirthView(User.shared().newKycData.kyc_list.birthday, t, e);
            t && (this.rootNode.getChildByName("submit_btn").getComponent(Button).interactable = true, i18nMgr.shared().changeLabelLanguage(this.rootNode.getChildByName("submit_btn").getChildByName("wz").getComponent(Label), "kyc.revise", true));
        }
    }
    updateErrTips() {
        if (2 == User.shared().data.card_check) {
            if (sys.isObjectValid(User.shared().newKycData.collect_list) && Array.isArray(User.shared().newKycData.collect_list)) {
                for (let e = 0; e < User.shared().newKycData.collect_list.length; e++) {
                    if (2 == User.shared().newKycData.collect_list[e].type) {
                        let t = User.shared().newKycData.collect_list[e].reason;
                        if (sys.isObjectValid(t) && t.length > 0) {
                            this.errTipNode.active = true;
                            this.errTipNode.getChildByName("tx").getComponent(Label).string = t;
                            this.errTipNode.getChildByName("tx").getComponent(Label).updateRenderData(true);
                            let e = this.errTipNode.getComponent(UITransform).contentSize, a = this.errTipNode.getChildByName("tx").getComponent(UITransform).contentSize.height + 8;
                            this.errTipNode.getComponent(UITransform).setContentSize(size(e.width, a));
                            this.panelCenter.setPosition(v3(0, -a, 0));
                            e = this.scrollView.content.getComponent(UITransform).contentSize;
                            this.scrollView.content.getComponent(UITransform).setContentSize(size(e.width, 1100 + a));
                        }
                        else {
                            this.errTipNode.active = false;
                            this.errTipNode.getChildByName("tx").getComponent(Label).string = "";
                            this.panelCenter.setPosition(v3(0, 0, 0));
                            let e = this.scrollView.content.getComponent(UITransform).contentSize;
                            this.scrollView.content.getComponent(UITransform).setContentSize(size(e.width, 1100));
                        }
                        break;
                    }
                }
            }
        }
        else if (sys.isObjectValid(User.shared().newKycData.kyc_list) && ToolUtils.isSafeString(User.shared().newKycData.kyc_list.reason).length > 0) {
            this.errTipNode.active = true;
            this.errTipNode.getChildByName("tx").getComponent(Label).string = User.shared().newKycData.kyc_list.reason;
            this.errTipNode.getChildByName("tx").getComponent(Label).updateRenderData(true);
            let e = this.errTipNode.getComponent(UITransform).contentSize, t = this.errTipNode.getChildByName("tx").getComponent(UITransform).contentSize.height + 8;
            this.errTipNode.getComponent(UITransform).setContentSize(size(e.width, t));
            this.panelCenter.setPosition(v3(0, -t, 0));
            e = this.scrollView.content.getComponent(UITransform).contentSize;
            this.scrollView.content.getComponent(UITransform).setContentSize(size(e.width, 1100 + t));
        }
        else {
            this.errTipNode.active = false;
            this.errTipNode.getChildByName("tx").getComponent(Label).string = "";
            this.panelCenter.setPosition(v3(0, 0, 0));
            let e = this.scrollView.content.getComponent(UITransform).contentSize;
            this.scrollView.content.getComponent(UITransform).setContentSize(size(e.width, 1100));
        }
    }
    updateCardTypeView(e, t, a = true) {
        let i = this.panelCenter.getChildByName("front_img"), s = this.panelCenter.getChildByName("back_img");
        a && (this.frontImgPath, this.backImgPath, e.photo_frontend && e.photo_frontend.length > 0 ? (this.frontImgName = e.photo_frontend, Utils.shared().updateNetImage(i.getComponent(Sprite), User.shared().data.kyc_imgPath + e.photo_frontend, this._uploadImgSize), t ? this.updateBtnStatus(1, 1) : this.updateBtnStatus(1, 2)) : (this.frontImgName = "", i.getComponent(Sprite).spriteFrame = null, this.updateBtnStatus(1, 0)), e.photo_backend && e.photo_backend.length > 0 ? (this.backImgName = e.photo_frontend, Utils.shared().updateNetImage(s.getComponent(Sprite), User.shared().data.kyc_imgPath + e.photo_backend, this._uploadImgSize), t ? this.updateBtnStatus(2, 1) : this.updateBtnStatus(2, 2)) : (this.backImgName = "", s.getComponent(Sprite).spriteFrame = null, this.updateBtnStatus(2, 0)));
    }
    updateNameView(e = "", t, a = true) {
        a && (this.nameStr = e, this.nameNode.getChildByName("del_btn").active = false);
        this.nameNode.getChildByName("EditBox").getComponent(EditBox).string = this.nameStr;
        this.nameNode.getChildByName("content").getComponent(Label).string = this.nameStr;
        this.nameNode.getChildByName("EditBox").active = t;
        this.nameNode.getChildByName("content").active = !t;
    }
    updateNameView2(e) {
        this.nameStr = e;
        this.nameNode.getChildByName("EditBox").getComponent(EditBox).string = this.nameStr;
        this.nameNode.getChildByName("content").getComponent(Label).string = this.nameStr;
        this.nameNode.getChildByName("EditBox").active = true;
        this.nameNode.getChildByName("content").active = false;
        this.nameNode.getChildByName("del_btn").active = ToolUtils.isSafeString(this.nameStr).length > 0;
    }
    updateCardNumberView(e = "", t, a = true) {
        a && (this.cardNumberStr = e, this.cardNumberNode.getChildByName("del_btn").active = false);
        this.cardNumberNode.getChildByName("EditBox").getComponent(EditBox).string = this.cardNumberStr;
        this.cardNumberNode.getChildByName("content").getComponent(Label).string = this.cardNumberStr;
        this.cardNumberNode.getChildByName("EditBox").active = t;
        this.cardNumberNode.getChildByName("content").active = !t;
        this.cardNumberNode.getChildByName("EditBox").getComponent(EditBox).inputMode = EditBox.InputMode.NUMERIC;
        this.cardNumberNode.getChildByName("EditBox").getComponent(EditBox).maxLength = 12;
        i18nMgr.shared().changeLabelLanguage(this.cardNumberNode.getChildByName("EditBox").getComponent(EditBox).placeholderLabel, "Enter aadhaar No.");
    }
    updateCardNumberView2(e) {
        this.cardNumberStr = e;
        this.cardNumberNode.getChildByName("EditBox").getComponent(EditBox).string = this.cardNumberStr;
        this.cardNumberNode.getChildByName("content").getComponent(Label).string = this.cardNumberStr;
        this.cardNumberNode.getChildByName("EditBox").active = true;
        this.cardNumberNode.getChildByName("content").active = false;
        this.cardNumberNode.getChildByName("del_btn").active = ToolUtils.isSafeString(this.cardNumberStr).length > 0;
    }
    updateDateBirthView(e = "", t, a = true) {
        if (this.dateBirthNode.getChildByName("birthdate").getComponent(Button).interactable = t, this.dateBirthNode.getChildByName("birthdate").getChildByName("icon").active = t, a) {
            if (e && e.length > 0) {
                let t = String(e).split("/");
                this.strDay = t[0];
                this.strMonth = t[1];
                this.strYear = t[2];
            }
            else {
                var i = new Date;
                this.strYear = ToolUtils.format("${0}", i.getFullYear() - 18);
                this.strMonth = ToolUtils.format("0${0}", i.getMonth() + 1).slice(-2);
                this.strDay = ToolUtils.format("0${0}", i.getDate()).slice(-2);
            }
        }
        this.dateBirthCallBack(this.strDay, this.strMonth, this.strYear);
    }
    updateDateBirthView2() {
        this.dateBirthNode.getChildByName("birthdate").getComponent(Button).interactable = true;
        this.dateBirthNode.getChildByName("birthdate").getChildByName("icon").active = true;
        this.dateBirthCallBack(this.strDay, this.strMonth, this.strYear);
    }
    onButtonClick(e, t) {
        if ("male" != t && "female" != t && SoundManager.shared().playFx("click"), "front" == t) {
            this.isLoadingImg || (this.imgType = 0, Utils.shared().showKycPhotoView(this.node, this.photoCallBack.bind(this)));
        }
        else if ("back" == t) {
            this.isLoadingImg || (this.imgType = 1, Utils.shared().showKycPhotoView(this.node, this.photoCallBack.bind(this)));
        }
        else if ("front_del" == t) {
            this.panelCenter.getChildByName("front_bg").active = true;
            this.panelCenter.getChildByName("front_btn").active = true;
            this.panelCenter.getChildByName("front_del_btn").active = false;
            this.panelCenter.getChildByName("front_img").getComponent(Sprite).spriteFrame = null;
            this.frontImgName = "";
            this.frontImgPath = null;
        }
        else if ("back_del" == t) {
            this.panelCenter.getChildByName("back_bg").active = true;
            this.panelCenter.getChildByName("back_btn").active = true;
            this.panelCenter.getChildByName("back_del_btn").active = false;
            this.panelCenter.getChildByName("back_img").getComponent(Sprite).spriteFrame = null;
            this.backImgName = "";
            this.backImgPath = null;
        }
        else if ("name_del" == t) {
            let e = this.nameNode.getChildByName("EditBox");
            e.getComponent(EditBox).string = "";
            e.getComponent(EditBox).blur();
            this.updateNameStatus();
        }
        else if ("cardnumber_del" == t) {
            let e = this.cardNumberNode.getChildByName("EditBox");
            e.getComponent(EditBox).string = "";
            e.getComponent(EditBox).blur();
            this.updateCardNumberStatus();
        }
        else if ("date_birth" == t) {
            Utils.shared().showSelectDateView(this.node, this.dateBirthCallBack.bind(this), this.strDay, this.strMonth, this.strYear);
        }
        else if ("noEditName" == t) {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("kyc.no_edit_name_tips"), 2);
        }
        else if ("kefu" == t) {
            if (1 == User.shared().temp_pingbi.feedback) {
                return void Utils.shared().showToast("Coming soon", 2);
            }
            let e = { sourceType: CommDefine.TawkUser_Feedback_Source.Kyc, groupType: CommDefine.TawkUser_Feedback_Source.Kyc_Group.Verify };
            Utils.shared().doJumpLogic(PushEvent.JUMP_TO_FEEDBACK, e);
        }
    }
    photoCallBack(e) {
        let t = sys.now() + ".jpg";
        "takephoto" == e ? TransferPlatform.shared().openCamera(t, 1, GameConfig.REAL_SCREEN_HEIGHT, GameConfig.REAL_SCREEN_HEIGHT) : TransferPlatform.shared().openPhoto(t, 1, GameConfig.REAL_SCREEN_HEIGHT, GameConfig.REAL_SCREEN_HEIGHT);
    }
    dateBirthCallBack(e, t, a) {
        this.strDay = e;
        this.strMonth = t;
        this.strYear = a;
        let i = this.dateBirthNode.getChildByName("birthdate");
        sys.isObjectValid(i) && (i.getChildByName("wz").getComponent(Label).string = ToolUtils.format("${0}/${1}/${2}", this.strDay, this.strMonth, this.strYear), i.getChildByName("wz").getComponent(Label).color = color(49, 49, 49));
    }
    updateNameStatus() {
        if (this.nameNode) {
            let e = this.nameNode.getChildByName("EditBox");
            this.nameStr = ToolUtils.isSafeString(e.getComponent(EditBox).string);
            this.nameStr.length > 0 && (0 == User.shared().data.card_check || 3 == User.shared().data.card_check) ? this.nameNode.getChildByName("del_btn").active = true : this.nameNode.getChildByName("del_btn").active = false;
        }
    }
    updateCardNumberStatus() {
        if (this.cardNumberNode) {
            let e = this.cardNumberNode.getChildByName("EditBox");
            this.cardNumberStr = ToolUtils.isSafeString(e.getComponent(EditBox).string);
            this.cardNumberStr.length > 0 && (0 == User.shared().data.card_check || 3 == User.shared().data.card_check) ? this.cardNumberNode.getChildByName("del_btn").active = true : (this.cardNumberNode.getChildByName("del_btn").active = false, 2 == User.shared().data.card_check && sys.isObjectValid(User.shared().newKycData.collect_list) && Array.isArray(User.shared().newKycData.collect_list) && this.cardNumberStr.length > 0 && (this.cardNumberNode.getChildByName("del_btn").active = true));
        }
    }
    onEditBoxChanged(e, t, a) {
        "name" == a ? this.updateNameStatus() : "card_number" == a && this.updateCardNumberStatus();
    }
    onEditBoxEnded(e, t) {
        "name" == t ? this.updateNameStatus() : "card_number" == t && this.updateCardNumberStatus();
    }
    onSumbitButtonClick(e, t) {
        if (SoundManager.shared().playFx("click"), !this._bBtnEnable) {
            return;
        }
        if (this._bBtnEnable = false, TweenTool.delayAct(this.node, (() => {
            this._bBtnEnable = true;
        }), 1, true), !User.shared().checkLocationPermit(CheckModule.KYC)) {
            return;
        }
        if (HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Hall, event: ReportConfig.hall_evt.click_kyc_submit }), 2 == User.shared().data.card_check) {
            if (sys.isObjectValid(User.shared().newKycData.collect_list) && Array.isArray(User.shared().newKycData.collect_list)) {
                for (let e = 0; e < User.shared().newKycData.collect_list.length; e++) {
                    if (2 == User.shared().newKycData.collect_list[e].type) {
                        User.shared().newKycData.collect_list[e].reason = "";
                        this.updateErrTips();
                        break;
                    }
                }
            }
        }
        else {
            sys.isObjectValid(User.shared().newKycData.kyc_list) && sys.isObjectValid(User.shared().newKycData.kyc_list.reason) && User.shared().newKycData.kyc_list.reason > 0 && (User.shared().newKycData.kyc_list.reason = "", User.shared().newKycData.kyc_list.fast_reason = "", User.shared().newKycData.kyc_list.trigger_age_pop = 0, this.updateErrTips());
        }
        let a = sys.isObjectValid(User.shared().newKycData.photo_clear_level) ? User.shared().newKycData.photo_clear_level : 1;
        if (a < 3 && ("" === this.frontImgName && null === this.frontImgPath || "" === this.backImgName && null == this.backImgPath)) {
            return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("kyc.upload_verify_both_image"), 2);
        }
        if (1 == a && sys.isObjectValid(User.shared().data.open_signzy) && 1 == Number(User.shared().data.open_signzy)) {
            if (TransferPlatform.shared().getIsCanOCR() && (0 === this._backImgDataStr.length || 0 === this._frontImgDataStr.length)) {
                return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("kyc.upload_verify_image_fail"), 2);
            }
            if (!this._bBackCanUpdate || !this._bFrontCanUpdate) {
                return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("kyc.upload_verify_image_fail"), 2);
            }
        }
        let i = ToolUtils.isSafeString(this.nameStr), s = ToolUtils.isSafeString(this.cardNumberStr), r = ToolUtils.isSafeString(ToolUtils.format("${0}/${1}/${2}", this.strDay, this.strMonth, this.strYear));
        0 !== i.length ? 12 === s.length ? 0 !== this.strDay.length && 0 != this.strMonth.length && 0 != this.strYear.length ? (Utils.shared().showLoading(30, true, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text37"), 3);
        })), TransferPlatform.shared().getIsCanOCR() ? this.frontImgPath ? HttpManager.shared().doUpdateFile(0, "", this.frontImgPath, ((e, t, a) => {
            if (200 !== a) {
                Utils.shared().hideLoading();
            }
            else {
                try {
                    let e = ToolUtils.parseJson(t);
                    if (0 === e.ret) {
                        this.frontImgName = e.data.imgName;
                        this.doUploadBackImg(i, s, r);
                    }
                    else {
                        e.desc && e.desc.length > 0 && Utils.shared().showToast(e.desc, 2);
                        let t = e.ret + ToolUtils.isSafeString(e.desc);
                        HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Hall, event: ReportConfig.hall_evt.kyc_submit_fail, kyc_err: t });
                    }
                }
                catch (e) {
                    let t = ToolUtils.isSafeString(e.toString());
                    HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Hall, event: ReportConfig.hall_evt.kyc_submit_fail, kyc_err: t });
                }
            }
        })) : this.doUploadBackImg(i, s, r) : this.frontImgPath && 0 == this.frontImgName.length ? this.doUploadFrontImg((() => {
            this.doUploadBackImg(i, s, r);
        })) : this.doUploadBackImg(i, s, r)) : Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text79"), 2) : Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text78"), 2) : Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text77"), 2);
    }
    doUploadFrontImg(e = null) {
        if (ToolUtils.isSafeString(this.frontImgPath).length > 0) {
            let t = this;
            HttpManager.shared().doUploadNewKycFile(this.frontImgPath, ((a, i, s) => {
                if (Utils.shared().hideToast(), 200 !== s) {
                    Utils.shared().hideLoading();
                }
                else {
                    if (!ToolUtils.isObjValid(t.node)) {
                        return;
                    }
                    try {
                        let a = sys.isObjectValid(User.shared().newKycData.photo_clear_level) ? User.shared().newKycData.photo_clear_level : 1, s = ToolUtils.parseJson(i);
                        if (0 === s.ret) {
                            if (t.frontImgName = s.data.img_url, sys.isObjectValid(s.data.img_content) && s.data.img_content.length > 0 ? t._frontImgDataStr = s.data.img_content : t._frontImgDataStr = "", e) {
                                e();
                            }
                            else if (t._bFrontCanUpdate = true, t.frontErrNode.active = false, t.updateBtnStatus(1, 2), sys.isObjectValid(s.data.name) && s.data.name.length > 0 ? t.updateNameView2(s.data.name) : 1 == a && t.updateNameView2(""), sys.isObjectValid(s.data.card) && s.data.card.length > 0 ? t.updateCardNumberView2(s.data.card) : 1 == a && t.updateCardNumberView2(""), this._phont_birthday = "", sys.isObjectValid(s.data.birthday) && s.data.birthday.length > 0) {
                                this._phont_birthday = s.data.birthday;
                                let e = s.data.birthday.split("/");
                                if (3 == e.length) {
                                    const a = /\d+/g, i = e[0].match(a);
                                    if (i) {
                                        let e = i.map(Number);
                                        if (1 == e.length) {
                                            let a = Math.floor(Number(e[0]));
                                            a >= 1 && a <= 31 && (1 == String(a).length ? t.strDay = ToolUtils.format("0${0}", "" + a) : t.strDay = ToolUtils.format("${0}", "" + a));
                                        }
                                    }
                                    let s = Math.floor(Number(e[1]));
                                    s >= 1 && s <= 12 && (1 == String(s).length ? t.strMonth = ToolUtils.format("0${0}", "" + s) : t.strMonth = ToolUtils.format("${0}", "" + s));
                                    t.strYear = e[2];
                                }
                                else {
                                    t.strYear = "";
                                    t.strMonth = "";
                                    t.strDay = "";
                                }
                                t.strYear.length > 0 && t.strMonth.length > 0 && t.strDay.length > 0 && t.updateDateBirthView2();
                            }
                            else {
                                1 == a && (t.strYear = "", t.strMonth = "", t.strDay = "", t.updateDateBirthView2());
                            }
                        }
                        else {
                            s.desc && s.desc.length > 0 && Utils.shared().showToast(s.desc, 2);
                            e || (sys.isObjectValid(User.shared().data.open_signzy) && 1 == Number(User.shared().data.open_signzy) && 1 == a && (t._bFrontCanUpdate = false, t.frontErrNode.active = true, this.strYear = "", this.strMonth = "", this.strDay = "", this.updateDateBirthView2(), this.updateNameView2(""), this.updateCardNumberView2("")), t.updateBtnStatus(1, 1));
                            let i = s.ret + ToolUtils.isSafeString(s.desc);
                            HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Hall, event: ReportConfig.hall_evt.kyc_submit_fail, kyc_err: i });
                        }
                    }
                    catch (e) {
                        let t = ToolUtils.isSafeString(e.toString());
                        HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Hall, event: ReportConfig.hall_evt.kyc_submit_fail, kyc_err: t });
                    }
                }
            }));
        }
    }
    doUploadBackImg(e, t, a) {
        if (this.backImgPath) {
            Utils.shared().showLoading(30, true, (() => {
                Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text37"), 3);
            }), ToolUtils.getIsNormalDirection(), 1);
            HttpManager.shared().doUpdateFile(1, "", this.backImgPath, ((i, s, r) => {
                if (200 !== r) {
                    Utils.shared().hideLoading();
                }
                else {
                    try {
                        let i = ToolUtils.parseJson(s);
                        if (0 === i.ret) {
                            this.backImgName = i.data.imgName;
                            Utils.shared().showLoading(20, true, (() => {
                                Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text37"), 3);
                            }), ToolUtils.getIsNormalDirection(), 1);
                            let s = 0;
                            2 == User.shared().data.card_check && (s = 1);
                            HttpManager.shared().doKycSaveAccount2(this.frontImgName, this.backImgName, t, a, this._phont_birthday, e, this._frontImgDataStr, this._backImgDataStr, 5, this.listenSubmitCall.bind(this), s);
                        }
                        else {
                            i.desc && i.desc.length > 0 && Utils.shared().showToast(i.desc, 2);
                            let e = i.ret + ToolUtils.isSafeString(i.desc);
                            HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Hall, event: ReportConfig.hall_evt.kyc_submit_fail, kyc_err: e });
                        }
                    }
                    catch (e) {
                        let t = ToolUtils.isSafeString(e.toString());
                        HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Hall, event: ReportConfig.hall_evt.kyc_submit_fail, kyc_err: t });
                    }
                }
            }));
        }
        else {
            Utils.shared().showLoading(15, true, (() => {
                Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text37"), 3);
            }), ToolUtils.getIsNormalDirection(), 1);
            let i = 0;
            2 == User.shared().data.card_check && (i = 1);
            HttpManager.shared().doKycSaveAccount2(this.frontImgName, this.backImgName, t, a, this._phont_birthday, e, this._frontImgDataStr, this._backImgDataStr, 5, this.listenSubmitCall.bind(this), i);
        }
    }
    listenSubmitCall(e, t, a) {
        if (200 !== a) {
            ToolUtils.isObjValid(this.node) && (Utils.shared().hideLoading(), Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text37"), 2));
        }
        else {
            try {
                let e = ToolUtils.parseJson(t);
                if (0 === e.ret) {
                    HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Hall, event: ReportConfig.hall_evt.kyc_submit_succ });
                    let t = 0;
                    sys.isObjectValid(e.data.is_sub_data) && (t = ToolUtils.isSafeNumber(e.data.is_sub_data));
                    let a = e.data.card_check;
                    if (1 == t) {
                        return sys.isObjectValid(e.data.collect_list) && Array.isArray(e.data.collect_list) && (User.shared().newKycData.collect_list = e.data.collect_list), void (sys.isObjectValid(e.data.loading_seconds) && Number(e.data.loading_seconds) > 0 ? ToolUtils.isObjValid(this.node) && (1 == a && (this.rootNode.getChildByName("submit_btn").getComponent(Button).interactable = false, i18nMgr.shared().changeLabelLanguage(this.rootNode.getChildByName("submit_btn").getChildByName("wz").getComponent(Label), "kyc.verity_pending", true)), PushCenter.shared().pushEvent(GameConfig.Update_Kyc, User.shared().data.kyc_check), Utils.shared().showLoading(Number(e.data.loading_seconds), true, (() => {
                            Utils.shared().hideLoading();
                            ToolUtils.isObjValid(this.node) && (PushCenter.shared().pushEvent(PushEvent.CloseAgeVerifySelect), PushCenter.shared().pushEvent(PushEvent.Close_FastOtpView), this.onBackView());
                            Utils.shared().showToast(i18nMgr.shared().getValueByKey("kyc.submit_success"), 3.5);
                        }), ToolUtils.getIsNormalDirection(), 1)) : (ToolUtils.isObjValid(this.node) && Utils.shared().hideLoading(), 2 != a && 1 != a || (PushCenter.shared().pushEvent(PushEvent.CloseAgeVerifySelect), PushCenter.shared().pushEvent(PushEvent.Close_FastOtpView), ToolUtils.isObjValid(this.node) && (2 == a && Utils.shared().showToast(i18nMgr.shared().getValueByKey("kyc.KYC_Verify_Suc"), 3.5), ToolUtils.isObjValid(this.node) && this.onBackView())), PushCenter.shared().pushEvent(GameConfig.Update_Kyc, User.shared().data.kyc_check)));
                    }
                    User.shared().data.card_check = a;
                    2 == User.shared().data.card_check ? HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Hall, event: ReportConfig.hall_evt.kyc_verify_succ }) : 3 == User.shared().data.card_check && HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Hall, event: ReportConfig.hall_evt.kyc_verify_fail });
                    sys.isObjectValid(e.data.loading_seconds) && Number(e.data.loading_seconds) > 0 ? ToolUtils.isObjValid(this.node) && (1 == a && (this.rootNode.getChildByName("submit_btn").getComponent(Button).interactable = false, i18nMgr.shared().changeLabelLanguage(this.rootNode.getChildByName("submit_btn").getChildByName("wz").getComponent(Label), "kyc.verity_pending", true)), Utils.shared().showLoading(Number(e.data.loading_seconds), true, (() => {
                        Utils.shared().hideLoading();
                        User.shared().doGetKycVerifyList();
                        ToolUtils.isObjValid(this.node) && (PushCenter.shared().pushEvent(PushEvent.CloseAgeVerifySelect), PushCenter.shared().pushEvent(PushEvent.Close_FastOtpView), this.onBackView());
                        Utils.shared().showToast(i18nMgr.shared().getValueByKey("kyc.submit_success"), 3.5);
                    }), ToolUtils.getIsNormalDirection(), 1)) : (ToolUtils.isObjValid(this.node) && Utils.shared().hideLoading(), 2 != a && 1 != a || (PushCenter.shared().pushEvent(PushEvent.CloseAgeVerifySelect), PushCenter.shared().pushEvent(PushEvent.Close_FastOtpView), User.shared().newKycData.kyc_list.reason = "", User.shared().newKycData.kyc_list.fast_reason = "", User.shared().newKycData.kyc_list.trigger_age_pop = 0, User.shared().updateKycAccount2(e.data), ToolUtils.isObjValid(this.node) && (2 == a && (sys.isObjectValid(e.data.reward_list) && e.data.reward_list.length > 0 ? Utils.shared().showKycVerifySucTip(e.data.reward_list, i18nMgr.shared().getValueByKey("kyc.KYC_Verify_Suc")) : Utils.shared().showToast(i18nMgr.shared().getValueByKey("kyc.KYC_Verify_Suc"), 3.5)), ToolUtils.isObjValid(this.node) && this.onBackView())), PushCenter.shared().pushEvent(GameConfig.Update_Kyc, User.shared().data.kyc_check));
                }
                else if (4027 === e.ret) {
                    User.shared().data.submit_left_hour = e.data.submit_left_seconds;
                    Utils.shared().doJumpLogic(PushEvent.Custom_TO_KycLimitTip);
                }
                else {
                    ToolUtils.isObjValid(this.node) && (Utils.shared().hideLoading(), e.desc && e.desc.length > 0 && Utils.shared().showToast(e.desc, 2));
                    let t = e.ret + ToolUtils.isSafeString(e.desc);
                    HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Hall, event: ReportConfig.hall_evt.kyc_submit_fail, kyc_err: t });
                }
            }
            catch (e) {
                ToolUtils.isObjValid(this.node) && Utils.shared().hideLoading();
                let t = ToolUtils.isSafeString(e.toString());
                HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Hall, event: ReportConfig.hall_evt.kyc_submit_fail, kyc_err: t });
            }
        }
    }
    onBackView(e = true) {
        e && (Utils.shared().hideLoading(), this.closeUICallBack && this.closeUICallBack(), this.bShowPushAnim ? (this._closed = true, ToolUtils.showPushAnim(this.node, 1, (() => {
            ToolUtils.isObjValid(this.node) && this.node.destroy();
        }))) : ToolUtils.isObjValid(this.node) && this.node.destroy());
    }
    fitScreen() {
        ToolUtils.adaptSafeArea(this.rootNode);
        let e = sys.getSafeAreaRect().y;
        this.rootNode.getChildByName("tips").getComponent(Widget).bottom = 120 - e;
        this.rootNode.getChildByName("submit_btn").getComponent(Widget).bottom = 20 - e;
        2 == i18nMgr.shared().language && (this.rootNode.getChildByName("tips").getComponent(Widget).bottom = 140 - e);
    }
}
