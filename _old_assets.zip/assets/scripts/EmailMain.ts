// @ts-nocheck
// Recovered from index.js:109
import { _decorator, Button, color, director, instantiate, Label, Node, Prefab, ScrollView, size, Sprite, SpriteFrame, sys, UIOpacity, UITransform, v3, Vec3, view } from "cc";
import BaseLayer from "./BaseLayer";
import i18nMgr from "./i18nMgr";
import PushCenter from "./PushCenter";
import TableViewUtils from "./TableViewUtils";
import { TLog } from "./TLog";
import { ToolUtils } from "./ToolUtils";
import TweenTool from "./TweenTool";
import Utils from "./Utils";
import GameConfig from "./GameConfig";
import { HttpRequest } from "./HttpRequestName";
import PushEvent from "./PushEvent";
import User from "./User";
import HttpManager from "./HttpManager";
import SoundManager from "./SoundManager";
const { ccclass, property } = _decorator;
@ccclass("EmailMain")
export default class EmailMain extends BaseLayer {
    public TAG: string = "EmailMain";
    @property(Node)
    public mail_root: Node = null;
    @property(ScrollView)
    public mail_list: ScrollView = null;
    @property(Node)
    public mail_moban: Node = null;
    @property([SpriteFrame])
    public isreadiconSp: SpriteFrame[] = [];
    @property([SpriteFrame])
    public isreadiconredSp: SpriteFrame[] = [];
    @property([SpriteFrame])
    public bgImgs: SpriteFrame[] = [];
    @property(Node)
    public deleteReadNode: Node = null;
    @property(Node)
    public collectAllNode: Node = null;
    @property(Prefab)
    public mailDetailPrefab: Prefab = null;
    @property(Node)
    public titleNode: Node = null;
    public TabView: any = null;
    public pageIndex: number = 0;
    public _eidArr: any[] = [];
    public _emailListData: any[] = [];
    public _lastEmailListDataMd5: any = null;
    public _hasRequestList: boolean = false;
    public _callback: any = null;
    public hasUnReadEmail: boolean = false;
    public hasUnGetEmail: boolean = false;
    onLoad() {
        this.mail_moban.active = false;
        1 == GameConfig.GAME_HALL_THEME ? (this.mail_root.getChildByName("top").getChildByName("title2").active = true, this.mail_root.getChildByName("top").getChildByName("title").active = false) : (this.mail_root.getChildByName("top").getChildByName("title2").active = false, this.mail_root.getChildByName("top").getChildByName("title").active = true);
        this.initView();
        PushCenter.shared().addListener(GameConfig.Jump_Hall_Choose_game, (e => {
            ToolUtils.isObjValid(this.node) && this.onBackView();
        }), this);
        this.fitLuckyTheme();
    }
    fitLuckyTheme() {
        0 != GameConfig.NATIVE_GAME_APP_TYPE && (this.mail_root.getChildByName("top").getChildByName("top_bg").getComponent(Sprite).color = color(12, 26, 60));
    }
    fitChipMode() {
        if (0 == GameConfig.CHIPS_MODLE) {
            return;
        }
        let e = 2000617 == GameConfig.CHANNEL_ID;
        e && e && 0 == GameConfig.GAME_HALL_THEME && (this.mail_root.getChildByName("top").getChildByName("top_bg").getComponent(Sprite).color = color(9, 69, 68, 255));
    }
    start() {
        if (super.start(), User.shared().emailData && User.shared().emailData.list && User.shared().emailData.list.length > 0) {
            if ("" === User.shared().emailData.eid && (this._eidArr = User.shared().emailData.eid), Array.isArray(User.shared().emailData.list)) {
                for (let e = 0, t = User.shared().emailData.list.length; e < t; e++) {
                    this._emailListData.push(User.shared().emailData.list[e]);
                }
                this.refreshList();
                this._emailListData.length > 0 ? this.checkMailInfo(false) : this.checkMailInfo(true);
            }
            this.refreshList();
            this.requestGetEmailList("", false);
        }
        else {
            this.requestGetEmailList("", true);
        }
        2 == i18nMgr.shared().language ? (this.collectAllNode.getChildByName("Label").getComponent(Label).fontSize = 22, this.collectAllNode.getChildByName("Label").getComponent(Label).lineHeight = 30, this.deleteReadNode.getChildByName("Label").getComponent(Label).fontSize = 28, this.deleteReadNode.getChildByName("Label").getComponent(Label).lineHeight = 32, this.deleteReadNode.getChildByName("Label").setPosition(new Vec3(0, 5))) : 3 == i18nMgr.shared().language && (this.deleteReadNode.getChildByName("Label").getComponent(Label).fontSize = 26, this.deleteReadNode.getChildByName("Label").getComponent(Label).lineHeight = 32, this.deleteReadNode.getChildByName("Label").setPosition(new Vec3(0, 5)));
    }
    onBackView() {
        ToolUtils.isObjValid(this.node) && (this._callback && this._callback(), this.node.destroy());
    }
    initData(e = null) {
        this._callback = e;
    }
    requestGetEmailList(e, t = false) {
        t && Utils.shared().showLoading(10, false, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
        }));
        let i = { eid: e };
        HttpManager.shared().doGetCommonRequest(i, HttpRequest.GetEmailList, ((t, i, a) => {
            if (Utils.shared().hideLoading(), ToolUtils.isObjValid(this.node)) {
                if (this._hasRequestList = false, 200 != a) {
                    ;
                }
                else {
                    let t = ToolUtils.parseJson(i);
                    if (User.shared().emailData = t.data, 0 == t.ret) {
                        if ("" === e && (this._emailListData = [], this._eidArr = t.data.eid), Array.isArray(t.data.list)) {
                            for (let e = 0, i = t.data.list.length; e < i; e++) {
                                this._emailListData.push(t.data.list[e]);
                            }
                        }
                        this.refreshList();
                    }
                }
                this._emailListData.length > 0 ? this.checkMailInfo(false) : this.checkMailInfo(true);
            }
        }));
    }
    button_click(e, t) {
        if (SoundManager.shared().playFx("click"), "delete" === t) {
            if (this._emailListData.length > 0) {
                let e = { bLandscape: ToolUtils.getIsNormalDirection(), bWithCancel: true, strContent: i18nMgr.shared().getValueByKey("email.delete_tips"), strTitle: i18nMgr.shared().getValueByKey("email.tips"), sureKey: "email.yes", cancelKey: "email.no" };
                Utils.shared().showCommonAlert(e, (e => {
                    1 === e ? this.requestDeleteEmail("", true) : this._hasRequestList = false;
                }), true);
            }
        }
        else {
            "collect" === t && (this._hasRequestList || this._emailListData.length > 0 && (this._hasRequestList = true, this.requestReceiveEmail("", true)));
        }
    }
    requestReadEmail(e, t = false) {
        t && Utils.shared().showLoading(10, false, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
        }));
        let i = { eid: e };
        HttpManager.shared().doGetCommonRequest(i, HttpRequest.EmailRead, ((t, i, a) => {
            if (Utils.shared().hideLoading(), ToolUtils.isObjValid(this.node)) {
                if (this._hasRequestList = false, 200 != a) {
                    ;
                }
                else {
                    if (0 == ToolUtils.parseJson(i).ret) {
                        for (let t = 0, i = this._emailListData.length; t < i; t++) {
                            const i = this._emailListData[t];
                            i.eid === e && (i.read = 1);
                        }
                        this.refreshList();
                    }
                }
            }
        }));
    }
    requestReceiveEmail(e, t = false) {
        t && Utils.shared().showLoading(10, false, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
        }));
        let i = { eid: e };
        "" === e && (i = null);
        HttpManager.shared().doGetCommonRequest(i, HttpRequest.EmailReceive, ((t, i, a) => {
            if (Utils.shared().hideLoading(), ToolUtils.isObjValid(this.node)) {
                if (200 != a) {
                    this._hasRequestList = false;
                }
                else {
                    this._hasRequestList = false;
                    let t = ToolUtils.parseJson(i);
                    if (0 == t.ret) {
                        let i = null;
                        for (let t = 0, a = this._emailListData.length; t < a; t++) {
                            const a = this._emailListData[t];
                            "" === e ? (a.read = 1, a.receive = 1) : e === a.eid && (i = a, a.read = 1, a.receive = 1);
                        }
                        if (this.refreshList(), Array.isArray(t.data.goods) && t.data.goods.length > 0) {
                            let e = false, i = { list: [] };
                            for (let a = 0, s = t.data.goods.length; a < s; a++) {
                                let s = t.data.goods[a], l = [];
                                l.num = s.num;
                                l.type = s.gtype;
                                l.discount = s.discount;
                                l.name = Utils.shared().getIconNameByType(s.type, s.desc);
                                l.php_data = s;
                                i.list[a] = l;
                                11 == s.gtype && (e = true);
                            }
                            Utils.shared().showRewardTips(i, null, 1, "reward_tips.okey");
                            e && PushCenter.shared().pushEvent(PushEvent.RefreshHallMatchList);
                            User.shared().getHallInfo();
                        }
                        else {
                            Utils.shared().showToast(i18nMgr.shared().getValueByKey("email.collect_tips"), 2);
                        }
                        if (null !== i) {
                            let e = director.getScene().getChildByName("Canvas");
                            if (null !== e.getChildByName("showEmailDetailView")) {
                                e.getChildByName("showEmailDetailView").getComponent("InboxDetail").refreshMailContent(i);
                            }
                        }
                        undefined !== t.money && User.shared().updateMoney(t.money);
                        undefined !== t.bonus && User.shared().updateBonus(t.bonus);
                        this._emailListData.length > 0 ? this.checkMailInfo(false) : this.checkMailInfo(true);
                    }
                }
            }
        }));
    }
    requestDeleteEmail(e, t = false) {
        t && Utils.shared().showLoading(10, false, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
        }));
        let i = { eid: e };
        "" === e && (i = null);
        HttpManager.shared().doGetCommonRequest(i, HttpRequest.EmailDelete, ((e, t, i) => {
            if (Utils.shared().hideLoading(), ToolUtils.isObjValid(this.node)) {
                if (200 != i) {
                    this._hasRequestList = false;
                }
                else {
                    this._hasRequestList = false;
                    let e = ToolUtils.parseJson(t);
                    if (0 == e.ret) {
                        this._emailListData = [];
                        this._eidArr = [];
                        this.pageIndex = 0;
                        this.requestGetEmailList("");
                        let e = director.getScene().getChildByName("Canvas");
                        if (null !== e.getChildByName("showEmailDetailView")) {
                            e.getChildByName("showEmailDetailView").getComponent("InboxDetail").onBackView();
                        }
                        User.shared().getHallInfo();
                    }
                    ToolUtils.isSafeString(e.desc).length > 0 && Utils.shared().showToast(e.desc, 2);
                }
            }
        }));
    }
    refreshList() {
        let e = true;
        if (sys.isObjectValid(this._lastEmailListDataMd5)) {
            let t = ToolUtils.jsonToMd5(this._emailListData);
            this._lastEmailListDataMd5 == t && (e = false);
        }
        e && (this.hasUnReadEmail = false, this.hasUnGetEmail = false, this._lastEmailListDataMd5 = ToolUtils.jsonToMd5(this._emailListData), this.TabView.reloadData(this._emailListData), this.playRoomInfoAnim());
    }
    scrollRefreshCallBack(e, t) {
        if (!this._hasRequestList && (this.pageIndex++, this._eidArr.length > this.pageIndex)) {
            this._hasRequestList = true;
            let e = this._eidArr[this.pageIndex];
            this.requestGetEmailList(e, true);
        }
    }
    initCurMobanCallBack(e, t) {
        e.active = true;
        ToolUtils.isSafeNumber(t.rich);
        let i = e.getChildByName("bg"), a = e.getChildByName("icon"), s = e.getChildByName("name"), l = e.getChildByName("content"), o = e.getChildByName("time"), n = e.getChildByName("detail"), h = e.getChildByName("arrow");
        n.getComponent(Label).color = color(2, 132, 11);
        h.getComponent(Sprite).color = color(2, 132, 11);
        i.getComponent(Sprite).spriteFrame = 0 === t.read ? this.bgImgs[0] : this.bgImgs[1];
        a.setPosition(v3(-288.864, -32.146));
        1 === t.attach ? 1 === t.receive ? (a.getComponent(Sprite).spriteFrame = this.isreadiconSp[0], 1 == t.receive && (a.setPosition(v3(-288.864, -22.146)), n.getComponent(Label).color = color(120, 120, 120), h.getComponent(Sprite).color = color(120, 120, 120))) : (a.getComponent(Sprite).spriteFrame = this.isreadiconSp[2], this.hasUnGetEmail = true) : (a.getComponent(Sprite).spriteFrame = 0 === t.read ? this.isreadiconSp[1] : this.isreadiconSp[0], 1 == t.read && (a.setPosition(v3(-288.864, -22.146)), n.getComponent(Label).color = color(120, 120, 120), h.getComponent(Sprite).color = color(120, 120, 120)));
        0 === t.read && (this.hasUnReadEmail = true);
        let c = t.title, u = t.content;
        u = Utils.shared().removeHTMLTag(u);
        u.length > 160 && (u = u.substring(0, 150) + "...");
        l.getComponent(Label).string = u;
        c.length > 22 && (c = c.substring(0, 21) + "...");
        s.getComponent(Label).string = c;
        o.getComponent(Label).string = t.date;
        e.getComponent(Button).clickEvents[0].customEventData = t;
    }
    initView() {
        this.fitScreen();
        let e = [this.mail_moban];
        this.TabView = this.node.addComponent(TableViewUtils);
        let t = this.mail_moban.getComponent(UITransform).height;
        this.TabView.init([], this.mail_list.node, e, this.initCurMobanCallBack.bind(this), 0, t, this.scrollRefreshCallBack.bind(this));
    }
    onReadMailContent(e, t) {
        SoundManager.shared().playFx("click");
        this._hasRequestList = false;
        0 == t.read && this.requestReadEmail(t.eid, false);
        this.createEmailDetailView(t);
    }
    createEmailDetailView(e) {
        try {
            let t = director.getScene().getChildByName("Canvas");
            if (null == t.getChildByName("showEmailDetailView")) {
                let i = instantiate(this.mailDetailPrefab);
                i.name = "showEmailDetailView";
                let a = i.getComponent("InboxDetail");
                a.init(true, (() => {
                    ToolUtils.isObjValid(this.node) && (this.node.active = false);
                }), (() => {
                    ToolUtils.isObjValid(this.node) && (this.node.active = true);
                }));
                a.initData(this.onDetailCallBack.bind(this), e);
                t.addChild(i);
            }
            else {
                let i = t.getChildByName("showEmailDetailView").getComponent("InboxDetail");
                i.init(true);
                i.initData(this.onDetailCallBack.bind(this), e);
            }
        }
        catch (e) {
            TLog.printError("------ createEmailDetailView error:", e);
        }
    }
    onDetailCallBack(e = "", t = null) {
        if (ToolUtils.isObjValid(this.node)) {
            if ("receive" == e) {
                if (sys.isObjectValid(t) && sys.isObjectValid(t.eid)) {
                    let e = !!t.hasLoading;
                    this.requestReceiveEmail(t.eid, e);
                }
            }
            else if ("delete" == e) {
                if (sys.isObjectValid(t) && sys.isObjectValid(t.eid)) {
                    let e = !!t.hasLoading;
                    this.requestDeleteEmail(t.eid, e);
                }
            }
            else {
                "refreshList" == e ? this.requestGetEmailList("", false) : "onclose" == e && this.onBackView();
            }
        }
    }
    onCloseClick(e, t) {
        SoundManager.shared().playFx("click");
        ToolUtils.isObjValid(this.node) && (User.shared().jumpFromHall && (User.shared().jumpFromHall = false), this.onBackView());
    }
    checkMailInfo(e) {
        if (this.mail_root.getChildByName("nodata").active = e, this.deleteReadNode.active = !e, this.collectAllNode.active = !e, !e) {
            let e = new Vec3;
            this.deleteReadNode.getPosition(e);
            this.deleteReadNode.setPosition(v3(-165, e.y));
            this.hasUnGetEmail || (this.collectAllNode.active = false, this.deleteReadNode.setPosition(v3(0, e.y)));
        }
    }
    fitScreen() {
        let e = ToolUtils.adaptSafeArea(this.mail_root), t = sys.getSafeAreaRect().y, i = view.getVisibleSize(), a = this.mail_list.getComponent(UITransform).contentSize, s = i.height - GameConfig.CONFIG_SCREEN_HEIGHT + a.height - t + e;
        this.mail_list.getComponent(UITransform).contentSize = size(a.width, s);
    }
    onDestroy() {
        super.onDestroy();
        Utils.shared().hideLoading();
    }
    playRoomInfoAnim() {
        if (!this.mail_list.isScrolling()) {
            let e, t = 0.08;
            e = 0;
            for (let i = 0, a = this.mail_list.content.children.length; i < a; i++) {
                let a = this.mail_list.content.children[i];
                if (ToolUtils.isObjValid(a) && a.active) {
                    let i = new Vec3;
                    TweenTool.stopNodeAction(a);
                    a.getPosition(i);
                    a.getComponent(UIOpacity).opacity = 0;
                    a.setPosition(v3(i.x, i.y - 40));
                    let s = TweenTool.moveToByFade(a, 0.16, i, 0, 1, false), l = TweenTool.delayAct(a, null, e, false);
                    TweenTool.sequence(a, true, null, l, s);
                    e += t;
                }
            }
        }
    }
}
