// @ts-nocheck
// Recovered from index.js:13
import { _decorator, Node, v3, Vec3 } from "cc";
import BaseLayer from "./BaseLayer";
import i18nMgr from "./i18nMgr";
import SoundManager from "./SoundManager";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("AgeVerification")
export class AgeVerification extends BaseLayer {
    public _cb: any = null;
    @property(Node)
    public rootNode: Node = null;
    @property(Node)
    public ppNode: Node = null;
    @property(Node)
    public tcNode: Node = null;
    start() {
        super.start();
        let t = this.node.getChildByName("bg1");
        ToolUtils.showFullScreen(t);
        this.startShowAnim(this.rootNode);
        ToolUtils.getIsNormalDirection() || this.node.setRotationFromEuler(v3(0, 0, 90));
        1 === i18nMgr.shared().language ? (this.tcNode.setPosition(new Vec3(-176, 17)), this.ppNode.setPosition(new Vec3(-17, 17))) : (this.tcNode.setPosition(new Vec3(-27, 17)), this.ppNode.setPosition(new Vec3(152, 17)));
    }
    update(t) {
    }
    setCallBack(t = null) {
        this._cb = t;
    }
    onclickByClose(t, e) {
        SoundManager.shared().playFx("click");
        this._cb && this._cb("close");
        ToolUtils.isObjValid(this.node) && this.node.destroy();
    }
    onClickByBtn(t, e) {
        SoundManager.shared().playFx("click");
        this._cb && this._cb(e + "");
        ToolUtils.isObjValid(this.node) && this.node.destroy();
    }
}
