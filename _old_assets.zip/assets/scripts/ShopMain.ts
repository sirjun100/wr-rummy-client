// @ts-nocheck
// Recovered from index.js:517
import { _decorator, color, game, instantiate, Label, Node, Sprite, SpriteFrame, sys, UITransform, v3, Vec3, view, Widget } from "cc";
import PushCenter from "./PushCenter";
import Utils from "./Utils";
import GameConfig from "./GameConfig";
import User from "./User";
import SoundManager from "./SoundManager";
import { TransferPlatform } from "./TransferPlatform";
import i18nMgr from "./i18nMgr";
import PushEvent from "./PushEvent";
import HttpManager from "./HttpManager";
import BaseLayer from "./BaseLayer";
import BundleNameDefined from "./BundleNameDefined";
import TweenTool from "./TweenTool";
import { ToolUtils } from "./ToolUtils";
import { CouponPopList } from "./CouponPopList";
const { ccclass, property } = _decorator;
@ccclass("ShopMain")
export class ShopMain extends BaseLayer {
    public TAG: string = "ShopMain";
    @property(Node)
    public rootNode: Node = null;
    @property(Node)
    public bgNode: Node = null;
    @property([SpriteFrame])
    public itemImgs: SpriteFrame[] = [];
    @property([Node])
    public goodItems: Node[] = [];
    @property(Node)
    public payRoot: Node = null;
    @property(Node)
    public couponRoot: Node = null;
    public couponAlertPrefab: any = null;
    public couponAlertNode: any = null;
    public lastPayTime: any = sys.now();
    public hasPay: boolean = false;
    public sucPay: boolean = false;
    public _linkId: number = 0;
    public exe: any = null;
    public _callback: any = null;
    public _isFromAct: boolean = false;
    public _hasClickBack: boolean = false;
    public _click_time: number = 0;
    public _rep_act_id: any = undefined;
    public _recommend_price: number = 0;
    public _scheduleAct: any = null;
    public move_distance: number = 0;
    public cur_select_index: number = 0;
    public cur_payment_index: number = 0;
    public forceSelectIndex: any = -1;
    public forceSelectPrice: number = 0;
    onLoad() {
        let e = view.getVisibleSize(), t = this.rootNode.getComponent(UITransform), i = this.bgNode.getComponent(UITransform), s = this.node.getComponent(UITransform);
        ToolUtils._orientation_landscape ? (this.node.setRotationFromEuler(new Vec3(0, 0, 90)), t.setContentSize(e.height, e.width), i.setContentSize(e.height, e.width), s.setContentSize(e.height, e.width), this.rootNode.setPosition(v3(0, -sys.getSafeAreaRect().x, 0)), this.rootNode.getChildByName("top_node").getComponent(Widget).enabled = false, this.rootNode.getChildByName("top_node").setPosition(v3(0, e.width / 2 - 45, 0)), this.rootNode.getChildByName("payRoot").getComponent(Widget).enabled = false, this.rootNode.getChildByName("payRoot").getComponent(UITransform).setContentSize(e.height, e.width)) : (t.setContentSize(e.width, e.height), i.setContentSize(e.width, e.height), s.setContentSize(e.width, e.height), this.rootNode.setPosition(v3(0, -sys.getSafeAreaRect().y, 0)), sys.getSafeAreaRect().y > 0 && (this.rootNode.getChildByName("payRoot").getChildByName("pay_btn").getComponent(Widget).bottom = 54.021 - sys.getSafeAreaRect().y, this.rootNode.getChildByName("payRoot").getChildByName("pay_btn").getComponent(Widget).updateAlignment(), this.rootNode.getChildByName("payRoot").getChildByName("bottom_tip").getComponent(Widget).bottom = 15.499 - sys.getSafeAreaRect().y, this.rootNode.getChildByName("payRoot").getChildByName("bottom_tip").getComponent(Widget).updateAlignment()));
        this.fitScreen();
        User.shared().b_storeLevel = true;
        this.fitLuckyTheme();
    }
    fitLuckyTheme() {
        0 != GameConfig.NATIVE_GAME_APP_TYPE && (this.rootNode.getChildByName("top_node").getChildByName("top_bg").getComponent(Sprite).color = color(12, 26, 60));
    }
    fitScreen() {
        if (!ToolUtils.isPadPlatform()) {
            ToolUtils.getSafeDistance();
            ToolUtils.getSafeDistance();
            this.move_distance;
        }
    }
    start() {
        super.start();
        TransferPlatform.shared().setNormalFrameRate();
        this.addNotify();
        sys.isObjectValid(this.exe) && sys.isObjectValid(this.exe.act_id) && (this.exe.act_id != PushEvent.JUMP_TO_LOTTERYACT && this.exe.act_id != PushEvent.JUMP_TO_PrayBless && this.exe.act_id != PushEvent.JUMP_TO_BonusForest || (this._isFromAct = true));
        this.refreshCashShopView();
        this.scheduleOnce((() => {
            User.shared().requestStoreList(this.exe);
        }), game.frameTime / 1000 * 3);
    }
    setParaData(e) {
        sys.isObjectValid(e) && (this.exe = e, sys.isObjectValid(this.exe.link_id) && (this._linkId = this.exe.link_id), sys.isObjectValid(this.exe.rep_act_id) && (this._rep_act_id = this.exe.rep_act_id), sys.isObjectValid(this.exe.recommend_price) && (this._recommend_price = this.exe.recommend_price));
    }
    getShowShopList() {
        let e = User.shared().soreTb;
        return e && e.list && Array.isArray(e.list) && e.list || [];
    }
    setCallBack(e = null) {
        this._callback = e;
    }
    addNotify() {
        PushCenter.shared().addListener(GameConfig.Update_Store, (e => {
            ToolUtils.isObjValid(this.node) && (this.refreshCashShopView(), this.updateStoreRetainTime());
        }), this);
        PushCenter.shared().addListener(PushEvent.Close_Store, (e => {
            ToolUtils.isObjValid(this.node) && this.onBackView();
        }), this);
        PushCenter.shared().addListener(GameConfig.onEnterForeground, (e => {
            ToolUtils.isObjValid(this.node) && User.shared().requestStoreList(this.exe);
        }), this);
        PushCenter.shared().addListener(GameConfig.Recharge, (e => {
            ToolUtils.isObjValid(this.node) && this.hasPay && (this.sucPay = true);
        }), this);
    }
    updateStoreRetainTime() {
    }
    scheduleCallBack() {
        User.shared().store_retain_expire_seconds -= 1;
        User.shared().store_retain_expire_seconds < 0 && (User.shared().store_retain_expire_seconds = 0, User.shared().requestStoreList(this.exe), this._scheduleAct && TweenTool.stopAction(this._scheduleAct));
    }
    onBackView() {
        ToolUtils.isObjValid(this.node) && (this._callback && this._callback(), this.node.destroy());
    }
    onDestroy() {
        super.onDestroy();
        Utils.shared().hideToast();
        User.shared().b_storeLevel = false;
        User.shared().requestStoreList(this.exe);
        PushCenter.shared().pushEvent(GameConfig.Update_Wallet);
        PushCenter.shared().removeListenersByTag(this);
        this.unscheduleAllCallbacks();
    }
    closeStoreView() {
        ToolUtils.judgeIfInHall();
        ToolUtils.isObjValid(this.node) && (this.onBackView(), PushCenter.shared().pushEvent(PushEvent.ShowSuperLevelUpAlert), PushCenter.shared().pushEvent(PushEvent.ShowGameRatingAlert), sys.isObjectValid(this.exe) && sys.isObjectValid(this.exe.tid_key) && PushCenter.shared().pushEvent(PushEvent.LeaveStore, this.exe));
    }
    onButtonClick(e, t) {
        if (SoundManager.shared().playFx("click"), "back_btn" === t) {
            if (sys.isObjectValid(User.shared().retention_pop_info) && sys.isObjectValid(User.shared().retention_pop_info.coupon_info)) {
                if (this.sucPay, !this._hasClickBack) {
                    this._click_time = sys.now();
                    let e = () => {
                        this.closeStoreView();
                    };
                    return Utils.shared().showStoreRetainView({ parent_node: this.node, callback: e }), void (this._hasClickBack = true);
                }
                if (sys.now() - this._click_time < 2) {
                    return;
                }
            }
            this.closeStoreView();
        }
        else if ("pay" == t) {
            let e = this.getShowShopList()[this.cur_select_index];
            if (e && (e.isShop = 1, User.shared().checkPayment(Number(e.price)))) {
                return void Utils.shared().showPaymentGuide(this.node, e, (e => {
                    this.cur_payment_index = e;
                    this.dealPayLogic();
                }));
            }
            this.cur_payment_index = 0;
            this.dealPayLogic();
        }
        else if ("change_coupons" === t) {
            ToolUtils.isObjValid(this.couponAlertNode) && this.couponAlertNode.destroy();
            sys.isObjectValid(this.couponAlertPrefab) && this.couponAlertPrefab.isValid ? this.showCouponAlert() : ToolUtils.loadCommonPrefab(this.couponAlertPrefab, BundleNameDefined.bundle_wallet, "prefab/coupon_popview", (e => {
                this.couponAlertPrefab = e;
                this.showCouponAlert();
            }));
        }
        else if ("recode" == t) {
            sys.isObjectValid(User.shared().StoreData_His_rec) ? Utils.shared().showWalletRecordView(1, this.node, User.shared().StoreData_His_rec) : (Utils.shared().showLoading(10, true, (() => {
                Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
            }), ToolUtils.getIsNormalDirection()), HttpManager.shared().doWalletRecode(1, 0, this.listenRecordCallback.bind(this)));
        }
        else if ("kefu" == t) {
            Utils.shared().showContactUsView();
        }
        else if (-1 != t.indexOf("store_good_")) {
            this.cur_select_index = parseInt(t.split("_good_")[1]);
            this.updateCouponInfo();
            this.updateItemBg();
            let e = this.getShowShopList()[this.cur_select_index];
            sys.isObjectValid(e) && (this.forceSelectIndex = this.cur_select_index, this.forceSelectPrice = Number(e.price));
        }
    }
    dealPayLogic() {
        try {
            let e = this.getShowShopList()[this.cur_select_index];
            if (e) {
                let t = sys.now();
                if (this.hasPay && t - this.lastPayTime <= 3) {
                    return;
                }
                if (0 == Number(e.price)) {
                    return;
                }
                this.lastPayTime = t;
                this.hasPay = true;
                let i = "";
                sys.isObjectValid(this.exe) && sys.isObjectValid(this.exe.tid_key) && (i = this.exe.tid_key);
                let s = { coupon_id: e.check_coupon_id, price: Number(e.price), pmode: this.cur_payment_index, tid_key: i, scene: 3 };
                e.check_coupon_id > 0 && sys.isObjectValid(e.check_act_id) && (s.act_id = e.check_act_id);
                this._rep_act_id && sys.isObjectValid(this.exe) && sys.isObjectValid(this.exe.client_time) && (this._rep_act_id != PushEvent.JUMP_TO_SuperVip && this._rep_act_id != PushEvent.JUMP_TO_NEW_NOVICESTASK || (s.client_time = this.exe.client_time));
                this._linkId > 0 && (s.link_id = this._linkId);
                User.shared().startPay(s, 1);
            }
        }
        catch (e) {
        }
    }
    showCouponAlert() {
        let e = this.getShowShopList()[this.cur_select_index];
        this._isFromAct && sys.isObjectValid(this.exe) && sys.isObjectValid(this.exe.act_id) && this.exe.act_id;
        this.couponAlertNode = instantiate(this.couponAlertPrefab);
        this.couponAlertNode.getComponent(CouponPopList).initParaData(e, (e => {
            User.shared().soreTb.list[this.cur_select_index] = e;
            this.refreshCurGood();
        }));
        this.node.addChild(this.couponAlertNode);
    }
    listenRecordCallback(e, t, i) {
        if (0 != t.length) {
            if (200 != i) {
                Utils.shared().hideLoading();
                alert("The login timed out, please try again");
            }
            else {
                let e = ToolUtils.parseJson(t);
                0 == e.ret && (User.shared().with_tip = e.data.rule_tips, sys.isObjectValid(this.node) && (sys.isObjectValid(e.data.list) && e.data.list.length > 0 ? User.shared().StoreData_His_rec = e.data.list : User.shared().StoreData_His_rec = [], Utils.shared().showWalletRecordView(1, this.node, User.shared().StoreData_His_rec)));
            }
        }
        else {
            Utils.shared().hideLoading();
        }
    }
    refreshCurGood() {
        let e = this.getShowShopList()[this.cur_select_index];
        sys.isObjectValid(e.tag_text) && e.tag_text.length > 0 ? (this.goodItems[this.cur_select_index].getChildByName("flag").active = true, this.goodItems[this.cur_select_index].getChildByName("flag").getChildByName("tx").getComponent(Label).string = e.tag_text) : this.goodItems[this.cur_select_index].getChildByName("flag").active = false;
        this.goodItems[this.cur_select_index].getChildByName("reward").getChildByName("cash").getChildByName("num").getComponent(Label).string = "₹" + e.price;
        let t = this.goodItems[this.cur_select_index].getChildByName("reward").getChildByName("add_root");
        sys.isObjectValid(e.check_coupon_id) && e.check_coupon_id > 0 ? (t.active = true, e.add_bonus > 0 ? (t.getChildByName("bonus").active = true, t.getChildByName("bonus").getChildByName("num").getComponent(Label).string = "₹" + e.add_bonus) : t.getChildByName("bonus").active = false, e.add_cash > 0 ? (t.getChildByName("cash").active = true, t.getChildByName("cash").getChildByName("num").getComponent(Label).string = "₹" + e.add_cash) : t.getChildByName("cash").active = false) : t.active = false;
        this.updateItemBg();
        this.updateCouponInfo();
    }
    refreshCashShopView() {
        let e = this.getShowShopList();
        if (0 == e.length) {
            return;
        }
        if (this.cur_select_index = User.shared().soreTb.check_index - 1, (this.cur_select_index < 0 || this.cur_select_index > 5) && (this.cur_select_index = 0), -1 != this.forceSelectIndex && e.length > this.forceSelectIndex) {
            let t = e[this.forceSelectIndex];
            sys.isObjectValid(t) && Number(t.price) == this.forceSelectPrice && (this.cur_select_index = this.forceSelectIndex);
        }
        let t = 6;
        e.length <= 6 && (t = e.length);
        for (let i = 0; i < t; i++) {
            let t = e[i];
            sys.isObjectValid(t.tag_text) && t.tag_text.length > 0 ? (this.goodItems[i].getChildByName("flag").active = true, this.goodItems[i].getChildByName("flag").getChildByName("tx").getComponent(Label).string = t.tag_text) : this.goodItems[i].getChildByName("flag").active = false;
            this.goodItems[i].getChildByName("reward").getChildByName("cash").getChildByName("num").getComponent(Label).string = "₹" + t.price;
            let s = this.goodItems[i].getChildByName("reward").getChildByName("add_root");
            sys.isObjectValid(t.check_coupon_id) && t.check_coupon_id > 0 ? (s.active = true, t.add_bonus > 0 ? (s.getChildByName("bonus").active = true, s.getChildByName("bonus").getChildByName("num").getComponent(Label).string = "₹" + t.add_bonus) : s.getChildByName("bonus").active = false, t.add_cash > 0 ? (s.getChildByName("cash").active = true, s.getChildByName("cash").getChildByName("num").getComponent(Label).string = "₹" + t.add_cash) : s.getChildByName("cash").active = false) : s.active = false;
        }
        this.updateItemBg();
        this.updateCouponInfo();
    }
    updateItemBg() {
        for (let e = 0; e < 6; e++) {
            this.cur_select_index == e ? this.goodItems[e].getChildByName("bg").getComponent(Sprite).spriteFrame = this.itemImgs[1] : this.goodItems[e].getChildByName("bg").getComponent(Sprite).spriteFrame = this.itemImgs[0];
        }
    }
    updateCouponInfo() {
        let e = this.getShowShopList()[this.cur_select_index];
        if (sys.isObjectValid(e.check_coupon_id) && e.check_coupon_id > 0) {
            this.couponRoot.getChildByName("coupon_node0").active = true;
            this.couponRoot.getChildByName("coupon_node1").active = false;
            this.couponRoot.getChildByName("coupon_node0").getChildByName("desc").getComponent(Label).string = `'${e.check_coupon_code}' applied!`;
            let t = "result2";
            e.add_cash > 0 && e.add_bonus > 0 ? (this.payRoot.getChildByName("result2").active = true, this.payRoot.getChildByName("result1").active = false, t = "result2") : (this.payRoot.getChildByName("result1").active = true, this.payRoot.getChildByName("result2").active = false, t = "result1");
            this.payRoot.getChildByName("result0").active = false;
            this.payRoot.getChildByName(t).getChildByName("pay_amt").getComponent(Label).string = `₹${e.price}`;
            this.payRoot.getChildByName(t).getChildByName("bonus_amt").getComponent(Label).string = `₹${e.add_bonus}`;
            e.add_cash > 0 && (this.payRoot.getChildByName(t).getChildByName("cash_amt").getComponent(Label).string = `₹${e.add_cash}`);
            this.payRoot.getChildByName(t).getChildByName("total_amt").getComponent(Label).string = `₹${e.total_get}`;
        }
        else {
            this.couponRoot.getChildByName("coupon_node0").active = false;
            this.couponRoot.getChildByName("coupon_node1").active = true;
            this.payRoot.getChildByName("result1").active = false;
            this.payRoot.getChildByName("result2").active = false;
            this.payRoot.getChildByName("result0").active = true;
            this.payRoot.getChildByName("result0").getChildByName("total_amt").getComponent(Label).string = `₹${e.price}`;
        }
        this.payRoot.getChildByName("pay_btn").getChildByName("Label").getComponent(Label).string = `ADD ₹${e.price}`;
    }
}
