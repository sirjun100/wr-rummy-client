// @ts-nocheck
// Recovered from index.js:679
import { _decorator, Label, Node, Sprite, SpriteFrame, sys, v3, Widget } from "cc";
import PushCenter from "./PushCenter";
import Utils from "./Utils";
import PushEvent from "./PushEvent";
import User from "./User";
import SoundManager from "./SoundManager";
import BaseLayer from "./BaseLayer";
import { TransferPlatform } from "./TransferPlatform";
import TweenTool from "./TweenTool";
import i18nMgr from "./i18nMgr";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("WholeDayGift")
export class WholeDayGift extends BaseLayer {
    @property(Node)
    public rootNode: Node = null;
    @property(Node)
    public maskNode: Node = null;
    @property(Label)
    public leftTimeLabel: Label = null;
    @property(Node)
    public mainRoot: Node = null;
    @property([SpriteFrame])
    public bgSpriteFrames: SpriteFrame[] = [];
    public isNext: boolean = false;
    public isBackKey: boolean = true;
    public goods_id: any = null;
    public isquick: boolean = false;
    public _nVid: number = 0;
    public _bStartCountDown: boolean = false;
    public _nCountcd: any = -1;
    public _linkId: number = 0;
    public _reportScene: any = -1;
    public _pop_souce: number = 0;
    public _has_close: boolean = false;
    public _flag: number = 0;
    public _mPara: any = null;
    public TAG: string = "TwentyFourRecharge";
    public checkKyc: number = 0;
    public _lastClick: number = 0;
    initParaData(e, t = 0) {
        this._mPara = e;
        this.isNext = e.isNext;
        sys.isObjectValid(e.isquick) && (this.isquick = e.isquick);
        sys.isObjectValid(e.flag) && (this._flag = e.flag);
        sys.isObjectValid(e.checkKyc) && (this.checkKyc = e.checkKyc);
        sys.isObjectValid(e) && sys.isObjectValid(e.pop_souce) && (this._pop_souce = e.pop_souce);
        sys.isObjectValid(e) && sys.isObjectValid(e.reportScene) && (this._reportScene = e.reportScene);
        sys.isObjectValid(e) && sys.isObjectValid(e.link_id) && e.link_id > 0 && (this._linkId = e.link_id);
    }
    onLoad() {
        ToolUtils.getIsInRoom() && (this.mainRoot.getComponent(Sprite).spriteFrame = this.bgSpriteFrames[1], this.mainRoot.getComponent(Sprite).sizeMode = 2, this.mainRoot.getChildByName("item_root").setPosition(v3(0, 0)));
    }
    start() {
        super.start();
        this._linkId = this._linkId > 0 ? this._linkId : sys.now();
        this._reportScene = this._reportScene >= 0 ? this._reportScene : ToolUtils.getIsInRoom() ? 2 : 1;
        ToolUtils.showFullScreen(this.maskNode);
        sys.isObjectValid(User.shared().twentyfourrechargeData) && this.refreshView();
        User.shared().requestTwentyFourRechargePageData((() => {
            ToolUtils.isObjValid(this.node) && this.refreshView();
        }));
        PushCenter.shared().addListener(PushEvent.CloseTwentyHourRecharge, (e => {
            ToolUtils.isObjValid(this.node) && (this.isNext && PushCenter.shared().pushEvent(PushEvent.Update_NextPopActivity), this.node.destroy());
        }), this);
        PushCenter.shared().pushEvent(PushEvent.HideGameOverBg);
        TweenTool.commonSchedule(this.node, 1, this.scheduleCallBack.bind(this));
        this.startShowAnim2(this.rootNode, 1);
        SoundManager.shared().playFx("act_popshow");
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().pushEvent(PushEvent.ShowGameOverBg);
        PushCenter.shared().removeListenersByTag(this);
        TweenTool.stopNodeAction(this.node);
        this.unscheduleAllCallbacks();
    }
    onEnable() {
        TransferPlatform.shared().setNormalFrameRate();
    }
    refreshView() {
        this.updateCashContent();
    }
    updateCashContent() {
        let e = User.shared().twentyfourrechargeData;
        if (sys.isObjectValid(e)) {
            this.startLeftTime(Number(e.time_left));
            sys.isObjectValid(e.title) && e.title.length > 0 && (this.mainRoot.getChildByName("flag").getComponent(Label).string = e.title);
            let t = this.mainRoot.getChildByName("item_root"), i = this.mainRoot.getChildByName("submit_btn");
            sys.isObjectValid(e.price) && (i.getChildByName("wz").getComponent(Label).string = "₹" + e.price);
            sys.isObjectValid(e.line_cash) && String(e.line_cash).length > 0 ? 0 == ToolUtils.isSafeNumber(e.line_cash) ? (t.getChildByName("item_cash").getChildByName("line_wz").active = false, t.getChildByName("item_cash").getChildByName("wz").setPosition(v3(0, -82.922))) : (t.getChildByName("item_cash").getChildByName("line_wz").active = true, t.getChildByName("item_cash").getChildByName("line_wz").getComponent(Label).string = "₹" + e.line_cash, t.getChildByName("item_cash").getChildByName("line_wz").getChildByName("line").getComponent(Widget).updateAlignment(), t.getChildByName("item_cash").getChildByName("wz").setPosition(v3(0, -98.124))) : (t.getChildByName("item_cash").getChildByName("line_wz").active = false, t.getChildByName("item_cash").getChildByName("wz").setPosition(v3(0, -82.922)));
            sys.isObjectValid(e.ratio) && e.ratio.length > 0 ? (i.getChildByName("flag").getChildByName("wz").getComponent(Label).string = e.ratio, i.getChildByName("flag").active = true) : i.getChildByName("flag").active = false;
            sys.isObjectValid(e.cash) && (t.getChildByName("item_cash").getChildByName("wz").getComponent(Label).string = "₹" + e.cash);
            sys.isObjectValid(e.bonus) && ToolUtils.isSafeNumber(e.bonus) > 0 ? (t.getChildByName("item_bonus").getChildByName("wz").getComponent(Label).string = "₹" + e.bonus, t.getChildByName("item_bonus").active = true, t.getChildByName("add_wz").active = true) : (t.getChildByName("item_bonus").active = false, t.getChildByName("add_wz").active = false);
        }
    }
    startLeftTime(e) {
        let t = i18nMgr.shared().getValueByKey("first_recharge_text.left_time");
        if (Number.isNaN(e) || e <= 0) {
            return User.shared().getHallInfo(), void (this.leftTimeLabel.string = "");
        }
        this._bStartCountDown = true;
        this._nCountcd = e;
        t = ToolUtils.format("${0} ${1}", t, Utils.shared().parseCountDown(this._nCountcd));
        this.leftTimeLabel.string = t;
        i18nMgr.shared().changeLabelFont(this.leftTimeLabel, false);
    }
    scheduleCallBack() {
        let e = User.shared().twentyfourrechargeData;
        if (sys.isObjectValid(e) && this._bStartCountDown) {
            if (this._nCountcd -= 1, e.time_left = this._nCountcd, this._nCountcd < 0) {
                return e.time_left = -1, User.shared().getHallInfo(), void this.onBackView();
            }
            this.leftTimeLabel.string = ToolUtils.format("${0} ${1}", i18nMgr.shared().getValueByKey("first_recharge_text.left_time"), Utils.shared().parseCountDown(this._nCountcd));
        }
    }
    onButtonClick(e, t) {
        if (SoundManager.shared().playFx("click"), "close" == t) {
            if (1 == Utils.shared().checkPopRestartGift(this._mPara)) {
                return void this.onBackView();
            }
            1 == this.checkKyc && Utils.shared().checkAddCashKyc();
            this.onBackView();
        }
        else {
            if (sys.now() - this._lastClick < 500) {
                return;
            }
            if (this._lastClick = sys.now(), sys.isObjectValid(User.shared().twentyfourrechargeData) && ToolUtils.isObjValid(this.node)) {
                if (!User.shared().checkCanRecharge()) {
                    return void this.node.destroy();
                }
                let e = { act_id: PushEvent.JUMP_TO_TwentyFourRecharge, price: User.shared().twentyfourrechargeData.price, link_id: this._linkId };
                User.shared().startPay(e);
            }
        }
    }
    onBackView() {
        if (ToolUtils.isObjValid(this.node)) {
            if (this._has_close) {
                return;
            }
            this._has_close = true;
            let e = { alert_node: this.node, rootNode: this.rootNode, isNext: this.isNext, pop_type: PushEvent.JUMP_TO_TwentyFourRecharge, pop_souce: this._pop_souce };
            Utils.shared().closeActivityView(e);
        }
    }
}
