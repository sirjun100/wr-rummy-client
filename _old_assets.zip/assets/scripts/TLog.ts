// @ts-nocheck
// Recovered from index.js:629
import { _decorator, Component, sys } from "cc";
import GameConfig from "./GameConfig";
const { ccclass } = _decorator;
@ccclass("TLog")
export class TLog extends Component {
    start() {
    }
    static printMsg(o, n, e, t, s, c, u, g, i) {
        if (0 == GameConfig.HTTP_MSG_DEBUG) {
            return;
        }
        let w = new Date, a = w.getFullYear() + "", p = w.getMonth() + 1;
        a = p < 10 ? a + "-0" + p : a + "-" + p;
        a = w.getDate() < 10 ? a + "-0" + w.getDate() : a + "-" + w.getDate();
        a = w.getHours() < 10 ? a + " 0" + w.getHours() : a + " " + w.getHours();
        a = w.getMinutes() < 10 ? a + ":0" + w.getMinutes() : a + ":" + w.getMinutes();
        a = w.getSeconds() < 10 ? a + ":0" + w.getSeconds() : a + ":" + w.getSeconds();
        null != i ? console.log(o, n, e, t, s, c, u, g, i, sys.now(), a) : null != g ? console.log(o, n, e, t, s, c, u, g, sys.now(), a) : null != u ? console.log(o, n, e, t, s, c, u, sys.now(), a) : null != c ? console.log(o, n, e, t, s, c, sys.now(), a) : null != s ? console.log(o, n, e, t, s, sys.now(), a) : null != t ? console.log(o, n, e, t, sys.now(), a) : null != e ? console.log(o, n, e, sys.now(), a) : null != n ? console.log(o, n, sys.now(), a) : null != o && console.log(o, sys.now(), a);
    }
    static printError(o, n, e, t, s, c, u, g, i) {
        0 != GameConfig.HTTP_MSG_DEBUG && (null != i ? console.error(o, n, e, t, s, c, u, g, i, sys.now()) : null != g ? console.error(o, n, e, t, s, c, u, g, sys.now()) : null != u ? console.error(o, n, e, t, s, c, u, sys.now()) : null != c ? console.error(o, n, e, t, s, c, sys.now()) : null != s ? console.error(o, n, e, t, s, sys.now()) : null != t ? console.error(o, n, e, t, sys.now()) : null != e ? console.error(o, n, e, sys.now()) : null != n ? console.error(o, n, sys.now()) : null != o && console.error(o, sys.now()));
    }
}
