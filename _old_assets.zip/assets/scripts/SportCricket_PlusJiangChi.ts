// @ts-nocheck
// Recovered from index.js:579
import { _decorator, Label, Node, sys, UITransform, v3, view } from "cc";
import SoundManager from "./SoundManager";
import PushCenter from "./PushCenter";
import Utils from "./Utils";
import BaseLayer from "./BaseLayer";
import PushEvent from "./PushEvent";
import TweenTool from "./TweenTool";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("SportCricket_PlusJiangChi")
export class SportCricket_PlusJiangChi extends BaseLayer {
    public TAG: string = "SportCricket_PlusJiangChi";
    @property(Node)
    public rootNode: Node = null;
    public _closed: boolean = false;
    public bShowPushAnim: boolean = false;
    public _lastClick: number = 0;
    public _sourceData: any = null;
    public _isSendMsg: boolean = false;
    public _match_id: number = 0;
    public _source: any = null;
    public _contest_id: number = 0;
    public _closeAct: any = null;
    public _startAct: any = null;
    public _startY: number = 0;
    public _fromType: number = 0;
    onLoad() {
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().removeListenersByTag(this);
        this.unscheduleAllCallbacks();
    }
    init(t) {
        sys.isObjectValid(t) && sys.isObjectValid(t.match_id) && (this._match_id = t.match_id);
        sys.isObjectValid(t) && sys.isObjectValid(t.source) && (this._source = t.source);
        sys.isObjectValid(t) && sys.isObjectValid(t.contest_source) && (this._sourceData = t.contest_source);
        sys.isObjectValid(t) && sys.isObjectValid(t.contest_id) && (this._contest_id = t.contest_id);
        sys.isObjectValid(t) && sys.isObjectValid(t.fromType) && (this._fromType = t.fromType);
    }
    start() {
        super.start();
        this.initView();
        this.refreshView();
        this.showSelectView();
    }
    showSelectView() {
        let t = -view.getVisibleSize().height / 2, e = this.rootNode.getComponent(UITransform).height;
        this._startY = t - e - 20;
        this.rootNode.setPosition(v3(0, this._startY));
        this._startAct = TweenTool.moveTo(this.rootNode, 0.2, v3(0, t), "sineIn", true);
    }
    hideSelectView() {
        this._startAct && TweenTool.stopAction(this._startAct);
        this._closeAct || (this._closeAct = TweenTool.moveTo(this.rootNode, 0.2, v3(0, this._startY), "sineIn", true, (() => {
            ToolUtils.isObjValid(this.node) && this.node.destroy();
        })));
    }
    refreshView() {
        this.updateContestDetails();
    }
    updateContestDetails() {
        sys.isObjectValid(this._sourceData) && (sys.isObjectValid(this._sourceData.all_reward) && (this.rootNode.getChildByName("cur_pool").getComponent(Label).string = "₹" + ToolUtils.parse_double(this._sourceData.all_reward)), sys.isObjectValid(this._sourceData.last_all_reward) && (this.rootNode.getChildByName("max_pool").getComponent(Label).string = "₹" + ToolUtils.parse_double(this._sourceData.last_all_reward)), sys.isObjectValid(this._sourceData.first_reward) && (this.rootNode.getChildByName("cur_first").getComponent(Label).string = "₹" + ToolUtils.parse_double(this._sourceData.first_reward)), sys.isObjectValid(this._sourceData.last_first_reward) && (this.rootNode.getChildByName("max_first").getComponent(Label).string = "₹" + ToolUtils.parse_double(this._sourceData.last_first_reward)), sys.isObjectValid(this._sourceData.current_reward_num) && (this.rootNode.getChildByName("cur_win").getComponent(Label).string = this._sourceData.current_reward_num + " winners"), sys.isObjectValid(this._sourceData.last_reward_num) && (this.rootNode.getChildByName("max_win").getComponent(Label).string = this._sourceData.last_reward_num + " winners"), sys.isObjectValid(this._sourceData.sign_num) && (this.rootNode.getChildByName("cur_spots").getComponent(Label).string = this._sourceData.sign_num + " spots"), sys.isObjectValid(this._sourceData.last_sign_num) && (this.rootNode.getChildByName("max_spots").getComponent(Label).string = this._sourceData.last_sign_num + " spots"));
    }
    onCloseButtonClick(t, e) {
        SoundManager.shared().playFx("click");
        sys.now() - this._lastClick < 500 || (this._lastClick = sys.now(), this.onBackView());
    }
    initView() {
        this.fitScreen();
    }
    onButtonClick(t, e) {
        if (SoundManager.shared().playFx("click"), !(sys.now() - this._lastClick < 500) && (this._lastClick = sys.now(), "winning" == e)) {
            if (this.onBackView(), 0 == this._fromType) {
                let t = { match_id: this._match_id, contest_id: this._contest_id, contest_source: this._sourceData, source: this._source, show_win: 1 };
                Utils.shared().showSportCricket_gameDetails(t);
            }
            else {
                PushCenter.shared().pushEvent(PushEvent.ChangeYes11DetailsWin);
            }
        }
    }
    onBackView(t = true) {
        t && (Utils.shared().hideLoading(), this.hideSelectView());
    }
    fitScreen() {
        ToolUtils.adaptSafeArea(this.rootNode);
        sys.getSafeAreaRect().y;
    }
}
