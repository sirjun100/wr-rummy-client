// @ts-nocheck
// Recovered from index.js:291
import { _decorator, director, game, instantiate, Label, Node, Prefab, sp, Sprite, SpriteFrame, sys, Vec3 } from "cc";
import Parent, { AdapDirection } from "./Parent";
import i18nMgr from "./i18nMgr";
import PushCenter from "./PushCenter";
import { TLog } from "./TLog";
import { ToolUtils } from "./ToolUtils";
import { TransferPlatform } from "./TransferPlatform";
import TweenTool from "./TweenTool";
import Utils from "./Utils";
import CommDefine, { CheckModule } from "./CommDefine";
import GameConfig from "./GameConfig";
import HowToPlayDefined from "./HowToPlayDefined";
import { HttpRequest } from "./HttpRequestName";
import NetConfig from "./NetConfig";
import PhpReportDefined from "./PhpReportDefined";
import PushEvent from "./PushEvent";
import ReportConfig from "./ReportConfig";
import RummyCmd from "./RummyCmd";
import { DeskInfo } from "./DeskInfo";
import User from "./User";
import gameNetworkDelay from "./gameNetworkDelay";
import HttpManager from "./HttpManager";
import Server from "./Server";
import SoundManager from "./SoundManager";
import RummyCardConstant from "./RummyCardConstant";
import RummyDataManager, { RUMMY_GAME_TYPE, RUMMY_MATCH_MODE, RUMMY_MATCH_TYPE, RUMMY_PLAYER_STATE_TYPE } from "./RummyDataManager";
import RummyGameManualSplit from "./RummyGameManualSplit";
import RummyGameOverAlert from "./RummyGameOverAlert";
import RummyGameOverOpenLogic from "./RummyGameOverOpenLogic";
import RummyHandCardDataAnalysis from "./RummyHandCardDataAnalysis";
import { RummyInfo } from "./RummyInfo";
import { RummyLogicProcessing } from "./RummyLogicProcessing";
import RummyOpenCardsAlert from "./RummyOpenCardsAlert";
import RummyPointsMatchOverAlert from "./RummyPointsMatchOverAlert";
import RummyShowTopUiLogic from "./RummyShowTopUiLogic";
import RummyTotalSettlement from "./RummyTotalSettlement";
import BundleNameDefined from "./BundleNameDefined";
const { ccclass, property } = _decorator;
@ccclass("MainRummy")
export default class MainRummy extends Parent {
    @property(Node)
    public playerRoot: Node = null;
    @property(Node)
    public actionRoot: Node = null;
    @property(Node)
    public tableRoot: Node = null;
    @property(Node)
    public tipRoot: Node = null;
    @property(Node)
    public chatRoot: Node = null;
    @property(Node)
    public cardRoot: Node = null;
    @property(Node)
    public autoDrop: Node = null;
    @property(Node)
    public pop_layer1: Node = null;
    @property(Node)
    public pop_layer2: Node = null;
    @property(Node)
    public pop_layer3: Node = null;
    @property(Node)
    public pop_layer4: Node = null;
    @property(Node)
    public pop_layer5: Node = null;
    @property(Node)
    public pop_layer6: Node = null;
    @property(Node)
    public winTips: Node = null;
    @property(Node)
    public node_taskBg: Node = null;
    @property(Prefab)
    public tipRootPrefab: Prefab = null;
    public tipsNode: any = null;
    @property([SpriteFrame])
    public winTipBtnImgs: SpriteFrame[] = [];
    @property(Node)
    public tingpaiNode: Node = null;
    public magicFaceAlertPrefab: any = null;
    public menualertPrefab: any = null;
    public rummyGameManualSplit: any = null;
    public rummyGamePoolPoP: any = null;
    public poolScoreboardView: any = null;
    public openFlag_poolScoreboard: any = null;
    public addGameAlert: any = null;
    public dealsScoreboardView: any = null;
    public openFlag_dealsScoreboard: any = null;
    public tipTopViewNetwork: any = null;
    public gameEndView: any = null;
    public RummyTotalSettlementNode: any = null;
    public gameHistoryView: any = null;
    public openCardPrefab: any = null;
    public openCardNode: any = null;
    public switchJokerPrefab: any = null;
    public switchJokerNode: any = null;
    public topBgNode: any = null;
    public finishType: any = undefined;
    public hasDeclare: any = undefined;
    public game_cd: number = 0;
    public isCanmqp: boolean = false;
    public canTouch: any = undefined;
    public drop_money: any = undefined;
    public isOpenQipai: any = undefined;
    public winPos: any = undefined;
    public rummyEndJpacket: any = undefined;
    public isUpdateMyMoney: boolean = true;
    public playerTs: any = undefined;
    public cardsTs: any = undefined;
    public actionTs: any = undefined;
    public tipTs: any = undefined;
    public autoDropTs: any = undefined;
    public playerInfoPop: any = null;
    public roomInfoTs: any = null;
    public newPlayerGuideTs: any = null;
    public roomInfoMsg: any = null;
    public roomInfoNode: any = null;
    public isDisconnect: boolean = false;
    public tid_key: string = "";
    public desk_index: number = 0;
    public isNewTable: number = 0;
    public skinStyles: any[] = [];
    public is_first_round: boolean = false;
    public recon_total_cd: number = 0;
    public autoReadyTime: number = 0;
    public isGameStarting: boolean = false;
    public time_action: any = null;
    public time_node: any = null;
    public action_node: any = null;
    public time_schedule: any = null;
    public has_showQuick_charge: boolean = false;
    public match_vid: number = 0;
    public ticket_mode: any = null;
    public mng_sid: any = null;
    public top_bg_hongdian: number = 0;
    public matchRankCurPage: number = 1;
    public matchRankTotalPage: number = 0;
    public is_data_reporting: boolean = true;
    public ceshiNum: number = 0;
    public testNum: number = 0;
    public pool_time_action: any = null;
    public start_time_action: any = null;
    public practice_action: any = null;
    public matchover_action: any = null;
    public delayShowGameOver_action: any = null;
    public hide_win_tip_action: any = null;
    public switch_tab_action: any = null;
    public _bIsWinnerAnimEnd: boolean = true;
    public _bIsGameEnd: boolean = false;
    public _bGameOverClosed: boolean = false;
    public delay_ready_action: any = null;
    public _bIsShowWaitDeclare: boolean = false;
    public _bIsCanSwitch: boolean = true;
    public _bIsCanFresh: boolean = true;
    public _nRobotPlayerCount: number = 0;
    public _bIsShowReady: boolean = true;
    public _isClickLeaveTable: boolean = false;
    public _isFaPaiAnim: boolean = false;
    public _lastChangeDeskTime: number = 0;
    public _bIsCanFinish: boolean = true;
    public _isPlayWinEffec: boolean = false;
    public _isShowTableinfo: boolean = false;
    public _pQipai_action: any = null;
    public isZhahuHupai: boolean = false;
    public gameOverOpenLogic: any = null;
    public rummyShowTopUiLogic: any = null;
    public rummyLogicProcessing: any = null;
    public switchPaySuccess: boolean = false;
    public serverUpdateTipsShow: boolean = false;
    public _hasSendMsg: boolean = false;
    public _guideJumpPricticeReq: boolean = false;
    public _bIsShowWinTip: boolean = false;
    public _lastClick: number = 0;
    public winTipBgPos: Vec3 = new Vec3;
    public roomPerformance: any = null;
    public tingPaiTs: any = null;
    public pickCardInfo: any = null;
    public helper_hu_card: number = 0;
    public finish_groups: any = null;
    public quick_sort: number = 0;
    public qipaiCardValues: any[] = [];
    public hasPlayOutLocalCard: boolean = false;
    public handCardDataAnalysis: any = null;
    public req_id: number = 0;
    public moveCard_action: any = null;
    public game_chatPrefab: any = null;
    public game_chatNode: any = null;
    public game_chatTs: any = null;
    public can_declare: number = 0;
    public gameStartMsg: any = undefined;
    public cardInfoMsg: any = null;
    public _gameOverMsg: any = null;
    public _lastGameOverMsg: any = null;
    public _playerEnterMsg: any[] = [];
    public _playerExitMsg: any[] = [];
    public tingPaiMsg: any = null;
    public room_act_rankNode: any = null;
    public has_room_act: boolean = false;
    public match_wait_info: any = null;
    public match_reward_info: any = null;
    public match_name: string = "";
    public delayFreeMatchAct: any = null;
    public hasFreeMatchPush: boolean = false;
    public freeMatchRaceId: any = null;
    public matchTotalSettleMsg: any = null;
    public hasPointsMatchExitAlert: boolean = false;
    public has_treasureHuntAct: boolean = false;
    public upvenue_entry_fee: any = -1;
    public hasShowSwitchSkinTips: boolean = false;
    public treahuntTaskData: any = null;
    public checkTreasureHunt: boolean = false;
    public match_rejoinid: number = 0;
    public match_anim_tip_action: any = null;
    public discardAutoSortGroupIds: any[] = [];
    start() {
    }
    onLoad() {
        GameConfig.HasInGameRoom = true;
        this.playerTs = this.playerRoot.getComponent("RummyPlayerRoot");
        this.cardsTs = this.cardRoot.getComponent("RummyGameCards");
        this.actionTs = this.actionRoot.getComponent("RummyActionRoot");
        try {
            this.tipsNode = instantiate(this.tipRootPrefab);
            ToolUtils.isObjValid(this.tipsNode) && (this.tipRoot.addChild(this.tipsNode), this.tipTs = this.tipsNode.getComponent("RummyTipRoot"), this.tipTs.setCallBack(this.onDealBtnAction.bind(this)), this.tipTs.changeTuoguanVisible(false));
        }
        catch (e) {
            TLog.printError("-------- create tipRoot error:", e);
        }
        this.autoDropTs = this.autoDrop.getComponent("RummyAutoDrop");
        this.autoDropTs.setCallBack(this.onDealBtnAction.bind(this));
        this.tingPaiTs = this.tingpaiNode.getComponent("RummyTingPai");
        this.tingPaiTs.cardsTs = this.cardsTs;
        null == this.gameOverOpenLogic && (this.gameOverOpenLogic = new RummyGameOverOpenLogic, this.gameOverOpenLogic.init(this));
        null == this.rummyShowTopUiLogic && (this.rummyShowTopUiLogic = new RummyShowTopUiLogic, this.rummyShowTopUiLogic.init(this));
        null == this.handCardDataAnalysis && (this.handCardDataAnalysis = new RummyHandCardDataAnalysis, this.handCardDataAnalysis.init(this), this.cardsTs.handCardDataAnalysis = this.handCardDataAnalysis);
        null == this.rummyLogicProcessing && (this.rummyLogicProcessing = new RummyLogicProcessing, this.rummyLogicProcessing.init(this));
        this.isDisconnect = false;
        this.is_data_reporting = true;
        User.shared().ruleFlag = "rummy";
        ToolUtils.isInGameScene = 1;
        User.shared()._nBackToHallGameId = HowToPlayDefined.gameId_RummyGame;
        this._playerEnterMsg = [];
        this._playerExitMsg = [];
        this.playerTs.setPaiDuiBgShow(false);
        this.actionTs.changeCenterFinishBtnStatus(false);
        this.updateTaskRed();
        this.updateTaskBtn();
        let e = this.node.getChildByName("rootNode").getChildByName("smallGamebg");
        this.resetUiPos(e, AdapDirection.Right, true, 1, true);
        this.node_taskBg.getPosition(this.winTipBgPos);
        this.initPushCenter();
        1 !== User.shared().isInPerformanceRoom && TweenTool.delayAct(RummyDataManager.shared().sceneNode, (() => {
            ToolUtils.isObjValid(this.node) && this.loadDailyTaskBubble(false);
        }), 1, true);
        this._bIsShowWinTip = false;
        let t = sys.localStorage.getItem("finish_conditions_def");
        null == t && (t = User.shared().help_setting.finish_conditions_def);
        sys.isObjectValid(t) && 1 == User.shared().help_setting.finish_conditions && 1 == Number(t) && (this._bIsShowWinTip = true);
        ToolUtils.isPadPlatform() && this.resetUiPos(this.tableRoot.getChildByName("delalsRummy6Player"), AdapDirection.Up, true, 1, false);
    }
    loadDailyTaskBubble(e, t = 1, s = null) {
        this.rummyShowTopUiLogic && this.rummyShowTopUiLogic.loadDailyTaskBubble(e, t, s);
    }
    initPushCenter() {
        PushCenter.shared().addListener(PushEvent.UpdateTaskRed, (e => {
            ToolUtils.isObjValid(this.node) && this.updateTaskRed();
        }), this);
        PushCenter.shared().addListener(PushEvent.UpdateRoomTaskBtn, (e => {
            ToolUtils.isObjValid(this.node) && this.updateTaskBtn();
        }), this);
        PushCenter.shared().addListener(GameConfig.Update_Money, (e => {
            ToolUtils.isObjValid(this.node) && this.updateGold(e);
        }), this);
        PushCenter.shared().addListener(PushEvent.UpdatePractiseGold, (e => {
            ToolUtils.isObjValid(this.node) && RummyDataManager.shared().rummyInfos.get(this.tid_key) && 1 !== User.shared().isInPerformanceRoom && (1 == RummyDataManager.shared().rummyInfos.get(this.tid_key).crashModel ? this.playerTs.updateSeatMoneyInfo(0, User.shared().data.money_exe) : this.playerTs.updateSeatMoneyInfo(0, User.shared().data.money));
        }), this);
        PushCenter.shared().addListener(GameConfig.BackKey_Clicked, (e => {
            if (ToolUtils.isObjValid(this.node) && this.node.active) {
                if (!RummyDataManager.shared().bCanGoBack) {
                    return void Utils.shared().showToast("Poor network, please try again later!", 2, 0, ToolUtils.getIsNormalDirection());
                }
                if (Utils.shared().mackCallBackStatus(), User.shared().popNode && User.shared().popNode.length > 0) {
                    let e = User.shared().popNode[User.shared().popNode.length - 1];
                    ToolUtils.isObjValid(e) && PushCenter.shared().pushEvent(GameConfig.BackKey_Event, { nodeName: e.name });
                }
                else {
                    let e = RummyDataManager.shared().rummyInfos.get(this.tid_key).popNode;
                    if (e && e.length > 0) {
                        let t = e[e.length - 1];
                        ToolUtils.isObjValid(t) && PushCenter.shared().pushEvent(GameConfig.BackKey_Event, { nodeName: t.name, tid_key: this.tid_key });
                    }
                    else {
                        this.tipsNode.getChildByName("tuoguan_bg").active ? this.onDealBtnAction("tuoguan_back") : this.onDealExitGame(true);
                    }
                }
            }
        }), this);
        PushCenter.shared().addListener(PushEvent.pushGamePopNode, (e => {
            if (e.tid_key == this.tid_key && ToolUtils.isObjValid(e.node)) {
                const room = RummyDataManager.shared().rummyInfos.get(this.tid_key);
                if (room && !room.popNode.includes(e.node)) room.popNode.push(e.node);
            }
        }), this);
        PushCenter.shared().addListener(PushEvent.removeGamePopNode, (e => {
            if (e.tid_key == this.tid_key) {
                let t = RummyDataManager.shared().rummyInfos.get(this.tid_key).popNode;
                if (t && t.length > 0) {
                    let s = t[t.length - 1];
                    ToolUtils.isObjValid(s) && e.node.name == s.name && RummyDataManager.shared().rummyInfos.get(this.tid_key).popNode.pop();
                }
            }
        }), this);
        PushCenter.shared().addListener(GameConfig.RefreshRummyTableInfo, (e => {
            e == this.tid_key && ToolUtils.isObjValid(this.node) && this.send_request_tableinfo();
        }), this);
        PushCenter.shared().addListener(PushEvent.UpdateRaceCSS, (() => {
            this.rummyLogicProcessing.send_req_small_table_info();
        }), this);
        PushCenter.shared().addListener(PushEvent.Setting_Auto_sort, (e => {
            ToolUtils.isObjValid(this.node) && this.rummyLogicProcessing.send_auto_sort_request();
        }), this);
        PushCenter.shared().addListener(GameConfig.ShowMatchJoinTips, (e => {
            this.showMatchJoinTips(e);
        }), this);
        PushCenter.shared().addListener(GameConfig.ShowMatchOverInfo, (e => {
            let t = ToolUtils.parseJson(e);
            t.raceid == RummyDataManager.shared().rummyInfos.get(this.tid_key).raceid && RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType == RUMMY_GAME_TYPE.MATCH && this.showMatchOverView(t);
        }), this);
        PushCenter.shared().addListener(PushEvent.RummyGameBGZD, (e => {
            if (this.tid_key == e) {
                let e = this.node.getChildByName("rootNode"), t = TweenTool.moveTo(e, 0.891 - 0.825, new Vec3(0, 4), "quadIn", false), s = TweenTool.moveTo(e, 0.957 - 0.891, new Vec3(0, -4), "quadIn", false), i = TweenTool.moveTo(e, 1.033 - 0.957, new Vec3(0, 0), "quadIn", false);
                TweenTool.sequence(e, false, null, t, s, i).start();
            }
        }), this);
        PushCenter.shared().addListener(PushEvent.RewardTipsBackToHall, (e => {
            ToolUtils.isObjValid(this.node) && e === this.tid_key && this.exitCallBack(1);
        }), this);
        PushCenter.shared().addListener(PushEvent.commentDownloaderImg, (e => {
            if (ToolUtils.isObjValid(this.node)) {
                for (let t = 0; t < 6; t++) {
                    let s = RummyDataManager.shared().rummyInfos.get(this.tid_key).playerModels[t];
                    if (s.avatar_url == e && 1 != RummyDataManager.shared().rummyInfos.get(this.tid_key).ding_zhuang_seat_state) {
                        let e = this.getPosBySeatid(s.seatid);
                        this.playerTs.updatePlayerHead(e, s.avatar, s.avatar_url);
                    }
                }
            }
        }), this);
        PushCenter.shared().addListener(PushEvent.replaceTableTidKey, (e => {
            this.replaceTableTidKey(e);
        }), this);
        PushCenter.shared().addListener(PushEvent.onBackGameCheckStatus, (e => {
            0 == User.shared().b_storeLevel && 1 == RummyDataManager.shared().rummyInfos.get(this.tid_key).bIsAddSwitchRoom && TweenTool.delayAct(RummyDataManager.shared().sceneNode, (() => {
                this.switchPaySuccess && (this.switchCallback(), this.switchPaySuccess = false);
                sys.isObjectValid(RummyDataManager.shared().rummyInfos.get(this.tid_key)) && sys.isObjectValid(RummyDataManager.shared().rummyInfos.get(this.tid_key).bIsAddSwitchRoom) && (RummyDataManager.shared().rummyInfos.get(this.tid_key).bIsAddSwitchRoom = false);
            }), 0.5, true);
        }), this);
        PushCenter.shared().addListener(PushEvent.LeaveStore, (e => {
            null != e.tid_key && e.tid_key === this.tid_key && 1 == RummyDataManager.shared().rummyInfos.get(this.tid_key).bIsAddSwitchRoom && TweenTool.delayAct(RummyDataManager.shared().sceneNode, (() => {
                this.switchPaySuccess && (this.switchCallback(), this.switchPaySuccess = false);
                sys.isObjectValid(RummyDataManager.shared().rummyInfos.get(this.tid_key).bIsAddSwitchRoom) && (RummyDataManager.shared().rummyInfos.get(this.tid_key).bIsAddSwitchRoom = false);
            }), 0.5, true);
        }), this);
        PushCenter.shared().addListener(PushEvent.SwitchTabEvent, (e => {
            null != e.tid_key && e.tid_key === this.tid_key && (this.switchPaySuccess = true);
        }), this);
        PushCenter.shared().addListener(PushEvent.ShowPrivateInviteBtn, (e => {
            ToolUtils.isObjValid(this.node) && e == this.tid_key && RummyDataManager.shared().rummyInfos.has(this.tid_key) && (RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType != RUMMY_GAME_TYPE.PRIVATE && this.removeGameOverView(), RummyDataManager.shared().rummyInfos.get(this.tid_key).roomPlayerCounter < RummyDataManager.shared().rummyInfos.get(this.tid_key).pnum && (this.actionTs.showInviteBtn(), this.actionTs.showCopyBtn()));
        }), this);
        PushCenter.shared().addListener(PushEvent.updateAutoGroup, (e => {
            ToolUtils.isObjValid(this.node) && this.tid_key == (e.tid_key || "") && (SoundManager.shared().playFx("click"), this.onDealBtnAction(e.eventData));
        }), this);
        PushCenter.shared().addListener(PushEvent.RoomShowTaskGouAnim, (e => {
            ToolUtils.isObjValid(this.node) && (this.tid_key == User.shared().curTid_key ? (this.actionTs.changeTaskAnimVisible(true), User.shared().getRoomRoomInfo(RummyDataManager.shared().rummyInfos.get(this.tid_key).vid, PushEvent.JUMP_TO_NEW_NOVICESTASK)) : this.actionTs.changeTaskRedDotVisible(true));
        }), this);
        PushCenter.shared().addListener(PushEvent.RoomShowSingleDailyTaskBubble, (e => {
            if (ToolUtils.isObjValid(this.node)) {
                if (e.vid == RummyDataManager.shared().rummyInfos.get(this.tid_key).vid && !this.actionTs.getTaskTipsVisible()) {
                    let t = e.taskData;
                    this.loadDailyTaskBubble(true, 0, t);
                }
            }
        }), this);
        PushCenter.shared().addListener(PushEvent.RoomShowDailyTaskListBubble, (e => {
            if (ToolUtils.isObjValid(this.node) && this.tid_key == User.shared().curTid_key) {
                let t = 1 == e.complete ? 1.3 : 0;
                TweenTool.delayAct(RummyDataManager.shared().sceneNode, (() => {
                    ToolUtils.isObjValid(this.node) && this.loadDailyTaskBubble(true, 1);
                }), t, true);
            }
        }), this);
        PushCenter.shared().addListener(PushEvent.RoomShowDailyTaskGouAnim, (e => {
            ToolUtils.isObjValid(this.node) && (this.tid_key == User.shared().curTid_key ? (this.actionTs.changeTaskAnimVisible(true), User.shared().getRoomRoomInfo(RummyDataManager.shared().rummyInfos.get(this.tid_key).vid, PushEvent.JUMP_TO_DAILYTASK)) : this.actionTs.changeTaskRedDotVisible(true));
        }), this);
        PushCenter.shared().addListener(PushEvent.CloseRoomPerformance, (e => {
            ToolUtils.isObjValid(this.node) && this.backToHall();
        }), this);
        PushCenter.shared().addListener(PushEvent.ShowCouponAct, (e => {
            ToolUtils.isObjValid(this.node) && Utils.shared().showCouponActView(null, e);
        }), this);
        PushCenter.shared().addListener(PushEvent.UpdateAutoDeclareStatus, (e => {
            ToolUtils.isObjValid(this.node) && e.tid_key != this.tid_key && RummyDataManager.shared().rummyInfos.get(this.tid_key).autoDeclareStatus != e.status && this.rummyLogicProcessing.handler_server_Auto_declare_request(e.status);
        }), this);
        PushCenter.shared().addListener(PushEvent.onGameSwitchChanged, (e => {
            if (ToolUtils.isObjValid(this.node)) {
                this._bIsShowWinTip = false;
                let e = sys.localStorage.getItem("finish_conditions_def");
                null == e && (e = User.shared().help_setting.finish_conditions_def);
                sys.isObjectValid(e) && 1 == User.shared().help_setting.finish_conditions && 1 == Number(e) && (this._bIsShowWinTip = true);
                this._bIsShowWinTip ? (this.winTips.active = true, this.node_taskBg.active ? this.winTips.getChildByName("icon").getComponent(Sprite).spriteFrame = this.winTipBtnImgs[1] : this.winTips.getChildByName("icon").getComponent(Sprite).spriteFrame = this.winTipBtnImgs[0]) : (this.winTips.active = false, this.node_taskBg.active = false, this.winTips.getChildByName("icon").getComponent(Sprite).spriteFrame = this.winTipBtnImgs[0], RummyDataManager.shared().stopTweenAction(this.hide_win_tip_action));
                let t = this.cardsTs.cardViewVec.length;
                0 != RummyDataManager.shared().rummyInfos.get(this.tid_key).disCardTipsValue && this.cardsTs.beginFaPaiWithoutAnim(RummyDataManager.shared().rummyInfos.get(this.tid_key).cardInfoModelVec, RummyDataManager.shared().rummyInfos.get(this.tid_key).cardInfoModelVec.length);
                this.refreshTingPaiSwitch();
                14 == t && RummyDataManager.shared().getCanShowQuickFinish() && 0 !== this.helper_hu_card && this.cardsTs.showHelperQuickFinishCard(this.helper_hu_card, false, this.tingPaiMsg);
            }
        }), this);
        PushCenter.shared().addListener(PushEvent.RefreshTingPaiCards, (e => {
            ToolUtils.isObjValid(this.node) && this.refreshTingPaiSwitch();
        }), this);
        PushCenter.shared().addListener(PushEvent.EasyGameIntroduce, (e => {
            if (ToolUtils.isObjValid(this.node) && sys.isObjectValid(User.shared().points_easy_cfg)) {
                let e = 1 == User.shared().points_easy_cfg.show_game_introduce;
                this.actionTs.setEasyHelpBtnVisible(e);
            }
        }), this);
        PushCenter.shared().addListener(PushEvent.MultipleGameIntroduce, (e => {
            if (ToolUtils.isObjValid(this.node)) {
                if (1 == RummyDataManager.shared().rummyInfos.get(this.tid_key).is_multiple && sys.isObjectValid(User.shared().points_multiple_cfg)) {
                    let e = 1 == User.shared().points_multiple_cfg.show_game_introduce;
                    this.actionTs.setMultipleHelpBtnVisible(e);
                }
            }
        }), this);
        PushCenter.shared().addListener(GameConfig.Hall_MemberShip_info, (e => {
            ToolUtils.isObjValid(this.node) && this.updateMemberShipInfo();
        }), this);
        PushCenter.shared().addListener(PushEvent.GameOverShowFreeMatchPush, (e => {
            if (ToolUtils.isObjValid(this.node)) {
                let e = RummyDataManager.shared().rummyInfos.get(this.tid_key);
                sys.isObjectValid(e) && 1 == e.able_race_push && this.rummyLogicProcessing.send_request_get_push_match_event(1);
            }
        }), this);
        PushCenter.shared().addListener(PushEvent.FreeMatchPushJoinSuccess, (e => {
            ToolUtils.isObjValid(this.node) && (this.tipTs.setFreeMatchPushActive(false), this.actionTs.changeMatchRankBtnVisibile(false), this.hasFreeMatchPush = false);
        }), this);
        PushCenter.shared().addListener(PushEvent.FreeMatchPushHide, (e => {
            ToolUtils.isObjValid(this.node) && this.rummyLogicProcessing.send_request_close_match_push();
        }), this);
        PushCenter.shared().addListener(PushEvent.CloseCommonAlert, (e => {
            ToolUtils.isObjValid(this.node) && (this.hasPointsMatchExitAlert = false);
        }), this);
        PushCenter.shared().addListener(PushEvent.NotifyGameDisplayModify, (e => {
            ToolUtils.isObjValid(this.node) && this.rummyLogicProcessing.send_request_notify_effect_modify();
        }), this);
        PushCenter.shared().addListener(PushEvent.ReceiveTreaHuntMarquee, (e => {
            if (ToolUtils.isObjValid(this.node) && RummyDataManager.shared().rummyInfos.get(this.tid_key).vid == e.vid && this.has_treasureHuntAct) {
                this.treahuntTaskData = JSON.parse(JSON.stringify(e));
                1 == RummyDataManager.shared().rummyInfos.get(this.tid_key).crashModel && (RummyDataManager.shared().rummyInfos.get(this.tid_key).act97_data = this.treahuntTaskData);
                let t = { vid: e.vid, show_box: Number(e.show_box), box_type: Number(e.box_type), pnum: RummyDataManager.shared().rummyInfos.get(this.tid_key).pnum, data: e, gameBaseMoney: RummyDataManager.shared().rummyInfos.get(this.tid_key).gameBaseMoney };
                sys.isObjectValid(e.show_box) && (RummyDataManager.shared().rummyInfos.get(this.tid_key).show_box_act97 = Number(e.show_box), RummyDataManager.shared().rummyInfos.get(this.tid_key).box_type_act97 = Number(e.box_type), this.actionTs.updateTreasureHuntBox(Number(e.show_box), Number(e.box_type)));
                1 == RummyDataManager.shared().rummyInfos.get(this.tid_key).crashModel && PushCenter.shared().pushEvent(PushEvent.UpdateTreaBoxStateInGame, t);
                this.actionTs.updateTreasureHuntBtn(1, e);
            }
        }), this);
        PushCenter.shared().addListener(PushEvent.UpdateTreaHuntProgress, (e => {
            ToolUtils.isObjValid(this.node);
        }), this);
        PushCenter.shared().addListener(PushEvent.EnterSwitchScene, (e => {
            ToolUtils.isObjValid(this.node) && (RummyDataManager.shared().stopTweenActionByNode(this.node), RummyDataManager.shared().stopTweenActionByNode(this.time_node), RummyDataManager.shared().stopTweenActionByNode(this.action_node));
        }), this);
        PushCenter.shared().addListener(PushEvent.ShowSwitchGameSkinTips, (e => {
            if (ToolUtils.isObjValid(this.node)) {
                if (this.hasShowSwitchSkinTips) {
                    return;
                }
                this.tipTs.showSwitchSkinTips(true);
                this.hasShowSwitchSkinTips = true;
            }
        }), this);
        PushCenter.shared().addListener(PushEvent.UpdateTreaBoxStateInGame, (e => {
            ToolUtils.isObjValid(this.node) && this.updateTreaBoxStatus(e);
        }), this);
        PushCenter.shared().addListener(PushEvent.HideSwitchGameSkinTips, (e => {
            ToolUtils.isObjValid(this.node) && this.tipTs.showSwitchSkinTips(false);
        }), this);
        PushCenter.shared().addListener(PushEvent.UpdateBonusGiftStatus, (e => {
            ToolUtils.isObjValid(this.node) && this.reportBonusStatus(e);
        }), this);
        PushCenter.shared().addListener(PushEvent.UpdateRoomTaskProgess, (e => {
            if (ToolUtils.isObjValid(this.node) && sys.isObjectValid(e)) {
                let t = e.progress;
                sys.isObjectValid(t) && t.vid == RummyDataManager.shared().rummyInfos.get(this.tid_key).vid && this.rummyLogicProcessing.updateNovicesTask(t);
            }
        }), this);
        PushCenter.shared().addListener(PushEvent.ShowGameOverNovicesBanner, (e => {
            if (ToolUtils.isObjValid(this.node) && sys.isObjectValid(e)) {
                let t = e.progress;
                sys.isObjectValid(t) && t.vid == RummyDataManager.shared().rummyInfos.get(this.tid_key).vid && (RummyDataManager.shared().rummyInfos.get(this.tid_key).novicesGameOverLaba = t, this.rummyLogicProcessing.updateGameOverNovices());
            }
        }), this);
        PushCenter.shared().addListener(PushEvent.UpdateRoomFlopCrashTaskProgess, (e => {
            if (ToolUtils.isObjValid(this.node) && sys.isObjectValid(e)) {
                let t = RummyDataManager.shared().rummyInfos.get(this.tid_key), s = 0;
                if (t.gameRummyType == RUMMY_GAME_TYPE.POINTS || t.gameRummyType == RUMMY_GAME_TYPE.MULTIPLE ? s = 0 : t.gameRummyType == RUMMY_GAME_TYPE.DEALS ? s = 2 : t.gameRummyType == RUMMY_GAME_TYPE.POOL && (s = 1), 0 == t.crashModel && sys.isObjectValid(e)) {
                    let i = t.flopCashTaskLaba;
                    sys.isObjectValid(i) && sys.isObjectValid(i.current_task_status) && 2 == i.current_task_status || e.vid != t.vid && s != e.rummy_type || (this.tid_key == e.tid_key && (t.flopCashTaskLaba = e), this.rummyLogicProcessing.updateGameOverFlopCash(), this.actionTs.updateFlopCashStatus(true, e));
                }
                RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType != RUMMY_GAME_TYPE.DEALS && RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType != RUMMY_GAME_TYPE.POOL ? e.vid == t.vid && this.rummyLogicProcessing.updateFlopCashTask(e) : ToolUtils.isObjValid(this.RummyTotalSettlementNode) ? t.gameRummyType != RUMMY_GAME_TYPE.MATCH && e.vid == t.vid && sys.isObjectValid(e) && sys.isObjectValid(e.tid_key) && this.rummyLogicProcessing.updateFlopCashTask(e) : sys.isObjectValid(e) && sys.isObjectValid(e.tid_key) && e.vid == t.vid && this.tid_key == e.tid_key && (RummyDataManager.shared().rummyInfos.get(this.tid_key).flopTempTaskInfo = e);
            }
        }), this);
        PushCenter.shared().addListener(PushEvent.NoticeFinishFlop, (e => {
            ToolUtils.isObjValid(this.node) && sys.isObjectValid(e) && e == this.tid_key && this.rummyLogicProcessing.send_request_flopcash_ok(0);
        }), this);
        PushCenter.shared().addListener(PushEvent.NoticeFinishFlopStart, (e => {
            ToolUtils.isObjValid(this.node) && this.tid_key == e && RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType != RUMMY_GAME_TYPE.DEALS && RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType != RUMMY_GAME_TYPE.POOL && (1 == RummyDataManager.shared().rummyInfos.get(this.tid_key).is_waiting ? this.switchRoom(5) : ToolUtils.isObjValid(this.gameEndView) ? this.onDealBtnAction("start") : this.actionTs.isSwitchBtnVisbile() ? this.onDealBtnAction("switch") : this.onDealBtnAction("refresh"));
        }), this);
        PushCenter.shared().addListener(PushEvent.Update_CheckFlopTaskGame, (e => {
            ToolUtils.isObjValid(this.node) && sys.isObjectValid(e) && e == this.tid_key && sys.isObjectValid(RummyDataManager.shared().rummyInfos.get(this.tid_key).flopTempTaskInfo) && this.rummyLogicProcessing.updateFlopCashTask(RummyDataManager.shared().rummyInfos.get(this.tid_key).flopTempTaskInfo);
        }), this);
        PushCenter.shared().addListener(PushEvent.ShowRoomQuickCharge, (e => {
            ToolUtils.isObjValid(this.node) && sys.isObjectValid(e) && e == this.tid_key && this.myTurnFastBuyCallback(1);
        }), this);
        PushCenter.shared().addListener(PushEvent.NoticeFinishFlop, (e => {
            ToolUtils.isObjValid(this.node) && sys.isObjectValid(e) && e == this.tid_key && this.rummyLogicProcessing.send_request_flopcash_ok(0);
        }), this);
        PushCenter.shared().addListener(PushEvent.NoticeFinishFlopStart, (e => {
            ToolUtils.isObjValid(this.node) && this.tid_key == e && (1 == RummyDataManager.shared().rummyInfos.get(this.tid_key).is_waiting ? this.switchRoom(5) : ToolUtils.isObjValid(this.gameEndView) ? this.onDealBtnAction("start") : this.actionTs.isSwitchBtnVisbile() ? this.onDealBtnAction("switch") : this.onDealBtnAction("refresh"));
        }), this);
        PushCenter.shared().addListener(PushEvent.ShowTwentyFourRecharge, (e => {
            sys.isObjectValid(e) && null != e.tid_key && ToolUtils.isObjValid(this.node) && ToolUtils.isObjValid(this.node) && (undefined !== e.parent_node && null !== e.parent_node || (e.parent_node = this.node), e.vid = RummyDataManager.shared().rummyInfos.get(this.tid_key).vid, e.in_room = 1, Utils.shared().showTwentyHourRecharge(e));
        }), this);
        PushCenter.shared().addListener(PushEvent.ShowBuyOneGetThree, (e => {
            sys.isObjectValid(e) && null != e.tid_key && ToolUtils.isObjValid(this.node) && ToolUtils.isObjValid(this.node) && (undefined !== e.parent_node && null !== e.parent_node || (e.parent_node = this.node), e.vid = RummyDataManager.shared().rummyInfos.get(this.tid_key).vid, e.in_room = 1, Utils.shared().showBuyOneGetThree(e));
        }), this);
        PushCenter.shared().addListener(PushEvent.ShowFirstRecharge, (e => {
            sys.isObjectValid(e) && null != e.tid_key && ToolUtils.isObjValid(this.node) && ToolUtils.isObjValid(this.node) && (undefined !== e.parent_node && null !== e.parent_node || (e.parent_node = this.node), e.vid = RummyDataManager.shared().rummyInfos.get(this.tid_key).vid, e.in_room = 1, Utils.shared().showFirstRecharge_game2(e));
        }), this);
        PushCenter.shared().addListener(PushEvent.CloseFirstRecharge, (e => {
            if (ToolUtils.isObjValid(this.node)) {
                let e = this.node.getChildByName("FirstRecharge");
                if (ToolUtils.isObjValid(e)) {
                    return void e.removeFromParent();
                }
                let t = director.getScene().getChildByName("Canvas");
                if (ToolUtils.isObjValid(t)) {
                    let e = t.getChildByName("FirstRecharge");
                    ToolUtils.isObjValid(e) && e.removeFromParent();
                }
            }
        }), this);
        PushCenter.shared().addListener(PushEvent.ShowRestartGift, (e => {
            sys.isObjectValid(e) && null != e.tid_key && e.tid_key === this.tid_key && (undefined !== e.parent_node && null !== e.parent_node || (e.parent_node = director.getScene().getChildByName("Canvas")), e.vid = RummyDataManager.shared().rummyInfos.get(this.tid_key).vid, e.in_room = 1, Utils.shared().showRestartGift(e));
        }), this);
        PushCenter.shared().addListener(PushEvent.ShowConsecutiveGift, (e => {
            sys.isObjectValid(e) && null != e.tid_key && e.tid_key === this.tid_key && ToolUtils.isObjValid(this.node) && (undefined !== e.parent_node && null !== e.parent_node || (e.parent_node = this.node), e.vid = RummyDataManager.shared().rummyInfos.get(this.tid_key).vid, e.in_room = 1, Utils.shared().showConsecutiveGift(e));
        }), this);
        PushCenter.shared().addListener(PushEvent.Update_Gullak_State, (e => {
            if (ToolUtils.isObjValid(this.node)) {
                let e = RummyDataManager.shared().rummyInfos.get(this.tid_key);
                sys.isObjectValid(e) && e.gameRummyType != RUMMY_GAME_TYPE.MATCH && 0 == e.crashModel && this.actionTs.updateGullakBtnStatus(User.shared().act_68_open, User.shared().act_68_full_status, true);
            }
        }), this);
        PushCenter.shared().addListener(PushEvent.Notice_VipUpdateShow, (e => {
            ToolUtils.isObjValid(this.node) && this.send_pause_auto_next_round();
        }), this);
        PushCenter.shared().addListener(PushEvent.Notice_VipUpdateHide, (e => {
            ToolUtils.isObjValid(this.node) && (Utils.shared().checkHasPopView(this.node) || sys.isObjectValid(ToolUtils.flopActInGameData) || this.reportSever());
        }), this);
    }
    reportSever() {
        let e = { cmd: NetConfig.CLIENT_NOTIFY_GOBACK_GAME, uid: User.shared().data.uid, type: 2, tid_key: this.tid_key };
        Server.shared().send(e);
    }
    send_pause_auto_next_round() {
        let e = { cmd: RummyCmd.GM_PAUSE_AUTO_NEXT_ROUND, uid: User.shared().data.uid, version: GameConfig.Server_Api_Ver, skey: User.shared().getSkey(), tid_key: this.tid_key };
        Server.shared().send(e);
    }
    reportBonusStatus(e) {
        this.rummyLogicProcessing.send_bonusgift_status(e);
    }
    initDesk(e) {
        this.upvenue_entry_fee = -1;
        this.time_node = new Node;
        RummyDataManager.shared().actionNode.addChild(this.time_node);
        this.action_node = new Node;
        RummyDataManager.shared().actionNode.addChild(this.action_node);
        let t = ToolUtils.deskInfos.get(e);
        this.tid_key = e;
        this.init(t);
        RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType = User.shared().gameRummyType;
        let s = ToolUtils.deskInfos.get(this.tid_key);
        if (sys.isObjectValid(s) && (RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType = s.mode, RummyDataManager.shared().rummyInfos.get(this.tid_key).gameMatchMode = s.match_mode), RummyDataManager.shared().rummyInfos.get(this.tid_key).pnum = t.pnum, this.cardsTs.tid_key = e, this.playerTs.tid_key = e, this.tipTs.tid_key = e, this.actionTs.tid_key = e, this.tingPaiTs.tid_key = e, this.tipTs.refreshcolor(), this.cardsTs.initGameCardView(), this.cardsTs.refreshdisCardLineBg(), this.actionTs.initActionView(), this.playerTs.updateClientInfo(), this.playerTs.refreshFontColor(), this.tipTs.showSwitchSkinTips(false), this.baseExe(), ToolUtils.deskInfos.has(e)) {
            let t = ToolUtils.deskInfos.get(e);
            sys.isObjectValid(t) && t.mode == RUMMY_GAME_TYPE.MATCH && User.shared().requestShareGetGameShare();
        }
        this.tid_key !== CommDefine.NewerGuideRoomTidkey ? (TweenTool.delayAct(this.action_node, (() => {
            this.send_request_tableinfo();
        }), game.frameTime / 1000, true), this.cardsTs.preInintCardPool(), TweenTool.delayAct(RummyDataManager.shared().sceneNode, (() => {
            ToolUtils.isObjValid(this.node) && this.rummyShowTopUiLogic.showGameChat();
        }), 0.5, true)) : (this.actionTs.ishudongshow(false), this.actionTs.menuBtnIsViseble(false), this.tipTs.hideWrongTips());
        let i = this;
        this.time_schedule = TweenTool.myschedule(RummyDataManager.shared().sceneNode, 1, (() => {
            ToolUtils.isObjValid(i.node) && (i.updateClientUserMoney(), i.updateAutoReadyTime(), i.updateRacingTime(), i.updateAddRobotPlyer());
        }));
        this.tableRoot.getChildByName("tid_key").getComponent(Label).string = i18nMgr.shared().getValueByKey("rummy_main.tid_key") + this.tid_key;
        i18nMgr.shared().changeLabelFont(this.tableRoot.getChildByName("tid_key").getComponent(Label));
        1 !== GameConfig.SERVER_DEBUG ? this.tableRoot.getChildByName("tid_key").active = false : this.tableRoot.getChildByName("tid_key").active = true;
        this.tid_key == CommDefine.NewerGuideRoomTidkey && (this.rummyShowTopUiLogic.showGuideRoomTopBg(), RummyDataManager.shared().rummyInfos.get(this.tid_key).pnum, this.playerTs.updateClientInfo(), this.playerTs.refreshPlayerPostion(), this.playerTs.showPlayer(1, CommDefine.GuidePlayerInfo), null == this.newPlayerGuideTs ? this.rummyShowTopUiLogic.showNewPlayerGuide() : (this.playerTs.setPaiDuiBgShow(true), this.newPlayerGuideTs.startGuideStep()));
        this.has_room_act = false;
        1 == User.shared().isInPerformanceRoom ? (this.tableRoot.getChildByName("tid_key").active = false, this.actionRoot.active = false, this.autoDrop.active = false, this.chatRoot.active = false, this.playerTs.hidePerformanceMyPlayer(), this.rummyShowTopUiLogic.showRoomPerformance(this.tid_key)) : (RummyDataManager.shared().reportSuccessIntoGameWithClient(t, e), 1 === User.shared().daily_task && 0 === User.shared().temp_pingbi.dailytask && this.tid_key !== CommDefine.NewerGuideRoomTidkey && (User.shared().getRoomRoomInfo(t.vid, PushEvent.JUMP_TO_DAILYTASK), User.shared().getRoomDailyTaskTips(t.vid), 1 == User.shared().showNewDailyTask || 1 == User.shared().showBackTask ? User.shared().requestNewDailyListData() : User.shared().roomDailyTaskListData || User.shared().requestRoomDailyTaskList(t.vid)));
        this.rummyLogicProcessing.checkTreasureHuntActivity();
        this.rummyLogicProcessing.checkNovicesTask();
        this.rummyLogicProcessing.checkFlopCashTask();
        let r = RummyDataManager.shared().rummyInfos.get(this.tid_key);
        sys.isObjectValid(r) && r.gameRummyType != RUMMY_GAME_TYPE.MATCH && 0 == r.crashModel && this.actionTs.updateGullakBtnStatus(User.shared().act_68_open, User.shared().act_68_full_status, false);
    }
    updateTreaBoxStatus(e) {
        if (this.has_treasureHuntAct) {
            let t = RummyDataManager.shared().rummyInfos.get(this.tid_key);
            sys.isObjectValid(t) && 1 == t.crashModel && t.pnum == e.pnum && t.gameBaseMoney == e.gameBaseMoney && (RummyDataManager.shared().rummyInfos.get(this.tid_key).show_box_act97 = e.show_box, RummyDataManager.shared().rummyInfos.get(this.tid_key).act97_data = e.data, this.treahuntTaskData = e.data, this.has_treasureHuntAct && (this.actionTs.updateTreasureHuntBox(e.show_box, e.box_type), this.actionTs.updateTreasureHuntBtn(1, e.data), ToolUtils.isObjValid(this.gameEndView) && t.gameRummyType != RUMMY_GAME_TYPE.MATCH && this.gameEndView.getComponent(RummyGameOverAlert).updateTreasureHuntBanner(e)));
        }
    }
    updateTaskRed() {
        let e = false;
        1 === User.shared().daily_task && 0 === User.shared().temp_pingbi.dailytask && this.tid_key !== CommDefine.NewerGuideRoomTidkey && (e = !!sys.isObjectValid(User.shared().dailyTask_red.is_red) && 1 == User.shared().dailyTask_red.is_red);
        this.actionTs.changeTaskRedDotVisible(e);
    }
    updateTaskBtn() {
        this.rummyLogicProcessing.updateTaskBtn();
    }
    clearFlopData() {
        let e = RummyDataManager.shared().rummyInfos.get(this.tid_key);
        sys.isObjectValid(e) && (e.flopCashTaskLaba = null, e.flopTempTaskInfo = null, Utils.shared().checkHasPopView(this.node) || this.reportSever());
    }
    refreshDestTid(e) {
        let t = new DeskInfo;
        t.tid_key = ToolUtils.isSafeString(e.tid_key);
        t.vid = e.vid;
        t.venuetype = e.venuetype;
        undefined !== e.game_type && (t.game_type = e.game_type);
        undefined !== e.pnum && (t.pnum = e.pnum);
        undefined !== e.base_money && (t.base_money = e.base_money);
        undefined !== e.round && (t.round = e.round);
        undefined !== e.currentRound && (t.currentRound = e.currentRound);
        undefined !== e.mode && (t.mode = e.mode);
        undefined !== e.special_mode && (t.special_mode = e.special_mode);
        sys.isObjectValid(e.match_mode) && (t.match_mode = e.match_mode);
        sys.isObjectValid(e.is_double) && (t.is_double = e.is_double);
        ToolUtils.deskInfos.set(ToolUtils.isSafeString(e.tid_key), t);
        this.tid_key = ToolUtils.isSafeString(e.tid_key);
        this.init(t);
        null !== e.mode && undefined !== e.mode && (RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType = e.mode);
        this.cardsTs.tid_key = this.tid_key;
        this.playerTs.tid_key = this.tid_key;
        this.tipTs.tid_key = this.tid_key;
        this.actionTs.tid_key = this.tid_key;
        this.tingPaiTs.tid_key = this.tid_key;
        this.playerTs.updateClientInfo();
        this.cardsTs.initGameCardView();
        this.actionTs.initActionView();
        sys.isObjectValid(e.only_update_tid_key) && 1 == e.only_update_tid_key || this.send_request_tableinfo();
        this.tableRoot.getChildByName("tid_key").getComponent(Label).string = i18nMgr.shared().getValueByKey("rummy_main.tid_key") + this.tid_key;
        i18nMgr.shared().changeLabelFont(this.tableRoot.getChildByName("tid_key").getComponent(Label));
        1 !== GameConfig.SERVER_DEBUG && (this.tableRoot.getChildByName("tid_key").active = false);
        ToolUtils.in_isGuideRoom >= 1 && this.updateTaskBtn();
        this.checkTreasureHunt = true;
    }
    init(e) {
        let t = new RummyInfo;
        for (let e = 0; e < 6; e++) {
            let s = {};
            s.seatid = e;
            s.isShow = false;
            t.playerModels[e] = s;
        }
        t.isInGameing = 0;
        t.seatPosVec = [];
        this.tipTs.seatPosVec = [];
        this.cardsTs.seatPosVec = [];
        for (let e = 0; e < 6; e++) {
            t.seatPosVec.push(this.playerTs.getPlayerHeadViewPos(e));
            this.tipTs.seatPosVec.push(this.playerTs.getPlayerHeadViewPos(e));
            this.cardsTs.seatPosVec.push(this.playerTs.getPlayerHeadViewPos(e));
        }
        if (this.tipTs.seatPosVec[0].y -= ToolUtils.getFitBottomHeightDiff(), t.clientSeatId = 0, t.game_state = 0, t.vid = null != e ? e.vid : 0, null != e && 5 == e.venuetype ? t.crashModel = 1 : t.crashModel = 0, sys.isObjectValid(e) && sys.isObjectValid(e.pnum) && (t.pnum = Number(e.pnum)), sys.isObjectValid(e) && sys.isObjectValid(e.base_money) && (t.gameBaseMoney = Number(e.base_money)), t.hasChupai = false, RummyDataManager.shared().rummyInfos.set(this.tid_key, t), this.cardsTs.setCallBack(this.onCardActionCallBack.bind(this)), this.cardsTs.setTingPaiCallBack(this.onTingPaiTipsActionCallback.bind(this)), 1 != User.shared().isInPerformanceRoom) {
            let s = false;
            if (0 == t.crashModel && sys.isObjectValid(e)) {
                let t = ToolUtils.isSafeNumber(e.mode);
                t != RUMMY_GAME_TYPE.POINTS && t != RUMMY_GAME_TYPE.POOL && t != RUMMY_GAME_TYPE.DEALS && t != RUMMY_GAME_TYPE.MULTIPLE || (s = true);
            }
            if (s && 0 == ToolUtils.in_isGuideRoom) {
                let t = sys.isObjectValid(e) ? e.vid : 0;
                User.shared().requestActRankGetRoomPage({ vid: t, type: "hour", page: 1 }, (() => {
                    if (ToolUtils.isObjValid(this.node)) {
                        this.has_room_act = false;
                        let e = "";
                        if (User.shared().roomActRankDataMap.has(t) && User.shared().roomActRankDataMap.get(t)) {
                            let s = User.shared().roomActRankDataMap.get(t);
                            sys.isObjectValid(s) && (this.has_room_act = 1 == ToolUtils.isSafeNumber(s.show), e = String(s.total_reward));
                        }
                        this.actionTs.setLeaderBoardsBtnVisible(this.has_room_act, e);
                    }
                }));
            }
        }
    }
    updateClientUserMoney() {
        if (!RummyDataManager.shared().rummyInfos.has(this.tid_key)) {
            return;
        }
        let e = RummyDataManager.shared().rummyInfos.get(this.tid_key);
        1 != e.game_state && (this.hasDeclare && (e.game_state = 4), 3 == e.game_state && 8 == this.game_cd && 13 == this.cardsTs.cardViewVec.length && e.isClientToPlay && this.tipTs.changePickTipsVisible(0, true), e.gameRummyType != RUMMY_GAME_TYPE.PRIVATE && e.gameRummyType != RUMMY_GAME_TYPE.PRI_POOL && e.gameRummyType != RUMMY_GAME_TYPE.PRI_DEAL || 5 != e.game_state && this.cardsTs.cardViewVec.length > 0 && this.actionTs.hidePrivateBtn(), this.game_cd = this.game_cd - 1);
    }
    login(e = false) {
        (e || this.tid_key != CommDefine.NewerGuideRoomTidkey) && User.shared().curTid_key === this.tid_key && this.rummyLogicProcessing.loginGameServer();
    }
    showGameOverAlert(e) {
        ToolUtils.isObjValid(this.gameEndView) && (this.gameEndView.active = e);
    }
    handler_server_small_return(e) {
        this.tid_key === (e.tid_key || "") && PushCenter.shared().pushEvent(GameConfig.RefreshSmallDesk, e);
    }
    getRoomVid() {
        if (!RummyDataManager.shared().rummyInfos.has(this.tid_key)) {
            return 0;
        }
        let e = RummyDataManager.shared().rummyInfos.get(this.tid_key);
        return sys.isObjectValid(e) ? e.vid : 0;
    }
    replaceTableTidKey(e) {
        if (null != e.old_tid_key && "" != e.old_tid_key && e.old_tid_key == this.tid_key) {
            let t = ToolUtils.isSafeString(e.tid_key);
            return e.mode != RUMMY_GAME_TYPE.MATCH && (User.shared().curTid_key == e.old_tid_key && (User.shared().curTid_key = t), PushCenter.shared().pushEvent(GameConfig.SwitchDesk, e)), this.refreshDestTid(e), ToolUtils.isSafeNumber(e.vid) > 0 && (RummyDataManager.shared().rummyInfos.get(t).vid = ToolUtils.isSafeNumber(e.vid)), null !== e.mode && undefined !== e.mode && (RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType = e.mode), this.checkTreasureHunt = true, this.has_treasureHuntAct = false, void this.actionTs.updateTreasureHuntBtn(4, null, null);
        }
    }
    handler_server_switch_view_table_return(e) {
        this.tid_key === (e.tid_key || "") && 1 === e.ret && ToolUtils.isSafeString(e.alertStr).length > 0 && Utils.shared().showToast(e.alertStr, 2, 0, ToolUtils.getIsNormalDirection());
    }
    handler_server_system_gateway_return(e) {
        if (null != e.tid_key && null != e.tid_key && "" != e.tid_key) {
            if (this.tid_key === (e.tid_key || "") && -1 === e.res) {
                let e = i18nMgr.shared().getValueByKey("utlis.service_upgrade");
                Utils.shared().showToast(e, 2, 0, ToolUtils.getIsNormalDirection());
                this.backToHall();
            }
        }
        else {
            User.shared().curTid_key === this.tid_key && -1 === e.res && ToolUtils.isSafeString(e.msg).length > 0 && Utils.shared().showToast(e.msg, 2, 0, ToolUtils.getIsNormalDirection());
        }
    }
    send_request_tableinfo() {
        this.rummyLogicProcessing.send_request_tableinfo();
    }
    send_request_enterBackGround() {
        this.tid_key !== CommDefine.NewerGuideRoomTidkey && this.rummyLogicProcessing.send_request_enterBackGround();
    }
    regEvent() {
        Server.shared().regDispatch(NetConfig.SYSTEM_GATEWAY_CMD, this.handler_server_system_gateway_return.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_SWITCH_VIEW_TABLE_RETURN, this.handler_server_switch_view_table_return.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_RESP_SMALL_TABLE_INFO, this.handler_server_small_return.bind(this), this);
        Server.shared().regDispatch(NetConfig.SERVER_LOGIN_GATE_RESP, this.handler_server_login_gate_return.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SERVER_GAME_HEART, this.handler_server_heart.bind(this), this);
        Server.shared().regDispatch(NetConfig.SM_LOGIN_RETURN, this.handler_server_login_return.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_LOGIN_SUCC_BC_RETURN, this.handler_server_login_succ_bc.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_LOGOUT_SUCC_BC_RETURN, this.handler_server_logout_succed_bc.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_TABLEINFO_BC_RETURN, this.handler_server_table_info_uc.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_NOTIFY_GAME_START_BC_RETURN, this.handler_server_pre_start_bc.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_START_BC_RETURN, this.handler_server_game_start_bc.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_CHANGE_SUCC_BC_RETURN, this.handler_server_change_succ_bc.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_NORMALEXPRESION_BC_RETURN, this.handler_server_expresion_info.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_CHAT_BC_RETURN, this.handler_server_talk_info.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_EXPRESSION_BC_RETURN, this.handler_server_bigface_uc.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_SELF_CARDS_RETURN, this.handler_server_self_cards_return.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_GONG_CARDS_RETURN, this.handler_server_gong_cards_return.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_NEXT_DEAL_BC_RETURN, this.handler_server_next_deal_bc_return.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_DROP_CARD_RETURN, this.handler_server_drop_card_return.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_DROP_CARD_BC_RETURN, this.handler_server_drop_bc_return.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_PICK_CARD_BC_RETRUN, this.handler_server_pick_card_bc_return.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_DECARE_CARD_RETURN, this.handler_server_declare_card_return.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_DECARE_CARD_BC_RETURN, this.handler_server_declare_card_bc_return.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_DISCARD_CARD_RETURN, this.handler_server_discard_return.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_DISCARD_CARD_BC_RETURN, this.handler_server_discard_card_bc_return.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_MOVE_CARD_REQUEST, this.handler_server_move_card_return.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_GROUP_CARD_REQUEST, this.handler_server_group_card_return.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_FINISH_RETURN, this.handler_server_finish_return.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_FINISH_RETURN_BC, this.handler_server_finish_return_bc.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_LAST_CARD_RETURN, this.handler_server_last_card_return.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_GAME_END_BC_INFORM, this.handler_server_game_end_bc.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_GAME_SHOW_INFO, this.handler_server_game_show_info_return.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_DECARE_CARD_CHECK_RETURN, this.handler_server_declare_check_return.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_ADD_CARD_RETURN, this.handler_server_add_card_return.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_NOTIFY_GIVE_CARD, this.handler_server_give_card_return.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_GAME_SHOW_SWITCH, this.handler_server_show_swtich_btn_return.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_PRE_DECARD_RESPOND, this.handler_server_decard_return.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_FINISH_STATUS_INFO, this.handler_server_finish_status_bc.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_SHOW_OTHER_PLAYER_CARDS, this.handler_server_show_other_cards_bc.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_NOTIFY_PLAYER_START_GAME, this.handler_server_start_game.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_PLAYER_START_GAME_RETURN, this.handler_server_start_game_return.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SERVER_NOTIFY_REFRESH_MONEY_BC, this.handler_server_notify_refresh_money_bc.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_NOTIFY_MONEY_CHANGE_BC_RETURN, this.handler_server_notify_money_return.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_GAME_READY, this.handler_server_notify_ready_bc_return.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_NOTIFY_GAME_AUTOSTART_BC_RETURN, this.handler_server_notify_autostart_bc.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_PLAYER_STATUS_NC, this.handler_server_auto_outcard_status_bc.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_GAME_NO_READY_SECOND_TIMERS, this.handler_server_notify_not_ready.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_JOIN_BC_RETRUN, this.handler_server_race_join_bc_return.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_JOIN_RETRUN, this.handler_server_join_return.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_CANCEL_JOIN_RACE_RESPOND, this.handler_server_race_cancel_join_return.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_RACE_START_RETURN, this.handler_server_race_start_return.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_RACE_GAME_END_RETURN, this.handler_server_race_game_end_return.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_RANK_INFO_RESPOND, this.handler_server_rank_info_return.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_NOTIFY_RACEID_WILL_START, this.handler_server_notify_race_will_start_return.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_NOTIFY_RACE_OVER_AND_WAIT, this.handler_server_notify_race_over_and_wait_return.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_NOTIFY_DISUSE, this.handler_server_notify_race_notify_disuse_return.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_GET_USER_RANK_RESPOND, this.handler_server_get_user_rank_return.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_NOTIFY_USER_REBUY_INFO, this.handler_server_notify_user_rebuy_return.bind(this), this);
        Server.shared().regDispatch(RummyCmd.GM_USER_REBUY_RSPOND, this.handler_server_user_rebuy_return.bind(this), this);
        Server.shared().regDispatch(RummyCmd.GM_USER_REBUY_BC_RSPOND, this.handler_server_user_rebuy_bc_return.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_NOTIFY_FLOW_BUREAU, this.handler_server_notify_flow_bureau_return.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_TIMER_EVENT_MSG_NOTIFY, this.handler_server_timer_event_msg_notify.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_BASE_MONEY_UP_NOTIFY, this.handler_server_base_money_up_notify.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_PRE_LOGOUT_RSQ, this.handler_server_logout_respond.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_GET_RECORD_RESPOND, this.handler_server_pool_record_return.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_REJOIN_RESPOND, this.handler_server_rejoin_return.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_REJOIN_BC, this.handler_server_rejoin_return_bc.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_END_GAME_NOTIFY, this.handler_server_geme_notify_bc.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_END_GAME_RESPOND_BC, this.handler_server_geme_respond_bc.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_ALL_END_BC, this.handler_server_pool_all_record_return.bind(this), this);
        Server.shared().regDispatch(RummyCmd.NOTIFY_SHOW_SPLIT_PRIZE, this.handler_server_show_split_prize_respond.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_DEALS_GAME_OVERTIME, this.handler_server_deals_overtime_pop_respond.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_NOTIFY_VENUE_BRIEF, this.show_table_top_info.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_AUTO_DROP_RESPONSE, this.handler_server_auto_drop_respond.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_NOTIFY_ICON_NAME_VISIBILITY, this.handler_notify_icon_name_visible_respond.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_MOVE_GROUP_CARDS_RESPONSE, this.handler_server_add_card_return.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_RSP_DROP_CARD_IS_ELIMINATE, this.handler_server_pool_drop_return.bind(this), this);
        Server.shared().regDispatch(RummyCmd.GM_HEARTBEAT_REQUEST, this.handler_server_heartbeat_return.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_RSP_SET_AUTO_SORT, this.handler_server_set_auto_sort_return.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_RSP_SORT_CARDS, this.handler_server_sort_cards_return.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_NOTIFY_READY_BTN_STATUS, this.handler_server_notify_ready_btn_status.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_NOTIFY_HEAD_STATUS, this.handler_server_notify_head_status.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_NOTIFY_ENTER_LINE_UP, this.handler_server_notify_enter_line_up.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_NOTIFY_LINE_UP_SUCC, this.handler_server_notify_line_up_succ.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_NOTIFY_NOTICE_INFO, this.handler_server_notify_notice_info.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_NOTIFY_TABLE_PLAYER_INFO, this.handler_server_table_player_info.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_NOTIFY_GUEST_GOHST_SETTLE, this.handler_server_game_guest_gameover_return.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_NOTIFY_SHOW_ZHANJI_BTN, this.handler_server_notify_show_zhanji_btn.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_REFRESH_TABLEINO_RETUTN, this.handler_server_refresh_tableinfo_return.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_NOTIFY_FLUSH_CARDS, this.handler_server_notify_flush_cards.bind(this), this);
        Server.shared().regDispatch(RummyCmd.NOTIFY_REJOIN_START, this.handler_server_notify_rejoin_start.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_NOTIFY_COMMING_SPLIT, this.handler_server_notify_comming_split.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_AUTO_GROUP_RSPOND, this.handler_server_auto_group_cards_return.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_PER_CHANGE, this.handler_server_per_change_return.bind(this), this);
        Server.shared().regDispatch(RummyCmd.WIN_CONDITION_TIPS, this.handler_server_win_condition_tips.bind(this), this);
        Server.shared().regDispatch(RummyCmd.WRONG_PICK_TIPS, this.handler_server_wrong_pick_tips.bind(this), this);
        Server.shared().regDispatch(RummyCmd.WRONG_DISCARD_TIPS, this.handler_server_wrong_discard_tips.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_AUTO_BEST_DECLARE, this.handler_server_auto_best_declare.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_NOTIFY_STAR_INFO, this.handler_server_notify_star_info.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_HELPER_PICK_CARD, this.handler_server_helper_pick_card.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_NOTIFY_MULTIPLE_CARD_SCORE, this.handler_server_notify_multiple_card_score.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_NOTIFY_SWITCH_SKIN, this.handler_server_notify_switch_skin.bind(this), this);
        Server.shared().regDispatch(NetConfig.SM_LOGIN_ERR_UC, this.handler_server_alert_return.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SERVER_ALERT_RETURN, this.handler_server_alert_return.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_NOTIFY_LISTEN_INFO, this.handler_server_notify_listen_info.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_HELPER_BEST_GROUP_AFTER_PICK, this.handler_server_helper_best_group_alert_pick.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_NOTIFY_MATCH_PUSH, this.handler_server_notify_match_push.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_SCORE_RANK_INFO, this.handler_server_score_rank_info_return.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_NOTIFY_EFFECT_MODIFY, this.handler_server_notify_effect_modify_return.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_NOTIFY_CLIENT_LOAD_HEAD, this.handler_server_notify_client_load_head.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_BUMP_CHANGE_LAIZI, this.handler_server_bump_change_joker.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_NOTIFY_PICK_INFO, this.handler_server_notify_pick_info.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_NOTIFY_RECOMMAND_LAIZI, this.handler_server_notify_recommand_laizi.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_BUMP_PRE_CHANGE_LAIZI, this.handler_server_bump_pre_change_laizi.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_BUMP_BATCH_PRE_CHANGE_LAIZI_INFO, this.handler_server_bump_batch_pre_change_laizi.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_NOTIFY_CHIP, this.handler_server_notify_chip.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_REJECT_UP_VENUE_TIPS, this.handler_server_reject_up_venue_tips.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_HISTORY_CARDS_INFO_RSP, this.handler_server_histroy_cards_info.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_REFULSH_OUTS_INFO, this.handler_server_refresh_outs_info_return.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_NOTIFY_CHOOSE_DOUBLE, this.handler_server_notify_choose_double.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_CHOOSE_DOUBLE_RETURN, this.handler_server_choose_double_return.bind(this), this);
        Server.shared().regDispatch(RummyCmd.SM_CHOOSE_DOUBLE_BC_RETURN, this.handler_server_choose_double_bc_return.bind(this), this);
    }
    handler_server_notify_go_cash(e) {
    }
    handler_server_win_condition_tips(e) {
        this.tid_key === (e.tid_key || "") && this.rummyShowTopUiLogic.dealWinConditionTips(e);
    }
    handler_server_wrong_pick_tips(e) {
        this.tid_key === (e.tid_key || "") && TweenTool.delayAct(this.action_node, (() => {
            this.cardsTs.showTipsCards(e);
            this.tipTs.dealWrongTips(e);
        }), 0.5, true);
    }
    handler_server_wrong_discard_tips(e) {
        this.tid_key === (e.tid_key || "") && TweenTool.delayAct(this.action_node, (() => {
            this.cardsTs.showTipsCards(e);
            this.tipTs.dealWrongTips(e, true);
        }), 0.3, true);
    }
    handler_server_auto_best_declare(e) {
        this.tid_key === (e.tid_key || "") && 1 == RummyDataManager.shared().rummyInfos.get(this.tid_key).autoBsetDeclareOpen && sys.isObjectValid(e.status) && (RummyDataManager.shared().rummyInfos.get(this.tid_key).autoDeclareStatus = e.status, sys.isObjectValid(e.cd) && sys.isObjectValid(e.dec_cd) && this.tipTs.changeConfimTips(e.status, e.cd, e.dec_cd));
    }
    handler_server_notify_star_info(e) {
        if (this.tid_key !== (e.tid_key || "")) {
            return;
        }
        let t = sys.localStorage.getItem("card_rating_def");
        null == t && (t = User.shared().help_setting.card_rating_def);
        sys.isObjectValid(t) && 1 == User.shared().help_setting.card_rating && 1 == Number(t) && sys.isObjectValid(e.ev_score) && sys.isObjectValid(e.star) && sys.isObjectValid(e.color) && (RummyDataManager.shared().rummyInfos.get(this.tid_key).ev_score = e.ev_score, RummyDataManager.shared().rummyInfos.get(this.tid_key).star = e.star, this.cardsTs.setHandCardValueStar(e.ev_score, e.star, e.color), this.cardsTs.refreshCardValueTip(ToolUtils.isSafeNumber(e.with_open)));
    }
    handler_server_per_change_return(e) {
        this.tid_key === (e.tid_key || "") && (1 === e.show_new_player_guide ? (HttpManager.shared().doReportPlayerGuideAct(PhpReportDefined.roomPlayerGuideEvent.loseGameSHow), this.showGuideTips((() => {
            this.switchCallback();
        }))) : this.switchCallback());
    }
    handler_server_notify_show_zhanji_btn(e) {
        if (this.tid_key !== (e.tid_key || "")) {
            return;
        }
        let t = 1 === e.ishavegamelog;
        this.actionTs.changeRecodeBtnStatus(t);
    }
    handler_server_refresh_tableinfo_return(e) {
        this.tid_key === (e.tid_key || "") && (1 === e.ret ? this.rummyLogicProcessing.send_login_request() : 2 === e.ret && this.send_request_tableinfo());
    }
    handler_server_notify_flush_cards(e) {
        this.tid_key === (e.tid_key || "") && e.uid == User.shared().data.uid && e.cardinfos && (this.saveServerCardInfos(e), this.refreshMyShouPai(e, true, true));
    }
    handler_server_notify_rejoin_start(e) {
        if (this.tid_key !== (e.tid_key || "")) {
            return;
        }
        let t = ToolUtils.isSafeNumber(e.cd);
        if (this.tipTs.showGameTipsText(9, t), ToolUtils.isObjValid(this.gameEndView) && RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType != RUMMY_GAME_TYPE.MATCH) {
            this.gameEndView.getComponent("RummyGameOverAlert").showNotifyRejoinTips(t);
        }
    }
    handler_server_notify_comming_split(e) {
        if (this.tid_key !== (e.tid_key || "")) {
            return;
        }
        let t = ToolUtils.isSafeNumber(e.cd);
        if (this.tipTs.showGameTipsText(9, t), ToolUtils.isObjValid(this.gameEndView) && RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType != RUMMY_GAME_TYPE.MATCH) {
            this.gameEndView.getComponent("RummyGameOverAlert").showCommingSplitTips(t);
        }
    }
    handler_server_game_guest_gameover_return(e) {
        this.tid_key === (e.tid_key || "") && this.rummyLogicProcessing.handler_server_game_guest_gameover_return(e);
    }
    handler_server_notify_enter_line_up(e) {
        this.tid_key === (e.tid_key || "") && this.rummyLogicProcessing.handler_server_notify_enter_line_up(e);
    }
    handler_server_notify_line_up_succ(e) {
        this.tid_key === (e.tid_key || "") && (Utils.shared().hideLoading(), PushCenter.shared().pushEvent(GameConfig.Update_Menu_Switch_Status, { tid_key: this.tid_key, bEnable: false }), RummyDataManager.shared().rummyInfos.get(this.tid_key).is_waiting = 0);
    }
    handler_server_notify_head_status(e) {
        this.tid_key === (e.tid_key || "") && this.rummyLogicProcessing.handler_server_notify_head_status(e);
    }
    refreshOpenCardPlayersInfo() {
        if (this.sortPlayerGiveCard(), ToolUtils.isObjValid(this.openCardNode)) {
            this.openCardNode.getComponent(RummyOpenCardsAlert).refreshOpenCardPlayer();
        }
    }
    handler_server_notify_ready_btn_status(e) {
        this.tid_key === (e.tid_key || "") && this.rummyLogicProcessing.handler_server_notify_ready_btn_status(e);
    }
    handler_server_sort_cards_return(e) {
        this.tid_key === (e.tid_key || "") && this.rummyLogicProcessing.handler_server_sort_cards_return(e);
    }
    handler_server_auto_group_cards_return(e) {
        this.tid_key === (e.tid_key || "") && this.rummyLogicProcessing.handler_server_auto_group_cards_return(e);
    }
    handler_server_set_auto_sort_return(e) {
        User.shared().curTid_key === this.tid_key && 0 == e.ret && undefined !== e.auto_sort && null !== e.auto_sort && (User.shared().auto_sort = ToolUtils.isSafeNumber(e.auto_sort), ToolUtils.saveData("auto_sort", String(User.shared().auto_sort)));
    }
    handler_server_login_gate_return(e) {
        (0 == e.res || User.shared().curTid_key === this.tid_key) && this.rummyLogicProcessing.handler_server_login_gate_return(e);
    }
    handler_server_heartbeat_return(e) {
        RummyDataManager.shared().bCanGoBack && Utils.shared().hideLoading();
    }
    updateGold(e) {
        if (1 != RummyDataManager.shared().rummyInfos.get(this.tid_key).crashModel && 1 !== User.shared().isInPerformanceRoom) {
            RummyDataManager.shared().rummyInfos.get(this.tid_key).playerModels[RummyDataManager.shared().rummyInfos.get(this.tid_key).clientSeatId].money = e;
            this.isUpdateMyMoney && this.playerTs.updatePlayerMoney(0, User.shared().data.money);
        }
    }
    updateMemberShipInfo() {
        if (1 !== User.shared().isInPerformanceRoom && sys.isObjectValid(User.shared().data.club)) {
            let e = RummyDataManager.shared().rummyInfos.get(this.tid_key).playerModels[RummyDataManager.shared().rummyInfos.get(this.tid_key).clientSeatId];
            e.club_level = Number(User.shared().data.club.club);
            this.playerTs.updatePlayerMemberShipInfo(0, e.club_level);
        }
    }
    doConnectRequest() {
        RummyDataManager.shared().rummyInfos.get(this.tid_key).isGameOver = false;
        User.shared().curTid_key == this.tid_key && this.tid_key !== CommDefine.NewerGuideRoomTidkey && (Server.shared().disconnectWebSocket(), this.login());
    }
    handler_user_rebuy_request(e) {
        this.rummyLogicProcessing.handler_user_rebuy_request(e);
    }
    handler_pre_switch_request() {
        this.rummyLogicProcessing.handler_pre_switch_request();
    }
    switchDestCallBack(e) {
        1 == e && (Utils.shared().showLoading(10, false), RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType == RUMMY_GAME_TYPE.POINTS || RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType == RUMMY_GAME_TYPE.MULTIPLE ? this.rummyLogicProcessing.handler_pre_switch_request() : this.switchCallback());
    }
    finishBtnCallBack(e) {
        1 == e ? this.handler_server_discard_request(1, 1) : this.finishType = -1;
    }
    handler_server_discard_request(e, t, s = null) {
        let i = RummyDataManager.shared().rummyInfos.get(this.tid_key), a = 0;
        if (1 == t) {
            let e = this.cardsTs.getSelectedCards();
            if (e.length > 0) {
                let t = e[0].getComponent("RummyCard");
                i.groupIndex = t.groupIndex;
                i.card_index = t.cardIndex;
                i.playCardValue = t.mCardValue;
                1 == i.is_bump && sys.isObjectValid(s) && (a = s.is_quick);
            }
            else {
                sys.isObjectValid(s) && (i.groupIndex = s.index, i.card_index = s.cardIndex, i.playCardValue = s.card, a = s.is_quick);
            }
        }
        if (i.isPlayingCard) {
            return;
        }
        i.isPlayingCard = true;
        i._discard_time = sys.now();
        let r = { cmd: RummyCmd.GM_DISCARD_CARD_REQUEST, uid: User.shared().data.uid, index: i.groupIndex, card_index: i.card_index, card: i.playCardValue, discard_type: e, tid_key: this.tid_key };
        1 == a && (r.is_quick = a);
        Server.shared().send(r);
        TweenTool.delayAct(this.action_node, (() => {
            RummyDataManager.shared().rummyInfos.get(this.tid_key).isPlayingCard = false;
        }), RummyCardConstant.DiscardDelayTime, true);
    }
    handler_server_decard_return(e) {
        this.tid_key === (e.tid_key || "") && this.rummyLogicProcessing.handler_server_decard_return(e);
    }
    handler_server_declare_check_request(e, t = null) {
        this.finishType = e;
        this.rummyLogicProcessing.handler_server_declare_check_request(e, t);
    }
    handler_server_move_card_request(e) {
        let t = RummyDataManager.shared().rummyInfos.get(this.tid_key), s = this.cardsTs.getSelectedCards();
        if (1 == e) {
            if (1 != s.length) {
                return;
            }
            if (1 == s.length) {
                let e = s[0].getComponent("RummyCard");
                t.from_index = e.groupIndex;
                t.from_card_index = e.cardIndex;
                t.playCardValue = e.mCardValue;
                t.to_card_index = 0;
            }
        }
        this.req_id += 1;
        let i = { cmd: RummyCmd.GM_MOVE_CARD_REQUEST, uid: User.shared().data.uid, from_index: t.from_index, to_index: t.to_index, from_card_index: t.from_card_index, to_card_index: t.to_card_index, card: t.playCardValue, tid_key: this.tid_key, req_id: this.req_id };
        Server.shared().send(i);
        t.bHandCardSynchronous = false;
    }
    switchRoom(e = -1, t) {
        if (this.tipTs.hideWinEffect(), this._hasSendMsg) {
            return;
        }
        let s;
        this._hasSendMsg = true;
        TweenTool.delayAct(this.action_node, (() => {
            ToolUtils.isObjValid(this.node) && (this._hasSendMsg = false);
        }), 1, true);
        -2 != e && this.upvenue_entry_fee > 0 && RummyDataManager.shared().rummyInfos.get(this.tid_key).bIsAddSwitchRoom && (e = -2);
        RummyDataManager.shared().rummyInfos.get(this.tid_key).bIsAddSwitchRoom = true;
        RummyDataManager.shared().rummyInfos.get(this.tid_key).bIsSwitchRoom = true;
        RummyDataManager.shared().stopTweenAction(this.switch_tab_action);
        this.switch_tab_action = TweenTool.delayAct(RummyDataManager.shared().sceneNode, (() => {
            ToolUtils.isObjValid(this.node) && (RummyDataManager.shared().stopTweenAction(this.switch_tab_action), this.switch_tab_action = null, RummyDataManager.shared().rummyInfos.get(this.tid_key).bIsSwitchRoom = false, this.gameOverOpenLogic.reShowEndView(this.tid_key));
        }), 3.5, true);
        e > 0 ? s = { cmd: RummyCmd.GM_CHANGE_REQUEST, type: e, tid_key: this.tid_key } : -2 == e ? (s = { cmd: RummyCmd.GM_REQUEST_UP_VENUE, tid_key: this.tid_key }, sys.isObjectValid(t) && t > 0 && (s.vid = t)) : s = { cmd: RummyCmd.GM_CHANGE_REQUEST, tid_key: this.tid_key };
        Server.shared().send(s);
    }
    handler_server_alert_return(e) {
        let t = e.tid_key;
        if (t && "" !== t || (t = User.shared().curTid_key), this.tid_key !== (t || "")) {
            return;
        }
        let s = 0;
        e.type && (s = e.type);
        let i = e.alertStr;
        if (2 == s) {
            if (RummyDataManager.shared().stopTweenAction(this.delay_ready_action), this.has_showQuick_charge = true, this.myTurnFastBuyCallback(1), Utils.shared().hideLoading(), sys.isObjectValid(e.reason) && 1 == e.reason) {
                let e = RummyDataManager.shared().rummyInfos.get(this.tid_key);
                User.shared().updatePayScene(PhpReportDefined.pay_scene.game_prop_less_money, e.vid);
            }
        }
        else {
            1 == s ? Utils.shared().showCommomDialog(i, i18nMgr.shared().getValueByKey("utlis.tips"), (e => {
            }), false, ToolUtils.getIsNormalDirection(), null, null, null, this.pop_layer4, null, this.tid_key) : 11 == s || 0 == s ? (i && i.length > 0 && Utils.shared().showToast(i, 2, 0, ToolUtils.getIsNormalDirection()), this.exitCallBack(1)) : 15 == s ? (User.shared().alertTip = i, Utils.shared().showCommomDialog(i, i18nMgr.shared().getValueByKey("utlis.tips"), (e => {
            }), false, ToolUtils.getIsNormalDirection(), null, null, null, this.pop_layer4, null, this.tid_key)) : 50 == s ? (Utils.shared().hideCommomDialog(this.pop_layer4), this.serverUpdateTipsShow = true, Utils.shared().showCommomDialog(i, i18nMgr.shared().getValueByKey("utlis.tips"), (e => {
                ToolUtils.isObjValid(this.gameEndView) || ToolUtils.isObjValid(this.RummyTotalSettlementNode) || (this.exitCallBack(1), this.backToHall());
            }), false, ToolUtils.getIsNormalDirection(), null, null, null, this.pop_layer5, null, this.tid_key)) : 51 == s ? (Utils.shared().hideCommomDialog(this.pop_layer4), Utils.shared().showCommomDialog(i, i18nMgr.shared().getValueByKey("utlis.tips"), (e => {
                this.exitCallBack(1);
                this.backToHall();
            }), false, ToolUtils.getIsNormalDirection(), null, null, null, this.pop_layer5, null, this.tid_key, false)) : i && i.length > 0 && Utils.shared().showToast(i, 2, 0, ToolUtils.getIsNormalDirection());
        }
    }
    handler_server_notify_money_return(e) {
        if (this.tid_key !== (e.tid_key || "")) {
            return;
        }
        let t = e.seatid, s = e.money;
        this.playerTs.updatePlayerMoney(this.getPosBySeatid(t), s);
    }
    handler_server_notify_refresh_money_bc(e) {
        if (this.tid_key === (e.tid_key || "") && 1 != RummyDataManager.shared().rummyInfos.get(this.tid_key).crashModel) {
            let t = e.seatid, s = RummyDataManager.shared().rummyInfos.get(this.tid_key).playerModels[t];
            if (s) {
                s.money = e.cur_money;
                let i = this.getPosBySeatid(t);
                this.playerTs.updatePlayerMoney(i, s.money);
            }
        }
    }
    handler_server_notify_autostart_bc(e) {
        if (this.tid_key !== (e.tid_key || "")) {
            return;
        }
        let t = e.cd;
        if (this.autoReadyTime = -1, RummyDataManager.shared().rummyInfos.get(this.tid_key).game_state = 5, RummyDataManager.shared().rummyInfos.get(this.tid_key).game_server_state = 1, this.autoReadyTime = t, t > 0) {
            let e = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_main.gameTipsText1"), t);
            ToolUtils.isObjValid(this.gameEndView) && (RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType == RUMMY_GAME_TYPE.MATCH ? this.gameEndView.getComponent(RummyPointsMatchOverAlert).showCountDown(e) : this.gameEndView.getComponent(RummyGameOverAlert).showCountDown(e));
        }
        this.actionTs.changeSwitchBtnStatus(false);
    }
    handler_server_notify_not_ready(e) {
        this.tid_key === (e.tid_key || "") && e.uid == User.shared().data.uid && null != e.alertStr && e.alertStr.length > 0 && Utils.shared().showCommomDialog(e.alertStr, i18nMgr.shared().getValueByKey("utlis.tips"), (e => {
            if (1 == e) {
                if (User.shared().isGameDisconnectServer) {
                    return void this.doConnectRequest();
                }
                if (this.isDisconnect) {
                    this.isDisconnect = false;
                    this.doConnectRequest();
                }
                else {
                    let e = RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType;
                    e == RUMMY_GAME_TYPE.PRIVATE || e == RUMMY_GAME_TYPE.PRI_POOL || e == RUMMY_GAME_TYPE.PRI_DEAL || this.switchRoom(5);
                }
            }
        }), false, ToolUtils.getIsNormalDirection(), null, null, null, this.pop_layer4, null, this.tid_key);
    }
    handler_server_race_start_return(e) {
        if (this.tid_key !== (e.tid_key || "")) {
            return;
        }
        RummyDataManager.shared().rummyInfos.get(this.tid_key).isMatchGameOver = false;
        RummyDataManager.shared().rummyInfos.get(this.tid_key).race_state = 3;
        let t = this.pop_layer4.getChildByName("match_prizes_rank");
        ToolUtils.isObjValid(t) && t.destroy();
        this.hideMatchWaitView();
        this.showMatchTipsAnim(0);
        let s = this.pop_layer4.getChildByName("commondialog_node");
        ToolUtils.isObjValid(s) && s.destroy();
    }
    handler_server_join_return(e) {
        this.tid_key === (e.tid_key || "") && 0 != e.ret && (ToolUtils.isSafeString(e.msg).length > 0 && Utils.shared().showToast(e.msg, 2), 5 == e.code && this.exitCallBack(1), Utils.shared().hideLoading());
    }
    handler_server_race_join_bc_return(e) {
        this.tid_key === (e.tid_key || "") && (Utils.shared().hideLoading(), RummyDataManager.shared().rummyInfos.get(this.tid_key).raceid == (e.raceid || "") && this.updateMatchWaitView(e.signup_cnt));
    }
    handler_server_race_cancel_join_return(e) {
        this.tid_key === (e.tid_key || "") && RummyDataManager.shared().rummyInfos.get(this.tid_key).raceid == (e.raceid || "") && 0 != e.ret && e.msg && ToolUtils.isSafeString(e.msg).length > 0 && Utils.shared().showToast(e.msg, 2);
    }
    handler_server_race_game_end_return(e) {
        if (this.tid_key !== (e.tid_key || "")) {
            return;
        }
        RummyDataManager.shared().rummyInfos.get(this.tid_key).race_state = 4;
        RummyDataManager.shared().rummyInfos.get(this.tid_key).isMatchGameOver = true;
        null != e.score && this.playerTs.setPoolScore(0, e.score);
        this.match_vid = e.match_vid;
        this.ticket_mode = e.ticket_mode;
        this.mng_sid = e.mng_sid;
        this.match_rejoinid = e.rejoinid;
        let t = this.pop_layer4.getChildByName("match_game_rebuy");
        ToolUtils.isObjValid(t) && t.destroy();
        this.actionTs.changeRaceRewardDiVisible(false);
        this.rummyShowTopUiLogic.setRaceTime("00:00");
        let s = true;
        this.checkIsPointsMatch() && (this.matchTotalSettleMsg = e, sys.isObjectValid(e.end_way) && 0 == e.end_way && (s = false, TweenTool.delayAct(this.action_node, (() => {
            ToolUtils.isObjValid(this.node) && (this._hasSendMsg = false);
        }), 2, true)));
        s && this.showMatchOverView(e);
    }
    handler_server_rank_info_return(e) {
        this.tid_key === (e.tid_key || "") && (0 == e.ret ? (this.matchRankCurPage = e.now_page, this.matchRankTotalPage = e.total_page, 1 == this.matchRankCurPage ? RummyDataManager.shared().rummyInfos.get(this.tid_key).matchRankInfo = e.players : this.matchRankCurPage > 1 && e.players && e.players.length > 0 && (RummyDataManager.shared().rummyInfos.get(this.tid_key).matchRankInfo = RummyDataManager.shared().rummyInfos.get(this.tid_key).matchRankInfo.concat(e.players)), 1 != this.matchRankCurPage && this.matchRankCurPage != this.matchRankTotalPage || (this.actionTs.getRaceRewardVisible() && this.actionTs.refreshRaceRankList(RummyDataManager.shared().rummyInfos.get(this.tid_key).matchRankInfo), this.rummyShowTopUiLogic.refreshMatchRankView()), 0 == e.is_active && e.now_page < e.total_page && 0 == e.active_push && this.rummyLogicProcessing.handler_server_rank_info_request(e.now_page + 1)) : this.actionTs.getRaceRewardVisible() && ToolUtils.isSafeString(e.msg).length > 0 && Utils.shared().showToast(e.msg, 2));
    }
    handler_server_notify_race_will_start_return(e) {
        this.tid_key === (e.tid_key || "") && RummyDataManager.shared().rummyInfos.get(this.tid_key).raceid == (e.raceid || "") && (RummyDataManager.shared().rummyInfos.get(this.tid_key).isMatchGameOver = false, RummyDataManager.shared().rummyInfos.get(this.tid_key).race_state = 2);
    }
    handler_server_notify_race_over_and_wait_return(e) {
        if (this.tid_key === (e.tid_key || "") && (RummyDataManager.shared().rummyInfos.get(this.tid_key).isMatchGameOver = true, RummyDataManager.shared().rummyInfos.get(this.tid_key).gameMatchType == RUMMY_MATCH_TYPE.FIXEDDURATION)) {
            let t = ToolUtils.format("${0} has ended, Settlement in \nprogress, please wait...", e.race_name);
            this.showTournamentExitAlert(t);
        }
    }
    handler_server_notify_race_notify_disuse_return(e) {
        if (this.tid_key === (e.tid_key || "") && (RummyDataManager.shared().rummyInfos.get(this.tid_key).isMatchGameOver = true, RummyDataManager.shared().rummyInfos.get(this.tid_key).gameMatchType == RUMMY_MATCH_TYPE.FIXEDDURATION)) {
            let e = "Oh Dear, You were eliminated!\nPlease check tourney lobby for Leaderboard.";
            this.showTournamentExitAlert(e);
        }
    }
    showTournamentExitAlert(text) {
        const tid = this.tid_key;
        Utils.shared().showMatchAlertView(4, {
            parentNode: director.getScene().getChildByName("Canvas"),
            strContent: text, strBtn: "LEAVE TABLE", strFunc: "exit",
            callfun: action => {
                if (action !== "exit" || this.tid_key !== tid) return;
                const room = RummyDataManager.shared().rummyInfos.get(tid);
                if (!room || !room.isMatchGameOver) return;
                this.exitCallBack(1);
                // Eliminated seats and completed tables may already be removed on the server.
                // Close this finished local desk without waiting for a logout acknowledgement.
                this.backToHall();
            }
        });
    }
    handler_server_get_user_rank_return(e) {
    }
    handler_server_notify_user_rebuy_return(e) {
        this.tid_key === (e.tid_key || "") && RummyDataManager.shared().rummyInfos.get(this.tid_key).raceid == (e.raceid || "") && this.rummyShowTopUiLogic.showMatchRebuy(e);
    }
    handler_server_user_rebuy_return(e) {
        if (this.tid_key === (e.tid_key || "")) {
            if (0 == e.ret) {
                this.playerTs.setPoolScore(0, e.score);
                let t = this.pop_layer4.getChildByName("match_game_rebuy");
                ToolUtils.isObjValid(t) && t.destroy();
            }
            else {
                e.msg && ToolUtils.isSafeString(e.msg).length > 0 && Utils.shared().showToast(e.msg, 2);
            }
        }
    }
    handler_server_user_rebuy_bc_return(e) {
        if (this.tid_key !== (e.tid_key || "")) {
            return;
        }
        let t = RummyDataManager.shared().rummyInfos.get(this.tid_key);
        if (e.players_info) {
            for (let s = 0, i = e.players_info.length; s < i; s++) {
                for (let i = 0; i < 6; i++) {
                    let a = t.playerModels[i];
                    if (a && e.players_info[s].uid == a.uid) {
                        a.score = e.players_info[s].score;
                        let t = this.getPosBySeatid(a.seatid);
                        this.playerTs.setPoolScore(t, e.players_info[s].score);
                        break;
                    }
                }
            }
        }
    }
    handler_server_notify_flow_bureau_return(e) {
        this.tid_key === (e.tid_key || "") && (this.showMatchTipsAnim(1), RummyDataManager.shared().onFlowBureauReset(this.tid_key), Utils.shared().hideCommomDialog(), this.onGameEndViewClosed(), this.autoDropTs.hideAllLayer());
    }
    handler_server_timer_event_msg_notify(e) {
        if (this.tid_key !== (e.tid_key || "")) {
            return;
        }
        let t = null;
        2 == Number(e.code) && ToolUtils.isObjValid(this.topBgNode) && ToolUtils.isObjValid(this.topBgNode.getChildByName("match_moneyup_tip")) && this.topBgNode.getChildByName("match_moneyup_tip").active && (t = this.topBgNode.getChildByName("match_moneyup_tip").getChildByName("flag"));
        this.tipTs.showMatchFlowTips(e.msg, e.code, t);
    }
    handler_server_base_money_up_notify(e) {
        if (this.tid_key === (e.tid_key || "")) {
            try {
                let t = RummyDataManager.shared().rummyInfos.get(this.tid_key);
                if (t.cur_level = e.level, t.racing_time = e.next_up_time, this.tipTs.getMatchLevelActive() && this.tipTs.setMatchLevelActive(true, t.levels_info, t.cur_level), t.gameRummyType == RUMMY_GAME_TYPE.MATCH && t.gameMatchType == RUMMY_MATCH_TYPE.BASEMONEYUP) {
                    if (this.rummyShowTopUiLogic.showMathMoneyUpTop(e.base_money, e.next_value), null != e.next_up_time) {
                        let t = RummyDataManager.formatRaceTime(e.next_up_time);
                        this.rummyShowTopUiLogic.setRaceTime(t);
                    }
                    sys.isObjectValid(e.is_game_start) && 1 == Number(e.is_game_start) || this.showMatchMoneyUpFlash();
                }
                sys.isObjectValid(e.rebuy) && sys.isObjectValid(e.qualify) && this.rummyShowTopUiLogic.updateMatchRebuy(e.rebuy, e.qualify);
            }
            catch (e) {
                TLog.printError("handler_server_base_money_up_notify error:", e);
            }
        }
    }
    showMatchMoneyUpFlash() {
        let e = this.topBgNode.getChildByName("match_moneyup_tip");
        if (ToolUtils.isObjValid(e) && e.active) {
            let t = e.getChildByName("flashAnim");
            if (ToolUtils.isObjValid(t)) {
                t.active = true;
                let e = t.getComponent(sp.Skeleton);
                e.setToSetupPose();
                e.clearTracks();
                e.setAnimation(0, "flash", false);
                let s = 0;
                e.setCompleteListener((() => {
                    s++;
                    s >= 2 ? t.active = false : e.setAnimation(0, "flash", false);
                }));
            }
        }
    }
    handler_server_pre_start_bc(e) {
        if (this.tid_key !== (e.tid_key || "")) {
            return;
        }
        let t = RummyDataManager.shared().rummyInfos.get(this.tid_key);
        if (User.shared().send_help_all_switcher(this.tid_key), RummyDataManager.shared().reportGameStartCountDown(this.tid_key), t.gameRummyType != RUMMY_GAME_TYPE.POOL && t.gameRummyType != RUMMY_GAME_TYPE.PRI_POOL) {
            this.cardsTs.resetView();
            this.tipTs.showMatchWaitTip(false);
            RummyDataManager.shared().onPreStartReset(this.tid_key, e.cd);
            t.bIsSwitchRoom = false;
            sys.isObjectValid(e.src_score) ? sys.isObjectValid(e.finish_multiple) ? this.playerTs.showLoseScore(0, e.all_score, true, e.src_score, e.finish_multiple) : this.playerTs.showLoseScore(0, e.all_score, true, e.src_score) : this.playerTs.showLoseScore(0, e.all_score, true);
            this.finishType = -1;
            this.process_server_pre_start();
            t.gameRummyType == RUMMY_GAME_TYPE.MATCH && (this.playerTs.setPaiDuiBgShow(false), this.actionTs.changeOpenCardStatus(false, this), this.actionTs.changeSwitchJokerStatus(false, this), this.removeGameOverView(), this.gameOverOpenLogic._gameEndMsg = null);
        }
        else {
            if (1 == t.is_game_all_end) {
                return;
            }
            1 == e.show_split_prize || (t.game_end_state = 0, ToolUtils.isObjValid(this.gameEndView) ? (this.gameEndView.getComponent(RummyGameOverAlert).setPoolRummyCountDown(e.cd), this.gameEndView.getComponent(RummyGameOverAlert).updateBtnShow()) : (0 == e.round && (t.game_end_state = 6), t.end_game_countdown = e.cd, this.showGameStartCountDown()));
        }
    }
    process_server_pre_start() {
        RummyDataManager.shared().stopTweenAction(this.delay_ready_action);
        this.deleteGameOverDalay();
        this._gameOverMsg = null;
        this.matchTotalSettleMsg = null;
        this._bIsGameEnd = false;
        this._bGameOverClosed = false;
        this._bIsWinnerAnimEnd = true;
        this.autoReadyTime = -1;
        this.gameOverOpenLogic._gameEndMsg = null;
        this.cardsTs.resetView();
        this.tipTs.showMatchWaitTip(false);
        let e = RummyDataManager.shared().rummyInfos.get(this.tid_key), t = e.clientSeatId, s = e.playerModels[t];
        if (s && this._bIsShowReady && 1 != s.ready && (this.is_first_round ? e.host_seat != e.clientSeatId ? this.actionTs.showReadyBtn() : this.actionTs.hideReadyBtn() : this.actionTs.showReadyBtn()), this.actionTs.hideStartBtn(), this.hasDeclare = false, e.gameRummyType != RUMMY_GAME_TYPE.POOL && e.gameRummyType != RUMMY_GAME_TYPE.DEALS && e.game_cd > 0) {
            let t = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_main.gameTipsText"), e.game_cd);
            RummyDataManager.shared().stopTweenAction(this.start_time_action);
            this.start_time_action = TweenTool.myschedule(RummyDataManager.shared().sceneNode, 1, this.updateTipTime.bind(this));
            e.gameRummyType != RUMMY_GAME_TYPE.POINTS && e.gameRummyType != RUMMY_GAME_TYPE.PRIVATE && e.gameRummyType != RUMMY_GAME_TYPE.PRI_POOL && e.gameRummyType != RUMMY_GAME_TYPE.PRI_DEAL && e.gameRummyType != RUMMY_GAME_TYPE.MATCH && e.gameRummyType != RUMMY_GAME_TYPE.MULTIPLE || ToolUtils.isObjValid(this.gameEndView) && (e.gameRummyType == RUMMY_GAME_TYPE.MATCH ? this.gameEndView.getComponent(RummyPointsMatchOverAlert).showCountDown(t) : this.gameEndView.getComponent(RummyGameOverAlert).showCountDown(t));
        }
        this.playerTs.setPaiDuiBgShow(false, true);
        this.actionTs.changeOpenCardStatus(false, this);
        this.actionTs.changeSwitchJokerStatus(false, this);
        e.gameRummyType != RUMMY_GAME_TYPE.MATCH && this.tipTs.resetFamaToReadyModel();
    }
    updateTipTime() {
        if (!ToolUtils.isObjValid(this.node)) {
            return;
        }
        if (!RummyDataManager.shared().rummyInfos.has(this.tid_key)) {
            return;
        }
        let e = RummyDataManager.shared().rummyInfos.get(this.tid_key);
        e.game_cd = e.game_cd - 1;
        e.game_cd <= 0 && (RummyDataManager.shared().stopTweenAction(this.start_time_action), this.start_time_action = null, this.removeGameOverView());
        let t = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_main.gameTipsText"), e.game_cd);
        if (e.gameRummyType == RUMMY_GAME_TYPE.PRIVATE || e.gameRummyType == RUMMY_GAME_TYPE.PRI_POOL || e.gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL || e.gameRummyType == RUMMY_GAME_TYPE.MATCH || (this.playerTs.setPaiDuiBgShow(false), this.actionTs.changeOpenCardStatus(false, this), this.actionTs.changeSwitchJokerStatus(false, this)), e.gameRummyType != RUMMY_GAME_TYPE.POINTS && e.gameRummyType != RUMMY_GAME_TYPE.PRIVATE && e.gameRummyType != RUMMY_GAME_TYPE.PRI_POOL && e.gameRummyType != RUMMY_GAME_TYPE.PRI_DEAL && e.gameRummyType != RUMMY_GAME_TYPE.MATCH && e.gameRummyType != RUMMY_GAME_TYPE.MULTIPLE || ToolUtils.isObjValid(this.gameEndView) && (e.gameRummyType == RUMMY_GAME_TYPE.MATCH ? this.gameEndView.getComponent(RummyPointsMatchOverAlert).showCountDown(t) : this.gameEndView.getComponent(RummyGameOverAlert).showCountDown(t)), e.gameRummyType == RUMMY_GAME_TYPE.POINTS || e.gameRummyType == RUMMY_GAME_TYPE.POOL || e.gameRummyType == RUMMY_GAME_TYPE.MULTIPLE) {
            let t = 0;
            for (let s = 0; s < 6; s++) {
                e.playerModels[s].isShow && (t += 1);
            }
            t <= 1 && (e.game_state = 5, this.playerTs.setPaiDuiBgShow(false), this.actionTs.changeOpenCardStatus(false, this), this.actionTs.changeSwitchJokerStatus(false, this));
        }
    }
    updateCheckReadyStatus() {
        if (!ToolUtils.isObjValid(this.node)) {
            return;
        }
        if (!RummyDataManager.shared().rummyInfos.has(this.tid_key)) {
            return;
        }
        let e = RummyDataManager.shared().rummyInfos.get(this.tid_key);
        if (e.gameRummyType == RUMMY_GAME_TYPE.PRIVATE || e.gameRummyType == RUMMY_GAME_TYPE.PRI_POOL || e.gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL) {
            let t = e.clientSeatId;
            1 == e.playerModels[t].ready ? (RummyDataManager.shared().stopTweenAction(this.delay_ready_action), this.delay_ready_action = null) : this.onDealBtnAction("private_ready");
        }
        else {
            RummyDataManager.shared().stopTweenAction(this.delay_ready_action);
            this.delay_ready_action = null;
        }
    }
    handler_server_game_start_bc(e) {
        if (1 == User.shared().isInPerformanceRoom) {
            return void (this.roomPerformance && this.roomPerformance.isValid && this.roomPerformance.handler_server_game_start_bc(e));
        }
        if (this.tid_key !== (e.tid_key || "")) {
            return;
        }
        User.shared().lastWinGameInfo = { nVid: -1, nScore: 0 };
        this.moveCard_action && (TweenTool.stopAction(this.moveCard_action), this.moveCard_action = null);
        let t = RummyDataManager.shared().rummyInfos.get(this.tid_key);
        if (t.isMovingCard = false, t.hasShowWinAnim = false, t.laizicard = 1, t.winLaizicard = 0, t.lastLaizicard = 0, this.hasPlayOutLocalCard = false, this.hideAllTingPaiFlag(), this.tipTs.showQuickFinishTips(false), this.tingPaiMsg = null, this.pickCardInfo = null, this.helper_hu_card = 0, this.can_declare = 0, this.quick_sort = 0, this.tipTs.show_wait_declare(false), this.tipTs.setAvailableCardTipsVisible(false), this.tipTs.setManulaTipsShow(false), this.checkIsPointsMatch()) {
            let e = this.pop_layer4.getChildByName("commondialog_node");
            ToolUtils.isObjValid(e) && (this.hasPointsMatchExitAlert || e.destroy());
        }
        else {
            Utils.shared().hideCommomDialog(this.pop_layer4);
        }
        Utils.shared().hideOtherQuickPayAlertByType();
        Utils.shared().hideOtherQuickPayAlertByType(null, this.node);
        t.xiaojuNum = e.cround;
        t.isAbleAutoGroup = e.is_able_auto_group;
        RummyDataManager.shared().onGameStartReset(this.tid_key);
        undefined !== e.cround && e.cround <= 1 && (t.hasReportFinish = false);
        this._isPlayWinEffec = false;
        RummyDataManager.shared().reportGameStart(this.tid_key, e);
        let s = ToolUtils.deskInfos.get(User.shared().curTid_key);
        s || (User.shared().curTid_key = this.tid_key, s = ToolUtils.deskInfos.get(User.shared().curTid_key));
        RummyDataManager.shared().stopTweenAction(this.start_time_action);
        this.start_time_action = null;
        ToolUtils.isObjValid(this.rummyGameManualSplit) && (this.rummyGameManualSplit.destroy(), this.rummyGameManualSplit = null);
        this.rummyShowTopUiLogic.cancelHistoryLoad();
        this.rummyShowTopUiLogic.cancelDealPoolRecord();
        ToolUtils.isObjValid(this.gameHistoryView) && (this.gameHistoryView.destroy(), this.gameHistoryView = null);
        ToolUtils.isObjValid(this.poolScoreboardView) && (this.poolScoreboardView.destroy(), this.poolScoreboardView = null);
        this.removeTotalSettlementView();
        this.removeGameOverView();
        for (let e = 0; e < 6; e++) {
            this.playerTs.changePlayerZhuangState(false, e);
            this.playerTs.hideEnterAnim(e);
            this.playerTs.setPoolManualState(e, false);
        }
        if (this.playerTs.resetHideBounsTime(), this.deleteGameOverDalay(), this._gameOverMsg = null, this.matchTotalSettleMsg = null, this._bIsGameEnd = false, this._bGameOverClosed = false, this._bIsWinnerAnimEnd = true, this._bIsShowReady = false, this._hasSendMsg = false, this._playerEnterMsg = [], this._playerExitMsg = [], this.gameStartMsg = null, this.gameOverOpenLogic._gameEndMsg = null, t.gameRummyType != RUMMY_GAME_TYPE.POOL && t.gameRummyType != RUMMY_GAME_TYPE.PRI_POOL && t.gameRummyType != RUMMY_GAME_TYPE.DEALS && t.gameRummyType != RUMMY_GAME_TYPE.PRI_DEAL || (t.is_game_all_end = 0, this.cardsTs.showCopyCard(false), null != e.pool_money && (t.pool_money = e.pool_money)), t.game_end_state = -1, null != e.zhuang_seatid) {
            let s = parseInt("" + e.zhuang_seatid);
            t.zhuang_seatid = s;
        }
        this.isUpdateMyMoney = true;
        t.gameRummyType == RUMMY_GAME_TYPE.POOL || t.gameRummyType == RUMMY_GAME_TYPE.DEALS || t.gameRummyType == RUMMY_GAME_TYPE.PRI_POOL || t.gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL || t.gameRummyType == RUMMY_GAME_TYPE.MATCH || this.tipTs.resetFamaToReadyModel();
        t.bIsSwitchRoom = false;
        this.isGameStarting = true;
        this.is_first_round = false;
        this.tipTs.hideWinEffect();
        this.tipTs.showGameTipsText(0, 0, "");
        this.rummyShowTopUiLogic.hideMatchTipsAnim();
        this.tipTs.showMatchPeopleAnimTips(false, null);
        for (let e = 0, s = t.playerGiveCards.length; e < s; e++) {
            t.playerGiveCards[e].cards = [];
        }
        if (this.hideOpenCardAlert(), this.hideWinTipAlert(), 1 == e.reassigned_seats) {
            for (let e = 0; e < 6; e++) {
                this.playerTs.changePlayerZhuangState(false, e);
            }
            t.is_table_change_status = true;
            PushCenter.shared().pushEvent(GameConfig.Update_Private_Exit_Status, { tid_key: this.tid_key, bEnable: false });
            PushCenter.shared().pushEvent(GameConfig.Update_Menu_Switch_Status, { tid_key: this.tid_key, bEnable: false });
        }
        else {
            t.gameRummyType != RUMMY_GAME_TYPE.POINTS && t.gameRummyType != RUMMY_GAME_TYPE.MULTIPLE || (t.is_table_change_status = true, PushCenter.shared().pushEvent(GameConfig.Update_Private_Exit_Status, { tid_key: this.tid_key, bEnable: false }), PushCenter.shared().pushEvent(GameConfig.Update_Menu_Switch_Status, { tid_key: this.tid_key, bEnable: false }));
        }
        this.actionTs.onGameStartReset();
        ToolUtils.isObjValid(this.gameEndView) || ToolUtils.isObjValid(this.gameHistoryView) || ToolUtils.isObjValid(this.RummyTotalSettlementNode) || PushCenter.shared().pushEvent(PushEvent.ShowWinShareBtn, false);
        this.autoDropTs.isshowAutoDropBtn(false, this.tid_key);
        this.cardsTs.showDropCardsZheZhao(false);
        this.tipTs.showMatchWaitTip(false);
        this.cardsTs.resetView();
        this.actionTs.showDoubleGameChooseTip(false);
        let i = t.clientSeatId, a = -1, r = -1;
        if (e.players) {
            for (let s = 0, h = e.players.length; s < h; s++) {
                e.players[s].uid == User.shared().data.uid && (i = e.players[s].old_seat, r = e.players[s].seatid, t.isWatching = ToolUtils.isSafeNumber(e.players[s].isWatching), sys.isObjectValid(e.players[s].bump_notify) && (t.bump_notify = e.players[s].bump_notify));
                e.players[s].drawing_card > 0 && (a = s);
            }
        }
        if (1 !== t.isWatching && (RummyDataManager.shared().rummyInfos.get(this.tid_key).manule_rejoin_select = false, this.tipTs.setManulaRejoinSelect(false)), RummyDataManager.shared().isShowSwitchBtn(this.tid_key) && this.actionTs.changeSwitchBtnStatus(true), this.gameStartMsg = e, e.players) {
            for (let s = 0, h = e.players.length; s < h; s++) {
                const h = e.players[s];
                let o = h.seatid, d = h.drawing_card, n = t.playerModels[o];
                n.fold_leave = h.fold_leave;
                n.status = h.status;
                n.betting = h.betting;
                undefined !== h.score && (n.score = h.score);
                n.isRejoin = 0;
                undefined !== h.isRejoin && (n.isRejoin = h.isRejoin);
                n.name = h.name;
                t.playerModels[o].money = h.money;
                let l = 0, _ = s == a, c = false;
                1 == e.reassigned_seats ? (l = this.getOldPosBySeatid(h.old_seat, i), c = 1 == h.drawing_card_is_max) : (l = this.getPosBySeatid(o), c = 1 == h.drawing_card_is_max);
                this.playerTs.updatePlayerMoney(l, h.money);
                this.playerTs.showDoubleState(l, 0, false);
                t.gameRummyType != RUMMY_GAME_TYPE.POOL && t.gameRummyType != RUMMY_GAME_TYPE.PRI_POOL && t.gameRummyType != RUMMY_GAME_TYPE.DEALS && t.gameRummyType != RUMMY_GAME_TYPE.PRI_DEAL && t.gameRummyType != RUMMY_GAME_TYPE.MATCH || (this.playerTs.setPoolScoreState(l, true), this.playerTs.setPoolRejoinState(l, 1 == n.isRejoin));
                let m = this.node.getChildByName("comm_magic_face");
                ToolUtils.isObjValid(m) && m.destroy();
                let y = this.getOldPosBySeatid(o, r);
                t.gameRummyType == RUMMY_GAME_TYPE.DEALS || t.gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL || t.gameRummyType == RUMMY_GAME_TYPE.POOL || t.gameRummyType == RUMMY_GAME_TYPE.PRI_POOL ? d > 0 ? this.cardsTs.drawCard(l, d, 0, c, _, this.showZhaung.bind(this), y) : 1 == h.betting && this.showZhaung() : d > 0 && this.cardsTs.drawCard(l, d, 0, c, _, this.showZhaung.bind(this), y);
                h.uid == User.shared().data.uid && 0 === t.crashModel && (User.shared().data.money = User.shared().real_money = h.money, PushCenter.shared().pushEvent(GameConfig.Update_Money, h.money));
            }
        }
        if (1 != e.reassigned_seats) {
            t.playerGiveCards = [];
            for (let e = 0; e < 6; e++) {
                let s = t.playerModels[e];
                if (s && null != s.betting && null != s.betting) {
                    let e = this.getPosBySeatid(s.seatid);
                    if (1 == s.betting || 0 == s.betting && s.status >= 0) {
                        let i = [];
                        i.seatid = s.seatid;
                        i.name = s.name;
                        i.cards = [];
                        t.playerGiveCards.push(i);
                        s.status > 0 ? 1 == s.status ? this.playerTs.changeAwayStateStatus(e, true, RUMMY_PLAYER_STATE_TYPE.DROPPED) : 5 == s.status ? this.playerTs.changeAwayStateStatus(e, true, RUMMY_PLAYER_STATE_TYPE.MIDDLEDROP) : 3 == s.status && this.playerTs.changeAwayStateStatus(e, true, RUMMY_PLAYER_STATE_TYPE.WRONGSHOW) : null != s.fold_leave && null != s.fold_leave && 1 == s.fold_leave && this.playerTs.changeAwayStateStatus(e, true, RUMMY_PLAYER_STATE_TYPE.AWAY);
                    }
                    else {
                        this.playerTs.changeAwayStateStatus(e, true, RUMMY_PLAYER_STATE_TYPE.WAITING);
                    }
                    undefined !== s.score && this.playerTs.setPoolScore(e, s.score);
                }
            }
            this.sortPlayerGiveCard();
        }
        if ((t.gameRummyType == RUMMY_GAME_TYPE.PRIVATE || t.gameRummyType == RUMMY_GAME_TYPE.PRI_POOL || t.gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL || t.gameRummyType == RUMMY_GAME_TYPE.DEALS || t.gameRummyType == RUMMY_GAME_TYPE.POOL) && -1 !== r) {
            let e = r, s = t.playerModels[e];
            1 == t.isInGameing && (1 == s.betting || 0 == s.betting && 4 == s.status) ? PushCenter.shared().pushEvent(GameConfig.Update_Private_Exit_Status, { tid_key: this.tid_key, bEnable: false }) : PushCenter.shared().pushEvent(GameConfig.Update_Private_Exit_Status, { tid_key: this.tid_key, bEnable: true });
        }
    }
    showZhaung(e) {
        if (e && this.gameStartMsg && 1 == this.gameStartMsg.reassigned_seats) {
            let e = this.gameStartMsg, t = RummyDataManager.shared().rummyInfos.get(this.tid_key);
            t.ding_zhuang_seat_state = 1;
            let s = 0, i = 0;
            if (1 == User.shared().isInPerformanceRoom) {
                t.clientSeatId = e.self_seatid;
                s = e.self_old_seatid;
                i = e.self_seatid;
            }
            else if (s = t.clientSeatId, i = 0, e && e.players && "object" == typeof e.players) {
                for (let a = 0, r = e.players.length; a < r; a++) {
                    e.players[a].uid == User.shared().data.uid && (i = e.players[a].seatid, s = e.players[a].old_seat, t.clientSeatId = e.players[a].seatid, 0 == t.crashModel && (User.shared().data.money = User.shared().real_money = e.players[a].money));
                }
            }
            if (e && e.players && "object" == typeof e.players) {
                for (let a = 0; a < 6; a++) {
                    let r = {};
                    r.seatid = a;
                    r.isShow = false;
                    t.playerModels[a] = null;
                    t.playerModels[a] = r;
                    let h = false;
                    for (let t = 0, r = e.players.length; t < r; t++) {
                        let r = this.getOldPosBySeatid(e.players[t].seatid, i), o = this.getOldPosBySeatid(e.players[t].old_seat, s);
                        r != a && o != a || (h = true);
                    }
                    h && 0 != a && this.playerTs.playerScaleDownAnim(a);
                }
                this.cardsTs.drawCardAnim();
                for (let s = 0, i = e.players.length; s < i; s++) {
                    let i = e.players[s].seatid, a = t.playerModels[i];
                    if (sys.isObjectValid(a)) {
                        if (a.isShow = true, a.ready = 0, a.uid = e.players[s].uid, a.seatid = e.players[s].seatid, a.role = e.players[s].role, null != e.players[s].ready ? a.ready = e.players[s].ready : null != e.players[s].zhunbei && (a.ready = e.players[s].zhunbei), a.betting = e.players[s].betting, a.fold_leave = e.players[s].fold_leave, a.see = e.players[s].see, a.bet = e.players[s].bet, a.status = e.players[s].status, a.name = e.players[s].name, a.sex = e.players[s].sex, a.avatar = e.players[s].avatar, a.avatar_url = e.players[s].avatar_url, a.money = e.players[s].money, a.score = e.players[s].score, a.total_board = e.players[s].total_board, a.total_win = e.players[s].total_win, a.vlevel = e.players[s].vlevel, a.dsc = e.players[s].ps, a.vip = e.players[s].vip, a.anim_id = e.players[s].anim_id, a.club_level = e.players[s].club_level, a.club_effect_v2 = e.players[s].club_effect_v2, null != e.players[s].rank && (a.rank = e.players[s].rank), sys.isObjectValid(e.players[s].avatar_frame_id) ? a.avatar_frame_id = e.players[s].avatar_frame_id : a.avatar_frame_id = 0, sys.isObjectValid(e.players[s].play_effect_id) ? a.play_effect_id = e.players[s].play_effect_id : a.play_effect_id = 0, t.playerModels[i] = a, 2 != t.pnum) {
                            let e = this.getPosBySeatid(i);
                            TweenTool.delayAct(this.time_node, (() => {
                                this.playerTs.playerScaleUpAnim(e, a);
                                a.anim_id && TweenTool.delayAct(this.time_node, (() => {
                                    this.playerTs.playEnterAnim(e, a.anim_id);
                                }), 0.5, true);
                            }), 0.17, true);
                            null != a.score && (this.playerTs.setPoolScore(e, a.score), this.updateSeatScore(i, a.score));
                            TweenTool.delayAct(this.time_node, (() => {
                                let t = RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType;
                                t != RUMMY_GAME_TYPE.POOL && t != RUMMY_GAME_TYPE.PRI_POOL && t != RUMMY_GAME_TYPE.DEALS && t != RUMMY_GAME_TYPE.PRI_DEAL && t != RUMMY_GAME_TYPE.MATCH || this.playerTs.setPoolScoreState(e, true);
                            }), 0.3, true);
                            a.status > 0 ? 1 == a.status ? this.playerTs.changeAwayStateStatus(e, true, RUMMY_PLAYER_STATE_TYPE.DROPPED) : 5 == a.status ? this.playerTs.changeAwayStateStatus(e, true, RUMMY_PLAYER_STATE_TYPE.MIDDLEDROP) : 3 == a.status && this.playerTs.changeAwayStateStatus(e, true, RUMMY_PLAYER_STATE_TYPE.WRONGSHOW) : null != a.fold_leave && null != a.fold_leave && 1 == a.fold_leave && this.playerTs.changeAwayStateStatus(e, true, RUMMY_PLAYER_STATE_TYPE.AWAY);
                        }
                        else {
                            let e = this.getPosBySeatid(i);
                            a.anim_id && TweenTool.delayAct(this.time_node, (() => {
                                this.playerTs.playEnterAnim(e, a.anim_id);
                            }), 0.5, true);
                        }
                    }
                    else {
                        TLog.printError("------- table info init player i, pmodel:", s, a);
                    }
                }
                t.gameRummyType == RUMMY_GAME_TYPE.MATCH && PushCenter.shared().pushEvent(GameConfig.Update_Menu_Switch_Status, { tid_key: this.tid_key, bEnable: false });
                this.delayShowEnterPlayers();
            }
            t.playerGiveCards = [];
            for (let e = 0; e < 6; e++) {
                let s = t.playerModels[e];
                if (s && s.isShow && null != s.betting && null != s.betting) {
                    let e = this.getPosBySeatid(s.seatid);
                    if (1 == s.betting || 0 == s.betting && s.status >= 0) {
                        let e = [];
                        e.seatid = s.seatid;
                        e.name = s.name;
                        e.cards = [];
                        t.playerGiveCards.push(e);
                    }
                    else {
                        this.playerTs.changeAwayStateStatus(e, true, RUMMY_PLAYER_STATE_TYPE.WAITING);
                    }
                }
            }
            this.sortPlayerGiveCard();
        }
        else if (this.cardsTs.drawCardAnim(true), this.gameStartMsg) {
            for (let e = 0, t = this.gameStartMsg.players.length; e < t; e++) {
                let t = this.gameStartMsg.players[e], s = t.seatid, i = this.getPosBySeatid(s);
                t.anim_id && TweenTool.delayAct(this.time_node, (() => {
                    this.playerTs.playEnterAnim(i, t.anim_id);
                }), 2, true);
            }
        }
        TweenTool.delayAct(this.time_node, (() => {
            this.playerTs.changePlayerZhuangState(true, this.getPosBySeatid(RummyDataManager.shared().rummyInfos.get(this.tid_key).zhuang_seatid));
        }), 1, true);
    }
    showGuideTips(e) {
        HttpManager.shared().doReportPlayerGuideAct(PhpReportDefined.roomPlayerGuideEvent.popNotice);
        Utils.shared().showCommomDialog(i18nMgr.shared().getValueByKey("gameRummy_notice_Pop.tip_cont"), i18nMgr.shared().getValueByKey("gameRummy_notice_Pop.guide_tip"), (t => {
            1 == t ? (this.jumpToNewPlayerGuide(), HttpManager.shared().doReportPlayerGuideAct(PhpReportDefined.roomPlayerGuideEvent.noticeClickOkay)) : 3 == t && (e && e(), HttpManager.shared().doReportPlayerGuideAct(PhpReportDefined.roomPlayerGuideEvent.noticeClickNo));
        }), true, ToolUtils.getIsNormalDirection(), i18nMgr.shared().getValueByKey("gameRummy_notice_Pop.okey"), i18nMgr.shared().getValueByKey("gameRummy_notice_Pop.no"), null, this.pop_layer4, null, this.tid_key);
    }
    handler_server_change_succ_bc(e) {
        this.tid_key === (e.tid_key || "") && (Utils.shared().hideLoading(), ToolUtils.isObjValid(this.game_chatNode) && this.game_chatTs.hideAllChat(), undefined !== e.alertStr && null !== e.alertStr && "string" == typeof e.alertStr && e.alertStr.length > 0 && this.tipTs.updateTableTipsInfo(true, e.alertStr, 5), RummyDataManager.shared().stopTweenAction(this.switch_tab_action), this.switch_tab_action = null, 1 === e.ret ? (RummyDataManager.shared().rummyInfos.get(this.tid_key).bIsSwitchRoom = false, this.gameOverOpenLogic.reShowEndView(this.tid_key)) : 2 === e.ret ? (RummyDataManager.shared().rummyInfos.get(this.tid_key).bIsSwitchRoom = false, RummyDataManager.shared().rummyInfos.get(this.tid_key).bIsAddSwitchRoom, sys.isObjectValid(e.msg) && Utils.shared().showToast(e.msg, 2, 0, ToolUtils.getIsNormalDirection())) : (RummyDataManager.shared().rummyInfos.get(this.tid_key).bIsAddSwitchRoom, this.playerTs.setPaiDuiBgShow(false), this.actionTs.changeOpenCardStatus(false, this), this.actionTs.changeSwitchJokerStatus(false, this), this.removeGameOverView(), this.removeTotalSettlementView(), this.gameOverOpenLogic._gameEndMsg = null));
    }
    delayShowEnterPlayers() {
        for (let e = 0, t = this._playerEnterMsg.length; e < t; e++) {
            this.handler_server_login_succ_bc(this._playerEnterMsg[e]);
        }
        this._playerEnterMsg = [];
    }
    delayHideExitPlayers() {
        for (let e = 0, t = this._playerExitMsg.length; e < t; e++) {
            this.handler_server_logout_succed_bc(this._playerExitMsg[e]);
        }
        this._playerExitMsg = [];
    }
    getOldPosBySeatid(e, t) {
        let s = e - t;
        return s >= 0 ? s : s + RummyDataManager.shared().rummyInfos.get(this.tid_key).pnum;
    }
    resetGameByTableInfo() {
        this.rummyLogicProcessing.resetGameByTableInfo();
    }
    myTurnFastBuyCallback(e) {
        if (1 == e) {
            let e = RummyDataManager.shared().rummyInfos.get(this.tid_key);
            if (User.shared().checkFastBuy()) {
                User.shared().data.shop_guide = 2;
                let t = 0, s = e.playerModels[e.clientSeatId];
                if (s.uid == User.shared().data.uid && (e.gameRummyType == RUMMY_GAME_TYPE.POINTS || e.gameRummyType == RUMMY_GAME_TYPE.MULTIPLE ? (t = this.playerTs.getLoseScore(), t = 1 == s.status || 5 == s.status ? 0 : 0 != t ? t : 2) : t = e.entry_fee), 1 == e.crashModel) {
                    let s = { vid: e.vid, isShowTip: true, parent_node: director.getScene().getChildByName("Canvas"), bShowNetTip: true, tid_key: User.shared().curTid_key, min_entry: t, in_room: 1 };
                    Utils.shared().showQuickChipRecharge(s);
                }
                else {
                    Utils.shared().showQuickRecharge(e.vid, this.node, true, this.tid_key, 0, t);
                    User.shared().updatePayScene(PhpReportDefined.pay_scene.game_gameover_less_money, e.vid);
                }
            }
            else {
                User.shared().showBlindAlert(0, 0);
            }
        }
        else {
            this.onDealBtnAction("QiPai_btn");
        }
    }
    restoreSeatRoundScore(snapshot, player, pos) {
        // The top-level score is our current hand. A playing seat's all_score
        // can be cumulative Pool/Deals PTS; never overwrite that hand with it.
        // Dropped/wrong-show/settled players still use their existing penalty UI.
        if (pos === 0 && Number(player.status) === 0 && snapshot.all_score != null) return;
        if (!(player.all_score > 0)) return;
        if (player.src_score != null) {
            if (snapshot.finish_multiple != null) {
                this.playerTs.showLoseScore(pos, player.all_score, true, player.src_score, player.finish_multiple);
            } else {
                this.playerTs.showLoseScore(pos, player.all_score, true, player.src_score);
            }
        } else {
            this.playerTs.showLoseScore(pos, player.all_score, true);
        }
    }
    handler_server_table_info_uc(e) {
        RummyDataManager.shared().bCanGoBack = true;
        this.upvenue_entry_fee = -1;
        let t = Math.floor(sys.now() / 1000);
        if (Utils.shared().hideLoading(), 1 == User.shared().isInPerformanceRoom) {
            return RummyDataManager.shared().tableData = e, void (this.roomPerformance && this.roomPerformance.isValid && this.roomPerformance.handler_server_table_info_uc(e));
        }
        if (this.tid_key !== (e.tid_key || "")) {
            return;
        }
        if (!RummyDataManager.shared().rummyInfos.has(this.tid_key)) {
            return;
        }
        // Recovery may enter a new match without receiving its start broadcast.
        this.rummyShowTopUiLogic.cancelDealPoolRecord();
        let s = RummyDataManager.shared().rummyInfos.get(this.tid_key);
        sys.isObjectValid(e.emotion_fee_cfg) && (s.emotion_fee_cfg = e.emotion_fee_cfg);
        s.flopCashTaskLaba = null;
        this.resetGameByTableInfo();
        sys.isObjectValid(e.finish_card) ? s.is_showhuAnim_status = ToolUtils.isSafeNumber(e.finish_card) > 0 : s.is_showhuAnim_status = false;
        sys.isObjectValid(e.able_client_group) && (s.able_client_group = 1 == e.able_client_group);
        s.able_local_discard = false;
        sys.isObjectValid(e.able_local_discard) && (s.able_local_discard = 1 == e.able_local_discard);
        s.able_race_push = 0;
        sys.isObjectValid(e.able_race_push) && (s.able_race_push = e.able_race_push);
        s.isWatching = ToolUtils.isSafeNumber(e.isWatching);
        s.gameRummyType = e.mode || 0;
        s.gameMatchMode = e.match_mode || 0;
        sys.isObjectValid(e.special_mode) && (s.gameRummyMode = e.special_mode);
        sys.isObjectValid(e.game_mode) && (s.gameMatchType = e.game_mode);
        sys.isObjectValid(e.helper_best_group_after_pick_open) && (s.helper_best_group_after_pick_open = e.helper_best_group_after_pick_open);
        sys.isObjectValid(e.helper_pick_additional_info_open) && (s.helper_pick_additional_info_open = e.helper_pick_additional_info_open);
        sys.isObjectValid(e.is_multiple) && (s.is_multiple = e.is_multiple);
        sys.isObjectValid(e.multiple_cfg) && (s.multiple_cfg = e.multiple_cfg);
        sys.isObjectValid(e.multiple_max_lost) && (s.multiple_max_lost = e.multiple_max_lost);
        sys.isObjectValid(e.multiple_middle_drop_cfg) && (s.multiple_midle_drop_cfg = e.multiple_middle_drop_cfg);
        sys.isObjectValid(e.multiple_show_fire_effect_turn) && (s.multiple_fire_round = e.multiple_show_fire_effect_turn);
        sys.isObjectValid(e.max_lost_score) && (s.max_lost_score = e.max_lost_score);
        sys.isObjectValid(e.is_bump) && (s.is_bump = e.is_bump);
        sys.isObjectValid(e.tf_venue_tips_touch_times) && (s.tf_max_tips_times = e.tf_venue_tips_touch_times);
        sys.isObjectValid(e.tf_venue_tips_entry_times) && (s.tf_entry_tips_times = e.tf_venue_tips_entry_times);
        sys.isObjectValid(e.tf_bonus) && (s.tf_bonus = e.tf_bonus);
        sys.isObjectValid(e.is_double) && (s.is_double = e.is_double);
        sys.isObjectValid(e.force_up_venue_tips_drop_times) && (s.force_up_venue_tips_drop_times = e.force_up_venue_tips_drop_times);
        sys.isObjectValid(e.force_up_venue_tips_drop_every) && (s.force_up_venue_tips_drop_every = e.force_up_venue_tips_drop_every);
        sys.isObjectValid(e.force_up_venue_tips_drop_touch_ts) && (s.force_up_venue_tips_drop_touch_ts = e.force_up_venue_tips_drop_touch_ts);
        sys.isObjectValid(e.drop_tips_count) && (s.drop_tips_count = e.drop_tips_count);
        sys.isObjectValid(e.has_first_open) && (s.first_force_up_venue_tips_drop = 0 == e.has_first_open);
        1 == s.gameRummyMode && sys.isObjectValid(User.shared().points_easy_cfg) && 1 == User.shared().points_easy_cfg.show_game_introduce && this.actionTs.setEasyHelpBtnVisible(true);
        1 == s.is_multiple && (this.actionTs.setMultipleTipsBtnShow(true), sys.isObjectValid(User.shared().points_multiple_cfg) && 1 == User.shared().points_multiple_cfg.show_game_introduce && this.actionTs.setMultipleHelpBtnVisible(true));
        1 == s.is_double && sys.isObjectValid(User.shared().points_double_cfg) && 1 == User.shared().points_double_cfg.show_game_introduce && this.actionTs.setMultipleHelpBtnVisible(true);
        User.shared().gameRummyType = e.mode;
        s.gameBaseMoney = e.base_money;
        s.gamePlayerNum = e.pnum;
        s.gameRummyType == RUMMY_GAME_TYPE.POOL || s.gameRummyType == RUMMY_GAME_TYPE.PRI_POOL ? s.gameRound = e.disuse_score : s.gameRummyType != RUMMY_GAME_TYPE.DEALS && s.gameRummyType != RUMMY_GAME_TYPE.PRI_DEAL || (s.gameRound = e.total_round);
        undefined !== e.cround && (s.xiaojuNum = e.cround, e.cround <= 1 && (s.hasReportFinish = false));
        this.is_data_reporting && (this.is_data_reporting = false, RummyDataManager.shared().reportSuccessIntoGameWithServer(e, this.tid_key));
        let i = this.node.getChildByName("rootNode").getChildByName("smallGamebg");
        i.active = false;
        i.getChildByName("guessCard_btn").getChildByName("Sprite").active = false;
        sys.isObjectValid(e.is_rapid) && (s.is_rapid = 1 == Number(e.is_rapid), ToolUtils.isObjValid(this.topBgNode) && ToolUtils.isObjValid(this.topBgNode.getChildByName("match_moneyup_tip")) && this.topBgNode.getChildByName("match_moneyup_tip").active && ToolUtils.isObjValid(this.topBgNode.getChildByName("match_moneyup_tip").getChildByName("flag")) && (this.topBgNode.getChildByName("match_moneyup_tip").getChildByName("flag").active = s.is_rapid));
        let a = e.state;
        if (s.in_choose_double = 5 == a ? 1 : 0, 2 == a || 5 == a ? (this._bIsShowReady = false, this.isGameStarting = true, this.is_first_round = false, s.isInGameing = 1, s.isGameStarting = 1, s.isCanTouchCard = true, s.bIsHasHu = false, !this.serverUpdateTipsShow && ToolUtils.isObjValid(this.gameEndView) && (s.gameRummyType != RUMMY_GAME_TYPE.POINTS && s.gameRummyType != RUMMY_GAME_TYPE.MULTIPLE || this.removeGameOverView()), this.winTips.active = !!this._bIsShowWinTip) : (this.winTips.active = false, RummyDataManager.shared().stopTweenAction(this.hide_win_tip_action), this.actionTs.changeOpenCardStatus(false, this), this.actionTs.changeSwitchJokerStatus(false, this), s.bIsHasHu = true, !this.serverUpdateTipsShow && ToolUtils.isObjValid(this.gameEndView) && (s.gameRummyType == RUMMY_GAME_TYPE.PRIVATE || s.gameRummyType == RUMMY_GAME_TYPE.MATCH ? this.checkIsPointsMatch() || this.removeGameOverView() : s.gameRummyType == RUMMY_GAME_TYPE.PRI_POOL || s.gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL ? 0 == e.cround && this.removeGameOverView() : s.gameRummyType != RUMMY_GAME_TYPE.POINTS && 3 != a && 4 != a && this.removeGameOverView())), (s.gameRummyType == RUMMY_GAME_TYPE.POOL || s.gameRummyType == RUMMY_GAME_TYPE.DEALS || s.gameRummyType == RUMMY_GAME_TYPE.PRI_POOL || s.gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL) && !this.serverUpdateTipsShow && ToolUtils.isObjValid(this.gameEndView) && 3 != a && 4 != a) {
            this.gameEndView.getComponent(RummyGameOverAlert).checkOverBtnsToDestroryEndAlert() && this.removeGameOverView();
        }
        this.hideWinTipAlert();
        s.game_type = ToolUtils.isSafeNumber(e.game_type);
        e.game_type !== HowToPlayDefined.gameId_PracticeRummy && e.game_type !== HowToPlayDefined.GameType_PoolPractice && e.game_type !== HowToPlayDefined.GameType_DealsPractice && e.game_type !== HowToPlayDefined.GameType_MultiplePractice || (s.crashModel = 1);
        s.base_money = ToolUtils.isSafeNumber(e.base_money);
        s.entry_fee = ToolUtils.isSafeNumber(e.entry_fee);
        s.raceid = e.raceid;
        s.dealsRummyCurrentRount = e.cround;
        s.dealsrummyIsCanFold = e.isCanFold;
        s.autoGroupStatus = e.auto_group_status;
        this.rummyLogicProcessing.resetAutoGroupIntent(s);
        s.isAbleAutoGroup = e.is_able_auto_group;
        s.autoBsetDeclareOpen = e.auto_best_declare_open;
        s.stayInTable = false;
        s.dropType = 0;
        User.shared().setGameRaceid(e.raceid, true);
        let r = e.dealTs;
        this.drop_money = e.drop_money;
        e.all_score;
        let h = e.pnum, o = sys.isObjectValid(e.start_cd) ? e.start_cd : 0, n = 0;
        e.mode === RUMMY_GAME_TYPE.PRIVATE ? (s.game_type = HowToPlayDefined.gameId_PrivateRummy, PushCenter.shared().pushEvent(GameConfig.Update_Menu_Switch_Status, { tid_key: this.tid_key, bEnable: false })) : e.mode === RUMMY_GAME_TYPE.PRI_POOL ? (s.game_type = HowToPlayDefined.gameId_PoolPrivateRummy, PushCenter.shared().pushEvent(GameConfig.Update_Menu_Switch_Status, { tid_key: this.tid_key, bEnable: false })) : e.mode === RUMMY_GAME_TYPE.PRI_DEAL ? (s.game_type = HowToPlayDefined.gameId_DealsPrivateRummy, PushCenter.shared().pushEvent(GameConfig.Update_Menu_Switch_Status, { tid_key: this.tid_key, bEnable: false })) : e.mode === RUMMY_GAME_TYPE.MATCH && (s.gameRummyType = RUMMY_GAME_TYPE.MATCH, s.game_type = HowToPlayDefined.gameId_RummyGame, PushCenter.shared().pushEvent(GameConfig.Update_Menu_Switch_Status, { tid_key: this.tid_key, bEnable: false }), s.gameMatchMode == RUMMY_MATCH_MODE.FULLMATCH && (s.matchPrizesInfo = e.reward_infos, 0 == e.isStarting ? (this.match_wait_info = e, this.rummyShowTopUiLogic.showMatchWaitView(e.race_name, e.reward_infos, e.signup_cnt, e.total_num)) : this.hideMatchWaitView()));
        let _ = false;
        e.mode === RUMMY_GAME_TYPE.MATCH && (sys.isObjectValid(e.reward_infos) && Array.isArray(e.reward_infos) && e.reward_infos.length > 0 && (this.match_reward_info = e.reward_infos, _ = true, this.actionTs.refreshRaceRewardList(this.match_reward_info)), this.checkIsPointsMatch() ? this.rummyLogicProcessing.send_request_score_rank_info() : (this.matchRankCurPage = 1, this.rummyLogicProcessing.handler_server_rank_info_request(this.matchRankCurPage)));
        this.actionTs.setMatch_reward_btnVisible(_);
        s.roomNum = String(e.tid);
        s.game_server_state = a;
        s.isGameOver = 2 != a;
        s.isClearCards = 2 != a;
        this.is_first_round = false;
        s.op_cd = 20;
        s.host_seat = -1;
        s.op_cd = null != e.op_cd ? e.op_cd : 20;
        let c = sys.isObjectValid(e.total_cd) ? e.total_cd : -1, y = sys.isObjectValid(e.is_decare) ? e.is_decare : 0;
        if (s.gameRummyType != RUMMY_GAME_TYPE.PRIVATE && s.gameRummyType != RUMMY_GAME_TYPE.PRI_POOL && s.gameRummyType != RUMMY_GAME_TYPE.PRI_DEAL && s.gameRummyType != RUMMY_GAME_TYPE.MATCH || (this.is_first_round = 0 === e.inngs, s.host_seat = null != e.creator_seatid ? e.creator_seatid : -1, s.op_cd = null != e.op_cd ? e.op_cd : 20), this.recon_total_cd = c, s.pnum = h, s.round_per_game = e.round, s.ting_round = e.round, User.shared().magicexpressioncost = e.mcost, s.magicexpressioncost = e.mcost, s.laizicard = e.lz_card, s.laiziFlopCard = e.flop_lz_card, s.is_waiting = e.is_waiting, s.wait_virtual_num = e.wait_virtual_num, s.is_replay = e.is_replay, sys.isObjectValid(e.hasLocalTingPai) && (s.hasLocalTingPai = ToolUtils.isSafeNumber(e.hasLocalTingPai)), sys.isObjectValid(e.vid) && (s.vid = e.vid), e.players && "object" == typeof e.players) {
            for (let t = 0; t < e.players.length; t++) {
                const i = e.players[t];
                if (i.uid == User.shared().data.uid) {
                    s.clientSeatId = i.seatid;
                    break;
                }
            }
        }
        if (s.gameRummyType == RUMMY_GAME_TYPE.MATCH) {
            if (s.race_state = null != e.race_state ? e.race_state : 0, s.gameMatchType == RUMMY_MATCH_TYPE.BASEMONEYUP) {
                if (s.racing_time = e.next_up_time, s.levels_info = e.levels, s.cur_level = e.level, sys.isObjectValid(e.next_up_time)) {
                    let t = RummyDataManager.formatRaceTime(e.next_up_time);
                    this.rummyShowTopUiLogic.setRaceTime(t);
                }
            }
            else if (sys.isObjectValid(e.racing_time)) {
                s.racing_time = e.racing_time;
                let t = RummyDataManager.formatRaceTime(e.racing_time);
                this.rummyShowTopUiLogic.setRaceTime(t);
            }
        }
        let u = false, p = false;
        s.gameRummyType != RUMMY_GAME_TYPE.PRIVATE && s.gameRummyType != RUMMY_GAME_TYPE.PRI_POOL && s.gameRummyType != RUMMY_GAME_TYPE.PRI_DEAL && s.gameRummyType != RUMMY_GAME_TYPE.MATCH && (p = true);
        this.checkIsPointsMatch() && (p = true);
        p && (u = 1 == s.is_waiting || 1 == a, 1 == s.is_waiting ? this._nRobotPlayerCount = 0 : this._nRobotPlayerCount = s.wait_virtual_num);
        PushCenter.shared().pushEvent(GameConfig.Update_Private_Exit_Status, { tid_key: this.tid_key, bEnable: true });
        u && PushCenter.shared().pushEvent(GameConfig.Update_Menu_Switch_Status, { tid_key: this.tid_key, bEnable: false });
        let g = [];
        this.playerTs.changePlayerZhuangState(false, 0);
        for (let t = 1; t <= 5; t++) {
            if (u) {
                if (1 == s.is_waiting) {
                    this.playerTs.hidePlayer(t);
                }
                else {
                    if (0 == g.length && (g = [false, false, false, false, false, false], e.players && "object" == typeof e.players)) {
                        for (let t = e.players.length - 1; t >= 0; t--) {
                            g[this.getPosBySeatid(e.players[t].seatid)] = true;
                        }
                    }
                    g[t] || this.playerTs.hidePlayer(t);
                }
            }
            else {
                this.playerTs.hidePlayer(t);
            }
            this.playerTs.hideEnterAnim(t);
            this.playerTs.changePlayerZhuangState(false, t);
        }
        if (this.playerTs.showEmptySeat(), this.playerTs.refreshPlayerPostion(), 2 == h) {
            this.tipTs.seatPosVec[1] = this.tipTs.seatPosVec[3];
            this.cardsTs.seatPosVec[1] = this.cardsTs.seatPosVec[3];
            this.tipTs.refreshLoseMoneyPostion();
        }
        else if (4 == h) {
            for (let e = 1; e < h; e++) {
                this.tipTs.seatPosVec[e] = RummyCardConstant.fourPlayerPosVec[e];
                this.cardsTs.seatPosVec[e] = RummyCardConstant.fourPlayerPosVec[e];
            }
            this.actionTs.refreshHeadClickPosition();
            this.tingpaiNode.setPosition(new Vec3(586, 3));
            this.tingpaiNode.getChildByName("bubble").setPosition(new Vec3(-35, -32));
            this.winTips.getChildByName("icon").setPosition(new Vec3(-586, 3));
        }
        if (ToolUtils.isObjValid(this.game_chatNode) && (this.game_chatTs.seatPosVec = this.tipTs.seatPosVec), s.game_cd = r, s.timeout_cd = e.cd - r, this.game_cd = r, this.actionTs.changeRecodeBtnStatus(1 == e.ishavegamelog), this.actionTs.updateDropNum(this.drop_money), this.autoDropTs.setAutoDropBtnMoney(this.drop_money), 4 != a || s.gameRummyType != RUMMY_GAME_TYPE.POINTS && s.gameRummyType != RUMMY_GAME_TYPE.MULTIPLE ? sys.isObjectValid(e.src_score) && Number(e.src_score) > 0 ? sys.isObjectValid(e.finish_multiple) ? this.playerTs.showLoseScore(0, e.all_score, true, e.src_score, e.finish_multiple) : this.playerTs.showLoseScore(0, e.all_score, true, e.src_score) : this.playerTs.showLoseScore(0, e.all_score, true) : this.playerTs.showLoseScore(0, e.all_score, false), this.changeQiPaiTableStatus(this.isOpenQipai), s.gameRummyType != RUMMY_GAME_TYPE.POOL && s.gameRummyType != RUMMY_GAME_TYPE.PRI_POOL && s.gameRummyType != RUMMY_GAME_TYPE.DEALS && s.gameRummyType != RUMMY_GAME_TYPE.PRI_DEAL || 1 == e.gaming && (s.is_game_all_end = 0, this._bIsShowReady = false), this.actionTs.showDoubleGameChooseTip(false), s.cardInfoModelVec = [], e.players && "object" == typeof e.players) {
            let t = e.players.length;
            s.roomPlayerCounter = t;
            s.players = e.players;
            for (let i = 0; i < t; i++) {
                let t = e.players[i].seatid, r = s.playerModels[t];
                r.isShow = true;
                r.ready = 0;
                r.uid = e.players[i].uid;
                r.seatid = e.players[i].seatid;
                r.role = e.players[i].role;
                null != e.players[i].ready ? r.ready = e.players[i].ready : null != e.players[i].zhunbei && (r.ready = e.players[i].zhunbei);
                r.betting = e.players[i].betting;
                r.see = e.players[i].see;
                r.bet = e.players[i].bet;
                r.status = e.players[i].status;
                r.fold_leave = e.players[i].fold_leave;
                r.name = e.players[i].name;
                r.sex = e.players[i].sex;
                r.avatar = e.players[i].avatar;
                r.avatar_url = e.players[i].avatar_url;
                r.money = e.players[i].money;
                r.score = e.players[i].score;
                r.total_board = e.players[i].total_board;
                r.total_win = e.players[i].total_win;
                r.vlevel = e.players[i].vlevel;
                r.dsc = e.players[i].ps;
                r.vip = e.players[i].vip;
                r.club_level = e.players[i].club_level;
                r.club_effect_v2 = e.players[i].club_effect_v2;
                sys.isObjectValid(e.players[i].avatar_frame_id) ? r.avatar_frame_id = e.players[i].avatar_frame_id : r.avatar_frame_id = 0;
                sys.isObjectValid(e.players[i].cash) && (r.cash = e.players[i].cash);
                sys.isObjectValid(e.players[i].play_effect_id) ? r.play_effect_id = e.players[i].play_effect_id : r.play_effect_id = 0;
                sys.isObjectValid(e.players[i].src_score) && (r.src_score = e.players[i].src_score);
                sys.isObjectValid(e.players[i].finish_multiple) && (r.finish_multiple = e.players[i].finish_multiple);
                null != e.players[i].rank && (r.rank = e.players[i].rank);
                r.isRejoin = !!sys.isObjectValid(e.players[i].isRejoin) && 1 == e.players[i].isRejoin;
                r.decision = ToolUtils.isSafeNumber(e.players[i].decision);
                e.players[i].uid == User.shared().data.uid && (s.clientSeatId = t, 0 == s.crashModel && (User.shared().data.money = r.money, User.shared().real_money = r.money, PushCenter.shared().pushEvent(GameConfig.Update_Money, r.money)), n = r.betting, 1 != r.status && 5 != r.status || (s.dropType = 1));
                sys.isObjectValid(e.players[i].double_type) && (r.double_type = e.players[i].double_type);
                let h = this.getPosBySeatid(t);
                u && this.playerTs.showPipeiAnim1(h);
                Utils.shared().preDownLoadHeadImg(r.avatar, r.avatar_url);
                let o = {};
                if (o.name = r.name, o.uid = r.uid, o.headname = r.avatar, o.vlevel = 0, o.money = r.money, o.sex = r.sex, o.avatar_url = r.avatar_url, o.vip = r.vip, o.club_level = r.club_level, o.club_effect_v2 = r.club_effect_v2, o.isinit = true, o.isLineUp = u, o.isHeadCallback = true, o.avatar_frame_id = r.avatar_frame_id, o.play_effect_id = r.play_effect_id, o.cash = r.cash, this.playerTs.showPlayer(h, o), this.playerTs.changeAwayStateStatus(h, true, e.players[i].status), this.playerTs.setPoolRejoinState(h, r.isRejoin), null != e.players[i].score && (this.playerTs.setPoolScore(h, e.players[i].score), this.updateSeatScore(t, e.players[i].score)), s.playerModels[t] = r, s.gameRummyType != RUMMY_GAME_TYPE.POOL && s.gameRummyType != RUMMY_GAME_TYPE.PRI_POOL && s.gameRummyType != RUMMY_GAME_TYPE.DEALS && s.gameRummyType != RUMMY_GAME_TYPE.PRI_DEAL && s.gameRummyType != RUMMY_GAME_TYPE.MATCH || 0 === a && s.gameRummyType != RUMMY_GAME_TYPE.MATCH || this.playerTs.setPoolScoreState(h, true), 1 == ToolUtils.isSafeNumber(e.is_double) && sys.isObjectValid(e.players[i].double_type)) {
                    let t = e.players[i].double_type;
                    0 == h && -1 == t && 5 == a && e.double_choose_open !== 0 && this.actionTs.showDoubleGameChooseTip(true, e);
                    5 == a && t < 0 && e.cd > 0 && this.playerTs.startPlayerTimer2(h, e.cd);
                    let s = 5 == a ? 0 : 1;
                    this.playerTs.showDoubleState(h, t, true, s);
                }
                if (2 == a && (this.restoreSeatRoundScore(e, e.players[i], h), this.playerTs.hidePipeiAnim(h)), s.gameRummyType == RUMMY_GAME_TYPE.PRIVATE || s.gameRummyType == RUMMY_GAME_TYPE.PRI_POOL || s.gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL) {
                    let r = this._bIsShowReady;
                    !r || s.gameRummyType != RUMMY_GAME_TYPE.PRI_POOL && s.gameRummyType != RUMMY_GAME_TYPE.PRI_DEAL || (r = 1 !== e.isWatching, r && (r = 9 != e.players[i].status));
                    r && (1 == y && 2 == a || 2 != a) && this.isMyPlayer(t) && this.actionTs.hideReadyBtn();
                }
                if (2 != e.players[i].status && 1 != e.players[i].status && 5 != e.players[i].status && 3 != e.players[i].status && 9 != e.players[i].status || null != e.players[i].all_score && e.players[i].all_score > 0 && (sys.isObjectValid(e.players[i].src_score) ? sys.isObjectValid(e.players[i].finish_multiple) ? this.playerTs.showLoseScore(h, e.players[i].all_score, true, e.players[i].src_score, e.players[i].finish_multiple) : this.playerTs.showLoseScore(h, e.players[i].all_score, true, e.players[i].src_score) : this.playerTs.showLoseScore(h, e.players[i].all_score, true)), this.isMyPlayer(t)) {
                    if (2 == e.players[i].status || 1 == e.players[i].status || 5 == e.players[i].status || 3 == e.players[i].status || 9 == e.players[i].status) {
                        if (e.cardinfos && "object" == typeof e.cardinfos && Array.isArray(e.cardinfos)) {
                            this.refreshMyCardInfos(e) > 0 && (this.cardsTs.showDropCardsZheZhao(true), s.gameRummyType == RUMMY_GAME_TYPE.MATCH && s.gameMatchMode != RUMMY_MATCH_MODE.PointsMatch && this.tipTs.showMatchWaitTip(true));
                        }
                        s.isCanTouchCard = false;
                        s.isInGameing = 0;
                    }
                    s.auto_out = e.players[i].auto_play;
                    this.resetPlayerHeadAnim(t);
                }
                if (1 == r.betting || 0 == r.betting && r.status >= 0) {
                    let t = [];
                    t.seatid = e.players[i].seatid;
                    t.name = e.players[i].name;
                    t.cards = e.players[i].cards || [];
                    s.playerGiveCards.push(t);
                }
            }
        }
        if (1 == s.is_waiting) {
            let e = 0, i = false;
            s.gameRummyType != RUMMY_GAME_TYPE.PRIVATE && s.gameRummyType != RUMMY_GAME_TYPE.PRI_POOL && s.gameRummyType != RUMMY_GAME_TYPE.PRI_DEAL && s.gameRummyType != RUMMY_GAME_TYPE.MATCH ? i = true : this.checkIsPointsMatch() && (i = true, e = s.raceid);
            i && (this._nRobotPlayerCount = 0, this.rummyLogicProcessing.send_request_line_up(e), RummyDataManager.shared().reportDeskBtnClick(this.tid_key, ReportConfig.cash_evt.request_line_up, { rev_tab_time: t }));
        }
        s.close_cardnum = sys.isObjectValid(e.close_cardnum) ? e.close_cardnum : 0;
        sys.isObjectValid(e.round_per_game) && (s.round_per_game = e.round_per_game, s.ting_round = e.round_per_game);
        s.disCardTipsValue = sys.isObjectValid(e.helper_discard_card) ? e.helper_discard_card : 0;
        s.winner_effects_round = sys.isObjectValid(e.winner_effects_round) ? e.winner_effects_round : 0;
        let b = 0;
        e.cardinfos && "object" == typeof e.cardinfos && Array.isArray(e.cardinfos) ? (this.cardInfoMsg = e, b = this.refreshMyCardInfos(e), this.cardsTs.beginFaPaiWithoutAnim(s.cardInfoModelVec, s.cardInfoModelVec.length), this.actionTs.setMopaiBtnInteractable(true), s.gameRummyType != RUMMY_GAME_TYPE.PRIVATE && s.gameRummyType != RUMMY_GAME_TYPE.PRI_POOL && s.gameRummyType != RUMMY_GAME_TYPE.PRI_DEAL || 2 != a || this.actionTs.hidePrivateBtn()) : s.gameRummyType != RUMMY_GAME_TYPE.PRIVATE && s.gameRummyType != RUMMY_GAME_TYPE.PRI_POOL && s.gameRummyType != RUMMY_GAME_TYPE.PRI_DEAL || (this.actionTs.changeOperateBgState(false), s.roomPlayerCounter < h && (this.actionTs.showInviteBtn(), this.actionTs.showCopyBtn()));
        this.qipaiCardValues = [];
        let w = [];
        if (e.opencards && Array.isArray(e.opencards)) {
            for (let t = 0, s = e.opencards.length; t < s; t++) {
                const s = e.opencards[t];
                w.push(s);
                this.qipaiCardValues.push(s);
            }
            1 == e.is_pre_decare && (w.pop(), this.qipaiCardValues.pop());
        }
        let P = parseInt("" + e.opseatid);
        if (s.curOptSeatid = P, 2 == a || 5 == a) {
            s.gameRummyType == RUMMY_GAME_TYPE.MATCH && (this.removeGameOverView(), this.gameOverOpenLogic._gameEndMsg = null);
            this.tipTs.showGameTipsText(0, 0, "");
            this.playerTs.updateCloseNum(s.close_cardnum);
            this.playerTs.updateOpenNum(w.length);
            this.playerTs.updateRoundNum(s.round_per_game);
            this.playerTs.updateMultipleTimes(s.round_per_game);
            let t = false;
            if (b > 0 && (t = true), s.close_cardnum > 0 && (s.gameRummyType !== RUMMY_GAME_TYPE.PRIVATE && s.gameRummyType !== RUMMY_GAME_TYPE.MATCH && s.gameRummyType !== RUMMY_GAME_TYPE.PRI_POOL && s.gameRummyType !== RUMMY_GAME_TYPE.PRI_DEAL || 0 === n && (t = true)), 1 === ToolUtils.isSafeNumber(e.isWatching) && (t = true), t) {
                this.playerTs.changeOpenNumVisibile(true);
                this.playerTs.changePaiduNumVisible(true);
                this.playerTs.changeRoundNumVisible(true);
                this.actionTs.changeOpenCardStatus(true, this);
                this.actionTs.setMopaiBtnInteractable(true);
                this.actionTs.changeCenterFinishBtnStatus(true);
                this.playerTs.setPaiDuiBgShow(true);
                s.gameRummyType == RUMMY_GAME_TYPE.MULTIPLE && this.actionTs.changeCenterFinishBtnStatus(true);
                this.cardsTs.showPaiduiCards();
                this.cardsTs.showLaiziCard(false);
                w.length > 0 && this.cardsTs.showQipaiWithAnim(w);
                s.hasFaPai = true;
                let e = s.clientSeatId;
                0 === s.playerModels[e].status && this.actionTs.changeSwitchJokerStatus(true, this);
            }
            if (s.gameRummyType == RUMMY_GAME_TYPE.PRIVATE || s.gameRummyType == RUMMY_GAME_TYPE.PRI_POOL || s.gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL) {
                if (this.actionTs.hidePrivateBtn(), s.gameRummyType == RUMMY_GAME_TYPE.PRI_POOL || s.gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL) {
                    let t = s.clientSeatId, i = s.playerModels[t];
                    1 !== e.isWatching && 9 !== i.status || this.actionTs.setMopaiBtnInteractable(false);
                }
            }
            else {
                this.actionTs.hideReadyBtn();
            }
            if ((ToolUtils.isSafeNumber(e.finish_card) > 0 || 0 === n) && this.actionTs.setMopaiBtnInteractable(false), null != e.zhuang_seatid && null != e.zhuang_seatid) {
                let t = parseInt("" + e.zhuang_seatid);
                s.zhuang_seatid = t;
                this.playerTs.changePlayerZhuangState(true, this.getPosBySeatid(t));
            }
            if (TweenTool.delayAct(this.action_node, (() => {
                this.cardsTs.setCardValueTipShow(true);
                this.refreshTingPaiSwitch();
            }), 0.1, true), P == s.clientSeatId) {
                if (1 == e.is_pre_decare) {
                    ;
                }
                else {
                    if (s.isClientToPlay = true, this.pickCardInfo = null, this.actionTs.changeOperateBgState(true), 13 == b) {
                        let t = e.can_mp;
                        this.isCanmqp = false;
                        0 == s.gameRummyMode && (this.isCanmqp = 0 == t);
                        let i = false, a = sys.localStorage.getItem("open_deck_pick_def");
                        null == a && (a = User.shared().help_setting.open_deck_pick_def);
                        1 == User.shared().help_setting.open_deck_pick && sys.isObjectValid(a) && 1 == Number(a) && (i = true);
                        sys.isObjectValid(e.helper_pick_card) && i ? (this.cardsTs.showMoPaiTisAnim(true, this.isCanmqp, true), sys.isObjectValid(e.helper_pick_card_array) && this.cardsTs.showHighTipsCards(e.helper_pick_card_array, e.helper_pick_group_index)) : this.cardsTs.showMoPaiTisAnim(true, this.isCanmqp);
                        1 != y && this.actionTs.changeDropBtnStatus(0 == s.gameRummyMode);
                    }
                    else {
                        14 == b && (this.cardsTs.showMoPaiTisAnim(false, true), this.cardsTs.showFinishTisiAnim(true), this.cardsTs.showPickCardTips(false));
                    }
                    this.actionTs.changeDirectionBtnStatus(false);
                    this.actionTs.changeAutoGroupBtnStatus(true);
                }
                -1 != P && this.autoDropTs.isshowAutoDropBtn(false, this.tid_key);
            }
            else {
                s.isClientToPlay = false;
                this.actionTs.changeDropBtnStatus(false);
                this.actionTs.changeGroupBtnStatus(false);
                this.actionTs.changeFinishBtnStatus(false);
                let t = s.clientSeatId, i = s.playerModels[t];
                if (0 == i.status && 1 == i.betting) {
                    if (this.actionTs.changeAutoGroupBtnStatus(true), s.gameRummyType == RUMMY_GAME_TYPE.DEALS || s.gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL) {
                        if (1 == s.dealsrummyIsCanFold && sys.isObjectValid(e.show_autodrop)) {
                            let t = 1 == e.show_autodrop;
                            this.autoDropTs.isshowAutoDropBtn(t, this.tid_key);
                        }
                    }
                    else if (0 == s.gameRummyMode && sys.isObjectValid(e.show_autodrop)) {
                        let t = 1 == e.show_autodrop;
                        this.autoDropTs.isshowAutoDropBtn(t, this.tid_key);
                    }
                }
            }
            if (1 == s.cardInfoModelVec.length && (this.actionTs.changeSortBtnStatus(this.cardsTs.showAutoSortBtn()), this.autoDropTs.setAutoDropBtn(1)), 0 == e.timestate) {
                -1 != P && (this.playerTs.startPlayerTimer(this.getPosBySeatid(P), r), this.playerTs.showEasyGameLight(this.getPosBySeatid(P)));
            }
            else {
                let e = s.timeout_cd;
                c > 0 ? this.playerTs.startPlayerTimer(this.getPosBySeatid(P), e, true, c - r) : this.playerTs.startPlayerTimer(this.getPosBySeatid(P), e, true);
                this.playerTs.showEasyGameLight(this.getPosBySeatid(P));
            }
            1 == e.is_pre_decare ? (P == s.clientSeatId ? (this.playEffectByName("rummySelfTurn"), this.tipTs.show_hupai_tip(true), this.cardsTs.readyHuCardShowFinish(e.pre_decare_card, false)) : this.cardsTs.readyHuCardShowFinish(e.pre_decare_card, true), this.playerTs.setMultipleFireAnimShow(false, 0), this.playerTs.setMultipleFireAnimShow(false, 1)) : (s.multiple_fire_round > 0 && s.round_per_game >= s.multiple_fire_round ? this.playerTs.setMultipleFireAnimShow(true, 1) : this.playerTs.setMultipleFireAnimShow(false, 1), this.playerTs.setMultipleFireAnimShow(false, 0));
        }
        else {
            this.playerTs.setMultipleFireAnimShow(false, 0);
            this.playerTs.setMultipleFireAnimShow(false, 1);
            this.actionTs.changeOperateBgState(false);
            s.gameRummyType != RUMMY_GAME_TYPE.PRIVATE && s.gameRummyType != RUMMY_GAME_TYPE.PRI_POOL && s.gameRummyType != RUMMY_GAME_TYPE.PRI_DEAL && s.gameRummyType != RUMMY_GAME_TYPE.MATCH || (this.actionTs.changeSwitchBtnStatus(false), PushCenter.shared().pushEvent(GameConfig.Update_Menu_Switch_Status, { tid_key: this.tid_key, bEnable: false }));
            this.hasDeclare = false;
            this.checkHasMatchJoinTips() || this.actionTs.changeMatchRankBtnVisibile(false);
        }
        if (s.auto_drop_type = e.auto_drop, this.autoDropTs.isAutoDropSelect(e.auto_drop), 1 != a && 0 != a && 4 != a || this.playerTs.showEmptySeat(), 1 == a) {
            s.game_state = 1;
            s.game_cd = o;
            this.process_server_pre_start();
        }
        else if (0 == a || 4 == a) {
            s.game_state = 5;
            i18nMgr.shared().getValueByKey("rummy_main.gameTipstext13");
            if (s.gameRummyType == RUMMY_GAME_TYPE.PRIVATE || s.gameRummyType == RUMMY_GAME_TYPE.PRI_POOL || s.gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL) {
                this.actionTs.hideStartBtn();
                s.roomPlayerCounter < h && (this.actionTs.showInviteBtn(), this.actionTs.showCopyBtn());
                let t = s.clientSeatId, i = s.playerModels[t];
                if (i && 1 != i.ready) {
                    let t = this._bIsShowReady;
                    !t || s.gameRummyType != RUMMY_GAME_TYPE.PRI_POOL && s.gameRummyType != RUMMY_GAME_TYPE.PRI_DEAL || (t = 1 !== e.isWatching, t && (t = 9 != i.status));
                    t && (this.is_first_round ? s.host_seat != s.clientSeatId ? this.actionTs.showReadyBtn() : this.actionTs.hideReadyBtn() : this.actionTs.showReadyBtn());
                }
            }
        }
        if (s.gameRummyType != RUMMY_GAME_TYPE.POOL && s.gameRummyType != RUMMY_GAME_TYPE.PRI_POOL || (4 == a && (s.game_state = 4, s.end_game_countdown = e.cd, ToolUtils.isObjValid(this.gameEndView) ? this.gameEndView.getComponent(RummyGameOverAlert).setPoolRummyCountDown(e.cd, true) : this.showGameStartCountDown()), sys.isObjectValid(e.pool_money) && (s.pool_money = e.pool_money), 1 == e.isEnding && (this.rummyShowTopUiLogic.showGameManualSplit(e.cd, e.ending_info), s.isInGameing = 0), 1 == e.WaitState && (s.game_end_state = 0, ToolUtils.isObjValid(this.gameEndView) ? (this.gameEndView.getComponent(RummyGameOverAlert).setPoolRummyCountDown(e.cd, true), this.gameEndView.getComponent(RummyGameOverAlert).updateBtnShow()) : (s.end_game_countdown = e.cd, this.showGameStartCountDown())), 1 == e.show_split_prize && (s.game_end_state = 2, ToolUtils.isObjValid(this.gameEndView) ? (this.gameEndView.getComponent(RummyGameOverAlert).setPoolRummyCountDown(e.cd, true), this.gameEndView.getComponent(RummyGameOverAlert).updateBtnShow()) : (s.end_game_countdown = e.cd, this.showGameStartCountDown())), 1 == e.wait_rejoin && (s.game_end_state = 1, ToolUtils.isObjValid(this.gameEndView) ? (this.gameEndView.getComponent(RummyGameOverAlert).setPoolRummyCountDown(e.cd, true), this.gameEndView.getComponent(RummyGameOverAlert).updateBtnShow()) : (s.end_game_countdown = e.cd, this.showGameStartCountDown())), 1 == e.gaming && this.actionTs.changeSwitchBtnStatus(false)), s.gameRummyType != RUMMY_GAME_TYPE.DEALS && s.gameRummyType != RUMMY_GAME_TYPE.PRI_DEAL || (sys.isObjectValid(e.start_score) && (s.dealsRummyStartScore = e.start_score), sys.isObjectValid(e.total_round) && (s.dealsRummyTotalRound = e.total_round), sys.isObjectValid(e.pool_money) && (s.pool_money = e.pool_money), 1 == e.WaitState && (s.game_end_state = 0, ToolUtils.isObjValid(this.gameEndView) ? this.gameEndView.getComponent(RummyGameOverAlert).setPoolRummyCountDown(e.cd, true) : (s.end_game_countdown = e.cd, this.showGameStartCountDown())), 1 == e.gaming && this.actionTs.changeSwitchBtnStatus(false)), s.gameRummyType == RUMMY_GAME_TYPE.PRIVATE || s.gameRummyType == RUMMY_GAME_TYPE.PRI_POOL || s.gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL) {
            let e = s.clientSeatId, t = s.playerModels[e];
            if (1 == s.isInGameing && (1 == t.betting || 0 == t.betting && 4 == t.status) ? PushCenter.shared().pushEvent(GameConfig.Update_Private_Exit_Status, { tid_key: this.tid_key, bEnable: false }) : PushCenter.shared().pushEvent(GameConfig.Update_Private_Exit_Status, { tid_key: this.tid_key, bEnable: true }), 1 == y && 2 == a) {
                let e = s.clientSeatId;
                1 == s.playerModels[e].ready && (this.tipTs.showMatchWaitTip(false), this._bGameOverClosed = true);
            }
        }
        if (s.gameRummyType == RUMMY_GAME_TYPE.MATCH) {
            let e = this.actionRoot.getChildByName("topNode").getChildByName("shop_btn");
            if (ToolUtils.isObjValid(e) && (e.active = false), 2 == s.race_state && (this.actionTs.changeSwitchBtnStatus(false), PushCenter.shared().pushEvent(GameConfig.Update_Menu_Switch_Status, { tid_key: this.tid_key, bEnable: false })), s.race_state < 4) {
                let e = this.pop_layer4.getChildByName("match_game_over");
                ToolUtils.isObjValid(e) && (e.destroy(), this.matchTotalSettleMsg = null);
            }
        }
        else {
            this.actionTs.changeSwitchBtnStatus(RummyDataManager.shared().isShowSwitchBtn(this.tid_key));
        }
        if (0 == e.interactive_enable) {
            if (this.actionTs.ishudongshow(false), 1 == a || 0 == a || 4 == a) {
                let e = false;
                if (s.gameRummyType != RUMMY_GAME_TYPE.PRIVATE && s.gameRummyType != RUMMY_GAME_TYPE.PRI_POOL && s.gameRummyType != RUMMY_GAME_TYPE.PRI_DEAL && s.gameRummyType != RUMMY_GAME_TYPE.MATCH && (e = true), this.checkIsPointsMatch() && (e = true), e) {
                    for (let e = 1; e < 6; e++) {
                        this.playerTs.checkHeadShow(e) && this.playerTs.showPipeiAnim1(e);
                    }
                }
            }
        }
        else {
            this.actionTs.ishudongshow(true);
        }
        if (this.actionTs.changeBuddyRankBtnVisibile(), this.helper_hu_card = ToolUtils.isSafeNumber(e.helper_hu_card), this.quick_sort = 0, this.finish_groups = null, this.can_declare = ToolUtils.isSafeNumber(e.can_declare), sys.isObjectValid(e.finish_groups) && (this.finish_groups = e.finish_groups, this.quick_sort = RummyDataManager.shared().checkSameCards(e.cardinfos, e.finish_groups)), RummyDataManager.shared().getCanShowQuickFinish() && 1 == ToolUtils.isSafeNumber(e.can_declare) && 0 != this.helper_hu_card) {
            let t = game.frameTime / 1000;
            this.tingPaiMsg = null;
            s.isCanTouchCard = false;
            TweenTool.delayAct(this.time_node, (() => {
                sys.isObjectValid(e.helper_hu_card) && (1 == s.is_bump && sys.isObjectValid(e.bump_win_lz) && sys.isObjectValid(e.bump_last_lz) && e.bump_last_lz > 0 && ToolUtils.getCardInfo(e.bump_win_lz).point != ToolUtils.getCardInfo(e.bump_last_lz).point ? this.tipTs.showQuickFinishTips(true, e.bump_win_lz, e.bump_last_lz) : this.tipTs.showQuickFinishTips(true), this.playerTs.hideBonustTime(), this.cardsTs.beginFaPaiWithoutAnim(RummyDataManager.shared().rummyInfos.get(this.tid_key).cardInfoModelVec, RummyDataManager.shared().rummyInfos.get(this.tid_key).cardInfoModelVec.length), this.cardsTs.showHelperQuickFinishCard(e.helper_hu_card, true, this.tingPaiMsg), this.tingPaiMsg = null, this.cardsTs.hideTingPaiTips());
            }), t, true);
        }
        else {
            this.tipTs.showQuickFinishTips(false);
        }
        1 == s.able_race_push && this.rummyLogicProcessing.send_request_get_push_match_event(0);
        this.checkTreasureHunt ? (this.checkTreasureHunt = false, this.rummyLogicProcessing.checkTreasureHuntActivity()) : this.has_treasureHuntAct && this.actionTs.updateTreasureHuntBtn(2, null);
        sys.isObjectValid(e.tf_venue) && (s.tf_venue = e.tf_venue);
        s.force_up_venue = null;
        sys.isObjectValid(e.force_up_venue_tips_drop) && (s.force_up_venue = e.force_up_venue_tips_drop);
        this.actionTs.changMatchLevelBtnVisibile();
        this.rummyLogicProcessing.restoreRecoveryPhase(e);
        sys.isObjectValid(RummyDataManager.shared().rummyInfos.get(this.tid_key).flopTempTaskInfo) && this.rummyLogicProcessing.updateFlopCashTask(RummyDataManager.shared().rummyInfos.get(this.tid_key).flopTempTaskInfo);
    }
    updateAutoReadyTime() {
        if (this.autoReadyTime -= 1, this.autoReadyTime < 0) {
            return;
        }
        if (!RummyDataManager.shared().rummyInfos.has(this.tid_key)) {
            return;
        }
        let e = this.autoReadyTime > 0, t = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_main.gameTipsText1"), this.autoReadyTime);
        if (ToolUtils.isObjValid(this.gameEndView)) {
            let s = RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType;
            s == RUMMY_GAME_TYPE.PRIVATE || s == RUMMY_GAME_TYPE.PRI_POOL || s == RUMMY_GAME_TYPE.PRI_DEAL ? e ? this.gameEndView.getComponent(RummyGameOverAlert).showCountDown(t) : (this.gameEndView.destroy(), this.gameEndView = null) : s == RUMMY_GAME_TYPE.MATCH ? this.gameEndView.getComponent(RummyPointsMatchOverAlert).showCountDown(t) : this.gameEndView.getComponent(RummyGameOverAlert).showCountDown(t);
        }
    }
    updateAddRobotPlyer() {
        if (!RummyDataManager.shared().rummyInfos.has(this.tid_key)) {
            return;
        }
        let e = RummyDataManager.shared().rummyInfos.get(this.tid_key), t = false;
        if (e.gameRummyType != RUMMY_GAME_TYPE.PRIVATE && e.gameRummyType != RUMMY_GAME_TYPE.PRI_POOL && e.gameRummyType != RUMMY_GAME_TYPE.PRI_DEAL && e.gameRummyType != RUMMY_GAME_TYPE.MATCH && (t = true), this.checkIsPointsMatch() && (t = true), t) {
            if (1 == e.is_waiting && this._nRobotPlayerCount < e.wait_virtual_num && this._nRobotPlayerCount < e.pnum - 1) {
                let e = { name: "", uid: 0, headname: "head_17.png", vlevel: 0, sex: 1, avatar_url: "", isinit: true, isLineUp: true, isHeadCallback: true, vip: 0, club_level: 0, club_effect_v2: 0 };
                this.playerTs.showPlayer(this._nRobotPlayerCount + 1, e);
                this.playerTs.showPipeiAnim1(this._nRobotPlayerCount + 1);
                this._nRobotPlayerCount++;
            }
            else {
                this._nRobotPlayerCount = e.wait_virtual_num;
            }
        }
    }
    updateRacingTime() {
        if (RummyDataManager.shared().rummyInfos.has(this.tid_key)) {
            let e = RummyDataManager.shared().rummyInfos.get(this.tid_key);
            if (3 == e.race_state && e.gameRummyType == RUMMY_GAME_TYPE.MATCH) {
                let t = e.racing_time;
                if (null != t && t >= 0) {
                    let s = RummyDataManager.formatRaceTime(t);
                    this.rummyShowTopUiLogic.setRaceTime(s);
                    e.racing_time -= 1;
                }
            }
            let t = e.race_tipsTime;
            t && t > 0 ? (this.tipTs.getMatchJoinTipsActive() || this.tipTs.changeMatchJoinTipsActive(true), e.race_tipsTime -= 1) : this.tipTs.getMatchJoinTipsActive() && this.tipTs.changeMatchJoinTipsActive(false);
        }
    }
    updateSeatMoney(e, t) {
        let s = RummyDataManager.shared().rummyInfos.get(this.tid_key);
        for (let i = s.playerModels.length - 1; i >= 0; i--) {
            s.playerModels[i].seatid == e && (s.playerModels[i].money = t);
        }
    }
    updateSeatScore(e, t) {
        let s = RummyDataManager.shared().rummyInfos.get(this.tid_key);
        for (let i = s.playerModels.length - 1; i >= 0; i--) {
            s.playerModels[i].seatid == e && (s.playerModels[i].score = t);
        }
    }
    handler_server_talk_info(e) {
        if (this.tid_key === (e.tid_key || "")) {
            try {
                let t = this.getPosBySeatid(e.seatid);
                0 != t && ToolUtils.isObjValid(this.game_chatNode) && this.game_chatTs.startTalk2(t, e.text, e.chatid);
            }
            catch (e) {
                TLog.printError("trycatch handler_server_talk_info");
            }
        }
    }
    handler_server_expresion_info(e) {
        if (this.tid_key === (e.tid_key || "")) {
            try {
                let t = parseInt(e.expressionid), s = this.getPosBySeatid(e.seatid);
                this.playEffectByName("message");
                0 != s && ToolUtils.isObjValid(this.game_chatNode) && (t >= 50 ? this.game_chatTs.showMemberShipFace(s, t - 1) : this.game_chatTs.showFace(s, t - 1));
            }
            catch (e) {
                TLog.printError("trycatch handler_server_expresion_info,error:", e);
            }
        }
    }
    handler_server_heart(e) {
        Server.shared().send({ cmd: RummyCmd.SERVER_GAME_HEART });
        RummyDataManager.shared().rummyInfos.has(this.tid_key) && (RummyDataManager.shared().rummyInfos.get(this.tid_key).lastReceiHeartAllKillPacketTime = (new Date).getSeconds(), RummyDataManager.shared().rummyInfos.get(this.tid_key).isNoWifi = false, RummyDataManager.shared().rummyInfos.get(this.tid_key).isShowNoWifiAlert = true, RummyDataManager.shared().rummyInfos.get(this.tid_key).tcpConnTryTime = 0);
    }
    handler_server_bigface_uc(e) {
        if (this.tid_key !== (e.tid_key || "")) {
            return;
        }
        let t = e.sendseatid, s = e.reciveseatid, i = e.expressionid, a = e.sex, r = e.money;
        ToolUtils.isObjValid(this.game_chatNode) && 0 != this.getPosBySeatid(t) && this.game_chatTs.showBigFace(this.getPosBySeatid(t), this.getPosBySeatid(s), i - 1, a);
        let h = RummyDataManager.shared().rummyInfos.get(this.tid_key).playerModels[t];
        RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType != RUMMY_GAME_TYPE.MATCH && (t === RummyDataManager.shared().rummyInfos.get(this.tid_key).clientSeatId && (0 === RummyDataManager.shared().rummyInfos.get(this.tid_key).crashModel ? (User.shared().data.money = r, User.shared().real_money = r, PushCenter.shared().pushEvent(GameConfig.Update_Money, r)) : 1 === RummyDataManager.shared().rummyInfos.get(this.tid_key).crashModel && (User.shared().data.money_exe = r, PushCenter.shared().pushEvent(PushEvent.UpdatePractiseGold, r))), null != h && null != h && (h.money = e.money));
    }
    handler_server_login_return(e) {
        try {
            sys.isObjectValid(e.session_id) && (User.shared().session_id = e.session_id);
            let t = ToolUtils.isSafeString(e.old_tid_key || e.tid_key);
            // Legacy failures without a key belong only to the visible table.
            if (!t && Number(e.ret) !== 0 && User.shared().curTid_key === this.tid_key) t = this.tid_key;
            if (this.isNewTable = 0, this.tid_key != t) {
                if (this.tid_key != CommDefine.NewerGuideRoomTidkey) {
                    return;
                }
                if (1 == e.isNewTable) {
                    return void this.create_new_table();
                }
            }
            if (Number(e.ret) !== 0 && e.recovery_failed === 1) {
                Utils.shared().hideLoading();
                this.backToHall();
                Utils.shared().showToast(e.alertStr || "Unable to restore this table. Please enter again from the lobby.", 3, 0, ToolUtils.getIsNormalDirection());
                if (ToolUtils.deskInfos.size === 0) Server.shared().disconnectWebSocket();
                return;
            }
            if (this._guideJumpPricticeReq = false, 1 == parseInt("" + e.ret) && ToolUtils.isSafeString(e.alertStr).length > 0) {
                return this.backToHall(), Utils.shared().showToast(e.alertStr, 2, 0, ToolUtils.getIsNormalDirection()), void (ToolUtils.deskInfos.size <= 1 && Server.shared().disconnectWebSocket());
            }
            if (0 == parseInt("" + e.ret)) {
                if (1 == e.isNewTable) {
                    return void this.create_new_table();
                }
                sys.isObjectValid(e.session_id) && (User.shared().session_id = e.session_id);
                let s = ToolUtils.isSafeString(e.tid_key);
                if (e.snapshot_follows === 1 && s === this.tid_key) {
                    // Every loaded desk re-authenticates after the shared gate opens.
                    return;
                }
                if (s !== this.tid_key && (User.shared().curTid_key == t && (User.shared().curTid_key = s), PushCenter.shared().pushEvent(GameConfig.SwitchDesk, e)), Array.isArray(e.table_keys) && e.table_keys.length >= 1) {
                    for (let t = 0, s = e.table_keys.length; t < s; t++) {
                        let s = e.table_keys[t];
                        this.tid_key == s.tid_key ? this.refreshDestTid(s) : PushCenter.shared().pushEvent(GameConfig.RefreshRummyTableInfo, s.tid_key);
                    }
                }
                else {
                    this.send_request_tableinfo();
                }
                RummyDataManager.shared().rummyInfos.get(s) && ToolUtils.isSafeNumber(e.vid) > 0 && (RummyDataManager.shared().rummyInfos.get(s).vid = ToolUtils.isSafeNumber(e.vid));
                null !== e.mode && undefined !== e.mode && RummyDataManager.shared().rummyInfos.get(this.tid_key) && (RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType = e.mode);
            }
            else {
                e.alertStr && "" != e.alertStr && Utils.shared().showCommomDialog(e.alertStr, "", (() => {
                }), false, ToolUtils.getIsNormalDirection(), null, null, null, this.pop_layer4, null, this.tid_key);
            }
        }
        catch (e) {
            TLog.printError("trycatch handler_server_login_return:", e);
        }
    }
    create_new_table() {
        if (User.shared().isGameDisconnectServer) {
            return Server.shared().disconnectWebSocket(), this.isNewTable = 1, void this.login(true);
        }
        let e = RummyDataManager.shared().rummyInfos.get(this.tid_key);
        (!e || e.gameRummyType != RUMMY_GAME_TYPE.PRIVATE && e.gameRummyType != RUMMY_GAME_TYPE.PRI_POOL && e.gameRummyType != RUMMY_GAME_TYPE.PRI_DEAL) && PushCenter.shared().pushEvent(GameConfig.Create_New_Table, { vid: e.vid, fromBeginnerTutorial: e.fromBeginnerTutorial, tid_key: this.tid_key });
    }
    handler_server_login_succ_bc(e) {
        this.rummyLogicProcessing.handler_server_login_succ_bc(e);
    }
    getPosBySeatid(e) {
        let t = e - RummyDataManager.shared().rummyInfos.get(this.tid_key).clientSeatId;
        return t >= 0 ? t : t + RummyDataManager.shared().rummyInfos.get(this.tid_key).pnum;
    }
    getSeatidByPos(e) {
        let t = e + RummyDataManager.shared().rummyInfos.get(this.tid_key).clientSeatId;
        return t >= RummyDataManager.shared().rummyInfos.get(this.tid_key).pnum && (t -= RummyDataManager.shared().rummyInfos.get(this.tid_key).pnum), t;
    }
    exitCallBack(e) {
        if (1 == e) {
            let e = { cmd: RummyCmd.GM_LOGINOUT_REQUEST, tid_key: this.tid_key, uid: User.shared().data.uid };
            Server.shared().send(e);
            this._isClickLeaveTable && (this._isClickLeaveTable = false, RummyDataManager.shared().reportLeaveTable(this.tid_key));
        }
        else {
            this._isClickLeaveTable = false;
        }
    }
    backToHall() {
        let e = { tid_key: this.tid_key, switchCash: RummyDataManager.shared().rummyInfos.get(this.tid_key).switchCash };
        PushCenter.shared().pushEvent(GameConfig.DeleteDesk, e);
    }
    isMyPlayer(e) {
        return e == RummyDataManager.shared().rummyInfos.get(this.tid_key).clientSeatId;
    }
    getReayPlayerNums() {
        let e, t = 0;
        for (let s = 0; s < 6; s++) {
            e = RummyDataManager.shared().rummyInfos.get(this.tid_key).playerModels[s];
            e && 1 == e.ready && (t += 1);
        }
        return t;
    }
    changeRoomHost() {
        RummyDataManager.shared().rummyInfos.has(this.tid_key) && this.rummyLogicProcessing.changeRoomHost();
    }
    handler_server_logout_succed_bc(e) {
        this.rummyLogicProcessing.handler_server_logout_succed_bc(e);
    }
    handler_server_self_cards_return(e) {
        this.actionTs.getRaceRewardVisible() && this.actionTs.changeRaceRewardDiVisible(false);
        this.rummyLogicProcessing.handler_server_self_cards_return(e);
    }
    delayRefreshPaidui() {
        this.cardsTs.paiduiCardVec.length < 1 && this.cardsTs.showPaiduiCards();
        ToolUtils.isObjValid(this.cardsTs.lzCard) || this.cardsTs.showLaiziCard(false);
    }
    handler_server_gong_cards_return(e) {
        this.rummyLogicProcessing.handler_server_gong_cards_return(e);
    }
    handler_server_next_deal_bc_return(e) {
        this.rummyLogicProcessing.handler_server_next_deal_bc_return(e);
    }
    handler_server_start_game(e) {
        if (this.tid_key !== (e.tid_key || "")) {
            return;
        }
        if (!RummyDataManager.shared().rummyInfos.has(this.tid_key)) {
            return;
        }
        let t = RummyDataManager.shared().rummyInfos.get(this.tid_key);
        if (e.seatid == t.clientSeatId) {
            if (t.gameRummyType == RUMMY_GAME_TYPE.POOL || t.gameRummyType == RUMMY_GAME_TYPE.PRI_POOL || t.gameRummyType == RUMMY_GAME_TYPE.DEALS || t.gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL) {
                9 != t.playerModels[t.clientSeatId].status && this.playerTs.changeAwayStateStatus(0, false);
            }
            else {
                this.playerTs.changeAwayStateStatus(0, false);
            }
            t.roomPlayerCounter > 1 && this.actionTs.showStartBtn();
        }
    }
    handler_server_start_game_return(e) {
        this.tid_key === (e.tid_key || "") && (0 == e.ret ? this.actionTs.hideStartBtn() : e.err_msg && ToolUtils.isSafeString(e.err_msg).length > 0 && Utils.shared().showToast(e.err_msg, 2, 0, ToolUtils.getIsNormalDirection()));
    }
    handler_server_notify_ready_bc_return(e) {
        if (this.tid_key !== (e.tid_key || "")) {
            return;
        }
        if (!RummyDataManager.shared().rummyInfos.has(this.tid_key)) {
            return;
        }
        let t = RummyDataManager.shared().rummyInfos.get(this.tid_key);
        if (t.gameRummyType != RUMMY_GAME_TYPE.PRIVATE && t.gameRummyType != RUMMY_GAME_TYPE.PRI_POOL && t.gameRummyType != RUMMY_GAME_TYPE.PRI_DEAL && t.gameRummyType != RUMMY_GAME_TYPE.MATCH) {
            return;
        }
        let s = e.ret, i = e.alertStr, a = e.seatid;
        if (0 != s) {
            null != i && i.length > 0 && Utils.shared().showToast(i, 1.5, 0, ToolUtils.getIsNormalDirection());
        }
        else {
            this.actionTs.changeOpenCardStatus(false, this);
            this.actionTs.changeSwitchJokerStatus(false, this);
            t.playerModels[a].ready = 1;
            let s = this.getPosBySeatid(a);
            this.playerTs.changeAwayStateStatus(s, true, RUMMY_PLAYER_STATE_TYPE.READY);
            a == t.clientSeatId && (this.actionTs.hideReadyBtn(), t.gameRummyType !== RUMMY_GAME_TYPE.PRIVATE && this.cardsTs.resetView(), this.tipTs.showMatchWaitTip(false), t.gameRummyType === RUMMY_GAME_TYPE.PRIVATE && this.removeGameOverView());
            ToolUtils.isObjValid(this.gameEndView) && (t.gameRummyType === RUMMY_GAME_TYPE.MATCH ? this.gameEndView.getComponent(RummyPointsMatchOverAlert).showReadyView(a, true) : this.gameEndView.getComponent(RummyGameOverAlert).showReadyView(a, true));
            ToolUtils.isObjValid(this.RummyTotalSettlementNode) && this.RummyTotalSettlementNode.getComponent(RummyTotalSettlement).showReadyView(e.seatid, true);
        }
    }
    handler_server_drop_card_return(e) {
        this.rummyLogicProcessing.handler_server_drop_card_return(e);
    }
    my_drop_card_state_show(e) {
        if (e.game_state = 4, e.game_server_state = 4, this.actionTs.changeOperateBgState(false), e.gameRummyType == RUMMY_GAME_TYPE.PRIVATE || e.gameRummyType == RUMMY_GAME_TYPE.PRI_POOL || e.gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL || e.gameRummyType == RUMMY_GAME_TYPE.MATCH) {
            let e = false;
            this.actionTs.changeSwitchBtnStatus(e);
        }
        else {
            TweenTool.delayAct(this.action_node, (() => {
                PushCenter.shared().pushEvent(GameConfig.Update_Menu_Switch_Status, { tid_key: this.tid_key, bEnable: true });
            }), 1, true);
        }
        e.gameRummyType == RUMMY_GAME_TYPE.MATCH && e.gameMatchMode != RUMMY_MATCH_MODE.PointsMatch && this.tipTs.showMatchWaitTip(true);
        e.isCanTouchCard = false;
        this.isOpenQipai = false;
        this.changeQiPaiTableStatus(false);
        this.actionTs.changeQiPaiTableStatus(false);
        this.actionTs.changeOpenCardStatus(true, this);
        this.actionTs.changeSwitchJokerStatus(false, this);
        ToolUtils.isObjValid(this.openCardNode) && (this.openCardNode.active = false);
        this.hideWinTipAlert();
        this.tipTs.changePickTipsVisible(0, false);
        this.playerTs.stopPlayerTimerByPos(0);
        e.isInGameing = 0;
        this.cardsTs.onDropReset();
    }
    handler_server_drop_bc_return(e) {
        if (1 == User.shared().isInPerformanceRoom) {
            return void (this.roomPerformance && this.roomPerformance.isValid && this.roomPerformance.handler_server_drop_bc_return(e));
        }
        if (this.tid_key !== (e.tid_key || "")) {
            return;
        }
        if (!RummyDataManager.shared().rummyInfos.has(this.tid_key)) {
            return;
        }
        let t = RummyDataManager.shared().rummyInfos.get(this.tid_key), s = e.seatid, i = this.getPosBySeatid(s);
        User.shared().curTid_key == this.tid_key && (SoundManager.shared().playFx("rummyDrop"), TweenTool.delayAct(this.time_node, (() => {
            if (User.shared().curTid_key == this.tid_key) {
                let e = RummyDataManager.shared().getSeatidByPos(i, this.tid_key), t = RummyDataManager.shared().rummyInfos.get(this.tid_key).playerModels[e];
                if (t && this.tid_key == User.shared().curTid_key) {
                    let e = 2 == t.sex ? "female" : "male";
                    SoundManager.shared().playSound(ToolUtils.format("disappointed_${0}", e), null, null, 0.2);
                }
            }
        }), 0.2, true));
        null != e.all_score && (sys.isObjectValid(e.src_score) ? sys.isObjectValid(e.finish_multiple) ? this.playerTs.showLoseScore(i, e.all_score, true, e.src_score, e.finish_multiple) : this.playerTs.showLoseScore(i, e.all_score, true, e.src_score) : this.playerTs.showLoseScore(i, e.all_score, true));
        null != e.cur_money && this.playerTs.updatePlayerMoney(i, e.cur_money);
        this.playerTs.stopPlayerTimerByPos(i);
        s == t.clientSeatId && (t.gameRummyType != RUMMY_GAME_TYPE.PRIVATE && t.gameRummyType != RUMMY_GAME_TYPE.PRI_POOL && t.gameRummyType != RUMMY_GAME_TYPE.PRI_DEAL && t.gameRummyType != RUMMY_GAME_TYPE.MATCH || PushCenter.shared().pushEvent(GameConfig.Update_Private_Exit_Status, { tid_key: this.tid_key, bEnable: true }), this.cardsTs.hideCardTipsGlow(), ToolUtils.isObjValid(this.switchJokerNode) && (this.switchJokerNode.active = false));
        t.gameRummyType != RUMMY_GAME_TYPE.POOL && t.gameRummyType != RUMMY_GAME_TYPE.DEALS && t.gameRummyType != RUMMY_GAME_TYPE.PRI_POOL && t.gameRummyType != RUMMY_GAME_TYPE.PRI_DEAL || null != e.score && (this.playerTs.setPoolScore(i, e.score), this.updateSeatScore(s, e.score));
        t.gameRummyType == RUMMY_GAME_TYPE.MATCH && null != e.score && (this.playerTs.setPoolScore(i, e.score), this.updateSeatScore(s, e.score));
    }
    handler_server_pick_card_bc_return(e) {
        this.rummyLogicProcessing.handler_server_pick_card_bc_return(e);
    }
    handler_server_declare_card_return(e) {
        if (this.tid_key !== (e.tid_key || "")) {
            return;
        }
        let t = e.ret;
        1 == t ? this.cardsTs.resetMyShouPai() : 0 == t && (this.actionTs.changeDropBtnStatus(false), this.actionTs.changeFinishBtnStatus(false), this.actionTs.changeAutoGroupBtnStatus(false), this.playerTs.stopPlayerTimerByPos(0));
    }
    handler_server_declare_card_bc_return(e) {
        if (this.tid_key !== (e.tid_key || "")) {
            return;
        }
        let t = RummyDataManager.shared().rummyInfos.get(this.tid_key).clientSeatId, s = RummyDataManager.shared().rummyInfos.get(this.tid_key).playerModels[t];
        PushCenter.shared().pushEvent(PushEvent.CloseRoomRankAct);
        1 !== e.isfaurd && 1 === s.betting && (this.cardsTs.setCardValueTipShow(false), this.rummyShowTopUiLogic.removeRoomTask(), this.tipTs.setMultipleCenterTipsShow(false), Utils.shared().hideOtherQuickPayAlertByType(), Utils.shared().hideOtherQuickPayAlertByType(null, this.node), PushCenter.shared().pushEvent(PushEvent.HideWinShareView));
        this.gameOverOpenLogic.handler_server_declare_card_bc_return(this.tid_key, e);
    }
    refreshMyCardInfos(e, t = true) {
        let s, i, a = 0;
        RummyDataManager.shared().rummyInfos.get(this.tid_key).cardInfoModelVec = [];
        for (let r = 0, h = e.cardinfos.length; r < h; r++) {
            s = e.cardinfos[r];
            let h = [];
            h.type = s.type;
            h.index = s.index;
            h.score = s.score;
            h.desc = s.desc;
            h.color = s.color;
            t && (h.isShowAnime = s.isShowAnime);
            h.isCatchGroup = s.is_lastcatch_index;
            h.catchIndex = s.catch_card_index;
            let o = [];
            if (s.cards) {
                for (let e = 0, t = s.cards.length; e < t; e++) {
                    i = s.cards[e];
                    o.push(i);
                    a += 1;
                }
            }
            h.cardVec = o;
            h.inputs = s.inputs;
            RummyDataManager.shared().rummyInfos.get(this.tid_key).cardInfoModelVec.push(h);
        }
        return a;
    }
    getCardinfosBefore(e) {
        let t, s, i = [];
        for (let a = 0, r = e.cardinfos_before.length; a < r; a++) {
            t = e.cardinfos_before[a];
            let r = [];
            r.type = t.type;
            r.index = t.index;
            r.score = t.score;
            r.desc = t.desc;
            r.color = t.color;
            r.isShowAnime = t.isShowAnime;
            r.isCatchGroup = t.is_lastcatch_index;
            r.catchIndex = t.catch_card_index;
            let h = [];
            if (t.cards) {
                for (let e = 0, i = t.cards.length; e < i; e++) {
                    s = t.cards[e];
                    h.push(s);
                }
            }
            r.cardVec = h;
            i.push(r);
        }
        return i;
    }
    refreshMyShouPai(e, t = true, s = false, i = []) {
        this.refreshMyCardInfos(e);
        this.cardsTs.beginFaPaiWithoutAnim(RummyDataManager.shared().rummyInfos.get(this.tid_key).cardInfoModelVec, RummyDataManager.shared().rummyInfos.get(this.tid_key).cardInfoModelVec.length, t, -1, -1, null, i);
        RummyDataManager.shared().rummyInfos.get(this.tid_key).bHandCardSynchronous = true;
        s && this.refreshTingPaiSwitch(0);
    }
    handler_server_discard_return(e) {
        if (1 == User.shared().isInPerformanceRoom) {
            return;
        }
        if (this.tid_key !== (e.tid_key || "")) {
            return;
        }
        if (!RummyDataManager.shared().rummyInfos.has(this.tid_key)) {
            return;
        }
        let t = RummyDataManager.shared().rummyInfos.get(this.tid_key);
        sys.isObjectValid(e.tf_bonus) && (t.tf_bonus = e.tf_bonus);
        let s = e.ret;
        if (this.discardAutoSortGroupIds = [], this.saveServerCardInfos(e), this.tipTs.setAvailableCardTipsVisible(false), this.cardsTs.setAvailableCardTipsClose(), 1 == s && (t.isPlayingCard = false, e.cardinfos && (this.moveCard_action && (TweenTool.stopAction(this.moveCard_action), this.moveCard_action = null), this.refreshMyShouPai(e, true, true))), 0 == s) {
            let s = e.discard_type;
            1 == s && this.hasPlayOutLocalCard && (!t.is_showhuAnim_status || t.is_showhuAnim_status && !t.hasChupai) && (this.cardsTs.checkShowHupaiAnim(e.card, e.isfaurd, e.opencards, e.isReissue), this.playerTs.stopPlayerTimerByPos(0));
            1 == s && (!this.has_treasureHuntAct || t.gameRummyType != RUMMY_GAME_TYPE.POINTS && t.gameRummyType != RUMMY_GAME_TYPE.MULTIPLE || sys.isObjectValid(this.treahuntTaskData) && this.treahuntTaskData.cju + 1 < this.treahuntTaskData.tju && PushCenter.shared().pushEvent(PushEvent.UpdateTreaHuntProgress, { vid: t.vid }));
        }
    }
    handler_server_discard_card_bc_return(e) {
        if (1 == User.shared().isInPerformanceRoom) {
            return void (this.roomPerformance && this.roomPerformance.isValid && this.roomPerformance.handler_server_discard_card_bc_return(e));
        }
        if (this.tid_key !== (e.tid_key || "")) {
            return;
        }
        if (!RummyDataManager.shared().rummyInfos.has(this.tid_key)) {
            return;
        }
        let t = RummyDataManager.shared().rummyInfos.get(this.tid_key), s = e.ret, i = e.uid, a = [];
        if (this.discardAutoSortGroupIds.length > 0 && (a = a.concat(this.discardAutoSortGroupIds)), this.discardAutoSortGroupIds = [], sys.isObjectValid(i) && i == User.shared().data.uid && (this.saveServerCardInfos(e), t._discard_time > 0 && (HttpManager.shared().doServerMsgResponseReport({ type: 16, c_t: t._discard_time, o_t: sys.now() }), t._discard_time = -1)), 0 == s) {
            sys.isObjectValid(e.tf_bonus) && (t.tf_bonus = e.tf_bonus);
            this.tipTs.show_hupai_tip(false);
            let s = parseInt("" + e.seatid), a = e.card, r = e.index, h = e.card_index, o = e.discard_type, d = 0 == o;
            t.is_showhuAnim_status = !d;
            t.is_showhuAnim_status && (this.playerTs.setMultipleFireAnimShow(false, 0), this.playerTs.setMultipleFireAnimShow(false, 1));
            t.game_state = 0;
            t.game_server_state = 2;
            t.disCardTipsValue = 0;
            this.tipTs.changePickTipsVisible(0, false);
            this.actionTs.changeDiscardBtnStatus(false);
            this.actionTs.changeFinishBtnStatus(false);
            this.actionTs.changeAutoGroupBtnStatus(true);
            1 === o && (this.actionTs.setMopaiBtnInteractable(false), this.cardsTs.setCardValueTipShow(false), this.tingPaiTs.hideTingPaiUI(), this.tingPaiMsg = null);
            let n = t.clientSeatId, _ = t.playerModels[n];
            (0 != _.status && 4 != _.status || 1 != _.betting) && this.actionTs.changeAutoGroupBtnStatus(false);
            this.pickCardInfo = null;
            let c = true, m = false;
            if (i == User.shared().data.uid && (this.actionTs.changeDropBtnStatus(false), this.actionTs.changeGroupBtnStatus(false), this.cardsTs.showFinishTisiAnim(false), this.cardsTs.showMoPaiTisAnim(false, false), this.tipTs.show_finish_tip(false), t.isPlayingCard = false, this.drop_money = e.drop_money, this.actionTs.updateDropNum(this.drop_money), this.autoDropTs.setAutoDropBtnMoney(this.drop_money), sys.isObjectValid(e.src_score) ? sys.isObjectValid(e.finish_multiple) ? this.playerTs.showLoseScore(0, e.all_score, true, e.src_score, e.finish_multiple) : this.playerTs.showLoseScore(0, e.all_score, true, e.src_score) : this.playerTs.showLoseScore(0, e.all_score, true), e.cardinfos && this.refreshMyCardInfos(e), 1 === o && this.actionTs.changeAutoGroupBtnStatus(false), this.cardsTs.hideTingPaiTips(), this.cardsTs.hideDiscardTips(), this.tingPaiTs.changeTingPaiBubbleVisible(false), this.tingPaiTs.showpickBubbleView(false), this.tipTs.showQuickFinishTips(false), this.playerTs.stopPlayerTimerByPos(0), this.helper_hu_card = 0, this.quick_sort = 0, this.can_declare = 0, this.finish_groups = null, this.hasPlayOutLocalCard && t.able_local_discard && (c = false, m = 1 == this.handCardDataAnalysis.checkSameCards(this.cardsTs.myGroupcardValueVec, t.cardInfoModelVec))), c) {
                t.winLaizicard = 1 === o && sys.isObjectValid(e.lz_card) ? e.lz_card : 0;
                this.cardsTs.playOutCards(a, this.getPosBySeatid(s), d, false, e.opencards, r, h);
            }
            else if (0 == o && TweenTool.delayAct(this.time_node, (() => {
                this.cardsTs.showLastQipaiCard(a);
            }), 0.2, true), i == User.shared().data.uid && m) {
                let e = 0 == o ? 0.2 : 0.3;
                TweenTool.delayAct(this.time_node, (() => {
                    this.cardsTs.beginFaPaiWithoutAnim(RummyDataManager.shared().rummyInfos.get(this.tid_key).cardInfoModelVec, RummyDataManager.shared().rummyInfos.get(this.tid_key).cardInfoModelVec.length);
                    RummyDataManager.shared().rummyInfos.get(this.tid_key).bHandCardSynchronous = true;
                }), e, true);
            }
            else {
                this.cardsTs.showAvailableCardFlag(RummyDataManager.shared().rummyInfos.get(this.tid_key).cardInfoModelVec);
            }
            this.hasPlayOutLocalCard = false;
            let y = this.getPlayerGiveCard(s);
            if (y) {
                let e = [];
                e.value = a;
                e.is_catch = 0;
                y.cards.push(e);
            }
            if (1 == e.isfarud) {
                let s = t.clientSeatId;
                t.game_server_state = 4;
                this.cardsTs.showDropCardsZheZhao(true);
                t.gameRummyType == RUMMY_GAME_TYPE.MATCH && t.gameMatchMode != RUMMY_MATCH_MODE.PointsMatch && this.tipTs.showMatchWaitTip(true);
                t.isCanTouchCard = false;
                t.isInGameing = 0;
                let i = this.getPosBySeatid(s);
                null != e.all_score && (sys.isObjectValid(e.src_score) ? sys.isObjectValid(e.finish_multiple) ? this.playerTs.showLoseScore(0, e.all_score, true, e.src_score, e.finish_multiple) : this.playerTs.showLoseScore(0, e.all_score, true, e.src_score) : this.playerTs.showLoseScore(i, e.all_score, true));
                this.playerTs.stopPlayerTimerByPos(i);
                null != e.cur_money && this.playerTs.updatePlayerMoney(i, e.cur_money);
                t.gameRummyType != RUMMY_GAME_TYPE.PRIVATE && t.gameRummyType != RUMMY_GAME_TYPE.PRI_POOL && t.gameRummyType != RUMMY_GAME_TYPE.PRI_DEAL && t.gameRummyType != RUMMY_GAME_TYPE.MATCH || s == t.clientSeatId && PushCenter.shared().pushEvent(GameConfig.Update_Private_Exit_Status, { tid_key: this.tid_key, bEnable: true });
                t.gameRummyType != RUMMY_GAME_TYPE.POOL && t.gameRummyType != RUMMY_GAME_TYPE.PRI_POOL && t.gameRummyType != RUMMY_GAME_TYPE.PRI_DEAL && t.gameRummyType != RUMMY_GAME_TYPE.DEALS || (null != e.score && this.playerTs.setPoolScore(i, e.score), PushCenter.shared().pushEvent(GameConfig.Update_Private_Exit_Status, { tid_key: this.tid_key, bEnable: false }), PushCenter.shared().pushEvent(GameConfig.Update_Menu_Switch_Status, { tid_key: this.tid_key, bEnable: false }));
                t.gameRummyType == RUMMY_GAME_TYPE.MATCH && null != e.score && (this.playerTs.setPoolScore(i, e.score), this.updateSeatScore(s, e.score));
            }
            else {
                t.isPlayingCard = false;
            }
            let u = RummyDataManager.shared().checkLiveAvatar(this.tid_key, s);
            0 == this.getPosBySeatid(s) && (1 == o && 1 != e.isfarud || this.rummyLogicProcessing.showPlayerHeadAnim(this.getPosBySeatid(s), 4, u));
        }
        else {
            1 == s && (t.isPlayingCard = false, e.cardinfos && (this.moveCard_action && (TweenTool.stopAction(this.moveCard_action), this.moveCard_action = null), this.refreshMyShouPai(e, true, true)));
        }
    }
    saveServerCardInfos(e) {
        sys.isObjectValid(e) && e.cardinfos && (this.cardInfoMsg = e, this.moveCard_action && (TweenTool.stopAction(this.moveCard_action), this.moveCard_action = null));
    }
    handler_server_move_card_return(e) {
        if (this.tid_key !== (e.tid_key || "")) {
            return;
        }
        let t = [];
        if (this.saveServerCardInfos(e), 0 == e.ret) {
            this.dealGroupCardByServerMsg(e, t);
            1 == e.positive ? this.playEffectByName("rummyPositiveGroup") : this.playEffectByName("rummyCardDeselect");
            sys.isObjectValid(e.src_score) ? sys.isObjectValid(e.finish_multiple) ? this.playerTs.showLoseScore(0, e.all_score, true, e.src_score, e.finish_multiple) : this.playerTs.showLoseScore(0, e.all_score, true, e.src_score) : this.playerTs.showLoseScore(0, e.all_score, true);
        }
        else {
            this.dealGroupCardByServerMsg(e, t);
            e.alertStr.length > 0 && Utils.shared().showToast(e.alertStr, 2, 0, ToolUtils.getIsNormalDirection());
        }
    }
    dealGroupCardByServerMsg(e, t = []) {
        if (sys.isObjectValid(e) && e.cardinfos) {
            let s = true;
            if (this.moveCard_action && (TweenTool.stopAction(this.moveCard_action), this.moveCard_action = null), RummyDataManager.shared().rummyInfos.get(this.tid_key).able_client_group) {
                let i = this.handCardDataAnalysis.getHandCardDataCheck(e.cardinfos, this.cardsTs.myGroupcardValueVec);
                i ? RummyDataManager.shared().rummyInfos.get(this.tid_key).isMovingCard ? (s = false, this.moveCard_action = TweenTool.delayAct(this.time_node, (() => {
                    sys.isObjectValid(this.cardInfoMsg) && sys.isObjectValid(this.cardInfoMsg.cardinfos) && (i = this.handCardDataAnalysis.getHandCardDataCheck(this.cardInfoMsg.cardinfos, this.cardsTs.myGroupcardValueVec), i && (RummyDataManager.shared().rummyInfos.get(this.tid_key).isMovingCard || (this.refreshMyShouPai(this.cardInfoMsg, true, true, t), gameNetworkDelay.shared().isShowNetworkDelay(true))));
                }), 5, true)) : s = true : s = false;
            }
            s ? this.refreshMyShouPai(e, true, true, t) : (this.refreshMyCardInfos(e), this.refreshTingPaiSwitch(0), this.cardsTs.showAvailableCardFlag(RummyDataManager.shared().rummyInfos.get(this.tid_key).cardInfoModelVec), t.length > 0 && this.cardsTs.refreshAllGroupInfo(t));
        }
    }
    handler_server_group_card_return(e) {
        if (this.tid_key !== (e.tid_key || "")) {
            return;
        }
        let t = [];
        if (this.saveServerCardInfos(e), 0 == e.ret) {
            if (1 == e.positive ? this.playEffectByName("rummyPositiveGroup") : this.playEffectByName("rummyGroup"), this.actionTs.changeGroupBtnStatus(false), this.actionTs.changeDiscardBtnStatus(false), this.actionTs.changeFinishBtnStatus(false), this.actionTs.changeAutoGroupBtnStatus(true), this.autoDropTs.setAutoDropBtn(2), sys.isObjectValid(e.src_score) ? sys.isObjectValid(e.finish_multiple) ? this.playerTs.showLoseScore(0, e.all_score, true, e.src_score, e.finish_multiple) : this.playerTs.showLoseScore(0, e.all_score, true, e.src_score) : this.playerTs.showLoseScore(0, e.all_score, true), e.cardinfos) {
                let s = true;
                if (RummyDataManager.shared().rummyInfos.get(this.tid_key).able_client_group) {
                    this.handCardDataAnalysis.getHandCardDataCheck(e.cardinfos, this.cardsTs.myGroupcardValueVec) || (s = false);
                }
                s ? this.refreshMyShouPai(e, true, true, t) : (this.refreshMyCardInfos(e), this.refreshTingPaiSwitch(0), this.cardsTs.showAvailableCardFlag(RummyDataManager.shared().rummyInfos.get(this.tid_key).cardInfoModelVec));
            }
        }
        else {
            e.cardinfos && this.refreshMyShouPai(e, true, true, t);
            e.alertStr.length > 0 && Utils.shared().showToast(e.alertStr, 2, 0, ToolUtils.getIsNormalDirection());
        }
    }
    handler_server_show_other_cards_bc(e) {
        if (this.tid_key !== (e.tid_key || "")) {
            return;
        }
        let t = this.getPosBySeatid(e.seatid), s = sys.isObjectValid(e.lz_card) ? e.lz_card : RummyDataManager.shared().rummyInfos.get(this.tid_key).laizicard;
        this.cardsTs.showRobotPlayerCards(e.cardinfos, t, s);
    }
    handler_server_finish_return(e) {
        if (this.tid_key !== (e.tid_key || "")) {
            return;
        }
        if (!RummyDataManager.shared().rummyInfos.has(this.tid_key)) {
            return;
        }
        let t = RummyDataManager.shared().rummyInfos.get(this.tid_key);
        if (0 == e.ret) {
            if (t._declare_time > 0 && (HttpManager.shared().doServerMsgResponseReport({ type: 18, c_t: t._declare_time, o_t: sys.now() }), t._declare_time = -1), sys.isObjectValid(e.src_score) ? sys.isObjectValid(e.finish_multiple) ? this.playerTs.showLoseScore(0, e.all_score, true, e.src_score, e.finish_multiple) : this.playerTs.showLoseScore(0, e.all_score, true, e.src_score) : this.playerTs.showLoseScore(0, e.all_score, true), this.tipTs.showConfimTips("", "", false), t.game_state = 4, t.game_server_state = 2, t.game_cd = 10, t.isCanTouchCard = false, this.actionTs.changeAutoGroupBtnStatus(false), null != e.cur_money && (this.playerTs.updatePlayerMoney(0, e.cur_money), 0 === t.crashModel && (User.shared().data.money = User.shared().real_money = e.cur_money, PushCenter.shared().pushEvent(GameConfig.Update_Money, e.cur_money))), t.gameRummyType == RUMMY_GAME_TYPE.MATCH && null != e.score) {
                let s = t.clientSeatId;
                this.playerTs.setPoolScore(0, e.score);
                this.updateSeatScore(s, e.score);
            }
            !this.has_treasureHuntAct || t.gameRummyType != RUMMY_GAME_TYPE.POINTS && t.gameRummyType != RUMMY_GAME_TYPE.MULTIPLE || sys.isObjectValid(this.treahuntTaskData) && this.treahuntTaskData.cju + 1 < this.treahuntTaskData.tju && PushCenter.shared().pushEvent(PushEvent.UpdateTreaHuntProgress, { vid: t.vid });
        }
    }
    handler_server_finish_return_bc(e) {
        if (this.tid_key !== (e.tid_key || "")) {
            return;
        }
        let t = e.seatid, s = this.getPosBySeatid(t);
        if (0 == s) {
            let e = RummyDataManager.shared().rummyInfos.get(this.tid_key);
            e && e._declare_time > 0 && (HttpManager.shared().doServerMsgResponseReport({ type: 18, c_t: e._declare_time, o_t: sys.now() }), e._declare_time = -1);
        }
        sys.isObjectValid(e.src_score) ? sys.isObjectValid(e.finish_multiple) ? this.playerTs.showLoseScore(s, e.all_score, true, e.src_score, e.finish_multiple) : this.playerTs.showLoseScore(s, e.all_score, true, e.src_score) : this.playerTs.showLoseScore(s, e.all_score, true);
        this.playerTs.stopPlayerTimer2(s);
        null != e.cur_money && (this.playerTs.updatePlayerMoney(s, e.cur_money), 0 == s && 0 === RummyDataManager.shared().rummyInfos.get(this.tid_key).crashModel && (User.shared().data.money = User.shared().real_money = e.cur_money, PushCenter.shared().pushEvent(GameConfig.Update_Money, e.cur_money)));
        this.playerTs.changeAwayStateStatus(s, true, RUMMY_PLAYER_STATE_TYPE.LOST);
        let i = RummyDataManager.shared().rummyInfos.get(this.tid_key).playerModels[t];
        i && (i.status = RUMMY_PLAYER_STATE_TYPE.LOST);
        RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType == RUMMY_GAME_TYPE.MATCH && null != e.score && (this.playerTs.setPoolScore(s, e.score), this.updateSeatScore(t, e.score));
    }
    handler_server_last_card_return(e) {
        if (this.tid_key !== (e.tid_key || "")) {
            return;
        }
        undefined === e.players && (e.players = []);
        for (let t = 0, s = e.players.length; t < s; t++) {
            e.players[t].isfinish = 1;
        }
        this._lastGameOverMsg = e;
        try {
            let t = this.pop_layer4.getChildByName("match_game_over");
            if (!ToolUtils.isObjValid(t)) {
                let t = 1;
                null != e.notice_type && (t = e.notice_type);
                null != e.start_cd && (RummyDataManager.shared().rummyInfos.get(this.tid_key).hasShowScanAlert = true);
                this.rummyShowTopUiLogic.showHistoryView(t, e);
            }
            let s = this.pop_layer4.getChildByName("comm_magic_face");
            ToolUtils.isObjValid(s) && s && (s.destroy(), s = null);
        }
        catch (e) {
            TLog.printError("trycatch handler_server_last_card_return,error:", e);
        }
        e.is_over;
        e.win_money;
        e.lose_money;
    }
    handler_server_game_end_bc(e) {
        if (1 != User.shared().isInPerformanceRoom) {
            try {
                if (this.tid_key !== (e.tid_key || "")) {
                    return;
                }
                this.actionTs.getRaceRewardVisible() && this.actionTs.changeRaceRewardDiVisible(false);
                this.can_declare = 0;
                this.helper_hu_card = 0;
                this.tingPaiMsg = null;
                this.pickCardInfo = null;
                PushCenter.shared().pushEvent(PushEvent.CloseRoomRankAct);
                this.tipTs.setAvailableCardTipsVisible(false);
                this.cardsTs.setAvailableCardTipsClose();
                this.tipTs.showQuickFinishTips(false);
                this.tipTs.setManulaRejoinSelect(false);
                this.hideAllTingPaiFlag();
                this.cardsTs.setCardValueTipShow(false);
                this.cardsTs.hideCardTipsGlow();
                this.winTips.active = false;
                RummyDataManager.shared().stopTweenAction(this.hide_win_tip_action);
                this.hideWinTipAlert();
                this.rummyShowTopUiLogic.removeRoomTask();
                this.hasFreeMatchPush = false;
                this.tipTs.setFreeMatchPushActive(false);
                this.checkHasMatchJoinTips() || this.actionTs.changeMatchRankBtnVisibile(false);
                ToolUtils.isObjValid(this.switchJokerNode) && (this.switchJokerNode.active = false);
                this.gameOverOpenLogic.handler_server_game_end_bc(this.tid_key, e);
                sys.isObjectValid(e.tf_venue) && sys.isObjectValid(e.tf_venue.entry_fee) && (RummyDataManager.shared().rummyInfos.get(this.tid_key).tf_venue = e.tf_venue);
            }
            catch (e) {
                TLog.printError("trycatch handler_server_game_end_bc,error:", e);
            }
        }
        else {
            this.roomPerformance && this.roomPerformance.isValid && this.roomPerformance.handler_server_game_end_bc(e);
        }
    }
    delayUpdatePlayerMoney(e) {
        if (this.rummyEndJpacket.players) {
            for (let t = 0, s = this.rummyEndJpacket.players.length; t < s; t++) {
                const s = this.rummyEndJpacket.players[t];
                if (e == s.seatid) {
                    let e = s.seatid, t = s.money, i = s.score, a = s.uid, r = RummyDataManager.shared().rummyInfos.get(this.tid_key).playerModels[e];
                    return r.money = t, r.score = i, a == User.shared().data.uid && 0 == RummyDataManager.shared().rummyInfos.get(this.tid_key).crashModel && (User.shared().data.money = t, User.shared().real_money = t, PushCenter.shared().pushEvent(GameConfig.Update_Money, t)), void this.playerTs.updatePlayerMoney(this.getPosBySeatid(e), t);
                }
            }
        }
    }
    delayToUpdatePlayerMoney() {
        if (this.rummyEndJpacket.players) {
            for (let e = 0, t = this.rummyEndJpacket.players.length; e < t; e++) {
                const t = this.rummyEndJpacket.players[e];
                let s = parseInt("" + t.seatid), i = t.money, a = t.score, r = t.uid, h = RummyDataManager.shared().rummyInfos.get(this.tid_key).playerModels[s];
                h.money = i;
                h.score = a;
                r == User.shared().data.uid && 2 != ToolUtils.game_model && (RummyDataManager.shared().rummyInfos.get(this.tid_key).money = i, RummyDataManager.shared().rummyInfos.get(this.tid_key).score = a, RummyDataManager.shared().rummyInfos.get(this.tid_key).myMoney = i);
                this.playerTs.updatePlayerMoney(this.getPosBySeatid(s), i);
            }
        }
    }
    dealPrivateTableTips() {
        RummyDataManager.shared().rummyInfos.has(this.tid_key) && this.rummyLogicProcessing.dealPrivateTableTips();
    }
    handler_server_finish_status_bc(e) {
        if (this.tid_key !== (e.tid_key || "")) {
            return;
        }
        this.actionTs.getRaceRewardVisible() && this.actionTs.changeRaceRewardDiVisible(false);
        this.tipTs.setAvailableCardTipsVisible(false);
        this.cardsTs.setAvailableCardTipsClose();
        PushCenter.shared().pushEvent(PushEvent.CloseRoomRankAct);
        this.gameOverOpenLogic.handler_server_finish_status_bc(this.tid_key, e);
    }
    checkReadyBtn() {
        RummyDataManager.shared().rummyInfos.has(this.tid_key) && this.rummyLogicProcessing.checkReadyBtn();
    }
    onGameEndViewClosed() {
        this._bIsShowWaitDeclare && this.tipTs.show_wait_declare(true);
        RummyDataManager.shared().rummyInfos.get(this.tid_key).isClearCards && (this.gameOverOpenLogic.clearCards(), this.gameOverOpenLogic.dealGameEnd(this.tid_key));
    }
    handler_server_game_show_info_return(e) {
        this.tid_key === (e.tid_key || "") && (1 == GameConfig.CHIPS_MODLE && e.GameVariant && (e.GameVariant = e.GameVariant.replace(new RegExp("Rummy", "g"), "")), this.roomInfoMsg = e, ToolUtils.isObjValid(this.roomInfoNode) ? this.roomInfoTs.refreshUI(e) : (this._isShowTableinfo && this.rummyShowTopUiLogic.createRoomInfoNode(), this._isShowTableinfo = false));
    }
    handler_server_declare_check_return(e) {
        if (this.tid_key !== (e.tid_key || "")) {
            return;
        }
        let t = e.ret;
        if (0 == t) {
            if (-1 != this.finishType) {
                let t = this.cardsTs.getQuickHuCard(this.helper_hu_card), s = {};
                if (1 == ToolUtils.isSafeNumber(e.is_quick) && 0 != this.helper_hu_card && ToolUtils.isObjValid(t)) {
                    let e = t.getComponent("RummyCard");
                    s.card = e.mCardValue;
                    s.index = e.groupIndex;
                    s.cardIndex = e.cardIndex;
                    RummyDataManager.shared().rummyInfos.get(this.tid_key).playCardValue = this.helper_hu_card;
                }
                else {
                    s = null;
                    let e = this.cardsTs.getSelectedCards();
                    if (e.length > 0) {
                        let t = e[0].getComponent("RummyCard");
                        RummyDataManager.shared().rummyInfos.get(this.tid_key).playCardValue = t.mCardValue;
                    }
                }
                this.handler_server_discard_request(1, this.finishType, s);
            }
        }
        else {
            1 == t ? -1 != this.finishType && (this.hasPlayOutLocalCard = false, this.cardsTs.resetMyShouPai(), this.restoreHuHandCards()) : 2 == t && this.onDealBtnAction("finish_no");
        }
    }
    restoreHuHandCards() {
        Utils.shared().showToast(i18nMgr.shared().getValueByKey("rummy_main.finish_tips"), 2, 0, ToolUtils.getIsNormalDirection());
        this.actionTs.changeDiscardBtnStatus(false);
        this.actionTs.changeFinishBtnStatus(false);
        this.actionTs.changeAutoGroupBtnStatus(true);
        RummyDataManager.shared().rummyInfos.get(this.tid_key).hasChupai = false;
        this.refreshTingPaiSwitch(0);
        this.finishType = -1;
    }
    finishCardsCallBack(e) {
        1 == e ? this.handler_server_discard_request(1, 0) : (RummyDataManager.shared().rummyInfos.get(this.tid_key).hasChupai = false, this.cardsTs.resetMyShouPai(), this.finishType = -1);
    }
    handler_server_show_swtich_btn_return(e) {
        if (this.tid_key !== (e.tid_key || "")) {
            return;
        }
        let t = RummyDataManager.shared().rummyInfos.get(this.tid_key), s = t.gameRummyType, i = false;
        1 == e.show && (s == RUMMY_GAME_TYPE.PRIVATE || s == RUMMY_GAME_TYPE.PRI_POOL || s == RUMMY_GAME_TYPE.PRI_DEAL || (s == RUMMY_GAME_TYPE.MATCH ? t.gameMatchMode == RUMMY_MATCH_MODE.PointsMatch && (i = true) : i = true));
        let a = false;
        0 != t.crashModel || s != RUMMY_GAME_TYPE.POINTS && s != RUMMY_GAME_TYPE.MULTIPLE || sys.isObjectValid(e.force_up_venue_tips_st) && 1 == ToolUtils.isSafeNumber(e.force_up_venue_tips_st.show) && (a = true, this.actionTs.refreshPlayBtnNum(e.force_up_venue_tips_st.base_money));
        this.actionTs.changePlayBtnStatus(a);
        !i || s != RUMMY_GAME_TYPE.POOL || 0 != e.is_show_pre_rejoin && 1 != e.is_show_pre_rejoin ? (t.manule_rejoin_select = false, this.tipTs.setManulaRejoinSelect(false), this.actionTs.changeSwitchBtnStatus(i)) : (t.manule_rejoin_select = 1 == e.status, this.tipTs.setManulaRejoinSelect(true, e.is_show_pre_rejoin), 1 == e.is_show_pre_rejoin ? this.actionTs.changeSwitchBtnStatus(true) : this.actionTs.changeSwitchBtnStatus(false));
        PushCenter.shared().pushEvent(GameConfig.Update_Menu_Switch_Status, { tid_key: this.tid_key, bEnable: i });
    }
    handler_server_give_card_return(e) {
        if (this.tid_key === (e.tid_key || "") && (this.sortPlayerGiveCard(), Array.isArray(e.players) && e.players.length > 0)) {
            for (let t = 0, s = e.players.length; t < s; t++) {
                let s = e.players[t], i = this.getPlayerGiveCard(s.seatid);
                i && s.cards && (i.cards = s.cards || []);
            }
        }
    }
    handler_server_add_card_return(e) {
        if (this.tid_key !== (e.tid_key || "")) {
            return;
        }
        let t = [];
        if (this.saveServerCardInfos(e), 0 == e.ret) {
            1 == e.positive ? this.playEffectByName("rummyPositiveGroup") : this.playEffectByName("rummyCardDeselect");
            this.actionTs.changeGroupBtnStatus(false);
            this.actionTs.changeDiscardBtnStatus(false);
            this.actionTs.changeFinishBtnStatus(false);
            this.actionTs.changeAutoGroupBtnStatus(true);
            this.autoDropTs.setAutoDropBtn(2);
            sys.isObjectValid(e.src_score) ? sys.isObjectValid(e.finish_multiple) ? this.playerTs.showLoseScore(0, e.all_score, true, e.src_score, e.finish_multiple) : this.playerTs.showLoseScore(0, e.all_score, true, e.src_score) : this.playerTs.showLoseScore(0, e.all_score, true);
            e.cardinfos && this.refreshMyShouPai(e, true, true, t);
        }
        else {
            e.cardinfos && this.refreshMyShouPai(e, true, true, t);
        }
    }
    showMagicFaceAlert(e, t) {
        this.rummyShowTopUiLogic.showMagicFaceAlert(e, t);
    }
    onClickByPlayerRoot(e, t) {
        let s = RummyDataManager.shared().rummyInfos.get(this.tid_key), i = parseInt("" + t);
        if (!s.is_table_change_status && 1 != s.crashModel && i < 6) {
            if (2 == s.pnum && (1 == i ? i = 3 : 3 == i && (i = 1)), !this.playerTs.checkHeadShow(i)) {
                return;
            }
            SoundManager.shared().playFx("click");
            let e = this.getSeatidByPos(i), t = s.playerModels[e];
            t.isShow && this.showMagicFaceAlert(e, t);
        }
    }
    sendMagicFace(e, t, s = 0) {
        RummyDataManager.shared().rummyInfos.get(this.tid_key).is_table_change_status || (this.rummyLogicProcessing.sendMagicFace(e, t), User.shared().data.money >= s && ToolUtils.isObjValid(this.game_chatNode) && this.game_chatTs.showBigFace(0, this.getPosBySeatid(t), e - 1, 1));
    }
    sendFace(e) {
        parseInt(e) >= 50 ? RummyDataManager.shared().chat_Type = 2 : RummyDataManager.shared().chat_Type = 1;
        RummyDataManager.shared().rummyInfos.get(this.tid_key).is_table_change_status || (this.rummyLogicProcessing.sendFace(e), ToolUtils.isObjValid(this.game_chatNode) && (e >= 50 ? this.game_chatTs.showMemberShipFace(0, e) : this.game_chatTs.showFace(0, e)));
    }
    sendText(e, t) {
        RummyDataManager.shared().chat_Type = 0;
        RummyDataManager.shared().rummyInfos.get(this.tid_key).is_table_change_status || (this.rummyLogicProcessing.sendText(e, t), ToolUtils.isObjValid(this.game_chatNode) && this.game_chatTs.startTalk2(0, e, t));
    }
    onClickByActionRoot_Normal(e, t) {
        if (!(sys.now() - this._lastClick < 500)) {
            if (this._lastClick = sys.now(), "drop" == t || "auto_drop" == t) {
                this.playEffectByName("rummyFlip");
            }
            else if (t.indexOf("Add_Btn") > -1) {
                RummyDataManager.shared().rummyInfos.get(this.tid_key).to_index = parseInt(t.substring("Add_Btn".length));
                this.rummyLogicProcessing.handler_server_add_card_request(RummyDataManager.shared().rummyInfos.get(this.tid_key).to_index);
            }
            else if (t.indexOf("left_btn") > -1) {
                let e = parseInt(t.substring("left_btn".length));
                this.rummyLogicProcessing.handler_server_move_group_cards_request(e, 1);
            }
            else if (t.indexOf("right_btn") > -1) {
                let e = parseInt(t.substring("right_btn".length));
                this.rummyLogicProcessing.handler_server_move_group_cards_request(e, 2);
            }
            else if ("mopai" == t) {
                this.playerTs.hasShowPaiduiDi();
            }
            else if ("qipai" == t) {
                this.playerTs.hasShowQipaiDi();
            }
            else if ("discard" == t) {
                ;
            }
            else if ("switch" == t) {
                let e = RummyDataManager.shared().rummyInfos.get(this.tid_key);
                0 == e.crashModel && ToolUtils.checkIsModuleReport(PhpReportDefined.module.room_drop_high) && this.actionTs.getIsPlayBtnVisible() && HttpManager.shared().doReportClick({ module: PhpReportDefined.module.room_drop_high, scene: PhpReportDefined.scece.cash_room_drop, event: PhpReportDefined.room_drop_high_event.click_switch_table, vid: e.vid });
            }
            else if ("cash_up_play" == t) {
                let e = RummyDataManager.shared().rummyInfos.get(this.tid_key);
                0 == e.crashModel && ToolUtils.checkIsModuleReport(PhpReportDefined.module.room_drop_high) && HttpManager.shared().doReportClick({ module: PhpReportDefined.module.room_drop_high, scene: PhpReportDefined.scece.cash_room_drop, event: PhpReportDefined.room_drop_high_event.click_play_with_value, force_up_venue: e.force_up_venue, vid: e.vid });
            }
            else {
                SoundManager.shared().playFx("click");
            }
            this.onDealBtnAction(t);
        }
    }
    showTournamentDropConfirmation(autoDrop = false) {
        const tid = this.tid_key;
        const text = i18nMgr.shared().getValueByKey("rummy_main.drop_text1");
        Utils.shared().showCommomDialog(text, "", (confirmed => {
            if (confirmed != 1 || this.tid_key !== tid || !RummyDataManager.shared().rummyInfos.has(tid)) return;
            // Tournament DROP means abandon this hand and keep the tournament seat.
            this.autoDropTs.tid_key = tid;
            if (autoDrop) this.autoDropTs.handler_auto_drop_request(tid, 1);
            else this.autoDropTs.send_drop_card_request(1);
        }), true, ToolUtils.getIsNormalDirection(), null, null, null, this.pop_layer4, null, tid, false);
    }
    showRummyRoomInfoView() {
        this.rummyLogicProcessing.send_game_show_info_request();
        null != this.roomInfoMsg && (ToolUtils.isObjValid(this.roomInfoNode) ? this.roomInfoTs.refreshUI(this.roomInfoMsg) : this.rummyShowTopUiLogic.createRoomInfoNode());
    }
    showMatchRankInfoView() {
        this.rummyShowTopUiLogic.showMatchRankInfoView();
    }
    showMatchTipsAnim(e) {
        this.rummyShowTopUiLogic.showMatchTipsAnim(e);
    }
    onBtnClick(e, t) {
        SoundManager.shared().playFx("click");
        this.onDealBtnAction(t);
    }
    onDealBtnAction(e, t = null) {
        if (this.tid_key == CommDefine.NewerGuideRoomTidkey) {
            return;
        }
        if (!RummyDataManager.shared().rummyInfos.has(this.tid_key)) {
            return;
        }
        let s = RummyDataManager.shared().rummyInfos.get(this.tid_key);
        switch (String(e)) {
            case "history":
                this.rummyLogicProcessing.send_last_card_request(), this.rummyShowTopUiLogic.showHistoryView(1, null);
                break;
            case "novices_task":
                Utils.shared().showNovicesTaskView(false, { vid: RummyDataManager.shared().rummyInfos.get(this.tid_key).vid });
                break;
            case "daily_task":
                RummyDataManager.shared().reportCommClickEvent(this.tid_key, ReportConfig.func.Weekly_Jackpot, ReportConfig.cash_evt.click_weekly_btn), this.loadDailyTaskBubble(true, 1);
                break;
            case "set":
                if (this.tid_key == CommDefine.NewerGuideRoomTidkey) {
                    return;
                }
                RummyDataManager.shared().reportCommClickEvent(this.tid_key, ReportConfig.func.Room_Menu, ReportConfig.cash_evt.click_menu), this.rummyShowTopUiLogic.showMenuAlert();
                break;
            case "drop":
                if (s.gameRummyType == RUMMY_GAME_TYPE.MATCH) {
                    this.showTournamentDropConfirmation();
                    break;
                }
                let i = 0;
                for (let e = 0; e < 6; e++) {
                    let t = s.playerModels[e];
                    1 != t.betting && 4 != t.status || (i += 1);
                }
                if ((s.gameRummyType == RUMMY_GAME_TYPE.POINTS || s.gameRummyType == RUMMY_GAME_TYPE.MULTIPLE || this.checkIsPointsMatch()) && i > 2) {
                    if (this.checkIsPointsMatch() && s.user_round == s.max_round) {
                        return void this.rummyLogicProcessing.handler_logout_request(0, 1);
                    }
                    let e = i18nMgr.shared().getValueByKey("rummy_main.yes"), t = i18nMgr.shared().getValueByKey("rummy_main.drop_go"), i = i18nMgr.shared().getValueByKey("rummy_main.drop_text");
                    this.autoDropTs.showDropNode(this.tid_key, i, 0, e, t, 1);
                }
                else {
                    let e = i18nMgr.shared().getValueByKey("store.okey"), t = i18nMgr.shared().getValueByKey("rummy_main.cancel"), i = i18nMgr.shared().getValueByKey("rummy_main.drop_text1");
                    s.gameRummyType == RUMMY_GAME_TYPE.POOL || s.gameRummyType == RUMMY_GAME_TYPE.PRI_POOL ? this.rummyLogicProcessing.send_drop_card_is_eliminate(1) : this.autoDropTs.showDropNode(this.tid_key, i, 0, e, t, 0, true);
                }
                break;
            case "group":
                this.rummyLogicProcessing.handler_server_group_card_request();
                break;
            case "finish":
                if (!this._bIsCanFinish) {
                    return;
                }
                if (s.able_local_discard && this.checkFinishCards()) {
                    let e = this.cardsTs.getSelectedCards(), t = {};
                    if (1 == e.length) {
                        let s = e[0].getComponent("RummyCard");
                        t.card = s.mCardValue;
                        t.index = s.groupIndex;
                        t.cardIndex = s.cardIndex;
                        t.isQipai = false;
                        this.qipaiCardValues[this.qipaiCardValues.length] = s.mCardValue;
                    }
                    this.finishType = 1;
                    this.dealLocalDisCardCard(t);
                }
                else {
                    this.handler_server_declare_check_request(1);
                }
                this._bIsCanFinish = false, this.scheduleOnce((() => {
                    this._bIsCanFinish = true;
                }), 1);
                break;
            case "discard":
                {
                    let e = this.cardsTs.getSelectedCards(), t = { isQipai: true };
                    if (e && e.length > 0) {
                        let i = e[0].getComponent("RummyCard");
                        s.groupIndex = i.groupIndex;
                        s.card_index = i.cardIndex;
                        s.playCardValue = i.mCardValue;
                        t.card = i.mCardValue;
                        t.index = i.groupIndex;
                        t.cardIndex = i.cardIndex;
                        this.qipaiCardValues[this.qipaiCardValues.length] = i.mCardValue;
                    }
                    if (this.cardsTs.isOneOnlyPureCard()) {
                        let e = i18nMgr.shared().getValueByKey("utlis.text12"), t = this;
                        Utils.shared().showCommomDialog(e, "", (e => {
                            1 == e ? t.handler_server_discard_request(0, 1) : (s.hasChupai = false, t.cardsTs.resetMyShouPai());
                        }), true, ToolUtils.getIsNormalDirection(), null, null, null, this.pop_layer4, null, this.tid_key);
                    }
                    else {
                        this.dealLocalDisCardCard(t);
                        this.handler_server_discard_request(0, 1);
                    }
                }
                break;
            case "switch":
                if (!this._bIsCanSwitch) {
                    return;
                }
                let a = s.clientSeatId, r = s.playerModels[a];
                if (1 == s.isInGameing && (1 == r.betting || 0 == r.betting && 4 == r.status)) {
                    let e = ToolUtils.format(i18nMgr.shared().getValueByKey("utlis.text19"), ToolUtils.parse_double("" + this.drop_money), s.entry_fee);
                    1 == s.crashModel && (e = ToolUtils.format(i18nMgr.shared().getValueByKey("utlis.text20"), Math.floor(this.drop_money)));
                    Utils.shared().showCommomDialog(e, "", this.switchDestCallBack.bind(this), true, ToolUtils.getIsNormalDirection(), null, null, null, this.pop_layer4, null, this.tid_key);
                }
                else {
                    s.gameRummyType == RUMMY_GAME_TYPE.POINTS || s.gameRummyType == RUMMY_GAME_TYPE.MULTIPLE ? this.rummyLogicProcessing.handler_pre_switch_request() : this.switchCallback();
                    this._bIsCanSwitch = false;
                    this.scheduleOnce((() => {
                        this._bIsCanSwitch = true;
                    }), 1);
                }
                break;
            case "opencard":
                this.isOpenQipai = !this.isOpenQipai, this.isOpenQipai ? (this.actionTs.changeOpenCardStatus(false, this), this.rummyLogicProcessing.send_gong_cards_request()) : this.changeQiPaiTableStatus(this.isOpenQipai);
                break;
            case "confirm":
                this.rummyLogicProcessing.send_finish_request();
                break;
            case "auto_declare":
                if (sys.now() - s.lastClick < 1000) {
                    return;
                }
                s.lastClick = sys.now(), this.rummyLogicProcessing.handler_server_Auto_declare_request(0 == s.autoDeclareStatus ? 1 : 0), PushCenter.shared().pushEvent(PushEvent.UpdateAutoDeclareStatus, { tid_key: this.tid_key, status: status });
                break;
            case "mopai":
                if (1 == s.isInGameing) {
                    if (s.isGameOver = false, !Server.shared().checkPauseState()) {
                        return void Server.shared().resumeWS();
                    }
                    s.isClientToPlay ? 14 == this.cardsTs.cardViewVec.length ? (this.tipTs.changePickTipsVisible(2, true), this.cardsTs.playArrowAnim(RummyCardConstant.arrowAnimType.mopai, false)) : (this.rummyLogicProcessing.send_pick_card_request(0), s.cur_seat == s.clientSeatId && this.playerTs.stopPlayerTimer()) : this.tipTs.changePickTipsVisible(1, true);
                }
                break;
            case "qipai":
                1 == s.isInGameing && (s.isClientToPlay ? 14 == this.cardsTs.cardViewVec.length ? (this.tipTs.changePickTipsVisible(2, true), this.cardsTs.playArrowAnim(RummyCardConstant.arrowAnimType.mopai, false)) : (this.rummyLogicProcessing.send_pick_card_request(1), s.cur_seat == s.clientSeatId && this.playerTs.stopPlayerTimer(), s.able_local_discard && !s.bHasLocalPickUp && (s.bHasLocalPickUp = true, this.cardsTs.getLocalMoPai(0, s.dc_card, s.cardInfoModelVec), TweenTool.delayAct(this.time_node, (() => {
                    RummyDataManager.shared().rummyInfos.get(this.tid_key).bHasLocalPickUp && (RummyDataManager.shared().rummyInfos.get(this.tid_key).bHasLocalPickUp = false, gameNetworkDelay.shared().isShowNetworkDelay(true), this.cardsTs.resetQiPaiDui(), this.cardsTs.resetMyShouPai());
                }), 2, true))) : this.tipTs.changePickTipsVisible(1, true));
                break;
            case "start":
                this.onGameOverStartBtnClick();
                break;
            case "up":
                this.onGameOverUpBtnClick();
                break;
            case "gameover_treasure_hunt":
                if (sys.isObjectValid(this.treahuntTaskData.end_task) && 0 == Number(this.treahuntTaskData.end_task) && 1 == Number(this.treahuntTaskData.show_box)) {
                    this.onDealTreasureHuntBoxReward();
                }
                else {
                    let e = { vid: RummyDataManager.shared().rummyInfos.get(this.tid_key).vid, player: RummyDataManager.shared().rummyInfos.get(this.tid_key).pnum };
                    sys.isObjectValid(this.treahuntTaskData) && sys.isObjectValid(this.treahuntTaskData.up_venue) && sys.isObjectValid(this.treahuntTaskData.up_venue.vid) && (e.vid = this.treahuntTaskData.up_venue.vid);
                    let t = PushEvent.JUMP_TO_TREASURE_HUNT;
                    1 == RummyDataManager.shared().rummyInfos.get(this.tid_key).crashModel && (t = PushEvent.JUMP_TO_CHIP_TREASURE_HUNT);
                    Utils.shared().doJumpLogic(t, e, { isNext: false, bWithTip: true, link_id: sys.now(), reportEvtId: 4, reportScene: 2 });
                }
                break;
            case "treasure_hunt":
                if (1 == RummyDataManager.shared().rummyInfos.get(this.tid_key).show_box_act97) {
                    this.onDealTreasureHuntBoxReward();
                }
                else {
                    let e = { vid: RummyDataManager.shared().rummyInfos.get(this.tid_key).vid, player: RummyDataManager.shared().rummyInfos.get(this.tid_key).pnum }, t = PushEvent.JUMP_TO_TREASURE_HUNT;
                    1 == RummyDataManager.shared().rummyInfos.get(this.tid_key).crashModel && (t = PushEvent.JUMP_TO_CHIP_TREASURE_HUNT);
                    Utils.shared().doJumpLogic(t, e, { isNext: false, bWithTip: true, link_id: sys.now(), reportEvtId: 4, reportScene: 2 });
                }
                break;
            case "treahunt_box":
                this.onDealTreasureHuntBoxReward();
                break;
            case "gullak_gameover":
            case "gullak":
                {
                    let t = { vid: RummyDataManager.shared().rummyInfos.get(this.tid_key).vid, player: RummyDataManager.shared().rummyInfos.get(this.tid_key).pnum, parent_node: this.pop_layer3 };
                    RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType != RUMMY_GAME_TYPE.POOL && RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType != RUMMY_GAME_TYPE.DEALS && RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType != RUMMY_GAME_TYPE.PRI_POOL && RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType != RUMMY_GAME_TYPE.PRI_DEAL || (t.parent_node = this.pop_layer4);
                    Utils.shared().doJumpLogic(PushEvent.JUMP_TO_Gullak, t, { isNext: false, bWithTip: true, link_id: sys.now(), reportEvtId: 4, reportScene: 2 });
                    "gullak" == e ? User.shared().updatePayScene(PhpReportDefined.pay_scene.game_desktop, RummyDataManager.shared().rummyInfos.get(this.tid_key).vid) : User.shared().updatePayScene(PhpReportDefined.pay_scene.game_gameover, RummyDataManager.shared().rummyInfos.get(this.tid_key).vid);
                }
                break;
            case "exit":
                if (!RummyDataManager.shared().rummyInfos.has(this.tid_key)) {
                    return void this.backToHall();
                }
                s.gameRummyType != RUMMY_GAME_TYPE.POINTS && s.gameRummyType != RUMMY_GAME_TYPE.MULTIPLE || this.gameOverOpenLogic.resetGameOverUI(), this.onDealExitGame();
                break;
            case "points_end_guide":
                HttpManager.shared().doReportPlayerGuideAct(PhpReportDefined.roomPlayerGuideEvent.gameOverTip), this.jumpToNewPlayerGuide();
                break;
            case "points_end_tip_guide":
                this.showGuideTips((() => {
                    this.onDealBtnAction("start");
                }));
                break;
            case "pool_game_all_end":
                this.show_pool_all_end();
                break;
            case "gameover_switch":
            case "yes":
                if (!RummyDataManager.shared().rummyInfos.has(this.tid_key)) {
                    return void this.backToHall();
                }
                if (s.gameRummyType == RUMMY_GAME_TYPE.POOL) {
                    this._bIsShowWaitDeclare = false;
                    this.tipTs.hideWinEffect();
                    this.gameOverOpenLogic.resetGameOverUI();
                    for (let e = 1; e < 6; e++) {
                        this.playerTs.hidePlayer(e);
                    }
                }
                this.switchRoom();
                break;
            case "ok":
                if (this.show_pool_all_end(), s.gameRummyType == RUMMY_GAME_TYPE.POOL || s.gameRummyType == RUMMY_GAME_TYPE.PRI_POOL) {
                    0 == s.crashModel && User.shared().data.money < s.entry_fee || this.removeGameOverView();
                    this.onGameEndViewClosed();
                    RummyDataManager.shared().send_request_close_finish_alert(this.tid_key);
                }
                else if (s.gameRummyType == RUMMY_GAME_TYPE.DEALS || s.gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL) {
                    this.onGameEndViewClosed();
                    RummyDataManager.shared().send_request_close_finish_alert(this.tid_key);
                }
                else if (s.gameRummyType == RUMMY_GAME_TYPE.MATCH && (this.onGameEndViewClosed(), this.checkIsPointsMatch())) {
                    if (this.rummyLogicProcessing.send_request_match_close_game_end(), sys.isObjectValid(this.matchTotalSettleMsg)) {
                        return void this.showMatchOverView(this.matchTotalSettleMsg);
                    }
                    this.switchRoom();
                }
                break;
            case "private_close":
                s.gameRummyType == RUMMY_GAME_TYPE.PRIVATE && this.checkReadyBtn(), this.onGameEndViewClosed(), this.show_pool_all_end(), s.gameRummyType == RUMMY_GAME_TYPE.POOL || s.gameRummyType == RUMMY_GAME_TYPE.PRI_POOL ? 0 == s.crashModel && User.shared().data.money < s.entry_fee || this.removeGameOverView() : s.gameRummyType != RUMMY_GAME_TYPE.DEALS && s.gameRummyType != RUMMY_GAME_TYPE.PRI_DEAL || this.showGameStartCountDown();
                break;
            case "finish_no":
                this.tipTs.show_finish_tip(false), this.actionTs.changeDiscardBtnStatus(false), this.actionTs.changeFinishBtnStatus(false), this.actionTs.changeAutoGroupBtnStatus(true), s.hasChupai = false, this.cardsTs.resetMyShouPai(), this.finishType = -1;
                break;
            case "finish_yes":
                this.rummyLogicProcessing.send_pre_decard_request(), this.tipTs.show_finish_tip(false);
                break;
            case "hupai_declare":
                this.rummyLogicProcessing.send_decard_card_request(), this.tipTs.show_hupai_tip(false);
                break;
            case "tuoguan_back":
                this.rummyLogicProcessing.send_cancel_auto_play(), this.tipTs.changeTuoguanVisible(false);
                break;
            case "wait_declare_btn":
                if (ToolUtils.isObjValid(this.gameEndView)) {
                    if (s.gameRummyType === RUMMY_GAME_TYPE.MATCH) {
                        let e = this.gameEndView.getComponent("RummyPointsMatchOverAlert");
                        e.updateInfo(0, this._gameOverMsg, this.onDealBtnAction.bind(this), this._bIsGameEnd);
                        e.isShowEndView(true);
                    }
                    else {
                        let e = this.gameEndView.getComponent("RummyGameOverAlert");
                        e.updateInfo(0, this._gameOverMsg, this.onDealBtnAction.bind(this), this._bIsGameEnd);
                        e.isShowEndView(true);
                    }
                }
                else {
                    this.gameOverOpenLogic.showEndView(this.tid_key);
                }
                break;
            case "auto_drop":
                if (s.gameRummyType == RUMMY_GAME_TYPE.MATCH && !s.auto_drop_type) {
                    this.showTournamentDropConfirmation(true);
                    break;
                }
                if (0 != s.auto_drop_type) {
                    return void this.autoDropTs.handler_auto_drop_request(this.tid_key, 0);
                }
                let h = 0;
                for (let e = 0; e < 6; e++) {
                    let t = s.playerModels[e];
                    1 != t.betting && 4 != t.status || (h += 1);
                }
                if ((s.gameRummyType == RUMMY_GAME_TYPE.POINTS || s.gameRummyType == RUMMY_GAME_TYPE.MULTIPLE || this.checkIsPointsMatch()) && h > 2) {
                    if (this.checkIsPointsMatch() && s.user_round == s.max_round) {
                        return void this.rummyLogicProcessing.handler_logout_request(0, 2);
                    }
                    let e = i18nMgr.shared().getValueByKey("rummy_main.yes"), t = i18nMgr.shared().getValueByKey("rummy_main.drop_go"), i = i18nMgr.shared().getValueByKey("rummy_main.drop_text");
                    this.autoDropTs.showDropNode(this.tid_key, i, 1, e, t, 1);
                }
                else {
                    s.gameRummyType == RUMMY_GAME_TYPE.POOL || s.gameRummyType == RUMMY_GAME_TYPE.PRI_POOL ? this.rummyLogicProcessing.send_drop_card_is_eliminate(2) : this.autoDropTs.handler_auto_drop_request(this.tid_key, 1);
                }
                break;
            case "sort":
                this.rummyLogicProcessing.send_sort_cards_request();
                break;
            case "auto_group":
                this.rummyLogicProcessing.toggleAutoGroup(true);
                break;
            case "auto_group_long":
                this.rummyLogicProcessing.toggleAutoGroup(false);
                break;
            case "auto_group_check":
                let _ = this.actionTs.isAutoGroupTipsCheck();
                this.actionTs.changeAutoGroupTipsStatus(true, !_);
                break;
            case "refresh":
                if (s.is_table_change_status) {
                    return;
                }
                if (!this._bIsCanFresh) {
                    return;
                }
                this._bIsCanFresh = false;
                let m = ToolUtils.deskInfos.get(User.shared().curTid_key);
                1 === User.shared().daily_task && 0 === User.shared().temp_pingbi.dailytask && this.tid_key !== CommDefine.NewerGuideRoomTidkey && User.shared().getRoomRoomInfo(m.vid, PushEvent.JUMP_TO_DAILYTASK), Utils.shared().showLoading(10, false), this.rummyLogicProcessing.send_login_request(), this.scheduleOnce((() => {
                    this._bIsCanFresh = true;
                }), 3);
                break;
            case "practice_exit":
                this.exitCallBack(1), this.gameOverOpenLogic.resetGameOverUI();
                for (let e = 0; e < 6; e++) {
                    this.playerTs.hidePlayer(e);
                }
                this.onGameEndViewClosed(), this.removeTotalSettlementView();
                break;
            case "guide_cancel":
                ToolUtils.isObjValid(this.gameEndView) || 2 != s.dropType || this.switchRoom(5);
                break;
            case "gameOverAlertDestroy":
                this.onGameEndViewClosed();
                s.gameRummyType != RUMMY_GAME_TYPE.POOL && s.gameRummyType != RUMMY_GAME_TYPE.PRI_POOL && s.gameRummyType != RUMMY_GAME_TYPE.DEALS && s.gameRummyType != RUMMY_GAME_TYPE.PRI_DEAL || RummyDataManager.shared().send_request_close_finish_alert(this.tid_key);
                break;
            case "cleanGameEndPointer":
                this.gameEndView = null;
                break;
            case "dealsRummyPrize":
                this.tableRoot.getChildByName("delalsRummy6Player").active ? this.isShowDealsPize(false) : this.isShowDealsPize(true);
                break;
            case "dealsRummyPrizePinbi":
                this.isShowDealsPize(false);
                break;
            case "pool_total_history":
                this.rummyShowTopUiLogic.showDealPoolRecord({}, false), this.rummyLogicProcessing.send_get_record_request();
                break;
            case "private_start":
                this.rummyLogicProcessing.send_private_player_start_game(s.clientSeatId);
                break;
            case "private_ready":
            case "end_ready":
                this.onGameOverReadyBtnClick(e);
                break;
            case "private_gameOver_self_closed":
                this._bGameOverClosed = true, s.gameRummyType != RUMMY_GAME_TYPE.PRIVATE && s.gameRummyType != RUMMY_GAME_TYPE.PRI_POOL && s.gameRummyType != RUMMY_GAME_TYPE.PRI_DEAL || this.checkReadyBtn(), this.onGameEndViewClosed(), s.gameRummyType != RUMMY_GAME_TYPE.PRI_POOL && s.gameRummyType != RUMMY_GAME_TYPE.POOL && s.gameRummyType != RUMMY_GAME_TYPE.DEALS && s.gameRummyType != RUMMY_GAME_TYPE.PRI_DEAL && s.gameRummyType != RUMMY_GAME_TYPE.POINTS && s.gameRummyType != RUMMY_GAME_TYPE.MULTIPLE || RummyDataManager.shared().send_request_close_finish_alert(this.tid_key);
                break;
            case "private_copy":
                let y = s.roomNum;
                null != y && y.length > 0 && (TransferPlatform.shared().copyContent(y), Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text33"), 2, 0, ToolUtils.getIsNormalDirection()));
                break;
            case "private_invite":
                let u = s.roomNum;
                HttpManager.shared().doGetShareUrl(s.gameRummyType, u, ((e, t, s) => {
                    if (200 != s) {
                        Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 1.5, 0, ToolUtils.getIsNormalDirection());
                    }
                    else {
                        let e = ToolUtils.parseJson(t);
                        e && 0 === e.ret && null != e.data && null != e.data && null != e.data.share_url && null != e.data.share_url && TransferPlatform.shared().shareWebPage(e.data.share_url);
                    }
                }));
                break;
            case "match_rank":
                this.matchRankCurPage = 1, this.rummyLogicProcessing.handler_server_rank_info_request(this.matchRankCurPage);
                break;
            case "match_tips":
                if (this.checkHasMatchJoinTips()) {
                    let e = this.tipTs.getMatchJoinTipsActive();
                    s.race_tipsTime = e ? 0 : 10;
                    this.tipTs.changeMatchJoinTipsActive(!e);
                }
                else if (this.hasFreeMatchPush) {
                    let e = this.tipTs.getFreeMatchPushActive();
                    TweenTool.stopAction(this.delayFreeMatchAct);
                    this.tipTs.setFreeMatchPushActive(!e);
                }
                break;
            case "over_rank":
                this.showMatchRankInfoView();
                break;
            case "split_prize":
                this.rummyLogicProcessing.send_split_prize_request();
                break;
            case "match_level":
                if (s.gameRummyType === RUMMY_GAME_TYPE.MATCH && s.gameMatchType == RUMMY_MATCH_TYPE.BASEMONEYUP) {
                    this.tipTs.getMatchLevelActive() ? this.tipTs.setMatchLevelActive(false) : this.tipTs.setMatchLevelActive(true, s.levels_info, s.cur_level);
                }
                break;
            case "close_match_level":
                this.tipTs.getMatchLevelActive() && this.tipTs.setMatchLevelActive(false);
                break;
            case "gameover_rejoin":
                if (ToolUtils.isObjValid(this.gameEndView) && RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType != RUMMY_GAME_TYPE.MATCH) {
                    let e = this.gameEndView.getComponent(RummyGameOverAlert).poolRejoinMoney, t = this.gameEndView.getComponent(RummyGameOverAlert).poolRejoinScore, s = this.gameEndView.getComponent(RummyGameOverAlert).startTime - 1;
                    this.removeGameOverView();
                    this.rummyShowTopUiLogic.showPoolRejoin(e, t, s);
                }
                break;
            case "manula_auto_rejoin":
                if (ToolUtils.isObjValid(this.gameEndView) && RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType != RUMMY_GAME_TYPE.MATCH) {
                    let e = this.gameEndView.getComponent(RummyGameOverAlert).poolRejoinMoney, t = this.gameEndView.getComponent(RummyGameOverAlert).poolRejoinScore, s = this.gameEndView.getComponent(RummyGameOverAlert).startTime - 1;
                    this.rummyShowTopUiLogic.showPoolRejoin(e, t, s);
                }
                break;
            case "gameover_cencel":
                this.rummyLogicProcessing.send_regoin_out_request(), s.gameRummyType === RUMMY_GAME_TYPE.POOL ? ToolUtils.isObjValid(this.gameEndView) && this.gameEndView.getComponent(RummyGameOverAlert).showYesOrNobtn() : (this.removeGameOverView(), ToolUtils.isObjValid(this.gameHistoryView) && this.gameHistoryView.destroy());
                break;
            case "auto_switch":
                this.rummyLogicProcessing.handler_logout_request(1);
                break;
            case "prizeInfo":
                this.tipTs.showPoolJackPot(true), 1 == this.top_bg_hongdian && this.hide_table_top_info_hongdian();
                break;
            case "prizeInfo_close":
                this.tipTs.showPoolJackPot(false);
                break;
            case "no":
                RummyDataManager.shared().send_request_close_out_ui(this.tid_key), this.removeGameOverView(), s.gameRummyType === RUMMY_GAME_TYPE.POOL && (s.hasSendCloseOut = true, RummyDataManager.shared().stopTweenAction(this.delayShowGameOver_action), this.delayShowGameOver_action = null, this.tipTs.getIsManulaSwitchShow() && this.actionTs.changeSwitchBtnStatus(true), PushCenter.shared().pushEvent(GameConfig.Update_Menu_Switch_Status, { tid_key: this.tid_key, bEnable: true }));
                break;
            case "add":
                if (1 == s.crashModel) {
                    let e = { vid: s.vid, isShowTip: true, parent_node: this.node, bShowNetTip: true, tid_key: this.tid_key, min_entry: s.entry_fee, in_room: 1 };
                    Utils.shared().showQuickChipRecharge(e);
                }
                else {
                    let e = false;
                    User.shared().data.money < s.entry_fee && (e = true);
                    Utils.shared().showQuickRecharge(s.vid, this.node, e, this.tid_key, 0, s.entry_fee);
                    User.shared().updatePayScene(PhpReportDefined.pay_scene.game_selectroom_less_money, Number(s.vid));
                }
                break;
            case "guesscard": break;
            case "chat":
                RummyDataManager.shared().reportCommClickEvent(this.tid_key, ReportConfig.func.emoji, ReportConfig.cash_evt.click_emoji), this.rummyShowTopUiLogic.showChatAlert();
                break;
            case "roomInfo":
                this.showRummyRoomInfoView();
                break;
            case "view_final_score":
                this.rummyLogicProcessing.send_last_card_request(1);
                break;
            case "points_time_out":
                this.gameOverOpenLogic.resetGameOverUI();
                break;
            case "security":
                this.rummyShowTopUiLogic.showSecurityFeaturesView();
                break;
            case "openWinTips":
                this.rummyShowTopUiLogic.showWinConditionTips();
                break;
            case "winTipsGou":
                this.rummyShowTopUiLogic.dealWinTipsGou();
                break;
            case "ceshiceshi":
                this.ceshiceshi();
                break;
            case "tingpai":
                if (sys.isObjectValid(this.pickCardInfo) && 0 != this.pickCardInfo.helper_pick_label) {
                    let e = this.tingPaiTs.pickBubbleNode.active;
                    e = !e;
                    this.tingPaiTs.showpickBubbleView(e, this.pickCardInfo);
                    this.tingPaiTs.changeTingpaiIconStatue(e);
                    this.cardsTs.restoreTingPaiTips();
                }
                else {
                    let e = this.tingPaiTs.bubbleNode.active;
                    e = !e;
                    RummyDataManager.shared().getCanShowTingPai() || (e = false);
                    this.tingPaiMsg && this.tingPaiMsg.listen_info && Array.isArray(this.tingPaiMsg.listen_info) || (e = false);
                    e ? this.tingPaiTs.showTingPaiInfo(this.tingPaiMsg, this.cardsTs) : this.cardsTs.restoreTingPaiTips();
                    this.tingPaiTs.changeTingPaiBubbleVisible(e);
                    this.tingPaiTs.showpickBubbleView(false);
                    e && this.tipTs.changePickTipsVisible(0, false);
                }
                break;
            case "quickfinish_cancle":
                this.rummyLogicProcessing.handler_server_quick_finish_cancel_request(), this.tipTs.showQuickFinishTips(false), this.cardsTs.resetMyCardsPostion();
                break;
            case "quickfinish_finsh":
                if (!this._bIsCanFinish) {
                    return;
                }
                this.tipTs.showQuickFinishTips(false), sys.isObjectValid(this.finish_groups) && 1 == this.quick_sort && this.refreshMyQuickFinishShouPai(this.finish_groups, s);
                let p = this.cardsTs.getQuickHuCard(this.helper_hu_card), g = {};
                if (ToolUtils.isObjValid(p)) {
                    let e = p.getComponent("RummyCard");
                    g.card = e.mCardValue;
                    g.index = e.groupIndex;
                    g.cardIndex = e.cardIndex;
                    g.isQipai = false;
                    g.is_quick = 1;
                    this.qipaiCardValues[this.qipaiCardValues.length] = e.mCardValue;
                }
                else {
                    g = null;
                }
                this.finishType = 1, this.dealLocalDisCardCard(g), s.able_local_discard || this.handler_server_declare_check_request(1, g), this._bIsCanFinish = false, TweenTool.delayAct(this.time_node, (() => {
                    this._bIsCanFinish = true;
                }), 1, true);
                break;
            case "show_rating":
                this.tipTs.showRatingDetail(true, true);
                break;
            case "hide_rating":
                this.tipTs.showRatingDetail(false, true);
                break;
            case "easy_help":
                {
                    let e = { isHelp: true, parent_node: this.pop_layer4 };
                    Utils.shared().showEasyGameTypeAlert(e, (e => {
                    }));
                }
                break;
            case "leader_boards":
                {
                    let e = { vid: RummyDataManager.shared().rummyInfos.get(this.tid_key).vid, tid_key: this.tid_key };
                    this.rummyShowTopUiLogic.showRoomActRank(e);
                }
                break;
            case "multipleHelp":
                {
                    let e = { isHelp: true, parent_node: this.pop_layer4 };
                    s.is_multiple ? Utils.shared().showMultipleGameTypeAlert(e, (e => {
                    })) : s.is_double && Utils.shared().showDoubleRummyTypeAlert(e, (e => {
                    }));
                }
                break;
            case "multipleTip": break;
            case "switch_skin":
                PushCenter.shared().pushEvent(PushEvent.UpdateRaceCSS), this.tipTs.showSwitchSkinTips(false), PushCenter.shared().pushEvent(PushEvent.HideSwitchGameSkinTips), User.shared().requestSwitchExclusiveSkin();
                break;
            case "switch_skin_close":
                this.tipTs.showSwitchSkinTips(false), PushCenter.shared().pushEvent(PushEvent.HideSwitchGameSkinTips);
                break;
            case "multipleCenterTip":
                this.tipTs.setMultipleCenterTipsShow(true);
                break;
            case "match_reward":
                this.actionTs.getRaceRewardVisible() ? this.actionTs.changeRaceRewardDiVisible(false) : (this.actionTs.changeRaceRewardDiVisible(true), this.checkIsPointsMatch() ? this.rummyLogicProcessing.send_request_score_rank_info() : (this.matchRankCurPage = 1, this.rummyLogicProcessing.handler_server_rank_info_request(this.matchRankCurPage)));
                break;
            case "raceRewardClose":
                this.actionTs.changeRaceRewardDiVisible(false);
                break;
            case "free_match_join":
                if (!User.shared().checkCanPlayCashGame(CheckModule.CASH_PLAY)) {
                    return;
                }
                if (1 == Utils.shared().showFastKyc()) {
                    return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("kyc.kyc_match"), 2);
                }
                this.tipTs.setFreeMatchPushActive(false), User.shared().sendJoinMatch({ raceid: this.freeMatchRaceId });
                break;
            case "match_points_rank":
                this.actionTs.changeRaceRewardTab(0);
                break;
            case "match_points_reward":
                this.actionTs.changeRaceRewardTab(1);
                break;
            case "flopcash":
                this.actionTs.updateFlopCashBannerStatus();
                break;
            case "selectJoker":
                this.rummyLogicProcessing.send_all_choose_joker_request();
                break;
            case "changeJoker":
                this.rummyLogicProcessing.send_switch_joker_request(t, RummyDataManager.shared().rummyInfos.get(this.tid_key).laizicard);
                break;
            case "chooseJoker":
                this.rummyLogicProcessing.send_choose_joker_request(t);
                break;
            case "best_laizi":
                let b = RummyDataManager.shared().rummyInfos.get(this.tid_key).best_lz;
                this.rummyLogicProcessing.send_switch_joker_request(b, RummyDataManager.shared().rummyInfos.get(this.tid_key).laizicard);
                break;
            case "treasurehunt_upbtn":
                if (User.shared().data.money_exe < this.treahuntTaskData.up_venue.entry_fee) {
                    let e = { vid: this.treahuntTaskData.up_venue.vid, isShowTip: true, parent_node: director.getScene().getChildByName("Canvas"), bShowNetTip: true, tid_key: User.shared().curTid_key, min_entry: this.treahuntTaskData.up_venue.entry_fee, in_room: 1 };
                    Utils.shared().showQuickChipRecharge(e);
                }
                else {
                    this.onGameOverUpBtnClick(false, this.treahuntTaskData.up_venue.vid);
                }
                break;
            case "practice_to_cash":
                let C = User.shared().checkRoomCanPlayCashGame(CheckModule.CASH_PLAY, false);
                if (C < 2) {
                    if (0 == C) {
                        let e = 0 == GameConfig.GAME_APP_THEME ? CommDefine.AppName_rummy : CommDefine.AppName_circ;
                        Utils.shared().showToast(ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_main.band_cash_game_tip"), e), 5);
                    }
                    return;
                }
                if (User.shared().data.money < s.tf_venue.entry_fee) {
                    let e = false;
                    return User.shared().data.money < s.tf_venue.entry_fee && (e = true), Utils.shared().showQuickRecharge(s.tf_venue.vid, this.node, e, this.tid_key, 0, s.tf_venue.entry_fee), void User.shared().updatePayScene(PhpReportDefined.pay_scene.game_selectroom_less_money, Number(s.tf_venue.vid));
                }
                this.removeGameOverView(), this.removeTotalSettlementView(), this.rummyLogicProcessing.send_practice_to_cash_request(), this.onGameOverUpBtnClick(true);
                break;
            case "continue":
                s && s.force_up_venue_tips_end && User.shared().showCashGameUpAlert(s.force_up_venue_tips_end.base_money, (e => {
                    1 == e ? this.switchRoom(-2, s.force_up_venue_tips_end.vid) : this.onGameOverStartBtnClick();
                }), PhpReportDefined.scece.cash_room_gameover);
                break;
            case "cash_up_play":
                s.force_up_venue && this.switchRoom(-2, ToolUtils.isSafeNumber(s.force_up_venue.vid));
                break;
            case "reject_up": break;
            case "show_quick":
                this.dealShowQuickLogic(), User.shared().updatePayScene(PhpReportDefined.pay_scene.game_gameover, RummyDataManager.shared().rummyInfos.get(this.tid_key).vid);
                break;
            case "close_available_cards":
                this.tipTs.setAvailableCardTipsVisible(false), this.cardsTs.setAvailableCardTipsClose();
                break;
            case "doubleHelp":
                {
                    let e = { isHelp: true, parent_node: this.pop_layer4 };
                    Utils.shared().showDoubleRummyTypeAlert(e, (e => {
                    }));
                }
                break;
            case "double0":
                this.rummyLogicProcessing.send_request_choose_double(0);
                break;
            case "double2":
                this.rummyLogicProcessing.send_request_choose_double(2);
                break;
            case "double1":
                this.rummyLogicProcessing.send_request_choose_double(1);
                break;
            case "manula_rejoin": return void this.rummyLogicProcessing.send_request_manula_rejoin(t);
        }
    }
    dealShowQuickLogic() {
        let e = RummyDataManager.shared().rummyInfos.get(this.tid_key);
        if (1 == e.crashModel) {
            let t = { vid: e.vid, isShowTip: true, parent_node: this.node, bShowNetTip: true, tid_key: this.tid_key, min_entry: e.entry_fee, in_room: 1, auto_quick: 1 };
            Utils.shared().showQuickChipRecharge(t);
        }
        else {
            let t = false;
            User.shared().data.money < e.entry_fee && (t = true);
            Utils.shared().showQuickRecharge(e.vid, this.node, t, this.tid_key, 0, e.entry_fee, true, 0, 0, 1);
        }
    }
    onDealTreasureHuntBoxReward() {
        let e = RummyDataManager.shared().rummyInfos.get(this.tid_key).vid, t = RummyDataManager.shared().rummyInfos.get(this.tid_key).pnum;
        HttpManager.shared().doGetCommonRequest({ vid: e, player: t }, HttpRequest.GetTreaHuntRank_REWARD_CHIP, ((t, s, i) => {
            if (200 != i) {
                ;
            }
            else {
                let t = ToolUtils.parseJson(s);
                if (0 == t.ret && ToolUtils.isObjValid(this.node)) {
                    if (sys.isObjectValid(t.data.reward_list) && Array.isArray(t.data.reward_list) && t.data.reward_list.length > 0) {
                        User.shared().showChargeReward(t.data.reward_list, (e => {
                        }), t.data.msg);
                        let s = 0, i = 0;
                        sys.isObjectValid(t.data.show_box) && (s = Number(t.data.show_box));
                        sys.isObjectValid(t.data.box_type) && (i = Number(t.data.box_type));
                        RummyDataManager.shared().rummyInfos.get(this.tid_key).show_box_act97 = s;
                        RummyDataManager.shared().rummyInfos.get(this.tid_key).box_type_act97 = i;
                        this.actionTs.updateTreasureHuntBox(s, i);
                        let a = { vid: e, show_box: s, box_type: i, data: t.data, pnum: RummyDataManager.shared().rummyInfos.get(this.tid_key).pnum, gameBaseMoney: RummyDataManager.shared().rummyInfos.get(this.tid_key).gameBaseMoney };
                        this.treahuntTaskData = t.data;
                        RummyDataManager.shared().rummyInfos.get(this.tid_key).act97_data = this.treahuntTaskData;
                        PushCenter.shared().pushEvent(PushEvent.UpdateTreaBoxStateInGame, a);
                        this.actionTs.updateTreasureHuntBtn(1, this.treahuntTaskData);
                    }
                    else if (sys.isObjectValid(t.data.show_box)) {
                        RummyDataManager.shared().rummyInfos.get(this.tid_key).show_box_act97 = Number(t.data.show_box);
                        RummyDataManager.shared().rummyInfos.get(this.tid_key).box_type_act97 = Number(t.data.box_type);
                        this.actionTs.updateTreasureHuntBox(Number(t.data.show_box), Number(t.data.box_type));
                        let s = { vid: e, show_box: Number(t.data.show_box), box_type: Number(t.data.box_type), data: t.data, pnum: RummyDataManager.shared().rummyInfos.get(this.tid_key).pnum, gameBaseMoney: RummyDataManager.shared().rummyInfos.get(this.tid_key).gameBaseMoney };
                        RummyDataManager.shared().rummyInfos.get(this.tid_key).act97_data = t.data;
                        this.treahuntTaskData = t.data;
                        this.actionTs.updateTreasureHuntBtn(1, this.treahuntTaskData);
                        PushCenter.shared().pushEvent(PushEvent.UpdateTreaBoxStateInGame, s);
                    }
                }
            }
        }));
    }
    removeGameOverView() {
        ToolUtils.isObjValid(this.gameEndView) && (this.gameEndView.destroy(), this.gameEndView = null);
    }
    removeTotalSettlementView() {
        ToolUtils.isObjValid(this.RummyTotalSettlementNode) && (this.RummyTotalSettlementNode.destroy(), this.RummyTotalSettlementNode = null);
    }
    deleteGameOverDalay() {
        RummyDataManager.shared().stopTweenAction(this.delayShowGameOver_action);
        this.delayShowGameOver_action = null;
        RummyDataManager.shared().stopTweenAction(this.switch_tab_action);
        this.switch_tab_action = null;
    }
    refreshMyQuickFinishShouPai(e, t) {
        t.cardInfoModelVec = [];
        for (let s = 0, i = e.length; s < i; s++) {
            const i = e[s];
            let a = [];
            a.type = i.type;
            a.index = i.index;
            a.score = i.score;
            a.desc = i.desc;
            a.color = i.color;
            a.isShowAnime = i.isShowAnime;
            a.isCatchGroup = i.is_lastcatch_index;
            a.catchIndex = i.catch_card_index;
            let r = [];
            if (i.cards) {
                for (let e = 0, t = i.cards.length; e < t; e++) {
                    r.push(i.cards[e]);
                }
            }
            a.cardVec = r;
            t.cardInfoModelVec.push(a);
        }
        this.cardsTs.beginFaPaiWithoutAnim(t.cardInfoModelVec, t.cardInfoModelVec.length);
    }
    onGameOverUpBtnClick(e = false, t) {
        if (!RummyDataManager.shared().rummyInfos.has(this.tid_key)) {
            return this.removeGameOverView(), void this.backToHall();
        }
        let s = RummyDataManager.shared().rummyInfos.get(this.tid_key);
        if (s.gameRummyType == RUMMY_GAME_TYPE.POINTS || s.gameRummyType == RUMMY_GAME_TYPE.MULTIPLE || this.checkIsPointsMatch()) {
            this._bIsShowWaitDeclare = false;
            this.gameOverOpenLogic.resetGameOverUI();
            for (let e = 1; e < 6; e++) {
                this.playerTs.hidePlayer(e);
            }
        }
        if (this.onGameEndViewClosed(), 0 == s.crashModel ? User.shared().data.money >= this.upvenue_entry_fee && this.removeTotalSettlementView() : User.shared().data.money_exe >= s.entry_fee && this.removeGameOverView(), !e) {
            if (s.isCanExit = true, s.gameRummyType == RUMMY_GAME_TYPE.PRIVATE || s.gameRummyType == RUMMY_GAME_TYPE.PRI_POOL || s.gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL) {
                this.playerTs.showLoseScore(0, 0, true);
                this.onDealBtnAction("end_ready");
            }
            else {
                if (User.shared().isGameDisconnectServer) {
                    return Server.shared().disconnectWebSocket(), this.isNewTable = 0, void this.login();
                }
                if ((s.gameRummyType == RUMMY_GAME_TYPE.POOL || s.gameRummyType == RUMMY_GAME_TYPE.DEALS || s.gameRummyType == RUMMY_GAME_TYPE.PRI_POOL || s.gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL) && ToolUtils.isObjValid(this.gameEndView)) {
                    this.gameEndView.getComponent(RummyGameOverAlert).getPoolRummyIsEnd() || this.showGameStartCountDown();
                }
                if (this.isDisconnect) {
                    return this.isDisconnect = false, s.isGameOver = false, void (ToolUtils.deskInfos.size <= 1 ? User.shared().curTid_key == this.tid_key && (Server.shared().disconnectWebSocket(), this.isNewTable = 0, this.login()) : this.rummyLogicProcessing.send_login_request());
                }
                s.isGameOver = false;
                Server.shared().checkPauseState() ? s.gameRummyType != RUMMY_GAME_TYPE.MATCH ? this.switchRoom(-2, t) : this.checkIsPointsMatch() && this.switchRoom(-2) : (s.bIsSwitchRoom = true, Server.shared().resumeWS());
            }
        }
    }
    onGameOverStartBtnClick() {
        if (!RummyDataManager.shared().rummyInfos.has(this.tid_key)) {
            return this.removeGameOverView(), void this.backToHall();
        }
        let e = RummyDataManager.shared().rummyInfos.get(this.tid_key);
        if (e.gameRummyType == RUMMY_GAME_TYPE.POINTS || e.gameRummyType == RUMMY_GAME_TYPE.MULTIPLE || this.checkIsPointsMatch()) {
            this._bIsShowWaitDeclare = false;
            this.gameOverOpenLogic.resetGameOverUI();
            for (let e = 1; e < 6; e++) {
                this.playerTs.hidePlayer(e);
            }
        }
        if (this.onGameEndViewClosed(), 0 == e.crashModel ? User.shared().data.money >= e.entry_fee && this.removeTotalSettlementView() : User.shared().data.money_exe >= e.entry_fee && this.removeGameOverView(), e.isCanExit = true, e.gameRummyType == RUMMY_GAME_TYPE.PRIVATE || e.gameRummyType == RUMMY_GAME_TYPE.PRI_POOL || e.gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL) {
            this.playerTs.showLoseScore(0, 0, true);
            this.onDealBtnAction("end_ready");
        }
        else {
            if (User.shared().isGameDisconnectServer) {
                return Server.shared().disconnectWebSocket(), this.isNewTable = 0, void this.login();
            }
            if ((e.gameRummyType == RUMMY_GAME_TYPE.POOL || e.gameRummyType == RUMMY_GAME_TYPE.DEALS || e.gameRummyType == RUMMY_GAME_TYPE.PRI_POOL || e.gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL) && ToolUtils.isObjValid(this.gameEndView)) {
                this.gameEndView.getComponent(RummyGameOverAlert).getPoolRummyIsEnd() || this.showGameStartCountDown();
            }
            if (this.isDisconnect) {
                return this.isDisconnect = false, e.isGameOver = false, void (ToolUtils.deskInfos.size <= 1 ? User.shared().curTid_key == this.tid_key && (Server.shared().disconnectWebSocket(), this.isNewTable = 0, this.login()) : this.rummyLogicProcessing.send_login_request());
            }
            e.isGameOver = false;
            Server.shared().checkPauseState() ? (e.gameRummyType != RUMMY_GAME_TYPE.MATCH || this.checkIsPointsMatch()) && this.switchRoom(5) : (e.bIsSwitchRoom = true, Server.shared().resumeWS());
        }
    }
    onGameOverReadyBtnClick(e) {
        if ("end_ready" == e && (this._bGameOverClosed = true, RummyDataManager.shared().stopTweenAction(this.delay_ready_action), this.delay_ready_action = TweenTool.myschedule(RummyDataManager.shared().sceneNode, 1, this.updateCheckReadyStatus.bind(this))), User.shared().isGameDisconnectServer) {
            return RummyDataManager.shared().stopTweenAction(this.delay_ready_action), this.delay_ready_action = null, Server.shared().disconnectWebSocket(), void this.login();
        }
        if (this.isDisconnect) {
            RummyDataManager.shared().stopTweenAction(this.delay_ready_action);
            this.delay_ready_action = null;
            this.isDisconnect = false;
            this.doConnectRequest();
        }
        else {
            let e = RummyDataManager.shared().rummyInfos.get(this.tid_key);
            e.gameRummyType == RUMMY_GAME_TYPE.PRIVATE || e.gameRummyType == RUMMY_GAME_TYPE.PRI_POOL || e.gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL ? this.rummyLogicProcessing.send_request_game_readl() : this.switchRoom(5);
            e.gameRummyType != RUMMY_GAME_TYPE.PRIVATE && e.gameRummyType != RUMMY_GAME_TYPE.PRI_POOL && e.gameRummyType != RUMMY_GAME_TYPE.PRI_DEAL && e.gameRummyType != RUMMY_GAME_TYPE.MATCH || e.roomPlayerCounter < 2 && (this.autoReadyTime = -1, e.game_state = 5);
        }
    }
    jumpToNewPlayerGuide() {
        Server.shared().send({ cmd: RummyCmd.GM_GO_TO_NEW_PLAYER_GUIDE, uid: User.shared().data.uid, tid_key: this.tid_key });
        Server.shared().send({ cmd: RummyCmd.GM_LOGINOUT_REQUEST, tid_key: this.tid_key, uid: User.shared().data.uid });
        ToolUtils.in_isGuideRoom = 2;
        PushCenter.shared().pushEvent(PushEvent.jumpToNewPlayerRoom, { table_keys: [{ tid_key: CommDefine.NewerGuideRoomTidkey, vid: 0, pnum: 2 }], cur_tidkey: this.tid_key });
    }
    restoreDisCardShouPai(e, t = true) {
        if (e.able_local_discard) {
            let s = {};
            s.card = e.playCardValue;
            s.index = e.groupIndex;
            s.cardIndex = e.card_index;
            s.isQipai = t;
            this.qipaiCardValues[this.qipaiCardValues.length] = e.playCardValue;
            this.dealLocalDisCardCard(s);
        }
        else {
            this.hasPlayOutLocalCard = true;
            this.cardsTs.hideTingPaiTips();
            TweenTool.delayAct(this.time_node, (() => {
                this.hasPlayOutLocalCard && (gameNetworkDelay.shared().isShowNetworkDelay(true), sys.isObjectValid(this.cardInfoMsg) && sys.isObjectValid(this.cardInfoMsg.cardinfos) ? this.refreshMyShouPai(this.cardInfoMsg, true, true) : this.cardsTs.resetMyShouPai(), this.hasPlayOutLocalCard = false, this.refreshTingPaiSwitch());
            }), 2, true);
        }
    }
    onTingPaiTipsActionCallback(e) {
        if (1 != User.shared().isInPerformanceRoom) {
            if (e && e.tingPai && sys.isObjectValid(e.cardCompent)) {
                let t = RummyDataManager.shared().getCanShowTingPai(), s = false, i = e.cardCompent;
                return i.mCardValue > 0 && t && this.tingPaiMsg && this.tingPaiMsg.listen_info && Array.isArray(this.tingPaiMsg.listen_info) && (this.tingPaiTs.showTingPaiInfo(this.tingPaiMsg, this.cardsTs, i.mCardValue), s = true), this.cardsTs.changeTingPaiStatus(i), s = 2 == i.tingpai_type, this.tingPaiTs.changeTingPaiBubbleVisible(s), void (s && this.tipTs.changePickTipsVisible(0, false));
            }
            if (e && sys.isObjectValid(e.check_quick) && e.check_quick && RummyDataManager.shared().getCanShowQuickFinish() && 1 == ToolUtils.isSafeNumber(this.can_declare) && 0 != this.helper_hu_card) {
                let e = RummyDataManager.shared().rummyInfos.get(this.tid_key);
                e.isCanTouchCard = false;
                1 == e.is_bump || (this.tipTs.showQuickFinishTips(true), this.playerTs.hideBonustTime());
                this.cardsTs.beginFaPaiWithoutAnim(e.cardInfoModelVec, e.cardInfoModelVec.length);
                this.cardsTs.showHelperQuickFinishCard(this.helper_hu_card, true, this.tingPaiMsg);
            }
            if (e && e.availableCardTip && ToolUtils.isObjValid(e.flagNode)) {
                if (RummyDataManager.shared().getCanShowAvailableCardTips()) {
                    let t = new Vec3;
                    if (e.flagNode.getWorldPosition(t), e.inputs) {
                        let s = { worldPos: t, tid_key: this.tid_key, data: e.inputs, groupIndex: e.groupIndex, cardIndex: e.cardIndex, cardValue: e.cardValue };
                        this.tipTs.setAvailableCardTipsVisible(true, s);
                    }
                }
            }
            else {
                ;
            }
        }
    }
    onCardActionCallBack(e, t = null) {
        let s = RummyDataManager.shared().rummyInfos.get(this.tid_key);
        if (1 != User.shared().isInPerformanceRoom) {
            switch (e = "" + e) {
                case "discard":
                    if (this.cardsTs.isOneOnlyPureCard()) {
                        let e = i18nMgr.shared().getValueByKey("utlis.text12"), t = this;
                        Utils.shared().showCommomDialog(e, "", (e => {
                            1 == e ? (t.restoreDisCardShouPai(s), t.handler_server_discard_request(0, 0)) : (s.hasChupai = false, t.cardsTs.resetMyShouPai());
                        }), true, ToolUtils.getIsNormalDirection(), null, null, null, this.pop_layer4, null, this.tid_key);
                    }
                    else {
                        this.restoreDisCardShouPai(s);
                        this.handler_server_discard_request(0, 0);
                    }
                    break;
                case "finish":
                    if (s.able_local_discard && this.checkFinishCards(s.playCardValue)) {
                        let e = {};
                        e.card = s.playCardValue;
                        e.index = s.groupIndex;
                        e.cardIndex = s.card_index;
                        e.isQipai = false;
                        this.qipaiCardValues[this.qipaiCardValues.length] = s.playCardValue;
                        this.finishType = 0;
                        this.dealLocalDisCardCard(e);
                    }
                    else {
                        this.hasPlayOutLocalCard = true;
                        this.cardsTs.hideTingPaiTips();
                        TweenTool.delayAct(this.time_node, (() => {
                            this.hasPlayOutLocalCard && (gameNetworkDelay.shared().isShowNetworkDelay(true), this.cardsTs.resetMyShouPai(), this.hasPlayOutLocalCard = false, this.refreshTingPaiSwitch());
                        }), 2, true);
                        this.handler_server_declare_check_request(0);
                    }
                    break;
                case "checkCards":
                    this.finishType = -1;
                    let i = this.cardsTs.getSelectedCards();
                    this.actionTs.changeGroupBtnStatus(false), this.actionTs.changeDiscardBtnStatus(false), this.actionTs.changeAutoGroupBtnStatus(true), this.autoDropTs.setAutoDropBtn(2), i.length >= 2 && i.length < 13 && (this.actionTs.changeGroupBtnStatus(true), this.actionTs.changeAutoGroupBtnStatus(false), this.autoDropTs.setAutoDropBtn(1)), this.cardsTs.showAutoSortBtn() && this.autoDropTs.setAutoDropBtn(1), this.actionTs.changeSortBtnStatus(this.cardsTs.showAutoSortBtn()), 14 == this.cardsTs.cardViewVec.length ? (1 == i.length ? (this.actionTs.changeDiscardBtnStatus(true), this.actionTs.changeFinishBtnStatus(true), this.actionTs.changeAutoGroupBtnStatus(false)) : (this.actionTs.changeDiscardBtnStatus(false), this.actionTs.changeFinishBtnStatus(false)), this.refreshTingPaiSwitch()) : (this.actionTs.changeDiscardBtnStatus(false), this.actionTs.changeFinishBtnStatus(false), this.tingPaiTs.changeTingPaiBubbleVisible(false), this.tingPaiTs.showpickBubbleView(false), this.cardsTs.restoreTingPaiTips()), this.cardsTs.changeAddBtnStatus(true);
                    let a = s.clientSeatId, r = s.playerModels[a];
                    (0 != r.status && 4 != r.status || 1 != r.betting) && this.actionTs.changeAutoGroupBtnStatus(false);
                    break;
                case "moveCards":
                    this.refreshTingPaiSwitch(), this.handler_server_move_card_request(0);
                    break;
                case "faPai_Over":
                    s.isClientToPlay && this.cardsTs.showMoPaiTisAnim(true, 0 == s.gameRummyMode);
                    break;
                case "reSetCards":
                    this.actionTs.changeDiscardBtnStatus(false), this.actionTs.changeFinishBtnStatus(false), this.actionTs.changeGroupBtnStatus(false);
                    let h = s.clientSeatId, o = s.playerModels[h];
                    1 != o.betting || 0 != o.status && 4 != o.status || this.actionTs.changeAutoGroupBtnStatus(true), this.autoDropTs.setAutoDropBtn(2), this.cardsTs.showAutoSortBtn() && this.autoDropTs.setAutoDropBtn(1), this.actionTs.changeSortBtnStatus(this.cardsTs.showAutoSortBtn()), this.tingPaiTs.changeTingPaiBubbleVisible(false), this.cardsTs.restoreTingPaiTips(), this.tingPaiTs.showpickBubbleView(false);
                    break;
                case "moveCardEnd":
                    RummyDataManager.shared().rummyInfos.get(this.tid_key).able_client_group && RummyDataManager.shared().rummyInfos.get(this.tid_key).isMovingCard && (RummyDataManager.shared().rummyInfos.get(this.tid_key).isMovingCard = false, this.dealGroupCardByServerMsg(this.cardInfoMsg));
                    break;
                case "freshMyCard":
                    let d = false, n = null, _ = null, c = false, m = [];
                    sys.isObjectValid(t) && (d = t.isCheckCards, n = t.catch_groupindex, _ = t.cardvalue, c = t.isShowDiscardTips, m = t.autoSortGroupIds), sys.isObjectValid(this.cardInfoMsg) && sys.isObjectValid(this.cardInfoMsg.cardinfos) && this.refreshMyCardInfos(this.cardInfoMsg), this.cardsTs.beginFaPaiWithoutAnim(RummyDataManager.shared().rummyInfos.get(this.tid_key).cardInfoModelVec, RummyDataManager.shared().rummyInfos.get(this.tid_key).cardInfoModelVec.length, d, n, _, c, m);
                    break;
                default: e.indexOf("Add_Btn") > -1 && (s.to_index = parseInt(e.substring("Add_Btn".length)), this.rummyLogicProcessing.handler_server_add_card_request(s.to_index));
            }
            s.cur_seat == s.clientSeatId && this.playerTs.stopPlayerTimer();
        }
        else {
            s.cur_seat == s.clientSeatId && this.playerTs.stopPlayerTimer();
        }
    }
    onNewPlayerGuideCallBack(e, t, s) {
        switch (e = "" + e) {
            case "wait_moPai":
            case "wait_outCard":
                RummyDataManager.shared().rummyInfos.get(User.shared().curTid_key).op_cd = 30, RummyDataManager.shared().rummyInfos.get(User.shared().curTid_key).timeout_cd = 30, this.playerTs.startPlayerTimer(1, 30);
                break;
            case "stopTimer":
                this.playerTs.stopPlayerTimer();
                break;
            case "updateMyScore":
                this.playerTs.showLoseScore(0, t, true);
                break;
            case "jumpToPracticeRoom":
                this._guideJumpPricticeReq = true, this.create_new_table(), this.actionTs.menuBtnIsViseble(true);
                break;
            case "fapai_end":
                this.playerTs.setPaiDuiBgShow(true);
                break;
            case "updateCloseNum":
                ToolUtils.isSafeNumber(t) >= 0 && (this.playerTs.updateCloseNum(ToolUtils.isSafeNumber(t)), this.playerTs.changePaiduNumVisible(true));
                break;
            case "updateOpenNum":
                ToolUtils.isSafeNumber(t) >= 0 && (this.playerTs.updateOpenNum(ToolUtils.isSafeNumber(t)), this.playerTs.changeOpenNumVisibile(true));
                break;
            case "updateRoundNum":
                ToolUtils.isSafeNumber(t) >= 0 && (this.playerTs.updateRoundNum(ToolUtils.isSafeNumber(t)), this.playerTs.changeRoundNumVisible(true), this.playerTs.updateMultipleTimes(t), this.actionTs.changeCenterFinishBtnStatus(true));
                break;
            case "hidePaiNum":
                this.playerTs.hidePaiNum();
                break;
            case "clearDesk":
                this.playerTs.hidePaiNum(), this.playerTs.resetAll(), this.cardsTs.resetView(), this.actionTs.resetAll();
                let e = { bLandscape: ToolUtils.getIsNormalDirection(), strContent: i18nMgr.shared().getValueByKey("newPlayer_guide.skip_tips"), strTitle: i18nMgr.shared().getValueByKey("gameRummy_notice_Pop.notice"), sureKey: "rummy_switch.okay", parent_node: this.pop_layer4, tid_key: this.tid_key };
                Utils.shared().showCommonAlert(e, (e => {
                    s && s();
                }));
        }
    }
    onDealExitGame(e = false) {
        let t = RummyDataManager.shared().rummyInfos.get(this.tid_key);
        if (t.gameRummyType == RUMMY_GAME_TYPE.POOL || t.gameRummyType == RUMMY_GAME_TYPE.DEALS || t.gameRummyType == RUMMY_GAME_TYPE.PRI_POOL || t.gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL || t.gameRummyType == RUMMY_GAME_TYPE.POINTS || t.gameRummyType == RUMMY_GAME_TYPE.PRIVATE || t.gameRummyType == RUMMY_GAME_TYPE.MULTIPLE) {
            if (t.is_table_change_status) {
                return;
            }
            let e = t.clientSeatId, s = t.playerModels[e];
            return void (1 == s.betting ? this.rummyLogicProcessing.handler_logout_request(0) : 9 == s.status ? this.exitCallBack(1) : 0 == t.is_game_all_end ? this.rummyLogicProcessing.handler_logout_request(0) : this.exitCallBack(1));
        }
        let s = false;
        if (t.gameRummyType == RUMMY_GAME_TYPE.PRIVATE || t.gameRummyType == RUMMY_GAME_TYPE.PRI_POOL || t.gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL || t.gameRummyType == RUMMY_GAME_TYPE.POINTS || t.gameRummyType == RUMMY_GAME_TYPE.MULTIPLE) {
            let e = t.clientSeatId, i = t.playerModels[e];
            s = !!i && !(1 == i.betting || 0 == i.betting && 4 == i.status);
        }
        if (1 != t.isInGameing || s || t.gameRummyType == RUMMY_GAME_TYPE.MATCH) {
            if (0 == t.isMatchGameOver && t.gameRummyType == RUMMY_GAME_TYPE.MATCH) {
                let s = this.pop_layer4.getChildByName("matchAlert");
                if (ToolUtils.isObjValid(s)) {
                    this.exitCallBack(1);
                }
                else if (t.gameMatchMode == RUMMY_MATCH_MODE.FULLMATCH && t.race_state < 3) {
                    this.exitCallBack(1);
                }
                else {
                    if (this.checkIsPointsMatch()) {
                        return void this.rummyLogicProcessing.handler_logout_request(0);
                    }
                    let s = i18nMgr.shared().getValueByKey("utlis.text14");
                    t.race_state > 2 && (s = i18nMgr.shared().getValueByKey("utlis.text15"));
                    let i = this;
                    Utils.shared().showCommomDialog(s, "", (t => {
                        i.exitCallBack(t);
                        e && Utils.shared().cancelGoBack();
                    }), true, ToolUtils.getIsNormalDirection(), null, null, null, this.pop_layer4, null, this.tid_key);
                }
            }
            else if (e) {
                let e = this;
                Utils.shared().showCommomDialog(i18nMgr.shared().getValueByKey("utlis.text"), "", (t => {
                    e.exitCallBack(t);
                    Utils.shared().cancelGoBack();
                }), true, ToolUtils.getIsNormalDirection(), null, null, null, this.pop_layer4, null, this.tid_key);
            }
            else {
                this.exitCallBack(1);
            }
        }
        else {
            let s = ToolUtils.format(i18nMgr.shared().getValueByKey("utlis.text19"), ToolUtils.parse_double("" + this.drop_money), t.entry_fee);
            1 == t.crashModel && (s = ToolUtils.format(i18nMgr.shared().getValueByKey("utlis.text20"), Math.floor(this.drop_money)));
            let i = this;
            Utils.shared().showCommomDialog(s, "", (t => {
                i.exitCallBack(t);
                e && Utils.shared().cancelGoBack();
            }), true, ToolUtils.getIsNormalDirection(), null, null, null, this.pop_layer4, null, this.tid_key);
        }
    }
    onMenuCallback(e) {
        SoundManager.shared().playFx("click");
        try {
            switch (String(e)) {
                case "exit":
                    if (!RummyDataManager.shared().bCanGoBack) {
                        return void Utils.shared().showToast("Poor network, please try again later!", 2, 0, ToolUtils.getIsNormalDirection());
                    }
                    RummyDataManager.shared().reportCommClickEvent(this.tid_key, ReportConfig.func.Room_Menu, ReportConfig.cash_evt.click_leave_table), this._isClickLeaveTable = true, this.onDealExitGame();
                    break;
                case "switch":
                    if (!RummyDataManager.shared().bCanGoBack) {
                        return void Utils.shared().showToast("Poor network, please try again later!", 2, 0, ToolUtils.getIsNormalDirection());
                    }
                    let e = RummyDataManager.shared().rummyInfos.get(this.tid_key);
                    if (RummyDataManager.shared().reportCommClickEvent(this.tid_key, ReportConfig.func.Room_Menu, ReportConfig.cash_evt.click_switch_table), e.gameRummyType == RUMMY_GAME_TYPE.POOL || e.gameRummyType == RUMMY_GAME_TYPE.DEALS || e.gameRummyType == RUMMY_GAME_TYPE.PRI_POOL || e.gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL || e.gameRummyType == RUMMY_GAME_TYPE.POINTS || e.gameRummyType == RUMMY_GAME_TYPE.PRIVATE || e.gameRummyType == RUMMY_GAME_TYPE.MULTIPLE) {
                        if (e.is_table_change_status) {
                            return;
                        }
                        let t = e.clientSeatId;
                        return void (1 == e.playerModels[t].betting || 0 == e.is_game_all_end ? this.rummyLogicProcessing.handler_logout_request(1) : e.gameRummyType == RUMMY_GAME_TYPE.POINTS || e.gameRummyType == RUMMY_GAME_TYPE.MULTIPLE ? this.rummyLogicProcessing.handler_pre_switch_request() : (Utils.shared().showLoading(10, false), this.switchCallback()));
                    }
                    let t = e.clientSeatId, s = e.playerModels[t];
                    if (1 == e.isInGameing && (1 == s.betting || 0 == s.betting && 4 == s.status)) {
                        let t = ToolUtils.format(i18nMgr.shared().getValueByKey("utlis.text19"), ToolUtils.parse_double("" + this.drop_money), e.entry_fee);
                        1 == e.crashModel && (t = ToolUtils.format(i18nMgr.shared().getValueByKey("utlis.text20"), Math.floor(this.drop_money)));
                        Utils.shared().showCommomDialog(t, "", this.switchDestCallBack.bind(this), true, ToolUtils.getIsNormalDirection(), null, null, null, this.pop_layer4, null, this.tid_key);
                    }
                    else {
                        e.gameRummyType == RUMMY_GAME_TYPE.POINTS || e.gameRummyType == RUMMY_GAME_TYPE.MULTIPLE ? this.rummyLogicProcessing.handler_pre_switch_request() : (Utils.shared().showLoading(10, false), this.switchCallback());
                    }
                    break;
                case "help":
                    RummyDataManager.shared().reportCommClickEvent(this.tid_key, ReportConfig.func.Room_Menu, ReportConfig.cash_evt.click_how_to_play);
                    let i = "point";
                    if (RummyDataManager.shared().rummyInfos.has(this.tid_key)) {
                        let e = RummyDataManager.shared().rummyInfos.get(this.tid_key);
                        e.gameRummyType === RUMMY_GAME_TYPE.POOL || e.gameRummyType === RUMMY_GAME_TYPE.PRI_POOL ? i = "pool" : e.gameRummyType !== RUMMY_GAME_TYPE.DEALS && e.gameRummyType !== RUMMY_GAME_TYPE.PRI_DEAL || (i = "deal");
                    }
                    this.rummyShowTopUiLogic.showHelpAlert(i);
                    break;
                case "setting":
                    RummyDataManager.shared().reportCommClickEvent(this.tid_key, ReportConfig.func.Room_Menu, ReportConfig.cash_evt.click_settings), PushCenter.shared().pushEvent(PushEvent.OpenGameSettingAlert, this.tid_key);
                    break;
                case "home":
                    if (!RummyDataManager.shared().bCanGoBack) {
                        return void Utils.shared().showToast("Poor network, please try again later!", 2, 0, ToolUtils.getIsNormalDirection());
                    }
                    PushCenter.shared().pushEvent(GameConfig.BackToHall);
                    break;
                case "menu_tableinfo":
                    RummyDataManager.shared().reportCommClickEvent(this.tid_key, ReportConfig.func.Room_Menu, ReportConfig.cash_evt.click_table_info), this._isShowTableinfo = true, this.showRummyRoomInfoView();
                    break;
                case "gamedisplay": RummyDataManager.shared().reportCommClickEvent(this.tid_key, ReportConfig.func.Room_Menu, ReportConfig.cash_evt.click_game_display), this.showGameDisplay();
            }
        }
        catch (e) {
            TLog.printError("trycatch onMenuCallback:", e);
        }
    }
    showGameDisplay() {
        1 !== User.shared().temp_pingbi.cardsetting ? Utils.shared().showRoomGameDisPlay({ parent_node: director.getScene().getChildByName("Canvas") }) : Utils.shared().showToast("Coming soon", 2);
    }
    onMatchCallback(e) {
        switch (String(e)) {
            case "more":
                if (null == RummyDataManager.shared().rummyInfos.get(this.tid_key).matchPrizesInfo) {
                    return;
                }
                this.rummyShowTopUiLogic.showMatchPrizeRank();
                break;
            case "cancel":
                let e = this, t = { bLandscape: ToolUtils.getIsNormalDirection(), bWithCancel: true, strContent: i18nMgr.shared().getValueByKey("utlis.text11"), strTitle: i18nMgr.shared().getValueByKey("gameRummy_notice_Pop.notice"), sureKey: "rummy_switch.okay", cancelKey: "rummy_switch.cancel", parent_node: this.pop_layer4, tid_key: this.tid_key };
                Utils.shared().showCommonAlert(t, (t => {
                    1 == t && (e.rummyLogicProcessing.handler_server_cancel_join_race_request(), e.onDealExitGame(), User.shared().setGameRaceid(RummyDataManager.shared().rummyInfos.get(this.tid_key).raceid, false));
                }), true);
                break;
            case "exit":
                this.onDealExitGame();
                break;
            case "agin":
                this.isDisconnect = false, this.isNewTable = 0, this.removeGameOverView(), this.checkIsPointsMatch() || this.onDealBtnAction("start"), this.playerTs.showLoseScore(0, 0, true);
                let s = RummyDataManager.shared().rummyInfos.get(this.tid_key).raceid;
                this.checkIsPointsMatch() || (s = this.match_rejoinid);
                let i = { raceid: s, tid_key: this.tid_key, match_vid: this.match_vid };
                User.shared().sendJoinMatch(i);
                break;
            case "rank": this.matchRankCurPage = 1, this.rummyLogicProcessing.handler_server_rank_info_request(this.matchRankCurPage), this.showMatchRankInfoView();
        }
    }
    switchCallback() {
        RummyDataManager.shared().rummyInfos.get(this.tid_key).bIsSwitchRoom = true;
        RummyDataManager.shared().rummyInfos.get(this.tid_key).isGameOver = false;
        this.switchRoom();
    }
    changeQiPaiTableStatus(e, t = [], s) {
        if (e) {
            this.rummyShowTopUiLogic.showOpenCardAlert(t, s);
        }
        else if (ToolUtils.isObjValid(this.openCardNode)) {
            this.openCardNode.getComponent(RummyOpenCardsAlert).removeGamePopNode();
            this.openCardNode.active = false;
            this.hideWinTipAlert();
        }
    }
    onDestroy() {
        super.onDestroy();
        this.removeGameOverView();
        this.rummyShowTopUiLogic.cancelHistoryLoad();
        this.rummyShowTopUiLogic.cancelDealPoolRecord();
        ToolUtils.isObjValid(this.gameHistoryView) && (this.gameHistoryView.destroy(), this.gameHistoryView = null);
        ToolUtils.isObjValid(this.roomInfoNode) && (this.roomInfoNode.destroy(), this.roomInfoNode = null);
        Server.shared().clearEventByTarget(this);
        PushCenter.shared().removeListenersByTag(this);
        this.unscheduleAllCallbacks();
        this.deleteGameOverDalay();
        RummyDataManager.shared().stopTweenAction(this.pool_time_action);
        RummyDataManager.shared().stopTweenAction(this.start_time_action);
        this.start_time_action = null;
        RummyDataManager.shared().stopTweenAction(this.delay_ready_action);
        RummyDataManager.shared().stopTweenAction(this.time_schedule);
        RummyDataManager.shared().stopTweenAction(this.practice_action);
        RummyDataManager.shared().stopTweenAction(this.matchover_action);
        RummyDataManager.shared().stopTweenAction(this.hide_win_tip_action);
        RummyDataManager.shared().stopTweenActionByNode(this.action_node, true);
        RummyDataManager.shared().stopTweenActionByNode(this.time_node, true);
        RummyDataManager.shared().stopTweenAction(this.match_anim_tip_action);
        null != this.gameOverOpenLogic && (delete this.gameOverOpenLogic, this.gameOverOpenLogic = null);
        null != this.rummyShowTopUiLogic && (delete this.rummyShowTopUiLogic, this.rummyShowTopUiLogic = null);
        null != this.handCardDataAnalysis && (delete this.handCardDataAnalysis, this.handCardDataAnalysis = null);
        null != this.rummyLogicProcessing && (delete this.rummyLogicProcessing, this.rummyLogicProcessing = null);
    }
    getPlayerGiveCard(e) {
        for (let t = 0, s = RummyDataManager.shared().rummyInfos.get(this.tid_key).playerGiveCards.length; t < s; t++) {
            let s = RummyDataManager.shared().rummyInfos.get(this.tid_key).playerGiveCards[t];
            if (s.seatid == e) {
                return s;
            }
        }
        return null;
    }
    sortPlayerGiveCard() {
        RummyDataManager.shared().sortPlayerGiveCard(this);
    }
    playEffectByName(e) {
        this.tid_key === User.shared().curTid_key && SoundManager.shared().playFx(e);
    }
    handler_server_auto_outcard_status_bc(e) {
        if (this.tid_key !== (e.tid_key || "")) {
            return;
        }
        let t = e.seatid, s = e.auto_play, i = false;
        1 == s && (i = true);
        let a = ToolUtils.isSafeNumber(e.auto_type);
        (a < 1 || a > 3) && (i = false);
        this.isMyPlayer(t) && (RummyDataManager.shared().rummyInfos.get(this.tid_key).auto_out = s, RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType != RUMMY_GAME_TYPE.PRIVATE && RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType != RUMMY_GAME_TYPE.MATCH ? 1 != RummyDataManager.shared().rummyInfos.get(this.tid_key).is_waiting && this.tipTs.changeTuoguanVisible(i, e.auto_times, e.total_auto_times, a) : this.tipTs.changeTuoguanVisible(i, e.auto_times, e.total_auto_times, a), i && (this.tipTs.showQuickFinishTips(false), this.actionTs.changeRaceRewardDiVisible(false)));
    }
    handler_server_logout_respond(e) {
        this.tid_key === (e.tid_key || "") && this.rummyLogicProcessing.handler_server_logout_respond(e);
    }
    showGameStartCountDown() {
        RummyDataManager.shared().stopTweenAction(this.pool_time_action);
        let e = RummyDataManager.shared().rummyInfos.get(this.tid_key);
        this.removeGameOverView();
        this.finishType = -1;
        this.hasDeclare = false;
        let t = i18nMgr.shared().getValueByKey("rummy_main.gameTipsText3");
        if (1 == e.game_end_state ? t = i18nMgr.shared().getValueByKey("rummy_main.gameTipstext12") : 6 == e.game_end_state && (t = i18nMgr.shared().getValueByKey("rummy_main.gameTipsText2")), e.gameRummyType == RUMMY_GAME_TYPE.DEALS && e.dealsRummyCurrentRount > 0) {
            let s = e.dealsRummyCurrentRount;
            t = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_main.gameTipsText4"), s, e.end_game_countdown);
        }
        this.pool_time_action = TweenTool.myschedule(RummyDataManager.shared().sceneNode, 1, this.poolRummyUpdateTipTime.bind(this));
    }
    poolRummyUpdateTipTime() {
        ToolUtils.isObjValid(this.node) && RummyDataManager.shared().rummyInfos.has(this.tid_key) && (RummyDataManager.shared().rummyInfos.get(this.tid_key).end_game_countdown = RummyDataManager.shared().rummyInfos.get(this.tid_key).end_game_countdown - 1, RummyDataManager.shared().rummyInfos.get(this.tid_key).end_game_countdown < 1 && RummyDataManager.shared().stopTweenAction(this.pool_time_action));
    }
    hide_table_top_info_hongdian() {
        this.rummyShowTopUiLogic.hide_table_top_info_hongdian();
        this.top_bg_hongdian = 0;
        this.rummyLogicProcessing.send_req_watch_reward_info();
    }
    show_table_top_info(e) {
        this.tid_key === (e.tid_key || "") && (e.game_serial_id && (RummyDataManager.shared().rummyInfos.get(this.tid_key).gameSerialId = e.game_serial_id), this.rummyShowTopUiLogic.show_table_top_info(e));
    }
    isShowDealsPize(e) {
        this.tableRoot.getChildByName("delalsRummy6Player").active = e;
        1 == RummyDataManager.shared().rummyInfos.get(this.tid_key).crashModel ? (this.tableRoot.getChildByName("delalsRummy6Player").getChildByName("practice_deals_tip").active = true, this.tableRoot.getChildByName("delalsRummy6Player").getChildByName("deals_tip").active = false) : (this.tableRoot.getChildByName("delalsRummy6Player").getChildByName("practice_deals_tip").active = false, this.tableRoot.getChildByName("delalsRummy6Player").getChildByName("deals_tip").active = true);
        this.actionRoot.getChildByName("topNode").getChildByName("dealsPrizebtnShowPinbi").active = e;
    }
    handler_server_pool_record_return(e) {
        this.tid_key === (e.tid_key || "") && this.rummyShowTopUiLogic.showDealPoolRecord(e);
    }
    show_pool_all_end() {
        if (this.removeGameOverView(), ToolUtils.isObjValid(this.gameHistoryView) && this.gameHistoryView.destroy(), 1 != RummyDataManager.shared().rummyInfos.get(this.tid_key).is_waiting && 1 != RummyDataManager.shared().rummyInfos.get(this.tid_key).isGameStarting && RummyDataManager.shared().rummyInfos.get(this.tid_key).pool_rummy_all_end_data && !ToolUtils.isObjValid(this.RummyTotalSettlementNode)) {
            this.tipTs.showGameTipsText(0, 0, "");
            try {
                ToolUtils.loadCommonPrefab(RummyDataManager.shared().RummyTotalSettlementPrefab, BundleNameDefined.bundle_rummy, "prefab/GameRummy_TotalSettlement", (e => {
                    if (sys.isObjectValid(e) && e.isValid) {
                        RummyDataManager.shared().RummyTotalSettlementPrefab = e;
                        let t = instantiate(RummyDataManager.shared().RummyTotalSettlementPrefab);
                        t.parent = this.pop_layer4;
                        t.getComponent(RummyTotalSettlement).initView(RummyDataManager.shared().rummyInfos.get(this.tid_key).pool_rummy_all_end_data, this, this.tid_key);
                        this.RummyTotalSettlementNode = t;
                        ToolUtils.isObjValid(this.rummyGamePoolPoP) && this.rummyGamePoolPoP.setSiblingIndex(20);
                    }
                }));
            }
            catch (e) {
                TLog.printError("trycatch laodRummyPrefab,error", e);
            }
        }
    }
    handler_server_rejoin_return_bc(e) {
        if (this.tid_key === (e.tid_key || "") && null != e.players && e.players.length > 0) {
            let t = RummyDataManager.shared().rummyInfos.get(this.tid_key);
            for (let s = 0, i = e.players.length; s < i; s++) {
                let i = e.players[s].seatid, a = this.getPosBySeatid(i);
                if (null != e.score && this.playerTs.setPoolScore(a, e.score), t.playerModels[i].money = e.players[s].money, this.playerTs.setPoolRejoinState(a, true), 0 == a) {
                    let e = this.pop_layer4.getChildByName("GameRummy_pool_rejoin");
                    ToolUtils.isObjValid(e) && e.destroy();
                    this.removeGameOverView();
                }
            }
            t.pool_money = e.pool_money;
        }
    }
    handler_server_rejoin_return(e) {
        if (this.tid_key !== (e.tid_key || "")) {
            return;
        }
        0 !== e.ret ? null != e.msg && ToolUtils.isSafeString(e.msg).length > 0 && Utils.shared().showToast(e.msg, 2, 0, ToolUtils.getIsNormalDirection()) : this.tipTs.setManulaRejoinSelect(false);
    }
    handler_server_geme_notify_bc(e) {
        if (this.tid_key === (e.tid_key || "")) {
            if (this.rummyShowTopUiLogic.showGameManualSplit(e.cd, e.user_info), RummyDataManager.shared().rummyInfos.get(this.tid_key).game_end_state = 4, ToolUtils.isObjValid(this.gameEndView) ? RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType != RUMMY_GAME_TYPE.MATCH && (this.gameEndView.getComponent(RummyGameOverAlert).setPoolRummyCountDown(e.cd), this.gameEndView.getComponent(RummyGameOverAlert).updateBtnShow()) : (RummyDataManager.shared().rummyInfos.get(this.tid_key).end_game_countdown = e.cd, this.showGameStartCountDown()), sys.isObjectValid(e.user_info)) {
                for (let t = 0, s = e.user_info.length; t < s; t++) {
                    0 == e.user_info[t].status ? this.playerTs.startPlayerTimer2(this.getPosBySeatid(e.user_info[t].seatid), e.cd) : this.playerTs.stopPlayerTimerByPos(this.getPosBySeatid(e.user_info[t].seatid), true);
                }
            }
            RummyDataManager.shared().rummyInfos.get(this.tid_key).isInGameing = 0;
        }
    }
    handler_server_geme_respond_bc(e) {
        this.tid_key === (e.tid_key || "") && (ToolUtils.isObjValid(this.rummyGameManualSplit) && this.rummyGameManualSplit.getComponent(RummyGameManualSplit).updatePlayerInfo(e), 1 != e.status && 2 != e.status || (this.playerTs.setPoolManualState(this.getPosBySeatid(e.seatid), true, 1 == e.status), this.playerTs.stopPlayerTimerByPos(this.getPosBySeatid(e.seatid), true)));
    }
    handler_server_pool_all_record_return(e) {
        1 != User.shared().isInPerformanceRoom ? this.tid_key === (e.tid_key || "") && (this._lastGameOverMsg = e, this.gameOverOpenLogic.handler_server_pool_all_record_return(this.tid_key, e), sys.isObjectValid(e.up_venue) && sys.isObjectValid(e.up_venue.entry_fee) && (this.upvenue_entry_fee = Number(e.up_venue.entry_fee)), sys.isObjectValid(e.tf_venue) && sys.isObjectValid(e.tf_venue.entry_fee) && (RummyDataManager.shared().rummyInfos.get(this.tid_key).tf_venue = e.tf_venue)) : this.roomPerformance && this.roomPerformance.isValid && this.roomPerformance.handler_server_pool_all_record_return(e);
    }
    showTotalSettlementInfo() {
        this.rummyShowTopUiLogic.showTotalSettlementInfo();
    }
    gameEendreset() {
        this.gameOverOpenLogic.gameEendreset(this.tid_key);
    }
    handler_server_show_split_prize_respond(e) {
        this.tid_key === (e.tid_key || "") && ToolUtils.isObjValid(this.gameEndView) && (RummyDataManager.shared().rummyInfos.get(this.tid_key).game_end_state = 2, RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType != RUMMY_GAME_TYPE.MATCH && (this.gameEndView.getComponent(RummyGameOverAlert).setPoolRummyCountDown(e.cd), this.gameEndView.getComponent(RummyGameOverAlert).updateBtnShow()));
    }
    handler_server_deals_overtime_pop_respond(e) {
        this.tid_key === (e.tid_key || "") && (this._bIsShowReady = false, this.actionTs.hideReadyBtn());
    }
    handler_server_auto_drop_respond(e) {
        if (this.tid_key !== (e.tid_key || "")) {
            return;
        }
        let t = RummyDataManager.shared().rummyInfos.get(this.tid_key);
        t._pre_drop_type = -1;
        0 == e.ret ? 4 != t.game_state && (t.auto_drop_type = e.auto_drop, this.autoDropTs.isAutoDropSelect(e.auto_drop)) : null != e.alertStr && e.alertStr.length > 0 && Utils.shared().showToast(e.alertStr, 1.5, 0, ToolUtils.getIsNormalDirection());
    }
    handler_notify_icon_name_visible_respond(e) {
        if (this.tid_key === (e.tid_key || "")) {
            try {
                if (null != e.players && null != e.players && e.players.length > 0) {
                    let t = RummyDataManager.shared().rummyInfos.get(this.tid_key);
                    for (let s = 0, i = e.players.length; s < i; s++) {
                        if (e.players[s].seatid != t.clientSeatId) {
                            let t = this.getPosBySeatid(e.players[s].seatid);
                            this.playerTs.updateHeadImgName(t, e.players[s].name, e.players[s].avatar, e.players[s].avatar_url);
                        }
                        let i = t.playerModels[e.players[s].seatid];
                        i.name = e.players[s].name;
                        i.avatar = e.players[s].avatar;
                        i.avatar_url = e.players[s].avatar_url;
                        i.vip = e.players[s].vip;
                        i.club_level = e.players[s].club_level;
                        i.club_effect_v2 = e.players[s].club_effect_v2;
                    }
                }
                if (0 == e.interactive_enable) {
                    this.actionTs.ishudongshow(false);
                    for (let e = 1; e < 6; e++) {
                        this.playerTs.checkHeadShow(e) && this.playerTs.showPipeiAnim1(e);
                    }
                }
                else {
                    for (let e = 1; e < 6; e++) {
                        this.playerTs.checkHeadShow(e) && this.playerTs.stopPipeiAnim1(e);
                    }
                }
            }
            catch (e) {
                TLog.printError("trycatch handler_notify_icon_name_visible_respond:", e);
            }
        }
    }
    clean_up_the_desk(e) {
        this.gameOverOpenLogic.clean_up_the_desk(this.tid_key, e);
    }
    showMatchJoinTips(e) {
        let t = false;
        ToolUtils.deskInfos.size >= 3 && e && "" != e && (t = true);
        this.match_name = e;
        t ? (RummyDataManager.shared().rummyInfos.get(this.tid_key).race_tipsTime = 10, this.actionTs.changeMatchRankBtnVisibile(true), this.tipTs.changeMatchJoinTipsActive(true, e)) : (this.actionTs.changeMatchRankBtnVisibile(false), RummyDataManager.shared().rummyInfos.get(this.tid_key).race_tipsTime = 0, this.hasFreeMatchPush = false);
    }
    checkHasMatchJoinTips() {
        let e = false;
        return ToolUtils.deskInfos.size >= 3 && this.match_name && "" != this.match_name && (e = true), e;
    }
    showMatchOverView(e) {
        if (this.pop_layer4) {
            let t = this.pop_layer4.getChildByName("match_game_over");
            ToolUtils.isObjValid(t) && t.destroy();
            let s = this.pop_layer4.getChildByName("match_rank");
            ToolUtils.isObjValid(s) && s.destroy();
            let i = this.pop_layer4.getChildByName("matchAlert");
            ToolUtils.isObjValid(i) && (i.destroy(), i = null);
            let a = this.pop_layer4.getChildByName("comm_magic_face");
            ToolUtils.isObjValid(a) && a && (a.destroy(), a = null);
            let r = ToolUtils.isObjValid(this.gameEndView) ? 3 : 0;
            RummyDataManager.shared().stopTweenAction(this.matchover_action);
            this.matchover_action = TweenTool.delayAct(RummyDataManager.shared().sceneNode, (() => {
                ToolUtils.isObjValid(this.node) && (this.removeGameOverView(), this.actionTs.changeMatchRankBtnVisibile(false), this.match_name = "", this.hasFreeMatchPush = false, this.rummyShowTopUiLogic.showMatchGameOver(e));
            }), r, true);
            User.shared().send_race_receive_reward_laba(e.raceid);
        }
    }
    showMatchAlertTip(e, t, s, i) {
        this.tipTs.changeTuoguanVisible(false);
        this.tipTs.showGameTipsText(0, 0, "");
        try {
            let a = this.pop_layer4.getChildByName("matchAlert");
            ToolUtils.isObjValid(a) && a.destroy();
            Utils.shared().showMatchAlertView(4, { parentNode: this.pop_layer4, strContent: e, strBtn: t, callfun: s, strFunc: i });
        }
        catch (e) {
            TLog.printError("trycatch showMatchAlertTip,error:", e);
        }
    }
    updateMatchWaitView(e) {
        let t = this.pop_layer4.getChildByName("match_game_wait");
        if (ToolUtils.isObjValid(t)) {
            t.active = true;
            t.getComponent("RummyMatchWait").updateJoinedNum(e);
        }
        else {
            sys.isObjectValid(this.match_wait_info) && this.rummyShowTopUiLogic.showMatchWaitView(this.match_wait_info.race_name, this.match_wait_info.reward_infos, e, this.match_wait_info.total_num);
        }
    }
    hideMatchWaitView() {
        let e = this.pop_layer4.getChildByName("match_game_wait");
        ToolUtils.isObjValid(e) && (e.active = false, e.destroy(), e = null);
    }
    handler_server_notify_notice_info(e) {
        if (this.tid_key !== (e.tid_key || "")) {
            return;
        }
        let t = RummyDataManager.shared().rummyInfos.get(this.tid_key), s = ToolUtils.isSafeNumber(e.cd);
        s < 0 && (s = 0);
        let i = 0;
        if (this.match_anim_tip_action && (TweenTool.stopAction(this.match_anim_tip_action), this.match_anim_tip_action = null), t.gameRummyType == RUMMY_GAME_TYPE.MATCH ? sys.isObjectValid(e) && sys.isObjectValid(e.ani_step) && (i = e.ani_step, 0 != i && this.tipTs.showGameTipsText(0, 0, ""), 1 == e.ani_step ? this.showMatchTipsAnim(2) : 2 != e.ani_step && 3 != e.ani_step || this.tipTs.showMatchPeopleAnimTips(true, e), e.ani_step >= 1 && e.ani_step <= 3 && (this.match_anim_tip_action = TweenTool.delayAct(RummyDataManager.shared().sceneNode, (() => {
            ToolUtils.isObjValid(this.node) && (this.rummyShowTopUiLogic.hideMatchTipsAnim(), this.tipTs.showMatchPeopleAnimTips(false, null), this.tipTs.showGameTipsText(e.type, s, e.back, e));
        }), 2, true))) : t.gameRummyType == RUMMY_GAME_TYPE.POINTS && 0 == e.type && 0 == s && 1 == t.crashModel && this.tipTs.hideWinEffect(), 0 == i) {
            if (this.rummyShowTopUiLogic.hideMatchTipsAnim(), this.tipTs.showMatchPeopleAnimTips(false, null), this.tipTs.showGameTipsText(e.type, s, e.back, e), this.checkIsPointsMatch() && (sys.isObjectValid(e.user_round) && (t.user_round = e.user_round), sys.isObjectValid(e.max_round) && (t.max_round = e.max_round)), 3 === e.type && ToolUtils.isObjValid(this.gameEndView)) {
                let e = i18nMgr.shared().getValueByKey("rummy_main.gameTipsText10");
                t.gameRummyType == RUMMY_GAME_TYPE.MATCH ? (this.gameEndView.getComponent(RummyPointsMatchOverAlert).showCountDown(e), this.gameEndView.getComponent(RummyPointsMatchOverAlert).onEnterLineUp()) : (this.gameEndView.getComponent(RummyGameOverAlert).showCountDown(e), this.gameEndView.getComponent(RummyGameOverAlert).onEnterLineUp());
            }
            2 !== e.type && 7 !== e.type || t.gameRummyType == RUMMY_GAME_TYPE.PRIVATE && this.actionTs.hidePrivateBtn();
            t.gameRummyType != RUMMY_GAME_TYPE.PRIVATE && t.gameRummyType != RUMMY_GAME_TYPE.PRI_POOL && t.gameRummyType != RUMMY_GAME_TYPE.PRI_DEAL && t.gameRummyType != RUMMY_GAME_TYPE.MATCH && (1 === e.type || 3 === e.type) && s > 0 && (this.playerTs.setPaiDuiBgShow(false), this.actionTs.changeCenterFinishBtnStatus(false), this.actionTs.changeOpenCardStatus(false, this), this.actionTs.changeSwitchJokerStatus(false, this));
        }
        else {
            this.tipTs.showGameTipsText(0, 0, "");
        }
    }
    send_table_player_info_request() {
        this.rummyLogicProcessing.send_table_player_info_request();
    }
    handler_server_table_player_info(e) {
        this.tid_key === (e.tid_key || "") && this.rummyLogicProcessing.handler_server_table_player_info(e);
    }
    hideOpenCardAlert() {
        if (ToolUtils.isObjValid(this.openCardNode)) {
            let e = this.openCardNode.getComponent(RummyOpenCardsAlert);
            e.removeGamePopNode();
            e.removeListView();
            this.openCardNode.active = false;
        }
    }
    hideWinTipAlert() {
        this.node_taskBg.active = false;
        this.winTips.getChildByName("icon").getComponent(Sprite).spriteFrame = this.winTipBtnImgs[0];
    }
    onEnterForeground() {
        this.deleteGameOverDalay();
        this.rummyLogicProcessing.showGameEndBtn();
    }
    refreshCurDesk() {
        RummyDataManager.shared().rummyInfos.has(this.tid_key) && this.rummyLogicProcessing.refreshCurDesk();
    }
    handler_server_pool_drop_return(e) {
        this.tid_key === (e.tid_key || "") && this.rummyLogicProcessing.handler_server_pool_drop_return(e);
    }
    handler_server_notify_listen_info(e) {
        if (this.tid_key !== (e.tid_key || "")) {
            return;
        }
        let t = RummyDataManager.shared().rummyInfos.get(this.tid_key);
        t && (sys.isObjectValid(e.all_finish_num_open) ? t.all_finish_num_open = e.all_finish_num_open : t.all_finish_num_open = 0, sys.isObjectValid(e.turn) && (t.ting_round = e.turn));
        this.tingPaiMsg = e;
        this.refreshTingPaiSwitch(0.65);
    }
    handler_server_helper_best_group_alert_pick(e) {
        this.tid_key === (e.tid_key || "") && this.tingPaiTs.showDetailBubble(e.tingpai_index, e);
    }
    refreshTingPaiSwitch(e = 0) {
        this.rummyLogicProcessing.refreshTingPaiSwitch(e);
    }
    hideAllTingPaiFlag() {
        this.cardsTs.hideTingPaiTips();
        this.tingpaiNode.active = false;
        this.tingPaiTs.changeTingPaiBubbleVisible(false);
    }
    ceshiceshi() {
        this.cardsTs.dayingshoupaiData(6);
        this.cardsTs.groupShoupaiArrange();
    }
    dealLocalDisCardCard(e) {
        this.rummyLogicProcessing.dealLocalDisCardCard(e);
    }
    showLocalFinishResult() {
        this.playerTs.showLoseScore(0, 0, true);
        this.playerTs.stopPlayerTimerByPos(0);
        this.tipTs.showWinEffect(0);
        this.tipTs.setMultipleCenterTipsShow(false);
        0 == this._isPlayWinEffec && (User.shared().curTid_key == this.tid_key && SoundManager.shared().playFx("winA"), this._isPlayWinEffec = true);
        RummyDataManager.shared().rummyInfos.get(this.tid_key).hasShowWinAnim = true;
    }
    checkFinishCards(e = null) {
        let t = false;
        if (sys.isObjectValid(this.finish_groups) && Array.isArray(this.finish_groups)) {
            let s = this.handCardDataAnalysis.transferToMyLocalGroups(this.finish_groups), i = this.handCardDataAnalysis.checkSameCards(this.cardsTs.myGroupcardValueVec, s), a = this.cardsTs.getSelectedCards(), r = false;
            if (sys.isObjectValid(e) && e == this.helper_hu_card && (r = true), 1 == a.length) {
                let e = a[0].getComponent("RummyCard");
                sys.isObjectValid(this.helper_hu_card) && e.mCardValue == this.helper_hu_card && (r = true);
            }
            0 == i && r && (t = true);
        }
        return t;
    }
    handler_server_helper_pick_card(e) {
        this.tid_key === (e.tid_key || "") && 1 == RummyDataManager.shared().rummyInfos.get(this.tid_key).helper_pick_additional_info_open && (sys.isObjectValid(e) && 0 != e.helper_pick_label ? (this.pickCardInfo = e, this.cardsTs.showPickCardTips(true, e.helper_pick_label), this.refreshTingPaiSwitch()) : (this.pickCardInfo = null, this.refreshTingPaiSwitch()));
    }
    handler_server_notify_multiple_card_score(e) {
        if (this.tid_key !== (e.tid_key || "")) {
            return;
        }
        let t = RummyDataManager.shared().rummyInfos.get(this.tid_key);
        sys.isObjectValid(t) && 1 == t.is_multiple && (sys.isObjectValid(e.src_score) ? sys.isObjectValid(e.finish_multiple) ? this.playerTs.showLoseScore(0, e.all_score, true, e.src_score, e.finish_multiple) : this.playerTs.showLoseScore(0, e.all_score, true, e.src_score) : this.playerTs.showLoseScore(0, e.all_score, true));
    }
    handler_server_notify_switch_skin(e) {
        this.tid_key;
        e.tid_key;
    }
    checkIsPointsMatch() {
        let e = false, t = RummyDataManager.shared().rummyInfos.get(this.tid_key);
        return sys.isObjectValid(t) && t.gameRummyType == RUMMY_GAME_TYPE.MATCH && t.gameMatchMode == RUMMY_MATCH_MODE.PointsMatch && (e = true), e;
    }
    handler_server_notify_match_push(e) {
        this.tid_key === (e.tid_key || "") && 1 != GameConfig.CHIPS_MODLE && this.rummyLogicProcessing.handler_server_notify_match_push(e);
    }
    handler_server_score_rank_info_return(e) {
        this.tid_key === (e.tid_key || "") && this.actionTs.refreshRaceRankList(e);
    }
    handler_server_notify_effect_modify_return(e) {
        if (this.tid_key !== (e.tid_key || "")) {
            return;
        }
        let t = RummyDataManager.shared().rummyInfos.get(this.tid_key), s = t.playerModels[e.seatid];
        sys.isObjectValid(e.avatar_frame_id) && (s.avatar_frame_id = e.avatar_frame_id);
        sys.isObjectValid(e.play_effect_id) && (s.play_effect_id = e.play_effect_id);
        sys.isObjectValid(e.avatar_url) && (s.avatar_url = e.avatar_url);
        sys.isObjectValid(e.avatar) && (s.avatar = e.avatar);
        t.playerModels[e.seatid] = s;
        this.rummyLogicProcessing.refreshPlayerInfoBySeatid(e.seatid);
        this.resetPlayerHeadAnim(e.seatid);
    }
    resetPlayerHeadAnim(e) {
        let t = RummyDataManager.shared().checkLiveAvatar(this.tid_key, e);
        this.tipTs.showPlayerHeadAnim(0, 6, -1, null);
        let s = 1 == t;
        this.playerTs.showPlayerHeadAnim(0, 6, t, s);
    }
    handler_server_notify_client_load_head(e) {
        if (this.tid_key === (e.tid_key || "") && sys.isObjectValid(e.avatar_url)) {
            for (let t = 0; t < e.avatar_url.length; t++) {
                Utils.shared().preDownLoadHeadImg("", e.avatar_url[t]);
            }
        }
    }
    handler_server_bump_change_joker(e) {
        if (this.tid_key !== (e.tid_key || "")) {
            return;
        }
        let t = RummyDataManager.shared().rummyInfos.get(this.tid_key);
        e.last_lz != e.new_lz && (this.cardsTs.hideBumpLaiziTipAnim(), t.lastLaizicard = e.last_lz);
        t.laizicard = e.new_lz;
        t.winLaizicard = 0;
        sys.isObjectValid(e.cardinfos) && (this.refreshMyShouPai(e), this.saveServerCardInfos(e));
        this.hideAllTingPaiFlag();
        this.tingPaiTs.hideTingPaiUI();
        this.tingPaiMsg = null;
        this.pickCardInfo = null;
        ToolUtils.getCardInfo(t.best_lz).point == ToolUtils.getCardInfo(t.laizicard).point && (this.actionTs.changeBestJokerStatus(false, this), this.cardsTs.hideBestLaiziBubble());
        this.cardsTs.updateCurBumpLaizi();
    }
    handler_server_notify_pick_info(e) {
        if (this.tid_key !== (e.tid_key || "")) {
            return;
        }
        let t = false, s = sys.localStorage.getItem("open_deck_pick_def");
        null == s && (s = User.shared().help_setting.open_deck_pick_def);
        1 == User.shared().help_setting.open_deck_pick && sys.isObjectValid(s) && 1 == Number(s) && (t = true);
        sys.isObjectValid(e.helper_pick_card) && e.helper_pick_card && t ? (this.cardsTs.showMoPaiTisAnim(true, this.isCanmqp, true), sys.isObjectValid(e.helper_pick_card_array) ? this.cardsTs.showHighTipsCards(e.helper_pick_card_array, e.helper_pick_group_index) : this.cardsTs.hideCardTipsGlow()) : (this.cardsTs.showMoPaiTisAnim(true, this.isCanmqp), this.cardsTs.hideCardTipsGlow(), this.cardsTs.showPickCardTips(false));
        let i = RummyDataManager.shared().rummyInfos.get(this.tid_key);
        sys.isObjectValid(e.lz_card) && (i.laizicard = e.lz_card);
        sys.isObjectValid(e.flop_lz_card) && (i.laiziFlopCard = e.flop_lz_card);
    }
    handler_server_notify_recommand_laizi(e) {
        if (this.tid_key !== (e.tid_key || "")) {
            return;
        }
        let t = RummyDataManager.shared().rummyInfos.get(this.tid_key);
        t.game_state < 4 && (t.best_lz = e.recommand_lz, t.best_lz > 0 ? this.cardsTs.updateBestLaizi() : this.cardsTs.hideBestLaiziBubble(), this.rummyShowTopUiLogic.updateBestLaizi(), t.best_lz > 0 && ToolUtils.getCardInfo(t.best_lz).point != ToolUtils.getCardInfo(t.laizicard).point ? this.actionTs.changeBestJokerStatus(true, this) : this.actionTs.changeBestJokerStatus(false, this));
    }
    handler_server_bump_pre_change_laizi(e) {
        this.tid_key === (e.tid_key || "") && this.rummyShowTopUiLogic.showSelectJokerAlert(this.cardInfoMsg, e);
    }
    handler_server_bump_batch_pre_change_laizi(e) {
        this.tid_key === (e.tid_key || "") && this.rummyShowTopUiLogic.updateBatchJokerInfo(e);
    }
    handler_server_notify_chip(e) {
        if (this.tid_key !== (e.tid_key || "")) {
            return;
        }
        User.shared().act_98_times = e.times;
        let t = RummyDataManager.shared().rummyInfos.get(this.tid_key), s = (t.vid, this.node, this.tid_key, t.entry_fee, e.times, e.reward_value, [{ amt: e.reward_value, type: 7 }]), i = ToolUtils.format(i18nMgr.shared().getValueByKey("chip_bankrupt.time_left"), e.times);
        User.shared().showChargeReward(s, null, i, 7);
    }
    handler_server_reject_up_venue_tips(e) {
        this.tid_key === (e.tid_key || "") && PushCenter.shared().pushEvent(PushEvent.ShowCreateDeskBubble, e.multitable_tips);
    }
    handler_server_histroy_cards_info(e) {
        if (this.tid_key === (e.tid_key || "")) {
            if (sys.isObjectValid(e) && sys.isObjectValid(e.players) && Array.isArray(e.players) && sys.isObjectValid(e.tid_key)) {
                let t = RummyDataManager.shared().rummyInfos.get(e.tid_key);
                t && (t.his_card_players = e.players || []);
            }
            PushCenter.shared().pushEvent(PushEvent.UpdateMagicGiftsCardView, { players: e.players, tid: e.tid_key });
        }
    }
    handler_server_refresh_outs_info_return(e) {
        if (this.tid_key === (e.tid_key || "") && e.cardinfos && "object" == typeof e.cardinfos && Array.isArray(e.cardinfos)) {
            if (!RummyDataManager.shared().getCanShowAvailableCardTips()) {
                return;
            }
            this.cardInfoMsg = e;
            this.refreshMyCardInfos(e);
            this.cardsTs.showAvailableCardFlag(RummyDataManager.shared().rummyInfos.get(this.tid_key).cardInfoModelVec);
            this.tipTs.refreshAvailableCardTips(RummyDataManager.shared().rummyInfos.get(this.tid_key).cardInfoModelVec, (() => {
                this.tipTs.setAvailableCardTipsVisible(false);
            }));
        }
    }
    handler_server_notify_choose_double(e) {
        this.tid_key === (e.tid_key || "") && this.rummyLogicProcessing.handler_server_notify_choose_double(e);
    }
    handler_server_choose_double_return(e) {
        this.tid_key === (e.tid_key || "") && this.rummyLogicProcessing.handler_server_choose_double_return(e);
    }
    handler_server_choose_double_bc_return(e) {
        this.tid_key === (e.tid_key || "") && this.rummyLogicProcessing.handler_server_choose_double_bc_return(e);
    }
}
