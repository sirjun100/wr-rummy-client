// @ts-nocheck
// Recovered from index.js:587
import { _decorator, Button, color, instantiate, Label, Node, size, Sprite, SpriteFrame, sys, UITransform, view, Widget } from "cc";
import SoundManager from "./SoundManager";
import PushCenter from "./PushCenter";
import { TLog } from "./TLog";
import Utils from "./Utils";
import User from "./User";
import HttpManager from "./HttpManager";
import i18nMgr from "./i18nMgr";
import BaseLayer from "./BaseLayer";
import { HttpRequest } from "./HttpRequestName";
import GameConfig from "./GameConfig";
import PushEvent from "./PushEvent";
import TweenTool from "./TweenTool";
import SportCricket_Manager from "./SportCricket_Manager";
import { ToolUtils } from "./ToolUtils";
import { TransferPlatform } from "./TransferPlatform";
import BundleNameDefined from "./BundleNameDefined";
import PhpReportDefined from "./PhpReportDefined";
const { ccclass, property } = _decorator;
@ccclass("SportCricket_TeamList")
export class SportCricket_TeamList extends BaseLayer {
    public TAG: string = "SportCricket_TeamList";
    @property(Node)
    public rootNode: Node = null;
    @property(Node)
    public goldNode: Node = null;
    @property(Node)
    public topNode: Node = null;
    @property(Node)
    public nextNode: Node = null;
    @property(Node)
    public contentNode: Node = null;
    @property([SpriteFrame])
    public teamBgImgs: SpriteFrame[] = [];
    @property([SpriteFrame])
    public capBgImgs: SpriteFrame[] = [];
    @property([SpriteFrame])
    public btnBgImgs: SpriteFrame[] = [];
    @property([SpriteFrame])
    public operateImgs: SpriteFrame[] = [];
    @property(Node)
    public team_mobanView: Node = null;
    public _closed: boolean = false;
    public bShowPushAnim: boolean = true;
    public _lastClick: number = 0;
    public _sourceData: any = null;
    public _isSendMsg: boolean = false;
    public taskAwardIconMap: Map = new Map;
    public _match_id: number = 0;
    public _source: any = null;
    public _teamlistData: any = null;
    public _fromType: number = 0;
    public _match_state: number = 1;
    public _lastNode: any = null;
    public _hasLoadedBundle: boolean = false;
    onLoad() {
        PushCenter.shared().addListener(GameConfig.Update_Money, (e => {
            try {
                ToolUtils.isObjValid(this.node) && this.updateGold(e);
            }
            catch (e) {
                TLog.printError(this.TAG, GameConfig.Update_Money, e);
            }
        }), this);
        PushCenter.shared().addListener(PushEvent.RefreshYes11TeamList, (e => {
            try {
                ToolUtils.isObjValid(this.node) && this.requestNewList();
            }
            catch (e) {
                TLog.printError(this.TAG, PushEvent.RefreshYes11TeamList, e);
            }
        }), this);
        PushCenter.shared().addListener(PushEvent.commentDownloaderImg, (e => {
            try {
                if (ToolUtils.isObjValid(this.node) && this.taskAwardIconMap.size > 0) {
                    for (const [t, i] of this.taskAwardIconMap) {
                        i == e && sys.isObjectValid(t) && Utils.shared().updateNetImage(t, e, size(88, 88));
                    }
                }
            }
            catch (e) {
                TLog.printError(this.TAG, PushEvent.commentDownloaderImg, e);
            }
        }), this);
        this.fitLuckyTheme();
    }
    fitLuckyTheme() {
        0 != GameConfig.NATIVE_GAME_APP_TYPE && (this.rootNode.getChildByName("top_node").getChildByName("top_bg").getComponent(Sprite).color = color(12, 26, 60, 255), this.goldNode.getChildByName("coin").getComponent(Label).color = color(251, 220, 0, 255));
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().removeListenersByTag(this);
        this.unscheduleAllCallbacks();
    }
    init(e) {
        sys.isObjectValid(e) && sys.isObjectValid(e.match_id) && (this._match_id = e.match_id);
        sys.isObjectValid(e) && sys.isObjectValid(e.source) && (this._source = { ...e.source });
        sys.isObjectValid(e) && sys.isObjectValid(e.fromType) && (this._fromType = e.fromType);
        sys.isObjectValid(e) && sys.isObjectValid(e.teamlistData) && (this._teamlistData = e.teamlistData);
        sys.isObjectValid(e) && sys.isObjectValid(e.lastNode) && (this._lastNode = e.lastNode);
    }
    start() {
        super.start();
        this.initView();
        this.bShowPushAnim && ToolUtils.showPushAnim(this.node, 0, (() => {
            sys.isObjectValid(this._lastNode) && (this._lastNode.active = false);
            this.refreshView();
        }));
        this.updateGold(User.shared().data.money);
    }
    requestNewList() {
        let e = { match_id: this._match_id };
        HttpManager.shared().doGetCommonRequest(e, HttpRequest.Yes11_TeamList, ((e, t, i) => {
            if (Utils.shared().hideLoading(), 200 != i) {
                Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.request_fail"), 2);
            }
            else {
                try {
                    let e = ToolUtils.parseJson(t);
                    0 == e.ret ? sys.isObjectValid(e.data) && (this._teamlistData = e.data, this.refreshView()) : sys.isObjectValid(e.desc) && e.desc.length > 0 && Utils.shared().showToast(e.desc, 2);
                }
                catch (e) {
                    TLog.printError("showSportCricket_teamList err:", e.toString());
                }
            }
        }));
    }
    refreshView() {
        this.rootNode.getChildByName("nodata").active = false;
        this.updateContestDetails();
        this._hasLoadedBundle || (this._hasLoadedBundle = true, TweenTool.delayAct(this.node, (() => {
            ToolUtils.preLoadBundlePrefab(BundleNameDefined.Bundle_Yes11, "prefab/cricket_teampreview", null);
            ToolUtils.preLoadBundlePrefab(BundleNameDefined.Bundle_Yes11, "prefab/cricket_backupedit", null);
        }), 2, true));
    }
    updateTopContestDetails() {
        if (!sys.isObjectValid(this._source)) {
            return;
        }
        let e = this._source.teama, t = this._source.teamb;
        sys.isObjectValid(e.short_name) && e.short_name.length > 0 && (this.topNode.getChildByName("team_short_name0").getComponent(Label).string = e.short_name);
        sys.isObjectValid(t.short_name) && t.short_name.length > 0 && (this.topNode.getChildByName("team_short_name1").getComponent(Label).string = t.short_name);
        sys.isObjectValid(e.logo_url) && e.logo_url.length > 0 && (this.taskAwardIconMap.set(this.topNode.getChildByName("team_icon0"), e.logo_url), Utils.shared().updateNetImage(this.topNode.getChildByName("team_icon0"), e.logo_url, size(76, 76)));
        sys.isObjectValid(t.logo_url) && t.logo_url.length > 0 && (this.taskAwardIconMap.set(this.topNode.getChildByName("team_icon1"), t.logo_url), Utils.shared().updateNetImage(this.topNode.getChildByName("team_icon1"), t.logo_url, size(76, 76)));
        sys.isObjectValid(this._source.location) && this._source.location.length > 0 && (this.topNode.getChildByName("location").getComponent(Label).string = this._source.location);
    }
    updateContestDetails() {
        sys.isObjectValid(this._teamlistData) && (this.updateNextButtonStatus(), this.reSortTeamInfo());
    }
    reSortTeamInfo() {
        this.contentNode.removeAllChildren();
        sys.isObjectValid(this._teamlistData.list) && Array.isArray(this._teamlistData.list) && this._teamlistData.list.length > 0 && (this.addTeamView(this.contentNode, this._teamlistData.list), SportCricket_Manager.shared().cricket_curTeamNum = this._teamlistData.list.length, PushCenter.shared().pushEvent(PushEvent.RefreshYesGameTeamNum));
    }
    addTeamView(e, t) {
        let i = 0, a = 1;
        for (let s = 0; s < t.length; s++) {
            let o = instantiate(this.team_mobanView);
            o.active = true;
            e.addChild(o);
            let n = ToolUtils.toJsonString(t[s]);
            if (o.getChildByName("bg").getComponent(Button).clickEvents[0].customEventData = n, o.getChildByName("edit_btn").getComponent(Button).clickEvents[0].customEventData = n, o.getChildByName("backup_btn").getComponent(Button).clickEvents[0].customEventData = n, o.getChildByName("copy_btn").getComponent(Button).clickEvents[0].customEventData = n, o.getChildByName("share_btn").getComponent(Button).clickEvents[0].customEventData = n, o.getChildByName("share_btn").active = false, o.getChildByName("backup_btn").getChildByName("dot").active = false, o.getChildByName("red_diban").active = false, sys.isObjectValid(t[s].fill_backup) && 1 == t[s].fill_backup && (1 == SportCricket_Manager.shared().cricket_backup_open ? (o.getChildByName("backup_btn").getChildByName("dot").active = true, i = 1, o.getChildByName("backup_btn").active = true) : o.getChildByName("backup_btn").active = false), sys.isObjectValid(t[s].not_in_lineup_num) && t[s].not_in_lineup_num > 0) {
                o.getChildByName("red_diban").active = true;
                o.getChildByName("red_diban").getChildByName("edit_arrow").getComponent(Button).clickEvents[0].customEventData = n;
                o.getComponent(UITransform).contentSize = size(670, 360);
                let e = ToolUtils.format(i18nMgr.shared().getValueByKey("yes11.lineup_tip"), t[s].not_in_lineup_num);
                o.getChildByName("red_diban").getChildByName("red_wz").getComponent(Label).string = e;
                a = 0;
            }
            if (sys.isObjectValid(t[s].name) && t[s].name.length > 0 && (o.getChildByName("name").getComponent(Label).string = t[s].name), sys.isObjectValid(t[s].wk_num) && String(t[s].wk_num).length > 0 && (o.getChildByName("wk").getComponent(Label).string = "WK " + t[s].wk_num), sys.isObjectValid(t[s].bat_num) && String(t[s].bat_num).length > 0 && (o.getChildByName("bat").getComponent(Label).string = "BAT " + t[s].bat_num), sys.isObjectValid(t[s].ar_num) && String(t[s].ar_num).length > 0 && (o.getChildByName("ar").getComponent(Label).string = "AR " + t[s].ar_num), sys.isObjectValid(t[s].bowl_num) && String(t[s].bowl_num).length > 0 && (o.getChildByName("bowl").getComponent(Label).string = "BOWL " + t[s].bowl_num), sys.isObjectValid(t[s].teama_short_name) && String(t[s].teama_short_name).length > 0 && (o.getChildByName("team_name0").getComponent(Label).string = t[s].teama_short_name), sys.isObjectValid(t[s].teamb_short_name) && String(t[s].teamb_short_name).length > 0 && (o.getChildByName("team_name1").getComponent(Label).string = t[s].teamb_short_name), sys.isObjectValid(t[s].teama_num) && String(t[s].teama_num).length > 0 && (o.getChildByName("team_num0").getComponent(Label).string = t[s].teama_num), sys.isObjectValid(t[s].teamb_num) && String(t[s].teamb_num).length > 0 && (o.getChildByName("team_num1").getComponent(Label).string = t[s].teamb_num), sys.isObjectValid(t[s].members) && Array.isArray(t[s].members) && t[s].members.length > 0) {
                for (let e = 0; e < t[s].members.length; e++) {
                    let i = t[s].members[e];
                    1 == Number(i.captain_role) ? (o.getChildByName("cap_node0").getChildByName("wz").getComponent(Label).string = i.short_name, i.out_team_id == t[s].teama_id ? (o.getChildByName("cap_node0").getChildByName("bg").getComponent(Sprite).spriteFrame = this.capBgImgs[0], o.getChildByName("cap_node0").getChildByName("wz").getComponent(Label).color = color(255, 255, 255), o.getChildByName("cap_node0").getChildByName("flag").getChildByName("wz").getComponent(Label).color = color(255, 255, 255), o.getChildByName("cap_node0").getChildByName("flag").getComponent(Sprite).spriteFrame = this.operateImgs[0]) : (o.getChildByName("cap_node0").getChildByName("bg").getComponent(Sprite).spriteFrame = this.capBgImgs[1], o.getChildByName("cap_node0").getChildByName("wz").getComponent(Label).color = color(51, 51, 51), o.getChildByName("cap_node0").getChildByName("flag").getChildByName("wz").getComponent(Label).color = color(51, 51, 51), o.getChildByName("cap_node0").getChildByName("flag").getComponent(Sprite).spriteFrame = this.operateImgs[1]), sys.isObjectValid(i.thumb_url) && i.thumb_url.length > 0 && (this.taskAwardIconMap.set(o.getChildByName("cap_node0").getChildByName("player_icon"), i.thumb_url), Utils.shared().updateNetImage(o.getChildByName("cap_node0").getChildByName("player_icon"), i.thumb_url, size(88, 88)))) : 2 == Number(i.captain_role) && (o.getChildByName("cap_node1").getChildByName("wz").getComponent(Label).string = i.short_name, i.out_team_id == t[s].teama_id ? (o.getChildByName("cap_node1").getChildByName("bg").getComponent(Sprite).spriteFrame = this.capBgImgs[0], o.getChildByName("cap_node1").getChildByName("wz").getComponent(Label).color = color(255, 255, 255), o.getChildByName("cap_node1").getChildByName("flag").getChildByName("wz").getComponent(Label).color = color(255, 255, 255), o.getChildByName("cap_node1").getChildByName("flag").getComponent(Sprite).spriteFrame = this.operateImgs[0]) : (o.getChildByName("cap_node1").getChildByName("bg").getComponent(Sprite).spriteFrame = this.capBgImgs[1], o.getChildByName("cap_node1").getChildByName("wz").getComponent(Label).color = color(51, 51, 51), o.getChildByName("cap_node1").getChildByName("flag").getChildByName("wz").getComponent(Label).color = color(51, 51, 51), o.getChildByName("cap_node1").getChildByName("flag").getComponent(Sprite).spriteFrame = this.operateImgs[1]), sys.isObjectValid(i.thumb_url) && i.thumb_url.length > 0 && (this.taskAwardIconMap.set(o.getChildByName("cap_node1").getChildByName("player_icon"), i.thumb_url), Utils.shared().updateNetImage(o.getChildByName("cap_node1").getChildByName("player_icon"), i.thumb_url, size(88, 88))));
                }
            }
        }
        PushCenter.shared().pushEvent(PushEvent.HideYes11BackkUpDot, i);
        0 == a ? PushCenter.shared().pushEvent(PushEvent.NoticeNotInLineUpInGame, 1) : PushCenter.shared().pushEvent(PushEvent.NoticeNotInLineUpInGame, 0);
    }
    updateGold(e) {
        let t = this.goldNode.getChildByName("coin");
        null != e && t && (t.getComponent(Label).string = ToolUtils.parse_double(e));
    }
    updateNextButtonStatus() {
        sys.isObjectValid(this._teamlistData.can_create_team) && 1 == this._teamlistData.can_create_team ? (this.rootNode.getChildByName("bottom_node").active = true, this.nextNode.active = true, this.nextNode.getComponent(Sprite).spriteFrame = this.btnBgImgs[0], this.nextNode.getComponent(Button).interactable = true, sys.isObjectValid(this._teamlistData.btn_text), this.rootNode.getChildByName("all_ScrollView").getComponent(Widget).bottom = 150, this.rootNode.getChildByName("all_ScrollView").getComponent(Widget).updateAlignment(), this.rootNode.getChildByName("all_ScrollView").getChildByName("view").getComponent(Widget).updateAlignment()) : (this.rootNode.getChildByName("bottom_node").active = false, this.nextNode.active = true, this.nextNode.getComponent(Sprite).spriteFrame = this.btnBgImgs[1], this.nextNode.getComponent(Button).interactable = true, sys.isObjectValid(this._teamlistData.btn_text), this.rootNode.getChildByName("all_ScrollView").getComponent(Widget).bottom = 10, this.rootNode.getChildByName("all_ScrollView").getComponent(Widget).updateAlignment(), this.rootNode.getChildByName("all_ScrollView").getChildByName("view").getComponent(Widget).updateAlignment());
    }
    checkCreateTeam(e = 0, t) {
        let i = { match_id: this._match_id };
        SportCricket_Manager.shared().requestYes11_PreCreateTeamCheck(i, true, (i => {
            let a = { source: this._source, match_id: this._match_id, player_source: i, fromType: e };
            sys.isObjectValid(t) && (a.contest_id = t);
            Utils.shared().showSportCricket_createTeam(a);
        }));
    }
    onCloseButtonClick(e, t) {
        if (SoundManager.shared().playFx("click"), "back_btn" == t) {
            if (this._closed) {
                return;
            }
            this.onBackView();
        }
    }
    initView() {
        if (this.fitScreen(), this.updateTopContestDetails(), sys.isObjectValid(this._source)) {
            this.rootNode.getChildByName("top_node").getChildByName("title").getComponent(Label).string = this._source.teama.short_name + " vs " + this._source.teamb.short_name;
            this.topNode.getChildByName("time_state").active = false;
            let e = this.rootNode.getChildByName("top_node").getChildByName("lefttime");
            sys.isObjectValid(this._source.status) && (this._match_state = this._source.status);
            let t = this.topNode.getChildByName("daybg"), i = this.topNode.getChildByName("hourbg"), a = this.topNode.getChildByName("minbg"), s = Utils.shared().parseTimeCount(this._source.time_left);
            t.getChildByName("time").getComponent(Label).string = s[0] > 9 ? String(s[0]) : "0" + String(s[0]);
            i.getChildByName("time").getComponent(Label).string = s[1] > 9 ? String(s[1]) : "0" + String(s[1]);
            a.getChildByName("time").getComponent(Label).string = s[2] > 9 ? String(s[2]) : "0" + String(s[2]);
            0 == this._source.time_left && 1 == this._source.status ? (e.getComponent(Label).string = this._source.start_day, sys.isObjectValid(this._source.is_current_day) && 1 == Number(this._source.is_current_day) && (this._source.status = 3, e.getComponent(Label).string = "Live", this.topNode.getChildByName("time_state").active = true, this.topNode.getChildByName("time_state").getComponent(Label).string = "Live", t.active = false, i.active = false, a.active = false)) : 1 == this._source.status ? TweenTool.myschedule(e, 1, (() => {
                if (ToolUtils.isObjValid(this.node)) {
                    if (this._source.time_left > 0) {
                        this._source.time_left = this._source.time_left - 1;
                        let e = Utils.shared().parseTimeCount(this._source.time_left);
                        t.getChildByName("time").getComponent(Label).string = e[0] > 9 ? String(e[0]) : "0" + String(e[0]);
                        i.getChildByName("time").getComponent(Label).string = e[1] > 9 ? String(e[1]) : "0" + String(e[1]);
                        a.getChildByName("time").getComponent(Label).string = e[2] > 9 ? String(e[2]) : "0" + String(e[2]);
                    }
                    else {
                        this._source.status = 3;
                        e.getComponent(Label).string = "Live";
                        TweenTool.stopNodeAction(e);
                        this.topNode.getChildByName("time_state").active = true;
                        this.topNode.getChildByName("time_state").getComponent(Label).string = "Live";
                        t.active = false;
                        i.active = false;
                        a.active = false;
                    }
                }
            })) : 3 == this._source.status ? (TweenTool.stopNodeAction(e), e.getComponent(Label).string = "Live", this.topNode.getChildByName("time_state").active = true, this.topNode.getChildByName("time_state").getComponent(Label).string = "Live", t.active = false, i.active = false, a.active = false) : 4 == this._source.status && (TweenTool.stopNodeAction(e), e.getComponent(Label).string = "Cancel", this.topNode.getChildByName("time_state").active = true, this.topNode.getChildByName("time_state").getComponent(Label).string = "Cancel", t.active = false, i.active = false, a.active = false);
            PushCenter.shared().addListener(PushEvent.UpdateYes11CurMatchLeftTime, (t => {
                try {
                    ToolUtils.isObjValid(this.node) && t.match_id == this._match_id && (this._source.time_left = t.time_left, this._source.is_current_day = t.is_current_day, this._match_state = t.status, 3 == t.status ? (TweenTool.stopNodeAction(e), e.getComponent(Label).string = "Live") : 4 == t.status && (TweenTool.stopNodeAction(e), e.getComponent(Label).string = "Cancel"));
                }
                catch (e) {
                    TLog.printError(this.TAG, PushEvent.UpdateYes11CurMatchLeftTime, e);
                }
            }), this);
        }
    }
    onPreviewClick(e, t) {
        if (SoundManager.shared().playFx("click"), sys.now() - this._lastClick < 500) {
            return;
        }
        this._lastClick = sys.now();
        let i = ToolUtils.parseJson(t), a = { match_id: this._match_id, team_id: i.team_id };
        SportCricket_Manager.shared().dealShowPreviewTeamLogic(a, this.node);
    }
    onBackUpTeamClick(e, t) {
        if (SoundManager.shared().playFx("click"), sys.now() - this._lastClick < 500) {
            return;
        }
        if (this._lastClick = sys.now(), 3 == this._match_state) {
            return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("yes11.live_tip"), 2);
        }
        if (4 == this._match_state) {
            return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("yes11.cancel_tip"), 2);
        }
        let i = ToolUtils.parseJson(t), a = { match_id: this._match_id, team_id: i.team_id };
        SportCricket_Manager.shared().requestYes11_PreCreateTeamCheck(a, true, (e => {
            let t = { source: this._source, match_id: this._match_id, player_source: e, team_id: i.team_id, fromType: 3, lastNode: this.node };
            Utils.shared().showSportCricket_backUpPlayers(t);
        }));
    }
    onCopyTeamClick(e, t) {
        if (SoundManager.shared().playFx("click"), sys.now() - this._lastClick < 500) {
            return;
        }
        if (this._lastClick = sys.now(), 3 == this._match_state) {
            return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("yes11.live_tip"), 2);
        }
        if (4 == this._match_state) {
            return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("yes11.cancel_tip"), 2);
        }
        let i = ToolUtils.parseJson(t), a = { match_id: this._match_id, team_id: i.team_id };
        SportCricket_Manager.shared().requestYes11_PreCreateTeamCheck(a, true, (e => {
            let t = { source: this._source, match_id: this._match_id, player_source: e, team_id: i.team_id, fromType: 4, lastNode: this.node };
            Utils.shared().showSportCricket_createTeam(t);
        }));
    }
    onShareTeamClick(e, t) {
        if (SoundManager.shared().playFx("click"), sys.now() - this._lastClick < 500) {
            return;
        }
        if (this._lastClick = sys.now(), 3 == this._match_state) {
            return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("yes11.live_tip"), 2);
        }
        if (4 == this._match_state) {
            return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("yes11.cancel_tip"), 2);
        }
        let i = ToolUtils.parseJson(t);
        Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text48"), 2);
        let a = i.share_text + " " + i.share_url;
        TransferPlatform.shared().shareWebPage(ToolUtils.isSafeString(a));
    }
    onEditTeamClick(e, t) {
        if (SoundManager.shared().playFx("click"), sys.now() - this._lastClick < 500) {
            return;
        }
        if (this._lastClick = sys.now(), 3 == this._match_state) {
            return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("yes11.live_tip"), 2);
        }
        if (4 == this._match_state) {
            return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("yes11.cancel_tip"), 2);
        }
        let i = ToolUtils.parseJson(t), a = { match_id: this._match_id, team_id: i.team_id };
        SportCricket_Manager.shared().requestYes11_PreCreateTeamCheck(a, true, (e => {
            let t = { source: this._source, match_id: this._match_id, player_source: e, team_id: i.team_id, fromType: 3, lastNode: this.node };
            Utils.shared().showSportCricket_createTeam(t);
        }));
    }
    onButtonClick(e, t) {
        SoundManager.shared().playFx("click");
        sys.now() - this._lastClick < 500 || (this._lastClick = sys.now(), 3 != this._match_state ? 4 != this._match_state ? "create" == t ? this.checkCreateTeam() : "add_chip" == t ? (Utils.shared().showStoreView(null, null), User.shared().updatePayScene(PhpReportDefined.pay_scene.hall_cricket)) : "contest" == t && this.onBackView() : Utils.shared().showToast(i18nMgr.shared().getValueByKey("yes11.cancel_tip"), 2) : Utils.shared().showToast(i18nMgr.shared().getValueByKey("yes11.live_tip"), 2));
    }
    onBackView(e = true) {
        e && (Utils.shared().hideLoading(), this.bShowPushAnim ? (this._closed = true, ToolUtils.isObjValid(this._lastNode) && (this._lastNode.active = true), ToolUtils.showPushAnim(this.node, 1, (() => {
            ToolUtils.isObjValid(this.node) && this.node.destroy();
        }))) : (ToolUtils.isObjValid(this._lastNode) && (this._lastNode.active = true), ToolUtils.isObjValid(this.node) && this.node.destroy()));
    }
    fitScreen() {
        ToolUtils.adaptSafeArea(this.rootNode);
        let e = sys.getSafeAreaRect().y, t = view.getVisibleSize();
        if (this.node.getComponent(UITransform).setContentSize(t.width, t.height), 0 != e) {
            let t = this.rootNode.getChildByName("all_ScrollView").getComponent(Widget).bottom;
            this.rootNode.getChildByName("all_ScrollView").getComponent(Widget).bottom = t - e;
        }
    }
}
