// @ts-nocheck
// Recovered from index.js:61
import { _decorator, Label, Node } from "cc";
import i18nMgr from "./i18nMgr";
import User from "./User";
import SoundManager from "./SoundManager";
import BaseLayer from "./BaseLayer";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("CashHelp")
export class CashHelp extends BaseLayer {
    @property(Label)
    public title: Label = null;
    @property(Label)
    public cus_tip: Label = null;
    @property(Node)
    public dp_cnt: Node = null;
    @property(Node)
    public win_cnt: Node = null;
    start() {
        super.start();
        ToolUtils.startShowAnim(this.node.getChildByName("bgVIew"));
    }
    onButtonClick(t, e) {
        SoundManager.shared().playFx("click");
        "close" == e && ToolUtils.isObjValid(this.node) && this.node.destroy();
    }
    setHelpType(t, e = "") {
        if (1 == t) {
            i18nMgr.shared().changeLabelLanguage(this.title, "cash_help.deposit_cash", true);
            this.dp_cnt.active = true;
            this.win_cnt.active = false;
            this.cus_tip.node.active = false;
        }
        else if (2 == t) {
            i18nMgr.shared().changeLabelLanguage(this.title, "cash_help.winnings_cash", true);
            this.dp_cnt.active = false;
            this.win_cnt.active = true;
            this.cus_tip.node.active = false;
        }
        else if (3 == t) {
            i18nMgr.shared().changeLabelLanguage(this.title, "cash_help.tips", true);
            this.dp_cnt.active = false;
            this.win_cnt.active = false;
            this.cus_tip.node.active = true;
            i18nMgr.shared().changeLabelLanguage(this.cus_tip, "cash_help.cash_help2");
        }
        else if (4 == t) {
            i18nMgr.shared().changeLabelLanguage(this.title, "cash_help.tips", true);
            this.dp_cnt.active = false;
            this.win_cnt.active = false;
            this.cus_tip.node.active = true;
            i18nMgr.shared().changeLabelLanguage(this.cus_tip, "cash_help.cash_help3");
        }
        else if (5 == t) {
            i18nMgr.shared().changeLabelLanguage(this.title, "cash_help.tips", true);
            this.dp_cnt.active = false;
            this.win_cnt.active = false;
            this.cus_tip.node.active = true;
            this.cus_tip.string = e;
        }
        else if (6 == t) {
            i18nMgr.shared().changeLabelLanguage(this.title, "cash_help.tips", true);
            this.dp_cnt.active = false;
            this.win_cnt.active = false;
            this.cus_tip.node.active = true;
            let t = i18nMgr.shared().getValueByKey("cash_help.cash_help4");
            User.shared().with_tip && User.shared().with_tip.length > 0 && (t = User.shared().with_tip);
            this.cus_tip.string = t;
        }
        else {
            7 == t && (this.title.string = "TIPS", i18nMgr.shared().changeLabelLanguage(this.title, "cash_help.tips", true), this.dp_cnt.active = false, this.win_cnt.active = false, this.cus_tip.node.active = true, this.cus_tip.string = e);
        }
    }
}
