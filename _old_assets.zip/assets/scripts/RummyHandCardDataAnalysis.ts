// @ts-nocheck
// Recovered from index.js:455
import { _decorator, sys } from "cc";
import { TLog } from "./TLog";
import RummyDataManager, { RUMMY_CARD_GROUP_TYPE } from "./RummyDataManager";
import GameConfig from "./GameConfig";
const { ccclass } = _decorator;
@ccclass("RummyHandCardDataAnalysis")
export default class RummyHandCardDataAnalysis {
    public finalHandCardData: any = null;
    public laiziValue: number = 0;
    public newCardVecData: any[] = [];
    public ceshi: any = null;
    public mainRummy: any = null;
    init(e) {
        this.mainRummy = e;
    }
    startAnalysisMoveHandCard(e, t, r, a) {
        let i, n = 0, s = 0, o = [];
        for (let t = 0, c = e.length; t < c; t++) {
            o.push(e[t]);
            t == r ? i = e[t].type : t != a && (e[t].type == RUMMY_CARD_GROUP_TYPE.eGroup_PureSeq && n++, e[t].type == RUMMY_CARD_GROUP_TYPE.eGroup_Seq && s++);
        }
        this.laiziValue = t;
        let c, h = [a];
        r >= 0 && r != a && h.push(r);
        for (let e = 0, t = h.length; e < t; e++) {
            c = h[e];
            let t = o[c].cardVec;
            if (t.length > 2) {
                if (this.ischunshunFunction(t)) {
                    n++;
                    o[c].type = RUMMY_CARD_GROUP_TYPE.eGroup_PureSeq;
                }
                else {
                    if (this.isshunziFunction(t)) {
                        s++;
                        o[c].type = RUMMY_CARD_GROUP_TYPE.eGroup_Seq;
                    }
                    else {
                        let e = this.isbaoziFunction(t);
                        o[c].type = e ? RUMMY_CARD_GROUP_TYPE.eGroup_Set : RUMMY_CARD_GROUP_TYPE.eGroup_Mix;
                    }
                }
            }
            else {
                let e = this.isallLaiziFunction(t);
                o[c].type = e ? RUMMY_CARD_GROUP_TYPE.eGroup_Laizi : RUMMY_CARD_GROUP_TYPE.eGroup_Mix;
            }
        }
        o = o.filter((e => e.cardVec.length > 0));
        r != a && (o[a].type != RUMMY_CARD_GROUP_TYPE.eGroup_PureSeq && o[a].type != RUMMY_CARD_GROUP_TYPE.eGroup_Seq || this.sortGroupCardData(o[a]), r >= 0 && (o[r].type == RUMMY_CARD_GROUP_TYPE.eGroup_PureSeq || o[r].type == RUMMY_CARD_GROUP_TYPE.eGroup_Seq) && i != RUMMY_CARD_GROUP_TYPE.eGroup_PureSeq && i != RUMMY_CARD_GROUP_TYPE.eGroup_Seq && this.sortGroupCardData(o[r]));
        let u = n + s;
        n > 0 && u > 1 ? this.arrangeFinalHandCardData(o, 1) : n > 0 && 1 == u ? this.arrangeFinalHandCardData(o, 2) : u > 0 ? this.arrangeFinalHandCardData(o, 3) : this.arrangeFinalHandCardData(o, 4);
        for (let e = 0, t = this.finalHandCardData.length; e < t; e++) {
            this.finalHandCardData[e].index = e;
        }
    }
    getFinalHandCardData() {
        return this.finalHandCardData;
    }
    groupBtnClickAnalysis(e, t, r) {
        let a = [], i = [];
        this.laiziValue = r;
        for (let t = 0, r = e.length; t < r; t++) {
            let r = e[t].cardVec, i = [];
            for (let e = 0, t = r.length; e < t; e++) {
                i.push(r[e]);
            }
            let l = [];
            l.cardVec = i;
            l.color = e[t].color;
            l.desc = e[t].desc;
            l.isShowAnime = e[t].isShowAnime;
            l.score = e[t].score;
            l.type = e[t].type;
            l.index = e[t].index;
            a.push(l);
        }
        let l = true;
        if (t.length > 0) {
            for (let e = 0, r = t.length; e < r; e++) {
                const r = t[e].getComponent("RummyCard");
                if (a[r.groupIndex]) {
                    let e = a[r.groupIndex].cardVec;
                    e[r.cardIndex] && e[r.cardIndex] == r.mCardValue || (l = false);
                }
                else {
                    l = false;
                }
            }
            if (l) {
                let e = [];
                e.type = 1;
                e.score = 0;
                e.desc = "";
                e.color = 0;
                e.isShowAnime = "";
                e.cardVec = [];
                for (let r = t.length - 1; r >= 0; r--) {
                    const i = t[r].getComponent("RummyCard");
                    let l = a[i.groupIndex].cardVec;
                    e.cardVec.push(i.mCardValue);
                    l.splice(i.cardIndex, 1);
                }
                i.push(e);
                a = a.filter((e => e.cardVec.length > 0));
                for (let t = 0, r = a.length; t < r; t++) {
                    let r = a[t].cardVec;
                    r.length > 0 && (e = [], e.type = a[t].type, e.score = a[t].score, e.desc = a[t].desc, e.color = a[t].color, e.isShowAnime = a[t].isShowAnime, e.cardVec = r, i.push(e));
                }
            }
        }
        if (i.length > 0) {
            if (i.length > 6) {
                let e = this.gruopGreaterThan6(i);
                return e.length < 7 && (this.analysisHandCardColorFraction(e), this.sortGroupCardData(this.finalHandCardData[0]), this.resortGroupCardsAfterGroup(), true);
            }
            return this.analysisHandCardColorFraction(i), this.sortGroupCardData(this.finalHandCardData[0]), this.resortGroupCardsAfterGroup(), true;
        }
        return false;
    }
    getHandCardDataCheck(e, t) {
        if (1 == GameConfig.HTTP_MSG_DEBUG) {
            for (let e = 0; e < t.length; e++) {
                ;
            }
            for (let t = 0; t < e.length; t++) {
                ;
            }
        }
        let a = false;
        if (t.length != e.length) {
            return true;
        }
        try {
            for (let i = 0, n = e.length; i < n; i++) {
                if (!sys.isObjectValid(e[i]) || !sys.isObjectValid(t[i])) {
                    a = true;
                    break;
                }
                if (!sys.isObjectValid(e[i].cards) || !sys.isObjectValid(t[i].cardVec)) {
                    a = true;
                    break;
                }
                if (!Array.isArray(e[i].cards) || !Array.isArray(t[i].cardVec)) {
                    a = true;
                    break;
                }
                if (e[i].cards.length != t[i].cardVec.length) {
                    a = true;
                    break;
                }
                if (e[i].color != t[i].color) {
                    a = true;
                    break;
                }
                if (e[i].desc != t[i].desc) {
                    a = true;
                    break;
                }
                if (e[i].index != t[i].index) {
                    a = true;
                    break;
                }
                if (e[i].score != t[i].score) {
                    a = true;
                    break;
                }
                let n = t[i].type == RUMMY_CARD_GROUP_TYPE.eGroup_Laizi ? RUMMY_CARD_GROUP_TYPE.eGroup_Mix : t[i].type;
                if (e[i].type != n) {
                    a = true;
                    break;
                }
                for (let r = 0, l = e[i].cards.length; r < l; r++) {
                    if (e[i].cards[r] != t[i].cardVec[r]) {
                        a = true;
                        break;
                    }
                }
            }
        }
        catch (e) {
            a = true;
        }
        return a;
    }
    analysisHandCardColorFraction(e) {
        let t = 0, r = 0;
        for (let a = 0, i = e.length; a < i; a++) {
            let i = e[a].cardVec;
            if (i.length > 2) {
                if (this.ischunshunFunction(i)) {
                    t += 1;
                    e[a].type = RUMMY_CARD_GROUP_TYPE.eGroup_PureSeq;
                }
                else {
                    if (this.isshunziFunction(i)) {
                        r += 1;
                        e[a].type = RUMMY_CARD_GROUP_TYPE.eGroup_Seq;
                    }
                    else {
                        let t = this.isbaoziFunction(i);
                        e[a].type = t ? RUMMY_CARD_GROUP_TYPE.eGroup_Set : RUMMY_CARD_GROUP_TYPE.eGroup_Mix;
                    }
                }
            }
            else {
                let t = this.isallLaiziFunction(i);
                e[a].type = t ? RUMMY_CARD_GROUP_TYPE.eGroup_Laizi : RUMMY_CARD_GROUP_TYPE.eGroup_Mix;
            }
        }
        let a = t + r;
        t > 0 && a > 1 ? this.arrangeFinalHandCardData(e, 1) : t > 0 && 1 == a ? this.arrangeFinalHandCardData(e, 2) : a > 0 ? this.arrangeFinalHandCardData(e, 3) : this.arrangeFinalHandCardData(e, 4);
    }
    ischunshunFunction(e) {
        let t = [];
        for (let r = 0, a = e.length; r < a; r++) {
            t.push(e[r]);
        }
        t.sort((function (e, t) {
            return e - t;
        }));
        let r = t.length, a = t[r - 1] - t[0], i = false;
        for (let e = 1; e < r; e++) {
            let r = e - 1;
            t[e] == t[r] && (i = true);
        }
        return !i && (a == r - 1 || (t[0] = this.cardValueIsA(t[0]), t.sort((function (e, t) {
            return e - t;
        })), a = t[r - 1] - t[0], a == r - 1));
    }
    isshunziFunction(e) {
        this.laiziValue = RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key).laizicard;
        let t, r, a = [], i = [], l = [];
        for (let n = 0, s = e.length; n < s; n++) {
            t = this.laiziValue % 16;
            r = e[n] % 16;
            t == r || 78 == e[n] || 79 == e[n] ? i.push(e[n]) : a.push(e[n]);
            l.push(e[n]);
        }
        a.sort((function (e, t) {
            return e - t;
        }));
        l.sort((function (e, t) {
            return e - t;
        }));
        let s = l.length, o = a.length, c = i.length, h = 0;
        if (o < 2) {
            return true;
        }
        let u = false;
        for (let e = 1; e < o; e++) {
            let t = e - 1;
            a[e] == a[t] && (u = true);
        }
        if (u) {
            return false;
        }
        if (a.length > 0) {
            let e = Math.floor(a[0] / 16);
            for (let t = 0, r = a.length; t < r; t++) {
                if (e != Math.floor(a[t] / 16)) {
                    return false;
                }
            }
        }
        return c > 0 ? (h = a[o - 1] - a[0], h <= o + c - 1 || (1 == a[0] || 17 == a[0] || 33 == a[0] || 49 == a[0]) && (a[0] = this.cardValueIsA(a[0]), a.sort((function (e, t) {
            return e - t;
        })), h = a[o - 1] - a[0], h <= o + c - 1)) : (h = a[o - 1] - a[0], h == o - 1 || (a[0] = this.cardValueIsA(a[0]), a.sort((function (e, t) {
            return e - t;
        })), h = a[o - 1] - a[0], h == s - 1));
    }
    isbaoziFunction(e) {
        this.laiziValue = RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key).laizicard;
        let t, r, a = [], i = [], l = [], s = [];
        for (let n = 0, o = e.length; n < o; n++) {
            t = this.laiziValue % 16;
            r = e[n] % 16;
            t == r || 78 == e[n] || 79 == e[n] ? l.push(e[n]) : (i.push(e[n]), s.push(r));
            a.push(e[n]);
        }
        let o = s.length;
        if (i.sort((function (e, t) {
            return e - t;
        })), e.length > 4) {
            return false;
        }
        let c = false;
        for (let e = 1, t = i.length; e < t; e++) {
            let t = e - 1;
            i[e] == i[t] && (c = true);
        }
        return !c && (s.sort((function (e, t) {
            return e - t;
        })), s[0] == s[o - 1]);
    }
    isallLaiziFunction(e) {
        this.laiziValue = RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key).laizicard;
        let t, r, a = [], i = [], l = [];
        for (let n = 0, s = e.length; n < s; n++) {
            t = this.laiziValue % 16;
            r = e[n] % 16;
            t == r || 78 == e[n] || 79 == e[n] ? l.push(e[n]) : i.push(e[n]);
            a.push(e[n]);
        }
        return !(i.length > 0);
    }
    cardValueIsA(e) {
        return 1 != e && 17 != e && 33 != e && 49 != e || (1 == e ? e = 14 : 17 == e ? e = 30 : 33 == e ? e = 46 : 49 == e && (e = 62)), e;
    }
    arrangeFinalHandCardData(e, t) {
        for (let r = 0, a = e.length; r < a; r++) {
            let a = e[r].cardVec, i = this.getSorce(a);
            e[r].score = i;
            e[r].isShowAnime = 0;
            let n = e[r].color;
            if (a.length < 3 && e[r].type == RUMMY_CARD_GROUP_TYPE.eGroup_Mix) {
                let t = this.isallLaiziFunction(a);
                e[r].type = t ? RUMMY_CARD_GROUP_TYPE.eGroup_Laizi : RUMMY_CARD_GROUP_TYPE.eGroup_Mix;
            }
            e[r].type == RUMMY_CARD_GROUP_TYPE.eGroup_PureSeq ? (e[r].color = 0, e[r].desc = "Pure Sequence") : e[r].type == RUMMY_CARD_GROUP_TYPE.eGroup_Mix ? (e[r].color = 3, a.length > 1 ? e[r].desc = "Invalid(" + i + ")" : e[r].desc = "") : e[r].type == RUMMY_CARD_GROUP_TYPE.eGroup_Laizi ? (e[r].color = 0, a.length > 1 ? e[r].desc = "Jokers" : e[r].desc = "") : 1 == t ? e[r].type == RUMMY_CARD_GROUP_TYPE.eGroup_Seq ? (e[r].color = 0, e[r].desc = "Sequence") : e[r].type == RUMMY_CARD_GROUP_TYPE.eGroup_Set && (e[r].color = 0, e[r].desc = "Set") : 2 == t ? e[r].type == RUMMY_CARD_GROUP_TYPE.eGroup_Seq ? (e[r].color = 0, e[r].desc = "Sequence") : e[r].type == RUMMY_CARD_GROUP_TYPE.eGroup_Set && (e[r].color = 2, e[r].desc = "Set(" + i + ")") : (3 == t || 4 == t) && (e[r].type == RUMMY_CARD_GROUP_TYPE.eGroup_Seq ? (e[r].color = 2, e[r].desc = "Sequence(" + i + ")") : e[r].type == RUMMY_CARD_GROUP_TYPE.eGroup_Set && (e[r].color = 2, e[r].desc = "Set(" + i + ")"));
            0 == e[r].color && 0 != n && (e[r].isShowAnime = 1);
        }
        this.finalHandCardData = e;
    }
    getSorce(e) {
        this.laiziValue = RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key).laizicard;
        let t = [], r = [], a = [];
        for (let i = 0, l = e.length; i < l; i++) {
            this.laiziValue % 16 == e[i] % 16 || 78 == e[i] || 79 == e[i] ? a.push(e[i]) : r.push(e[i]);
            t.push(e[i]);
        }
        let i = r.length, l = 0;
        for (let e = 0; e < i; e++) {
            r[e] = this.cardValueIsA(r[e]);
            let t = r[e] % 16;
            l += t > 9 ? 10 : t;
        }
        return l;
    }
    resortGroupCardsAfterGroup() {
        if (this.finalHandCardData.length > 1) {
            if (this.finalHandCardData[0].type == RUMMY_CARD_GROUP_TYPE.eGroup_Mix) {
                let e = 0;
                for (let t = 1, r = this.finalHandCardData.length; t < r; t++) {
                    this.finalHandCardData[t].type != RUMMY_CARD_GROUP_TYPE.eGroup_PureSeq && this.finalHandCardData[t].type != RUMMY_CARD_GROUP_TYPE.eGroup_Seq && this.finalHandCardData[t].type != RUMMY_CARD_GROUP_TYPE.eGroup_Set && this.finalHandCardData[t].type != RUMMY_CARD_GROUP_TYPE.eGroup_Laizi || (e = t);
                }
                if (e > 0) {
                    let t = this.finalHandCardData[0];
                    this.finalHandCardData.splice(0, 1);
                    this.finalHandCardData.splice(e, 0, t);
                }
            }
            else if (this.finalHandCardData[0].type == RUMMY_CARD_GROUP_TYPE.eGroup_Laizi) {
                let e = 0;
                for (let t = 1, r = this.finalHandCardData.length; t < r && (this.finalHandCardData[t].type == RUMMY_CARD_GROUP_TYPE.eGroup_PureSeq || this.finalHandCardData[t].type == RUMMY_CARD_GROUP_TYPE.eGroup_Seq || this.finalHandCardData[t].type == RUMMY_CARD_GROUP_TYPE.eGroup_Set); t++) {
                    e = t;
                }
                if (e > 0) {
                    let t = this.finalHandCardData[0];
                    this.finalHandCardData.splice(0, 1);
                    this.finalHandCardData.splice(e, 0, t);
                }
            }
            for (let e = 0, t = this.finalHandCardData.length; e < t; e++) {
                this.finalHandCardData[e].index = e;
            }
        }
    }
    gruopGreaterThan6(e) {
        let t = [], r = [];
        for (let a = 0, i = e.length; a < i; a++) {
            let i = e[a].cardVec;
            1 == i.length ? r.push(i[0]) : i.length >= 2 && t.push(e[a]);
        }
        let a = t.length, i = [];
        i.cardVec = r;
        i.color = 0;
        i.desc = "";
        i.isShowAnime = 0;
        i.score = 0;
        i.type = 0;
        i.index = a;
        t.push(i);
        for (let e = 0; e < a; e++) {
            t[e].index = e;
        }
        return t;
    }
    sortGroupCardData(e) {
        this.laiziValue = RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key).laizicard;
        let t = e.cardVec, r = t.length;
        if (e.type == RUMMY_CARD_GROUP_TYPE.eGroup_PureSeq) {
            t.sort((function (e, t) {
                return e - t;
            }));
            t[r - 1] - t[0] == r - 1 || this.sortIsAchuli(t);
        }
        else if (e.type == RUMMY_CARD_GROUP_TYPE.eGroup_Seq) {
            e.cardVec = this.sortGroupShunzi(t);
        }
        else if (e.type == RUMMY_CARD_GROUP_TYPE.eGroup_Set) {
            let r, a, i = [], l = [], n = [];
            for (let e = 0, i = t.length; e < i; e++) {
                r = this.laiziValue % 16;
                a = t[e] % 16;
                r == a || 78 == t[e] || 79 == t[e] ? n.push(t[e]) : l.push(t[e]);
            }
            if (l.length > 0 && l.sort((function (e, t) {
                return e - t;
            })), n.length > 0 && n.sort((function (e, t) {
                return e - t;
            })), l.length > 0) {
                for (let e = 0, t = l.length; e < t; e++) {
                    i.push(l[e]);
                }
            }
            if (n.length > 0) {
                for (let e = 0, t = n.length; e < t; e++) {
                    i.push(n[e]);
                }
            }
            e.cardVec = i;
        }
        else {
            e.type == RUMMY_CARD_GROUP_TYPE.eGroup_Mix ? this.sortIsAchuli(t) : t.sort((function (e, t) {
                return e - t;
            }));
        }
    }
    sortGroupShunzi(e) {
        this.laiziValue = RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key).laizicard;
        let t, r, a = [], i = [], l = [], s = [], o = [];
        for (let a = 0, n = e.length; a < n; a++) {
            t = this.laiziValue % 16;
            r = e[a] % 16;
            t == r || 78 == e[a] || 79 == e[a] ? (l.push(e[a]), o.push(e[a])) : (i.push(e[a]), s.push(e[a]));
        }
        i.sort((function (e, t) {
            return e - t;
        }));
        let c = 0;
        if (s.length > 0) {
            let e, t = Math.floor(s[0] / 16), r = false;
            for (let a = 0, i = o.length; a < i; a++) {
                if (e = Math.floor(o[a] / 16), e == t) {
                    r = true;
                    s.push(o[a]);
                    o.splice(a, 1);
                    break;
                }
            }
            if (s.length < 3 && (r = false), r) {
                s.sort((function (e, t) {
                    return e - t;
                }));
                this.ischunshunFunction(s) && (i = s, l = o);
            }
        }
        let h = i.length, u = l.length;
        if (i.sort((function (e, t) {
            return e - t;
        })), l.sort((function (e, t) {
            return e - t;
        })), i.length < 1) {
            return a = l, a;
        }
        if (!(u > 0)) {
            return c = i[h - 1] - i[0], c == h - 1 || this.sortIsAchuli(i), i;
        }
        {
            c = i[h - 1] - i[0];
            let e = 0;
            if (c <= h + u - 1) {
                for (let t = 0, r = i.length; t < r; t++) {
                    if (0 == t) {
                        a.push(i[t]);
                    }
                    else {
                        let r = i[t] - i[t - 1];
                        if (1 == r) {
                            a.push(i[t]);
                        }
                        else {
                            for (let t = 0; t < r - 1; t++) {
                                a.push(l[e]);
                                e += 1;
                            }
                            a.push(i[t]);
                        }
                    }
                }
                let t = i[h - 1] % 16;
                if (e < u) {
                    for (let r = e; r < u; r++) {
                        t < 14 ? a.push(l[r]) : a.unshift(l[r]);
                        t += 1;
                    }
                }
                return a;
            }
            if (1 == i[0] || 17 == i[0] || 33 == i[0] || 49 == i[0]) {
                this.sortIsAchuli(i);
                for (let t = 0, r = i.length; t < r; t++) {
                    if (0 == t) {
                        a.push(i[t]);
                    }
                    else {
                        let r = i[t] - i[t - 1];
                        if (1 == i[t] ? r = 14 - i[t - 1] : 17 == i[t] ? r = 30 - i[t - 1] : 33 == i[t] ? r = 46 - i[t - 1] : 49 == i[t] && (r = 62 - i[t - 1]), 1 == r) {
                            a.push(i[t]);
                        }
                        else {
                            for (let t = 0; t < r - 1; t++) {
                                a.push(l[e]);
                                e += 1;
                            }
                            a.push(i[t]);
                        }
                    }
                }
                let t = i[h - 1] % 16;
                if (1 == t && (t = 14), e < u) {
                    for (let r = e; r < u; r++) {
                        t < 14 ? a.push(l[r]) : a.unshift(l[r]);
                        t += 1;
                    }
                }
                return a;
            }
        }
    }
    sortIsAchuli(e) {
        e.sort((function (e, t) {
            let r = e, a = t;
            return 1 == r ? r = 14 : 17 == r ? r = 30 : 33 == r ? r = 46 : 49 == r && (r = 62), 1 == a ? a = 14 : 17 == a ? a = 30 : 33 == a ? a = 46 : 49 == a && (a = 62), r - a;
        }));
    }
    logCardData(e) {
        for (let t = 0, r = e.length; t < r; t++) {
            if (null != e[t].cardVec) {
                let r = e[t].cardVec, a = [];
                for (let e = 0, t = r.length; e < t; e++) {
                    a.push(r[e]);
                }
                let i = [];
                i.cardVec = a;
                i.color = e[t].color;
                i.desc = e[t].desc;
                i.isShowAnime = e[t].isShowAnime;
                i.score = e[t].score;
                i.type = e[t].type;
                i.index = e[t].index;
            }
            else {
                TLog.printError("___________________________有为空的手牌数据");
            }
        }
    }
    resortDiscardCards(e, t, a) {
        let i = [];
        for (let e = 0, t = a.length; e < t; e++) {
            let t = [];
            t.type = a[e].type;
            t.score = a[e].score;
            t.desc = a[e].desc;
            t.color = a[e].color;
            t.index = a[e].index;
            t.isShowAnime = a[e].isShowAnime;
            let l = [];
            if (sys.isObjectValid(a[e].cardVec) && Array.isArray(a[e].cardVec)) {
                for (let t = 0, r = a[e].cardVec.length; t < r; t++) {
                    l.push(a[e].cardVec[t]);
                }
            }
            t.cardVec = l;
            i.push(t);
        }
        if (i.length > e) {
            let r = i[e].cardVec;
            r.length > t && r.splice(t, 1);
            0 == r.length && i.splice(e, 1);
        }
        for (let e = 0, t = i.length; e < t; e++) {
            i[e].index = e;
        }
        return this.analysisHandCardColorFraction(i), this.finalHandCardData;
    }
    checkSameCards(e, t) {
        if (1 == GameConfig.HTTP_MSG_DEBUG) {
            for (let t = 0; t < e.length; t++) {
                ;
            }
            for (let e = 0; e < t.length; e++) {
                ;
            }
        }
        let a = 0;
        try {
            if (Array.isArray(e) && Array.isArray(t)) {
                if (e.length != e.length) {
                    a = 1;
                }
                else {
                    for (let i = 0, n = e.length; i < n; i++) {
                        let n = e[i], s = t[i];
                        if (!(sys.isObjectValid(n) && sys.isObjectValid(s) && sys.isObjectValid(n.cardVec) && sys.isObjectValid(s.cardVec))) {
                            a = 1;
                            break;
                        }
                        if (!Array.isArray(n.cardVec) || !Array.isArray(s.cardVec)) {
                            a = 1;
                            break;
                        }
                        if (n.cardVec.length != s.cardVec.length) {
                            a = 1;
                            break;
                        }
                        if ((n.type == RUMMY_CARD_GROUP_TYPE.eGroup_Laizi ? RUMMY_CARD_GROUP_TYPE.eGroup_Mix : n.type) !== s.type || n.color !== s.color || n.desc !== s.desc || n.score !== s.score || n.index !== s.index) {
                            a = 1;
                            break;
                        }
                        for (let e = 0, t = n.cardVec.length; e < t; e++) {
                            if (n.cardVec[e] != s.cardVec[e]) {
                                a = 1;
                                break;
                            }
                        }
                        if (1 == a) {
                            break;
                        }
                    }
                }
            }
        }
        catch (e) {
            a = 1;
        }
        return a;
    }
    transferToMyLocalGroups(e) {
        let t = [];
        if (sys.isObjectValid(e) && Array.isArray(e)) {
            for (let r = 0, a = e.length; r < a; r++) {
                const a = e[r];
                let i = [];
                i.type = a.type;
                i.index = a.index;
                i.score = a.score;
                i.desc = a.desc;
                i.color = a.color;
                i.isShowAnime = a.isShowAnime;
                i.isCatchGroup = a.is_lastcatch_index;
                i.catchIndex = a.catch_card_index;
                let l = [];
                if (a.cards) {
                    for (let e = 0, t = a.cards.length; e < t; e++) {
                        const t = a.cards[e];
                        l.push(t);
                    }
                }
                i.cardVec = l;
                t.push(i);
            }
        }
        return t;
    }
    checkHandCardsIfHu(e) {
        let t = true;
        for (let a = 0; a < e.length; a++) {
            if (sys.isObjectValid(e[a].color) && 0 != e[a].color && e[a].cardVec.length > 0) {
                t = false;
                break;
            }
        }
        return t;
    }
    getFinishDeclareCards(e) {
        let t = [];
        for (let a = 0; a < e.length; a++) {
            if (sys.isObjectValid(e[a].cardVec) && e[a].cardVec.length > 0) {
                let r = [];
                for (let t = 0; t < e[a].cardVec.length; t++) {
                    r.push(e[a].cardVec[t]);
                }
                t.push(r);
            }
        }
        return t;
    }
}
