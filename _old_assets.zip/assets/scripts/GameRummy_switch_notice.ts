// @ts-nocheck
// Recovered from index.js:163
import { _decorator, Label, Node } from "cc";
import BaseLayer from "./BaseLayer";
import i18nMgr from "./i18nMgr";
import { ToolUtils } from "./ToolUtils";
import GameConfig from "./GameConfig";
import SoundManager from "./SoundManager";
import RummyDataManager, { RUMMY_GAME_TYPE } from "./RummyDataManager";
const { ccclass, property } = _decorator;
@ccclass("GameRummy_switch_notice")
export default class GameRummy_switch_notice extends BaseLayer {
    @property(Label)
    public contentLabel: Label = null;
    @property(Label)
    public tips1: Label = null;
    @property(Label)
    public tips2: Label = null;
    @property(Node)
    public okayBtn: Node = null;
    @property(Node)
    public cancelBtn: Node = null;
    public gameController: any = undefined;
    onLoad() {
        this.bIsInGame = true;
    }
    start() {
        super.start();
        ToolUtils.showFullScreen(this.node.getChildByName("bg1"));
        ToolUtils.startShowAnim(this.node.getChildByName("rootNode"));
    }
    initView(t, e, i, n, r) {
        this.gameController = t;
        this.tid_key = e;
        let a = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_switch.tip1"), ToolUtils.parse_double("" + i, 0));
        1 == RummyDataManager.shared().rummyInfos.get(this.tid_key).crashModel && (a = 1 == GameConfig.CHIPS_MODLE ? ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_switch.tip4_practice"), ToolUtils.parse_ChipNum2("" + i)) : ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_switch.tip1_practice"), ToolUtils.parse_ChipNum2("" + i)));
        this.contentLabel.string = a;
        2 == i18nMgr.shared().language ? this.contentLabel.getComponent(Label).fontSize = 24 : this.contentLabel.getComponent(Label).fontSize = 28;
    }
    touchBtnEvent(t, e) {
        SoundManager.shared().playFx("click");
        "close" == e ? ToolUtils.isObjValid(this.node) && this.node.destroy() : "okay" == e && RummyDataManager.shared().rummyInfos.has(this.tid_key) && (RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType == RUMMY_GAME_TYPE.POINTS || RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType == RUMMY_GAME_TYPE.MULTIPLE ? this.gameController.handler_pre_switch_request() : this.gameController.switchCallback(), ToolUtils.isObjValid(this.node) && this.node.destroy());
    }
    onBackView() {
        ToolUtils.isObjValid(this.node) && this.node.destroy();
    }
}
