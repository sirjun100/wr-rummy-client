// @ts-nocheck
// Recovered from index.js:461
import { _decorator, Button, color, instantiate, Label, Node, RichText, ScrollView, size, sp, Sprite, SpriteFrame, sys, UITransform, v3, Vec3, view } from "cc";
import { TransferPlatform } from "./TransferPlatform";
import { TLog } from "./TLog";
import TweenTool from "./TweenTool";
import Utils from "./Utils";
import SoundManager from "./SoundManager";
import BaseLayer from "./BaseLayer";
import i18nMgr from "./i18nMgr";
import { RoomRewardType } from "./RummyDataManager";
import User from "./User";
import { ToolUtils } from "./ToolUtils";
import HttpManager from "./HttpManager";
import PhpReportDefined from "./PhpReportDefined";
const { ccclass, property } = _decorator;
@ccclass("RummyMatchOver")
export class RummyMatchOver extends BaseLayer {
    @property(Node)
    public winRoot: Node = null;
    @property(Node)
    public loseRoot: Node = null;
    @property([SpriteFrame])
    public iconImages: SpriteFrame[] = [];
    @property(Node)
    public rankNode: Node = null;
    @property(Node)
    public bubble_tipNode: Node = null;
    @property([SpriteFrame])
    public ticket_images: SpriteFrame[] = [];
    @property([SpriteFrame])
    public small_ticket_images: SpriteFrame[] = [];
    public callback: any = null;
    public msg: any = null;
    public lastClick: number = 0;
    public drawItemNode: any = null;
    public rewardRaceData: any = null;
    public drawIndex: number = 0;
    public rewardItems: any[] = [];
    public small_ticket_index: number = 0;
    public rewardNames: any[] = ["reward_watch.png"];
    public lastTime: number = 0;
    onLoad() {
        this.bIsInGame = true;
    }
    start() {
        super.start();
        let e = this.node.getChildByName("mask");
        ToolUtils.showFullScreen(e);
        this.node.getChildByName("rootNode").active = true;
        this.bubble_tipNode.getChildByName("mask").getComponent(UITransform).setContentSize(view.getVisibleSize());
        this.adapptationScreen();
        this.refreshView();
    }
    onDestroy() {
        super.onDestroy();
    }
    setParaData(e, t, i) {
        this.msg = e;
        this.callback = i;
    }
    refreshView() {
        if (this.msg) {
            let e = this.node.getChildByName("mask");
            1 == this.msg.is_win ? (e.getComponent(Sprite).color = color(0, 0, 0, 178), this.winRoot.active = false, this.loseRoot.active = false, this.showMatchWin()) : (e.getComponent(Sprite).color = color(0, 0, 0, 178), this.winRoot.active = false, this.loseRoot.active = true);
        }
    }
    showMatchLose() {
        this.winRoot.active = false;
        this.loseRoot.active = true;
        let e = this.loseRoot.getChildByName("anim");
        e.active = true;
        let t = e.getChildByName("title_node"), i = t.getChildByName("title"), a = this.loseRoot.getChildByName("content");
        a.active = false;
        t.active = true;
        i.active = true;
        let s = a.getChildByName("top1"), o = a.getChildByName("top2");
        if (sys.isObjectValid(this.msg.game_mode) && 2 == this.msg.game_mode) {
            s.active = true;
            o.active = false;
            let e = s.getChildByName("pts").getComponent(Label);
            i18nMgr.shared().changeLabelFont(e.getComponent(Label));
            e.getComponent(Label).string = ToolUtils.format(i18nMgr.shared().getValueByKey("match_over.lose_tip0"), this.msg.score);
            let t = s.getChildByName("reward").getComponent(Label);
            i18nMgr.shared().changeLabelFont(t.getComponent(Label));
            t.getComponent(Label).string = ToolUtils.format(i18nMgr.shared().getValueByKey("match_over.lose_tips1"), this.msg.min_reward_score);
            e.node.active = true;
            t.node.active = true;
        }
        else {
            s.active = false;
            o.active = true;
            let e = o.getChildByName("rank").getComponent(Label);
            e.node.active = true;
            i18nMgr.shared().changeLabelFont(e);
            e.string = ToolUtils.format(i18nMgr.shared().getValueByKey("match_over.lose_tip2"), this.msg.rank, ToolUtils.isSafeNumber(this.msg.next_score));
            o.getChildByName("tip").active = true;
        }
        let r = e.getComponent(sp.Skeleton);
        r.clearTracks();
        r.setAnimation(0, "1_fail_start", false);
        r.addAnimation(0, "2_fail_stationary", true);
        let n = new Vec3;
        a.getPosition(n);
        TweenTool.delayAct(this.node, (() => {
            a.active = true;
            let e = a.getChildByName("exit_btn"), t = a.getChildByName("agin_btn");
            e.active = true;
            1 == this.msg.rejoin ? (t.active = true, e.setPosition(v3(-62, -179)), t.setPosition(v3(178, -179))) : (t.active = false, e.setPosition(v3(62, -179)));
            TweenTool.moveToByFade(a, 0.2, n, 0, 1, true);
        }), 0.15, true);
    }
    checkIfShowShareBtn(e, t) {
        let i = false, a = User.shared().gameShareConfig;
        sys.isObjectValid(a) && sys.isObjectValid(a.share_show) && 1 == a.share_show && (i = true);
        t || (i = false);
        e.active = i;
    }
    showMatchWin() {
        this.winRoot.active = true;
        this.loseRoot.active = false;
        let e = this.winRoot.getChildByName("rank");
        sys.isObjectValid(this.msg.game_mode) && 2 == this.msg.game_mode ? e.active = false : (e.active = true, e.getComponent(Label).string = ToolUtils.format("${0}", this.msg.rank), this.rewardRaceData = this.msg.infos2);
        let t = this.winRoot.getChildByName("reward_di").getChildByName("prize_root");
        if (t && sys.isObjectValid(this.rewardRaceData) && Array.isArray(this.rewardRaceData)) {
            let e = [];
            for (let t = 0; t < this.rewardRaceData.length; t++) {
                let i = this.rewardRaceData[t];
                i.type != RoomRewardType.CASH && i.type != RoomRewardType.BONUS && i.type != RoomRewardType.TICKET && i.type != RoomRewardType.PHYSICAL || e.push(i);
            }
            e.sort(((e, t) => e.type - t.type));
            this.rewardRaceData = e;
            let i = e.length;
            t.active = true;
            let a = t.getChildByName("layout0"), s = t.getChildByName("layout1"), o = t.getChildByName("layout2"), r = t.getChildByName("layout3"), n = a.getChildByName("gold").getComponent(Label), l = s.getChildByName("bonus").getComponent(Label), c = o.getChildByName("discount").getComponent(Label), g = o.getChildByName("ic").getComponent(Sprite);
            a.active = false;
            s.active = false;
            o.active = false;
            r.active = false;
            for (let t = 0; t < i; t++) {
                const i = e[t];
                if (sys.isObjectValid(i)) {
                    if (sys.isObjectValid(i.type) && 2 == i.type) {
                        a.active = true;
                        sys.isObjectValid(i.value) && (n.string = "" + i.value);
                    }
                    else if (sys.isObjectValid(i.type) && 6 == i.type) {
                        s.active = true;
                        sys.isObjectValid(i.value) && (l.string = "" + i.value);
                    }
                    else if (sys.isObjectValid(i.type) && 11 == i.type && (o.active = true, sys.isObjectValid(i.discount))) {
                        0 != i18nMgr.shared().language && i18nMgr.shared().changeLabelFont(c);
                        let e = ToolUtils.format(i18nMgr.shared().getValueByKey("ticket.off"), i.discount);
                        sys.isObjectValid(i.value) && Number(i.value) >= 2 && (e = e + "*" + i.value);
                        c.string = e;
                        let t = Number(i.discount);
                        g.spriteFrame = 100 == t ? this.ticket_images[1] : this.ticket_images[0];
                    }
                }
            }
            t.getChildByName("split2").active = a.active && s.active;
            t.getChildByName("split2").active = a.active && o.active;
            t.getChildByName("split3").active = s.active && o.active;
        }
        sys.isObjectValid(this.msg.show_share) && 1 == this.msg.show_share && (this.winRoot.getChildByName("share_btn").active = true, this.winRoot.getChildByName("exit_btn").active = false, HttpManager.shared().doReportClick({ module: PhpReportDefined.module.share, scene: PhpReportDefined.scece.share_gameover, event: PhpReportDefined.share_event.show }));
    }
    resetPointsWinNodesVisible() {
        this.winRoot.getChildByName("top_node").active = false;
        let e = this.winRoot.getChildByName("reward_root");
        e.active = false;
        e.destroyAllChildren();
        this.winRoot.getChildByName("item").active = false;
        this.winRoot.getChildByName("bottom_node").active = false;
    }
    refreshPointsTopNode() {
        let e = this.winRoot.getChildByName("top_node"), t = e.getChildByName("rank_tips"), i = e.getChildByName("pts_tips");
        sys.isObjectValid(this.msg.game_mode) && 2 == this.msg.game_mode ? (i.active = true, t.active = false, i18nMgr.shared().changeLabelFont(i.getComponent(RichText)), i.getComponent(RichText).string = ToolUtils.format(i18nMgr.shared().getValueByKey("match_over.over_tips"), this.msg.score)) : (i.active = false, t.active = true, i18nMgr.shared().changeLabelFont(t.getComponent(RichText)), t.getComponent(RichText).string = ToolUtils.format(i18nMgr.shared().getValueByKey("match_over.over_tips2"), this.msg.rank));
    }
    refreshPointsRaceReward() {
        let e = this.winRoot.getChildByName("reward_root");
        e.destroyAllChildren();
        let t = this.winRoot.getChildByName("item");
        if (t.active = false, this.rewardItems = [], sys.isObjectValid(this.rewardRaceData) && Array.isArray(this.rewardRaceData) && this.rewardRaceData.length > 0) {
            let i = [];
            for (let e = 0; e < this.rewardRaceData.length; e++) {
                let t = this.rewardRaceData[e];
                t.type != RoomRewardType.CASH && t.type != RoomRewardType.BONUS && t.type != RoomRewardType.TICKET && t.type != RoomRewardType.PHYSICAL || i.push(t);
            }
            i.sort(((e, t) => e.type - t.type));
            let a = i.length;
            for (let s = 0; s < a; s++) {
                let o = this.addRewardItem(i[s], t, s), r = v3(140 * (s - (a - 1) / 2) + 0, 0);
                o.setPosition(r);
                e.addChild(o);
                o.active = true;
                this.rewardItems[s] = o;
            }
            this.rewardRaceData = i;
        }
    }
    refreshPointsRewardList() {
        try {
            let e = this.winRoot.getChildByName("reward_di");
            e.active = true;
            let t = new Vec3;
            e.getPosition(t);
            e.setPosition(new Vec3(t.x + 360, t.y));
            let i = e.getChildByName("item");
            i.active = false;
            let a = e.getChildByName("ScrollView").getComponent(ScrollView);
            if (a.content.destroyAllChildren(), this.msg.reward_infos && this.msg.reward_infos.length > 0) {
                let e;
                for (let t = 0, s = this.msg.reward_infos.length; t < s; t++) {
                    let s = this.msg.reward_infos[t];
                    e = instantiate(i);
                    a.content.addChild(e);
                    e.active = true;
                    e.getChildByName("Id").getComponent(Label).string = String(t + 1);
                    e.getChildByName("pts").getComponent(Label).string = ToolUtils.parse_double(String(s.points), -1) + "PTS";
                    sys.isObjectValid(s.draw) && 1 == s.draw && (this.drawItemNode = e, this.rewardRaceData = s.infos2, this.drawIndex = t);
                    let o = e.getChildByName("prize_root");
                    if (o && sys.isObjectValid(s.infos2) && Array(s.infos2) && s.infos2.length > 0) {
                        o.active = true;
                        let e = o.getChildByName("layout0"), t = o.getChildByName("layout1"), i = o.getChildByName("layout2"), a = e.getChildByName("gold").getComponent(Label), r = t.getChildByName("bonus").getComponent(Label), n = i.getChildByName("discount").getComponent(Label), l = i.getChildByName("ic").getComponent(Sprite);
                        e.active = false;
                        t.active = false;
                        i.active = false;
                        for (let o = 0; o < s.infos2.length; o++) {
                            const h = s.infos2[o];
                            if (sys.isObjectValid(h)) {
                                if (sys.isObjectValid(h.type) && 2 == h.type) {
                                    e.active = true;
                                    sys.isObjectValid(h.value) && (a.string = "" + ToolUtils.parse_double(String(h.value), -1));
                                }
                                else if (sys.isObjectValid(h.type) && 6 == h.type) {
                                    t.active = true;
                                    sys.isObjectValid(h.value) && (r.string = "" + ToolUtils.parse_double(String(h.value), -1));
                                }
                                else if (sys.isObjectValid(h.type) && 11 == h.type && (i.active = true, sys.isObjectValid(h.discount))) {
                                    0 != i18nMgr.shared().language && i18nMgr.shared().changeLabelFont(n);
                                    n.string = ToolUtils.format(i18nMgr.shared().getValueByKey("ticket.off"), h.discount);
                                    l.spriteFrame = this.small_ticket_images[2];
                                    let e = Number(h.discount);
                                    sys.isObjectValid(s.draw) && 1 == s.draw && (this.small_ticket_index = 100 == e ? 1 : 0);
                                }
                            }
                        }
                    }
                }
            }
            this.drawIndex >= 2 && a.scrollToBottom();
            TweenTool.moveToByFade(e, 0.33, t, 0, 1, true);
        }
        catch (e) {
            TLog.printError("trycatch error refreshPointsRewardList:", e);
        }
    }
    addRewardItem(e, t, i) {
        let a = instantiate(t);
        a.active = true;
        let s = a.getChildByName("num").getComponent(Label), o = Number(e.type);
        sys.isObjectValid(e.value) && (o === RoomRewardType.CASH || o === RoomRewardType.BONUS ? s.string = ToolUtils.parse_double(e.value, -1) : s.string = e.value + "");
        let r = a.getChildByName("name").getComponent(Label), n = "";
        i18nMgr.shared().changeLabelFont(r);
        let l = a.getChildByName("icon").getComponent(Sprite), c = a.getChildByName("ticket_node"), g = c.getChildByName("discount").getComponent(Label), u = a.getChildByName("tips_btn"), y = a.getChildByName("tips_icon");
        if (o == RoomRewardType.CASH) {
            l.spriteFrame = this.iconImages[0];
            n = i18nMgr.shared().getValueByKey("store.cash");
        }
        else if (o == RoomRewardType.BONUS) {
            l.spriteFrame = this.iconImages[1];
            n = i18nMgr.shared().getValueByKey("store.bonus");
        }
        else if (o == RoomRewardType.TICKET) {
            if (l.spriteFrame = this.iconImages[2], n = i18nMgr.shared().getValueByKey("store.ticket"), c.active = true, sys.isObjectValid(e.discount)) {
                let t = Number(e.discount);
                100 == Number(t) ? (l.spriteFrame = this.ticket_images[1], c.setPosition(v3(0, 0))) : (l.spriteFrame = this.ticket_images[0], c.setPosition(v3(-6, 0)));
                g.string = String(t);
            }
            u.active = true;
            y.active = true;
            u.getComponent(Button).clickEvents[0].customEventData = String(i);
        }
        else if (o == RoomRewardType.PHYSICAL) {
            u.active = true;
            y.active = true;
            u.getComponent(Button).clickEvents[0].customEventData = String(i);
            let t = ToolUtils.isSafeString(e.item_url), a = ToolUtils.getImageUrlPictureName(t);
            ToolUtils.isSafeString(a).length > 0 && (a != this.rewardNames[0] ? (l.spriteFrame = this.iconImages[4], Utils.shared().updateNetImage(l.node, t, size(134, 134), (() => {
            }))) : l.spriteFrame = this.iconImages[3]);
            sys.isObjectValid(e.item_num) && (s.string = e.item_num + "");
        }
        else {
            c.active = false;
            u.active = false;
            y.active = false;
        }
        return r.string = n, r.node.active = false, a;
    }
    getRankName(e) {
        let t = "";
        return t = 1 == e ? "st" : 2 == e ? "nd" : 3 == e ? "rd" : "th", t;
    }
    onButtonClick(e, t) {
        if (SoundManager.shared().playFx("click"), "agin" == t) {
            if (sys.now() - this.lastClick < 3000) {
                return;
            }
            this.lastClick = sys.now();
        }
        else if ("share" == t) {
            if (User.shared().shareMainInfo) {
                let e = ToolUtils.isSafeString(User.shared().shareMainInfo.match_share_text), t = ToolUtils.isSafeString(User.shared().shareMainInfo.share_url), i = sys.now();
                if (0 === TransferPlatform.shared().checkPackageInstalled("com.whatsapp")) {
                    Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text48"), 2);
                    let i = e + " " + t;
                    return TransferPlatform.shared().shareWebPage(ToolUtils.isSafeString(i)), void HttpManager.shared().doReportClick({ module: PhpReportDefined.module.share, scene: PhpReportDefined.scece.share_gameover, event: PhpReportDefined.share_event.click_share });
                }
                if (i - this.lastTime < 500) {
                    return;
                }
                this.lastTime = i;
                let a = e + " " + t;
                ToolUtils.isSafeString(a).length > 0 && (User.shared().shareImageAndTextToThirdApp(1, "", a), HttpManager.shared().doReportClick({ module: PhpReportDefined.module.share, scene: PhpReportDefined.scece.share_gameover, event: PhpReportDefined.share_event.click_share }));
            }
            return;
        }
        this.callback && this.callback(t);
    }
    itemCloseTipsClick(e, t) {
        SoundManager.shared().playFx("click");
        this.bubble_tipNode.active = false;
    }
    onItemTipsBtnClick(e, t) {
        SoundManager.shared().playFx("click");
        this.bubble_tipNode.active = true;
        let i = this.bubble_tipNode.getChildByName("bubble"), a = this.bubble_tipNode.getChildByName("bubble2"), s = this.rewardItems[Number(t)], o = new Vec3;
        s.getWorldPosition(o);
        let r = v3();
        if (this.node.inverseTransformPoint(r, o), Array.isArray(this.rewardRaceData) && this.rewardRaceData.length > Number(t)) {
            let e = this.rewardRaceData[Number(t)];
            if (e.type == RoomRewardType.TICKET) {
                i.active = true;
                a.active = false;
                i.setPosition(v3(r.x, r.y + 207));
                let t = i.getChildByName("name").getComponent(Label), s = i.getChildByName("purpose").getComponent(Label);
                if (sys.isObjectValid(e.discount)) {
                    let i = e.discount;
                    i18nMgr.shared().changeLabelFont(t);
                    t.string = ToolUtils.format(i18nMgr.shared().getValueByKey("ticket.reward_tip_name"), i);
                    i18nMgr.shared().changeLabelFont(s);
                    sys.isObjectValid(e.match_name) && (s.string = ToolUtils.format(i18nMgr.shared().getValueByKey("ticket.reward_tip_purpose"), e.match_name, i));
                }
            }
            else if (e.type == RoomRewardType.PHYSICAL && (i.active = false, a.active = true, a.setPosition(v3(r.x, r.y + 77)), sys.isObjectValid(e.tips) && ToolUtils.isSafeString(e.tips).length > 0)) {
                a.getChildByName("tips").getComponent(Label).string = e.tips;
            }
        }
    }
    adapptationScreen() {
    }
    setLandscapeShow() {
        ToolUtils.getOrientation() || this.node.setRotationFromEuler(v3(0, 0, -90));
    }
    setTidKey(e) {
        this.tid_key = e;
    }
}
