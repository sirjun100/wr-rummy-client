// @ts-nocheck
// Recovered from index.js:477
import { _decorator, color, instantiate, Label, Layout, Node, Prefab, size, sp, Sprite, SpriteAtlas, SpriteFrame, sys, tween, UITransform, v2, v3, Vec3 } from "cc";
import User from "./User";
import Utils from "./Utils";
import RummyDataManager, { RUMMY_GAME_TYPE, RUMMY_MATCH_MODE, RUMMY_PLAYER_STATE_TYPE } from "./RummyDataManager";
import GameConfig from "./GameConfig";
import { TLog } from "./TLog";
import TweenTool from "./TweenTool";
import RummyCardConstant from "./RummyCardConstant";
import PushCenter from "./PushCenter";
import PushEvent from "./PushEvent";
import i18nMgr from "./i18nMgr";
import SoundManager from "./SoundManager";
import Parent, { AdapDirection } from "./Parent";
import { ToolUtils } from "./ToolUtils";
import RobotAvatar from "./RobotAvatar";
const { ccclass, property } = _decorator;
@ccclass("RummyPlayerRoot")
export default class RummyPlayerRoot extends Parent {
    @property(Node)
    public img_close: Node = null;
    @property(Node)
    public img_open: Node = null;
    @property(Node)
    public img_turn: Node = null;
    @property(Prefab)
    public cardPrefab: Prefab = null;
    @property([SpriteFrame])
    public player_head_img: SpriteFrame[] = [];
    @property([SpriteFrame])
    public vip_img: SpriteFrame[] = [];
    @property(SpriteAtlas)
    public clubKuangAtlas: SpriteAtlas = null;
    @property([sp.SkeletonData])
    public enterAnimVec: sp.SkeletonData[] = [];
    @property([SpriteFrame])
    public double_bgImgs: SpriteFrame[] = [];
    public data: any = {};
    public _vecFVPos: any[] = [];
    public compareAnimFlag: number = 0;
    public _mBeginPos: number = 0;
    public _mEndPos: number = 0;
    public _mLossPos: number = 0;
    public handCardScore: number = 0;
    public hasChangeSelected: boolean = false;
    public signMoney: number = 1000000;
    public zhuangFlag: number = 0;
    public isSuozhu: boolean = false;
    public selectIndex: number = 0;
    public curmoney: number = 0;
    public isUpdateFlag: boolean = false;
    public mcd: number = 0;
    public mcdFlag: number = 0;
    public mcdPos: number = 0;
    public nLastCd: number = 0;
    public bIsTimeout: boolean = false;
    public isjiesuanUpdateFlag: boolean = false;
    public jiesuanCountDown: number = 0;
    public orginPlayerPosVec: any[] = [];
    public tid_key: string = "";
    public playerPos: any[] = [];
    public time_node: any = null;
    public delay_node: any[] = [];
    public time_action: any = null;
    public stepDt: number = 0.1;
    private timerTickAt: number = 0;
    private settlementTickAt: number = 0;
    public _bPiPeiAnimShow: any[] = [false, false, false, false, false, false];
    public decision_actions: any[] = [];
    public decision_times: Map = new Map;
    public track_times: Map = new Map;
    public TAG: string = "RummyPlayerRoot";
    public translateHeadImg: any[] = ["rummy_img.head_away", "rummy_img.head_drop", "rummy_img.head_middle_drop", "rummy_img.head_wrong_show", "rummy_img.head_waiting", "rummy_img.head_lost", "rummy_img.head_ready", "rummy_img.head_out"];
    public _whiteColor: any = color(255, 255, 255);
    public _grayColor: any = color(127, 127, 127);
    public enterAnimName: any[] = ["Appearing_motorcycle", "Appearing_bird", "throne_1", "Array1", "Array2"];
    public enterAnimSound: any[] = ["motorcycle", "phoenix", "throne", "array1", "array2"];
    public bIsHideBonustTime: boolean = false;
    onLoad() {
        let e;
        this.orginPlayerPosVec = [];
        for (let t = 0; t < 6; t++) {
            e = this.node.getChildByName("player" + t);
            e && (this.orginPlayerPosVec.push(e.getPosition()), this.playerPos.push(e.getPosition()), 0 != t && (e.active = false));
            this.delay_node[t] = new Node;
            this.node.addChild(this.delay_node[t]);
        }
        this.fitScreen();
        this.initPushCenter();
        this.time_action = TweenTool.myschedule(RummyDataManager.shared().sceneNode, this.stepDt, this.updateTimer.bind(this));
        this.hidePaiNum();
        this.initPlayerView();
        this.dealMultipleLanguages();
    }
    dealMultipleLanguages() {
        2 == i18nMgr.shared().language ? this.node.getChildByName("finishslot").getChildByName("finish_txt").getComponent(Label).fontSize = 32 : 3 == i18nMgr.shared().language && (this.img_turn.getChildByName("finish_txt").getComponent(Label).fontSize = 24);
    }
    showPlayerRootTimeAction(e) {
        this.time_action && (1 == e ? TweenTool.stopAction(this.time_action) : 0 == e && this.time_action.start());
    }
    start() {
    }
    setPaiDuiBgShow(e, t = false) {
        this.node.getChildByName("finishslot").active = e;
        this.node.getChildByName("paidui_di").active = e;
        this.node.getChildByName("qipai_di").active = e;
        e || this.hidePaiNum();
        let i = RummyDataManager.shared().rummyInfos.get(this.tid_key);
        sys.isObjectValid(i) && 1 == i.is_multiple && t && (this.node.getChildByName("finishslot").getChildByName("time_txt").getComponent(Label).string = "");
    }
    initPlayerView() {
        let e = this.node.getChildByName("opencard_btn");
        e && (e.active = false);
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().removeListenersByTag(this);
        this.unscheduleAllCallbacks();
        this.time_action && (TweenTool.stopAction(this.time_action), this.time_action = null);
        for (let e = 0; e < 6; e++) {
            TweenTool.stopNodeAction(this.delay_node[e]);
            this.decision_actions[e] && (TweenTool.stopAction(this.decision_actions[e]), this.decision_actions[e] = null);
        }
    }
    fitScreen() {
        let e = this.node.getChildByName("player0");
        if (ToolUtils.isPadPlatform()) {
            this.resetUiPos(e, AdapDirection.Down, true, 1, false);
        }
        else {
            let t = ToolUtils.getFitBottomHeightDiff();
            if (t > 0) {
                let i = new Vec3;
                e.getPosition(i);
                e.setPosition(v3(i.x, i.y - t, i.z));
            }
        }
    }
    resetAll() {
        this.hidePaiNum();
        this.resetPlayerView();
        this.resetAllCard();
        this.setPaiDuiBgShow(false, true);
        this.stopPlayerTimer();
        for (let e = 0; e <= 5; e++) {
            this.stopPlayerTimerByPos(e);
        }
        this.hideAllEasyGameLight();
        this.bIsHideBonustTime = false;
    }
    showLoseScore(e, t, i, a = -1, s = -1) {
        let o = "player" + e, l = this.node.getChildByName(o);
        if (0 == e && 1 == User.shared().isInPerformanceRoom && RummyDataManager.shared().performancePlayer) {
            l = RummyDataManager.shared().performancePlayer;
            let e = l.getChildByName("name_bg");
            if (this.handCardScore = t, e) {
                let a = e.getChildByName("scoreNode").getChildByName("Layout"), s = a.getChildByName("scoreItem"), o = a.getChildByName("score");
                o && (Utils.shared().setStr(o, "" + t), o.active = i);
                s.active = i;
            }
            let a = l.getChildByName("pts_bg");
            if (a) {
                let e = a.getChildByName("scoreNode").getChildByName("Layout").getChildByName("score"), i = ToolUtils.parse_double(t + "", -2);
                Utils.shared().setStr(e, i);
            }
            return;
        }
        let r = RummyDataManager.shared().rummyInfos.get(this.tid_key);
        if (0 == e && sys.isObjectValid(r) && 1 == r.is_multiple) {
            if (l) {
                l.getChildByName("head_kuang").active = false;
                l.getChildByName("head_multiple_kuang").active = true;
                let e = l.getChildByName("name_bg");
                if (this.handCardScore = t, e) {
                    let o = e.getChildByName("score"), l = e.getChildByName("scoreItem"), r = 0;
                    o && (s > 0 && a > 0 ? (Utils.shared().setStr(o, a + "/" + ToolUtils.parse_double("" + t, -2)), r = ("" + ToolUtils.parse_double("" + t, -2)).length > 3 ? -8 : -6) : 0 == t ? Utils.shared().setStr(o, "0/0") : Utils.shared().setStr(o, "" + ToolUtils.parse_double("" + t, -2)), o.active = i);
                    l.active = i;
                    this.refreshScorePosition(o, l, Number(ToolUtils.parse_double("" + t, -2)), r);
                }
                let o = l.getChildByName("pts_bg");
                if (o) {
                    let e = o.getChildByName("score"), i = o.getChildByName("scoreItem"), a = ToolUtils.parse_double(t + "", -2);
                    Utils.shared().setStr(e, a);
                    this.refreshScorePosition(e, i, t);
                }
            }
        }
        else if (l) {
            if (0 != e) {
                return void (r.gameRummyType == RUMMY_GAME_TYPE.POOL || (r.gameRummyType, RUMMY_GAME_TYPE.DEALS));
            }
            {
                let e = l.getChildByName("name_bg");
                if (this.handCardScore = t, e) {
                    let a = e.getChildByName("score"), s = e.getChildByName("scoreItem");
                    a && (Utils.shared().setStr(a, "" + t), a.active = i);
                    s.active = i;
                    this.refreshScorePosition(a, s, t);
                }
                let a = l.getChildByName("pts_bg");
                if (a) {
                    let e = a.getChildByName("score"), i = a.getChildByName("scoreItem"), s = ToolUtils.parse_double(t + "", -2);
                    Utils.shared().setStr(e, s);
                    this.refreshScorePosition(e, i, t);
                }
            }
        }
    }
    getLoseScore() {
        return this.handCardScore;
    }
    refreshScorePosition(e, t, i, a = 0) {
    }
    hidePlayer(e) {
        let t = "player" + e, i = this.node.getChildByName(t);
        if (i) {
            if (i.getChildByName("qipai_bg").active = false, i.getChildByName("zhuang").active = false, this.setPoolRejoinState(e, false), this.setDecisionStateVisible(e, false), this.setPoolManualState(e, false), this.showDoubleState(e, 0, false), 0 != e) {
                RummyDataManager.shared().rummyInfos.get(this.tid_key).has_rev_tableInfo && (i.active = true, 2 == RummyDataManager.shared().rummyInfos.get(this.tid_key).pnum ? e >= 2 && (i.active = false) : 4 == RummyDataManager.shared().rummyInfos.get(this.tid_key).pnum && e >= 4 && (i.active = false));
                let t = i.getChildByName("head_kuang");
                t && (t.active = true);
                i.getChildByName("head_bg").active = false;
                i.getChildByName("head_mask").active = false;
                i.getChildByName("state").active = false;
                i.getChildByName("name_bg").active = false;
                i.getChildByName("jiesuan_num").active = false;
                i.getChildByName("img_djs_num_bg").active = false;
                i.getChildByName("daojishi").active = false;
                i.getChildByName("pts_bg").active = false;
                i.getChildByName("vip").active = false;
                i.getChildByName("club_kuang").active = false;
                let a = i.getChildByName("userName");
                a && (a.active = false);
                let s = i.getChildByName("lost_flag");
                s && (s.active = false);
                this.changeWinFlagStatus(e, false);
                this.setPoolScoreState(e, false);
                this.hidePipeiAnim(e);
                this.changeEasyGameLightVisible(e, false);
            }
            else {
                i.getChildByName("head_bg").active = false;
                i.getChildByName("head_kuang").active = false;
                i.getChildByName("userName").active = false;
                i.getChildByName("qipai_bg").active = false;
                i.getChildByName("zhuang").active = false;
                i.getChildByName("vip").active = false;
                i.getChildByName("club_kuang").active = false;
                this.hidePipeiAnim(e);
            }
        }
    }
    showEmptySeat() {
        for (let e = 1; e < RummyDataManager.shared().rummyInfos.get(this.tid_key).pnum; e++) {
            let t = "player" + e, i = this.node.getChildByName(t);
            sys.isObjectValid(i) && (i.active = true);
        }
    }
    checkHeadShow(e) {
        let t = "player" + e, i = this.node.getChildByName(t);
        if (i) {
            let e = i.getChildByName("head_mask");
            if (e) {
                return 1 == e.active;
            }
        }
        return false;
    }
    changeWinFlagStatus(e, t) {
        let i = "player" + e, a = this.node.getChildByName(i);
        if (a) {
            let e = a.getChildByName("win_flag");
            e && (e.active = t);
        }
    }
    refreshPlayerPostion() {
        if (2 == RummyDataManager.shared().rummyInfos.get(this.tid_key).pnum) {
            let e = this.node.getChildByName("player1");
            e && e.setPosition(this.orginPlayerPosVec[3]);
            e.active = true;
        }
        else if (4 == RummyDataManager.shared().rummyInfos.get(this.tid_key).pnum) {
            for (let e = 1; e < RummyDataManager.shared().rummyInfos.get(this.tid_key).pnum; e++) {
                let t = "player" + e, i = this.node.getChildByName(t);
                sys.isObjectValid(i) && i.setPosition(RummyCardConstant.fourPlayerPosVec[e]);
            }
        }
        else {
            let e = this.node.getChildByName("player1");
            e && e.setPosition(this.orginPlayerPosVec[1]);
            e.active = true;
        }
        let e = RummyDataManager.shared().rummyInfos.get(this.tid_key);
        sys.isObjectValid(e) && 1 == e.is_multiple && (this.node.getChildByName("finishslot").getChildByName("finish_txt").active = false, this.img_turn.getChildByName("finish_txt").active = true, this.img_turn.getChildByName("turn_txt").active = false);
    }
    checkIsMatchRoom() {
        let e = false, t = RummyDataManager.shared().rummyInfos.get(this.tid_key);
        return sys.isObjectValid(t) && 4 == t.gameRummyType && 3 != t.gameMatchMode && (e = true), e;
    }
    refreshFontColor() {
        let e = this.img_close.getChildByName("text"), t = this.img_open.getChildByName("text"), i = this.node.getChildByName("finishslot").getChildByName("finish_txt"), a = this.img_turn.getChildByName("turn_txt"), s = (RummyDataManager.shared().rummyInfos.get(this.tid_key), this.img_turn.getChildByName("finish_txt")), o = this.checkIsMatchRoom() ? -1 : User.shared().styles[0];
        -1 == o ? (i.getComponent(Label).color = color(131, 148, 211, 255), ToolUtils.isObjValid(s) && (s.getComponent(Label).color = color(131, 148, 211, 255)), t.getComponent(Label).color = color(131, 148, 211, 255), e.getComponent(Label).color = color(131, 148, 211, 255), a.getComponent(Label).color = color(131, 148, 211, 255)) : 1 == o ? (i.getComponent(Label).color = color(57, 199, 118, 255), ToolUtils.isObjValid(s) && (s.getComponent(Label).color = color(57, 199, 118, 255)), t.getComponent(Label).color = color(57, 199, 118, 255), e.getComponent(Label).color = color().fromHEX("#39C776"), a.getComponent(Label).color = color().fromHEX("#39C776")) : 2 == o ? (i.getComponent(Label).color = color().fromHEX("#ea9c8c"), ToolUtils.isObjValid(s) && (s.getComponent(Label).color = color().fromHEX("#ea9c8c")), t.getComponent(Label).color = color().fromHEX("#ea9c8c"), e.getComponent(Label).color = color().fromHEX("#ea9c8c"), a.getComponent(Label).color = color().fromHEX("#ea9c8c")) : 3 == o ? (i.getComponent(Label).color = color(83, 143, 218, 255), ToolUtils.isObjValid(s) && (s.getComponent(Label).color = color(83, 143, 218, 255)), t.getComponent(Label).color = color(83, 143, 218, 255), e.getComponent(Label).color = color().fromHEX("#538fda"), a.getComponent(Label).color = color().fromHEX("#538fda")) : 4 == o ? (i.getComponent(Label).color = color(135, 116, 219, 255), ToolUtils.isObjValid(s) && (s.getComponent(Label).color = color(135, 116, 219, 255)), t.getComponent(Label).color = color(135, 116, 219, 255), e.getComponent(Label).color = color(135, 116, 219, 255), a.getComponent(Label).color = color(135, 116, 219, 255)) : 5 == o && (i.getComponent(Label).color = color(255, 222, 108, 255), ToolUtils.isObjValid(s) && (s.getComponent(Label).color = color(255, 222, 108, 255)), t.getComponent(Label).color = color(255, 222, 108, 255), e.getComponent(Label).color = color(255, 222, 108, 255), a.getComponent(Label).color = color(255, 222, 108, 255));
        for (let e = 0; e < 6; e++) {
            let t = this.node.getChildByName("player" + e);
            if (t) {
                let i = t.getChildByName("rejoinState_node"), a = i.getChildByName("rejoinState"), s = i.getChildByName("wz").getComponent(Label);
                1 == o ? (a.getComponent(Sprite).color = 0 == e ? color(0, 101, 65, 255) : color(0, 0, 0, 50), s.color = color(131, 250, 159, 255)) : 2 == o ? (a.getComponent(Sprite).color = 0 == e ? color(97, 24, 45, 255) : color(0, 0, 0, 50), s.color = color(250, 131, 131, 255)) : 3 == o ? (a.getComponent(Sprite).color = 0 == e ? color(26, 46, 94, 255) : color(0, 0, 0, 50), s.color = color(131, 182, 250, 255)) : 4 == o ? (a.getComponent(Sprite).color = 0 == e ? color(168, 142, 255, 255) : color(0, 0, 0, 50), s.color = color(135, 116, 219, 255)) : 5 == o && (s.color = color(135, 116, 219, 255));
            }
        }
        this.refreshDecisionColor();
        this.refreshEasyGameLightColor();
    }
    reset() {
        this.isSuozhu = false;
        this.bIsHideBonustTime = false;
        this.setUserInfo();
    }
    setUserInfo() {
        this.updateClientInfo();
    }
    initPushCenter() {
        PushCenter.shared().addListener(PushEvent.UpdateRaceCSS, (() => {
            this.refreshFontColor();
        }), this);
    }
    updateCloseNum(e) {
        e >= 0 && (this.img_close.getChildByName("text").getComponent(Label).string = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_main.close"), e), i18nMgr.shared().changeLabelFont(this.img_close.getChildByName("text").getComponent(Label)));
    }
    updateOpenNum(e) {
        e >= 0 && (this.img_open.getChildByName("text").getComponent(Label).string = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_main.open"), e), i18nMgr.shared().changeLabelFont(this.img_open.getChildByName("text").getComponent(Label)));
    }
    updateRoundNum(e) {
        if (e >= 0) {
            let t = this.img_turn.getChildByName("turn_txt"), i = RummyDataManager.shared().rummyInfos.get(this.tid_key);
            sys.isObjectValid(i) && 1 == i.is_multiple ? (t = this.node.getChildByName("finishslot").getChildByName("turn_txt"), t.getComponent(Label).string = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_main.turn2"), e), i18nMgr.shared().changeLabelFont(t.getComponent(Label), true)) : (t.getComponent(Label).string = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_main.turn"), e), i18nMgr.shared().changeLabelFont(t.getComponent(Label)));
        }
    }
    updateMultipleTimes(e) {
        let t = RummyDataManager.shared().rummyInfos.get(this.tid_key);
        if (sys.isObjectValid(t) && 1 == t.is_multiple) {
            if (e >= 0 && sys.isObjectValid(t.multiple_cfg[e])) {
                let i = this.node.getChildByName("finishslot").getChildByName("time_txt");
                i.getComponent(Label).string = "x" + t.multiple_cfg[e];
                i.active = true;
                this.node.getChildByName("finishslot").getChildByName("multiple_tip").active = true;
            }
        }
        else {
            this.node.getChildByName("finishslot").getChildByName("multiple_tip").active = false;
            this.node.getChildByName("finishslot").getChildByName("time_txt").active = false;
        }
    }
    changeOpenNumVisibile(e) {
    }
    changeRoundNumVisible(e) {
        let t = RummyDataManager.shared().rummyInfos.get(this.tid_key);
        sys.isObjectValid(t) && 1 == t.is_multiple && (this.node.getChildByName("finishslot").getChildByName("turn_txt").active = e);
    }
    hidePaiNum() {
        this.img_close.active = false;
        this.img_open.active = false;
        let e = RummyDataManager.shared().rummyInfos.get(this.tid_key);
        sys.isObjectValid(e) && 1 == e.is_multiple ? this.node.getChildByName("finishslot").getChildByName("turn_txt").active = false : this.img_turn.active = false;
    }
    updateClientInfo() {
        var e;
        for (let e = 0; e < 6; e++) {
            this.hidePlayer(e);
        }
        let t = {};
        t.name = User.shared().data.name;
        t.uid = User.shared().data.uid;
        t.headname = User.shared().data.avatar;
        t.vlevel = (null == (e = User.shared().data.vip_info) ? undefined : e.current_show_level) ?? 0;
        t.sex = User.shared().data.sex;
        t.avatar_url = User.shared().data.avatar_url;
        sys.isObjectValid(User.shared().data.club) && (t.club_level = Number(User.shared().data.club.club));
        t.isinit = true;
        t.isLineUp = false;
        t.isHeadCallback = true;
        t.money = User.shared().data.money;
        1 == RummyDataManager.shared().rummyInfos.get(this.tid_key).crashModel && (t.money = User.shared().data.money_exe);
        this.showPlayer(0, t);
    }
    resetAllCard() {
        for (let e = 0; e < 6; e++) {
            this.hideDingZhaungCard(e);
        }
    }
    changePlayerZhuangState(e, t) {
        let i = "player" + t, a = this.node.getChildByName(i);
        if (0 == t && 1 == User.shared().isInPerformanceRoom && RummyDataManager.shared().performancePlayer && (a = RummyDataManager.shared().performancePlayer), a && (a.getChildByName("zhuang").active = e, !e)) {
            try {
                let e = this.node.getChildByName("dingzhuang_player" + t);
                ToolUtils.isObjValid(e) && e.destroy();
            }
            catch (e) {
                TLog.printError("--------- changePlayerZhuangState error:", e.toString());
            }
        }
    }
    updatePlayerMoney(e, t) {
        let i = "player" + e, a = this.node.getChildByName(i);
        if (a) {
            let i = a.getChildByName("name_bg").getChildByName("goldNum");
            if (i) {
                let a = "";
                0 == e ? (1 == RummyDataManager.shared().rummyInfos.get(this.tid_key).crashModel ? User.shared().data.money_exe = t : User.shared().updateMoney(t), PushCenter.shared().pushEvent(PushEvent.UpdatePractiseGold, t)) : (t < 0 && (t = 0), a = 1 == RummyDataManager.shared().rummyInfos.get(this.tid_key).crashModel ? "" + ToolUtils.parse_ChipNum2(t) : "₹" + ToolUtils.parse_double(t + ""), Utils.shared().setStr(i, a));
                this.updatePracticeIconPostion(0);
            }
        }
    }
    updatePlayerVip(e, t) {
    }
    updatePlayerMemberShipInfo(e, t) {
        if (sys.isObjectValid(User.shared().data.club) && 1 == User.shared().data.club.show_room_avatar_frame) {
            let t = "player" + e, i = this.node.getChildByName(t);
            if (i) {
                let e = User.shared().avatar_frame_id;
                i.getChildByName("club_kuang").active = e > 0;
                e > 0 && e <= 9 && Utils.shared().setImage(i.getChildByName("club_kuang"), ToolUtils.format("club_headkuang${0}", e), this.clubKuangAtlas);
            }
        }
    }
    removeObject() {
    }
    sendWinBet(e) {
        let t = "fama" + e, i = instantiate(this.node.getChildByName(t));
        i.parent = this.node;
        i.active = true;
        i.setScale(v3(1.9, 1.9, 1.9));
        i.setPosition(this.node.getChildByName("total_flag").getPosition());
        let a = RummyDataManager.shared().rummyInfos.get(this.tid_key);
        t = 1 == a.crashModel ? "" + Math.floor(a.total_bet) : ToolUtils.parse_double("" + a.total_bet);
        Utils.shared().setStr(i.getChildByName("label"), t);
    }
    showPlayer(e, t) {
        const avatarPlayer = t;
        let i = ToolUtils.isSafeString(t.name), a = ToolUtils.isSafeString(t.headname), s = (ToolUtils.isSafeNumber(t.vip), ToolUtils.isSafeNumber(t.club_level), ToolUtils.isSafeNumber(t.avatar_frame_id)), o = -1;
        null != t.money && null != t.money && (o = t.money);
        let l = ToolUtils.isSafeString(t.avatar_url);
        const avatarRoom = RummyDataManager.shared().rummyInfos.get(this.tid_key);
        const robotMode = avatarRoom && 1 == avatarRoom.crashModel && RobotAvatar.roomMode(avatarRoom.vid) === 1;
        if (e > 0 && RobotAvatar.isRobot(t, robotMode)) {
            a = RobotAvatar.KEY;
            l = "";
        }
        null != t.isinit && null != t.isinit && t.isinit;
        let r = false;
        null != t.isLineUp && null != t.isLineUp && (r = t.isLineUp);
        let h = true;
        null != t.isHeadCallback && null != t.isHeadCallback && (h = t.isHeadCallback);
        let d = 0;
        null != t.head_refresh_type && null != t.head_refresh_type && (d = t.head_refresh_type);
        null != t.is_gray_name && null != t.is_gray_name && t.is_gray_name;
        let n = "player" + e, u = this.node.getChildByName(n);
        0 == e && 1 == User.shared().isInPerformanceRoom && RummyDataManager.shared().performancePlayer && (u = RummyDataManager.shared().performancePlayer);
        let p = RummyDataManager.shared().rummyInfos.get(this.tid_key);
        if (u) {
            u.active = true;
            TweenTool.stopNodeAction(u);
            u.setScale(v3(1, 1, 1));
            u.getChildByName("head_mask").active = true;
            r && 0 != e ? (u.getChildByName("head_bg").active = false, u.getChildByName("head_mask").getChildByName("head_img").active = false) : (u.getChildByName("head_bg").active = true, u.getChildByName("head_mask").getChildByName("head_img").active = true);
            let t = true;
            if (a && a.length > 0 && 1 == d && 1 == p.ding_zhuang_seat_state && (t = false), t && this.updateHeadImg(e, u, a, l, h, r, avatarPlayer), u.getChildByName("vip").active = false, sys.isObjectValid(User.shared().data.club) && 1 == User.shared().data.club.show_room_avatar_frame) {
                let t = s;
                u.getChildByName("club_kuang").active = (!r || 0 == e) && t > 0;
                t > 0 && t <= 9 && Utils.shared().setImage(u.getChildByName("club_kuang"), ToolUtils.format("club_headkuang${0}", t), this.clubKuangAtlas);
            }
            if (0 != e) {
                let t = u.getChildByName("name_bg").getChildByName("lineup_nick");
                r ? u.getChildByName("userName").active = false : "..." == ToolUtils.isSafeString(i) ? (t.active = true, u.getChildByName("userName").active = false) : (u.getChildByName("userName").active = true, t.active = false);
                u.getChildByName("name_bg").active = true;
                i = ToolUtils.GetShortName2(i, 9, true);
                Utils.shared().setStr(u.getChildByName("userName"), i);
                this.showHeadStateByStatus(e);
            }
            else {
                let e = u.getChildByName("name_bg");
                if (1 == p.crashModel) {
                    e.getChildByName("icon").active = true;
                    let t = new Vec3;
                    e.getChildByName("goldNum").getPosition(t);
                    e.getChildByName("goldNum").setPosition(v3(-116, t.y, t.z));
                }
                else {
                    e.getChildByName("icon").active = false;
                }
                u.getChildByName("state").active = false;
            }
            0 == e && sys.isObjectValid(p) && 1 == p.is_multiple ? (u.getChildByName("head_kuang").active = false, u.getChildByName("head_multiple_kuang").active = true) : u.getChildByName("head_kuang").active = true;
            let n = u.getChildByName("name_bg").getChildByName("goldNum");
            if (ToolUtils.isObjValid(n) && o >= 0) {
                if (0 == e) {
                    n.active = true;
                    PushCenter.shared().pushEvent(PushEvent.UpdatePractiseGold, o);
                }
                else if (1 === GameConfig.SERVER_DEBUG && User.shared().roomTable && 1 === User.shared().roomTable.pri_list_open) {
                    n.active = true;
                    let e = new Vec3;
                    n.getPosition(e);
                    n.setPosition(v3(e.x, -40, e.z));
                }
                let t = "";
                t = 1 == p.crashModel ? "" + ToolUtils.parse_ChipNum2(o) : "₹" + ToolUtils.parse_double(o + "");
                Utils.shared().setStr(n, t);
                0 === e && this.updatePracticeIconPostion(0);
            }
            if (p.gameRummyType == RUMMY_GAME_TYPE.POOL || p.gameRummyType == RUMMY_GAME_TYPE.PRI_POOL || p.gameRummyType == RUMMY_GAME_TYPE.DEALS || p.gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL || p.gameRummyType == RUMMY_GAME_TYPE.MATCH ? 0 == e && (u.getChildByName("head_kuang").active = true, u.getChildByName("name_bg").active = false, this.setPoolScoreState(e, true)) : (0 == e && sys.isObjectValid(p) && 1 == p.is_multiple ? (u.getChildByName("head_kuang").active = false, u.getChildByName("head_multiple_kuang").active = true) : u.getChildByName("head_kuang").active = true, u.getChildByName("name_bg").active = true, this.setPoolScoreState(e, false)), 0 != e) {
                let e = u.getChildByName("pts_bg"), t = e.getChildByName("layout"), i = t.getChildByName("value"), a = t.getChildByName("text");
                p.gameRummyType == RUMMY_GAME_TYPE.MATCH ? (e.getComponent(UITransform).setContentSize(size(106, 22)), ToolUtils.isObjValid(e.getChildByName("mask")) && e.getChildByName("mask").getComponent(UITransform).setContentSize(size(106, 22)), i.getComponent(Label).updateRenderData(true), a.getComponent(Label).updateRenderData(true), t.getComponent(Layout).updateLayout()) : (e.getComponent(UITransform).setContentSize(size(86, 22)), ToolUtils.isObjValid(e.getChildByName("mask")) && e.getChildByName("mask").getComponent(UITransform).setContentSize(size(86, 22)), i.getComponent(Label).updateRenderData(true), a.getComponent(Label).updateRenderData(true), t.getComponent(Layout).updateLayout());
            }
        }
    }
    updatePlayerHead(e, t, i) {
        let a = "player" + e, s = this.node.getChildByName(a);
        s && this.updateHeadImg(e, s, t, i);
    }
    showPipeiAnim1(e) {
        let t = "player" + e, i = this.node.getChildByName(t);
        if (i && i.getChildByName("pipei_anim")) {
            let t = i.getChildByName("pipei_anim");
            if (this._bPiPeiAnimShow[e] && t.active) {
                return;
            }
            User.shared().curTid_key == this.tid_key && SoundManager.shared().playFx("players_setdown");
            t.active = true;
            this._bPiPeiAnimShow[e] = true;
            i.getChildByName("name_bg").getChildByName("lineup_nick").active = true;
            i.getChildByName("userName").active = false;
        }
    }
    stopPipeiAnim1(e) {
        let t = "player" + e, i = this.node.getChildByName(t);
        if (i && i.getChildByName("pipei_anim")) {
            let t = i.getChildByName("pipei_anim");
            this._bPiPeiAnimShow[e] && (t.active || (t.active = true), t.active = false);
            this._bPiPeiAnimShow[e] = false;
            let a = i.getChildByName("name_bg").getChildByName("lineup_nick"), s = i.getChildByName("userName").getComponent(Label).string;
            "..." == ToolUtils.isSafeString(s) ? (a.active = true, i.getChildByName("userName").active = false) : (a.active = false, i.getChildByName("userName").active = i.getChildByName("name_bg").active, this.showNameColor(e));
            i.getChildByName("head_mask").active && (i.getChildByName("head_bg").active = true, i.getChildByName("head_mask").getChildByName("head_img").active = true);
        }
    }
    hidePipeiAnim(e) {
        let t = "player" + e, i = this.node.getChildByName(t);
        if (i && i.getChildByName("pipei_anim")) {
            this._bPiPeiAnimShow[e] = false;
            i.getChildByName("pipei_anim").active = false;
            this._bPiPeiAnimShow[e] = false;
            let t = i.getChildByName("name_bg").getChildByName("lineup_nick"), a = i.getChildByName("userName").getComponent(Label).string;
            "..." == ToolUtils.isSafeString(a) ? (t.active = true, i.getChildByName("userName").active = false) : (t.active = false, i.getChildByName("userName").active = i.getChildByName("name_bg").active, this.showNameColor(e));
            i.getChildByName("head_mask").active && (i.getChildByName("head_bg").active = true, i.getChildByName("head_mask").getChildByName("head_img").active = true);
        }
    }
    updateTimer() {
        if (!ToolUtils.isObjValid(this.node) || !RummyDataManager.shared().rummyInfos.has(this.tid_key)) return;
        const now = sys.now();
        const elapsed = this.timerTickAt ? Math.max(0, (now - this.timerTickAt) / 1000) : 0;
        this.timerTickAt = now;
        for (let pos = 0; pos < 6; pos++) {
            this.track_times.set(pos, (this.track_times.get(pos) || 0) + elapsed);
        }
        const room = RummyDataManager.shared().rummyInfos.get(this.tid_key);
        if (this.isUpdateFlag && this.mcdPos >= 0) {
            const pos = this.mcdPos;
            const player = pos === 0 && User.shared().isInPerformanceRoom === 1 && RummyDataManager.shared().performancePlayer
                ? RummyDataManager.shared().performancePlayer : this.node.getChildByName("player" + pos);
            const ring = player.getChildByName("daojishi");
            const label = player.getChildByName("img_djs_num_bg");
            const remaining = this.mcd - elapsed;
            this.mcd = Math.max(0, remaining);
            if (this.bIsTimeout) room.timeout_cd = this.mcd;
            else room.op_cd = this.mcd;
            // Carry elapsed time across the normal/bonus boundary, including a
            // stalled frame. A fresh server snapshot resets the anchor below.
            if (!this.bIsTimeout && remaining <= 0 && label.active &&
                (pos !== 0 || !this.bIsHideBonustTime) && room.timeout_cd > 0) {
                room.timeout_cd = Math.max(0, room.timeout_cd + remaining);
                if (room.timeout_cd > 0) this.startPlayerTimer(pos, room.timeout_cd, true);
            }
            const seconds = Math.ceil(this.mcd);
            ring.getComponent(Sprite).fillRange = this.mcdFlag > 0 ? Math.min(1, this.mcd / this.mcdFlag) : 0;
            Utils.shared().setStr(label.getChildByName("left"), String(seconds));
            if (this.bIsTimeout) Utils.shared().setStr(label.getChildByName("total"), pos === 0 && this.bIsHideBonustTime ? "" : String(seconds));
            if (seconds !== this.nLastCd && seconds > 0 && seconds <= 10 && pos === 0 &&
                User.shared().curTid_key === this.tid_key && room.in_choose_double !== 1) SoundManager.shared().playFx("rummyCountDown");
            this.nLastCd = seconds;
            if (this.mcd <= 0) {
                this.isUpdateFlag = false;
                this.mcdPos = -1;
                label.active = false;
            }
        }
        if (this.isjiesuanUpdateFlag) {
            const dt = this.settlementTickAt ? Math.max(0, (now - this.settlementTickAt) / 1000) : 0;
            this.settlementTickAt = now;
            const previous = Math.ceil(this.jiesuanCountDown);
            this.jiesuanCountDown = Math.max(0, this.jiesuanCountDown - dt);
            const seconds = Math.ceil(this.jiesuanCountDown);
            room.op_cd = this.jiesuanCountDown;
            for (let pos = 0; pos < 6; pos++) {
                const player = pos === 0 && User.shared().isInPerformanceRoom === 1 && RummyDataManager.shared().performancePlayer
                    ? RummyDataManager.shared().performancePlayer : this.node.getChildByName("player" + pos);
                const label = player.getChildByName("jiesuan_num");
                if (!label.active) continue;
                const ring = player.getChildByName("daojishi");
                ring.getComponent(Sprite).fillRange = this.mcdFlag > 0 ? Math.min(1, this.jiesuanCountDown / this.mcdFlag) : 0;
                Utils.shared().setStr(label.getChildByName("Label"), String(seconds));
                if (pos === 0 && seconds !== previous && seconds > 0 && seconds <= 10 &&
                    User.shared().curTid_key === this.tid_key && room.in_choose_double !== 1) SoundManager.shared().playFx("rummyCountDown");
                if (seconds === 0) label.active = false;
            }
            if (seconds === 0) this.isjiesuanUpdateFlag = false;
        }
    }
    startPlayerTimer(e, t, i = false, a) {
        let s = RummyDataManager.shared().rummyInfos.get(this.tid_key);
        i && (t = s.timeout_cd);
        let o = s.op_cd;
        i && (o = null != a ? a / 2 : s.timeout_cd);
        this.stopPlayerTimer();
        this.mcd = t;
        this.timerTickAt = sys.now();
        this.mcdFlag = o;
        this.mcdPos = e;
        this.nLastCd = t;
        this.isUpdateFlag = true;
        this.bIsTimeout = i;
        let l = "player" + e, r = this.node.getChildByName(l);
        if (0 == e && 1 == User.shared().isInPerformanceRoom && RummyDataManager.shared().performancePlayer && (r = RummyDataManager.shared().performancePlayer), ToolUtils.isObjValid(r)) {
            let i = r.getChildByName("daojishi");
            this.bIsTimeout ? i.getComponent(Sprite).spriteFrame = this.player_head_img[0] : i.getComponent(Sprite).spriteFrame = this.player_head_img[1];
            let a = i.getComponent(Sprite);
            i.active = true;
            a.fillRange = this.mcd / this.mcdFlag;
            let o = r.getChildByName("img_djs_num_bg");
            0 == e && this.bIsHideBonustTime ? (this.bIsTimeout ? o.getComponent(Sprite).spriteFrame = this.player_head_img[15] : o.getComponent(Sprite).spriteFrame = this.player_head_img[14], Utils.shared().setStr(o.getChildByName("total"), "")) : (this.bIsTimeout ? o.getComponent(Sprite).spriteFrame = this.player_head_img[2] : o.getComponent(Sprite).spriteFrame = this.player_head_img[3], s.timeout_cd < 0 && (s.timeout_cd = 0), s.timeout_cd < 0 ? Utils.shared().setStr(o.getChildByName("total"), "0") : Utils.shared().setStr(o.getChildByName("total"), "" + Math.floor(s.timeout_cd)));
            Utils.shared().setStr(o.getChildByName("left"), "" + Math.floor(t));
            o.active = true;
        }
    }
    hideBonustTime() {
        let e = this.node.getChildByName("player0");
        if (ToolUtils.isObjValid(e)) {
            this.bIsHideBonustTime = true;
            let t = e.getChildByName("img_djs_num_bg");
            this.bIsTimeout ? t.getComponent(Sprite).spriteFrame = this.player_head_img[15] : t.getComponent(Sprite).spriteFrame = this.player_head_img[14];
            Utils.shared().setStr(t.getChildByName("total"), "");
        }
    }
    resetHideBounsTime() {
        this.bIsHideBonustTime = false;
    }
    stopPlayerTimer() {
        for (let e = 0; e < 6; e++) {
            let t = "player" + e, i = this.node.getChildByName(t);
            if (0 == e && 1 == User.shared().isInPerformanceRoom && RummyDataManager.shared().performancePlayer && (i = RummyDataManager.shared().performancePlayer), ToolUtils.isObjValid(i)) {
                i.getChildByName("daojishi").getComponent(Sprite).fillRange = 0;
                i.getChildByName("img_djs_num_bg").active = false;
                i.getChildByName("jiesuan_num").active = false;
            }
        }
        this.mcdPos = -1;
        this.isUpdateFlag = false;
        this.mcd = 0;
        this.isjiesuanUpdateFlag = false;
        this.jiesuanCountDown = 0;
    }
    stopPlayerTimerByPos(e, t) {
        let i = "player" + e, a = this.node.getChildByName(i);
        if (0 == e && 1 == User.shared().isInPerformanceRoom && RummyDataManager.shared().performancePlayer && (a = RummyDataManager.shared().performancePlayer), ToolUtils.isObjValid(a)) {
            a.getChildByName("daojishi").getComponent(Sprite).fillRange = 0;
            a.getChildByName("img_djs_num_bg").active = false;
            a.getChildByName("jiesuan_num").active = false;
            this.isUpdateFlag = false;
            t || (this.isjiesuanUpdateFlag = false, this.mcd = 0);
        }
    }
    startPlayerTimer2(e, t, i) {
        this.stopPlayerTimerByPos(e, true);
        let a = "player" + e, s = this.node.getChildByName(a);
        if (0 == e && (RummyDataManager.shared().rummyInfos.get(this.tid_key).op_cd = t, 1 == User.shared().isInPerformanceRoom && RummyDataManager.shared().performancePlayer && (s = RummyDataManager.shared().performancePlayer)), ToolUtils.isObjValid(s)) {
            if (!s.getChildByName("head_mask").active) {
                return;
            }
            let e = t;
            null != i && (e = i > 0 ? i : t);
            this.mcd = 0;
            this.mcdFlag = e;
            this.nLastCd = 0;
            this.isUpdateFlag = false;
            this.jiesuanCountDown = t;
            this.settlementTickAt = sys.now();
            this.isjiesuanUpdateFlag = true;
            let a = s.getChildByName("daojishi");
            a.getComponent(Sprite).spriteFrame = this.player_head_img[1];
            a.getComponent(Sprite).fillRange = this.jiesuanCountDown / this.mcdFlag;
            let o = s.getChildByName("jiesuan_num");
            o.active = true;
            Utils.shared().setStr(o.getChildByName("Label"), "" + t);
        }
    }
    stopPlayerTimer2(e) {
        let t = "player" + e, i = this.node.getChildByName(t);
        0 == e && 1 == User.shared().isInPerformanceRoom && RummyDataManager.shared().performancePlayer && (i = RummyDataManager.shared().performancePlayer);
        i.getChildByName("daojishi").getComponent(Sprite).fillRange = 0;
        i.getChildByName("img_djs_num_bg").active = false;
        i.getChildByName("jiesuan_num").active = false;
    }
    updateSeatMoneyInfo(e, t) {
        let i = "player" + e, a = this.node.getChildByName(i);
        if (0 == e && 1 == User.shared().isInPerformanceRoom && RummyDataManager.shared().performancePlayer) {
            if (a = RummyDataManager.shared().performancePlayer, a) {
                let s = a.getChildByName("name_bg").getChildByName("goldNum");
                s && (i = 1 == RummyDataManager.shared().rummyInfos.get(this.tid_key).crashModel ? "" + ToolUtils.parse_ChipNum2(t) : "₹" + ToolUtils.parse_double(t + ""), Utils.shared().setStr(s, i));
                0 == e && this.updatePracticeIconPostion(0);
            }
        }
        else if (a) {
            // Rendering a cached seat must never write the account wallet.
            // Authoritative balance updates go through updatePlayerMoney/User.
            t = Math.max(0, Number(t) || 0);
            let s = a.getChildByName("name_bg").getChildByName("goldNum");
            s && (i = 1 == RummyDataManager.shared().rummyInfos.get(this.tid_key).crashModel ? "" + ToolUtils.parse_ChipNum2(t) : "₹" + ToolUtils.parse_double(t + ""), Utils.shared().setStr(s, i));
            0 == e && this.updatePracticeIconPostion(0);
        }
    }
    getPlayerHeadViewPos(e) {
        let t = "player" + e, i = this.node.getChildByName(t);
        return i ? i.getPosition() : v2(0, 0);
    }
    updateUser() {
        let e = User.shared().data.money;
        1 == RummyDataManager.shared().rummyInfos.get(this.tid_key).crashModel && (e = User.shared().data.money_exe);
        this.curmoney != e && (this.curmoney = e, this.setUserInfo());
    }
    changeAwayStateStatus(e, t, i, a) {
        let s = "player" + e, o = this.node.getChildByName(s);
        if (0 == e && 1 == User.shared().isInPerformanceRoom && RummyDataManager.shared().performancePlayer && (o = RummyDataManager.shared().performancePlayer), o) {
            let s = o.getChildByName("state");
            if (s) {
                let l = true;
                (o.getChildByName("head_mask").active || a) && t ? (i == RUMMY_PLAYER_STATE_TYPE.AWAY ? i18nMgr.shared().changeSpriteLanguage(s, this.translateHeadImg[0], this.player_head_img[4]) : i == RUMMY_PLAYER_STATE_TYPE.DROPPED ? (i18nMgr.shared().changeSpriteLanguage(s, this.translateHeadImg[1], this.player_head_img[5]), l = false) : i == RUMMY_PLAYER_STATE_TYPE.MIDDLEDROP ? (i18nMgr.shared().changeSpriteLanguage(s, this.translateHeadImg[2], this.player_head_img[6]), l = false) : i == RUMMY_PLAYER_STATE_TYPE.WRONGSHOW ? (i18nMgr.shared().changeSpriteLanguage(s, this.translateHeadImg[3], this.player_head_img[7]), l = false) : i == RUMMY_PLAYER_STATE_TYPE.WAITING ? (i18nMgr.shared().changeSpriteLanguage(s, this.translateHeadImg[4], this.player_head_img[9]), l = false, RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType != RUMMY_GAME_TYPE.PRI_POOL && RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType != RUMMY_GAME_TYPE.PRI_DEAL || this.setPoolScoreState(e, false)) : i == RUMMY_PLAYER_STATE_TYPE.LOST ? (i18nMgr.shared().changeSpriteLanguage(s, this.translateHeadImg[5], this.player_head_img[10]), l = false) : i == RUMMY_PLAYER_STATE_TYPE.READY ? i18nMgr.shared().changeSpriteLanguage(s, this.translateHeadImg[6], this.player_head_img[11]) : i == RUMMY_PLAYER_STATE_TYPE.OUT ? (i18nMgr.shared().changeSpriteLanguage(s, this.translateHeadImg[7], this.player_head_img[12]), l = false, RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType !== RUMMY_GAME_TYPE.PRI_DEAL && RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType !== RUMMY_GAME_TYPE.DEALS || this.setPoolScoreState(e, false)) : i == RUMMY_PLAYER_STATE_TYPE.FirstWinner ? (s.getComponent(Sprite).spriteFrame = this.player_head_img[13], this.setPoolScoreState(e, false), l = false) : t = false, s.active = t) : s.active = false;
                o.getChildByName("userName").getComponent(Label).color = l ? this._whiteColor : this._grayColor;
                ToolUtils.isObjValid(o.getChildByName("pts_bg")) && ToolUtils.isObjValid(o.getChildByName("pts_bg").getChildByName("mask")) && 0 != e && (o.getChildByName("pts_bg").getChildByName("mask").active = !l);
            }
        }
    }
    replacePlayerPos(e, t) {
        if (0 == e && 0 == t) {
            return;
        }
        let i = "player" + e, a = this.node.getChildByName(i);
        if (a) {
            let i = a.getChildByName("dingzhuangCard");
            ToolUtils.isObjValid(i) && (i.active = true);
            try {
                let s = this.node.getChildByName("dingzhuang_player" + e);
                ToolUtils.isObjValid(s) && s.destroy();
                s = instantiate(a);
                s.name = "dingzhuang_player" + e;
                this.node.addChild(s);
                s.setPosition(this.playerPos[e]);
                this.hidePlayer(e);
                ToolUtils.isObjValid(i) && i.destroy();
                TweenTool.stopNodeAction(this.delay_node[e]);
                TweenTool.moveTo(s, 0.33, this.playerPos[t], "sineInOut", true, (() => {
                    TweenTool.delayAct(this.delay_node[e], (() => {
                        ToolUtils.isObjValid(s) && s.destroy();
                    }), 0.5, true);
                }));
            }
            catch (e) {
                TLog.printError("-------- replacePlayerPos error:", e.toString());
            }
        }
    }
    playerScaleDownAnim(e) {
        let t = "player" + e, i = this.node.getChildByName(t);
        if (0 == e && 1 == User.shared().isInPerformanceRoom && RummyDataManager.shared().performancePlayer && (i = RummyDataManager.shared().performancePlayer), i) {
            TweenTool.stopNodeAction(i);
            let t = TweenTool.scaleTo(i, 0.1, v3(1.05, 1.05, 1), "backOut", true, (() => {
            })), a = TweenTool.scaleTo(i, 0.06, v3(0.5, 0.5, 1), "backOut", true, (() => {
            })), s = TweenTool.scaleTo(i, 0.14, v3(1, 1, 1), "backOut", true, (() => {
            })), o = TweenTool.delayAct(this.node, (() => {
                this.hidePlayer(e);
            }), 0);
            TweenTool.sequence(i, true, null, t, a, o, s);
        }
    }
    playerScaleUpAnim(e, t) {
        let i = "player" + e, a = this.node.getChildByName(i);
        if (0 == e && 1 == User.shared().isInPerformanceRoom && RummyDataManager.shared().performancePlayer && (a = RummyDataManager.shared().performancePlayer), a) {
            TweenTool.stopNodeAction(a);
            let i = TweenTool.scaleTo(a, 0.1, v3(1, 1, 1), "backOut", true, (() => {
            })), s = TweenTool.delayAct(this.node, (() => {
                let i = {};
                i.name = t.name;
                i.uid = t.uid;
                i.headname = t.avatar;
                i.vlevel = 0;
                i.money = t.money;
                i.sex = t.sex;
                i.avatar_url = t.avatar_url;
                i.vip = t.vip;
                i.club_level = t.club_level;
                i.isinit = false;
                i.isLineUp = false;
                i.isHeadCallback = true;
                RummyDataManager.shared().rummyInfos.get(this.tid_key).ding_zhuang_seat_state = 2;
                i.avatar_frame_id = t.avatar_frame_id;
                i.play_effect_id = t.play_effect_id;
                e > 0 && (this._bPiPeiAnimShow[e] = true, this.stopPipeiAnim1(e));
                this.showPlayer(e, i);
                let a = t.status;
                0 == a ? this.changeAwayStateStatus(e, false) : this.changeAwayStateStatus(e, true, a);
            }), 0);
            TweenTool.sequence(a, true, null, i, s);
        }
    }
    playEnterAnim(e, t) {
    }
    hideEnterAnim(e) {
        let t = "player" + e, i = this.node.getChildByName(t);
        i && (i.getChildByName("enter_anim_bg").active = false, i.getChildByName("enter_anim").active = false);
    }
    showDingZhaungCard(e, t, i) {
        let a = "player" + e, s = this.node.getChildByName(a);
        if (s) {
            let a = instantiate(this.cardPrefab), o = a.getComponent("RummyCard");
            o.init(t, true);
            o.openCard();
            a.setScale(RummyCardConstant.DrawCardScale);
            0 == e ? a.setPosition(v3(0, 5, 0)) : a.setPosition(v3(0, 14, 0));
            a.active = false;
            s.addChild(a);
            a.name = "dingzhuangCard";
            i ? o.setMask(false) : o.setMask(true);
        }
    }
    deletePlayerCard() {
        for (let e = 0; e < 6; e++) {
            let t = "player" + e, i = this.node.getChildByName(t);
            if (i) {
                let e = i.getChildByName("dingzhuangCard");
                ToolUtils.isObjValid(e) && e.destroy();
            }
        }
    }
    setPoolScoreState(e, t) {
        let i = "player" + e, a = this.node.getChildByName(i);
        if (0 == e && 1 == User.shared().isInPerformanceRoom && RummyDataManager.shared().performancePlayer && (a = RummyDataManager.shared().performancePlayer), a) {
            if (RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType == RUMMY_GAME_TYPE.DEALS || RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL) {
                let i = RummyDataManager.shared().getSeatidByPos(e, this.tid_key), a = RummyDataManager.shared().rummyInfos.get(this.tid_key).playerModels[i];
                a && (a.status !== RUMMY_PLAYER_STATE_TYPE.OUT && a.status !== RUMMY_PLAYER_STATE_TYPE.FirstWinner || (t = false));
            }
            if (t) {
                if (!a.getChildByName("pts_bg").active) {
                    let t = true;
                    RummyDataManager.shared().rummyInfos.get(this.tid_key).gameMatchMode == RUMMY_MATCH_MODE.PointsMatch && 0 != e && (t = false);
                    a.getChildByName("pts_bg").active = t;
                }
            }
            else {
                a.getChildByName("pts_bg").active && (a.getChildByName("pts_bg").active = false);
            }
        }
    }
    setPoolScore(e, t) {
        RummyDataManager.shared().rummyInfos.get(this.tid_key).pts_score = t;
        let i = "player" + e, a = this.node.getChildByName(i);
        if (0 == e && 1 == User.shared().isInPerformanceRoom && RummyDataManager.shared().performancePlayer) {
            a = RummyDataManager.shared().performancePlayer;
            let e = a.getChildByName("pts_bg").getChildByName("ptsNode").getChildByName("Layout").getChildByName("value"), i = ToolUtils.parse_double(t + "", -2);
            Utils.shared().setStr(e, i);
        }
        else if (a) {
            let i = ToolUtils.parse_double(t + "", -2);
            if (0 == e) {
                a.getChildByName("pts_bg").getChildByName("pts_layout").getChildByName("value").getComponent(Label).string = i + "";
                a.getChildByName("pts_bg").getChildByName("pts_layout").getComponent(Layout).updateLayout();
            }
            else {
                let e = a.getChildByName("pts_bg").getChildByName("layout"), t = e.getChildByName("value"), s = e.getChildByName("text");
                t.getComponent(Label).string = i + "";
                t.getComponent(Label).updateRenderData(true);
                s.getComponent(Label).updateRenderData(true);
                e.getComponent(Layout).updateLayout();
            }
        }
    }
    setPoolRejoinState(e, t) {
        let i = "player" + e, a = this.node.getChildByName(i);
        if (0 == e && 1 == User.shared().isInPerformanceRoom && RummyDataManager.shared().performancePlayer && (a = RummyDataManager.shared().performancePlayer), sys.isObjectValid(a)) {
            let i = a.getChildByName("rejoinState_node"), s = i.getChildByName("rejoinState");
            i.active = t;
            let o = i.getChildByName("wz").getComponent(Label), l = User.shared().styles[0];
            1 == l ? (s.getComponent(Sprite).color = 0 == e ? color(0, 101, 65, 255) : color(0, 0, 0, 50), o.color = color(131, 250, 159, 255)) : 2 == l ? (s.getComponent(Sprite).color = 0 == e ? color(97, 24, 45, 255) : color(0, 0, 0, 50), o.color = color(250, 131, 131, 255)) : 3 == l ? (s.getComponent(Sprite).color = 0 == e ? color(26, 46, 94, 255) : color(0, 0, 0, 50), o.color = color(131, 182, 250, 255)) : 4 == l ? o.color = color(135, 116, 219, 255) : 5 == l && (o.color = color(254, 255, 142, 255));
            t && this.setDecisionStateVisible(e, false);
        }
    }
    setPoolManualState(e, t, i = false) {
        let a = this.node.getChildByName("player" + e);
        if (sys.isObjectValid(a)) {
            let e = a.getChildByName("manula_status");
            e.active = t;
            t && (e.getChildByName("wz").getComponent(Label).string = i ? "ACCEPTED" : "REJECT");
        }
    }
    refreshPtsValuePosition(e, t, i) {
    }
    hideDingZhaungCard(e) {
        try {
            let t = "player" + e, i = this.node.getChildByName(t);
            if (0 == e && 1 == User.shared().isInPerformanceRoom && RummyDataManager.shared().performancePlayer && (i = RummyDataManager.shared().performancePlayer), i) {
                let e = i.getChildByName("dingzhuangCard");
                ToolUtils.isObjValid(e) && e.destroy();
            }
        }
        catch (e) {
            TLog.printError("--------- hideDingZhaungCard error:", e.toString());
        }
    }
    updateHeadImgName(e, t, i, a) {
        let s = "player" + e;
        t = ToolUtils.GetShortName2(t, 9, true);
        let o = this.node.getChildByName(s);
        Utils.shared().setStr(o.getChildByName("userName"), t);
        this.updateHeadImg(e, o, i, a);
    }
    updatePracticeIconPostion(e) {
        let t = "player" + e, i = this.node.getChildByName(t);
        0 == e && 1 == User.shared().isInPerformanceRoom && RummyDataManager.shared().performancePlayer && (i = RummyDataManager.shared().performancePlayer);
        let a = i.getChildByName("name_bg"), s = a.getChildByName("icon"), o = new Vec3;
        if (a.getChildByName("goldNum").getPosition(o), s && 1 == RummyDataManager.shared().rummyInfos.get(this.tid_key).crashModel) {
            let e = a.getChildByName("goldNum").getComponent(UITransform);
            this.scheduleOnce((() => {
                let t = o.x - e.width / 2 - 8 - 10, i = new Vec3;
                s.getPosition(i);
                s.setPosition(v3(t, i.y, i.z));
            }));
        }
    }
    fadeOutPaidui(e) {
        TweenTool.moveToByFade(this.node.getChildByName("finishslot"), e, this.node.getChildByName("finishslot").getPosition(), 0, 1, true, (() => {
            this.node.getChildByName("finishslot").active = true;
            this.updateRoundNum(RummyDataManager.shared().rummyInfos.get(this.tid_key).round_per_game);
        }));
        TweenTool.moveToByFade(this.node.getChildByName("paidui_di"), e, this.node.getChildByName("paidui_di").getPosition(), 0, 1, true, (() => {
            this.node.getChildByName("paidui_di").active = true;
            this.updateCloseNum(RummyDataManager.shared().rummyInfos.get(this.tid_key).close_cardnum);
        }));
        TweenTool.moveToByFade(this.node.getChildByName("qipai_di"), e, this.node.getChildByName("qipai_di").getPosition(), 0, 1, true, (() => {
            this.node.getChildByName("qipai_di").active = true;
        }));
        let t = RummyDataManager.shared().rummyInfos.get(this.tid_key);
        sys.isObjectValid(t) && 1 == t.is_multiple && TweenTool.moveToByFade(this.img_turn, e, this.img_turn.getPosition(), 0, 1, true, (() => {
            this.updateRoundNum(RummyDataManager.shared().rummyInfos.get(this.tid_key).round_per_game);
        }));
    }
    changePaiduNumVisible(e) {
    }
    updateHeadImg(e, t, i, a, s = false, o = false, currentPlayer = null) {
        if (t) {
            // Download callbacks and recovery notifications bypass showPlayer.
            // Resolve identity from the current seat so a reused human seat does
            // not inherit the previous occupant's robot overlay.
            const manager = RummyDataManager.shared();
            const room = manager.rummyInfos.get(this.tid_key);
            const seat = room && manager.getSeatidByPos(e, this.tid_key);
            const player = currentPlayer || (room && room.playerModels[seat]);
            const robotMode = room && room.crashModel == 1 && RobotAvatar.roomMode(room.vid) === 1;
            const robot = e > 0 && (i === RobotAvatar.KEY || RobotAvatar.isRobot(player, robotMode));
            const head = t.getChildByName("head_mask").getChildByName("head_img");
            if (RobotAvatar.apply(head, robot, size(134, 134))) return;
            Utils.shared().updateHeadImg(head, i, a, size(134, 134), "head_17.png", s);
        }
    }
    hasShowPaiduiDi() {
        return this.node.getChildByName("paidui_di").active;
    }
    hasShowQipaiDi() {
        return this.node.getChildByName("qipai_di").active;
    }
    setDecisionStateVisible(e, t) {
        let i = "player" + e, a = this.node.getChildByName(i);
        if (sys.isObjectValid(a)) {
            let i = a.getChildByName("decision"), s = i.getChildByName("state");
            i.active = t;
            let o = i.getChildByName("wz").getComponent(Label), l = User.shared().styles[0];
            1 == l ? (s.getComponent(Sprite).color = 0 == e ? color(0, 101, 65, 255) : color(0, 0, 0, 50), o.color = color(131, 250, 159, 255)) : 2 == l ? (s.getComponent(Sprite).color = 0 == e ? color(97, 24, 45, 255) : color(0, 0, 0, 50), o.color = color(250, 131, 131, 255)) : 3 == l ? (s.getComponent(Sprite).color = 0 == e ? color(26, 46, 94, 255) : color(0, 0, 0, 50), o.color = color(131, 182, 250, 255)) : 4 == l ? o.color = color(135, 116, 219, 255) : 5 == l && (o.color = color(254, 255, 142, 255));
            this.decision_actions[e] && (TweenTool.stopAction(this.decision_actions[e]), this.decision_actions[e] = null);
            let r = i18nMgr.shared().getValueByKey("rummy_main.decision");
            t && (this.setPoolRejoinState(e, false), this.decision_times.set(e, 0), i18nMgr.shared().changeLabelFont(o), o.string = r + "", this.decision_actions[e] = TweenTool.myschedule(RummyDataManager.shared().sceneNode, 0.5, (() => {
                if (this.decision_times.has(e)) {
                    let t = this.decision_times.get(e);
                    0 === t ? (o.string = r + ".", this.decision_times.set(e, 1)) : 1 === t ? (o.string = r + "..", this.decision_times.set(e, 2)) : 2 === t ? (o.string = r + "...", this.decision_times.set(e, 3)) : (o.string = r + "", this.decision_times.set(e, 0));
                }
            })));
        }
    }
    refreshDecisionColor() {
        for (let e = 0; e < 6; e++) {
            let t = "player" + e, i = this.node.getChildByName(t);
            if (sys.isObjectValid(i)) {
                let t = i.getChildByName("decision"), a = t.getChildByName("state"), s = t.getChildByName("wz").getComponent(Label), o = User.shared().styles[0];
                1 == o ? (a.getComponent(Sprite).color = 0 == e ? color(0, 101, 65, 255) : color(0, 0, 0, 50), s.color = color(131, 250, 159, 255)) : 2 == o ? (a.getComponent(Sprite).color = 0 == e ? color(97, 24, 45, 255) : color(0, 0, 0, 50), s.color = color(250, 131, 131, 255)) : 3 == o ? (a.getComponent(Sprite).color = 0 == e ? color(26, 46, 94, 255) : color(0, 0, 0, 50), s.color = color(131, 182, 250, 255)) : 4 == o ? s.color = color(135, 116, 219, 255) : 5 == o && (s.color = color(254, 255, 142, 255));
            }
        }
    }
    resetPlayerView() {
        for (let e = 0; e < 6; e++) {
            this.setDecisionStateVisible(e, false);
            this.setPoolManualState(e, false);
            this.showDoubleState(e, 0, false);
        }
    }
    restorePlayerImage(e) {
        if (e && e.players && Array.isArray(e.players) && e.players.length > 0) {
            for (let t = 0, i = e.players.length; t < i; t++) {
                const i = e.players[t];
                i.uid == User.shared().data.uid && (RummyDataManager.shared().rummyInfos.get(this.tid_key).clientSeatId = i.seatid);
            }
            for (let t = 0, i = e.players.length; t < i; t++) {
                const i = e.players[t];
                let a = RummyDataManager.shared().getPosBySeatid(i.seatid, this.tid_key), s = this.node.getChildByName("player" + a);
                if (s && a > 0) {
                    this.stopPipeiAnim1(a);
                    TweenTool.stopNodeAction(s);
                    Utils.shared().clearImagUrlPushEvent(i.avatar_url);
                    let o = {};
                    o.name = i.name;
                    o.uid = i.uid;
                    o.headname = i.avatar;
                    o.vlevel = 0;
                    o.money = i.money;
                    o.sex = i.sex;
                    o.avatar_url = i.avatar_url;
                    o.vip = i.vip;
                    o.club_level = i.club_level;
                    o.isinit = false;
                    o.isLineUp = false;
                    o.isHeadCallback = true;
                    o.avatar_frame_id = i.avatar_frame_id || 0;
                    RummyDataManager.shared().rummyInfos.get(this.tid_key).ding_zhuang_seat_state = 2;
                    s.active = true;
                    s.setScale(v3(1, 1, 1));
                    s.getChildByName("head_mask").active = true;
                    s.getChildByName("head_bg").active = true;
                    s.getChildByName("head_mask").getChildByName("head_img").active = true;
                    let l = i.seatid, r = RummyDataManager.shared().rummyInfos.get(this.tid_key).playerModels[l];
                    r.isShow = true;
                    r.ready = 0;
                    r.uid = i.uid;
                    r.seatid = i.seatid;
                    r.role = i.role;
                    null != i.ready ? r.ready = i.ready : null != i.zhunbei && (r.ready = i.zhunbei);
                    r.betting = e.players[t].betting;
                    r.fold_leave = e.players[t].fold_leave;
                    r.see = e.players[t].see;
                    r.bet = e.players[t].bet;
                    r.status = e.players[t].status;
                    r.name = e.players[t].name;
                    r.sex = e.players[t].sex;
                    r.avatar = e.players[t].avatar;
                    r.avatar_url = e.players[t].avatar_url;
                    r.money = e.players[t].money;
                    r.score = e.players[t].score;
                    r.total_board = e.players[t].total_board;
                    r.total_win = e.players[t].total_win;
                    r.vlevel = e.players[t].vlevel;
                    r.dsc = e.players[t].ps;
                    r.vip = e.players[t].vip;
                    r.club_level = e.players[t].club_level;
                    null != e.players[t].rank && (r.rank = e.players[t].rank);
                    sys.isObjectValid(e.players[t].avatar_frame_id) ? r.avatar_frame_id = e.players[t].avatar_frame_id : r.avatar_frame_id = 0;
                    sys.isObjectValid(e.players[t].play_effect_id) ? r.play_effect_id = e.players[t].play_effect_id : r.play_effect_id = 0;
                    RummyDataManager.shared().rummyInfos.get(this.tid_key).playerModels[l] = r;
                    this.showPlayer(a, o);
                }
            }
        }
    }
    hidePerformanceMyPlayer() {
        let e = this.node.getChildByName("player0");
        e && (e.active = false);
    }
    showNameColor(e) {
        let t = "player" + e, i = this.node.getChildByName(t);
        if (i) {
            let t = RummyDataManager.shared().getSeatidByPos(e, this.tid_key), a = RummyDataManager.shared().rummyInfos.get(this.tid_key).playerModels[t], s = true;
            sys.isObjectValid(a) && sys.isObjectValid(a.status) && (a.status == RUMMY_PLAYER_STATE_TYPE.DROPPED || a.status == RUMMY_PLAYER_STATE_TYPE.MIDDLEDROP || a.status == RUMMY_PLAYER_STATE_TYPE.WAITING || a.status == RUMMY_PLAYER_STATE_TYPE.WRONGSHOW || a.status == RUMMY_PLAYER_STATE_TYPE.LOST || a.status == RUMMY_PLAYER_STATE_TYPE.OUT || a.status == RUMMY_PLAYER_STATE_TYPE.FirstWinner) && (s = false);
            i.getChildByName("userName").getComponent(Label).color = s ? this._whiteColor : this._grayColor;
        }
    }
    showHeadStateByStatus(e) {
        let t = "player" + e;
        if (this.node.getChildByName(t)) {
            let t = RummyDataManager.shared().getSeatidByPos(e, this.tid_key), i = RummyDataManager.shared().rummyInfos.get(this.tid_key).playerModels[t];
            this.changeAwayStateStatus(e, true, i.status);
        }
    }
    showEasyGameLight(e) {
        if (1 == RummyDataManager.shared().rummyInfos.get(this.tid_key).gameRummyMode) {
            2 == RummyDataManager.shared().rummyInfos.get(this.tid_key).pnum && 1 == e && (e = 2);
            for (let t, i, a = 0; a < 4; a++) {
                i = "light" + a;
                t = this.node.getChildByName(i);
                t && (t.active = a == e);
            }
        }
    }
    changeEasyGameLightVisible(e, t) {
        let i = "light" + e, a = this.node.getChildByName(i);
        a && (a.active = t);
    }
    hideAllEasyGameLight() {
        for (let e, t, i = 0; i < 4; i++) {
            t = "light" + i;
            e = this.node.getChildByName(t);
            e && (e.active = false);
        }
    }
    refreshEasyGameLightColor() {
        for (let e, t, i = 0; i < 4; i++) {
            if (t = "light" + i, e = this.node.getChildByName(t), sys.isObjectValid(e)) {
                let t = User.shared().styles[0];
                1 == t ? e.getComponent(Sprite).color = color(63, 201, 108, 255) : 2 == t ? e.getComponent(Sprite).color = color(214, 68, 89, 255) : 3 == t ? e.getComponent(Sprite).color = color(86, 127, 230, 255) : 4 == t ? e.getComponent(Sprite).color = color(146, 117, 255, 255) : 5 == t && (e.getComponent(Sprite).color = color(255, 222, 108, 255));
            }
        }
    }
    setMultipleFireAnimShow(e, t) {
        if (0 == t) {
            let t = this.node.getChildByName("finishslot").getChildByName("time_txt");
            t.active && (TweenTool.stopNodeAction(t), e ? (t.setScale(v3(0.8, 0.8, 0.8)), tween(t).to(0.23, { scale: v3(1.4, 1.4, 1.4) }).to(0.33, { scale: v3(1.5, 1.5, 1.5) }).to(0.18, { scale: v3(0.9, 0.9, 0.9) }).to(0.16, { scale: v3(1, 1, 1) }).start()) : t.setScale(v3(1, 1, 1)));
        }
        else if (1 == t) {
            let t = this.node.getChildByName("finishslot").getChildByName("multiple_fire");
            if (sys.isObjectValid(t) && (t.active = e, e)) {
                let e = t.getComponent(sp.Skeleton);
                e.clearTracks();
                e.setAnimation(0, "Highmultiple", true);
            }
        }
    }
    refreshMultipleAnim() {
        let e = this.node.getChildByName("finishslot").getChildByName("multiple_fire");
        if (sys.isObjectValid(e) && e.active) {
            let t = e.getComponent(sp.Skeleton);
            t.clearTracks();
            t.setToSetupPose();
            t.setAnimation(0, "Highmultiple", true);
        }
        let t = this.node.getChildByName("finishslot").getChildByName("multiple_change");
        sys.isObjectValid(t) && (t.active = false);
    }
    showPlayerHeadAnim(e, t = 1, i = 0, a) {
        let s = "player" + e, o = this.node.getChildByName(s);
        if (o) {
            let e = o.getChildByName("head_anim_di"), s = o.getChildByName("head_anim");
            if (0 == i) {
                6 == t && (a = false);
                e && (e.active = a);
                s && (s.active = false);
            }
            else if (1 == i) {
                if (e && (e.active = false), s) {
                    if (1 == t || 5 == t || 6 == t) {
                        if (s.active = a, a) {
                            let e = s.getComponent(sp.Skeleton);
                            e.clearTracks();
                            e.setToSetupPose();
                            let i = "", a = false;
                            1 == t ? i = "1_welcome_1" : 5 == t ? i = "5_win_1" : 6 == t && (i = "6_Standby", a = true);
                            e.setAnimation(0, i, a);
                            e.setCompleteListener((() => {
                                ToolUtils.isObjValid(this.node) && 6 != t && (s.active = false);
                            }));
                        }
                    }
                    else {
                        s.active = false;
                    }
                }
            }
            else {
                e && (e.active = false);
                s && (s.active = false);
            }
        }
    }
    showDoubleState(e, t, i, a = 0, s = false) {
        let o = "player" + e, l = this.node.getChildByName(o);
        if (t < 0 && (i = false), t <= 0 && 1 == a && !s && (i = false), l) {
            let e = l.getChildByName("double_state");
            if (e && (e.active = i, i)) {
                TweenTool.stopNodeAction(e);
                let i = 0 == t ? 0 : 1;
                e.getComponent(Sprite).spriteFrame = this.double_bgImgs[i];
                let l = 0 == a ? 110 : 40;
                o = 0 == t ? "NO DOUBLE" : "DOUBLE +" + t;
                0 == t && 0 == a && (l = 110);
                1 == a && (s ? (l = 110, o = 0 == t ? "NO DOUBLE" : "DOUBLE +" + t) : (l = 40, o = 0 == t ? "" : "+" + t));
                let r = 0 == t ? 0 : 1;
                e.getChildByName("Label").setPosition(v3(-11, r));
                e.getChildByName("Label").getComponent(Label).fontSize = 0 == t ? 17 : 18;
                e.getComponent(UITransform).setContentSize(size(l, 24));
                e.getChildByName("Label").getComponent(Label).string = o;
                s && TweenTool.delayAct(e, (() => {
                    ToolUtils.isObjValid(this.node) && (0 == t ? e.active = false : (e.getChildByName("Label").getComponent(Label).string = "+" + t, User.shared().curTid_key == this.tid_key ? TweenTool.changeUItranform(e, e.getPosition(), size(110, 24), size(40, 24), 0.2, true) : e.getComponent(UITransform).setContentSize(size(40, 24))));
                }), 2, true);
            }
        }
    }
}
