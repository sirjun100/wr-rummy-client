// @ts-nocheck
// Recovered from index.js:293
import { _decorator, Button, color, instantiate, Label, Node, ScrollView, size, Sprite, SpriteFrame, sys, UITransform, Vec3, view, Widget } from "cc";
import { TLog } from "./TLog";
import SoundManager from "./SoundManager";
import HttpManager from "./HttpManager";
import { HttpRequest } from "./HttpRequestName";
import Utils from "./Utils";
import i18nMgr from "./i18nMgr";
import PushCenter from "./PushCenter";
import PushEvent from "./PushEvent";
import User from "./User";
import BaseLayer from "./BaseLayer";
import ReportConfig from "./ReportConfig";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("ManageAccounts")
export class ManageAccounts extends BaseLayer {
    @property(Node)
    public nodata: Node = null;
    @property(Node)
    public add_btn: Node = null;
    @property(ScrollView)
    public scrollview: ScrollView = null;
    @property(Node)
    public item1: Node = null;
    @property(Node)
    public item2: Node = null;
    @property([SpriteFrame])
    public diImags: SpriteFrame[] = [];
    @property([SpriteFrame])
    public selectImags: SpriteFrame[] = [];
    @property([SpriteFrame])
    public bankImags: SpriteFrame[] = [];
    @property([SpriteFrame])
    public upiImags: SpriteFrame[] = [];
    public _callabck: any = null;
    public _curpage: number = 1;
    public _listData: any = null;
    public _items: any[] = [];
    public _curIndex: number = 0;
    public _can_add: number = 1;
    public _valid_color: any = color(51, 51, 51, 255);
    public _invalid_color: any = color(153, 153, 153, 255);
    public _hasToast: boolean = false;
    public _scrollViewCollisonBox: any = null;
    public _hei_space: number = 0;
    public _isScrolling: boolean = false;
    public _distance: number = 0;
    public _itemSize: any = undefined;
    onLoad() {
        this._itemSize = this.item1.getChildByName("di").getComponent(UITransform).contentSize;
    }
    start() {
        super.start();
        this.nodata.active = false;
        this.item1.active = false;
        this.item2.active = false;
        this._distance = ToolUtils.adaptSafeArea(this.node.getChildByName("root"));
        this.add_btn.getComponent(Widget).bottom = 30 - sys.getSafeAreaRect().y;
        this.scrollview.getComponent(Widget).bottom = 122 - sys.getSafeAreaRect().y;
        this._hei_space = view.getVisibleSize().height - 1280;
        this.scrollview.node.on(ScrollView.EventType.SCROLL_BEGAN, this.srollviewCallback, this);
        this.scrollview.node.on(ScrollView.EventType.SCROLLING, this.srollviewCallback, this);
        this.scrollview.node.on(ScrollView.EventType.SCROLL_ENDED, this.scrollviewEnd, this);
        User.shared().withdrawAccountData && User.shared().withdrawAccountData.list && User.shared().withdrawAccountData.list.length > 0 ? (this._can_add = User.shared().withdrawAccountData.can_add, this._listData = User.shared().withdrawAccountData.list, this.showNodata(), this.refreshList()) : Utils.shared().showLoading(10, false, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3);
        }));
        this.requestWithdrawAccPage(true);
        this.refreshAddWzPosition();
        PushCenter.shared().addListener(PushEvent.UpdateBankCardVerify, (t => {
            try {
                sys.isObjectValid(this.node) && this.requestWithdrawAccPage();
            }
            catch (t) {
                TLog.printError("ManageAccounts", "UpdateBankCardVerify:", t);
            }
        }), this);
        HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Withdraw, event: ReportConfig.hall_evt.withdraw_manager_show });
        3 == i18nMgr.shared().language ? this.node.getChildByName("root").getChildByName("top_root").getChildByName("title").getComponent(Label).fontSize = 32 : this.node.getChildByName("root").getChildByName("top_root").getChildByName("title").getComponent(Label).fontSize = 36;
    }
    refreshAddWzPosition() {
        let t = this.add_btn.getChildByName("wz");
        t.getComponent(Label).updateRenderData(true);
        let e = (t.getComponent(UITransform).width - 373.28) / 2;
        t.setPosition(new Vec3(-169.027 - e, -1.444));
        this.add_btn.getChildByName("ic").setPosition(new Vec3(-181 - e, -2));
    }
    initData(t = null) {
        this._callabck = t;
    }
    requestWithdrawAccPage(t = false) {
        HttpManager.shared().doGetCommonRequest({ page: this._curpage }, HttpRequest.WithdrawAccPage2, ((e, i, a) => {
            if (Utils.shared().hideLoading(), 200 != a) {
                ToolUtils.isObjValid(this.node) && this.showNodata();
            }
            else {
                try {
                    let e = ToolUtils.parseJson(i);
                    ToolUtils.isObjValid(this.node) && (User.shared().withdrawAccountData = e.data, 0 === e.ret ? (this._can_add = e.data.can_add, this._listData = e.data.list) : ToolUtils.isSafeString(e.desc).length > 0 && t && Utils.shared().showToast(e.desc, 2), this.showNodata(), this.refreshList());
                }
                catch (t) {
                    TLog.printError("trycatch requestWithdrawAccPage,error:", t);
                }
            }
        }));
    }
    refreshList() {
        if (this.scrollview.content.destroyAllChildren(), Array.isArray(this._listData) && this._listData.length > 0) {
            let t = -1;
            for (let e = 0; e < this._listData.length; e++) {
                const i = this._listData[e];
                if (-1 === t && 0 === i.can_use) {
                    t = e;
                    break;
                }
            }
            this._items = [];
            let e = 152, i = 4, a = 8, s = 10, n = 28, o = 44, r = this._listData.length, l = r * e + (r - 1) * i;
            -1 !== t && (l = l + o + s + (this._listData.length - t - 1) * i);
            this.scrollview.content.getComponent(UITransform).height = l;
            let c = 0;
            for (let s = 0; s < this._listData.length; s++) {
                const r = this._listData[s];
                let l = instantiate(this.item1);
                if (t === s) {
                    let i = instantiate(this.item2);
                    i.active = true;
                    let s = a;
                    0 === t && (s = 0);
                    i.setPosition(new Vec3(0, c - s, 0));
                    c = c - s - o;
                    l.setPosition(new Vec3(0, c - a, 0));
                    c = c - a - e - 2;
                    this.scrollview.content.addChild(i);
                    this.scrollview.content.addChild(l);
                }
                else {
                    let t = i;
                    0 === s ? t = 0 : 0 === r.can_use && (t = a);
                    l.setPosition(new Vec3(0, c - t, 0));
                    c = c - t - e;
                    this.scrollview.content.addChild(l);
                }
                l.active = true;
                sys.isObjectValid(r.not_same_msg) && r.not_same_msg.length > 0 && (c -= n);
                this._items.push(l);
                this.refreshScroviewItem(l, r, s);
            }
        }
        this.onScolling(true);
    }
    refreshScroviewItem(t, e, i) {
        t.active = true;
        let a = t.getChildByName("di");
        a.getComponent(Button).clickEvents[0].customEventData = i + "";
        let s = t.getChildByName("select"), n = t.getChildByName("ic"), o = t.getChildByName("delete_btn"), r = t.getChildByName("edit_btn"), c = t.getChildByName("name"), g = t.getChildByName("number"), _ = t.getChildByName("label1"), f = t.getChildByName("label2");
        o.getComponent(Button).clickEvents[0].customEventData = i + "";
        o.active = !!e.can_del;
        r.getComponent(Button).clickEvents[0].customEventData = i + "";
        r.active = !!e.can_update;
        c.getComponent(Label).string = ToolUtils.getLimitLengthString(e.w_name, 30, false);
        g.getComponent(Label).string = ToolUtils.getLimitLengthString(e.w_account, 24, false);
        _.getComponent(Label).updateRenderData(true);
        f.getComponent(Label).updateRenderData(true);
        i18nMgr.shared().changeLabelFont(c.getComponent(Label));
        i18nMgr.shared().changeLabelFont(g.getComponent(Label));
        let y = -177;
        y += (_.getComponent(UITransform).width - 70.69) / 2;
        c.setPosition(new Vec3(y, -42.959));
        let b = -155;
        if (b += (f.getComponent(UITransform).width - 92.03) / 2, g.setPosition(new Vec3(b, -92.459)), 1 === Number(e.is_checked) ? (this._curIndex = i, 1 === e.can_use ? (s.getComponent(Sprite).spriteFrame = this.selectImags[1], s.getComponent(Sprite).color = color(255, 255, 255)) : (s.getComponent(Sprite).spriteFrame = this.selectImags[0], s.getComponent(Sprite).color = color(200, 200, 200))) : (s.getComponent(Sprite).spriteFrame = this.selectImags[0], s.getComponent(Sprite).color = color(200, 200, 200)), 1 === e.can_use ? (a.getComponent(Sprite).spriteFrame = this.diImags[1], c.getComponent(Label).color = this._valid_color, g.getComponent(Label).color = this._valid_color, _.getComponent(Label).color = this._valid_color, f.getComponent(Label).color = this._valid_color, a.getComponent(Sprite).color = color(255, 255, 255)) : (a.getComponent(Sprite).spriteFrame = this.diImags[0], c.getComponent(Label).color = this._invalid_color, g.getComponent(Label).color = this._invalid_color, _.getComponent(Label).color = this._invalid_color, f.getComponent(Label).color = this._invalid_color, a.getComponent(Sprite).color = color(240, 240, 240)), ToolUtils.isObjValid(t.getChildByName("err")) && (t.getChildByName("err").active ? a.getComponent(UITransform).setContentSize(size(this._itemSize.width, this._itemSize.height + 28)) : a.getComponent(UITransform).setContentSize(this._itemSize)), 1 === Number(e.w_type)) {
            let t = this.upiImags[0];
            1 === Number(e.can_use) && (t = this.upiImags[1]);
            n.getComponent(Sprite).spriteFrame = t;
        }
        else if (4 === Number(e.w_type)) {
            let t = this.bankImags[0];
            1 === Number(e.can_use) && (t = this.bankImags[1]);
            n.getComponent(Sprite).spriteFrame = t;
        }
        if (ToolUtils.isObjValid(t.getChildByName("err"))) {
            if (sys.isObjectValid(e.not_same_msg) && e.not_same_msg.length > 0) {
                let i = t.getChildByName("err").getChildByName("wz").getComponent(Label);
                i.string = ToolUtils.format("*${0}", e.not_same_msg);
                t.getChildByName("err").active = true;
                i18nMgr.shared().changeLabelFont(i);
                2 == i18nMgr.shared().language && (i.fontSize = 18);
                t.getChildByName("di").getComponent(UITransform).setContentSize(size(this._itemSize.width, this._itemSize.height + 28));
            }
            else {
                t.getChildByName("err").active = false;
                t.getChildByName("di").getComponent(UITransform).setContentSize(this._itemSize);
            }
        }
        ToolUtils.isObjValid(t.getChildByName("flag")) && sys.isObjectValid(e.status) && (1 == e.status ? (i18nMgr.shared().changeLabelLanguage(t.getChildByName("flag").getChildByName("wz").getComponent(Label), "kyc.verity_pending", true), t.getChildByName("flag").getComponent(Sprite).color = color(0, 140, 22), t.getChildByName("flag").active = true) : 3 == e.status ? (i18nMgr.shared().changeLabelLanguage(t.getChildByName("flag").getChildByName("wz").getComponent(Label), "kyc.resubmit", true), t.getChildByName("flag").getComponent(Sprite).color = color(215, 60, 69), t.getChildByName("flag").active = true) : t.getChildByName("flag").active = false);
    }
    showNodata() {
        Array.isArray(this._listData) && this._listData.length > 0 ? this.nodata.active = false : this.nodata.active = true;
    }
    button_click(t, e) {
        if (SoundManager.shared().playFx("click"), "close" === e) {
            this.onBackView();
        }
        else if ("add" === e) {
            if (1 !== this._can_add) {
                return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("withdraw.limit_tips"), 2);
            }
            if (1 !== this._can_add && 1 == User.shared().DepositTransferData.api_limit) {
                return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("withdraw.api_limit"), 2);
            }
            HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Withdraw, event: ReportConfig.hall_evt.click_withdraw_add });
            Utils.shared().showWithdrawAddView(this.node, (t => {
                ToolUtils.isObjValid(this.node) && (this.node.active = true, t && this.changeAccount(t));
            }));
        }
    }
    select_click(t, e) {
        SoundManager.shared().playFx("click");
        let i = Number(e);
        if (Array.isArray(this._listData) && this._listData.length > i) {
            let t = this._listData[i].can_use;
            if (0 === t) {
                let t = this._listData[i].status;
                return void (!sys.isObjectValid(t) || 0 != t && 3 != t || Utils.shared().showWithdrawEditView(this.node, { data: this._listData[i] }, (t => {
                    ToolUtils.isObjValid(this.node) && (this.node.active = true);
                    t && this.changeAccount(t);
                })));
            }
            1 === t && ToolUtils.isObjValid(this.node) && this.requestWithdrawAccDoCheck(this._listData[i].record_id, (t => {
                1 == t && (PushCenter.shared().pushEvent(PushEvent.SelectWithdrawAccount, this._listData[i]), this.onBackView());
            }));
        }
    }
    requestWithdrawAccDoCheck(t, e) {
        Utils.shared().showLoading(10, false, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3);
        }));
        HttpManager.shared().doGetCommonRequest({ record_id: t }, HttpRequest.WithdrawAccDoCheck, ((t, i, a) => {
            if (Utils.shared().hideLoading(), 200 != a) {
                ;
            }
            else {
                let t = ToolUtils.parseJson(i);
                0 == t.ret ? e && e(1) : ToolUtils.isSafeString(t.desc).length > 0 && Utils.shared().showToast(t.desc, 6);
            }
        }));
    }
    delete_click(t, e) {
        SoundManager.shared().playFx("click");
        let i = Number(e);
        if (Array.isArray(this._listData) && this._listData.length > i) {
            if (HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Withdraw, event: ReportConfig.hall_evt.click_withdraw_delete }), this._listData[i] && 1 == this._listData[i].status) {
                return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("withdraw.tips_verifi"), 2);
            }
            Utils.shared().showWithdrawDeleteView(this._listData[i], (t => {
                "confirm" === t && (Utils.shared().showLoading(10, false, (() => {
                    Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3);
                })), this.requestDeleteWithdrawAccount(this._listData[i].record_id));
            }));
        }
    }
    requestDeleteWithdrawAccount(t) {
        HttpManager.shared().doGetCommonRequest({ record_id: t }, HttpRequest.WithdrawAccDoDel, ((t, e, i) => {
            if (Utils.shared().hideLoading(), 200 != i) {
                ;
            }
            else {
                let t = ToolUtils.parseJson(e);
                try {
                    PushCenter.shared().pushEvent(PushEvent.RefreshWithdrawAccount);
                    ToolUtils.isObjValid(this.node) && (0 === t.ret && this.requestWithdrawAccPage(), t.desc && ToolUtils.isSafeString(t.desc).length > 0 && Utils.shared().showToast(t.desc, 2));
                }
                catch (t) {
                    TLog.printError("trycatch requestWithdrawAccPage,error:", t);
                }
            }
        }));
    }
    edit_click(t, e) {
        SoundManager.shared().playFx("click");
        let i = Number(e);
        Array.isArray(this._listData) && this._listData.length > i && (HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Withdraw, event: ReportConfig.hall_evt.click_withdraw_edit }), Utils.shared().showWithdrawEditView(this.node, { data: this._listData[i] }, (t => {
            ToolUtils.isObjValid(this.node) && (this.node.active = true);
            t && this.changeAccount(t);
        })));
    }
    changeAccount(t) {
        try {
            1 === t.is_checked ? ToolUtils.isObjValid(this.node) && this.requestWithdrawAccDoCheck(t.record_id, (e => {
                1 == e && (PushCenter.shared().pushEvent(PushEvent.SelectWithdrawAccount, t), this.onBackView());
            })) : ToolUtils.isObjValid(this.node) && this.requestWithdrawAccPage();
        }
        catch (t) {
            TLog.printError("trycatch changeAccount,error:", t);
        }
    }
    update(t) {
    }
    onScolling(t) {
        if (Array.isArray(this._listData) && this._listData.length > 0 && t) {
            let t = 152, e = 1058 + view.getVisibleSize().height - 1280 - sys.getSafeAreaRect().y + this._distance;
            this.scrollview.content.children.forEach((i => {
                let a = false, s = this.scrollview.getScrollOffset().y;
                a = i.getPosition().y + s <= t && i.getPosition().y + s >= -e;
                i.active = a;
            }));
        }
    }
    srollviewCallback(t) {
        this._isScrolling = true;
        this.onScolling(this._isScrolling);
    }
    scrollviewEnd(t) {
        this._isScrolling = false;
    }
    onBackView() {
        ToolUtils.isObjValid(this.node) && (this._callabck && this._callabck(), this.node.destroy());
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().removeListenersByTag(this);
    }
}
