// @ts-nocheck
// Recovered from index.js:249
import { _decorator, Component, Font, resources, sys } from "cc";
import { _language, init, ready, t } from "./LanguageData";
const { ccclass, property, executeInEditMode } = _decorator;
@ccclass("LocalizedLabel")
@executeInEditMode
export class LocalizedLabel extends Component {
    public label: any = null;
    @property({ visible: false })
    public key: string = "";
    @property({ visible: true })
    public bIsBold: boolean = false;
    public _font: Map = new Map;
    @property({ displayName: "Key", visible: true })
    public _key: any = null;
    get _key() {
        return this.key;
    }
    set _key(t) {
        this.updateLabel();
        this.key = t;
    }
    onLoad() {
        ready || init("en");
        this.fetchRender();
    }
    onDestroy() {
        if (this._font && this._font.has(this.key)) {
            let t = this._font.get(this.key);
            sys.isObjectValid(t) && t.isValid && t.decRef();
            this._font.delete(this.key);
        }
    }
    fetchRender() {
        let t = this.getComponent("cc.Label");
        if (t) {
            return this.label = t, void this.updateLabel();
        }
        let e = this.getComponent("cc.RichText");
        return e ? (this.label = e, void this.updateLabel()) : undefined;
    }
    updateLabel() {
        sys.isObjectValid(this.label) && (this.label.string = t(this.key), this.setLabelFont(this.label));
    }
    setLabelFont(t) {
        let e = null;
        if (this.bIsBold ? "en" == _language ? e = "font/cuti" : "hi" == _language ? e = "font/mangal" : "ta" == _language ? e = "font/NotoSansTamil_VariableFont_wdth_wght" : "ur" == _language && (e = "font/AdobeArabic-Bold") : "en" == _language ? e = "font/xiti" : "hi" == _language ? e = "font/mangal" : "ta" == _language ? e = "font/NotoSansTamil_VariableFont_wdth_wght" : "ur" == _language && (e = "font/AdobeArabic-Regular"), null != e) {
            if (this._font && this._font.has(e)) {
                let i = this._font.get(e);
                t.font = i;
            }
            else {
                resources.load(e, Font, ((i, o) => {
                    null == i && sys.isObjectValid(o) && (sys.isObjectValid(this._font) || (this._font = new Map), o.addRef(), this._font.set(e, o), sys.isObjectValid(t) && t.isValid && (t.font = o));
                }));
            }
        }
    }
}
