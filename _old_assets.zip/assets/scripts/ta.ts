// @ts-nocheck
// Recovered from index.js:7
const e = window;
export const languages = {};
(e.languages || (e.languages = {}));
(e.languages.ta = languages);
