// @ts-nocheck
// Recovered from index.js:677
import { _decorator, Button, color, instantiate, Label, Node, ProgressBar, sp, Sprite, SpriteFrame, sys, v3 } from "cc";
import BaseLayer from "./BaseLayer";
import PushCenter from "./PushCenter";
import PushEvent from "./PushEvent";
import SoundManager from "./SoundManager";
import i18nMgr from "./i18nMgr";
import Utils from "./Utils";
import TweenTool from "./TweenTool";
import User from "./User";
import GameConfig from "./GameConfig";
import { TLog } from "./TLog";
import HttpManager from "./HttpManager";
import { HttpRequest } from "./HttpRequestName";
import ReportConfig from "./ReportConfig";
import BundleNameDefined from "./BundleNameDefined";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("WelcomeBackWork")
export class WelcomeBackWork extends BaseLayer {
    public TAG: string = "WelcomeBackWork";
    @property([SpriteFrame])
    public task_StateBgs: SpriteFrame[] = [];
    @property([SpriteFrame])
    public login_Bgs: SpriteFrame[] = [];
    @property([SpriteFrame])
    public task_Bgs: SpriteFrame[] = [];
    @property(Label)
    public task_timeLabel: Label = null;
    @property(Node)
    public root: Node = null;
    @property([SpriteFrame])
    public awardIconFrames: SpriteFrame[] = [];
    @property([SpriteFrame])
    public chargeTaskBtnBgs: SpriteFrame[] = [];
    @property([Node])
    public loginTask_items: Node[] = [];
    @property([Node])
    public playTask_items: Node[] = [];
    @property(Node)
    public chargeTask_item: Node = null;
    @property(Node)
    public collectAllNode: Node = null;
    @property([Node])
    public chargeItems: Node[] = [];
    @property(Node)
    public ruleRoot: Node = null;
    @property(Label)
    public ruleLabel: Label = null;
    @property(Node)
    public fingerAnim: Node = null;
    @property(Node)
    public awardBoxAnimNode: Node = null;
    @property(Node)
    public flashAnimNode: Node = null;
    @property(Node)
    public openCardAnimNode: Node = null;
    public param: any = null;
    public _linkId: number = 0;
    public _reportScene: any = -1;
    public _initDelay: number = 0;
    public _has_close: boolean = false;
    public chargeSelectIndex: number = 0;
    public has_sendAwardReq: boolean = false;
    public chargeTaskState: number = 0;
    public task_StateWzKeys: any[] = ["club.locked", "tournament.finished"];
    public canGetRewardItemCount: number = 0;
    public canGetRewardData: any[] = [];
    public fingerAnimPos: any = v3(-1, -1, 0);
    public task_StateWzColors: any[] = [color(255, 255, 255), color(116, 229, 41)];
    public charge_itembgColors: any[] = [color(34, 132, 38), color(255, 255, 255)];
    public charge_itemwzColors: any[] = [color(51, 51, 51), color(75, 75, 75)];
    public _scheduleAct: any = null;
    public _leftTime: any = -1;
    public has_reportUI: boolean = false;
    public _lastClick: number = 0;
    public _callback: any = null;
    onLoad() {
        this._initDelay = 0;
        this.dealMultipleLanguages();
    }
    dealMultipleLanguages() {
        if (2 == i18nMgr.shared().language) {
            this.root.getChildByName("tip").getComponent(Label).fontSize = 24;
            this.root.getChildByName("collect_btn").getChildByName("wz").getComponent(Label).fontSize = 30;
            for (let e = 0; e < 3; e++) {
                this.loginTask_items[e].getChildByName("flag").getChildByName("day_wz_1").setPosition(v3(13.083, 3.584));
                this.loginTask_items[e].getChildByName("flag").getChildByName("day_wz_2").setPosition(v3(13.083, 3.584));
            }
        }
        else {
            3 == i18nMgr.shared().language && (this.chargeTask_item.getChildByName("charge_btn").getChildByName("wz").getComponent(Label).fontSize = 24);
        }
    }
    start() {
        super.start();
        this._linkId = this._linkId > 0 ? this._linkId : sys.now();
        this._reportScene = this._reportScene >= 0 ? this._reportScene : ToolUtils.getIsInRoom() ? 2 : 1;
        this.startShowAnim(this.root, (() => {
        }));
        TweenTool.delayAct(this.node, (() => {
            null !== User.shared().backCardTaskdata && this.updateBackTaskContent();
            User.shared().requestBackCardTaskData(true);
        }), this._initDelay, true);
        PushCenter.shared().addListener(PushEvent.UpdateBackCardTask, (e => {
            sys.isObjectValid(this.node) && (this.updateBackTaskContent(), this.has_reportUI || (this.has_reportUI = true, HttpManager.shared().doCommReportRechargeEvent(ReportConfig.Cmd_BackCardTask, this._reportScene, 4, this._linkId, "", 0)));
        }), this);
        PushCenter.shared().addListener(GameConfig.Recharge, (e => {
            ToolUtils.isObjValid(this.node) && User.shared().requestBackCardTaskData(true);
        }), this);
        sys.isObjectValid(User.shared().backCardTaskdata) && (this.has_reportUI || (this.has_reportUI = true, HttpManager.shared().doCommReportRechargeEvent(ReportConfig.Cmd_BackCardTask, this._reportScene, 4, this._linkId, "", 0)));
        ToolUtils.showFullScreen(this.node.getChildByName("mask"));
        ToolUtils.showFullScreen(this.ruleRoot.getChildByName("mask"));
        TweenTool.delayAct(this.node, (() => {
            SoundManager.shared().preLoadBundleSounds(BundleNameDefined.bundle_sound, "novicesTask");
        }), this._initDelay, true);
    }
    scheduleCallBack() {
        this._leftTime <= -1 || (this._leftTime -= 1, this._leftTime < 0 && (this._leftTime = 0, this._scheduleAct && TweenTool.stopAction(this._scheduleAct), User.shared().requestBackCardTaskData(true)), this.refreshLeftTime());
    }
    refreshLeftTime() {
        let e = Utils.shared().getCountDownArray(this._leftTime);
        this.task_timeLabel.string = e[0] + ":" + e[1] + ":" + e[2];
    }
    updateBackTaskContent() {
        this.canGetRewardItemCount = 0;
        this.fingerAnimPos = v3(-1, -1, 0);
        this.canGetRewardData = [];
        this._leftTime = Number(User.shared().backCardTaskdata.lefttime);
        this._scheduleAct && TweenTool.stopAction(this._scheduleAct);
        this._leftTime > 0 && (this._scheduleAct = TweenTool.commonSchedule(this.node, 1, this.scheduleCallBack.bind(this)));
        this.refreshLeftTime();
        this.updateLoginTaskState();
        this.updatePlayTaskState();
        this.chargeTaskState = Number(User.shared().backCardTaskdata.charge_t.st);
        this.updateChargeTaskState();
        this.updateFingerAndCollectBtnState();
    }
    updateFingerAndCollectBtnState() {
        this.root.getChildByName("collect_btn").active = 0 != this.canGetRewardItemCount;
        this.fingerAnim.active = 0 != this.canGetRewardItemCount;
        this.canGetRewardItemCount > 0 && (1 == this.canGetRewardItemCount ? i18nMgr.shared().changeLocalizedLabelKey(this.root.getChildByName("collect_btn").getChildByName("wz"), "daily_tasks.collect") : i18nMgr.shared().changeLocalizedLabelKey(this.root.getChildByName("collect_btn").getChildByName("wz"), "daily_tasks.all_txt"), this.fingerAnim.setPosition(this.fingerAnimPos), this.fingerAnim.getComponent(sp.Skeleton).clearTracks(), this.fingerAnim.getComponent(sp.Skeleton).setAnimation(0, "click", true));
        this.root.getChildByName("collect_btn").active = false;
    }
    updatePlayTaskState() {
        if (sys.isObjectValid(User.shared().backCardTaskdata.play_t) && 3 == User.shared().backCardTaskdata.play_t.length) {
            for (let e = 0; e < 3; e++) {
                let t = User.shared().backCardTaskdata.play_t[e];
                if (this.playTask_items[e].getChildByName("awardbg").active = 3 == t.st, this.playTask_items[e].getChildByName("state_exp").active = 4 == t.st, this.playTask_items[e].getChildByName("getbtn").getComponent(Button).enabled = 2 == t.st, this.playTask_items[e].getChildByName("task_wz").active = true, this.playTask_items[e].getChildByName("percent").active = true, this.playTask_items[e].getChildByName("bg").active = true, 4 == t.st ? (this.playTask_items[e].getChildByName("bg").getComponent(Sprite).spriteFrame = this.task_Bgs[0], this.playTask_items[e].getChildByName("flag").getComponent(Sprite).color = color(148, 148, 148), this.playTask_items[e].getChildByName("task_wz").getComponent(Label).color = color(148, 148, 148)) : (this.playTask_items[e].getChildByName("bg").getComponent(Sprite).spriteFrame = this.task_Bgs[1], this.playTask_items[e].getChildByName("flag").getComponent(Sprite).color = color(228, 120, 23), this.playTask_items[e].getChildByName("task_wz").getComponent(Label).color = color(51, 51, 51)), sys.isObjectValid(t.cnt) && (this.playTask_items[e].getChildByName("task_wz").getComponent(Label).string = t.cnt), 0 == t.st ? this.playTask_items[e].getChildByName("task_wz").setPosition(v3(0, -46.607)) : this.playTask_items[e].getChildByName("task_wz").setPosition(v3(0, -26.607)), 3 != t.st) {
                    this.playTask_items[e].getChildByName("percent").active = 1 == t.st || 2 == t.st;
                    this.playTask_items[e].getChildByName("statebg").active = 0 == t.st;
                    let a = Number(t.percent);
                    this.playTask_items[e].getChildByName("percent").getComponent(ProgressBar).progress = a / 100;
                    0 == t.st || 2 == t.st && (this.canGetRewardItemCount++, this.canGetRewardData.push({ index: e + 3, tid: t.tid }), -1 == this.fingerAnimPos.x && this.playTask_items[e].getPosition(this.fingerAnimPos));
                }
                else {
                    if (this.playTask_items[e].getChildByName("awardbg").getChildByName("gou").active = true, sys.isObjectValid(t.rnum)) {
                        let a = String(t.rnum);
                        this.playTask_items[e].getChildByName("awardbg").getChildByName("num").getComponent(Label).string = a;
                    }
                    sys.isObjectValid(t.rtype) && Number(t.rtype) < 3 && (this.playTask_items[e].getChildByName("awardbg").getChildByName("ico").getComponent(Sprite).spriteFrame = this.awardIconFrames[Number(t.rtype)]);
                    this.playTask_items[e].getChildByName("awardbg").getChildByName("ico").active = true;
                }
            }
        }
    }
    updateLoginTaskState() {
        if (sys.isObjectValid(User.shared().backCardTaskdata.login_t) && 3 == User.shared().backCardTaskdata.login_t.length) {
            for (let e = 0; e < 3; e++) {
                let t = User.shared().backCardTaskdata.login_t[e];
                this.loginTask_items[e].getChildByName("awardbg").active = 2 == t.st;
                this.loginTask_items[e].getChildByName("state_exp").active = 3 == t.st;
                this.loginTask_items[e].getChildByName("award_fuhao").active = true;
                this.loginTask_items[e].getChildByName("award_num").active = true;
                this.loginTask_items[e].getChildByName("uptip").active = true;
                this.loginTask_items[e].getChildByName("bg").active = true;
                this.loginTask_items[e].getChildByName("getbtn").getComponent(Button).enabled = 1 == t.st;
                this.loginTask_items[e].getChildByName("flag").active = 2 != t.st;
                3 == t.st ? (this.loginTask_items[e].getChildByName("bg").getComponent(Sprite).spriteFrame = this.login_Bgs[0], this.loginTask_items[e].getChildByName("flag").getComponent(Sprite).color = color(148, 148, 148), this.loginTask_items[e].getChildByName("uptip").getComponent(Label).color = color(148, 148, 148), this.loginTask_items[e].getChildByName("award_fuhao").getComponent(Label).color = color(148, 148, 148), this.loginTask_items[e].getChildByName("award_num").getComponent(Label).color = color(148, 148, 148), this.loginTask_items[e].getChildByName("award_fuhao").active = false, this.loginTask_items[e].getChildByName("award_num").active = false, this.loginTask_items[e].getChildByName("uptip").active = false) : (this.loginTask_items[e].getChildByName("bg").getComponent(Sprite).spriteFrame = this.login_Bgs[1], this.loginTask_items[e].getChildByName("flag").getComponent(Sprite).color = color(228, 120, 23), this.loginTask_items[e].getChildByName("uptip").getComponent(Label).color = color(231, 13, 13), this.loginTask_items[e].getChildByName("award_fuhao").getComponent(Label).color = color(231, 13, 13), this.loginTask_items[e].getChildByName("award_num").getComponent(Label).color = color(231, 13, 13));
                2 != t.st ? this.loginTask_items[e].getChildByName("award_num").getComponent(Label).string = t.up : (sys.isObjectValid(t.rnum) && (this.loginTask_items[e].getChildByName("awardbg").getChildByName("num").getComponent(Label).string = t.rnum), sys.isObjectValid(t.rtype) && Number(t.rtype) < 3 && (this.loginTask_items[e].getChildByName("awardbg").getChildByName("ico").getComponent(Sprite).spriteFrame = this.awardIconFrames[Number(t.rtype)]), this.loginTask_items[e].getChildByName("awardbg").getChildByName("gou").active = true, this.loginTask_items[e].getChildByName("awardbg").getChildByName("ico").active = true);
                1 == t.st && (this.canGetRewardItemCount++, this.canGetRewardData.push({ index: e, tid: t.tid }), -1 == this.fingerAnimPos.x && this.loginTask_items[e].getPosition(this.fingerAnimPos));
            }
        }
    }
    updateChargeTaskState() {
        if (sys.isObjectValid(User.shared().backCardTaskdata.charge_t)) {
            if (this.chargeTask_item.getChildByName("awardbg").active = 2 == this.chargeTaskState, this.chargeTask_item.getChildByName("upto").active = true, this.chargeTask_item.getChildByName("award_fuhao").active = true, this.chargeTask_item.getChildByName("award_num").active = true, this.chargeTask_item.getChildByName("charge_btn").active = true, this.chargeTask_item.getChildByName("bg").active = true, this.chargeTask_item.getChildByName("tip").active = 2 != this.chargeTaskState, 0 == this.chargeTaskState) {
                this.chargeTask_item.getChildByName("award_num").getComponent(Label).string = User.shared().backCardTaskdata.charge_t.up;
                let e = this.chargeTask_item.getChildByName("charge_btn");
                e.getChildByName("ico").getComponent(Sprite).spriteFrame = this.chargeTaskBtnBgs[1];
                i18nMgr.shared().changeLocalizedLabelKey(e.getChildByName("wz"), "store.add_cash");
            }
            else if (1 == this.chargeTaskState) {
                this.chargeTask_item.getChildByName("award_num").getComponent(Label).string = User.shared().backCardTaskdata.charge_t.up;
                let e = this.chargeTask_item.getChildByName("charge_btn");
                e.getChildByName("ico").getComponent(Sprite).spriteFrame = this.chargeTaskBtnBgs[0];
                i18nMgr.shared().changeLocalizedLabelKey(e.getChildByName("wz"), "novices.collect");
                this.canGetRewardItemCount++;
                this.chargeTask_item.getChildByName("charge_btn").getChildByName("ico").setSiblingIndex(555);
                this.chargeTask_item.getChildByName("charge_btn").getChildByName("wz").setSiblingIndex(556);
                this.canGetRewardData.push({ index: 6, tid: User.shared().backCardTaskdata.charge_t.tid });
                -1 == this.fingerAnimPos.x && (this.fingerAnimPos = v3(170, -355));
            }
            else {
                if (sys.isObjectValid(User.shared().backCardTaskdata.charge_t.rnum)) {
                    let e = String(User.shared().backCardTaskdata.charge_t.rnum);
                    this.chargeTask_item.getChildByName("awardbg").getChildByName("num").getComponent(Label).string = e;
                    this.chargeTask_item.getChildByName("charge_btn").getComponent(Button).enabled = false;
                }
                this.chargeTask_item.getChildByName("awardbg").getChildByName("gou").active = true;
                this.chargeTask_item.getChildByName("awardbg").getChildByName("ico").active = true;
            }
        }
    }
    initParaData(e, t) {
        this.param = e;
        this._callback = t;
        sys.isObjectValid(e) && sys.isObjectValid(e.reportScene) && (this._reportScene = e.reportScene);
        sys.isObjectValid(e) && sys.isObjectValid(e.link_id) && e.link_id > 0 && (this._linkId = e.link_id);
    }
    onHelpBtnClick(e, t) {
        SoundManager.shared().playFx("click");
        this.ruleRoot.active = true;
        this.startShowAnim(this.ruleRoot.getChildByName("bg"), (() => {
            this.ruleLabel.string = User.shared().backCardTaskdata.rule;
            i18nMgr.shared().changeLabelFont(this.ruleLabel);
        }));
    }
    onClosetnClick(e, t) {
        if (SoundManager.shared().playFx("click"), ToolUtils.isObjValid(this.node)) {
            if ("ruleclose" == t) {
                return void (this.ruleRoot.active = false);
            }
            if (this._has_close) {
                return;
            }
            this._has_close = true;
            this.param.isNext && PushCenter.shared().pushEvent(PushEvent.Update_NextPopActivity);
            PushCenter.shared().removeListenersByTag(this);
            ToolUtils.isObjValid(this.node) && (this.node.destroy(), this._callback && this._callback());
            User.shared().getHallInfo();
        }
    }
    onChargeTaskBtnClick(e, t) {
        if (SoundManager.shared().playFx("click"), 0 == this.chargeTaskState) {
            if (!User.shared().checkCanRecharge()) {
                return void (ToolUtils.isObjValid(this.node) && this.node.destroy());
            }
            Utils.shared().showStoreView();
        }
        else if (1 == this.chargeTaskState) {
            let e = User.shared().backCardTaskdata.charge_t.tid;
            this.dealGetTaskAward([e]);
            {
                let e = sys.now(), t = "";
                t = {};
                HttpManager.shared().doCommReportRechargeEvent(ReportConfig.Cmd_BackCardTask, this._reportScene, 7, this._linkId, t, 0, e);
            }
        }
    }
    refreshAwardBgView(e, t) {
        let a = [];
        for (let i = 0; i < e.length; i++) {
            for (let s = 0; s < this.canGetRewardData.length; s++) {
                if (e[i] == this.canGetRewardData[s].tid) {
                    let l = this.canGetRewardData[s].index;
                    a.push(l);
                    let h = null;
                    l < 3 ? (this.loginTask_items[l].getChildByName("awardbg").getChildByName("gou").active = false, this.loginTask_items[l].getChildByName("awardbg").getChildByName("num").active = true, this.loginTask_items[l].getChildByName("awardbg").getChildByName("ico").active = false, h = this.loginTask_items[l].getChildByName("awardbg")) : l < 6 ? (this.playTask_items[l - 3].getChildByName("awardbg").getChildByName("gou").active = false, this.playTask_items[l - 3].getChildByName("awardbg").getChildByName("num").active = true, this.playTask_items[l - 3].getChildByName("awardbg").getChildByName("ico").active = false, h = this.playTask_items[l - 3].getChildByName("awardbg")) : (this.chargeTask_item.getChildByName("awardbg").getChildByName("gou").active = false, this.chargeTask_item.getChildByName("awardbg").getChildByName("num").active = true, this.chargeTask_item.getChildByName("awardbg").getChildByName("ico").active = false, h = this.chargeTask_item.getChildByName("awardbg"));
                    for (let a = 0; a < t.length; a++) {
                        if (e[i] == t[a].tid) {
                            sys.isObjectValid(t[a].rnum) && (h.getChildByName("num").getComponent(Label).string = t[a].rnum);
                            sys.isObjectValid(t[a].rtype) && Number(t[a].rtype) < 3 && l < 6 && (h.getChildByName("ico").getComponent(Sprite).spriteFrame = this.awardIconFrames[Number(t[a].rtype)]);
                            break;
                        }
                    }
                }
            }
        }
        return a;
    }
    playOpenCardAnim(e) {
        this.fingerAnim.active = false;
        SoundManager.shared().playFx("scraping");
        for (let t = 0; t < e.length; t++) {
            let a = e[t], i = null, s = "open_big_1";
            a < 3 ? (i = this.loginTask_items[a], s = "open_big_" + (t + 1), i.getChildByName("uptip").active = false, i.getChildByName("award_fuhao").active = false, i.getChildByName("award_num").active = false, i.getChildByName("bg").active = false, i.getChildByName("flag").active = false) : a < 6 ? (i = this.playTask_items[a - 3], s = "open_double", i.getChildByName("task_wz").active = false, i.getChildByName("percent").active = false, i.getChildByName("bg").active = false, i.getChildByName("flag").active = false) : (i = this.chargeTask_item, s = "open_crazy", i.getChildByName("upto").active = false, i.getChildByName("award_fuhao").active = false, i.getChildByName("award_num").active = false, i.getChildByName("charge_btn").active = false, i.getChildByName("tip").active = false, i.getChildByName("bg").active = false);
            sys.isObjectValid(i.getChildByName("flash_anim")) && i.getChildByName("flash_anim").destroy();
            let r = instantiate(this.openCardAnimNode);
            r.name = "openAnim";
            i.addChild(r);
            i.getChildByName("awardbg").active = true;
            r.active = true;
            r.getComponent(sp.Skeleton).clearTracks();
            r.getComponent(sp.Skeleton).setAnimation(0, s, false);
            let l = false;
            r.getComponent(sp.Skeleton).setCompleteListener((() => {
                l || r.destroy();
                l = true;
            }));
        }
    }
    playBoxAnim(e, t) {
        for (let t = 0; t < e.length; t++) {
            let a = e[t], i = null;
            v3(0, 0, 0);
            i = a < 3 ? this.loginTask_items[a] : a < 6 ? this.playTask_items[a - 3] : this.chargeTask_item;
            i.getChildByName("awardbg").active = true;
            i.getChildByName("awardbg").getChildByName("ico").active = true;
            i.getChildByName("awardbg").getChildByName("gou").active = true;
        }
    }
    dealGetTaskAward(e) {
        if (this.has_sendAwardReq) {
            return;
        }
        this.has_sendAwardReq = true;
        let t = "";
        1 == e.length && (t = e[0]);
        Utils.shared().showLoading(10, true, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
        }));
        HttpManager.shared().doGetCommonRequest({ tid: t }, HttpRequest.GetBackCardAward, ((t, a, i) => {
            if (ToolUtils.isObjValid(this.node)) {
                if (Utils.shared().hideLoading(), 200 != i) {
                    0 == sys.getNetworkType() ? Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text91"), 3, 0, ToolUtils.getIsNormalDirection()) : Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
                    this.has_sendAwardReq = false;
                }
                else {
                    try {
                        let t = ToolUtils.parseJson(a);
                        if (0 == t.ret) {
                            this.fingerAnim.active = false;
                            let a = t.data.treward, i = this.refreshAwardBgView(e, a), s = 0;
                            this.playOpenCardAnim(i);
                            s += 0.6;
                            TweenTool.delayAct(this.root, (() => {
                                this.playBoxAnim(i, a);
                            }), s, true);
                            s += 1.2;
                            TweenTool.delayAct(this.root, (() => {
                                this.showRewards(t.data.reward, t.data.msg);
                            }), s, true);
                            s += 1;
                            TweenTool.delayAct(this.root, (() => {
                                this.has_sendAwardReq = false;
                                User.shared().requestBackCardTaskData(true);
                            }), s, true);
                        }
                        else {
                            ToolUtils.isSafeString(t.desc).length > 0 && (Utils.shared().showToast(t.desc, 2), this.has_sendAwardReq = false);
                        }
                    }
                    catch (e) {
                        this.has_sendAwardReq = false;
                        TLog.printError(this.TAG, "_dealGetTaskAward  error:", e);
                    }
                }
            }
        }));
    }
    onClickAddCash(e, t) {
        if (SoundManager.shared().playFx("click"), sys.now() - this._lastClick < 500) {
            return;
        }
        this._lastClick = sys.now();
        let a = Number(User.shared().backCardTaskdata.charge_t.tprice[this.chargeSelectIndex]), i = sys.now(), s = { price: Number(a), link_id: this._linkId, act_id: PushEvent.JUMP_TO_BACKCARDTASK };
        s.client_time = i;
        User.shared().startPay(s);
        {
            let e = sys.now(), t = "";
            t = {};
            HttpManager.shared().doCommReportRechargeEvent(ReportConfig.Cmd_BackCardTask, this._reportScene, 13, this._linkId, t, 0, e);
        }
    }
    onSelectChargeItemClick(e, t) {
        SoundManager.shared().playFx("click");
        this.chargeSelectIndex = Number(t);
        {
            let e = sys.now(), t = "";
            t = {};
            HttpManager.shared().doCommReportRechargeEvent(ReportConfig.Cmd_BackCardTask, this._reportScene, 9 + this.chargeSelectIndex, this._linkId, t, 0, e);
        }
    }
    onCollectBtnClick(e, t) {
        if (SoundManager.shared().playFx("click"), this.canGetRewardData.length > 0) {
            let e = [];
            for (let t = 0; t < this.canGetRewardData.length; t++) {
                e.push(this.canGetRewardData[t].tid);
            }
            this.dealGetTaskAward(e);
        }
    }
    onGetLoginRewardClick(e, t) {
        SoundManager.shared().playFx("click");
        let a = Number(t), i = User.shared().backCardTaskdata.login_t[a].tid;
        this.dealGetTaskAward([i]);
        {
            let e = sys.now(), t = "";
            t = {};
            HttpManager.shared().doCommReportRechargeEvent(ReportConfig.Cmd_BackCardTask, this._reportScene, 5, this._linkId, t, 0, e);
        }
    }
    onGetDayTaskRewardClick(e, t) {
        SoundManager.shared().playFx("click");
        let a = Number(t), i = User.shared().backCardTaskdata.play_t[a].tid;
        this.dealGetTaskAward([i]);
        {
            let e = sys.now(), t = "";
            t = {};
            HttpManager.shared().doCommReportRechargeEvent(ReportConfig.Cmd_BackCardTask, this._reportScene, 6, this._linkId, t, 0, e);
        }
    }
    showRewards(e, t = "") {
        let a = e;
        if (a && a.length > 0) {
            let e = null;
            sys.isObjectValid(t) && ToolUtils.isSafeString(t).length > 0 && (e = ToolUtils.isSafeString(t));
            User.shared().showChargeReward(a, null, e);
        }
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().pushEvent(PushEvent.HallGet);
        PushCenter.shared().removeListenersByTag(this);
    }
}
