// @ts-nocheck
// Recovered from index.js:27
import { _decorator } from "cc";
const { ccclass } = _decorator;
@ccclass("Base64")
export default class Base64 {
    static _instance = null;
    public _keyStr: string = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
    public str: string = "";
    public toastPrefab: any = null;
    static shared() : Base64 {
        return null == this._instance && (this._instance = new Base64), this._instance;
    }
    encode(r) {
        var t, e, a, o, n, h, c, i = "", s = 0;
        for (r = this._utf8_encode(r); s < r.length;) {
            o = (t = r.charCodeAt(s++)) >> 2;
            n = (3 & t) << 4 | (e = r.charCodeAt(s++)) >> 4;
            h = (15 & e) << 2 | (a = r.charCodeAt(s++)) >> 6;
            c = 63 & a;
            isNaN(e) ? h = c = 64 : isNaN(a) && (c = 64);
            i = i + this._keyStr.charAt(o) + this._keyStr.charAt(n) + this._keyStr.charAt(h) + this._keyStr.charAt(c);
        }
        return i;
    }
    decode(r) {
        var t, e, a, o, n, h, c = "", i = 0;
        for (r = r.replace(/[^A-Za-z0-9\+\/\=]/g, ""); i < r.length;) {
            t = this._keyStr.indexOf(r.charAt(i++)) << 2 | (o = this._keyStr.indexOf(r.charAt(i++))) >> 4;
            e = (15 & o) << 4 | (n = this._keyStr.indexOf(r.charAt(i++))) >> 2;
            a = (3 & n) << 6 | (h = this._keyStr.indexOf(r.charAt(i++)));
            c += String.fromCharCode(t);
            64 != n && (c += String.fromCharCode(e));
            64 != h && (c += String.fromCharCode(a));
        }
        return c = this._utf8_decode(c);
    }
    _utf8_encode(r) {
        for (var t = "", e = 0, a = (r = r.replace(/\r\n/g, "\n")).length; e < a; e++) {
            var o = r.charCodeAt(e);
            o < 128 ? t += String.fromCharCode(o) : o > 127 && o < 2048 ? (t += String.fromCharCode(o >> 6 | 192), t += String.fromCharCode(63 & o | 128)) : (t += String.fromCharCode(o >> 12 | 224), t += String.fromCharCode(o >> 6 & 63 | 128), t += String.fromCharCode(63 & o | 128));
        }
        return t;
    }
    _utf8_decode(r) {
        let t = "", e = 0, a = 0, o = 0, n = 0;
        for (; e < r.length;) {
            a = r.charCodeAt(e);
            a < 128 ? (t += String.fromCharCode(a), e++) : a > 191 && a < 224 ? (o = r.charCodeAt(e + 1), t += String.fromCharCode((31 & a) << 6 | 63 & o), e += 2) : (o = r.charCodeAt(e + 1), n = r.charCodeAt(e + 2), t += String.fromCharCode((15 & a) << 12 | (63 & o) << 6 | 63 & n), e += 3);
        }
        return t;
    }
}
