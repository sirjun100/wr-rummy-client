// @ts-nocheck
// Recovered from index.js:515
import { _decorator, Node, sys } from "cc";
import BaseLayer from "./BaseLayer";
import i18nMgr from "./i18nMgr";
import PushCenter from "./PushCenter";
import { ToolUtils } from "./ToolUtils";
import { TransferPlatform } from "./TransferPlatform";
import Utils from "./Utils";
import PushEvent from "./PushEvent";
import User from "./User";
import SoundManager from "./SoundManager";
import HttpManager from "./HttpManager";
import PhpReportDefined from "./PhpReportDefined";
const { ccclass, property } = _decorator;
@ccclass("SharePopAct")
export class SharePopAct extends BaseLayer {
    @property(Node)
    public rootNode: Node = null;
    public _cb: any = null;
    public _data: any = null;
    public isSendMsg: boolean = false;
    public _lastClick: number = 0;
    public dialogType: number = 0;
    public inShare: number = 0;
    public _has_close: boolean = false;
    public _isNext: boolean = false;
    public canClick: boolean = true;
    public share_url: any = null;
    public share_text: string = "";
    public lastTime: number = 0;
    setParaData(e, t) {
        this._cb = e;
        this._data = t;
        this._isNext = t.isNext;
    }
    start() {
        super.start();
        ToolUtils.showFullScreen(this.node.getChildByName("bg"));
        this.startShowAnim(this.rootNode);
        HttpManager.shared().doReportClick({ module: PhpReportDefined.module.share, scene: PhpReportDefined.scece.share_pop_page, event: PhpReportDefined.share_event.show });
    }
    onButtonClick(e, t) {
        if (SoundManager.shared().playFx("click"), "close" == t) {
            let e = { alert_node: this.node, rootNode: this.rootNode, isNext: this._isNext, pop_type: PushEvent.JUMP_TO_InviteCheck, pop_souce: 1 };
            Utils.shared().closeActivityView(e);
            this.onBackView();
        }
        else if ("whatsapp" == t) {
            if (sys.isObjectValid(User.shared().shareMainInfo) ? (this.share_url = User.shared().shareMainInfo.share_url, this.share_text = User.shared().shareMainInfo.share_text) : (sys.isObjectValid(this._data) && sys.isObjectValid(this._data.share_url) && (this.share_url = this._data.share_url), sys.isObjectValid(this._data) && sys.isObjectValid(this._data.share_text) && (this.share_text = this._data.share_text)), 0 === TransferPlatform.shared().checkPackageInstalled("com.whatsapp")) {
                Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text48"), 2);
                let e = this.share_text + " " + this.share_url;
                return TransferPlatform.shared().shareWebPage(ToolUtils.isSafeString(e)), void HttpManager.shared().doReportClick({ module: PhpReportDefined.module.share, scene: PhpReportDefined.scece.share_pop_page, event: PhpReportDefined.share_event.click_share });
            }
            let e = sys.now();
            if (e - this.lastTime < 500) {
                return;
            }
            this.lastTime = e;
            let t = this.share_text + " " + this.share_url;
            ToolUtils.isSafeString(t).length > 0 && (User.shared().shareImageAndTextToThirdApp(1, "", t), HttpManager.shared().doReportClick({ module: PhpReportDefined.module.share, scene: PhpReportDefined.scece.share_pop_page, event: PhpReportDefined.share_event.click_share }));
        }
        else if ("link" == t) {
            let e = sys.now();
            if (e - this.lastTime < 500) {
                return;
            }
            if (this.lastTime = e, sys.isObjectValid(this._data) && sys.isObjectValid(this._data.share_url) ? this.share_url = this._data.share_url : sys.isObjectValid(User.shared().shareMainInfo) && (this.share_url = User.shared().shareMainInfo.share_url), sys.isObjectValid(this._data) && sys.isObjectValid(this._data.share_text) ? this.share_text = this._data.share_text : sys.isObjectValid(User.shared().shareMainInfo) && (this.share_text = User.shared().shareMainInfo.share_text), ToolUtils.isSafeString(this.share_url).length > 0 || ToolUtils.isSafeString(this.share_text).length > 0) {
                let e = this.share_text + " " + this.share_url;
                TransferPlatform.shared().shareWebPage(e);
                TransferPlatform.shared().copyContent(e);
                HttpManager.shared().doReportClick({ module: PhpReportDefined.module.share, scene: PhpReportDefined.scece.share_pop_page, event: PhpReportDefined.share_event.click_share });
            }
        }
    }
    onBackView() {
        if (ToolUtils.isObjValid(this.node)) {
            if (this._has_close) {
                return;
            }
            this._has_close = true;
            PushCenter.shared().removeListenersByTag(this);
            ToolUtils.isObjValid(this.node) && this.node.destroy();
        }
    }
}
