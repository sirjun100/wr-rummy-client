// @ts-nocheck
// Recovered from index.js:665
import { _decorator, color, Label, Node, size, Sprite, SpriteFrame, sys, UITransform, v3, Widget } from "cc";
import BaseLayer from "./BaseLayer";
import SoundManager from "./SoundManager";
import PushCenter from "./PushCenter";
import { TLog } from "./TLog";
import Utils from "./Utils";
import i18nMgr from "./i18nMgr";
import HttpManager from "./HttpManager";
import GameConfig from "./GameConfig";
import User from "./User";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("VerifySelect")
export class VerifySelect extends BaseLayer {
    @property(Node)
    public rootNode: Node = null;
    @property(Node)
    public sub_tips: Node = null;
    @property(Node)
    public items_list: Node = null;
    @property(Node)
    public bottom_tips: Node = null;
    @property(Node)
    public submitBtn: Node = null;
    @property(Node)
    public tipsNode: Node = null;
    @property([Node])
    public items: Node[] = [];
    @property([SpriteFrame])
    public selectSpriteFrame: SpriteFrame[] = [];
    @property([SpriteFrame])
    public bgSpriteFrame: SpriteFrame[] = [];
    public _showItems: any[] = [];
    public _selectIdx: any[] = [];
    public _curType: number = 1;
    public _curIdx: number = 0;
    public bShowPushAnim: boolean = false;
    public showUICallback: any = null;
    public closeUICallBack: any = null;
    public _closed: boolean = false;
    init(t, e = null, i = null) {
        this.bShowPushAnim = t;
        this.showUICallback = e;
        this.closeUICallBack = i;
    }
    onLoad() {
        if (sys.isObjectValid(User.shared().newKycData.policy_card_content) && User.shared().newKycData.policy_card_content.length > 0 ? (this.sub_tips.active = true, this.sub_tips.getChildByName("wz").getComponent(Label).string = User.shared().newKycData.policy_card_content, this.items_list.setPosition(v3(0, -495))) : (this.sub_tips.active = false, this.items_list.setPosition(v3(0, -330))), this.initShowItems(), ToolUtils.isSafeString(User.shared().kyc_bottom_tip).length > 0) {
            this.tipsNode.getComponent(Label).string = User.shared().kyc_bottom_tip;
        }
        else {
            let t = i18nMgr.shared().getValueByKey("kyc.kyc_18tips");
            this.tipsNode.getComponent(Label).string = t;
        }
        this.dealMultipleLanguages();
    }
    dealMultipleLanguages() {
        2 == i18nMgr.shared().language && (this.items[0].getChildByName("label2").getComponent(Label).fontSize = 22, this.items[1].getChildByName("label2").getComponent(Label).fontSize = 22, this.items[2].getChildByName("label2").getComponent(Label).fontSize = 22);
    }
    start() {
        if (super.start(), this.fitScreen(), this.bShowPushAnim ? ToolUtils.showPushAnim(this.node, 0, (() => {
            this.showUICallback && this.showUICallback();
        })) : this.showUICallback && this.showUICallback(), this._curIdx = 0, this.updateSelectStatus(), PushCenter.shared().addListener(GameConfig.Update_Kyc, (() => {
            if (ToolUtils.isObjValid(this.node) && User.shared().data.card_check > 0) {
                if (!(sys.isObjectValid(User.shared().newKycData.collect_list) && User.shared().newKycData.collect_list.length > 0)) {
                    return this.bShowPushAnim = false, void this.onBackView();
                }
                this.refreshShowItems();
            }
        }), this), this.sub_tips.active && (this.sub_tips.getChildByName("wz").getComponent(Label).updateRenderData(true), this.sub_tips.getChildByName("wz").getComponent(UITransform).contentSize.height > 85)) {
            let t = this.sub_tips.getChildByName("wz").getPosition();
            this.sub_tips.getChildByName("wz").setPosition(v3(t.x, t.y - 10));
            let e = this.sub_tips.getComponent(UITransform).contentSize;
            this.sub_tips.getComponent(UITransform).setContentSize(size(e.width, e.height + 30));
            this.items_list.setPosition(v3(0, -65));
            2 == i18nMgr.shared().language && (this.sub_tips.getChildByName("wz").getComponent(Label).fontSize = 20, this.sub_tips.getComponent(UITransform).setContentSize(size(e.width, e.height + 150)), this.sub_tips.getChildByName("wz").setPosition(v3(t.x, t.y - 20)), this.tipsNode.getComponent(Widget).bottom = 140);
        }
    }
    refreshShowItems() {
        this._curIdx = 0;
        this.initShowItems();
        this.updateSelectStatus();
    }
    initShowItems() {
        for (let t = 0; t < 5; t++) {
            ToolUtils.isObjValid(this.items[t]) && (this.items[t].active = false);
        }
        this._selectIdx = [];
        this._showItems = [];
        for (let t = 0; t < User.shared().newKycData.collect_list.length; t++) {
            1 == Number(User.shared().newKycData.collect_list[t].type) ? ToolUtils.isObjValid(this.items[0]) && (this._selectIdx.push(1), this._showItems.push(this.items[0]), this.items[0].active = true) : 2 == Number(User.shared().newKycData.collect_list[t].type) ? ToolUtils.isObjValid(this.items[1]) && (this._selectIdx.push(2), this._showItems.push(this.items[1]), this.items[1].active = true) : 4 == Number(User.shared().newKycData.collect_list[t].type) ? ToolUtils.isObjValid(this.items[2]) && (this._selectIdx.push(4), this._showItems.push(this.items[2]), this.items[2].active = true) : 3 == Number(User.shared().newKycData.collect_list[t].type) && ToolUtils.isObjValid(this.items[3]) && (this._selectIdx.push(3), this._showItems.push(this.items[3]), this.items[3].active = true);
        }
        this._curType = sys.isObjectValid(this._selectIdx[0]) ? this._selectIdx[0] : -1;
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().removeListenersByTag(this);
        this.unscheduleAllCallbacks();
    }
    onCloseButtonClick(t, e) {
        if (SoundManager.shared().playFx("click"), "back_btn" == e) {
            if (this._closed) {
                return;
            }
            this.onBackView();
        }
    }
    onBackView() {
        this.closeUICallBack && this.closeUICallBack();
        this.bShowPushAnim ? (this._closed = true, ToolUtils.showPushAnim(this.node, 1, (() => {
            ToolUtils.isObjValid(this.node) && this.node.destroy();
        }))) : ToolUtils.isObjValid(this.node) && this.node.destroy();
    }
    onButtonClick(t, e) {
        if (SoundManager.shared().playFx("click"), "submit" == e) {
            1 == this._curType || 4 == this._curType && this.dealDigitaLockerVerify();
        }
        else {
            "online" == e ? this._curType = 1 : "upload" == e ? this._curType = 2 : "input" == e ? this._curType = 3 : "digilocker" == e && (this._curType = 4);
            let t = this._selectIdx.indexOf(this._curType);
            t >= 0 && t != this._curIdx && (this._curIdx = t, this.updateSelectStatus());
        }
    }
    dealDigitaLockerVerify() {
        Utils.shared().showLoading(10, true, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3);
        }));
        HttpManager.shared().doGetDialockerUrl(4, ((t, e, i) => {
            if (Utils.shared().hideLoading(), 200 == i) {
                try {
                    let t = ToolUtils.parseJson(e);
                    if (0 == t.ret) {
                        if (ToolUtils.isSafeString(t.data.url).length > 0 && ToolUtils.isObjValid(this.node)) {
                            let e = { url: t.data.url, title: i18nMgr.shared().getValueByKey("kyc.digitalLocker_verify"), key: "kyc.digitalLocker_verify" };
                            Utils.shared().openUrl(e, this.node);
                        }
                    }
                    else {
                        null != t.desc && null != t.desc && Utils.shared().showToast(t.desc, 2, 0, ToolUtils.getIsNormalDirection());
                    }
                }
                catch (t) {
                    TLog.printError("listenGetDialockerUrl err:", t);
                }
            }
        }));
    }
    updateSelectStatus() {
        for (let t = 0, e = 0; t < this._showItems.length; t++) {
            e = this._curIdx === t ? 1 : 0;
            this._showItems[t].getChildByName("select").getComponent(Sprite).spriteFrame = this.selectSpriteFrame[e];
            this._showItems[t].getChildByName("select").getComponent(Sprite).color = 0 == e ? color(200, 200, 200) : color(255, 255, 255);
            this._showItems[t].getChildByName("di").getComponent(Sprite).spriteFrame = this.bgSpriteFrame[e];
        }
    }
    fitScreen() {
        ToolUtils.adaptSafeArea(this.rootNode);
        let t = sys.getSafeAreaRect().y;
        this.bottom_tips.getComponent(Widget).bottom = 120 - t;
        this.submitBtn.getComponent(Widget).bottom = 20 - t;
    }
}
