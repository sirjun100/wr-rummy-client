// @ts-nocheck
// Recovered from index.js:29
import { _decorator, Component, sys, v3, view } from "cc";
import GameConfig from "./GameConfig";
import TweenTool from "./TweenTool";
import PushCenter from "./PushCenter";
import PushEvent from "./PushEvent";
import { ToolUtils } from "./ToolUtils";
const { ccclass } = _decorator;
export let AdapDirection;
(AdapDirection = undefined);
(!function (e) {
    e[e.Left = 0] = "Left";
    e[e.Right = 1] = "Right";
    e[e.Up = 2] = "Up";
    e[e.Down = 3] = "Down";
}(AdapDirection || (AdapDirection = AdapDirection = {})));
@ccclass("BaseLayer")
export default class BaseLayer extends Component {
    public bIsInGame: boolean = false;
    public tid_key: string = "";
    onLoad() {
    }
    start() {
        if (this.bIsInGame) {
            let e = { node: this.node, tid_key: this.tid_key };
            PushCenter.shared().pushEvent(PushEvent.pushGamePopNode, e);
        }
        else {
            PushCenter.shared().pushEvent(PushEvent.pushPopNode, this.node);
        }
        PushCenter.shared().addListener(GameConfig.BackKey_Event, (e => {
            null != e.tid_key ? e.tid_key == this.tid_key && this.node.name == e.nodeName && this.onBackView() : this.node.name == e.nodeName && this.onBackView();
        }), this);
    }
    onDestroy() {
        if (this.bIsInGame) {
            let e = { node: this.node, tid_key: this.tid_key };
            PushCenter.shared().pushEvent(PushEvent.removeGamePopNode, e);
        }
        else {
            PushCenter.shared().pushEvent(PushEvent.removePopNode, this.node);
        }
        PushCenter.shared().removeListenersByTag(this);
        this.unscheduleAllCallbacks();
        TweenTool.stopNodeAction(this.node);
    }
    onBackView() {
        ToolUtils.isObjValid(this.node) && this.node.destroy();
    }
    startShowAnim(e, t) {
        e.setScale(v3(0.2, 0.2, 0.2));
        TweenTool.scaleTo(e, 0.2, v3(1, 1, 1), "backOut", true, (() => {
            e.setScale(v3(1, 1, 1));
            t && t();
        }));
    }
    startShowAnim2(e, t = 1, s) {
        e.setScale(v3(0.2, 0.2, 0.2));
        TweenTool.scaleTo(e, 0.2, v3(t, t, t), "backOut", true, (() => {
            e.setScale(v3(t, t, t));
            s && s();
        }));
    }
    resetUiPos(e, t, s = false, a, d, c) {
        let h = e.position, _ = (GameConfig.REAL_SCREEN_WIDTH - GameConfig.CONFIG_SCREEN_WIDTH) / 2, r = (GameConfig.REAL_SCREEN_HEIGHT - GameConfig.CONFIG_SCREEN_HEIGHT) / 2;
        s && (_ = (GameConfig.REAL_SCREEN_HEIGHT - GameConfig.CONFIG_SCREEN_HEIGHT) / 2, r = 0);
        let l = sys.getSafeAreaRect().y;
        l <= 0 && sys.getSafeAreaRect().x > 0 && (l = sys.getSafeAreaRect().x);
        a || (a = 1);
        let u = _ * a;
        s ? t == AdapDirection.Left ? (d && (u -= l), view.getVisibleSize().width > GameConfig.CONFIG_SCREEN_HEIGHT && e.setPosition(v3(h.x - u, h.y, h.z))) : t == AdapDirection.Right ? (c && (u -= l), view.getVisibleSize().width > GameConfig.CONFIG_SCREEN_HEIGHT && e.setPosition(v3(h.x + u, h.y, h.z))) : t == AdapDirection.Up ? (u = (GameConfig.REAL_SCREEN_WIDTH - GameConfig.CONFIG_SCREEN_WIDTH) / 2, u *= a, e.setPosition(v3(h.x, h.y + u, h.z))) : t == AdapDirection.Down && (u = (GameConfig.REAL_SCREEN_WIDTH - GameConfig.CONFIG_SCREEN_WIDTH) / 2, u *= a, e.setPosition(v3(h.x, h.y - u, h.z))) : (u = r * a, t == AdapDirection.Up ? (d && (u -= l), e.setPosition(v3(h.x, h.y + u, h.z))) : t == AdapDirection.Down && e.setPosition(v3(h.x, h.y - u, h.z)));
    }
    setUiEdgeDistance(e, t, s, o = false) {
        let n = GameConfig.REAL_SCREEN_WIDTH / 2, a = GameConfig.REAL_SCREEN_HEIGHT / 2;
        o && (n = GameConfig.REAL_SCREEN_HEIGHT / 2, a = GameConfig.REAL_SCREEN_WIDTH / 2);
        let d = e.position;
        s == AdapDirection.Left ? e.setPosition(v3(t - n, d.y, d.z)) : s == AdapDirection.Right ? e.setPosition(v3(n - t, d.y, d.z)) : s == AdapDirection.Up ? e.setPosition(v3(d.x, a - t, d.z)) : s == AdapDirection.Down && e.setPosition(v3(d.x, t - a, d.z));
    }
}
