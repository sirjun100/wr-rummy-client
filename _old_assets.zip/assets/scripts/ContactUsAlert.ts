// @ts-nocheck
// Recovered from index.js:79
import { _decorator, Button, Label, Node, size, Sprite, SpriteFrame, sys, UITransform, v3 } from "cc";
import { TransferPlatform } from "./TransferPlatform";
import i18nMgr from "./i18nMgr";
import Utils from "./Utils";
import User from "./User";
import SoundManager from "./SoundManager";
import BaseLayer from "./BaseLayer";
import { ToolUtils } from "./ToolUtils";
import BundleNameDefined from "./BundleNameDefined";
import GameConfig from "./GameConfig";
import HttpManager from "./HttpManager";
import CommDefine from "./CommDefine";
import AppInfo from "./AppInfo";
const { ccclass, property } = _decorator;
@ccclass("ContactUsAlert")
export class ContactUsAlert extends BaseLayer {
    @property(Node)
    public rootNode: Node = null;
    @property(Node)
    public titleNode: Node = null;
    @property(Node)
    public emailNode: Node = null;
    @property(Node)
    public whatsappNode: Node = null;
    @property(Node)
    public tgNode: Node = null;
    @property(Node)
    public feedbackNode: Node = null;
    @property([SpriteFrame])
    public chip_imgs_617: SpriteFrame[] = [];
    public feedbackUrl: any = null;
    private supportOpening: boolean = false;
    private supportButtonText: string = "";
    onLoad() {
        this.emailNode.active = false;
        this.whatsappNode.active = false;
        this.tgNode.active = false;
        let e = this.node.getChildByName("bg");
        ToolUtils.showFullScreen(e);
    }
    fitChipMode() {
        if (0 == GameConfig.CHIPS_MODLE) {
            return;
        }
        let e = 2000617 == GameConfig.CHANNEL_ID;
        e && e && 0 == GameConfig.GAME_HALL_THEME && (this.rootNode.getChildByName("bg").getComponent(Sprite).spriteFrame = this.chip_imgs_617[0]);
    }
    setParaData(e) {
        this.feedbackUrl = e;
    }
    start() {
        super.start();
        let e = ToolUtils.isSafeString(ToolUtils.feedback_data.email), t = ToolUtils.isSafeString(ToolUtils.feedback_data.whatsapp), a = ToolUtils.isSafeString(ToolUtils.feedback_data.tg), i = null, s = 0, o = this.emailNode.getPosition().y;
        if (this.emailNode.active = false, e && e.length > 0 && (i = this.emailNode, s += 1, this.emailNode.active = true, this.emailNode.getChildByName("item_text").getComponent(Label).string = e, this.emailNode.setPosition(v3(0, o)), o -= 100), t && t.length > 0 && 1 == User.shared().s_whatsapp) {
            i = this.whatsappNode;
            s += 1;
            this.whatsappNode.active = true;
            this.whatsappNode.getChildByName("item_text").getComponent(Label).string = t;
            this.whatsappNode.setPosition(v3(0, o));
            o -= 100;
            let e = "contact_us.copy", a = this.whatsappNode.getChildByName("copy_btn").getChildByName("Label");
            !sys.isNative || sys.os !== sys.OS.IOS && sys.os !== sys.OS.OSX ? 1 === TransferPlatform.shared().checkPackageInstalled("com.whatsapp") && (e = "contact_us.copy") : e = "contact_us.copy";
            i18nMgr.shared().changeLocalizedLabelKey(a, e);
        }
        if (a && a.length > 0) {
            i = this.tgNode;
            s += 1;
            this.tgNode.active = true;
            this.tgNode.getChildByName("item_text").getComponent(Label).string = a;
            this.tgNode.setPosition(v3(0, o));
            o -= 100;
            let e = "contact_us.copy", t = this.tgNode.getChildByName("copy_btn").getChildByName("Label");
            !sys.isNative || sys.os !== sys.OS.IOS && sys.os !== sys.OS.OSX ? (1 === TransferPlatform.shared().checkPackageInstalled("org.telegram.messenger") || 1 === TransferPlatform.shared().checkPackageInstalled("org.telegram.messenger.web")) && (e = "contact_us.copy") : e = "contact_us.copy";
            i18nMgr.shared().changeLocalizedLabelKey(t, e);
        }
        const inLoginScene = ToolUtils.judgeIfInScene(BundleNameDefined.login_scene);
        if (this.feedbackUrl = User.shared().data.feedback_url, inLoginScene && (this.feedbackUrl = ToolUtils.loginKeFu_url), ((this.feedbackUrl && this.feedbackUrl.length > 0) || (ToolUtils.support_enabled && Number(ToolUtils.uid) > 0 && !inLoginScene)) ? (s += 1, this.feedbackNode.setPosition(v3(0, o))) : (this.feedbackNode.active = false, ToolUtils.isObjValid(i) && (i.getChildByName("line").active = false)), this.rootNode.getChildByName("bg").getComponent(UITransform).setContentSize(size(610, 94 + 100 * s)), this.feedbackNode.setPosition(v3(0, o)), ToolUtils.getIsNormalDirection() || this.node.setRotationFromEuler(v3(0, 0, 90)), sys.isNative && (sys.os === sys.OS.IOS || sys.os === sys.OS.OSX)) {
            let e = this.emailNode.getChildByName("copy_btn").getChildByName("Label");
            i18nMgr.shared().changeLocalizedLabelKey(e, "contact_us.go");
        }
        this.startShowAnim(this.node.getChildByName("content"));
    }
    onClickByBtn(e, t) {
        if (SoundManager.shared().playFx("click"), "close" != t) {
            if (!sys.isNative || sys.os !== sys.OS.IOS && sys.os !== sys.OS.OSX) {
                if ("email" == t) {
                    this.dealCombineEmailContent();
                }
                else if ("whatsapp" == t) {
                    1 === TransferPlatform.shared().checkPackageInstalled("com.whatsapp") ? Utils.shared().jumpToWhatsApp() : (TransferPlatform.shared().copyContent(ToolUtils.feedback_data.whatsapp), Utils.shared().showToast(i18nMgr.shared().getValueByKey("contact_us.copy_successfully"), 2));
                }
                else if ("tel" == t) {
                    TransferPlatform.shared().copyContent(ToolUtils.feedback_data.tg);
                    Utils.shared().showToast(i18nMgr.shared().getValueByKey("contact_us.copy_successfully"), 2);
                }
                else if ("feedback" == t) {
                    if (ToolUtils.support_enabled && Number(ToolUtils.uid) > 0 && !ToolUtils.judgeIfInScene(BundleNameDefined.login_scene)) {
                        this.openSupport();
                        return;
                    }
                    let e = { url: this.feedbackUrl, title: i18nMgr.shared().getValueByKey("utlis.feedback"), key: "utlis.feedback" };
                    e && e.url && (0 == Number(ToolUtils.feedback_url_type) ? sys.openURL(e.url) : Utils.shared().openUrl(e));
                }
            }
            else if ("email" == t) {
                TransferPlatform.shared().copyContent(ToolUtils.feedback_data.email);
                Utils.shared().showToast(i18nMgr.shared().getValueByKey("contact_us.copy_successfully"), 2, 0, ToolUtils.getIsNormalDirection());
            }
            else if ("whatsapp" == t) {
                TransferPlatform.shared().copyContent(ToolUtils.feedback_data.whatsapp);
                Utils.shared().showToast(i18nMgr.shared().getValueByKey("contact_us.copy_successfully"), 2);
            }
            else if ("tel" == t) {
                TransferPlatform.shared().copyContent(ToolUtils.feedback_data.tg);
                Utils.shared().showToast(i18nMgr.shared().getValueByKey("contact_us.copy_successfully"), 2);
            }
            else if ("feedback" == t) {
                if (ToolUtils.support_enabled && Number(ToolUtils.uid) > 0 && !ToolUtils.judgeIfInScene(BundleNameDefined.login_scene)) {
                    this.openSupport();
                    return;
                }
                let e = { url: this.feedbackUrl, title: i18nMgr.shared().getValueByKey("utlis.feedback"), key: "utlis.feedback" };
                e && e.url && Utils.shared().openUrl(e);
            }
        }
        else {
            if (this.supportOpening) Utils.shared().hideLoading();
            ToolUtils.isObjValid(this.node) && this.node.destroy();
        }
    }
    private openSupport() {
        if (this.supportOpening) return;
        this.supportOpening = true;
        const supportButton = this.feedbackNode.getChildByName("copy_btn");
        const supportLabel = supportButton?.getChildByName("Label")?.getComponent(Label);
        const supportLabelFontSize = supportLabel?.fontSize;
        if (supportLabel) {
            this.supportButtonText = supportLabel.string;
            supportLabel.fontSize = 18;
            supportLabel.string = "OPENING...";
        }
        const button = supportButton?.getComponent(Button);
        if (button) button.interactable = false;
        // Link issuance happens before the native WebView exists. Show feedback
        // from the first tap so this network wait never looks like a dead button.
        Utils.shared().showLoading(12, true);
        HttpManager.shared().httpRequest("SupportLink.getPlayerUrl", "SupportLink.getPlayerUrl", { uid: ToolUtils.uid }, (_request, raw, status) => {
            this.supportOpening = false;
            Utils.shared().hideLoading();
            if (!this.node || !this.node.isValid) return;
            if (supportLabel) {
                supportLabel.string = this.supportButtonText;
                supportLabel.fontSize = supportLabelFontSize;
            }
            if (button) button.interactable = true;
            let url = "";
            if (status === 200) {
                try {
                    const response = ToolUtils.parseJson(raw);
                    if (response.ret === 0 && typeof response.data?.url === "string") url = response.data.url;
                } catch (_) { /* malformed response follows the normal error path */ }
            }
            if (!/^https:\/\//i.test(url)) {
                Utils.shared().showToast("Customer support is temporarily unavailable. Please try again.", 3);
                return;
            }
            const title = i18nMgr.shared().getValueByKey("utlis.feedback");
            if (sys.isNative && sys.os === sys.OS.ANDROID) {
                AppInfo.shared().showSupportWebView(url, title);
            } else {
                Utils.shared().openUrl({ url, title, key: "utlis.feedback" });
            }
        });
    }
    dealCombineEmailContent() {
        let e = ToolUtils.isSafeString(ToolUtils.feedback_data.email), t = "", a = 0 == GameConfig.GAME_APP_THEME ? CommDefine.AppName_rummy : CommDefine.AppName_circ;
        t = 0 == User.shared().data.uid ? ToolUtils.format(i18nMgr.shared().getValueByKey("contact_us.email_theme_nouid"), a) : ToolUtils.format(i18nMgr.shared().getValueByKey("contact_us.email_theme_hasuid"), String(User.shared().data.uid), a);
        let i = "";
        i = 0 == User.shared().data.uid ? i18nMgr.shared().getValueByKey("contact_us.email_body_nouid") : ToolUtils.format(i18nMgr.shared().getValueByKey("contact_us.email_body_hasuid"), String(User.shared().data.uid));
        0 == TransferPlatform.shared().sendEmail(e, t, i) && (TransferPlatform.shared().copyContent(ToolUtils.feedback_data.email), Utils.shared().showToast(i18nMgr.shared().getValueByKey("contact_us.copy_email_tips"), 2, 0, ToolUtils.getIsNormalDirection()));
    }
}
