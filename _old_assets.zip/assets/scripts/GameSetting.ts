// @ts-nocheck
// Recovered from index.js:167
import { _decorator, director, Node, Sprite, SpriteFrame, sys, v3 } from "cc";
import SoundManager from "./SoundManager";
import User from "./User";
import PushCenter from "./PushCenter";
import TweenTool from "./TweenTool";
import BaseLayer from "./BaseLayer";
import BundleNameDefined from "./BundleNameDefined";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("GameSetting")
export default class GameSetting extends BaseLayer {
    @property(Node)
    public rootNode: Node = null;
    @property(Sprite)
    public background_switch: Sprite = null;
    @property(Sprite)
    public sound_switch: Sprite = null;
    @property(Sprite)
    public vibration_switch: Sprite = null;
    @property([SpriteFrame])
    public switchs: SpriteFrame[] = [];
    onLoad() {
        director.getScene().name == BundleNameDefined.rummy_scence && (this.bIsInGame = true);
        let e = sys.localStorage.getItem("auto_sort");
        null != e && null != e && (User.shared().auto_sort = Number(e));
        this.refreshSwitchUI();
    }
    dealMultipleLanguages() {
    }
    showGameSwitchs(e, t = 0, i = false, s = false) {
    }
    onEnable() {
    }
    reflanguage(e) {
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().removeListenersByTag(this);
    }
    refreshAutoSettingChoice(e) {
    }
    fitScreen() {
        ToolUtils.showFullScreen(this.node.getChildByName("bg1"));
    }
    startShowAnim() {
        this.rootNode.setScale(v3(0.2, 0.2, 0.2));
        TweenTool.scaleTo(this.rootNode, 0.2, v3(1, 1, 1), "backOut", true, (() => {
            this.rootNode.setScale(v3(1, 1, 1));
        }));
    }
    start() {
        super.start();
        this.fitScreen();
    }
    onclickByClose(e, t) {
        SoundManager.shared().playFx("click");
        ToolUtils.isObjValid(this.node) && this.node.destroy();
    }
    refreshSwitchUI() {
        let e = SoundManager.shared().bg_enabled;
        this.background_switch.spriteFrame = e ? this.switchs[0] : this.switchs[1];
        let t = SoundManager.shared().fx_enabled;
        this.sound_switch.spriteFrame = t ? this.switchs[0] : this.switchs[1];
        let i = sys.localStorage.getItem("vb_enabled"), s = true;
        sys.isObjectValid(i) && (s = "true" === i);
        this.vibration_switch.spriteFrame = s ? this.switchs[0] : this.switchs[1];
    }
    onClickByBtn(e, t) {
        if (SoundManager.shared().playFx("click"), "background" == t) {
            let e = SoundManager.shared().bg_enabled;
            e = !e;
            SoundManager.shared().setEnabled(e);
            ToolUtils.saveData("bg_enabled", String(e));
            this.refreshSwitchUI();
        }
        else if ("sound" == t) {
            let e = SoundManager.shared().fx_enabled;
            e = !e;
            SoundManager.shared().setFxEnabled(e);
            ToolUtils.saveData("fx_enabled", String(e));
            this.refreshSwitchUI();
        }
        else if ("vibration" == t) {
            let e = sys.localStorage.getItem("vb_enabled"), t = true;
            sys.isObjectValid(e) && (t = "true" === e);
            t = !t;
            ToolUtils.saveData("vb_enabled", String(t));
            this.refreshSwitchUI();
        }
    }
    refreshAutosortSwitch() {
    }
    updateInfo(e) {
        this.refreshSwitchUI();
    }
    setLandscapeShow() {
        ToolUtils.getOrientation() || this.node.setRotationFromEuler(v3(0, 0, -90));
        let e = this.node.getChildByName("bg1");
        ToolUtils.showFullScreen(e);
    }
}
