// @ts-nocheck
// Recovered from index.js:519
import { _decorator, Label, Layout, Node, Sprite, SpriteFrame, sys, tween, Vec3, Widget } from "cc";
import BaseLayer from "./BaseLayer";
import User from "./User";
import SoundManager from "./SoundManager";
import i18nMgr from "./i18nMgr";
import PushEvent from "./PushEvent";
import HttpManager from "./HttpManager";
import { HttpRequest } from "./HttpRequestName";
import { ToolUtils } from "./ToolUtils";
import Utils from "./Utils";
const { ccclass, property } = _decorator;
@ccclass("ShopRetain")
export class ShopRetain extends BaseLayer {
    @property(Node)
    public bgView: Node = null;
    @property([SpriteFrame])
    public bg_imgs: SpriteFrame[] = [];
    public _linkId: number = 0;
    public _nVid: number = 0;
    public _callback: any = null;
    public lastClick: number = 0;
    public _cur_price: number = 0;
    public coupon_id: number = 0;
    onLoad() {
    }
    dealMultipleLanguages() {
        if (2 == i18nMgr.shared().language) {
            new Vec3;
        }
    }
    initParaData(e) {
        sys.isObjectValid(e) && sys.isObjectValid(e.vid) ? this._nVid = e.vid : this._nVid = ToolUtils.curRoomId;
        sys.isObjectValid(e) && sys.isObjectValid(e.callback) && (this._callback = e.callback);
        this.refreshUI();
    }
    requestRetainPopTimes() {
        HttpManager.shared().doGetCommonRequest({ ui_type: 1 }, HttpRequest.StoreRetainPopTimes, ((e, t, i) => {
        }));
    }
    refreshUI() {
        let e = User.shared().retention_pop_info.coupon_info;
        this.coupon_id = e.coupon_id;
        this._cur_price = Number(User.shared().retention_pop_info.price);
        this.bgView.getChildByName("reward").getChildByName("cash_item").active = false;
        this.bgView.getChildByName("reward").getChildByName("bonus_item").active = false;
        let t = Number(User.shared().retention_pop_info.price), i = Number(User.shared().retention_pop_info.price), a = 0;
        if (sys.isObjectValid(User.shared().retention_pop_info.add_bonus) && User.shared().retention_pop_info.add_bonus > 0 && (this.bgView.getChildByName("reward").getChildByName("bonus_item").active = true, this.bgView.getChildByName("reward").getChildByName("bonus_item").getChildByName("wz").getComponent(Label).string = "₹" + String(User.shared().retention_pop_info.add_bonus), a += Number(User.shared().retention_pop_info.add_bonus)), sys.isObjectValid(User.shared().retention_pop_info.add_cash) && (t += Number(User.shared().retention_pop_info.add_cash), this.bgView.getChildByName("reward").getChildByName("cash_item").active = true, this.bgView.getChildByName("reward").getChildByName("cash_item").getChildByName("wz").getComponent(Label).string = "₹" + String(t), a += t), this.bgView.getChildByName("reward").getComponent(Layout).updateLayout(), sys.isObjectValid(User.shared().retention_pop_info.title_type)) {
            let e = Number(User.shared().retention_pop_info.title_type);
            this.bgView.getChildByName("bg").getComponent(Sprite).spriteFrame = 1 == e ? this.bg_imgs[1] : this.bg_imgs[0];
        }
        sys.isObjectValid(User.shared().retention_pop_info.tip) && User.shared().retention_pop_info.tip.length > 0 && (this.bgView.getChildByName("title").getComponent(Label).string = User.shared().retention_pop_info.tip);
        let n = Math.floor(100 * (a - Number(i)) / Number(i));
        this.bgView.getChildByName("flag").getChildByName("zhekou_layout").getChildByName("zhekou").getComponent(Label).string = String(n);
        this.bgView.getChildByName("flag").getChildByName("zhekou_layout").getComponent(Layout).updateLayout();
        this.bgView.getChildByName("add_cash").getChildByName("wz").getComponent(Label).string = "₹" + String(User.shared().retention_pop_info.price);
        this.bgView.getChildByName("add_cash").getChildByName("wz").getComponent(Label).updateRenderData(true);
        this.bgView.getChildByName("add_cash").getChildByName("wz").getChildByName("source_amt").getComponent(Label).string = "₹" + String(a);
        this.bgView.getChildByName("add_cash").getChildByName("wz").getChildByName("source_amt").getComponent(Widget).updateAlignment();
        this.bgView.getChildByName("add_cash").getChildByName("wz").getChildByName("source_amt").getChildByName("line").getComponent(Widget).updateAlignment();
        this.updateCouponItem(e);
    }
    updateCouponItem(e) {
        let t = this.bgView.getChildByName("cur_coupon");
        sys.isObjectValid(e) && (sys.isObjectValid(e.coupon_rate) && (t.getChildByName("flag").getChildByName("wz").getComponent(Label).string = e.coupon_rate), sys.isObjectValid(e.coupon_name) && (t.getChildByName("wz").getComponent(Label).string = `Use: ${e.coupon_name}`), t.getComponent(Layout).updateLayout());
    }
    start() {
        super.start();
        ToolUtils.showFullScreen(this.node.getChildByName("bg"));
        tween(this.bgView).to(0.2, { scale: new Vec3(1.05, 1.05, 1.05) }).to(0.133, { scale: new Vec3(0.98, 0.98, 0.98) }).to(0.1, { scale: new Vec3(1, 1, 1) }).union().call((() => {
        })).start();
        this.lastClick = sys.now();
        this._linkId = this.lastClick;
        this.requestRetainPopTimes();
        this.dealMultipleLanguages();
        SoundManager.shared().playFx("act_popshow");
    }
    onButtonClick(e, t) {
        if (SoundManager.shared().playFx("click"), "close" === t) {
            this.onBackView();
        }
        else if ("addcash" === t) {
            if (!User.shared().checkCanRecharge()) {
                return void (ToolUtils.isObjValid(this.node) && this.node.destroy());
            }
            if (sys.now() - this.lastClick < 1000) {
                return;
            }
            this.lastClick = sys.now();
            let e = { price: this._cur_price, act_id: PushEvent.JUMP_TO_StoreRetain, link_id: this._linkId, coupon_id: this.coupon_id, isShop: 1, goodsId: User.shared().retention_pop_info.good_id, scene: User.shared().payment_scene.scene, vid: User.shared().payment_scene.vid };
            if (User.shared().checkPayment(Number(e.price))) {
                return void Utils.shared().showPaymentGuide(this.node.parent, e, (t => {
                    e.pmode = t;
                    User.shared().startOrder(HttpRequest.CommPay, e, 0);
                    ToolUtils.isObjValid(this.node) && this.node.destroy();
                }));
            }
            User.shared().startPay(e);
            ToolUtils.isObjValid(this.node) && this.node.destroy();
        }
        else if ("exit" === t) {
            this._callback && this._callback();
            ToolUtils.isObjValid(this.node) && this.node.destroy();
        }
        else if ("date_open" == t) {
            let e = this.bgView.getChildByName("cur_coupon"), t = e.getChildByName("date_ez").active;
            e.getChildByName("date_ez").active = !t;
            e.getChildByName("date_open").getChildByName("wz").getComponent(Label).string = t ? "+ MORE" : "- CLOSE";
        }
    }
    onBackView() {
        ToolUtils.isObjValid(this.node) && this.node.destroy();
    }
    onDestroy() {
        super.onDestroy();
        this.unscheduleAllCallbacks();
    }
    update(e) {
    }
}
