// @ts-nocheck
// Recovered from index.js:689
import { _decorator, Button, color, instantiate, Label, Node, Sprite, SpriteFrame, sys, UITransform, view, Widget } from "cc";
import BaseLayer from "./BaseLayer";
import i18nMgr from "./i18nMgr";
import PushCenter from "./PushCenter";
import TableViewUtils from "./TableViewUtils";
import { TLog } from "./TLog";
import { ToolUtils } from "./ToolUtils";
import { TransferPlatform } from "./TransferPlatform";
import TweenTool from "./TweenTool";
import Utils from "./Utils";
import BundleNameDefined from "./BundleNameDefined";
import GameConfig from "./GameConfig";
import { HttpRequest } from "./HttpRequestName";
import PushEvent from "./PushEvent";
import User from "./User";
import HttpManager from "./HttpManager";
import SoundManager from "./SoundManager";
const { ccclass, property } = _decorator;
@ccclass("WithdrawalMain")
export class WithdrawalMain extends BaseLayer {
    @property(Node)
    public rootNode: Node = null;
    @property(Node)
    public depositNode: Node = null;
    @property(Node)
    public recordNode: Node = null;
    @property(Node)
    public nodataIC: Node = null;
    @property(Node)
    public recordMoban: Node = null;
    @property(Node)
    public recordScrollView: Node = null;
    @property(Node)
    public bankInfoNode: Node = null;
    @property(Node)
    public assureNode: Node = null;
    @property([SpriteFrame])
    public assureImags: SpriteFrame[] = [];
    @property([SpriteFrame])
    public his_status_img: SpriteFrame[] = [];
    @property([SpriteFrame])
    public item_imgs: SpriteFrame[] = [];
    @property([Node])
    public itemNodes: Node[] = [];
    @property([Node])
    public tabNodes: Node[] = [];
    @property([SpriteFrame])
    public tabImgs: SpriteFrame[] = [];
    @property(Node)
    public qiPaoNode: Node = null;
    public walletTabView: any = null;
    public last_id: number = 0;
    public _callback: any = null;
    public _curSelectIndex: number = 0;
    public _curTab: number = 0;
    public _has_next_page: number = 0;
    public scollToTop: boolean = true;
    public canRefresh: boolean = true;
    public walletData: any[] = [];
    initData(t = null) {
        this._callback = t;
    }
    onLoad() {
        this.depositNode.active = true;
        this.recordNode.active = false;
        this.adaptScreen();
        this.fitLuckyTheme();
    }
    fitLuckyTheme() {
        0 != GameConfig.NATIVE_GAME_APP_TYPE && (this.rootNode.getChildByName("top_node").getChildByName("top_bg").getComponent(Sprite).color = color(12, 26, 60));
    }
    start() {
        super.start();
        this.addNotify();
        let t = ToolUtils.parse_double(User.shared().data.withdraw, 2, true);
        this.depositNode.getChildByName("balance_amt").getComponent(Label).string = ToolUtils.format("₹${0}", t);
        sys.isObjectValid(User.shared().DepositTransferData) && this.updateWithdrawView();
        this.walletTabView = this.node.addComponent(TableViewUtils);
        let e = this.recordMoban.getComponent(UITransform).height, i = [this.recordMoban];
        this.walletTabView.init([], this.recordScrollView, i, this.initCurMobanCallBack.bind(this), 0, e, this.scrollRefreshCallBack.bind(this));
        this.changeTab(0);
        this.requestDepositTransferPage(true);
    }
    adaptScreen() {
        view.getVisibleSize();
        this.node.getChildByName("root");
        ToolUtils.showFullScreen(this.node.getChildByName("bg"));
        sys.getSafeAreaRect().y > 0 && (this.depositNode.getChildByName("assure_btn").getComponent(Widget).bottom = 54.021 - sys.getSafeAreaRect().y, this.depositNode.getChildByName("assure_btn").getComponent(Widget).updateAlignment(), this.depositNode.getChildByName("bottom_tip").getComponent(Widget).bottom = 15.499 - sys.getSafeAreaRect().y, this.depositNode.getChildByName("bottom_tip").getComponent(Widget).updateAlignment());
    }
    addNotify() {
        PushCenter.shared().addListener(GameConfig.Update_withdraw, (t => {
            if (ToolUtils.isObjValid(this.node)) {
                let e = ToolUtils.parse_double(t, 2, true);
                this.depositNode.getChildByName("balance_amt").getComponent(Label).string = ToolUtils.format("₹${0}", e);
                this.requestDepositTransferPage();
            }
        }), this);
        PushCenter.shared().addListener(PushEvent.WithdrawFail, (t => {
            ToolUtils.isObjValid(this.node) && this.requestDepositTransferPage();
        }), this);
        PushCenter.shared().addListener(PushEvent.RefreshWithdrawAccount, (t => {
            ToolUtils.isObjValid(this.node) && this.requestDepositTransferPage();
        }), this);
        PushCenter.shared().addListener(PushEvent.RefreshWithdrawRecord, (t => {
            ToolUtils.isObjValid(this.node) && 1 == this._curTab && (this.canRefresh = true, this.clearRecordAndReq());
        }), this);
        PushCenter.shared().addListener(PushEvent.WithdrawClose, (t => {
            ToolUtils.isObjValid(this.node) && (this._callback && this._callback(), PushCenter.shared().pushEvent(PushEvent.ShowGameRatingAlert), this.node.destroy());
        }), this);
    }
    initCurMobanCallBack(t, e) {
        ToolUtils.isObjValid(t) && (t.active = true, sys.isObjectValid(e.date_text) && (t.getChildByName("time").getComponent(Label).string = e.date_text), sys.isObjectValid(e.amount) && (t.getChildByName("amt").getComponent(Label).string = "₹" + e.amount), sys.isObjectValid(e.status) && (t.getChildByName("status_node").getChildByName("status_ico").getComponent(Sprite).spriteFrame = this.his_status_img[e.status], 0 == e.status ? (t.getChildByName("status_node").getChildByName("status_wz").getComponent(Label).string = "Pending", t.getChildByName("status_node").getChildByName("status_wz").getComponent(Label).color = color(255, 180, 0)) : 1 == e.status ? (t.getChildByName("status_node").getChildByName("status_wz").getComponent(Label).string = "Success", t.getChildByName("status_node").getChildByName("status_wz").getComponent(Label).color = color(9, 147, 14)) : 2 == e.status && (t.getChildByName("status_node").getChildByName("status_wz").getComponent(Label).string = "Failed", t.getChildByName("status_node").getChildByName("status_wz").getComponent(Label).color = color(182, 0, 0))), t.getChildByName("arrow_btn").getComponent(Button).clickEvents[0].customEventData = ToolUtils.toJsonString(e));
    }
    scrollRefreshCallBack() {
        0 != this._has_next_page && this.canRefresh && (this.requestRecord(), this.scollToTop = false, this.canRefresh = false);
    }
    requestRecord() {
        HttpManager.shared().doGetCommonRequest({ last_id: this.last_id }, "Withdraw.getList", ((t, e, i) => {
            if (this.canRefresh = true, Utils.shared().hideLoading(), 200 != i) {
                ;
            }
            else {
                let t = ToolUtils.parseJson(e);
                if (0 == t.ret) {
                    try {
                        if (ToolUtils.isObjValid(this.node)) {
                            if (sys.isObjectValid(t.data.last_id) && (this.last_id = t.data.last_id), sys.isObjectValid(t.data.has_next_page) && (this._has_next_page = t.data.has_next_page), null == t.data.list && this.walletData.length < 1) {
                                this.walletData = [];
                                this.nodataIC.active = true;
                            }
                            else if (null != t.data.list) {
                                for (let e = 0; e < t.data.list.length; e++) {
                                    this.walletData.push(t.data.list[e]);
                                }
                                this.nodataIC.active = false;
                            }
                            this.walletTabView.reloadData(this.walletData, this.scollToTop);
                        }
                    }
                    catch (t) {
                        TLog.printError("trycatch requestRecord:error:", t);
                    }
                }
                else {
                    ToolUtils.isSafeString(t.desc).length > 0 && Utils.shared().showToast(t.desc, 2);
                }
            }
        }));
    }
    requestDepositTransferPage(t = false) {
        HttpManager.shared().doGetCommonRequest(null, HttpRequest.DepositTransferPage, ((e, i, a) => {
            if (Utils.shared().hideLoading(), 200 != a) {
                t && ToolUtils.isObjValid(this.node) && Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.request_fail"), 6);
            }
            else {
                let e = ToolUtils.parseJson(i);
                if (0 == e.ret) {
                    try {
                        User.shared().DepositTransferData = e.data;
                        ToolUtils.isObjValid(this.node) && (ToolUtils.isSafeString(e.data.notify_msg).length > 0 && Utils.shared().showCommomDialog(ToolUtils.isSafeString(e.data.notify_msg), i18nMgr.shared().getValueByKey("utlis.notice"), (t => {
                        }), false, ToolUtils.getIsNormalDirection()), this.updateWithdrawView());
                    }
                    catch (t) {
                        TLog.printError("trycatch requestWithDrawPage:error:", t);
                    }
                }
                else {
                    ToolUtils.isSafeString(e.desc).length > 0 && t && Utils.shared().showToast(e.desc, 2);
                }
            }
        }));
    }
    restoreScrollviewTop() {
        this.rootNode.setPosition(0, -ToolUtils.getSafeDistance());
    }
    onDestroy() {
        super.onDestroy();
        TransferPlatform.shared().setSoftInputMode(0);
        PushCenter.shared().pushEvent(GameConfig.Update_Wallet);
        PushCenter.shared().removeListenersByTag(this);
        this.unscheduleAllCallbacks();
    }
    updateWithdrawView() {
        0 == this._curTab && (this.depositNode.active = true, this.assureNode.active = true);
        let t = User.shared().DepositTransferData;
        sys.isObjectValid(t.daily_times_limit) && (this.qiPaoNode.getChildByName("times_num").getComponent(Label).string = t.daily_times_limit);
        sys.isObjectValid(t.daily_amount_limit) && (this.qiPaoNode.getChildByName("amt_num").getComponent(Label).string = ToolUtils.parse_double(t.daily_amount_limit, 2, true));
        this.updateTxItemStatus();
    }
    updateTxItemStatus() {
        let t = User.shared().DepositTransferData, e = 6;
        t.list.length < 6 && (e = t.list.length);
        for (let i = 0; i < e; i++) {
            let e = this.itemNodes[i];
            e.info = t.list[i];
            e.active = true;
            e.getChildByName("amt").getComponent(Label).string = "₹" + t.list[i].amount;
            i == this._curSelectIndex ? (e.getChildByName("bg").getComponent(Sprite).spriteFrame = this.item_imgs[1], this.updateBankAndBtnStatus(t.list[i])) : e.getChildByName("bg").getComponent(Sprite).spriteFrame = this.item_imgs[0];
        }
    }
    updateBankAndBtnStatus(t) {
        this.bankInfoNode.getChildByName("get_amt").getComponent(Label).string = "₹" + t.real_amount;
        1 == t.btn_status ? (this.assureNode.getComponent(Sprite).spriteFrame = this.assureImags[1], this.assureNode.getChildByName("wz").getComponent(Label).color = color(255, 255, 255)) : (this.assureNode.getComponent(Sprite).spriteFrame = this.assureImags[0], this.assureNode.getChildByName("wz").getComponent(Label).color = color(255, 255, 255));
        sys.isObjectValid(t.limit_tips) && t.limit_tips.length > 0 ? this.depositNode.getChildByName("main_tip").getComponent(Label).string = t.limit_tips : this.depositNode.getChildByName("main_tip").getComponent(Label).string = "";
    }
    changeTab(t) {
        this._curTab = t;
        0 == t ? (this.tabNodes[0].getChildByName("bg").getComponent(Sprite).spriteFrame = this.tabImgs[1], this.tabNodes[0].getChildByName("btn").getChildByName("ico").getComponent(Sprite).color = color(255, 255, 255), this.tabNodes[0].getChildByName("btn").getChildByName("wz").getComponent(Label).color = color(255, 255, 255), this.tabNodes[1].getChildByName("bg").getComponent(Sprite).spriteFrame = this.tabImgs[0], this.tabNodes[1].getChildByName("btn").getChildByName("ico").getComponent(Sprite).color = color(153, 153, 153), this.tabNodes[1].getChildByName("btn").getChildByName("wz").getComponent(Label).color = color(153, 153, 153), i18nMgr.shared().changeLabelFont(this.tabNodes[0].getChildByName("btn").getChildByName("wz").getComponent(Label), true), i18nMgr.shared().changeLabelFont(this.tabNodes[1].getChildByName("btn").getChildByName("wz").getComponent(Label), false)) : (this.tabNodes[0].getChildByName("bg").getComponent(Sprite).spriteFrame = this.tabImgs[0], this.tabNodes[0].getChildByName("btn").getChildByName("ico").getComponent(Sprite).color = color(153, 153, 153), this.tabNodes[0].getChildByName("btn").getChildByName("wz").getComponent(Label).color = color(153, 153, 153), this.tabNodes[1].getChildByName("bg").getComponent(Sprite).spriteFrame = this.tabImgs[1], this.tabNodes[1].getChildByName("btn").getChildByName("ico").getComponent(Sprite).color = color(255, 255, 255), this.tabNodes[1].getChildByName("btn").getChildByName("wz").getComponent(Label).color = color(255, 255, 255), i18nMgr.shared().changeLabelFont(this.tabNodes[0].getChildByName("btn").getChildByName("wz").getComponent(Label), false), i18nMgr.shared().changeLabelFont(this.tabNodes[1].getChildByName("btn").getChildByName("wz").getComponent(Label), true));
    }
    onRecordClick(t, e) {
        if (SoundManager.shared().playFx("click"), sys.isObjectValid(e) && e.length > 0) {
            let t = ToolUtils.parseJson(e);
            this.showRecordView(t);
        }
    }
    onButtonClick(t, e) {
        if (SoundManager.shared().playFx("click"), "close" === e) {
            this.onBackView();
        }
        else if ("kefu" === e) {
            Utils.shared().showContactUsView();
        }
        else {
            if ("balance_help" === e) {
                let t = this.qiPaoNode.active;
                return t = !t, this.qiPaoNode.active = t, TweenTool.stopNodeAction(this.bankInfoNode), void (t && TweenTool.delayAct(this.bankInfoNode, (() => {
                    this.qiPaoNode.active = false;
                }), 2, true));
            }
            if ("tab0" == e) {
                if (0 == this._curTab) {
                    return;
                }
                this.changeTab(0);
                this.depositNode.active = true;
                this.recordNode.active = false;
            }
            else if ("tab1" == e) {
                if (1 == this._curTab) {
                    return;
                }
                this.changeTab(1);
                this.canRefresh = true;
                this.clearRecordAndReq();
                this.depositNode.active = false;
                this.recordNode.active = true;
            }
            else {
                if ("history" === e) {
                    return void Utils.shared().showWalletRecordView(2, this.node, "DepositTransfer");
                }
                if ("feedback" === e) {
                    return void Utils.shared().showContactUsView();
                }
                if (-1 != e.indexOf("dp_tx_item")) {
                    let t = parseInt(e.split("_item")[1]);
                    if (this._curSelectIndex == t) {
                        return;
                    }
                    this._curSelectIndex = t;
                    this.updateTxItemStatus();
                }
                else {
                    "assure" === e && this.dealAssureLogic();
                }
            }
        }
    }
    clearRecordAndReq() {
        this.walletTabView.reloadData([], true);
        this.last_id = 0;
        this.walletData = [];
        this.requestRecord();
    }
    dealAssureLogic() {
        let t = User.shared().DepositTransferData.list[this._curSelectIndex];
        sys.isObjectValid(t) && (1 == t.btn_status ? this.dealWithdraw() : 2 == t.btn_status ? Utils.shared().showToast("Today's times limit has been reached.", 3, 0, ToolUtils.getIsNormalDirection()) : 3 == t.btn_status && Utils.shared().showToast("Today's amount limit has been reached.", 3, 0, ToolUtils.getIsNormalDirection()));
    }
    dealWithdraw() {
        let t = User.shared().DepositTransferData.list[this._curSelectIndex];
        Utils.shared().showLoading(10, false, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3);
        }));
        HttpManager.shared().doGetCommonRequest({}, "WithdrawAcc.pageV3", ((e, i, a) => {
            if (this.canRefresh = true, Utils.shared().hideLoading(), 200 != a) {
                ;
            }
            else {
                let e = ToolUtils.parseJson(i);
                if (0 == e.ret) {
                    try {
                        ToolUtils.isObjValid(this.node) && (e.data.amount = t.amount, this.showAccountListView(e.data));
                    }
                    catch (t) {
                        TLog.printError("trycatch requestRecord:error:", t);
                    }
                }
                else {
                    ToolUtils.isSafeString(e.desc).length > 0 && Utils.shared().showToast(e.desc, 2);
                }
            }
        }));
    }
    showAccountListView(t) {
        null == this.node.getChildByName("Withdrawal_accountlist") && ToolUtils.loadCommonPrefab(null, BundleNameDefined.bundle_wallet, "prefab/Withdrawal_accountlist", (e => {
            let i = instantiate(e);
            i.name = "Withdrawal_accountlist";
            this.node.addChild(i);
            i.getComponent("Withdrawal_accountlist").initData(t);
        }));
    }
    showRecordView(t) {
        null == this.node.getChildByName("Withdrawal_details") && ToolUtils.loadCommonPrefab(null, BundleNameDefined.bundle_wallet, "prefab/Withdrawal_details", (e => {
            let i = instantiate(e);
            i.name = "Withdrawal_details";
            this.node.addChild(i);
            i.getComponent("Withdrawal_details").initData(t);
        }));
    }
    onBackView() {
        ToolUtils.isObjValid(this.node) && (this._callback && this._callback(), PushCenter.shared().pushEvent(PushEvent.ShowGameRatingAlert), User.shared().jumpFromHall && (PushCenter.shared().pushEvent(PushEvent.HallGet), User.shared().jumpFromHall = false), this.node.destroy());
    }
}
