// @ts-nocheck
// Recovered from index.js:121
import { _decorator, Button, color, EditBox, instantiate, Label, Node, ScrollView, size, Sprite, SpriteFrame, sys, UITransform } from "cc";
import Utils from "./Utils";
import SoundManager from "./SoundManager";
import BaseLayer from "./BaseLayer";
import CommDefine from "./CommDefine";
import i18nMgr from "./i18nMgr";
import HttpManager from "./HttpManager";
import { HttpRequest } from "./HttpRequestName";
import User from "./User";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("FeedbackAlert")
export class FeedbackAlert extends BaseLayer {
    public _TAG: string = "FeedbackAlert";
    @property(Node)
    public rootNode: Node = null;
    @property([SpriteFrame])
    public itemBgImgs: SpriteFrame[] = [];
    @property([SpriteFrame])
    public statusBgImgs: SpriteFrame[] = [];
    @property(Node)
    public mobanNode: Node = null;
    @property(Node)
    public detailNode: Node = null;
    @property(Node)
    public editScrollView: Node = null;
    @property(Node)
    public editBoxNode: Node = null;
    @property(Node)
    public itemRoot: Node = null;
    public _lastClick: number = 0;
    public _curItemIndex: any = -1;
    public _sourceType: number = 1;
    public _groupType: number = 1;
    public _curData: any = null;
    public _itemArr: any[] = [];
    public _account_name: string = "";
    public _password: string = "";
    public _telNo: string = "";
    public _optNo: string = "";
    public _star: number = 0;
    onLoad() {
        let e = this.node.getChildByName("bg");
        ToolUtils.showFullScreen(e);
    }
    setParaData(e) {
        sys.isObjectValid(e) && sys.isObjectValid(e.sourceType) && (this._sourceType = ToolUtils.isSafeNumber(e.sourceType));
        sys.isObjectValid(e) && sys.isObjectValid(e.groupType) && (this._groupType = ToolUtils.isSafeNumber(e.groupType));
        sys.isObjectValid(e) && sys.isObjectValid(e.account_name) && (this._account_name = e.account_name);
        sys.isObjectValid(e) && sys.isObjectValid(e.password) && (this._password = e.password);
        sys.isObjectValid(e) && sys.isObjectValid(e.optNo) && (this._optNo = e.optNo);
        sys.isObjectValid(e) && sys.isObjectValid(e.telNo) && (this._telNo = e.telNo);
        sys.isObjectValid(e) && sys.isObjectValid(e.star) && (this._star = e.star);
    }
    start() {
        super.start();
        this.startShowAnim(this.rootNode);
        this.combineDataGroup();
        this._curItemIndex = -1;
        this.initContent();
        this.updateChooseItemStatus();
    }
    initContent() {
        if (sys.isObjectValid(this._curData)) {
            for (let e = 0; e < this._curData.group.length; e++) {
                let t = instantiate(this.mobanNode);
                t.getChildByName("wz").getComponent(Label).string = this._curData.group[e];
                t.getComponent(Button).clickEvents[0].customEventData = "" + e;
                t.active = true;
                this.itemRoot.addChild(t);
                this._itemArr.push(t);
            }
        }
    }
    combineDataGroup() {
        if (this._sourceType == CommDefine.TawkUser_Feedback_Source.Charge) {
            if (this._groupType == CommDefine.TawkUser_Feedback_Source.Charge_Group.Store) {
                this._curData = { group: [], group_tip: [] };
                for (let e = 1; e <= 4; e++) {
                    this._curData.group.push(i18nMgr.shared().getValueByKey(ToolUtils.format("Tawk_Feedback.charge_1_${0}_main", e)));
                    this._curData.group_tip.push(i18nMgr.shared().getValueByKey(ToolUtils.format("Tawk_Feedback.charge_1_${0}_tip", e)));
                }
            }
            else if (this._groupType == CommDefine.TawkUser_Feedback_Source.Charge_Group.ChargeRecord) {
                this._curData = { group: [], group_tip: [] };
                for (let e = 1; e <= 4; e++) {
                    this._curData.group.push(i18nMgr.shared().getValueByKey(ToolUtils.format("Tawk_Feedback.charge_2_${0}_main", e)));
                    this._curData.group_tip.push(i18nMgr.shared().getValueByKey(ToolUtils.format("Tawk_Feedback.charge_2_${0}_tip", e)));
                }
            }
        }
        else if (this._sourceType == CommDefine.TawkUser_Feedback_Source.Withdraw) {
            if (this._groupType == CommDefine.TawkUser_Feedback_Source.Withdraw_Group.Main) {
                this._curData = { group: [], group_tip: [] };
                for (let e = 1; e <= 6; e++) {
                    this._curData.group.push(i18nMgr.shared().getValueByKey(ToolUtils.format("Tawk_Feedback.withdraw_1_${0}_main", e)));
                    this._curData.group_tip.push(i18nMgr.shared().getValueByKey(ToolUtils.format("Tawk_Feedback.withdraw_1_${0}_tip", e)));
                }
            }
            else if (this._groupType == CommDefine.TawkUser_Feedback_Source.Withdraw_Group.WithdrawRecord) {
                this._curData = { group: [], group_tip: [] };
                for (let e = 1; e <= 5; e++) {
                    this._curData.group.push(i18nMgr.shared().getValueByKey(ToolUtils.format("Tawk_Feedback.withdraw_2_${0}_main", e)));
                    this._curData.group_tip.push(i18nMgr.shared().getValueByKey(ToolUtils.format("Tawk_Feedback.withdraw_2_${0}_tip", e)));
                }
            }
            else if (this._groupType == CommDefine.TawkUser_Feedback_Source.Withdraw_Group.Pan) {
                this._curData = { group: [], group_tip: [] };
                for (let e = 1; e <= 4; e++) {
                    this._curData.group.push(i18nMgr.shared().getValueByKey(ToolUtils.format("Tawk_Feedback.withdraw_3_${0}_main", e)));
                    this._curData.group_tip.push(i18nMgr.shared().getValueByKey(ToolUtils.format("Tawk_Feedback.withdraw_3_${0}_tip", e)));
                }
            }
        }
        else if (this._sourceType == CommDefine.TawkUser_Feedback_Source.Kyc) {
            if (this._groupType == CommDefine.TawkUser_Feedback_Source.Kyc_Group.Verify) {
                this._curData = { group: [], group_tip: [] };
                for (let e = 1; e <= 4; e++) {
                    this._curData.group.push(i18nMgr.shared().getValueByKey(ToolUtils.format("Tawk_Feedback.kyc_1_${0}_main", e)));
                    this._curData.group_tip.push(i18nMgr.shared().getValueByKey(ToolUtils.format("Tawk_Feedback.kyc_1_${0}_tip", e)));
                }
            }
            else if (this._groupType == CommDefine.TawkUser_Feedback_Source.Kyc_Group.Limit) {
                this._curData = { group: [], group_tip: [] };
                for (let e = 1; e <= 2; e++) {
                    this._curData.group.push(i18nMgr.shared().getValueByKey(ToolUtils.format("Tawk_Feedback.kyc_2_${0}_main", e)));
                    this._curData.group_tip.push(i18nMgr.shared().getValueByKey(ToolUtils.format("Tawk_Feedback.kyc_2_${0}_tip", e)));
                }
            }
            else if (this._groupType == CommDefine.TawkUser_Feedback_Source.Kyc_Group.Checking) {
                this._curData = { group: [], group_tip: [] };
                for (let e = 1; e <= 2; e++) {
                    this._curData.group.push(i18nMgr.shared().getValueByKey(ToolUtils.format("Tawk_Feedback.kyc_2_${0}_main", e)));
                    this._curData.group_tip.push(i18nMgr.shared().getValueByKey(ToolUtils.format("Tawk_Feedback.kyc_2_${0}_tip", e)));
                }
            }
        }
        else if (this._sourceType == CommDefine.TawkUser_Feedback_Source.Records) {
            if (this._groupType == CommDefine.TawkUser_Feedback_Source.Records_Group.Wallet_Main) {
                this._curData = { group: [], group_tip: [] };
                for (let e = 1; e <= 3; e++) {
                    this._curData.group.push(i18nMgr.shared().getValueByKey(ToolUtils.format("Tawk_Feedback.record_1_${0}_main", e)));
                    this._curData.group_tip.push(i18nMgr.shared().getValueByKey(ToolUtils.format("Tawk_Feedback.record_1_${0}_tip", e)));
                }
            }
            else if (this._groupType == CommDefine.TawkUser_Feedback_Source.Records_Group.Wallet_Records) {
                this._curData = { group: [], group_tip: [] };
                for (let e = 1; e <= 4; e++) {
                    this._curData.group.push(i18nMgr.shared().getValueByKey(ToolUtils.format("Tawk_Feedback.record_2_${0}_main", e)));
                    this._curData.group_tip.push(i18nMgr.shared().getValueByKey(ToolUtils.format("Tawk_Feedback.record_2_${0}_tip", e)));
                }
            }
            else if (this._groupType == CommDefine.TawkUser_Feedback_Source.Records_Group.Wallet_Bonus_Records) {
                this._curData = { group: [], group_tip: [] };
                for (let e = 1; e <= 3; e++) {
                    this._curData.group.push(i18nMgr.shared().getValueByKey(ToolUtils.format("Tawk_Feedback.record_3_${0}_main", e)));
                    this._curData.group_tip.push(i18nMgr.shared().getValueByKey(ToolUtils.format("Tawk_Feedback.record_3_${0}_tip", e)));
                }
            }
        }
        else if (this._sourceType == CommDefine.TawkUser_Feedback_Source.Login) {
            if (this._groupType == CommDefine.TawkUser_Feedback_Source.Login_Group.Login_Main) {
                this._curData = { group: [], group_tip: [] };
                for (let e = 1; e <= 7; e++) {
                    this._curData.group.push(i18nMgr.shared().getValueByKey(ToolUtils.format("Tawk_Feedback.login_1_${0}_main", e)));
                    this._curData.group_tip.push(i18nMgr.shared().getValueByKey(ToolUtils.format("Tawk_Feedback.login_1_${0}_tip", e)));
                }
            }
        }
        else if (this._sourceType == CommDefine.TawkUser_Feedback_Source.Suggestion) {
            this._curData = { group: [], group_tip: [] };
            for (let e = 1; e <= 6; e++) {
                this._curData.group.push(i18nMgr.shared().getValueByKey(ToolUtils.format("suggestion.question${0}", e)));
                this._curData.group_tip.push("");
            }
            let e = this.rootNode.getChildByName("submit_btn");
            i18nMgr.shared().changeLocalizedLabelKey(e.getChildByName("txt"), "utlis.ok");
            i18nMgr.shared().changeLocalizedLabelKey(this.rootNode.getChildByName("title"), "suggestion.title");
            i18nMgr.shared().changeLocalizedLabelKey(this.rootNode.getChildByName("tip"), "suggestion.tips");
            this.editBoxNode.getComponent(EditBox).placeholder = i18nMgr.shared().getValueByKey("suggestion.edit_placehoder");
        }
    }
    updateChooseItemStatus() {
        for (let e = 0; e < this._itemArr.length; e++) {
            e == this._curItemIndex ? (this._itemArr[e].getChildByName("bg").getComponent(Sprite).spriteFrame = this.itemBgImgs[1], this._itemArr[e].getChildByName("wz").getComponent(Label).color = color(0, 140, 22)) : (this._itemArr[e].getChildByName("bg").getComponent(Sprite).spriteFrame = this.itemBgImgs[0], this._itemArr[e].getChildByName("wz").getComponent(Label).color = color(102, 102, 102));
        }
    }
    onClickItemEvent(e, t) {
        SoundManager.shared().playFx("click");
        let i = Number(t);
        this._curItemIndex = i;
        this.updateChooseItemStatus();
        this.editBoxNode.getComponent(EditBox).blur();
        this.checkUpdateDetailsNode();
        this.updateCardNumberStatus();
    }
    checkUpdateDetailsNode() {
        if (this._sourceType != CommDefine.TawkUser_Feedback_Source.Suggestion) {
            let e = this._curData.group_tip[this._curItemIndex], t = this.editBoxNode.getComponent(EditBox).string;
            if (0 == t.length) {
                this.editBoxNode.getComponent(EditBox).string = e;
            }
            else if (t !== e) {
                for (let i = 0; i < this._curData.group_tip.length; i++) {
                    if (t === this._curData.group_tip[i]) {
                        this.editBoxNode.getComponent(EditBox).string = e;
                        break;
                    }
                }
            }
        }
        this.updateEditScrollSize(false);
    }
    onBackView() {
        if (ToolUtils.isObjValid(this.node)) {
            if (this._sourceType == CommDefine.TawkUser_Feedback_Source.Suggestion) {
                let e = { star: this._star, skip_type: 2 };
                User.shared().requestGameRatingSubmitData(e);
            }
            this.node.destroy();
        }
    }
    onClickByBtn(e, t) {
        if (SoundManager.shared().playFx("click"), "close" != t) {
            if ("submit" == t) {
                if (sys.now() - this._lastClick < 500) {
                    return;
                }
                this._lastClick = sys.now();
                this.dealSubmitLogic();
            }
            else if ("clear" == t) {
                if (sys.now() - this._lastClick < 500) {
                    return;
                }
                this._lastClick = sys.now();
                this.editBoxNode.getComponent(EditBox).string = "";
                this.editBoxNode.getComponent(EditBox).focus();
            }
        }
        else {
            this.onBackView();
        }
    }
    dealSubmitLogic() {
        let e = this.editBoxNode.getComponent(EditBox).string;
        if (this._sourceType == CommDefine.TawkUser_Feedback_Source.Suggestion) {
            if (-1 == this._curItemIndex && 0 == e.length) {
                return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("suggestion.toast2"), 3, 0, ToolUtils.getIsNormalDirection());
            }
            Utils.shared().showLoading(10, false, (() => {
                Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3);
            }));
            let t = { star: this._star, skip_type: 2, suggestion_type: this._curItemIndex + 1, details: e };
            return void User.shared().requestGameRatingSubmitData(t, (() => {
                ToolUtils.isObjValid(this.node) && this.node.destroy();
            }));
        }
        if (-1 == this._curItemIndex && 0 == e.length) {
            return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("Tawk_Feedback.tip"), 3, 0, ToolUtils.getIsNormalDirection());
        }
        Utils.shared().showLoading(10, false, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3);
        }));
        let t = { type: this._groupType, sub_type: this._curItemIndex + 1, details: e }, i = HttpRequest.TwakFeedBackSubmit;
        this._groupType == CommDefine.TawkUser_Feedback_Source.Login_Group.Login_Main && (i = HttpRequest.TwakFeedBackSubmit_Login, this._telNo.length > 0 ? (t.telNo = this._telNo, t.optNo = this._optNo) : (t.accout_name = this._account_name, t.password = this._password));
        HttpManager.shared().doGetCommonRequest(t, i, this.listenSubmitCallback.bind(this));
    }
    listenSubmitCallback(e, t, i) {
        if (Utils.shared().hideLoading(), 0 != t.length) {
            if (200 != i) {
                alert("The login timed out, please try again");
            }
            else {
                let e = ToolUtils.parseJson(t);
                if (0 == e.ret) {
                    if (sys.isObjectValid(e.data) && sys.isObjectValid(e.data.url) && e.data.url.length > 0) {
                        let t = { url: e.data.url, title: i18nMgr.shared().getValueByKey("utlis.feedback") };
                        Utils.shared().openUrl(t);
                        ToolUtils.isObjValid(this.node) && this.node.destroy();
                    }
                }
                else {
                    ToolUtils.isSafeString(e.desc).length > 0 && Utils.shared().showToast(e.desc, 2, 0, ToolUtils.getIsNormalDirection());
                }
            }
        }
    }
    onEditBoxChanged(e, t, i) {
        this.updateCardNumberStatus();
    }
    onEditBoxEnded(e, t) {
        this.updateCardNumberStatus();
    }
    updateCardNumberStatus() {
        if (this.detailNode) {
            ToolUtils.isSafeString(this.editBoxNode.getComponent(EditBox).string).length > 0 ? (this.detailNode.getChildByName("del_btn").active = true, this.updateEditScrollSize(false)) : (this.detailNode.getChildByName("del_btn").active = false, this.updateEditScrollSize(true));
        }
    }
    updateEditScrollSize(e) {
        if (e) {
            this.editScrollView.getComponent(ScrollView).content.getComponent(UITransform).contentSize = size(590, 152);
            this.editBoxNode.getComponent(UITransform).contentSize = size(530, 152);
        }
        else {
            let e = this.editBoxNode.getChildByName("TEXT_LABEL").getComponent(UITransform).contentSize.height;
            e < 152 ? (this.editBoxNode.getComponent(UITransform).contentSize = size(530, 152), this.editScrollView.getComponent(ScrollView).content.getComponent(UITransform).contentSize = size(590, 152)) : (this.editBoxNode.getComponent(UITransform).contentSize = size(530, e), this.editScrollView.getComponent(ScrollView).content.getComponent(UITransform).contentSize = size(590, e));
        }
    }
}
