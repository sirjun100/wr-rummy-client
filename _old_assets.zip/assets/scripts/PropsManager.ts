// @ts-nocheck
// Recovered from index.js:351
import { _decorator, Button, EditBox, instantiate, Node, size, Size, Sprite, SpriteAtlas, SpriteFrame, sys, UITransform, v3 } from "cc";
import PushCenter from "./PushCenter";
import { TLog } from "./TLog";
import PushEvent from "./PushEvent";
import User from "./User";
import SoundManager from "./SoundManager";
import BaseLayer from "./BaseLayer";
import Utils from "./Utils";
import TweenTool from "./TweenTool";
import HttpManager from "./HttpManager";
import { HttpRequest } from "./HttpRequestName";
import GameConfig from "./GameConfig";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("PropsManager")
export class PropsManager extends BaseLayer {
    @property(Node)
    public rootNode: Node = null;
    @property(Node)
    public avatarMoban: Node = null;
    @property(Node)
    public userNameNode: Node = null;
    @property(Node)
    public avatarRoot: Node = null;
    @property(SpriteAtlas)
    public avatarAtlas: SpriteAtlas = null;
    @property(Node)
    public save_btnNode: Node = null;
    @property([SpriteFrame])
    public buttonImages: SpriteFrame[] = [];
    public selectAvatarIndex: any = -1;
    public usingAvatarIndex: any = -1;
    public avatarItemNodes: any[] = [];
    public props: any[] = [2];
    public propMaps: Map = new Map;
    public click_time: number = 0;
    public isSaveRefresh: boolean = false;
    public last_prop_values: any[] = [-1];
    public _ui_type: number = 0;
    public _callback: any = null;
    public select_sub_tab: number = 0;
    public select_prop: number = 0;
    public avatarList: any[] = [];
    public space_time: number = 0;
    public page_time: number = 0;
    public avatarIconMap: Map = new Map;
    setGameMode(t) {
    }
    initParaData(t, e = null) {
        sys.isObjectValid(t) && sys.isObjectValid(t.ui_type) && (this._ui_type = t.ui_type);
        sys.isObjectValid(e) && (this._callback = e);
    }
    start() {
        super.start();
        ToolUtils.showFullScreen(this.node.getChildByName("bg"));
        this.userNameNode.getComponent(EditBox).string = User.shared().data.name;
        this.fitScreen();
        PushCenter.shared().addListener(PushEvent.RefreshGameDisplayPage, (t => {
            if (ToolUtils.isObjValid(this.node)) {
                if (sys.now() - this.page_time <= 1000) {
                    return;
                }
                this.page_time = sys.now();
                User.shared().requestGameDisplayPage((() => {
                    ToolUtils.isObjValid(this.node) && (this.isSaveRefresh = false, this.refreshUI(true), this.refreshSaveBtnState());
                }));
            }
        }), this);
        this.refreshUI(true);
        User.shared().requestGameDisplayPage((() => {
            this.refreshUI(true);
        }));
        this.startShowAnim();
    }
    fitScreen() {
    }
    startShowAnim() {
        let t = this.node.getChildByName("bg").getComponent(UITransform).contentSize, e = v3(0, -t.height / 2);
        this.rootNode.setPosition(v3(0, -1820, 0));
        TweenTool.moveTo(this.rootNode, 0.15, e, "fade", true, (() => {
            this.rootNode.setPosition(e);
        }));
    }
    refreshSaveBtnState() {
        let t = false, e = false;
        for (let t = 0; t < this.props.length; t++) {
            3 == this.props[t] && (e = true);
        }
        t = e;
        this.userNameNode.getComponent(EditBox).string != User.shared().data.name && (t = true);
        this.setSaveBtnEnale(t);
    }
    setSaveBtnEnale(t) {
        let e = this.save_btnNode.getChildByName("Label"), a = this.save_btnNode.getChildByName("Label2");
        t ? (this.save_btnNode.getComponent(Button).interactable = true, this.save_btnNode.getComponent(Sprite).spriteFrame = this.buttonImages[0], this.save_btnNode.getComponent(UITransform).setContentSize(new Size(660, 79)), e.active = false, a.active = true) : (this.save_btnNode.getComponent(Button).interactable = true, this.save_btnNode.getComponent(Sprite).spriteFrame = this.buttonImages[1], this.save_btnNode.getComponent(UITransform).setContentSize(new Size(666, 79)), e.active = true, a.active = false);
    }
    onEditBoxEnded(t, e) {
        this.refreshSaveBtnState();
    }
    onEditBoxChanged(t, e) {
        this.refreshSaveBtnState();
    }
    refreshUI(t = false) {
        if (sys.isObjectValid(User.shared().gameDisplayPageData)) {
            let e = User.shared().gameDisplayPageData.list;
            if (t && Array.isArray(e)) {
                sys.isObjectValid(User.shared().gameDisplayPageData.table_red_dot) && User.shared().table_red_dot != User.shared().gameDisplayPageData.table_red_dot && (User.shared().table_red_dot = User.shared().gameDisplayPageData.table_red_dot, PushCenter.shared().pushEvent(PushEvent.ChangeTableRedDot, User.shared().table_red_dot));
                for (let t = 0; t < e.length; t++) {
                    const a = e[t];
                    if (sys.isObjectValid(a) && sys.isObjectValid(a.sub_tab) && 1 == Number(a.sub_tab)) {
                        this.avatarList = a.sub_list;
                        let t = [], e = [];
                        if (Array.isArray(this.avatarList)) {
                            for (let a = 0, s = this.avatarList.length; a < s; a++) {
                                if (sys.isObjectValid(this.avatarList[a]) && sys.isObjectValid(this.avatarList[a].is_dynamics) && 1 == this.avatarList[a].is_dynamics ? t.push(this.avatarList[a]) : e.push(this.avatarList[a]), 2 == Number(this.avatarList[a].type)) {
                                    let t = "head_" + this.avatarList[a].prop + ".png";
                                    User.shared().data.avatar != t && (User.shared().data.avatar = t, PushCenter.shared().pushEvent(GameConfig.Change_Head));
                                }
                            }
                        }
                        this.avatarList = [];
                        for (let e = 0; e < t.length; e++) {
                            this.avatarList.push(t[e]);
                        }
                        for (let t = 0; t < e.length; t++) {
                            this.avatarList.push(e[t]);
                        }
                    }
                }
                for (let t = 0; t < this.avatarList.length; t++) {
                    sys.isObjectValid(this.avatarList[t].type) && (2 == Number(this.avatarList[t].type) && (this.usingAvatarIndex = t, this.isSaveRefresh || (this.selectAvatarIndex = t, this.last_prop_values[0] = Number(this.avatarList[t].prop))), this.isSaveRefresh && -1 != this.last_prop_values[0] && this.last_prop_values[0] == Number(this.avatarList[t].prop) && (this.selectAvatarIndex = t));
                }
            }
            this.showAvatars();
            this.refreshAvatarChoose();
        }
        this.refreshSaveBtnState();
    }
    showAvatars() {
        this.avatarMoban.active = false;
        this.avatarItemNodes = [];
        this.avatarIconMap.clear();
        let t = [], e = [];
        if (Array.isArray(this.avatarList)) {
            for (let a = 0, s = this.avatarList.length; a < s; a++) {
                sys.isObjectValid(this.avatarList[a]) && sys.isObjectValid(this.avatarList[a].is_dynamics) && 1 == this.avatarList[a].is_dynamics ? t.push(this.avatarList[a]) : e.push(this.avatarList[a]);
            }
        }
        let a = t.length;
        a > 2 && (a = 2);
        let s = e.length;
        s > 16 && (s = 16);
        this.avatarList = [];
        for (let e = 0; e < a; e++) {
            this.avatarList.push(t[e]);
        }
        for (let t = 0; t < s; t++) {
            this.avatarList.push(e[t]);
        }
        this.avatarRoot.removeAllChildren();
        let i, r = this.avatarList.length;
        for (let t = 0; t < r; t++) {
            i = ToolUtils.isObjValid(this.avatarItemNodes[t]) ? this.avatarItemNodes[t] : instantiate(this.avatarMoban);
            i.active = true;
            let e = this.avatarList[t];
            sys.isObjectValid(e) && sys.isObjectValid(e.is_dynamics) && e.is_dynamics;
            this.avatarRoot.addChild(i);
            i.getComponent(Button).clickEvents[0].customEventData = String(t);
            this.refreshToolItem(i, 1, t, e);
            this.avatarItemNodes[t] = i;
        }
        if (this.selectAvatarIndex >= 0 && this.avatarList.length > this.selectAvatarIndex) {
            let t = Number(this.avatarList[this.selectAvatarIndex].type);
            this.props[0] = t;
        }
    }
    refreshToolItem(t, e, a, s) {
        let i = t.getChildByName("image"), r = t.getChildByName("using");
        if (r.active = false, i.active = true, sys.isObjectValid(s) && sys.isObjectValid(s.prop) && 1 == e) {
            if (sys.isObjectValid(s.avatar_url) && s.avatar_url.length > 0) {
                i.active = false;
                sys.isObjectValid(t.getChildByName("head_mask")) && (t.getChildByName("head_mask").active = true, this.avatarIconMap.set(t.getChildByName("head_mask").getChildByName("head_img"), s.avatar_url), ToolUtils.judgeIfInHall() ? Utils.shared().updateNetImage(t.getChildByName("head_mask").getChildByName("head_img"), s.avatar_url, size(210, 210), (() => {
                })) : Utils.shared().updateNetImage(t.getChildByName("head_mask").getChildByName("head_img"), s.avatar_url, size(86.4, 86.4), (() => {
                })));
            }
            else {
                let e = "head_" + s.prop;
                Utils.shared().setImage(t.getChildByName("head_mask").getChildByName("head_img"), e, this.avatarAtlas);
            }
        }
        sys.isObjectValid(s.type) && (2 == Number(s.type) ? (1 == e && (this.usingAvatarIndex = a), r.active = true) : r.active = false);
    }
    refreshAvatarChoose() {
        for (let t = 0; t < this.avatarItemNodes.length; t++) {
            let e = this.avatarItemNodes[t].getChildByName("using");
            e.active = this.usingAvatarIndex == t;
            e.active = this.selectAvatarIndex == t;
        }
    }
    avatarChooseClick(t, e) {
        if (this.selectAvatarIndex != Number(e) && (SoundManager.shared().playFx("click"), this.selectAvatarIndex = Number(e), this.refreshAvatarChoose(), Array.isArray(this.avatarList) && this.avatarList.length > this.selectAvatarIndex)) {
            let t = Number(this.avatarList[this.selectAvatarIndex].type);
            this.props[0] = t;
            this.refreshSaveBtnState();
        }
    }
    onDestroy() {
        PushCenter.shared().removeListenersByTag(this);
        this.unscheduleAllCallbacks();
    }
    onSaveClick(t, e) {
        SoundManager.shared().playFx("click");
        sys.now() - this.click_time <= 1000 || (this.click_time = sys.now(), this.save_btnNode.getComponent(Button).interactable = false, this.requestGameDisplayModify());
    }
    requestGameDisplayModify() {
        let t = {}, e = false;
        this.selectAvatarIndex >= 0 && 3 == this.props[0] && this.avatarList.length > this.selectAvatarIndex && (t.sub_tab_1 = Number(this.avatarList[this.selectAvatarIndex].prop), e = true);
        let a = this.userNameNode.getComponent(EditBox).string;
        a != User.shared().data.name && (e = true, t.name = a);
        e ? (Utils.shared().showLoading(10, false), HttpManager.shared().doGetCommonRequest(t, HttpRequest.GameDisPlayModify, ((t, e, s) => {
            if (Utils.shared().hideLoading(), 200 != s) {
                ToolUtils.isObjValid(this.node) && this.refreshSaveBtnState();
            }
            else {
                try {
                    let t = ToolUtils.parseJson(e);
                    if (0 == t.ret) {
                        if (sys.isObjectValid(t.data)) {
                            if (ToolUtils.isObjValid(this.node)) {
                                let e = false;
                                sys.isObjectValid(t.data.sub_tab_1) && (e = true, this.props[0] = 2, this.usingAvatarIndex = this.selectAvatarIndex, User.shared().data.avatar = "head_" + t.data.sub_tab_1 + ".png", sys.isObjectValid(t.data.avatar_url) && ToolUtils.isSafeString(t.data.avatar_url).length > 0 && (User.shared().data.avatar_url = t.data.avatar_url), this.last_prop_values[0] = Number(t.data.sub_tab_1));
                                sys.isObjectValid(t.data.name) ? User.shared().data.name = t.data.name : User.shared().data.name = a;
                                PushCenter.shared().pushEvent(GameConfig.Change_Head);
                                e && 1 == this._ui_type && PushCenter.shared().pushEvent(PushEvent.NotifyGameDisplayModify);
                                Utils.shared().showToast("Change successful", 3);
                            }
                            this.onBackView();
                        }
                    }
                    else {
                        null != t.desc && null != t.desc && Utils.shared().showToast(t.desc, 2, 0, ToolUtils.getIsNormalDirection());
                        User.shared().requestGameDisplayPage((() => {
                            ToolUtils.isObjValid(this.node) && (this.isSaveRefresh = true, this.refreshUI(true));
                        }));
                    }
                }
                catch (t) {
                    TLog.printError("requestGameDisplayModify err:", t.toString());
                }
            }
        }))) : this.refreshSaveBtnState();
    }
    onCloseClick(t, e) {
        SoundManager.shared().playFx("click");
        this.onBackView();
    }
    onBackView() {
        ToolUtils.isObjValid(this.node) && (this._callback && this._callback(), this.node.destroy());
    }
    update(t) {
    }
}
