// @ts-nocheck
// Recovered from index.js:5
import "./en";
import "./hi";
import "./ta";
import "./ur";
