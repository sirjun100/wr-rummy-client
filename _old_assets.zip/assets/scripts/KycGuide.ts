// @ts-nocheck
// Recovered from index.js:211
import { _decorator, Button, color, EditBox, Label, LabelShadow, Node, Sprite, SpriteFrame, sys, v3 } from "cc";
import SoundManager from "./SoundManager";
import Utils from "./Utils";
import BaseLayer from "./BaseLayer";
import User from "./User";
import HttpManager from "./HttpManager";
import i18nMgr from "./i18nMgr";
import PushCenter from "./PushCenter";
import PushEvent from "./PushEvent";
import { TransferPlatform } from "./TransferPlatform";
import TweenTool from "./TweenTool";
import ReportConfig from "./ReportConfig";
import GameConfig from "./GameConfig";
import CommDefine, { CheckModule } from "./CommDefine";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("KycGuide")
export class KycGuide extends BaseLayer {
    @property(Node)
    public rootNode: Node = null;
    @property(Node)
    public verifyNode: Node = null;
    @property(Node)
    public waitNode: Node = null;
    @property(Node)
    public secTipsLabel: Node = null;
    @property(Node)
    public cardNumberNode: Node = null;
    @property(Node)
    public errTipNode: Node = null;
    @property(Node)
    public buttomNode: Node = null;
    @property(Node)
    public verify_btn: Node = null;
    @property([SpriteFrame])
    public verifyBtnDiImags: SpriteFrame[] = [];
    public cardNumberStr: string = "";
    public isNext: boolean = false;
    public from_source: number = 0;
    public _closed: boolean = false;
    public _mIdTime: number = 0;
    public _identitytimeAction: any = null;
    public _countDownAction: any = null;
    public _keyboardHei: number = 740;
    public _lastClick: number = 0;
    public is_permit: boolean = false;
    initParaData(e) {
        sys.isObjectValid(e) && (sys.isObjectValid(e.isNext) && (this.isNext = e.isNext), sys.isObjectValid(e.from_source) && (this.from_source = e.from_source), sys.isObjectValid(e.is_permit) && (this.is_permit = e.is_permit));
    }
    onLoad() {
        let e = this.node.getChildByName("mask");
        ToolUtils.showFullScreen(e);
        this.updateCheckStatus();
        this.dealMultipleLanguages();
    }
    dealMultipleLanguages() {
        2 == i18nMgr.shared().language && (this.verifyNode.getChildByName("enter_number").getComponent(Label).fontSize = 22, this.verifyNode.getChildByName("sec_tip_wz").getComponent(Label).fontSize = 14);
    }
    start() {
        super.start();
        TransferPlatform.shared().setSoftInputMode(1);
        this.startShowAnim(this.rootNode);
        this.updateVerifyView(true);
        this.updateCardNumberStatus();
        PushCenter.shared().addListener(GameConfig.Update_Kyc, (() => {
            if (ToolUtils.isObjValid(this.node)) {
                if (this.stopCountDownActin(), 1 == User.shared().data.card_check ? this.updateCheckStatus(false) : this.updateCheckStatus(true), this.updateVerifyView(), this.restoreScrollviewTop(), this.updateRewardList(), 2 == User.shared().data.card_check || 3 == User.shared().data.card_check) {
                    if (3 == User.shared().data.card_check && (this.updateCardNumberView("", true, false), this.updateCardNumberStatus()), Utils.shared().hideLoading(), 2 == User.shared().data.card_check) {
                        if (1 === User.shared().data.kyc_otp_pop) {
                            if (0 == User.shared().data.kyc_otp_check || 3 == User.shared().data.kyc_otp_check) {
                                ;
                            }
                            else if (1 == User.shared().data.kyc_otp_check) {
                                return void this.updateCheckStatus(true);
                            }
                        }
                        this.onBackView();
                    }
                    else {
                        this.showVerifyBtnStatus(1);
                        sys.isObjectValid(User.shared().newKycData.kyc_list.trigger_age_pop) && 1 == Number(User.shared().newKycData.kyc_list.trigger_age_pop) && (Utils.shared().doJumpLogic(PushEvent.Custom_TO_KycAgeTip), this.onBackView());
                    }
                }
                else {
                    1 != User.shared().data.card_check && this.showVerifyBtnStatus(1);
                }
            }
        }), this);
        PushCenter.shared().addListener(PushEvent.changeWebViewHeight, (e => {
            ToolUtils.isObjValid(this.node) && (this._keyboardHei = ToolUtils.isSafeNumber(Number(e)), this.showScrollivewUp(this.cardNumberNode.getChildByName("EditBox")));
        }), this);
        PushCenter.shared().addListener(PushEvent.RefreshKycGuideTips, (e => {
            ToolUtils.isObjValid(this.node);
        }), this);
        this.updateRewardList();
    }
    updateRewardList() {
        let e = User.shared().data.kyc_list;
        if (sys.isObjectValid(e) && Array.isArray(e) && e.length > 0) {
            for (let t = 0; t < e.length; t++) {
                if (2 == ToolUtils.isSafeNumber(e[t].type)) {
                    let i = 0, a = 0;
                    if (sys.isObjectValid(e[t].cash) && (i = Number(e[t].cash)), sys.isObjectValid(e[t].bonus) && (a = Number(e[t].bonus)), i > 0 && a > 0) {
                        let e = ToolUtils.format(i18nMgr.shared().getValueByKey("kyc.kyc_top_tip"), "₹" + String(i + a) + "*");
                        this.rootNode.getChildByName("top_tip").getComponent(Label).string = e;
                    }
                    else if (i > 0) {
                        let e = ToolUtils.format(i18nMgr.shared().getValueByKey("kyc.kyc_top_tip"), "CASH ₹" + String(i));
                        this.rootNode.getChildByName("top_tip").getComponent(Label).string = e;
                    }
                    else if (a > 0) {
                        let e = ToolUtils.format(i18nMgr.shared().getValueByKey("kyc.kyc_top_tip"), "BONUS ₹" + String(a));
                        this.rootNode.getChildByName("top_tip").getComponent(Label).string = e;
                    }
                    else {
                        this.rootNode.getChildByName("top_tip").getComponent(Label).string = i18nMgr.shared().getValueByKey("kyc.kyc_top_tip1") || "";
                    }
                    break;
                }
            }
        }
    }
    onDestroy() {
        super.onDestroy();
        TransferPlatform.shared().setSoftInputMode(0);
        TweenTool.stopNodeAction(this.rootNode);
        TweenTool.stopNodeAction(this.node);
        Utils.shared().hideLoading();
        PushCenter.shared().removeListenersByTag(this);
    }
    updateCheckStatus(e = true) {
        e && (0 == User.shared().data.card_check || 3 == User.shared().data.card_check ? (this.verifyNode.active = true, this.waitNode.active = false) : 1 == User.shared().data.card_check && (this.waitNode.active = true, this.verifyNode.active = false), 1 === User.shared().data.kyc_otp_pop && 1 == User.shared().data.kyc_otp_check && (this.waitNode.active = true, this.verifyNode.active = false));
    }
    updateErrTips() {
        sys.isObjectValid(User.shared().newKycData.kyc_list) && ToolUtils.isSafeString(User.shared().newKycData.kyc_list.fast_reason).length > 0 ? (this.errTipNode.active = true, this.errTipNode.getChildByName("tx").getComponent(Label).string = User.shared().newKycData.kyc_list.fast_reason, this.errTipNode.getChildByName("tx").getComponent(Label).updateRenderData(true), ToolUtils.judgeIfInHall() ? (this.cardNumberNode.setPosition(v3(0, -19.268)), this.verifyNode.getChildByName("enter_number").setPosition(v3(-280.603, -24.395)), this.verifyNode.getChildByName("Layout").setPosition(v3(198.988, -28.03)), this.verifyNode.getChildByName("sec_tip_bg").setPosition(v3(279.88, -31.614))) : (this.cardNumberNode.setPosition(v3(230.621, 95.871)), this.verifyNode.getChildByName("enter_number").setPosition(v3(-30.932, 98.526)), this.verifyNode.getChildByName("Layout").setPosition(v3(347.751, 90.162)), this.verifyNode.getChildByName("sec_tip_bg").setPosition(v3(347.751, 88.661)))) : (this.errTipNode.active = false, this.errTipNode.getChildByName("tx").getComponent(Label).string = "", ToolUtils.judgeIfInHall() ? (this.cardNumberNode.setPosition(v3(0, -54.156)), this.verifyNode.getChildByName("enter_number").setPosition(v3(-280.603, -59.283)), this.verifyNode.getChildByName("Layout").setPosition(v3(198.988, -62.918)), this.verifyNode.getChildByName("sec_tip_bg").setPosition(v3(279.88, -66.502))) : (this.cardNumberNode.setPosition(v3(230.621, 75.871)), this.verifyNode.getChildByName("enter_number").setPosition(v3(-30.932, 78.526)), this.verifyNode.getChildByName("Layout").setPosition(v3(347.751, 70.162)), this.verifyNode.getChildByName("sec_tip_bg").setPosition(v3(347.751, 68.661))));
    }
    updateCardNumberView(e = "", t, i = true) {
        i && (this.cardNumberStr = e, this.cardNumberNode.getChildByName("del_btn").active = false);
        this.cardNumberNode.getChildByName("EditBox").getComponent(EditBox).string = this.cardNumberStr;
        this.cardNumberNode.getChildByName("content").getComponent(Label).string = this.cardNumberStr;
        this.cardNumberNode.getChildByName("EditBox").active = t;
        this.cardNumberNode.getChildByName("content").active = !t;
        this.cardNumberNode.getChildByName("EditBox").getComponent(EditBox).inputMode = EditBox.InputMode.NUMERIC;
        this.cardNumberNode.getChildByName("EditBox").getComponent(EditBox).maxLength = 12;
        i18nMgr.shared().changeLabelLanguage(this.cardNumberNode.getChildByName("EditBox").getComponent(EditBox).placeholderLabel, "Enter aadhaar No.");
    }
    updateCardNumberStatus() {
        if (this.cardNumberNode) {
            let e = this.cardNumberNode.getChildByName("EditBox");
            this.cardNumberStr = ToolUtils.isSafeString(e.getComponent(EditBox).string);
            this.cardNumberStr.length > 0 && (0 == User.shared().data.card_check || 3 == User.shared().data.card_check) ? this.cardNumberNode.getChildByName("del_btn").active = true : this.cardNumberNode.getChildByName("del_btn").active = false;
            12 == this.cardNumberStr.length ? this.showVerifyBtnStatus(1) : this.showVerifyBtnStatus(0);
        }
    }
    onEditDidBegan(e, t) {
    }
    onEditBoxChanged(e, t, i) {
        "card_number" == i && this.updateCardNumberStatus();
    }
    onEditBoxEnded(e, t) {
        "card_number" == t && (this.updateCardNumberStatus(), e.string.length);
    }
    showScrollivewUp(e) {
        if (ToolUtils.getIsInRoom()) {
            return;
        }
        let t = v3(0, 0);
        this.node.inverseTransformPoint(t, e.getWorldPosition());
        let i = GameConfig.REAL_SCREEN_HEIGHT;
        ToolUtils.getIsInRoom() && (i = GameConfig.REAL_SCREEN_WIDTH);
        let a = i / 2 + t.y - 34 - 80;
        a < this._keyboardHei ? this.rootNode.setPosition(v3(0, this._keyboardHei - a)) : this.rootNode.setPosition(v3(0, 0));
    }
    restoreScrollviewTop() {
        this.rootNode.setPosition(v3(0, 0));
    }
    updateVerifyView(e = false) {
        this._closed || (e && sys.isObjectValid(User.shared().kyc_guide_data.loading_seconds) && i18nMgr.shared().changeLabelLanguage(this.secTipsLabel.getComponent(Label), "kyc.just_5_secs", false, User.shared().kyc_guide_data.loading_seconds), 3 == User.shared().data.card_check && sys.isObjectValid(User.shared().newKycData.kyc_list) && (this.updateErrTips(), ToolUtils.isSafeString(User.shared().newKycData.kyc_list.card).length > 0 && (this.updateCardNumberView(User.shared().newKycData.kyc_list.card, true), this.updateCardNumberStatus())), 0 == User.shared().data.card_check || 3 == User.shared().data.card_check ? (this.verify_btn.getComponent(Button).interactable = true, 0 == User.shared().data.card_check ? i18nMgr.shared().changeLabelLanguage(this.verify_btn.getChildByName("wz").getComponent(Label), "kyc.verify", true) : (Utils.shared().hideLoading(), i18nMgr.shared().changeLabelLanguage(this.verify_btn.getChildByName("wz").getComponent(Label), "kyc.resubmit", true))) : this.verify_btn.getComponent(Button).interactable = false);
    }
    onButtonClick(e, t) {
        if (SoundManager.shared().playFx("click"), "back" == t || "close" == t) {
            this.onCloseLogic();
        }
        else if ("verify" == t) {
            if (sys.now() - this._lastClick < 500) {
                return;
            }
            if (this._lastClick = sys.now(), !User.shared().checkLocationPermit(CheckModule.KYC, this.from_source)) {
                return;
            }
            let e = ToolUtils.isSafeString(this.cardNumberStr);
            if (12 !== e.length) {
                return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text78"), 2);
            }
            sys.isObjectValid(User.shared().newKycData.kyc_list) && sys.isObjectValid(User.shared().newKycData.kyc_list.fast_reason) && User.shared().newKycData.kyc_list.fast_reason > 0 && (User.shared().newKycData.kyc_list.reason = "", User.shared().newKycData.kyc_list.fast_reason = "", User.shared().newKycData.kyc_list.trigger_age_pop = 0, this.updateErrTips());
            this.showVerifyBtnStatus(2);
            this.verify_btn.getChildByName("wz").getComponent(Label).string = i18nMgr.shared().getValueByKey("kyc.verity_pending");
            this.stopCountDownActin();
            this._countDownAction = TweenTool.delayAct(this.node, (() => {
                Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text37"), 3);
                this.revertBtnStatus(1);
            }), 30, true);
            this.cardNumberNode.getChildByName("del_btn").active = false;
            HttpManager.shared().doKycFastSava(e, this.from_source, this.listenSubmitCall.bind(this));
        }
        else if ("check" == t) {
            this.onCloseLogic();
        }
        else if ("feedback" == t) {
            Utils.shared().doJumpLogic(PushEvent.JUMP_TO_FEEDBACK);
        }
        else if ("cardnumber_del" == t) {
            let e = this.cardNumberNode.getChildByName("EditBox");
            e.getComponent(EditBox).string = "";
            e.getComponent(EditBox).blur();
            this.updateCardNumberStatus();
        }
        else if ("more_verify" == t) {
            ToolUtils.getIsInRoom() && (User.shared().BackHallOpenModule = 3, User.shared().isShowPopList = false, PushCenter.shared().pushEvent(GameConfig.BackToHall));
            this.onCloseLogic();
        }
        else if ("check_more" == t) {
            ToolUtils.getIsInRoom() && (User.shared().BackHallOpenModule = 3, User.shared().isShowPopList = false, PushCenter.shared().pushEvent(GameConfig.BackToHall));
        }
        else if ("kefu" == t) {
            if (1 == User.shared().temp_pingbi.feedback) {
                return void Utils.shared().showToast("Coming soon", 2);
            }
            let e = { sourceType: CommDefine.TawkUser_Feedback_Source.Kyc, groupType: CommDefine.TawkUser_Feedback_Source.Kyc_Group.Verify };
            this.verifyNode.active || (e.groupType = CommDefine.TawkUser_Feedback_Source.Kyc_Group.Checking);
            Utils.shared().doJumpLogic(PushEvent.JUMP_TO_FEEDBACK, e);
        }
    }
    revertBtnStatus(e) {
        this.showVerifyBtnStatus(e);
        this.updateVerifyView();
    }
    listenSubmitCall(e, t, i) {
        if (200 !== i) {
            ToolUtils.isObjValid(this.node) && (Utils.shared().hideLoading(), Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text37"), 2), this.stopCountDownActin(), this.revertBtnStatus(1));
        }
        else {
            try {
                let e = ToolUtils.parseJson(t);
                if (0 === e.ret) {
                    HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Hall, event: ReportConfig.hall_evt.kyc_submit_succ });
                    let t = e.data.card_check;
                    if (User.shared().data.card_check = t, sys.isObjectValid(e.data.kyc_otp_check) && (User.shared().data.kyc_otp_check = e.data.kyc_otp_check), 2 == User.shared().data.card_check ? HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Hall, event: ReportConfig.hall_evt.kyc_verify_succ }) : 3 == User.shared().data.card_check && HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Hall, event: ReportConfig.hall_evt.kyc_verify_fail }), 1 == t) {
                        if (sys.isObjectValid(e.data.msg) && e.data.msg.length > 0) {
                            Utils.shared().showToast(e.data.msg, 3);
                        }
                        else {
                            let e = i18nMgr.shared().getValueByKey("kyc.kyc_submit_tip");
                            Utils.shared().showToast(e, 3);
                        }
                        this.cardNumberNode.getChildByName("del_btn").active = false;
                        this.updateCardNumberView("", false, false);
                        this.showVerifyBtnStatus(2);
                    }
                    1 == User.shared().data.card_check && (this.verify_btn.getComponent(Button).interactable = false, i18nMgr.shared().changeLabelLanguage(this.verify_btn.getChildByName("wz").getComponent(Label), "kyc.verity_pending", true));
                    ToolUtils.isSafeString(e.data.card).length > 0 && (User.shared().newKycData.kyc_list.card = e.data.card);
                    sys.isObjectValid(e.data.loading_seconds) && Number(e.data.loading_seconds) > 0 ? ToolUtils.isObjValid(this.node) && (1 == User.shared().data.card_check && (this.verify_btn.getComponent(Button).interactable = false, i18nMgr.shared().changeLabelLanguage(this.verify_btn.getChildByName("wz").getComponent(Label), "kyc.verity_pending", true)), this.stopCountDownActin(), this._countDownAction = TweenTool.delayAct(this.node, (() => {
                        Utils.shared().hideLoading();
                        User.shared().doGetKycVerifyList();
                    }), Number(e.data.loading_seconds), true)) : (sys.isObjectValid(e.data.fast_reason) && (User.shared().newKycData.kyc_list.fast_reason = e.data.fast_reason), sys.isObjectValid(e.data.trigger_age_pop) && (User.shared().newKycData.kyc_list.trigger_age_pop = e.data.trigger_age_pop), 2 != t && 1 != t || (User.shared().newKycData.kyc_list.reason = "", User.shared().newKycData.kyc_list.fast_reason = "", User.shared().newKycData.kyc_list.trigger_age_pop = 0, User.shared().data.kyc_data.reason = "", User.shared().updateKycAccount2(e.data), ToolUtils.isObjValid(this.node) && (this.stopCountDownActin(), 2 == t && (sys.isObjectValid(e.data.reward_list) && e.data.reward_list.length > 0 ? Utils.shared().showKycVerifySucTip(e.data.reward_list, i18nMgr.shared().getValueByKey("kyc.KYC_Verify_Suc")) : Utils.shared().showToast(i18nMgr.shared().getValueByKey("kyc.submit_success"), 2), ToolUtils.isObjValid(this.node) && this.onBackView()))), PushCenter.shared().pushEvent(GameConfig.Update_Kyc, User.shared().data.kyc_check));
                }
                else if (4027 === e.ret) {
                    User.shared().data.submit_left_hour = e.data.submit_left_seconds;
                    Utils.shared().doJumpLogic(PushEvent.Custom_TO_KycLimitTip);
                    TweenTool.delayAct(this.node, (() => {
                        this.onBackView();
                    }), 1, true);
                }
                else {
                    ToolUtils.isObjValid(this.node) && (this.stopCountDownActin(), this.revertBtnStatus(1), e.desc && e.desc.length > 0 && Utils.shared().showToast(e.desc, 2));
                    let t = e.ret + ToolUtils.isSafeString(e.desc);
                    HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Hall, event: ReportConfig.hall_evt.kyc_submit_fail, kyc_err: t });
                }
            }
            catch (e) {
                ToolUtils.isObjValid(this.node) && (this.stopCountDownActin(), this.revertBtnStatus(1));
                let t = ToolUtils.isSafeString(e.toString());
                HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Hall, event: ReportConfig.hall_evt.kyc_submit_fail, kyc_err: t });
            }
        }
    }
    showVerifyBtnStatus(e) {
        let t = this.verify_btn.getChildByName("anim_waiting");
        1 == e ? (this.verify_btn.getComponent(Button).interactable = true, this.verify_btn.getChildByName("di").getComponent(Sprite).spriteFrame = this.verifyBtnDiImags[1], this.verify_btn.getChildByName("di").active = true, t.active = false, this.verify_btn.getChildByName("wz").getComponent(Label).color = color(255, 255, 255), this.verify_btn.getChildByName("wz").getComponent(LabelShadow).color = CommDefine.shadowcolor.green, this.verify_btn.getChildByName("wz").getComponent(LabelShadow).enabled = true, Utils.updateLabelMaterial(this.verify_btn.getChildByName("wz"), CommDefine.gradient.btn_green)) : 0 == e ? (this.verify_btn.getComponent(Button).interactable = false, this.verify_btn.getChildByName("di").getComponent(Sprite).spriteFrame = this.verifyBtnDiImags[0], this.verify_btn.getChildByName("di").active = true, t.active = false, this.verify_btn.getChildByName("wz").getComponent(Label).color = color(255, 255, 255), this.verify_btn.getChildByName("wz").getComponent(LabelShadow).enabled = true, this.verify_btn.getChildByName("wz").getComponent(LabelShadow).color = CommDefine.shadowcolor.gray, Utils.updateLabelMaterial(this.verify_btn.getChildByName("wz"), CommDefine.gradient.btn_gray)) : 2 == e && (this.verify_btn.getComponent(Button).interactable = false, t.active = true, this.verify_btn.getChildByName("wz").getComponent(LabelShadow).enabled = true, this.verify_btn.getChildByName("wz").getComponent(LabelShadow).color = CommDefine.shadowcolor.gray, this.verify_btn.getChildByName("di").active = true, this.verify_btn.getChildByName("di").getComponent(Sprite).spriteFrame = this.verifyBtnDiImags[0], Utils.updateLabelMaterial(this.verify_btn.getChildByName("wz"), CommDefine.gradient.btn_gray));
    }
    showVerifyWaitTime(e) {
        if (this._identitytimeAction && TweenTool.stopAction(this._identitytimeAction), this._mIdTime = Number(e), e > 0) {
            this.showVerifyBtnStatus(2);
            let t = this.verify_btn.getChildByName("wz");
            t.getComponent(Label).string = ToolUtils.format(i18nMgr.shared().getValueByKey("kyc.pending_count"), String(e));
            this._identitytimeAction = TweenTool.myschedule(this.node, 1, (() => {
                this._mIdTime -= 1;
                this._mIdTime <= 0 ? (this.stopIdentityActin(), this.updateCheckStatus(), this.updateVerifyView(), this.updateCardNumberStatus(), User.shared().doGetKycVerifyList()) : t.getComponent(Label).string = ToolUtils.format(i18nMgr.shared().getValueByKey("kyc.pending_count"), String(this._mIdTime));
            }));
        }
    }
    stopCountDownActin() {
        this._countDownAction && (TweenTool.stopAction(this._countDownAction), this._countDownAction = null);
    }
    stopIdentityActin() {
        this._identitytimeAction && (TweenTool.stopAction(this._identitytimeAction), this._identitytimeAction = null);
    }
    onCloseLogic() {
        PushCenter.shared().pushEvent(PushEvent.onKycGuideRemove);
        this.stopIdentityActin();
        this.stopCountDownActin();
        this.isNext && PushCenter.shared().pushEvent(PushEvent.Update_NextPopActivity);
        this.onRemoveWindow();
    }
    onRemoveWindow() {
        this._closed || ToolUtils.isObjValid(this.node) && (this._closed = true, this.node.destroy());
    }
    onBackView() {
        this.onCloseLogic();
    }
}
