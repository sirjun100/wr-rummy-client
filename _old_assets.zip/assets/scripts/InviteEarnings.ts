// @ts-nocheck
// Recovered from index.js:205
import { _decorator, Button, Color, Label, Layout, Node, ScrollView, size, Sprite, SpriteFrame, sys, UITransform, v3, Widget } from "cc";
import TableViewUtils from "./TableViewUtils";
import { TLog } from "./TLog";
import Utils from "./Utils";
import HttpManager from "./HttpManager";
import SoundManager from "./SoundManager";
import User from "./User";
import BaseLayer from "./BaseLayer";
import i18nMgr from "./i18nMgr";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("InviteEarnings")
export class InviteEarnings extends BaseLayer {
    @property(ScrollView)
    public detailList: ScrollView = null;
    @property(Node)
    public moban: Node = null;
    @property(Node)
    public nodata: Node = null;
    @property(Node)
    public contentNode: Node = null;
    @property(Node)
    public earnNode: Node = null;
    @property([SpriteFrame])
    public taskBgFrames: SpriteFrame[] = [];
    @property([SpriteFrame])
    public headMoreFrames: SpriteFrame[] = [];
    public hasNextPage: number = 0;
    public detailData: any[] = [];
    public detailTabView: any = null;
    public _cb: any = null;
    public _data: any = null;
    public isSendMsg: boolean = false;
    public _lastClick: number = 0;
    setParaData(e, t) {
        this._cb = e;
        this._data = t;
    }
    start() {
        super.start();
        ToolUtils.adaptSafeArea(this.node.getChildByName("root"));
        this.setUiEdgeDistance(this.node.getChildByName("bottom_node"), 68, 3, false);
        this.moban.active = false;
        let e = [this.moban];
        this.detailTabView = this.node.addComponent(TableViewUtils);
        let t = this.moban.getComponent(UITransform).height;
        this.detailList.node.getComponent(Widget).updateAlignment();
        this.detailTabView.init([], this.detailList.node, e, this.initCurMobanCallBack.bind(this), 0, t, this.scrollRefreshCallBack.bind(this), false);
        sys.isObjectValid(this._data) && sys.isObjectValid(this._data.no_his) && 1 == this._data.no_his ? (this.nodata.active = true, this.node.getChildByName("bottom_node").active = true, this.contentNode.active = false) : (this.nodata.active = false, this.node.getChildByName("bottom_node").active = false, this.contentNode.active = true, this.refreshDetailList(this._data), this.updateCurTask(this._data));
        this.dealMultipleLanguages();
    }
    dealMultipleLanguages() {
        2 == i18nMgr.shared().language && (this.node.getChildByName("root").getChildByName("title").getComponent(Label).fontSize = 32, this.node.getChildByName("bottom_node").getChildByName("whatsapp_btn").getChildByName("invite_friends").getComponent(Label).fontSize = 32);
    }
    doShareGetIncomeList() {
        HttpManager.shared().doShareGetIncomeList(this.listenDailyDetailCallback.bind(this));
    }
    listenDailyDetailCallback(e, t, i) {
        Utils.shared().hideLoading();
        this.isSendMsg = false;
        try {
            if (200 != i) {
                alert("The login timed out, please try again");
            }
            else if (200 === i) {
                let e = ToolUtils.parseJson(t);
                0 === e.ret ? ToolUtils.isObjValid(this.node) && (User.shared().inviteEarnings = e.data, this.refreshDetailList(e.data), this.updateCurTask(e.data)) : e.desc && ToolUtils.isSafeString(e.desc).length > 0 && Utils.shared().showToast(e.desc, 3);
            }
        }
        catch (e) {
            TLog.printError("----- listenDailyDetailCallback error:", e);
        }
    }
    updateCurTask(e) {
        if (sys.isObjectValid(e.no_his) && 1 == e.no_his) {
            return;
        }
        let t = this.earnNode.getChildByName("total_node");
        if (t && sys.isObjectValid(e.receive_amt) && (t.getChildByName("num").getComponent(Label).string = e.receive_amt), sys.isObjectValid(e.cur_amt)) {
            let t = this.earnNode.getChildByName("pnode");
            t && (3 != i18nMgr.shared().language ? t.getChildByName("inprogress").getComponent(Label).string = ToolUtils.format(i18nMgr.shared().getValueByKey("invite.earn_his_inprogress"), e.cur_amt) : (t.getChildByName("inprogress").getComponent(Label).string = i18nMgr.shared().getValueByKey("invite.earn_his_inprogress"), t.getChildByName("inprogress2").getComponent(Label).string = "₹" + String(e.cur_amt) + ")"));
        }
        this.initCurMobanCallBack(this.moban, e.cur_task, 0, 1);
    }
    refreshDetailList(e) {
        let t = false;
        if (this.detailData = [], this.detailTabView.clearAllItem(true), t = true, e && e.task_list && e.task_list.length > 0) {
            this.nodata.active = false;
            this.node.getChildByName("bottom_node").active = false;
            this.contentNode.active = true;
            for (let t = 0; t < e.task_list.length; t++) {
                this.detailData.push(e.task_list[t]);
            }
            this.detailTabView.reloadData(this.detailData, true);
        }
        else {
            e && e.no_his && 1 == e.no_his && (this.nodata.active = true, this.contentNode.active = false, this.node.getChildByName("bottom_node").active = true);
        }
    }
    initCurMobanCallBack(e, t, i, a) {
        e.active = true;
        a && 1 == a ? (e.getChildByName("ongoing_wz").active = true, e.getChildByName("ok_wz").active = false, e.getChildByName("ok_flag").active = false, e.getChildByName("ok_date").active = false, e.getChildByName("bg").getComponent(Sprite).spriteFrame = this.taskBgFrames[0], e.getChildByName("total_node").getChildByName("fuhao").getComponent(Label).color = new Color(241, 56, 42), e.getChildByName("total_node").getChildByName("num").getComponent(Label).color = new Color(241, 56, 42), e.getChildByName("total_node").getChildByName("fuhao2").getComponent(Label).color = new Color(241, 56, 42)) : (e.getChildByName("ongoing_wz").active = false, e.getChildByName("ok_wz").active = true, e.getChildByName("ok_flag").active = true, e.getChildByName("ok_date").active = true, e.getChildByName("bg").getComponent(Sprite).spriteFrame = this.taskBgFrames[1], sys.isObjectValid(t.date) && (e.getChildByName("ok_date").getComponent(Label).string = t.date), 1 == i18nMgr.shared().language ? e.getChildByName("ok_flag").setPosition(v3(29.069 - 15, -15.944)) : 2 == i18nMgr.shared().language && e.getChildByName("ok_flag").setPosition(v3(17.069, -15.944)), e.getChildByName("total_node").getChildByName("fuhao").getComponent(Label).color = new Color(129, 128, 128), e.getChildByName("total_node").getChildByName("num").getComponent(Label).color = new Color(129, 128, 128), e.getChildByName("total_node").getChildByName("fuhao2").getComponent(Label).color = new Color(129, 128, 128));
        e.getComponent(Button).clickEvents[0].customEventData = ToolUtils.toJsonString(t);
        sys.isObjectValid(t.receive_amt) && (e.getChildByName("total_node").getChildByName("num").getComponent(Label).string = t.receive_amt);
        let n = e.getChildByName("player_node");
        if (n && sys.isObjectValid(t.bound_player) && t.bound_player.length > 0) {
            t.bound_player.length < 6 ? n.getComponent(Layout).spacingX = 4 : n.getComponent(Layout).spacingX = -16;
            for (let e = 0; e < 6; e++) {
                n.getChildByName("head" + e).active = false;
            }
            n.getChildByName("head_more").active = false;
            for (let e = 0; e < t.bound_player.length; e++) {
                if (e >= 6) {
                    n.getChildByName("head_more").active = true;
                    n.getChildByName("head_more").getChildByName("more").getComponent(Sprite).spriteFrame = a && 1 == a ? this.headMoreFrames[0] : this.headMoreFrames[1];
                    break;
                }
                n.getChildByName("head" + e).active = true;
                Utils.shared().updateHeadImg(n.getChildByName("head" + e).getChildByName("head_mask").getChildByName("head_img"), t.bound_player[e], t.bound_player[e], size(60, 60));
            }
        }
        e.getChildByName("nodata").active = false;
        a && 1 == a && (sys.isObjectValid(t.bound_player) && 0 == t.bound_player.length ? e.getChildByName("nodata").active = true : sys.isObjectValid(t.bound_player) ? e.getChildByName("nodata").active = false : e.getChildByName("nodata").active = true);
    }
    scrollRefreshCallBack() {
    }
    onGetTaskDetailsClick(e, t) {
        if (SoundManager.shared().playFx("click"), sys.now() - this._lastClick < 500) {
            return;
        }
        this._lastClick = sys.now();
        let i = ToolUtils.parseJson(t);
        this.showTaskDetailLogic(i);
    }
    showTaskDetailLogic(e) {
        Utils.shared().showLoading(10, true, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3);
        }));
        HttpManager.shared().doGetCommonRequest({ tid: e.tid }, "Share.taskDetail", ((t, i, a) => {
            Utils.shared().hideLoading();
            this.isSendMsg = false;
            try {
                if (200 != a) {
                    alert("The login timed out, please try again");
                }
                else if (200 === a) {
                    let t = ToolUtils.parseJson(i);
                    0 === t.ret ? ToolUtils.isObjValid(this.node) && ToolUtils.isObjValid(this.node) && (t.data.tid = e.tid, Utils.shared().showEarnDetailsView((() => {
                    }), t.data)) : t.desc && ToolUtils.isSafeString(t.desc).length > 0 && Utils.shared().showToast(t.desc, 3);
                }
            }
            catch (e) {
                TLog.printError("----- listenDailyDetailCallback error:", e);
            }
        }));
    }
    onButtonClick(e, t) {
        "earnings_close" == t ? (SoundManager.shared().playFx("click"), ToolUtils.isObjValid(this.node) && this.node.destroy()) : this._cb && this._cb(e, t);
    }
}
