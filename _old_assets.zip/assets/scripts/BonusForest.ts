// @ts-nocheck
// Recovered from index.js:41
import { _decorator, Button, color, HorizontalTextAlignment, instantiate, Label, Node, ProgressBar, ScrollView, size, Size, sp, Sprite, SpriteAtlas, SpriteFrame, sys, UIOpacity, UITransform, v2, v3 } from "cc";
import BaseLayer from "./BaseLayer";
import SoundManager from "./SoundManager";
import Utils from "./Utils";
import User from "./User";
import HttpManager from "./HttpManager";
import { HttpRequest } from "./HttpRequestName";
import i18nMgr from "./i18nMgr";
import TweenTool from "./TweenTool";
import PushCenter from "./PushCenter";
import PushEvent from "./PushEvent";
import GameConfig from "./GameConfig";
import BundleNameDefined from "./BundleNameDefined";
import ReportConfig from "./ReportConfig";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("BonusForest")
export class BonusForest extends BaseLayer {
    public TAG: string = "BonusForest";
    @property(Node)
    public rootNode: Node = null;
    @property(sp.Skeleton)
    public bgAnim: any = null;
    @property(ScrollView)
    public scrollView: ScrollView = null;
    @property(Node)
    public bgMoabn: Node = null;
    @property(Node)
    public treeMoabn: Node = null;
    @property(Node)
    public topNode: Node = null;
    @property(Node)
    public bottomNode: Node = null;
    @property(Node)
    public waterNode: Node = null;
    @property(Node)
    public rechargeNode: Node = null;
    @property(Node)
    public ruleNode: Node = null;
    @property(Label)
    public ruleLabel: Label = null;
    @property(SpriteAtlas)
    public forestTreeAtlas: SpriteAtlas = null;
    @property([SpriteFrame])
    public rewardSpriteFrame: SpriteFrame[] = [];
    @property([SpriteFrame])
    public giftSpriteFrame: SpriteFrame[] = [];
    public isNext: boolean = false;
    public _callback: any = null;
    public _isFirstShow: boolean = true;
    public _scheduleTime: any = null;
    public _scheduleAct: any = null;
    public _scheduleProgress: any = null;
    public _scheduleTree: any = null;
    public _waterData: any = null;
    public _leftTime: number = 0;
    public _lastClick: number = 0;
    public _price: number = 0;
    public _linkId: number = 0;
    public _hasReward: boolean = false;
    public _bCanSend: boolean = false;
    public _rewardIndex: number = 0;
    public _rewardCount: number = 0;
    public _scene: number = 1;
    public _has_close: boolean = false;
    public _pop_souce: number = 0;
    public bonusForestData_md5: any = null;
    initParaData(e, t) {
        sys.isObjectValid(e) && (sys.isObjectValid(e.isNext) && (this.isNext = e.isNext), sys.isObjectValid(e.pop_souce) && (this._pop_souce = e.pop_souce), sys.isObjectValid(e.reportScene) && (this._scene = e.reportScene), sys.isObjectValid(e.link_id) && e.link_id > 0 && (this._linkId = e.link_id));
        this._callback = t;
    }
    onLoad() {
        this.bgMoabn.active = false;
        this.treeMoabn.active = false;
        this.waterNode.active = false;
        this.ruleNode.active = false;
        this.rechargeNode.active = false;
        for (let e = 0; e < 2; e++) {
            let t = instantiate(this.bgMoabn);
            t.active = true;
            t.setPosition(v3(0, -1280 * e));
            this.scrollView.content.addChild(t);
        }
        this.scrollView.content.getComponent(UITransform).setContentSize(size(GameConfig.REAL_SCREEN_WIDTH, 2560));
        ToolUtils.showFullScreen(this.node.getChildByName("mask"));
        ToolUtils.showFullScreen(this.waterNode.getChildByName("mask"));
        ToolUtils.showFullScreen(this.ruleNode.getChildByName("mask"));
        ToolUtils.showFullScreen(this.rechargeNode.getChildByName("mask"));
        SoundManager.shared().preLoadBundleSounds(BundleNameDefined.bundle_sound, "bonusForest");
        sys.isObjectValid(User.shared().bonusForestData) ? this.initView() : Utils.shared().showLoading(10, true, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
        }));
    }
    start() {
        super.start();
        this._linkId = this._linkId > 0 ? this._linkId : sys.now();
        sys.isObjectValid(User.shared().bonusForestData) && (this._bCanSend = true, HttpManager.shared().doCommReportRechargeEvent(ReportConfig.Cmd_BonusForest, this._scene, 4, this._linkId, null, 0));
        this.refreshLeftTime();
        this.requestBonusForestPage();
        this._scheduleAct = TweenTool.commonSchedule(this.node, 5, this.scheduleCallBack.bind(this));
        PushCenter.shared().addListener(GameConfig.Recharge, (e => {
            ToolUtils.isObjValid(this.node) && this.requestBonusForestPage();
        }), this);
    }
    scheduleCallBack() {
        let e = ToolUtils.getRandomInt(0, 1);
        if (this.bgAnim.node.active = true, 0 == e) {
            this.bgAnim.clearTracks();
            this.bgAnim.setAnimation(0, "leaf", false);
        }
        else {
            let e = ToolUtils.getRandomInt(1, 4);
            e >= 1 && e <= 4 && this.bgAnim.setAnimation(0, "bird" + e, false);
        }
        let t = 300 * (ToolUtils.getRandomInt(100, 600) / 100 - 3);
        this.bgAnim.node.setPosition(v3(0, t));
        TweenTool.stopNodeAction(this.bgAnim);
        TweenTool.delayAct(this.bgAnim, (() => {
            this.bgAnim.node.active = false;
        }), 3, true);
    }
    onDestroy() {
        super.destroy();
        PushCenter.shared().removeListenersByTag(this);
        this.unscheduleAllCallbacks();
        this._scheduleAct && TweenTool.stopAction(this._scheduleAct);
        this._scheduleTime && TweenTool.stopAction(this._scheduleTime);
    }
    requestBonusForestPage() {
        HttpManager.shared().doGetCommonRequest(null, HttpRequest.BonusForestPage, ((e, t, i) => {
            if (Utils.shared().hideLoading(), 200 != i) {
                alert("The login timed out, please try again");
            }
            else {
                try {
                    let e = ToolUtils.parseJson(t);
                    if (0 == e.ret) {
                        this._bCanSend || (this._bCanSend = true, HttpManager.shared().doCommReportRechargeEvent(ReportConfig.Cmd_BonusForest, this._scene, 4, this._linkId, null, 0));
                        let t = true;
                        if (sys.isObjectValid(this.bonusForestData_md5)) {
                            let i = ToolUtils.jsonToMd5(e.data);
                            this.bonusForestData_md5 == i && (t = false);
                        }
                        User.shared().bonusForestData = e.data;
                        ToolUtils.isObjValid(this.node) && t && this.initView();
                    }
                }
                catch (e) {
                }
            }
        }));
    }
    initView() {
        if (sys.isObjectValid(User.shared().bonusForestData)) {
            if (this.bonusForestData_md5 = ToolUtils.jsonToMd5(User.shared().bonusForestData), this._leftTime = User.shared().bonusForestData.left, this._scheduleTime && this._scheduleTime.stop(), this.refreshLeftTime(), this._scheduleTime = TweenTool.myschedule(this.node, 1, (() => {
                this._leftTime = this._leftTime - 1;
                this._leftTime >= 0 ? this.refreshLeftTime() : (this._scheduleTime.stop(), this.requestBonusForestPage());
            })), 1 == User.shared().bonusForestData.finish ? (this.bottomNode.getChildByName("complete_btn").active = true, this.bottomNode.getChildByName("water_btn").active = false, this.bottomNode.getChildByName("recharge_btn").active = false) : (this.bottomNode.getChildByName("complete_btn").active = false, this.bottomNode.getChildByName("water_btn").active = User.shared().bonusForestData.water > 0, this.bottomNode.getChildByName("water_btn").getComponent(Button).interactable = User.shared().bonusForestData.water > 0, this.bottomNode.getChildByName("recharge_btn").active = 0 == User.shared().bonusForestData.water, this.bottomNode.getChildByName("water_btn").getChildByName("free").active = 0 != User.shared().bonusForestData.free, i18nMgr.shared().changeLabelLanguage(this.bottomNode.getChildByName("water_btn").getChildByName("wz").getComponent(Label), "bonusForest.watering", true, User.shared().bonusForestData.water)), sys.isObjectValid(User.shared().bonusForestData.desc) && (this.bottomNode.getChildByName("tips").getComponent(Label).string = User.shared().bonusForestData.desc, i18nMgr.shared().changeLabelFont(this.bottomNode.getChildByName("tips").getComponent(Label), true)), 2 == i18nMgr.shared().language ? (this.rechargeNode.getChildByName("bgView").getChildByName("other").getChildByName("wz").getComponent(Label).fontSize = 20, this.bottomNode.getChildByName("tips").getComponent(Label).fontSize = 18, this.bottomNode.getChildByName("tips").getComponent(UITransform).contentSize = new Size(600, 58.76), this.bottomNode.getChildByName("water_btn").getChildByName("wz").getComponent(Label).fontSize = 28, this.bottomNode.getChildByName("water_btn").getChildByName("free").getChildByName("wz").getComponent(Label).fontSize = 16) : 3 == i18nMgr.shared().language && (this.rechargeNode.getChildByName("bgView").getChildByName("add_cash").getChildByName("wz").getComponent(Label).horizontalAlign = HorizontalTextAlignment.LEFT), this.scrollView.content.removeAllChildren(), sys.isObjectValid(User.shared().bonusForestData.tree) && User.shared().bonusForestData.tree.length > 0) {
                let e = Math.floor(User.shared().bonusForestData.tree.length / 3) + 1;
                for (let t = 0; t < e; t++) {
                    let e = instantiate(this.bgMoabn);
                    e.active = true;
                    e.setPosition(v3(0, -1280 * t));
                    this.scrollView.content.addChild(e);
                }
                let t = 0;
                for (let e = 0, i = User.shared().bonusForestData.tree.length; e < i; e++) {
                    let i = instantiate(this.treeMoabn);
                    i.active = true;
                    i.setPosition(v3(0, -200 - 310 * e));
                    let a = User.shared().bonusForestData.tree[User.shared().bonusForestData.tree.length - e - 1];
                    sys.isObjectValid(a) && 1 == a.status && (t = e + 1);
                    this.initTreeMoban(i, e, a);
                    this.scrollView.content.addChild(i);
                }
                this.scrollView.content.getComponent(UITransform).setContentSize(size(GameConfig.REAL_SCREEN_WIDTH, 310 * User.shared().bonusForestData.tree.length + 200 + 220));
                let i = this._isFirstShow ? 0 : 0.5;
                this.scrollView.scrollToOffset(v2(0, 200 + 310 * (t + 1) - (this.scrollView.getComponent(UITransform).contentSize.height - 280)), i);
            }
            if (this.rechargeNode.active = false, sys.isObjectValid(User.shared().bonusForestData.good)) {
                for (let e = 0; e < 4; e++) {
                    let t = User.shared().bonusForestData.good[e], i = this.rechargeNode.getChildByName("bgView").getChildByName("price" + e);
                    sys.isObjectValid(t) ? (i.active = true, i.getChildByName("num").getComponent(Label).string = ToolUtils.format("₹${0}", t)) : i.active = false;
                }
            }
            sys.isObjectValid(User.shared().bonusForestData.goodDesc) && (this.rechargeNode.getChildByName("bgView").getChildByName("tips").getComponent(Label).string = User.shared().bonusForestData.goodDesc, i18nMgr.shared().changeLabelFont(this.rechargeNode.getChildByName("bgView").getChildByName("tips").getComponent(Label), false));
            this._isFirstShow = false;
        }
    }
    initTreeMoban(e, t, i) {
        if (sys.isObjectValid(i)) {
            let a = 0 == Math.floor(t % 2) ? 216 : -216;
            e.getChildByName("parterre").setPosition(v3(a, -266));
            e.getChildByName("tree").setPosition(v3(a, -250));
            Utils.shared().setImage(e.getChildByName("tree"), ToolUtils.format("tree${0}_${1}", i.sid, i.node), this.forestTreeAtlas);
            e.getChildByName("anim").setPosition(v3(a, -250));
            e.getChildByName("anim").active = 1 == i.status;
            let o = 0 == Math.floor(t % 2) ? -114 : 114;
            e.getChildByName("reward_bg").setPosition(v3(o, -158));
            let r = 0 == Math.floor(t % 2) ? -1 : 1;
            e.getChildByName("reward_bg").setScale(v3(r, 1, 1));
            let l = 0 == Math.floor(t % 2) ? -124 : 124;
            e.getChildByName("reward").setPosition(v3(l, -158));
            let h = e.getChildByName("reward");
            h.getChildByName("totalNode").removeAllChildren();
            let d = h.getChildByName("total_moban");
            if (d.active = false, sys.isObjectValid(i.reward_list) && i.reward_list.length > 0) {
                for (let e = 0, t = i.reward_list.length; e < t; e++) {
                    let t = instantiate(d);
                    t.active = true;
                    t.setPosition(v3(0, 0));
                    this.initRewardMobanView(t, i, e);
                    h.getChildByName("totalNode").addChild(t);
                }
            }
            h.getChildByName("giftNode").removeAllChildren();
            let N = h.getChildByName("gift_moban");
            if (N.active = false, sys.isObjectValid(i.node_list) && i.node_list.length) {
                let e = h.getChildByName("ProgressBar").getComponent(UITransform).contentSize.width;
                for (let t = 0, a = i.node_list.length + 1; t < a; t++) {
                    let a = instantiate(N);
                    h.getChildByName("giftNode").addChild(a);
                    a.setPosition(v3(0, 0));
                    a.active = true;
                    2 == i.status && (i.current = i.node_list[i.node_list.length - 1].grow);
                    this.initGiftMoabnView(a, i.node_list[t - 1], t, i.node_list.length, e, i.current);
                }
            }
            let w = 0, p = color(255, 255, 255), _ = color(255, 255, 255);
            if (0 == i.status) {
                p = color(115, 173, 111);
                _ = color(155, 226, 155);
                w = 0;
            }
            else if (1 == i.status) {
                let t = i.node_list.length;
                for (let e = t - 1; e >= 0; e--) {
                    if (e > 0) {
                        if (i.current >= i.node_list[e - 1].grow) {
                            w = ((i.current - i.node_list[e - 1].grow) / (i.node_list[e].grow - i.node_list[e - 1].grow) + e) / t;
                            break;
                        }
                    }
                    else {
                        w = i.current / i.node_list[0].grow / t;
                    }
                }
                e.getChildByName("anim").getComponent(sp.Skeleton).clearTracks();
                e.getChildByName("anim").getComponent(sp.Skeleton).setAnimation(0, "animation", true);
                this._scheduleTree && TweenTool.stopAction(this._scheduleTree);
                this.scheduleTreeCallBack(e.getChildByName("tree"));
                this._scheduleTree = TweenTool.commonSchedule(e.getChildByName("tree"), 10, this.scheduleTreeCallBack.bind(this));
            }
            else {
                2 == i.status && (w = 1);
            }
            e.getChildByName("reward").getChildByName("ProgressBar").getComponent(ProgressBar).progress = w;
            let f = e.getChildByName("reward").getChildByName("ProgressBar").getComponent(UITransform).contentSize.width, v = e.getChildByName("reward").getChildByName("grow");
            if (v.active = 1 == i.status, 1 == i.status) {
                v.setPosition(v3(f * w - f / 2 - 6, -6));
                v.getChildByName("num").getComponent(Label).string = String(Math.floor(Number(i.current)));
                v.getChildByName("num").getComponent(Label).updateRenderData(true);
                let e = v.getChildByName("num").getComponent(UITransform).contentSize.width, t = e > 20 ? e : 20;
                v.getComponent(UITransform).setContentSize(size(t + 30, 32));
            }
            e.getChildByName("tree").getComponent(Sprite).color = p;
            e.getChildByName("parterre").getComponent(Sprite).color = _;
        }
    }
    scheduleTreeCallBack(e) {
        if (ToolUtils.isObjValid(e)) {
            let t = TweenTool.scaleTo(e, 10 / 30, v3(0.8, 0.78, 1), null, false), i = TweenTool.scaleTo(e, 5 / 30, v3(0.8, 0.84, 1), null, false), a = TweenTool.scaleTo(e, 5 / 30, v3(0.8, 0.79, 1), null, false), o = TweenTool.scaleTo(e, 4 / 30, v3(0.8, 0.82, 1), null, false), s = TweenTool.scaleTo(e, 0.1, v3(0.8, 0.8, 1), null, false);
            TweenTool.sequence(e, true, null, t, i, a, o, s);
        }
    }
    initRewardMobanView(e, t, i) {
        let a = t.reward_list[i], o = this.rewardSpriteFrame[a.type], s = v3(0.6, 0.6), r = v3(0, -2);
        0 != a.type && 1 != a.type && (o = this.rewardSpriteFrame[2], s = v3(0.75, 0.75), r = v3(0, 2));
        e.getChildByName("icon").getComponent(Sprite).spriteFrame = o;
        e.getChildByName("icon").setScale(s);
        e.getChildByName("icon").setPosition(r);
        e.getChildByName("num").getComponent(Label).string = ToolUtils.format("x${0}", a.amt);
        sys.isObjectValid(a.ext) && sys.isObjectValid(a.ext.ratio) && (e.getChildByName("ratio").active = true, e.getChildByName("ratio").getComponent(Label).string = ToolUtils.format("${0}%", a.ext.ratio));
        let l = 2 == t.status ? 153 : 255;
        e.getChildByName("bubble").getComponent(UIOpacity).opacity = l;
        e.getChildByName("icon").getComponent(UIOpacity).opacity = l;
        e.getChildByName("num").getComponent(UIOpacity).opacity = l;
        e.getChildByName("ratio").getComponent(UIOpacity).opacity = l;
        e.getChildByName("tick").active = 2 == t.status;
    }
    initGiftMoabnView(e, t, i, a, o, s = 0) {
        if (0 == i) {
            e.getChildByName("icon").active = false;
            e.getChildByName("num").getComponent(Label).string = "0";
            let t = 0 == s ? 255 : 153;
            e.getChildByName("num").getComponent(UIOpacity).opacity = t;
            e.setPosition(v3(-o / 2, 0));
        }
        else {
            e.getChildByName("icon").active = true;
            this.giftSpriteFrame[t.complete] && (e.getChildByName("icon").getComponent(Sprite).spriteFrame = this.giftSpriteFrame[t.complete]);
            e.getChildByName("num").getComponent(Label).string = t.grow;
            let s = 0 == t.complete ? 255 : 153;
            e.getChildByName("num").getComponent(UIOpacity).opacity = s;
            let r = 0;
            a > 0 && (r = o / a);
            let l = i == a ? o / 2 - 10 : -o / 2 + r * i - 10;
            e.setPosition(v3(l, 0));
        }
    }
    refreshLeftTime() {
        let e = this.topNode.getChildByName("time").getComponent(Label);
        e.string = Utils.shared().parseCountDownToSec(this._leftTime);
        this._leftTime <= 0 && (e.string = "0m 0s");
    }
    refreshWaterView() {
        if (sys.isObjectValid(this._waterData)) {
            Utils.shared().setImage(this.waterNode.getChildByName("tree"), ToolUtils.format("tree${0}_${1}", this._waterData.sid, this._waterData.start_node), this.forestTreeAtlas);
            this.refreshObtainedView(this._waterData.before);
            this.waterNode.getChildByName("giftNode").removeAllChildren();
            let e = this.waterNode.getChildByName("gift_moban");
            if (e.active = false, this._rewardCount = 0, sys.isObjectValid(this._waterData.node_list) && this._waterData.node_list.length > 0) {
                let t = this.waterNode.getChildByName("ProgressBar").getComponent(UITransform).contentSize.width;
                for (let i = 0, a = this._waterData.node_list.length + 1; i < a; i++) {
                    let a = instantiate(e);
                    a.active = true;
                    a.setPosition(v3(0, 0));
                    a.name = "gift" + i;
                    this.initGiftMoabnView(a, this._waterData.node_list[i - 1], i, this._waterData.node_list.length, t, this._waterData.grow_old);
                    this.waterNode.getChildByName("giftNode").addChild(a);
                    sys.isObjectValid(this._waterData.node_list[i - 1]) && this._waterData.grow_now >= this._waterData.node_list[i - 1].grow && 0 == this._waterData.node_list[i - 1].complete && (this._rewardCount += 1);
                }
            }
            let t = this.waterNode.getChildByName("wateringAnim").getComponent(sp.Skeleton);
            t.node.active = true;
            t.clearTracks();
            t.setAnimation(0, "pot", false);
            t.setCompleteListener((() => {
                ToolUtils.isObjValid(t.node) && (t.node.active = false);
            }));
            SoundManager.shared().playFx("forest_watering");
            this._hasReward = false;
            this._rewardIndex = 0;
            this.waterNode.getChildByName("drop_node").removeAllChildren();
            this._scheduleProgress && TweenTool.stopAction(this._scheduleProgress);
            this.bottomNode.getChildByName("water_btn").getComponent(Button).interactable = false;
            this.scheduleProgressCallBack();
            TweenTool.delayAct(this.waterNode, (() => {
                this._scheduleProgress = TweenTool.commonSchedule(this.waterNode, 0.03, this.scheduleProgressCallBack.bind(this));
            }), 20 / 30, true);
        }
    }
    scheduleProgressCallBack() {
        this._waterData.grow_old >= this._waterData.grow_now && (this._waterData.grow_old = this._waterData.grow_now);
        let e = 0, t = 0, i = this._waterData.node_list.length;
        for (let a = i - 1; a >= 0; a--) {
            if (a > 0) {
                if (this._waterData.grow_old >= this._waterData.node_list[a - 1].grow) {
                    t = (this._waterData.node_list[a].grow - this._waterData.node_list[a - 1].grow) / 50;
                    e = ((this._waterData.grow_old - this._waterData.node_list[a - 1].grow) / (this._waterData.node_list[a].grow - this._waterData.node_list[a - 1].grow) + a) / i;
                    break;
                }
            }
            else {
                t = this._waterData.node_list[0].grow / 50;
                e = this._waterData.grow_old / this._waterData.node_list[0].grow / i;
            }
        }
        this.waterNode.getChildByName("ProgressBar").getComponent(ProgressBar).progress = e;
        this.waterNode.getChildByName("progressAnim").active || (this.waterNode.getChildByName("progressAnim").active = true);
        let a = this.waterNode.getChildByName("ProgressBar").getComponent(UITransform).contentSize.width;
        this.waterNode.getChildByName("progressAnim").setPosition(v3(a * e - a / 2, -320));
        this.waterNode.getChildByName("grow").setPosition(v3(a * e - a / 2, -277));
        this.waterNode.getChildByName("grow").getChildByName("num").getComponent(Label).string = String(Math.floor(Number(this._waterData.grow_old)));
        this.waterNode.getChildByName("grow").getChildByName("num").getComponent(Label).updateRenderData(true);
        let o = this.waterNode.getChildByName("grow").getChildByName("num").getComponent(UITransform).contentSize.width, r = o > 20 ? o : 20;
        this.waterNode.getChildByName("grow").getComponent(UITransform).setContentSize(size(r + 30, 32));
        for (let e = 0; e < i + 1; e++) {
            let t = this.waterNode.getChildByName("giftNode").getChildByName(ToolUtils.format("gift${0}", e));
            if (ToolUtils.isObjValid(t)) {
                if (e > 0) {
                    let i = this._waterData.node_list[e - 1];
                    if (0 == i.complete && this._waterData.grow_old >= i.grow) {
                        this._hasReward = true;
                        this._rewardIndex += 1;
                        i.complete = 1;
                        t.getChildByName("icon").active = false;
                        t.getChildByName("anim").active = true;
                        t.getChildByName("anim").getComponent(sp.Skeleton).clearTracks();
                        t.getChildByName("anim").getComponent(sp.Skeleton).setAnimation(0, "gift", false);
                        t.getChildByName("num").getComponent(UIOpacity).opacity = 153;
                        t.getChildByName("anim").getComponent(sp.Skeleton).setCompleteListener((() => {
                            ToolUtils.isObjValid(t) && (t.getChildByName("anim").active = false, t.getChildByName("icon").active = true, t.getChildByName("icon").getComponent(Sprite).spriteFrame = this.giftSpriteFrame[1]);
                        }));
                        this.playTreeAnim(this._waterData.sid, i.node);
                        this.playLightAnim("watering2");
                        this.playRewardDropAnim(i.reward, this._rewardIndex);
                        SoundManager.shared().playFx("forest_upgrade");
                        this._hasReward && PushCenter.shared().pushEvent(PushEvent.RefreshWallet);
                    }
                    else if (t.getChildByName("icon").active) {
                        let e = 1 == i.complete ? 1 : 0;
                        t.getChildByName("icon").getComponent(Sprite).spriteFrame = this.giftSpriteFrame[e];
                    }
                }
                else {
                    t.getChildByName("icon").active = false;
                    t.getChildByName("anim").active = false;
                    t.getChildByName("num").getComponent(UIOpacity).opacity = 153;
                }
            }
        }
        if (this._waterData.grow_old >= this._waterData.grow_now) {
            this._waterData.grow_old = this._waterData.grow_now;
            this.waterNode.getChildByName("progressAnim").active = false;
            TweenTool.stopAction(this._scheduleProgress);
            let e = 0.5 * this._rewardCount + 3 + 1.5;
            this._hasReward || (e = 3, this.playTreeAnim(this._waterData.sid), this.playLightAnim("watering1"), SoundManager.shared().playFx("forest_growup"));
            TweenTool.delayAct(this.waterNode, (() => {
                if (ToolUtils.isObjValid(this.waterNode)) {
                    this.waterNode.getChildByName("drop_node").removeAllChildren();
                    this.waterNode.active = false;
                    this.requestBonusForestPage();
                }
            }), e, true);
        }
        this._waterData.grow_old += t;
    }
    playTreeAnim(e, t) {
        if (sys.isObjectValid(t)) {
            let i = TweenTool.scaleTo(this.waterNode.getChildByName("tree"), 0.1, v3(1, 0.8, 1), null, false, (() => {
                Utils.shared().setImage(this.waterNode.getChildByName("tree"), ToolUtils.format("tree${0}_${1}", e, t), this.forestTreeAtlas);
            })), a = TweenTool.scaleTo(this.waterNode.getChildByName("tree"), 4 / 30, v3(1, 1.06, 1), null, false), o = TweenTool.scaleTo(this.waterNode.getChildByName("tree"), 4 / 30, v3(1, 0.98, 1), null, false), s = TweenTool.scaleTo(this.waterNode.getChildByName("tree"), 5 / 30, v3(1, 1.02, 1), null, false), r = TweenTool.scaleTo(this.waterNode.getChildByName("tree"), 0.2, v3(1, 1, 1), null, false);
            TweenTool.sequence(this.waterNode.getChildByName("tree"), true, null, i, a, o, s, r);
        }
        else {
            let e = TweenTool.scaleTo(this.waterNode.getChildByName("tree"), 0.1, v3(1, 0.8, 1), null, false), t = TweenTool.scaleTo(this.waterNode.getChildByName("tree"), 4 / 30, v3(1, 1.02, 1), null, false), i = TweenTool.scaleTo(this.waterNode.getChildByName("tree"), 4 / 30, v3(1, 0.99, 1), null, false), a = TweenTool.scaleTo(this.waterNode.getChildByName("tree"), 5 / 30, v3(1, 1.01, 1), null, false), o = TweenTool.scaleTo(this.waterNode.getChildByName("tree"), 0.2, v3(1, 1, 1), null, false);
            TweenTool.sequence(this.waterNode.getChildByName("tree"), true, null, e, t, i, a, o);
        }
    }
    playLightAnim(e) {
        this.waterNode.getChildByName("lightAnim").active = true;
        this.waterNode.getChildByName("lightAnim").getComponent(sp.Skeleton).clearTracks();
        this.waterNode.getChildByName("lightAnim").getComponent(sp.Skeleton).setAnimation(0, e, false);
        this.waterNode.getChildByName("lightAnim").getComponent(sp.Skeleton).setCompleteListener((() => {
            ToolUtils.isObjValid(this.waterNode) && (this.waterNode.getChildByName("lightAnim").active = true);
        }));
    }
    playRewardDropAnim(e, t) {
        if (sys.isObjectValid(e) && e.length > 0) {
            let i = this.waterNode.getChildByName("drop_node"), a = this.waterNode.getChildByName("reward_moban");
            a.active = false;
            for (let o = 0, s = e.length; o < s; o++) {
                let r = 120 * o - 60 * (s - 1) + ToolUtils.getRandomInt(1, 120) - 60, l = 230 + ToolUtils.getRandomInt(0, 80) - 40, h = instantiate(a);
                h.name = "" + o;
                h.active = true;
                h.setPosition(v3(r, l));
                i.addChild(h);
                let d = this.rewardSpriteFrame[e[o].type], u = v3(0.6, 0.6), C = v3(0, -2);
                0 != e[o].type && 1 != e[o].type && (d = this.rewardSpriteFrame[2], u = v3(0.75, 0.75), C = v3(0, 2));
                h.getChildByName("icon").getComponent(Sprite).spriteFrame = d;
                h.getChildByName("icon").setScale(u);
                h.getChildByName("icon").setPosition(C);
                h.getChildByName("num").getComponent(Label).string = ToolUtils.format("x${0}", e[o].amt);
                sys.isObjectValid(e[o].ext) && sys.isObjectValid(e[o].ext.ratio) ? (h.getChildByName("ratio").active = true, h.getChildByName("ratio").getComponent(Label).string = ToolUtils.format("${0}%", e[o].ext.ratio)) : h.getChildByName("ratio").active = false;
                h.setScale(v3(0, 0));
                let N = TweenTool.scaleTo(h, 5 / 30, v3(1.2, 1.2), null, false), w = TweenTool.scaleTo(h, 10 / 30, v3(1, 1), null, false), p = TweenTool.delayAct(h, null, 20 / 30, false), _ = TweenTool.moveTo(h, 10 / 30, v3(r, 0), null, false), y = TweenTool.moveTo(h, 4 / 30, v3(r, 8), null, false), b = TweenTool.moveTo(h, 0.1, v3(r, 0), null, false), f = TweenTool.delayAct(h, null, 1.5 * (this._rewardCount - t) + (15 * t + 5 * (o - 1)) / 30, false), v = TweenTool.moveTo(h, 0.5, v3(0, 437), null, false);
                TweenTool.sequence(h, true, (t => {
                    if (ToolUtils.isObjValid(t)) {
                        t.active = false;
                        let i = false, a = Number(t.name);
                        for (let t = 0, o = this._waterData.before.length; t < o; t++) {
                            this._waterData.before[t].type == e[a].type && (0 == e[a].type || 1 == e[a].type || this._waterData.before[t].ext.coupon_id == e[a].ext.coupon_id) && (i = true, this._waterData.before[t].new = 1, this._waterData.before[t].amt += e[a].amt);
                        }
                        i || (sys.isObjectValid(this._waterData.before) || (this._waterData.before = []), e[a].new = 1, this._waterData.before.push(e[a]));
                        this.refreshObtainedView(this._waterData.before);
                        SoundManager.shared().playFx("forest_reward");
                    }
                }), N, w, p, _, y, b, f, v);
            }
        }
    }
    refreshObtainedView(e) {
        let t = this.waterNode.getChildByName("obtained");
        t.getChildByName("reward").removeAllChildren();
        let i = t.getChildByName("moban");
        if (i.active = false, sys.isObjectValid(e) && e.length > 0) {
            t.active = true;
            for (let a = 0, o = e.length; a < o; a++) {
                let o = instantiate(i);
                o.active = true;
                o.setPosition(v3(0, 0));
                let r = this.rewardSpriteFrame[e[a].type], l = v3(0.86, 0.86);
                0 != e[a].type && 1 != e[a].type && (r = this.rewardSpriteFrame[2], l = v3(1, 1));
                o.getChildByName("icon").getComponent(Sprite).spriteFrame = r;
                o.getChildByName("icon").setScale(l);
                o.getChildByName("name").getComponent(Label).string = e[a].desc;
                o.getChildByName("num").getComponent(Label).string = e[a].amt;
                o.getChildByName("anim").active = 1 == e[a].new;
                1 == e[a].new && (o.getChildByName("anim").getComponent(sp.Skeleton).clearTracks(), o.getChildByName("anim").getComponent(sp.Skeleton).setToSetupPose(), o.getChildByName("anim").getComponent(sp.Skeleton).setAnimation(0, "flash", false), e[a].new = 0);
                sys.isObjectValid(e[a].ext) && sys.isObjectValid(e[a].ext.ratio) ? (o.getChildByName("ratio").active = true, o.getChildByName("ratio").getComponent(Label).string = ToolUtils.format("${0}%", e[a].ext.ratio)) : o.getChildByName("ratio").active = false;
                t.getChildByName("reward").addChild(o);
            }
        }
        else {
            t.active = false;
        }
    }
    onPriceClick(e, t, i = true) {
        i && SoundManager.shared().playFx("click");
        for (let e = 0; e < 4; e++) {
            let i = this.rechargeNode.getChildByName("bgView").getChildByName("price" + e);
            if (Number(t) == e) {
                let t = User.shared().bonusForestData.good[e];
                this._price = t;
                i.getComponent(Sprite).color = color(72, 113, 231);
                i.getChildByName("num").getComponent(Label).color = color(76, 113, 230);
            }
            else {
                i.getComponent(Sprite).color = color(255, 255, 255);
                i.getChildByName("num").getComponent(Label).color = color(75, 75, 75);
            }
        }
    }
    onButtonClick(e, t) {
        if (SoundManager.shared().playFx("click"), !(sys.now() - this._lastClick < 500)) {
            if (this._lastClick = sys.now(), "close" == t) {
                this.onBackView();
            }
            else if ("help" == t) {
                ToolUtils.isObjValid(this.ruleNode) && (this.ruleNode.active = true, this.startShowAnim(this.ruleNode.getChildByName("bg")), sys.isObjectValid(User.shared().bonusForestData) && (this.ruleLabel.string = User.shared().bonusForestData.rule));
            }
            else if ("watering" == t) {
                Utils.shared().showLoading(10, true, (() => {
                    Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
                }));
                HttpManager.shared().doGetCommonRequest(null, HttpRequest.bonusForestGetReward, this.listenBonusForestGetRewardCallBack.bind(this));
            }
            else if ("recharge" == t) {
                if (!User.shared().checkCanRecharge()) {
                    return void (ToolUtils.isObjValid(this.node) && this.onBackView());
                }
                this.rechargeNode.active = true;
                this.startShowAnim(this.rechargeNode.getChildByName("bgView"));
                this.onPriceClick(null, "0", false);
                HttpManager.shared().doCommReportRechargeEvent(ReportConfig.Cmd_BonusForest, this._scene, 5, this._linkId, null, 0);
            }
            else if ("addcash" == t) {
                let e = sys.now();
                this._bCanSend && HttpManager.shared().doCommReportRechargeEvent(ReportConfig.Cmd_BonusForest, this._scene, 6, this._linkId, { price: Number(this._price) }, 0, e);
                let t = { pway: User.shared().bonusForestData.pways + "", price: Number(this._price), act_id: PushEvent.JUMP_TO_BonusForest };
                this._bCanSend && (t.link_id = this._linkId, t.event = 6, t.client_time = e);
                User.shared().startPay(t);
                this.rechargeNode.active = false;
            }
            else if ("amount" == t) {
                if (User.shared().b_storeLevel) {
                    this.rechargeNode.active = false;
                    PushCenter.shared().pushEvent(PushEvent.showStoreRecharge);
                    this.onBackView();
                }
                else {
                    this.rechargeNode.active = false;
                    let e = { act_id: PushEvent.JUMP_TO_BonusForest }, t = sys.now();
                    this._bCanSend && (e.link_id = this._linkId, e.client_time = t);
                    Utils.shared().showStoreView(e);
                }
                HttpManager.shared().doCommReportRechargeEvent(ReportConfig.Cmd_BonusForest, this._scene, 7, this._linkId, null, 0);
            }
        }
    }
    listenBonusForestGetRewardCallBack(e, t, i) {
        if (Utils.shared().hideLoading(), 200 != i) {
            alert("The login timed out, please try again");
        }
        else {
            try {
                let e = ToolUtils.parseJson(t);
                0 == e.ret && ToolUtils.isObjValid(this.node) && (this.waterNode.active = true, this.waterNode.getComponent(UIOpacity).opacity = 0, TweenTool.moveToByFade(this.waterNode, 10 / 30, v3(0, 0, 0), 0, 1, true, (() => {
                    this.waterNode.getComponent(UIOpacity).opacity = 255;
                })), this._waterData = e.data, this.refreshWaterView());
            }
            catch (e) {
            }
        }
    }
    onBackView() {
        if (ToolUtils.isObjValid(this.node)) {
            if (this.waterNode.active) {
                this.waterNode.active = false;
            }
            else if (this.rechargeNode.active) {
                this.rechargeNode.active = false;
            }
            else if (this.ruleNode.active) {
                this.ruleNode.active = false;
            }
            else {
                if (this._has_close) {
                    return;
                }
                let e = { alert_node: this.node, rootNode: this.rootNode, isNext: this.isNext, pop_type: PushEvent.JUMP_TO_BonusForest, pop_souce: this._pop_souce };
                Utils.shared().closeActivityView(e);
                this._has_close = true;
                User.shared().getHallInfo();
                this._callback && this._callback();
            }
        }
    }
}
