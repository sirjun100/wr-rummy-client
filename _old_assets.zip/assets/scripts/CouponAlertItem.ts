// @ts-nocheck
// Recovered from index.js:81
import { _decorator, Component, color, Label, Node, Size, Sprite, SpriteFrame, sys, UITransform, Vec3 } from "cc";
import i18nMgr from "./i18nMgr";
import Utils from "./Utils";
import User from "./User";
import PushCenter from "./PushCenter";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("CouponAlertItem")
export class CouponAlertItem extends Component {
    @property(Sprite)
    public seletctImg: Sprite = null;
    @property(Sprite)
    public clubIcon: Sprite = null;
    @property(Sprite)
    public couponImg: Sprite = null;
    @property(Node)
    public tagTxt: Node = null;
    @property([SpriteFrame])
    public coupons: SpriteFrame[] = [];
    @property([SpriteFrame])
    public disCoupons: SpriteFrame[] = [];
    @property(Label)
    public numLabel: Label = null;
    @property(Label)
    public danweiLabel: Label = null;
    @property(Label)
    public typeLabel: Label = null;
    @property(Label)
    public contentLabel: Label = null;
    @property(Label)
    public contentLabel2: Label = null;
    @property(Label)
    public dateLabel: Label = null;
    @property([SpriteFrame])
    public selectImags: SpriteFrame[] = [];
    @property([SpriteFrame])
    public clubIconFrames: SpriteFrame[] = [];
    @property(Node)
    public flagDiNode: Node = null;
    public itemIndex: number = 0;
    public itemId: any = -1;
    public callback: any = null;
    public callback2: any = null;
    public select: number = 0;
    public bIsAvailable: boolean = true;
    public target_surl: string = "";
    start() {
    }
    buttonClick(e, t) {
        this.callback && this.callback(this.itemIndex);
    }
    onJumpBtnClick(e, t) {
        this.callback2 && this.callback2(this.itemId, t);
    }
    updateUI(e, t, i, n, a, s) {
        this.callback = a;
        this.callback2 = s;
        this.bIsAvailable = n;
        let r = (e.content || "").split("|");
        if (ToolUtils.isSafeString(r[0]) && (this.contentLabel.string = ToolUtils.isSafeString(r[0])), ToolUtils.isSafeString(r[1]) && (this.contentLabel2.string = ToolUtils.isSafeString(r[1]), this.contentLabel2.node.active = true), sys.isObjectValid(e.real_ratio) ? this.numLabel.string = "" + e.real_ratio : this.numLabel.string = "" + e.ratio, this.dateLabel.string = "" + e.expire, this.bIsAvailable) {
            this.select = i;
            this.itemIndex = t;
            this.itemId = e.coupon_id;
            this.refreshSelect(i);
            1 === Number(e.type) ? (this.typeLabel.string = i18nMgr.shared().getValueByKey("store.bonus").toUpperCase(), i18nMgr.shared().changeLabelFont(this.typeLabel, true)) : 2 === Number(e.type) && (this.typeLabel.string = i18nMgr.shared().getValueByKey("store.cash").toUpperCase(), i18nMgr.shared().changeLabelFont(this.typeLabel, true));
            let n = ToolUtils.isSafeNumber(e.color);
            if (n >= 0 && n <= 4 && (this.couponImg.spriteFrame = this.coupons[n]), 1 == Number(e.src_type) && sys.isObjectValid(e.club)) {
                let t = User.shared().getGradeByMemberShipLevel(e.club);
                t > 0 && t <= 9 && (this.clubIcon.spriteFrame = this.clubIconFrames[t - 1], this.clubIcon.node.active = true);
            }
            if (3 == n ? (this.numLabel.color = color(255, 255, 0, 255), this.danweiLabel.color = color(255, 255, 0, 255), this.typeLabel.color = color(255, 255, 0, 255)) : (this.numLabel.color = color(255, 255, 255, 255), this.danweiLabel.color = color(255, 255, 255, 255), this.typeLabel.color = color(255, 255, 255, 255)), this.tagTxt.active = false, this.flagDiNode.active = false, ToolUtils.isSafeString(e.src_bimg).length > 0) {
                this.target_surl = e.src_bimg;
                Utils.shared().updateNetImage(this.couponImg, ToolUtils.isSafeString(e.src_bimg), new Size(672, 190), (() => {
                }));
                let t = ToolUtils.isSafeString(e.src_color);
                t.length > 0 && (this.numLabel.color = Utils.stringToColor(t), this.danweiLabel.color = Utils.stringToColor(t), this.typeLabel.color = Utils.stringToColor(t));
            }
        }
        else {
            if (this.seletctImg.node.active = false, 1 === Number(e.type) ? i18nMgr.shared().changeLabelLanguage(this.typeLabel, "store.bonus") : 2 === Number(e.type) && i18nMgr.shared().changeLabelLanguage(this.typeLabel, "store.cash"), 2 === Number(e.use_type) ? (i18nMgr.shared().changeLabelLanguage(this.tagTxt.getComponent(Label), "store.used"), 1 === i18nMgr.shared().language ? i18nMgr.shared().changeLabelFontSize(this.tagTxt.getComponent(Label), 20) : i18nMgr.shared().changeLabelFontSize(this.tagTxt.getComponent(Label), 24)) : 3 === Number(e.use_type) ? (i18nMgr.shared().changeLabelLanguage(this.tagTxt.getComponent(Label), "store.expired"), i18nMgr.shared().changeLabelFontSize(this.tagTxt.getComponent(Label), 24)) : 4 === Number(e.use_type) && (i18nMgr.shared().changeLabelLanguage(this.tagTxt.getComponent(Label), "store.invalid"), i18nMgr.shared().changeLabelFontSize(this.tagTxt.getComponent(Label), 24)), this.couponImg.spriteFrame = this.disCoupons[0], 1 == Number(e.src_type) && sys.isObjectValid(e.club)) {
                let t = User.shared().getGradeByMemberShipLevel(e.club);
                t > 0 && t <= 9 && (this.clubIcon.spriteFrame = this.clubIconFrames[t - 1], this.clubIcon.node.active = true);
            }
            this.tagTxt.active = true;
            this.flagDiNode.active = true;
        }
        this.refreshNumPosition();
    }
    refreshNumPosition() {
        this.numLabel.updateRenderData(true);
        let e = (this.numLabel.node.getComponent(UITransform).width - 70.16) / 2;
        this.numLabel.node.setPosition(new Vec3(-214 + e, 22));
        this.danweiLabel.node.setPosition(new Vec3(-216 + e, 9));
    }
    refreshSelect(e) {
        this.bIsAvailable && (1 === e ? (this.seletctImg.spriteFrame = this.selectImags[1], this.seletctImg.color = color(255, 255, 255, 255)) : (this.seletctImg.spriteFrame = this.selectImags[0], this.seletctImg.color = color(0, 0, 0, 51)), this.seletctImg.node.active = true);
    }
    onDestroy() {
        PushCenter.shared().removeListenersByTag(this);
    }
}
