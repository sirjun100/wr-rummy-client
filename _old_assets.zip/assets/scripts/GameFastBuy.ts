// @ts-nocheck
// Recovered from index.js:153
import { _decorator, Label, Node, Sprite, SpriteFrame, sys, v3 } from "cc";
import SoundManager from "./SoundManager";
import Utils from "./Utils";
import User from "./User";
import PushCenter from "./PushCenter";
import PushEvent from "./PushEvent";
import GameConfig from "./GameConfig";
import BaseLayer from "./BaseLayer";
import { HttpRequest } from "./HttpRequestName";
import Server from "./Server";
import RummyCmd from "./RummyCmd";
import { ToolUtils } from "./ToolUtils";
import i18nMgr from "./i18nMgr";
const { ccclass, property } = _decorator;
@ccclass("GameFastBuy")
export default class GameFastBuy extends BaseLayer {
    @property(Node)
    public rootNode: Node = null;
    @property([SpriteFrame])
    public icon_imgs: SpriteFrame[] = [];
    @property([SpriteFrame])
    public tab_imgs: SpriteFrame[] = [];
    public dataPara: any = null;
    public curRoomId: number = 0;
    public match_vid: number = 0;
    public _inRoom: number = 0;
    public isquick: boolean = false;
    public type: any = undefined;
    public shop_type: number = 1;
    public checkKyc: number = 0;
    public auto_quick: number = 0;
    public _curTabIndex: number = 0;
    public _mPara: any[] = [];
    public _linkId: number = 0;
    public TAG: string = "GameCommRecharge";
    onLoad() {
    }
    start() {
        super.start();
        ToolUtils.startShowAnim(this.node.getChildByName("rootNode"));
        PushCenter.shared().pushEvent(PushEvent.HideGameOverBg);
        SoundManager.shared().playFx("act_popshow");
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().pushEvent(PushEvent.ShowGameOverBg);
        PushCenter.shared().removeListenersByTag(this);
        this.unscheduleAllCallbacks();
    }
    initView(t) {
        let e = this.node.getChildByName("bg");
        if (ToolUtils.showFullScreen(e), PushCenter.shared().addListener(GameConfig.Recharge, (t => {
            ToolUtils.isObjValid(this.node) && this.node.destroy();
            101 == this.type && PushCenter.shared().pushEvent(PushEvent.UpdateBonusGiftStatus, 0);
        }), this), sys.isObjectValid(t) && (this._mPara = t, sys.isObjectValid(t.ext) && (this.dataPara = t.ext, this.type = t.type), sys.isObjectValid(t.isquick) && (this.isquick = t.isquick), sys.isObjectValid(t.inRoom) && (this._inRoom = t.inRoom), sys.isObjectValid(t.checkKyc) && (this.checkKyc = t.checkKyc), sys.isObjectValid(t.tid_key) && (this.tid_key = t.tid_key), sys.isObjectValid(t.auto_quick) && (this.auto_quick = t.auto_quick)), this.showNodeAnim(t.vid, t.isShowTip, t.tid_key), sys.isObjectValid(this.dataPara)) {
            if (sys.isObjectValid(this.dataPara.shop_type) && (this.shop_type = Number(this.dataPara.shop_type)), sys.isObjectValid(this.dataPara.curTab) && (this._curTabIndex = Number(this.dataPara.curTab)), sys.isObjectValid(this.dataPara) && sys.isObjectValid(this.dataPara.good_list) && Array.isArray(this.dataPara.good_list) && 3 == this.dataPara.good_list.length) {
                for (let t = 0; t < 3; t++) {
                    let e = this.rootNode.getChildByName("tab" + t), i = this.dataPara.good_list[t];
                    sys.isObjectValid(i.money) && String(i.money).length > 0 && (e.getChildByName("price").getComponent(Label).string = `₹${i.money}`);
                    sys.isObjectValid(i.rate) && String(i.rate).length > 0 && (e.getChildByName("percent").getComponent(Label).string = `+${i.rate}`);
                }
            }
            this.updateTabContent();
        }
    }
    updateGoodItemView(t, e) {
        if (sys.isObjectValid(e)) {
            if (e.active = true, sys.isObjectValid(t.type)) {
                let i = Number(t.type);
                7 == i && (i = 2);
                e.getChildByName("icon").getComponent(Sprite).spriteFrame = this.icon_imgs[i];
            }
            sys.isObjectValid(t.nums) && String(t.nums).length > 0 && (e.getChildByName("num").getComponent(Label).string = String(t.nums));
        }
    }
    updateTabContent() {
        for (let t = 0; t < 3; t++) {
            let e = this.rootNode.getChildByName("tab" + t);
            t == this._curTabIndex ? (e.getChildByName("ico").getComponent(Sprite).spriteFrame = this.tab_imgs[1], e.getChildByName("ico").scale = v3(1, 1), e.getChildByName("ico").setPosition(v3(8, -64.794)), e.getChildByName("price").getComponent(Label).fontSize = 68, e.getChildByName("price").getComponent(Label).lineHeight = 70, e.getChildByName("price").setPosition(v3(0, 9))) : (e.getChildByName("ico").getComponent(Sprite).spriteFrame = this.tab_imgs[0], e.getChildByName("ico").scale = v3(0.9, 0.9), e.getChildByName("ico").setPosition(v3(0, -65.176)), e.getChildByName("price").getComponent(Label).fontSize = 64, e.getChildByName("price").getComponent(Label).lineHeight = 68, e.getChildByName("price").setPosition(v3(0, 3)));
        }
        if (sys.isObjectValid(this.dataPara) && sys.isObjectValid(this.dataPara.good_list) && Array.isArray(this.dataPara.good_list) && 3 == this.dataPara.good_list.length) {
            let t = this.dataPara.good_list[this._curTabIndex];
            if (sys.isObjectValid(t.money) && String(t.money).length > 0 && (this.rootNode.getChildByName("ok_btn").getChildByName("wz").getComponent(Label).string = "₹" + String(t.money)), sys.isObjectValid(t.reward_list) && Array.isArray(t.reward_list) && t.reward_list.length > 0) {
                this.rootNode.getChildByName("content").getChildByName("item0").active = false;
                this.rootNode.getChildByName("content").getChildByName("item1").active = false;
                for (let e = 0; e < t.reward_list.length; e++) {
                    this.updateGoodItemView(t.reward_list[e], this.rootNode.getChildByName("content").getChildByName("item" + e));
                }
            }
            sys.isObjectValid(t.rate) && String(t.rate).length > 0 && (this.rootNode.getChildByName("ok_btn").getChildByName("flag").getChildByName("Label").getComponent(Label).string = `${t.rate}`);
        }
    }
    showNodeAnim(t, e, i, a = 0) {
        this.curRoomId = t;
        this.tid_key = i;
        i && i.length > 0 && (this.bIsInGame = true);
        this.startShowAnim(this.rootNode);
    }
    onclickByClose(t, e) {
        SoundManager.shared().playFx("click");
        101 == this.type && PushCenter.shared().pushEvent(PushEvent.UpdateBonusGiftStatus, 0);
        1 != Utils.shared().checkPopRestartGift(this._mPara) ? (1 == this.checkKyc && Utils.shared().checkAddCashKyc(), ToolUtils.isObjValid(this.node) && this.node.destroy()) : ToolUtils.isObjValid(this.node) && this.node.destroy();
    }
    touchTabEvent(t, e) {
        SoundManager.shared().playFx("click");
        let i = Number(e);
        i != this._curTabIndex && (this._curTabIndex = i, this.updateTabContent());
    }
    touchAddCashEvent(t, e) {
        if (SoundManager.shared().playFx("click"), ToolUtils.isObjValid(this.node)) {
            if (!User.shared().checkCanRecharge()) {
                return 101 == this.type && PushCenter.shared().pushEvent(PushEvent.UpdateBonusGiftStatus, 0), void (ToolUtils.isObjValid(this.node) && this.node.destroy());
            }
            let t = null;
            if (!(sys.isObjectValid(this.dataPara) && sys.isObjectValid(this.dataPara.good_list) && Array.isArray(this.dataPara.good_list) && 3 == this.dataPara.good_list.length)) {
                return;
            }
            t = this.dataPara.good_list[this._curTabIndex];
            let e = { goodsId: t.goods_id + "", tid_key: this.type == PushEvent.JUMP_TO_Treasure ? this.dataPara.reportRechargePara.tid_key : this.tid_key, act_id: this.type == PushEvent.JUMP_TO_Treasure ? PushEvent.JUMP_TO_Treasure : this.type, link_id: this.type == PushEvent.JUMP_TO_Treasure ? this.dataPara.reportRechargePara.link_id : this._linkId, inRoom: this._inRoom, price: t.money };
            if (2 == this.shop_type) {
                if (User.shared().checkFirstChipClick()) {
                    let t = { bLandscape: ToolUtils.getIsNormalDirection(), bWithCancel: true, strContent: i18nMgr.shared().getValueByKey("store.chip_charge_tip"), strTitle: i18nMgr.shared().getValueByKey("store.chip_charge_title"), sureKey: "store.chip_confirm", cancelKey: "reward_tips.cancel", dialogType: 0, closeType: 1 };
                    Utils.shared().showCommonAlert(t, (t => {
                        1 == t && User.shared().startOrder(HttpRequest.CommChipPay, e);
                    }), false);
                }
                else {
                    User.shared().startOrder(HttpRequest.CommChipPay, e);
                }
                this.node.destroy();
            }
            else {
                User.shared().startPay(e, 0, (() => {
                    1 == this.auto_quick && Server.shared().send({ cmd: RummyCmd.CLIENT_NOTIFY_CLICK_RECHARGE, tid_key: this.tid_key, uid: User.shared().data.uid });
                }));
            }
        }
    }
    onBackView() {
        0 == this.bIsInGame && (SoundManager.shared().playFx("click"), ToolUtils.isObjValid(this.node) && this.node.destroy());
    }
}
