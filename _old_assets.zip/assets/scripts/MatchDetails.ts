// @ts-nocheck
// Recovered from index.js:297
import { _decorator, Button, color, instantiate, Label, Node, ScrollView, size, Sprite, SpriteAtlas, SpriteFrame, sys, UITransform, v3, Vec3, view } from "cc";
import PushCenter from "./PushCenter";
import TweenTool from "./TweenTool";
import Utils from "./Utils";
import GameConfig from "./GameConfig";
import SoundManager from "./SoundManager";
import i18nMgr from "./i18nMgr";
import BaseLayer from "./BaseLayer";
import PushEvent from "./PushEvent";
import RummyCmd from "./RummyCmd";
import User from "./User";
import Server from "./Server";
import TableViewUtils from "./TableViewUtils";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("MatchDetails")
export class MatchDetails extends BaseLayer {
    @property([Node])
    public switchBtn: Node[] = [];
    @property([SpriteFrame])
    public topbgFrame: SpriteFrame[] = [];
    @property([SpriteFrame])
    public rankFrame: SpriteFrame[] = [];
    @property([SpriteFrame])
    public btnStateFrame: SpriteFrame[] = [];
    @property(Sprite)
    public topbg: Sprite = null;
    @property(Label)
    public title: Label = null;
    @property(Node)
    public top_info: Node = null;
    @property(Node)
    public overViewTips: Node = null;
    @property(Node)
    public prizesTips: Node = null;
    @property(Node)
    public overView: Node = null;
    @property(Node)
    public prizesView: Node = null;
    @property(Node)
    public rankView: Node = null;
    @property(Node)
    public top_root0: Node = null;
    @property(Node)
    public top_root1: Node = null;
    @property(Node)
    public overView1: Node = null;
    @property(Node)
    public detailReward: Node = null;
    @property([Node])
    public pointsTabBtn: Node[] = [];
    @property([SpriteFrame])
    public ticket_images: SpriteFrame[] = [];
    @property(Node)
    public ticket_tipNode: Node = null;
    @property(Node)
    public helpBtn1Node: Node = null;
    @property(Node)
    public helpBtn2Node: Node = null;
    @property(Node)
    public helpBtn3Node: Node = null;
    @property(Node)
    public prizes_rewardNode: Node = null;
    @property(SpriteAtlas)
    public rewardAtlas: SpriteAtlas = null;
    @property(Node)
    public newOverViewView: Node = null;
    @property(Node)
    public newLevelList: Node = null;
    @property(Node)
    public rejoinNode: Node = null;
    @property(Node)
    public rejoinList: Node = null;
    @property(Node)
    public lateJoinNode: Node = null;
    @property(Node)
    public lateJoinList: Node = null;
    @property(Node)
    public newRewardView: Node = null;
    @property(Node)
    public newRewardList: Node = null;
    @property(Node)
    public newFinalView: Node = null;
    @property(Node)
    public newFinalList: Node = null;
    public rewardNames: any[] = ["reward_watch.png"];
    public raceinfo: any = null;
    public cb: any = null;
    public comingTime: number = 0;
    public time_schedule: number = 0;
    public raceBtnStatus: any[] = ["tournament.upcoming", "tournament.join_now", "tournament.withdraw", "tournament.full", "tournament.enter", "tournament.eliminated2", "tournament.running", "tournament.completed", "tournament.rejoin2", "tournament.late_registing2", "tournament.late_join2", "tournament.early_seating2"];
    public prizeItems: any[] = [];
    public reward_list_hei: number = 214;
    public level_list_hei: number = 260;
    public reward_tips: any = null;
    public overview_tips: any = null;
    public rewardTableView: any = null;
    public finalTableView: any = null;
    public _from_source: number = 0;
    public _curIdx: number = 0;
    public bInitNewLevelList: boolean = false;
    public RegisterButtonStatus: any = { UPCOMING: 0, JOINNOW: 1, WITHDRAW: 2, FULL: 3, ENTER: 4, ELIMINATED: 5, RUNNING: 6, COMPLETED: 7, REJOIN: 8, LATEREGISTER: 9, LATE_JOIN: 10, EARLY_SEATING: 11 };
    public tab_select_color: any = color(147, 11, 11);
    onLoad() {
        this.fitLuckyTheme();
    }
    fitLuckyTheme() {
        if (0 == GameConfig.NATIVE_GAME_APP_TYPE) {
            return;
        }
        this.tab_select_color = color(221, 3, 3);
        this.topbg.getComponent(Sprite).color = color(12, 26, 60);
        let e = this.top_info.getChildByName("top_root0");
        e.getChildByName("bg").getComponent(Sprite).color = color(250, 250, 250, 255);
        e.getChildByName("overview_btn").getChildByName("line").getComponent(Sprite).color = color(221, 3, 3, 255);
        e.getChildByName("prizes_btn").getChildByName("line").getComponent(Sprite).color = color(221, 3, 3, 255);
        e.getChildByName("rank_btn").getChildByName("line").getComponent(Sprite).color = color(221, 3, 3, 255);
        let t = this.top_info.getChildByName("top_root1");
        t.getChildByName("overview_btn").getChildByName("line").getComponent(Sprite).color = color(221, 3, 3, 255);
        t.getChildByName("prizes_btn").getChildByName("line").getComponent(Sprite).color = color(221, 3, 3, 255);
    }
    start() {
        super.start();
        this.fitScreen();
        this.initView();
        PushCenter.shared().addListener(GameConfig.UpdateRaceJoined, (e => {
            this.raceinfo && this.raceinfo.raceid == e.raceid && (this.raceinfo.num = e.num, this.updateOverView(), null != e.reward_value && null != e.reward_value && (this.raceinfo.reward_value = e.reward_value));
        }), this);
        PushCenter.shared().addListener(GameConfig.UpdateRaceBtnStatus, (e => {
            this.raceinfo && this.raceinfo.raceid == e.raceid && (this.raceinfo.btn_status = e.btn_status, this.updateStatusBtn(), this.updateOverView());
        }), this);
        PushCenter.shared().addListener(PushEvent.RefreshRacePointsRewardList, (e => {
            this.raceinfo && this.raceinfo.raceid == e.raceid && (0 == this.raceinfo.mode || 1 == this.raceinfo.mode ? this.updateFinalView(e) : 3 == this.raceinfo.mode && this.refreshPointsRewardList(e));
        }), this);
        1 == this._from_source && this.scheduleOnce((() => {
            ToolUtils.isObjValid(this.node) && Utils.shared().doJumpLogic(PushEvent.JUMP_TO_MATCH_ROOM);
        }));
        this.time_schedule = TweenTool.myschedule(this.node, 1, this.onUpdateRaceTime.bind(this));
    }
    setParaData(e) {
        let t = e.msg;
        this.raceinfo = t.race_info;
        this.overview_tips = t.tips;
        this.cb = e.func;
        sys.isObjectValid(t) && sys.isObjectValid(t.from_source) && (this._from_source = t.from_source);
        sys.isObjectValid(e.showIdx) && Number(e.showIdx) >= 0 && Number(e.showIdx) <= 2 && (this._curIdx = Number(e.showIdx));
    }
    initView() {
        if (this.raceinfo && sys.isObjectValid(this.raceinfo.mode)) {
            if (0 == this.raceinfo.mode || 1 == this.raceinfo.mode) {
                this.top_root0.active = true;
                this.top_root1.active = false;
                this.newOverViewView.active = true;
                this.raceinfo.btn_status == this.RegisterButtonStatus.COMPLETED ? this.updateSelectButton(2) : this.updateSelectButton(this._curIdx);
                let e = this.newRewardView.getChildByName("reward_moban"), t = 81;
                this.rewardTableView = this.node.addComponent(TableViewUtils);
                this.rewardTableView.init([], this.newRewardList, [e], this.initRewardItem.bind(this), 10, t);
                let i = this.newFinalView.getChildByName("final_moban");
                t = 81;
                this.finalTableView = this.node.addComponent(TableViewUtils);
                this.finalTableView.init([], this.newFinalList, [i], this.initRankItem.bind(this), 10, t);
                this.updateOverView();
                this.updatePrizesView();
                this.updateStatusBtn();
                this.raceinfo && sys.isObjectValid(this.raceinfo.raceid) && this.send_get_race_points_rewardlist_request(this.raceinfo.raceid);
            }
            else {
                3 == this.raceinfo.mode && (this.top_root0.active = false, this.top_root1.active = true, this.refreshPointsTabButton(0), this.updateStatusBtn(), this.refreshPointsOverview(), this.raceinfo && sys.isObjectValid(this.raceinfo.raceid) && this.send_get_race_points_rewardlist_request(this.raceinfo.raceid));
            }
        }
    }
    updatePrizesReward() {
        if (sys.isObjectValid(this.raceinfo.real)) {
            let e = [], t = { type: 13 };
            t.value = ToolUtils.isSafeNumber(this.raceinfo.real.item_num);
            t.item_url = ToolUtils.isSafeString(this.raceinfo.real.item_url);
            t.item_name = ToolUtils.isSafeString(this.raceinfo.real.item_name);
            e[0] = t;
            let i = { type: 2 };
            if (i.value = ToolUtils.parse_double(String(this.raceinfo.reward_value), 0), e[1] = i, Array.isArray(e) && e.length > 0) {
                this.top_root0.getChildByName("item").active = false;
                this.top_root0.getChildByName("prizes_reward").removeAllChildren();
                for (let t = 0; t < e.length; t++) {
                    let i = e[t], n = instantiate(this.top_root0.getChildByName("item"));
                    n.active = true;
                    this.top_root0.getChildByName("prizes_reward").addChild(n);
                    sys.isObjectValid(i.value) && (n.getChildByName("num").getComponent(Label).string = "" + i.value);
                    let a = n.getChildByName("icon"), o = "reward_tips_cash";
                    if (2 == i.type) {
                        o = "reward_tips_cash";
                        Utils.shared().setImage(a, "reward_tips_cash", this.rewardAtlas);
                    }
                    else if (6 == i.type) {
                        o = "reward_tips_bonus";
                        Utils.shared().setImage(a, o, this.rewardAtlas);
                    }
                    else if (11 == i.type) {
                        if (sys.isObjectValid(i.discount)) {
                            o = 100 == Number(i.discount) ? "reward_tips_ticket2" : "reward_tips_ticket1";
                        }
                        Utils.shared().setImage(a, o, this.rewardAtlas);
                    }
                    else if (13 == i.type) {
                        o = "reward_watch";
                        let e = ToolUtils.isSafeString(i.item_url), t = ToolUtils.getImageUrlPictureName(e);
                        ToolUtils.isSafeString(t).length > 0 && (t != this.rewardNames[0] ? (o = "reward_unload", Utils.shared().setImage(a, o, this.rewardAtlas), Utils.shared().updateNetImage(a, e, size(134, 134), (() => {
                        }))) : Utils.shared().setImage(a, "reward_watch", this.rewardAtlas));
                    }
                }
            }
        }
    }
    send_get_race_points_rewardlist_request(e) {
        let t = { cmd: RummyCmd.GM_RANK_INFO_REQUEST, uid: User.shared().data.uid, skey: User.shared().getSkey(), version: GameConfig.Server_Api_Ver, raceid: e, session_id: User.shared().session_id };
        Server.shared().send(t);
    }
    refreshPointsOverview() {
        let e = this.top_root1.getChildByName("overview"), t = e.getChildByName("status"), i = e.getChildByName("time");
        t.active = true;
        this.raceinfo.btn_status == this.RegisterButtonStatus.UPCOMING ? i18nMgr.shared().changeLabelLanguage(t.getComponent(Label), "match_info.regist_at") : i18nMgr.shared().changeLabelLanguage(t.getComponent(Label), "match_info.starts_at");
        this.raceinfo.btn_status == this.RegisterButtonStatus.UPCOMING && Number(this.raceinfo.will_ready_time) > 0 ? (i.getComponent(Label).string = ToolUtils.timeStr2(this.raceinfo.will_ready_time, true), i18nMgr.shared().changeLabelLanguage(t.getComponent(Label), "match_info.regist_in")) : (this.raceinfo.btn_status == this.RegisterButtonStatus.JOINNOW || this.raceinfo.btn_status == this.RegisterButtonStatus.WITHDRAW || this.raceinfo.btn_status == this.RegisterButtonStatus.EARLY_SEATING) && Number(this.raceinfo.will_start_time) > 0 ? (i.getComponent(Label).string = ToolUtils.timeStr2(this.raceinfo.will_start_time, true), i18nMgr.shared().changeLabelLanguage(t.getComponent(Label), "match_info.starts_in")) : sys.isObjectValid(this.raceinfo.start_time) && (i.getComponent(Label).string = "" + this.raceinfo.start_time);
        let n = this.overView1.getChildByName("fee");
        if (this.raceinfo.btn_status != this.RegisterButtonStatus.REJOIN && this.raceinfo.btn_status != this.RegisterButtonStatus.LATE_JOIN || !sys.isObjectValid(this.raceinfo.running_entry)) {
            let e = "";
            if (this.raceinfo.ticket_mode && this.raceinfo.ticket_mode.length > 0) {
                for (let t = 0, i = this.raceinfo.ticket_mode.length; t < i; t++) {
                    for (let i = 0, n = this.raceinfo.ticket_mode[t].pay_info.length; i < n; i++) {
                        0 == this.raceinfo.ticket_mode[t].pay_info[i].type ? e = ToolUtils.format("${0}₹${1}", e, this.raceinfo.ticket_mode[t].pay_info[i].value) : 1 == this.raceinfo.ticket_mode[t].pay_info[i].type && (e += i18nMgr.shared().getValueByKey("tournament.ticket"));
                        i != n - 1 && (e = ToolUtils.format("${0}&&", e));
                    }
                    t != this.raceinfo.ticket_mode.length - 1 && (e = ToolUtils.format("${0}/", e));
                }
            }
            else {
                e = i18nMgr.shared().getValueByKey("tournament.free");
            }
            n.getComponent(Label).string = e;
        }
        else {
            let e = "Free";
            Number(this.raceinfo.running_entry) > 0 && (e = ToolUtils.format("₹${0}", this.raceinfo.running_entry));
            n.getComponent(Label).string = e;
        }
        let a = this.overView1.getChildByName("score");
        sys.isObjectValid(this.raceinfo.score) && (a.getComponent(Label).string = "" + this.raceinfo.score);
        let o = this.overView1.getChildByName("times");
        sys.isObjectValid(this.raceinfo.entry_times) && sys.isObjectValid(this.raceinfo.can_join_times) && (o.getComponent(Label).string = this.raceinfo.can_join_times + "/" + this.raceinfo.entry_times);
        let l = this.overView1.getChildByName("rounds");
        sys.isObjectValid(this.raceinfo.max_round) && (l.getComponent(Label).string = "" + this.raceinfo.max_round);
        let h = this.overView1.getChildByName("stacks");
        sys.isObjectValid(this.raceinfo.starting_stacks) && (h.getComponent(Label).string = "" + this.raceinfo.starting_stacks);
        let c = this.overView1.getChildByName("duration");
        sys.isObjectValid(this.raceinfo.game_duration) && (c.getComponent(Label).string = "" + this.raceinfo.game_duration);
        let g = this.overView1.getChildByName("reward_moban");
        g.active = false;
        let f = this.overView1.getChildByName("rewardList").getComponent(ScrollView).content;
        f.destroyAllChildren();
        let _ = this.overView1.getChildByName("line");
        if (sys.isObjectValid(this.raceinfo.reward_infos) && Array.isArray(this.raceinfo.reward_infos) && this.raceinfo.reward_infos.length > 0) {
            let e, t;
            for (let i = 0, n = this.raceinfo.reward_infos.length; i < n; i++) {
                let n = instantiate(g);
                n.active = true;
                f.addChild(n);
                e = this.raceinfo.reward_infos[i];
                t = n.getChildByName("content");
                t.active = true;
                t.getChildByName("Id").getComponent(Label).string = String(i + 1);
                t.getChildByName("pts").getComponent(Label).string = String(e.points);
                let a = t.getChildByName("prize_root");
                if (a && sys.isObjectValid(e.infos2) && Array(e.infos2) && e.infos2.length > 0) {
                    a.active = true;
                    let t = a.getChildByName("layout0"), i = a.getChildByName("layout1"), n = a.getChildByName("layout2"), o = t.getChildByName("gold").getComponent(Label), l = i.getChildByName("bonus").getComponent(Label), h = n.getChildByName("discount").getComponent(Label), c = n.getChildByName("ic").getComponent(Sprite);
                    t.active = false;
                    i.active = false;
                    n.active = false;
                    for (let a = 0; a < e.infos2.length; a++) {
                        const r = e.infos2[a];
                        if (sys.isObjectValid(r)) {
                            if (sys.isObjectValid(r.type) && 2 == r.type) {
                                t.active = true;
                                sys.isObjectValid(r.value) && (o.string = "" + r.value);
                            }
                            else if (sys.isObjectValid(r.type) && 6 == r.type) {
                                i.active = true;
                                sys.isObjectValid(r.value) && (l.string = "" + r.value);
                            }
                            else if (sys.isObjectValid(r.type) && 11 == r.type && (n.active = true, sys.isObjectValid(r.discount))) {
                                0 != i18nMgr.shared().language && i18nMgr.shared().changeLabelFont(h);
                                let e = ToolUtils.format(i18nMgr.shared().getValueByKey("ticket.off"), r.discount);
                                sys.isObjectValid(r.value) && Number(r.value) >= 2 && (e = e + "*" + r.value);
                                h.string = e;
                                let t = Number(r.discount);
                                c.spriteFrame = 100 == t ? this.ticket_images[1] : this.ticket_images[0];
                            }
                        }
                    }
                }
            }
            let i = 52 * this.raceinfo.reward_infos.length - 2;
            _.active = true;
            this.reward_list_hei >= i ? _.setPosition(v3(0, -623 - i - 1)) : _.setPosition(v3(0, -623 - this.reward_list_hei));
        }
        else {
            _.active = false;
        }
    }
    refreshPointsRewardList(e) {
        let t = this.detailReward.getChildByName("nodata"), i = false;
        if (sys.isObjectValid(e.tips) && Array.isArray(e.tips) && e.tips.length > 0 && (i = true), this.reward_tips = e.tips, this.helpBtn2Node.active = i, sys.isObjectValid(e.reward_info) && Array.isArray(e.reward_info) && e.reward_info.length > 0 && 3 == ToolUtils.isSafeNumber(e.mode)) {
            t.active = false;
            let i = this.detailReward.getChildByName("prizes_moban");
            i.active = false;
            let n = this.detailReward.getChildByName("prizes_list").getComponent(ScrollView).content;
            n.destroyAllChildren();
            for (let t = 0, a = e.reward_info.length; t < a; t++) {
                let a = e.reward_info[t], o = instantiate(i);
                o.active = true;
                n.addChild(o);
                o.getChildByName("line").active = true;
                o.getChildByName("name").getComponent(Label).string = ToolUtils.GetShortName2(a.player, 10, true);
                o.getChildByName("points").getComponent(Label).string = "" + a.points;
                let l = o.getChildByName("prize_root");
                if (l && sys.isObjectValid(a.infos2) && Array(a.infos2) && a.infos2.length > 0) {
                    l.active = true;
                    let e = l.getChildByName("layout0"), t = l.getChildByName("layout1"), i = l.getChildByName("layout2"), n = e.getChildByName("gold").getComponent(Label), o = t.getChildByName("bonus").getComponent(Label), h = i.getChildByName("discount").getComponent(Label), c = i.getChildByName("ic").getComponent(Sprite);
                    e.active = false;
                    t.active = false;
                    i.active = false;
                    for (let r = 0; r < a.infos2.length; r++) {
                        const s = a.infos2[r];
                        if (sys.isObjectValid(s)) {
                            if (sys.isObjectValid(s.type) && 2 == s.type) {
                                e.active = true;
                                sys.isObjectValid(s.value) && (n.string = "" + s.value);
                            }
                            else if (sys.isObjectValid(s.type) && 6 == s.type) {
                                t.active = true;
                                sys.isObjectValid(s.value) && (o.string = "" + s.value);
                            }
                            else if (sys.isObjectValid(s.type) && 11 == s.type && (i.active = true, sys.isObjectValid(s.discount))) {
                                0 != i18nMgr.shared().language && i18nMgr.shared().changeLabelFont(h);
                                let e = ToolUtils.format(i18nMgr.shared().getValueByKey("ticket.off"), s.discount);
                                sys.isObjectValid(s.value) && Number(s.value) >= 2 && (e = e + "*" + s.value);
                                h.string = e;
                                let t = Number(s.discount);
                                c.spriteFrame = 100 == t ? this.ticket_images[1] : this.ticket_images[0];
                            }
                        }
                    }
                }
            }
        }
        else {
            t.active = true;
        }
    }
    updateOverView() {
        this.top_info.getChildByName("title").getComponent(Label).string = this.raceinfo.race_name;
        let e = this.overViewTips.getChildByName("layout").getChildByName("status"), t = this.overViewTips.getChildByName("layout").getChildByName("time"), i = this.overView.getChildByName("entry"), n = this.overView.getChildByName("reward"), a = this.overView.getChildByName("join"), o = this.overView.getChildByName("starting");
        i18nMgr.shared().changeLabelLanguage(o.getComponent(Label), "match_info.when_full");
        this.raceinfo.btn_status == this.RegisterButtonStatus.UPCOMING ? (e.active = true, i18nMgr.shared().changeLabelLanguage(e.getComponent(Label), "match_info.regist_at"), t.getComponent(Label).color = color(126, 10, 10), Number(this.raceinfo.will_ready_time) > 0 && Number(this.raceinfo.will_ready_time) <= 10800 ? (t.getComponent(Label).string = ToolUtils.timeStr2(this.raceinfo.will_ready_time, true), i18nMgr.shared().changeLabelLanguage(e.getComponent(Label), "match_info.regist_in")) : t.getComponent(Label).string = ToolUtils.format("${0}", this.raceinfo.ready_time)) : this.raceinfo.btn_status == this.RegisterButtonStatus.JOINNOW || this.raceinfo.btn_status == this.RegisterButtonStatus.WITHDRAW || this.raceinfo.btn_status == this.RegisterButtonStatus.EARLY_SEATING || this.raceinfo.btn_status == this.RegisterButtonStatus.FULL ? (e.active = true, i18nMgr.shared().changeLabelLanguage(e.getComponent(Label), "match_info.starts_at"), 1 == this.raceinfo.mode || 3 == this.raceinfo.mode ? (this.raceinfo.btn_status == this.RegisterButtonStatus.JOINNOW || this.raceinfo.btn_status == this.RegisterButtonStatus.WITHDRAW || this.raceinfo.btn_status == this.RegisterButtonStatus.EARLY_SEATING) && Number(this.raceinfo.will_start_time) > 0 && Number(this.raceinfo.will_start_time) <= 10800 ? (t.getComponent(Label).string = ToolUtils.timeStr2(this.raceinfo.will_start_time, true), i18nMgr.shared().changeLabelLanguage(e.getComponent(Label), "match_info.starts_in")) : t.getComponent(Label).string = this.raceinfo.time_info : t.getComponent(Label).string = i18nMgr.shared().getValueByKey("tournament.start_full"), t.getComponent(Label).color = color(126, 10, 10)) : this.raceinfo.btn_status == this.RegisterButtonStatus.REJOIN ? (e.active = true, i18nMgr.shared().changeLabelLanguage(e.getComponent(Label), "tournament.rejoin"), 1 == this.raceinfo.mode || 3 == this.raceinfo.mode ? t.getComponent(Label).string = this.raceinfo.time_info : t.getComponent(Label).string = i18nMgr.shared().getValueByKey("tournament.start_full"), t.getComponent(Label).color = color(126, 10, 10)) : this.raceinfo.btn_status == this.RegisterButtonStatus.LATE_JOIN ? (e.active = true, i18nMgr.shared().changeLabelLanguage(e.getComponent(Label), "tournament.late_join"), 1 == this.raceinfo.mode || 3 == this.raceinfo.mode ? t.getComponent(Label).string = this.raceinfo.time_info : t.getComponent(Label).string = i18nMgr.shared().getValueByKey("tournament.start_full"), t.getComponent(Label).color = color(126, 10, 10)) : this.raceinfo.btn_status == this.RegisterButtonStatus.ENTER || this.raceinfo.btn_status == this.RegisterButtonStatus.RUNNING ? (e.active = false, i18nMgr.shared().changeLabelLanguage(t.getComponent(Label), "tournament.running"), t.getComponent(Label).color = color(39, 138, 42)) : (e.active = false, i18nMgr.shared().changeLabelLanguage(t.getComponent(Label), "tournament.completed1"), t.getComponent(Label).color = color(39, 138, 42));
        let r = "";
        if (this.raceinfo.ticket_mode && this.raceinfo.ticket_mode.length > 0) {
            for (let e = 0, t = this.raceinfo.ticket_mode.length; e < t; e++) {
                for (let t = 0, i = this.raceinfo.ticket_mode[e].pay_info.length; t < i; t++) {
                    0 == this.raceinfo.ticket_mode[e].pay_info[t].type ? r = ToolUtils.format("${0}₹${1}", r, this.raceinfo.ticket_mode[e].pay_info[t].value) : 1 == this.raceinfo.ticket_mode[e].pay_info[t].type && (r += i18nMgr.shared().getValueByKey("tournament.ticket"));
                    t != i - 1 && (r = ToolUtils.format("${0}&&", r));
                }
                e != this.raceinfo.ticket_mode.length - 1 && (r = ToolUtils.format("${0}/", r));
            }
        }
        else {
            r = i18nMgr.shared().getValueByKey("tournament.free");
        }
        if (i.getComponent(Label).string = r, n.getComponent(Label).string = ToolUtils.format("${0}", this.raceinfo.reward_num), a.getComponent(Label).string = ToolUtils.format("${0}/${1}", this.raceinfo.min_num, this.raceinfo.num), o.getComponent(Label).string = ToolUtils.format("${0}", this.raceinfo.starting_stacks), this.bInitNewLevelList) {
            return;
        }
        let l = this.newLevelList.getComponent(ScrollView).content, h = this.newOverViewView.getChildByName("level_moban"), g = false, p = false;
        h.active = false;
        for (let e = 0, t = this.raceinfo.levels.length; e < t; e++) {
            let t = instantiate(h);
            l.addChild(t);
            this.initLevelItem(t, this.raceinfo.levels[e], e);
            sys.isObjectValid(this.raceinfo.levels[e].rejoin_score) && Number(this.raceinfo.levels[e].rejoin_score) > 0 && (g = true);
            sys.isObjectValid(this.raceinfo.levels[e].late_score) && Number(this.raceinfo.levels[e].late_score) > 0 && (p = true);
        }
        let f = this.newOverViewView.getChildByName("latejoin_moban");
        if (f.active = false, this.lateJoinNode.active = p, p) {
            this.lateJoinNode.parent = l;
            for (let e = 0, t = this.raceinfo.levels.length; e < t; e++) {
                if (sys.isObjectValid(this.raceinfo.levels[e].late_score) && Number(this.raceinfo.levels[e].late_score) > 0) {
                    let t = instantiate(f);
                    t.getChildByName("time").getComponent(Label).string = this.getDuration(this.raceinfo.levels[e].max_time);
                    t.getChildByName("join_fee").getComponent(Label).string = ToolUtils.format("₹${0}", this.raceinfo.levels[e].late_fee);
                    t.getChildByName("join_chips").getComponent(Label).string = String(this.raceinfo.levels[e].late_score);
                    t.active = true;
                    this.lateJoinList.addChild(t);
                }
            }
        }
        let _ = this.newOverViewView.getChildByName("rejoin_moban");
        if (_.active = false, this.rejoinNode.active = g, g) {
            this.rejoinNode.parent = l;
            for (let e = 0, t = this.raceinfo.levels.length; e < t; e++) {
                if (sys.isObjectValid(this.raceinfo.levels[e].rejoin_score) && Number(this.raceinfo.levels[e].rejoin_score) > 0) {
                    let t = instantiate(_);
                    t.getChildByName("level").getComponent(Label).string = String(this.raceinfo.levels[e].level);
                    t.getChildByName("rejoin").getComponent(Label).string = ToolUtils.format("₹${0}", this.raceinfo.levels[e].rejoin_fee);
                    t.getChildByName("reload").getComponent(Label).string = String(this.raceinfo.levels[e].rejoin_score);
                    t.active = true;
                    this.rejoinList.addChild(t);
                }
            }
        }
        this.raceinfo.levels.length > 0 && (this.bInitNewLevelList = true);
    }
    updatePrizesView() {
        this.raceinfo.reward_infos && this.raceinfo.reward_infos.length > 0 && this.rewardTableView.reloadData(this.raceinfo.reward_infos);
    }
    initLevelItem(e, t, i) {
        e.active = true;
        e.getChildByName("line").active = true;
        e.getChildByName("level").getComponent(Label).string = String(t.level);
        e.getChildByName("time").getComponent(Label).string = this.getDuration(t.time);
        e.getChildByName("value").getComponent(Label).string = String(t.pt_value);
        e.getChildByName("min").getComponent(Label).string = String(t.qualify);
        null != t.rebuy && t.rebuy > 0 ? e.getChildByName("fee").getComponent(Label).string = ToolUtils.format("₹${0}", t.rebuy) : e.getChildByName("fee").getComponent(Label).string = "-";
        null != t.reload && t.reload > 0 ? e.getChildByName("chips").getComponent(Label).string = ToolUtils.format("${0}", t.reload) : e.getChildByName("chips").getComponent(Label).string = "-";
    }
    initRewardItem(e, t, i) {
        let n = t;
        e.active = true;
        e.getChildByName("line").active = true;
        let a = e.getChildByName("rank").getComponent(Label), o = e.getChildByName("rank_icon").getComponent(Sprite);
        sys.isObjectValid(n.rank) && n.rank >= 1 && n.rank <= 3 ? (o.node.active = true, a.node.active = false, o.spriteFrame = this.rankFrame[n.rank - 1]) : (o.node.active = false, a.node.active = true, ToolUtils.isSafeString(n.desc).length > 0 ? a.string = String(n.desc) : a.string = String(n.rank));
        let l = e.getChildByName("prize"), h = e.getChildByName("prize_root");
        if (h && sys.isObjectValid(n.infos2) && Array(n.infos2) && n.infos2.length > 0) {
            h.active = true;
            l.active = false;
            let e = h.getChildByName("layout0"), t = h.getChildByName("layout1"), i = h.getChildByName("layout2"), a = h.getChildByName("layout3"), o = e.getChildByName("gold").getComponent(Label), c = t.getChildByName("bonus").getComponent(Label), d = i.getChildByName("discount").getComponent(Label), u = i.getChildByName("ic").getComponent(Sprite);
            e.active = false;
            t.active = false;
            i.active = false;
            a.active = false;
            for (let r = 0; r < n.infos2.length; r++) {
                const l = n.infos2[r];
                if (sys.isObjectValid(l)) {
                    if (sys.isObjectValid(l.type) && 2 == l.type) {
                        e.active = true;
                        sys.isObjectValid(l.value) && (o.string = "" + l.value);
                    }
                    else if (sys.isObjectValid(l.type) && 6 == l.type) {
                        t.active = true;
                        sys.isObjectValid(l.value) && (c.string = "" + l.value);
                    }
                    else if (sys.isObjectValid(l.type) && 11 == l.type) {
                        if (i.active = true, sys.isObjectValid(l.discount)) {
                            0 != i18nMgr.shared().language && i18nMgr.shared().changeLabelFont(d);
                            let e = ToolUtils.format(i18nMgr.shared().getValueByKey("ticket.off"), l.discount);
                            sys.isObjectValid(l.value) && Number(l.value) >= 2 && (e = e + "*" + l.value);
                            d.string = e;
                            let t = Number(l.discount);
                            u.spriteFrame = 100 == t ? this.ticket_images[1] : this.ticket_images[0];
                        }
                    }
                    else if (sys.isObjectValid(l.type) && 13 == l.type) {
                        a.active = true;
                        let e = a.getChildByName("ic"), t = a.getChildByName("desc"), i = ToolUtils.isSafeString(l.item_url), n = ToolUtils.getImageUrlPictureName(i);
                        ToolUtils.isSafeString(n).length > 0 && (n != this.rewardNames[0] ? (Utils.shared().setImage(e, "reward_unload", this.rewardAtlas), Utils.shared().updateNetImage(e, i, size(48.24, 48.24), (() => {
                        }))) : Utils.shared().setImage(e, "reward_watch", this.rewardAtlas));
                        sys.isObjectValid(l.item_name) && (i18nMgr.shared().changeLabelFont(t.getComponent(Label)), t.getComponent(Label).string = "" + l.item_name);
                    }
                }
            }
        }
        else {
            l.active = true;
            h.active = false;
            sys.isObjectValid(n.reward_money) && n.reward_money > 0 ? (l.getComponent(Label).string = ToolUtils.format("₹${0}", ToolUtils.parse_double(n.reward_money, 0)), l.getComponent(Label).color = color(0, 131, 21)) : (l.getComponent(Label).string = "--", l.getComponent(Label).color = color(102, 102, 102));
        }
    }
    initRankItem(e, t, i) {
        let n = t;
        e.active = true;
        let a = e.getChildByName("rank").getComponent(Label), o = e.getChildByName("rank_icon").getComponent(Sprite);
        sys.isObjectValid(n.rank) && n.rank >= 1 && n.rank <= 3 ? (o.node.active = true, a.node.active = false, o.spriteFrame = this.rankFrame[n.rank - 1]) : (o.node.active = false, a.node.active = true, a.string = String(n.rank));
        e.getChildByName("name").getComponent(Label).string = ToolUtils.GetShortName2(n.name, 10, true);
        let l = e.getChildByName("head").getChildByName("img");
        Utils.shared().updateHeadImg(l, n.avatar, n.avatar_url, size(46, 46));
        let h = e.getChildByName("prize"), d = e.getChildByName("prize_root");
        if (d && sys.isObjectValid(n.infos2) && Array(n.infos2) && n.infos2.length > 0) {
            d.active = true;
            h.active = false;
            let e = d.getChildByName("layout0"), t = d.getChildByName("layout1"), i = d.getChildByName("layout2"), a = d.getChildByName("layout3"), o = e.getChildByName("gold").getComponent(Label), l = t.getChildByName("bonus").getComponent(Label), c = i.getChildByName("discount").getComponent(Label), u = i.getChildByName("ic").getComponent(Sprite);
            e.active = false;
            t.active = false;
            i.active = false;
            a.active = false;
            for (let r = 0; r < n.infos2.length; r++) {
                const h = n.infos2[r];
                if (sys.isObjectValid(h)) {
                    if (sys.isObjectValid(h.type) && 2 == h.type) {
                        e.active = true;
                        sys.isObjectValid(h.value) && (o.string = "" + h.value);
                    }
                    else if (sys.isObjectValid(h.type) && 6 == h.type) {
                        t.active = true;
                        sys.isObjectValid(h.value) && (l.string = "" + h.value);
                    }
                    else if (sys.isObjectValid(h.type) && 11 == h.type) {
                        if (i.active = true, sys.isObjectValid(h.discount)) {
                            0 != i18nMgr.shared().language && i18nMgr.shared().changeLabelFont(c);
                            let e = ToolUtils.format(i18nMgr.shared().getValueByKey("ticket.off"), h.discount);
                            sys.isObjectValid(h.value) && Number(h.value) >= 2 && (e = e + "*" + h.value);
                            c.string = e;
                            let t = Number(h.discount);
                            u.spriteFrame = 100 == t ? this.ticket_images[1] : this.ticket_images[0];
                        }
                    }
                    else if (sys.isObjectValid(h.type) && 13 == h.type) {
                        a.active = true;
                        let e = a.getChildByName("ic"), t = a.getChildByName("desc"), i = ToolUtils.isSafeString(h.item_url), n = ToolUtils.getImageUrlPictureName(i);
                        ToolUtils.isSafeString(n).length > 0 && (n != this.rewardNames[0] ? (Utils.shared().setImage(e, "reward_unload", this.rewardAtlas), Utils.shared().updateNetImage(e, i, size(48.24, 48.24), (() => {
                        }))) : Utils.shared().setImage(e, "reward_watch", this.rewardAtlas));
                        sys.isObjectValid(h.item_name) && (i18nMgr.shared().changeLabelFont(t.getComponent(Label)), t.getComponent(Label).string = "" + h.item_name);
                    }
                }
            }
        }
        else {
            h.active = true;
            d.active = false;
            sys.isObjectValid(n.reward_money) && n.reward_money > 0 ? (h.getComponent(Label).string = ToolUtils.format("₹${0}", ToolUtils.parse_double(n.reward_money, 0)), h.getComponent(Label).color = color(0, 131, 21)) : (h.getComponent(Label).string = "--", h.getComponent(Label).color = color(102, 102, 102));
        }
    }
    updateFinalView(e) {
        let t = this.newFinalView.getChildByName("nodata");
        !sys.isObjectValid(e.mode) || 0 != e.mode && 1 != e.mode || (sys.isObjectValid(e.players) && Array.isArray(e.players) && e.players.length > 0 ? (t.active = false, this.finalTableView.reloadData(e.players)) : t.active = true);
    }
    onUpdateRaceTime() {
        let e = this.overViewTips.getChildByName("layout").getChildByName("time");
        this.raceinfo && (1 == this.raceinfo.mode || 3 == this.raceinfo.mode) && ToolUtils.isObjValid(e) && (this.raceinfo.btn_status == this.RegisterButtonStatus.UPCOMING ? this.raceinfo.will_ready_time > 0 && Number(this.raceinfo.will_ready_time) <= 10800 && (this.raceinfo.will_ready_time -= 1, e.getComponent(Label).string = ToolUtils.timeStr2(this.raceinfo.will_ready_time, true)) : this.raceinfo.btn_status != this.RegisterButtonStatus.JOINNOW && this.raceinfo.btn_status != this.RegisterButtonStatus.WITHDRAW && this.raceinfo.btn_status != this.RegisterButtonStatus.EARLY_SEATING || this.raceinfo.will_start_time > 0 && Number(this.raceinfo.will_start_time) <= 10800 && (this.raceinfo.will_start_time -= 1, e.getComponent(Label).string = ToolUtils.timeStr2(this.raceinfo.will_start_time, true)));
    }
    updateStatusBtn() {
        let e = this.node.getChildByName("status_btn"), t = e.getChildByName("wz"), i = this.raceBtnStatus[this.raceinfo.btn_status];
        this.raceinfo.btn_status == this.RegisterButtonStatus.UPCOMING ? (e.getComponent(Button).interactable = false, e.getComponent(Button).normalSprite = this.btnStateFrame[5], e.getComponent(Sprite).color = color(255, 255, 255), t.getComponent(Label).color = color(153, 153, 153), 3 == this.raceinfo.mode && (i = "tournament.upcoming")) : this.raceinfo.btn_status == this.RegisterButtonStatus.JOINNOW ? (e.getComponent(Button).interactable = true, e.getComponent(Button).normalSprite = this.btnStateFrame[1], e.getComponent(Sprite).color = color(255, 255, 255), t.getComponent(Label).color = color(255, 255, 255), 3 == this.raceinfo.mode && (i = "tournament.join_now")) : this.raceinfo.btn_status == this.RegisterButtonStatus.LATE_JOIN ? (e.getComponent(Button).interactable = true, e.getComponent(Button).normalSprite = this.btnStateFrame[1], e.getComponent(Sprite).color = color(255, 255, 255), t.getComponent(Label).color = color(255, 255, 255)) : this.raceinfo.btn_status == this.RegisterButtonStatus.WITHDRAW ? (e.getComponent(Button).interactable = true, e.getComponent(Button).normalSprite = this.btnStateFrame[6], e.getComponent(Sprite).color = color(255, 255, 255), t.getComponent(Label).color = color(153, 153, 153), 3 == this.raceinfo.mode && (i = "tournament.withdraw")) : this.raceinfo.btn_status == this.RegisterButtonStatus.FULL ? (e.getComponent(Button).interactable = true, e.getComponent(Button).normalSprite = this.btnStateFrame[2], e.getComponent(Sprite).color = color(153, 153, 153), t.getComponent(Label).color = color(153, 153, 153), 3 == this.raceinfo.mode && (i = "tournament.full")) : this.raceinfo.btn_status == this.RegisterButtonStatus.ENTER ? 3 == this.raceinfo.mode ? (e.getComponent(Button).interactable = true, i = "tournament.enter", e.getComponent(Button).normalSprite = this.btnStateFrame[0], e.getComponent(Sprite).color = color(255, 255, 255), t.getComponent(Label).color = color(255, 255, 255)) : (e.getComponent(Button).interactable = true, i = "tournament.running", e.getComponent(Button).normalSprite = this.btnStateFrame[4], e.getComponent(Sprite).color = color(217, 243, 222), t.getComponent(Label).color = color(70, 153, 75)) : this.raceinfo.btn_status == this.RegisterButtonStatus.EARLY_SEATING ? (e.getComponent(Button).interactable = true, e.getComponent(Button).normalSprite = this.btnStateFrame[0], e.getComponent(Sprite).color = color(255, 255, 255), t.getComponent(Label).color = color(255, 255, 255)) : this.raceinfo.btn_status == this.RegisterButtonStatus.ELIMINATED ? 3 == this.raceinfo.mode ? (e.getComponent(Button).interactable = true, i = "tournament.join_now", e.getComponent(Button).normalSprite = this.btnStateFrame[1], e.getComponent(Sprite).color = color(255, 255, 255), t.getComponent(Label).color = color(255, 255, 255)) : (e.getComponent(Button).interactable = false, i = "tournament.eliminated2", e.getComponent(Button).normalSprite = this.btnStateFrame[4], e.getComponent(Sprite).color = color(240, 240, 240), t.getComponent(Label).color = color(153, 153, 153)) : this.raceinfo.btn_status == this.RegisterButtonStatus.RUNNING ? (e.getComponent(Button).interactable = false, i = "tournament.running", e.getComponent(Button).normalSprite = this.btnStateFrame[4], e.getComponent(Sprite).color = color(217, 243, 222), t.getComponent(Label).color = color(70, 153, 75)) : this.raceinfo.btn_status == this.RegisterButtonStatus.REJOIN ? (e.getComponent(Button).interactable = true, i = "tournament.rejoin2", e.getComponent(Button).normalSprite = this.btnStateFrame[1], e.getComponent(Sprite).color = color(255, 255, 255), t.getComponent(Label).color = color(255, 255, 255)) : this.raceinfo.btn_status == this.RegisterButtonStatus.LATE_JOIN ? (e.getComponent(Button).interactable = true, e.getComponent(Button).normalSprite = this.btnStateFrame[1], e.getComponent(Sprite).color = color(255, 255, 255), t.getComponent(Label).color = color(255, 255, 255)) : (e.getComponent(Button).interactable = false, e.getComponent(Button).normalSprite = this.btnStateFrame[4], e.getComponent(Sprite).color = color(217, 243, 222), t.getComponent(Label).color = color(70, 153, 72), i = "tournament.completed");
        t.getComponent(Label).string = ToolUtils.format("${0}", i18nMgr.shared().getValueByKey(i));
    }
    refreshPointsTabButton(e) {
        for (let t = 0; t < 2; t++) {
            t == e ? (this.pointsTabBtn[t].getComponent(Button).interactable = false, this.pointsTabBtn[t].getChildByName("wz").getComponent(Label).color = this.tab_select_color, i18nMgr.shared().changeLabelFont(this.pointsTabBtn[t].getChildByName("wz").getComponent(Label), true)) : (this.pointsTabBtn[t].getComponent(Button).interactable = true, this.pointsTabBtn[t].getChildByName("wz").getComponent(Label).color = color(102, 102, 102), i18nMgr.shared().changeLabelFont(this.pointsTabBtn[t].getChildByName("wz").getComponent(Label), false));
        }
        0 == e ? (this.top_root1.getChildByName("overview").active = true, this.top_root1.getChildByName("list_flag").active = false, this.overView1.active = true, this.detailReward.active = false) : (this.top_root1.getChildByName("overview").active = false, this.top_root1.getChildByName("list_flag").active = true, this.overView1.active = false, this.detailReward.active = true, e = 3);
    }
    updateSelectButton(e) {
        for (let t = 0; t < 3; t++) {
            let i = this.switchBtn[t].getChildByName("line");
            if (t == e) {
                this.switchBtn[t].getComponent(Button).interactable = false;
                this.switchBtn[t].getChildByName("wz").getComponent(Label).color = this.tab_select_color;
                i18nMgr.shared().changeLabelFont(this.switchBtn[t].getChildByName("wz").getComponent(Label), true);
                i.active = true;
                i.scale = v3(0, 1, 1);
                let e = TweenTool.scaleTo(i, 0.16, v3(1.1, 1, 1), null, false), n = TweenTool.scaleTo(i, 0.16, v3(1, 1, 1), null, false);
                TweenTool.sequence(i, true, null, e, n);
            }
            else {
                this.switchBtn[t].getComponent(Button).interactable = true;
                this.switchBtn[t].getChildByName("wz").getComponent(Label).color = color(102, 102, 102);
                i18nMgr.shared().changeLabelFont(this.switchBtn[t].getChildByName("wz").getComponent(Label), false);
                i.scale = v3(1, 1, 1);
                TweenTool.scaleTo(i, 0.1, v3(0.2, 1, 1), null, true, (() => {
                    i.scale = v3(1, 1, 1);
                    i.active = false;
                }));
            }
        }
        this.overViewTips.active = 0 == e;
        this.overView.active = 0 == e;
        this.newOverViewView.active = 0 == e;
        this.newRewardView.active = 1 == e;
        this.newFinalView.active = 2 == e;
    }
    onButtonClick(e, t) {
        if ("close" == t) {
            SoundManager.shared().playFx("click");
            ToolUtils.isObjValid(this.node) && this.node.destroy();
        }
        else if ("help" == t) {
            Utils.shared().showHelpAlert({ parent_node: this.node, tips: "Test Mathch tips" });
        }
        else {
            let t = { raceid: this.raceinfo.raceid, status: this.raceinfo.btn_status, payinfo: this.raceinfo.ticket_mode };
            1 == this._from_source ? this.cb && this.cb(t) : this.cb && this.cb(e, ToolUtils.toJsonString(t));
        }
    }
    onSwitchSelectClick(e, t) {
        SoundManager.shared().playFx("click");
        this.updateSelectButton(Number(t));
    }
    onPoitnsTabClick(e, t) {
        SoundManager.shared().playFx("click");
        this.refreshPointsTabButton(Number(t));
    }
    onTicketHelpClick(e, t) {
        if (SoundManager.shared().playFx("click"), "close" == t) {
            this.ticket_tipNode.active = false;
        }
        else if ("overview" == t) {
            this.ticket_tipNode.active = true;
            let e = this.ticket_tipNode.getChildByName("bubble");
            e.active = true;
            let t = new Vec3;
            this.helpBtn1Node.getWorldPosition(t);
            let i = new Vec3;
            this.ticket_tipNode.inverseTransformPoint(i, t);
            e.setPosition(new Vec3(79, i.y + 24));
            let n = e.getChildByName("item");
            n.active = false;
            let a = e.getChildByName("item_root");
            a.active = true;
            a.removeAllChildren();
            let o = 550, r = 194, s = 42;
            if (sys.isObjectValid(this.overview_tips) && Array.isArray(this.overview_tips) && this.overview_tips.length > 0) {
                let e = this.overview_tips.length;
                for (let t = 0; t < e; t++) {
                    let e = instantiate(n);
                    e.active = true;
                    a.addChild(e);
                    this.refreshTicketTipsItem(this.overview_tips[t], e);
                }
                r += (e - 3) * s;
            }
            e.getComponent(UITransform).setContentSize(size(o, r));
        }
        else if ("rewardlist" == t) {
            this.ticket_tipNode.active = true;
            let e = this.ticket_tipNode.getChildByName("bubble");
            e.active = true;
            let t = new Vec3;
            this.helpBtn2Node.getWorldPosition(t);
            let i = new Vec3;
            this.ticket_tipNode.inverseTransformPoint(i, t);
            e.setPosition(new Vec3(79, i.y + 24));
            let n = e.getChildByName("item");
            n.active = false;
            let a = e.getChildByName("item_root");
            a.active = true;
            a.removeAllChildren();
            let o = 550, r = 194, s = 42;
            if (sys.isObjectValid(this.reward_tips) && Array.isArray(this.reward_tips) && this.reward_tips.length > 0) {
                let e = this.reward_tips.length;
                for (let t = 0; t < e; t++) {
                    let e = instantiate(n);
                    e.active = true;
                    a.addChild(e);
                    this.refreshTicketTipsItem(this.reward_tips[t], e);
                }
                r += (e - 3) * s;
            }
            e.getComponent(UITransform).setContentSize(size(o, r));
        }
        else if ("prize" == t) {
            this.ticket_tipNode.active = true;
            let e = this.ticket_tipNode.getChildByName("bubble");
            e.active = true;
            let t = new Vec3;
            this.helpBtn3Node.getWorldPosition(t);
            let i = new Vec3;
            this.ticket_tipNode.inverseTransformPoint(i, t);
            e.setPosition(new Vec3(79, i.y + 24));
            let n = e.getChildByName("item");
            n.active = false;
            let a = e.getChildByName("item_root");
            a.active = true;
            a.removeAllChildren();
            let o = 550, r = 194, s = 42;
            if (sys.isObjectValid(this.overview_tips) && Array.isArray(this.overview_tips) && this.overview_tips.length > 0) {
                let e = this.overview_tips.length;
                for (let t = 0; t < e; t++) {
                    let e = instantiate(n);
                    e.active = true;
                    a.addChild(e);
                    this.refreshTicketTipsItem(this.overview_tips[t], e);
                }
                r += (e - 3) * s;
            }
            e.getComponent(UITransform).setContentSize(size(o, r));
        }
    }
    refreshTicketTipsItem(e, t) {
        let i = t.getChildByName("icon").getComponent(Sprite), n = t.getChildByName("Label"), a = e.discount, o = e.match_name + " " + a + "%" + i18nMgr.shared().getValueByKey("ticket.off2");
        i18nMgr.shared().changeLabelFont(n.getComponent(Label));
        n.getComponent(Label).string = o;
        i.spriteFrame = 100 == a ? this.ticket_images[1] : this.ticket_images[0];
    }
    getDuration(e) {
        let t = "";
        if (e >= 86400) {
            let i = (e - e % 86400) / 86400;
            e -= 86400 * i;
            t = t + i + "day";
        }
        if (e >= 3600) {
            let i = (e - e % 3600) / 3600;
            e -= 3600 * i;
            t = t + i + "H";
        }
        if (e >= 60) {
            let i = (e - e % 60) / 60;
            e -= 60 * i;
            t = t + i + "min";
        }
        if (e > 0) {
            t = t + e + "sec";
        }
        return "" == t && (t = "0min"), t;
    }
    fitScreen() {
        let e = ToolUtils.adaptSafeArea(this.node.getChildByName("bgView")), t = sys.getSafeAreaRect().y;
        ToolUtils.isPadPlatform() && (t = 0);
        let i = view.getVisibleSize().height - GameConfig.CONFIG_SCREEN_HEIGHT - t - e, n = this.newOverViewView.getChildByName("level_list").getComponent(ScrollView), a = n.view;
        n.getComponent(UITransform).setContentSize(size(a.width, a.height + i));
        let o = this.newRewardView.getChildByName("reward_list").getComponent(ScrollView);
        a = o.view;
        o.getComponent(UITransform).setContentSize(size(a.width, a.height + i));
        let r = this.newFinalView.getChildByName("final_list").getComponent(ScrollView);
        a = r.view;
        r.getComponent(UITransform).setContentSize(size(a.width, a.height + i));
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().removeListenersByTag(this);
        this.time_schedule && (this.time_schedule.stop(), this.time_schedule = null);
    }
}
