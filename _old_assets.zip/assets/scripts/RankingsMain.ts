// @ts-nocheck
// Recovered from index.js:365
import { _decorator, Button, color, instantiate, Label, Layout, Node, ProgressBar, ScrollView, size, Slider, Sprite, SpriteFrame, sys, UITransform, v2, v3, view } from "cc";
import BaseLayer from "./BaseLayer";
import { TLog } from "./TLog";
import PushCenter from "./PushCenter";
import SoundManager from "./SoundManager";
import Utils from "./Utils";
import i18nMgr from "./i18nMgr";
import User from "./User";
import PushEvent from "./PushEvent";
import TweenTool from "./TweenTool";
import { PointsType } from "./CommDefine";
import HttpManager from "./HttpManager";
import { HttpRequest } from "./HttpRequestName";
import { ToolUtils } from "./ToolUtils";
import GameConfig from "./GameConfig";
import HowToPlayDefined from "./HowToPlayDefined";
const { ccclass, property } = _decorator;
@ccclass("RankingsMain")
export class RankingsMain extends BaseLayer {
    @property(Node)
    public rootNode: Node = null;
    @property(Node)
    public backBtnNode: Node = null;
    @property(Node)
    public tabRootNode: Node = null;
    @property([SpriteFrame])
    public tabImags: SpriteFrame[] = [];
    @property(ScrollView)
    public scrollView: ScrollView = null;
    @property(Node)
    public rank_itemNode: Node = null;
    @property([SpriteFrame])
    public rankImags: SpriteFrame[] = [];
    @property([SpriteFrame])
    public iconSpriteFrames: SpriteFrame[] = [];
    @property([SpriteFrame])
    public timeSelectSprites: SpriteFrame[] = [];
    @property(Node)
    public itemBubbleNode: Node = null;
    @property(Node)
    public tool_rootNode: Node = null;
    @property(Node)
    public autoTipsNode: Node = null;
    @property(Node)
    public scheduleListNode: Node = null;
    @property(ScrollView)
    public scheduleScrollView: ScrollView = null;
    @property(Node)
    public optInNode: Node = null;
    @property(Node)
    public optInSuccNode: Node = null;
    @property(Node)
    public optOutNode: Node = null;
    @property(Node)
    public optOutSuccNode: Node = null;
    @property(Node)
    public totalPrizeNode: Node = null;
    @property(Node)
    public detaSelecctNode: Node = null;
    @property(Node)
    public bannerRewardNode: Node = null;
    @property(Node)
    public topNode: Node = null;
    @property(Node)
    public titleNode: Node = null;
    @property(Node)
    public totalPrizeTx: Node = null;
    @property(Node)
    public subTimeTx: Node = null;
    @property(Node)
    public leftTimeArrow: Node = null;
    @property(Node)
    public detaSelectBtn: Node = null;
    @property(Node)
    public leftTimeTx: Node = null;
    @property(Node)
    public bottomLeftTimeTx: Node = null;
    @property(Node)
    public totalPrizeBtn: Node = null;
    @property(Node)
    public optInBtn: Node = null;
    @property(Node)
    public playBtn: Node = null;
    @property(Node)
    public optOutBtn: Node = null;
    @property(Node)
    public endBtn: Node = null;
    @property(Node)
    public bottomNode: Node = null;
    @property(Node)
    public sliderStarNode: Node = null;
    @property(Node)
    public autoOtpBtn: Node = null;
    @property(Node)
    public otpInAutoBtn: Node = null;
    @property([SpriteFrame])
    public switchIcons: SpriteFrame[] = [];
    @property([SpriteFrame])
    public rankItemBgImgs: SpriteFrame[] = [];
    @property([SpriteFrame])
    public rankStarFrame: SpriteFrame[] = [];
    public _prizeItemArr: any[] = [];
    public isNext: boolean = false;
    public rule: string = "";
    public _tabData: any[] = [];
    public _tabItemArr: any[] = [];
    public _tabIndex: number = 0;
    public _curTableRankItems: any[] = [];
    public _lastTableRankItems: any[] = [];
    public _taskScrolHei: number = 0;
    public _taskContentDiHei: number = 0;
    public _listScrollHei: number = 0;
    public _listContentDiHei: number = 0;
    public _contentDiTop: number = 0;
    public _rewardItems: any[] = [];
    public _tast_scrll_offsetY: number = 0;
    public rank_listData: any[] = [];
    public _has_task_progress: boolean = false;
    public _task_open: number = 1;
    public myRankData: any = null;
    public cycle_sn: any = null;
    public has_next_page: number = 0;
    public cur_page: number = 1;
    public _isSendMsg: boolean = false;
    public rank_type: string = "daily";
    public status: number = 0;
    public recom_roomInfo: any = null;
    public gameType: number = 0;
    public rummyType: number = 0;
    public miniRankData: any = null;
    public megaRankData: any = null;
    public rankDetailData: any = {};
    public scheduleData: any = {};
    public _lastClick: number = 0;
    public auto_entry_status: number = 0;
    public current_mini_id: number = 0;
    public cur_mini_idx: any = -1;
    public current_date: string = "";
    public cur_date_idx: any = -1;
    public _items: any[] = [];
    public _lastNode: any = null;
    public time_action: any = null;
    public leftTime: number = 0;
    public _reqStep: any = -1;
    public _startCd: boolean = false;
    public nIdx: number = 0;
    public vCurRoomList: any[] = [];
    public bestIndex: number = 0;
    public lastIndex: number = 0;
    public b_refresh: boolean = false;
    public b_scheduleRefresh: boolean = false;
    public cur_schedule_idx: number = 0;
    public _isScrolling: boolean = false;
    public _scrollHei: number = 0;
    public _tmpScrollHei: number = 0;
    public freshDistance: number = 0;
    public tmpTimeIdx: any = -1;
    public timeItems: any[] = [];
    public sel_color: any = color(147, 11, 11, 255);
    onTouchBegan(t) {
        this.b_refresh = false;
    }
    srollviewCallback(t) {
        this._isScrolling = true;
        let e = this.scrollView.content.getComponent(UITransform).height;
        if (e > this._tmpScrollHei) {
            let t = this.scrollView.getScrollOffset().y;
            this.b_refresh = false;
            this.rank_listData.length > 0 && t + this._tmpScrollHei > e + this.freshDistance && (this.b_refresh = true);
        }
    }
    scrollviewEnd(t) {
        this._isScrolling = false;
        this.b_refresh && this.scrollRefreshCallBack && this.scrollRefreshCallBack();
    }
    onScheduleSrollviewTouchBegan(t) {
        this.b_scheduleRefresh = false;
    }
    scheduleSrollviewCallback(t) {
        this._isScrolling = true;
        let e = this.scheduleScrollView.content.getComponent(UITransform).height, i = this.scheduleScrollView.node.getComponent(UITransform).height;
        if (e > i) {
            let t = this.scheduleScrollView.getScrollOffset().y;
            this.b_scheduleRefresh = false;
            sys.isObjectValid(this.scheduleData) && this.scheduleData.schedule.length > 0 && t + i > e + 30 && (this.b_scheduleRefresh = true);
        }
    }
    scheduleScrollviewEnd(t) {
        this._isScrolling = false;
        this.b_scheduleRefresh && this.scheduleRefreshCallBack && this.scheduleRefreshCallBack();
    }
    onEnable() {
        sys.isObjectValid(this.scrollView) && (this.scrollView.node.on(Node.EventType.TOUCH_START, this.onTouchBegan, this), this.scrollView.node.on(ScrollView.EventType.SCROLL_BEGAN, this.srollviewCallback, this), this.scrollView.node.on(ScrollView.EventType.SCROLLING, this.srollviewCallback, this), this.scrollView.node.on(ScrollView.EventType.SCROLL_ENDED, this.scrollviewEnd, this), this.scrollView.node.on(Node.EventType.TOUCH_END, this.scrollviewEnd, this), this.scrollView.node.on(Node.EventType.TOUCH_CANCEL, this.scrollviewEnd, this), this.scrollView.node.on(Node.EventType.MOUSE_LEAVE, this.scrollviewEnd, this));
        sys.isObjectValid(this.scheduleScrollView) && (this.scheduleScrollView.node.on(Node.EventType.TOUCH_START, this.onScheduleSrollviewTouchBegan, this), this.scheduleScrollView.node.on(ScrollView.EventType.SCROLL_BEGAN, this.scheduleSrollviewCallback, this), this.scheduleScrollView.node.on(ScrollView.EventType.SCROLLING, this.scheduleSrollviewCallback, this), this.scheduleScrollView.node.on(ScrollView.EventType.SCROLL_ENDED, this.scheduleScrollviewEnd, this), this.scheduleScrollView.node.on(Node.EventType.TOUCH_END, this.scheduleScrollviewEnd, this), this.scheduleScrollView.node.on(Node.EventType.TOUCH_CANCEL, this.scheduleScrollviewEnd, this), this.scheduleScrollView.node.on(Node.EventType.MOUSE_LEAVE, this.scheduleScrollviewEnd, this));
    }
    onDisable() {
        sys.isObjectValid(this.scrollView) && (this.scrollView.node.off(Node.EventType.TOUCH_START, this.onTouchBegan, this), this.scrollView.node.off(ScrollView.EventType.SCROLL_BEGAN, this.srollviewCallback, this), this.scrollView.node.off(ScrollView.EventType.SCROLLING, this.srollviewCallback, this), this.scrollView.node.off(ScrollView.EventType.SCROLL_ENDED, this.scrollviewEnd, this), this.scrollView.node.off(Node.EventType.TOUCH_END, this.scrollviewEnd, this), this.scrollView.node.off(Node.EventType.TOUCH_CANCEL, this.scrollviewEnd, this), this.scrollView.node.off(Node.EventType.MOUSE_LEAVE, this.scrollviewEnd, this));
        sys.isObjectValid(this.scheduleScrollView) && (this.scheduleScrollView.node.off(Node.EventType.TOUCH_START, this.onScheduleSrollviewTouchBegan, this), this.scheduleScrollView.node.off(ScrollView.EventType.SCROLL_BEGAN, this.scheduleSrollviewCallback, this), this.scheduleScrollView.node.off(ScrollView.EventType.SCROLLING, this.scheduleSrollviewCallback, this), this.scheduleScrollView.node.off(ScrollView.EventType.SCROLL_ENDED, this.scheduleScrollviewEnd, this), this.scheduleScrollView.node.off(Node.EventType.TOUCH_END, this.scheduleScrollviewEnd, this), this.scheduleScrollView.node.off(Node.EventType.TOUCH_CANCEL, this.scheduleScrollviewEnd, this), this.scheduleScrollView.node.off(Node.EventType.MOUSE_LEAVE, this.scheduleScrollviewEnd, this));
    }
    onLoad() {
        this.fitScreen();
        sys.isObjectValid(User.shared().hallLeaderBoardMainData) && sys.isObjectValid(User.shared().hallLeaderBoardMainData.cycle_sn) && (this.cycle_sn = User.shared().hallLeaderBoardMainData.cycle_sn);
        this.fitLuckyTheme();
    }
    fitLuckyTheme() {
        0 != GameConfig.NATIVE_GAME_APP_TYPE && (this.sel_color = color(221, 3, 3, 255), this.rootNode.getChildByName("top").getChildByName("top_bg").getComponent(Sprite).color = color(12, 26, 60), this.tabRootNode.getChildByName("bg").getComponent(Sprite).color = color(250, 250, 250, 255), this.tabRootNode.getChildByName("tab0").getChildByName("line").getComponent(Sprite).color = color(221, 3, 3, 255), this.tabRootNode.getChildByName("tab1").getChildByName("line").getComponent(Sprite).color = color(221, 3, 3, 255), this.scheduleListNode.getChildByName("total_bg").getComponent(Sprite).color = color(12, 26, 60, 255), this.bannerRewardNode.getChildByName("total_bg").getComponent(Sprite).color = color(12, 26, 60, 255));
    }
    start() {
        super.start();
        this.time_action = TweenTool.myschedule(this.node, 1, this.updatTime.bind(this));
        this.freshDistance = this.rank_itemNode.getComponent(UITransform).contentSize.height;
        this.initViewTab();
        this.updateSelectBtnState(false);
        sys.isObjectValid(User.shared().hallLeaderBoardMainData) && sys.isObjectValid(User.shared().hallLeaderBoardMainData.cycle_sn) ? this.requestGetRankDetail(true) : User.shared().requestLeaderBoarderMainFramePage();
        PushCenter.shared().addListener(PushEvent.RefreshHallLeaderBoardMain, (t => {
            ToolUtils.isObjValid(this.node) && (sys.isObjectValid(User.shared().hallLeaderBoardMainData) && sys.isObjectValid(User.shared().hallLeaderBoardMainData.cycle_sn) && (this.cycle_sn = User.shared().hallLeaderBoardMainData.cycle_sn), this.requestGetRankDetail(true));
        }), this);
        PushCenter.shared().addListener(PushEvent.RefreshHallLeaderBoardsPage, (t => {
            ToolUtils.isObjValid(this.node) && this.requestGetLeaderBoardList(false);
        }), this);
        ToolUtils.isObjValid(this._lastNode) && (this._lastNode.active = false);
    }
    requestGetRankDetail(t = false) {
        let e = { cycle_sn: this.cycle_sn, uid: User.shared().data.uid };
        t && Utils.shared().showLoading(10, true, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
        }));
        HttpManager.shared().doGetCommonRequest(e, HttpRequest.HallRankDetail, ((e, i, a) => {
            if (Utils.shared().hideLoading(), 200 != a) {
                t && ToolUtils.isObjValid(this.node) && Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.request_fail"), 2);
            }
            else {
                try {
                    let t = ToolUtils.parseJson(i);
                    if (0 == t.ret) {
                        if (sys.isObjectValid(t.data) && ToolUtils.isObjValid(this.node)) {
                            if (this.rankDetailData = t.data, this.leftTime = ToolUtils.isSafeNumber(this.rankDetailData.mini_tab.left_time), this._startCd = true, this.updatTime(), this.initTopView(), sys.isObjectValid(t.data.my_rank_info) && sys.isObjectValid(t.data.rank_list)) {
                                if ((1 == this._tabIndex ? "cycle" : "daily") == ToolUtils.isSafeString(t.data.type)) {
                                    if (this._isSendMsg = false, 1 == this.cur_page && sys.isObjectValid(t.data.my_rank_info) && (this.myRankData = t.data.my_rank_info, this.rank_listData.push(this.myRankData)), sys.isObjectValid(t.data.rank_list) && Array.isArray(t.data.rank_list) && t.data.rank_list.length > 0) {
                                        for (let e = 0, i = t.data.rank_list.length; e < i; e++) {
                                            this.rank_listData.push(t.data.rank_list[e]);
                                        }
                                    }
                                    sys.isObjectValid(t.data.has_next_page) && (this.has_next_page = t.data.has_next_page);
                                    this.freshRankList(this.rank_listData, 0 == this.has_next_page);
                                    sys.isObjectValid(t.data.page) && (this.cur_page = t.data.page);
                                }
                            }
                            else {
                                this.refreshListUI();
                            }
                        }
                    }
                    else {
                        ToolUtils.isObjValid(this.node) && sys.isObjectValid(t.desc) && t.desc.length > 0 && Utils.shared().showToast(t.desc, 2);
                    }
                }
                catch (t) {
                    TLog.printError("requestGetRankDetail err:", t.toString());
                }
            }
        }));
    }
    requestGetLeaderBoardList(t = false) {
        let e = "daily";
        1 == this._tabIndex && (e = "cycle");
        let i = { type: e, cycle_sn: this.cycle_sn, page: this.cur_page, search_date: this.current_date, mini_id: this.current_mini_id, origin: 2 };
        t && Utils.shared().showLoading(10, true, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
        }));
        HttpManager.shared().doGetCommonRequest(i, HttpRequest.HallRankBoardList, ((e, i, a) => {
            if (Utils.shared().hideLoading(), 200 != a) {
                t && Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.request_fail"), 2);
                ToolUtils.isObjValid(this.node) && (this._isSendMsg = false, this.cur_page > 1 && (this.cur_page = this.cur_page - 1), 1 == this.cur_page && this.freshRankList([]));
            }
            else {
                try {
                    let t = ToolUtils.parseJson(i);
                    if (0 == t.ret) {
                        if (sys.isObjectValid(t.data) && ToolUtils.isObjValid(this.node)) {
                            if ((1 == this._tabIndex ? "cycle" : "daily") == ToolUtils.isSafeString(t.data.type)) {
                                if (this._isSendMsg = false, 1 == this.cur_page && sys.isObjectValid(t.data.my_rank_info) && (this.myRankData = t.data.my_rank_info, this.rank_listData.push(this.myRankData)), sys.isObjectValid(t.data.rank_list) && Array.isArray(t.data.rank_list) && t.data.rank_list.length > 0) {
                                    for (let e = 0, i = t.data.rank_list.length; e < i; e++) {
                                        this.rank_listData.push(t.data.rank_list[e]);
                                    }
                                }
                                sys.isObjectValid(t.data.has_next_page) && (this.has_next_page = t.data.has_next_page);
                                this.freshRankList(this.rank_listData, 0 == this.has_next_page);
                                sys.isObjectValid(t.data.page) && (this.cur_page = t.data.page);
                            }
                        }
                    }
                    else {
                        ToolUtils.isObjValid(this.node) && 1 == this.cur_page && this.freshRankList([]);
                    }
                }
                catch (t) {
                    TLog.printError("requestGetLeaderBoardList err:", t.toString());
                }
            }
        }));
    }
    updatTime() {
        return this._startCd ? (this.leftTime = this.leftTime - 1, this.leftTime <= 0 ? (this.leftTimeTx.getComponent(Label).string = "", this.bottomLeftTimeTx.getComponent(Label).string = "", this._startCd = false, void (-1 == this._reqStep && (this._reqStep = 1, this.requestGetRankDetail()))) : (this._reqStep = -1, this.leftTimeTx.getComponent(Label).string = Utils.shared().getCountDownString(this.leftTime), void (this.bottomLeftTimeTx.getComponent(Label).string = Utils.shared().getCountDownString(this.leftTime)))) : (this._reqStep++, void (this._reqStep % 5 == 0 && (this.requestGetRankDetail(), this._reqStep = 0)));
    }
    freshListTopInfo() {
        if (this.tmpTimeIdx = -1, 0 == this._tabIndex && sys.isObjectValid(this.rankDetailData.mini_tab)) {
            this.totalPrizeTx.getComponent(Label).string = ToolUtils.format("${0}", this.rankDetailData.mini_tab.total_reward);
            this.leftTimeArrow.active = true;
            this.detaSelectBtn.getComponent(Button).interactable = true;
            let t = this.current_date + "_" + this.current_mini_id;
            for (let e = 0, i = this.rankDetailData.mini_tab.select_item.length; e < i; e++) {
                if (t == this.rankDetailData.mini_tab.select_item[e].key) {
                    this.subTimeTx.getComponent(Label).string = this.rankDetailData.mini_tab.select_item[e].value;
                    this.tmpTimeIdx = e;
                    break;
                }
            }
            for (let t = 0, e = this.rankDetailData.mini_tab.reward_list.length; t < e; t++) {
                if (this.current_mini_id == this.rankDetailData.mini_tab.reward_list[t].mini_id) {
                    this.totalPrizeTx.getComponent(Label).string = ToolUtils.format("${0}", this.rankDetailData.mini_tab.reward_list[t].total_reward);
                    break;
                }
            }
        }
        else {
            1 == this._tabIndex && sys.isObjectValid(this.rankDetailData.mega_tab) && (this.totalPrizeTx.getComponent(Label).string = ToolUtils.format("${0}", this.rankDetailData.mega_tab.total_reward), this.subTimeTx.getComponent(Label).string = this.rankDetailData.time_str, this.leftTimeArrow.active = false, this.detaSelectBtn.getComponent(Button).interactable = false);
        }
    }
    freshRankList(t, e = false) {
        this.rank_itemNode.getComponent(UITransform).contentSize.height;
        let i = this.scrollView.content, a = (this.scrollView.view, sys.getSafeAreaRect().y), s = view.getVisibleSize().height - GameConfig.CONFIG_SCREEN_HEIGHT - a;
        s <= 0 && (s = 0);
        for (let e = 0, a = t.length; e < a; e++) {
            if (ToolUtils.isObjValid(this._items[e])) {
                this._items[e].parent = i;
            }
            else {
                let t = instantiate(this.rank_itemNode);
                t.name = "rank_item_" + e;
                t.active = true;
                i.addChild(t);
                this._items.push(t);
            }
            this.initRankItem(this._items[e], t[e], e);
        }
        for (let e = t.length, i = this._items.length; e < i; e++) {
            this._items[e].active = false;
            this._items[e].parent = this.node;
        }
        if (this.bottomNode.active) {
            this.scrollView.content.getComponent(Layout).paddingBottom = e ? 80 : 0;
        }
    }
    scrollRefreshCallBack() {
        1 != this.has_next_page || this._isSendMsg || (this._isSendMsg = true, this.cur_page = this.cur_page + 1, this.requestGetLeaderBoardList(false));
    }
    scheduleRefreshCallBack() {
        let t = this.scheduleData ? this.scheduleData.schedule : [];
        if (t.length > 0 && this.cur_schedule_idx < t.length - 1) {
            let e = 3, i = this.cur_schedule_idx + e <= t.length - 1 ? this.cur_schedule_idx + e : t.length, a = this.scheduleListNode.getChildByName("item_date"), s = this.scheduleListNode.getChildByName("item_time"), o = this.scheduleScrollView.content;
            for (let e = this.cur_schedule_idx; e < i; e++) {
                let i = t[e], l = instantiate(a);
                l.getChildByName("wz").getComponent(Label).string = "" + i.show_day;
                l.active = true;
                o.addChild(l);
                for (let t = 0, e = i.reward_list.length; t < e; t++) {
                    let e = instantiate(s);
                    e.getChildByName("wz").getComponent(Label).string = "" + i.reward_list[t].show_range_time;
                    e.getChildByName("num").getComponent(Label).string = "" + i.reward_list[t].total_reward;
                    1 == i.reward_list[t].is_live ? e.getChildByName("mask").getChildByName("ico").getComponent(Sprite).color = color(23, 141, 29, 255) : e.getChildByName("mask").getChildByName("ico").getComponent(Sprite).color = color(158, 158, 158, 255);
                    e.active = true;
                    o.addChild(e);
                }
            }
            this.cur_schedule_idx = i;
        }
    }
    requestGetScheduleList(t = false) {
        t && Utils.shared().showLoading(10, true, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
        }));
        HttpManager.shared().doGetCommonRequest({ uid: User.shared().data.uid, cycle_sn: this.cycle_sn }, "Activity.Act_116.getScheduleList", ((e, i, a) => {
            if (t && Utils.shared().hideLoading(), 200 != a) {
                t && Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.request_fail"), 2);
            }
            else {
                try {
                    let e = ToolUtils.parseJson(i);
                    0 == e.ret ? sys.isObjectValid(e.data) && ToolUtils.isObjValid(this.node) && (this.scheduleData = e.data, t && this.showScheduleList()) : ToolUtils.isSafeString(e.desc).length > 0 && ToolUtils.isObjValid(this.node) && Utils.shared().showToast(e.desc, 2, 0, ToolUtils.getIsNormalDirection());
                }
                catch (t) {
                    TLog.printError("requestGetLeaderBoardList err:", t.toString());
                }
            }
        }));
    }
    showScheduleList() {
        sys.isObjectValid(this.scheduleData) && sys.isObjectValid(this.scheduleData.schedule) && (this.tool_rootNode.active = true, this.tool_rootNode.getChildByName("mask").active = true, this.scheduleListNode.active = true, sys.isObjectValid(this.scheduleData.top_tips) && (this.scheduleListNode.getChildByName("title").getComponent(Label).string = "" + this.scheduleData.top_tips), sys.isObjectValid(this.scheduleData.start_day) && sys.isObjectValid(this.scheduleData.end_day) && (this.scheduleListNode.getChildByName("date").getComponent(Label).string = ToolUtils.format("${0} to ${1}", this.scheduleData.start_day, this.scheduleData.end_day)), sys.isObjectValid(this.scheduleData.total_reward) && (this.scheduleListNode.getChildByName("total").getComponent(Label).string = ToolUtils.format("Total Prize: ${0}", this.scheduleData.total_reward)), this.cur_schedule_idx = 0, this.scheduleScrollView.content.removeAllChildren(), this.scheduleRefreshCallBack());
    }
    showBannerRewardView() {
        if (this.tool_rootNode.active = true, this.tool_rootNode.getChildByName("mask").active = true, this.bannerRewardNode.active = true, ToolUtils.startShowAnim(this.bannerRewardNode), this.bannerRewardNode.getChildByName("total").getComponent(Label).string = ToolUtils.format("Total Prize Issued: ${0}", this.rankDetailData.issued_reward), sys.isObjectValid(this.rankDetailData.pass_reward_list)) {
            let t = this.bannerRewardNode.getChildByName("ScrollView").getComponent(ScrollView).content;
            t.removeAllChildren();
            let e = this.bannerRewardNode.getChildByName("item_date");
            e.active = false;
            for (let i = 0, a = this.rankDetailData.pass_reward_list.length; i < a; i++) {
                let a = this.rankDetailData.pass_reward_list[i], s = instantiate(e);
                s.getChildByName("wz").getComponent(Label).string = ToolUtils.format("${0} to ${1}", a.start_time, a.end_time);
                s.getChildByName("num").getComponent(Label).string = "" + a.total_reward;
                s.active = true;
                t.addChild(s);
            }
        }
    }
    showTotalPrizeView() {
        this.tool_rootNode.active = true;
        this.tool_rootNode.getChildByName("mask").active = true;
        this.totalPrizeNode.active = true;
        let t = this.totalPrizeNode.getChildByName("num"), e = this.totalPrizeNode.getChildByName("ScrollView").getComponent(ScrollView).content, i = this.totalPrizeNode.getChildByName("rank_item");
        i.active = false;
        let a = [];
        if (0 == this._tabIndex && sys.isObjectValid(this.rankDetailData.mini_tab)) {
            let e = this.current_mini_id;
            for (let i = 0, s = this.rankDetailData.mini_tab.reward_list.length; i < s; i++) {
                if (e == this.rankDetailData.mini_tab.reward_list[i].mini_id) {
                    t.getComponent(Label).string = ToolUtils.format("${0}", this.rankDetailData.mini_tab.reward_list[i].total_reward);
                    a = this.rankDetailData.mini_tab.reward_list[i].reward_list;
                    break;
                }
            }
        }
        else if (1 == this._tabIndex && sys.isObjectValid(this.rankDetailData.mega_tab)) {
            t.getComponent(Label).string = ToolUtils.format("${0}", this.rankDetailData.mega_tab.total_reward);
            a = this.rankDetailData.mega_tab.reward_list;
        }
        else if (2 == this._tabIndex && sys.isObjectValid(this.rankDetailData.mini_tab)) {
            for (let e = 0, i = this.rankDetailData.mini_tab.reward_list.length; e < i; e++) {
                if (this.current_mini_id == this.rankDetailData.mini_tab.reward_list[e].mini_id) {
                    t.getComponent(Label).string = ToolUtils.format("${0}", this.rankDetailData.mini_tab.reward_list[e].total_reward);
                    a = this.rankDetailData.mini_tab.reward_list[e].reward_list;
                    break;
                }
            }
        }
        e.removeAllChildren();
        for (let t = 0, s = a.length; t < s; t++) {
            let s = instantiate(i);
            s.getChildByName("rank").getComponent(Label).string = ToolUtils.format("Rank ${0}", a[t].rank);
            s.active = true;
            e.addChild(s);
            sys.isObjectValid(a[t].bmoney) && a[t].bmoney > 0 && (s.getChildByName("prize").getComponent(Label).string = ToolUtils.format("₹${0}", a[t].bmoney));
        }
    }
    initTopView() {
        let t = this.rankDetailData;
        if (sys.isObjectValid(t)) {
            let e = this.topNode.getChildByName("bannel_reward").getComponent(Label);
            sys.isObjectValid(t.issued_reward) && (e.string = ToolUtils.isSafeString(t.issued_reward));
            let i = this.topNode.getChildByName("reward").getComponent(Label), a = this.bottomNode.getChildByName("tip").getComponent(Label);
            sys.isObjectValid(t.total_reward) && (i.string = ToolUtils.isSafeString(t.total_reward), a.string = ToolUtils.format("Win ${0} Cash Prize", t.total_reward));
            let s = this.topNode.getChildByName("fee_node").getChildByName("wz").getComponent(Label);
            sys.isObjectValid(t.ratio_tips) && (s.string = "" + t.ratio_tips);
            let o = this.topNode.getChildByName("variant_node").getChildByName("wz").getComponent(Label);
            sys.isObjectValid(t.game_play_tips) && (o.string = "" + t.game_play_tips);
            let l = this.topNode.getChildByName("entryFee_node").getChildByName("wz").getComponent(Label);
            if (sys.isObjectValid(t.entry_tips) && (l.string = "" + t.entry_tips), sys.isObjectValid(t.cycle_tips)) {
                this.topNode.getChildByName("reward_subtitle").getComponent(Label).string = "" + t.cycle_tips;
            }
            t.mini_tab && (this.current_mini_id = t.mini_tab.current_mini_id, this.current_date = t.mini_tab.current_date);
            this.freshListTopInfo();
            sys.isObjectValid(t.entry_status) && (this.status = t.entry_status, this.refreshOptStatusView());
        }
    }
    refreshOptStatusView() {
        if (0 == this.status) {
            this.optInBtn.active = true;
            this.topNode.getChildByName("live").active = true;
            this.bottomNode.active = true;
            this.bottomNode.getChildByName("btn_otpin").active = true;
            this.bottomNode.getChildByName("btn_playnow").active = false;
            this.playBtn.active = false;
            this.optOutBtn.active = false;
            this.endBtn.active = false;
            let t = this.scrollView.node.getComponent(UITransform).contentSize;
            t.height != this._scrollHei && (this.scrollView.node.getComponent(UITransform).setContentSize(size(t.width, this._scrollHei)), this._tmpScrollHei = this._scrollHei);
        }
        else if (1 == this.status) {
            this.optOutBtn.active = true;
            this.playBtn.active = true;
            this.topNode.getChildByName("live").active = true;
            this.bottomNode.active = true;
            this.bottomNode.getChildByName("btn_playnow").active = true;
            this.bottomNode.getChildByName("btn_otpin").active = false;
            this.optInBtn.active = false;
            this.endBtn.active = false;
            let t = this.scrollView.node.getComponent(UITransform).contentSize;
            t.height != this._scrollHei && (this.scrollView.node.getComponent(UITransform).setContentSize(size(t.width, this._scrollHei)), this._tmpScrollHei = this._scrollHei);
        }
        else if (2 == this.status) {
            this.endBtn.active = true;
            this.playBtn.active = false;
            this.bottomNode.active = false;
            this.optInBtn.active = false;
            this.topNode.getChildByName("live").active = false;
            this.optOutBtn.active = false;
            let t = this.scrollView.node.getComponent(UITransform).contentSize;
            t.height != this._scrollHei + 72 && (this.scrollView.node.getComponent(UITransform).setContentSize(size(t.width, this._scrollHei + 72)), this._tmpScrollHei = this._scrollHei + 72);
        }
    }
    initParaData(t) {
        sys.isObjectValid(t) && sys.isObjectValid(t.isNext) && (this.isNext = t.isNext);
        sys.isObjectValid(t) && sys.isObjectValid(t.tab) && (this._tabIndex = t.tab);
        sys.isObjectValid(t) && sys.isObjectValid(t.lastNode) && (this._lastNode = t.lastNode);
    }
    initViewTab() {
        let t = "";
        for (let e = 0; e < 2; e++) {
            t = "tab" + e;
            let i = this.tabRootNode.getChildByName(t);
            this._tabItemArr[e] = i;
        }
    }
    tabViewClick(t, e) {
        SoundManager.shared().playFx("click");
        this._tabIndex != Number(e) && (this._tabIndex = Number(e), 0 == this._tabIndex && this.rankDetailData.mini_tab && (this.current_mini_id = this.rankDetailData.mini_tab.current_mini_id, this.current_date = this.rankDetailData.mini_tab.current_date), this.freshListTopInfo(), this.refreshListUI(), this.updateSelectBtnState());
    }
    updateSelectBtnState(t = true) {
        let e = this.sel_color, i = color(102, 102, 102, 255);
        for (let a = 0, s = this._tabItemArr.length; a < s; a++) {
            let s = this._tabItemArr[a], o = s.getChildByName("wz"), l = s.getChildByName("line");
            if (a == this._tabIndex) {
                if (s.getComponent(Button).interactable = false, o.getComponent(Label).color = e, i18nMgr.shared().changeLabelFont(o.getComponent(Label), true), l.active = true, TweenTool.stopNodeAction(l), t) {
                    l.scale = v3(0, 1, 1);
                    let t = TweenTool.scaleTo(l, 0.16, v3(1.1, 1, 1), null, false), e = TweenTool.scaleTo(l, 0.16, v3(1, 1, 1), null, false);
                    TweenTool.sequence(l, true, null, t, e);
                }
                else {
                    l.scale = v3(1, 1, 1);
                }
            }
            else {
                s.getComponent(Button).interactable = true;
                o.getComponent(Label).color = i;
                i18nMgr.shared().changeLabelFont(o.getComponent(Label), false);
                TweenTool.stopNodeAction(l);
                l.scale = v3(1, 1, 1);
                t ? TweenTool.scaleTo(l, 0.1, v3(0.2, 1, 1), null, true, (() => {
                    l.scale = v3(1, 1, 1);
                    l.active = false;
                })) : l.active = false;
            }
        }
    }
    onDateSelectClick(t, e) {
        SoundManager.shared().playFx("click");
        let i = Number(e);
        this.tmpTimeIdx = i;
        this.updateTmpTimeSelect();
    }
    updateTmpTimeSelect() {
        for (let t = 0, e = this.timeItems.length; t < e; t++) {
            t == this.tmpTimeIdx ? (this.timeItems[t].getChildByName("image").getComponent(Sprite).spriteFrame = this.timeSelectSprites[1], this.timeItems[t].getChildByName("wz").getComponent(Label).color = color(51, 51, 51, 255), i18nMgr.shared().changeLabelFont(this.timeItems[t].getChildByName("wz").getComponent(Label), true)) : (this.timeItems[t].getChildByName("image").getComponent(Sprite).spriteFrame = this.timeSelectSprites[0], this.timeItems[t].getChildByName("wz").getComponent(Label).color = color(102, 102, 102, 255), i18nMgr.shared().changeLabelFont(this.timeItems[t].getChildByName("wz").getComponent(Label), false));
        }
    }
    refreshListUI() {
        sys.isObjectValid(this.rankDetailData.total_reward) && (this.scrollView.stopAutoScroll(), this.scrollView.scrollToOffset(v2(0, 0)), this.rank_listData = [], this.cur_page = 1, this.requestGetLeaderBoardList(true));
    }
    onButtonClick(t, e) {
        switch ((SoundManager.shared().playFx("click"), String(e))) {
            case "close":
                this.onBackView();
                break;
            case "schedule":
                sys.isObjectValid(this.scheduleData.schedule) ? this.showScheduleList() : this.requestGetScheduleList(true);
                break;
            case "close_schedule":
                this.tool_rootNode.active = false, this.tool_rootNode.getChildByName("mask").active = false, this.scheduleListNode.active = false;
                break;
            case "auto_help":
                this.tool_rootNode.active = true, this.autoTipsNode.active = true;
                break;
            case "hide_tool":
                this.tool_rootNode.active = false, this.tool_rootNode.getChildByName("mask").active = false, this.autoTipsNode.active = false, this.optInNode.active = false, this.optInSuccNode.active = false, this.optOutNode.active = false, this.optOutSuccNode.active = false, this.totalPrizeNode.active = false, this.detaSelecctNode.active = false, this.bannerRewardNode.active = false, this.scheduleListNode.active = false;
                break;
            case "opt_out":
                this.showOptOutView();
                break;
            case "opt_out_process":
                Utils.shared().showLoading(10, true, (() => {
                    Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
                })), User.shared().dealLeadboardLogic_OptOut((t => {
                    ToolUtils.isObjValid(this.node) && (this.status = t, this.refreshOptStatusView(), Utils.shared().hideLoading(), 0 == this.status && (this.optOutNode.active = false, this.showOptOutSuccView()));
                }));
                break;
            case "opt_in":
                this.showOptInView();
                break;
            case "close":
                this.onBackView();
                break;
            case "opt_in_process":
                Utils.shared().showLoading(10, true, (() => {
                    Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
                })), User.shared().dealLeadboardLogic_OptIn((t => {
                    ToolUtils.isObjValid(this.node) && (Utils.shared().hideLoading(), this.status = t, this.refreshOptStatusView(), 1 == this.status && (this.optInNode.active = false, this.showOptInSuccView()));
                }));
                break;
            case "playnow":
            case "opt_in_playnow":
                PushCenter.shared().pushEvent(PushEvent.FastStartGame);
                break;
            case "hide_opt_in_succ":
                this.tool_rootNode.active = false, this.tool_rootNode.getChildByName("mask").active = false, this.optInSuccNode.active = false;
                break;
            case "opt_in_close":
                this.tool_rootNode.active = false, this.tool_rootNode.getChildByName("mask").active = false, this.optInNode.active = false;
                break;
            case "opt_out_close":
                this.tool_rootNode.active = false, this.tool_rootNode.getChildByName("mask").active = false, this.optOutNode.active = false;
                break;
            case "hide_opt_out_succ":
                this.tool_rootNode.active = false, this.tool_rootNode.getChildByName("mask").active = false, this.optOutSuccNode.active = false;
                break;
            case "total_prize":
                this.showTotalPrizeView();
                break;
            case "total_prize_close":
                this.tool_rootNode.active = false, this.tool_rootNode.getChildByName("mask").active = false, this.totalPrizeNode.active = false;
                break;
            case "date":
                this.showDateSelectView();
                break;
            case "date_select_close":
                this.tool_rootNode.active = false, this.tool_rootNode.getChildByName("mask").active = false, this.detaSelecctNode.active = false;
                break;
            case "selectDate_reset":
                this.tmpTimeIdx = -1, this.updateTmpTimeSelect();
                break;
            case "selectDate_confirm":
                let t = this.tmpTimeIdx < 0 ? 0 : this.tmpTimeIdx, e = null;
                if (Array.isArray(this.rankDetailData.mini_tab.select_item) && this.rankDetailData.mini_tab.select_item.length > 0 && (e = this.rankDetailData.mini_tab.select_item[t]), this.detaSelecctNode.active = false, this.tool_rootNode.getChildByName("mask").active = false, this.tool_rootNode.active = false, e) {
                    let [t, i] = e.key.split("_");
                    this.current_date == t && this.current_mini_id == i || (this.current_date = t, this.current_mini_id = i, this.freshListTopInfo(), this.refreshListUI());
                    1 == e.is_live ? this.titleNode.getChildByName("title2").getComponent(Label).string = "Expected Prize" : this.titleNode.getChildByName("title2").getComponent(Label).string = "Rewards";
                }
                break;
            case "banner_reward":
                this.showBannerRewardView();
                break;
            case "close_bannerReward": this.tool_rootNode.active = false, this.tool_rootNode.getChildByName("mask").active = false, this.bannerRewardNode.active = false;
        }
    }
    enterGame(t) {
        if (this.optInSuccNode.getChildByName("btn_playnow").getComponent(Button).interactable = false, TweenTool.delayAct(this.node, (() => {
            ToolUtils.isObjValid(this.node) && (this.optInSuccNode.getChildByName("btn_playnow").getComponent(Button).interactable = true);
        }), 1, true), t && t.vid) {
            let e = t.vid;
            User.shared().min_money = t.entry;
            ToolUtils.curRoomId = e;
            let i = {};
            i.lobby = this.gameType;
            i.game = this.rummyType;
            i.data = t;
            ToolUtils.saveData(User.shared().data.uid + "recommendRoom" + this.gameType + this.rummyType, ToolUtils.toJsonString(i));
            ToolUtils.saveData(User.shared().data.uid + "recommendRoomNew", ToolUtils.toJsonString(i));
            ToolUtils.curRoomId = e;
            Utils.shared().showCommEnterRoom({ vid: e, game_type: this.rummyType, is_back: 0, isNewTable: 1 });
        }
    }
    showDateSelectView() {
        this.tool_rootNode.active = true;
        this.tool_rootNode.getChildByName("mask").active = true;
        this.detaSelecctNode.active = true;
        let t = this.detaSelecctNode.getChildByName("date_item");
        t.active = false;
        let e = this.detaSelecctNode.getChildByName("ScrollView").getComponent(ScrollView).content, i = [];
        Array.isArray(this.rankDetailData.mini_tab.select_item) && this.rankDetailData.mini_tab.select_item.length > 0 && (i = this.rankDetailData.mini_tab.select_item);
        Array.isArray(e.children) && e.children.length > 0 && e.removeAllChildren();
        this.timeItems = [];
        for (let a = 0, s = i.length; a < s; a++) {
            let s = instantiate(t);
            s.active = true;
            e.addChild(s);
            this.timeItems.push(s);
            s.getChildByName("wz").getComponent(Label).string = ToolUtils.isSafeString(i[a].value);
            s.getChildByName("live").active = 1 == i[a].is_live;
            s.getComponent(Button).clickEvents[0].customEventData = "" + a;
        }
        this.tmpTimeIdx > i.length && (this.tmpTimeIdx = 0);
        this.updateTmpTimeSelect();
    }
    showOptInView() {
        this.tool_rootNode.active = true;
        this.tool_rootNode.getChildByName("mask").active = true;
        this.optInNode.active = true;
        sys.isObjectValid(this.rankDetailData) && sys.isObjectValid(this.rankDetailData.total_reward_num) && (this.optInNode.getChildByName("total").getComponent(Label).string = this.rankDetailData.total_reward_num);
    }
    showOptInSuccView() {
        this.tool_rootNode.active = true;
        this.tool_rootNode.getChildByName("mask").active = true;
        this.optInSuccNode.active = true;
        let t = 6, e = PointsType.Classic;
        sys.isObjectValid(this.rankDetailData.jump_info) && (this.gameType = this.rankDetailData.jump_info.lobby, this.rummyType = this.rankDetailData.jump_info.game, sys.isObjectValid(this.rankDetailData.jump_info.player) && (t = this.rankDetailData.jump_info.player));
        let i = Utils.shared().getCurSelectRoomList(this.gameType, this.rummyType, t, 101, 2, e);
        if (i && i.length > 0) {
            this.vCurRoomList = i;
            let e = this.getRecommendRoomIndex(i);
            this.vCurRoomList && this.vCurRoomList[e - 1] && (this.optInSuccNode.getChildByName("game_name").getComponent(Label).string = `Points/Classic - ${t}P/${this.vCurRoomList[e - 1].boot}`);
        }
    }
    getRecommendRoomIndex(t, e, i = -1) {
        let a = 0, s = 0;
        -1 == i && (this.bestIndex = 0, this.lastIndex = 0);
        let o = User.shared().data.money;
        if (3 == this.gameType && (o = User.shared().data.money_exe), 0 == i ? o = User.shared().data.money : 1 == i && (o = User.shared().data.money_exe), null != t && sys.isObjectValid(t.length) && t.length > 0) {
            let l;
            for (let n = t.length - 1; n >= 0; n--) {
                sys.isObjectValid(e) && (l = t[n].entry, l == e && (-1 == i ? 0 == this.lastIndex && (this.lastIndex = n + 1) : 0 == s && (s = n + 1)));
                t[n].min_money <= o && o < t[n].max_money && (-1 == i ? 0 == this.bestIndex && (this.bestIndex = n + 1) : 0 == a && (a = n + 1));
            }
            if (sys.isObjectValid(e)) {
                for (let n = t.length - 1; n >= 0; n--) {
                    if (l = t[n].entry, l == e && e <= o) {
                        let t = n + 1;
                        return 0 == this.lastIndex ? t = this.bestIndex : 0 != this.bestIndex && (t = this.lastIndex >= this.bestIndex ? this.lastIndex : this.bestIndex), -1 == i ? t : [t, a, s];
                    }
                }
            }
            for (let e = t.length - 1; e >= 0; e--) {
                if (t[e].min_money <= o && o < t[e].max_money) {
                    let t = e + 1;
                    return 0 == this.lastIndex ? t = this.bestIndex : 0 != this.bestIndex && (t = this.lastIndex >= this.bestIndex ? this.lastIndex : this.bestIndex), -1 == i ? t : [t, a, s];
                }
            }
        }
        return -1 == i ? 1 : [1, a, s];
    }
    onSliderCallback(t, e) {
        let i = 0, a = this.optInSuccNode.getChildByName("slider_view").getChildByName("Slider"), s = a.getChildByName("ProgressBar"), o = a.getComponent(Slider).progress;
        this.vCurRoomList && this.vCurRoomList.length > 1 && (i = Math.floor((this.vCurRoomList.length - 1) * o + 0.5));
        s.getComponent(ProgressBar).progress = o;
        this.updateSliderProgress(i + 1);
    }
    onChangePointClick(t, e) {
        SoundManager.shared().playFx("click");
        sys.now() - this._lastClick < 500 || (this._lastClick = sys.now(), this.vCurRoomList && this.vCurRoomList.length > 0 && ("add" == e ? this.nIdx + 1 < this.vCurRoomList.length && (this.nIdx = this.nIdx + 1, this.updateSliderProgress(this.nIdx + 1)) : this.nIdx > 0 && (this.nIdx = this.nIdx - 1, this.updateSliderProgress(this.nIdx + 1)), this.updateChangePointBtnState()));
    }
    updateSliderProgress(t, e = true) {
        let i = this.optInSuccNode.getChildByName("slider_view").getChildByName("Slider"), a = i.getChildByName("ProgressBar");
        if (this.vCurRoomList && this.vCurRoomList.length > 1) {
            this.nIdx = t - 1;
            let e = (t - 1) / (this.vCurRoomList.length - 1);
            i.getComponent(Slider).progress = e;
            a.getComponent(ProgressBar).progress = e;
            this.updateEntryInfo(t);
        }
        else {
            this.nIdx = 0;
            i.getComponent(Slider).progress = 0;
            a.getComponent(ProgressBar).progress = 0;
            this.updateEntryInfo(1);
        }
    }
    updateEntryInfo(t) {
        let e = this.optInSuccNode.getChildByName("entry_info");
        if (this.vCurRoomList && this.vCurRoomList[t - 1]) {
            e.active = true;
            let i = e.getChildByName("arrow"), a = e.getChildByName("points"), s = a.getChildByName("value"), o = e.getChildByName("entry"), l = o.getChildByName("fee"), n = e.getChildByName("feeNode"), r = n.getChildByName("fee"), h = "", d = "";
            this.rummyType == HowToPlayDefined.RUMMY_POINTS || this.rummyType == HowToPlayDefined.RUMMY_MULTIPLE ? (a.active = true, o.active = true, i.active = true, n.active = false, h = this.vCurRoomList[t - 1].boot, d = this.vCurRoomList[t - 1].entry) : (n.active = true, i.active = false, a.active = false, o.active = false, h = this.vCurRoomList[t - 1].boot, d = this.vCurRoomList[t - 1].entry);
            let c = 3 == this.gameType ? "" : "₹";
            3 == this.gameType && (h = ToolUtils.parse_ChipNum2(h), d = ToolUtils.parse_ChipNum2(d));
            s.getComponent(Label).string = c + h;
            l.getComponent(Label).string = c + d;
            r.getComponent(Label).string = c + d;
        }
        else {
            e.active = false;
        }
        this.updateChangePointBtnState();
        this.refreshRankStar();
    }
    updateChangePointBtnState() {
        let t = this.optInSuccNode.getChildByName("slider_view"), e = t.getChildByName("btn_add").getComponent(Button), i = t.getChildByName("btn_reduce").getComponent(Button);
        this.vCurRoomList && this.vCurRoomList.length > 1 ? (e.interactable = this.nIdx + 1 < this.vCurRoomList.length, i.interactable = this.nIdx > 0) : (e.interactable = false, i.interactable = false);
    }
    refreshRankStar() {
        let t = false, e = 1;
        if (0 == this.gameType) {
            if (2 == User.shared().act_116_not_recommend_show) {
                if (this.vCurRoomList && this.vCurRoomList[this.nIdx]) {
                    let i = this.vCurRoomList[this.nIdx];
                    if (sys.isObjectValid(i) && i.vid) {
                        let a = i.vid;
                        sys.isObjectValid(User.shared().act_116_not_recommend_list) && Array.isArray(User.shared().act_116_not_recommend_list) && -1 === User.shared().act_116_not_recommend_list.indexOf(String(a)) && (t = true, e = 5);
                    }
                }
            }
            else {
                1 == User.shared().act_116_not_recommend_show ? (t = true, e = 5) : 0 == User.shared().act_116_not_recommend_show && (t = false, e = 1);
            }
        }
        this.sliderStarNode.getParent().getComponent(Sprite).spriteFrame = t ? this.rankStarFrame[e] : this.rankStarFrame[0];
    }
    showOptOutView() {
        this.tool_rootNode.active = true;
        this.tool_rootNode.getChildByName("mask").active = true;
        this.optOutNode.active = true;
        sys.isObjectValid(this.rankDetailData) && sys.isObjectValid(this.rankDetailData.total_reward_num) && (this.optOutNode.getChildByName("total").getComponent(Label).string = this.rankDetailData.total_reward_num);
    }
    showOptOutSuccView() {
        this.tool_rootNode.active = true;
        this.tool_rootNode.getChildByName("mask").active = true;
        this.optOutSuccNode.active = true;
    }
    initRankItem(t, e, i) {
        t.active = true;
        let a = t.getChildByName("image"), s = t.getChildByName("rank_sp"), o = t.getChildByName("num"), l = t.getChildByName("name"), n = t.getChildByName("head_mask").getChildByName("head_img"), h = t.getChildByName("prize_node"), u = t.getChildByName("score_node").getChildByName("score");
        if (0 == i ? a && (a.getComponent(Sprite).color = color(255, 247, 224, 255)) : a && (a.getComponent(Sprite).color = color(240, 240, 240, 255)), sys.isObjectValid(e.name) && (l.getComponent(Label).string = ToolUtils.GetShortName2(ToolUtils.isSafeString(e.name), 13, false)), (ToolUtils.isSafeString(e.avatar).length > 0 || ToolUtils.isSafeString(e.avatar_url).length > 0) && Utils.shared().updateHeadImg(n, e.avatar, e.avatar_url, size(84, 84)), sys.isObjectValid(e.rank)) {
            let t = Number(e.rank);
            0 == t ? (s.active = false, o.active = true, o.getComponent(Label).string = "-") : t >= 1 && t <= 3 ? (s.active = true, o.active = false, s.getComponent(Sprite).spriteFrame = this.rankImags[t - 1]) : (s.active = false, o.active = true, o.getComponent(Label).string = "" + t);
        }
        sys.isObjectValid(e.points) && (u.getComponent(Label).string = "" + e.points);
        h.active = false;
        let _ = 0;
        sys.isObjectValid(e.bmoney) && e.bmoney > 0 && (_ += e.bmoney);
        sys.isObjectValid(e.bonus) && e.bonus > 0 && (_ += e.bonus);
        h.getChildByName("cash").active = false;
        h.getChildByName("bonus").active = false;
        h.getChildByName("wz").getComponent(Label).string = _ > 0 ? ToolUtils.format("₹${0}", _) : "-";
        h.active = true;
    }
    onBackView() {
        ToolUtils.isObjValid(this.node) && (Utils.shared().hideLoading(), this.isNext && PushCenter.shared().pushEvent(PushEvent.Update_NextPopActivity), this.node.destroy(), ToolUtils.isObjValid(this._lastNode) && (this._lastNode.active = true));
    }
    fitScreen() {
        ToolUtils.showFullScreen(this.node.getChildByName("mask"));
        ToolUtils.showFullScreen(this.tool_rootNode.getChildByName("mask"));
        let t = ToolUtils.adaptSafeArea(this.rootNode), e = ToolUtils.getSafeDistance();
        ToolUtils.isPadPlatform() && (e = 0);
        let i = 0;
        sys.os === sys.OS.IOS && (i = 20);
        let a = view.getVisibleSize(), s = this.scrollView.node.getComponent(UITransform).contentSize;
        this._scrollHei = a.height - 1280 + s.height - e - i + t;
        this._tmpScrollHei = this._scrollHei;
        this.scrollView.node.getComponent(UITransform).setContentSize(size(s.width, this._scrollHei));
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().removeListenersByTag(this);
        this.unscheduleAllCallbacks();
    }
}
