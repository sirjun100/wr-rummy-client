// @ts-nocheck
// Recovered from index.js:141
import { _decorator, instantiate, Node, size, sp, Sprite, SpriteFrame, sys, tween, UIOpacity, UITransform, v3 } from "cc";
import Parent from "./Parent";
import SoundManager from "./SoundManager";
import { FruitSlotGameManager } from "./FruitSlotGameManager";
import { ToolUtils } from "./ToolUtils";
import TweenTool from "./TweenTool";
import PushCenter from "./PushCenter";
import PushEvent from "./PushEvent";
const { ccclass, property } = _decorator;
@ccclass("FruitSlotGoodsPannel")
export default class FruitSlotGoodsPannel extends Parent {
    public _TAG: string = "FruitSlotGoodsPannel";
    @property(Node)
    public panel_bg: Node = null;
    @property(Node)
    public imgGood: Node = null;
    @property(Node)
    public action_layout: Node = null;
    @property(Node)
    public musicNode: Node = null;
    @property([Node])
    public panelTab: Node[] = [];
    @property([sp.SkeletonData])
    public skeletonData: sp.SkeletonData[] = [];
    @property([Node])
    public nearWinAnimNode: Node[] = [];
    public anim_names: any[] = [["pingguo"], ["mangguo"], ["juzi"], ["putao"], ["xigua"], ["yingtao"], ["lingdang"], ["777"], ["bar"], ["xyc", "xyc_tx"], ["wild", "wild_tx"], ["jackpot_2", "jackpot_1"]];
    @property([SpriteFrame])
    public fruitImgs: SpriteFrame[] = [];
    public panelItem: any[] = [];
    public _gameData: any = {};
    public lastClick: number = 0;
    public ani_time: number = 2.5;
    public shake_dis: number = 70;
    public shake_time: number = 0.2;
    public good_num: number = 40;
    onLoad() {
        this._gameData = {};
        this._gameData.pool_major = 0;
        this._gameData.pool_minor = 0;
        this._gameData.pool_mini = 0;
        this._gameData.jackPotNum = 0;
    }
    start() {
        this.initView();
    }
    onDestroy() {
        super.onDestroy();
        ToolUtils.isObjValid(this.action_layout) && TweenTool.stopNodeAction(this.action_layout);
        ToolUtils.isObjValid(this.musicNode) && TweenTool.stopNodeAction(this.musicNode);
        this.unscheduleAllCallbacks();
        PushCenter.shared().removeListenersByTag(this);
    }
    initView() {
        this.imgGood.active = false;
        this.panelItem = [];
    }
    updateJackpotPool(t, e, i, a) {
    }
    updateJackPotState(t, e, i) {
    }
    touchBtnEvent(t, e) {
    }
    initPanel() {
        for (let t = 0; t < this.panelTab.length; t++) {
            if (ToolUtils.isObjValid(this.panelTab[t])) {
                TweenTool.stopNodeAction(this.panelTab[t]);
                this.panelTab[t].removeAllChildren();
                this.panelTab[t].getComponent(UITransform).contentSize = size(180, 470);
                let e = v3(0, 0);
                this.panelTab[t].getPosition(e);
                this.panelTab[t].setPosition(v3(e.x, 0));
            }
        }
    }
    remove_action_clone() {
        TweenTool.stopNodeAction(this.action_layout);
    }
    formatData(t, e) {
        for (let i = t.length; i >= 1; i--) {
            let a = t[i - 1], n = i % 5;
            1 === n ? e[0].push(a) : 2 === n ? e[1].push(a) : 3 === n ? e[2].push(a) : 4 === n ? e[3].push(a) : e[4].push(a);
        }
    }
    showBetStatePanel() {
        this.initPanel();
        let t = FruitSlotGameManager.shared()._result, e = [[], [], [], [], []];
        this.formatData(t, e);
        for (let t = 0; t < this.panelTab.length; t++) {
            if (ToolUtils.isObjValid(this.panelTab[t])) {
                for (let i = 0; i < e.length; i++) {
                    let a = instantiate(this.imgGood);
                    a.active = true;
                    a.getChildByName("ico").active = true;
                    a.getChildByName("anim").active = false;
                    a.getChildByName("ico").getComponent(Sprite).spriteFrame = this.fruitImgs[e[t][i] - 1];
                    let n = 79 + 163 * i;
                    a.setPosition(v3(88, n));
                    this.panelTab[t].addChild(a);
                }
            }
        }
    }
    startRollingAni(t) {
        this.initPanel();
        this.remove_action_clone();
        let e = [[], [], [], [], []], i = FruitSlotGameManager.shared()._result;
        this.formatData(i, e);
        let a = 0;
        e.forEach(((t, e) => {
            FruitSlotGameManager.shared()._jackpot_type > 0 && FruitSlotGameManager.shared()._near_win_cols.forEach(((t, i) => {
                e == t && (a += 1);
            }));
            this.good_num = 3 * e + 40 + 40 * a;
            for (let e = 0; e < this.good_num; e++) {
                let e = ToolUtils.getRandomInt(1, 11);
                2 == FruitSlotGameManager.shared()._game_state_type && (e = ToolUtils.getRandomInt(1, 12));
                t.push(e);
            }
        }));
        this.formatData(t, e);
        this._gameData.nearWinNum = 0;
        for (let i = 0; i < this.panelTab.length; i++) {
            this.createAni(i, this.panelTab[i], e[i], t);
        }
    }
    createAni(t, e, i, a) {
        this.panelItem = [];
        for (let t = 0; t < i.length; t++) {
            let a = instantiate(this.imgGood);
            a.active = true;
            a.getChildByName("ico").getComponent(Sprite).spriteFrame = this.fruitImgs[i[t] - 1];
            let n = 79 + 163 * t;
            a.setPosition(v3(88, n));
            e.addChild(a);
        }
        let n = 490 + 163 * (i.length - 3);
        e.getComponent(UITransform).content = size(190, n);
        FruitSlotGameManager.shared()._jackpot_type > 0 && FruitSlotGameManager.shared()._near_win_cols.forEach(((e, i) => {
            t == e && (this._gameData.nearWinNum = this._gameData.nearWinNum + 1);
        }));
        this.shake_time = 0.2;
        this.ani_time = 1.6;
        0 == FruitSlotGameManager.shared()._isfast ? (this.shake_time = 0.2, this.ani_time = 1.6, this.ani_time = this.ani_time + 0.2 * (t + 1) + 2.5 * this._gameData.nearWinNum) : (this.shake_time = 0.18, this.ani_time = 0.8, this.ani_time = this.ani_time + 0.18 * (t + 1) + 1.5 * this._gameData.nearWinNum);
        let s = tween(e).delay(0 * (t - 1)), o = tween(e).by(this.shake_time, { position: v3(0, this.shake_dis) }), l = tween(e).by(this.ani_time, { position: v3(0, -(n - 490 + 2 * this.shake_dis)) }), p = tween(e).call((() => {
            SoundManager.shared().playFx("gundongtingxia");
        })), _ = tween(e).by(this.shake_time, { position: v3(0, this.shake_dis) }), g = tween(this.action_layout).call((() => {
            4 == t ? (TweenTool.delayAct(this.node, (() => {
                2 == FruitSlotGameManager.shared()._winshow_anim || 3 == FruitSlotGameManager.shared()._winshow_anim || 4 == FruitSlotGameManager.shared()._winshow_anim ? PushCenter.shared().pushEvent("slot_good_ani_finish", 1) : 1 == FruitSlotGameManager.shared()._winshow_anim ? PushCenter.shared().pushEvent("slot_good_ani_finish", 4) : (PushCenter.shared().pushEvent("slot_good_ani_finish", 0), PushCenter.shared().pushEvent(PushEvent.Update_FlopGame, 0));
            }), 0, true), this.showEndAnimPanel(a, t, true), TweenTool.stopNodeAction(this.musicNode)) : this.showEndAnimPanel(a, t);
        }));
        if (tween(e).sequence(s, o, l, p, _, g).start(), 0 == t) {
            let t = tween(this.musicNode).delay(0.1), e = tween(this.musicNode).call((() => {
                SoundManager.shared().playFx("jinbigundong");
            }));
            tween(this.musicNode).sequence(t, e).repeatForever().start();
        }
    }
    stop_music_jingbiguandong() {
        TweenTool.stopNodeAction(this.musicNode);
    }
    showEndAnimPanel(t, e, i) {
        TweenTool.stopNodeAction(this.panelTab[e]);
        this.panelTab[e].removeAllChildren();
        this.panelTab[e].getComponent(UITransform).contentSize = size(180, 470);
        let a = v3(0, 0);
        this.panelTab[e].getPosition(a);
        this.panelTab[e].setPosition(v3(a.x, 0));
        let n = t, o = [[], [], [], [], []];
        this.formatData(n, o);
        o[e].forEach(((t, i) => {
            let a = instantiate(this.imgGood);
            a.active = true;
            a.getChildByName("ico").getComponent(Sprite).spriteFrame = this.fruitImgs[t - 1];
            let n = 79 + 163 * i;
            a.setPosition(v3(88, n));
            this.panelTab[e].addChild(a);
            let o = 5 * i + e;
            0 == i ? o = 10 + e : 2 == i && (o = 0 + e);
            this.panelItem[o] = a;
            this.panelItem[o].fruitType = t;
            TweenTool.delayAct(this.action_layout, (() => {
                if ((10 == t || 11 == t || 12 == t) && ToolUtils.isObjValid(a)) {
                    let i = a.getChildByName("anim").getComponent(sp.Skeleton);
                    this.skeletonData[t - 1] && (i.clearTracks(), i.setToSetupPose(), i.skeletonData = this.skeletonData[t - 1], a.getChildByName("anim").active = true, 2 == this.anim_names[t - 1].length ? i.setAnimation(0, this.anim_names[t - 1][1], false) : i.setAnimation(0, this.anim_names[t - 1][0], false));
                    e < 4 && (a.getChildByName("ico").active = false);
                    TweenTool.delayAct(i, (() => {
                        a.getChildByName("ico").active = true;
                        a.getChildByName("anim").active = false;
                    }), 0.5, true);
                    SoundManager.shared().playFx("chuxianzuanshi");
                }
            }), 0, true);
        }));
        1 == i && this.play_end_anim();
    }
    play_end_anim() {
        let t = FruitSlotGameManager.shared()._win_data, e = t.length;
        1 == e ? TweenTool.delayAct(this.node, (() => {
            for (let t = 0; t < this.panelItem.length; t++) {
                ToolUtils.isObjValid(this.panelItem[t]) && (this.panelItem[t].getChildByName("ico").active = true, this.panelItem[t].getChildByName("anim").active = false, this.panelItem[t].getChildByName("link").active = false);
            }
            if (sys.isObjectValid(t[0].win_index)) {
                for (let e = 0; e < t[0].win_index.length; e++) {
                    if (t[0].win_index[e] > 0 && t[0].win_index[e] < 16 && ToolUtils.isObjValid(this.panelItem[t[0].win_index[e] - 1])) {
                        let i = this.panelItem[t[0].win_index[e] - 1], a = 1;
                        sys.isObjectValid(i.fruitType) && (a = i.fruitType);
                        let n = i.getChildByName("anim").getComponent(sp.Skeleton);
                        this.skeletonData[a - 1] && (n.clearTracks(), n.setToSetupPose(), n.skeletonData = this.skeletonData[a - 1], i.getChildByName("anim").active = true, i.getChildByName("ico").active = false, n.setAnimation(0, this.anim_names[a - 1][0], true));
                        i.getChildByName("link").active = true;
                        i.getChildByName("link").getComponent(sp.Skeleton).setAnimation(0, "glow", true);
                    }
                }
            }
        }), 0.1, true) : e > 1 && TweenTool.delayAct(this.node, (() => {
            let i = 3.3 * e, a = tween(this.action_layout).delay(i), n = tween(this.action_layout).call((() => {
                let i = 0;
                for (let a = 0; a < e; a++) {
                    TweenTool.delayAct(this.action_layout, (() => {
                        for (let t = 0; t < this.panelItem.length; t++) {
                            ToolUtils.isObjValid(this.panelItem[t]) && (this.panelItem[t].getChildByName("ico").active = true, this.panelItem[t].getChildByName("anim").active = false, this.panelItem[t].getChildByName("link").active = false);
                        }
                        if (sys.isObjectValid(t[a].win_index)) {
                            for (let e = 0; e < t[a].win_index.length; e++) {
                                if (t[a].win_index[e] > 0 && t[a].win_index[e] < 16 && ToolUtils.isObjValid(this.panelItem[t[a].win_index[e] - 1])) {
                                    let i = this.panelItem[t[a].win_index[e] - 1], n = 1;
                                    sys.isObjectValid(i.fruitType) && (n = i.fruitType);
                                    let o = i.getChildByName("anim").getComponent(sp.Skeleton);
                                    this.skeletonData[n - 1] && (o.clearTracks(), o.setToSetupPose(), o.skeletonData = this.skeletonData[n - 1], i.getChildByName("anim").active = true, i.getChildByName("ico").active = false, o.setAnimation(0, this.anim_names[n - 1][0], true));
                                    i.getChildByName("link").active = true;
                                    i.getChildByName("link").getComponent(sp.Skeleton).setAnimation(0, "glow", true);
                                }
                            }
                        }
                    }), i, true);
                    i += 3.3;
                }
            }));
            tween(this.action_layout).sequence(n, a).repeatForever().start();
        }), 0.1, true);
    }
    showNearWinAnim(t) {
        let e = 0, i = 0, a = 0, n = 0;
        0 == FruitSlotGameManager.shared()._isfast ? (n = 0.2, i = 2, a = 2.5) : (n = 0.18, i = 1.16, a = 1.5);
        t.forEach(((t, o) => {
            let l = t;
            if (ToolUtils.isObjValid(this.nearWinAnimNode[l])) {
                this.nearWinAnimNode[l].active = true;
                let t = this.nearWinAnimNode[l].getComponent(sp.Skeleton);
                t.clearTracks();
                t.setToSetupPose();
                t.setAnimation(0, "jackpot_bk", true);
                let o = tween(this.nearWinAnimNode[l]).delay(i + l * n + e * a), h = tween(this.nearWinAnimNode[l]).delay(a - 0.2), r = TweenTool.fadeInOrOut(this.nearWinAnimNode[l], 0.2, 0, 255), m = TweenTool.fadeInOrOut(this.nearWinAnimNode[l], 0.2, 255, 0), d = tween(this.nearWinAnimNode[l]).call((() => {
                    this.nearWinAnimNode[l].active = true;
                    this.nearWinAnimNode[l].getComponent(UIOpacity).opacity = 0;
                    SoundManager.shared().playFx("near_win");
                })), c = tween(this.nearWinAnimNode[l]).call((() => {
                    this.nearWinAnimNode[l].active = false;
                }));
                tween(this.nearWinAnimNode[l]).sequence(o, d, r, h, m, c).start();
                e += 1;
            }
        }));
    }
}
