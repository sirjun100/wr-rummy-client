// @ts-nocheck
// Recovered from index.js:83
import { _decorator, Component, Button, color, Label, Node, Size, Sprite, SpriteFrame, sys, UITransform, Vec3 } from "cc";
import i18nMgr from "./i18nMgr";
import Utils from "./Utils";
import User from "./User";
import PushCenter from "./PushCenter";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("CouponItem")
export class CouponItem extends Component {
    @property(Sprite)
    public seletctImg: Sprite = null;
    @property(Node)
    public couponImg: Node = null;
    @property(Sprite)
    public clubIcon: Sprite = null;
    @property([SpriteFrame])
    public clubIconFrames: SpriteFrame[] = [];
    @property([SpriteFrame])
    public coupons: SpriteFrame[] = [];
    @property(Label)
    public numLabel: Label = null;
    @property(Label)
    public danweiLabel: Label = null;
    @property(Label)
    public typeLabel: Label = null;
    @property(Label)
    public contentLabel: Label = null;
    @property(Label)
    public contentLabel2: Label = null;
    @property(Label)
    public dateLabel: Label = null;
    @property(Sprite)
    public seletctCircle: Sprite = null;
    @property([SpriteFrame])
    public circleFrames: SpriteFrame[] = [];
    public itemIndex: number = 0;
    public callback: any = null;
    public select: number = 0;
    public target_surl: string = "";
    start() {
    }
    buttonClick(e, t) {
        this.callback && this.callback(this.itemIndex);
    }
    updateUI(e, t, i, n) {
        this.callback = n;
        this.select = i;
        this.itemIndex = t;
        this.refreshSelect(i);
        let l = (e.content || "").split("|");
        if (ToolUtils.isSafeString(l[0]) && (this.contentLabel.string = ToolUtils.isSafeString(l[0])), ToolUtils.isSafeString(l[1]) && (this.contentLabel2.string = ToolUtils.isSafeString(l[1]), this.contentLabel2.node.active = true), sys.isObjectValid(e.real_ratio) ? this.numLabel.string = "" + e.real_ratio : this.numLabel.string = "" + e.ratio, this.dateLabel.string = "" + e.expire, 1 === Number(e.type) ? (this.typeLabel.string = i18nMgr.shared().getValueByKey("store.bonus").toUpperCase(), i18nMgr.shared().changeLabelFont(this.typeLabel, true)) : 2 === Number(e.type) && (this.typeLabel.string = i18nMgr.shared().getValueByKey("store.cash").toUpperCase(), i18nMgr.shared().changeLabelFont(this.typeLabel, true)), 1 == Number(e.src_type) && sys.isObjectValid(e.club)) {
            let t = User.shared().getGradeByMemberShipLevel(e.club);
            t > 0 && t <= 9 && (this.clubIcon.spriteFrame = this.clubIconFrames[t - 1], this.clubIcon.node.active = true);
        }
        let s = ToolUtils.isSafeNumber(e.color);
        if (s >= 0 && s <= 4 && (this.couponImg.getComponent(Sprite).spriteFrame = this.coupons[s]), 0 == Number(e.sta) ? (this.dateLabel.node.active = true, this.couponImg.getComponent(Button).interactable = false, this.seletctImg.node.active = false, this.seletctCircle.node.active = false) : (this.dateLabel.node.active = true, this.couponImg.getComponent(Button).interactable = true), 3 == s ? (this.numLabel.color = color(255, 255, 0, 255), this.danweiLabel.color = color(255, 255, 0, 255), this.typeLabel.color = color(255, 255, 0, 255)) : (this.numLabel.color = color(255, 255, 255, 255), this.danweiLabel.color = color(255, 255, 255, 255), this.typeLabel.color = color(255, 255, 255, 255)), ToolUtils.isSafeString(e.src_simg).length > 0) {
            this.target_surl = e.src_simg;
            Utils.shared().updateNetImage(this.couponImg, ToolUtils.isSafeString(e.src_simg), new Size(480, 120));
            let t = ToolUtils.isSafeString(e.src_color);
            t.length > 0 && (this.numLabel.color = Utils.stringToColor(t), this.danweiLabel.color = Utils.stringToColor(t), this.typeLabel.color = Utils.stringToColor(t));
        }
        this.refreshNumPosition();
    }
    refreshNumPosition() {
        this.numLabel.updateRenderData(true);
        let e = (this.numLabel.node.getComponent(UITransform).width - 49.6) / 2;
        this.numLabel.node.setPosition(new Vec3(-160 + e, 14));
        this.danweiLabel.node.setPosition(new Vec3(-163 + e, 6));
    }
    refreshSelect(e) {
        this.seletctImg.node.active = 1 === e;
        this.seletctCircle.node.active = true;
        1 === e ? (this.seletctCircle.spriteFrame = this.circleFrames[1], this.seletctCircle.color = color(255, 255, 255, 255)) : (this.seletctCircle.spriteFrame = this.circleFrames[0], this.seletctCircle.color = color(0, 0, 0, 51));
    }
    hideSeletctCircle() {
        this.seletctImg.node.active = false;
    }
    showUnselect(e) {
        let t = this.node.getChildByName("unselect");
        t && (t.active = !e);
    }
    onDestroy() {
        PushCenter.shared().removeListenersByTag(this);
    }
}
