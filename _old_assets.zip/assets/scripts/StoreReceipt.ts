// @ts-nocheck
// Recovered from index.js:609
import { _decorator, color, instantiate, Label, Layout, Node, ScrollView, size, sys, UITransform, v3, view } from "cc";
import Parent from "./Parent";
import SoundManager from "./SoundManager";
import Utils from "./Utils";
import PushCenter from "./PushCenter";
import PushEvent from "./PushEvent";
import User from "./User";
import i18nMgr from "./i18nMgr";
import HttpManager from "./HttpManager";
import TweenTool from "./TweenTool";
import { HttpRequest } from "./HttpRequestName";
import GameConfig from "./GameConfig";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("StoreReceipt")
export class StoreReceipt extends Parent {
    @property(Node)
    public rootNode: Node = null;
    @property(Node)
    public bgNode: Node = null;
    @property(ScrollView)
    public scrollView: ScrollView = null;
    @property(Node)
    public topInfoNode: Node = null;
    @property(Node)
    public publicizeNode: Node = null;
    @property(Node)
    public prizeNode: Node = null;
    @property(Node)
    public receiptsNode: Node = null;
    @property(Node)
    public resultsNode: Node = null;
    @property(Node)
    public occupyNode: Node = null;
    public _scheduleTime: any = null;
    public _isShowWin: boolean = false;
    public _countdownTime: number = 0;
    onLoad() {
        this.fitScreen();
        PushCenter.shared().addListener(PushEvent.commentDownloaderImg, (e => {
            ToolUtils.isObjValid(this.node) && Utils.shared().updateNetImage(this.publicizeNode.getChildByName("img"), User.shared().receiptData.imgUrl, size(680, 460));
        }), this);
        PushCenter.shared().addListener(GameConfig.Recharge, (e => {
            ToolUtils.isObjValid(this.node) && this.requestReceiptInfo();
        }), this);
        PushCenter.shared().addListener(PushEvent.RefreshReceipt, (e => {
            ToolUtils.isObjValid(this.node) && this.requestReceiptInfo();
        }), this);
        PushCenter.shared().addListener(GameConfig.onEnterForeground, (e => {
            ToolUtils.isObjValid(this.node) && this.requestReceiptInfo();
        }), this);
        this.dealMultipleLanguages();
    }
    dealMultipleLanguages() {
        2 == i18nMgr.shared().language && (this.prizeNode.getChildByName("collect_btn").getChildByName("wz").getComponent(Label).fontSize = 20);
    }
    onEnable() {
        this.scrollView.node.on(ScrollView.EventType.SCROLLING, this.onScrollViewScrolling, this);
    }
    onDisable() {
        this.scrollView.node.off(ScrollView.EventType.SCROLLING, this.onScrollViewScrolling, this);
    }
    onDestroy() {
        PushCenter.shared().removeListenersByTag(this);
        this.unscheduleAllCallbacks();
        this._scheduleTime && this._scheduleTime.stop();
    }
    onScrollViewScrolling(e) {
        this.bgNode.setPosition(v3(0, this.scrollView.getScrollOffset().y));
    }
    start() {
        this.scrollView.node.active = false;
        sys.isObjectValid(User.shared().receiptData) && (User.shared().receiptData.rule = null, this.refreshReceiptView());
        this.requestReceiptInfo();
    }
    requestReceiptInfo() {
        sys.isObjectValid(User.shared().receiptData) || Utils.shared().showLoading(10, true, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
        }));
        HttpManager.shared().doGetCommonRequest(null, HttpRequest.LotteryPage, ((e, t, i) => {
            if (Utils.shared().hideLoading(), 200 != i) {
                alert("The login timed out, please try again");
            }
            else {
                try {
                    let e = ToolUtils.parseJson(t);
                    0 == e.ret && (User.shared().receiptData = e.data, ToolUtils.isObjValid(this.node) && (this._isShowWin = true, this.refreshReceiptView()));
                }
                catch (e) {
                }
            }
        }));
    }
    refreshReceiptView() {
        if (sys.isObjectValid(User.shared().receiptData)) {
            this.scrollView.node.active = true;
            this.occupyNode.active = false;
            this.showReceiptWinView();
            let e = 0 == i18nMgr.shared().language ? 48 : 36;
            if (i18nMgr.shared().changeLabelFontSize(this.topInfoNode.getChildByName("title").getComponent(Label), e), sys.isObjectValid(User.shared().receiptData.soon) && 0 == User.shared().receiptData.soon) {
                if (this.publicizeNode.getChildByName("img").active = true, this.publicizeNode.getChildByName("wz").active = false, Utils.shared().updateNetImage(this.publicizeNode.getChildByName("img"), User.shared().receiptData.img, size(680, 460)), this.prizeNode.getChildByName("round").getComponent(Label).string = ToolUtils.format("#${0}", User.shared().receiptData.round), this._countdownTime = User.shared().receiptData.left, this.prizeNode.active = true, this._scheduleTime && this._scheduleTime.stop(), this.setFormatTime(this._countdownTime), this._scheduleTime = TweenTool.myschedule(this.node, 1, (() => {
                    this._countdownTime = this._countdownTime - 1;
                    this._countdownTime >= 0 ? this.setFormatTime(this._countdownTime) : (this._scheduleTime.stop(), User.shared().requestStoreList(), this.requestReceiptInfo());
                })), this.prizeNode.getChildByName("collect_btn").active = 1 == User.shared().receiptData.free, this.prizeNode.getChildByName("get_btn").active = 1 != User.shared().receiptData.free, 1 != User.shared().receiptData.free) {
                    let e = this.prizeNode.getChildByName("get_btn").getChildByName("wz").getComponent(UITransform).contentSize;
                    this.prizeNode.getChildByName("get_btn").getChildByName("line").getComponent(UITransform).setContentSize(size(e.width, 2));
                }
                this.receiptsNode.active = true;
                let e = this.receiptsNode.getChildByName("layout");
                if (Array.isArray(e.children) && e.children.length > 0 && e.removeAllChildren(), sys.isObjectValid(User.shared().receiptData.my) && User.shared().receiptData.my.length > 0) {
                    this.receiptsNode.getChildByName("layout").active = true;
                    this.receiptsNode.getChildByName("noreceipts").active = false;
                    this.receiptsNode.getChildByName("top_info").getChildByName("more_btn").active = 1 == User.shared().receiptData.more;
                    let e = this.receiptsNode.getChildByName("moban");
                    e.active = false;
                    for (let t = 0, i = User.shared().receiptData.my.length; t < i; t++) {
                        let i = User.shared().receiptData.my[t], a = instantiate(e);
                        ToolUtils.isObjValid(a) && (a.active = true, a.getChildByName("code").getComponent(Label).string = i.code, a.setPosition(v3(0, 0)), a.getChildByName("round").getComponent(Label).string = ToolUtils.format("#${0}", User.shared().receiptData.round), this.receiptsNode.getChildByName("layout").addChild(a));
                    }
                }
                else {
                    this.receiptsNode.getChildByName("noreceipts").active = true;
                    this.receiptsNode.getChildByName("layout").active = false;
                    this.receiptsNode.getChildByName("top_info").getChildByName("more_btn").active = false;
                    let e = this.receiptsNode.getChildByName("noreceipts").getChildByName("help_btn"), t = e.getChildByName("wz").getComponent(UITransform).contentSize;
                    e.getChildByName("line").getComponent(UITransform).setContentSize(size(t.width, 2));
                }
            }
            else {
                this.prizeNode.active = false;
                this.publicizeNode.getChildByName("wz").active = true;
                let e = 0 == i18nMgr.shared().language ? 76 : 64;
                i18nMgr.shared().changeLabelFontSize(this.publicizeNode.getChildByName("wz").getComponent(Label), e);
                this.publicizeNode.getChildByName("img").active = false;
                this.receiptsNode.active = false;
            }
            if (sys.isObjectValid(User.shared().receiptData.history) && User.shared().receiptData.history.length > 0) {
                this.resultsNode.active = true;
                let e = User.shared().receiptData.history[0], t = this.resultsNode.getChildByName("recently");
                t.getChildByName("date_node").getChildByName("time").getComponent(Label).string = e.time;
                t.getChildByName("date_node").getChildByName("round").getComponent(Label).string = ToolUtils.format("#${0}", e.round);
                for (let i = 1; i <= 5; i++) {
                    let a = t.getChildByName("rank" + i), o = e.rank[ToolUtils.format("${0}", i)];
                    if (sys.isObjectValid(o)) {
                        if (a.active = true, a.getChildByName("rank_node").getChildByName("reward").getComponent(Label).string = ToolUtils.format("₹${0}", o.cash), a.getChildByName("rank_node").getChildByName("win_bg").active = 1 == o.win, a.getChildByName("rank_node").getChildByName("win").active = 1 == o.win, i <= 3) {
                            a.getChildByName("name").getComponent(Label).string = ToolUtils.GetShortName2(o.name, 13, false);
                            a.getChildByName("code").getComponent(Label).string = o.code;
                            Utils.shared().updateHeadImg(a.getChildByName("head").getChildByName("img"), o.avatar, o.avatar_url, size(72, 72));
                        }
                        else {
                            let e = a.getChildByName("num_node");
                            e.removeAllChildren();
                            let t = a.getChildByName("num_moban");
                            t.active = false;
                            for (let i = 0, a = o.codes.length; i < a; i++) {
                                let a = instantiate(t);
                                a.active = true;
                                a.getChildByName("bg").active = 1 == o.codes[i].win;
                                a.getChildByName("code").getComponent(Label).string = o.codes[i].code;
                                let s = 1 == o.codes[i].win ? color(255, 254, 254) : color(102, 102, 102);
                                a.getChildByName("code").getComponent(Label).color = s;
                                e.addChild(a);
                                e.getComponent(Layout).updateLayout();
                            }
                        }
                    }
                    else {
                        a.active = false;
                    }
                }
            }
            else {
                this.resultsNode.active = false;
                this.occupyNode.active = !(sys.isObjectValid(User.shared().receiptData.soon) && 0 == User.shared().receiptData.soon);
            }
            this.scrollView.content.getComponent(Layout).updateLayout();
        }
    }
    showReceiptWinView() {
        let e = User.shared().receiptData.youWin;
        if (sys.isObjectValid(e) && e.rank && this._isShowWin) {
            this._isShowWin = false;
            let t = { list: [] };
            sys.isObjectValid(User.shared().receiptData.msg) && (t.msg = User.shared().receiptData.msg);
            for (let i = 0, a = e.reward.length; i < a; i++) {
                let a = e.reward[i], o = [];
                o.num = a.amt;
                o.type = a.type;
                o.php_data = a;
                o.name = Utils.shared().getIconNameByType(a.type, a.desc || "");
                t.list[i] = o;
            }
            Utils.shared().showRewardTips(t, null, 1, "reward_tips.okey");
        }
    }
    setFormatTime(e) {
        if (ToolUtils.isSafeNumber(e) >= 0) {
            let t = Math.floor(e / 3600).toString().padStart(2, "0"), i = Math.floor(e % 3600 / 60).toString().padStart(2, "0"), a = Math.floor(e % 60).toString().padStart(2, "0");
            ToolUtils.isObjValid(this.prizeNode) && (this.prizeNode.getChildByName("hour").getComponent(Label).string = t, this.prizeNode.getChildByName("minute").getComponent(Label).string = i, this.prizeNode.getChildByName("second").getComponent(Label).string = a);
        }
    }
    onButtonClick(e, t) {
        SoundManager.shared().playFx("click");
        "collect" == t ? HttpManager.shared().doGetCommonRequest(null, HttpRequest.LotteryReceipt, this.listenLotteryReceiptCallBack.bind(this)) : "get" == t ? PushCenter.shared().pushEvent(PushEvent.showStoreRecharge) : "help" == t ? Utils.shared().showStoreReceiptDialogView(0) : "more" == t ? Utils.shared().showStoreReceiptDialogView(2) : "history" == t && Utils.shared().showStoreReceiptDialogView(3);
    }
    listenLotteryReceiptCallBack(e, t, i) {
        if (Utils.shared().hideLoading(), 200 != i) {
            alert("The login timed out, please try again");
        }
        else {
            try {
                let e = ToolUtils.parseJson(t);
                0 == e.ret && (User.shared().soreTb.receipt = 0, ToolUtils.isObjValid(this.node) && this.requestReceiptInfo(), User.shared().showChargeReward(e.data.reward, (e => {
                    User.shared().requestStoreList();
                })));
            }
            catch (e) {
            }
        }
    }
    fitScreen() {
        ToolUtils.adaptSafeArea(this.node);
        let e = view.getVisibleSize(), t = this.bgNode.getComponent(UITransform);
        ToolUtils.getOrientation() ? t.setContentSize(e.height, 2 * e.width) : t.setContentSize(e.width, 2 * e.height);
    }
}
