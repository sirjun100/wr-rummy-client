// @ts-nocheck
// Recovered from index.js:657
import { _decorator, color, director, instantiate, Label, Node, size, SpriteAtlas, SpriteFrame, sys, UITransform, v3, Vec3, view } from "cc";
import User from "./User";
import Utils from "./Utils";
import SoundManager from "./SoundManager";
import PushCenter from "./PushCenter";
import GameConfig from "./GameConfig";
import HttpManager from "./HttpManager";
import { TLog } from "./TLog";
import { TransferPlatform } from "./TransferPlatform";
import PushEvent from "./PushEvent";
import i18nMgr from "./i18nMgr";
import BaseLayer from "./BaseLayer";
import BundleNameDefined from "./BundleNameDefined";
import { ChangeNamePrefabs } from "./ChangeNamePrefabs";
import { HttpRequest } from "./HttpRequestName";
import CommDefine from "./CommDefine";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("UserInfoPerfabs")
export class UserInfoPerfabs extends BaseLayer {
    public TAG: string = "UserInfoPerfabs";
    @property(Node)
    public head_img: Node = null;
    @property(Node)
    public club_kuang: Node = null;
    @property(Label)
    public nick_name: Label = null;
    @property(Node)
    public tel_notadd: Node = null;
    @property(Label)
    public tel: Label = null;
    @property(Node)
    public tel_verified: Node = null;
    @property(Node)
    public btn_tel: Node = null;
    @property(Node)
    public email_notadd: Node = null;
    @property(Label)
    public email: Label = null;
    @property(Node)
    public email_verified: Node = null;
    @property(Node)
    public btn_email: Node = null;
    @property([SpriteFrame])
    public clubStarFrame: SpriteFrame[] = [];
    @property([SpriteFrame])
    public btnSprites: SpriteFrame[] = [];
    @property(SpriteAtlas)
    public clubKuangAtlas: SpriteAtlas = null;
    @property(SpriteAtlas)
    public rewardPlist: SpriteAtlas = null;
    public cb: any = null;
    public close_cb: any = null;
    public _unBindType: any = -1;
    public _lastClick: number = 0;
    public _pageTypes: any[] = [];
    public _clubItems: any[] = [];
    public _superVipItems: any[] = [];
    public _hasSuperVip: boolean = false;
    public bindType: any = -1;
    onLoad() {
        PushCenter.shared().addListener(GameConfig.Update_Name, (e => {
            ToolUtils.isObjValid(this.node) && this.updateUserName();
        }), this);
        PushCenter.shared().addListener(GameConfig.MobileBlind_State, (e => {
            ToolUtils.isObjValid(this.node) && this.refreshTel_no();
        }), this);
        PushCenter.shared().addListener(GameConfig.EmailBlind_State, (e => {
            ToolUtils.isObjValid(this.node) && this.refreshEmailState();
        }), this);
        PushCenter.shared().addListener(GameConfig.Change_Head, (e => {
            if (ToolUtils.isObjValid(this.node)) {
                try {
                    this.updateUserAvatar();
                }
                catch (e) {
                }
            }
        }), this);
        PushCenter.shared().addListener(PushEvent.OTP_Verify_Succ, (e => {
            ToolUtils.isObjValid(this.node) && (0 == this.bindType ? PushCenter.shared().pushEvent(PushEvent.ShowChangeBindMobile, { nType: 1 }) : PushCenter.shared().pushEvent(PushEvent.ShowChangeBindMobile, { nType: 4 }));
        }), this);
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().removeListenersByTag(this);
        this.unscheduleAllCallbacks();
    }
    adaptScreen() {
        let e = view.getVisibleSize(), t = this.node.getChildByName("bgView"), a = this.node.getChildByName("bg"), i = t.getComponent(UITransform), n = a.getComponent(UITransform), s = this.node.getComponent(UITransform);
        if (ToolUtils.getOrientation()) {
            this.node.setRotationFromEuler(new Vec3(0, 0, 90));
            i.setContentSize(e.height, e.width);
            n.setContentSize(e.height, e.width);
            s.setContentSize(e.height, e.width);
            t.setPosition(v3(0, -sys.getSafeAreaRect().x, 0));
            ToolUtils.adaptSafeArea(t);
        }
        else {
            ToolUtils.adaptSafeArea(t);
            let e = ToolUtils.getSafeDistance();
            ToolUtils.isPadPlatform() && (e = 0);
        }
    }
    start() {
        super.start();
        this.initView();
    }
    onEnable() {
        TransferPlatform.shared().setNormalFrameRate();
    }
    onDisable() {
    }
    initView() {
        this.nick_name.string = ToolUtils.GetShortName2(User.shared().data.name, 13, false);
        this.updateUserAvatar();
        this.refreshTel_no();
        this.refreshEmailState();
    }
    refreshEmailState() {
        User.shared().data.email && "" != User.shared().data.email ? (this.email.node.active = true, this.email.string = User.shared().data.email, this.email_notadd.active = false, this.email_verified.active = true, this.btn_email.active = false) : (this.email_notadd.active = true, this.tel.node.active = false, this.email_verified.active = false, this.btn_email.getChildByName("wz").getComponent(Label).string = "Add", this.btn_email.active = true);
    }
    refreshTel_no() {
        User.shared().data.tel_no && "" !== User.shared().data.tel_no ? (this.tel.node.active = true, this.btn_tel.getChildByName("wz").getComponent(Label).string = "Change", this.tel_notadd.getComponent(Label).string = User.shared().data.tel_no, this.tel_notadd.getComponent(Label).isBold = true, this.tel_notadd.getComponent(Label).color = color(30, 30, 30, 255), this.tel_verified.active = true) : (this.tel_notadd.getComponent(Label).string = "Not added", this.tel_notadd.getComponent(Label).color = color(82, 82, 82, 255), this.btn_tel.getChildByName("wz").getComponent(Label).string = "Add", this.tel_notadd.getComponent(Label).isBold = false, this.tel_verified.active = false);
    }
    updateRewardSprite(e, t) {
        ToolUtils.isSafeString(CommDefine.rewardPistName[t]).length > 0 && Utils.shared().setImage(e, CommDefine.rewardPistName[t], this.rewardPlist);
    }
    setCloseCallBack(e = null) {
        this.close_cb = e;
    }
    onClickClose(e, t) {
        SoundManager.shared().playFx("click");
        User.shared().jumpFromHall && (PushCenter.shared().pushEvent(PushEvent.HallGet), User.shared().jumpFromHall = false);
        this.close_cb && this.close_cb();
        ToolUtils.isObjValid(this.node) && this.node.destroy();
    }
    onBtnClick(e, t) {
        if (SoundManager.shared().playFx("click"), !(sys.now() - this._lastClick < 1000)) {
            if (this._lastClick = sys.now(), "head" == t) {
                let e = director.getScene().getChildByName("Canvas");
                Utils.shared().showHallGameDisPlay({ parent_node: e });
            }
            else if ("tel" == t) {
                if (User.shared().data.tel_no && "" !== User.shared().data.tel_no) {
                    if (10 != User.shared().data.tel_no.length) {
                        return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("bind_mobile.invalid_mobile_number"), 2);
                    }
                    this.bindType;
                    User.shared().data.email && "" != User.shared().data.email && -1 != User.shared().data.email.search("@") ? PushCenter.shared().pushEvent(PushEvent.ShowChangeBindMobile, { nType: 6 }) : PushCenter.shared().pushEvent(PushEvent.ShowChangeBindMobile, { nType: 5 });
                }
                else {
                    PushCenter.shared().pushEvent(PushEvent.ShowChangeBindMobile, { nType: 0 });
                }
            }
            else if ("email" == t) {
                if (User.shared().data.email && "" != User.shared().data.email) {
                    if (-1 == User.shared().data.email.search("@")) {
                        return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("bind_mobile.invalid_email"), 2);
                    }
                    this.bindType;
                    User.shared().data.tel_no && "" !== User.shared().data.tel_no && 10 == User.shared().data.tel_no.length ? PushCenter.shared().pushEvent(PushEvent.ShowChangeBindMobile, { nType: 5 }) : PushCenter.shared().pushEvent(PushEvent.ShowChangeBindMobile, { nType: 6 });
                }
                else {
                    PushCenter.shared().pushEvent(PushEvent.ShowChangeBindMobile, { nType: 2 });
                }
            }
            this.cb && this.cb(t);
        }
    }
    showChangeName() {
        let e = TransferPlatform.shared().getIsNewKyc();
        if (1 == User.shared().can_update_nick_name) {
            try {
                ToolUtils.loadCommonPrefab(null, BundleNameDefined.bundle_hallTopUI, "prefab/change_name_node", (t => {
                    let a = director.getScene().getChildByName("Canvas"), i = a.getChildByName("ChangeNameNode");
                    if (!ToolUtils.isObjValid(i)) {
                        i = instantiate(t);
                        i.name = "ChangeNameNode";
                        i.parent = a;
                        let n = i.getComponent(ChangeNamePrefabs);
                        n.init(e, (() => {
                            ToolUtils.isObjValid(this.node) && (this.node.active = false);
                        }));
                        n.setCloseCallBack((() => {
                            ToolUtils.isObjValid(this.node) && (this.node.active = true);
                        }));
                    }
                }));
            }
            catch (e) {
                TLog.printError("Hall showChangeName err:", e);
            }
        }
        else {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("userinfo.name_change"), 2);
        }
    }
    showDisconnectSureAlert(e) {
        let t = "", a = "";
        this._unBindType = e;
        1 == e ? (t = i18nMgr.shared().getValueByKey("utlis.disconnect_sure_fb"), a = i18nMgr.shared().getValueByKey("utlis.fb_disconnect")) : 2 == e && (t = i18nMgr.shared().getValueByKey("utlis.disconnect_sure_apple"), a = i18nMgr.shared().getValueByKey("utlis.apple_disconnect"));
        let i = { bLandscape: ToolUtils.getIsNormalDirection(), bWithCancel: true, strContent: t, strTitle: a, sureKey: "utlis.confirm", cancelKey: "utlis.cancle" };
        Utils.shared().showCommonAlert(i, (t => {
            1 === t && (ToolUtils.isSafeString(User.shared().data.tel_no).length > 0 ? this.requestUnbinding(e) : TransferPlatform.shared().getIsNewKyc() ? PushCenter.shared().pushEvent(PushEvent.ShowChangeBindMobile, { lastNode: this.node, nType: 3, callback: this.onChangeBindMoblieCallBack.bind(this), bShowPushAnim: true }) : PushCenter.shared().pushEvent(PushEvent.ShowChangeBindMobile, { lastNode: this.node, nType: 3, callback: this.onChangeBindMoblieCallBack.bind(this) }));
        }));
    }
    onChangeBindMoblieCallBack(e, t, a) {
        e && this.requestUnbinding(this._unBindType, false);
    }
    requestUnbinding(e, t = true) {
        let a = "";
        1 == e ? a = "facebook" : 2 == e && (a = "apple");
        t && Utils.shared().showLoading(10, true, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3);
        }));
        HttpManager.shared().doGetCommonRequest({ src: a }, HttpRequest.Unbinding, ((e, t, i) => {
            if (Utils.shared().hideLoading(), 200 != i) {
                Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 1.5, 0, ToolUtils.getIsNormalDirection());
            }
            else {
                ToolUtils.parseJson(t);
                try {
                    let e = ToolUtils.parseJson(t);
                    if (0 == e.ret) {
                        let t = a;
                        undefined !== e.data.src && null !== e.data.src && (t = e.data.src);
                        this.showDisconnectSuccAlert(t);
                    }
                    else {
                        e.desc && e.desc.length > 0 && Utils.shared().showToast(e.desc, 2);
                    }
                }
                catch (e) {
                }
            }
        }));
    }
    showDisconnectSuccAlert(e) {
        let t = "";
        "facebook" == e ? (t = i18nMgr.shared().getValueByKey("utlis.disconnect_suc_fb"), User.shared().data.hasBlindFb = 0, TransferPlatform.shared().logoutFacebookAccount()) : "apple" == e && (t = i18nMgr.shared().getValueByKey("utlis.disconnect_suc_apple"), User.shared().data.bindIOS = 0, localStorage.removeItem(CommDefine.AppleTokenKey), TransferPlatform.shared().disconnectAppleAccount());
        ToolUtils.saveData("logintype", "-1");
        ToolUtils.getIsNormalDirection();
        i18nMgr.shared().getValueByKey("utlis.disconnect_suc");
    }
    listenChangeMobileCall(e, t, a) {
        if (0 != t.length) {
            if (200 != a) {
                alert("The login timed out, please try again");
            }
            else {
                let e = ToolUtils.parseJson(t);
                501 == e.ret ? PushCenter.shared().pushEvent(PushEvent.ShowSafetyVerify, { lastNode: this.node, jump_info: { type: PushEvent.JUMP_TO_MOBILE, exe: { lastNode: this.node, nType: 1 } } }) : 502 == e.ret ? PushCenter.shared().pushEvent(PushEvent.ShowChangeBindMobile, { lastNode: this.node, nType: 1 }) : (e.ret, e.desc && e.desc.length > 0 && Utils.shared().showToast(e.desc, 3));
            }
        }
    }
    updateUserName() {
        this.nick_name.string = ToolUtils.GetShortName2(User.shared().data.name, 13, false);
    }
    updateUserAvatar() {
        User.shared().data.avatar && User.shared().data.avatar.length > 0 && Utils.shared().updateHeadImg(this.head_img, User.shared().data.avatar, User.shared().data.avatar_url, size(190, 190));
        this.nick_name.string = ToolUtils.GetShortName2(User.shared().data.name, 13, false);
    }
    setCallback(e) {
        this.cb = e;
    }
    update_clubInfo() {
    }
}
