// @ts-nocheck
// Recovered from index.js:255
import { _decorator, Component, Asset, assetManager, Button, color, director, dynamicAtlasManager, EditBox, game, HorizontalTextAlignment, Input, Label, macro, native, Node, ProgressBar, Sprite, SpriteFrame, sys, ToggleContainer, tween, v3, Vec3, Widget } from "cc";
import AppInfo from "./AppInfo";
import PushCenter from "./PushCenter";
import { TLog } from "./TLog";
import { ToolUtils } from "./ToolUtils";
import { TransferPlatform } from "./TransferPlatform";
import TweenTool from "./TweenTool";
import Utils from "./Utils";
import i18nMgr from "./i18nMgr";
import BundleNameDefined from "./BundleNameDefined";
import CommDefine, { CommonGameType, RemoteGameList } from "./CommDefine";
import GameConfig from "./GameConfig";
import PushEvent from "./PushEvent";
import ReportConfig from "./ReportConfig";
import URLConfig from "./URLConfig";
import User from "./User";
import HttpManager from "./HttpManager";
import LabaServer from "./LabaServer";
import NetHostManager from "./NetHostManager";
import Server from "./Server";
import SoundManager from "./SoundManager";
import ClientDiagnostics from "./ClientDiagnostics";
const { ccclass, property } = _decorator;
(macro.CLEANUP_IMAGE_CACHE = true);
(dynamicAtlasManager.enabled = false);
@ccclass("LoginScene")
export class LoginScene extends Component {
    @property(Node)
    public logo: Node = null;
    @property(Node)
    public smalllogo: Node = null;
    @property(Node)
    public ringNode: Node = null;
    @property(Node)
    public robotNode: Node = null;
    @property(Node)
    public logo_title: Node = null;
    @property(Node)
    public logo_title_tip: Node = null;
    @property(Node)
    public login_node: Node = null;
    @property(Node)
    public bottom_node: Node = null;
    @property(Node)
    public mobile_node: Node = null;
    @property(Node)
    public otp_node: Node = null;
    @property(Node)
    public flag_node: Node = null;
    @property(Node)
    public cer_node: Node = null;
    @property(EditBox)
    public phoneField: EditBox = null;
    @property(Node)
    public getPhoneNumBtn: Node = null;
    @property(EditBox)
    public otpField: EditBox = null;
    @property([Label])
    public otp_Label: Label[] = [];
    @property([SpriteFrame])
    public flagImgs: SpriteFrame[] = [];
    @property([SpriteFrame])
    public logoImgs: SpriteFrame[] = [];
    @property([SpriteFrame])
    public smallLogoImgs: SpriteFrame[] = [];
    @property([SpriteFrame])
    public titleImgs: SpriteFrame[] = [];
    @property([SpriteFrame])
    public ringImgs: SpriteFrame[] = [];
    @property([SpriteFrame])
    public robotImgs: SpriteFrame[] = [];
    @property([SpriteFrame])
    public cerImgs: SpriteFrame[] = [];
    @property(Button)
    public guestLoginBtn: Button = null;
    @property(Label)
    public text_version: Label = null;
    @property(Node)
    public del_btn: Node = null;
    @property(Asset)
    public manifestUrl: Asset = null;
    @property(Node)
    public updateUI: Node = null;
    @property(ProgressBar)
    public byteProgress: ProgressBar = null;
    @property(Node)
    public curFbButton: Node = null;
    @property(EditBox)
    public gaid_Edit: EditBox = null;
    @property(EditBox)
    public channel_Edit: EditBox = null;
    @property(Button)
    public maskBtn: Button = null;
    @property(Node)
    public loading: Node = null;
    @property(Node)
    public orImgNode: Node = null;
    @property(Node)
    public service_btn: Node = null;
    @property(Node)
    public kefu_btn: Node = null;
    @property(Node)
    public policy_btn: Node = null;
    @property(Node)
    public responsibly_btn: Node = null;
    public focusCurOtpEdit: number = 0;
    public _updating: boolean = false;
    public _canRetry: boolean = false;
    public show: boolean = false;
    public _assetsManager: any = null;
    public updateUrl: string = "";
    public bDealUpdate: boolean = false;
    public serverVer: string = "";
    public appsflyer_guid: string = "";
    public POS_LOGIN_OFFSET: number = 100;
    public POS_LOGIN_LOGO: Vec3 = new Vec3(0, 132.36, 0);
    public bounsTabView: any = null;
    public bounstData: any[] = [];
    public _canAutoLogin: boolean = true;
    public getOtpCount: number = 1;
    public bindEmailNo: string = "";
    public curOtpLoginType: number = 0;
    public _otpAutoSubmitted: boolean = false;
    public phoneNumber: string = "";
    public _autoLogin: boolean = false;
    public _tag: string = "LoginScene";
    public getCount: number = 0;
    public installAction: any = null;
    public hasLoginScucess: boolean = false;
    public hostAction: any = null;
    public downLoadAction: any = null;
    public updateLoadingAction: any = null;
    public loadingAction: any = null;
    public loadingDelayAction: any = null;
    public hotupdateDelay: any = null;
    public loginDelay: any = null;
    public nReqUpdateTimes: number = 0;
    public nReqHostTimes: number = 0;
    public tmpAddressArr: any[] = [];
    public nCheckAddressIdx: number = 0;
    public m_nReq: number = 1;
    public m_bFadeAnimEnd: boolean = false;
    public _hasPlayAnim: boolean = false;
    public _fadeAnimEnd: boolean = false;
    public _fadeAnimTime: number = 0.5;
    public _bgShowTime: number = 0.33;
    public _hasdownLoadhalf: boolean = false;
    public _nRestart: any = -1;
    public curGoogleButton: any = null;
    public time_node: any = null;
    public certification_node: any = null;
    public _show_applebtn: boolean = false;
    public _show_googlebtn: boolean = false;
    public _lastLoadStep: any = -1;
    public _curLoadStep: number = 0;
    public _curProgress: number = 0;
    public _tmpProgress: number = 0;
    public _bProgressRun: boolean = false;
    public _bDealApkType: boolean = false;
    public _bLoadTipRand: boolean = false;
    public _bPopLocation: boolean = false;
    public _nLoadTipcd: number = 0;
    public _loadStep: any = undefined;
    public _loadBg: any = null;
    public _loginBg: any = null;
    public _nAutoLoginCount: number = 0;
    public _nMaxTime: number = 3;
    public _savePhoneNo: string = "";
    public _savePwdNo: string = "";
    public _googleName: string = "";
    public _googleAvatar: string = "";
    public _googleEmail: string = "";
    public _googlePhone: string = "";
    public otpPhoneNo: string = "";
    public chip_617_login: boolean = false;
    onEnable() {
        ToolUtils.isObjValid(this.node) && this.node.on(Input.EventType.TOUCH_START, this.onTouchStart, this);
    }
    onDisable() {
        ToolUtils.isObjValid(this.node) && this.node.off(Input.EventType.TOUCH_START, this.onTouchStart, this);
    }
    refreshTheme() {
        this.logo_title.getComponent(Sprite).spriteFrame = this.titleImgs[GameConfig.GAME_APP_THEME];
        this.logo.getComponent(Sprite).spriteFrame = this.logoImgs[GameConfig.GAME_APP_THEME];
        this.flag_node.getComponent(Sprite).spriteFrame = this.flagImgs[GameConfig.GAME_APP_THEME];
        this.smalllogo.getComponent(Sprite).spriteFrame = this.smallLogoImgs[GameConfig.GAME_APP_THEME];
        this.ringNode.getComponent(Sprite).spriteFrame = this.ringImgs[GameConfig.GAME_APP_THEME];
        this.robotNode.getComponent(Sprite).spriteFrame = this.robotImgs[GameConfig.GAME_APP_THEME];
        this.cer_node.getComponent(Sprite).spriteFrame = this.cerImgs[GameConfig.GAME_APP_THEME];
        1 == GameConfig.GAME_HALL_THEME ? BundleNameDefined.hall_scene = "lobby2" : BundleNameDefined.hall_scene = "lobby";
        0 == GameConfig.GAME_APP_THEME ? this.kefu_btn.setPosition(v3(318.56, -44.406)) : this.kefu_btn.setPosition(v3(318.56, -109.406));
    }
    initChipsLoading() {
        if (!User.shared().bBackToLogin) {
            if (-1 != GameConfig.CHIPS_CHANNELS.indexOf(GameConfig.CHANNEL_ID)) {
                GameConfig.CHIPS_MODLE = 1;
                let e = sys.localStorage.getItem("LastChipsModel");
                null != e && (ToolUtils.LAST_CHIPS_MODLE = 1 == Number(e) ? 1 : 0);
                this.logo_title.getComponent(Sprite).spriteFrame = this.titleImgs[3];
                this.flag_node.getComponent(Sprite).spriteFrame = this.flagImgs[3];
                this._nMaxTime = 10;
            }
            else {
                GameConfig.CHIPS_MODLE = 0;
            }
        }
    }
    fitChipMode() {
        1 != GameConfig.CHIPS_MODLE && -1 != GameConfig.CHIPS_CHANNELS.indexOf(GameConfig.CHANNEL_ID) && (this.logo_title.getComponent(Sprite).spriteFrame = this.titleImgs[GameConfig.GAME_APP_THEME], this.logo.getComponent(Sprite).spriteFrame = this.logoImgs[GameConfig.GAME_APP_THEME], this.flag_node.getComponent(Sprite).spriteFrame = this.flagImgs[GameConfig.GAME_APP_THEME], this.smalllogo.getComponent(Sprite).spriteFrame = this.smallLogoImgs[GameConfig.GAME_APP_THEME]);
    }
    onLoad() {
        ClientDiagnostics.start();
        ToolUtils.report_time_param = {};
        ToolUtils.report_time_param.loginOnLoad = sys.now();
        AppInfo.shared().initIsProductVer();
        AppInfo.shared().initLobbyThemeType();
        AppInfo.shared().setAutoAdapt();
        AppInfo.shared().getChannelId();
        this.refreshTheme();
        this.initChipsLoading();
        try {
            if (this._bDealApkType = false, this._bProgressRun = false, this._bLoadTipRand = false, this._curLoadStep = 0, this._curProgress = CommDefine.LoadToLoginStep[this._curLoadStep].start, this.time_node = new Node, this.node.addChild(this.time_node), "-1" == User.shared().loginType && (AppInfo.shared().logoutGoogleAccount(), AppInfo.shared().logoutFacebookAccount(), localStorage.removeItem(CommDefine.AppleTokenKey)), AppInfo.shared().hasLaunchScript(), AppInfo.shared().setFirebaseUserId(AppInfo.shared().getGaid()), AppInfo.shared().logEvent_firebase(ReportConfig.login_evt.load_update_page), this.m_nReq = 1, this.node.getChildByName("mask") && (this._loadBg = this.node.getChildByName("mask")), this.node.getChildByName("bg") && (this._loginBg = this.node.getChildByName("bg")), sys.isNative) {
                native.fileUtils.getSearchPaths();
                const t = native.fileUtils.getWritablePath() + "HotUpdateSearchPaths/", i = native.fileUtils.getWritablePath() + CommDefine.UpdateRenamePath;
                let s = sys.localStorage.getItem("currentVersion");
                if (null === s) {
                    ToolUtils.saveData("currentVersion", AppInfo.shared().getAppVersionCode());
                }
                else {
                    let e = parseFloat(s);
                    if (e && e < parseFloat(AppInfo.shared().getAppVersionCode())) {
                        return this._nRestart = 0, ToolUtils.saveData("currentVersion", AppInfo.shared().getAppVersionCode()), ToolUtils.saveData("resourceDownloaded", "no"), native.fileUtils.purgeCachedEntries(), native.fileUtils.removeDirectory(t), native.fileUtils.removeDirectory(i), dynamicAtlasManager.reset(), void setTimeout((() => {
                            AppInfo.shared().logEvent_firebase(ReportConfig.login_evt.game_restart);
                            game.restart();
                        }), game.frameTime / 1000 * 2);
                    }
                }
                if (User.shared().isFirstOpenApp && native.fileUtils.isDirectoryExist(i)) {
                    this._nRestart = 1;
                    native.fileUtils.purgeCachedEntries();
                    let s = 500;
                    if (native.fileUtils.isDirectoryExist(t)) {
                        let e = Utils.shared().mergeDirectories(i, t);
                        TweenTool.delayAct(this.node, (() => {
                            this.login_node.active || this.showLoading(0, null, 0.5);
                        }), this._fadeAnimTime, true);
                        s = 3500;
                        sys.isObjectValid(e) && (e >= 50 && e < 100 ? s = 4500 : e >= 100 ? s = 5500 : e >= 300 && (s = 6500));
                    }
                    else {
                        sys.os !== sys.OS.IOS && sys.os !== sys.OS.OSX || (s = 1500);
                        Utils.shared().renameDirectory(native.fileUtils.getWritablePath(), CommDefine.UpdateRenamePath, "HotUpdateSearchPaths/");
                    }
                    var e = native.fileUtils.getSearchPaths();
                    return -1 == e.indexOf(t) && e.unshift(t), ToolUtils.saveData("HotUpdateSearchPaths", ToolUtils.toJsonString(e)), native.fileUtils.setSearchPaths(e), 1 === GameConfig.WITH_REMOTE_RES && ToolUtils.saveData("resourceDownloaded", "yes"), void setTimeout((() => {
                        dynamicAtlasManager.reset();
                        assetManager.cacheManager.clearCache();
                        for (let e = 0, t = 0; e < RemoteGameList.length; e++) {
                            t = RemoteGameList[e];
                            sys.localStorage.setItem("subGameVer" + t, "");
                        }
                        native.fileUtils.removeDirectory(i);
                        AppInfo.shared().logEvent_firebase(ReportConfig.login_evt.game_restart);
                        game.restart();
                    }), s);
                }
            }
            let t = sys.localStorage.getItem("is_report");
            null != t && (Number.isNaN(Number(t)) ? ToolUtils.saveData("is_report", "" + GameConfig.USR_REPORT_SWITCH) : GameConfig.USR_REPORT_SWITCH = Number(t));
            1 === User.shared().temp_pingbi.register && ToolUtils.saveData("type", "2");
            AppInfo.shared().setInstallLink();
            Utils.shared().checkScreenPortrait();
            Utils.shared().removeNetImageDirectory();
            i18nMgr.shared().initLanguage();
            ToolUtils.setGlobalNode();
        }
        catch (e) {
            TLog.printError("------- login scene onload err", e);
        }
    }
    start() {
        ToolUtils.report_time_param.loginStart = sys.now();
        window.InSwitchScene = false;
        window.IsBackToHallLoad = false;
        sys.isNative && assetManager.cacheManager.removeCache(BundleNameDefined.Bundle_Yes11);
        try {
            if (this._nRestart >= 0) {
                return void (1 == this._nRestart && (1 === GameConfig.WITH_REMOTE_RES && ToolUtils.saveData("resourceDownloaded", "yes"), this.fitScreen(), this.showLoginNode(false)));
            }
            this.init();
            LabaServer.shared().reset();
            Server.shared().reset();
        }
        catch (e) {
            TLog.printError("------- login scene start err1:", e);
        }
        if (HttpManager.shared().setUidAndKey(0, "0"), User.shared().data.location_status = 0, User.shared().data.chip_location_status = 0, ToolUtils.hasGetLocation = false, ToolUtils.latitude = "", ToolUtils.longitude = "", User.shared().s_whatsapp = 0, this._updating = false, User.shared().bBackToLogin) {
            this._hasPlayAnim = true;
            this._loadStep = CommDefine.LoadToLoginStep;
            let e = sys.localStorage.getItem("logintype");
            sys.isObjectValid(e) && "" !== e && "-1" !== e && (this._loadStep = CommDefine.LoadToHallStep);
            this.updateUI.active = false;
            this.startLogin();
            this.showLoginButtons();
            this.showLoginNode(true);
            sys.os !== sys.OS.IOS && sys.os !== sys.OS.OSX && Utils.shared().releaseGameBundleAssets();
        }
        else {
            this._loginBg.active = false;
            let e = sys.localStorage.getItem("HotUpdateRestart");
            if (null != e && "1" === e) {
                ToolUtils.saveData("HotUpdateRestart", "0");
                1 === GameConfig.WITH_REMOTE_RES && ToolUtils.saveData("resourceDownloaded", "yes");
                let e = sys.localStorage.getItem("lastLoadStep");
                sys.isObjectValid(e) && e.length > 0 && (this._lastLoadStep = Number(e), ToolUtils.saveData("lastLoadStep", ""));
                this.showLoginNode(false);
                this.m_bFadeAnimEnd = true;
                this.hideLoading();
                this.startUpdate();
            }
            else {
                this.m_bFadeAnimEnd = false;
                this._fadeAnimEnd = false;
                this.showLoginNode(false);
                this.startUpdate();
            }
        }
        User.shared().bBackToLogin = false;
        User.shared().fromGame = 0;
        try {
            this.init2();
        }
        catch (e) {
            TLog.printError("------- login scene start err2:", e);
        }
        AppInfo.shared().checkGoogleId();
    }
    init() {
        User.shared().nAutoLoginType = -1;
        ToolUtils.switchSceneTye = -1;
        User.shared().data.uid = 0;
        User.shared().cleanTmpData();
        User.shared().reSetHallBundleLoadState();
        User.shared().isFirstOpenApp && HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Login, event: ReportConfig.login_evt.openApp });
        User.shared().isFirstOpenApp = false;
        this._nAutoLoginCount = 0;
        let e = localStorage.getItem("reportData");
        if (null != e && "" != e && ToolUtils.saveData("reportData", ""), this.fitScreen(), 1 == GameConfig.SERVER_SELECT_SWITCH) {
            let e = sys.localStorage.getItem("serverSelectServerType"), t = sys.localStorage.getItem("serverSelectServerDebug");
            null != e && "" != e && (GameConfig.server_type = Number(e));
            null != t && "" != t && (GameConfig.SERVER_DEBUG = Number(t));
        }
        TweenTool.commonSchedule(this.time_node, 1, this.scheduleCallBack.bind(this));
    }
    fitScreen() {
    }
    scheduleCallBack() {
        this._bLoadTipRand && (this._nLoadTipcd += 1, this._nLoadTipcd >= 3 && (this._nLoadTipcd = 0, this.updateLoadTipLabel()));
        this._bProgressRun && this.updateProgressByStep();
        this.refreshCode();
    }
    init2() {
        ToolUtils.has_offline && this.scheduleOnce((() => {
            ToolUtils.has_offline = false;
            Utils.shared().showCommomDialog(ToolUtils.offlineMsg, "", (e => {
            }), false, ToolUtils.getIsNormalDirection(), "", null, true);
        }));
        null == sys.localStorage.getItem("type") || sys.localStorage.getItem("type");
        null == sys.localStorage.getItem("save_phoneno") ? this.mobile_node.getChildByName("phone_text").getComponent(EditBox).string = "" : this.mobile_node.getChildByName("phone_text").getComponent(EditBox).string = sys.localStorage.getItem("save_phoneno");
        this.phoneField.string = null == sys.localStorage.getItem("code_phoneno") ? "" : sys.localStorage.getItem("code_phoneno");
        this.del_btn.active = this.phoneField.string.length > 0;
        ToolUtils.saveData(CommDefine.Has18Year, "1");
        let e = sys.localStorage.getItem("display_styles");
        User.shared().styles = !e || null == e || ToolUtils.parseJson(e).length < 3 ? [1, 1, 3] : ToolUtils.parseJson(e);
        this.mobile_node.active = true;
        ToolUtils.isObjValid(this.getPhoneNumBtn) && (this.getPhoneNumBtn.active = 0 == this.phoneField.string.length);
        this.otp_node.active = false;
        this.showLoginButtons();
        let t = sys.localStorage.getItem("Datastar"), i = ToolUtils.parseJson(t);
        if (this.bounstData = i, this.getInstallInfo(), this.refreshWallet(), Utils.shared().loadSoundManager(), 1 === GameConfig.SERVER_DEBUG && 1 == GameConfig.HTTP_MSG_DEBUG && ("MOBILE_BROWSER" == sys.platform || "DESKTOP_BROWSER" == sys.platform)) {
            try {
                let e = new Node, t = e.addComponent(Label);
                t.string = "Build Time: " + GameConfig.BUILD_TIME;
                t.horizontalAlign = HorizontalTextAlignment.LEFT;
                t.color = color(255, 255, 255, 255);
                e.setPosition(new Vec3(0, 400));
                e.parent = this.login_node;
            }
            catch (e) {
                TLog.printError("---- create build time text err:", e);
            }
        }
        if (PushCenter.shared().addListener(PushEvent.Update_GuestLogin, (e => {
            sys.isObjectValid(this.guestLoginBtn) && (this.guestLoginBtn.node.active = 1 == ToolUtils.showGuest, this.orImgNode.active = 1 == ToolUtils.showGuest || 0 == User.shared().temp_pingbi.fblogin);
        }), this), PushCenter.shared().addListener(PushEvent.Update_FBLogin, (e => {
            sys.isObjectValid(this.curFbButton) && this.showLoginButtons();
        }), this), PushCenter.shared().addListener(GameConfig.BackKey_Clicked, (() => {
            if (User.shared().popNode && User.shared().popNode.length > 0) {
                let e = User.shared().popNode[User.shared().popNode.length - 1];
                ToolUtils.isObjValid(e) && PushCenter.shared().pushEvent(GameConfig.BackKey_Event, { nodeName: e.name });
            }
            else {
                Utils.shared().showCommomDialog(i18nMgr.shared().getValueByKey("utlis.leave_game"), i18nMgr.shared().getValueByKey("utlis.notice"), (e => {
                    1 == e && TransferPlatform.shared().exitApp();
                }), true, ToolUtils.getIsNormalDirection(), i18nMgr.shared().getValueByKey("email.yse"), i18nMgr.shared().getValueByKey("email.no"), false);
            }
        }), this), PushCenter.shared().addListener(PushEvent.NativeFacebookLogin, (e => {
            this.doFaceBookLogic(e);
        }), this), PushCenter.shared().addListener(PushEvent.NativeAppleLogin, (e => {
            this.doAppleLogic(e);
        }), this), PushCenter.shared().addListener(GameConfig.onEnterBackground, (e => {
            HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Login, event: ReportConfig.hall_evt.enterBackGround });
        }), this), PushCenter.shared().addListener(PushEvent.UpdateDownApkProgress, (e => {
            this.updateProgressByDownLoad(e);
        }), this), PushCenter.shared().addListener(PushEvent.Low_Memory_Notice, (e => {
            ToolUtils.isObjValid(this.node) && sys.os !== sys.OS.IOS && sys.os !== sys.OS.OSX && (Utils.shared().releaseHallBundleAssets(), Utils.shared().releaseGameBundleAssets());
        }), this), PushCenter.shared().addListener(PushEvent.receivedCode, (e => {
            ToolUtils.isObjValid(this.node) && (this.otpField.string = e, this.otpField.blur(), this.clickCallback(null, "mobileLogin"));
        }), this), PushCenter.shared().addListener(PushEvent.getPhoneNumber, (e => {
            if (ToolUtils.isObjValid(this.node)) {
                let t = ToolUtils.getPureNumberString(e);
                t && t.length > 10 && (t = t.slice(-10));
                this.phoneField.string = t;
                this.del_btn.active = true;
            }
        }), this), 1 === GameConfig.SERVER_DEBUG && 1 == GameConfig.HTTP_MSG_DEBUG && sys.isNative) {
            try {
                let e = Number(AppInfo.shared().getDeviceLevel()), t = "高端机";
                0 == e ? t = "低端机" : 1 == e && (t = "中端机");
                let i = new Node, s = i.addComponent(Label);
                s.string = t;
                s.horizontalAlign = HorizontalTextAlignment.CENTER;
                s.fontSize = 30;
                s.color = color(255, 255, 255, 255);
                i.setPosition(new Vec3(0, 400));
                i.parent = this.login_node;
            }
            catch (e) {
                TLog.printError("---- create device level text err:", e);
            }
        }
        if (User.shared().hasPreload || (AppInfo.shared().getDeviceLevel() > 0 ? Utils.shared().preLoadBundleAsset() : Utils.shared().preLoadBundleAsset(true)), 1 == GameConfig.HTTP_MSG_DEBUG && ("MOBILE_BROWSER" == sys.platform || "DESKTOP_BROWSER" == sys.platform)) {
            let e = this.login_node.getChildByName("change_btn");
            ToolUtils.isObjValid(e) && (e.active = true);
        }
        1 == GameConfig.SERVER_DEBUG && "DESKTOP_BROWSER" == sys.platform && 1 == GameConfig.Development && (ToolUtils.preLoadGameBundle(BundleNameDefined.Bundle_FruitMachine, BundleNameDefined.fruitmachine_scene, false), ToolUtils.preLoadGameBundle(BundleNameDefined.Bundle_SixDice, BundleNameDefined.sixdice_scene, false), ToolUtils.preLoadGameBundle(BundleNameDefined.Bundle_GameCrash, BundleNameDefined.gamecrash_scene, false), ToolUtils.preLoadGameBundle(BundleNameDefined.Bundle_LuckyBall, BundleNameDefined.Bundle_LuckyBall, false));
        User.shared().getFirebaseJumpType(true);
    }
    getInstallInfo() {
        let e = AppInfo.shared().getAppInstallData(), t = false;
        e.hasInstall && e.channelId.length > 0 || (this.installAction = TweenTool.myschedule(this.node, 0.5, (() => {
            this.getCount = this.getCount + 1;
            AppInfo.shared().getAppInstallData().hasInstall && e.channelId.length > 0 && (t = true);
            (this.getCount >= 3 || t) && this.installAction && (TweenTool.stopAction(this.installAction), this.installAction = null);
        })));
    }
    refreshWallet() {
    }
    initCurMobanCallBack(e, t) {
        e.active = true;
        e.getChildByName("txt_gold_type").getComponent(Label).string = t;
        e.getComponent(Button).clickEvents[0].customEventData = t;
        e.getChildByName("delete_btn").getComponent(Button).clickEvents[0].customEventData = t;
    }
    scrollRefreshCallBack() {
    }
    showGaidEditboxForTest() {
        if ("MOBILE_BROWSER" == sys.platform || "DESKTOP_BROWSER" == sys.platform) {
            let e = this.login_node.getChildByName("gaid_input_bg");
            if (ToolUtils.isObjValid(e)) {
                e.active = true;
                let t = sys.localStorage.getItem("gaid");
                ToolUtils.isSafeString(t).length > 0 ? this.gaid_Edit.string = ToolUtils.isSafeString(t) : this.gaid_Edit.string = "" + sys.now();
            }
        }
        if ("MOBILE_BROWSER" == sys.platform || "DESKTOP_BROWSER" == sys.platform) {
            let e = this.login_node.getChildByName("channel_input_bg");
            e && (e.active = true, this.channel_Edit.string = "" + GameConfig.CHANNEL_ID);
            let t = this.login_node.getChildByName("theme_select_bg");
            t && (t.active = true, 0 == GameConfig.GAME_APP_THEME ? t.getChildByName("ToggleGroup").getComponent(ToggleContainer).toggleItems[0].isChecked = true : t.getChildByName("ToggleGroup").getComponent(ToggleContainer).toggleItems[1].isChecked = true);
            let i = this.login_node.getChildByName("guest_select_bg");
            i && (i.active = true, ToolUtils.showGuestLocal ? i.getChildByName("ToggleGroup").getComponent(ToggleContainer).toggleItems[1].isChecked = true : i.getChildByName("ToggleGroup").getComponent(ToggleContainer).toggleItems[0].isChecked = true);
        }
    }
    startUpdate() {
        this._loadStep = CommDefine.LoadToLoginStep;
        let e = sys.localStorage.getItem("logintype");
        if ((sys.isObjectValid(e) && "" !== e && "-1" !== e || 1 == GameConfig.CHIPS_MODLE) && (this._loadStep = CommDefine.LoadToHallStep), sys.isNative) {
            this.nReqUpdateTimes = 0;
            let e = 0;
            this.m_bFadeAnimEnd || (e = this._fadeAnimTime);
            TweenTool.delayAct(this.node, (() => {
                this.login_node.active || (this._curLoadStep = 0, this.showProgress(), this._bProgressRun = true);
            }), e, true);
            ToolUtils.report_time_param.getUpdateStart = sys.now();
            this.checkHttpAddr((() => {
                if (ToolUtils.nNetDelayTimeOut >= 3) {
                    ToolUtils.nNetDelayTimeOut = -1;
                    let e = 0;
                    this.m_bFadeAnimEnd || (e = this._fadeAnimTime);
                    TweenTool.delayAct(this.node, (() => {
                        this._bProgressRun = false;
                        this.hideLoading();
                        Utils.shared().showCommomDialog(i18nMgr.shared().getValueByKey("login.net_tip6"), "", (() => {
                            this.nReqUpdateTimes = 0;
                            this.login_node.active || (this._curLoadStep = 0, this.showProgress(), this._bProgressRun = true);
                            this.checkHttpAddr((() => {
                                this.checkUpdate();
                            }));
                        }), false, ToolUtils.getIsNormalDirection(), "RETRY", "", true);
                    }), e, true);
                }
                else {
                    this.checkUpdate();
                }
            }));
        }
        else {
            HttpManager.shared().doGetAppStartInit(((e, t, i) => {
                try {
                    let e = ToolUtils.parseJson(t);
                    sys.isObjectValid(e.data) && 0 == e.ret && (1000 * e.t3 - sys.now() > 0 ? ToolUtils.local_time_diff = Math.round(1000 * e.t3) - sys.now() : ToolUtils.local_time_diff = sys.now() - Math.round(1000 * e.t3), this.dealAppStartInfo(e.data));
                }
                catch (e) {
                    TLog.printError("-------------  doGetAppStartInit error:", e.toString());
                }
            }));
        }
    }
    checkHttpAddr(e) {
        // Test-server builds pin the compiled endpoint. A cached address from
        // a previous test environment must not silently override a new APK.
        // Production retains server-directed failover within its own environment.
        let t = 1 == GameConfig.SERVER_DEBUG ? null : sys.localStorage.getItem(URLConfig.httpHostCacheKey);
        if (ToolUtils.isSafeString(t).length > 0) {
            try {
                this.tmpAddressArr = ToolUtils.parseJson(t);
            }
            catch (e) {
                this.tmpAddressArr = [];
                TLog.printError("------- checkHttpAddr err:", e);
            }
        }
        if (!(Array.isArray(this.tmpAddressArr) && this.tmpAddressArr.length > 0) && Array.isArray(URLConfig.update_url) && URLConfig.update_url.length > 0 && (this.tmpAddressArr = URLConfig.update_url), !(Array.isArray(this.tmpAddressArr) && this.tmpAddressArr.length > 0)) {
            let t = (1 == GameConfig.SERVER_DEBUG ? "http://" : "https://") + URLConfig.orginHttp_CurHttpUrl + "/api.php";
            return HttpManager.shared().setUrl(t), void (e && e());
        }
        this.nCheckAddressIdx = 0;
        this.startCheckAddress(e);
    }
    startCheckAddress(e) {
        if (this.tmpAddressArr[this.nCheckAddressIdx]) {
            HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Login, event: ReportConfig.login_evt.getHotUpdate });
            AppInfo.shared().logEvent_firebase(ReportConfig.login_evt.getHotUpdate);
            let t = this.nCheckAddressIdx;
            HttpManager.shared().setUrl(this.tmpAddressArr[t]);
            HttpManager.shared().doGetAppStartInit(((i, s, o) => {
                if (ToolUtils.isObjValid(this.node)) {
                    if (200 !== o) {
                        if (0 == sys.getNetworkType()) {
                            let e = 0;
                            this.m_bFadeAnimEnd || (e = this._fadeAnimTime);
                            TweenTool.delayAct(this.node, (() => {
                                this.bDealUpdate || (this.hideLoading(), this._bProgressRun = false, Utils.shared().showCommomDialog(i18nMgr.shared().getValueByKey("login.net_tip6"), "", (() => {
                                    this.bDealUpdate = false;
                                    this.nReqUpdateTimes = 0;
                                    this._curLoadStep = 0;
                                    this.showProgress();
                                    this._bProgressRun = true;
                                    this.checkHttpAddr((() => {
                                        this.checkUpdate();
                                    }));
                                }), false, ToolUtils.getIsNormalDirection(), "RETRY", "", true));
                            }), e, true);
                        }
                        else {
                            this.nCheckAddressIdx = this.nCheckAddressIdx + 1;
                            this.startCheckAddress(e);
                        }
                    }
                    else {
                        HttpManager.shared().setUrl(this.tmpAddressArr[t]);
                        let i = [this.tmpAddressArr[t]];
                        for (let e = 0, s = this.tmpAddressArr.length; e < s; e++) {
                            e != t && i.push(this.tmpAddressArr[e]);
                        }
                        ToolUtils.saveData(URLConfig.httpHostCacheKey, ToolUtils.toJsonString(i));
                        try {
                            let e = ToolUtils.parseJson(s);
                            0 === e.ret && (1000 * e.t3 - sys.now() > 0 ? ToolUtils.local_time_diff = Math.round(1000 * e.t3) - sys.now() : ToolUtils.local_time_diff = sys.now() - Math.round(1000 * e.t3), this.dealAppStartInfo(e.data));
                        }
                        catch (t) {
                            e && e();
                        }
                    }
                }
            }), 8000);
        }
        else {
            HttpManager.shared().setUrl(this.tmpAddressArr[0]);
            e && e();
        }
    }
    onEditDidEnded(e, t) {
        if (e === this.gaid_Edit) {
            let e = this.gaid_Edit.string;
            ToolUtils.saveData("gaid", e);
            ToolUtils.saveData("LoginProxy_user" + AppInfo.shared().getChannelId(), "");
            ToolUtils.saveData("LoginProxy_password" + AppInfo.shared().getChannelId(), "");
        }
        else {
            e === this.channel_Edit && (7 == ToolUtils.isSafeString(this.channel_Edit.string).length ? (GameConfig.CHANNEL_ID = Number(this.channel_Edit.string), this.startUpdate()) : Utils.shared().showToast("Wrong Channel ID", 2));
        }
    }
    onDestroy() {
        this._assetsManager && this._assetsManager.setEventCallback(null);
        this.unscheduleAllCallbacks();
        this.installAction && (TweenTool.stopAction(this.installAction), this.installAction = null);
        this.downLoadAction && (TweenTool.stopAction(this.downLoadAction), this.downLoadAction = null);
        this.hostAction && (TweenTool.stopAction(this.hostAction), this.hostAction = null);
        this.updateLoadingAction && (TweenTool.stopAction(this.updateLoadingAction), this.updateLoadingAction = null);
        this.loadingAction && (TweenTool.stopAction(this.loadingAction), this.loadingAction = null);
        this.loadingDelayAction && (TweenTool.stopAction(this.loadingDelayAction), this.loadingDelayAction = null);
        this.hotupdateDelay && (TweenTool.stopAction(this.hotupdateDelay), this.hotupdateDelay = null);
        this.loginDelay && (TweenTool.stopAction(this.loginDelay), this.loginDelay = null);
        TweenTool.stopNodeAction(this.node);
        TweenTool.stopNodeAction(this.time_node);
        PushCenter.shared().removeListenersByTag(this);
    }
    checkCb(e) {
        let t = false;
        switch (e.getEventCode()) {
            case native.EventAssetsManager.ERROR_NO_LOCAL_MANIFEST:
                t = true, this.showErrTips("No local manifest file found, hot update skipped.");
                break;
            case native.EventAssetsManager.ERROR_DOWNLOAD_MANIFEST:
            case native.EventAssetsManager.ERROR_PARSE_MANIFEST:
                t = true, this.showErrTips(i18nMgr.shared().getValueByKey("login.net_tip1"));
                break;
            case native.EventAssetsManager.ALREADY_UP_TO_DATE: break;
            case native.EventAssetsManager.NEW_VERSION_FOUND:
                t = true, this._updating = false, this._curLoadStep = 2, this.showProgress(), this._bProgressRun = false, this.hotUpdate(), HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Login, event: ReportConfig.login_evt.downHotUpdate }), AppInfo.shared().logEvent_firebase(ReportConfig.login_evt.downHotUpdate);
                break;
            default: return;
        }
        t ? this.showUpdateUI() : (this.afterComplateHotUpdate(), this._assetsManager.setEventCallback(null));
        this._updating = false;
    }
    showErrTips(e) {
        Utils.shared().hideLoading();
        this.hideLoading();
        Utils.shared().hideCommomDialog();
        Utils.shared().showCommomDialog(e, "", this.retry.bind(this), false, ToolUtils.getIsNormalDirection(), "OKAY", "", true);
    }
    updateCb(e) {
        var t = false, i = false;
        switch (e.getEventCode()) {
            case native.EventAssetsManager.ERROR_NO_LOCAL_MANIFEST:
                this.showErrTips("No local manifest file found, hot update skipped."), i = true;
                break;
            case native.EventAssetsManager.UPDATE_PROGRESSION:
                let s = Math.floor(100 * e.getPercent());
                isNaN(s) || (this.updateProgressByDownLoad(e.getPercent()), 50 != s || this._hasdownLoadhalf || (this._hasdownLoadhalf = true, AppInfo.shared().logEvent_firebase(ReportConfig.login_evt.update_half))), this.updateUI.active && (Utils.shared().hideLoading(), this.downLoadAction && (TweenTool.stopAction(this.downLoadAction), this.downLoadAction = null), this.downLoadAction = TweenTool.myschedule(this.node, 20, (() => {
                    ToolUtils.nNetDelayTimeOut >= 3 && (ToolUtils.nNetDelayTimeOut = -1, this.showErrTips(i18nMgr.shared().getValueByKey("login.net_tip2")));
                })));
                break;
            case native.EventAssetsManager.ERROR_DOWNLOAD_MANIFEST:
            case native.EventAssetsManager.ERROR_PARSE_MANIFEST:
                this.showErrTips(i18nMgr.shared().getValueByKey("login.net_tip1")), AppInfo.shared().logEvent_firebase(ReportConfig.login_evt.fail_to_download_manifest), i = true;
                break;
            case native.EventAssetsManager.ALREADY_UP_TO_DATE:
                i = true;
                break;
            case native.EventAssetsManager.UPDATE_FINISHED:
                t = true, HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Login, event: ReportConfig.login_evt.updateSuc }), AppInfo.shared().logEvent_firebase(ReportConfig.login_evt.updateSuc);
                break;
            case native.EventAssetsManager.UPDATE_FAILED:
                this.showErrTips(i18nMgr.shared().getValueByKey("login.net_tip2")), this._updating = false, this._canRetry = true, HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Login, event: ReportConfig.login_evt.updateFail }), AppInfo.shared().logEvent_firebase(ReportConfig.login_evt.updateFail);
                break;
            case native.EventAssetsManager.ERROR_UPDATING:
            case native.EventAssetsManager.ERROR_DECOMPRESS:
        }
        if (i && (this._assetsManager.setEventCallback(null), this._updating = false), t) {
            this._assetsManager.setEventCallback(null);
            let e = native.fileUtils.getSearchPaths(), t = this._assetsManager.getLocalManifest().getSearchPaths();
            for (let i = 0, s = t.length; i < s; i++) {
                -1 == e.indexOf(t[i]) && e.unshift(t[i]);
            }
            ToolUtils.saveData("HotUpdateSearchPaths", ToolUtils.toJsonString(e));
            native.fileUtils.setSearchPaths(e);
            const i = native.fileUtils.getWritablePath() + "HotUpdateSearchPaths/";
            native.fileUtils.isFileExist(i + "project.manifest") && native.fileUtils.removeFile(i + "project.manifest");
            native.fileUtils.purgeCachedEntries();
            dynamicAtlasManager.reset();
            assetManager.cacheManager.clearCache();
            for (let e = 0, t = 0; e < RemoteGameList.length; e++) {
                t = RemoteGameList[e];
                sys.localStorage.setItem("subGameVer" + t, "");
            }
            ToolUtils.saveData("HotUpdateRestart", "1");
            ToolUtils.saveData("lastLoadStep", "" + this._curLoadStep);
            1 === GameConfig.WITH_REMOTE_RES && ToolUtils.saveData("resourceDownloaded", "yes");
            setTimeout((() => {
                AppInfo.shared().logEvent_firebase(ReportConfig.login_evt.game_restart);
                game.restart();
            }), 500);
        }
    }
    retry() {
        ToolUtils.nNetDelayTimeOut = -1;
        this._updating ? this._canRetry && (this._canRetry = false, this._assetsManager.downloadFailedAssets()) : this.beganHotUpdate();
    }
    checkUpdate() {
        HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Login, event: ReportConfig.login_evt.getHotUpdate });
        HttpManager.shared().doGetAppStartInit(((e, t, i) => {
            if (ToolUtils.isObjValid(this.node)) {
                if (200 !== i) {
                    if (this.nReqUpdateTimes += 1, 1 == this.nReqUpdateTimes) {
                        this.checkUpdate();
                    }
                    else if (2 == this.nReqUpdateTimes) {
                        this.checkUpdate();
                    }
                    else if (this.nReqUpdateTimes >= 3) {
                        let e = 0;
                        this.m_bFadeAnimEnd || (e = this._fadeAnimTime);
                        TweenTool.delayAct(this.node, (() => {
                            this.bDealUpdate || (Utils.shared().hideLoading(), this.hideLoading(), this._bProgressRun = false, Utils.shared().showCommomDialog(i18nMgr.shared().getValueByKey("login.net_tip6"), "", (() => {
                                this.bDealUpdate = false;
                                this.nReqUpdateTimes = 0;
                                this._curLoadStep = 1;
                                this.showProgress();
                                this._bProgressRun = true;
                                this.checkHttpAddr((() => {
                                    this.checkUpdate();
                                }));
                            }), false, ToolUtils.getIsNormalDirection(), "RETRY", "", true));
                        }), e, true);
                    }
                }
                else {
                    let e = ToolUtils.parseJson(t);
                    if (0 === e.ret) {
                        1000 * e.t3 - sys.now() > 0 ? ToolUtils.local_time_diff = Math.round(1000 * e.t3) - sys.now() : ToolUtils.local_time_diff = sys.now() - Math.round(1000 * e.t3);
                        this.dealAppStartInfo(e.data);
                    }
                    else if (this.nReqUpdateTimes += 1, 1 == this.nReqUpdateTimes) {
                        this.checkUpdate();
                    }
                    else if (2 == this.nReqUpdateTimes) {
                        this.checkUpdate();
                    }
                    else if (this.nReqUpdateTimes >= 3) {
                        let e = 0;
                        this.m_bFadeAnimEnd || (e = this._fadeAnimTime);
                        TweenTool.delayAct(this.node, (() => {
                            this.bDealUpdate || (Utils.shared().hideLoading(), this.hideLoading(), Utils.shared().showCommomDialog(i18nMgr.shared().getValueByKey("login.net_tip2"), "", (() => {
                                this.bDealUpdate = false;
                                this.nReqUpdateTimes = 0;
                                this._curLoadStep = 1;
                                this.showProgress();
                                this._bProgressRun = true;
                                this.checkHttpAddr((() => {
                                    this.checkUpdate();
                                }));
                            }), false, ToolUtils.getIsNormalDirection(), "RETRY", "", true));
                        }), e, true);
                    }
                }
            }
        }));
    }
    dealAppStartInfo(e) {
        ToolUtils.saveData("rummy_install" + TransferPlatform.shared().getChannelId(), "1");
        sys.isObjectValid(e.sw) && User.shared().dealAppStartSwitchInfo(e.sw);
        sys.isObjectValid(e.gain_host) && NetHostManager.shared().parseAppStartPacketData(e.gain_host);
        sys.isObjectValid(e.hot) && (sys.isNative ? this.dealUpdateInfo(e.hot) : (this.afterComplateHotUpdate(), null != e.hot.is_report && null != e.hot.is_report && (GameConfig.USR_REPORT_SWITCH = Number(e.hot.is_report), ToolUtils.saveData("is_report", "" + GameConfig.USR_REPORT_SWITCH))));
    }
    dealUpdateInfo(e) {
        if (this._curLoadStep = 1, this.showProgress(), this._bProgressRun = true, AppInfo.shared().logEvent_firebase(ReportConfig.login_evt.rq_update_succ), this.bDealUpdate = true, this.updateUrl = e.update_url, this.serverVer = e.serverVer, this.appsflyer_guid = e.appsflyer_guid, sys.isObjectValid(e.adjust_gid)) {
            let t = "";
            sys.isObjectValid(e.adjust_key) && (t = e.adjust_key);
            AppInfo.shared().initAdjustSDK(e.adjust_gid, t, AppInfo.shared().getGaid());
            sys.isObjectValid(e.reg_event) && (User.shared().adjust_reg_event = e.reg_event);
        }
        if (sys.os === sys.OS.ANDROID || sys.os === sys.OS.OHOS) {
            let t = Number(e.apk_type);
            if (!Number.isNaN(t) && t > 0) {
                this._bDealApkType = true;
                let i = ToolUtils.isSafeString(e.apk_title), s = ToolUtils.isSafeString(e.apk_desc), o = Number(e.apk_pass), a = ToolUtils.isSafeString(e.apk_url), n = ToolUtils.isSafeString(e.apk_h5);
                return void Utils.shared().showMiddelCommomDialog(s, i, (i => {
                    1 == i ? 1 == t ? (this._curLoadStep = 2, this.showProgress(), this._bProgressRun = false, Utils.shared().downLoadApk(a, n)) : 2 == t && (sys.openURL(n), game.end()) : 3 == i && this.doAfterApkTypeSelect(e);
                }), false, false, null, null, null, 1 == o ? 2 : 3);
            }
            this.doAfterApkTypeSelect(e);
        }
        else {
            this.doAfterApkTypeSelect(e);
        }
    }
    doAfterApkTypeSelect(e) {
        if (undefined !== e.is_check_location && (User.shared().is_check_location = ToolUtils.isSafeNumber(e.is_check_location)), undefined !== e.is_check_adult) {
            if ("" === ToolUtils.isSafeString(sys.localStorage.getItem(CommDefine.Has18Year))) {
                let t = "" + e.is_check_adult;
                ToolUtils.saveData(CommDefine.Has18Year, t);
            }
        }
        let t = e.host_url;
        if (t && t.length > 0) {
            let e = sys.localStorage.getItem(URLConfig.httpHostCacheKey);
            if (ToolUtils.isSafeString(e).length > 0) {
                try {
                    let i = ToolUtils.parseJson(e), s = [i[0]];
                    for (let e = 0, o = t.length; e < o; e++) {
                        t[e] != i[0] && s.push(t[e]);
                    }
                    ToolUtils.saveData(URLConfig.httpHostCacheKey, ToolUtils.toJsonString(s));
                    GameConfig.HTTP_MSG_DEBUG;
                }
                catch (e) {
                    TLog.printError("------- dealUpdateInfo tmpHttpUrls err:", e);
                }
            }
        }
        null != e.is_report && null != e.is_report && (GameConfig.USR_REPORT_SWITCH = Number(e.is_report), ToolUtils.saveData("is_report", "" + GameConfig.USR_REPORT_SWITCH));
        try {
            let t = GameConfig.NEW_APP_VERSION;
            this.updateUrl.length > 0 && this.serverVer.length > 0 && t && t.length > 0 && ToolUtils.versionCompareHandle(t, this.serverVer) < 0 ? 1 == Number(e.update_type) ? this.beganHotUpdate() : (this.manifestUrl.refCount < 2 && this.manifestUrl.addRef(), Utils.shared().startDownLoadHotUpdate(e, this.manifestUrl), this.afterComplateHotUpdate()) : this.afterComplateHotUpdate();
        }
        catch (e) {
        }
    }
    beganHotUpdate() {
        if (null == native || !native) {
            return void this.afterComplateHotUpdate();
        }
        if (this._updating) {
            return;
        }
        this.hotupdateDelay && TweenTool.stopAction(this.hotupdateDelay);
        sys.isObjectValid(ToolUtils._globalNode) && TweenTool.stopNodeAction(ToolUtils._globalNode);
        this.hotupdateDelay = TweenTool.delayAct(this.time_node, (() => {
            this.showErrTips(i18nMgr.shared().getValueByKey("login.net_tip1"));
        }), 30, true);
        const e = native.fileUtils.getWritablePath() + "HotUpdateSearchPaths/";
        let t = native.fileUtils.getWritablePath() + "HotUpdateSearchPaths";
        native.fileUtils.isDirectoryExist(t) || native.fileUtils.createDirectory(t);
        let i = native.fileUtils.getStringFromFile(this.manifestUrl.nativeUrl);
        if (!i) {
            return this.afterComplateHotUpdate(), void TLog.printError("-------------- can not find project.manifest");
        }
        let s = ToolUtils.parseJson(i);
        this.updateUrl && (s.packageUrl = this.updateUrl, s.remoteManifestUrl = this.updateUrl + "project.manifest", s.remoteVersionUrl = this.updateUrl + "version.manifest");
        native.fileUtils.writeStringToFile(ToolUtils.toJsonString(s), e + "project.manifest");
        let o = new native.Manifest(ToolUtils.toJsonString(s), e);
        if (this._assetsManager = new native.AssetsManager("", e, ToolUtils.versionCompareHandle), this._assetsManager.loadLocalManifest(o, e), !this._assetsManager.getLocalManifest() || !this._assetsManager.getLocalManifest().isLoaded()) {
            return void this.showErrTips("Failed to load local manifest ...");
        }
        this._assetsManager.getLocalManifest().getVersion();
        let a = this;
        if (this._assetsManager.setVerifyCallback((function (e, t) {
            t.compressed;
            t.md5;
            t.path;
            t.size;
            return a.hideLoading(), a.showUpdateUI(), true;
        })), sys.os !== sys.OS.ANDROID && sys.os !== sys.OS.OHOS || this._assetsManager.setMaxConcurrentTask(2), this._assetsManager.getState() === native.AssetsManager.State.UNINITED) {
            var n = this.manifestUrl.nativeUrl;
            this._assetsManager.loadLocalManifest(n);
        }
        if (!this._assetsManager.getLocalManifest() || !this._assetsManager.getLocalManifest().isLoaded()) {
            return this.showErrTips("Failed to load local manifest ..."), void this.afterComplateHotUpdate();
        }
        this._assetsManager.setEventCallback(this.checkCb.bind(this));
        this._assetsManager.checkUpdate();
        HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Login, event: ReportConfig.login_evt.requestPhpAssets });
        AppInfo.shared().logEvent_firebase(ReportConfig.login_evt.requestPhpAssets);
        this._updating = true;
    }
    hotUpdate() {
        try {
            if (this._assetsManager && !this._updating) {
                if (this._assetsManager.setEventCallback(this.updateCb.bind(this)), this._assetsManager.getState() === native.AssetsManager.State.UNINITED) {
                    var e = this.manifestUrl.nativeUrl;
                    this._assetsManager.loadLocalManifest(e);
                }
                this._assetsManager.update();
                this._updating = true;
            }
        }
        catch (e) {
        }
    }
    showUpdateUI() {
        this.text_version.node.active = true;
        this.text_version.string = GameConfig.NEW_APP_VERSION + "_" + GameConfig.Server_Api_Ver + "_" + GameConfig.CHANNEL_ID;
        this.login_node.active = false;
    }
    afterComplateHotUpdate() {
        Utils.shared().hideLoading();
        1 == GameConfig.CHIPS_MODLE ? ToolUtils.preLoadGameBundle(BundleNameDefined.Bundle_ludo, BundleNameDefined.ludo_scence) : this._nMaxTime = 3;
        this.startLogin();
    }
    startLogin() {
        window.InHallScene = false;
        window.InRummyScene = false;
        User.shared().code_timeout = 0;
        HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Login, event: ReportConfig.login_evt.showLogin });
        AppInfo.shared().logEvent_firebase(ReportConfig.login_evt.showLogin);
        this.showMaintainAlert();
        this.text_version.node.active = false;
        this.nReqHostTimes = 0;
        this.listenHostServerCallback(1);
        "1" == ToolUtils.isSafeString(sys.localStorage.getItem(CommDefine.FirstLogin)) && TweenTool.delayAct(this.node, (() => {
            Utils.shared().showLocationTipsAlert(0);
        }), game.frameTime / 1000, true);
    }
    showMaintainAlert() {
        User.shared().hasMaintain && (User.shared().hasMaintain = false, this._canAutoLogin = false, Utils.shared().showMiddelCommomDialog(User.shared().maintainMsg.msg, User.shared().maintainMsg.title, (e => {
            1 == e && (this._canAutoLogin = true, this.delayToAutoLogin());
        }), false, false, null, null, null, 1, User.shared().maintainMsg.sec));
    }
    refreshCode() {
        if (!(User.shared().code_timeout < 0)) {
            if (User.shared().code_timeout > 0 && (User.shared().code_timeout = User.shared().code_timeout - 1), User.shared().code_timeout >= 0) {
                let e = ToolUtils.format("(${0}s)", User.shared().code_timeout);
                this.otp_node.getChildByName("otp_tip_info").getChildByName("otp_time_info").getChildByName("time").getComponent(Label).string = e;
            }
            this.otp_node.getChildByName("otp_tip_info").getChildByName("otp_time_info").active = User.shared().code_timeout > 0;
            this.otp_node.getChildByName("otp_tip_info").getChildByName("resend_btn").active = 0 == User.shared().code_timeout;
            this.bindEmailNo.length > 0 ? this.otp_node.getChildByName("otp_tip_info").getChildByName("resend_email_btn").active = 0 == User.shared().code_timeout : this.otp_node.getChildByName("otp_tip_info").getChildByName("resend_email_btn").active = false;
        }
    }
    showLoginNode(e, t = false) {
        this.fitChipMode();
        e ? (sys.isObjectValid(this.logo_title) && (this.logo_title.active = true, this.logo_title.getComponent(Widget).top = 164.938, this.logo_title.getComponent(Widget).updateAlignment()), sys.isObjectValid(this.logo_title_tip) && (this.logo_title_tip.active = false), sys.isObjectValid(this.logo) && (this.logo.active = false), this._loginBg.active = true, this._loadBg.active = false) : (this.logo_title_tip.active = true, this.logo_title.active = true, this.logo_title.getComponent(Widget).top = 49.155, this.logo_title.getComponent(Widget).updateAlignment(), this._loginBg.active = false, this._loadBg.active = true);
        1 == GameConfig.CHIPS_MODLE ? this.logo.active = false : this.logo.active = !e;
        this.showLoginView(e);
        this.bottom_node.active = !e;
        this.updateUI.active = !e;
        e ? this.node.getChildByName("chip_loading").active = false : (this.chip_617_login && (this.logo.active = false, this.logo_title_tip.active = false, this.logo_title.active = false), this.node.getChildByName("chip_loading").active = 1 == GameConfig.CHIPS_MODLE);
    }
    showLoginView(e) {
        this.login_node.active = e;
        e && (ToolUtils.report_time_param.showLoginView = sys.now(), this.setMaskLayerShow(false), this.updateUI.active = false, this.mobile_node.active = true, this.otp_node.active = false, "-1" == User.shared().loginType || this._bPopLocation || (this._bPopLocation = true, TweenTool.delayAct(this.node, (() => {
            Utils.shared().showLocationTipsAlert(0);
        }), 0.6, true)));
    }
    listenHostServerCallback(e) {
        if (1 == e) {
            if (User.shared().doReqCommRoomList(), this.refreshProgress(4), 1 == GameConfig.CHIPS_MODLE) {
                ToolUtils.saveData("logintype", "0");
            }
            else {
                let e = sys.localStorage.getItem("logintype");
                1 == GameConfig.SERVER_SELECT_SWITCH && (e = "-1");
                sys.isObjectValid(e) && "" != e && "-1" != e || this.scheduleOnce((() => {
                    this.showLoginNode(true, true);
                }), 0.05);
            }
            this.scheduleOnce(this.delayToAutoLogin.bind(this), 0);
        }
    }
    delayToAutoLogin() {
        if (!this._canAutoLogin) {
            return;
        }
        if (this.hasLoginScucess) {
            return;
        }
        ToolUtils.report_time_param.startAutoLogin = sys.now();
        let e = sys.localStorage.getItem("logintype");
        if (1 == GameConfig.SERVER_SELECT_SWITCH) {
            e = "-1";
            let t = 0;
            this.m_bFadeAnimEnd || (t = this._fadeAnimTime);
            TweenTool.delayAct(this.node, (() => {
                this.reShowLoginUI(false);
            }), t, true);
        }
        if (sys.isObjectValid(e) && "" !== e && "-1" !== e) {
            if (this.scheduleOnce((() => {
                this.hasLoginScucess || (this.reShowLoginUI(), this.setMaskLayerShow(false));
            }), 15), "0" === e) {
                User.shared().nAutoLoginType = 0;
                this._nAutoLoginCount = 0;
                this.showLoginNode(false);
                HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Login, event: ReportConfig.login_evt.auto_guest_login });
                AppInfo.shared().logEvent_firebase(ReportConfig.login_evt.auto_guest_login);
                this.dealGuestLoginLogic();
                this.refreshProgress(4);
            }
            else if ("1" === e) {
                User.shared().nAutoLoginType = 1;
                this._nAutoLoginCount = 0;
                this.showLoginNode(false);
                HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Login, event: ReportConfig.login_evt.auto_fb_login });
                this.dealFaceBookLoginLogic();
                this.refreshProgress(4);
            }
            else if ("2" == e) {
                let t = ToolUtils.isSafeString(sys.localStorage.getItem("save_phoneno")), i = ToolUtils.isSafeString(sys.localStorage.getItem("save_pwdno"));
                t.length > 0 && i.length > 0 ? (User.shared().nAutoLoginType = 2, this._nAutoLoginCount = 0, User.shared().loginType = e, this.showLoginNode(false), this._autoLogin = true, this.loginDelay && TweenTool.stopAction(this.loginDelay), this.loginDelay = TweenTool.delayAct(this.time_node, (() => {
                    this.setMaskLayerShow(false);
                    this.hideLoading();
                }), 20, true), HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Login, event: ReportConfig.login_evt.auto_phone_login }), AppInfo.shared().logEvent_firebase(ReportConfig.login_evt.auto_phone_login), this._savePhoneNo = t, this._savePwdNo = i, this.startMoblieLogin(), this.refreshProgress(4)) : (this.reShowLoginUI(), this.setMaskLayerShow(false));
            }
            else if ("3" === e) {
                let t = ToolUtils.isSafeString(sys.localStorage.getItem("code_phoneno")), i = ToolUtils.isSafeString(sys.localStorage.getItem("code_pwdno"));
                t.length > 0 && i.length > 0 ? (User.shared().nAutoLoginType = 3, this._nAutoLoginCount = 0, this._autoLogin = true, User.shared().loginType = e, this.showLoginNode(false), this.loginDelay && TweenTool.stopAction(this.loginDelay), this.loginDelay = TweenTool.delayAct(this.time_node, (() => {
                    this.setMaskLayerShow(false);
                    this.hideLoading();
                }), 20, true), HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Login, event: ReportConfig.login_evt.auto_code_login }), AppInfo.shared().logEvent_firebase(ReportConfig.login_evt.auto_code_login), this._savePhoneNo = t, this._savePwdNo = i, this.startOtpCodeLogin(), this.refreshProgress(4)) : (this.reShowLoginUI(), this.setMaskLayerShow(false));
            }
            else {
                "7" === e ? (User.shared().nAutoLoginType = 7, this._nAutoLoginCount = 0, this.showLoginNode(false), HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Login, event: ReportConfig.login_evt.auto_google_login }), this.dealGoogleLoginLogic(), this.refreshProgress(4)) : "5" === e && (User.shared().nAutoLoginType = 5, this._nAutoLoginCount = 0, this.login_node.active = false, HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Login, event: ReportConfig.login_evt.auto_apple_login }), this.dealAppleLoginLogic(), this.refreshProgress(4));
            }
        }
        else {
            this.hideLoading();
            this.setMaskLayerShow(false);
        }
    }
    setMaskLayerShow(e) {
        this.maskBtn && (this.maskBtn.enabled = e, this.maskBtn.node.active = e);
    }
    reShowLoginUI(e = true) {
        1 != GameConfig.CHIPS_MODLE && (ToolUtils.report_time_param.reshowLogin = sys.now(), this.showLoginNode(true), e && this.hideLoading(), this.node.getChildByName("black_mask") && (this.node.getChildByName("black_mask").active = false), this.hideProgress(), this.setMaskLayerShow(false), "-1" == User.shared().loginType || this._bPopLocation || (this._bPopLocation = true, TweenTool.delayAct(this.node, (() => {
            Utils.shared().showLocationTipsAlert(0);
        }), game.frameTime / 1000, true)));
    }
    startMoblieLogin() {
        this.m_nReq += 1;
        HttpManager.shared().doPlayerLogin("", this._savePhoneNo, this._savePwdNo, 6, this.listenMobileLoginCall.bind(this), this.m_nReq);
    }
    startOtpCodeLogin() {
        this.m_nReq += 1;
        HttpManager.shared().doPhoneCodeLogin(this._savePhoneNo, "", this._savePwdNo, 3, this.listenMobileLoginCall.bind(this), this.m_nReq);
    }
    dealFaceBookLoginLogic() {
        0 == AppInfo.shared().getFacebookAuthorization() ? (HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Login, event: ReportConfig.login_evt.fb_auth_pop }), AppInfo.shared().logEvent_firebase(ReportConfig.login_evt.fb_auth_pop)) : AppInfo.shared().logEvent_firebase(ReportConfig.login_evt.fb_auth_no_pop);
        AppInfo.shared().startFacebookLogin("LoginScene", this, "doFaceBookLogic", "");
    }
    doFaceBookLogic(e) {
        if (ToolUtils.isJsonString(e)) {
            let t = ToolUtils.parseJson(e), i = t.code, s = t.error;
            if (400 == i && (s = "fb_cancel"), 401 == i) {
                let e = ReportConfig.login_evt.FB_authorError;
                1 == User.shared().nAutoLoginType && (e = ReportConfig.login_evt.FBAutoAuthorError);
                HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Login, event: e, fb_error: ToolUtils.isSafeString(s) });
                AppInfo.shared().logEvent_firebase(ReportConfig.login_evt.FB_authorError);
            }
            return;
        }
        if (400 == e || 401 == e) {
            let e = ReportConfig.login_evt.FB_authorFail;
            return 1 == User.shared().nAutoLoginType && (e = ReportConfig.login_evt.FBAutoAuthorFail), HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Login, event: e, fb_error: "fb_cancel" }), AppInfo.shared().logEvent_firebase(ReportConfig.login_evt.FB_authorFail), this.reShowLoginUI(), void this.setMaskLayerShow(false);
        }
        let t = ReportConfig.login_evt.FB_authorSuc;
        1 == User.shared().nAutoLoginType && (t = ReportConfig.login_evt.FBAutoAuthorSuc);
        HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Login, event: t });
        AppInfo.shared().logEvent_firebase(ReportConfig.login_evt.FB_authorSuc);
        User.shared().access_token = e;
        this.startFaceBookLogin();
    }
    startFaceBookLogin() {
        this._nAutoLoginCount += 1;
        this.login_node.active && Utils.shared().showLoading(20, true, (() => {
            this.setMaskLayerShow(false);
        }), ToolUtils.getIsNormalDirection(), 1);
        User.shared().loginType = "1";
        let e = User.shared().getLoginParam();
        this.setMaskLayerShow(true);
        this.m_nReq += 1;
        HttpManager.shared().LoginProxy(e, this.listenFBRegisterOrLoginCallback.bind(this), this.m_nReq);
    }
    mobanCallBack(e, t) {
        SoundManager.shared().playFx("click");
    }
    kefuCallBack(e, t) {
        SoundManager.shared().playFx("click");
        if (!ToolUtils.loginKeFu_url && !ToolUtils.feedback_data?.email && !ToolUtils.feedback_data?.whatsapp && !ToolUtils.feedback_data?.tg) {
            Utils.shared().showToast("Sign in to chat with support.", 3);
            return;
        }
        Utils.shared().showContactUsView();
    }
    mobanDeleteCallBack(e, t) {
        let i = sys.localStorage.getItem("Datastar");
        if (null != i && "" != i) {
            let e = ToolUtils.parseJson(i), s = [];
            for (let i = 0, o = e.length; i < o; i++) {
                e[i] != t && s.push(e[i]);
            }
            ToolUtils.saveData("Datastar", ToolUtils.toJsonString(s));
            this.bounstData = s;
            this.refreshWallet();
        }
    }
    onTouchStart(e) {
    }
    clickCallback(e, t) {
        switch (("mask_btn" !== t && null !== e && SoundManager.shared().playFx("click"), "unfold" != t && this.onTouchStart(null), String(t))) {
            case "otp":
                HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Login, event: ReportConfig.login_evt.getOptNum }), AppInfo.shared().logEvent_firebase(ReportConfig.login_evt.getOptNum), this.dealMobileLoginLogic();
                break;
            case "email_otp":
                this.dealEmailLoginLogic();
                break;
            case "clearPhonenumber":
                this.phoneField.string = "", this.phoneNumber = "", this.del_btn.active = false;
                break;
            case "facebookLogin":
                if (1 === User.shared().temp_pingbi.fblogin) {
                    return void Utils.shared().showToast("Coming soon", 2);
                }
                HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Login, event: ReportConfig.login_evt.clickFbBtn }), AppInfo.shared().logEvent_firebase(ReportConfig.login_evt.clickFbBtn), User.shared().nAutoLoginType = -1, this.dealFaceBookLoginLogic();
                break;
            case "googleLogin":
                if (1 === ToolUtils.isSafeNumber(User.shared().temp_pingbi.googlelogin)) {
                    return void Utils.shared().showToast("Coming soon", 2);
                }
                User.shared().nAutoLoginType = -1, this.dealGoogleLoginLogic();
                break;
            case "appleLogin":
                User.shared().nAutoLoginType = -1, this.dealAppleLoginLogic();
                break;
            case "guestLogin":
                if (1 === User.shared().temp_pingbi.guestlogin) {
                    return void Utils.shared().showToast("Coming soon", 2);
                }
                HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Login, event: ReportConfig.login_evt.clickGuestBtn }), AppInfo.shared().logEvent_firebase(ReportConfig.login_evt.clickGuestBtn), Utils.shared().showLoading(20, true, (() => {
                    this.setMaskLayerShow(false);
                }), ToolUtils.getIsNormalDirection()), User.shared().nAutoLoginType = -1, this.refreshProgress(4), this.dealGuestLoginLogic();
                break;
            case "policy":
                this.openTcUrl();
                break;
            case "service":
                this.openPrivacyPolicy();
                break;
            case "responsibly":
                this.openResponsibly();
                break;
            case "clearCode":
                this.otpField.string = "";
                break;
            case "mask_btn": break;
            case "phone_number":
                this.getPhoneNumBtn.active = false, AppInfo.shared().getPhoneNumberListener();
                break;
            case "continue_login":
                let e = this.phoneField.string;
                if (0 === ToolUtils.isSafeString(e).length || 10 !== ToolUtils.isSafeString(e).length) {
                    return void this.showPhoneNoError(true, i18nMgr.shared().getValueByKey("login.error_number"));
                }
                if (User.shared().nAutoLoginType = -1, e == this.otpPhoneNo && User.shared().code_timeout > 0) {
                    return void this.showOptView();
                }
                this.dealMobileLoginLogic();
                break;
            case "back_to_mobile":
                this.showPhoneView();
                break;
            case "change":
                this.showGaidEditboxForTest();
                break;
            case "theme_rummy":
                GameConfig.GAME_APP_THEME = 0, GameConfig.GAME_HALL_THEME = GameConfig.GAME_APP_THEME, this.refreshTheme();
                break;
            case "theme_yes11":
                GameConfig.GAME_APP_THEME = 1, GameConfig.GAME_HALL_THEME = GameConfig.GAME_APP_THEME, this.refreshTheme();
                break;
            case "guest_local_open":
                ToolUtils.showGuestLocal = true, this.showLoginButtons();
                break;
            case "guest_local_close": ToolUtils.showGuestLocal = false, this.showLoginButtons();
        }
    }
    showPhoneView() {
        this.getOtpCount = 1;
        this.mobile_node.active = true;
        this.otp_node.active = false;
        this.curOtpLoginType = 0;
        this.bindEmailNo = "";
        this.showPhoneNoError(false, "");
    }
    showOptView(e = true) {
        this.otpPhoneNo = this.phoneNumber;
        this.mobile_node.active = false;
        this.otp_node.active = true;
        this.showPhoneNoError(false, "");
        this.curOtpLoginType = e ? 0 : 1;
        this.otp_node.getChildByName("otp_tip_info").getChildByName("error_info").active = false;
        e ? (this.otp_node.getChildByName("otp_send_mobile").getComponent(Label).string = this.phoneNumber, this.otp_node.getChildByName("mobile_edit").active = true) : (this.otp_node.getChildByName("otp_send_mobile").getComponent(Label).string = this.bindEmailNo, this.otp_node.getChildByName("mobile_edit").active = false);
        User.shared().code_timeout > 0 ? (this.otp_node.getChildByName("otp_tip_info").getChildByName("otp_time_info").active = true, this.otp_node.getChildByName("otp_tip_info").getChildByName("resend_btn").active = false, this.otp_node.getChildByName("otp_tip_info").getChildByName("resend_email_btn").active = false) : (this.otp_node.getChildByName("otp_tip_info").getChildByName("otp_time_info").active = false, e && (this.otp_node.getChildByName("otp_tip_info").getChildByName("resend_btn").active = true), this.bindEmailNo.length > 0 && (this.otp_node.getChildByName("otp_tip_info").getChildByName("resend_email_btn").active = true));
        this.clearOptView();
    }
    clearOptView() {
        this._otpAutoSubmitted = false;
        for (let e = 0; e < this.otp_Label.length; e++) {
            this.otp_Label[e].string = "";
            this.otp_Label[e].color = color(0, 0, 0);
        }
        this.otpField.string = "";
        this.otpField.focus();
    }
    showPhoneNoError(e, t = "") {
        let i = this.mobile_node.getChildByName("mobile_error_info");
        i.active = e;
        e && (i.getChildByName("tip").getComponent(Label).string = t);
    }
    onTextbegan(e, t) {
        this.onTouchStart(null);
        "phone" === t ? (HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Login, event: ReportConfig.login_evt.inputPhoneNumSuc }), this.showPhoneNoError(false)) : "otp" === t && HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Login, event: ReportConfig.login_evt.enterSigncode });
    }
    checkOtpInputLogic(e) {
        let t = e.length;
        for (let i = 0; i < this.otp_Label.length; i++) {
            this.otp_Label[i].string = i < t ? e.charAt(i) : "";
        }
        if (t >= 6 && !this._otpAutoSubmitted) {
            this._otpAutoSubmitted = true;
            this.checkAndSendOtpReq();
        }
        else if (t < 6) {
            this._otpAutoSubmitted = false;
        }
    }
    onOtpTextChanged(e, t, i) {
        "input_otp_all" != i || this.checkOtpInputLogic(e);
    }
    checkAndSendOtpReq() {
        let e = this.otpField.string;
        if (e.length < 6) {
            return this.otp_node.getChildByName("otp_tip_info").getChildByName("error_info").active = true, void (this.otp_node.getChildByName("otp_tip_info").getChildByName("error_info").getChildByName("tip").getComponent(Label).string = i18nMgr.shared().getValueByKey("login.error_otp"));
        }
        this.otp_node.getChildByName("otp_tip_info").getChildByName("error_info").active = false;
        try {
            this.setMaskLayerShow(true);
            Utils.shared().showLoading(20, true, (() => {
                this.setMaskLayerShow(false);
            }), ToolUtils.getIsNormalDirection());
            this.m_nReq += 1;
            this.refreshProgress(4);
            0 == this.curOtpLoginType ? (User.shared().loginType = "3", HttpManager.shared().doPhoneCodeLogin(this.phoneNumber, e, "", 3, this.listenMobileLoginCall.bind(this), this.m_nReq)) : (User.shared().loginType = "3", HttpManager.shared().doEmailCodeLogin(this.phoneNumber, this.bindEmailNo, e, "", 3, this.listenMobileLoginCall.bind(this), this.m_nReq));
        }
        catch (e) {
        }
    }
    onOtpTextEnded(e, t) {
        if (this._otpAutoSubmitted) {
            return;
        }
        if (this.otpField.string.length >= 6) {
            this._otpAutoSubmitted = true;
        }
        this.checkAndSendOtpReq();
    }
    onTextChanged(e, t, i) {
        ToolUtils.isSafeString(e).length > 0 ? this.del_btn.active = true : this.del_btn.active = false;
    }
    showCodeError(e) {
        ToolUtils.isSafeString(e).length > 0 && Utils.shared().showToast(ToolUtils.isSafeString(e), 3);
    }
    showError(e) {
        ToolUtils.isSafeString(e).length > 0 && Utils.shared().showToast(ToolUtils.isSafeString(e), 3);
    }
    showLoginError(e) {
        ToolUtils.isSafeString(e).length > 0 && Utils.shared().showToast(ToolUtils.isSafeString(e), 3);
    }
    dealGuestLoginLogic() {
        this._nAutoLoginCount += 1;
        this.setMaskLayerShow(true);
        User.shared().loginType = "0";
        let e = User.shared().getLoginParam();
        this.m_nReq += 1;
        HttpManager.shared().LoginProxy(e, this.listenRegisterOrLoginCallback.bind(this), this.m_nReq);
    }
    dealEmailLoginLogic() {
        try {
            this.setMaskLayerShow(true);
            Utils.shared().showLoading(30, true, (() => {
                this.setMaskLayerShow(false);
            }), ToolUtils.getIsNormalDirection());
            HttpManager.shared().doGetLoginEmailCode(this.bindEmailNo, this.phoneNumber, this.listenGetEmailCodeCall.bind(this));
            AppInfo.shared().receivedCodeListener();
        }
        catch (e) {
        }
    }
    dealMobileLoginLogic() {
        let e = this.phoneField.textLabel.string;
        if (10 == e.length) {
            this.phoneNumber = e;
            try {
                this.setMaskLayerShow(true);
                Utils.shared().showLoading(30, true, (() => {
                    this.setMaskLayerShow(false);
                }), ToolUtils.getIsNormalDirection());
                HttpManager.shared().doGetMobileCode(e, 3, 1, this.listenGetCodeCall.bind(this), this.getOtpCount);
                AppInfo.shared().receivedCodeListener();
            }
            catch (e) {
            }
        }
        else {
            this.showPhoneNoError(true, i18nMgr.shared().getValueByKey("login.error_number"));
        }
    }
    listenGetEmailCodeCall(e, t, i) {
        if (Utils.shared().hideLoading(), this.setMaskLayerShow(false), 200 !== i) {
            Utils.shared().showCommomDialog(i18nMgr.shared().getValueByKey("utlis.text7"), "", (() => {
            }));
        }
        else {
            let e = ToolUtils.parseJson(t);
            if (0 === e.ret) {
                this.getOtpCount += 1;
                let t = e.data.timeout;
                if (User.shared().code_timeout = t, this.showOptView(false), this.refreshCode(), e.desc && ToolUtils.isSafeString(e.desc).length > 0) {
                    let t = ToolUtils.isSafeString(e.desc);
                    Utils.shared().showToast(t, 3);
                }
            }
            else {
                if (e.desc && ToolUtils.isSafeString(e.desc).length > 0) {
                    let t = ToolUtils.isSafeString(e.desc);
                    this.mobile_node.active && this.showPhoneNoError(true, t);
                }
                let t = e.data.timeout;
                t && ToolUtils.isSafeNumber(t) > 0 && (User.shared().code_timeout = t, this.refreshCode());
            }
        }
    }
    listenGetCodeCall(e, t, i) {
        if (Utils.shared().hideLoading(), this.setMaskLayerShow(false), 200 !== i) {
            Utils.shared().showCommomDialog(i18nMgr.shared().getValueByKey("utlis.text7"), "", (() => {
            }));
        }
        else {
            let e = ToolUtils.parseJson(t);
            if (0 === e.ret) {
                this.getOtpCount += 1;
                let t = e.data.timeout;
                if (User.shared().code_timeout = t, this.showOptView(), sys.isObjectValid(e.data.email) && e.data.email.length > 0 && (this.bindEmailNo = e.data.email), this.refreshCode(), e.desc && ToolUtils.isSafeString(e.desc).length > 0) {
                    let t = ToolUtils.isSafeString(e.desc);
                    Utils.shared().showToast(t, 3);
                }
            }
            else {
                if (e.desc && ToolUtils.isSafeString(e.desc).length > 0) {
                    let t = ToolUtils.isSafeString(e.desc);
                    this.mobile_node.active && this.showPhoneNoError(true, t);
                }
                let t = e.data.timeout;
                t && ToolUtils.isSafeNumber(t) > 0 && (User.shared().code_timeout = t, this.refreshCode());
            }
        }
    }
    listenFBRegisterOrLoginCallback(e, t, i) {
        if (sys.isObjectValid(this.node)) {
            if (200 !== i) {
                if (1 == User.shared().nAutoLoginType && this._nAutoLoginCount < this._nMaxTime) {
                    return void this.startFaceBookLogin();
                }
                Utils.shared().hideLoading();
                Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text7"), 2, 0);
                this.reShowLoginUI();
                this.setMaskLayerShow(false);
                let e = ReportConfig.login_evt.FBLoginFail;
                1 == User.shared().nAutoLoginType && (e = ReportConfig.login_evt.FBAutoLoginFail);
                User.shared().nAutoLoginType = -1;
                HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Login, event: e, err_code: "req" + i });
                AppInfo.shared().logEvent_firebase(ReportConfig.login_evt.fb_login_timeout);
            }
            else {
                let e = ToolUtils.parseJson(t);
                if (0 !== e.ret) {
                    Utils.shared().hideLoading();
                    ToolUtils.saveData("logintype", "-1");
                    this.reShowLoginUI();
                    this.setMaskLayerShow(false);
                    let t = ReportConfig.login_evt.FBLoginFail;
                    1 == User.shared().nAutoLoginType && (t = ReportConfig.login_evt.FBAutoLoginFail);
                    User.shared().nAutoLoginType = -1;
                    HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Login, event: t, err_code: e.ret });
                    AppInfo.shared().logEvent_firebase(ReportConfig.login_evt.FBLoginFail);
                }
                if (0 === e.ret) {
                    if (Utils.shared().hideLoading(), e.data.req_key !== this.m_nReq) {
                        return void TLog.printError("------------ login req_key error!");
                    }
                    if (this.showLoginNode(false), User.shared().initLoginMsg(e), 1 == e.data.isregister) {
                        HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Login, event: ReportConfig.login_evt.FB_registSuc });
                        AppInfo.shared().logEvent_firebase(ReportConfig.login_evt.FB_registSuc);
                    }
                    else {
                        let e = ReportConfig.login_evt.FBLoginSuc;
                        1 == User.shared().nAutoLoginType && (e = ReportConfig.login_evt.FBAutoLoginSuc);
                        HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Login, event: e });
                        AppInfo.shared().logEvent_firebase(ReportConfig.login_evt.FBLoginSuc);
                    }
                    this.jumpToHallScene();
                }
                else if (901 === e.ret || 800 === e.ret || 801 === e.ret || 805 === e.ret || 400 === e.ret) {
                    let t = true;
                    if (this.reShowLoginUI(), 400 === e.ret && e.data.verify && "tel_no" == e.data.verify) {
                        t = false;
                        let i = {};
                        i.tel_no = e.data.tel_no;
                        i.show_verify = e.data.show_verify;
                        Utils.shared().showLoginSafeVerification(i, (e => {
                            0 == e ? this.jumpToHallScene() : 1 == e ? this.showMaintainAlert() : 2 == e && (this.reShowLoginUI(), this.setMaskLayerShow(false));
                        }), this.node);
                    }
                    t && Utils.shared().showToast(ToolUtils.isSafeString(e.desc), 2, 0);
                }
                else if (9999 === e.ret) {
                    User.shared().maintainMsg = e.data;
                    User.shared().hasMaintain = true;
                    this.showMaintainAlert();
                }
                else if (608 === e.ret) {
                    let e = { type: 1 };
                    Utils.shared().showLoginBlindPhoneView(e, (e => {
                        0 == e ? this.jumpToHallScene() : 1 == e ? this.showMaintainAlert() : 2 == e && (this.reShowLoginUI(), this.setMaskLayerShow(false));
                    }), this.node);
                }
                else {
                    this.reShowLoginUI();
                    let t = i18nMgr.shared().getValueByKey("utlis.text7");
                    e.desc && (t = e.desc);
                    Utils.shared().showToast(t, 2, 0);
                }
            }
        }
    }
    listenRegisterOrLoginCallback(e, t, i) {
        if (sys.isObjectValid(this.node)) {
            if (200 !== i) {
                if (0 == User.shared().nAutoLoginType && this._nAutoLoginCount < this._nMaxTime) {
                    return void this.dealGuestLoginLogic();
                }
                Utils.shared().hideLoading();
                Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text7"), 2, 0);
                this.reShowLoginUI();
                this.setMaskLayerShow(false);
                let e = ReportConfig.login_evt.guestLoginFail;
                0 == User.shared().nAutoLoginType && (e = ReportConfig.login_evt.guestAutoLoginFail);
                User.shared().nAutoLoginType = -1;
                HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Login, event: e, err_code: "req" + i });
                AppInfo.shared().logEvent_firebase(ReportConfig.login_evt.guest_login_timeout);
            }
            else {
                let e = ToolUtils.parseJson(t);
                if (0 !== e.ret) {
                    Utils.shared().hideLoading();
                    this.reShowLoginUI();
                    this.setMaskLayerShow(false);
                    let t = ReportConfig.login_evt.guestLoginFail;
                    0 == User.shared().nAutoLoginType && (t = ReportConfig.login_evt.guestAutoLoginFail);
                    User.shared().nAutoLoginType = -1;
                    HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Login, event: t, err_code: e.ret });
                    AppInfo.shared().logEvent_firebase(ReportConfig.login_evt.guestLoginFail);
                }
                if (0 === e.ret) {
                    if (Utils.shared().hideLoading(), e.data.req_key !== this.m_nReq) {
                        return void TLog.printError("------------ login req_key error!");
                    }
                    if (this.showLoginNode(false), User.shared().initLoginMsg(e), 1 == e.data.isregister) {
                        HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Login, event: ReportConfig.login_evt.guestRegistSuc });
                        AppInfo.shared().logEvent_firebase(ReportConfig.login_evt.guestRegistSuc);
                    }
                    else {
                        let e = ReportConfig.login_evt.guestLoginSuc;
                        0 == User.shared().nAutoLoginType && (e = ReportConfig.login_evt.guestAutoLoginSuc);
                        HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Login, event: e });
                        AppInfo.shared().logEvent_firebase(ReportConfig.login_evt.guestLoginSuc);
                    }
                    this.jumpToHallScene();
                }
                else if (901 === e.ret || 800 === e.ret || 801 === e.ret || 805 === e.ret || 400 === e.ret) {
                    Utils.shared().showToast(ToolUtils.isSafeString(e.desc), 2, 0);
                    this.reShowLoginUI();
                    ToolUtils.saveData("logintype", "-1");
                }
                else if (9999 === e.ret) {
                    User.shared().maintainMsg = e.data;
                    User.shared().hasMaintain = true;
                    this.showMaintainAlert();
                }
                else {
                    ToolUtils.saveData("logintype", "-1");
                    this.reShowLoginUI();
                    let t = i18nMgr.shared().getValueByKey("utlis.text7");
                    sys.isObjectValid(e.desc) && e.desc.length > 0 && (t = e.desc);
                    Utils.shared().showToast(t, 2, 0);
                    -1 != GameConfig.CHIPS_CHANNELS.indexOf(GameConfig.CHANNEL_ID) && 1 == GameConfig.CHIPS_MODLE ? (ToolUtils.saveData("LoginProxy_password" + AppInfo.shared().getChannelId() + GameConfig.CHIPS_MODLE, ""), ToolUtils.saveData("LoginProxy_user" + AppInfo.shared().getChannelId() + GameConfig.CHIPS_MODLE, "")) : (ToolUtils.saveData("LoginProxy_password" + AppInfo.shared().getChannelId(), ""), ToolUtils.saveData("LoginProxy_user" + AppInfo.shared().getChannelId(), ""));
                }
            }
        }
    }
    switchToLoadView() {
        this.showLoginNode(false);
    }
    listenMobileLoginCall(e, t, i) {
        if (sys.isObjectValid(this.node)) {
            if (200 !== i) {
                if (2 == User.shared().nAutoLoginType && this._nAutoLoginCount < this._nMaxTime) {
                    return void this.startMoblieLogin();
                }
                if (3 == User.shared().nAutoLoginType && this._nAutoLoginCount < this._nMaxTime) {
                    return void this.startOtpCodeLogin();
                }
                Utils.shared().hideLoading();
                this.otp_node.getChildByName("otp_tip_info").getChildByName("error_info").active = true;
                this.otp_node.getChildByName("otp_tip_info").getChildByName("error_info").getChildByName("tip").getComponent(Label).string = i18nMgr.shared().getValueByKey("utlis.text7");
                this.setMaskLayerShow(false);
                this._autoLogin && (this._autoLogin = false, this.reShowLoginUI());
                let e = ReportConfig.login_evt.phoneLoginFail;
                2 == User.shared().nAutoLoginType ? e = ReportConfig.login_evt.phoneAutoLoginFail : 3 == User.shared().nAutoLoginType && (e = ReportConfig.login_evt.codeAutoLoginFail);
                User.shared().nAutoLoginType = -1;
                HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Login, event: e, err_code: "req" + i });
                AppInfo.shared().logEvent_firebase(ReportConfig.login_evt.tel_login_timeout);
            }
            else {
                let e = ToolUtils.parseJson(t);
                if (0 === e.ret) {
                    if (Utils.shared().hideLoading(), e.data.req_key !== this.m_nReq) {
                        return void TLog.printError("------------ login req_key error!");
                    }
                    this.switchToLoadView();
                    User.shared().initLoginMsg(e);
                    let t = sys.localStorage.getItem("Datastar");
                    if (null != t && "" != t) {
                        let i = ToolUtils.parseJson(t);
                        i.length > 6 && i.pop();
                        let s = [];
                        3 == e.data.logintype && i.unshift(e.data.tel_no);
                        6 == e.data.logintype && i.unshift(e.data.account);
                        for (let e = 0, t = i.length; e < t; e++) {
                            s.indexOf(i[e]) < 0 && null != i[e] && s.push(i[e]);
                        }
                        i = s;
                        this.bounstData = i;
                        ToolUtils.saveData("Datastar", ToolUtils.toJsonString(i));
                    }
                    else {
                        let t = [];
                        this.bounstData = [];
                        let i = [];
                        3 == e.data.logintype && t.unshift(e.data.tel_no);
                        6 == e.data.logintype && t.unshift(e.data.account);
                        for (let e = 0, s = t.length; e < s; e++) {
                            i.indexOf(t[e]) < 0 && null != t[e] && i.push(t[e]);
                        }
                        t = i;
                        this.bounstData = t;
                        ToolUtils.saveData("Datastar", ToolUtils.toJsonString(t));
                    }
                    this.refreshWallet();
                    this.jumpToHallScene();
                }
                else {
                    Utils.shared().hideLoading();
                    let t = ReportConfig.login_evt.phoneLoginFail;
                    2 == User.shared().nAutoLoginType ? t = ReportConfig.login_evt.phoneAutoLoginFail : 3 == User.shared().nAutoLoginType && (t = ReportConfig.login_evt.codeAutoLoginFail);
                    User.shared().nAutoLoginType = -1;
                    HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Login, event: t, err_code: e.ret });
                    AppInfo.shared().logEvent_firebase(ReportConfig.login_evt.phoneLoginFail);
                    9999 === e.ret ? (User.shared().maintainMsg = e.data, User.shared().hasMaintain = true, this.showMaintainAlert()) : (ToolUtils.saveData("logintype", "-1"), ToolUtils.isSafeString(e.desc).length > 0 && (this.otp_node.getChildByName("otp_tip_info").getChildByName("error_info").active = true, this.otp_node.getChildByName("otp_tip_info").getChildByName("error_info").getChildByName("tip").getComponent(Label).string = ToolUtils.isSafeString(e.desc)));
                    this._autoLogin && (this._autoLogin = false, this.reShowLoginUI());
                    this.setMaskLayerShow(false);
                }
            }
        }
    }
    jumpToHallScene() {
        if (this.showProgress(), 1 == GameConfig.CHIPS_MODLE) {
            let e = { vid: 6201, isNewTable: 1, game_type: CommonGameType.Ludo };
            return this.refreshProgress(5), Utils.shared().showCommEnterGame(e), void Utils.shared().showLoading(10, true, (() => {
                Utils.shared().hideLoading();
                Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text7"), 2, 0);
                this.reShowLoginUI(true);
            }), ToolUtils.getIsNormalDirection());
        }
        if (window.InHallScene) {
            return;
        }
        if (ToolUtils.report_time_param.jumpToHall = sys.now(), this.refreshProgress(5), Utils.shared().hideLoading(), this.setMaskLayerShow(true), this.hostAction && (TweenTool.stopAction(this.hostAction), this.hostAction = null), !User.shared().hasPreload) {
            let e = sys.isObjectValid(User.shared().data.beginner_reward) && User.shared().data.beginner_reward.length > 0;
            Utils.shared().preLoadBundleAsset(false, e);
        }
        Utils.shared().hideCommomDialog();
        User.shared().hasLogin = false;
        this.hasLoginScucess = true;
        let e = this;
        this.scheduleOnce((() => {
            AppInfo.shared().logEvent_firebase(ReportConfig.login_evt.load_hall_scene_begin);
            try {
                assetManager.loadBundle(BundleNameDefined.bundle_hall, null, ((t, i) => {
                    null == t ? i.loadScene(BundleNameDefined.hall_scene, ((t, i) => {
                        if (ToolUtils.report_time_param.loadHallResEnd = sys.now(), window.InHallScene = true, e.refreshProgress(6), i && i.isValid) {
                            if (User.shared().checkIfHasLoadHallBundle()) {
                                Utils.shared().hideLoading();
                                User.shared().isLoginHall = true;
                                AppInfo.shared().logEvent_firebase(ReportConfig.login_evt.load_hall_scene_succ);
                                director.runScene(i);
                            }
                            else {
                                let t = false, s = 0;
                                e.schedule((o => {
                                    s += o;
                                    t || (User.shared().checkIfHasLoadHallBundle() || s >= 2) && (t = true, Utils.shared().hideLoading(), User.shared().isLoginHall = true, AppInfo.shared().logEvent_firebase(ReportConfig.login_evt.load_hall_scene_succ), director.runScene(i), e.unscheduleAllCallbacks());
                                }));
                            }
                        }
                        else {
                            e.setMaskLayerShow(false);
                            Utils.shared().hideLoading();
                        }
                    })) : e.setMaskLayerShow(false);
                }));
            }
            catch (e) {
                TLog.printError("LoginScene load hall scene,error:", e);
            }
        }));
    }
    showLoginButtons() {
        let e = 0 == User.shared().temp_pingbi.fblogin;
        sys.isObjectValid(this.curFbButton) && (this.curFbButton.active = e);
        let t = false;
        "MOBILE_BROWSER" == sys.platform || "DESKTOP_BROWSER" == sys.platform ? sys.isObjectValid(this.guestLoginBtn) && (t = !!ToolUtils.showGuestLocal || 1 == ToolUtils.showGuest, this.guestLoginBtn.node.active = t) : sys.isObjectValid(this.guestLoginBtn) && (t = 1 == ToolUtils.showGuest, this.guestLoginBtn.node.active = t);
        this.orImgNode.active = t || 0 == User.shared().temp_pingbi.fblogin;
    }
    updateLoadTipLabel() {
        let e = ToolUtils.getRandomInt(0, 39);
        i18nMgr.shared().changeLabelLanguage(this.updateUI.getChildByName("label_tip1").getComponent(Label), "login.load_tip" + e);
    }
    showProgress() {
        ToolUtils.isObjValid(this.updateUI) && !this.updateUI.active && (this.updateUI.active = true, this.updateUI.getChildByName("label_loading").active = true, this._bLoadTipRand = true, i18nMgr.shared().changeLabelLanguage(this.updateUI.getChildByName("label_tip1").getComponent(Label), "login.load_tip0"));
        this.updateProgressByStep();
    }
    refreshProgress(e, t = true) {
        if (ToolUtils.isObjValid(this.updateUI) && this.updateUI.active) {
            if (this._loadStep[e] || (e = this._loadStep.length - 1), this._curProgress > this._loadStep[e].end) {
                return;
            }
            this._curLoadStep = e;
            this.showProgress();
            this._bProgressRun = t;
        }
    }
    updateProgressByStep() {
        if (sys.isObjectValid(this.byteProgress)) {
            if (this._loadStep[this._curLoadStep] || (this._curLoadStep = this._loadStep.length - 1), this._lastLoadStep > 0) {
                if (this._curProgress >= this._loadStep[this._lastLoadStep].end) {
                    if (this._curProgress < this._loadStep[this._curLoadStep].start) {
                        this._curProgress = this._loadStep[this._curLoadStep].start;
                    }
                    else {
                        let e = this._curProgress + ToolUtils.getRandomInt(0, this._loadStep[this._curLoadStep].stepRand);
                        e < this._loadStep[this._curLoadStep].end && (this._curProgress = e);
                    }
                }
                else {
                    this._curProgress = this._loadStep[this._lastLoadStep].end;
                }
                this._lastLoadStep = -1;
            }
            else if (this._curProgress < this._loadStep[this._curLoadStep].start) {
                this._curProgress = this._loadStep[this._curLoadStep].start;
            }
            else {
                let e = this._curProgress + ToolUtils.getRandomInt(0, this._loadStep[this._curLoadStep].stepRand);
                e < this._loadStep[this._curLoadStep].end && (this._curProgress = e);
            }
            this.byteProgress.progress = this._curProgress / 100;
            this.updateUI.getChildByName("label_loading").getComponent(Label).string = "Loading " + Math.floor(this._curProgress) + "%";
        }
    }
    updateProgressByDownLoad(e) {
        if (!sys.isObjectValid(this.byteProgress)) {
            return;
        }
        let t = this._loadStep[this._curLoadStep], i = t.start + (t.end - t.start) * e;
        i > this._curProgress && (this._curProgress = i, this._curProgress - this._tmpProgress >= 1.5 && (this._tmpProgress = this._curProgress, this.byteProgress.progress = this._curProgress / 100, this.updateUI.getChildByName("label_loading").getComponent(Label).string = "Loading " + Math.floor(this._curProgress) + "%"));
    }
    hideProgress() {
        this.updateUI.active = false;
        this._bLoadTipRand = false;
        this._bProgressRun = false;
    }
    showLoading(e = 0, t = null, i = 0) {
        0 == i && (this.loading.active = true);
        null == this.loadingAction && TweenTool.delayAct(this.node, (() => {
            this.loading.active = true;
            let e = this.loading.getChildByName("img");
            TweenTool.stopNodeAction(e);
            this.loading.getChildByName("label").getComponent(Label).string = i18nMgr.shared().getValueByKey("login.loading") + "...";
            this.loadingAction && (TweenTool.stopAction(this.loadingAction), this.loadingAction = null);
            this.loadingAction = tween(e).by(0.2, { eulerAngles: new Vec3(0, 0, -90) }, { easing: "fade" }).repeat(4).union().repeatForever().start();
        }), i, true);
        this.loadingDelayAction && (TweenTool.stopAction(this.loadingDelayAction), this.loadingDelayAction = null);
        e > 0 && (this.loadingDelayAction = TweenTool.delayAct(this.node, (() => {
            ToolUtils.isObjValid(this.node) && (t && t(), this.hideLoading());
        }), e, true));
    }
    hideLoading() {
        this.loadingDelayAction && (TweenTool.stopAction(this.loadingDelayAction), this.loadingDelayAction = null);
        this.hotupdateDelay && (TweenTool.stopAction(this.hotupdateDelay), this.hotupdateDelay = null);
        this.loginDelay && (TweenTool.stopAction(this.loginDelay), this.loginDelay = null);
        this.loading.active = false;
    }
    openPrivacyPolicy() {
        ToolUtils.isSafeString(ToolUtils.pp_url).length > 0 && Utils.shared().doJumpLogic(PushEvent.JUMP_TO_PrivacyPolicy);
    }
    openTcUrl() {
        ToolUtils.isSafeString(ToolUtils.tos_url).length > 0 && Utils.shared().doCustomJump(PushEvent.Custom_TO_TC);
    }
    openResponsibly() {
        ToolUtils.isSafeString(ToolUtils.responsible_url).length > 0 && Utils.shared().doJumpLogic(PushEvent.JUMP_TO_LOGIN_RESPONSIBLY);
    }
    dealGoogleLoginLogic() {
        HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Login, event: ReportConfig.login_evt.google_auth_req });
        AppInfo.shared().startGoogleLogin("LoginScene", this, "doGoogleLogic");
    }
    doGoogleLogic(e) {
        if (ToolUtils.isJsonString(e)) {
            let t = ToolUtils.parseJson(e), i = Number(t.code);
            if (0 == i) {
                let e = ReportConfig.login_evt.google_auth_succ;
                7 == User.shared().nAutoLoginType && (e = ReportConfig.login_evt.googleAutoAuthSucc);
                HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Login, event: e });
                User.shared().access_token = t.uid || "";
                this._googleName = t.name || "";
                this._googleAvatar = t.avatar || "";
                this._googleEmail = t.email || "";
                this._googlePhone = t.phone || "";
                this.setMaskLayerShow(true);
                this.startReqGoogleLogin();
            }
            else if (400 == i) {
                let e = ToolUtils.isSafeString(t.error), i = ReportConfig.login_evt.google_auth_fail;
                return 7 == User.shared().nAutoLoginType && (i = ReportConfig.login_evt.googleAutoAuthFail), HttpManager.shared().doNewSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Login, event: i, fb_error: e }), this.reShowLoginUI(), void this.setMaskLayerShow(false);
            }
        }
        else if (400 == e) {
            let e = ReportConfig.login_evt.google_auth_fail;
            return 7 == User.shared().nAutoLoginType && (e = ReportConfig.login_evt.googleAutoAuthFail), HttpManager.shared().doNewSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Login, event: e }), this.reShowLoginUI(), void this.setMaskLayerShow(false);
        }
    }
    startReqGoogleLogin() {
        this._nAutoLoginCount += 1;
        this.login_node.active && Utils.shared().showLoading(20, true, (() => {
            this.setMaskLayerShow(false);
        }), ToolUtils.getIsNormalDirection());
        User.shared().loginType = "7";
        let e = User.shared().getLoginParam();
        e.gp_name = this._googleName;
        e.gp_avatar = this._googleAvatar;
        e.gp_email = this._googleEmail;
        e.gp_phone = this._googlePhone;
        this.m_nReq += 1;
        HttpManager.shared().LoginProxy(e, this.listenGoogleRegisterOrLoginCallback.bind(this), this.m_nReq);
    }
    listenGoogleRegisterOrLoginCallback(e, t, i) {
        if (sys.isObjectValid(this.node)) {
            if (200 !== i) {
                if (7 == User.shared().nAutoLoginType && this._nAutoLoginCount < this._nMaxTime) {
                    return void this.startReqGoogleLogin();
                }
                Utils.shared().hideLoading();
                Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text7"), 2, 0);
                this.reShowLoginUI();
                this.setMaskLayerShow(false);
                let e = ReportConfig.login_evt.google_login_fail;
                7 == User.shared().nAutoLoginType && (e = ReportConfig.login_evt.googleAutoLoginFail);
                User.shared().nAutoLoginType = -1;
                HttpManager.shared().doNewSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Login, event: e, err_code: "req" + i });
            }
            else {
                let e = ToolUtils.parseJson(t);
                if (0 !== e.ret) {
                    Utils.shared().hideLoading();
                    ToolUtils.saveData("logintype", "-1");
                    this.reShowLoginUI();
                    this.setMaskLayerShow(false);
                    let t = ReportConfig.login_evt.google_login_fail;
                    7 == User.shared().nAutoLoginType && (t = ReportConfig.login_evt.googleAutoLoginFail);
                    User.shared().nAutoLoginType = -1;
                    HttpManager.shared().doNewSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Login, event: t, err_code: e.ret });
                }
                if (0 === e.ret) {
                    if (Utils.shared().hideLoading(), e.data.req_key !== this.m_nReq) {
                        return void TLog.printError("------------ login req_key error!");
                    }
                    if (User.shared().initLoginMsg(e), 1 == e.data.isregister) {
                        HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Login, event: ReportConfig.login_evt.google_reg_succ });
                    }
                    else {
                        let e = ReportConfig.login_evt.google_login_succ;
                        7 == User.shared().nAutoLoginType && (e = ReportConfig.login_evt.googleAutoLoginSucc);
                        HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Login, event: e });
                    }
                    this.jumpToHallScene();
                }
                else if (901 === e.ret || 800 === e.ret || 801 === e.ret || 805 === e.ret || 400 === e.ret) {
                    let t = true;
                    if (this.reShowLoginUI(), 400 === e.ret && e.data.verify && "tel_no" == e.data.verify) {
                        t = false;
                        let i = {};
                        i.tel_no = e.data.tel_no;
                        i.show_verify = e.data.show_verify;
                        Utils.shared().showLoginSafeVerification(i, (e => {
                            0 == e ? this.jumpToHallScene() : 1 == e ? this.showMaintainAlert() : 2 == e && (this.reShowLoginUI(), this.setMaskLayerShow(false));
                        }), this.node);
                    }
                    t && Utils.shared().showToast(ToolUtils.isSafeString(e.desc), 2, 0);
                }
                else if (9999 === e.ret) {
                    User.shared().maintainMsg = e.data;
                    User.shared().hasMaintain = true;
                    this.showMaintainAlert();
                }
                else {
                    this.reShowLoginUI();
                    let t = i18nMgr.shared().getValueByKey("utlis.text7");
                    e.desc && (t = e.desc);
                    Utils.shared().showToast(t, 2, 0);
                }
            }
        }
    }
    dealAppleLoginLogic() {
        HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Login, event: ReportConfig.login_evt.apple_auth_req });
        let e = ToolUtils.isSafeString(localStorage.getItem(CommDefine.AppleTokenKey));
        e.length > 0 ? this.doAppleLogic(e) : AppInfo.shared().startAppleLogin("LoginScene", "AppleLogin");
    }
    doAppleLogic(e) {
        if (ToolUtils.isJsonString(e)) {
            let t = ToolUtils.parseJson(e), i = (t.code, t.error);
            HttpManager.shared().doNewSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Login, event: ReportConfig.login_evt.apple_auth_fail, fb_error: ToolUtils.isSafeString(i) });
        }
        else {
            localStorage.setItem(CommDefine.AppleTokenKey, e);
            HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Login, event: ReportConfig.login_evt.apple_auth_succ });
            User.shared().access_token = e;
            this.startReqAppleLogin();
        }
    }
    startReqAppleLogin() {
        this._nAutoLoginCount += 1;
        this.login_node.active && Utils.shared().showLoading(20, true, (() => {
            this.setMaskLayerShow(false);
        }), ToolUtils.getIsNormalDirection(), 1);
        User.shared().loginType = "5";
        let e = User.shared().getLoginParam();
        this.setMaskLayerShow(true);
        this.m_nReq += 1;
        HttpManager.shared().LoginProxy(e, this.listenAppleRegisterOrLoginCallback.bind(this), this.m_nReq);
    }
    listenAppleRegisterOrLoginCallback(e, t, i) {
        if (sys.isObjectValid(this.node)) {
            if (200 !== i) {
                if (5 == User.shared().nAutoLoginType && this._nAutoLoginCount < this._nMaxTime) {
                    return void this.startReqAppleLogin();
                }
                Utils.shared().hideLoading();
                Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text7"), 2, 0);
                this.reShowLoginUI();
                this.setMaskLayerShow(false);
                let e = ReportConfig.login_evt.apple_login_fail;
                5 == User.shared().nAutoLoginType && (e = ReportConfig.login_evt.appleAutoLoginFail);
                User.shared().nAutoLoginType = -1;
                HttpManager.shared().doNewSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Login, event: e, err_code: "req" + i });
            }
            else {
                let e = ToolUtils.parseJson(t);
                if (0 !== e.ret) {
                    Utils.shared().hideLoading();
                    ToolUtils.saveData("logintype", "-1");
                    this.reShowLoginUI();
                    this.setMaskLayerShow(false);
                    let t = ReportConfig.login_evt.apple_login_fail;
                    5 == User.shared().nAutoLoginType && (t = ReportConfig.login_evt.appleAutoLoginFail);
                    User.shared().nAutoLoginType = -1;
                    HttpManager.shared().doNewSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Login, event: t, err_code: e.ret });
                }
                if (0 === e.ret) {
                    if (Utils.shared().hideLoading(), e.data.req_key !== this.m_nReq) {
                        return void TLog.printError("------------ login req_key error!");
                    }
                    if (User.shared().initLoginMsg(e), 1 == e.data.isregister) {
                        HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Login, event: ReportConfig.login_evt.apple_reg_succ });
                    }
                    else {
                        let e = ReportConfig.login_evt.apple_login_succ;
                        5 == User.shared().nAutoLoginType && (e = ReportConfig.login_evt.appleAutoLoginSucc);
                        HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Login, event: e });
                    }
                    this.jumpToHallScene();
                }
                else if (901 === e.ret || 800 === e.ret || 801 === e.ret || 805 === e.ret || 400 === e.ret) {
                    let t = true;
                    if (this.reShowLoginUI(), 400 === e.ret && e.data.verify && "tel_no" == e.data.verify) {
                        t = false;
                        let i = {};
                        i.tel_no = e.data.tel_no;
                        i.show_verify = e.data.show_verify;
                        Utils.shared().showLoginSafeVerification(i, (e => {
                            0 == e ? this.jumpToHallScene() : 1 == e ? this.showMaintainAlert() : 2 == e && (this.reShowLoginUI(), this.setMaskLayerShow(false));
                        }), this.node);
                    }
                    t && Utils.shared().showToast(ToolUtils.isSafeString(e.desc), 2, 0);
                }
                else if (9999 === e.ret) {
                    User.shared().maintainMsg = e.data;
                    User.shared().hasMaintain = true;
                    this.showMaintainAlert();
                }
                else if (608 === e.ret) {
                    let e = { type: 2 };
                    Utils.shared().showLoginBlindPhoneView(e, (e => {
                        0 == e ? this.jumpToHallScene() : 1 == e ? this.showMaintainAlert() : 2 == e && (this.reShowLoginUI(), this.setMaskLayerShow(false));
                    }), this.node);
                }
                else {
                    this.reShowLoginUI();
                    let t = i18nMgr.shared().getValueByKey("utlis.text7");
                    e.desc && (t = e.desc);
                    Utils.shared().showToast(t, 2, 0);
                }
            }
        }
    }
}
