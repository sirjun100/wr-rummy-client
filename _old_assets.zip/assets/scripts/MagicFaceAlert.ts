// @ts-nocheck
// Recovered from index.js:283
import { _decorator, Button, color, director, instantiate, Label, LabelShadow, Layout, Node, Prefab, ScrollView, size, Sprite, SpriteAtlas, SpriteFrame, sys, UITransform, v3, Vec3 } from "cc";
import SoundManager from "./SoundManager";
import Utils from "./Utils";
import TweenTool from "./TweenTool";
import GameConfig from "./GameConfig";
import PushCenter from "./PushCenter";
import BaseLayer from "./BaseLayer";
import User from "./User";
import PushEvent from "./PushEvent";
import RummyDataManager, { RoomRewardType, RUMMY_PLAYER_STATE_TYPE } from "./RummyDataManager";
import RummyCardConstant from "./RummyCardConstant";
import { ToolUtils } from "./ToolUtils";
import PhpReportDefined from "./PhpReportDefined";
const { ccclass, property } = _decorator;
@ccclass("MagicFaceAlert")
export default class MagicFaceAlert extends BaseLayer {
    public TAG: string = "MagicFaceAlert";
    @property([Vec3])
    public vecMoneyPos: Vec3[] = [];
    @property(SpriteAtlas)
    public myAtlas: SpriteAtlas = null;
    @property([SpriteFrame])
    public face_imgs: SpriteFrame[] = [];
    @property([SpriteFrame])
    public recordIcon_imgs: SpriteFrame[] = [];
    @property(Node)
    public bgNode: Node = null;
    @property(Node)
    public faceModelNode: Node = null;
    @property(Node)
    public rootNode: Node = null;
    @property(Node)
    public playeInfoNode: Node = null;
    @property(Sprite)
    public headSp: Sprite = null;
    @property(Node)
    public clubKuang: Node = null;
    @property(Node)
    public club: Node = null;
    @property(Node)
    public vip: Node = null;
    @property(Label)
    public nameLable: Label = null;
    @property(Node)
    public cashTitleNode: Node = null;
    @property(Label)
    public cashLable: Label = null;
    @property(Node)
    public btn_add_cash: Node = null;
    @property(Node)
    public bonusTitleNode: Node = null;
    @property(Label)
    public bonusLable: Label = null;
    @property(Node)
    public self_chipTitleNode: Node = null;
    @property(Label)
    public self_chipLable: Label = null;
    @property(Node)
    public other_chip_title: Node = null;
    @property(Label)
    public other_chip: Label = null;
    @property(Node)
    public btn_add_chip: Node = null;
    @property(Node)
    public add_bg_1: Node = null;
    @property(Node)
    public add_bg_2: Node = null;
    @property(Node)
    public infoSwitchNode: Node = null;
    @property([Node])
    public infoSwitchTabs: Node[] = [];
    @property(Node)
    public gifts_tab: Node = null;
    @property(Node)
    public card_info: Node = null;
    @property(Node)
    public card_nodata: Node = null;
    @property(Node)
    public disLayout: Node = null;
    @property(Node)
    public pickLayout: Node = null;
    @property(Node)
    public panel_face: Node = null;
    @property(Node)
    public gift_scroll: Node = null;
    @property(Node)
    public his_tab: Node = null;
    @property(Node)
    public recordItem: Node = null;
    @property(Node)
    public his_nodata: Node = null;
    @property(Node)
    public his_scroll: Node = null;
    @property(Prefab)
    public cardPrefab: Prefab = null;
    @property(Node)
    public ticket_moban: Node = null;
    @property(SpriteAtlas)
    public clubKuangAtlas: SpriteAtlas = null;
    @property(SpriteAtlas)
    public cmomonIconAtlas: SpriteAtlas = null;
    @property([SpriteFrame])
    public rticketIcon_imgs: SpriteFrame[] = [];
    @property([SpriteFrame])
    public phyIconImages: SpriteFrame[] = [];
    public cb_face: any = null;
    public cb_text: any = null;
    public cb_his_cards_info: any = null;
    public cb_notify_user_info_status: any = null;
    public target_seatid: number = 0;
    public seat_id: number = 0;
    public _showPos: any = v3(0, 0, 0);
    public _rewardNames: any[] = ["reward_watch.png"];
    public _chatFaceCount: number = 13;
    public magicexpressioncost: number = 0;
    public bIsInPrivateRoom: boolean = false;
    public bIsPracticeRoom: boolean = false;
    public bIsMatchRoom: boolean = false;
    public bIsSend: boolean = false;
    public cur_uid: any = null;
    public _switchType: number = 1;
    public _his_list: any[] = [];
    public _is_drop: boolean = false;
    public _dis_list: any[] = [];
    public _pick_list: any[] = [];
    public _card_info_offset: number = 7;
    public _record_win_color: any = color(0, 140, 22);
    public _record_fail_color: any = color(215, 60, 69);
    onLoad() {
        this.bIsSend = false;
        this.fitScreen();
        this.bIsInGame = true;
        this._chatFaceCount = this.face_imgs.length;
        PushCenter.shared().addListener(GameConfig.Close_Magic_View, (e => {
            ToolUtils.isObjValid(this.node) && Number(e) >= 0 && e === this.target_seatid && ToolUtils.isObjValid(this.node) && this.node.destroy();
        }), this);
        PushCenter.shared().addListener(GameConfig.Update_Bonus, (e => {
            ToolUtils.isObjValid(this.node) && this.updateSelfMoney();
        }), this);
        PushCenter.shared().addListener(GameConfig.Update_Money, (e => {
            ToolUtils.isObjValid(this.node) && this.updateSelfMoney();
        }), this);
        PushCenter.shared().addListener(GameConfig.Update_Deposit, (e => {
            ToolUtils.isObjValid(this.node) && this.updateSelfMoney();
        }), this);
        PushCenter.shared().addListener(PushEvent.UpdateMagicHisView, (e => {
            if (ToolUtils.isObjValid(this.node) && sys.isObjectValid(e.id) && e.id && sys.isObjectValid(e.arr) && e.arr && Array.isArray(e.arr)) {
                if (this.cur_uid != e.id) {
                    return;
                }
                this._his_list = e.arr || [];
                this.updateHisScroll();
            }
        }), this);
        PushCenter.shared().addListener(PushEvent.UpdateMagicGiftsCardView, (e => {
            if (ToolUtils.isObjValid(this.node) && sys.isObjectValid(e) && sys.isObjectValid(e.players) && sys.isObjectValid(e.tid) && this.tid_key) {
                let t = e.players || [], i = e.tid || 0;
                if (this.seat_id >= 0 && t && Array.isArray(t) && i && this.tid_key == i) {
                    for (let e = 0; e < t.length; e++) {
                        if (t[e].seatid == this.seat_id) {
                            sys.isObjectValid(t[e].is_drop) && (1 == t[e].is_drop ? this._is_drop = true : (sys.isObjectValid(t[e].discards) && t[e].discards && Array.isArray(t[e].discards) && (this._dis_list = t[e].discards.slice().reverse(), this._is_drop = false), sys.isObjectValid(t[e].pick_cards) && t[e].pick_cards && Array.isArray(t[e].pick_cards) && (this._pick_list = t[e].pick_cards.slice().reverse(), this._is_drop = false)));
                            this.updateCardInfo();
                            break;
                        }
                    }
                }
            }
        }), this);
    }
    onDestroy() {
        this.seat_id >= 0 && this.cb_notify_user_info_status(this.seat_id, 0);
        super.onDestroy();
        PushCenter.shared().removeListenersByTag(this);
        this.unscheduleAllCallbacks();
    }
    fitScreen() {
        ToolUtils.showFullScreen(this.node.getChildByName("bg"));
    }
    start() {
        super.start();
        this.initCostView();
        this.startShowAnim(this.rootNode);
        let e = new Vec3;
        this.bgNode.getPosition(e);
        TweenTool.moveSpriteByFade(this.bgNode, 0.1, e, 0, 1, true);
        this.preUpdateCardInfo();
        this.seat_id >= 0 && this.cb_notify_user_info_status(this.seat_id, 1);
        this.checkReqHisGameRecord();
    }
    preUpdateCardInfo() {
        if (!this.tid_key) {
            return;
        }
        let e = RummyDataManager.shared().rummyInfos.get(this.tid_key);
        if (!e) {
            return;
        }
        let t = e.his_card_players;
        if (sys.isObjectValid(t) && t && Array.isArray(t)) {
            for (let e = 0, i = t.length; e < i; e++) {
                if (t[e].seatid == this.seat_id) {
                    sys.isObjectValid(t[e].is_drop) && (1 == t[e].is_drop ? this._is_drop = true : (sys.isObjectValid(t[e].discards) && t[e].discards && Array.isArray(t[e].discards) && (this._dis_list = t[e].discards.slice().reverse(), this._is_drop = false), sys.isObjectValid(t[e].pick_cards) && t[e].pick_cards && Array.isArray(t[e].pick_cards) && (this._pick_list = t[e].pick_cards.slice().reverse(), this._is_drop = false)));
                    this.updateCardInfo();
                    break;
                }
            }
        }
    }
    initCostView() {
        this.faceModelNode.active = false;
        let e = this.gift_scroll.getComponent(ScrollView).content;
        e.destroyAllChildren();
        for (let t = 0, i = this._chatFaceCount; t < i; t++) {
            let i = instantiate(this.faceModelNode);
            i.getChildByName("magic").getComponent(Sprite).spriteFrame = this.face_imgs[t];
            i.getChildByName("cashAmtNode").active = !this.bIsPracticeRoom;
            i.getChildByName("chipAmtNode").active = this.bIsPracticeRoom;
            this.bIsPracticeRoom ? i.getChildByName("chipAmtNode").getChildByName("chipAmt").getComponent(Label).string = "" + this.magicexpressioncost || "" : i.getChildByName("cashAmtNode").getComponent(Label).string = "₹" + this.magicexpressioncost || "";
            i.getComponent(Button).clickEvents[0].customEventData = String(t);
            i.active = true;
            e.addChild(i);
        }
    }
    updateHisScroll() {
        if (2 != this._switchType) {
            return;
        }
        let e = this._his_list && Array.isArray(this._his_list) && this._his_list.length > 0;
        if (this.his_nodata.active = !e, this.his_scroll.active = e, this.recordItem.active = false, e) {
            let e = this.his_scroll.getComponent(ScrollView).content;
            e.destroyAllChildren();
            for (let t = 0, i = this._his_list.length; t < i; t++) {
                let i = instantiate(this.recordItem);
                this.initRecordItem(i, this._his_list[t]);
                e.addChild(i);
            }
        }
    }
    initRecordItem(e, t) {
        if (e && t) {
            let i = e.getChildByName("icon"), a = e.getChildByName("rule"), s = e.getChildByName("entry"), r = e.getChildByName("people_title"), n = e.getChildByName("people_lab"), o = e.getChildByName("time"), h = e.getChildByName("result"), d = h.getChildByName("result_value"), u = h.getChildByName("physical"), _ = h.getChildByName("ticket_layout"), b = u.getChildByName("ic"), m = u.getChildByName("name"), f = "", y = 0, C = 0, w = 0, v = 0, I = "", S = "", k = [], L = false, z = 0 == t.is_win ? this._record_fail_color : this._record_win_color;
            if (sys.isObjectValid(t.reward_detail) && t.reward_detail && Array.isArray(t.reward_detail)) {
                let e = t.reward_detail.length;
                for (let i = 0; i < e; i++) {
                    let e = t.reward_detail[i];
                    if (sys.isObjectValid(e.type) && e.type) {
                        switch (e.type) {
                            case RoomRewardType.CASH:
                                sys.isObjectValid(e.value) && e.value && (w += e.value);
                                break;
                            case RoomRewardType.BONUS:
                                sys.isObjectValid(e.value) && e.value && (v += e.value);
                                break;
                            case RoomRewardType.TICKET:
                                sys.isObjectValid(e.value) && e.value && (C += e.value, k.push(e.discount));
                                break;
                            case RoomRewardType.PHYSICAL: sys.isObjectValid(e.item_num) && e.item_num && (y += e.item), sys.isObjectValid(e.item_name) && e.item_name && (I = e.item_name || ""), sys.isObjectValid(e.item_url) && e.item_url && (S = e.item_url || "");
                        }
                    }
                }
            }
            else {
                L = true;
            }
            if (sys.isObjectValid(t.lobby_type) && t.lobby_type && Number(t.lobby_type) > 0 && (i.getComponent(Sprite).spriteFrame = this.recordIcon_imgs[Number(t.lobby_type - 1)]), sys.isObjectValid(t.name) && t.name && (a.getComponent(Label).string = t.name || ""), sys.isObjectValid(t.game) && t.game && sys.isObjectValid(t.value)) {
                let e = 1 == t.game ? "Value: " : "Entry: ";
                4 == t.game && 0 == Number(t.value) ? s.getComponent(Label).string = e + "Free" : s.getComponent(Label).string = e + ToolUtils.parse_double(t.value, -1);
            }
            if (sys.isObjectValid(t.player_count_text) && t.player_count_text && ToolUtils.isSafeString(t.player_count_text).length > 0 ? (r.active = n.active = true, n.getComponent(Label).string = t.player_count_text || "") : r.active = n.active = false, sys.isObjectValid(t.date) && t.date && (o.getComponent(Label).string = this.formatTimestampToDayMonth(t.date) || ""), sys.isObjectValid(t.is_win) && (d.getComponent(Label).color = m.getComponent(Label).color = z), L) {
                sys.isObjectValid(t.win) && t.win ? (d.active = true, u.active = _.active = false, d.getComponent(Label).color = z, f = (0 == t.is_win ? "-" : "+") + ToolUtils.parse_double(t.win, -1), d.getComponent(Label).string = f || "") : 4 == t.game && (d.active = true, u.active = _.active = false, d.getComponent(Label).string = "0");
            }
            else if (y <= 0) {
                _.active = C > 0;
                d.active = w > 0 || v > 0;
                w <= 0 && v ? f = "₹" + ToolUtils.parse_double(v + "", -1) : w && v ? f = "₹" + ToolUtils.parse_double(w + v + "", -1) + "*" : w && (f = "₹" + ToolUtils.parse_double(w + "", -1));
                sys.isObjectValid(t.is_win) && (f = (0 == t.is_win ? "-" : "+") + f);
                4 == t.game ? (d.active = true, d.getComponent(Label).string = f.length > 1 ? f : "0") : d.getComponent(Label).string = f || "";
                C && sys.isObjectValid(t.is_win) && this.updateTicketLayout(_, k, t.is_win);
            }
            else if (u.active = true, d.active = _.active = false, S && I) {
                let e = ToolUtils.isSafeString(S), t = ToolUtils.getImageUrlPictureName(e);
                ToolUtils.isSafeString(t).length > 0 && (t != this._rewardNames[0] ? (b.getComponent(Sprite).spriteFrame = this.phyIconImages[4], Utils.shared().updateNetImage(b, e, size(134, 134), (() => {
                }))) : b.getComponent(Sprite).spriteFrame = this.phyIconImages[3]);
                m.getComponent(Label).string = I || "";
            }
            e.active = true;
        }
    }
    updateTicketLayout(e, t, i) {
        if (this.ticket_moban.active = false, sys.isObjectValid(e) && sys.isObjectValid(t) && e && t && Array.isArray(t)) {
            e.destroyAllChildren();
            let a = t || [];
            for (let t = 0, s = a.length; t < s; t++) {
                let s = instantiate(this.ticket_moban), r = s.getChildByName("ic"), n = s.getChildByName("dis");
                if (a[t] > 0) {
                    let o = a[t] >= 100 ? 1 : 0, h = 0 == i ? this._record_fail_color : this._record_win_color;
                    n.getComponent(Label).color = h;
                    r.getComponent(Sprite).spriteFrame = this.rticketIcon_imgs[o];
                    n.getComponent(Label).string = ToolUtils.parse_double(a[t] + "", -1) + "%OFF" || "";
                    s.active = true;
                    e.addChild(s);
                }
            }
        }
    }
    updateCardInfo() {
        if (1 !== this._switchType) {
            return;
        }
        let e = this.checkIsNoCardInfo();
        this.card_nodata.active = e;
        this.updateDisLayoutView();
        this.updatePickLayoutView();
    }
    updateDisLayoutView() {
        let e = this.checkIsNoCardInfo(), t = size(), i = this.disLayout.getChildByName("card_node"), a = this.disLayout.getChildByName("flag"), s = a.getComponent(UITransform).contentSize.height;
        if (i.destroyAllChildren(), e) {
            this.disLayout.active = false;
        }
        else {
            if (this._is_drop) {
                this.disLayout.active = true;
                a.active = false;
                for (let e = 0; e < 13; e++) {
                    let e = instantiate(this.cardPrefab);
                    e.getComponent("RummyCard").init(1, true);
                    e.setScale(RummyCardConstant.DrawCardScaleMax);
                    i.addChild(e);
                }
                return i.getComponent(Layout).updateLayout(), t = size(i.getComponent(UITransform).contentSize.width + 2 * this._card_info_offset, s), void this.disLayout.getComponent(UITransform).setContentSize(t);
            }
            if (this._dis_list.length > 0 && this.tid_key) {
                this.disLayout.active = a.active = true;
                for (let e of this._dis_list) {
                    let t = instantiate(this.cardPrefab), a = t.getComponent("RummyCard");
                    a.init(e);
                    a.showLaiziFlag(RummyDataManager.shared().isShowLaiziColor(e, this.tid_key));
                    t.setScale(RummyCardConstant.DrawCardScaleMax);
                    i.addChild(t);
                }
                i.getComponent(Layout).updateLayout();
                t = size(i.getComponent(UITransform).contentSize.width + 2 * this._card_info_offset, s);
                this.disLayout.getComponent(UITransform).setContentSize(t);
                a.getComponent(UITransform).setContentSize(t);
            }
            else {
                this.disLayout.active = false;
            }
        }
    }
    updatePickLayoutView() {
        if (1 !== this._switchType) {
            return;
        }
        let e = size(), t = this.pickLayout.getChildByName("card_node"), i = this.pickLayout.getChildByName("flag"), a = i.getComponent(UITransform).contentSize.height;
        if (t.destroyAllChildren(), this.checkIsNoCardInfo() || this._is_drop || !Array.isArray(this._pick_list) || 0 === this._pick_list.length) {
            this.pickLayout.active = false;
        }
        else {
            this.pickLayout.active = i.active = true;
            for (let e of this._pick_list) {
                let i = instantiate(this.cardPrefab), a = i.getComponent("RummyCard");
                a.init(e);
                a.showLaiziFlag(RummyDataManager.shared().isShowLaiziColor(e, this.tid_key));
                i.setScale(RummyCardConstant.DrawCardScaleMax);
                t.addChild(i);
            }
            t.getComponent(Layout).updateLayout();
            e = size(t.getComponent(UITransform).contentSize.width + 2 * this._card_info_offset, a);
            this.pickLayout.getComponent(UITransform).setContentSize(e);
            i.getComponent(UITransform).setContentSize(e);
        }
    }
    checkIsNoCardInfo() {
        return !this._is_drop && !this._dis_list.length && !this._pick_list.length;
    }
    setIsInPrivateRoom(e) {
        this.bIsInPrivateRoom = e;
    }
    setIsPracticeRoom(e) {
        let t = this.cur_uid == User.shared().data.uid;
        this.bIsPracticeRoom = e;
        this.cashTitleNode.active = this.cashLable.node.active = !!t || !this.bIsPracticeRoom;
        this.bonusTitleNode.active = this.bonusLable.node.active = this.btn_add_cash.active = t && !this.bIsPracticeRoom;
        this.self_chipTitleNode.active = this.self_chipLable.node.active = this.btn_add_chip.active = t && this.bIsPracticeRoom;
        this.other_chip_title.active = this.other_chip.node.active = !t && this.bIsPracticeRoom;
    }
    setIsMatchRoom(e) {
    }
    updateSelfMoney() {
        if (this.cur_uid == User.shared().data.uid) {
            let e = User.shared().data.money;
            if (this.cashLable.getComponent(Label).string = ToolUtils.parse_double(e + ""), this.bIsPracticeRoom) {
                let e = User.shared().data.money_exe;
                this.self_chipLable.getComponent(Label).string = ToolUtils.parse_double(e + "") || "";
            }
            else {
                let e = User.shared().data.bonus;
                this.bonusLable.getComponent(Label).string = ToolUtils.parse_double(e + "");
            }
        }
    }
    updatePlayerInfo(e) {
        let t = e.pmodel, i = e.money, a = t.avatar, s = t.avatar_url, r = (t.club_level, t.vip || 0);
        this.cur_uid = t.uid;
        let n = t.name, o = this.cur_uid == User.shared().data.uid;
        this.playeInfoNode.setPosition(v3(0, o ? 0 : -10, 0));
        this.add_bg_1.active = true;
        this.add_bg_2.active = o;
        this.vip.active = r > 0;
        this.clubKuang.active = this.club.active = false;
        this.cashTitleNode.active = this.cashLable.node.active = !!o || !this.bIsPracticeRoom;
        this.bonusTitleNode.active = this.bonusLable.node.active = this.btn_add_cash.active = o && !this.bIsPracticeRoom;
        this.self_chipTitleNode.active = this.self_chipLable.node.active = this.btn_add_chip.active = o && this.bIsPracticeRoom;
        this.other_chip_title.active = this.other_chip.node.active = !o && this.bIsPracticeRoom;
        i <= 0 && (i = 0);
        this.nameLable.string = ToolUtils.GetShortName2(n, 12, true);
        let l = ToolUtils.isSafeNumber(t.avatar_frame_id);
        if (a && a.length > 0 && Utils.shared().updateHeadImg(this.headSp.node, a, s, size(118, 118)), sys.isObjectValid(User.shared().data.club) && 1 == User.shared().data.club.show_room_avatar_frame) {
            let e = l;
            this.clubKuang.active = this.club.active = e > 0;
            e > 0 && e <= 9 && (Utils.shared().setImage(this.clubKuang, ToolUtils.format("club_headkuang${0}", e), this.clubKuangAtlas), Utils.shared().setImage(this.club, ToolUtils.format("club_${0}", e), this.cmomonIconAtlas));
        }
        if (r > 0 && Utils.shared().setImage(this.vip, ToolUtils.format("vip_${0}", r), this.cmomonIconAtlas), o) {
            let e = User.shared().data.money;
            if (this.cashLable.getComponent(Label).string = ToolUtils.parse_double(e + ""), this.bIsPracticeRoom) {
                let e = User.shared().data.money_exe;
                this.self_chipLable.getComponent(Label).string = ToolUtils.parse_double(e + "") || "";
            }
            else {
                let e = User.shared().data.bonus;
                this.bonusLable.getComponent(Label).string = ToolUtils.parse_double(e + "");
            }
        }
        else {
            this.bIsPracticeRoom ? this.other_chip.getComponent(Label).string = ToolUtils.parse_double(i + "") : this.cashLable.getComponent(Label).string = ToolUtils.parse_double(i + "");
        }
        this.updateInfoSwitchUI(this._switchType);
    }
    setFaceCallback(e) {
        this.cb_face = e;
    }
    setHisCardsInfoReqCb(e) {
        this.cb_his_cards_info = e;
    }
    setNotifyUserInfoStatus(e, t) {
        this.cb_notify_user_info_status = e;
        this.seat_id = t;
    }
    setTargetClientId(e) {
        this.target_seatid = e;
    }
    infoSwitchClick(e, t) {
        SoundManager.shared().playFx("click");
        "1" != t && "2" != t || 1 == this._switchType && "1" == t || 2 == this._switchType && "2" == t || this.updateInfoSwitchUI(Number(t));
    }
    updateInfoSwitchUI(e) {
        if (1 != e && 2 != e) {
            return;
        }
        this.infoSwitchNode.getChildByName("lin1").active = false;
        let t = color(255, 248, 226, 255), i = color(196, 209, 243, 255);
        for (let a = 0, s = this.infoSwitchTabs.length; a < s; a++) {
            let s = this.infoSwitchTabs[a], r = s.getChildByName("wz"), n = s.getChildByName("line"), o = s.getChildByName("di");
            if (a == e - 1) {
                if (s.getComponent(Button).interactable = false, r.getComponent(Label).color = color(183, 0, 0, 255), r.getComponent(LabelShadow).color = t, n.active = true, this._switchType != e) {
                    n.scale = v3(0, 1, 1);
                    let e = TweenTool.scaleTo(n, 0.16, v3(1.1, 1, 1), null, false), t = TweenTool.scaleTo(n, 0.16, v3(1, 1, 1), null, false);
                    TweenTool.sequence(n, true, null, e, t);
                }
                else {
                    n.scale = v3(1, 1, 1);
                }
                o.active = false;
            }
            else {
                s.getComponent(Button).interactable = true;
                r.getComponent(Label).color = color(84, 89, 155, 255);
                r.getComponent(LabelShadow).color = i;
                n.scale = v3(1, 1, 1);
                a == this._switchType - 1 ? TweenTool.scaleTo(n, 0.1, v3(0.2, 1, 1), null, true, (() => {
                    n.scale = v3(1, 1, 1);
                    n.active = false;
                })) : n.active = false;
                o.active = true;
            }
        }
        this._switchType = e;
        this.gifts_tab.active = this.panel_face.active = 1 == this._switchType;
        this.his_tab.active = 2 == this._switchType;
        1 == this._switchType ? this.cb_his_cards_info() : 2 == this._switchType && this.checkReqHisGameRecord();
    }
    onClickByFace(e, t) {
        this.bIsSend || (this.bIsSend = true, SoundManager.shared().playFx("click"), this.cb_face(t, this.target_seatid), this.bIsInPrivateRoom ? this.scheduleOnce((() => {
            this.bIsSend = false;
        }), 0.7) : ToolUtils.isObjValid(this.node) && this.node.destroy());
    }
    onClickClose(e, t) {
        SoundManager.shared().playFx("click");
        ToolUtils.isObjValid(this.node) && this.node.destroy();
    }
    onClickAdd(e, t) {
        if (SoundManager.shared().playFx("click"), this.cur_uid == User.shared().data.uid) {
            let e = RummyDataManager.shared().rummyInfos.get(this.tid_key);
            if (!e || !e.vid || !User.shared().curTid_key) {
                return;
            }
            if ("cash" == t) {
                Utils.shared().showQuickRecharge(e.vid, null, true, "", 0, e.entry_fee, false, 0, 0, 0, 1);
                User.shared().updatePayScene(PhpReportDefined.pay_scene.game_prop_less_money, Number(e.vid));
            }
            else if ("chip" == t) {
                if (!e.entry_fee) {
                    return;
                }
                let t = { vid: e.vid, isShowTip: true, parent_node: director.getScene().getChildByName("Canvas"), bShowNetTip: true, tid_key: User.shared().curTid_key, min_entry: e.entry_fee, in_room: 1, is_pop: 1 };
                Utils.shared().showQuickChipRecharge(t);
            }
        }
    }
    setLandscapeShow() {
        ToolUtils.getOrientation() || this.node.setRotationFromEuler(v3(0, 0, -90));
    }
    setTidKey(e) {
        this.tid_key = e;
    }
    checkReqHisGameRecord() {
        var e;
        let t = User.shared(), i = Number(this.cur_uid), a = true, s = this.cur_uid == User.shared().data.uid;
        if (null != (e = t.hisGameRecord) && e.has(i) && !s) {
            let e = t.hisGameRecord.get(i), s = t.histroyCardGameCd, r = sys.now() / 1000;
            e && "number" == typeof e.req_time && Array.isArray(e.record_arr) && "number" == typeof s && r - e.req_time <= s && (a = false, this._his_list = e.record_arr, this.updateHisScroll());
        }
        a && this.cur_uid && t.requestHisGameRecord(this.cur_uid);
    }
    checkIsDroped() {
        let e = -2, t = RummyDataManager.shared().rummyInfos.get(this.tid_key).playerModels;
        for (let i = 0; i < t.length; i++) {
            if (this.cur_uid && t[i].isShow && t[i].uid == this.cur_uid) {
                e = t[i].state;
                break;
            }
        }
        return e == RUMMY_PLAYER_STATE_TYPE.DROPPED || e == RUMMY_PLAYER_STATE_TYPE.MIDDLEDROP;
    }
    formatTimestampToDayMonth(e) {
        let t = new Date(1000 * e), i = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"][t.getMonth()];
        return `${t.getDate().toString()} ${i}`;
    }
}
