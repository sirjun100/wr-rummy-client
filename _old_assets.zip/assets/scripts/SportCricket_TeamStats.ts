// @ts-nocheck
// Recovered from index.js:595
import { _decorator, color, Label, Node, Sprite, sys, UITransform, view } from "cc";
import SoundManager from "./SoundManager";
import PushCenter from "./PushCenter";
import { TLog } from "./TLog";
import Utils from "./Utils";
import User from "./User";
import i18nMgr from "./i18nMgr";
import BaseLayer from "./BaseLayer";
import GameConfig from "./GameConfig";
import PushEvent from "./PushEvent";
import TweenTool from "./TweenTool";
import { ToolUtils } from "./ToolUtils";
import { SportCricket_TeamStatsCmp } from "./SportCricket_TeamStatsCmp";
const { ccclass, property } = _decorator;
@ccclass("SportCricket_TeamStats")
export class SportCricket_TeamStats extends BaseLayer {
    public TAG: string = "SportCricket_TeamStats";
    @property(Node)
    public rootNode: Node = null;
    @property(Node)
    public goldNode: Node = null;
    @property(Node)
    public statRoot: Node = null;
    public _closed: boolean = false;
    public bShowPushAnim: boolean = true;
    public _lastClick: number = 0;
    public _isSendMsg: boolean = false;
    public _match_id: number = 0;
    public _source: any = null;
    public lastClick: number = 0;
    public _fromType: number = 0;
    public _match_state: number = 1;
    public _team_source: any = null;
    public _lastNode: any = null;
    public _call: any = null;
    onLoad() {
        PushCenter.shared().addListener(GameConfig.Update_Money, (t => {
            try {
                ToolUtils.isObjValid(this.node) && this.updateGold(t);
            }
            catch (t) {
                TLog.printError(this.TAG, GameConfig.Update_Money, t);
            }
        }), this);
        this.fitLuckyTheme();
    }
    fitLuckyTheme() {
        0 != GameConfig.NATIVE_GAME_APP_TYPE && (this.rootNode.getChildByName("top_node").getChildByName("top_bg").getComponent(Sprite).color = color(12, 26, 60, 255), this.goldNode.getChildByName("coin").getComponent(Label).color = color(251, 220, 0, 255));
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().removeListenersByTag(this);
        this.unscheduleAllCallbacks();
    }
    init(t) {
        sys.isObjectValid(t) && sys.isObjectValid(t.match_id) && (this._match_id = t.match_id);
        sys.isObjectValid(t) && sys.isObjectValid(t.source) && (this._source = { ...t.source });
        sys.isObjectValid(t) && sys.isObjectValid(t.team_source) && (this._team_source = t.team_source);
        sys.isObjectValid(t) && sys.isObjectValid(t.fromType) && (this._fromType = t.fromType);
        sys.isObjectValid(t) && sys.isObjectValid(t.call) && (this._call = t.call);
        sys.isObjectValid(t) && sys.isObjectValid(t.lastNode) && (this._lastNode = t.lastNode);
    }
    start() {
        super.start();
        this.initView();
        this.bShowPushAnim && ToolUtils.showPushAnim(this.node, 0, (() => {
            this.refreshView();
            sys.isObjectValid(this._lastNode) && (this._lastNode.active = false);
        }));
        this.updateGold(User.shared().data.money);
    }
    updateGold(t) {
        let e = this.goldNode.getChildByName("coin");
        null != t && e && (e.getComponent(Label).string = ToolUtils.parse_double(t));
    }
    refreshView() {
        let t = this.statRoot.getChildByName("teamstat");
        if (ToolUtils.isObjValid(t)) {
            let e = { team_source: this._team_source, match_id: this._match_id, lastNode: this.node, fromType: this._fromType, source: this._source };
            t.getComponent(SportCricket_TeamStatsCmp).init(e);
            t.getComponent(SportCricket_TeamStatsCmp).refreshView();
        }
    }
    onCloseButtonClick(t, e) {
        if (SoundManager.shared().playFx("click"), "back_btn" == e) {
            if (this._closed) {
                return;
            }
            this.onBackView();
        }
    }
    initView() {
        if (this.fitScreen(), sys.isObjectValid(this._source)) {
            let t = this.rootNode.getChildByName("top_node").getChildByName("lefttime");
            t.getComponent(Label).string = Utils.shared().parseCountDown(this._source.time_left);
            sys.isObjectValid(this._source.status) && (this._match_state = this._source.status);
            0 == this._source.time_left && 1 == this._source.status ? (t.getComponent(Label).string = this._source.start_day, sys.isObjectValid(this._source.is_current_day) && 1 == Number(this._source.is_current_day) && (this._source.status = 3, t.getComponent(Label).string = "Live")) : 1 == this._source.status ? TweenTool.myschedule(t, 1, (() => {
                ToolUtils.isObjValid(this.node) && (this._source.time_left > 0 ? t.getComponent(Label).string = Utils.shared().parseCountDown(this._source.time_left) : (this._source.status = 3, t.getComponent(Label).string = "Live", TweenTool.stopNodeAction(t)));
            })) : 3 == this._source.status ? (TweenTool.stopNodeAction(t), t.getComponent(Label).string = "Live") : 4 == this._source.status && (TweenTool.stopNodeAction(t), t.getComponent(Label).string = "Cancel");
            PushCenter.shared().addListener(PushEvent.UpdateYes11CurMatchLeftTime, (e => {
                try {
                    ToolUtils.isObjValid(this.node) && e.match_id == this._match_id && (this._source.time_left = e.time_left, this._source.is_current_day = e.is_current_day, this._match_state = e.status, 3 == e.status ? (TweenTool.stopNodeAction(t), t.getComponent(Label).string = "Live") : 4 == e.status && (TweenTool.stopNodeAction(t), t.getComponent(Label).string = "Cancel"));
                }
                catch (t) {
                    TLog.printError(this.TAG, PushEvent.UpdateYes11CurMatchLeftTime, t);
                }
            }), this);
        }
    }
    onButtonClick(t, e) {
        SoundManager.shared().playFx("click");
        sys.now() - this._lastClick < 500 || (this._lastClick = sys.now(), 3 != this._match_state ? 4 != this._match_state ? "add_chip" == e && Utils.shared().showStoreView(null, null) : Utils.shared().showToast(i18nMgr.shared().getValueByKey("yes11.cancel_tip"), 2) : Utils.shared().showToast(i18nMgr.shared().getValueByKey("yes11.live_tip"), 2));
    }
    onBackView(t = true) {
        t && (Utils.shared().hideLoading(), this.bShowPushAnim ? (this._closed = true, ToolUtils.isObjValid(this._lastNode) && (this._lastNode.active = true), ToolUtils.showPushAnim(this.node, 1, (() => {
            ToolUtils.isObjValid(this.node) && this.node.destroy();
        }))) : (ToolUtils.isObjValid(this._lastNode) && (this._lastNode.active = true), ToolUtils.isObjValid(this.node) && this.node.destroy()));
    }
    fitScreen() {
        ToolUtils.adaptSafeArea(this.rootNode);
        sys.getSafeAreaRect().y;
        let t = view.getVisibleSize();
        this.node.getComponent(UITransform).setContentSize(t.width, t.height);
    }
}
