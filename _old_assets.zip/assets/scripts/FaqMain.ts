// @ts-nocheck
// Recovered from index.js:119
import { _decorator, Label, Node, ScrollView, sys } from "cc";
import SoundManager from "./SoundManager";
import PushCenter from "./PushCenter";
import Utils from "./Utils";
import BaseLayer from "./BaseLayer";
import { ToolUtils } from "./ToolUtils";
import GameConfig from "./GameConfig";
import CommDefine from "./CommDefine";
const { ccclass, property } = _decorator;
@ccclass("FaqMain")
export class FaqMain extends BaseLayer {
    public TAG: string = "FaqMain";
    @property(Node)
    public rootNode: Node = null;
    @property(ScrollView)
    public scrollView: ScrollView = null;
    public _closed: boolean = false;
    public bShowPushAnim: boolean = true;
    public _lastClick: number = 0;
    onLoad() {
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().removeListenersByTag(this);
        this.unscheduleAllCallbacks();
    }
    init(e) {
    }
    start() {
        ToolUtils.showFullScreen(this.node.getChildByName("mask"));
        super.start();
        this.initView();
        this.startShowAnim(this.rootNode);
    }
    onCloseButtonClick(e, t) {
        if (SoundManager.shared().playFx("click"), "back_btn" == t) {
            if (this._closed) {
                return;
            }
            this.onBackView();
        }
    }
    initView() {
        this.fitScreen();
        this.fitGameName();
    }
    fitGameName() {
        let e = 0 == GameConfig.GAME_APP_THEME ? CommDefine.AppName_rummy : CommDefine.AppName_circ, t = "Master Rummy";
        for (let i = 0; i <= 8; i++) {
            let n = this.scrollView.content.getChildByName("title" + i).getComponent(Label).string;
            -1 != n.indexOf(CommDefine.AppName_rummy) && 1 == GameConfig.GAME_APP_THEME ? (n = n.replace(new RegExp(CommDefine.AppName_rummy, "g"), e), this.scrollView.content.getChildByName("title" + i).getComponent(Label).string = n) : 1 == GameConfig.NATIVE_GAME_APP_TYPE && -1 != n.indexOf(t) && (n = n.replace(new RegExp(t, "g"), e), this.scrollView.content.getChildByName("title" + i).getComponent(Label).string = n);
            n = this.scrollView.content.getChildByName("wz" + i).getComponent(Label).string;
            -1 != n.indexOf(CommDefine.AppName_rummy) && 1 == GameConfig.GAME_APP_THEME ? (n = n.replace(new RegExp(CommDefine.AppName_rummy, "g"), e), this.scrollView.content.getChildByName("wz" + i).getComponent(Label).string = n) : 1 == GameConfig.NATIVE_GAME_APP_TYPE && -1 != n.indexOf(t) && (n = n.replace(new RegExp(t, "g"), e), this.scrollView.content.getChildByName("wz" + i).getComponent(Label).string = n);
        }
    }
    onButtonClick(e, t) {
        SoundManager.shared().playFx("click");
        sys.now() - this._lastClick < 500 || (this._lastClick = sys.now(), "chat_us" == t && Utils.shared().showContactUsView());
    }
    onBackView(e = true) {
        e && (Utils.shared().hideLoading(), ToolUtils.isObjValid(this.node) && this.node.destroy());
    }
    fitScreen() {
        ToolUtils.adaptSafeArea(this.rootNode);
        sys.getSafeAreaRect().y;
    }
}
