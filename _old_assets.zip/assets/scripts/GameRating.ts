// @ts-nocheck
// Recovered from index.js:157
import { _decorator, Label, LabelShadow, Node, size, Sprite, SpriteFrame, sys, UITransform, Vec3 } from "cc";
import Utils from "./Utils";
import SoundManager from "./SoundManager";
import User from "./User";
import PushEvent from "./PushEvent";
import BaseLayer from "./BaseLayer";
import HttpManager from "./HttpManager";
import { TransferPlatform } from "./TransferPlatform";
import PushCenter from "./PushCenter";
import CommDefine from "./CommDefine";
import i18nMgr from "./i18nMgr";
import { HttpRequest } from "./HttpRequestName";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("GameRating")
export class GameRating extends BaseLayer {
    @property(Node)
    public rootNode: Node = null;
    @property(Node)
    public maskNode: Node = null;
    @property([SpriteFrame])
    public starSpriteFrames: SpriteFrame[] = [];
    @property(Node)
    public ratingRootNode: Node = null;
    @property(Node)
    public skipRootNode: Node = null;
    @property([SpriteFrame])
    public okBtnSpriteFrames: SpriteFrame[] = [];
    @property(Node)
    public okBtnNode: Node = null;
    @property(Node)
    public diNode: Node = null;
    public turningAction: any = null;
    public _starItems: any[] = [];
    public _ui_type: number = 0;
    public fromType: any = -1;
    public rating_star: any = -1;
    public target_star: number = 0;
    public isNext: boolean = false;
    public share_text: string = "Bonus in A23 Rummy a little less, but there are quite a lot here nice game";
    onLoad() {
    }
    requestGameRatingConfirmPop(t = null) {
        HttpManager.shared().doGetCommonRequest(t, HttpRequest.GameRatingConfirmPop, ((t, e, i) => {
        }));
    }
    start() {
        if (super.start(), ToolUtils.showFullScreen(this.maskNode), this.ratingRootNode.active = true, this.skipRootNode.active = false, User.shared().last_rating_time = sys.now() / 1000, this._ui_type = 0, 0 == this._ui_type) {
            let t = this.ratingRootNode.getChildByName("star_content");
            this._starItems = [];
            let e = "";
            for (let i = 0; i < 5; i++) {
                e = "star" + i;
                let s = t.getChildByName(e);
                s && (this._starItems[i] = s);
            }
        }
        this.updateOkBtnSprite();
        this.startShowAnim(this.rootNode, (() => {
        }));
        this.requestGameRatingConfirmPop();
    }
    initParaData(t) {
        sys.isObjectValid(t) && (sys.isObjectValid(t.target_star) && (this.target_star = t.target_star), sys.isObjectValid(t.finish_seconds) && (User.shared().gp_raing_finish_seconds = t.finish_seconds), sys.isObjectValid(t.gp_rating_lock_hour) && (User.shared().gp_rating_lock_hour = t.gp_rating_lock_hour), sys.isObjectValid(t.share_text) && (this.share_text = t.share_text), sys.isObjectValid(t.isNext) && (this.isNext = t.isNext));
    }
    updateOkBtnSprite() {
        this.rating_star > 0 ? (this.okBtnNode.getComponent(Sprite).spriteFrame = this.okBtnSpriteFrames[1], Utils.updateLabelMaterial(this.okBtnNode.getChildByName("wz"), CommDefine.gradient.btn_blue), this.okBtnNode.getChildByName("wz").getComponent(LabelShadow).color = CommDefine.shadowcolor.blue) : (this.okBtnNode.getComponent(Sprite).spriteFrame = this.okBtnSpriteFrames[0], Utils.updateLabelMaterial(this.okBtnNode.getChildByName("wz"), CommDefine.gradient.btn_gray), this.okBtnNode.getChildByName("wz").getComponent(LabelShadow).color = CommDefine.shadowcolor.gray);
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().removeListenersByTag(this);
    }
    starButtonClick(t, e) {
        SoundManager.shared().playFx("click");
        let i = Number(e);
        for (let t = 0; t < this._starItems.length; t++) {
            this._starItems[t].getComponent(Sprite).spriteFrame = t <= i ? this.starSpriteFrames[1] : this.starSpriteFrames[0];
        }
        this.rating_star = i + 1;
        this.updateOkBtnSprite();
    }
    onBackView() {
        ToolUtils.isObjValid(this.node) && (this.isNext && PushCenter.shared().pushEvent(PushEvent.Update_NextPopActivity), this.node.destroy());
    }
    onButtonClick(t, e) {
        if (SoundManager.shared().playFx("click"), "close" == e) {
            if (this.skipRootNode.active) {
                let t = { star: this.rating_star, skip_type: 1 };
                User.shared().requestGameRatingSubmitData(t);
            }
            this.onBackView();
        }
        else if ("ok" == e) {
            if (this.rating_star <= 0) {
                return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("suggestion.no_rating_tips"), 2);
            }
            if (this.rating_star < this.target_star) {
                return this.onBackView(), void Utils.shared().showTawkFeedback({ sourceType: CommDefine.TawkUser_Feedback_Source.Suggestion, star: this.rating_star });
            }
            {
                this.ratingRootNode.active = false;
                this.skipRootNode.active = true;
                let t = this.skipRootNode.getChildByName("share_txt");
                t.getComponent(Label).string = this.share_text;
                t.getComponent(Label).updateRenderData(true);
                let e = t.getComponent(UITransform).height;
                if (e >= 77) {
                    let t = e - 77;
                    this.rootNode.setPosition(new Vec3(0, t / 2));
                    this.diNode.getComponent(UITransform).setContentSize(size(672, 706 + t));
                    this.skipRootNode.getChildByName("ok_btn").setPosition(new Vec3(0, -280 - t));
                }
            }
        }
        else if ("ok2" == e) {
            TransferPlatform.shared().copyContent(this.share_text);
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text33"), 2);
            let t = { star: this.rating_star, skip_type: 1, click_jump: 1 };
            User.shared().requestGameRatingSubmitData(t);
            this.onBackView();
            User.shared().gp_raing_hasSkip = true;
            User.shared().gp_raing_skip_time = sys.now();
            TransferPlatform.shared().openGooglePlayReview();
        }
    }
}
