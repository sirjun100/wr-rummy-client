// @ts-nocheck
// Recovered from index.js:585
import { _decorator, Button, color, instantiate, Label, LabelShadow, Node, size, Sprite, SpriteFrame, sys, UITransform, v3, view } from "cc";
import SoundManager from "./SoundManager";
import PushCenter from "./PushCenter";
import { TLog } from "./TLog";
import Utils from "./Utils";
import BaseLayer from "./BaseLayer";
import i18nMgr from "./i18nMgr";
import PushEvent from "./PushEvent";
import TweenTool from "./TweenTool";
import SportCricket_Manager from "./SportCricket_Manager";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("SportCricket_SwitchTeamList")
export class SportCricket_SwitchTeamList extends BaseLayer {
    public TAG: string = "SportCricket_SwitchTeamList";
    @property(Node)
    public rootNode: Node = null;
    @property(Node)
    public nextNode: Node = null;
    @property(Node)
    public contentNode: Node = null;
    @property([SpriteFrame])
    public teamBgImgs: SpriteFrame[] = [];
    @property([SpriteFrame])
    public capBgImgs: SpriteFrame[] = [];
    @property([SpriteFrame])
    public btnBgImgs: SpriteFrame[] = [];
    @property([SpriteFrame])
    public operateImgs: SpriteFrame[] = [];
    @property([SpriteFrame])
    public checkBtnImgs: SpriteFrame[] = [];
    @property(Node)
    public team_mobanView: Node = null;
    public _closed: boolean = false;
    public _lastClick: number = 0;
    public _isSendMsg: boolean = false;
    public taskAwardIconMap: Map = new Map;
    public _match_id: number = 0;
    public _teamlistData: any = null;
    public _curTeamData: any = null;
    public _selectTeamId: number = 0;
    public _contest_id: number = 0;
    public teamMap: Map = new Map;
    public teamIdDateMap: Map = new Map;
    public _startY: number = 0;
    public _closeAct: any = null;
    public _startAct: any = null;
    public _call: any = null;
    onLoad() {
        PushCenter.shared().addListener(PushEvent.commentDownloaderImg, (t => {
            try {
                if (ToolUtils.isObjValid(this.node) && this.taskAwardIconMap.size > 0) {
                    for (const [e, i] of this.taskAwardIconMap) {
                        i == t && sys.isObjectValid(e) && Utils.shared().updateNetImage(e, t, size(88, 88));
                    }
                }
            }
            catch (t) {
                TLog.printError(this.TAG, PushEvent.commentDownloaderImg, t);
            }
        }), this);
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().removeListenersByTag(this);
        this.unscheduleAllCallbacks();
    }
    init(t) {
        sys.isObjectValid(t) && sys.isObjectValid(t.match_id) && (this._match_id = t.match_id);
        sys.isObjectValid(t) && sys.isObjectValid(t.contest_id) && (this._contest_id = t.contest_id);
        sys.isObjectValid(t) && sys.isObjectValid(t.teamlistData) && (this._teamlistData = t.teamlistData);
        sys.isObjectValid(t) && sys.isObjectValid(t.curTeam) && (this._curTeamData = t.curTeam);
        sys.isObjectValid(t) && sys.isObjectValid(t.call) && (this._call = t.call);
    }
    start() {
        super.start();
        this.initView();
        this.refreshView();
        this.showSelectView();
        TweenTool.delayAct(this.node, (() => {
            this.reSortTeamInfo();
            this.updateNextButtonStatus();
        }), 0.3, true);
    }
    showSelectView() {
        let t = -view.getVisibleSize().height / 2, e = this.rootNode.getComponent(UITransform).height;
        this._startY = t - e - 20;
        this.rootNode.setPosition(v3(0, this._startY));
        this._startAct = TweenTool.moveTo(this.rootNode, 0.2, v3(0, t), "sineIn", true);
    }
    hideSelectView() {
        this._startAct && TweenTool.stopAction(this._startAct);
        this._closeAct || (this._closeAct = TweenTool.moveTo(this.rootNode, 0.2, v3(0, this._startY), "sineIn", true, (() => {
            ToolUtils.isObjValid(this.node) && this.node.destroy();
        })));
    }
    refreshView() {
        this.updateContestDetails();
    }
    updateContestDetails() {
        sys.isObjectValid(this._teamlistData) && sys.isObjectValid(this._curTeamData) && (this.rootNode.getChildByName("title").getComponent(Label).string = ToolUtils.format(i18nMgr.shared().getValueByKey("yes11.switch_title"), this._curTeamData.short_name), this.rootNode.getChildByName("switch_info").getChildByName("cur_team").getComponent(Label).string = this._curTeamData.name);
    }
    reSortTeamInfo() {
        this.contentNode.removeAllChildren();
        this.teamMap.clear();
        sys.isObjectValid(this._teamlistData.list) && Array.isArray(this._teamlistData.list) && this._teamlistData.list.length > 0 && (this._selectTeamId = this._teamlistData.list[0].team_id, this._teamlistData.list.unshift(this._curTeamData), this.addTeamView(this.contentNode, this._teamlistData.list), this.updateItemCheckStatus(this.teamMap.get(String(this._selectTeamId)), 1), this.updateItemFlag(this.teamMap.get(String(this._selectTeamId)), 1, this._selectTeamId));
    }
    addTeamView(t, e) {
        for (let i = 0; i < e.length; i++) {
            let a = instantiate(this.team_mobanView);
            if (a.active = true, t.addChild(a), this.teamMap.set(String(e[i].team_id), a), this.teamIdDateMap.set(String(e[i].team_id), e[i]), a.getChildByName("flag").active = false, e[i].team_id == this._curTeamData.team_id && (a.getChildByName("flag").getComponent(Label).string = "Current", a.getChildByName("flag").active = true), sys.isObjectValid(e[i].name) && e[i].name.length > 0 && (a.getChildByName("name").getComponent(Label).string = e[i].name), a.getComponent(Button).clickEvents[0].customEventData = ToolUtils.toJsonString(e[i]), sys.isObjectValid(e[i].wk_num) && String(e[i].wk_num).length > 0 && (a.getChildByName("wk").getComponent(Label).string = "WK " + e[i].wk_num), sys.isObjectValid(e[i].bat_num) && String(e[i].bat_num).length > 0 && (a.getChildByName("bat").getComponent(Label).string = "BAT " + e[i].bat_num), sys.isObjectValid(e[i].ar_num) && String(e[i].ar_num).length > 0 && (a.getChildByName("ar").getComponent(Label).string = "AR " + e[i].ar_num), sys.isObjectValid(e[i].bowl_num) && String(e[i].bowl_num).length > 0 && (a.getChildByName("bowl").getComponent(Label).string = "BOWL " + e[i].bowl_num), sys.isObjectValid(e[i].teama_short_name) && String(e[i].teama_short_name).length > 0 && (a.getChildByName("team_name0").getComponent(Label).string = e[i].teama_short_name), sys.isObjectValid(e[i].teamb_short_name) && String(e[i].teamb_short_name).length > 0 && (a.getChildByName("team_name1").getComponent(Label).string = e[i].teamb_short_name), sys.isObjectValid(e[i].teama_num) && String(e[i].teama_num).length > 0 && (a.getChildByName("team_num0").getComponent(Label).string = e[i].teama_num), sys.isObjectValid(e[i].teamb_num) && String(e[i].teamb_num).length > 0 && (a.getChildByName("team_num1").getComponent(Label).string = e[i].teamb_num), sys.isObjectValid(e[i].members) && Array.isArray(e[i].members) && e[i].members.length > 0) {
                for (let t = 0; t < e[i].members.length; t++) {
                    let n = e[i].members[t];
                    1 == Number(n.captain_role) ? (a.getChildByName("cap_node0").getChildByName("wz").getComponent(Label).string = ToolUtils.GetShortName2(n.short_name, 13, false), n.out_team_id == e[i].teama_id ? (a.getChildByName("cap_node0").getChildByName("bg").getComponent(Sprite).spriteFrame = this.capBgImgs[0], a.getChildByName("cap_node0").getChildByName("wz").getComponent(Label).color = color(255, 255, 255), a.getChildByName("cap_node0").getChildByName("flag").getChildByName("wz").getComponent(Label).color = color(255, 255, 255), a.getChildByName("cap_node0").getChildByName("flag").getComponent(Sprite).spriteFrame = this.operateImgs[0]) : (a.getChildByName("cap_node0").getChildByName("bg").getComponent(Sprite).spriteFrame = this.capBgImgs[1], a.getChildByName("cap_node0").getChildByName("wz").getComponent(Label).color = color(51, 51, 51), a.getChildByName("cap_node0").getChildByName("flag").getChildByName("wz").getComponent(Label).color = color(51, 51, 51), a.getChildByName("cap_node0").getChildByName("flag").getComponent(Sprite).spriteFrame = this.operateImgs[1]), sys.isObjectValid(n.thumb_url) && n.thumb_url.length > 0 && (this.taskAwardIconMap.set(a.getChildByName("cap_node0").getChildByName("player_icon"), n.thumb_url), Utils.shared().updateNetImage(a.getChildByName("cap_node0").getChildByName("player_icon"), n.thumb_url, size(88, 88)))) : 2 == Number(n.captain_role) && (a.getChildByName("cap_node1").getChildByName("wz").getComponent(Label).string = ToolUtils.GetShortName2(n.short_name, 13, false), n.team_id == e[i].teama_id ? (a.getChildByName("cap_node1").getChildByName("bg").getComponent(Sprite).spriteFrame = this.capBgImgs[0], a.getChildByName("cap_node1").getChildByName("wz").getComponent(Label).color = color(255, 255, 255), a.getChildByName("cap_node1").getChildByName("flag").getChildByName("wz").getComponent(Label).color = color(255, 255, 255), a.getChildByName("cap_node1").getChildByName("flag").getComponent(Sprite).spriteFrame = this.operateImgs[0]) : (a.getChildByName("cap_node1").getChildByName("bg").getComponent(Sprite).spriteFrame = this.capBgImgs[1], a.getChildByName("cap_node1").getChildByName("wz").getComponent(Label).color = color(51, 51, 51), a.getChildByName("cap_node1").getChildByName("flag").getChildByName("wz").getComponent(Label).color = color(51, 51, 51), a.getChildByName("cap_node1").getChildByName("flag").getComponent(Sprite).spriteFrame = this.operateImgs[1]), sys.isObjectValid(n.thumb_url) && n.thumb_url.length > 0 && (this.taskAwardIconMap.set(a.getChildByName("cap_node1").getChildByName("player_icon"), n.thumb_url), Utils.shared().updateNetImage(a.getChildByName("cap_node1").getChildByName("player_icon"), n.thumb_url, size(88, 88))));
                }
            }
        }
    }
    updateNextButtonStatus() {
        this._selectTeamId != this._curTeamData.team_id ? (this.nextNode.getComponent(Sprite).spriteFrame = this.btnBgImgs[0], this.nextNode.getComponent(Sprite).color = color(255, 255, 255), this.nextNode.getChildByName("wz").getComponent(Label).color = color(255, 255, 255), this.nextNode.getChildByName("wz").getComponent(LabelShadow).enabled = true, this.nextNode.getChildByName("wz").getComponent(Label).string = "SWITCH", this.nextNode.getComponent(Button).interactable = true) : (this.nextNode.getComponent(Sprite).spriteFrame = this.btnBgImgs[2], this.nextNode.getComponent(Sprite).color = color(88, 115, 209), this.nextNode.getChildByName("wz").getComponent(Label).color = color(58, 115, 209), this.nextNode.getChildByName("wz").getComponent(Label).string = "SKIP", this.nextNode.getComponent(Button).interactable = true);
    }
    checkJoinTeam() {
        if (0 == this._selectTeamId || this._selectTeamId == this._curTeamData.team_id) {
            return void this.onBackView();
        }
        let t = { match_id: this._match_id, session_id: this._contest_id, replace_team_id: this._curTeamData.team_id, team_id: this._selectTeamId };
        SportCricket_Manager.shared().requestYes11_SwitchTeam(t, true, (t => {
            if (this._call) {
                let e = { session_id: this._contest_id, target_team_id: this._curTeamData.team_id, switch_teamInfo: this.teamIdDateMap.get(String(this._selectTeamId)) };
                sys.isObjectValid(t) && sys.isObjectValid(t.not_in_lineup) && (e.not_in_lineup = t.not_in_lineup);
                sys.isObjectValid(t) && sys.isObjectValid(t.fill_back_up) && (e.fill_back_up = t.fill_back_up);
                this.onBackView(true);
                this._call(e);
            }
        }));
    }
    onCloseButtonClick(t, e) {
        SoundManager.shared().playFx("click");
        sys.now() - this._lastClick < 500 || (this._lastClick = sys.now(), this.onBackView());
    }
    initView() {
        this.fitScreen();
    }
    onItemCheckClick(t, e) {
        if (SoundManager.shared().playFx("click"), sys.now() - this._lastClick < 500) {
            return;
        }
        this._lastClick = sys.now();
        let i = ToolUtils.parseJson(e).team_id;
        this._selectTeamId != i && (this.updateItemCheckStatus(this.teamMap.get(String(i)), 1), this.updateItemFlag(this.teamMap.get(String(i)), 1, i), 0 != this._selectTeamId && (this.updateItemCheckStatus(this.teamMap.get(String(this._selectTeamId)), 0), this.updateItemFlag(this.teamMap.get(String(this._selectTeamId)), 0, i)), this._selectTeamId = i);
        this.updateNextButtonStatus();
    }
    updateItemFlag(t, e, i) {
        if (sys.isObjectValid(t) && 1 == e) {
            let t = this.teamIdDateMap.get(String(i));
            sys.isObjectValid(t) && (this.rootNode.getChildByName("switch_info").getChildByName("switch_team").getComponent(Label).string = t.name);
        }
    }
    updateItemCheckStatus(t, e) {
        sys.isObjectValid(t) && (1 == e ? (t.getChildByName("check_btn").getChildByName("ico").getComponent(Sprite).spriteFrame = this.checkBtnImgs[1], t.getChildByName("check_btn").getChildByName("ico").getComponent(Sprite).color = color(255, 255, 255)) : (t.getChildByName("check_btn").getChildByName("ico").getComponent(Sprite).spriteFrame = this.checkBtnImgs[0], t.getChildByName("check_btn").getChildByName("ico").getComponent(Sprite).color = color(225, 225, 225)));
    }
    onButtonClick(t, e) {
        SoundManager.shared().playFx("click");
        sys.now() - this._lastClick < 500 || (this._lastClick = sys.now(), "join" == e && this.checkJoinTeam());
    }
    onBackView(t = true) {
        t && (Utils.shared().hideLoading(), this.hideSelectView());
    }
    fitScreen() {
        ToolUtils.adaptSafeArea(this.rootNode);
        sys.getSafeAreaRect().y;
    }
}
