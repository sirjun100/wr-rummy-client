// @ts-nocheck
// Recovered from index.js:691
import { _decorator, Label, LabelShadow, Node, Sprite, SpriteFrame, sys } from "cc";
import BaseLayer from "./BaseLayer";
import Utils from "./Utils";
import SoundManager from "./SoundManager";
import PushEvent from "./PushEvent";
import { ToolUtils } from "./ToolUtils";
import CommDefine from "./CommDefine";
const { ccclass, property } = _decorator;
@ccclass("WithdrawalStatus")
export class WithdrawalStatus extends BaseLayer {
    @property(Node)
    public bgView: Node = null;
    @property(Label)
    public withdrawIdLabel: Label = null;
    @property(Node)
    public remindBtn: Node = null;
    @property(Label)
    public amountLabel: Label = null;
    @property([SpriteFrame])
    public iconSpriteFrames: SpriteFrame[] = [];
    @property([SpriteFrame])
    public verifyBtnImgs: SpriteFrame[] = [];
    @property(Label)
    public amountTitleLabel: Label = null;
    public withdraw_id: string = "";
    public amount: string = "";
    public processArr: any[] = [];
    public amount_str: string = "";
    public show_bank_review_toast: number = 0;
    public hasClick: boolean = false;
    start() {
        super.start();
        ToolUtils.showFullScreen(this.node.getChildByName("bg"));
        ToolUtils.startShowAnim(this.node.getChildByName("rootNode"));
        this.refreshUI();
    }
    refreshUI() {
        this.withdrawIdLabel.string = this.withdraw_id;
        this.amountLabel.string = this.amount;
        let t, e = "";
        for (let i = 0; i < this.processArr.length; i++) {
            let s = this.processArr[i];
            if (e = "process" + i, t = this.bgView.getChildByName(e), t) {
                t.active = true;
                let e = ToolUtils.isSafeNumber(s.status), i = ToolUtils.isSafeString(s.desc), a = ToolUtils.isSafeString(s.time), n = t.getChildByName("icon"), o = t.getChildByName("status"), h = t.getChildByName("time");
                this.iconSpriteFrames[e] && (n.getComponent(Sprite).spriteFrame = this.iconSpriteFrames[e]);
                o.getComponent(Label).string = i;
                h.getComponent(Label).string = a;
            }
        }
        this.amount_str.length > 0 && (this.amountTitleLabel.string = this.amount_str);
        this.remindBtn.active = false;
        1 == this.show_bank_review_toast && (this.bgView.getChildByName("process2").active = false, this.remindBtn.active = true, this.hasClick ? this.updateVerifyBtnStatus(this.remindBtn, 0) : this.updateVerifyBtnStatus(this.remindBtn, 1));
    }
    initParaData(t) {
        sys.isObjectValid(t) && (sys.isObjectValid(t.id) && (this.withdraw_id = "" + t.id), sys.isObjectValid(t.amount) && (this.amount = "₹" + t.amount), sys.isObjectValid(t.process) && Array.isArray(t.process) && (this.processArr = t.process), sys.isObjectValid(t.show_bank_review) && (this.show_bank_review_toast = t.show_bank_review), sys.isObjectValid(t.amount_str) && ToolUtils.isSafeString(t.amount_str).length > 0 && (this.amount_str = t.amount_str), this.hasClick = this.checkStatehasClick());
    }
    checkStatehasClick() {
        let t = sys.localStorage.getItem(this.withdraw_id + "withstate");
        return !(!sys.isObjectValid(t) || "1" != t);
    }
    buttonClick(t, e) {
        SoundManager.shared().playFx("click");
        "close" === e ? this.onBackView() : "kefu" === e ? Utils.shared().doJumpLogic(PushEvent.JUMP_TO_FEEDBACK) : "remind" === e && (this.hasClick ? Utils.shared().showToast("Your order is in the bank queue. It’ll be processed shortly!", 2) : (sys.localStorage.setItem(this.withdraw_id + "withstate", "1"), Utils.shared().showToast("Successfully! The request has been urgently queued for bank processing", 2)), this.hasClick = true, this.updateVerifyBtnStatus(this.remindBtn, 0));
    }
    updateVerifyBtnStatus(t, e) {
        sys.isObjectValid(t) && (0 == e ? (t.getComponent(Sprite).spriteFrame = this.verifyBtnImgs[0], t.getChildByName("wz").getComponent(LabelShadow).color = CommDefine.shadowcolor.gray, Utils.updateLabelMaterial(t.getChildByName("wz"), CommDefine.gradient.btn_gray), t.getChildByName("wz").getComponent(Label).string = "SUBMITTED") : 1 == e && (t.getComponent(Sprite).spriteFrame = this.verifyBtnImgs[1], t.getChildByName("wz").getComponent(LabelShadow).color = CommDefine.shadowcolor.blue, t.getChildByName("wz").getComponent(Label).string = "REMIND", Utils.updateLabelMaterial(t.getChildByName("wz"), CommDefine.gradient.btn_blue)));
    }
    onBackView() {
        ToolUtils.isObjValid(this.node) && this.node.destroy();
    }
}
