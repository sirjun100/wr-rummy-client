// @ts-nocheck
// Recovered from index.js:367
import { _decorator, Button, director, Label, Node, ProgressBar, Slider, Sprite, SpriteFrame, sys, v3 } from "cc";
import BaseLayer from "./BaseLayer";
import SoundManager from "./SoundManager";
import Utils from "./Utils";
import PushCenter from "./PushCenter";
import TweenTool from "./TweenTool";
import { ToolUtils } from "./ToolUtils";
import User from "./User";
import i18nMgr from "./i18nMgr";
import { CheckModule, PointsType } from "./CommDefine";
import HowToPlayDefined from "./HowToPlayDefined";
import PushEvent from "./PushEvent";
import PhpReportDefined from "./PhpReportDefined";
const { ccclass, property } = _decorator;
@ccclass("RankingsOptIn")
export class RankingsOptIn extends BaseLayer {
    public TAG: string = "RankingsOptIn";
    @property(Node)
    public optInNode: Node = null;
    @property(Node)
    public optSucNode: Node = null;
    @property(Node)
    public sliderStarNode: Node = null;
    @property([SpriteFrame])
    public switchIcons: SpriteFrame[] = [];
    public _data: any = null;
    public auto_entry_status: number = 0;
    @property([SpriteFrame])
    public rankStarFrame: SpriteFrame[] = [];
    public status: number = 0;
    public gameType: number = 0;
    public rummyType: number = 0;
    public vCurRoomList: any[] = [];
    public nIdx: number = 0;
    public bestIndex: number = 0;
    public lastIndex: number = 0;
    public cb: any = null;
    initParaData(t, e) {
        sys.isObjectValid(t) && (this._data = t);
        this.cb = e;
    }
    onLoad() {
    }
    start() {
        super.start();
        this.refreshData();
        ToolUtils.showFullScreen(this.node.getChildByName("mask"));
    }
    refreshData() {
        sys.isObjectValid(this._data) && sys.isObjectValid(this._data.status) && (this.status = this._data.status);
        sys.isObjectValid(this._data) && sys.isObjectValid(this._data.total_reward_num) && (this.optInNode.getChildByName("total").getComponent(Label).string = this._data.total_reward_num);
        this.optInNode.active = true;
        this.optSucNode.active = false;
    }
    onDestroy() {
        super.onDestroy();
        TweenTool.stopNodeAction(this.node);
        PushCenter.shared().removeListenersByTag(this);
        Utils.shared().hideLoading();
    }
    onEnable() {
    }
    onDisable() {
    }
    onButtonClick(t, e) {
        SoundManager.shared().playFx("click");
        "opt_in_close" == e ? this.onBackView() : "opt_in_process" == e ? this.dealOptInProcess() : "hide_opt_in_succ" == e ? this.onBackView() : "add" == e ? (this.nIdx + 1 < this.vCurRoomList.length && (this.nIdx = this.nIdx + 1, this.updateSliderProgress(this.nIdx + 1)), this.updateChangePointBtnState()) : "reduce" == e ? (this.nIdx > 0 && (this.nIdx = this.nIdx - 1, this.updateSliderProgress(this.nIdx + 1)), this.updateChangePointBtnState()) : "opt_in_playnow" == e && this.dealGameStartLogic();
    }
    dealGameStartLogic() {
        if (3 == this.gameType) {
            if (!User.shared().checkCanPlayCashGame(CheckModule.CHIPS_PLAY)) {
                return;
            }
        }
        else if (!User.shared().checkCanPlayCashGame(CheckModule.CASH_PLAY)) {
            return;
        }
        let t = 0, e = 0, i = 3 == this.gameType ? User.shared().data.money_exe : User.shared().data.money;
        if (Array.isArray(this.vCurRoomList) && this.vCurRoomList.length > this.nIdx) {
            let s = this.vCurRoomList[this.nIdx];
            if (e = s.boot, undefined !== s.entry && (t = s.entry), undefined !== s.max_money && s.max_money > t && (t = s.max_money), i < s.entry) {
                let t = null, e = 0, i = 0;
                if (Array.isArray(this.vCurRoomList) && this.vCurRoomList.length > this.nIdx && (t = this.vCurRoomList[this.nIdx], e = ToolUtils.isSafeNumber(t.vid), undefined !== t.entry && (i = t.entry)), 0 == this.gameType || 3 == this.gameType) {
                    Utils.shared().showQuickRecharge(e, null, true, "", 0, i, true, 0, 1);
                }
                else if (2 == this.gameType) {
                    let t = { vid: e, parent_node: director.getScene().getChildByName("Canvas"), bShowNetTip: true, min_entry: i };
                    Utils.shared().showQuickChipRecharge(t);
                }
                return;
            }
        }
        if (0 == this.gameType && sys.isObjectValid(this.vCurRoomList) && 0 != this.bestIndex) {
            let t = this.vCurRoomList[this.bestIndex - 1];
            if (null != t.boot && t.boot > e) {
                return void User.shared().requestCheckCashGameUpPop({ vid: t.vid }, (e => {
                    sys.isObjectValid(e) && 1 == e ? User.shared().showCashGameUpAlert(t.boot, (e => {
                        ToolUtils.isObjValid(this.node) && (1 == e ? this.enterGame(t) : Array.isArray(this.vCurRoomList) && this.vCurRoomList.length > this.nIdx && this.enterGame(this.vCurRoomList[this.nIdx]));
                    }), PhpReportDefined.scece.cash_hall_rankings) : ToolUtils.isObjValid(this.node) && Array.isArray(this.vCurRoomList) && this.vCurRoomList.length > this.nIdx && this.enterGame(this.vCurRoomList[this.nIdx]);
                }));
            }
        }
        this.enterGame(this.vCurRoomList[this.nIdx]);
    }
    enterGame(t) {
        if (this.optSucNode.getChildByName("btn_playnow").getComponent(Button).interactable = false, TweenTool.delayAct(this.node, (() => {
            ToolUtils.isObjValid(this.node) && (this.optSucNode.getChildByName("btn_playnow").getComponent(Button).interactable = true);
        }), 1, true), t && t.vid) {
            let e = t.vid;
            User.shared().min_money = t.entry;
            ToolUtils.curRoomId = e;
            let i = {};
            i.lobby = this.gameType;
            i.game = this.rummyType;
            i.data = t;
            ToolUtils.saveData(User.shared().data.uid + "recommendRoom" + this.gameType + this.rummyType, ToolUtils.toJsonString(i));
            ToolUtils.saveData(User.shared().data.uid + "recommendRoomNew", ToolUtils.toJsonString(i));
            ToolUtils.curRoomId = e;
            Utils.shared().showCommEnterRoom({ vid: e, game_type: this.rummyType, is_back: 0, isNewTable: 1 });
        }
    }
    dealOptInProcess() {
        Utils.shared().showLoading(10, true, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
        }));
        User.shared().dealLeadboardLogic_OptIn((t => {
            ToolUtils.isObjValid(this.node) && (Utils.shared().hideLoading(), this.status = t, 1 == this.status && (this.optInNode.active = false, this.showOptInSuccView(), PushCenter.shared().pushEvent(PushEvent.RefreshHallLeaderBoardMain), this.cb && this.cb(this.status)));
        }));
    }
    showOptInSuccView() {
        this.optSucNode.active = true;
        this.optInNode.active = false;
        let t = 6, e = PointsType.Classic;
        sys.isObjectValid(this._data.jump_info) && (this.gameType = this._data.jump_info.lobby, this.rummyType = this._data.jump_info.game, t = this._data.jump_info.player);
        let i = Utils.shared().getCurSelectRoomList(this.gameType, this.rummyType, t, 101, 2, e);
        if (i && i.length > 0) {
            this.vCurRoomList = i;
            let e = this.getRecommendRoomIndex(i);
            this.vCurRoomList && this.vCurRoomList[e - 1] && (this.optSucNode.getChildByName("game_name").getComponent(Label).string = `Points/Classic - ${t}P/${this.vCurRoomList[e - 1].boot}`);
        }
    }
    getRecommendRoomIndex(t, e, i = -1) {
        let s = 0, a = 0;
        -1 == i && (this.bestIndex = 0, this.lastIndex = 0);
        let o = User.shared().data.money;
        if (3 == this.gameType && (o = User.shared().data.money_exe), 0 == i ? o = User.shared().data.money : 1 == i && (o = User.shared().data.money_exe), null != t && sys.isObjectValid(t.length) && t.length > 0) {
            let n;
            for (let h = t.length - 1; h >= 0; h--) {
                sys.isObjectValid(e) && (n = t[h].entry, n == e && (-1 == i ? 0 == this.lastIndex && (this.lastIndex = h + 1) : 0 == a && (a = h + 1)));
                t[h].min_money <= o && o < t[h].max_money && (-1 == i ? 0 == this.bestIndex && (this.bestIndex = h + 1) : 0 == s && (s = h + 1));
            }
            if (sys.isObjectValid(e)) {
                for (let r = t.length - 1; r >= 0; r--) {
                    if (n = t[r].entry, n == e && e <= o) {
                        let t = r + 1;
                        return 0 == this.lastIndex ? t = this.bestIndex : 0 != this.bestIndex && (t = this.lastIndex >= this.bestIndex ? this.lastIndex : this.bestIndex), -1 == i ? t : [t, s, a];
                    }
                }
            }
            for (let e = t.length - 1; e >= 0; e--) {
                if (t[e].min_money <= o && o < t[e].max_money) {
                    let t = e + 1;
                    return 0 == this.lastIndex ? t = this.bestIndex : 0 != this.bestIndex && (t = this.lastIndex >= this.bestIndex ? this.lastIndex : this.bestIndex), -1 == i ? t : [t, s, a];
                }
            }
        }
        return -1 == i ? 1 : [1, s, a];
    }
    updateSliderProgress(t, e = true) {
        let i = this.optSucNode.getChildByName("slider_view").getChildByName("Slider"), s = i.getChildByName("ProgressBar");
        if (this.vCurRoomList && this.vCurRoomList.length > 1) {
            this.nIdx = t - 1;
            let e = (t - 1) / (this.vCurRoomList.length - 1);
            i.getComponent(Slider).progress = e;
            s.getComponent(ProgressBar).progress = e;
            this.updateEntryInfo(t);
        }
        else {
            this.nIdx = 0;
            i.getComponent(Slider).progress = 0;
            s.getComponent(ProgressBar).progress = 0;
            this.updateEntryInfo(1);
        }
    }
    updateEntryInfo(t) {
        let e = this.optSucNode.getChildByName("entry_info");
        if (this.vCurRoomList && this.vCurRoomList[t - 1]) {
            e.active = true;
            let i = e.getChildByName("arrow"), s = e.getChildByName("points"), a = s.getChildByName("value"), o = e.getChildByName("entry"), n = o.getChildByName("fee"), r = e.getChildByName("feeNode"), d = r.getChildByName("fee"), l = "", m = "";
            this.rummyType == HowToPlayDefined.RUMMY_POINTS || this.rummyType == HowToPlayDefined.RUMMY_MULTIPLE ? (s.active = true, o.active = true, i.active = true, r.active = false, l = this.vCurRoomList[t - 1].boot, m = this.vCurRoomList[t - 1].entry) : (r.active = true, i.active = false, s.active = false, o.active = false, l = this.vCurRoomList[t - 1].boot, m = this.vCurRoomList[t - 1].entry);
            let u = 3 == this.gameType ? "" : "₹";
            3 == this.gameType && (l = ToolUtils.parse_ChipNum2(l), m = ToolUtils.parse_ChipNum2(m));
            a.getComponent(Label).string = u + l;
            n.getComponent(Label).string = u + m;
            d.getComponent(Label).string = u + m;
        }
        else {
            e.active = false;
        }
        this.updateChangePointBtnState();
        this.refreshRankStar();
    }
    refreshRankStar() {
        let t = false, e = 1;
        if (0 == this.gameType) {
            if (2 == User.shared().act_116_not_recommend_show) {
                if (this.vCurRoomList && this.vCurRoomList[this.nIdx]) {
                    let i = this.vCurRoomList[this.nIdx];
                    if (sys.isObjectValid(i) && i.vid) {
                        let s = i.vid;
                        sys.isObjectValid(User.shared().act_116_not_recommend_list) && Array.isArray(User.shared().act_116_not_recommend_list) && -1 === User.shared().act_116_not_recommend_list.indexOf(String(s)) && (t = true, e = 5);
                    }
                }
            }
            else {
                1 == User.shared().act_116_not_recommend_show ? (t = true, e = 5) : 0 == User.shared().act_116_not_recommend_show && (t = false, e = 1);
            }
        }
        this.sliderStarNode.getParent().getComponent(Sprite).spriteFrame = t ? this.rankStarFrame[e] : this.rankStarFrame[0];
    }
    onSliderCallback(t, e) {
        let i = 0, s = this.optSucNode.getChildByName("slider_view").getChildByName("Slider"), a = s.getChildByName("ProgressBar"), o = s.getComponent(Slider).progress;
        this.vCurRoomList && this.vCurRoomList.length > 1 && (i = Math.floor((this.vCurRoomList.length - 1) * o + 0.5));
        a.getComponent(ProgressBar).progress = o;
        this.updateSliderProgress(i + 1);
    }
    updateChangePointBtnState() {
        let t = this.optSucNode.getChildByName("slider_view"), e = t.getChildByName("btn_add").getComponent(Button), i = t.getChildByName("btn_reduce").getComponent(Button);
        this.vCurRoomList && this.vCurRoomList.length > 1 ? (e.interactable = this.nIdx + 1 < this.vCurRoomList.length, i.interactable = this.nIdx > 0) : (e.interactable = false, i.interactable = false);
    }
    dealAutoSwitch() {
        let t = 1 == this.auto_entry_status ? 0 : 1;
        User.shared().requestUpdateRankAutoEntry(t, (t => {
            this.auto_entry_status = t;
            let e = 0;
            e = 1 == this.auto_entry_status ? 1 : 0;
            sys.isObjectValid(this.switchIcons[e]) && (this.optInNode.getChildByName("ico").getComponent(Sprite).spriteFrame = this.switchIcons[e]);
        }));
    }
    startShowAnim(t, e) {
        t.setScale(v3(0.2, 0.2, 0.2));
        TweenTool.scaleTo(t, 0.35, v3(1, 1, 1), "backOut", true, (() => {
            t.setScale(v3(1, 1, 1));
            e && e();
        }));
    }
    onBackView() {
        ToolUtils.isObjValid(this.node) && this.node.destroy();
    }
}
