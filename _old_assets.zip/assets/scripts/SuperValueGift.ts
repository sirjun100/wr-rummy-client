// @ts-nocheck
// Recovered from index.js:613
import { _decorator, Button, color, Label, Layout, Node, Sprite, SpriteFrame, sys } from "cc";
import Utils from "./Utils";
import SoundManager from "./SoundManager";
import User from "./User";
import PushEvent from "./PushEvent";
import BaseLayer from "./BaseLayer";
import HttpManager from "./HttpManager";
import PushCenter from "./PushCenter";
import GameConfig from "./GameConfig";
import i18nMgr from "./i18nMgr";
import { HttpRequest } from "./HttpRequestName";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("SuperValueGift")
export class SuperValueGift extends BaseLayer {
    @property(Node)
    public rootNode: Node = null;
    @property(Node)
    public maskNode: Node = null;
    @property(Node)
    public rewardRoot: Node = null;
    @property([SpriteFrame])
    public okBtnSpriteFrames: SpriteFrame[] = [];
    @property([SpriteFrame])
    public rewardBgSpriteFrames: SpriteFrame[] = [];
    @property(Node)
    public okBtnNode: Node = null;
    public _ui_type: number = 0;
    public fromType: any = -1;
    public isNext: boolean = false;
    public status: number = 0;
    public price: number = 0;
    public ratio_text: string = "";
    public collectArr: any[] = [];
    public _linkId: number = 0;
    public lastClick: number = 0;
    public pageData: any = null;
    public _has_close: boolean = false;
    public _pop_souce: number = 0;
    public _hasCurRewardShow: boolean = false;
    onLoad() {
    }
    start() {
        super.start();
        ToolUtils.showFullScreen(this.maskNode);
        this._linkId = this._linkId > 0 ? this._linkId : sys.now();
        sys.isObjectValid(this.pageData) ? this.refreshUI() : (sys.isObjectValid(User.shared().restartGift_pagedata) && (this.pageData = User.shared().restartGift_pagedata, this.refreshUI()), Utils.shared().showLoading(10, false), this.refreshPageUI());
        ToolUtils.getIsInRoom() ? this.startShowAnim2(this.rootNode, 0.69) : this.startShowAnim(this.rootNode);
        PushCenter.shared().addListener(GameConfig.Recharge, (t => {
            ToolUtils.isObjValid(this.node) && this.refreshPageUI();
        }), this);
        PushCenter.shared().addListener(PushEvent.RefreshRestartGift, (t => {
            ToolUtils.isObjValid(this.node) && (this.pageData = t, this.refreshUI());
        }), this);
        SoundManager.shared().playFx("act_popshow");
    }
    refreshPageUI() {
        User.shared().requestRestartGiftPage(null, (t => {
            if (ToolUtils.isObjValid(this.node) && sys.isObjectValid(t)) {
                let e = true, i = ToolUtils.jsonToMd5(t);
                if (sys.isObjectValid(this.pageData)) {
                    e = ToolUtils.jsonToMd5(this.pageData) != i;
                }
                User.shared().restartGift_pagedata = t;
                e && (this.pageData = t, this.refreshUI());
            }
        }));
    }
    refreshUI() {
        sys.isObjectValid(this.pageData) && (sys.isObjectValid(this.pageData.instant_amount) && (this.price = this.pageData.instant_amount), sys.isObjectValid(this.pageData.status) && (this.status = this.pageData.status), sys.isObjectValid(this.pageData.ratio_text) && (this.ratio_text = this.pageData.ratio_text), sys.isObjectValid(this.pageData.collect) && Array.isArray(this.pageData.collect) && this.pageData.collect.length > 0 && (this.collectArr = this.pageData.collect), sys.isObjectValid(this.pageData.tips_text) && ToolUtils.isSafeString(this.pageData.tips_text).length > 0 && (this.rootNode.getChildByName("total_amt").getComponent(Label).string = this.pageData.tips_text), sys.isObjectValid(this.pageData.tips_text2) && ToolUtils.isSafeString(this.pageData.tips_text2).length > 0 && (this.rootNode.getChildByName("less_tips").getComponent(Label).string = this.pageData.tips_text2), this.rewardRoot.getChildByName("item_cash").getChildByName("wz").getComponent(Label).string = "₹" + this.price, sys.isObjectValid(this.pageData.instant_bonus) && Number(this.pageData.instant_bonus) > 0 ? (this.rewardRoot.getChildByName("item_bonus").active = true, this.rewardRoot.getChildByName("add").active = true, this.rewardRoot.getChildByName("item_bonus").getChildByName("wz").getComponent(Label).string = "₹" + this.pageData.instant_bonus) : (this.rewardRoot.getChildByName("item_bonus").active = false, this.rewardRoot.getChildByName("add").active = false), this.rewardRoot.getComponent(Layout).updateLayout());
        0 == this.status || 1 == this.status ? this.okBtnNode.getComponent(Sprite).spriteFrame = this.okBtnSpriteFrames[1] : (this.status, this.okBtnNode.getComponent(Sprite).spriteFrame = this.okBtnSpriteFrames[0]);
        let t = this.okBtnNode.getChildByName("flag"), e = this.okBtnNode.getChildByName("zhekou_layout");
        e.active = false;
        0 == this.status ? (this.okBtnNode.getChildByName("wz").getComponent(Label).string = "₹" + this.price, ToolUtils.isSafeString(this.ratio_text).length > 0 ? (t.active = true, e.getChildByName("zhekou").getComponent(Label).string = "" + this.ratio_text, e.active = true, e.getComponent(Layout).updateLayout()) : t.active = false) : (t.active = false, this.okBtnNode.getChildByName("wz").getComponent(Label).string = "COLLECT");
        this._hasCurRewardShow = false;
        this.okBtnNode.getComponent(Button).interactable = 2 != this.status;
        let i = "";
        for (let t = 0; t < this.collectArr.length; t++) {
            let e = this.collectArr[t];
            i = "item" + t;
            let a = this.rootNode.getChildByName(i);
            ToolUtils.isObjValid(a) && (sys.isObjectValid(e.tips) && (a.getChildByName("title").getComponent(Label).string = e.tips + ""), sys.isObjectValid(e.amt) && (a.getChildByName("num").getComponent(Label).string = "₹" + e.amt));
            i = "gou" + t;
            let s = this.rootNode.getChildByName(i);
            s && sys.isObjectValid(e.iscollect) && (s.active = 1 == ToolUtils.isSafeNumber(e.iscollect));
            this.updateItemStatus(a, e.iscollect);
        }
    }
    updateItemStatus(t, e) {
        1 == e ? (t.getComponent(Sprite).color = color(120, 120, 120), t.getChildByName("reward").getComponent(Sprite).color = color(120, 120, 120), t.getChildByName("num").getComponent(Label).color = color(120, 120, 120), t.getChildByName("title").getComponent(Label).color = color(63, 0, 0), t.getComponent(Sprite).spriteFrame = this.rewardBgSpriteFrames[0]) : (t.getComponent(Sprite).spriteFrame = this.rewardBgSpriteFrames[0], 1 == this.status && (this._hasCurRewardShow || (this._hasCurRewardShow = true, t.getComponent(Sprite).spriteFrame = this.rewardBgSpriteFrames[1])), t.getComponent(Sprite).color = color(255, 255, 255), t.getChildByName("reward").getComponent(Sprite).color = color(255, 255, 255), t.getChildByName("num").getComponent(Label).color = color(255, 255, 255), t.getChildByName("title").getComponent(Label).color = color(63, 0, 0));
    }
    initParaData(t) {
        sys.isObjectValid(t) && (sys.isObjectValid(t.isNext) && (this.isNext = t.isNext), sys.isObjectValid(t.status) && (this.pageData = t), sys.isObjectValid(t.ext) && sys.isObjectValid(t.ext.status) && (this.pageData = t.ext), sys.isObjectValid(t) && sys.isObjectValid(t.link_id) && t.link_id > 0 && (this._linkId = t.link_id), sys.isObjectValid(t) && sys.isObjectValid(t.pop_souce) && (this._pop_souce = t.pop_souce));
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().removeListenersByTag(this);
    }
    onBackView() {
        if (ToolUtils.isObjValid(this.node)) {
            if (this._has_close) {
                return;
            }
            let t = { alert_node: this.node, rootNode: this.rootNode, isNext: this.isNext, pop_type: PushEvent.JUMP_TO_RestartGift, pop_souce: this._pop_souce };
            Utils.shared().closeActivityView(t);
            this._has_close = true;
            Utils.shared().hideToast();
            User.shared().getHallInfo();
        }
    }
    onButtonClick(t, e) {
        if (SoundManager.shared().playFx("click"), "close" == e) {
            this.onBackView();
        }
        else if ("ok" == e) {
            if (0 == this.status) {
                if (!User.shared().checkCanRecharge()) {
                    return void (ToolUtils.isObjValid(this.node) && this.node.destroy());
                }
                if (sys.now() - this.lastClick < 1000) {
                    return;
                }
                this.lastClick = sys.now();
                let t = { price: this.price, act_id: PushEvent.JUMP_TO_RestartGift, link_id: this._linkId };
                User.shared().startPay(t);
            }
            else if (1 == this.status || 3 == this.status) {
                if (sys.now() - this.lastClick < 1000) {
                    return;
                }
                this.lastClick = sys.now();
                Utils.shared().showLoading(10, true, (() => {
                    Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
                }));
                HttpManager.shared().doGetCommonRequest(null, HttpRequest.RestartGiftCollect, ((t, e, i) => {
                    if (Utils.shared().hideLoading(), 200 != i) {
                        ;
                    }
                    else {
                        let t = ToolUtils.parseJson(e);
                        if (0 == t.ret) {
                            if (sys.isObjectValid(t.data.reward_list)) {
                                let e = null;
                                sys.isObjectValid(t.data.tips) && (e = t.data.tips + "");
                                User.shared().showChargeReward(t.data.reward_list, (e => {
                                    ToolUtils.isObjValid(this.node) && sys.isObjectValid(t.data.ext) && (this.pageData = t.data.ext, User.shared().restartGift_pagedata = this.pageData, this.refreshUI());
                                }), e);
                            }
                        }
                        else {
                            ToolUtils.isSafeString(t.desc).length > 0 && Utils.shared().showToast(t.desc, 3, 0, ToolUtils.getIsNormalDirection());
                        }
                    }
                }));
            }
        }
    }
}
