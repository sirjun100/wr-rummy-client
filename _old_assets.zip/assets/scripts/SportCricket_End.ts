// @ts-nocheck
// Recovered from index.js:553
import { _decorator, Button, color, instantiate, Label, Node, ScrollView, size, Sprite, SpriteFrame, sys, UITransform, v3, view, Widget } from "cc";
import SoundManager from "./SoundManager";
import PushCenter from "./PushCenter";
import { TLog } from "./TLog";
import Utils from "./Utils";
import User from "./User";
import HttpManager from "./HttpManager";
import i18nMgr from "./i18nMgr";
import BaseLayer from "./BaseLayer";
import { HttpRequest } from "./HttpRequestName";
import GameConfig from "./GameConfig";
import TableViewUtils from "./TableViewUtils";
import PushEvent from "./PushEvent";
import TweenTool from "./TweenTool";
import SportCricket_Manager from "./SportCricket_Manager";
import { ToolUtils } from "./ToolUtils";
import PhpReportDefined from "./PhpReportDefined";
const { ccclass, property } = _decorator;
@ccclass("SportCricket_End")
export class SportCricket_End extends BaseLayer {
    public TAG: string = "SportCricket_End";
    @property(Node)
    public rootNode: Node = null;
    @property(Node)
    public topNode: Node = null;
    @property(Node)
    public filterPopRoot: Node = null;
    @property(Node)
    public scoreTabRoot: Node = null;
    @property(Node)
    public selectNode: Node = null;
    @property(ScrollView)
    public myContestList: ScrollView = null;
    @property(ScrollView)
    public statsList: ScrollView = null;
    @property(ScrollView)
    public scoreBoardList: ScrollView = null;
    @property(Node)
    public filterNode: Node = null;
    @property(Node)
    public filterList: Node = null;
    @property(Node)
    public noData: Node = null;
    @property(Node)
    public myContestItem: Node = null;
    @property(Node)
    public statsItem: Node = null;
    @property(Node)
    public scoreBoardItem: Node = null;
    @property(Node)
    public filterItem: Node = null;
    @property(Node)
    public filterContent: Node = null;
    @property(Node)
    public stateListFilter: Node = null;
    @property([SpriteFrame])
    public sortBgImgs: SpriteFrame[] = [];
    @property([SpriteFrame])
    public teamIconArr: SpriteFrame[] = [];
    @property([SpriteFrame])
    public sortArrowImgs: SpriteFrame[] = [];
    public statsTable: any = null;
    public _closed: boolean = false;
    public bShowPushAnim: boolean = true;
    public _lastClick: number = 0;
    public _sourceData: any = null;
    public _itemArr: any[] = [];
    public all_has_next_page: number = 0;
    public all_cur_page: number = 1;
    public _isSendMsg: boolean = false;
    public my_has_next_page: number = 0;
    public my_cur_page: number = 1;
    public tabWzColor: any[] = [color(147, 11, 11), color(102, 102, 102)];
    public _popfilter_itemArr: any[] = [];
    public _popfilter_selectIndex: number = 0;
    public taskAwardIconMap: Map = new Map;
    public lastClick: number = 0;
    public topEndInfo: any = null;
    public contestsInfo: any = null;
    public statsInfo: any = null;
    public scoreBoardInfo: any = null;
    public leaderBoardInfo: any[] = [];
    public wingsInfo: any = null;
    public detailInfo: any = null;
    public sortParamList: any[] = [];
    public cur_matchId: any = null;
    public curTab: number = 0;
    public curScoreBoardTab: number = 0;
    public player_sort: number = 0;
    public point_sort: number = 1;
    public curStateSortType: number = 0;
    public curSelectIdx: any = -1;
    public lastNodeName: string = "";
    public _enter_cb: any = null;
    public _exit_cb: any = null;
    public teamAItem: any = null;
    public teamBItem: any = null;
    public _teamA_open: boolean = false;
    public _teamB_open: boolean = false;
    public _headPos: any = v3();
    public _namePos: any = v3();
    public sort_select_color: any = color(182, 0, 0);
    onLoad() {
        let t = this.myContestItem.getChildByName("bg").getChildByName("item");
        this._headPos = t.getChildByName("head_kuang").getPosition();
        this._namePos = t.getChildByName("teamName").getPosition();
        PushCenter.shared().addListener(PushEvent.commentDownloaderImg, (t => {
            try {
                if (ToolUtils.isObjValid(this.node) && this.taskAwardIconMap.size > 0) {
                    for (const [e, i] of this.taskAwardIconMap) {
                        i == t && Utils.shared().updateNetImage(e, t, size(79, 79));
                    }
                }
            }
            catch (t) {
                TLog.printError(this.TAG, PushEvent.commentDownloaderImg, t);
            }
        }), this);
        PushCenter.shared().addListener(GameConfig.Update_Money, (t => {
            try {
                ToolUtils.isObjValid(this.node) && this.updateGold(t);
            }
            catch (t) {
                TLog.printError(this.TAG, GameConfig.Update_Money, t);
            }
        }), this);
        this.fitLuckyTheme();
    }
    fitLuckyTheme() {
        0 != GameConfig.NATIVE_GAME_APP_TYPE && (this.sort_select_color = color(47, 66, 98), this.tabWzColor = [color(221, 3, 3), color(102, 102, 102)], this.rootNode.getChildByName("top_node").getChildByName("top_bg").getComponent(Sprite).color = color(12, 26, 60, 255), this.topNode.getChildByName("add_gold").getChildByName("coin").getComponent(Label).color = color(251, 220, 0, 255), this.selectNode.getChildByName("bg").getComponent(Sprite).color = color(250, 250, 250, 255), this.selectNode.getChildByName("select_text1").getChildByName("line").getComponent(Sprite).color = this.tabWzColor[0], this.selectNode.getChildByName("select_text2").getChildByName("line").getComponent(Sprite).color = this.tabWzColor[0], this.selectNode.getChildByName("select_text2").getChildByName("line").getComponent(Sprite).color = this.tabWzColor[0]);
    }
    updateGold(t) {
        let e = this.topNode.getChildByName("add_gold").getChildByName("coin");
        null != t && e && (e.getComponent(Label).string = ToolUtils.parse_double(t));
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().removeListenersByTag(this);
        this.unscheduleAllCallbacks();
    }
    init(t, e = null, i = null) {
        sys.isObjectValid(t) && sys.isObjectValid(t.match_id) && (this.cur_matchId = t.match_id);
        sys.isObjectValid(t.completeInfo) && (sys.isObjectValid(t.completeInfo.endInfo) && (this.topEndInfo = t.completeInfo.endInfo), sys.isObjectValid(t.completeInfo.contestsInfo) && (this.contestsInfo = t.completeInfo.contestsInfo), sys.isObjectValid(t.completeInfo.statsInfo) && (this.statsInfo = t.completeInfo.statsInfo), sys.isObjectValid(t.completeInfo.scoreBoardInfo) && (this.scoreBoardInfo = t.completeInfo.scoreBoardInfo));
        e && (this._enter_cb = e);
        i && (this._exit_cb = i);
        this.curTab = 0;
    }
    start() {
        super.start();
        this.initView();
        this.updateTopInfo();
        this.updateGold(User.shared().data.money);
        let t = [this.statsItem];
        this.statsTable = this.node.addComponent(TableViewUtils);
        let e = this.statsItem.getComponent(UITransform).height;
        this.statsTable.init([], this.statsList.node, t, this.initStatsItem.bind(this), 10, e);
        sys.isObjectValid(this.contestsInfo) || this.requestMyContestList(0 == this.curTab);
        this.requestSortParamList(false, (() => {
            this.sortParamList.length > 0 && (this.curSelectIdx = 0);
            sys.isObjectValid(this.statsInfo) || this.requestPlayerStatsList(1 == this.curTab);
            sys.isObjectValid(this.scoreBoardInfo) || this.requestScoreBoardList(2 == this.curTab);
        }));
        this.bShowPushAnim ? ToolUtils.showPushAnim(this.node, 0, (() => {
            this._enter_cb && this._enter_cb();
            this.refreshView();
        })) : (this._enter_cb && this._enter_cb(), this.refreshView());
    }
    updateTopInfo() {
        if (sys.isObjectValid(this.topEndInfo) && sys.isObjectValid(this.topEndInfo.teama) && sys.isObjectValid(this.topEndInfo.teamb) && ToolUtils.isObjValid(this.topNode)) {
            if (this.topNode.getChildByName("vsTitle") && (this.topNode.getChildByName("vsTitle").getChildByName("name1").getComponent(Label).string = this.topEndInfo.teama.short_name, this.topNode.getChildByName("vsTitle").getChildByName("name2").getComponent(Label).string = this.topEndInfo.teamb.short_name), this.topNode.getChildByName("status").getComponent(Label).string = this.topEndInfo.status_str, this.topNode.getChildByName("tips").getComponent(Label).string = this.topEndInfo.result, this.topNode.getChildByName("left")) {
                this.topNode.getChildByName("left").getChildByName("name").getComponent(Label).string = this.topEndInfo.teama.short_name;
                this.topNode.getChildByName("left").getChildByName("score").getComponent(Label).string = this.topEndInfo.teama.scores_full;
                let t = this.topNode.getChildByName("left").getChildByName("head_mask").getChildByName("head_img");
                Utils.shared().updateNetImage(t, this.topEndInfo.teama.thumb_url, size(79, 79));
                sys.isObjectValid(this.topEndInfo.teama.thumb_url) && this.topEndInfo.teama.thumb_url.length > 0 && this.taskAwardIconMap.set(t, this.topEndInfo.teama.thumb_url);
            }
            if (this.topNode.getChildByName("right")) {
                this.topNode.getChildByName("right").getChildByName("name").getComponent(Label).string = this.topEndInfo.teamb.short_name;
                this.topNode.getChildByName("right").getChildByName("score").getComponent(Label).string = this.topEndInfo.teamb.scores_full;
                let t = this.topNode.getChildByName("right").getChildByName("head_mask").getChildByName("head_img");
                Utils.shared().updateNetImage(t, ToolUtils.isSafeString(this.topEndInfo.teamb.thumb_url), size(79, 79));
                sys.isObjectValid(this.topEndInfo.teamb.thumb_url) && this.topEndInfo.teamb.thumb_url.length > 0 && this.taskAwardIconMap.set(t, this.topEndInfo.teamb.thumb_url);
            }
        }
    }
    initContestItem(t, e, i) {
        t.active = true;
        let s = t.getChildByName("bg").getChildByName("val");
        s.getChildByName("pool_node").getChildByName("prize_pool").getComponent(Label).string = "₹" + e.all_reward || "";
        s.getChildByName("pool_node").getChildByName("ico").active = false;
        sys.isObjectValid(e.is_chip) && 1 == e.is_chip && (s.getChildByName("pool_node").getChildByName("ico").active = true);
        s.getChildByName("winners").getComponent(Label).string = e.winners || "";
        s.getChildByName("entry_node").getChildByName("entry").getComponent(Label).string = "₹" + e.fee || "";
        s.getChildByName("entry_node").getChildByName("ico").active = false;
        sys.isObjectValid(e.is_chip) && 1 == e.is_chip && (s.getChildByName("entry_node").getChildByName("ico").active = true);
        let a = t.getChildByName("bg").getChildByName("item"), o = t.getChildByName("bg").getChildByName("rankBtn"), r = t.getChildByName("bg").getChildByName("bg2");
        if (sys.isObjectValid(e.rank)) {
            for (let t = 0, i = e.rank.length; t < i; t++) {
                let i = instantiate(a);
                Utils.shared().updateHeadImg(i.getChildByName("head_mask").getChildByName("head_img"), e.rank[t].avatar, e.rank[t].avatar_url, size(65, 65));
                sys.isObjectValid(e.rank[t].avatar_url) && e.rank[t].avatar_url.length > 0 && this.taskAwardIconMap.set(i.getChildByName("head_mask").getChildByName("head_img"), e.rank[t].avatar_url);
                i.getChildByName("teamName").getComponent(Label).string = e.rank[t].name || "";
                String(e.rank[t].reward).length > 0 ? (sys.isObjectValid(e.is_chip) && 1 == e.is_chip ? (i.getChildByName("chip").active = true, i.getChildByName("winScore").getComponent(Label).string = ToolUtils.format(" You won      ${0}", e.rank[t].reward)) : (i.getChildByName("chip").active = false, i.getChildByName("winScore").getComponent(Label).string = ToolUtils.format("You won ${0}", e.rank[t].reward)), i.getChildByName("rank_bg").active = true, i.getChildByName("winFlag").active = true, i.getChildByName("head_kuang").setPosition(this._headPos), i.getChildByName("head_mask").setPosition(v3(this._headPos.x, this._headPos.y - 1)), i.getChildByName("teamName").setPosition(this._namePos)) : (i.getChildByName("winScore").getComponent(Label).string = "", i.getChildByName("rank_bg").active = false, i.getChildByName("winFlag").active = false, i.getChildByName("head_kuang").setPosition(v3(this._headPos.x, 0)), i.getChildByName("head_mask").setPosition(v3(this._headPos.x, -1)), i.getChildByName("teamName").setPosition(v3(this._namePos.x, -1)));
                i.getChildByName("points").getComponent(Label).string = ToolUtils.format("${0}", e.rank[t].point);
                i.getChildByName("rank").getComponent(Label).string = ToolUtils.format("${0}", e.rank[t].rank);
                i.active = true;
                r.addChild(i);
            }
        }
        let l = instantiate(o);
        l.getComponent(Button).clickEvents[0].customEventData = ToolUtils.toJsonString(e);
        l.active = true;
        r.addChild(l);
    }
    initStatsItem(t, e, i) {
        t.active = true;
        t.getChildByName("tx_name").getComponent(Label).string = e.player_name || "";
        t.getChildByName("tx_team").getComponent(Label).string = e.team_name || "";
        t.getChildByName("tx_point").getComponent(Label).string = e.point || "";
        "teama_player_thumb.png" == e.player_thumb_url ? t.getChildByName("head_mask").getChildByName("head_img").getComponent(Sprite).spriteFrame = this.teamIconArr[0] : "teamb_player_thumb.png" == e.player_thumb_url ? t.getChildByName("head_mask").getChildByName("head_img").getComponent(Sprite).spriteFrame = this.teamIconArr[1] : (Utils.shared().updateNetImage(t.getChildByName("head_mask").getChildByName("head_img"), ToolUtils.isSafeString(e.player_thumb_url), size(65, 65)), sys.isObjectValid(e.player_thumb_url) && e.player_thumb_url.length > 0 && this.taskAwardIconMap.set(t.getChildByName("head_mask").getChildByName("head_img"), e.player_thumb_url));
        t.getChildByName("detailBtn").getComponent(Button).clickEvents[0].customEventData = ToolUtils.toJsonString(e);
        0 == e.is_color ? t.getChildByName("bg").getComponent(Sprite).color = color(240, 240, 240) : t.getChildByName("bg").getComponent(Sprite).color = color(255, 247, 224);
        sys.isObjectValid(e.is_best) && 1 == e.is_best ? t.getChildByName("logo").active = true : t.getChildByName("logo").active = false;
        "0" == e.point || 0 == e.point.length ? t.getChildByName("detailBtn").active = false : t.getChildByName("detailBtn").active = true;
    }
    initScoreBoardItem(t, e, i) {
        let s = 0 == i ? this._teamA_open : this._teamB_open;
        s = true;
        t.active = true;
        let a = t.getChildByName("item_moban"), o = t.getChildByName("line_moban"), r = t.getChildByName("batsmen");
        if (sys.isObjectValid(e.batsmen) && sys.isObjectValid(e.batsmen.list)) {
            for (let t = 0, i = e.batsmen.list.length; t < i; t++) {
                let i = instantiate(a), s = i.getChildByName("scores");
                s.getChildByName("name").getComponent(Label).string = e.batsmen.list[t].short_name;
                s.getChildByName("tx_r").getComponent(Label).string = e.batsmen.list[t].runs;
                s.getChildByName("tx_b").getComponent(Label).string = e.batsmen.list[t].balls_faced;
                s.getChildByName("tx_4").getComponent(Label).string = e.batsmen.list[t].fours;
                s.getChildByName("tx_6").getComponent(Label).string = e.batsmen.list[t].sixes;
                s.getChildByName("tx_sr").getComponent(Label).string = e.batsmen.list[t].strike_rate;
                i.getChildByName("sub_title").getComponent(Label).string = e.batsmen.list[t].how_out;
                i.getChildByName("sub_title").active = true;
                0 == e.batsmen.list[t].is_color ? i.getComponent(Sprite).color = color(255, 255, 255) : i.getComponent(Sprite).color = color(255, 247, 224);
                i.active = true;
                r.addChild(i);
                let l = instantiate(o);
                l.active = true;
                r.addChild(l);
            }
            if (0 == e.batsmen.list.length) {
                let t = instantiate(o);
                t.active = true;
                r.addChild(t);
            }
            r.active = true;
        }
        else {
            r.active = false;
        }
        let l = t.getChildByName("bowling");
        if (sys.isObjectValid(e.bowlers) && sys.isObjectValid(e.bowlers.list)) {
            for (let t = 0, i = e.bowlers.list.length; t < i; t++) {
                let i = instantiate(a), s = i.getChildByName("scores");
                s.getChildByName("name").getComponent(Label).string = e.bowlers.list[t].short_name;
                s.getChildByName("tx_r").getComponent(Label).string = e.bowlers.list[t].overs;
                s.getChildByName("tx_b").getComponent(Label).string = e.bowlers.list[t].maidens;
                s.getChildByName("tx_4").getComponent(Label).string = e.bowlers.list[t].runs_conceded;
                s.getChildByName("tx_6").getComponent(Label).string = e.bowlers.list[t].wickets;
                s.getChildByName("tx_sr").getComponent(Label).string = e.bowlers.list[t].econ;
                0 == e.bowlers.list[t].is_color ? i.getComponent(Sprite).color = color(255, 255, 255) : i.getComponent(Sprite).color = color(255, 247, 224);
                i.getChildByName("sub_title").active = false;
                i.active = true;
                l.addChild(i);
                let r = instantiate(o);
                r.active = true;
                l.addChild(r);
            }
            if (0 == e.bowlers.list.length) {
                let t = instantiate(o);
                t.active = true;
                l.addChild(t);
            }
            l.active = true;
        }
        else {
            l.active = false;
        }
    }
    updateSelectView() {
        this.selectNode.getChildByName("select_text1").getChildByName("line").active = 0 == this.curTab;
        this.selectNode.getChildByName("select_text2").getChildByName("line").active = 1 == this.curTab;
        this.selectNode.getChildByName("select_text3").getChildByName("line").active = 2 == this.curTab;
        this.selectNode.getChildByName("select_text1").getChildByName("Label").getComponent(Label).color = 0 == this.curTab ? this.tabWzColor[0] : this.tabWzColor[1];
        this.selectNode.getChildByName("select_text2").getChildByName("Label").getComponent(Label).color = 1 == this.curTab ? this.tabWzColor[0] : this.tabWzColor[1];
        this.selectNode.getChildByName("select_text3").getChildByName("Label").getComponent(Label).color = 2 == this.curTab ? this.tabWzColor[0] : this.tabWzColor[1];
        i18nMgr.shared().changeLabelFont(this.selectNode.getChildByName("select_text1").getChildByName("Label").getComponent(Label), 0 == this.curTab);
        i18nMgr.shared().changeLabelFont(this.selectNode.getChildByName("select_text2").getChildByName("Label").getComponent(Label), 1 == this.curTab);
        i18nMgr.shared().changeLabelFont(this.selectNode.getChildByName("select_text3").getChildByName("Label").getComponent(Label), 2 == this.curTab);
        let t = [];
        t.push(this.selectNode.getChildByName("select_text1").getChildByName("line"));
        t.push(this.selectNode.getChildByName("select_text2").getChildByName("line"));
        t.push(this.selectNode.getChildByName("select_text3").getChildByName("line"));
        for (let e = 0; e < 3; e++) {
            if (this.curTab == e) {
                t[e].scale = v3(0, 1, 1);
                let i = TweenTool.scaleTo(t[e], 0.16, v3(1.1, 1, 1), null, false), s = TweenTool.scaleTo(t[e], 0.16, v3(1, 1, 1), null, false);
                TweenTool.sequence(t[e], true, null, i, s);
            }
            else {
                t[e].scale = v3(1, 1, 1);
            }
        }
    }
    updateTabContent() {
        0 == this.curTab ? (this.myContestList.node.active = true, this.statsList.node.active = false, this.scoreBoardList.node.active = false, this.filterNode.active = false, this.filterList.active = false, this.scoreTabRoot.active = false, this.updateMyContestsList()) : 1 == this.curTab ? (this.myContestList.node.active = false, this.statsList.node.active = true, this.scoreBoardList.node.active = false, this.filterNode.active = true, this.filterList.active = false, this.scoreTabRoot.active = false, this.refreshSortView(), this.filterNode.getChildByName("statslistFilter").active = true, this.updatePlayerStatsList(), 0 == this.sortParamList.length && this.requestSortParamList(), sys.isObjectValid(this.statsInfo) || this.requestPlayerStatsList(true), this.updateStateSortArrow()) : 2 == this.curTab && (this.myContestList.node.active = false, this.statsList.node.active = false, this.scoreBoardList.node.active = true, this.filterNode.active = true, this.filterList.active = false, this.curScoreBoardTab = 0, this.updateScoreTabState(), this.refreshSortView(), this.scoreTabRoot.active = true, this.filterNode.getChildByName("statslistFilter").active = false, this.updateScoreBoardList(), 0 == this.sortParamList.length && this.requestSortParamList(), sys.isObjectValid(this.scoreBoardInfo) || this.requestScoreBoardList(true));
    }
    updateScoreTabState() {
        let t = [color(51, 51, 51), color(168, 26, 26)];
        this.scoreTabRoot.getChildByName("select_text0").getChildByName("Label").getComponent(Label).color = 0 == this.curScoreBoardTab ? t[1] : t[0];
        this.scoreTabRoot.getChildByName("select_text1").getChildByName("Label").getComponent(Label).color = 1 == this.curScoreBoardTab ? t[1] : t[0];
        this.scoreTabRoot.getChildByName("select_text0").getChildByName("ico").active = 0 == this.curScoreBoardTab;
        this.scoreTabRoot.getChildByName("select_text1").getChildByName("ico").active = 1 == this.curScoreBoardTab;
        i18nMgr.shared().changeLabelFont(this.scoreTabRoot.getChildByName("select_text0").getChildByName("Label").getComponent(Label), 0 == this.curScoreBoardTab);
        i18nMgr.shared().changeLabelFont(this.scoreTabRoot.getChildByName("select_text1").getChildByName("Label").getComponent(Label), 1 == this.curScoreBoardTab);
    }
    requestMyContestList(t = false) {
        let e = { uid: User.shared().data.uid, match_id: this.cur_matchId };
        t && Utils.shared().showLoading(10, true, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
        }), ToolUtils.getIsNormalDirection());
        let i = this.cur_matchId;
        HttpManager.shared().doGetCommonRequest(e, HttpRequest.Yes11_EndMyContests, ((e, s, a) => {
            if (Utils.shared().hideLoading(), 200 != a) {
                ToolUtils.isObjValid(this.node) && (t && Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.request_fail"), 2), this.noData.active = 0 == this.curTab);
            }
            else {
                try {
                    let e = ToolUtils.parseJson(s);
                    0 == e.ret ? sys.isObjectValid(e.data) && (sys.isObjectValid(SportCricket_Manager.shared().cricket_completeInfo[i]) || (SportCricket_Manager.shared().cricket_completeInfo[i] = {}), SportCricket_Manager.shared().cricket_completeInfo[i].contestsInfo = e.data, ToolUtils.isObjValid(this.node) && (this.contestsInfo = e.data, 0 == this.curTab && this.myContestList.node.active && this.updateMyContestsList())) : ToolUtils.isObjValid(this.node) && (t && ToolUtils.isSafeString(e.desc).length > 0 && Utils.shared().showToast(e.desc, 3), this.noData.active = 0 == this.curTab);
                }
                catch (t) {
                    TLog.printError("requestMyContestList err:", t.toString());
                }
            }
        }));
    }
    updateMyContestsList() {
        let t = sys.isObjectValid(this.contestsInfo) && sys.isObjectValid(this.contestsInfo.list) ? this.contestsInfo.list : [];
        this.myContestList.content.removeAllChildren();
        let e = t.length;
        for (let i = 0; i < e; i++) {
            let e = instantiate(this.myContestItem);
            this.initContestItem(e, t[i], i);
            this.myContestList.content.addChild(e);
        }
        this.noData.active = !(e > 0);
        this.selectNode.getChildByName("select_text1").getChildByName("Label").getComponent(Label).string = ToolUtils.format("My Contest(${0})", t.length);
    }
    requestPlayerStatsList(t = false) {
        let e = { uid: User.shared().data.uid, match_id: this.cur_matchId };
        this.sortParamList[this.curSelectIdx] && (e.team_id = this.sortParamList[this.curSelectIdx].team_id);
        t && Utils.shared().showLoading(10, true, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
        }), ToolUtils.getIsNormalDirection());
        let i = this.cur_matchId;
        HttpManager.shared().doGetCommonRequest(e, HttpRequest.Yes11_EndPlayerStats, ((e, s, a) => {
            if (Utils.shared().hideLoading(), 200 != a) {
                ToolUtils.isObjValid(this.node) && (t && Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.request_fail"), 2), this.noData.active = 1 == this.curTab);
            }
            else {
                try {
                    let e = ToolUtils.parseJson(s);
                    0 == e.ret ? sys.isObjectValid(e.data) && (sys.isObjectValid(SportCricket_Manager.shared().cricket_completeInfo[i]) || (SportCricket_Manager.shared().cricket_completeInfo[i] = {}), SportCricket_Manager.shared().cricket_completeInfo[i].statsInfo = e.data, ToolUtils.isObjValid(this.node) && (this.statsInfo = e.data, 1 == this.curTab && this.statsList.node.active && this.updatePlayerStatsList())) : ToolUtils.isObjValid(this.node) && (t && ToolUtils.isSafeString(e.desc).length > 0 && Utils.shared().showToast(e.desc, 3), this.noData.active = 1 == this.curTab);
                }
                catch (t) {
                    TLog.printError("requestPlayerStatsList err:", t.toString());
                }
            }
        }));
    }
    updatePlayerStatsList() {
        let t = sys.isObjectValid(this.statsInfo) && sys.isObjectValid(this.statsInfo.list) ? this.statsInfo.list : [];
        this.statsTable.reloadData(t);
        1 == this.curTab && (this.noData.active = 0 == t.length);
    }
    requestScoreBoardList(t = false) {
        let e = { uid: User.shared().data.uid, match_id: this.cur_matchId };
        this.sortParamList[this.curSelectIdx] && (e.team_id = this.sortParamList[this.curSelectIdx].team_id);
        t && Utils.shared().showLoading(10, true, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
        }), ToolUtils.getIsNormalDirection());
        let i = this.cur_matchId;
        HttpManager.shared().doGetCommonRequest(e, HttpRequest.Yes11_EndScoreBoard, ((e, s, a) => {
            if (Utils.shared().hideLoading(), 200 != a) {
                ToolUtils.isObjValid(this.node) && (t && Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.request_fail"), 2), this.noData.active = 2 == this.curTab);
            }
            else {
                try {
                    let e = ToolUtils.parseJson(s);
                    0 == e.ret ? sys.isObjectValid(e.data) && (sys.isObjectValid(SportCricket_Manager.shared().cricket_completeInfo[i]) || (SportCricket_Manager.shared().cricket_completeInfo[i] = {}), SportCricket_Manager.shared().cricket_completeInfo[i].scoreBoardInfo = e.data, ToolUtils.isObjValid(this.node) && (this.scoreBoardInfo = e.data, 2 == this.curTab && this.scoreBoardList.node.active && this.updateScoreBoardList())) : ToolUtils.isObjValid(this.node) && (t && ToolUtils.isSafeString(e.desc).length > 0 && Utils.shared().showToast(e.desc, 3), this.noData.active = 2 == this.curTab);
                }
                catch (t) {
                    TLog.printError("requestScoreBoardList err:", t.toString());
                }
            }
        }));
    }
    updateScoreBoardList() {
        let t = sys.isObjectValid(this.scoreBoardInfo) ? this.scoreBoardInfo : {}, e = [];
        if (t && sys.isObjectValid(t.teama) && (e.push(t.teama), this.scoreTabRoot.getChildByName("select_text0").getChildByName("Label").getComponent(Label).string = t.teama.short_name || ""), t && sys.isObjectValid(t.teamb) && (e.push(t.teamb), this.scoreTabRoot.getChildByName("select_text1").getChildByName("Label").getComponent(Label).string = t.teamb.short_name || ""), this.scoreBoardList.content.removeAllChildren(), e.length > 0) {
            this.scoreTabRoot.getChildByName("team_name").getComponent(Label).string = e[this.curScoreBoardTab].short_name || "";
            let t = e[this.curScoreBoardTab].scores || "";
            t += e[this.curScoreBoardTab].ov || " ";
            this.scoreTabRoot.getChildByName("rate_info").getChildByName("score").getComponent(Label).string = t;
            t = "Run Rate:" + e[this.curScoreBoardTab].rate || "";
            this.scoreTabRoot.getChildByName("rate_info").getChildByName("rate").getComponent(Label).string = t;
            let i = instantiate(this.scoreBoardItem);
            this.initScoreBoardItem(i, e[this.curScoreBoardTab], this.curScoreBoardTab);
            i.active = true;
            this.scoreBoardList.content.addChild(i);
        }
        2 == this.curTab && (this.noData.active = 0 == e.length);
    }
    updateFilterList() {
        if (this.sortParamList.length > 0 && this.sortParamList[this.curSelectIdx]) {
            let t = this.sortParamList[this.curSelectIdx], e = ToolUtils.format("${0}-${1}-${2} pts", t.username, t.team_name, t.point);
            this.filterNode.getChildByName("filterBtn").getChildByName("wz").getComponent(Label).string = e;
        }
        else {
            this.filterNode.getChildByName("filterBtn").getChildByName("wz").getComponent(Label).string = "";
        }
    }
    requestLeaderBoardList(t, e = false, i = null) {
        let s = { uid: User.shared().data.uid, match_id: this.cur_matchId, session_id: t, page: 0 };
        e && Utils.shared().showLoading(10, true, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
        }), ToolUtils.getIsNormalDirection());
        let a = t;
        HttpManager.shared().doGetCommonRequest(s, HttpRequest.Yes11_EndLeaderBoard, ((t, s, o) => {
            if (Utils.shared().hideLoading(), 200 != o) {
                ToolUtils.isObjValid(this.node) && e && Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.request_fail"), 2);
            }
            else {
                try {
                    let t = ToolUtils.parseJson(s);
                    0 == t.ret ? sys.isObjectValid(t.data) && (sys.isObjectValid(this.leaderBoardInfo) || (this.leaderBoardInfo = []), this.leaderBoardInfo[a] = t.data, ToolUtils.isObjValid(this.node) && 0 == this.curTab && i && i()) : ToolUtils.isObjValid(this.node) && e && ToolUtils.isSafeString(t.desc).length > 0 && Utils.shared().showToast(t.desc, 3);
                }
                catch (t) {
                    TLog.printError("requestLeaderBoardList err:", t.toString());
                }
            }
        }));
    }
    requestWingsList(t, e = false) {
        let i = { uid: User.shared().data.uid, match_id: this.cur_matchId, session_id: t };
        e && Utils.shared().showLoading(10, true, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
        }), ToolUtils.getIsNormalDirection());
        let s = t;
        HttpManager.shared().doGetCommonRequest(i, HttpRequest.Yes11_EndWings, ((t, i, a) => {
            if (Utils.shared().hideLoading(), 200 != a) {
                ToolUtils.isObjValid(this.node) && e && Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.request_fail"), 2);
            }
            else {
                try {
                    let t = ToolUtils.parseJson(i);
                    0 == t.ret ? sys.isObjectValid(t.data) && (sys.isObjectValid(this.wingsInfo) || (this.wingsInfo = []), this.wingsInfo[s] = t.data) : ToolUtils.isObjValid(this.node) && e && ToolUtils.isSafeString(t.desc).length > 0 && Utils.shared().showToast(t.desc, 3);
                }
                catch (t) {
                    TLog.printError("requestwingsList err:", t.toString());
                }
            }
        }));
    }
    requestDetailList(t, e = false, i = null) {
        let s = { uid: User.shared().data.uid, match_id: this.cur_matchId, player_id: t };
        e && Utils.shared().showLoading(10, true, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
        }), ToolUtils.getIsNormalDirection());
        let a = t;
        HttpManager.shared().doGetCommonRequest(s, HttpRequest.Yes11_EndPlayerDetail, ((t, s, o) => {
            if (Utils.shared().hideLoading(), 200 != o) {
                ToolUtils.isObjValid(this.node) && e && Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.request_fail"), 2);
            }
            else {
                try {
                    let t = ToolUtils.parseJson(s);
                    0 == t.ret ? sys.isObjectValid(t.data) && (sys.isObjectValid(this.detailInfo) || (this.detailInfo = []), this.detailInfo[a] = t.data, ToolUtils.isObjValid(this.node) && 1 == this.curTab && i && i()) : ToolUtils.isObjValid(this.node) && e && ToolUtils.isSafeString(t.desc).length > 0 && Utils.shared().showToast(t.desc, 3);
                }
                catch (t) {
                    TLog.printError("requestDetailList err:", t.toString());
                }
            }
        }));
    }
    refreshSortView() {
        let t = this.filterNode.getChildByName("filter_scroll");
        t.getComponent(ScrollView).content.removeAllChildren();
        let e = this.filterNode.getChildByName("filter_moban"), i = 3;
        this.sortParamList.length < i && (i = this.sortParamList.length);
        for (let s = 0; s < i; s++) {
            let a = instantiate(e);
            a.active = true;
            t.getComponent(ScrollView).content.addChild(a);
            a.getChildByName("wz").getComponent(Label).string = this.sortParamList[s].team_name + "-" + String(this.sortParamList[s].point) + " pts";
            s == this.curSelectIdx ? this.updateSortItemStatus(a, 1) : this.updateSortItemStatus(a, 0);
            a.getComponent(Button).clickEvents[0].customEventData = "" + s;
            a.getComponent(Button).interactable = 1 != i;
        }
        if (this.sortParamList.length > 3) {
            let i = instantiate(e);
            i.active = true;
            t.getComponent(ScrollView).content.addChild(i);
            i.getChildByName("wz").getComponent(Label).string = "More";
            this.updateSortItemStatus(i, 0);
            i.getComponent(Button).clickEvents[0].customEventData = "-1";
        }
    }
    updateSortItemStatus(t, e) {
        ToolUtils.isObjValid(t) && (1 == e ? (t.getChildByName("ico").getComponent(Sprite).spriteFrame = this.sortBgImgs[1], t.getChildByName("wz").getComponent(Label).color = this.sort_select_color, i18nMgr.shared().changeLabelFont(t.getChildByName("wz").getComponent(Label), true)) : (t.getChildByName("ico").getComponent(Sprite).spriteFrame = this.sortBgImgs[0], t.getChildByName("wz").getComponent(Label).color = color(10, 10, 10), i18nMgr.shared().changeLabelFont(t.getChildByName("wz").getComponent(Label), false)));
    }
    requestSortParamList(t = false, e = null) {
        let i = { uid: User.shared().data.uid, match_id: this.cur_matchId };
        t && Utils.shared().showLoading(10, true, (() => {
            Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
        }), ToolUtils.getIsNormalDirection());
        HttpManager.shared().doGetCommonRequest(i, HttpRequest.Yes11_EndSortParam, ((i, s, a) => {
            if (Utils.shared().hideLoading(), 200 != a) {
                ToolUtils.isObjValid(this.node) && t && Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.request_fail"), 2);
            }
            else {
                try {
                    let i = ToolUtils.parseJson(s);
                    0 == i.ret ? sys.isObjectValid(i.data) && ToolUtils.isObjValid(this.node) && (this.sortParamList = i.data.list || [], e && e()) : ToolUtils.isObjValid(this.node) && t && ToolUtils.isSafeString(i.desc).length > 0 && Utils.shared().showToast(i.desc, 3);
                }
                catch (t) {
                    TLog.printError("requestSortParamList err:", t.toString());
                }
            }
        }));
    }
    refreshView() {
        this.noData.active = false;
        this.updateSelectView();
        this.updateTabContent();
    }
    onCloseButtonClick(t, e) {
        if (SoundManager.shared().playFx("click"), "back_btn" == e) {
            if (this._closed) {
                return;
            }
            this.onBackView();
        }
    }
    initView() {
        SportCricket_Manager.shared().cricket_curMatchId = 0;
        this.fitScreen();
    }
    onContestItemClick(t, e) {
        if (SoundManager.shared().playFx("click"), sys.now() - this._lastClick < 500) {
            return;
        }
        this._lastClick = sys.now();
        let i = ToolUtils.parseJson(e), s = i.session_id;
        sys.isObjectValid(s) && (sys.isObjectValid(this.wingsInfo) && sys.isObjectValid(this.wingsInfo[s]) || this.requestWingsList(s, false), sys.isObjectValid(this.leaderBoardInfo) && sys.isObjectValid(this.leaderBoardInfo[s]) ? Utils.shared().showSportCricket_leaderBoard({ session_id: s, match_id: this.cur_matchId, all_reward: i.all_reward, winners: i.winners, fee: i.fee, leaderBoardInfo: this.leaderBoardInfo[s], wingsInfo: this.wingsInfo ? this.wingsInfo[s] : null, topEndInfo: this.topEndInfo, target: this.node }) : this.requestLeaderBoardList(s, true, (() => {
            Utils.shared().showSportCricket_leaderBoard({ session_id: s, match_id: this.cur_matchId, all_reward: i.all_reward, winners: i.winners, fee: i.fee, leaderBoardInfo: this.leaderBoardInfo[s], wingsInfo: this.wingsInfo ? this.wingsInfo[s] : null, topEndInfo: this.topEndInfo, target: this.node });
        })));
    }
    onStatsItemClick(t, e) {
        if (SoundManager.shared().playFx("click"), sys.now() - this._lastClick < 500) {
            return;
        }
        this._lastClick = sys.now();
        let i = ToolUtils.parseJson(e), s = i.player_id;
        sys.isObjectValid(s) && (sys.isObjectValid(this.detailInfo) && sys.isObjectValid(this.detailInfo[s]) ? Utils.shared().showSportCricket_playerDetail({ playerInfo: i, detailInfo: this.detailInfo[s], targer: this }) : this.requestDetailList(s, true, (() => {
            Utils.shared().showSportCricket_playerDetail({ playerInfo: i, detailInfo: this.detailInfo[s], targer: this });
        })));
    }
    onLeaderBoardItemClick(t, e) {
        if (SoundManager.shared().playFx("click"), sys.now() - this._lastClick < 500) {
            return;
        }
        let i, s;
        this._lastClick = sys.now();
        1 == Number(e) ? (i = this.teamBItem, this._teamB_open = !this._teamB_open, s = this._teamB_open) : (i = this.teamAItem, this._teamA_open = !this._teamA_open, s = this._teamA_open);
        i.getChildByName("batsmen").active = s;
        i.getChildByName("bowling").active = s;
        s ? i.getChildByName("top").getChildByName("detailBtn").getChildByName("arrow").setRotationFromEuler(v3(0, 0, 90)) : i.getChildByName("top").getChildByName("detailBtn").getChildByName("arrow").setRotationFromEuler(v3(0, 0, -90));
    }
    onScoreTabClick(t, e) {
        SoundManager.shared().playFx("click");
        let i = Number(e);
        i != this.curScoreBoardTab && (this.curScoreBoardTab = i, this.updateScoreTabState(), this.updateScoreBoardList());
    }
    onFilterViewItemClick(t, e) {
        if (SoundManager.shared().playFx("click"), "submit" == e) {
            this.filterPopRoot.active = false;
            this.curSelectIdx = this._popfilter_selectIndex;
            let t = Number(this._popfilter_selectIndex);
            this.sortParamList[t] && (this.curSelectIdx != t && (this.requestPlayerStatsList(1 == this.curTab), this.requestScoreBoardList(2 == this.curTab)), this.curSelectIdx = t, this.updateFilterList(), this.filterList.active = false, this.filterNode.getChildByName("filterBtn").getChildByName("arrow").setRotationFromEuler(v3(0, 0, -90)));
        }
        else if ("cancel" == e) {
            this.filterPopRoot.active = false;
        }
        else {
            let t = Number(e);
            if (t != this._popfilter_selectIndex) {
                this._popfilter_selectIndex = t;
                for (let e = 0; e < this._popfilter_itemArr.length; e++) {
                    e == t ? this.updateSortItemStatus(this._popfilter_itemArr[e], 1) : this.updateSortItemStatus(this._popfilter_itemArr[e], 0);
                }
            }
        }
    }
    onSelectItemClick(t, e) {
        if (SoundManager.shared().playFx("click"), !(sys.now() - this._lastClick < 500)) {
            if (this._lastClick = sys.now(), "-1" == e) {
                this.showFilterPopView();
            }
            else {
                let t = Number(e);
                this.sortParamList[t] && (this.curSelectIdx != t && (this.requestPlayerStatsList(1 == this.curTab), this.requestScoreBoardList(2 == this.curTab)), this.curSelectIdx = t, this.updateFilterList(), this.refreshSortView(), this.filterList.active = false, this.filterNode.getChildByName("filterBtn").getChildByName("arrow").setRotationFromEuler(v3(0, 0, -90)));
            }
        }
    }
    showFilterPopView() {
        ToolUtils.showFullScreen(this.filterPopRoot.getChildByName("mask"));
        let t = this.filterPopRoot.getChildByName("main_sort").getChildByName("filter_scroll");
        t.removeAllChildren();
        this._popfilter_selectIndex = this.curSelectIdx;
        this._popfilter_itemArr = [];
        let e = this.filterPopRoot.getChildByName("main_sort").getChildByName("filter_moban"), i = this.sortParamList.length;
        for (let s = 0; s < i; s++) {
            let i = instantiate(e);
            i.active = true;
            t.addChild(i);
            i.getChildByName("wz").getComponent(Label).string = this.sortParamList[s].team_name + "-" + String(this.sortParamList[s].point) + " pts";
            s == this._popfilter_selectIndex ? this.updateSortItemStatus(i, 1) : this.updateSortItemStatus(i, 0);
            i.getComponent(Button).clickEvents[0].customEventData = "" + s;
            i.getComponent(Button).interactable = true;
            this._popfilter_itemArr.push(i);
        }
        this.filterPopRoot.active = true;
    }
    onButtonClick(t, e) {
        if (SoundManager.shared().playFx("click"), !(sys.now() - this._lastClick < 500)) {
            if (this._lastClick = sys.now(), "tab0" == e) {
                if (0 == this.curTab) {
                    return;
                }
                this.curTab = 0;
                this.updateSelectView();
                this.updateTabContent();
            }
            else if ("tab1" == e) {
                if (1 == this.curTab) {
                    return;
                }
                this.curTab = 1;
                this.updateSelectView();
                this.updateTabContent();
            }
            else if ("tab2" == e) {
                if (2 == this.curTab) {
                    return;
                }
                this.curTab = 2;
                this.updateSelectView();
                this.updateTabContent();
            }
            else if ("best_team" == e) {
                SportCricket_Manager.shared().requestYes11_showBestTeam(this.cur_matchId, 0, true, this.node);
            }
            else if ("onFilterSelect" == e) {
                if (this.filterList.active) {
                    this.filterList.active = false;
                    this.filterNode.getChildByName("filterBtn").getChildByName("arrow").setRotationFromEuler(v3(0, 0, -90));
                }
                else {
                    let t = this.sortParamList.length;
                    if (t > 0) {
                        this.filterContent.removeAllChildren();
                        for (let e = 0; e < t; e++) {
                            let t = this.sortParamList[e], i = instantiate(this.filterItem);
                            i.getChildByName("wz").getComponent(Label).string = ToolUtils.format("${0}-${1}-${2} pts", t.username, t.team_name, t.point);
                            i.getComponent(Button).clickEvents[0].customEventData = String(e);
                            i.active = true;
                            this.filterContent.addChild(i);
                        }
                    }
                    this.filterList.active = true;
                    this.filterNode.getChildByName("filterBtn").getChildByName("arrow").setRotationFromEuler(v3(0, 0, 90));
                }
            }
            else if ("sort_player" == e) {
                this.player_sort = (this.player_sort + 1) % 2;
                let t = sys.isObjectValid(this.statsInfo) && sys.isObjectValid(this.statsInfo.list) ? this.statsInfo.list : [], e = this;
                this.curStateSortType = 0;
                t.sort(((t, i) => String(t.player_name).charCodeAt(0) > String(i.player_name).charCodeAt(0) ? 1 == e.player_sort ? 1 : -1 : String(t.player_name).charCodeAt(0) < String(i.player_name).charCodeAt(0) ? 1 == e.player_sort ? -1 : 1 : 0));
                this.statsTable.reloadData(t);
                this.updateStateSortArrow();
            }
            else if ("sort_point" == e) {
                this.curStateSortType = 1;
                this.point_sort = (this.point_sort + 1) % 2;
                let t = sys.isObjectValid(this.statsInfo) && sys.isObjectValid(this.statsInfo.list) ? this.statsInfo.list : [], e = this;
                t.sort(((t, i) => Number(t.point) > Number(i.point) ? 1 == e.point_sort ? 1 : -1 : Number(t.point) < Number(i.point) ? 1 == e.point_sort ? -1 : 1 : 0));
                this.statsTable.reloadData(t);
                this.updateStateSortArrow();
            }
            else {
                "add_chip" == e && (Utils.shared().showStoreView(null, null), User.shared().updatePayScene(PhpReportDefined.pay_scene.hall_cricket));
            }
        }
    }
    updateStateSortArrow() {
        0 == this.curStateSortType ? (this.stateListFilter.getChildByName("playersBtn").getChildByName("wz").getComponent(Label).color = color(183, 0, 0), 1 == this.player_sort ? this.stateListFilter.getChildByName("playersBtn").getChildByName("arrow").getComponent(Sprite).spriteFrame = this.sortArrowImgs[2] : this.stateListFilter.getChildByName("playersBtn").getChildByName("arrow").getComponent(Sprite).spriteFrame = this.sortArrowImgs[1], this.stateListFilter.getChildByName("playersBtn").getChildByName("arrow").getComponent(Sprite).color = color(255, 255, 255), this.stateListFilter.getChildByName("pointsBtn").getChildByName("arrow").getComponent(Sprite).spriteFrame = this.sortArrowImgs[0], this.stateListFilter.getChildByName("pointsBtn").getChildByName("arrow").getComponent(Sprite).color = color(102, 102, 102), this.stateListFilter.getChildByName("pointsBtn").getChildByName("wz").getComponent(Label).color = color(102, 102, 102)) : (this.stateListFilter.getChildByName("pointsBtn").getChildByName("wz").getComponent(Label).color = color(183, 0, 0), 1 == this.point_sort ? this.stateListFilter.getChildByName("pointsBtn").getChildByName("arrow").getComponent(Sprite).spriteFrame = this.sortArrowImgs[2] : this.stateListFilter.getChildByName("pointsBtn").getChildByName("arrow").getComponent(Sprite).spriteFrame = this.sortArrowImgs[1], this.stateListFilter.getChildByName("pointsBtn").getChildByName("arrow").getComponent(Sprite).color = color(255, 255, 255), this.stateListFilter.getChildByName("playersBtn").getChildByName("arrow").getComponent(Sprite).spriteFrame = this.sortArrowImgs[0], this.stateListFilter.getChildByName("playersBtn").getChildByName("arrow").getComponent(Sprite).color = color(102, 102, 102), this.stateListFilter.getChildByName("playersBtn").getChildByName("wz").getComponent(Label).color = color(102, 102, 102));
    }
    onStateFilterSelect(t, e) {
        SoundManager.shared().playFx("click");
    }
    onBackView(t = true) {
        t && (Utils.shared().hideLoading(), this._exit_cb && this._exit_cb(), this.bShowPushAnim ? (this._closed = true, ToolUtils.showPushAnim(this.node, 1, (() => {
            ToolUtils.isObjValid(this.node) && this.node.destroy();
        }))) : ToolUtils.isObjValid(this.node) && this.node.destroy());
    }
    fitScreen() {
        let t = ToolUtils.adaptSafeArea(this.rootNode), e = view.getVisibleSize();
        this.node.getComponent(UITransform).setContentSize(e.width, e.height);
        let i = sys.getSafeAreaRect().y;
        if (0 != i) {
            this.myContestList.getComponent(Widget).bottom = -i;
            this.statsList.getComponent(Widget).bottom = -i;
            this.scoreBoardList.getComponent(Widget).bottom = -i;
            let s = this.myContestList.getComponent(UITransform).contentSize, a = e.height - GameConfig.CONFIG_SCREEN_HEIGHT + s.height - i + t;
            this.myContestList.getComponent(UITransform).contentSize = size(s.width, a);
            s = this.statsList.getComponent(UITransform).contentSize;
            a = e.height - GameConfig.CONFIG_SCREEN_HEIGHT + s.height - i + t;
            this.statsList.getComponent(UITransform).contentSize = size(s.width, a);
            s = this.scoreBoardList.getComponent(UITransform).contentSize;
            a = e.height - GameConfig.CONFIG_SCREEN_HEIGHT + s.height - i + t;
            this.scoreBoardList.getComponent(UITransform).contentSize = size(s.width, a);
        }
    }
}
