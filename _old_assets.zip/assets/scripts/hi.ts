// @ts-nocheck
// Recovered from index.js:3
const s = window;
export const languages = {};
(s.languages || (s.languages = {}));
(s.languages.hi = languages);
