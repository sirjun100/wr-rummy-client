// @ts-nocheck
// Recovered from index.js:605
import { _decorator, Button, instantiate, Label, Node, Sprite, SpriteFrame, sys } from "cc";
import Parent from "./Parent";
import { TLog } from "./TLog";
import SoundManager from "./SoundManager";
import User from "./User";
import PushEvent from "./PushEvent";
import PushCenter from "./PushCenter";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("StoreCash")
export class StoreCash extends Parent {
    public TAG: string = "StoreCash";
    @property(Node)
    public cash_moban: Node = null;
    @property(Node)
    public cashlayout: Node = null;
    @property([SpriteFrame])
    public cashIconArr: SpriteFrame[] = [];
    public lastPayTime: number = 0;
    public pway: string = "";
    public hasPay: boolean = false;
    public _cashItems: any[] = [];
    public _showCashShopList: any[] = [];
    public exe: any = null;
    public _linkId: number = 0;
    public _rep_act_id: any = undefined;
    public _isShowActTips: number = 0;
    public _curSelCouponId: number = 0;
    public _curAutoBestSelStatus: boolean = false;
    start() {
    }
    setCashParaData(t) {
        sys.isObjectValid(t) && (this.exe = t, sys.isObjectValid(this.exe.link_id) && (this._linkId = this.exe.link_id), sys.isObjectValid(this.exe.rep_act_id) && (this._rep_act_id = this.exe.rep_act_id), sys.isObjectValid(this.exe.isShowActTips) && (this._isShowActTips = this.exe.isShowActTips));
    }
    setIsShowActTips(t) {
        this._isShowActTips = t;
    }
    setCurSelCouponId(t, e, i = true) {
        this._curSelCouponId = t || 0;
        this._curAutoBestSelStatus = e;
        i && this.updateAddUI();
    }
    setCashShopData(t) {
        this._showCashShopList = Array.isArray(t) ? t : [];
        this.refreshCashShopView();
    }
    refreshCashShopView() {
        if (this.cash_moban.active = false, this._showCashShopList && this._showCashShopList.length) {
            this._cashItems = [];
            this.cashlayout.removeAllChildren();
            for (let t = 0, e = this._showCashShopList.length; t < e; t++) {
                let e = instantiate(this.cash_moban);
                this.initCashMoban(e, this._showCashShopList[t]);
                e.active = true;
                this.cashlayout.addChild(e);
                this._cashItems.push(e);
            }
        }
        this.updateAddUI();
    }
    initCashMoban(t, e) {
        let i = t.getChildByName("icon"), s = t.getChildByName("pay_btn");
        i.getComponent(Sprite).spriteFrame = this.cashIconArr[e.icon_id - 1];
        s.getChildByName("num").getComponent(Label).string = " ₹" + e.price || "";
        s.getComponent(Button).clickEvents[0].customEventData = ToolUtils.toJsonString(e);
    }
    updateAddUI() {
        if (Array.isArray(this._cashItems) && !(this._cashItems.length < 1)) {
            for (let t = 0; t < this._cashItems.length; t++) {
                let e = this._cashItems[t];
                if (!sys.isObjectValid(e)) {
                    TLog.printError(this.TAG, "updateAddUI item is null", t);
                    continue;
                }
                let i = e.getChildByName("best"), s = e.getChildByName("rate"), a = e.getChildByName("bonus"), h = e.getChildByName("cash"), o = "", n = "", c = this._showCashShopList[t].price || 0, l = this.getAddValue(t);
                i.active = 1 == this._showCashShopList[t].best && (0 != this._curSelCouponId || this._curAutoBestSelStatus);
                s.active = l.cash > 0 || l.bonus > 0;
                a.active = l.bonus > 0;
                h.active = l.cash + c > 0;
                l.bonus > 0 && (o = ToolUtils.format("${0}", l.bonus));
                l.cash + c > 0 && (n = ToolUtils.format("${0}", l.cash + c));
                a.getChildByName("num").getComponent(Label).string = o;
                h.getChildByName("num").getComponent(Label).string = n;
                a.getChildByName("num").getComponent(Label).updateRenderData(true);
                h.getChildByName("num").getComponent(Label).updateRenderData(true);
                s.getChildByName("tx").getComponent(Label).string = l.ratio_text || "";
            }
        }
    }
    getAddValue(t) {
        let e = 0, i = 0, s = "", a = this.getCouponList(t);
        for (let t = 0; t < a.length && 1 == a[t].sta; t++) {
            this._curAutoBestSelStatus ? a[t].is_best && 1 == a[t].is_best && (e = a[t].add_bonus < a[t].max ? a[t].add_bonus : a[t].max, i = a[t].add_cash, s = a[t].rate_text) : this._curSelCouponId && Number(a[t].id) == this._curSelCouponId && (e = a[t].add_bonus < a[t].max ? a[t].add_bonus : a[t].max, i = a[t].add_cash, s = a[t].rate_text);
        }
        return { bonus: e || 0, cash: i || 0, ratio_text: s || "" };
    }
    getCouponList(t) {
        if (Array.isArray(this._showCashShopList)) {
            let e = this._showCashShopList[t];
            if (Array.isArray(e.coupon)) {
                return e.coupon || [];
            }
        }
        return [];
    }
    setBgSize(t) {
    }
    payBtnClick(t, e) {
        if (SoundManager.shared().playFx("click"), User.shared().checkCanRecharge()) {
            try {
                let t = ToolUtils.parseJson(e);
                if (t) {
                    let e = sys.now();
                    if (this.hasPay && e - this.lastPayTime <= 3) {
                        return;
                    }
                    let i = 0;
                    if (this._curAutoBestSelStatus) {
                        for (let e = 0; e < t.coupon.length; e++) {
                            if (1 == t.coupon[e].sta && t.coupon[e].is_best && 1 == t.coupon[e].is_best) {
                                i = Number(t.coupon[e].id);
                                break;
                            }
                        }
                    }
                    else if (this._curSelCouponId) {
                        for (let e = 0; e < t.coupon.length; e++) {
                            if (1 == t.coupon[e].sta && Number(t.coupon[e].id) == this._curSelCouponId) {
                                i = Number(t.coupon[e].id);
                                break;
                            }
                        }
                    }
                    if (i < 0) {
                        return void TLog.printError(this.TAG, "recCouponId error:", this._curSelCouponId, this._curAutoBestSelStatus);
                    }
                    if (0 == Number(t.price)) {
                        return;
                    }
                    this.lastPayTime = e;
                    this.hasPay = true;
                    let s = "";
                    sys.isObjectValid(this.exe) && sys.isObjectValid(this.exe.tid_key) && (s = this.exe.tid_key);
                    let a = { pway: this.pway, coupon_id: i, price: Number(t.price), tid_key: s, scene: 3 };
                    sys.isObjectValid(this._rep_act_id) && (a.act_id = this._rep_act_id);
                    0 == i && sys.isObjectValid(this.exe) && sys.isObjectValid(this.exe.act_id) && (a.act_id = this.exe.act_id, a.tips = this._isShowActTips, sys.isObjectValid(this.exe.act_type) && (a.act_type = this.exe.act_type), sys.isObjectValid(this.exe.event) && (a.event = this.exe.event), sys.isObjectValid(this.exe.client_time) && (a.client_time = this.exe.client_time));
                    this._rep_act_id && sys.isObjectValid(this.exe) && sys.isObjectValid(this.exe.client_time) && (this._rep_act_id != PushEvent.JUMP_TO_SuperVip && this._rep_act_id != PushEvent.JUMP_TO_NEW_NOVICESTASK || (a.client_time = this.exe.client_time));
                    this._linkId > 0 && (a.link_id = this._linkId);
                    User.shared().startPay(a, 1);
                }
            }
            catch (t) {
            }
        }
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().removeListenersByTag(this);
        this.unscheduleAllCallbacks();
    }
}
