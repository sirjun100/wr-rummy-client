// @ts-nocheck
// Recovered from index.js:63
import { _decorator, EditBox, HorizontalTextAlignment, Label, Node, UITransform, view, Widget } from "cc";
import SoundManager from "./SoundManager";
import HttpManager from "./HttpManager";
import PushCenter from "./PushCenter";
import GameConfig from "./GameConfig";
import Utils from "./Utils";
import BaseLayer from "./BaseLayer";
import i18nMgr from "./i18nMgr";
import User from "./User";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("ChangeNamePrefabs")
export class ChangeNamePrefabs extends BaseLayer {
    @property(Node)
    public content_root: Node = null;
    @property(Node)
    public edit_name: Node = null;
    @property(Label)
    public input_num: Label = null;
    @property(Node)
    public btn_delete: Node = null;
    @property(Node)
    public btn_submit: Node = null;
    public _cb: any = null;
    public bShowPushAnim: boolean = false;
    public _closed: boolean = false;
    public showUICallback: any = null;
    init(t, e = null) {
        this.bShowPushAnim = t;
        this.showUICallback = e;
    }
    start() {
        super.start();
        this.node.getComponent(UITransform).setContentSize(view.getVisibleSize());
        this.bShowPushAnim ? ToolUtils.showPushAnim(this.node, 0, (() => {
            this.showUICallback && this.showUICallback();
            this.initView();
        })) : (this.showUICallback && this.showUICallback(), this.initView());
        this.fitScreen();
        this.dealMultipleLanguages();
    }
    dealMultipleLanguages() {
        if (3 == i18nMgr.shared().language) {
            this.content_root.getChildByName("tips").getComponent(Label).horizontalAlign = HorizontalTextAlignment.RIGHT;
            this.content_root.getChildByName("tips").getComponent(Label).fontSize = 22;
            let t = this.content_root.getChildByName("tips").getComponent(Widget).left;
            this.content_root.getChildByName("tips").getComponent(Widget).left = t + 32;
        }
    }
    setCloseCallBack(t) {
        this._cb = t;
    }
    initView() {
        this.edit_name.getComponent(EditBox).string = User.shared().data.name;
        this.edit_name.getComponent(EditBox).focus();
        this.updateClearStatus();
    }
    updateClearStatus() {
        let t = ToolUtils.isSafeString(this.edit_name.getComponent(EditBox).string);
        t.length > 0 ? this.btn_delete.active = true : this.btn_delete.active = false;
        this.input_num.string = t.length + "/20";
    }
    onEditBoxEnded(t, e) {
        this.updateClearStatus();
    }
    onEditBoxChanged(t, e, i) {
        this.updateClearStatus();
    }
    onBtnByClick(t, e) {
        if (SoundManager.shared().playFx("click"), "close" == e) {
            if (this._closed) {
                return;
            }
            this.onBackView();
        }
        else if ("submit" == e) {
            let t = ToolUtils.isSafeString(this.edit_name.getComponent(EditBox).string);
            if (t.length < 6) {
                return void Utils.shared().showToast(i18nMgr.shared().getValueByKey("userinfo.change_name_fail"), 2);
            }
            if (User.shared().data.name == t) {
                return void this.onBackView();
            }
            HttpManager.shared().doChangeNameRequist(t, this.listenChangeNameCall.bind(this));
        }
        else {
            "clear" == e && (this.edit_name.getComponent(EditBox).string = "", this.edit_name.getComponent(EditBox).blur(), this.updateClearStatus());
        }
    }
    listenChangeNameCall(t, e, i) {
        if (0 != e.length) {
            if (200 != i) {
                alert("The login timed out, please try again");
            }
            else {
                let t = ToolUtils.parseJson(e);
                0 == t.ret && (User.shared().data.name = t.data.name, User.shared().can_update_nick_name = 0, PushCenter.shared().pushEvent(GameConfig.Update_Name, User.shared().data.name));
                ToolUtils.isObjValid(this.node) && (t.desc && t.desc.length > 0 && Utils.shared().showToast(t.desc, 3), this.onBackView());
            }
        }
    }
    fitScreen() {
        this.content_root.getChildByName("submit_btn") && this.setUiEdgeDistance(this.content_root.getChildByName("submit_btn"), 68, 3, false);
        ToolUtils.adaptSafeArea(this.content_root);
    }
    onBackView() {
        this.bShowPushAnim ? (this._cb && this._cb(), this._closed = true, ToolUtils.showPushAnim(this.node, 1, (() => {
            ToolUtils.isObjValid(this.node) && this.node.destroy();
        }))) : (this._cb && this._cb(), ToolUtils.isObjValid(this.node) && this.node.destroy());
    }
}
