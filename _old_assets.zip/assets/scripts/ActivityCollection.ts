// @ts-nocheck
// Recovered from index.js:5
import { _decorator, Component, Button, instantiate, Label, Node, size, Sprite, SpriteFrame, sys, UITransform, v3, Vec3, Widget } from "cc";
import SoundManager from "./SoundManager";
import User from "./User";
import { TLog } from "./TLog";
import Utils from "./Utils";
import TweenTool from "./TweenTool";
import PushEvent from "./PushEvent";
import HttpManager from "./HttpManager";
import ReportConfig from "./ReportConfig";
import i18nMgr from "./i18nMgr";
import PushCenter from "./PushCenter";
import { TransferPlatform } from "./TransferPlatform";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("ActivityCollection")
export class ActivityCollection extends Component {
    public TAG: string = "ActivityCollection";
    @property(Node)
    public mobanNew: Node = null;
    @property(Node)
    public popNodeNew: Node = null;
    @property([SpriteFrame])
    public actEntImgs: SpriteFrame[] = [];
    @property(Node)
    public btn_videoNode: Node = null;
    @property(Node)
    public btn_boxNode: Node = null;
    @property(Node)
    public tab_actNode: Node = null;
    @property(Node)
    public actAnimListViewNew: Node = null;
    @property(Node)
    public act_node: Node = null;
    public _items: any[] = [];
    public lastClick: number = 0;
    public _popNodeActive: boolean = false;
    public _animNodes: Map = new Map;
    public _skeletonData: any = {};
    public _choose_game_type: number = 0;
    public _luckyboxChaocaoIndex: number = 0;
    public _lastRefreshType: any = -1;
    public _bFresh: boolean = false;
    public exe_act_collect_open_md5: any = null;
    public act_collect_open_md5: any = null;
    public hasCheckActData: boolean = false;
    onLoad() {
        this.popNodeNew.active = false;
        this.mobanNew.active = false;
        this._popNodeActive = false;
        PushCenter.shared().addListener(PushEvent.RefreshAdVideoSwitch, (t => {
            ToolUtils.isObjValid(this.node) && ToolUtils.isObjValid(this.btn_videoNode) && this.refreshVideoSwitch();
        }), this);
        PushCenter.shared().addListener(PushEvent.InMatchChooseGameCloseAct, (t => {
            ToolUtils.isObjValid(this.node) && (this._choose_game_type = t, ToolUtils.isObjValid(this.btn_videoNode) && this.refreshVideoSwitch(), this.refreshBoxSwitch());
        }), this);
        PushCenter.shared().addListener(PushEvent.RefreshActCollStatus, (t => {
            if (ToolUtils.isObjValid(this.node)) {
                if (1 == t || 3 == t) {
                    return;
                }
                (3 == t && 1 != this._lastRefreshType || 3 != t && 0 != this._lastRefreshType) && this.updateActivityCollection();
            }
        }), this);
        this.refreshBoxSwitch();
        ToolUtils.isPadPlatform() || (this.act_node.getComponent(Widget).bottom = 131 - sys.getSafeAreaRect().y);
    }
    start() {
        this._bFresh = true;
        this.updateActivityCollection();
    }
    refreshVideoSwitch() {
        ToolUtils.isObjValid(this.btn_videoNode) && (this.btn_videoNode.active = false);
    }
    refreshBoxSwitch() {
        let t = false, e = this.btn_boxNode.getChildByName("mask"), i = this.btn_boxNode.getChildByName("name");
        if (e.active = i.active = false, 1 == User.shared().choose_game_type) {
            this.btn_boxNode.active = false;
            this.popNodeNew.active = false;
        }
        else if (sys.isObjectValid(User.shared().data.act_collect_open) && sys.isObjectValid(User.shared().data.act_collect_open.list) && User.shared().data.act_collect_open.list.length > 0 ? (t = true, this.btn_boxNode.active = true, e.active = true, Utils.shared().actNodePos = this.btn_boxNode.worldPosition) : this.btn_boxNode.active = false, this.popNodeNew.active = this._popNodeActive, t) {
            i.active = false;
            Array.isArray(e.children) && e.children.length > 0 && e.removeAllChildren();
            TweenTool.stopNodeAction(e);
            i.getComponent(Label).updateRenderData(true);
            let t = i.getComponent(UITransform).width;
            if (t > 90) {
                for (let o = 0; o < 2; o++) {
                    let a = instantiate(i);
                    a.active = true;
                    let s = (t - 90) / 2 + o * (t + 10);
                    a.setPosition(v3(s, 14));
                    e.addChild(a);
                }
                TweenTool.commonSchedule(e, 0.03, (() => {
                    let i = e.children;
                    if (sys.isObjectValid(i)) {
                        for (let e = 0, o = i.length; e < o; e++) {
                            let o = new Vec3;
                            i[e].getPosition(o);
                            i[e].setPosition(v3(o.x - 1.2, 14));
                            o.x < -(90 + t) / 2 - 15 && i[e].setPosition(v3((t - 90) / 2 + (t + 10), 14));
                        }
                    }
                }));
            }
            else {
                let t = instantiate(i);
                t.active = true;
                t.setPosition(v3(0, 14));
                e.addChild(t);
            }
        }
    }
    onDestroy() {
        PushCenter.shared().removeListenersByTag(this);
    }
    onEnable() {
        this.refreshVideoSwitch();
        this.node.on(Node.EventType.TOUCH_START, this.onTouchStart, this);
        this.node.on(Node.EventType.TOUCH_MOVE, this.onTouchMove, this);
        this.node.on(Node.EventType.TOUCH_END, this.onTouchEnd, this);
        this.node.on(Node.EventType.TOUCH_CANCEL, this.onTouchCancel, this);
    }
    onDisable() {
        this.node.off(Node.EventType.TOUCH_START, this.onTouchStart, this);
        this.node.off(Node.EventType.TOUCH_MOVE, this.onTouchMove, this);
        this.node.off(Node.EventType.TOUCH_END, this.onTouchEnd, this);
        this.node.off(Node.EventType.TOUCH_CANCEL, this.onTouchCancel, this);
        ToolUtils.isObjValid(this.node) && this.popNodeNew.active && this.changePopNodeActive(false);
    }
    onTouchStart(t) {
        t.preventSwallow = true;
    }
    onTouchMove(t) {
        t.preventSwallow = true;
    }
    onTouchEnd(t) {
        t.preventSwallow = true;
        ToolUtils.isObjValid(this.node) && this.popNodeNew.active && this.changePopNodeActive(false);
    }
    onTouchCancel(t) {
        t.preventSwallow = true;
    }
    updateActForCash() {
        try {
            let t = this.actAnimListViewNew.getChildByName("view").getChildByName("content"), e = this.popNodeNew.getChildByName("bg");
            if (Array.isArray(t.children) && t.children.length > 0 && t.removeAllChildren(), this.refreshBoxSwitch(), this.act_collect_open_md5 = ToolUtils.jsonToMd5(User.shared().data.act_collect_open), sys.isObjectValid(User.shared().data.act_collect_open)) {
                let i = 0;
                if (sys.isObjectValid(User.shared().data.act_collect_open.list) && User.shared().data.act_collect_open.list.length > 0 && (i = User.shared().data.act_collect_open.list.length), i > 0) {
                    let o = 30, a = 10, s = 110, n = 20, c = 610, l = 20, h = i < 6 ? o - 6 : -s / 3 - 14;
                    this.popNodeNew.active = true;
                    let r = n + i * s + (i - 1) * a;
                    if (t && (t.getComponent(UITransform).contentSize = size(130, r)), r <= c ? (this.actAnimListViewNew.getComponent(UITransform).contentSize = size(130, r), this.actAnimListViewNew.getChildByName("view").getComponent(UITransform).contentSize = size(130, r), t.setPosition(0, r)) : (this.actAnimListViewNew.getComponent(UITransform).contentSize = size(130, c), this.actAnimListViewNew.getChildByName("view").getComponent(UITransform).contentSize = size(130, c), t.setPosition(0, c)), e) {
                        let t = i < 6 ? i * s + (i - 1) * a + l : 6 * s + 5 * a - l;
                        e.getComponent(UITransform).contentSize = size(130, t + h);
                    }
                    for (let e, o = 0; o < i; o++) {
                        e = this._items[o];
                        ToolUtils.isObjValid(e) ? (e.setPosition(0, -(n + s / 2 + o * (a + s))), t.addChild(e)) : (e = instantiate(this.mobanNew), e.setPosition(0, -(n + s / 2 + o * (a + s))), t.addChild(e), this._items.push(e));
                        ToolUtils.isObjValid(e) ? (e.active = true, this.initCurMobanCallBack(e, User.shared().data.act_collect_open.list[o])) : TLog.printError("ActivityCollection moban is nil:", o);
                    }
                    for (; this._items.length > i;) {
                        let t = this._items.length;
                        this._items[t - 1].removeFromParent();
                        this._items.splice(t - 1, 1);
                    }
                }
                else {
                    this.popNodeNew.active = false;
                }
                this.changePopNodeActive(this._popNodeActive);
            }
            this.refreshVideoSwitch();
        }
        catch (t) {
            TLog.printError("ActivityCollection trycatch updateActivityCollection:", t);
        }
    }
    updateActForChip() {
        try {
            let t = this.actAnimListViewNew.getChildByName("view").getChildByName("content"), e = this.popNodeNew.getChildByName("bg");
            if (Array.isArray(t.children) && t.children.length > 0 && t.removeAllChildren(), this.refreshBoxSwitch(), this.exe_act_collect_open_md5 = ToolUtils.jsonToMd5(User.shared().data.exe_act_collect_open), sys.isObjectValid(User.shared().data.exe_act_collect_open)) {
                let i = 0;
                if (sys.isObjectValid(User.shared().data.exe_act_collect_open.list) && User.shared().data.exe_act_collect_open.list.length > 0 && (i = User.shared().data.exe_act_collect_open.list.length), i > 0) {
                    let o = 30, a = 10, s = 97, n = 10, c = 570, l = i < 6 ? o - 6 : -s / 3 - 14;
                    this.popNodeNew.active = true;
                    let h = n + i * s + (i - 1) * a;
                    if (t && (t.getComponent(UITransform).contentSize = size(110, h)), h <= c ? (this.actAnimListViewNew.getComponent(UITransform).contentSize = size(110, h), this.actAnimListViewNew.getChildByName("view").getComponent(UITransform).contentSize = size(110, h), t.setPosition(0, h)) : (this.actAnimListViewNew.getComponent(UITransform).contentSize = size(110, c), this.actAnimListViewNew.getChildByName("view").getComponent(UITransform).contentSize = size(110, c), t.setPosition(0, c)), e) {
                        let t = i < 6 ? i * s + (i - 1) * a : 6 * s + 5 * a;
                        e.getComponent(UITransform).contentSize = size(110, t + l);
                    }
                    for (let e, o = 0; o < i; o++) {
                        e = this._items[o];
                        ToolUtils.isObjValid(e) ? (e.setPosition(0, -(n + s / 2 + o * (a + s))), t.addChild(e)) : (e = instantiate(this.mobanNew), e.setPosition(0, -(n + s / 2 + o * (a + s))), t.addChild(e), this._items.push(e));
                        ToolUtils.isObjValid(e) ? (e.active = true, this.initCurMobanCallBack(e, User.shared().data.exe_act_collect_open.list[o])) : TLog.printError("ActivityCollection moban is nil:", o);
                    }
                    for (; this._items.length > i;) {
                        let t = this._items.length;
                        this._items[t - 1].removeFromParent();
                        this._items.splice(t - 1, 1);
                    }
                }
                else {
                    this.popNodeNew.active = false;
                }
                this.changePopNodeActive(this._popNodeActive);
            }
            this.refreshVideoSwitch();
        }
        catch (t) {
            TLog.printError("ActivityCollection trycatch updateActivityCollection:", t);
        }
    }
    updateTabActNodeUI() {
        var t, e;
        let i = false;
        sys.isObjectValid(null == (t = User.shared().data.act_collect_open) ? undefined : t.tab_act) && (null == (e = User.shared().data.act_collect_open.tab_act) ? undefined : e.act_id) > 0 && (i = true);
        i && (i = 0 === User.shared().choose_game_type);
        ToolUtils.isObjValid(this.tab_actNode) && (this.tab_actNode.active = i || false);
        i && User.shared().data.act_collect_open.tab_act && (this.initCurMobanCallBack(this.tab_actNode, User.shared().data.act_collect_open.tab_act), sys.isObjectValid(User.shared().data.act_collect_open.tab_act.act_id) && User.shared().checkTargetRequestActData(ToolUtils.isSafeNumber(Number(User.shared().data.act_collect_open.tab_act.act_id))));
    }
    updateActivityCollection() {
        if (!ToolUtils.isObjValid(this.node) || !this.node.active) {
            return;
        }
        if (1 != User.shared().choose_game_type && sys.isObjectValid(User.shared().data.act_collect_open) && sys.isObjectValid(User.shared().data.act_collect_open.list) && User.shared().data.act_collect_open.list.length > 0 && (this.btn_boxNode.active = true), (3 == User.shared().choose_game_type && 0 == this._lastRefreshType || 3 != User.shared().choose_game_type && 1 == this._lastRefreshType) && (this._bFresh = true), !this._bFresh) {
            return;
        }
        this._bFresh = false;
        TweenTool.delayAct(this.node, (() => {
            this._bFresh = true;
        }), 0.2, true);
        let t = true;
        if (0 == this._lastRefreshType && sys.isObjectValid(this.act_collect_open_md5)) {
            let e = ToolUtils.jsonToMd5(User.shared().data.act_collect_open);
            this.act_collect_open_md5 == e && (t = false);
        }
        this._lastRefreshType = 0;
        t ? this.updateActForCash() : this.changePopNodeActive(this._popNodeActive);
    }
    initCurMobanCallBack(t, e) {
        t.getComponent(Button).clickEvents[0].customEventData = e;
        t.getChildByName("redpot").active = 1 == e.has_red;
        let i = t.getChildByName("discount");
        i.active = false;
        sys.isObjectValid(e.percent) && (i.active = true, i.getChildByName("wz").getComponent(Label).string = e.percent);
        let o = t.getChildByName("time_left");
        o.active = false;
        t.getChildByName("num").active = false;
        t.getChildByName("gou").active = false;
        TweenTool.stopNodeAction(o);
        sys.isObjectValid(e.time_left) && (o.active = true, o.getChildByName("wz").getComponent(Label).string = Utils.shared().parseCountDown(e.time_left), TweenTool.myschedule(o, 1, (() => {
            ToolUtils.isObjValid(this.node) && (e.time_left > 0 ? (e.time_left = e.time_left - 1, o.getChildByName("wz").getComponent(Label).string = Utils.shared().parseCountDown(e.time_left)) : (User.shared().getHallInfo(), TweenTool.stopNodeAction(o)));
        })));
        let a = t.getChildByName("mask"), s = t.getChildByName("name");
        s.active = false;
        let n = t.getChildByName("ico").getComponent(Sprite);
        switch (Number(e.act_id)) {
            case PushEvent.JUMP_TO_SCLB:
                this.actEntImgs[4] && (n.spriteFrame = this.actEntImgs[4]), s.getComponent(Label).string = i18nMgr.shared().getValueByKey("first_recharge_text.welcome_bonus");
                break;
            case PushEvent.JUMP_TO_TwentyFourRecharge:
                this.actEntImgs[0] && (n.spriteFrame = this.actEntImgs[0]), s.getComponent(Label).string = i18nMgr.shared().getValueByKey("first_recharge_text.twentyhour_act_title");
                break;
            case PushEvent.JUMP_TO_BuyOneGetThree:
                this.actEntImgs[1] && (n.spriteFrame = this.actEntImgs[1]), s.getComponent(Label).string = i18nMgr.shared().getValueByKey("buyonegetthree.act_coll_title");
                break;
            case PushEvent.JUMP_TO_DAILYLOGIN:
                this.actEntImgs[3] && (n.spriteFrame = this.actEntImgs[3]), s.getComponent(Label).string = i18nMgr.shared().getValueByKey("dailylogin.title");
                break;
            case PushEvent.JUMP_TO_NEW_NOVICESTASK:
                this.actEntImgs[2] && (n.spriteFrame = this.actEntImgs[2]), s.getComponent(Label).string = i18nMgr.shared().getValueByKey("novices.novices_task");
                break;
            case PushEvent.JUMP_TO_RestartGift:
                this.actEntImgs[5] && (n.spriteFrame = this.actEntImgs[5]), s.getComponent(Label).string = "RESTART GIFT";
                break;
            case PushEvent.JUMP_TO_ConsecutiveGift:
                this.actEntImgs[6] && (n.spriteFrame = this.actEntImgs[6]), s.getComponent(Label).string = "ENDLESS BENEFITS";
                break;
            case PushEvent.JUMP_TO_Adventrue:
                this.actEntImgs[7] && (n.spriteFrame = this.actEntImgs[7]), s.getComponent(Label).string = "ADVENTURE BONUS";
                break;
            case PushEvent.JUMP_TO_WEEK_MONTH:
                this.actEntImgs[8] && (n.spriteFrame = this.actEntImgs[8]), s.getComponent(Label).string = "GOOD VALUE OFFER";
                break;
            case PushEvent.JUMP_TO_BACKCARDTASK:
                this.actEntImgs[9] && (n.spriteFrame = this.actEntImgs[9]), s.getComponent(Label).string = "WELCOME BACK";
                break;
            case PushEvent.JUMP_TO_Gullak:
                this.actEntImgs[10] && (n.spriteFrame = this.actEntImgs[10]), s.getComponent(Label).string = i18nMgr.shared().getValueByKey("gullak.gullak");
                break;
            case PushEvent.JUMP_TO_TREASURE_HUNT:
                this.actEntImgs[11] && (n.spriteFrame = this.actEntImgs[11]), s.getComponent(Label).string = "TREASURE HUNT";
                break;
            case PushEvent.JUMP_TO_Act_FlopCash: this.actEntImgs[12] && (n.spriteFrame = this.actEntImgs[12]), s.getComponent(Label).string = "FLOP FOR CASH";
        }
        Array.isArray(a.children) && a.children.length > 0 && a.removeAllChildren();
        TweenTool.stopNodeAction(a);
        s.getComponent(Label).updateRenderData(true);
        let c = s.getComponent(UITransform).width;
        if (c > 90) {
            for (let t = 0; t < 2; t++) {
                let e = instantiate(s);
                e.active = true;
                let i = (c - 90) / 2 + t * (c + 10);
                e.setPosition(v3(i, 0));
                a.addChild(e);
            }
            TweenTool.commonSchedule(a, 0.03, (() => {
                let t = a.children;
                if (sys.isObjectValid(t)) {
                    for (let e = 0, i = t.length; e < i; e++) {
                        let i = new Vec3;
                        t[e].getPosition(i);
                        t[e].setPosition(v3(i.x - 1.2, 0));
                        i.x < -(90 + c) / 2 - 15 && t[e].setPosition(v3((c - 90) / 2 + (c + 10), 0));
                    }
                }
            }));
        }
        else {
            let t = instantiate(s);
            t.active = true;
            t.setPosition(v3(0, 0));
            a.addChild(t);
        }
    }
    onButtonClick(t, e) {
        if (SoundManager.shared().playFx("click"), "box" == e) {
            let t = this.popNodeNew.active;
            if (!t) {
                if (3 == User.shared().choose_game_type) {
                    if (1 == User.shared().s_uirp_4 && sys.isObjectValid(User.shared().data.exe_act_collect_open.list) && User.shared().data.act_collect_open.list.length > 0) {
                        let t = [];
                        for (let e = 0, i = User.shared().data.exe_act_collect_open.list.length; e < i; e++) {
                            t.push(User.shared().data.exe_act_collect_open.list[e]);
                        }
                        HttpManager.shared().doGetBannerShowRequest(ReportConfig.Cmd_UICollectReport, t, ((t, e, i) => {
                        }));
                    }
                }
                else if (1 == User.shared().s_uirp_4 && sys.isObjectValid(User.shared().data.act_collect_open.list) && User.shared().data.act_collect_open.list.length > 0) {
                    let t = [];
                    for (let e = 0, i = User.shared().data.act_collect_open.list.length; e < i; e++) {
                        t.push(User.shared().data.act_collect_open.list[e]);
                    }
                    HttpManager.shared().doGetBannerShowRequest(ReportConfig.Cmd_UICollectReport, t, ((t, e, i) => {
                    }));
                }
                this.hasCheckActData || (this.hasCheckActData = true, User.shared().checkPreRequestActData());
            }
            this.changePopNodeActive(!t, true);
            t || HttpManager.shared().doSdkApiReport({ scene: ReportConfig.scece.Hall, func: ReportConfig.func.Hall, event: ReportConfig.hall_evt.click_recharge_events });
        }
        else if ("video" == e) {
            Utils.shared().doJumpLogic(PushEvent.JUMP_TO_AdVideo, { from_source: 1 });
        }
        else {
            if (sys.now() - this.lastClick < 1000) {
                return;
            }
            this.lastClick = sys.now();
            let t = e.ext, i = 1;
            sys.isObjectValid(t) || (t = {});
            e.act_id == PushEvent.JUMP_TO_Adventrue ? t.from_source = 1 : e.act_id == PushEvent.JUMP_TO_FREECASH ? t.from_source = 6 : e.act_id == PushEvent.JUMP_TO_BANKRUPTCARD && (i = 2);
            Utils.shared().doJumpLogic(e.act_id, t, { reportEvtId: i, link_id: sys.now() });
            this.changePopNodeActive(false);
            let o = "ClickActivityCollection_" + e.act_id;
            TransferPlatform.shared().logEvent_firebase(o);
        }
    }
    changePopNodeActive(t, e) {
        this.popNodeNew.active = t;
        this._popNodeActive = t;
        User.shared().hall_box_active = t;
        User.shared().hall_box_click = e;
    }
}
