import RobotAvatar from "./RobotAvatar";
// @ts-nocheck
// Recovered from index.js:459
import { _decorator, sys } from "cc";
import { TLog } from "./TLog";
import RummyDataManager, { RUMMY_GAME_TYPE, RUMMY_PLAYER_STATE_TYPE } from "./RummyDataManager";
import User from "./User";
import Utils from "./Utils";
import PushCenter from "./PushCenter";
import GameConfig from "./GameConfig";
import RummyGameOverAlert from "./RummyGameOverAlert";
import TweenTool from "./TweenTool";
import PushEvent from "./PushEvent";
import SoundManager from "./SoundManager";
import { TransferPlatform } from "./TransferPlatform";
import HttpManager from "./HttpManager";
import PhpReportDefined from "./PhpReportDefined";
import i18nMgr from "./i18nMgr";
import RummyPointsMatchOverAlert from "./RummyPointsMatchOverAlert";
import Server from "./Server";
import RummyCmd from "./RummyCmd";
import CommDefine from "./CommDefine";
import NetConfig from "./NetConfig";
import RummyTotalSettlement from "./RummyTotalSettlement";
import HowToPlayDefined from "./HowToPlayDefined";
import RummyCardConstant, { isMeldedGroup } from "./RummyCardConstant";
import gameNetworkDelay from "./gameNetworkDelay";
import NetHostManager from "./NetHostManager";
import URLConfig from "./URLConfig";
import { HttpRequest } from "./HttpRequestName";
import { ToolUtils } from "./ToolUtils";
const { ccclass } = _decorator;
@ccclass("RummyLogicProcessing")
export class RummyLogicProcessing {
    public _lastChangeDeskTime: number = 0;
    public mainRummy: any = null;
    init(e) {
        this.mainRummy = e;
    }
    resetGameByTableInfo() {
        if (RummyDataManager.shared().reset(), RummyDataManager.shared().resetTabDataByTidkey(this.mainRummy.tid_key), this.mainRummy.playerTs.resetAll(), this.mainRummy.tipTs.resetAll(), this.mainRummy.actionTs.resetAll(), ToolUtils.isObjValid(this.mainRummy.gameEndView) && RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key).gameRummyType == RUMMY_GAME_TYPE.PRIVATE) {
            let e = this.mainRummy.gameEndView.getComponent("RummyGameOverAlert");
            e.isAlreadyShow() && e.checkShowWinShareBtn();
        }
        else if (ToolUtils.isObjValid(this.mainRummy.gameHistoryView) && RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key).gameRummyType == RUMMY_GAME_TYPE.PRIVATE) {
            let e = this.mainRummy.gameHistoryView.getComponent("RummyGameOverAlert");
            e.isAlreadyShow() && e.checkShowWinShareBtn();
        }
        else if (ToolUtils.isObjValid(this.mainRummy.RummyTotalSettlementNode)) {
            let e = this.mainRummy.RummyTotalSettlementNode.getComponent(RummyTotalSettlement);
            e.isAlreadyShow() && e.checkShowShareBtn();
        }
        else {
            PushCenter.shared().pushEvent(PushEvent.ShowWinShareBtn, false);
        }
        this.mainRummy.cardsTs.showMoPaiTisAnim(false, false);
        this.mainRummy.cardsTs.resetView(false);
        this.mainRummy.autoDropTs.hideAllLayer();
        this.mainRummy.autoDropTs.isshowAutoDropBtn(false, this.mainRummy.tid_key);
        User.shared().data.isChangeSceneLayerLevel = true;
        this.mainRummy._playerEnterMsg = [];
        this.mainRummy._playerExitMsg = [];
        this.mainRummy.gameStartMsg = null;
        this.mainRummy._gameOverMsg = null;
        this.mainRummy.has_showQuick_charge = false;
        this.mainRummy.isDisconnect = false;
        this.mainRummy.canTouch = true;
        this.mainRummy.finishType = -1;
        this.mainRummy.hasDeclare = false;
        this.mainRummy.isUpdateMyMoney = true;
        this.mainRummy.isZhahuHupai = false;
        this.mainRummy.isOpenQipai = false;
        this.mainRummy._bIsGameEnd = false;
        this.mainRummy._bGameOverClosed = false;
        this.mainRummy._bIsWinnerAnimEnd = true;
        this.mainRummy._bIsShowReady = true;
        this.mainRummy._isFaPaiAnim = false;
        this.mainRummy._hasSendMsg = false;
        this.mainRummy._isPlayWinEffec = false;
        this.mainRummy._bIsShowWaitDeclare = false;
        this.mainRummy.matchTotalSettleMsg = null;
        this.mainRummy.autoReadyTime = -1;
        User.shared().isGameDisconnectServer = false;
        this.mainRummy.gameOverOpenLogic._gameEndMsg = null;
        User.shared().curTid_key === this.mainRummy.tid_key && TransferPlatform.shared().setNormalFrameRate();
        RummyDataManager.shared().stopTweenActionByNode(this.mainRummy.time_node);
        RummyDataManager.shared().stopTweenActionByNode(this.mainRummy.action_node);
        RummyDataManager.shared().stopTweenAction(this.mainRummy._pQipai_action);
        RummyDataManager.shared().stopTweenAction(this.mainRummy.delay_ready_action);
        RummyDataManager.shared().stopTweenAction(this.mainRummy.start_time_action);
        this.mainRummy.deleteGameOverDalay();
        ToolUtils.isObjValid(this.mainRummy.openCardNode) && (this.mainRummy.openCardNode.active = false);
        ToolUtils.isObjValid(this.mainRummy.rummyGameManualSplit) && this.mainRummy.rummyGameManualSplit.destroy();
        this.mainRummy.hideWinTipAlert();
        this.mainRummy.hideOpenCardAlert();
        this.mainRummy.poolRummyUpdateTipTime();
        this.mainRummy.rummyShowTopUiLogic.reset();
        this.mainRummy.tingPaiMsg = null;
        this.mainRummy.pickCardInfo = null;
        this.mainRummy.hideAllTingPaiFlag();
        this.mainRummy._bIsCanFinish = true;
        this.mainRummy.hasPlayOutLocalCard = false;
        RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key).hasShowWinAnim = false;
        this.mainRummy.cardInfoMsg = null;
        this.mainRummy.req_id = 0;
        this.mainRummy.moveCard_action && (TweenTool.stopAction(this.mainRummy.moveCard_action), this.mainRummy.moveCard_action = null);
        RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key).isMovingCard = false;
        User.shared().lastWinGameInfo = { nVid: -1, nScore: 0 };
        this.mainRummy.match_wait_info = null;
        this.mainRummy.discardAutoSortGroupIds = [];
    }
    restoreRecoveryPhase(snapshot) {
        const phase = snapshot.recovery_phase;
        if (phase === "choosing_double") {
            this.applyDoubleChoicePhase();
            return;
        }
        if (phase !== "declaring" && phase !== "inactive") return;
        const main = this.mainRummy;
        const info = RummyDataManager.shared().rummyInfos.get(main.tid_key);
        if (!info) return;
        // Snapshot restoration must finish atomically; don't let an ordinary
        // turn hint scheduled during rendering re-enable a now-invalid action.
        RummyDataManager.shared().stopTweenActionByNode(main.action_node);
        main.actionTs.setMopaiBtnInteractable(false);
        main.actionTs.changeDropBtnStatus(false);
        main.actionTs.changeDiscardBtnStatus(false);
        main.actionTs.changeGroupBtnStatus(false);
        main.actionTs.changeFinishBtnStatus(false);
        main.actionTs.changeAutoGroupBtnStatus(false);
        main.cardsTs.showMoPaiTisAnim(false, false);
        main.cardsTs.showFinishTisiAnim(false);
        main.cardsTs.showPickCardTips(false);
        main.autoDropTs.hideAllLayer();
        main.autoDropTs.isshowAutoDropBtn(false, main.tid_key);
        info.isClientToPlay = false;
        info.isCanTouchCard = false;
        info.isInGameing = 0;
        if (phase === "inactive") {
            main.cardsTs.showDropCardsZheZhao(true);
            return;
        }
        const declaration = snapshot.recovery_declaration;
        if (!declaration) return;
        main.hasDeclare = true;
        info.game_state = 4;
        info.game_server_state = 4;
        info.is_declare_status = true;
        info.bIsHasHu = true;
        info.autoDeclareStatus = 0;
        const remaining = Math.max(0, Number(declaration.remaining) || 0);
        const canSubmit = declaration.can_submit === 1 && remaining > 0;
        info.game_cd = remaining;
        info.op_cd = remaining;
        main._bIsShowWaitDeclare = !canSubmit;
        for (let seat = 0; seat < info.pnum; seat++) {
            main.playerTs.stopPlayerTimerByPos(main.getPosBySeatid(seat), true);
        }
        for (const seat of declaration.pending_seats || []) {
            if (remaining > 0) main.playerTs.startPlayerTimer2(main.getPosBySeatid(seat), remaining, remaining);
        }
        if (snapshot.finish_card > 0) main.cardsTs.readyHuCardShowFinish(snapshot.finish_card, false);
        main.tipTs.showConfimTips(declaration.title || "A player has declared", "Group your cards and declare.", canSubmit, remaining);
        main.tipTs.show_wait_declare(!canSubmit);
        main.actionTs.changeAutoGroupBtnStatus(canSubmit);
        info.isCanTouchCard = canSubmit;
        info.isInGameing = canSubmit ? 1 : 0;
    }
    checkTreasureHuntActivity() {
        let e = RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key);
        if (0 === e.crashModel) {
            if (1 == User.shared().act_90_open) {
                let i = false;
                if (sys.isObjectValid(User.shared().act_90_recommend_list) && Array.isArray(User.shared().act_90_recommend_list) && User.shared().act_90_recommend_list.length > 0) {
                    let a = User.shared().act_90_recommend_list.length;
                    for (let t = 0; t < a; t++) {
                        let a = User.shared().act_90_recommend_list[t];
                        if (e.vid == Number(a)) {
                            i = true;
                            break;
                        }
                    }
                }
                this.mainRummy.has_treasureHuntAct = i;
                i ? User.shared().requestTreaHuntMainData(true, e.vid, e.pnum, (i => {
                    sys.isObjectValid(i.cvid) && i.cvid == e.vid && (sys.isObjectValid(i.open) && 1 == i.open ? (this.mainRummy.treahuntTaskData = i.ctask, this.mainRummy.actionTs.updateTreasureHuntBtn(0, i.ctask), this.mainRummy.has_treasureHuntAct = true) : (this.mainRummy.actionTs.updateTreasureHuntBtn(4, null), this.mainRummy.has_treasureHuntAct = false));
                }), 0) : (this.mainRummy.has_treasureHuntAct = false, this.mainRummy.actionTs.updateTreasureHuntBtn(4, null));
            }
        }
        else if (1 == User.shared().act_97_open) {
            let i = false;
            if (sys.isObjectValid(User.shared().act_97_recommend_list) && Array.isArray(User.shared().act_97_recommend_list) && User.shared().act_97_recommend_list.length > 0) {
                let a = User.shared().act_97_recommend_list.length;
                for (let t = 0; t < a; t++) {
                    let a = User.shared().act_97_recommend_list[t];
                    if (e.vid == Number(a)) {
                        i = true;
                        break;
                    }
                }
            }
            this.mainRummy.has_treasureHuntAct = i;
            i ? User.shared().requestTreaHuntMainData(true, e.vid, e.pnum, (i => {
                if (sys.isObjectValid(i.cvid) && i.cvid == e.vid) {
                    if (sys.isObjectValid(i.open) && 1 == i.open) {
                        sys.isObjectValid(i.show_box) && (RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key).show_box_act97 = Number(i.show_box));
                        sys.isObjectValid(i.box_type) && (RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key).box_type_act97 = Number(i.box_type));
                        this.mainRummy.actionTs.updateTreasureHuntBox(RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key).show_box_act97, RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key).box_type_act97);
                        this.mainRummy.treahuntTaskData = i.ctask;
                        RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key).act97_data = this.mainRummy.treahuntTaskData;
                        this.mainRummy.actionTs.updateTreasureHuntBtn(0, i.ctask);
                        this.mainRummy.has_treasureHuntAct = true;
                        RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key).has_treasurehunt = true;
                        let t = { vid: e.vid, show_box: Number(i.show_box), box_type: Number(i.box_type), data: i.ctask, pnum: RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key).pnum, gameBaseMoney: RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key).gameBaseMoney };
                        PushCenter.shared().pushEvent(PushEvent.UpdateTreaBoxStateInGame, t);
                    }
                    else {
                        RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key).has_treasurehunt = false;
                        RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key).show_box_act97 = 0;
                        this.mainRummy.actionTs.updateTreasureHuntBox(0, 0);
                        this.mainRummy.actionTs.updateTreasureHuntBtn(4, null);
                        this.mainRummy.has_treasureHuntAct = false;
                    }
                }
            }), 1) : (this.mainRummy.has_treasureHuntAct = false, this.mainRummy.actionTs.updateTreasureHuntBtn(4, null));
        }
    }
    checkNovicesTask() {
        let e = RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key).vid;
        HttpManager.shared().doGetCommonRequest({ vid: e }, HttpRequest.NovicesTaskList, ((i, t, m) => {
            if (200 != m) {
                ;
            }
            else {
                let i = ToolUtils.parseJson(t);
                0 == i.ret && (e > 0 ? (User.shared().roomNovicesData = i, sys.isObjectValid(i.data.show) && 1 == i.data.show && this.mainRummy.actionTs.updateNovicesTaskBtn(true)) : (User.shared().novicesTaskData = i, this.mainRummy.actionTs.updateNovicesTaskBtn(false)));
            }
        }));
    }
    checkFlopCashTask() {
        if (1 != User.shared().new_user_flopcash_open) {
            return;
        }
        let e = RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key).vid;
        HttpManager.shared().doGetCommonRequest({ vid: e }, HttpRequest.FlopCashTaskList, ((i, t, m) => {
            if (200 != m) {
                ;
            }
            else {
                let i = ToolUtils.parseJson(t);
                0 == i.ret && (e > 0 ? sys.isObjectValid(i.data.show) && 1 == i.data.show && (this.mainRummy.actionTs.updateFlopCashStatus(true, i.data), RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key).flopCashTaskLaba = i.data, this.updateGameOverFlopCash()) : this.mainRummy.actionTs.updateFlopCashStatus(false, i.data));
            }
        }));
    }
    updateNovicesTask(e) {
        sys.isObjectValid(User.shared().roomNovicesData) && sys.isObjectValid(User.shared().roomNovicesData.data) && (User.shared().roomNovicesData.data.progress = e, sys.isObjectValid(User.shared().roomNovicesData.data.show) && 1 == User.shared().roomNovicesData.data.show && this.mainRummy.actionTs.updateNovicesTaskBtn(true));
    }
    updateFlopCashTask(e) {
        if (sys.isObjectValid(e) && sys.isObjectValid(e.tid_key) && sys.isObjectValid(e.current_task_status) && 2 == e.current_task_status && this.mainRummy.tid_key == e.tid_key && this.mainRummy.node.active) {
            let i = { source: e, vid: this.mainRummy.getRoomVid(), tid_key: e.tid_key };
            ToolUtils.flopActInGameData = i;
            Utils.shared().checkMemberShipUpgradeShown() || Utils.shared().showFlopCashActInGame(i);
        }
    }
    updateGameOverNovices() {
        let e = RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key).novicesGameOverLaba;
        sys.isObjectValid(this.mainRummy) && sys.isObjectValid(e) && ToolUtils.isObjValid(this.mainRummy.gameEndView) && RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key).gameRummyType != RUMMY_GAME_TYPE.MATCH && this.mainRummy.gameEndView.getComponent(RummyGameOverAlert).updateNovicesBanner(e);
    }
    updateGameOverFlopCash() {
        let e = RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key).flopCashTaskLaba;
        sys.isObjectValid(this.mainRummy) && sys.isObjectValid(e) && ToolUtils.isObjValid(this.mainRummy.gameEndView) && RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key).gameRummyType != RUMMY_GAME_TYPE.MATCH && this.mainRummy.gameEndView.getComponent(RummyGameOverAlert).updateFlopCashBanner(e);
    }
    updateTaskBtn() {
        let e = false, i = false, a = 0;
        1 === User.shared().daily_task && 0 === User.shared().temp_pingbi.dailytask && User.shared().curTid_key !== CommDefine.NewerGuideRoomTidkey && (e = true, i = false, a = 1, 1 == User.shared().act_90_open && (e = false, i = false));
        1 == User.shared().showBackCardTask && (e = false, i = false);
        this.mainRummy.actionTs.changeTaskTipsVisible(i);
        this.mainRummy.actionTs.changeTaskBtnVisible(e, a);
    }
    joinMatchRequest() {
        let e = this, i = 0, a = 0, t = this.mainRummy.ticket_mode, m = 0;
        if (t && t.length > 1) {
            let m = 0, s = 0;
            for (let e = 0, n = t.length; e < n; e++) {
                0 == t[e].pay_type ? (i = t[e].pay_info[0].value, m = t[e].pay_type) : 1 == t[e].pay_type && (a = t[e].pay_info[0].value, s = t[e].pay_type);
            }
            let n = "", r = false, h = User.shared().getPropNumById(100001);
            0 != i && 0 != a && a <= h ? (n = ToolUtils.format(i18nMgr.shared().getValueByKey("utlis.text8"), i, a), r = true, Utils.shared().showCommomDialog(n, i18nMgr.shared().getValueByKey("gameRummy_notice_Pop.notice"), (i => {
                1 == i ? (Utils.shared().showLoading(10, false), e.handler_server_join_race_request(m)) : 3 == i && (Utils.shared().showLoading(10, false), e.handler_server_join_race_request(s));
            }), r, false, "CASH", "TICKET")) : 0 != i ? (Utils.shared().showLoading(10, false), e.handler_server_join_race_request(m)) : e.handler_server_join_race_request(s);
        }
        else if (t && t.length > 0) {
            for (let e = 0, m = t[0].pay_info.length; e < m; e++) {
                0 == t[0].pay_info[e].type ? i = t[0].pay_info[e].value : a = t[0].pay_info[e].value;
            }
            m = t[0].pay_type;
            Utils.shared().showLoading(10, false);
            e.handler_server_join_race_request(m);
        }
        else {
            this.mainRummy.checkIsPointsMatch() && (Utils.shared().showLoading(10, false), e.handler_server_join_race_request(m));
        }
    }
    refreshPlayerSeat() {
        let e = RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key);
        if (0 == e.is_waiting || 2 == e.game_server_state) {
            for (let i = 0; i <= 5; i++) {
                this.mainRummy.playerTs.hidePipeiAnim(i);
                TweenTool.delayAct(this.mainRummy.time_node, (() => {
                    this.mainRummy.playerTs.playEnterAnim(i);
                }), 0.5, true);
                let a = this.mainRummy.getSeatidByPos(i), t = e.playerModels[a];
                if (t && this.mainRummy.playerTs.checkHeadShow(i) && t.isShow && null != t.seatid) {
                    let a = i, m = {};
                    m.name = t.name;
                    m.uid = t.uid;
                    m.headname = t.avatar;
                    m.vlevel = 0;
                    0 == a ? 1 == e.crashModel ? m.money = User.shared().data.money_exe : m.money = User.shared().data.money : m.money = t.money;
                    m.sex = t.sex;
                    m.avatar_url = t.avatar_url;
                    m.vip = t.vip;
                    m.club_level = t.club_level;
                    m.club_effect_v2 = t.club_effect_v2;
                    m.isinit = false;
                    m.isLineUp = false;
                    m.isHeadCallback = true;
                    m.head_refresh_type = 1;
                    t.status != RUMMY_PLAYER_STATE_TYPE.DROPPED && t.status != RUMMY_PLAYER_STATE_TYPE.LOST && t.status != RUMMY_PLAYER_STATE_TYPE.MIDDLEDROP && t.status != RUMMY_PLAYER_STATE_TYPE.WRONGSHOW && t.status != RUMMY_PLAYER_STATE_TYPE.WAITING && t.status != RUMMY_PLAYER_STATE_TYPE.OUT && t.status != RUMMY_PLAYER_STATE_TYPE.FirstWinner || (m.is_gray_name = 1);
                    m.avatar_frame_id = t.avatar_frame_id;
                    m.play_effect_id = t.play_effect_id;
                    this.mainRummy.playerTs.showPlayer(a, m);
                    t && null != t.betting && null != t.betting && (1 == t.betting || 0 == t.betting && t.status >= 0 ? t.status > 0 ? (this.mainRummy.playerTs.changeAwayStateStatus(a, true, t.status), 7 == t.status && ToolUtils.isObjValid(this.mainRummy.RummyTotalSettlementNode) && this.mainRummy.RummyTotalSettlementNode.getComponent(RummyTotalSettlement).showReadyView(t.seatid, true)) : null != t.fold_leave && null != t.fold_leave && 1 == t.fold_leave && this.mainRummy.playerTs.changeAwayStateStatus(a, true, RUMMY_PLAYER_STATE_TYPE.AWAY) : e.gameRummyType != RUMMY_GAME_TYPE.PRIVATE && e.gameRummyType != RUMMY_GAME_TYPE.PRI_POOL && e.gameRummyType != RUMMY_GAME_TYPE.PRI_DEAL && e.gameRummyType != RUMMY_GAME_TYPE.MATCH || -1 == t.status && this.mainRummy.playerTs.changeAwayStateStatus(a, true, RUMMY_PLAYER_STATE_TYPE.WAITING));
                }
            }
        }
    }
    refreshPlayerInfoBySeatid(e) {
        let i = RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key);
        if (0 == i.is_waiting || 2 == i.game_server_state) {
            let a = i.playerModels[e], t = this.mainRummy.getPosBySeatid(e);
            if (a && this.mainRummy.playerTs.checkHeadShow(t) && a.isShow && null != a.seatid) {
                let e = {};
                e.name = a.name;
                e.uid = a.uid;
                e.headname = a.avatar;
                e.vlevel = 0;
                0 == t ? 1 == i.crashModel ? e.money = User.shared().data.money_exe : e.money = User.shared().data.money : e.money = a.money;
                e.sex = a.sex;
                e.avatar_url = a.avatar_url;
                e.vip = a.vip;
                e.club_level = a.club_level;
                e.club_effect_v2 = a.club_effect_v2;
                e.isinit = false;
                e.isLineUp = false;
                e.isHeadCallback = true;
                e.head_refresh_type = 1;
                a.status != RUMMY_PLAYER_STATE_TYPE.DROPPED && a.status != RUMMY_PLAYER_STATE_TYPE.LOST && a.status != RUMMY_PLAYER_STATE_TYPE.MIDDLEDROP && a.status != RUMMY_PLAYER_STATE_TYPE.WRONGSHOW && a.status != RUMMY_PLAYER_STATE_TYPE.WAITING && a.status != RUMMY_PLAYER_STATE_TYPE.OUT && a.status != RUMMY_PLAYER_STATE_TYPE.FirstWinner || (e.is_gray_name = 1);
                e.avatar_frame_id = a.avatar_frame_id;
                e.play_effect_id = a.play_effect_id;
                this.mainRummy.playerTs.showPlayer(t, e);
            }
        }
    }
    changeRoomHost() {
        let e = RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key);
        if (e.host_seat >= 0) {
            if (this.mainRummy.is_first_round) {
                let i = e.playerModels[e.host_seat];
                if (i && (i.ready = 1), e.host_seat == e.clientSeatId) {
                    let i = this.mainRummy.getPosBySeatid(e.clientSeatId);
                    this.mainRummy.playerTs.changeAwayStateStatus(i, false);
                    this.mainRummy.actionTs.hideReadyBtn();
                }
                else {
                    let i = this.mainRummy.getPosBySeatid(e.host_seat);
                    this.mainRummy.playerTs.changeAwayStateStatus(i, false);
                }
            }
            if (e.roomPlayerCounter >= 2) {
                if (this.mainRummy.is_first_round) {
                    this.mainRummy.getReayPlayerNums() >= 2 && e.host_seat == e.clientSeatId ? this.mainRummy.actionTs.showStartBtn() : this.mainRummy.actionTs.hideStartBtn();
                }
                else if (this.mainRummy.actionTs.hideStartBtn(), e.host_seat != e.clientSeatId) {
                    let i = e.playerModels[e.clientSeatId];
                    i && (1 != i.ready ? this.mainRummy.actionTs.showReadyBtn() : this.mainRummy.actionTs.hideReadyBtn());
                }
            }
            else if (this.mainRummy.actionTs.hideStartBtn(), e.host_seat != e.clientSeatId) {
                let i = e.playerModels[e.clientSeatId];
                i && (1 != i.ready ? this.mainRummy.actionTs.showReadyBtn() : this.mainRummy.actionTs.hideReadyBtn());
            }
        }
    }
    handler_server_notify_head_status(e) {
        let i = RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key), t = 0;
        sys.isObjectValid(e.end_way) && 1 == e.end_way && (t = 1.5);
        try {
            if (null != e.players && e.players.length > 0) {
                let a = false;
                for (let m = 0, n = e.players.length; m < n; m++) {
                    let n = e.players[m], d = parseInt("" + n.seatid), u = this.mainRummy.getPosBySeatid(d), h = ToolUtils.isSafeNumber(n.decision), y = 1 === h;
                    this.mainRummy.playerTs.setDecisionStateVisible(u, y);
                    let o = i.playerModels[d];
                    if (o) {
                        let m = n.head_status;
                        if (o.betting = n.betting, o.status = n.head_status, o.decision = h, 0 == m ? TweenTool.delayAct(this.mainRummy.time_node, (() => {
                            this.mainRummy.playerTs.changeAwayStateStatus(u, true, o.status);
                        }), t, true) : (this.mainRummy.playerTs.changeAwayStateStatus(u, true, m), m == RUMMY_PLAYER_STATE_TYPE.READY && ToolUtils.isObjValid(this.mainRummy.RummyTotalSettlementNode) && this.mainRummy.RummyTotalSettlementNode.getComponent(RummyTotalSettlement).showReadyView(n.seatid, true)), o.status != RUMMY_PLAYER_STATE_TYPE.DROPPED && o.status != RUMMY_PLAYER_STATE_TYPE.OUT || (a = true, i.playerGiveCards = i.playerGiveCards.filter((e => e.seatid !== d))), 0 == u && n.head_status == RUMMY_PLAYER_STATE_TYPE.OUT && RummyDataManager.shared().rummyInfos.get(e.tid_key).game_type == HowToPlayDefined.gameId_PoolRummy) {
                            let i = {};
                            i.head_status = RUMMY_PLAYER_STATE_TYPE.OUT;
                            i.tid_key = e.tid_key;
                            RummyDataManager.shared().reportGameFinish(i);
                        }
                    }
                }
                a && this.mainRummy.refreshOpenCardPlayersInfo();
            }
        }
        catch (e) {
            TLog.printError("trycatch handler_server_notify_head_status ,error:", e);
        }
    }
    handler_server_game_guest_gameover_return(e) {
    }
    handler_server_notify_enter_line_up(e) {
        let i = RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key);
        if (Utils.shared().hideLoading(), this.mainRummy.removeTotalSettlementView(), ToolUtils.isObjValid(this.mainRummy.node)) {
            let e = this.mainRummy.node.getChildByName("quick_recharge");
            ToolUtils.isObjValid(e) && e.destroy();
            let i = this.mainRummy.pop_layer4.getChildByName("quick_recharge");
            ToolUtils.isObjValid(i) && i.destroy();
        }
        PushCenter.shared().pushEvent(GameConfig.Update_Menu_Switch_Status, { tid_key: this.mainRummy.tid_key, bEnable: false });
        i.is_waiting = 1;
        i.is_replay = e.is_replay;
        i.is_showhuAnim_status = false;
        i.gameRummyType != RUMMY_GAME_TYPE.PRIVATE && i.gameRummyType != RUMMY_GAME_TYPE.PRI_POOL && i.gameRummyType != RUMMY_GAME_TYPE.PRI_DEAL && i.gameRummyType != RUMMY_GAME_TYPE.MATCH && (this.mainRummy.playerTs.setPaiDuiBgShow(false), this.mainRummy.actionTs.changeCenterFinishBtnStatus(false));
        this.mainRummy.tipTs.show_wait_declare(false);
        this.mainRummy._bIsShowWaitDeclare = false;
        i.wait_virtual_num = e.wait_virtual_num;
        for (let e = 0; e <= 5; e++) {
            0 != e && this.mainRummy.playerTs.hidePlayer(e);
            this.mainRummy.playerTs.hideEnterAnim(e);
            this.mainRummy.playerTs.changePlayerZhuangState(false, e);
            ToolUtils.isObjValid(this.mainRummy.game_chatNode) && this.mainRummy.game_chatTs.hideMagicFace(e);
        }
        this.mainRummy.cardsTs.resetView();
        this.mainRummy.tipTs.showMatchWaitTip(false);
        this.mainRummy.tipTs.hideWinEffect();
        this.mainRummy._nRobotPlayerCount = 0;
    }
    handler_server_sort_cards_return(e) {
        let i = this.getAutoSortAnimGroup(e);
        if (this.mainRummy.saveServerCardInfos(e), 0 == e.ret) {
            1 == e.positive ? this.mainRummy.playEffectByName("rummyPositiveGroup") : this.mainRummy.playEffectByName("rummyGroup");
            this.mainRummy.actionTs.changeGroupBtnStatus(false);
            this.mainRummy.actionTs.changeDiscardBtnStatus(false);
            this.mainRummy.actionTs.changeFinishBtnStatus(false);
            this.mainRummy.actionTs.changeSortBtnStatus(false);
            this.mainRummy.actionTs.changeAutoGroupBtnStatus(true);
            this.mainRummy.autoDropTs.setAutoDropBtn(2);
            sys.isObjectValid(e.src_score) ? sys.isObjectValid(e.finish_multiple) ? this.mainRummy.playerTs.showLoseScore(0, e.all_score, true, e.src_score, e.finish_multiple) : this.mainRummy.playerTs.showLoseScore(0, e.all_score, true, e.src_score) : this.mainRummy.playerTs.showLoseScore(0, e.all_score, true);
            e.cardinfos && this.mainRummy.refreshMyShouPai(e, true, true, i);
        }
        else {
            ToolUtils.isSafeString(e.alertStr).length > 0 && Utils.shared().showToast(e.alertStr, 2, 0, ToolUtils.getIsNormalDirection());
            e.cardinfos && this.mainRummy.refreshMyShouPai(e, true, true, i);
        }
    }
    handler_server_auto_group_cards_return(e) {
        let i = RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key);
        i.autoGroupStatus = e.status;
        this.acknowledgeAutoGroup(i, e);
        sys.isObjectValid(e.lz_card) && (i.laizicard = e.lz_card);
        sys.isObjectValid(e.flop_lz_card) && (i.laiziFlopCard = e.flop_lz_card);
        let t = 1 == e.status ? this.getAutoSortAnimGroup(e) : [];
        if (this.mainRummy.saveServerCardInfos(e), i.hasFaPai) {
            let m = i.clientSeatId, s = i.playerModels[m];
            if ((0 == s.status || 4 == s.status) && 1 == s.betting) {
                if (0 == (i.autoGroupDesiredStatus == null ? e.status : i.autoGroupDesiredStatus)) {
                    let e = sys.localStorage.getItem("autoSortCount");
                    User.shared().auto_sort_tips && (!sys.isObjectValid(e) || Number(e) > 0) && (this.mainRummy.actionTs.changeAutoGroupTipsStatus(true), ToolUtils.saveData("autoSortCount", String(Number(e) - 1)));
                }
                else {
                    this.mainRummy.actionTs.changeAutoGroupTipsStatus(false);
                }
                this.mainRummy.actionTs.changeAutoGroupBtnStatus(null);
                sys.isObjectValid(e.all_score) && (sys.isObjectValid(e.src_score) ? sys.isObjectValid(e.finish_multiple) ? this.mainRummy.playerTs.showLoseScore(0, e.all_score, true, e.src_score, e.finish_multiple) : this.mainRummy.playerTs.showLoseScore(0, e.all_score, true, e.src_score) : this.mainRummy.playerTs.showLoseScore(0, e.all_score, true));
                e.cardinfos && this.mainRummy.refreshMyShouPai(e, false, true, t);
                this.mainRummy.tipTs.getQuickFinishTips() && 0 != this.mainRummy.helper_hu_card && this.mainRummy.cardsTs.showHelperQuickFinishCard(this.mainRummy.helper_hu_card, true, this.mainRummy.tingPaiMsg);
                this.mainRummy.node.active && null != e.ani_type && null != e.ani_type && (0 != e.ani_type && 1 != e.ani_type || (SoundManager.shared().playFx("rummyAutoSort"), this.mainRummy.tipTs.showAutoSortAnim(e.ani_type)));
            }
        }
    }
    getAutoSortAnimGroup(e) {
        let i = [];
        if (e.cardinfos && this.mainRummy.cardInfoMsg && this.mainRummy.cardInfoMsg.cardinfos) {
            for (let t, m, s = 0, n = e.cardinfos.length; s < n; s++) {
                if (t = e.cardinfos[s], isMeldedGroup(t, e.cardinfos)) {
                    m = false;
                    for (let e, i = 0, s = this.mainRummy.cardInfoMsg.cardinfos.length; i < s; i++) {
                        if (e = this.mainRummy.cardInfoMsg.cardinfos[i], isMeldedGroup(e, this.mainRummy.cardInfoMsg.cardinfos) && sys.isObjectValid(t.cards) && sys.isObjectValid(e.cards) && t.cards.length == e.cards.length) {
                            let i = true;
                            for (let a = 0, m = t.cards.length; a < m; a++) {
                                if (!e.cards.includes(t.cards[a])) {
                                    i = false;
                                    break;
                                }
                            }
                            if (i) {
                                m = true;
                                break;
                            }
                        }
                    }
                    m || i.push(s);
                }
            }
        }
        return i;
    }
    handler_server_notify_ready_btn_status(e) {
        let i = RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key);
        if (1 === e.display) {
            for (let e = 0; e < 6; e++) {
                this.mainRummy.playerTs.changePlayerZhuangState(false, e);
                let a = i.playerModels[e];
                a && (a.ready = 0);
            }
            i.isGameOver && this.mainRummy._bIsWinnerAnimEnd && this.mainRummy.actionTs.showReadyBtn();
        }
        else {
            this.mainRummy._bIsShowReady = false;
            this.mainRummy.actionTs.hideReadyBtn();
        }
        ToolUtils.isObjValid(this.mainRummy.gameEndView) && RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key).gameRummyType != RUMMY_GAME_TYPE.MATCH && (1 === e.display ? this.mainRummy.gameEndView.getComponent(RummyGameOverAlert).show_ready_btn() : this.mainRummy.gameEndView.getComponent(RummyGameOverAlert).hide_ready_btn());
    }
    handler_server_logout_respond(e) {
        if (this.mainRummy.checkIsPointsMatch()) {
            let i = "", t = "";
            if (sys.isObjectValid(e.is_drop) && 1 == e.is_drop) {
                if (sys.isObjectValid(e.go_next_step_score) && -1 == e.go_next_step_score) {
                    i = i18nMgr.shared().getValueByKey("rummy_main.match_leave_tip2");
                }
                else {
                    let a = ToolUtils.isSafeNumber(e.go_next_step_score);
                    i = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_main.match_leave_tip3"), ToolUtils.parse_double("" + a, -1));
                }
            }
            else {
                this.mainRummy.hasPointsMatchExitAlert = true;
                let m = ToolUtils.isSafeNumber(e.reward_value);
                t = sys.isObjectValid(e.mixed) && 1 == e.mixed ? ToolUtils.parse_double("" + m) + "*" : "" + ToolUtils.parse_double("" + m);
                i = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_main.match_leave_tip1"), t);
            }
            let m = this.mainRummy, s = { bLandscape: ToolUtils.getIsNormalDirection(), bWithCancel: true, strContent: i, strTitle: i18nMgr.shared().getValueByKey("gameRummy_notice_Pop.notice"), sureKey: "rummy_switch.okay", cancelKey: "rummy_switch.cancel", parent_node: this.mainRummy.pop_layer4, tid_key: this.mainRummy.tid_key };
            return void Utils.shared().showCommonAlert(s, (i => {
                this.mainRummy.hasPointsMatchExitAlert = false;
                1 == i && (sys.isObjectValid(e.is_drop) && 1 == e.is_drop ? m.switchRoom(5) : sys.isObjectValid(e.is_drop) && 2 == e.is_drop ? m.autoDropTs.send_auto_drop_card_request(2) : m.exitCallBack(1));
            }), true);
        }
        let i = RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key).gameRummyType;
        if (1 === e.show_notice) {
            let t = ToolUtils.isSafeNumber(e.notice_type), m = e.lose_money, r = "", d = RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key).crashModel, h = "";
            if (h = 1 == d ? ToolUtils.parse_ChipNum2("" + m) : ToolUtils.parse_double("" + m), i == RUMMY_GAME_TYPE.POINTS || i == RUMMY_GAME_TYPE.MULTIPLE) {
                if (1 == e.leave_type) {
                    r = 1 == e.isGoHall ? i18nMgr.shared().getValueByKey("utlis.text16") : i18nMgr.shared().getValueByKey("utlis.text17");
                }
                else if (2 == e.leave_type) {
                    1 == e.isGoHall ? (r = ToolUtils.format(i18nMgr.shared().getValueByKey("utlis.loseup5"), h), 1 == d && (r = ToolUtils.format(i18nMgr.shared().getValueByKey("utlis.loseup6"), h))) : (r = ToolUtils.format(i18nMgr.shared().getValueByKey("utlis.text22"), h), 1 == d && (r = ToolUtils.format(i18nMgr.shared().getValueByKey("utlis.text21"), h)));
                }
                else {
                    if (1 == e.isGoHall) {
                        let i = e.drop_lose, t = e.decare_lose;
                        return void (sys.isObjectValid(i) && sys.isObjectValid(t) && this.mainRummy.rummyShowTopUiLogic.showSwitchNotice(m, i, t));
                    }
                    r = ToolUtils.format(i18nMgr.shared().getValueByKey("utlis.text22"), h);
                    1 == d && (r = ToolUtils.format(i18nMgr.shared().getValueByKey("utlis.text21"), h));
                    2 === t && (r = ToolUtils.format(i18nMgr.shared().getValueByKey("utlis.loseup1"), h), 1 == d && (r = ToolUtils.format(i18nMgr.shared().getValueByKey("utlis.loseup2"), h)));
                }
            }
            else {
                let i = e.next_table_cost;
                sys.isObjectValid(i) || (i = 0);
                r = ToolUtils.format(i18nMgr.shared().getValueByKey("utlis.text22"), h);
                1 == d && (r = ToolUtils.format(i18nMgr.shared().getValueByKey("utlis.text21"), h));
                1 == e.isGoHall && (r = ToolUtils.format(i18nMgr.shared().getValueByKey("utlis.text19"), h, ToolUtils.parse_double("" + i, 0)), 1 == d && (r = ToolUtils.format(i18nMgr.shared().getValueByKey("utlis.text18"), h, ToolUtils.parse_ChipNum2("" + i))));
            }
            let y = this.mainRummy;
            Utils.shared().showCommomDialog(r, "", (a => {
                1 == a && (1 == e.isGoHall ? i == RUMMY_GAME_TYPE.POINTS || i == RUMMY_GAME_TYPE.MULTIPLE ? y.rummyLogicProcessing.handler_pre_switch_request() : y.switchCallback() : y.exitCallBack(1));
            }), true, ToolUtils.getIsNormalDirection(), null, null, null, this.mainRummy.pop_layer4, null, this.mainRummy.tid_key, false);
        }
        else {
            1 == e.isGoHall ? i == RUMMY_GAME_TYPE.POINTS || i == RUMMY_GAME_TYPE.MULTIPLE ? this.handler_pre_switch_request() : this.mainRummy.switchCallback() : this.mainRummy.exitCallBack(1);
        }
    }
    handler_server_login_gate_return(e) {
        if (this.mainRummy.tid_key == CommDefine.NewerGuideRoomTidkey) {
            if (1 != User.shared().data.beginner_guide.practice_status) {
                return;
            }
            if (!this.mainRummy._guideJumpPricticeReq) {
                return;
            }
        }
        try {
            if (0 == e.res) {
                this.send_login_request();
                PushCenter.shared().pushEvent(GameConfig.NetWorkDelayShow);
            }
            else if (2 == e.res) {
                if (RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key).gameRummyType == RUMMY_GAME_TYPE.MATCH && RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key).isMatchGameOver) {
                    return;
                }
                if (gameNetworkDelay.shared().setActiveDisconnect(true), this.mainRummy.isDisconnect = true, User.shared().isGameDisconnectServer = true, Server.shared().disconnectWebSocket(), ToolUtils.isObjValid(this.mainRummy.rummyGamePoolPoP)) {
                    return;
                }
                if (ToolUtils.isObjValid(this.mainRummy.RummyTotalSettlementNode)) {
                    return;
                }
                if (!ToolUtils.isObjValid(this.mainRummy.gameEndView)) {
                    let i = "You are not in any table!", a = "NOTICE";
                    ToolUtils.isSafeString(e.title).length > 0 && (a = e.title);
                    ToolUtils.isSafeString(e.msg).length > 0 && (i = e.msg);
                    TweenTool.delayAct(this.mainRummy.time_node, (() => {
                        window.InRummyScene && Utils.shared().showCommomDialog(i, a, (e => {
                            PushCenter.shared().pushEvent(GameConfig.RummyCompleteExit);
                        }), false, ToolUtils.getIsNormalDirection());
                    }), 2, true);
                }
            }
            else {
                Utils.shared().showCommomDialog(i18nMgr.shared().getValueByKey("rummy_main.gameTipstext11"), i18nMgr.shared().getValueByKey("gameRummy_notice_Pop.notice"), (e => {
                    this.mainRummy.exitCallBack(1);
                }), false, ToolUtils.getIsNormalDirection(), null, null, null, this.mainRummy.pop_layer4, null, this.mainRummy.tid_key);
            }
        }
        catch (e) {
            TLog.printError("trycatch handler_server_login_gate_return ,error:", e);
        }
    }
    handler_server_login_succ_bc(e) {
        if (this.mainRummy.tid_key === (e.tid_key || "") && RummyDataManager.shared().rummyInfos.has(this.mainRummy.tid_key)) {
            try {
                this.mainRummy._guideJumpPricticeReq = false;
                let i = RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key);
                if (i.is_table_change_status) {
                    return void this.mainRummy._playerEnterMsg.push(e);
                }
                i.roomPlayerCounter = i.roomPlayerCounter + 1;
                let t = e.seatid, m = i.playerModels[t];
                if (m.fold_leave = 0, m.isShow = true, m.uid = e.uid, m.seatid = e.seatid, m.sex = e.sex, m.avatar = e.avatar, m.money = e.money, m.score = e.score, sys.isObjectValid(e.ready) ? m.ready = e.ready : sys.isObjectValid(e.zhunbei) && (m.ready = e.zhunbei), sys.isObjectValid(e.see) && (m.see = e.see), m.status = -1, sys.isObjectValid(e.status) && (m.status = e.status), sys.isObjectValid(e.bet) && (m.bet = e.bet), sys.isObjectValid(e.ps) && (m.dsc = e.ps), sys.isObjectValid(e.name) && (m.name = e.name), sys.isObjectValid(e.total_board) && (m.total_board = e.total_board), sys.isObjectValid(e.total_win) && (m.total_win = e.total_win), sys.isObjectValid(e.vlevel) && (m.vlevel = e.vlevel), sys.isObjectValid(e.avatar_url) && (m.avatar_url = e.avatar_url), sys.isObjectValid(e.vip) && (m.vip = e.vip), sys.isObjectValid(e.club_level) && (m.club_level = e.club_level), sys.isObjectValid(e.club_effect_v2) && (m.club_effect_v2 = e.club_effect_v2), m.uid == User.shared().data.uid && (i.avatar = m.avatar, m.avatar_url && (i.avatar_url = m.avatar_url)), 1 == m.betting || 0 == m.betting && m.status >= 0) {
                    let a = [];
                    a.seatid = t;
                    a.name = e.name;
                    a.cards = [];
                    i.playerGiveCards.push(a);
                }
                null != e.rank && null != e.rank && (m.rank = e.rank);
                let r = this.mainRummy.getPosBySeatid(t), u = false;
                i.playerModels[t] = m;
                i.gameRummyType != RUMMY_GAME_TYPE.PRIVATE && i.gameRummyType != RUMMY_GAME_TYPE.PRI_POOL && i.gameRummyType != RUMMY_GAME_TYPE.PRI_DEAL && i.gameRummyType != RUMMY_GAME_TYPE.MATCH && (u = 1 == i.is_waiting || 1 == i.game_state);
                let h = {};
                h.name = m.name;
                h.uid = m.uid;
                h.headname = m.avatar;
                h.vlevel = m.vlevel;
                h.money = m.money;
                h.sex = m.sex;
                h.avatar_url = m.avatar_url;
                h.vip = m.vip;
                h.club_level = m.club_level;
                h.club_effect_v2 = m.club_effect_v2;
                h.isinit = true;
                h.isLineUp = u;
                h.isHeadCallback = true;
                h.avatar_frame_id = m.avatar_frame_id;
                h.play_effect_id = m.play_effect_id;
                this.mainRummy.playerTs.showPlayer(r, h);
                u && this.mainRummy.playerTs.showPipeiAnim1(r);
                null != e.score && (e.score > 0 && this.mainRummy.playerTs.setPoolScoreState(r, true), this.mainRummy.playerTs.setPoolScore(r, e.score), this.mainRummy.updateSeatScore(t, e.score));
                i.gameRummyType == RUMMY_GAME_TYPE.MATCH && this.mainRummy.playerTs.setPoolScoreState(r, true);
                this.mainRummy.playerTs.changeAwayStateStatus(r, true, m.status);
            }
            catch (e) {
                TLog.printError("trycatch handler_server_login_succ_bc error:", e);
            }
        }
    }
    handler_server_logout_succed_bc(e) {
        try {
            if (this.mainRummy.tid_key !== (e.tid_key || "")) {
                return;
            }
            if (!RummyDataManager.shared().rummyInfos.has(this.mainRummy.tid_key)) {
                return;
            }
            let i = RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key);
            if (e.uid != User.shared().data.uid && i.is_table_change_status) {
                return void this.mainRummy._playerExitMsg.push(e);
            }
            RummyDataManager.shared().rummyInfos.has(this.mainRummy.tid_key) && (i.roomPlayerCounter = i.roomPlayerCounter - 1);
            let t = -1;
            if (sys.isObjectValid(e.seatid) && (t = e.seatid), this.mainRummy.isMyPlayer(t) && e.uid == User.shared().data.uid) {
                if (this.mainRummy.playerTs.changeAwayStateStatus(0, false), 1 == e.type) {
                    return i.isGameOver = false, RummyDataManager.shared().stopTweenActionByNode(this.mainRummy.time_node), this.mainRummy.removeTotalSettlementView(), void this.mainRummy.removeGameOverView();
                }
                if (5 == e.type || 7 == e.type) {
                    return i.isGameOver = false, RummyDataManager.shared().stopTweenActionByNode(this.mainRummy.time_node), this.mainRummy.removeTotalSettlementView(), void this.mainRummy.removeGameOverView();
                }
                if (13 == e.type) {
                    return void (ToolUtils.deskInfos.size <= 1 ? (null != e.alertStr && e.alertStr.length > 0 && (User.shared().alertTip = e.alertStr), this.mainRummy.exitCallBack(1)) : Utils.shared().showCommomDialog(ToolUtils.isSafeString(e.alertStr), "", (e => {
                        this.mainRummy.exitCallBack(1);
                    }), false, ToolUtils.getIsNormalDirection(), "", "", false, this.mainRummy.pop_layer4));
                }
                if (14 == e.type) {
                    return i.isGameOver = false, void RummyDataManager.shared().stopTweenActionByNode(this.mainRummy.time_node);
                }
                if (6 == e.type) {
                    this.mainRummy.isDisconnect = true;
                    for (let e = 0; e < 6; e++) {
                        if (e > 0) {
                            i.playerModels[e].isShow = false;
                        }
                        this.mainRummy.playerTs.hidePlayer(e);
                        this.mainRummy.playerTs.stopPlayerTimerByPos(e);
                    }
                    return i.playerGiveCards = i.playerGiveCards.filter((e => e.seatid == t)), void this.mainRummy.refreshOpenCardPlayersInfo();
                }
                if (0 == e.type || 2 == e.type || 3 == e.type || 4 == e.type || 9 == e.type) {
                    return e.alertStr && e.alertStr.length > 0 && (i.toastTip = e.alertStr), sys.isObjectValid(e.money) && 0 === i.crashModel && User.shared().updateMoney(e.money), void this.mainRummy.backToHall();
                }
            }
            else {
                if (e.uid == User.shared().data.uid) {
                    return e.alertStr && e.alertStr.length > 0 && (i.toastTip = e.alertStr), sys.isObjectValid(e.money) && 0 === i.crashModel && User.shared().updateMoney(e.money), void this.mainRummy.backToHall();
                }
                let m = i.playerModels[t];
                if (m && m.uid == e.uid) {
                    m.isShow = false;
                    m.status = -1;
                    m.ready = 0;
                    m.betting = 0;
                    let e = this.mainRummy.getPosBySeatid(t);
                    this.mainRummy.tipTs.hideWinEffect();
                    this.mainRummy.playerTs.hidePlayer(e);
                    this.mainRummy.playerTs.stopPlayerTimer2(e);
                    this.mainRummy.playerTs.changeAwayStateStatus(e, false);
                    PushCenter.shared().pushEvent(GameConfig.Close_Magic_View, t);
                }
                else {
                    for (let a = 0; a < 6; a++) {
                        let m = i.playerModels[a];
                        if (m.uid == e.uid) {
                            t = m.seatid;
                            m.isShow = false;
                            m.status = -1;
                            m.ready = 0;
                            m.betting = 0;
                            let e = this.mainRummy.getPosBySeatid(t);
                            this.mainRummy.tipTs.hideWinEffect();
                            this.mainRummy.playerTs.hidePlayer(e);
                            this.mainRummy.playerTs.stopPlayerTimer2(e);
                            this.mainRummy.playerTs.changeAwayStateStatus(e, false);
                            PushCenter.shared().pushEvent(GameConfig.Close_Magic_View, t);
                            break;
                        }
                    }
                }
                if (i.gameRummyType != RUMMY_GAME_TYPE.PRIVATE && i.gameRummyType != RUMMY_GAME_TYPE.PRI_POOL && i.gameRummyType != RUMMY_GAME_TYPE.PRI_DEAL && i.gameRummyType != RUMMY_GAME_TYPE.MATCH || 1 == i.roomPlayerCounter && (this.mainRummy.isGameStarting = false), !this.mainRummy.isGameStarting && (i.gameRummyType == RUMMY_GAME_TYPE.PRIVATE || i.gameRummyType == RUMMY_GAME_TYPE.PRI_POOL || i.gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL || i.gameRummyType == RUMMY_GAME_TYPE.MATCH) && (i.gameRummyType != RUMMY_GAME_TYPE.PRIVATE && i.gameRummyType != RUMMY_GAME_TYPE.PRI_POOL && i.gameRummyType != RUMMY_GAME_TYPE.PRI_DEAL || (this.mainRummy.actionTs.showInviteBtn(), this.mainRummy.actionTs.showCopyBtn()), i.host_seat = null != e.creator_seatid ? e.creator_seatid : -1, this.mainRummy.is_first_round && this.mainRummy.changeRoomHost(), this.mainRummy.getReayPlayerNums() < 2)) {
                    if (RummyDataManager.shared().stopTweenAction(this.mainRummy.start_time_action), this.mainRummy.start_time_action = null, this.mainRummy.autoReadyTime = -1, ToolUtils.isObjValid(this.mainRummy.gameEndView) && (i.gameRummyType == RUMMY_GAME_TYPE.MATCH || this.mainRummy.gameEndView.getComponent(RummyGameOverAlert).showCountDown(" ")), i.roomPlayerCounter < 2) {
                        i.game_state = 5;
                    }
                    else {
                        let e = i.playerModels[i.clientSeatId];
                        e && 1 == e.ready && (i.game_state = 5);
                    }
                }
                if (0 == i.isGameStarting) {
                    if (i.gameRummyType == RUMMY_GAME_TYPE.PRIVATE || i.gameRummyType == RUMMY_GAME_TYPE.PRI_POOL || i.gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL || i.gameRummyType == RUMMY_GAME_TYPE.MATCH) {
                        this.mainRummy.actionTs.changeSwitchBtnStatus(false);
                        PushCenter.shared().pushEvent(GameConfig.Update_Menu_Switch_Status, { tid_key: this.mainRummy.tid_key, bEnable: false });
                    }
                    else {
                        let e = 0;
                        for (let a = 0; a < 6; a++) {
                            i.playerModels[a].isShow && (e += 1);
                        }
                        e <= 1 && (this.mainRummy.start_time_action && (RummyDataManager.shared().stopTweenAction(this.mainRummy.start_time_action), this.mainRummy.start_time_action = null, ToolUtils.isObjValid(this.mainRummy.gameEndView) && (i.gameRummyType == RUMMY_GAME_TYPE.MATCH ? this.mainRummy.gameEndView.getComponent(RummyPointsMatchOverAlert).showCountDown("") : this.mainRummy.gameEndView.getComponent(RummyGameOverAlert).showCountDown("")), i.game_cd = -1), PushCenter.shared().pushEvent(GameConfig.Update_Menu_Switch_Status, { tid_key: this.mainRummy.tid_key, bEnable: true }), i.game_state = 5);
                    }
                }
                i.playerGiveCards = i.playerGiveCards.filter((e => e.seatid !== t));
                this.mainRummy.refreshOpenCardPlayersInfo();
            }
        }
        catch (e) {
            TLog.printError("handler_server_logout_succed_bc,error:", e);
        }
    }
    handler_server_decard_return(e) {
        let i = RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key), t = parseInt("" + e.seatid), m = e.card;
        if (i.op_cd = e.cd, this.mainRummy.playerTs.startPlayerTimer(this.mainRummy.getPosBySeatid(t), e.cd), i.is_declare_status = true, this.mainRummy.isMyPlayer(t)) {
            sys.isObjectValid(e.all_score) && (sys.isObjectValid(e.src_score) ? sys.isObjectValid(e.finish_multiple) ? this.mainRummy.playerTs.showLoseScore(0, e.all_score, true, e.src_score, e.finish_multiple) : this.mainRummy.playerTs.showLoseScore(0, e.all_score, true, e.src_score) : this.mainRummy.playerTs.showLoseScore(0, e.all_score, true));
            i.isClientToPlay = false;
            this.mainRummy.autoDropTs.isshowAutoDropBtn(false, this.mainRummy.tid_key);
            PushCenter.shared().pushEvent(GameConfig.Update_Menu_Switch_Status, { tid_key: this.mainRummy.tid_key, bEnable: false });
            PushCenter.shared().pushEvent(GameConfig.Update_Private_Exit_Status, { tid_key: this.mainRummy.tid_key, bEnable: false });
            let t = i.playerModels[i.clientSeatId];
            t && (t.status = RUMMY_PLAYER_STATE_TYPE.FINISH);
            this.mainRummy.actionTs.onDecaredReset();
            this.mainRummy.cardsTs.showFinishTisiAnim(false);
            this.mainRummy.cardsTs.showMoPaiTisAnim(false, false);
            this.mainRummy.cardsTs.showPickCardTips(false);
            i.isCanExit = false;
            this.mainRummy.hideOpenCardAlert();
            this.mainRummy.hideWinTipAlert();
            e.cardinfos && (this.mainRummy.refreshMyShouPai(e), this.mainRummy.saveServerCardInfos(e));
            this.mainRummy.cardsTs.HuCardShowFinish(m, true);
            this.mainRummy.tipTs.show_hupai_tip(true);
            this.mainRummy.playerTs.setMultipleFireAnimShow(false, 0);
            this.mainRummy.playerTs.setMultipleFireAnimShow(false, 1);
            i.gameRummyType != RUMMY_GAME_TYPE.POOL && i.gameRummyType != RUMMY_GAME_TYPE.PRI_POOL && i.gameRummyType != RUMMY_GAME_TYPE.DEALS && i.gameRummyType != RUMMY_GAME_TYPE.PRI_DEAL || (PushCenter.shared().pushEvent(GameConfig.Update_Private_Exit_Status, { tid_key: this.mainRummy.tid_key, bEnable: false }), PushCenter.shared().pushEvent(GameConfig.Update_Menu_Switch_Status, { tid_key: this.mainRummy.tid_key, bEnable: false }));
        }
        else {
            this.mainRummy.cardsTs.HuCardShowFinish(1, false);
            i.gameRummyType != RUMMY_GAME_TYPE.POOL && i.gameRummyType != RUMMY_GAME_TYPE.PRI_POOL && i.gameRummyType != RUMMY_GAME_TYPE.DEALS && i.gameRummyType != RUMMY_GAME_TYPE.PRI_DEAL || (PushCenter.shared().pushEvent(GameConfig.Update_Private_Exit_Status, { tid_key: this.mainRummy.tid_key, bEnable: false }), PushCenter.shared().pushEvent(GameConfig.Update_Menu_Switch_Status, { tid_key: this.mainRummy.tid_key, bEnable: false }));
        }
    }
    handler_server_self_cards_return(e) {
        if (this.mainRummy.tid_key !== (e.tid_key || "")) {
            return;
        }
        if (1 == User.shared().isInPerformanceRoom) {
            return void (this.mainRummy.roomPerformance && this.mainRummy.roomPerformance.isValid && this.mainRummy.roomPerformance.handler_server_self_cards_return(e));
        }
        if (!RummyDataManager.shared().rummyInfos.has(this.mainRummy.tid_key)) {
            return;
        }
        let i = RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key);
        if (this.mainRummy.playerTs.restorePlayerImage(this.mainRummy.gameStartMsg), this.mainRummy.cardsTs.drawClear(), this.mainRummy.delayHideExitPlayers(), this.mainRummy.actionTs.changeSwitchBtnStatus(RummyDataManager.shared().isShowSwitchBtn(this.mainRummy.tid_key)), this.mainRummy._isFaPaiAnim = true, this.mainRummy.cardsTs.showMoPaiTisAnim(false, false), this.mainRummy.cardsTs.hideBestLaiziBubble(), this.mainRummy.actionTs.changeOperateBgState(true), this.mainRummy.drop_money = e.drop_money, this.mainRummy.actionTs.updateDropNum(this.mainRummy.drop_money), this.mainRummy.actionTs.setMopaiBtnInteractable(false), this.mainRummy.autoDropTs.setAutoDropBtnMoney(this.mainRummy.drop_money), i.hasFaPai = false, i.game_cd = -1, i.game_state = 0, i.game_server_state = 2, i.is_declare_status = false, i.isCanTouchCard = true, i.close_cardnum = e.close_cardnum, i.round_per_game = e.round_per_game, i.ting_round = e.round_per_game, i.winner_effects_round = e.winner_effects_round, i.laizicard = e.lz_card, i.winLaizicard = 0, i.best_lz = 0, i.lastLaizicard = 0, i.laiziFlopCard = e.flop_lz_card, i.dc_card = e.dc_card, i.bHandCardSynchronous = true, sys.isObjectValid(e.tf_bonus) && (i.tf_bonus = e.tf_bonus), this.mainRummy.playerTs.setPaiDuiBgShow(false), this.mainRummy.actionTs.changeCenterFinishBtnStatus(false), e.cardinfos) {
            this.mainRummy.saveServerCardInfos(e);
            this.mainRummy.refreshMyCardInfos(e);
            this.mainRummy.cardsTs.beginFaPaiWithAnim(e, i.cardInfoModelVec);
            TweenTool.delayAct(this.mainRummy.action_node, (() => {
                this.mainRummy.playerTs.fadeOutPaidui(0.26);
            }), 1.4, true);
            TweenTool.delayAct(this.mainRummy.action_node, (() => {
                this.mainRummy.cardsTs.setCardValueTipShow(true);
                sys.isObjectValid(e.src_score) ? sys.isObjectValid(e.finish_multiple) ? this.mainRummy.playerTs.showLoseScore(0, e.all_score, true, e.src_score, e.finish_multiple) : this.mainRummy.playerTs.showLoseScore(0, e.all_score, true, e.src_score) : this.mainRummy.playerTs.showLoseScore(0, e.all_score, true);
            }), 2, true);
            TweenTool.delayAct(this.mainRummy.action_node, (() => {
                this.mainRummy.actionTs.changeOpenCardStatus(true, this.mainRummy);
                this.mainRummy.actionTs.changeSwitchJokerStatus(true, this.mainRummy);
                this.mainRummy.playerTs.changePaiduNumVisible(true);
                this.mainRummy.playerTs.changeOpenNumVisibile(true);
                this.mainRummy.playerTs.changeRoundNumVisible(true);
                this.mainRummy.actionTs.changeCenterFinishBtnStatus(true);
                RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key).hasFaPai = true;
                1 == RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key).cardInfoModelVec.length && this.mainRummy.actionTs.changeSortBtnStatus(this.mainRummy.cardsTs.showAutoSortBtn());
                this.mainRummy._isFaPaiAnim = false;
                this.mainRummy.cardsTs.getCardValueShow() || this.mainRummy.refreshTingPaiSwitch();
                1 == i.is_bump && 1 == i.bump_notify && this.mainRummy.cardsTs.showBumpLaiziTipAnim();
            }), 2.35, true);
            TweenTool.delayAct(this.mainRummy.action_node, (() => {
                this.mainRummy.actionTs.setMopaiBtnInteractable(true);
                this.mainRummy.refreshTingPaiSwitch();
                this.mainRummy._bIsShowWinTip && (this.mainRummy.winTips.active = true, this.mainRummy.hideWinTipAlert(), this.mainRummy.rummyShowTopUiLogic.refreshWinTips());
            }), 3, true);
            1 == i.is_bump && 1 == i.bump_notify && TweenTool.delayAct(this.mainRummy.action_node, (() => {
                this.mainRummy.tipTs.setBumpTipShow(true);
            }), 3.5, true);
            let t = RummyDataManager.shared().checkLiveAvatar(this.mainRummy.tid_key, RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key).clientSeatId);
            this.showPlayerHeadAnim(0, 1, t);
        }
        else {
            i.gameRummyType != RUMMY_GAME_TYPE.PRIVATE && i.gameRummyType != RUMMY_GAME_TYPE.PRI_POOL && i.gameRummyType != RUMMY_GAME_TYPE.PRI_DEAL && i.gameRummyType != RUMMY_GAME_TYPE.MATCH && i.gameRummyType != RUMMY_GAME_TYPE.POOL && i.gameRummyType != RUMMY_GAME_TYPE.DEALS || (this.mainRummy.actionTs.changeOperateBgState(false), this.mainRummy.cardsTs.beginFaPaiWithAnim(e, {}), TweenTool.delayAct(this.mainRummy.action_node, (() => {
                this.mainRummy.playerTs.fadeOutPaidui(0.26);
            }), 1.4, true), this.mainRummy._pQipai_action = TweenTool.delayAct(this.mainRummy.action_node, (() => {
                this.mainRummy.playerTs.changeOpenNumVisibile(true);
                this.mainRummy.playerTs.changePaiduNumVisible(true);
                this.mainRummy.playerTs.changeRoundNumVisible(true);
                this.mainRummy.actionTs.changeOpenCardStatus(true, this.mainRummy);
                this.mainRummy.actionTs.changeSwitchJokerStatus(true, this.mainRummy);
                this.mainRummy.actionTs.setMopaiBtnInteractable(true);
                RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key).hasFaPai = true;
                let i = [e.dc_card];
                i.length > 0 && this.mainRummy.cardsTs.showQipaiWithAnim(i);
                this.mainRummy._isFaPaiAnim = false;
                this.mainRummy.delayRefreshPaidui();
                this.mainRummy._bIsShowWinTip && (this.mainRummy.winTips.active = true, this.mainRummy.hideWinTipAlert());
            }), 2.35, true));
        }
        if (e.start_seat) {
            e.start_seat == i.clientSeatId && (i.isClientToPlay = true);
        }
        if (i.gameRummyType == RUMMY_GAME_TYPE.PRIVATE || i.gameRummyType == RUMMY_GAME_TYPE.PRI_POOL || i.gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL || i.gameRummyType == RUMMY_GAME_TYPE.POINTS || i.gameRummyType == RUMMY_GAME_TYPE.MATCH || i.gameRummyType == RUMMY_GAME_TYPE.MULTIPLE) {
            for (let a = 1; a < 6; a++) {
                let t = i.playerModels[a];
                if (t.isShow && 1 == t.betting) {
                    let i = this.mainRummy.getPosBySeatid(t.seatid);
                    8 == t.status ? this.mainRummy.playerTs.changeAwayStateStatus(i, true, RUMMY_PLAYER_STATE_TYPE.AWAY) : 9 == e.status ? this.mainRummy.playerTs.changeAwayStateStatus(i, true, RUMMY_PLAYER_STATE_TYPE.OUT) : -1 == e.status ? this.mainRummy.playerTs.changeAwayStateStatus(i, true, RUMMY_PLAYER_STATE_TYPE.WAITING) : 11 == e.status ? this.mainRummy.playerTs.changeAwayStateStatus(i, true, RUMMY_PLAYER_STATE_TYPE.FirstWinner) : this.mainRummy.playerTs.changeAwayStateStatus(i, false);
                }
            }
        }
    }
    handler_server_next_deal_bc_return(e) {
        if (1 == User.shared().isInPerformanceRoom) {
            return void (this.mainRummy.roomPerformance && this.mainRummy.roomPerformance.isValid && this.mainRummy.roomPerformance.handler_server_next_deal_bc_return(e));
        }
        if (this.mainRummy.tid_key !== (e.tid_key || "")) {
            return;
        }
        if (!RummyDataManager.shared().rummyInfos.has(this.mainRummy.tid_key)) {
            return;
        }
        let i = RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key);
        this.mainRummy.tipTs.hideTipRootTimeTips();
        this.mainRummy.tipTs.show_finish_tip(false);
        this.mainRummy.actionTs.ishudongshow(true);
        let t = e.uid, m = e.seatid, r = e.dealTs, o = e.can_mp;
        this.mainRummy.game_cd = r;
        let l = e.round_per_game, p = e.is_able_auto_group, T = i.round_per_game;
        if (i.op_cd = r, i.timeout_cd = e.cd - r, i.is_table_change_status = false, i.is_declare_status = false, i.round_per_game = l, i.ting_round = l, i.isAbleAutoGroup = p, i.disCardTipsValue = 0, i._mopai_time = -1, i._discard_time = -1, i._drop_time = -1, i._declare_time = -1, i.gameRummyType != RUMMY_GAME_TYPE.PRI_POOL && i.gameRummyType != RUMMY_GAME_TYPE.PRI_DEAL && i.gameRummyType != RUMMY_GAME_TYPE.MATCH && (PushCenter.shared().pushEvent(GameConfig.Update_Private_Exit_Status, { tid_key: this.mainRummy.tid_key, bEnable: true }), PushCenter.shared().pushEvent(GameConfig.Update_Menu_Switch_Status, { tid_key: this.mainRummy.tid_key, bEnable: true })), this.mainRummy.delayShowEnterPlayers(), this.mainRummy.delayHideExitPlayers(), this.mainRummy.playerTs.updateRoundNum(l), this.mainRummy.playerTs.updateMultipleTimes(l), l > 1 ? i.multiple_fire_round > 0 && l >= i.multiple_fire_round && (this.mainRummy.playerTs.setMultipleFireAnimShow(true, 1), T != l && sys.isObjectValid(i.multiple_cfg[l]) && i.multiple_cfg[T] != i.multiple_cfg[l] && this.mainRummy.playerTs.setMultipleFireAnimShow(true, 0)) : (this.mainRummy.playerTs.setMultipleFireAnimShow(false, 1), this.mainRummy.playerTs.setMultipleFireAnimShow(false, 0)), this.mainRummy.isCanmqp = false, t == User.shared().data.uid) {
            if (i._pre_drop_type >= 0 && 4 != i.game_state && this.mainRummy.autoDropTs.handler_auto_drop_request(this.mainRummy.tid_key, i._pre_drop_type), this.mainRummy.checkIsPointsMatch()) {
                let e = this.mainRummy.pop_layer4.getChildByName("commondialog_node");
                ToolUtils.isObjValid(e) && (this.mainRummy.hasPointsMatchExitAlert || e.destroy());
            }
            else {
                Utils.shared().hideCommomDialog(this.mainRummy.pop_layer4);
            }
            Utils.shared().hideOtherQuickPayAlertByType();
            Utils.shared().hideOtherQuickPayAlertByType(null, this.mainRummy.node);
            PushCenter.shared().pushEvent(PushEvent.HideWinShareView);
            PushCenter.shared().pushEvent(PushEvent.CloseRoomRankAct);
            0 == i.auto_drop_type && (SoundManager.shared().playFx("rummySelfTurn"), TransferPlatform.shared().openVibrate());
            i.isCanTouchCard = true;
            i.game_state = 3;
            i.game_server_state = 2;
            i.game_cd = 2;
            i.isClientToPlay = true;
            0 == i.gameRummyMode && (this.mainRummy.isCanmqp = 0 == o);
            this.mainRummy.actionTs.changeOperateBgState(true);
            this.mainRummy.actionTs.changeFinishBtnStatus(false);
            this.mainRummy.tipTs.setMultipleCenterTipsShow(false);
            0 == i.gameRummyMode && this.mainRummy.actionTs.changeDropBtnStatus(true);
            let t = false, m = sys.localStorage.getItem("open_deck_pick_def");
            if (null == m && (m = User.shared().help_setting.open_deck_pick_def), 1 == User.shared().help_setting.open_deck_pick && sys.isObjectValid(m) && 1 == Number(m) && (t = true), sys.isObjectValid(e.helper_pick_card) && t ? (this.mainRummy.cardsTs.showMoPaiTisAnim(true, this.mainRummy.isCanmqp, true), sys.isObjectValid(e.helper_pick_card_array) && this.mainRummy.cardsTs.showHighTipsCards(e.helper_pick_card_array, e.helper_pick_group_index)) : (this.mainRummy.cardsTs.showMoPaiTisAnim(true, this.mainRummy.isCanmqp), this.mainRummy.cardsTs.hideCardTipsGlow()), i.isPlayingCard = false, this.mainRummy.actionTs.setMopaiBtnInteractable(true), this.mainRummy.actionTs.changeDirectionBtnStatus(false), this.mainRummy.actionTs.changeAutoGroupBtnStatus(true), this.mainRummy.rummyShowTopUiLogic.removeRoomTask(true), null != e.auto_drop && null != e.auto_drop && 0 != e.auto_drop || this.mainRummy.autoDropTs.isshowAutoDropBtn(false, this.mainRummy.tid_key), sys.isObjectValid(e.show_autodrop)) {
                let i = 1 == e.show_autodrop;
                this.mainRummy.autoDropTs.isshowAutoDropBtn(i, this.mainRummy.tid_key);
            }
            RummyDataManager.shared().reSetTouchCardState(this.mainRummy.tid_key);
            PushCenter.shared().pushEvent(PushEvent.HideRoomActRankPop);
            ToolUtils.isObjValid(this.mainRummy.switchJokerNode) && (this.mainRummy.switchJokerNode.active = false);
            i.force_up_venue = null;
            sys.isObjectValid(e.force_up_venue_tips_drop) && (i.force_up_venue = e.force_up_venue_tips_drop);
            i.gameRummyType != RUMMY_GAME_TYPE.POINTS && i.gameRummyType != RUMMY_GAME_TYPE.MULTIPLE || this.mainRummy.autoDropTs.checkHasShowDropAlert() && (this.mainRummy.autoDropTs.dropType = 0);
        }
        else {
            i.isClientToPlay = false;
            this.mainRummy.actionTs.changeFinishBtnStatus(false);
            this.mainRummy.actionTs.changeDiscardBtnStatus(false);
            this.mainRummy.actionTs.changeDropBtnStatus(false);
            this.mainRummy.actionTs.changeAutoGroupBtnStatus(true);
            this.mainRummy.cardsTs.showFinishTisiAnim(false);
            i.hasChupai = false;
            i.isCanTouchCard = true;
            i.isPlayingCard = false;
            this.mainRummy.tipTs.changePickTipsVisible(0, false);
            this.mainRummy.actionTs.changeDirectionBtnStatus(true);
            this.mainRummy.cardsTs.showMoPaiTisAnim(false, false);
            this.mainRummy.cardsTs.showPickCardTips(false);
            let t = i.clientSeatId, m = i.playerModels[t];
            if ((0 != m.status && 4 != m.status || 1 != m.betting) && this.mainRummy.actionTs.changeAutoGroupBtnStatus(false), 0 == i.auto_drop_type && 0 == i.gameRummyMode && 0 == m.status && 1 == m.betting) {
                if (i.gameRummyType == RUMMY_GAME_TYPE.DEALS || i.gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL) {
                    if (1 == i.dealsrummyIsCanFold && sys.isObjectValid(e.show_autodrop)) {
                        let i = 1 == e.show_autodrop;
                        this.mainRummy.autoDropTs.isshowAutoDropBtn(i, this.mainRummy.tid_key);
                    }
                }
                else if (sys.isObjectValid(e.show_autodrop)) {
                    let i = 1 == e.show_autodrop;
                    this.mainRummy.autoDropTs.isshowAutoDropBtn(i, this.mainRummy.tid_key);
                }
            }
        }
        let g = this.mainRummy.cardsTs.getSelectedCards();
        g.length >= 2 && g.length < 13 ? (this.mainRummy.actionTs.changeGroupBtnStatus(true), this.mainRummy.autoDropTs.setAutoDropBtn(1)) : (this.mainRummy.actionTs.changeGroupBtnStatus(false), this.mainRummy.autoDropTs.setAutoDropBtn(2));
        this.mainRummy.playerTs.startPlayerTimer(this.mainRummy.getPosBySeatid(m), r, false, null);
        this.mainRummy.cardsTs.showAutoSortBtn() && this.mainRummy.autoDropTs.setAutoDropBtn(1);
        this.mainRummy.actionTs.changeSortBtnStatus(this.mainRummy.cardsTs.showAutoSortBtn());
        i.gameRummyType != RUMMY_GAME_TYPE.PRIVATE && i.gameRummyType != RUMMY_GAME_TYPE.PRI_POOL && i.gameRummyType != RUMMY_GAME_TYPE.PRI_DEAL || this.mainRummy.actionTs.hideReadyBtn();
        i.curOptSeatid = m;
        this.mainRummy.playerTs.showEasyGameLight(this.mainRummy.getPosBySeatid(m));
    }
    handler_server_drop_card_return(e) {
        if (this.mainRummy.tid_key !== (e.tid_key || "")) {
            return;
        }
        if (!RummyDataManager.shared().rummyInfos.has(this.mainRummy.tid_key)) {
            return;
        }
        let i = RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key);
        if (0 == e.ret) {
            User.shared().curTid_key == this.mainRummy.tid_key && (SoundManager.shared().playFx("rummyDrop"), !this.mainRummy.has_treasureHuntAct || i.gameRummyType != RUMMY_GAME_TYPE.POINTS && i.gameRummyType != RUMMY_GAME_TYPE.MULTIPLE || sys.isObjectValid(this.mainRummy.treahuntTaskData) && this.mainRummy.treahuntTaskData.cju + 1 < this.mainRummy.treahuntTaskData.tju && PushCenter.shared().pushEvent(PushEvent.UpdateTreaHuntProgress, { vid: i.vid }), TweenTool.delayAct(this.mainRummy.node, (() => {
                if (User.shared().curTid_key == this.mainRummy.tid_key) {
                    let e = RummyDataManager.shared().getSeatidByPos(0, this.mainRummy.tid_key), i = RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key).playerModels[e];
                    if (i && this.mainRummy.tid_key == User.shared().curTid_key) {
                        let e = 2 == i.sex ? "female" : "male";
                        SoundManager.shared().playSound(ToolUtils.format("disappointed_${0}", e), null, null, 0.2);
                    }
                }
            }), 0.2, true));
            i._drop_time > 0 && (HttpManager.shared().doServerMsgResponseReport({ type: 17, c_t: i._drop_time, o_t: sys.now() }), i._drop_time = -1);
            this.mainRummy.pickCardInfo = null;
            i.dropType = e.drop_type;
            this.mainRummy.my_drop_card_state_show(i);
            this.mainRummy.autoDropTs.isshowAutoDropBtn(false, this.mainRummy.tid_key);
            this.mainRummy.actionTs.changeAutoGroupBtnStatus(false);
            this.mainRummy.cardsTs.setCardValueTipShow(false);
            this.mainRummy.cardsTs.showPickCardTips(false);
            this.mainRummy.refreshTingPaiSwitch();
            this.mainRummy.autoDropTs.hideAllLayer();
            ToolUtils.isObjValid(this.mainRummy.switchJokerNode) && (this.mainRummy.switchJokerNode.active = false);
            let t = i.clientSeatId;
            null != e.all_score && (sys.isObjectValid(e.src_score) ? sys.isObjectValid(e.finish_multiple) ? this.mainRummy.playerTs.showLoseScore(0, e.all_score, true, e.src_score, e.finish_multiple) : this.mainRummy.playerTs.showLoseScore(0, e.all_score, true, e.src_score) : this.mainRummy.playerTs.showLoseScore(0, e.all_score, true));
            this.mainRummy.playerTs.stopPlayerTimerByPos(0);
            null != e.cur_money && this.mainRummy.playerTs.updatePlayerMoney(0, e.cur_money);
            i.gameRummyType != RUMMY_GAME_TYPE.PRI_POOL && i.gameRummyType != RUMMY_GAME_TYPE.PRI_DEAL && i.gameRummyType != RUMMY_GAME_TYPE.MATCH || PushCenter.shared().pushEvent(GameConfig.Update_Private_Exit_Status, { tid_key: this.mainRummy.tid_key, bEnable: true });
            null != e.score && (this.mainRummy.playerTs.setPoolScore(0, e.score), this.mainRummy.updateSeatScore(t, e.score));
            this.mainRummy.actionTs.changeSortBtnStatus(false);
            this.mainRummy.actionTs.setMopaiBtnInteractable(false);
            2 == e.drop_type && i.gameRummyType != RUMMY_GAME_TYPE.MATCH && (i.gameRummyType == RUMMY_GAME_TYPE.POINTS || i.gameRummyType == RUMMY_GAME_TYPE.MULTIPLE ? 1 != e.stay_in_table && (sys.isObjectValid(e.show_new_player_guide) && 1 == e.show_new_player_guide ? (HttpManager.shared().doReportPlayerGuideAct(PhpReportDefined.roomPlayerGuideEvent.dropCardShow), this.mainRummy.showGuideTips((() => {
                this.mainRummy.switchRoom(5);
            }))) : this.mainRummy.switchRoom(5)) : this.mainRummy.switchRoom(5));
        }
        else {
            const message = ToolUtils.isSafeString(e.alertStr);
            if (message.length > 0) Utils.shared().showToast(message, 2, 0, ToolUtils.getIsNormalDirection());
        }
    }
    handler_server_notify_match_push(e) {
        0 == e.ret ? sys.isObjectValid(e.is_over) && (sys.isObjectValid(e.raceid) && (this.mainRummy.freeMatchRaceId = e.raceid), 0 == e.is_over && (this.mainRummy.checkHasMatchJoinTips() || (this.mainRummy.hasFreeMatchPush = true, this.mainRummy.actionTs.changeMatchRankBtnVisibile(true), this.mainRummy.tipTs.setFreeMatchPushActive(true), this.mainRummy.tipTs.refreshFreeMatchPush(e), this.mainRummy.delayFreeMatchAct && TweenTool.stopAction(this.mainRummy.delayFreeMatchAct), this.mainRummy.delayFreeMatchAct = TweenTool.delayAct(this.mainRummy.time_node, (() => {
            ToolUtils.isObjValid(this.mainRummy.node) && this.mainRummy.tipTs.setFreeMatchPushActive(false);
        }), 10, true)))) : 1 == e.ret && (this.mainRummy.checkHasMatchJoinTips() || (this.mainRummy.actionTs.changeMatchRankBtnVisibile(false), this.mainRummy.hasFreeMatchPush = false));
    }
    dealPrivateTableTips() {
        let e = RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key);
        if (e.gameRummyType == RUMMY_GAME_TYPE.PRIVATE || e.gameRummyType == RUMMY_GAME_TYPE.PRI_POOL || e.gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL) {
            if (e.roomPlayerCounter < 2) {
                this.mainRummy.autoReadyTime = -1;
                e.game_state = 5;
            }
            else {
                let i = e.clientSeatId, a = e.playerModels[i];
                if (a) {
                    if (1 != a.ready) {
                        if (this.mainRummy._bIsShowReady) {
                            let i = true;
                            e.gameRummyType != RUMMY_GAME_TYPE.PRI_POOL && e.gameRummyType != RUMMY_GAME_TYPE.PRI_DEAL || (1 !== ToolUtils.isSafeNumber(this.mainRummy._gameOverMsg.all_end) && (i = false), 2 === ToolUtils.isSafeNumber(this.mainRummy._gameOverMsg.settle_type) && (i = false));
                            e.gameRummyType !== RUMMY_GAME_TYPE.PRIVATE && (i ? this.mainRummy.actionTs.showReadyBtn() : this.mainRummy.actionTs.hideReadyBtn());
                        }
                    }
                    else if (this.mainRummy.getReayPlayerNums() < 2) {
                        let e = i18nMgr.shared().getValueByKey("rummy_main.gameTipstext7");
                        ToolUtils.isObjValid(this.mainRummy.gameEndView) && this.mainRummy.gameEndView.active && this.mainRummy.gameEndView.getComponent(RummyGameOverAlert).showCountDown(e);
                    }
                }
            }
        }
        else if (e.gameRummyType == RUMMY_GAME_TYPE.MATCH && e.roomPlayerCounter < 2 && (this.mainRummy.autoReadyTime = -1, e.game_state = 5, ToolUtils.isObjValid(this.mainRummy.gameEndView) && this.mainRummy.gameEndView.active)) {
            let i = i18nMgr.shared().getValueByKey("rummy_main.gameTipstext7");
            e.gameRummyType === RUMMY_GAME_TYPE.MATCH ? this.mainRummy.gameEndView.getComponent(RummyPointsMatchOverAlert).showCountDown(i) : this.mainRummy.gameEndView.getComponent(RummyGameOverAlert).showCountDown(i);
        }
    }
    checkReadyBtn() {
        let e = RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key);
        if (e.gameRummyType == RUMMY_GAME_TYPE.PRIVATE) {
            let i = e.clientSeatId;
            1 != e.playerModels[i].ready && e.isGameOver && this.mainRummy.actionTs.showReadyBtn();
        }
        else if ((e.gameRummyType == RUMMY_GAME_TYPE.PRI_POOL || e.gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL) && (!this.mainRummy._gameOverMsg || this.mainRummy._gameOverMsg && 1 === this.mainRummy._gameOverMsg.all_end)) {
            let i = e.clientSeatId;
            if (1 != e.playerModels[i].ready && e.isGameOver) {
                let i = true;
                e.gameRummyType == RUMMY_GAME_TYPE.PRI_DEAL && 2 === ToolUtils.isSafeNumber(this.mainRummy._gameOverMsg.settle_type) && (i = false);
                i && this.mainRummy.actionTs.showReadyBtn();
            }
        }
    }
    showGameEndBtn() {
        let e = true, i = RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key);
        if (ToolUtils.isObjValid(this.mainRummy.gameEndView)) {
            if (i.gameRummyType === RUMMY_GAME_TYPE.MATCH) {
                this.mainRummy.gameEndView.getComponent("RummyPointsMatchOverAlert").reshow_btn(true);
            }
            else {
                this.mainRummy.gameEndView.getComponent("RummyGameOverAlert").reshow_btn(true);
            }
            e = false;
        }
        if (ToolUtils.isObjValid(this.mainRummy.gameHistoryView) && RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key).gameRummyType == RUMMY_GAME_TYPE.PRIVATE) {
            let i = this.mainRummy.gameHistoryView.getComponent("RummyGameOverAlert");
            i.isAlreadyShow() && i.checkShowWinShareBtn();
            e = false;
        }
        if (ToolUtils.isObjValid(this.mainRummy.RummyTotalSettlementNode)) {
            let i = this.mainRummy.RummyTotalSettlementNode.getComponent(RummyTotalSettlement);
            i.isAlreadyShow() && i.checkShowShareBtn();
            e = false;
        }
        e && PushCenter.shared().pushEvent(PushEvent.ShowWinShareBtn, false);
    }
    reshowActBtn() {
        this.mainRummy.actionTs.reshow_btn();
    }
    refreshCurDesk() {
        let e = RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key);
        this.showGameEndBtn();
        this.reshowActBtn();
        this.refreshPlayerSeat();
        this.mainRummy.cardsTs.refreshArrowAnim();
        this.mainRummy.cardsTs.refreshxipaicolor();
        this.mainRummy.playerTs.refreshMultipleAnim();
        this.mainRummy._isFaPaiAnim ? (TransferPlatform.shared().setHighFrameRate(), sys.now() - this._lastChangeDeskTime <= 1000 && (this.mainRummy._isFaPaiAnim = false, this.mainRummy.send_request_tableinfo()), this._lastChangeDeskTime = sys.now()) : (1 == e.is_showhuAnim_status ? TransferPlatform.shared().setHighFrameRate() : TransferPlatform.shared().setNormalFrameRate(), e.hasFaPai && e.close_cardnum >= 2 && this.mainRummy.cardsTs.checkIfHasPaidui(e.close_cardnum));
        let i = false, t = false;
        if (e.gameRummyType != RUMMY_GAME_TYPE.PRIVATE && e.gameRummyType != RUMMY_GAME_TYPE.PRI_POOL && e.gameRummyType != RUMMY_GAME_TYPE.PRI_DEAL && e.gameRummyType != RUMMY_GAME_TYPE.MATCH && (t = true), this.mainRummy.checkIsPointsMatch() && (t = true), t && (i = 1 == e.is_waiting || 1 == e.game_state, i && this.mainRummy.cardsTs.hideMyHandCards()), ToolUtils.in_isGuideRoom >= 1 && this.mainRummy.updateTaskBtn(), this.mainRummy.rummyShowTopUiLogic.refreshTask(), e.gameRummyType != RUMMY_GAME_TYPE.MATCH) {
            let e = this.mainRummy.pop_layer4.getChildByName("match_game_over");
            ToolUtils.isObjValid(e) && (e.active = false, e.destroy(), this.mainRummy.matchTotalSettleMsg = null);
        }
        if (this.mainRummy.has_treasureHuntAct && (this.mainRummy.actionTs.updateTreasureHuntBtn(3, null, true), ToolUtils.isObjValid(this.mainRummy.gameEndView) && e.gameRummyType != RUMMY_GAME_TYPE.MATCH && 1 == e.crashModel)) {
            this.mainRummy.gameEndView.getComponent("RummyGameOverAlert").updateTreasureHuntBanner(null);
        }
        if (ToolUtils.isObjValid(this.mainRummy.gameEndView) && e.gameRummyType != RUMMY_GAME_TYPE.MATCH) {
            let e = this.mainRummy.gameEndView.getComponent("RummyGameOverAlert");
            e && e.refreshRoomActAnim();
        }
        if (ToolUtils.isObjValid(this.mainRummy.RummyTotalSettlementNode)) {
            let e = this.mainRummy.RummyTotalSettlementNode.getComponent(RummyTotalSettlement);
            e && e.refreshRoomActAnim();
        }
        if (this.mainRummy.tipTs.refreshWinEffect(), sys.isObjectValid(User.shared().roomNovicesData) && sys.isObjectValid(User.shared().roomNovicesData.data) && sys.isObjectValid(User.shared().roomNovicesData.data.show) && 1 == User.shared().roomNovicesData.data.show) {
            let e = User.shared().roomNovicesData.data.progress;
            sys.isObjectValid(e) && e.vid == RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key).vid ? this.mainRummy.actionTs.updateNovicesTaskBtn(true) : this.checkNovicesTask();
        }
        if (1 == User.shared().new_user_flopcash_open && RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key).gameRummyType == RUMMY_GAME_TYPE.POINTS && 0 == RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key).crashModel) {
            let e = RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key).flopCashTaskLaba;
            sys.isObjectValid(e) && sys.isObjectValid(e.current_task_status) && 2 == e.current_task_status && this.updateFlopCashTask(e);
        }
    }
    dealLocalDisCardCard(e) {
        let i = RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key);
        if (i.able_local_discard && sys.isObjectValid(e)) {
            let t = e.index, m = e.cardIndex, n = e.isQipai, r = e.card, d = this.mainRummy.handCardDataAnalysis.resortDiscardCards(t, m, this.mainRummy.cardsTs.myGroupcardValueVec);
            i.cardInfoModelVec = [];
            for (let e = 0, a = d.length; e < a; e++) {
                i.cardInfoModelVec.push(d[e]);
            }
            let u = i.disCardTipsValue;
            i.disCardTipsValue = 0;
            this.mainRummy.cardsTs.hideTingPaiTips();
            n || (i.is_showhuAnim_status = true, this.mainRummy.playerTs.setMultipleFireAnimShow(false, 0), this.mainRummy.playerTs.setMultipleFireAnimShow(false, 1));
            this.mainRummy.cardsTs.playOutCards(r, 0, n, false, this.mainRummy.qipaiCardValues, t, m);
            this.mainRummy.hasPlayOutLocalCard = true;
            this.mainRummy.cardsTs.myGroupcardValueVec = d;
            i.isClientToPlay = false;
            TweenTool.delayAct(this.mainRummy.time_node, (() => {
                this.mainRummy.hasPlayOutLocalCard && (n && (gameNetworkDelay.shared().isShowNetworkDelay(true), i.disCardTipsValue = u, sys.isObjectValid(this.mainRummy.cardInfoMsg) && sys.isObjectValid(this.mainRummy.cardInfoMsg.cardinfos) && this.mainRummy.refreshMyCardInfos(this.mainRummy.cardInfoMsg, false), this.mainRummy.cardsTs.beginFaPaiWithoutAnim(RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key).cardInfoModelVec, RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key).cardInfoModelVec.length), this.mainRummy.qipaiCardValues.pop(), this.mainRummy.cardsTs.qipai_node.removeAllChildren(), this.mainRummy.qipaiCardValues.length > 0 && this.mainRummy.cardsTs.showQipaiWithAnim(this.mainRummy.qipaiCardValues), this.mainRummy.refreshTingPaiSwitch(0), i.isClientToPlay || (i.isClientToPlay = true)), this.mainRummy.hasPlayOutLocalCard = false);
            }), RummyCardConstant.DiscardDelayTime, true);
            n || (this.mainRummy.handler_server_discard_request(1, this.mainRummy.finishType, e), i.bIsHasHu = true, i.isCanTouchCard = false, this.mainRummy.actionTs.changeDropBtnStatus(false), this.mainRummy.actionTs.changeGroupBtnStatus(false), this.mainRummy.cardsTs.showFinishTisiAnim(false), this.mainRummy.cardsTs.showMoPaiTisAnim(false, false), this.mainRummy.tipTs.show_finish_tip(false), i.isPlayingCard = false, this.mainRummy.cardsTs.hideTingPaiTips(), this.mainRummy.tingPaiTs.changeTingPaiBubbleVisible(false), this.mainRummy.tipTs.showQuickFinishTips(false), this.mainRummy.autoDropTs.isshowAutoDropBtn(false, this.mainRummy.tid_key), this.mainRummy.actionTs.changeAutoGroupBtnStatus(false), this.mainRummy.autoDropTs.hideAllLayer(), this.mainRummy.actionTs.changeFinishBtnStatus(false), this.mainRummy.actionTs.changeSortBtnStatus(false), this.mainRummy.actionTs.changeDiscardBtnStatus(false), TweenTool.delayAct(this.mainRummy.time_node, (() => {
                this.mainRummy.showLocalFinishResult();
            }), 1, true));
        }
    }
    refreshTingPaiSwitch(e = 0) {
        let i = RummyDataManager.shared().getCanShowTingPai();
        if (sys.isObjectValid(this.mainRummy.pickCardInfo) && 0 != this.mainRummy.pickCardInfo.helper_pick_label) {
            this.mainRummy.tingpaiNode.active = true;
            this.mainRummy.tingPaiTs.iconNode.active = true;
            this.mainRummy.cardsTs.restoreTingPaiTips();
            this.mainRummy.tingPaiTs.changeTingPaiBubbleVisible(false);
            this.mainRummy.tingPaiTs.showPickCardTips(true, this.mainRummy.pickCardInfo.helper_pick_label);
        }
        else if (i) {
            let i = RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key);
            if (i && !i.hasFaPai) {
                return;
            }
            if (this.mainRummy.tingpaiNode.active = true, sys.isObjectValid(this.mainRummy.tingPaiMsg) && sys.isObjectValid(this.mainRummy.tingPaiMsg.listen_info) && ToolUtils.isObjValid(this.mainRummy.tingPaiTs.iconNode)) {
                if (this.mainRummy.tingPaiTs.iconNode.active = true, this.mainRummy.tingPaiTs.showPickCardTips(false), 0 == e) {
                    let e = false;
                    RummyDataManager.shared().getCanShowQuickFinish() && this.mainRummy.helper_hu_card > 0 && (e = true);
                    this.mainRummy.cardsTs.showTingPaiTips(this.mainRummy.tingPaiMsg, e);
                    this.mainRummy.tingPaiTs.bubbleNode.active && this.mainRummy.tingPaiTs._cur_cardValue > 0 && this.mainRummy.cardsTs.showtLightTingPai(this.mainRummy.tingPaiTs._cur_cardValue);
                }
                else {
                    TweenTool.delayAct(this.mainRummy.time_node, (() => {
                        let e = false;
                        RummyDataManager.shared().getCanShowQuickFinish() && this.mainRummy.helper_hu_card > 0 && (e = true);
                        this.mainRummy.cardsTs.showTingPaiTips(this.mainRummy.tingPaiMsg, e);
                        this.mainRummy.tingPaiTs.bubbleNode.active && this.mainRummy.tingPaiTs._cur_cardValue > 0 && this.mainRummy.cardsTs.showtLightTingPai(this.mainRummy.tingPaiTs._cur_cardValue);
                    }), e, true);
                }
            }
            else {
                this.mainRummy.tingPaiTs.hideTingPaiUI();
                this.mainRummy.cardsTs.hideTingPaiTips();
                this.mainRummy.tingPaiMsg = null;
                this.mainRummy.pickCardInfo = null;
            }
        }
        else {
            this.mainRummy.hideAllTingPaiFlag();
        }
    }
    handler_server_pool_drop_return(e) {
        let i = i18nMgr.shared().getValueByKey("store.okey"), a = i18nMgr.shared().getValueByKey("rummy_main.cancel"), t = ToolUtils.format(i18nMgr.shared().getValueByKey("rummy_main.drop_text2"), e.disuse_score);
        e.fail_score + e.total_score >= e.disuse_score ? 2 == e.is_auto_drop ? this.mainRummy.autoDropTs.showDropNode(this.mainRummy.tid_key, t, 1, i, a) : this.mainRummy.autoDropTs.showDropNode(this.mainRummy.tid_key, t, 0, i, a) : 2 == e.is_auto_drop ? this.mainRummy.autoDropTs.handler_auto_drop_request(this.mainRummy.tid_key, 1) : (t = i18nMgr.shared().getValueByKey("rummy_main.drop_text1"), this.mainRummy.autoDropTs.showDropNode(this.mainRummy.tid_key, t, 0, i, a));
    }
    handler_server_gong_cards_return(e) {
        if (this.mainRummy.tid_key !== (e.tid_key || "")) {
            return;
        }
        let i, a = [];
        if (a.cards = [], this.mainRummy.qipaiCardValues = [], e.cards) {
            for (let t = 0, m = e.cards.length; t < m; t++) {
                i = e.cards[t];
                a.cards.push(i);
                this.mainRummy.qipaiCardValues.push(i);
            }
        }
        a.cards_mark = [];
        let t = 0, m = false;
        if (e.cards_mark) {
            for (let s = 0, n = e.cards_mark.length; s < n; s++) {
                i = e.cards_mark[s];
                a.cards_mark.push(i);
                m || e.cards_mark[s].c == e.dc_card && (t += 1, s == e.last_mark_idx && (m = true));
            }
        }
        a.first_card = e.first_card;
        a.comcard_iscatch = e.comcard_iscatch;
        a.dc_card = e.dc_card;
        a.mark_idx = t;
        this.mainRummy.playerTs.updateOpenNum(a.cards.length);
        this.mainRummy.isOpenQipai && this.mainRummy.changeQiPaiTableStatus(true, a, e.is_out_card);
        RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key).dc_card = e.dc_card;
        RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key).laizicard = e.lz_card;
        RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key).laiziFlopCard = e.flop_lz_card;
        this.mainRummy.cardsTs.syncOpenPile(e.cards);
    }
    handler_server_pick_card_bc_return(e) {
        if (1 == User.shared().isInPerformanceRoom) {
            return void (this.mainRummy.roomPerformance && this.mainRummy.roomPerformance.isValid && this.mainRummy.roomPerformance.handler_server_pick_card_bc_return(e));
        }
        if (this.mainRummy.tid_key !== (e.tid_key || "")) {
            return;
        }
        if (!RummyDataManager.shared().rummyInfos.has(this.mainRummy.tid_key)) {
            return;
        }
        this.mainRummy.pickCardInfo = null;
        let i = RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key), t = e.close_cardnum;
        i.close_cardnum = t;
        i.is_reshuffle = ToolUtils.isSafeNumber(e.is_reshuffle);
        1 === e.is_reshuffle && (t = 0, TweenTool.delayAct(this.mainRummy.time_node, (() => {
            this.mainRummy.playerTs.updateCloseNum(i.close_cardnum);
            this.mainRummy.playerTs.updateOpenNum(0);
        }), 1.5, true));
        this.mainRummy.playerTs.updateCloseNum(t);
        let m = e.type, n = parseInt("" + e.seatid), r = e.uid, h = i.dc_card;
        e.card ? h = e.card : sys.isObjectValid(e.catch_card) && (h = e.catch_card);
        let y = this.mainRummy.getPosBySeatid(n);
        if (r != User.shared().data.uid) {
            this.mainRummy.cardsTs.showMoPaiTisAnim(false, false);
            this.mainRummy.cardsTs.showPickCardTips(false);
            let e = i.cardInfoModelVec;
            if (!(e && e.length > 0)) {
                let a = i.clientSeatId;
                1 == i.playerModels[a].betting && this.send_request_tableinfo();
                e = [];
            }
            this.mainRummy.cardsTs.getMoPai(y, m, h, e);
        }
        else {
            i._mopai_time > 0 && (HttpManager.shared().doServerMsgResponseReport({ type: 15, c_t: i._mopai_time, o_t: sys.now() }), i._mopai_time = -1);
            let t = this.getAutoSortAnimGroup(e);
            this.mainRummy.saveServerCardInfos(e);
            this.mainRummy.tipTs.changePickTipsVisible(0, false);
            this.mainRummy.cardsTs.setCardValueTipShow(false);
            this.mainRummy.cardsTs.hideCardTipsGlow();
            i.game_cd = -1;
            i.game_state = 0;
            i.game_server_state = 2;
            let n = e.ret;
            if (0 == n) {
                let n = null, r = null;
                e.helper_discard_card && (i.disCardTipsValue = e.helper_discard_card);
                (this.mainRummy.cardsTs.checkHasTingPaiTip(this.mainRummy.tingPaiMsg, e.cardinfos) || sys.isObjectValid(e.helper_hu_card)) && (i.disCardTipsValue = 0);
                i.isAbleAutoGroup && (e.cardinfos_before && (n = this.mainRummy.getCardinfosBefore(e)), null != e.catch_groupindex && null != e.catch_groupindex && (r = e.catch_groupindex));
                e.cardinfos && this.mainRummy.refreshMyCardInfos(e);
                i.mp_refresh = false;
                this.mainRummy.cardsTs.getMoPai(0, m, h, i.cardInfoModelVec, n, r, i.bHasLocalPickUp, t);
                i.bHasLocalPickUp = false;
                this.mainRummy.cardsTs.showMoPaiTisAnim(false, true);
                this.mainRummy.cardsTs.showFinishTisiAnim(true);
                this.mainRummy.cardsTs.showPickCardTips(false);
                i.hasChupai = false;
                sys.isObjectValid(e.src_score) ? sys.isObjectValid(e.finish_multiple) ? (i.finish_multiple = e.finish_multiple, this.mainRummy.playerTs.showLoseScore(0, e.all_score, true, e.src_score, e.finish_multiple)) : this.mainRummy.playerTs.showLoseScore(0, e.all_score, true, e.src_score) : this.mainRummy.playerTs.showLoseScore(0, e.all_score, true);
                1 == e.positive && this.mainRummy.playEffectByName("rummyPositiveGroup");
                this.mainRummy.drop_money = e.drop_money;
                this.mainRummy.autoDropTs.setAutoDropBtnMoney(this.mainRummy.drop_money);
                this.mainRummy.actionTs.onPickUpReset(this.mainRummy.drop_money, this.mainRummy.cardsTs.showAutoSortBtn());
                let d = 0.4;
                n && n.length > 0 ? (d = 1.3, sys.isObjectValid(e.delayTime) && (d = Number(e.delayTime))) : sys.isObjectValid(e.delayTime) && (d = Number(e.delayTime));
                let u = d < 0.65 ? 0.65 : d;
                this.mainRummy.refreshTingPaiSwitch(u);
                this.mainRummy.helper_hu_card = ToolUtils.isSafeNumber(e.helper_hu_card);
                this.mainRummy.finish_groups = null;
                this.mainRummy.quick_sort = 0;
                sys.isObjectValid(e.finish_groups) && (this.mainRummy.finish_groups = e.finish_groups, this.mainRummy.quick_sort = RummyDataManager.shared().checkSameCards(e.cardinfos, e.finish_groups));
                this.mainRummy.can_declare = ToolUtils.isSafeNumber(e.can_declare);
                RummyDataManager.shared().getCanShowQuickFinish() && 1 == ToolUtils.isSafeNumber(e.can_declare) && 0 != this.mainRummy.helper_hu_card && (this.mainRummy.tingPaiMsg = null, this.mainRummy.cardsTs.hideTingPaiTips(), i.isCanTouchCard = false, TweenTool.delayAct(this.mainRummy.time_node, (() => {
                    if (sys.isObjectValid(e.helper_hu_card)) {
                        let i = RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key);
                        1 == i.is_bump && sys.isObjectValid(e.bump_win_lz) && sys.isObjectValid(e.bump_last_lz) && e.bump_last_lz > 0 && ToolUtils.getCardInfo(e.bump_win_lz).point != ToolUtils.getCardInfo(e.bump_last_lz).point ? this.mainRummy.tipTs.showQuickFinishTips(true, e.bump_win_lz, e.bump_last_lz) : this.mainRummy.tipTs.showQuickFinishTips(true);
                        this.mainRummy.playerTs.hideBonustTime();
                        sys.isObjectValid(this.mainRummy.cardInfoMsg) && sys.isObjectValid(this.mainRummy.cardInfoMsg.cardinfos) && this.mainRummy.refreshMyCardInfos(this.mainRummy.cardInfoMsg, false);
                        this.mainRummy.cardsTs.beginFaPaiWithoutAnim(i.cardInfoModelVec, i.cardInfoModelVec.length);
                        this.mainRummy.cardsTs.showHelperQuickFinishCard(e.helper_hu_card, true, this.mainRummy.tingPaiMsg);
                    }
                }), d, true));
                1 == i.is_bump && sys.isObjectValid(e.bump_lz) && (i.laizicard = e.bump_lz, this.mainRummy.cardsTs.hideBumpLaiziTipAnim(), sys.isObjectValid(e.bump_last_lz) && e.bump_last_lz > 0 && (i.lastLaizicard = e.bump_last_lz), i.winLaizicard = 0, this.mainRummy.cardsTs.updateCurBumpLaizi());
                this.mainRummy.hasPlayOutLocalCard = false;
            }
            else {
                3 == n ? (Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text69"), 2, 0, ToolUtils.getIsNormalDirection()), e.cardinfos && this.mainRummy.refreshMyShouPai(e)) : e.cardinfos && this.mainRummy.refreshMyShouPai(e);
            }
        }
        if (1 == m && ToolUtils.getRandomInt(1, 100) > 50) {
            let i = 2 == RummyDataManager.shared().rummyInfos.get(e.tid_key).playerModels[n].sex ? "female" : "male";
            this.mainRummy.tid_key == User.shared().curTid_key && SoundManager.shared().playSound(ToolUtils.format("rummy_catchcard${0}_${1}", ToolUtils.getRandomInt(0, 2), i), null, null, 0.2);
        }
        if (null != e.catch_card && 0 != e.catch_card && null != e.catch_seatid) {
            let i = this.mainRummy.getPlayerGiveCard(e.catch_seatid);
            if (i && i.cards.length > 0) {
                let a = i.cards[i.cards.length - 1];
                a.value == e.catch_card && (a.is_catch = 1, this.mainRummy.cardsTs.updateLast3Card());
            }
        }
        if (1 === ToolUtils.isSafeNumber(e.is_reshuffle)) {
            let e = 0 != y ? 0.95 : 0.2;
            TweenTool.delayAct(this.mainRummy.action_node, (() => {
                this.mainRummy.cardsTs.changeXipaiAnimVisibile(true);
            }), e, true);
        }
        if (i.hasShowWinAnim && (this.mainRummy.tipTs.hideWinEffect(), this.mainRummy.cardsTs.hidehuAnimCards(), i.bIsHasHu = false, i.isCanTouchCard = true, i.hasShowWinAnim = false), 0 == this.mainRummy.getPosBySeatid(n)) {
            let e = RummyDataManager.shared().checkLiveAvatar(this.mainRummy.tid_key, n);
            this.showPlayerHeadAnim(0, 3, e);
        }
    }
    handler_server_table_player_info(e) {
        try {
            if (e.players && "object" == typeof e.players) {
                let i = e.players.length, a = RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key);
                a.roomPlayerCounter = i;
                a.players = e.players;
                for (let t = 0; t < i; t++) {
                    let i = e.players[t].seatid, m = a.playerModels[i];
                    m.ready = 0;
                    null != e.players[t].ready ? m.ready = e.players[t].ready : null != e.players[t].zhunbei && (m.ready = e.players[t].zhunbei);
                    ToolUtils.isObjValid(this.mainRummy.RummyTotalSettlementNode) && 1 == m.ready && this.mainRummy.RummyTotalSettlementNode.getComponent(RummyTotalSettlement).showReadyView(i, true);
                }
            }
        }
        catch (e) {
            TLog.printError("trycatch handler_server_table_player_info:", e);
        }
    }
    loginGameServer() {
        Server.shared().setOpenCb((() => {
            User.shared().send_login_gate_request();
        }));
        Server.shared().setReconCb((() => {
            User.shared().send_request_game_tableinfo();
            RummyDataManager.shared().rummyInfos.has(this.mainRummy.tid_key) && RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key).isGameOver && Utils.shared().hideLoading();
            this.mainRummy.deleteGameOverDalay();
        }));
        let e = URLConfig.orginHttp_tcp, i = NetHostManager.shared().chooseBestTcpIpConn(RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key).vid), a = NetHostManager.shared().chooseBestTcpPortConn(RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key).vid);
        "-1" != i && -1 != a && (e = 443 == a ? "wss://" + i + ":443" : "ws://" + i + ":" + a);
        Server.shared().createSocket(e);
        User.shared().isGameDisconnectServer = false;
    }
    send_login_request() {
        if (1 == User.shared().isInPerformanceRoom) {
            let e = { cmd: NetConfig.GM_LOGIN_REQUEST, uid: User.shared().data.uid, skey: User.shared().getSkey(), version: GameConfig.Server_Api_Ver, ch_id: GameConfig.CHANNEL_ID, game_id: User.shared().game_id, vid: ToolUtils.play_back_vid, round: User.shared().play_back_round, tid_key: this.mainRummy.tid_key && this.mainRummy.tid_key != CommDefine.PerformanceRoomTidkey ? this.mainRummy.tid_key : "" };
            return void Server.shared().send(e);
        }
        let e = { cmd: NetConfig.GM_LOGIN_REQUEST, uid: User.shared().data.uid, skey: User.shared().getSkey(), version: GameConfig.Server_Api_Ver, tid_key: this.mainRummy.tid_key && this.mainRummy.tid_key != CommDefine.NewerGuideRoomTidkey ? this.mainRummy.tid_key : "", auto_sort: User.shared().auto_sort, ch_id: GameConfig.CHANNEL_ID };
        if (e.isNewTable = this.mainRummy.isNewTable, e.screen_type = 0, !RummyDataManager.shared().rummyInfos.has(this.mainRummy.tid_key)) {
            return;
        }
        let i = RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key);
        0 == i.direction && (e.screen_type = 1);
        e.tid = i.tid || 0;
        e.vid = i.vid;
        e.robot_view = 1 == i.crashModel ? RobotAvatar.roomMode(i.vid) : 0;
        null != i.raceid && (e.raceid = i.raceid);
        Server.shared().send(e);
    }
    send_request_tableinfo() {
        if (this.mainRummy.tid_key !== CommDefine.NewerGuideRoomTidkey) {
            if (RummyDataManager.shared().rummyInfos.has(this.mainRummy.tid_key)) {
                let e = RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key);
                e.winLaizicard = 0;
                e.best_lz = 0;
                e.lastLaizicard = 0;
            }
            let e = { cmd: RummyCmd.GM_FLUSH_TABLEINFO_REQUEST, uid: User.shared().data.uid, version: GameConfig.Server_Api_Ver, tid_key: this.mainRummy.tid_key, helper_all_switcher: User.shared().getHelper_all_switcher(), skey: User.shared().getSkey() };
            Server.shared().send(e);
            this.mainRummy.cardsTs.clearHandCardValue();
            PushCenter.shared().pushEvent(PushEvent.SwitchRoomDesk);
        }
    }
    send_req_small_table_info() {
        let e = { cmd: RummyCmd.GM_REQ_SMALL_TABLE_INFO, uid: User.shared().data.uid, version: GameConfig.Server_Api_Ver, tid_key: this.mainRummy.tid_key, skey: User.shared().getSkey() };
        Server.shared().send(e);
    }
    send_table_player_info_request() {
        let e = { cmd: RummyCmd.GM_NOTIFY_TABLE_PLAYER_INFO, uid: User.shared().data.uid, tid_key: this.mainRummy.tid_key };
        Server.shared().send(e);
    }
    send_request_game_readl() {
        let e = { cmd: RummyCmd.GM_GAME_READY_REQUEST, uid: User.shared().data.uid, version: GameConfig.Server_Api_Ver, skey: User.shared().getSkey(), tid_key: this.mainRummy.tid_key };
        Server.shared().send(e);
    }
    send_request_line_up(e = 0) {
        let i = { cmd: RummyCmd.GM_NOTIFY_ENTER_LINE_UP_OK, uid: User.shared().data.uid, version: GameConfig.Server_Api_Ver, skey: User.shared().getSkey(), tid_key: this.mainRummy.tid_key, raceid: e };
        Server.shared().send(i);
    }
    send_request_flopcash_ok(e = 0) {
        let i = { cmd: RummyCmd.CLIENT_NOTIFY_CLOSE_CARD, uid: User.shared().data.uid, version: GameConfig.Server_Api_Ver, skey: User.shared().getSkey(), tid_key: this.mainRummy.tid_key, raceid: e };
        Server.shared().send(i);
    }
    send_bonusgift_status(e) {
        let i = { cmd: RummyCmd.CLIENT_NOTIFY_RECHARGE_STATUS, uid: User.shared().data.uid, version: GameConfig.Server_Api_Ver, tid_key: this.mainRummy.tid_key, skey: User.shared().getSkey(), status: e };
        Server.shared().send(i);
    }
    send_request_enterBackGround() {
        let e = { cmd: RummyCmd.CLIENT_OFFLINE, uid: User.shared().data.uid, version: GameConfig.Server_Api_Ver, tid_key: this.mainRummy.tid_key, skey: User.shared().getSkey() };
        Server.shared().send(e);
    }
    resetAutoGroupIntent(model) {
        if (model.autoGroupTimeout) this.mainRummy.unschedule(model.autoGroupTimeout);
        model.autoGroupTimeout = null;
        model.autoGroupPendingStatus = null;
        model.autoGroupDesiredStatus = null;
        model.autoGroupIntentGeneration = (model.autoGroupIntentGeneration || 0) + 1;
    }
    toggleAutoGroup(withAnimation) {
        const model = RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key);
        if (!model) return;
        const current = model.autoGroupDesiredStatus == null ? model.autoGroupStatus : model.autoGroupDesiredStatus;
        model.autoGroupDesiredStatus = current == 1 ? 0 : 1;
        model.autoGroupDesiredAction = withAnimation && model.autoGroupDesiredStatus == 1 ? 1 : 0;
        this.mainRummy.actionTs.changeAutoGroupTipsStatus(false);
        this.mainRummy.actionTs.changeAutoGroupBtnStatus(null);
        this.flushAutoGroupIntent(model);
    }
    flushAutoGroupIntent(model) {
        if (model.autoGroupPendingStatus != null || model.autoGroupDesiredStatus == null) return;
        if (model.autoGroupDesiredStatus == model.autoGroupStatus) {
            model.autoGroupDesiredStatus = null;
            return;
        }
        const tid = this.mainRummy.tid_key;
        const generation = (model.autoGroupIntentGeneration || 0) + 1;
        model.autoGroupIntentGeneration = generation;
        model.autoGroupPendingStatus = model.autoGroupDesiredStatus;
        // One request in flight: later taps update intent, not the last server acknowledgement.
        model.autoGroupTimeout = () => {
            if (this.mainRummy.tid_key != tid || model.autoGroupIntentGeneration != generation) return;
            this.resetAutoGroupIntent(model);
            this.mainRummy.actionTs.changeAutoGroupBtnStatus(null);
            this.send_login_request();
        };
        this.mainRummy.scheduleOnce(model.autoGroupTimeout, 8);
        this.send_auto_group_cards_request(model.autoGroupPendingStatus, model.autoGroupDesiredAction);
    }
    acknowledgeAutoGroup(model, response) {
        // Unsolicited grouping notifications cannot acknowledge a toggle request.
        if (response.is_req != 1 || response.status != model.autoGroupPendingStatus) return;
        if (model.autoGroupTimeout) this.mainRummy.unschedule(model.autoGroupTimeout);
        model.autoGroupTimeout = null;
        model.autoGroupPendingStatus = null;
        model.autoGroupIntentGeneration = (model.autoGroupIntentGeneration || 0) + 1;
        this.flushAutoGroupIntent(model);
    }
    send_auto_group_cards_request(e, i) {
        let a = { cmd: RummyCmd.GM_AUTO_GROUP_REQUEST, uid: User.shared().data.uid, tid_key: this.mainRummy.tid_key, status: e, action: i };
        Server.shared().send(a);
    }
    send_auto_sort_request() {
        let e = { cmd: RummyCmd.GM_REQ_SET_AUTO_SORT, uid: User.shared().data.uid, tid_key: this.mainRummy.tid_key, auto_sort: User.shared().auto_sort };
        Server.shared().send(e);
    }
    send_sort_cards_request() {
        let e = { cmd: RummyCmd.GM_REQ_SORT_CARDS, uid: User.shared().data.uid, tid_key: this.mainRummy.tid_key };
        Server.shared().send(e);
    }
    send_req_watch_reward_info() {
        let e = { cmd: RummyCmd.GM_REQ_WATCH_REWARD_INFO, uid: User.shared().data.uid, tid_key: this.mainRummy.tid_key };
        Server.shared().send(e);
    }
    handler_server_quick_finish_cancel_request() {
        let e = { cmd: RummyCmd.GM_QUICK_FINISH_CANCEL, uid: User.shared().data.uid, tid_key: this.mainRummy.tid_key };
        Server.shared().send(e);
    }
    send_request_get_push_match_event(e = 0) {
        let i = { cmd: RummyCmd.GM_GET_PUSH_MATCH_EVENT, uid: User.shared().data.uid, version: GameConfig.Server_Api_Ver, skey: User.shared().getSkey(), tid_key: this.mainRummy.tid_key, is_over: e };
        Server.shared().send(i);
    }
    send_decard_card_request() {
        let e = { cmd: RummyCmd.GM_DECARE_CARD_REQUEST, uid: User.shared().data.uid, tid_key: this.mainRummy.tid_key };
        Server.shared().send(e);
    }
    send_cancel_auto_play() {
        let e = { cmd: RummyCmd.GM_CANCAL_AUTO_PLAY, uid: User.shared().data.uid, tid_key: this.mainRummy.tid_key };
        Server.shared().send(e);
    }
    send_drop_card_is_eliminate(e) {
        let i = { cmd: RummyCmd.GM_REQ_DROP_CARD_IS_ELIMINATE, uid: User.shared().data.uid, tid_key: this.mainRummy.tid_key, is_auto_drop: e };
        Server.shared().send(i);
    }
    send_split_prize_request() {
        let e = { cmd: RummyCmd.GM_SPLIT_PRIZE_REQUEST, uid: User.shared().data.uid, tid_key: this.mainRummy.tid_key };
        Server.shared().send(e);
    }
    send_private_player_start_game(e) {
        let i = { cmd: RummyCmd.GM_PLAYER_START_GAME_REQUEST, seatid: e, tid_key: this.mainRummy.tid_key, uid: User.shared().data.uid };
        Server.shared().send(i);
    }
    send_request_close_match_push() {
        let e = { cmd: RummyCmd.GM_NOTIFY_CLOSE_MATCH_PUSH, uid: User.shared().data.uid, version: GameConfig.Server_Api_Ver, skey: User.shared().getSkey(), tid_key: this.mainRummy.tid_key };
        Server.shared().send(e);
    }
    handler_server_rank_info_request(e) {
        let i = { cmd: RummyCmd.GM_RANK_INFO_REQUEST, uid: User.shared().data.uid, tid_key: this.mainRummy.tid_key, raceid: RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key).raceid, page: e };
        Server.shared().send(i);
    }
    handler_logout_request(e, i = 0) {
        let a = { cmd: RummyCmd.GM_PRE_LOGOUT, uid: User.shared().data.uid, tid_key: this.mainRummy.tid_key, isGoHall: e || 0 };
        this.mainRummy.checkIsPointsMatch() && (a.is_drop = i);
        Server.shared().send(a);
    }
    handler_pre_switch_request() {
        let e = { cmd: RummyCmd.GM_PER_CHANGE, uid: User.shared().data.uid, tid_key: this.mainRummy.tid_key };
        Server.shared().send(e);
    }
    send_request_score_rank_info() {
        let e = RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key), i = { cmd: RummyCmd.GM_SCORE_RANK_INFO, uid: User.shared().data.uid, version: GameConfig.Server_Api_Ver, skey: User.shared().getSkey(), tid_key: this.mainRummy.tid_key, raceid: sys.isObjectValid(e) ? e.raceid : 0 };
        Server.shared().send(i);
    }
    send_request_match_close_game_end() {
        let e = { cmd: RummyCmd.GM_NOTIFY_CLOSE_GAME_END, uid: User.shared().data.uid, version: GameConfig.Server_Api_Ver, skey: User.shared().getSkey(), tid_key: this.mainRummy.tid_key };
        Server.shared().send(e);
    }
    send_regoin_out_request() {
        let e = { cmd: RummyCmd.GM_REJOIN_REQUEST, uid: User.shared().data.uid, tid_key: this.mainRummy.tid_key, status: 0 };
        Server.shared().send(e);
    }
    send_request_notify_effect_modify() {
        let e = { cmd: RummyCmd.GM_NOTIFY_EFFECT_MODIFY, uid: User.shared().data.uid, version: GameConfig.Server_Api_Ver, skey: User.shared().getSkey(), tid_key: this.mainRummy.tid_key };
        Server.shared().send(e);
    }
    handler_server_join_race_request(e) {
        let i = { cmd: RummyCmd.GM_RACE_REJOIN_REQUEST, uid: User.shared().data.uid, tid_key: this.mainRummy.tid_key, match_vid: this.mainRummy.match_vid, pay_type: e, mng_sid: this.mainRummy.mng_sid, from: 3, in_hall: 0, session_id: User.shared().session_id };
        Server.shared().send(i);
    }
    handler_server_cancel_join_race_request() {
        let e = { cmd: RummyCmd.GM_CANCEL_JOIN_RACE_REQUEST, uid: User.shared().data.uid, tid_key: this.mainRummy.tid_key, raceid: RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key).raceid };
        Server.shared().send(e);
    }
    handler_get_user_rank_request(e) {
        let i = { cmd: RummyCmd.SM_GET_USER_RANK_REQUEST, uid: User.shared().data.uid, tid_key: this.mainRummy.tid_key, raceid: RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key).raceid, target_uid: e };
        Server.shared().send(i);
    }
    sendMagicFace(e, i) {
        let a = { cmd: RummyCmd.GM_EXPRESSION_REQUEST, uid: User.shared().data.uid, seatid: RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key).clientSeatId, reciveseatid: parseInt(i), expressionid: parseInt(e), tid_key: this.mainRummy.tid_key };
        Server.shared().send(a);
    }
    sendFace(e) {
        let i = { cmd: RummyCmd.GM_NORMALEXPRESION_REQUEST, uid: User.shared().data.uid, seatid: RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key).clientSeatId, tid_key: this.mainRummy.tid_key, expressionid: parseInt(e) + 1 };
        Server.shared().send(i);
    }
    sendText(e, i) {
        let a = { cmd: RummyCmd.GM_CHAT_REQUEST, uid: User.shared().data.uid, tid_key: this.mainRummy.tid_key, text: e, seatid: RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key).clientSeatId, chatid: Number(i) };
        Server.shared().send(a);
    }
    handler_user_rebuy_request(e) {
        let i = { cmd: RummyCmd.GM_USER_REBUY_REQUEST, uid: User.shared().data.uid, tid_key: this.mainRummy.tid_key, raceid: RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key).raceid, type: e };
        Server.shared().send(i);
    }
    handler_server_add_card_request(e) {
        let i = { cmd: RummyCmd.GM_ADD_CARD_REQUEST, uid: User.shared().data.uid, tid_key: this.mainRummy.tid_key }, a = this.mainRummy.cardsTs.getSelectedCards();
        if (i.cards = [], i.indexs = [], i.cardindexs = [], a.length > 0) {
            for (let e = 0, t = a.length; e < t; e++) {
                const t = a[e].getComponent("RummyCard");
                i.cards.push(t.mCardValue);
                i.indexs.push(t.groupIndex);
                i.cardindexs.push(t.cardIndex);
            }
            i.to_groupindex = e;
            Server.shared().send(i);
            RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key).bHandCardSynchronous = false;
        }
    }
    send_last_card_request(e = 0) {
        let i = { cmd: RummyCmd.GM_LAST_CARD_REQUEST, uid: User.shared().data.uid, tid_key: this.mainRummy.tid_key, notice_type: 1, click_check_settle: e };
        Server.shared().send(i);
    }
    send_get_record_request() {
        let e = RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key).gameRummyType;
        if (e == RUMMY_GAME_TYPE.POOL || e == RUMMY_GAME_TYPE.PRI_POOL || e == RUMMY_GAME_TYPE.DEALS || e == RUMMY_GAME_TYPE.PRI_DEAL) {
            let e = { cmd: RummyCmd.GM_GET_RECORD_REQUET, uid: User.shared().data.uid, tid_key: this.mainRummy.tid_key };
            Server.shared().send(e);
        }
    }
    send_game_show_info_request() {
        let e = { cmd: RummyCmd.GM_GAME_SHOW_INFO, uid: User.shared().data.uid, tid_key: this.mainRummy.tid_key };
        Server.shared().send(e);
    }
    send_gong_cards_request() {
        let e = { cmd: RummyCmd.GM_GONG_CARDS_REQUEST, uid: User.shared().data.uid, tid_key: this.mainRummy.tid_key };
        Server.shared().send(e);
    }
    send_finish_request() {
        RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key)._declare_time = sys.now();
        let e = { cmd: RummyCmd.GM_FINISH_REQUEST, uid: User.shared().data.uid, tid_key: this.mainRummy.tid_key, cardinfos: this.mainRummy.handCardDataAnalysis.getFinishDeclareCards(this.mainRummy.cardsTs.myGroupcardValueVec) };
        Server.shared().send(e);
    }
    handler_server_Auto_declare_request(e) {
        let i = { cmd: RummyCmd.GM_AUTO_BEST_DECLARE, uid: User.shared().data.uid, tid_key: this.mainRummy.tid_key, status: e };
        Server.shared().send(i);
    }
    send_pre_decard_request() {
        let e = RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key), i = this.mainRummy.cardsTs.getSelectedCards();
        if (i.length > 0) {
            let a = i[0].getComponent("RummyCard");
            e.groupIndex = a.groupIndex;
            e.card_index = a.cardIndex;
            e.playCardValue = a.mCardValue;
        }
        let a = { cmd: RummyCmd.GM_PRE_DECARD_REQUEST, uid: User.shared().data.uid, index: e.groupIndex, card_index: e.card_index, card: e.playCardValue, tid_key: this.mainRummy.tid_key };
        Server.shared().send(a);
    }
    handler_server_declare_check_request(e, i = null) {
        let a = RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key).playCardValue, t = RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key).groupIndex;
        if (1 == e) {
            let e = this.mainRummy.cardsTs.getSelectedCards();
            if (1 == e.length) {
                let i = e[0].getComponent("RummyCard");
                a = i.mCardValue;
                t = i.groupIndex;
            }
            i && (a = i.card, t = i.index);
        }
        let m = { cmd: RummyCmd.GM_DECARE_CARD_CHECK_RETURN, uid: User.shared().data.uid, card: a, index: t, tid_key: this.mainRummy.tid_key };
        i && (m.is_quick = 1);
        Server.shared().send(m);
    }
    handler_server_group_card_request() {
        let e = { cmd: RummyCmd.GM_GROUP_CARD_REQUEST, uid: User.shared().data.uid, tid_key: this.mainRummy.tid_key }, i = this.mainRummy.cardsTs.getSelectedCards();
        if (e.cards = [], e.indexs = [], e.cardindexs = [], i.length > 0) {
            for (let a = 0, t = i.length; a < t; a++) {
                const t = i[a].getComponent("RummyCard");
                e.cards.push(t.mCardValue);
                e.indexs.push(t.groupIndex);
                e.cardindexs.push(t.cardIndex);
            }
            Server.shared().send(e);
            RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key).bHandCardSynchronous = false;
        }
        RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key).able_client_group && this.mainRummy.cardsTs.groupShoupaiArrange();
    }
    handler_server_move_group_cards_request(e, i) {
        let a = { cmd: RummyCmd.GM_MOVE_GROUP_CARDS_REQUEST, uid: User.shared().data.uid, tid_key: this.mainRummy.tid_key, groupindex: e, movetype: i };
        Server.shared().send(a);
        RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key).bHandCardSynchronous = false;
    }
    send_pick_card_request(e) {
        RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key)._mopai_time = sys.now();
        let i = { cmd: RummyCmd.GM_PICK_CARD_REQUEST, uid: User.shared().data.uid, type: e, tid_key: this.mainRummy.tid_key };
        Server.shared().send(i);
    }
    showPlayerHeadAnim(e, i, a = -1) {
        this.mainRummy.tid_key == User.shared().curTid_key && (this.mainRummy.playerTs.showPlayerHeadAnim(e, i, a, true), this.mainRummy.tipTs.showPlayerHeadAnim(e, i, a, (() => {
            0 == a ? this.mainRummy.playerTs.showPlayerHeadAnim(e, i, a, false) : 1 == a && i >= 1 && i <= 5 && this.mainRummy.playerTs.showPlayerHeadAnim(e, 6, a, true);
        })));
    }
    send_switch_joker_request(e, i) {
        let a = { cmd: RummyCmd.GM_BUMP_CHANGE_LAIZI, uid: User.shared().data.uid, new_lz: e, last_lz: i, tid_key: this.mainRummy.tid_key };
        Server.shared().send(a);
    }
    send_choose_joker_request(e) {
        let i = this.mainRummy.cardsTs.getShouPaiGroupCardValues(), a = { cmd: RummyCmd.GM_BUMP_PRE_CHANGE_LAIZI, uid: User.shared().data.uid, version: GameConfig.Server_Api_Ver, skey: User.shared().getSkey(), tid_key: this.mainRummy.tid_key, cards: i, laizi_card: e };
        Server.shared().send(a);
    }
    send_all_choose_joker_request() {
        Server.shared().send({ cmd: RummyCmd.GM_BUMP_BATCH_PRE_CHANGE_LAIZI_INFO, tid_key: this.mainRummy.tid_key, uid: User.shared().data.uid });
    }
    send_practice_to_cash_request() {
        Server.shared().send({ cmd: RummyCmd.GM_GOTO_CASH_REQUEST, tid_key: this.mainRummy.tid_key, uid: User.shared().data.uid });
    }
    send_request_history_cards_info() {
        let e = { cmd: RummyCmd.GM_HISTORY_CARDS_INFO_REQ, uid: User.shared().data.uid, version: GameConfig.Server_Api_Ver, skey: User.shared().getSkey(), tid_key: this.mainRummy.tid_key };
        Server.shared().send(e);
    }
    send_notify_user_info_status(e, i) {
        let a = { cmd: RummyCmd.GM_NOTIFY_USER_INFO_STATUS, uid: User.shared().data.uid, version: GameConfig.Server_Api_Ver, skey: User.shared().getSkey(), tid_key: this.mainRummy.tid_key, seatid: e, status: i };
        Server.shared().send(a);
    }
    send_request_choose_double(e) {
        let i = { cmd: RummyCmd.GM_CHOOSE_DOUBLE, uid: User.shared().data.uid, version: GameConfig.Server_Api_Ver, skey: User.shared().getSkey(), tid_key: this.mainRummy.tid_key, type: e };
        Server.shared().send(i);
    }
    send_request_manula_rejoin(e) {
        let i = { cmd: RummyCmd.CLIENT_SYNC_PRE_REJOIN_STATUS, uid: User.shared().data.uid, version: GameConfig.Server_Api_Ver, skey: User.shared().getSkey(), tid_key: this.mainRummy.tid_key, status: e ? 1 : 0 };
        Server.shared().send(i);
    }
    applyDoubleChoicePhase() {
        const main = this.mainRummy;
        const info = RummyDataManager.shared().rummyInfos.get(main.tid_key);
        if (!info) return;
        info.in_choose_double = 1;
        info.game_server_state = 5;
        info.isClientToPlay = false;
        main.actionTs.setMopaiBtnInteractable(false);
        main.actionTs.changeDropBtnStatus(false);
        main.actionTs.changeDiscardBtnStatus(false);
        main.actionTs.changeFinishBtnStatus(false);
        main.actionTs.changeCenterFinishBtnStatus(false);
        main.cardsTs.showMoPaiTisAnim(false, false);
        main.cardsTs.showFinishTisiAnim(false);
        main.autoDropTs.isshowAutoDropBtn(false, main.tid_key);
    }
    handler_server_notify_choose_double(e) {
        this.applyDoubleChoicePhase();
        if (RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key).in_choose_double = 1, Array.isArray(e.seats) && e.seats.length > 0) {
            for (let i = 0; i < e.seats.length; i++) {
                let a = e.seats[i], t = this.mainRummy.getPosBySeatid(a);
                0 == t && this.mainRummy.actionTs.showDoubleGameChooseTip(true, e);
                this.mainRummy.playerTs.startPlayerTimer2(t, e.cd);
            }
        }
    }
    handler_server_choose_double_return(e) {
        if (e.ret != null && e.ret !== 0) {
            // A rejected/late choice must not hide the pending choice or change its badge.
            return;
        }
        let i = e.seatid, a = this.mainRummy.getPosBySeatid(i);
        this.mainRummy.playerTs.showDoubleState(a, e.type, true, 0, false);
        let t = RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key).playerModels[i];
        if (t && this.mainRummy.tid_key == User.shared().curTid_key) {
            let i = 2 == t.sex ? "female" : "male", m = "";
            0 == e.type ? m = "no_double_" + i : 1 == e.type ? m = "double_one_" + i : 2 == e.type && (m = "double_two_" + i);
            m.length > 0 && 0 == a && SoundManager.shared().playSound(m);
        }
        0 == a && this.mainRummy.actionTs.showDoubleGameChooseTip(false);
        this.mainRummy.playerTs.stopPlayerTimer2(a);
    }
    handler_server_choose_double_bc_return(e) {
        if (e.players) {
            for (let i = 0, a = e.players.length; i < a; i++) {
                let a = e.players[i], t = a.seatid, m = this.mainRummy.getPosBySeatid(t), s = a.type;
                this.mainRummy.playerTs.showDoubleState(m, s, true, 1, true);
                this.mainRummy.playerTs.stopPlayerTimer2(m);
            }
        }
        this.mainRummy.actionTs.showDoubleGameChooseTip(false);
        RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key).in_choose_double = 0;
        RummyDataManager.shared().rummyInfos.get(this.mainRummy.tid_key).game_server_state = 2;
    }
}
