// @ts-nocheck
// Recovered from index.js:269
import { _decorator } from "cc";
import SoundManager from "./SoundManager";
import { MyComponent } from "./MyComponent";
const { ccclass } = _decorator;
@ccclass("LuckBallExplainPop")
export class LuckBallExplainPop extends MyComponent {
    start() {
    }
    update(t) {
    }
    onCloseBtn() {
        SoundManager.shared().playFx("click");
        this.node.destroy();
    }
}
