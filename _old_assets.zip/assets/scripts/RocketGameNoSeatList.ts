// @ts-nocheck
// Recovered from index.js:405
import { _decorator, instantiate, Label, Node, ScrollView, size, sys } from "cc";
import BaseLayer from "./BaseLayer";
import PushCenter from "./PushCenter";
import Utils from "./Utils";
import SoundManager from "./SoundManager";
import { ToolUtils } from "./ToolUtils";
import { PullToRefresh } from "./PullToRefresh";
const { ccclass, property } = _decorator;
@ccclass("RocketGameNoSeatList")
export class RocketGameNoSeatList extends BaseLayer {
    public TAG: string = "RocketGameNoSeatList";
    @property(Node)
    public root: Node = null;
    @property(Node)
    public moban: Node = null;
    @property(Node)
    public scrollView: Node = null;
    public _lastClick: number = 0;
    public _has_close: boolean = false;
    public gameCallback: any = null;
    public curPage: number = 1;
    public totalPage: number = 1;
    public canGetMore: boolean = true;
    onLoad() {
    }
    start() {
        super.start();
        this.startShowAnim(this.root);
        ToolUtils.showFullScreen(this.node.getChildByName("bg"));
        this.initView();
    }
    initParaData(e) {
        sys.isObjectValid(e) && sys.isObjectValid(e.cb) && (this.gameCallback = e.cb);
    }
    initView() {
        let e = this.scrollView.getComponent(PullToRefresh);
        sys.isObjectValid(e) && e.setOnLoadMore(this.getMoreInfo.bind(this));
    }
    getMoreInfo() {
        sys.isObjectValid(this.gameCallback) && this.curPage < this.totalPage && this.canGetMore && (this.gameCallback(this.curPage), this.canGetMore = false);
    }
    refreshUI(e) {
        if (this.curPage = e.page, this.totalPage = e.total, this.canGetMore = true, sys.isObjectValid(e.players) && Array.isArray(e.players) && e.players.length > 0) {
            for (let t = 0; t < e.players.length; t++) {
                let i = instantiate(this.moban);
                i.active = true;
                let a = i.getChildByName("head_kuang").getChildByName("mask").getChildByName("head_img");
                Utils.shared().updateHeadImg(a, e.players[t].avatar, e.players[t].avatar_url, size(75, 75));
                sys.isObjectValid(e.players[t].name) && (i.getChildByName("name").getComponent(Label).string = ToolUtils.GetShortName2(ToolUtils.isSafeString(e.players[t].name), 10, false));
                sys.isObjectValid(e.players[t].money) && (i.getChildByName("chip_num").getComponent(Label).string = ToolUtils.parse_double(e.players[t].money));
                this.scrollView.getComponent(ScrollView).content.addChild(i);
            }
        }
        let t = this.scrollView.getComponent(PullToRefresh);
        sys.isObjectValid(t) && (t.finishLoadMore(), t.finishRefresh());
    }
    touchBtnEvent(e, t) {
        SoundManager.shared().playFx("click");
        sys.now() - this._lastClick < 500 || (this._lastClick = sys.now(), this.onBackView());
    }
    onBackView() {
        ToolUtils.isObjValid(this.node) && (this.gameCallback && this.gameCallback[-1], this.node.destroy());
    }
    onDestroy() {
        super.onDestroy();
        PushCenter.shared().removeListenersByTag(this);
    }
}
