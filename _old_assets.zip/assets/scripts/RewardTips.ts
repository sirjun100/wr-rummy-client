// @ts-nocheck
// Recovered from index.js:389
import { _decorator, color, instantiate, Label, Node, RichText, size, sp, Sprite, SpriteAtlas, SpriteFrame, sys, UITransform, v3, view } from "cc";
import BaseLayer from "./BaseLayer";
import i18nMgr from "./i18nMgr";
import TweenTool from "./TweenTool";
import Utils from "./Utils";
import PushEvent from "./PushEvent";
import User from "./User";
import SoundManager from "./SoundManager";
import PushCenter from "./PushCenter";
import { ToolUtils } from "./ToolUtils";
import BundleNameDefined from "./BundleNameDefined";
import { BagItemType, CUSTOM_REWARD_ENUM } from "./CommDefine";
const { ccclass, property } = _decorator;
@ccclass("RewardTips")
export class RewardTips extends BaseLayer {
    @property(Node)
    public rootNode: Node = null;
    @property([SpriteFrame])
    public iconSpriteFrame: SpriteFrame[] = [];
    @property(SpriteFrame)
    public oldActiveImg: SpriteFrame = null;
    @property(Node)
    public itemMoban: Node = null;
    @property(Node)
    public addMoban: Node = null;
    @property(Node)
    public cancel_btn: Node = null;
    @property(Node)
    public close_btn: Node = null;
    @property(Node)
    public assure_btn: Node = null;
    @property(Node)
    public richtips: Node = null;
    @property(Node)
    public tip1: Node = null;
    @property(Node)
    public tip2: Node = null;
    @property(Node)
    public tip3: Node = null;
    @property(Node)
    public kefu_btn: Node = null;
    @property(Node)
    public bgMask: Node = null;
    @property(Node)
    public item_root: Node = null;
    @property(Node)
    public rewardRoot: Node = null;
    @property(Node)
    public animNode: Node = null;
    @property([SpriteFrame])
    public ticket_images: SpriteFrame[] = [];
    @property(SpriteAtlas)
    public skinPropsAtlas: SpriteAtlas = null;
    @property(SpriteAtlas)
    public commonIconAtlas: SpriteAtlas = null;
    public rewardData: any = null;
    public rewardType: number = 0;
    public cancelWz: any = null;
    public assureWz: any = null;
    public callback: any = null;
    public startCb: any = null;
    public _bBtnEnable: boolean = true;
    public isSuperVip: boolean = false;
    public itemPositions: any[] = [];
    public isNext: boolean = false;
    public addCashCount: number = 0;
    onLoad() {
        SoundManager.shared().preLoadBundleSounds(BundleNameDefined.bundle_sound, "reward");
        this.tip1.getComponent(Label).string = i18nMgr.shared().getValueByKey("reward_tips.tip");
        this.tip2.getComponent(Label).string = i18nMgr.shared().getValueByKey("reward_tips.tip");
        this.tip3.getComponent(Label).string = i18nMgr.shared().getValueByKey("reward_tips.tip");
        i18nMgr.shared().changeLabelFont(this.tip1.getComponent(Label));
        i18nMgr.shared().changeLabelFont(this.tip2.getComponent(Label));
        i18nMgr.shared().changeLabelFont(this.tip3.getComponent(Label));
        this.node.getComponent(UITransform).setContentSize(view.getVisibleSize());
        this.bgMask.getComponent(UITransform).setContentSize(view.getVisibleSize());
        SoundManager.shared().playFx("get_reward");
    }
    onDestroy() {
        super.onDestroy();
        this.unscheduleAllCallbacks();
    }
    initData(t, e, i = 0, s = "", a = "", n) {
        this.rewardData = t;
        this.rewardType = i;
        this.cancelWz = i18nMgr.shared().getValueByKey("reward_tips.cancel");
        this.callback = e;
        this.startCb = n || null;
        sys.isObjectValid(t) && sys.isObjectValid(t.isSuperVip) && (this.isSuperVip = t.isSuperVip);
        sys.isObjectValid(t) && sys.isObjectValid(t.isNext) && (this.isNext = t.isNext);
        s.length > 0 ? (this.assureWz = i18nMgr.shared().getValueByKey(s), "reward_tips.play_now" == s && (this.tip1.active = true, this.tip2.active = false)) : (this.assureWz = i18nMgr.shared().getValueByKey("reward_tips.play_now"), this.tip1.active = false, this.tip2.active = false);
        a.length > 0 ? this.cancelWz = i18nMgr.shared().getValueByKey(a) : this.cancelWz = i18nMgr.shared().getValueByKey("reward_tips.cancel");
    }
    delayToClose(t) {
        ToolUtils.isObjValid(this.node) && (t = t >= 0 ? t : 0, TweenTool.delayAct(this.node, (() => {
            this._bBtnEnable && (this._bBtnEnable = false, ToolUtils.isObjValid(this.node) && this.node.destroy());
        }), t, true), 9 == this.rewardType && TweenTool.stopNodeAction(this.node));
    }
    start() {
        super.start();
        TweenTool.moveSpriteByFade(this.bgMask, 0.15, v3(0, 0, 0), 0, 1, true, (() => {
            this.bgMask.getComponent(Sprite).color = color(0, 0, 0, 204);
            this.rootNode.active = true;
            this.rewardRoot.active = false;
            this.item_root.active = false;
            this.showContent();
        }));
        PushCenter.shared().addListener(PushEvent.RichTextClick, (t => {
            ToolUtils.isObjValid(this.node) && this.onButtonClick(null, t);
        }), this);
        this.startCb && this.startCb();
        9 == this.rewardType && this.delayToClose(5);
        10 == this.rewardType && sys.isObjectValid(this.rewardData.priceTips) && this.rewardData.priceTips.length > 0 && Utils.shared().showToast(this.rewardData.priceTips, 6, 4, ToolUtils.getIsNormalDirection());
    }
    showContent() {
        if (this.addCashCount = 0, this.animNode.active = true, this.rootNode.active = true, this.animNode.getComponent(sp.Skeleton).clearTracks(), this.animNode.getComponent(sp.Skeleton).setToSetupPose(), this.animNode.getComponent(sp.Skeleton).setSkin("congratulation"), ToolUtils.getOrientation() && !User.shared().b_storeLevel) {
            this.animNode.getComponent(sp.Skeleton).setAnimation(0, "room", false);
            this.rootNode.setPosition(v3(0, -70));
            let t = v3();
            this.close_btn.getPosition(t);
            this.close_btn.setPosition(v3(t.x + 30, t.y + 5));
        }
        else {
            if (ToolUtils.getIsInRoom()) {
                let t = view.getVisibleSize();
                this.node.getComponent(UITransform).setContentSize(size(t.height, t.width));
                this.bgMask.getComponent(UITransform).setContentSize(size(t.height, t.width));
                this.node.setRotationFromEuler(v3(0, 0, 90));
                this.node.setPosition(v3(0, 0, 0));
            }
            this.animNode.getComponent(sp.Skeleton).setAnimation(0, "hall", false);
        }
        this.itemMoban.setPosition(v3(0, 0));
        this.cancel_btn.active = this.assure_btn.active = true;
        this.itemMoban.active = false;
        this.kefu_btn.active = false;
        9 == this.rewardType && (this.assureWz = i18nMgr.shared().getValueByKey("rummy_main.start"));
        this.assureWz && "" != this.assureWz && (this.assure_btn.getChildByName("wz").getComponent(Label).string = this.assureWz);
        this.cancelWz && "" != this.cancelWz && (this.cancel_btn.getChildByName("wz").getComponent(Label).string = this.cancelWz);
        this.item_root.active = true;
        this.rewardRoot.active = true;
        sys.isObjectValid(this.rewardData.hasCdkeyReward) && this.rewardData.hasCdkeyReward;
        let t = false;
        if (this.assure_btn.active = true, 1 == this.rewardType || 7 == this.rewardType || 8 == this.rewardType || 9 == this.rewardType) {
            this.cancel_btn.active = false;
            this.assure_btn.active = true;
            this.assure_btn.setPosition(v3(0, -177.692));
            9 == this.rewardType && (this.close_btn.active = true);
        }
        else if (2 == this.rewardType) {
            this.cancel_btn.active = false;
            t = true;
            this.assure_btn.setPosition(v3(0, -177.692));
        }
        else if (3 == this.rewardType) {
            this.assure_btn.setPosition(v3(0, -177.692));
            this.cancel_btn.active = false;
        }
        else if (4 == this.rewardType) {
            this.cancel_btn.active = false;
            this.assure_btn.setPosition(v3(0, -177.692));
        }
        else if (5 == this.rewardType) {
            let e = 88;
            1 == i18nMgr.shared().language && (e = -4);
            this.cancel_btn.active = false;
            this.kefu_btn.active = true;
            t = true;
            this.assure_btn.setPosition(v3(0, -177.692));
            this.kefu_btn.setPosition(v3(e, 116));
        }
        else {
            6 == this.rewardType ? (ToolUtils.getOrientation() || (t = true), this.cancel_btn.active = false, this.assure_btn.setPosition(v3(0, -177.692))) : 10 == this.rewardType && (this.assure_btn.active = true, this.assure_btn.setPosition(v3(0, -177.692)), this.close_btn.active = true, this.cancel_btn.active = false);
        }
        if (this.richtips.active = t, this.tip3.active = false, 2 == this.rewardType || 5 == this.rewardType ? ToolUtils.isSafeString(this.rewardData.msg).length > 0 && (this.richtips.getComponent(RichText).string = this.rewardData.msg) : 0 == this.rewardType || 1 == this.rewardType || 7 == this.rewardType || 3 == this.rewardType || 4 == this.rewardType || 8 == this.rewardType ? ToolUtils.isSafeString(this.rewardData.msg).length > 0 && (8 == this.rewardType ? (this.tip1.active = true, this.tip1.getComponent(Label).string = this.rewardData.msg, this.tip2.active = false) : 7 == this.rewardType ? (this.tip1.active = true, this.tip1.getComponent(Label).string = this.rewardData.msg2 || "", this.tip2.getComponent(Label).string = this.rewardData.msg, this.tip2.active = true) : (this.tip2.active = false, this.tip1.getComponent(Label).string = this.rewardData.msg, this.tip1.active = true)) : 6 == this.rewardType ? (ToolUtils.isSafeString(this.rewardData.card_title).length > 0 && (this.richtips.getComponent(RichText).string = this.rewardData.card_title), ToolUtils.isSafeString(this.rewardData.card_content).length > 0 && (this.tip1.getComponent(Label).string = this.rewardData.card_content, this.tip1.active = true, this.tip2.active = false)) : 10 == this.rewardType ? (this.tip2.active = false, ToolUtils.isSafeString(this.rewardData.rechargeId).length > 0 ? (this.tip1.active = true, this.tip1.getComponent(Label).string = ToolUtils.format("Recharge ID：${0}", this.rewardData.rechargeId), this.tip3.active = true, this.tip3.getComponent(Label).string = this.rewardData.msg) : (this.tip1.active = true, this.tip1.getComponent(Label).string = this.rewardData.msg)) : ToolUtils.isSafeString(this.rewardData.msg).length > 0 && (this.tip2.active = false, this.tip1.getComponent(Label).string = this.rewardData.msg, this.tip1.active = true), this.isSuperVip && (this.richtips.active = true, ToolUtils.isSafeString(this.rewardData.msg).length > 0)) {
            this.rewardData.msg.indexOf("<color=") >= 0 ? (this.richtips.active = true, this.tip1.active = false, this.tip2.active = false, i18nMgr.shared().changeLabelFont(this.richtips.getComponent(RichText)), this.richtips.getComponent(RichText).string = this.rewardData.msg) : (this.richtips.active = false, this.tip1.active = true, this.tip2.active = false, i18nMgr.shared().changeLabelFont(this.tip1.getComponent(Label)), this.tip1.getComponent(Label).string = this.rewardData.msg);
        }
        this.itemPositions = [];
        let e = Array.isArray(this.rewardData.list) ? this.rewardData.list : [], i = e.length, s = [];
        this.item_root.removeAllChildren();
        for (let t = 0; t < i; t++) {
            let i = e[t].type;
            !isNaN(Number(i)) && i <= BagItemType.TreasureKey && s.push(e[t]);
        }
        for (let t = 0; t < s.length; t++) {
            let e = this.addRewardItem(s[t], t);
            if (this.item_root.addChild(e), e.active = true, t != s.length - 1) {
                let t = instantiate(this.addMoban);
                t.active = true;
                this.item_root.addChild(t);
            }
        }
    }
    getLineCount(t) {
        if (!t) {
            return 0;
        }
        return (t = t.replace(/<br\s*\/?>/gi, "\n")).split("\n").length;
    }
    addRewardItem(t, e) {
        let i = instantiate(this.itemMoban);
        i.active = true;
        let s = i.getChildByName("num").getComponent(Label), a = i.getChildByName("bg"), n = i.getChildByName("icon"), r = Number(t.type);
        if (r >= 0) {
            if ([0, 1, BagItemType.LuckyLeaf, BagItemType.TreasureKey].includes(r) ? (s.string = ToolUtils.parse_double(t.num), "Cash" == t.name && (this.addCashCount = t.num, SoundManager.shared().preLoadBundleSounds(BundleNameDefined.bundle_sound, "luckball"))) : s.string = 7 === r ? ToolUtils.parse_ChipNum2(t.num) : t.num + "", 2 == r ? 1 == User.shared().showNewDailyTask || 1 == User.shared().showBackTask ? n.getComponent(Sprite).spriteFrame = this.iconSpriteFrame[r] : n.getComponent(Sprite).spriteFrame = this.oldActiveImg : n.getComponent(Sprite).spriteFrame = this.iconSpriteFrame[r], 12 == r && sys.isObjectValid(t.php_data) && sys.isObjectValid(t.php_data.prop_type) && sys.isObjectValid(t.php_data.prop_icon)) {
                let e = Number(t.php_data.prop_type), i = Number(t.php_data.prop_icon), a = "";
                1 == e ? a = "skin_props_head_" + i : 2 == e ? a = "skin_props_headkuang_" + i : 3 == e ? a = "skin_props_hupai_" + i : 4 == e ? a = "skin_props_enterance_" + i : 5 == e ? a = "skin_props_desk_" + i : 6 == e ? a = "skin_props_pokerback_" + i : 7 == e && (a = "skin_props_pokerfront_" + i);
                a.length > 0 && Utils.shared().setImage(n, a, this.skinPropsAtlas);
                s.string = 3 == e || 4 == e ? t.num + "" : "";
            }
        }
        else {
            let e = "";
            r == CUSTOM_REWARD_ENUM.CLUB_LEVEL ? t.num && t.num > 0 && (e = "club_" + t.num, Utils.shared().setImage(n, e, this.commonIconAtlas)) : r == CUSTOM_REWARD_ENUM.HEADFRAME_LEVEL ? t.num && t.num > 0 && (a.active = true, e = "head_frame_" + t.num, Utils.shared().setImage(n, e, this.commonIconAtlas)) : r == CUSTOM_REWARD_ENUM.VIP_LEVEL && t.num && t.num > 0 && (e = "vip_" + t.num, Utils.shared().setImage(n, e, this.commonIconAtlas));
        }
        return i;
    }
    onButtonClick(t, e) {
        SoundManager.shared().playFx("click");
        this._bBtnEnable && (this._bBtnEnable = false, TweenTool.delayAct(this.node, (() => {
            this._bBtnEnable = true;
        }), 1, true), "assure" == e ? this.callback && this.callback(1) : "cancel" == e ? this.callback && this.callback(2) : "close" == e ? this.callback && this.callback(3) : "kefu" == e && Utils.shared().doJumpLogic(PushEvent.JUMP_TO_FEEDBACK), ToolUtils.isObjValid(this.node) && (this.isNext && PushCenter.shared().pushEvent(PushEvent.Update_NextPopActivity), this.addCashCount > 0 && "PLAY NOW" != this.assureWz && (ToolUtils.getIsInRoom() || Utils.shared().flyGoldAnim1(this.addCashCount)), this.node.destroy()));
    }
    onBackView() {
    }
}
