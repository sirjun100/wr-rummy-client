// @ts-nocheck
// Recovered from index.js:441
import { _decorator, Label, Node } from "cc";
import SoundManager from "./SoundManager";
import User from "./User";
import BaseLayer from "./BaseLayer";
import i18nMgr from "./i18nMgr";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("RummyGameDealsRecord")
export default class RummyGameDealsRecord extends BaseLayer {
    @property(Node)
    public bgView: Node = null;
    @property(Node)
    public layer2: Node = null;
    public startScore: number = 0;
    public data: any = undefined;
    public gameController: any = undefined;
    onLoad() {
        this.bIsInGame = true;
        for (let e = 1; e < 6; e++) {
            let t = "";
            t = "item" + e;
            let i = this.layer2.getChildByName(t);
            i.getChildByName("Text1").getComponent(Label).string = "";
            i.getChildByName("Text2").getComponent(Label).string = "";
            i.getChildByName("Text3").getComponent(Label).string = "";
        }
    }
    start() {
        super.start();
        ToolUtils.showFullScreen(this.node.getChildByName("bg1"));
        ToolUtils.startShowAnim(this.node.getChildByName("rootNode"));
    }
    onDestroy() {
        super.onDestroy();
    }
    initView(e, t, i, l) {
        this.data = e;
        this.gameController = i;
        this.tid_key = l;
        this.startScore = t;
        let o = [];
        for (let t = 0, i = e.length; t < i; t++) {
            e[t].uid == User.shared().data.uid ? o.unshift(e[t]) : o.push(e[t]);
        }
        this.showlayer2(o);
    }
    showlayer2(e) {
        let t = this.layer2.getChildByName("title_layout"), i = this.layer2.getChildByName("Score_layout"), l = "", o = "", r = e.length, s = 0;
        i18nMgr.shared().changeLabelLanguage(this.layer2.getChildByName("item1").getChildByName("Text1").getComponent(Label), "gameRummy_deals_record.start");
        this.layer2.getChildByName("item1").getChildByName("Text2").getComponent(Label).string = this.startScore + "";
        this.layer2.getChildByName("item1").getChildByName("Text3").getComponent(Label).string = this.startScore + "";
        for (let n = 0; n < r; n++) {
            let r = n + 2;
            if (0 != n && null != e[n].name) {
                l = "Text" + r;
                let i = e[n].name + "";
                i = ToolUtils.GetShortName2(i, 10, true);
                t.getChildByName(l).getComponent(Label).string = i + "";
            }
            null != e[n].total_score && (l = "Text" + r, o = ToolUtils.parse_double(e[n].total_score), i.getChildByName(l).getComponent(Label).string = o + "");
            e[n].detail_score.length > 0 && (s = e[n].detail_score.length);
        }
        for (let t = 0; t < s; t++) {
            l = "item" + (t + 2);
            let i = this.layer2.getChildByName(l);
            i.active = true;
            let o = t + 1;
            i.getChildByName("Text1").getComponent(Label).string = o + "";
            for (let o = 0; o < r; o++) {
                if (l = "Text" + (o + 2), null != e[o].detail_score[t]) {
                    let r = e[o].detail_score[t].score;
                    i.getChildByName(l).getComponent(Label).string = r + "";
                }
            }
        }
    }
    touchBtnEvent(e, t) {
        SoundManager.shared().playFx("click");
        ToolUtils.isObjValid(this.node) && this.node.destroy();
    }
}
