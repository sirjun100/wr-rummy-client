// @ts-nocheck
// Recovered from index.js:281
import { _decorator, tween } from "cc";
import i18nMgr from "./i18nMgr";
import PushCenter from "./PushCenter";
import { TLog } from "./TLog";
import { ToolUtils } from "./ToolUtils";
import TweenTool from "./TweenTool";
import Utils from "./Utils";
import GameConfig from "./GameConfig";
import NetConfig from "./NetConfig";
import PushEvent from "./PushEvent";
import URLConfig from "./URLConfig";
import User from "./User";
import NetHostManager from "./NetHostManager";
import Server from "./Server";
import gameNetworkDelay from "./gameNetworkDelay";
import { LuckyBallGameCmd } from "./LuckyBallGameCmd";
const { ccclass } = _decorator;
@ccclass("LuckyBallGameManager")
export class LuckyBallGameManager {
    static _instance = null;
    public _TAG: string = "LuckyBallGameManager";
    public checkLoadingRefresh: boolean = false;
    public sceneNode: any = null;
    public popNode: any = null;
    public _tidKey: string = "";
    public _vid: number = 0;
    public _is_xyc_complete: boolean = false;
    public _game_win_socre: number = 0;
    public _game_state_type: number = 0;
    public _free_game_total_win: number = 0;
    public _jackpot_type: number = 0;
    public isAnimPlaying: boolean = false;
    public data: any = {};
    constructor() {
        this.init();
    }
    static shared() : LuckyBallGameManager {
        return null == this._instance && (this._instance = new LuckyBallGameManager), this._instance;
    }
    init() {
    }
    sendGameInfoRequest() {
        let t = { cmd: LuckyBallGameCmd.GM_GET_TABLE_INFO, uid: User.shared().data.uid, version: GameConfig.Server_Api_Ver, skey: User.shared().getSkey(), vid: ToolUtils.curRoomId, tid_key: this._tidKey };
        Server.shared().send(t);
        LuckyBallGameManager.shared().checkLoadingRefresh = true;
        TweenTool.delayAct(this.sceneNode, (() => {
            LuckyBallGameManager.shared().checkLoadingRefresh && (LuckyBallGameManager.shared().checkLoadingRefresh = false, ToolUtils.backgroundWebSocketReconnection = false, Server.shared().disconnectWebSocket(), TweenTool.delayAct(this.sceneNode, (() => {
                LuckyBallGameManager.shared().loginGameServer();
            }), 0.2, true));
        }), 5, true);
    }
    sendLoginOutRequest() {
        let e = { cmd: LuckyBallGameCmd.GM_LOGINOUT_REQUEST, uid: User.shared().data.uid, version: GameConfig.Server_Api_Ver, skey: User.shared().getSkey(), vid: ToolUtils.curRoomId, tid_key: this._tidKey };
        Server.shared().send(e);
    }
    sendGameRecordRequest() {
        let e = { cmd: LuckyBallGameCmd.GM_HISTORY_RECORD_REQUSET, uid: User.shared().data.uid, version: GameConfig.Server_Api_Ver, skey: User.shared().getSkey(), vid: ToolUtils.curRoomId, tid_key: this._tidKey };
        Server.shared().send(e);
    }
    loginGameServer() {
        this.checkLoadingRefresh = false;
        Server.shared().setOpenCb((() => {
            User.shared().send_login_gate_request();
        }));
        Server.shared().setReconCb((() => {
            User.shared().send_request_game_tableinfo();
        }));
        let e = URLConfig.orginHttp_tcp, t = NetHostManager.shared().chooseBestTcpIpConn(ToolUtils.curRoomId), s = NetHostManager.shared().chooseBestTcpPortConn(ToolUtils.curRoomId);
        "-1" != t && -1 != s && (e = 443 == s ? "wss://" + t + ":443" : "ws://" + t + ":" + s);
        Server.shared().createSocket(e);
        User.shared().isGameDisconnectServer = false;
    }
    login(e = false) {
        User.shared().curTid_key === this._tidKey && this.loginGameServer();
    }
    create_new_table() {
        if (User.shared().isGameDisconnectServer) {
            return Server.shared().disconnectWebSocket(), void this.login(true);
        }
        this.send_create_table_request();
    }
    send_create_table_request() {
        let e = { cmd: NetConfig.GM_CREATE_TABLE_REQUEST, uid: User.shared().data.uid, version: GameConfig.Server_Api_Ver, skey: User.shared().getSkey(), vid: this._vid, auto_sort: User.shared().auto_sort, ch_id: GameConfig.CHANNEL_ID };
        e.tid_key = this._tidKey;
        Server.shared().send(e);
    }
    handler_server_login_gate_return(e) {
        try {
            if (0 == e.res) {
                this.send_login_request();
                PushCenter.shared().pushEvent(GameConfig.NetWorkDelayShow);
            }
            else if (2 == e.res) {
                gameNetworkDelay.shared().setActiveDisconnect(true);
                User.shared().isGameDisconnectServer = true;
                Server.shared().disconnectWebSocket();
                let t = "You are not in any table!", s = "NOTICE";
                ToolUtils.isSafeString(e.title).length > 0 && (s = e.title);
                ToolUtils.isSafeString(e.msg).length > 0 && (t = e.msg);
                TweenTool.delayAct(this.sceneNode, (() => {
                    window.InGameScene && Utils.shared().showCommomDialog(t, s, (e => {
                        PushCenter.shared().pushEvent(PushEvent.ExitGameToHall);
                    }), false, ToolUtils.getIsNormalDirection());
                }), 2, true);
            }
            else {
                Utils.shared().showCommomDialog(i18nMgr.shared().getValueByKey("rummy_main.gameTipstext11"), i18nMgr.shared().getValueByKey("gameRummy_notice_Pop.notice"), (e => {
                    PushCenter.shared().pushEvent(PushEvent.ExitGameToHall);
                }), false, ToolUtils.getIsNormalDirection(), null, null, null, null, null, null);
            }
        }
        catch (e) {
            TLog.printError("trycatch handler_server_login_gate_return ,error:", e);
        }
    }
    send_login_request() {
        let e = { cmd: NetConfig.GM_CREATE_TABLE_REQUEST, uid: User.shared().data.uid, skey: User.shared().getSkey(), version: GameConfig.Server_Api_Ver, ch_id: GameConfig.CHANNEL_ID, isNewTable: 1, tid_key: this._tidKey };
        e.vid = ToolUtils.curVId;
        Server.shared().send(e);
    }
    static parseJackPotNum(e) {
        if (e < 1000) {
            return `${Math.floor(e)}`;
        }
        if (e < 100000) {
            const t = e % 1000;
            return `${Math.floor(e / 1000) % 100},${t.toString().padStart(3, "0")}`;
        }
        if (e < 10000000) {
            const t = e % 1000, s = Math.floor(e / 1000) % 100;
            return `${Math.floor(e / 100000) % 100},${s.toString().padStart(2, "0")},${t.toString().padStart(3, "0")}`;
        }
        if (e < 1000000000) {
            const t = e % 1000, s = Math.floor(e / 1000) % 100, r = Math.floor(e / 100000) % 100;
            return `${Math.floor(e / 10000000) % 100},${r.toString().padStart(2, "0")},${s.toString().padStart(2, "0")},${t.toString().padStart(3, "0")}`;
        }
        {
            const t = e % 1000, s = Math.floor(e / 1000) % 100, r = Math.floor(e / 100000) % 100, a = Math.floor(e / 10000000) % 100;
            return `${Math.floor(e / 1000000000) % 100},${a.toString().padStart(2, "0")},${r.toString().padStart(2, "0")},${s.toString().padStart(2, "0")},${t.toString().padStart(3, "0")}`;
        }
    }
    static playTextAnim(t, s, a, n) {
        if (TweenTool.stopNodeAction(t), t.string = LuckyBallGameManager.parseJackPotNum(a), Math.abs(n - a) > 0) {
            const i = 0.03, o = (n - a) / Math.floor(s / i);
            let d = a, c = tween(t).delay(i), l = tween(t).call((() => {
                d += o;
                let s = LuckyBallGameManager.parseJackPotNum(d);
                t.string = "₹" + s;
            }));
            tween(t).sequence(c, l).repeatForever().start();
        }
    }
    static arrayUnique(e) {
        const t = {}, s = [];
        for (let r = 0; r < e.length; r++) {
            const a = e[r];
            t[a] || (s.push(a), t[a] = true);
        }
        return s.sort(((e, t) => e < t ? -1 : e > t ? 1 : 0)), s;
    }
}
