// @ts-nocheck
// Recovered from index.js:381
import { _decorator, Button, EditBox, HorizontalTextAlignment, Label, Node, RichText, Sprite, SpriteFrame, sys, v3 } from "cc";
import SoundManager from "./SoundManager";
import Utils from "./Utils";
import BaseLayer from "./BaseLayer";
import PushCenter from "./PushCenter";
import PushEvent from "./PushEvent";
import { TransferPlatform } from "./TransferPlatform";
import User from "./User";
import i18nMgr from "./i18nMgr";
import CommDefine from "./CommDefine";
import { ToolUtils } from "./ToolUtils";
import GameConfig from "./GameConfig";
const { ccclass, property } = _decorator;
@ccclass("RedemptionCode")
export class RedemptionCode extends BaseLayer {
    @property(Node)
    public rootNode: Node = null;
    @property(EditBox)
    public edit_code: EditBox = null;
    @property(Button)
    public btn_redeem: Button = null;
    @property([SpriteFrame])
    public btnSprites: SpriteFrame[] = [];
    @property(Node)
    public errNode: Node = null;
    @property([SpriteFrame])
    public chip_imgs_617: SpriteFrame[] = [];
    public isNext: boolean = false;
    public lastClick: number = 0;
    onLoad() {
    }
    initParaData(e) {
        sys.isObjectValid(e.isNext) && (this.isNext = e.isNext);
    }
    fitChipMode() {
        if (0 == GameConfig.CHIPS_MODLE) {
            return;
        }
        let e = 2000617 == GameConfig.CHANNEL_ID;
        e && e && 0 == GameConfig.GAME_HALL_THEME && (this.rootNode.getChildByName("bg").getComponent(Sprite).spriteFrame = this.chip_imgs_617[0]);
    }
    start() {
        super.start();
        this.startShowAnim(this.rootNode);
        this.btn_redeem.node.getComponent(Sprite).spriteFrame = this.btnSprites[1];
        Utils.updateLabelMaterial(this.btn_redeem.node.getChildByName("wz"), CommDefine.gradient.btn_gray);
        ToolUtils.showFullScreen(this.node.getChildByName("mask"));
        PushCenter.shared().addListener(PushEvent.RichTextClick, (e => {
            ToolUtils.isObjValid(this.node) && this.onButtonClick(null, e);
        }), this);
        this.errNode.active = false;
        this.dealMultipleLanguages();
    }
    dealMultipleLanguages() {
        if (2 == i18nMgr.shared().language) {
            let e = this.rootNode.getChildByName("tips1").getPosition();
            this.rootNode.getChildByName("tips1").setPosition(v3(e.x, e.y + 15, e.z));
        }
        else {
            3 == i18nMgr.shared().language && (this.rootNode.getChildByName("tips1").getComponent(RichText).horizontalAlign = HorizontalTextAlignment.RIGHT);
        }
    }
    onEditBoxChanged(e, t, i) {
        if (ToolUtils.isObjValid(this.node)) {
            if (!/^[a-zA-Z0-9]+$/.test(e)) {
                let i = e.replace(/[^a-zA-Z0-9]/g, "");
                t.string = i;
            }
            sys.isObjectValid(t.string) && t.string.length >= 8 && t.string.length <= 30 ? this.btn_redeem.node.getComponent(Sprite).spriteFrame = this.btnSprites[0] : this.btn_redeem.node.getComponent(Sprite).spriteFrame = this.btnSprites[1];
            this.rootNode.getChildByName("brn_clear").active = sys.isObjectValid(t.string) && t.string.length > 0;
            this.rootNode.getChildByName("brn_paste").active = sys.isObjectValid(t.string) && 0 == t.string.length;
        }
    }
    onButtonClick(e, t) {
        if (SoundManager.shared().playFx("click"), "close" == t) {
            this.onBackView();
        }
        else if ("clear" == t) {
            ToolUtils.isObjValid(this.node) && (this.edit_code.string = "", this.rootNode.getChildByName("brn_clear").active = false, this.rootNode.getChildByName("brn_paste").active = true, this.btn_redeem.node.getComponent(Sprite).spriteFrame = this.btnSprites[1]);
        }
        else if ("redeem" == t) {
            if (sys.now() - this.lastClick < 1000) {
                return;
            }
            this.lastClick = sys.now();
            let e = this.edit_code.string;
            if (sys.isObjectValid(e) && e.length >= 8 && e.length <= 30) {
                Utils.shared().showLoading(10, true, (() => {
                    Utils.shared().showToast(i18nMgr.shared().getValueByKey("utlis.text6"), 3, 0, ToolUtils.getIsNormalDirection());
                }));
                User.shared().requestDoExchange(e, 1, (e => {
                    ToolUtils.isObjValid(this.node) && (sys.isObjectValid(e) ? (this.errNode.active = true, this.errNode.getComponent(Label).string = e) : (this.errNode.active = false, this.edit_code.string = "", this.btn_redeem.node.getComponent(Sprite).spriteFrame = this.btnSprites[1]));
                }));
            }
            else {
                let e = i18nMgr.shared().getValueByKey("redeemcode.error_tips");
                this.errNode.getComponent(Label).string = e;
                this.errNode.active = true;
            }
        }
        else if ("telegram" == t) {
            1 === TransferPlatform.shared().checkPackageInstalled("org.telegram.messenger") ? TransferPlatform.shared().openApplicationChat("org.telegram.messenger", ToolUtils.feedback_data.tg_official_url) : 1 === TransferPlatform.shared().checkPackageInstalled("org.telegram.messenger.web") ? TransferPlatform.shared().openApplicationChat("org.telegram.messenger.web", ToolUtils.feedback_data.tg_official_url) : sys.openURL(ToolUtils.feedback_data.tg_official_url);
        }
        else if ("facebook" == t) {
            if (1 === TransferPlatform.shared().checkPackageInstalled("com.facebook.katana")) {
                let e = "fb://facewebmodal/f?href=https://www.facebook.com/" + ToolUtils.feedback_data.fburl, t = TransferPlatform.shared().getPackgeVersionCode("com.facebook.katana");
                t > 0 && t < 3002850 && (e = "fb://page/" + ToolUtils.feedback_data.fburl);
                TransferPlatform.shared().openApplicationChat("com.facebook.katana", e);
            }
            else {
                sys.openURL("https://www.facebook.com/" + ToolUtils.feedback_data.fburl);
            }
        }
        else if ("instagram" == t) {
            1 === TransferPlatform.shared().checkPackageInstalled("com.instagram.android") ? TransferPlatform.shared().openApplicationChat("com.instagram.android", ToolUtils.feedback_data.igurl) : sys.openURL(ToolUtils.feedback_data.igurl);
        }
        else if ("paste" == t) {
            let e = TransferPlatform.shared().getPasteBoard(), t = /^[a-zA-Z0-9]+$/;
            null != e && (t.test(e) ? this.edit_code.string = e : this.edit_code.string = e.replace(/[^a-zA-Z0-9]/g, ""), sys.isObjectValid(this.edit_code.string) && this.edit_code.string.length >= 8 && this.edit_code.string.length <= 30 ? (this.btn_redeem.node.getComponent(Sprite).spriteFrame = this.btnSprites[0], Utils.updateLabelMaterial(this.btn_redeem.node.getChildByName("wz"), CommDefine.gradient.btn_green)) : (this.btn_redeem.node.getComponent(Sprite).spriteFrame = this.btnSprites[1], Utils.updateLabelMaterial(this.btn_redeem.node.getChildByName("wz"), CommDefine.gradient.btn_gray)), this.rootNode.getChildByName("brn_clear").active = sys.isObjectValid(this.edit_code.string) && this.edit_code.string.length > 0, this.rootNode.getChildByName("brn_paste").active = sys.isObjectValid(this.edit_code.string) && 0 == this.edit_code.string.length);
        }
    }
    onBackView() {
        ToolUtils.isObjValid(this.node) && (this.isNext && PushCenter.shared().pushEvent(PushEvent.Update_NextPopActivity), this.node.destroy());
    }
}
