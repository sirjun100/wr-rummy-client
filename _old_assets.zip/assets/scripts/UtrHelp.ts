// @ts-nocheck
// Recovered from index.js:663
import { _decorator, Label, Node, Sprite, SpriteFrame, sys, UITransform, v3, Vec3, view } from "cc";
import SoundManager from "./SoundManager";
import BaseLayer from "./BaseLayer";
import { ToolUtils } from "./ToolUtils";
const { ccclass, property } = _decorator;
@ccclass("UtrHelp")
export class UtrHelp extends BaseLayer {
    @property(Node)
    public rootNode: Node = null;
    @property(Node)
    public bgNode: Node = null;
    @property(Node)
    public moban: Node = null;
    @property(Label)
    public titlelabel: Label = null;
    @property([SpriteFrame])
    public helpFrame: SpriteFrame[] = [];
    @property([SpriteFrame])
    public pointFrame: SpriteFrame[] = [];
    @property([Sprite])
    public pointTab: Sprite[] = [];
    public titles: any[] = ["TYPE1", "TYPE2", "TYPE3"];
    public curPage: number = 1;
    public totalPage: number = 3;
    start() {
        super.start();
        this.updatePoint();
        let t = view.getVisibleSize(), e = this.rootNode.getComponent(UITransform), i = this.bgNode.getComponent(UITransform), r = this.node.getComponent(UITransform);
        ToolUtils.getOrientation() ? (this.node.setRotationFromEuler(new Vec3(0, 0, 90)), e.setContentSize(t.height, t.width), i.setContentSize(t.height, t.width), r.setContentSize(t.height, t.width)) : (e.setContentSize(t.width, t.height), i.setContentSize(t.width, t.height), r.setContentSize(t.width, t.height), this.rootNode.setPosition(v3(0, -sys.getSafeAreaRect().y, 0)));
    }
    onButtonClick(t, e) {
        SoundManager.shared().playFx("click");
        "close" == e ? ToolUtils.isObjValid(this.node) && this.node.destroy() : "right" == e ? (this.curPage = this.curPage + 1, this.curPage >= this.totalPage && (this.curPage = this.totalPage), this.updatePoint()) : "left" == e && (this.curPage = this.curPage - 1, this.curPage <= 0 && (this.curPage = 1), this.updatePoint());
    }
    updatePoint() {
        if (this.pointTab) {
            for (let t = 0; t < this.pointTab.length; t++) {
                t == this.curPage - 1 ? this.pointTab[t].spriteFrame = this.pointFrame[1] : this.pointTab[t].spriteFrame = this.pointFrame[0];
            }
        }
        let t = this.moban.getChildByName("img");
        t && (t.active = true, t.getComponent(Sprite).spriteFrame = this.helpFrame[this.curPage - 1], this.titlelabel.string = this.titles[this.curPage - 1]);
    }
}
